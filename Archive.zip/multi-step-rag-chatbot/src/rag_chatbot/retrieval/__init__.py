"""Retrieval layer over Chroma."""
