"""FastAPI entrypoint."""
