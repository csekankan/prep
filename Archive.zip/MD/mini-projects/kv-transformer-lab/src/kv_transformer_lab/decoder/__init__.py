"""Decoder block components."""
