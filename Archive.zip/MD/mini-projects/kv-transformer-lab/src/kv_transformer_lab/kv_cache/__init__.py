"""KV cache teaching code."""
