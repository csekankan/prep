"""Attention primitives."""
