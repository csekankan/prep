#!/usr/bin/env python3
"""Remove script-appended FAANG blocks (capstone / full study guide markers only)."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "MD"
MARKER = "## FAANG Interview Deep Dive"
CAPSTONE = "Interview Q&A (capstone)"
STUDY_GUIDE = "full study guide"


def should_strip(block: str) -> bool:
    return CAPSTONE in block or STUDY_GUIDE in block


def strip_file(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    if MARKER not in text:
        return False
    idx = text.rfind(MARKER)
    if idx == -1:
        return False
    # Include preceding --- separator if present
    start = idx
    prefix = text[:start].rstrip()
    if prefix.endswith("---"):
        start = prefix.rfind("---")
    else:
        start = idx
    block = text[start:]
    if not should_strip(block):
        return False
    new_text = text[:start].rstrip() + "\n"
    path.write_text(new_text, encoding="utf-8")
    return True


def main() -> None:
    updated = []
    for path in sorted(ROOT.rglob("*.md")):
        if path.name == "DEEP_DIVE_COVERAGE.md":
            continue
        if strip_file(path):
            updated.append(path.relative_to(ROOT))
    print(f"Stripped {len(updated)} files:")
    for p in updated:
        print(f"  {p}")


if __name__ == "__main__":
    main()
