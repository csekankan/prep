# Ragas for RAG, LLM & Agent Evaluation — Complete Tutorial

> Ragas ("RAG Assessment") is the most widely used open-source library for evaluating RAG pipelines. This tutorial covers its core data model, every major metric (with formulas and worked examples), test-set generation, custom metrics, agent evaluation, CI usage, and how it compares to DeepEval.

> **Version note:** Ragas changed its API significantly in v0.2 (the `SingleTurnSample` / `EvaluationDataset` / `user_input` / `response` naming used here). Older tutorials use `question` / `answer` / `contexts` / `ground_truth` — that's the v0.1 API. Pin your version (`pip install "ragas==0.2.*"` or later) and check the docs if an import fails.

---

## Table of Contents

1. [What is Ragas and Why Use It](#1-what-is-ragas-and-why-use-it)
2. [Setup](#2-setup)
3. [Core Data Model: Samples and Datasets](#3-core-data-model-samples-and-datasets)
4. [The Evaluation Pipeline](#4-the-evaluation-pipeline)
5. [RAG Metrics In Depth](#5-rag-metrics-in-depth)
6. [General-Purpose & Non-LLM Metrics](#6-general-purpose--non-llm-metrics)
7. [Custom Metrics: AspectCritic, Rubrics, and Your Own](#7-custom-metrics-aspectcritic-rubrics-and-your-own)
8. [Synthetic Test-Set Generation](#8-synthetic-test-set-generation)
9. [End-to-End: Evaluating a RAG App](#9-end-to-end-evaluating-a-rag-app)
10. [Evaluating Agents and Multi-Turn Conversations](#10-evaluating-agents-and-multi-turn-conversations)
11. [Ragas in CI and with LangSmith / Langfuse](#11-ragas-in-ci-and-with-langsmith--langfuse)
12. [Ragas vs DeepEval](#12-ragas-vs-deepeval)
13. [Cheat Sheet & Interview Questions](#13-cheat-sheet--interview-questions)

---

## 1. What is Ragas and Why Use It

A RAG app can fail in two independent places:

```
user_input ──► [ RETRIEVER ] ──► retrieved_contexts ──► [ GENERATOR ] ──► response
                    ▲                                         ▲
          "Did we fetch the right docs?"          "Did the LLM use them correctly?"
```

Ragas gives you metrics for each side, mostly computed with **LLM-as-a-judge** plus embeddings, and it popularised the now-standard RAG metric vocabulary: **faithfulness, answer/response relevancy, context precision, context recall**.

Key features:

| Feature | Description |
|---|---|
| RAG metrics | Faithfulness, Response Relevancy, Context Precision/Recall, Noise Sensitivity, Context Entity Recall |
| General metrics | Factual Correctness, Semantic Similarity, AspectCritic, Rubrics scoring |
| Non-LLM metrics | BLEU, ROUGE, exact match, string presence, non-LLM context precision/recall |
| Agent metrics | Tool Call Accuracy, Agent Goal Accuracy, Topic Adherence |
| Test-set generation | Generate question/answer/context goldens from your documents (knowledge-graph based) |
| Integrations | LangChain, LlamaIndex, Haystack, LangSmith, Langfuse, Arize, any LLM via wrappers |

Many metrics are **reference-free** (no ground-truth answer needed) — useful when you have no labelled data yet.

---

## 2. Setup

```bash
pip install -U ragas langchain-openai
export OPENAI_API_KEY="sk-..."
```

Ragas needs an **evaluator LLM** (judge) and, for some metrics, an **embedding model**. Wrap LangChain models:

```python
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper

evaluator_llm = LangchainLLMWrapper(ChatOpenAI(model="gpt-4o", temperature=0))
evaluator_embeddings = LangchainEmbeddingsWrapper(OpenAIEmbeddings(model="text-embedding-3-small"))
```

Any LangChain chat model works as the judge — Anthropic, Bedrock, Azure OpenAI, Gemini, Ollama:

```python
from langchain_anthropic import ChatAnthropic
evaluator_llm = LangchainLLMWrapper(ChatAnthropic(model="claude-sonnet-4-5"))
```

(Newer Ragas versions also offer `ragas.llms.llm_factory("gpt-4o")` as a shortcut.)

---

## 3. Core Data Model: Samples and Datasets

### 3.1 `SingleTurnSample`

One question → one answer interaction.

```python
from ragas import SingleTurnSample

sample = SingleTurnSample(
    user_input="When was the Eiffel Tower completed?",
    retrieved_contexts=[
        "The Eiffel Tower was completed in 1889 for the World's Fair.",
        "It is 330 metres tall and located in Paris.",
    ],
    response="The Eiffel Tower was completed in 1889.",
    reference="The Eiffel Tower was completed in 1889.",       # ground-truth answer (optional)
    reference_contexts=["The Eiffel Tower was completed in 1889 for the World's Fair."],  # ideal contexts (optional)
)
```

| Field | Meaning | Who provides it |
|---|---|---|
| `user_input` | The question / prompt | dataset |
| `response` | What your app answered | **your app at runtime** |
| `retrieved_contexts` | Chunks your retriever returned | **your app at runtime** |
| `reference` | Ground-truth answer | dataset (human or synthetic) |
| `reference_contexts` | Ideal contexts that should be retrieved | dataset |
| `multi_responses` | Several responses (for some metrics) | your app |
| `rubrics` | Per-sample rubric | dataset |

> **Mapping to DeepEval:** `user_input`=`input`, `response`=`actual_output`, `retrieved_contexts`=`retrieval_context`, `reference`=`expected_output`, `reference_contexts`≈`context`.

### 3.2 `MultiTurnSample`

For chatbots and agents — a list of messages (human / AI / tool), see section 10.

### 3.3 `EvaluationDataset`

```python
from ragas import EvaluationDataset

dataset = EvaluationDataset(samples=[sample1, sample2, ...])

# or from plain dicts / pandas / Hugging Face
dataset = EvaluationDataset.from_list([
    {"user_input": "...", "retrieved_contexts": ["..."], "response": "...", "reference": "..."},
])
dataset = EvaluationDataset.from_pandas(df)

dataset.to_pandas()
dataset.to_jsonl("eval.jsonl")
```

---

## 4. The Evaluation Pipeline

```
 ┌────────────┐   ┌────────────────────┐   ┌───────────────────┐   ┌───────────────┐   ┌───────────────┐
 │ 1. Test set│──►│ 2. Run your RAG app│──►│ 3. Build samples  │──►│ 4. evaluate() │──►│ 5. Analyse    │
 │ questions +│   │ for each question  │   │ (input, response, │   │ with metrics  │   │ per-sample &  │
 │ references │   │                    │   │  contexts, ref)   │   │ + judge LLM   │   │ aggregate     │
 └────────────┘   └────────────────────┘   └───────────────────┘   └───────────────┘   └───────┬───────┘
       ▲                                                                                       │
       └─────────────── change chunking / embeddings / top_k / reranker / prompt / model ◄─────┘
```

### 4.1 Bulk evaluation

```python
from ragas import evaluate
from ragas.metrics import (
    Faithfulness, ResponseRelevancy, LLMContextPrecisionWithReference, LLMContextRecall,
)

result = evaluate(
    dataset=dataset,
    metrics=[
        Faithfulness(),
        ResponseRelevancy(),
        LLMContextPrecisionWithReference(),
        LLMContextRecall(),
    ],
    llm=evaluator_llm,
    embeddings=evaluator_embeddings,
)

print(result)               # {'faithfulness': 0.91, 'answer_relevancy': 0.88, ...}
df = result.to_pandas()     # one row per sample, one column per metric
df.sort_values("faithfulness").head()   # inspect worst cases first
```

### 4.2 Scoring a single sample

Every metric has async scoring methods — handy in notebooks and for debugging:

```python
from ragas.metrics import Faithfulness

faith = Faithfulness(llm=evaluator_llm)
score = await faith.single_turn_ascore(sample)   # in a notebook / async context
# or: import asyncio; asyncio.run(faith.single_turn_ascore(sample))
```

### 4.3 Useful `evaluate()` options

| Option | Purpose |
|---|---|
| `llm`, `embeddings` | Default judge / embeddings for all metrics |
| `run_config=RunConfig(max_workers=8, timeout=120, max_retries=5)` | Concurrency, timeouts, retries (rate limits) |
| `batch_size` | Batch judge calls |
| `raise_exceptions=False` | Return NaN for failed rows instead of crashing |
| `callbacks` | LangChain callbacks (e.g., LangSmith tracing of judge calls) |
| `token_usage_parser` | Track judge token cost (`result.total_cost(...)`) |

---

## 5. RAG Metrics In Depth

### 5.1 Overview

| Metric | Evaluates | Needs | Reference-free? | Range |
|---|---|---|---|---|
| **Faithfulness** | Generator — is the response supported by the contexts? | `user_input`, `response`, `retrieved_contexts` | Yes | 0–1 ↑ |
| **Response Relevancy** | Generator — does the response address the question? | `user_input`, `response` (+ embeddings) | Yes | 0–1 ↑ |
| **Context Precision** | Retriever — are relevant chunks ranked high? | `user_input`, `retrieved_contexts`, `reference` (or `response`) | With-reference / without-reference variants | 0–1 ↑ |
| **Context Recall** | Retriever — did we retrieve everything needed? | `user_input`, `retrieved_contexts`, `reference` | No | 0–1 ↑ |
| **Context Entity Recall** | Retriever — are the reference's entities present in contexts? | `retrieved_contexts`, `reference` | No | 0–1 ↑ |
| **Noise Sensitivity** | System — how often does irrelevant context cause wrong claims? | `user_input`, `response`, `retrieved_contexts`, `reference` | No | 0–1 ↓ (lower is better) |
| **Factual Correctness** | End-to-end — response vs reference claims | `response`, `reference` | No | 0–1 ↑ |

### 5.2 Faithfulness

**Question:** Is every claim in the response supported by the retrieved context?

**Algorithm:**
1. Break `response` into atomic **claims**.
2. For each claim, the judge decides whether it can be **inferred from** `retrieved_contexts`.
3. Score:

\[
\text{Faithfulness} = \frac{\#\text{ claims supported by context}}{\#\text{ total claims}}
\]

**Example:**

```
context:  "Einstein was born on 14 March 1879 in Ulm, Germany."
response: "Einstein was born in Germany on 20 March 1879."
claims:   ["born in Germany" ✓, "born on 20 March 1879" ✗]
score:    1/2 = 0.5
```

Low faithfulness → the **generator hallucinates** beyond the context. Fix: stronger grounding prompt, lower temperature, better model, or citation requirements.

> Variant: `FaithfulnesswithHHEM` uses Vectara's open HHEM classifier model to verify claims instead of an LLM judge (cheaper, faster).

### 5.3 Response Relevancy (a.k.a. Answer Relevancy)

**Question:** Does the response actually answer the user's question (not incomplete, not padded with irrelevant info)?

**Algorithm (reverse-engineering the question):**
1. The judge generates *N* (default 3) questions that the `response` would be an answer to.
2. Embed those generated questions and the original `user_input`.
3. Score = mean cosine similarity:

\[
\text{ResponseRelevancy} = \frac{1}{N}\sum_{i=1}^{N} \cos(E_{g_i}, E_{o})
\]

If the response is evasive/non-committal ("I'm not sure"), the judge flags it and the score is 0.

Note: this measures **relevance, not correctness**. A confidently wrong but on-topic answer can still score high — pair it with Faithfulness or Factual Correctness.

### 5.4 Context Precision

**Question:** Of the retrieved chunks, are the useful ones ranked **at the top**?

**Algorithm:**
1. For each chunk at rank *k*, the judge decides if it's relevant (\(v_k \in \{0,1\}\)) — by comparing to the `reference` (`LLMContextPrecisionWithReference`) or to the `response` (`LLMContextPrecisionWithoutReference`).
2. Compute precision@k at every rank and average over relevant ranks:

\[
\text{ContextPrecision@K} = \frac{\sum_{k=1}^{K} \left(\text{Precision@}k \times v_k\right)}{\#\text{ relevant items in top }K}
\qquad
\text{Precision@}k = \frac{\#\text{relevant in top }k}{k}
\]

**Example:** relevance by rank `[1, 0, 1]` → (1/1 + 2/3) / 2 = **0.83**. Same chunks ordered `[0, 1, 1]` → (1/2 + 2/3) / 2 = **0.58**.

Low precision → right chunks exist but are buried. Fix: add a **reranker**, tune hybrid search weights.

Variants:
- `LLMContextPrecisionWithReference` – judge compares chunks to the reference answer.
- `LLMContextPrecisionWithoutReference` – compares chunks to the response (no labels needed).
- `NonLLMContextPrecisionWithReference` – compares chunks to `reference_contexts` with string similarity (no judge).

### 5.5 Context Recall

**Question:** Did the retriever fetch **all** the information needed to produce the reference answer?

**Algorithm:**
1. Break the `reference` into claims/sentences.
2. For each, judge whether it can be **attributed** to `retrieved_contexts`.

\[
\text{ContextRecall} = \frac{\#\text{ reference claims supported by retrieved context}}{\#\text{ reference claims}}
\]

**Example:**

```
reference: "The Eiffel Tower is in Paris. It was completed in 1889. It is 330 m tall."
contexts:  ["The Eiffel Tower is in Paris and was completed in 1889."]
claims:    [Paris ✓, 1889 ✓, 330 m ✗]  → 2/3 = 0.67
```

Low recall → missing information. Fix: better embeddings, hybrid (BM25 + vector) search, bigger `top_k`, better chunking, query rewriting / multi-query.

Variants: `LLMContextRecall` (judge), `NonLLMContextRecall` (string similarity vs `reference_contexts`), `IDBasedContextRecall` (compare chunk IDs — fully deterministic if you have labelled chunk IDs).

### 5.6 Context Entity Recall

Fraction of entities (names, dates, places, products) in the `reference` that also appear in `retrieved_contexts`. Useful for fact-heavy domains (legal, finance, support with product names).

\[
\text{ContextEntityRecall} = \frac{|E_{\text{context}} \cap E_{\text{reference}}|}{|E_{\text{reference}}|}
\]

### 5.7 Noise Sensitivity

**Question:** How often does the system make **incorrect claims** because of relevant or irrelevant noise in the context?

1. Decompose `response` into claims.
2. Check each claim against the `reference` (is it correct?) and against contexts (which chunk did it come from?).
3. Score = proportion of incorrect claims (**lower is better**).

`NoiseSensitivity(mode="relevant")` (default) or `mode="irrelevant"` — measures errors caused by relevant vs irrelevant retrieved chunks.

### 5.8 Diagnosis table

| Low score | Component | Typical fix |
|---|---|---|
| Context Recall | Retriever coverage | Embeddings, hybrid search, `top_k`↑, chunking, query expansion |
| Context Precision | Retriever ranking | Reranker (cross-encoder / Cohere), metadata filters |
| Faithfulness | Generator grounding | Grounding prompt, "say I don't know", lower temperature, citations |
| Response Relevancy | Generator focus | Answer-first prompt, conciseness, avoid hedging |
| Noise Sensitivity high | Generator robustness | Fewer/cleaner chunks, contextual compression, stronger model |

---

## 6. General-Purpose & Non-LLM Metrics

### 6.1 Factual Correctness

Decomposes both `response` and `reference` into claims and uses NLI-style checks to compute precision, recall or F1:

```python
from ragas.metrics import FactualCorrectness

fc = FactualCorrectness(llm=evaluator_llm, mode="f1")   # "precision" | "recall" | "f1"
sample = SingleTurnSample(
    response="The Eiffel Tower is in Paris and was built in 1901.",
    reference="The Eiffel Tower is in Paris and was completed in 1889.",
)
await fc.single_turn_ascore(sample)   # ≈ 0.5
```

- **precision** = how many response claims are in the reference (penalises hallucination).
- **recall** = how many reference claims are in the response (penalises omission).
- Tune granularity with `atomicity="low"|"high"` and `coverage="low"|"high"`.

### 6.2 Semantic Similarity

Cosine similarity between `response` and `reference` embeddings. Cheap, but only measures topical similarity, not correctness.

```python
from ragas.metrics import SemanticSimilarity
SemanticSimilarity(embeddings=evaluator_embeddings)
```

### 6.3 Non-LLM (deterministic) metrics

```python
from ragas.metrics import BleuScore, RougeScore, ExactMatch, StringPresence, NonLLMStringSimilarity

BleuScore()                       # n-gram overlap (translation-style)
RougeScore(rouge_type="rougeL")   # summarisation overlap
ExactMatch()                      # response == reference
StringPresence()                  # reference string appears in response
NonLLMStringSimilarity()          # Levenshtein / Jaro etc.
```

Use these for strict formats (IDs, codes, short factual answers) and as cheap guards alongside LLM metrics.

---

## 7. Custom Metrics: AspectCritic, Rubrics, and Your Own

### 7.1 `AspectCritic` — binary yes/no criterion

The Ragas equivalent of a simple binary G-Eval. Define the criterion in plain English; output is 0 or 1.

```python
from ragas.metrics import AspectCritic

harmfulness = AspectCritic(
    name="harmfulness",
    definition="Does the response contain content that could harm the user or others?",
    llm=evaluator_llm,
)

politeness = AspectCritic(
    name="politeness",
    definition="Is the response polite and professional, suitable for a customer-support context?",
    llm=evaluator_llm,
    strictness=3,   # judge votes 3 times, majority wins → more stable
)

await politeness.single_turn_ascore(SingleTurnSample(
    user_input="Where is my order?",
    response="Check the tracking link yourself.",
))   # → 0
```

### 7.2 `SimpleCriteriaScore` — numeric score from a definition

```python
from ragas.metrics import SimpleCriteriaScore

clarity = SimpleCriteriaScore(
    name="clarity",
    definition="Score 0 to 5 for how clear and easy to follow the response is.",
    llm=evaluator_llm,
)
```

### 7.3 `RubricsScore` — anchored rubric

```python
from ragas.metrics import RubricsScore

rubrics = {
    "score1_description": "The response is incorrect or irrelevant.",
    "score2_description": "Partially correct with major errors or omissions.",
    "score3_description": "Mostly correct, minor errors or missing details.",
    "score4_description": "Correct and complete, slightly verbose or unclear.",
    "score5_description": "Correct, complete, concise and clear.",
}
quality = RubricsScore(name="answer_quality", rubrics=rubrics, llm=evaluator_llm)
```

`InstanceRubrics` lets each sample carry its own rubric (via the sample's `rubrics` field) — useful when every test question has different "what good looks like" criteria.

### 7.4 Writing a fully custom metric

Subclass `SingleTurnMetric` (+ `MetricWithLLM` if it uses the judge). Example: a deterministic **citation check** — every answer must cite a source like `[1]`.

```python
import re
from dataclasses import dataclass, field
from ragas.metrics.base import MetricType, SingleTurnMetric
from ragas import SingleTurnSample

@dataclass
class CitationPresence(SingleTurnMetric):
    name: str = "citation_presence"
    _required_columns: dict = field(
        default_factory=lambda: {MetricType.SINGLE_TURN: {"response", "retrieved_contexts"}}
    )

    def init(self, run_config):
        pass

    async def _single_turn_ascore(self, sample: SingleTurnSample, callbacks) -> float:
        cites = {int(n) for n in re.findall(r"\[(\d+)\]", sample.response or "")}
        if not cites:
            return 0.0
        valid = {c for c in cites if 1 <= c <= len(sample.retrieved_contexts or [])}
        return len(valid) / len(cites)

    async def _ascore(self, row, callbacks) -> float:
        return await self._single_turn_ascore(SingleTurnSample(**row), callbacks)
```

Use it like any other metric: `evaluate(dataset, metrics=[CitationPresence(), Faithfulness()], llm=evaluator_llm)`.

### 7.5 Aligning metrics with human judgement

Ragas supports **metric alignment**: annotate some judge verdicts as correct/incorrect (e.g., on the Ragas app), then call `metric.train(...)` to optimise the metric's prompt / few-shot examples so it agrees better with your reviewers. Even without that feature, always sanity-check a metric on ~30 hand-labelled samples before trusting it.

---

## 8. Synthetic Test-Set Generation

The hardest part of evaluation is usually **getting a test set**. Ragas generates one from your documents.

### 8.1 How it works

```
documents ──► chunk + extract (headlines, summaries, entities, themes, embeddings)
          ──► KNOWLEDGE GRAPH (nodes = docs/chunks, edges = similarity / shared entities)
          ──► query synthesizers pick nodes/paths and generate:
                 • single-hop specific  ("What is the refund window?")
                 • multi-hop specific   (needs facts from 2+ chunks)
                 • multi-hop abstract   (comparison / reasoning across chunks)
          ──► user_input + reference + reference_contexts
```

It can also simulate **personas** (e.g., "new customer", "support agent") so questions resemble real users.

### 8.2 Code

```python
from langchain_community.document_loaders import DirectoryLoader
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper
from ragas.testset import TestsetGenerator

docs = DirectoryLoader("policies/", glob="**/*.md").load()

generator = TestsetGenerator(
    llm=LangchainLLMWrapper(ChatOpenAI(model="gpt-4o")),
    embedding_model=LangchainEmbeddingsWrapper(OpenAIEmbeddings()),
)
testset = generator.generate_with_langchain_docs(docs, testset_size=30)

df = testset.to_pandas()     # user_input, reference_contexts, reference, synthesizer_name
df.to_csv("testset.csv", index=False)
```

Control the question mix:

```python
from ragas.testset.synthesizers import default_query_distribution
query_distribution = default_query_distribution(LangchainLLMWrapper(ChatOpenAI(model="gpt-4o")))
testset = generator.generate_with_langchain_docs(docs, testset_size=30,
                                                 query_distribution=query_distribution)
```

LlamaIndex users: `generator.generate_with_llamaindex_docs(...)`.

### 8.3 Tips

- **Review** generated samples — drop ambiguous or wrong ones. Synthetic ≠ ground truth until a human has skimmed it.
- Mix synthetic data with **real production questions** as soon as you have them.
- Save the test set (CSV/JSONL) and **version** it; regenerate rarely so scores stay comparable.

---

## 9. End-to-End: Evaluating a RAG App

### 9.1 A small LangChain RAG app

```python
# rag_app.py
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_core.documents import Document

DOCS = [
    "Refund policy: customers may request a full refund within 30 days of purchase. Items must be unused.",
    "Shipping: we ship to 40 countries. Standard shipping takes 5-7 business days.",
    "Express shipping costs $15 and takes 1-2 business days within the US.",
    "Warranty: electronics carry a 1-year limited warranty covering manufacturing defects.",
    "Support hours: Monday to Friday, 9am to 6pm EST. Email support@acme.com.",
]

store = InMemoryVectorStore.from_documents([Document(page_content=d) for d in DOCS], OpenAIEmbeddings())
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

def rag(question: str, k: int = 3) -> dict:
    ctx = [d.page_content for d in store.similarity_search(question, k=k)]
    prompt = ("Answer ONLY from the context. If the answer isn't there, say you don't know.\n\n"
              "Context:\n" + "\n".join(f"- {c}" for c in ctx) + f"\n\nQuestion: {question}")
    return {"response": llm.invoke(prompt).content, "retrieved_contexts": ctx}
```

### 9.2 Test set

```python
# testset.py
TESTSET = [
    {"user_input": "How long do I have to return an item?",
     "reference": "You can get a full refund within 30 days of purchase if the item is unused."},
    {"user_input": "How much is express shipping and how fast is it?",
     "reference": "Express shipping costs $15 and takes 1-2 business days within the US."},
    {"user_input": "Does my laptop have a warranty?",
     "reference": "Yes, electronics have a 1-year limited warranty covering manufacturing defects."},
    {"user_input": "When can I contact support?",
     "reference": "Monday to Friday, 9am-6pm EST, via support@acme.com."},
    {"user_input": "Do you sell gift cards?",
     "reference": "The information is not available, so the assistant should say it doesn't know."},
]
```

### 9.3 Run + evaluate

```python
# eval_rag.py
from ragas import EvaluationDataset, evaluate
from ragas.metrics import (
    Faithfulness, ResponseRelevancy, LLMContextPrecisionWithReference,
    LLMContextRecall, FactualCorrectness, AspectCritic,
)
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from rag_app import rag
from testset import TESTSET

evaluator_llm = LangchainLLMWrapper(ChatOpenAI(model="gpt-4o", temperature=0))
evaluator_embeddings = LangchainEmbeddingsWrapper(OpenAIEmbeddings())

rows = []
for t in TESTSET:
    out = rag(t["user_input"])
    rows.append({**t, **out})

dataset = EvaluationDataset.from_list(rows)

refuses_when_unknown = AspectCritic(
    name="refuses_when_unknown",
    definition=("If the reference says the information is unavailable, does the response "
                "decline to answer instead of inventing one? If the reference has an answer, return 1."),
    llm=evaluator_llm,
)

result = evaluate(
    dataset=dataset,
    metrics=[
        Faithfulness(),
        ResponseRelevancy(),
        LLMContextPrecisionWithReference(),
        LLMContextRecall(),
        FactualCorrectness(mode="f1"),
        refuses_when_unknown,
    ],
    llm=evaluator_llm,
    embeddings=evaluator_embeddings,
)

print(result)
df = result.to_pandas()
df.to_csv("results_k3.csv", index=False)
```

### 9.4 Experiment loop

Wrap the above in a function and compare configurations:

```python
for k in [1, 2, 3, 5]:
    rows = [{**t, **rag(t["user_input"], k=k)} for t in TESTSET]
    res = evaluate(EvaluationDataset.from_list(rows),
                   metrics=[Faithfulness(), LLMContextPrecisionWithReference(), LLMContextRecall()],
                   llm=evaluator_llm)
    print(k, res)
```

Expect the classic trade-off: larger `k` → higher **recall**, lower **precision**, and sometimes lower **faithfulness** (more noise).

---

## 10. Evaluating Agents and Multi-Turn Conversations

### 10.1 `MultiTurnSample` and messages

```python
from ragas import MultiTurnSample
from ragas.messages import HumanMessage, AIMessage, ToolMessage, ToolCall

sample = MultiTurnSample(
    user_input=[
        HumanMessage(content="What's the weather in Paris?"),
        AIMessage(content="Let me check.",
                  tool_calls=[ToolCall(name="get_weather", args={"city": "Paris"})]),
        ToolMessage(content='{"temp_c": 18, "condition": "cloudy"}'),
        AIMessage(content="It's 18°C and cloudy in Paris."),
    ],
    reference_tool_calls=[ToolCall(name="get_weather", args={"city": "Paris"})],
    reference="The agent reports the current weather in Paris.",
)
```

Ragas also ships converters for LangGraph, LlamaIndex, Swarm, Bedrock agents etc. — e.g. `from ragas.integrations.langgraph import convert_to_ragas_messages`.

### 10.2 Agent metrics

| Metric | What it checks | Needs |
|---|---|---|
| **ToolCallAccuracy** | Did the agent call the expected tools with the expected arguments (in order)? | `user_input` messages, `reference_tool_calls` |
| **ToolCallF1** | Precision/recall over tool calls (order-insensitive) | same |
| **AgentGoalAccuracyWithReference** | Did the agent achieve the goal described in `reference`? (binary) | messages + `reference` |
| **AgentGoalAccuracyWithoutReference** | Judge infers the goal from the conversation and checks if achieved | messages |
| **TopicAdherenceScore** | Did the agent stay within allowed topics (e.g., refuse off-topic)? | messages + `reference_topics` |

```python
from ragas.metrics import ToolCallAccuracy, AgentGoalAccuracyWithReference, TopicAdherenceScore

await ToolCallAccuracy().multi_turn_ascore(sample)                               # 1.0
await AgentGoalAccuracyWithReference(llm=evaluator_llm).multi_turn_ascore(sample) # 1.0

topic = TopicAdherenceScore(llm=evaluator_llm, mode="precision")
sample.reference_topics = ["weather", "travel"]
await topic.multi_turn_ascore(sample)
```

You can also apply `AspectCritic` to multi-turn samples ("Did the agent ask for confirmation before booking?").

### 10.3 Evaluating a LangGraph agent

```python
from ragas.integrations.langgraph import convert_to_ragas_messages
from ragas import MultiTurnSample
from ragas.messages import ToolCall
from ragas.metrics import ToolCallAccuracy

result = graph.invoke({"messages": [("user", "What's the weather in Paris?")]})
ragas_messages = convert_to_ragas_messages(result["messages"])

sample = MultiTurnSample(
    user_input=ragas_messages,
    reference_tool_calls=[ToolCall(name="get_weather", args={"city": "Paris"})],
)
await ToolCallAccuracy().multi_turn_ascore(sample)
```

---

## 11. Ragas in CI and with LangSmith / Langfuse

### 11.1 Pytest gate

Ragas has no built-in test runner (unlike DeepEval), so assert on aggregate scores:

```python
# tests/test_rag_quality.py
from ragas import EvaluationDataset, evaluate
from ragas.metrics import Faithfulness, LLMContextRecall
from rag_app import rag
from testset import TESTSET

THRESHOLDS = {"faithfulness": 0.85, "context_recall": 0.75}

def test_rag_quality(evaluator_llm):     # provide evaluator_llm via a conftest fixture
    rows = [{**t, **rag(t["user_input"])} for t in TESTSET]
    res = evaluate(EvaluationDataset.from_list(rows),
                   metrics=[Faithfulness(), LLMContextRecall()], llm=evaluator_llm)
    df = res.to_pandas()
    for metric, threshold in THRESHOLDS.items():
        mean = df[metric].mean()
        assert mean >= threshold, f"{metric} {mean:.2f} < {threshold}"
```

Column names come from each metric's `name` attribute (e.g., `faithfulness`, `context_recall`, `answer_relevancy`) — print `df.columns` once to confirm.

### 11.2 Tracing judge calls in LangSmith

```bash
export LANGSMITH_TRACING=true
export LANGSMITH_API_KEY=...
export LANGSMITH_PROJECT=ragas-evals
```

Because the judge runs through LangChain, every metric's LLM calls show up as traces — great for seeing *why* a metric gave a score.

### 11.3 Using Ragas metrics as evaluators elsewhere

- **LangSmith:** wrap a Ragas metric inside a LangSmith evaluator function (see the LangSmith tutorial) and run it with `client.evaluate(...)`.
- **Langfuse:** score production traces with Ragas and push results back as Langfuse scores (`langfuse.score(trace_id=..., name="faithfulness", value=...)`) — a common open-source monitoring setup.

### 11.4 Cost control

- Each sample × metric = several judge calls (claim extraction + verification). 100 samples × 4 metrics ≈ 1,000+ LLM calls.
- Use a cheaper judge for iteration (`gpt-4o-mini`) and a strong judge for release gates.
- Use non-LLM metrics (`NonLLMContextRecall`, `IDBasedContextRecall`, `ExactMatch`) where possible.
- Tune `RunConfig(max_workers=...)` to stay under rate limits.

---

## 12. Ragas vs DeepEval

| Aspect | Ragas | DeepEval |
|---|---|---|
| Focus | RAG metrics (origin), now also agents | General LLM unit testing, RAG, agents, safety |
| Data model | `SingleTurnSample`, `MultiTurnSample`, `EvaluationDataset` | `LLMTestCase`, `Golden`, `EvaluationDataset` |
| Field names | `user_input`, `response`, `retrieved_contexts`, `reference` | `input`, `actual_output`, `retrieval_context`, `expected_output` |
| Custom metrics | `AspectCritic`, `RubricsScore`, subclass `SingleTurnMetric` | `GEval`, `DAGMetric`, subclass `BaseMetric` |
| Test runner | None (use pytest manually) | Built in: `deepeval test run`, `assert_test` |
| Test-set generation | Knowledge-graph based, personas, multi-hop — very strong | `Synthesizer` with evolutions |
| Judge models | Any LangChain / LlamaIndex model | OpenAI default, many providers, custom `DeepEvalBaseLLM` |
| Hosted platform | Ragas app (lighter) | Confident AI |
| Best for | RAG research, retrieval tuning, synthetic test sets | CI regression gates, custom business rules, agent testing |

Many teams use **both**: Ragas for test-set generation and retrieval tuning, DeepEval (or LangSmith) for CI gates.

---

## 13. Cheat Sheet & Interview Questions

### 13.1 Imports

```python
from ragas import evaluate, EvaluationDataset, SingleTurnSample, MultiTurnSample
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper
from ragas.run_config import RunConfig
from ragas.messages import HumanMessage, AIMessage, ToolMessage, ToolCall
from ragas.metrics import (
    Faithfulness, ResponseRelevancy,
    LLMContextPrecisionWithReference, LLMContextPrecisionWithoutReference,
    LLMContextRecall, NonLLMContextRecall, ContextEntityRecall, NoiseSensitivity,
    FactualCorrectness, SemanticSimilarity,
    AspectCritic, SimpleCriteriaScore, RubricsScore,
    BleuScore, RougeScore, ExactMatch, StringPresence,
    ToolCallAccuracy, AgentGoalAccuracyWithReference, TopicAdherenceScore,
)
from ragas.testset import TestsetGenerator
```

### 13.2 Which metric?

| I want to know… | Ragas metric |
|---|---|
| Is the answer grounded in retrieved docs? | Faithfulness |
| Does the answer address the question? | ResponseRelevancy |
| Is the answer correct vs reference? | FactualCorrectness |
| Are relevant chunks ranked first? | LLMContextPrecisionWithReference |
| Did we retrieve all needed info? | LLMContextRecall |
| Does noise cause wrong claims? | NoiseSensitivity |
| Custom yes/no rule (tone, safety, policy)? | AspectCritic |
| Graded quality with rubric? | RubricsScore |
| Did the agent call the right tools? | ToolCallAccuracy |
| Did the agent achieve the goal? | AgentGoalAccuracy |

### 13.3 Interview questions

1. **What are the four core Ragas RAG metrics?** Faithfulness and Response Relevancy (generator); Context Precision and Context Recall (retriever).
2. **How is Faithfulness computed?** Decompose the response into claims, verify each against retrieved contexts, score = supported / total.
3. **How is Response Relevancy computed and what's its weakness?** Generate questions from the response, mean cosine similarity with the real question. It measures relevance, not correctness.
4. **Context Precision vs Context Recall?** Precision = ranking quality (are relevant chunks at the top); recall = coverage (is every claim of the reference supported by retrieved chunks).
5. **Which metrics need ground truth?** Context Recall, Context Precision (with-reference variant), Factual Correctness, Noise Sensitivity. Faithfulness and Response Relevancy are reference-free.
6. **High recall, low faithfulness — what's broken?** Retrieval is fine; the generator ignores or goes beyond context.
7. **How does Ragas generate test sets?** Builds a knowledge graph from documents (entities, summaries, embeddings), then synthesises single-hop and multi-hop queries with personas, producing questions, references and reference contexts.
8. **How do you evaluate an agent with Ragas?** `MultiTurnSample` of messages with tool calls; ToolCallAccuracy vs `reference_tool_calls`, AgentGoalAccuracy, TopicAdherence.
9. **How do you keep Ragas evals stable and affordable?** Pin judge model and Ragas version, temperature 0, `strictness` for AspectCritic, cheap judge for iteration, non-LLM metrics where possible, versioned test sets, human calibration.
