# Mem0 — Memory Layer for AI Agents (Deep Dive + Production System Design)

> Mem0 ("mem-zero") is the most popular open-source memory layer for LLM apps. It extracts facts from conversations, stores them in a vector DB (and optionally a graph DB), deduplicates/updates them with an LLM, and retrieves relevant memories for each new request. Works with any framework (LangGraph, CrewAI, OpenAI Agents SDK, plain OpenAI calls) and has a managed platform.

> **Version note:** Mem0 evolves quickly (OSS `mem0ai` package, `Memory` class; platform `MemoryClient`). Return formats and default models change between versions — pin your version and check the docs if something differs.

---

## Table of Contents

1. [What Mem0 Is](#1-what-mem0-is)
2. [Core Concepts](#2-core-concepts)
3. [Architecture](#3-architecture)
4. [How `add()` Works: Extraction + Update Algorithm](#4-how-add-works-extraction--update-algorithm)
5. [How `search()` Works](#5-how-search-works)
6. [Quickstart](#6-quickstart)
7. [Full API Reference with Examples](#7-full-api-reference-with-examples)
8. [Configuration: LLMs, Embedders, Vector Stores](#8-configuration-llms-embedders-vector-stores)
9. [Graph Memory](#9-graph-memory)
10. [Building a Chatbot with Memory](#10-building-a-chatbot-with-memory)
11. [Coding Agent Example](#11-coding-agent-example)
12. [Mem0 with LangGraph](#12-mem0-with-langgraph)
13. [Customizing What Gets Stored](#13-customizing-what-gets-stored)
14. [Mem0 Platform (Managed)](#14-mem0-platform-managed)
15. [Mem0 vs LangMem vs Zep vs Letta](#15-mem0-vs-langmem-vs-zep-vs-letta)
16. [FAANG-Scale Memory System with Mem0](#16-faang-scale-memory-system-with-mem0)
17. [Pitfalls, Cheat Sheet & Interview Questions](#17-pitfalls-cheat-sheet--interview-questions)

---

## 1. What Mem0 Is

```mermaid
flowchart LR
    U["User message"] --> APP["Your app / agent"]
    APP -->|"1. search(query, user_id)"| M0["Mem0"]
    M0 -->|"relevant memories"| APP
    APP -->|"2. prompt = memories + message"| LLM["LLM"]
    LLM --> APP
    APP -->|"3. add(conversation, user_id)"| M0
    M0 --> VS[("Vector DB")]
    M0 --> GS[("Graph DB (optional)")]
    M0 --> H[("History DB")]
```

Mem0 does three things for you:

| Job | You call | Mem0 does |
|---|---|---|
| **Remember** | `m.add(messages, user_id=...)` | LLM extracts facts → compares with existing memories → ADD / UPDATE / DELETE |
| **Recall** | `m.search(query, user_id=...)` | Embeds query → vector (and graph) search → ranked memories |
| **Manage** | `get_all`, `update`, `delete`, `history` | CRUD + audit trail of every change |

Why not just store chat history? Full history grows without limit, costs tokens, and buries facts in noise. Mem0 keeps **compact facts** ("Prefers pytest") instead of raw transcripts.

### 1.1 Benchmark results (Mem0 paper, LOCOMO, Table 2)

Source: [Mem0: Building Production-Ready AI Agents with Scalable Long-Term Memory](https://arxiv.org/abs/2504.19413) (2025). These are the vendor's own benchmarks.

| Method | Tokens per query | Total latency p50 | Total latency p95 | Accuracy (LLM-as-judge) |
|---|---|---|---|---|
| Full context | 26,031 | 9.87 s | 17.12 s | **72.90%** (highest) |
| Mem0 + graph | 3,616 | 1.09 s | 2.59 s | 68.44% |
| **Mem0** | **1,764** | **0.71 s** | **1.44 s** | 66.88% |
| Zep | 3,911 | 1.29 s | 2.93 s | 65.99% |
| Best RAG setup (8192-token chunks) | — | 2.31 s | 9.94 s | 60.53% |
| LangMem | 127 | 18.53 s | 60.40 s | 58.10% |
| OpenAI memory | 4,437 | 0.47 s | 0.89 s | 52.90% |
| A-Mem | 2,520 | 1.41 s | 4.37 s | 48.38% |

- Compared with **full context**: ~93% fewer tokens and ~92% lower p95 latency, but ~6 points **lower** accuracy.
- Compared with **other memory systems**: Mem0 has higher accuracy than all of them; Mem0 + graph is the highest of any memory system.

---

## 2. Core Concepts

### 2.1 Memory = a fact

```json
{
  "id": "a1b2c3",
  "memory": "Prefers pytest over unittest",
  "user_id": "kjana",
  "metadata": {"category": "coding"},
  "hash": "…",
  "created_at": "2026-11-10T10:00:00Z",
  "updated_at": "2026-11-10T10:00:00Z"
}
```

### 2.2 Scoping identifiers

Every memory is scoped by one or more IDs. These play the role of LangMem's **namespace**.

```mermaid
flowchart TD
    M["Memories"] --> U["user_id<br/>who the memory is about"]
    M --> A["agent_id<br/>which agent/bot learned it"]
    M --> R["run_id<br/>one session / conversation"]
    U --> U1["kjana: Prefers pytest"]
    A --> A1["support-bot: Refund policy is 30 days"]
    R --> R1["session-123: Currently debugging refund()"]
```

| ID | Scope | Lifetime | Example |
|---|---|---|---|
| `user_id` | One user, across all sessions | Long-term | "Allergic to peanuts" |
| `agent_id` | One agent's own knowledge | Long-term | "I should always cite sources" |
| `run_id` | One session/conversation | Short-term | "User is currently booking a Paris trip" |

Combine them: `m.add(msgs, user_id="kjana", agent_id="coding-bot", run_id="s-42")`.

### 2.3 Memory types in Mem0 terms

| Type | Meaning | How in Mem0 |
|---|---|---|
| Working / session | Current conversation context | `run_id`-scoped memories |
| Semantic / factual | Facts and preferences | Default `add()` behaviour |
| Episodic | Past events / interactions | Facts with timestamps, `run_id`, metadata |
| Procedural | How the agent performed a task | `add(..., agent_id=..., memory_type="procedural_memory")` summarizes agent execution history |

---

## 3. Architecture

```mermaid
flowchart TB
    subgraph API["Mem0 Memory API"]
        ADD["add()"]
        SEARCH["search()"]
        CRUD["get / get_all / update / delete / history"]
    end

    ADD --> EXT["Extraction LLM<br/>facts from messages"]
    EXT --> UPD["Update LLM<br/>ADD / UPDATE / DELETE / NONE"]
    UPD --> EMB["Embedder"]
    EMB --> VS[("Vector store<br/>Qdrant, pgvector, Pinecone, Chroma, ...")]
    UPD --> HIST[("History DB<br/>SQLite by default")]

    ADD -.optional.-> GEXT["Entity + relation extraction LLM"]
    GEXT --> GS[("Graph store<br/>Neo4j, Memgraph, Neptune")]

    SEARCH --> EMB2["Embed query"]
    EMB2 --> VS
    SEARCH -.optional.-> GS
    SEARCH -.optional.-> RR["Reranker"]
```

| Component | Default (OSS) | Replaceable with |
|---|---|---|
| LLM (extraction + update) | OpenAI small model | Anthropic, Groq, Gemini, Ollama, Azure, Bedrock, LiteLLM, … |
| Embedder | OpenAI `text-embedding-3-small` | Gemini, HuggingFace, Ollama, Azure, Bedrock, … |
| Vector store | Local Qdrant (on disk under `/tmp/qdrant`) | pgvector, Pinecone, Chroma, Milvus, Redis, Elasticsearch, OpenSearch, Weaviate, FAISS, MongoDB, … |
| History store | SQLite (`~/.mem0/history.db`) | Configurable path |
| Graph store | Off | Neo4j, Memgraph, Neptune, Kuzu |

---

## 4. How `add()` Works: Extraction + Update Algorithm

This is the heart of Mem0. Two LLM phases:

```mermaid
flowchart TD
    IN["New messages + user_id"] --> P1

    subgraph P1["Phase 1: EXTRACTION"]
        E1["LLM reads messages<br/>(+ recent context)"] --> E2["Candidate facts<br/>['Prefers pytest', 'Moved to Berlin']"]
    end

    E2 --> P2

    subgraph P2["Phase 2: UPDATE (per fact)"]
        U1["Embed fact"] --> U2["Search top-k similar<br/>existing memories for this user"]
        U2 --> U3["LLM compares fact vs existing"]
        U3 --> D{"Decision"}
        D -->|"new info"| ADD["ADD"]
        D -->|"refines existing"| UPD["UPDATE (same id)"]
        D -->|"contradicts existing"| DEL["DELETE old"]
        D -->|"already known"| NOOP["NONE"]
    end

    ADD --> VS[("Vector store")]
    UPD --> VS
    DEL --> VS
    ADD --> H[("History log")]
    UPD --> H
    DEL --> H
```

### 4.1 Worked example

Existing memories for `kjana`:

```
id=1  "Lives in Pune"
id=2  "Prefers pytest"
```

New message: *"I just moved to Berlin, and I still love pytest. Also I'm vegetarian."*

| Step | Result |
|---|---|
| Extraction | `["Lives in Berlin", "Loves pytest", "Is vegetarian"]` |
| "Lives in Berlin" vs similar `id=1 Lives in Pune` | **UPDATE** id=1 → "Lives in Berlin (moved from Pune)" |
| "Loves pytest" vs similar `id=2 Prefers pytest` | **NONE** (already known) |
| "Is vegetarian" vs no similar memory | **ADD** id=3 "Is vegetarian" |

Return value:

```python
{"results": [
    {"id": "1", "memory": "Lives in Berlin", "event": "UPDATE", "previous_memory": "Lives in Pune"},
    {"id": "3", "memory": "Is vegetarian", "event": "ADD"},
]}
```

### 4.2 Why two phases?

| Single "just store everything" | Mem0's extract + update |
|---|---|
| Duplicates pile up ("prefers pytest" ×10) | Dedupe: NONE if already known |
| Contradictions coexist (Pune and Berlin) | UPDATE/DELETE resolves conflicts |
| Memory grows linearly with chat volume | Grows with **distinct facts**, not messages |

### 4.3 Cost of `add()`

Each `add()` = 1 extraction LLM call + embedding calls + 1 update LLM call (+ graph LLM calls if enabled). That's **seconds**, not milliseconds, so in production call it **in the background**, not before replying (section 16).

`infer=False` skips both LLM phases and stores the message text as-is (cheap, but no dedupe):

```python
m.add("User clicked dark mode in settings", user_id="kjana", infer=False)
```

---

## 5. How `search()` Works

```mermaid
sequenceDiagram
    participant App
    participant M as Mem0
    participant E as Embedder
    participant V as Vector store
    participant G as Graph store (optional)
    participant R as Reranker (optional)

    App->>M: search("write a test", user_id="kjana", limit=5)
    M->>E: embed query
    E-->>M: vector
    M->>V: ANN search WHERE user_id = kjana
    V-->>M: top-k memories + scores
    opt graph enabled
        M->>G: find related entities/relations
        G-->>M: relations
    end
    opt reranker configured
        M->>R: rerank results
    end
    M-->>App: {"results": [...], "relations": [...]}
```

```python
results = m.search("write a test", user_id="kjana", limit=5)
for r in results["results"]:
    print(r["memory"], r["score"])
# Prefers pytest            0.82
# Runs tests with make test 0.77
```

No LLM call by default, so search is fast (embedding + vector lookup, typically tens of ms).

---

## 6. Quickstart

```bash
pip install mem0ai
export OPENAI_API_KEY="sk-..."
```

```python
from mem0 import Memory

m = Memory()   # defaults: OpenAI LLM + embedder, local Qdrant, SQLite history

# Remember
m.add([
    {"role": "user", "content": "Hi, I'm Kjana. I love Python and prefer dark mode."},
    {"role": "assistant", "content": "Nice to meet you, Kjana!"},
], user_id="kjana")

# Recall
print(m.search("What theme does the user like?", user_id="kjana"))
# {'results': [{'memory': 'Prefers dark mode', 'score': 0.8, ...}, ...]}

# Inspect everything
print(m.get_all(user_id="kjana"))
```

Same flow as the LangMem notebook (dark mode), with no agent or tool needed: you call `add` and `search` directly.

---

## 7. Full API Reference with Examples

| Method | Purpose | Example |
|---|---|---|
| `add(messages, user_id=, agent_id=, run_id=, metadata=, infer=True)` | Extract + store memories | `m.add(msgs, user_id="kjana", metadata={"topic": "coding"})` |
| `search(query, user_id=, limit=, filters=)` | Semantic recall | `m.search("test framework", user_id="kjana", limit=3)` |
| `get_all(user_id=, agent_id=, run_id=)` | List all memories in scope | `m.get_all(user_id="kjana")` |
| `get(memory_id)` | One memory | `m.get("a1b2c3")` |
| `update(memory_id, data)` | Manually edit | `m.update(memory_id="a1b2c3", data="Prefers unittest")` |
| `delete(memory_id)` | Delete one | `m.delete(memory_id="a1b2c3")` |
| `delete_all(user_id=)` | Delete all for a user (GDPR) | `m.delete_all(user_id="kjana")` |
| `history(memory_id)` | Audit trail of changes | `m.history(memory_id="a1b2c3")` |
| `reset()` | Wipe everything (dev only) | `m.reset()` |

### 7.1 Messages can be a string or a chat list

```python
m.add("I prefer pytest", user_id="kjana")
m.add([{"role": "user", "content": "I prefer pytest"}], user_id="kjana")
```

### 7.2 Metadata + filters

```python
m.add("Run tests with make test", user_id="kjana", metadata={"repo": "payments-api"})
m.search("how to run tests", user_id="kjana", filters={"repo": "payments-api"})
```

### 7.3 History (audit)

```python
m.history(memory_id="1")
# [{'event': 'ADD',    'old_memory': None,          'new_memory': 'Lives in Pune',   ...},
#  {'event': 'UPDATE', 'old_memory': 'Lives in Pune', 'new_memory': 'Lives in Berlin', ...}]
```

### 7.4 Async

```python
from mem0 import AsyncMemory

m = AsyncMemory()
await m.add(msgs, user_id="kjana")
await m.search("theme", user_id="kjana")
```

---

## 8. Configuration: LLMs, Embedders, Vector Stores

### 8.1 Config structure

```mermaid
flowchart LR
    CFG["config dict"] --> L["llm<br/>provider + model"]
    CFG --> E["embedder<br/>provider + model"]
    CFG --> V["vector_store<br/>provider + connection"]
    CFG --> G["graph_store (optional)"]
    CFG --> P["custom prompts (optional)"]
    CFG --> H["history_db_path"]
```

### 8.2 Groq + Gemini (same stack as the LangMem notebook)

```python
import os
from mem0 import Memory

config = {
    "llm": {
        "provider": "groq",
        "config": {"model": "qwen/qwen3-32b", "temperature": 0, "api_key": os.environ["GROQ_API_KEY"]},
    },
    "embedder": {
        "provider": "gemini",
        "config": {"model": "models/gemini-embedding-001", "api_key": os.environ["GOOGLE_API_KEY"],
                   "embedding_dims": 3072},
    },
    "vector_store": {
        "provider": "qdrant",
        "config": {"collection_name": "mem0", "path": "./qdrant_data", "embedding_model_dims": 3072},
    },
}
m = Memory.from_config(config)
```

> `embedding_model_dims` in the vector store **must equal** the embedder's output size, or inserts fail.

### 8.3 Production: Postgres + pgvector

```python
config = {
    "llm": {"provider": "openai", "config": {"model": "gpt-4o-mini", "temperature": 0}},
    "embedder": {"provider": "openai", "config": {"model": "text-embedding-3-small"}},
    "vector_store": {
        "provider": "pgvector",
        "config": {
            "host": "db", "port": 5432, "dbname": "memory",
            "user": "mem0", "password": os.environ["PG_PASSWORD"],
            "collection_name": "memories", "embedding_model_dims": 1536,
        },
    },
    "history_db_path": "/data/mem0_history.db",
}
m = Memory.from_config(config)
```

### 8.4 Fully local (no API keys): Ollama

```python
config = {
    "llm": {"provider": "ollama", "config": {"model": "llama3.1:8b"}},
    "embedder": {"provider": "ollama", "config": {"model": "nomic-embed-text"}},
    "vector_store": {"provider": "qdrant", "config": {"path": "./qdrant_data", "embedding_model_dims": 768}},
}
```

### 8.5 Where data is saved

| Store | Default location | Survives restart? |
|---|---|---|
| Vector memories | Local Qdrant files (`/tmp/qdrant` by default; set `path`) | Yes, unless in `/tmp` and the OS clears it |
| History | `~/.mem0/history.db` (SQLite) | Yes |
| Graph | Your Neo4j/Memgraph server | Yes |
| Platform | Mem0's cloud | Yes |

---

## 9. Graph Memory

Vector memory stores **isolated facts**. Graph memory also stores **relationships between entities**, which helps multi-hop questions.

```mermaid
flowchart LR
    K(("Kjana")) -- works_on --> P(("payments-api"))
    P -- uses --> F(("FastAPI"))
    P -- tests_with --> T(("pytest"))
    K -- lives_in --> B(("Berlin"))
    K -- manager --> A(("Alice"))
    A -- owns --> P
```

Question: *"Who owns the repo Kjana works on?"* Vector search may miss it; graph traversal finds Kjana → payments-api → owned by Alice.

```python
config = {
    "graph_store": {
        "provider": "neo4j",
        "config": {"url": "neo4j://localhost:7687", "username": "neo4j", "password": os.environ["NEO4J_PW"]},
    },
    # plus llm / embedder / vector_store as above
}
m = Memory.from_config(config)

m.add("Alice owns payments-api. I work on payments-api.", user_id="kjana")
res = m.search("who owns my repo?", user_id="kjana")
print(res["relations"])
# [{'source': 'alice', 'relationship': 'owns', 'target': 'payments-api'}, ...]
```

### 9.1 How Mem0 + graph writes (`add`)

From the Mem0 paper (section on Mem0ᵍ, Figure 3). Runs **in addition to** the normal vector pipeline (section 4).

```mermaid
flowchart TD
    MSG["Messages"] --> ENT["1. Entity extractor (LLM)<br/>Kjana:person, payments-api:repo, Alice:person"]
    ENT --> REL["2. Relationship generator (LLM)<br/>(Alice, owns, payments-api)<br/>(Kjana, works_on, payments-api)"]
    REL --> EMB["3. Embed source + target entity"]
    EMB --> MATCH{"Similar node already exists?<br/>(similarity > threshold t)"}
    MATCH -- "yes" --> REUSE["Reuse existing node"]
    MATCH -- "no" --> CREATE["Create new node"]
    REUSE --> EDGE["Create edge with metadata"]
    CREATE --> EDGE
    EDGE --> CONF["4. Conflict detection<br/>find existing edges that clash"]
    CONF --> RES["5. Update resolver (LLM)<br/>mark old edge INVALID (kept, not deleted)"]
    RES --> NEO[("Graph DB")]
```

| Step | What happens | Example |
|---|---|---|
| 1. Entity extraction | LLM finds entities + types | `Kjana` (person), `Berlin` (city) |
| 2. Relationship generation | LLM creates triplets (source, relation, target) | `(Kjana, lives_in, Berlin)` |
| 3. Node matching | Embed each entity; reuse a node if a similar one exists, so "payments api" and "payments-api" become one node | Avoids duplicate nodes |
| 4. Conflict detection | Find existing edges that contradict the new one | Old edge `(Kjana, lives_in, Pune)` |
| 5. Update resolution | LLM marks the old edge **invalid** instead of deleting it | Graph remembers she lived in Pune *before* Berlin, enabling time-based questions |

> The paper describes marking edges invalid; the open-source implementation may delete conflicting edges depending on version. Check `m.search(...)["relations"]` behaviour in your version.

### 9.2 How Mem0 + graph reads (`search`)

Two retrieval methods run together:

```mermaid
flowchart TD
    Q["Query: 'Who owns the repo I work on?'"] --> A["A. Entity-centric"]
    Q --> B["B. Semantic triplet"]

    A --> A1["Find entities in query: 'I' → Kjana, 'repo'"]
    A1 --> A2["Match graph nodes by embedding similarity"]
    A2 --> A3["Expand incoming + outgoing edges<br/>→ subgraph"]

    B --> B1["Embed whole query"]
    B1 --> B2["Compare with embeddings of every triplet text<br/>e.g. 'Alice owns payments-api'"]
    B2 --> B3["Keep triplets above threshold, ranked"]

    A3 --> OUT["relations returned with vector memories"]
    B3 --> OUT
```

| Method | How | Good at |
|---|---|---|
| Entity-centric | Find query entities → matching nodes → walk neighbouring edges | Multi-hop: Kjana → works_on → payments-api ← owns ← Alice |
| Semantic triplet | Embed query, match against triplet texts | Queries phrased differently from stored entity names |

### 9.3 Worked example

```
Conversation 1: "I work on payments-api."          → (Kjana, works_on, payments-api)
Conversation 2: "Alice owns payments-api."         → (Alice, owns, payments-api)
Conversation 3: "I moved from Pune to Berlin."     → (Kjana, lives_in, Berlin)
                                                     (Kjana, lives_in, Pune) marked INVALID

Query: "Who owns the repo I work on?"
  Entity-centric: Kjana → works_on → payments-api → owned by Alice
  Answer context: "Alice owns payments-api"
```

Plain vector memory has two separate facts ("Works on payments-api", "Alice owns payments-api") and may retrieve only one. The graph connects them.

### 9.4 Results from the paper

| | Mem0 (vector) | Mem0 + graph |
|---|---|---|
| Overall accuracy (J) | 66.88% | **68.44%** |
| Total p95 latency | **1.44 s** | 2.59 s |
| Memory footprint per conversation | **~7k tokens** | ~14k tokens |
| Strongest on | Single-hop and multi-hop facts | **Temporal** and open-domain questions |

### 9.5 Implementation A: graph memory from scratch (to understand it)

A minimal in-memory version of the Mem0ᵍ pipeline: same steps as the paper, about 150 lines, no graph DB. Use it to learn; use the Mem0 library (9.6) in real apps.

```mermaid
flowchart TB
    subgraph ADD["add(text, user)"]
        A1["extract_entities (LLM)"] --> A2["extract_triplets (LLM)"]
        A2 --> A3["_resolve_node: embed + match<br/>existing node ≥ threshold"]
        A3 --> A4["_find_candidates: valid edges<br/>touching same nodes"]
        A4 --> A5["detect_conflicts (LLM)<br/>→ ids to invalidate"]
        A5 --> A6["mark old edges valid=False<br/>append new edge"]
    end

    subgraph SEARCH["search(query, user)"]
        S1["extract_entities(query) (LLM)"] --> S2["match anchor nodes"]
        S2 --> S3["entity-centric: edges touching anchors<br/>+ 1-hop expansion"]
        S4["embed query"] --> S5["semantic triplet: cosine vs<br/>every valid edge text"]
        S3 --> S6["merge, dedupe, rank"]
        S5 --> S6
    end

    A6 --> G[("nodes: name → embedding<br/>edges: source, relation, target, valid, timestamps")]
    G --> S2
    G --> S5
```

```python
# graph_memory.py
import json
from datetime import datetime, timezone
import numpy as np
from openai import OpenAI
from pydantic import BaseModel

client = OpenAI()
LLM = "gpt-4o-mini"
EMBED = "text-embedding-3-small"


class Entity(BaseModel):
    name: str
    type: str

class Entities(BaseModel):
    entities: list[Entity]

class Triplet(BaseModel):
    source: str
    relation: str
    target: str

class Triplets(BaseModel):
    triplets: list[Triplet]

class Conflicts(BaseModel):
    invalid_edge_ids: list[int]


def parse(system: str, user: str, schema):
    resp = client.beta.chat.completions.parse(
        model=LLM, temperature=0, response_format=schema,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
    )
    return resp.choices[0].message.parsed

def embed(texts: list[str]) -> np.ndarray:
    data = client.embeddings.create(model=EMBED, input=texts).data
    return np.array([d.embedding for d in data])

def cosine(a: np.ndarray, b: np.ndarray) -> float:
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b)))

def now() -> str:
    return datetime.now(timezone.utc).isoformat()


class GraphMemory:
    def __init__(self, node_threshold: float = 0.85, triplet_threshold: float = 0.35):
        self.nodes: dict[str, np.ndarray] = {}
        self.edges: list[dict] = []
        self.node_threshold = node_threshold
        self.triplet_threshold = triplet_threshold

    # ---------- WRITE ----------
    def add(self, text: str, user: str) -> list[dict]:
        entities = parse(
            f"Extract people, places, objects, concepts and events worth remembering. "
            f"Refer to the speaker ('I', 'me', 'my') as '{user}'.",
            text, Entities,
        ).entities
        if not entities:
            return []

        triplets = parse(
            "Given the text and entity list, output relationship triplets (source, relation, target). "
            "Use short snake_case relations like lives_in, works_on, owns, prefers.",
            f"Text: {text}\nEntities: {[e.name for e in entities]}", Triplets,
        ).triplets

        added = []
        for t in triplets:
            source, target = self._resolve_node(t.source), self._resolve_node(t.target)
            new_edge = {
                "id": len(self.edges), "source": source, "relation": t.relation, "target": target,
                "valid": True, "created_at": now(), "invalidated_at": None,
            }
            candidates = self._find_candidates(source, target)
            if candidates:
                self._invalidate_conflicts(new_edge, candidates)
            self.edges.append(new_edge)
            added.append(new_edge)
        return added

    def _resolve_node(self, name: str) -> str:
        name = name.strip().lower()
        vec = embed([name])[0]
        for existing, existing_vec in self.nodes.items():
            if cosine(vec, existing_vec) >= self.node_threshold:
                return existing
        self.nodes[name] = vec
        return name

    def _find_candidates(self, source: str, target: str) -> list[dict]:
        return [e for e in self.edges if e["valid"] and (e["source"] == source or e["target"] == target)]

    def _invalidate_conflicts(self, new_edge: dict, candidates: list[dict]) -> None:
        payload = {
            "new": f"{new_edge['source']} {new_edge['relation']} {new_edge['target']}",
            "existing": [{"id": e["id"], "fact": f"{e['source']} {e['relation']} {e['target']}"} for e in candidates],
        }
        result = parse(
            "Return ids of existing facts that are contradicted or made outdated by the new fact. "
            "Facts that can both be true at once are NOT conflicts.",
            json.dumps(payload), Conflicts,
        )
        for e in self.edges:
            if e["id"] in result.invalid_edge_ids:
                e["valid"] = False
                e["invalidated_at"] = now()

    # ---------- READ ----------
    def search(self, query: str, user: str, limit: int = 10) -> list[str]:
        valid = [e for e in self.edges if e["valid"]]
        if not valid:
            return []

        # A. Entity-centric
        query_entities = parse(
            f"Extract entities from the query. Refer to the speaker as '{user}'.", query, Entities,
        ).entities
        anchors = {m for m in (self._match_node(e.name) for e in query_entities) if m}
        hits = {e["id"] for e in valid if e["source"] in anchors or e["target"] in anchors}
        neighbours = {n for e in valid if e["id"] in hits for n in (e["source"], e["target"])}
        hits |= {e["id"] for e in valid if e["source"] in neighbours or e["target"] in neighbours}

        # B. Semantic triplet
        texts = [f"{e['source']} {e['relation']} {e['target']}" for e in valid]
        q_vec, t_vecs = embed([query])[0], embed(texts)
        scored = sorted(((cosine(q_vec, v), e) for v, e in zip(t_vecs, valid)), key=lambda x: -x[0])
        hits |= {e["id"] for score, e in scored if score >= self.triplet_threshold}

        ranked = [e for _, e in scored if e["id"] in hits][:limit]
        return [f"{e['source']} {e['relation']} {e['target']}" for e in ranked]

    def _match_node(self, name: str) -> str | None:
        vec = embed([name.strip().lower()])[0]
        best = max(self.nodes.items(), key=lambda kv: cosine(vec, kv[1]), default=None)
        if best and cosine(vec, best[1]) >= self.node_threshold:
            return best[0]
        return None

    def history(self) -> list[str]:
        return [f"{'✓' if e['valid'] else '✗'} {e['source']} {e['relation']} {e['target']}" for e in self.edges]
```

Run it:

```python
from graph_memory import GraphMemory

gm = GraphMemory()
gm.add("I work on payments-api.", user="kjana")
gm.add("Alice owns payments-api.", user="kjana")
gm.add("I live in Pune.", user="kjana")
gm.add("I just moved to Berlin.", user="kjana")

print(gm.search("Who owns the repo I work on?", user="kjana"))
# ['alice owns payments-api', 'kjana works_on payments-api', ...]

print("\n".join(gm.history()))
# ✓ kjana works_on payments-api
# ✓ alice owns payments-api
# ✗ kjana lives_in pune        ← invalidated, kept for history
# ✓ kjana lives_in berlin
```

What each method maps to in the paper:

| Method | Paper step |
|---|---|
| `add` → entity `parse` | Entity extractor |
| `add` → triplet `parse` | Relationship generator |
| `_resolve_node` | Node matching by embedding similarity (threshold `t`) |
| `_find_candidates` + `_invalidate_conflicts` | Conflict detection + LLM update resolver (mark invalid) |
| `search` part A | Entity-centric retrieval with subgraph expansion |
| `search` part B | Semantic triplet retrieval with relevance threshold |

Simplifications vs production: everything in RAM, node matching is O(n) (a real system uses a vector index), one embedding call per entity (batch these), and no per-user isolation (store `user_id` on nodes/edges).

### 9.6 Implementation B: Mem0 library + Neo4j (real setup)

```mermaid
flowchart LR
    APP["Your app"] -->|"add / search"| M0["Mem0 Memory"]
    M0 --> VS[("Qdrant / pgvector<br/>vector facts")]
    M0 --> NEO[("Neo4j<br/>entities + relations")]
    M0 --> H[("SQLite / Postgres<br/>history")]
    M0 --> LLM["LLM<br/>(extraction, triplets, conflicts)"]
    M0 --> EMB["Embedder"]
```

**1. Start Neo4j**

```bash
docker run -d --name neo4j -p 7474:7474 -p 7687:7687 \
  -e NEO4J_AUTH=neo4j/password123 \
  -e NEO4J_PLUGINS='["apoc"]' \
  neo4j:5
pip install "mem0ai[graph]"
```

**2. Configure Mem0 with vector + graph**

```python
import os
from mem0 import Memory

config = {
    "llm": {"provider": "openai", "config": {"model": "gpt-4o-mini", "temperature": 0}},
    "embedder": {"provider": "openai", "config": {"model": "text-embedding-3-small"}},
    "vector_store": {
        "provider": "qdrant",
        "config": {"collection_name": "mem0", "path": "./qdrant_data", "embedding_model_dims": 1536},
    },
    "graph_store": {
        "provider": "neo4j",
        "config": {"url": "bolt://localhost:7687", "username": "neo4j", "password": "password123"},
    },
}
m = Memory.from_config(config)
```

**3. Add and search**

```python
m.add("I work on payments-api. Alice owns payments-api.", user_id="kjana")
m.add("I moved from Pune to Berlin.", user_id="kjana")

res = m.search("Who owns the repo I work on?", user_id="kjana")

print(res["results"])     # vector facts
# [{'memory': 'Works on payments-api', 'score': 0.71, ...}, ...]

print(res["relations"])   # graph triplets
# [{'source': 'alice', 'relationship': 'owns', 'destination': 'payments-api'},
#  {'source': 'kjana', 'relationship': 'works_on', 'destination': 'payments-api'}]
```

The exact keys in `relations` (`destination` vs `target`) differ between Mem0 versions; print one result first.

**4. Feed both into the prompt**

```python
def build_context(res: dict) -> str:
    facts = [f"- {r['memory']}" for r in res.get("results", [])]
    rels = [
        f"- {r['source']} {r['relationship']} {r.get('destination') or r.get('target')}"
        for r in res.get("relations", [])
    ]
    return "Facts:\n" + "\n".join(facts) + "\n\nRelationships:\n" + "\n".join(rels)

context = build_context(res)
reply = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {"role": "system", "content": f"Answer using this memory about the user:\n{context}"},
        {"role": "user", "content": "Who owns the repo I work on?"},
    ],
).choices[0].message.content
# "Alice owns payments-api, the repo you work on."
```

```mermaid
sequenceDiagram
    participant App
    participant M as Mem0
    participant V as Vector store
    participant N as Neo4j
    participant L as LLM

    App->>M: search("Who owns the repo I work on?", user_id)
    par
        M->>V: vector search
        V-->>M: facts
    and
        M->>N: entity + triplet search
        N-->>M: relations
    end
    M-->>App: {results, relations}
    App->>L: system(facts + relations) + question
    L-->>App: "Alice owns payments-api"
```

**5. Inspect the graph in Neo4j Browser** (`http://localhost:7474`)

```cypher
MATCH (a)-[r]->(b)
RETURN a.name AS source, type(r) AS relation, b.name AS target
LIMIT 50;
```

**6. Graph for selected calls only** (save cost)

Graph extraction adds several LLM calls per `add`. A common pattern is two `Memory` instances: a vector-only one for routine chat, and a graph-enabled one only for messages about people, organizations, or projects (decided by a cheap classifier).

| | Vector only | Vector + graph |
|---|---|---|
| Good at | "What does the user like?" | "How are these people/things connected?" |
| Cost per `add` | ~2 LLM calls | ~4+ LLM calls |
| Infra | Vector DB | Vector DB + graph DB |
| Use when | Preferences, facts | Org charts, CRM, multi-entity domains |

---

## 10. Building a Chatbot with Memory

```python
from openai import OpenAI
from mem0 import Memory

client = OpenAI()
memory = Memory()

def chat(message: str, user_id: str) -> str:
    # 1. Recall
    relevant = memory.search(query=message, user_id=user_id, limit=5)
    facts = "\n".join(f"- {r['memory']}" for r in relevant["results"]) or "None yet"

    # 2. Generate
    messages = [
        {"role": "system", "content": f"You are a helpful assistant.\nKnown about the user:\n{facts}"},
        {"role": "user", "content": message},
    ]
    reply = client.chat.completions.create(model="gpt-4o-mini", messages=messages).choices[0].message.content

    # 3. Remember (synchronous here; move to background in production)
    memory.add(messages[1:] + [{"role": "assistant", "content": reply}], user_id=user_id)
    return reply

chat("I'm vegetarian and I live in Berlin", "kjana")
chat("Suggest a dinner place for tonight", "kjana")   # uses: vegetarian + Berlin
```

```mermaid
sequenceDiagram
    actor U as User
    participant App
    participant M as Mem0
    participant L as LLM

    U->>App: "Suggest a dinner place"
    App->>M: search(query, user_id)
    M-->>App: ["Is vegetarian", "Lives in Berlin"]
    App->>L: system + memories + message
    L-->>App: "Try a vegetarian place in Kreuzberg…"
    App-->>U: reply
    App--)M: add(conversation) (background)
```

### 10.1 Making `add()` non-blocking

```python
from concurrent.futures import ThreadPoolExecutor
pool = ThreadPoolExecutor(max_workers=4)

def chat(message, user_id):
    ...
    pool.submit(memory.add, messages[1:] + [{"role": "assistant", "content": reply}], user_id=user_id)
    return reply   # user doesn't wait for extraction
```

At scale, replace the thread pool with a queue (section 16).

---

## 11. Coding Agent Example

```python
memory = Memory.from_config(config)

# Session 1
memory.add([
    {"role": "user", "content": "In payments-api we use FastAPI and Postgres. Run tests with make test. I prefer pytest."},
], user_id="kjana", agent_id="coding-bot", metadata={"repo": "payments-api"})

memory.add(
    "Flaky test in test_refund.py was a timezone bug; fixed with freezegun",
    user_id="kjana", agent_id="coding-bot", metadata={"repo": "payments-api", "type": "episode"},
)

# Session 2 (a week later)
hits = memory.search("write a test for partial refunds", user_id="kjana",
                     filters={"repo": "payments-api"}, limit=5)
for h in hits["results"]:
    print("-", h["memory"])
# - Prefers pytest
# - Runs tests with make test
# - Uses FastAPI and Postgres
# - Timezone bug in test_refund.py fixed with freezegun
```

What gets stored:

| Memory | Scope | Metadata |
|---|---|---|
| "Prefers pytest" | `user_id=kjana` | `repo=payments-api` |
| "Runs tests with make test" | `user_id=kjana` | `repo=payments-api` |
| "Uses FastAPI and Postgres" | `user_id=kjana` | `repo=payments-api` |
| "Timezone bug … freezegun" | `user_id=kjana` | `type=episode` |

---

## 12. Mem0 with LangGraph

Mem0 replaces LangGraph's Store + LangMem: one node recalls, the same node (or a background job) remembers.

```python
from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_openai import ChatOpenAI
from mem0 import Memory

llm = ChatOpenAI(model="gpt-4o-mini")
mem0 = Memory()

class State(TypedDict):
    messages: Annotated[list, add_messages]
    user_id: str

def chatbot(state: State):
    user_id = state["user_id"]
    last = state["messages"][-1].content

    hits = mem0.search(last, user_id=user_id, limit=5)
    facts = "\n".join(f"- {h['memory']}" for h in hits["results"])

    reply = llm.invoke([
        {"role": "system", "content": f"You are helpful. Known about the user:\n{facts}"},
        *state["messages"],
    ])

    mem0.add([{"role": "user", "content": last},
              {"role": "assistant", "content": reply.content}], user_id=user_id)
    return {"messages": [reply]}

graph = StateGraph(State)
graph.add_node("chatbot", chatbot)
graph.add_edge(START, "chatbot")
graph.add_edge("chatbot", END)
app = graph.compile()

app.invoke({"messages": [("user", "I prefer dark mode")], "user_id": "kjana"})
```

Here LangGraph's **checkpointer** still handles short-term thread history; **Mem0** handles long-term memory.

---

## 13. Customizing What Gets Stored

### 13.1 Custom extraction prompt

By default Mem0 extracts personal preferences, details, plans, etc. Restrict it to your domain:

```python
config["custom_fact_extraction_prompt"] = """
Extract only coding-related facts: languages, frameworks, tools, test commands,
code style preferences, and project conventions.
Never extract secrets, API keys, passwords, or personal data.
Return JSON: {"facts": ["...", "..."]}

Input: Hi, how are you?
Output: {"facts": []}

Input: We use FastAPI and run tests with make test.
Output: {"facts": ["Uses FastAPI", "Runs tests with make test"]}
"""
m = Memory.from_config(config)
```

### 13.2 Custom update prompt

`custom_update_memory_prompt` controls how the update LLM chooses ADD / UPDATE / DELETE / NONE (e.g., "never delete, only update with history").

### 13.3 Steering summary

| Lever | Controls |
|---|---|
| `custom_fact_extraction_prompt` | **What** facts are extracted |
| `custom_update_memory_prompt` | **How** conflicts/duplicates are resolved |
| `metadata` + `filters` | Organizing and narrowing retrieval |
| `infer=False` | Store exact text, no LLM |
| `user_id` / `agent_id` / `run_id` | **Whose** memory it is |

---

## 14. Mem0 Platform (Managed)

```python
from mem0 import MemoryClient

client = MemoryClient(api_key=os.environ["MEM0_API_KEY"])

client.add([{"role": "user", "content": "I prefer dark mode"}], user_id="kjana")
client.search("theme preference", user_id="kjana")
client.get_all(user_id="kjana")
```

| | OSS (`Memory`) | Platform (`MemoryClient`) |
|---|---|---|
| Hosting | You run vector DB, graph DB, LLM keys | Mem0 runs everything |
| Cost | Your infra + LLM calls | Subscription / usage pricing |
| Extras | Full control, any provider, self-hosted data | Dashboard, analytics, advanced filters, webhooks, async add, enterprise compliance |
| Use when | Data must stay in-house; custom stack | Fastest path to production |

**OpenMemory MCP** (from Mem0) exposes memory over the Model Context Protocol, so tools like Cursor and Claude Desktop can share one local memory store.

---

## 15. Mem0 vs LangMem vs Zep vs Letta

| | Mem0 | LangMem | Zep | Letta (MemGPT) |
|---|---|---|---|---|
| Model | Memory layer (`add` / `search`) | Memory toolkit for LangGraph | Temporal knowledge-graph memory | Full agent framework with self-editing memory |
| Framework lock-in | None | LangGraph Store | None | Letta runtime |
| Extraction | Built-in 2-phase LLM pipeline | Memory manager / tools | Automatic, temporal graph | Agent edits its own memory blocks |
| Graph memory | Optional (Neo4j etc.) | No | Core feature (Graphiti) | No (blocks + archival) |
| Procedural memory | Basic | **Prompt optimizer** | No | Core memory blocks |
| Managed option | Mem0 Platform | LangGraph Platform | Zep Cloud | Letta Cloud |
| Popularity | **Highest** | Lower | Medium | Medium–high |

```mermaid
flowchart TD
    Q{"Your stack?"} -->|"LangGraph already"| LM["LangMem<br/>(or Mem0 if you want simplicity)"]
    Q -->|"Any framework, want simple add/search"| M0["Mem0"]
    Q -->|"Need time-aware facts + relationships"| Z["Zep"]
    Q -->|"Want agent to manage its own memory"| L["Letta"]
```

---

## 16. FAANG-Scale Memory System with Mem0

**Problem:** personal memory for an assistant with **100M users, 1B messages/day**, memory recall p99 < 100 ms, GDPR compliance.

### 16.1 Architecture

```mermaid
flowchart TB
    C["Clients"] --> GW["API Gateway<br/>auth → user_id"]
    GW --> AG["Agent Service (stateless)"]

    AG -->|"recall: search()"| MS["Memory Service<br/>(wraps Mem0 search)"]
    MS --> CACHE[("Redis<br/>hot memories per user")]
    MS --> VDB[("Vector DB cluster<br/>sharded by user_id")]
    MS -.-> GDB[("Graph DB<br/>(optional, high-value domains)")]

    AG --> LLMGW["LLM Gateway"]
    AG -->|"turn event"| K[["Kafka: conversation-events<br/>key = user_id"]]

    K --> W["Mem0 Extraction Workers<br/>batch per user, call Mem0 add()"]
    W --> LLMGW
    W --> VDB
    W --> GDB
    W --> HIST[("History / audit DB<br/>Postgres")]
    W --> INV["Invalidate Redis for user"]

    PRIV["Privacy Service"] -->|"delete_all(user_id)"| MS
```

### 16.2 Write path vs read path

```mermaid
flowchart LR
    subgraph Write["WRITE (background)"]
        T["Chat turn"] --> K[["Kafka (key=user_id)"]]
        K --> B["Batch per user<br/>(e.g., 60s quiet window)"]
        B --> G{"Memorable?<br/>cheap classifier"}
        G -- No --> X["drop"]
        G -- Yes --> ADD["Mem0 add()<br/>extract → update"]
        ADD --> V[("Vector DB")]
    end
    subgraph Read["READ (in request)"]
        U["New message"] --> S["Mem0 search(user_id)"]
        V --> S
        S --> P["Prompt = system + memories + message"]
        P --> L["LLM"]
    end
```

- **Read path** = `search()` only: embedding + ANN lookup + cache, no LLM, fits a < 100 ms budget.
- **Write path** = `add()` (2+ LLM calls): **never** in the request path. Kafka keyed by `user_id` keeps each user's updates **ordered** (avoids two workers racing on the same memory).
- **Batching per user**: concatenate a user's recent turns and call `add()` once, cutting LLM calls 5–10×.
- **Gating**: skip turns like "thanks!" with a cheap classifier before paying for extraction.

### 16.3 Mapping Mem0 to scalable infra

| Mem0 component | Dev default | At scale |
|---|---|---|
| Vector store | Local Qdrant | Qdrant/Milvus cluster, pgvector with partitioning, or Pinecone; shard/partition by `user_id`; quantized vectors |
| History DB | SQLite | Postgres (shared, replicated) |
| LLM | OpenAI | LLM gateway; small/cheap model for extraction; fine-tuned extractor at very large scale |
| Embedder | OpenAI API | Self-hosted embedding service (GPU) for cost and latency |
| Graph | Off | Only for domains that need relations (CRM, org data); Neo4j cluster / Neptune |
| `add()` calls | In request | Async workers consuming Kafka |

### 16.4 Back-of-envelope

| Quantity | Estimate |
|---|---|
| Turns/day | 1B → ~35k/s peak |
| `search()` QPS | ~35k/s peak (vector DB + cache) |
| `add()` calls/day | 1B × 30% gated × ÷5 batching ≈ **60M/day** (~700/s) |
| LLM calls for memory | ~2 per `add()` → ~120M/day → **must** use a cheap model |
| Memories | cap ~500/user × 100M ≈ up to 50B; with dedupe realistically 5–10B |
| Vector storage | 10B × ~1.5 KB (quantized) ≈ 15 TB, sharded |

### 16.5 Reliability, privacy, quality

| Concern | Approach |
|---|---|
| Vector DB slow | Timeout (~80 ms) → answer without memory |
| Worker lag | Kafka buffers; memory freshness drops, chat unaffected |
| Bad extractor release | Store `model_version` in metadata; replay Kafka to reprocess |
| Tenant isolation | `user_id` from auth token only; vector DB filter/partition per user |
| Sensitive data | Custom extraction prompt excludes PII categories + PII filter before `add()` |
| GDPR delete | `delete_all(user_id)` across vector, graph, history, cache, backups |
| Prompt injection via memories | Treat memories as data (`<memories>` block), never instructions |
| Quality | Multi-session recall evals, extraction precision sampling, A/B personalization lift |

---

## 17. Pitfalls, Cheat Sheet & Interview Questions

### 17.1 Pitfalls

| Pitfall | Fix |
|---|---|
| Calling `add()` before replying | Background thread / queue |
| Default local Qdrant under `/tmp` in prod | Configure a real vector DB |
| `embedding_model_dims` mismatch | Match embedder output (1536 OpenAI small, 3072 Gemini, 768 nomic) |
| Missing `user_id` | Every memory call must be scoped, or users share memories |
| Extracting secrets / PII | `custom_fact_extraction_prompt` + PII filter |
| Graph memory everywhere | Enable only where relations matter; it doubles LLM cost |
| Too many memories in prompt | `limit=3–8` + score threshold |

### 17.2 Cheat sheet

```python
from mem0 import Memory, AsyncMemory, MemoryClient

m = Memory()                                   # or Memory.from_config(config)
m.add(messages, user_id="u1", agent_id="bot", run_id="s1", metadata={...}, infer=True)
m.search("query", user_id="u1", limit=5, filters={...})   # → {"results": [...], "relations": [...]}
m.get_all(user_id="u1"); m.get(mid); m.update(memory_id=mid, data="...")
m.delete(memory_id=mid); m.delete_all(user_id="u1"); m.history(memory_id=mid)

config = {
    "llm":          {"provider": "openai", "config": {"model": "gpt-4o-mini"}},
    "embedder":     {"provider": "openai", "config": {"model": "text-embedding-3-small"}},
    "vector_store": {"provider": "pgvector", "config": {..., "embedding_model_dims": 1536}},
    "graph_store":  {"provider": "neo4j", "config": {...}},          # optional
    "custom_fact_extraction_prompt": "...",                          # optional
}
```

### 17.3 Interview questions

1. **What happens inside `mem0.add()`?** Extraction LLM pulls candidate facts; for each fact, similar existing memories are retrieved and an update LLM decides ADD / UPDATE / DELETE / NONE; changes go to the vector store and history log.
2. **Why is `search()` fast but `add()` slow?** Search is embedding + vector lookup (no LLM). Add needs 2+ LLM calls.
3. **How does Mem0 avoid duplicates and contradictions?** The update phase compares each new fact with similar existing memories and updates/deletes instead of inserting.
4. **`user_id` vs `agent_id` vs `run_id`?** Whose memory (user), which agent's own knowledge, which session.
5. **When do you enable graph memory?** When questions depend on relationships between entities (multi-hop); not for simple preferences.
6. **Mem0 vs LangMem?** Mem0: framework-agnostic `add`/`search` layer with built-in extraction, vector + graph, managed platform. LangMem: LangGraph-native toolkit with memory tools, background managers, and prompt optimization.
7. **How do you scale Mem0 to 100M users?** Search in the request path with caching and a sharded vector DB; `add()` in Kafka-driven workers partitioned by user, batched and gated, with a cheap extraction model; Postgres for history; GDPR via `delete_all`.
8. **How do you stop Mem0 from storing sensitive data?** Custom extraction prompt that excludes it, PII detection before `add()`, metadata tagging, audits via `history()`.
