# Amazon VPC: From Basics to Production Design

This guide covers what a VPC is and every building block inside one:

- CIDR address ranges
- subnets and Availability Zones
- internet gateways
- route tables
- public and private subnets
- NAT gateways
- security groups and network ACLs

It then covers how real teams design, secure, connect, pay for, and debug VPCs.

The running example is a **web shop** with three layers: a load balancer that faces the internet, application servers, and a database.

---

## 1. The problem a VPC solves

When you launch an EC2 instance, it gets a private IP address such as `172.31.5.20`. Someone must decide:

- where that address comes from;
- which machines can reach the instance;
- whether it can reach the internet, and whether the internet can reach it.

In an office, those decisions live in physical cables, switches, routers, and firewalls. In AWS there are no cables you can touch. AWS gives every account a **software-defined network** instead, called a **Virtual Private Cloud (VPC)**.

**Definition:** A VPC is an isolated, private network inside one AWS Region. You choose its address range, divide it into subnets, and decide what can reach what, using API calls instead of cables.

- **Private:** resources in your VPC are isolated from every other AWS customer by default, even when they run in the same data center.
- **Virtual:** it behaves like a real network, with IP addresses, routers, and firewalls, but all of it is defined in software.

### Where everything lives

```mermaid
flowchart TB
    subgraph Region["AWS Region: us-east-1"]
        subgraph VPC["Your VPC: 10.0.0.0/16"]
            subgraph AZa["Availability Zone us-east-1a"]
                S1["Subnet 10.0.1.0/24"]
                S1 --> I1["EC2 instance<br/>10.0.1.15"]
            end
            subgraph AZb["Availability Zone us-east-1b"]
                S2["Subnet 10.0.2.0/24"]
                S2 --> I2["EC2 instance<br/>10.0.2.40"]
            end
        end
    end
```

| Term | Definition |
|---|---|
| **Region** | A geographic location with several data centers, for example `us-east-1` (N. Virginia). A VPC lives in exactly one Region. |
| **Availability Zone (AZ)** | One or more separate data centers inside a Region, with independent power and networking: `us-east-1a`, `us-east-1b`, and so on. A fire or power cut in one AZ doesn't affect the others. |
| **VPC** | Your private network spanning the whole Region. |
| **Subnet** | A slice of the VPC's address range that lives in **exactly one AZ**. Instances are launched into subnets, never directly into the VPC. |

**Every EC2 instance must be in a VPC.** The same is true of RDS databases, ECS tasks, Lambda functions attached to a VPC, and load balancers.

---

## 2. The default VPC

You launched an EC2 instance earlier without creating any network. That worked because **AWS creates a default VPC in every Region of every account**. When you don't specify a network, EC2 uses it.

What AWS puts in the default VPC:

| Component | Default value |
|---|---|
| Address range | `172.31.0.0/16` (65,536 addresses) |
| Subnets | One `/20` subnet (4,096 addresses) in **every AZ** of the Region |
| Internet gateway | Already attached |
| Main route table | `local` route plus `0.0.0.0/0 → internet gateway`, so every default subnet is **public** |
| Public IPs | Instances get a public IP automatically |
| Security group | A default group: allows all outbound traffic, and inbound only from members of the same group |
| Network ACL | A default ACL that allows all traffic in and out |

```mermaid
flowchart TB
    Internet((Internet)) <--> IGW["Internet gateway<br/>(already attached)"]
    subgraph DVPC["Default VPC 172.31.0.0/16"]
        RT["Main route table<br/>172.31.0.0/16 → local<br/>0.0.0.0/0 → IGW"]
        A["Default subnet us-east-1a<br/>172.31.0.0/20"]
        B["Default subnet us-east-1b<br/>172.31.16.0/20"]
        C["Default subnet us-east-1c<br/>172.31.32.0/20"]
        RT -.-> A & B & C
    end
    IGW <--> DVPC
```

**Why real teams don't use it for production:**

- **Everything is public by default.** Every subnet routes to the internet, and instances get public IPs automatically.
- **You didn't choose the address range.** `172.31.0.0/16` is the same in every account, so connecting VPCs together, or to an office network, causes address overlaps.
- **There's no separation** between internet-facing and internal resources.

The default VPC is fine for experiments. Production VPCs are built on purpose, which is what the rest of this guide covers.

### Lab task: inspect the default VPC

```bash
aws ec2 describe-vpcs --filters Name=isDefault,Values=true > /root/default-vpc.json

jq -r '.Vpcs[0].VpcId' /root/default-vpc.json > /root/default-vpc-id.txt

aws ec2 describe-subnets \
  --filters Name=vpc-id,Values=$(cat /root/default-vpc-id.txt) \
  > /root/default-subnets.json
```

Check what you got:

```bash
cat /root/default-vpc-id.txt                                           # vpc-...
jq -r '.Vpcs[0].CidrBlock' /root/default-vpc.json                      # 172.31.0.0/16
jq -r '.Subnets[] | "\(.AvailabilityZone)  \(.CidrBlock)"' /root/default-subnets.json
```

The last command prints one `/20` subnet per AZ.

---

## 3. CIDR: reading address ranges

### The problem

A network needs a short way to say "these addresses belong to me" without listing all 65,536 of them. **CIDR notation** describes a whole range in one string, such as `10.0.0.0/16`.

### How to read it

An IPv4 address is 4 numbers from 0 to 255. Each number is 8 bits, so the address is 32 bits. **The number after the slash says how many bits at the start are fixed.** The rest can vary.

```mermaid
flowchart LR
    subgraph S16["10.0.0.0/16: first 16 bits fixed"]
        direction LR
        a1["10"]:::fixed --- a2["0"]:::fixed --- a3["0–255"]:::free --- a4["0–255"]:::free
    end
    subgraph S24["10.0.1.0/24: first 24 bits fixed"]
        direction LR
        b1["10"]:::fixed --- b2["0"]:::fixed --- b3["1"]:::fixed --- b4["0–255"]:::free
    end
    classDef fixed fill:#bbdefb,stroke:#0d47a1
    classDef free fill:#c8e6c9,stroke:#1b5e20
```

Blue numbers are fixed, and green numbers vary.

- `10.0.0.0/16`: the first two numbers are fixed, so the range is `10.0.0.0` to `10.0.255.255`, which is **65,536 addresses**.
- `10.0.1.0/24`: the first three numbers are fixed, so the range is `10.0.1.0` to `10.0.1.255`, which is **256 addresses**.

**Rule: a bigger number after the slash means a smaller range.** Each step of 1 halves the size.

**Formula:** number of addresses = 2^(32 − prefix).

| CIDR | Addresses | Usable in an AWS subnet | Typical use |
|---|---|---|---|
| `/16` | 65,536 | — | A whole VPC (the largest AWS allows) |
| `/19` | 8,192 | 8,187 | Large private subnets for containers |
| `/20` | 4,096 | 4,091 | Default VPC subnets |
| `/22` | 1,024 | 1,019 | Medium subnets |
| `/24` | 256 | 251 | Small subnets, common in tutorials |
| `/28` | 16 | 11 | The smallest AWS subnet |
| `/32` | 1 | — | A single address, used in firewall rules |
| `/0` | All addresses | — | `0.0.0.0/0` means "anywhere" |

### AWS reserves 5 addresses in every subnet

In `10.0.1.0/24`, these 5 addresses can't be used by your resources:

| Address | Reserved for |
|---|---|
| `10.0.1.0` | Network address |
| `10.0.1.1` | VPC router |
| `10.0.1.2` | DNS server |
| `10.0.1.3` | Reserved for future use |
| `10.0.1.255` | Broadcast address (not supported, but reserved) |

So a `/24` has **251** usable addresses, not 256.

### Private address ranges

These ranges are reserved worldwide for private networks and never appear on the public internet:

| Range | CIDR | Example use |
|---|---|---|
| `10.0.0.0` – `10.255.255.255` | `10.0.0.0/8` | Most custom VPCs |
| `172.16.0.0` – `172.31.255.255` | `172.16.0.0/12` | The default VPC (`172.31.0.0/16`) |
| `192.168.0.0` – `192.168.255.255` | `192.168.0.0/16` | Home and office networks |

### The VPC owns a big range, and subnets take pieces

```mermaid
flowchart TB
    V["VPC 10.0.0.0/16<br/>65,536 addresses"] --> A["Subnet 10.0.1.0/24<br/>256 addresses"]
    V --> B["Subnet 10.0.2.0/24<br/>256 addresses"]
    V --> F["Rest of the range<br/>free for future subnets"]
```

AWS rejects a subnet whose range overlaps another subnet, or falls outside the VPC's range.

### Planning address ranges like a production team

- **Use a `/16` for each VPC.** Addresses inside a VPC are free, and running out is painful to fix.
- **Never overlap with networks you might connect to:** other VPCs, other accounts, the office network, or a partner. VPC peering and most routing can't work between overlapping ranges. Large companies give each VPC its own range from a central plan, often managed with **Amazon VPC IPAM**:

  | Environment | VPC range |
  |---|---|
  | prod | `10.0.0.0/16` |
  | staging | `10.1.0.0/16` |
  | dev | `10.2.0.0/16` |
  | office network | `192.168.0.0/16` |

- **Give container workloads large subnets.** With ECS on Fargate or EKS, every task or pod uses one IP address. A `/24` holds only 251 tasks, and deployments briefly double the count. Teams use `/20` or `/19` private subnets.
- **If you do run out,** you can add a **secondary CIDR block** to a VPC, but planning ahead is much simpler.

---

## 4. Subnets and Availability Zones

### Why subnets exist

A VPC spans the whole Region, but a machine has to physically run in one AZ. **A subnet pins part of the VPC's address range to one AZ.** Every instance launched into that subnet runs in that AZ.

### Why teams always create several

**Reason 1: surviving an AZ failure.** Run copies of the application in subnets in different AZs. If one AZ fails, the other copies keep serving.

**Reason 2: separating what faces the internet from what doesn't.** Load balancers go in public subnets, and application servers and databases go in private subnets. (Section 7 explains what makes a subnet public.)

### The standard production layout: 3 tiers across 3 AZs

```mermaid
flowchart TB
    subgraph VPC["VPC 10.0.0.0/16"]
        subgraph AZa["us-east-1a"]
            Pa["Public 10.0.0.0/24<br/>load balancer, NAT"]
            Aa["Private app 10.0.32.0/19<br/>app servers, containers"]
            Da["Private data 10.0.128.0/24<br/>database"]
        end
        subgraph AZb["us-east-1b"]
            Pb["Public 10.0.1.0/24"]
            Ab["Private app 10.0.64.0/19"]
            Db["Private data 10.0.129.0/24"]
        end
        subgraph AZc["us-east-1c"]
            Pc["Public 10.0.2.0/24"]
            Ac["Private app 10.0.96.0/19"]
            Dc["Private data 10.0.130.0/24"]
        end
    end
```

| Tier | Contains | Size | Why that size |
|---|---|---|---|
| Public | Load balancers, NAT gateways | Small (`/24`) | Few resources live here |
| Private app | EC2, ECS tasks, EKS pods, Lambda in a VPC | Large (`/19`) | One IP per task or pod; room for scaling and deployments |
| Private data | RDS, ElastiCache | Small (`/24`) | Few database nodes |

### Lab tasks: build a VPC and two subnets

The lessons plan this small network:

- **VPC** `10.0.0.0/16`
- **Subnet A** `10.0.1.0/24` in `us-east-1a`
- **Subnet B** `10.0.2.0/24` in `us-east-1b`

```bash
aws ec2 create-vpc --cidr-block 10.0.0.0/16 \
  --tag-specifications 'ResourceType=vpc,Tags=[{Key=Name,Value=escbash-lab-vpc}]' \
  > /root/vpc.json
VPC_ID=$(jq -r '.Vpc.VpcId' /root/vpc.json)

aws ec2 create-subnet --vpc-id "$VPC_ID" --cidr-block 10.0.1.0/24 --availability-zone us-east-1a \
  --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=escbash-lab-subnet-a}]' \
  > /root/subnet-a.json

aws ec2 create-subnet --vpc-id "$VPC_ID" --cidr-block 10.0.2.0/24 --availability-zone us-east-1b \
  --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=escbash-lab-subnet-b}]' \
  > /root/subnet-b.json

SUBNET_A=$(jq -r '.Subnet.SubnetId' /root/subnet-a.json)
SUBNET_B=$(jq -r '.Subnet.SubnetId' /root/subnet-b.json)
```

Use whatever file names and tags each task asks for. These are examples.

A new VPC is **sealed**. It has no internet gateway and no route out. Instances in it can talk to each other, but not to the internet.

---

## 5. The internet gateway

### The problem

In the default VPC, instances could download packages from the internet. In your new VPC, they can't, and nothing on the internet can reach them. AWS makes you open the VPC on purpose, so nothing is exposed by accident.

**Definition:** An **internet gateway (IGW)** connects one VPC to the internet. It handles traffic in both directions: out to the internet, and in from it.

```mermaid
flowchart LR
    Internet((Internet)) <--> IGW["Internet gateway<br/>igw-..."]
    IGW <--> VPC
    subgraph VPC["Your VPC 10.0.0.0/16"]
        A["Subnet 10.0.1.0/24"]
        B["Subnet 10.0.2.0/24"]
    end
```

Facts to remember:

- **It's created as its own resource, then attached to a VPC.** That's two separate API calls.
- **One VPC can have at most one internet gateway.**
- **It has no bandwidth limit and no hourly price.** AWS scales it automatically. It's not a machine you size.
- **Attaching it changes nothing by itself.** No traffic uses it until a route table points to it (section 6).

### Lab task: create and attach the internet gateway

```bash
aws ec2 create-internet-gateway \
  --tag-specifications 'ResourceType=internet-gateway,Tags=[{Key=Name,Value=escbash-lab-igw}]' \
  > /root/igw.json
IGW_ID=$(jq -r '.InternetGateway.InternetGatewayId' /root/igw.json)

aws ec2 attach-internet-gateway --internet-gateway-id "$IGW_ID" --vpc-id "$VPC_ID"

aws ec2 describe-internet-gateways --internet-gateway-ids "$IGW_ID" \
  --query 'InternetGateways[0].Attachments'
# [{"State": "available", "VpcId": "vpc-..."}]
```

---

## 6. Route tables

### The problem

When an instance sends a packet, the VPC must decide where it goes: to another instance in the VPC, out through the internet gateway, or nowhere. **Route tables** hold those decisions.

**Definition:** A route table is a list of routes. Each **route** says: traffic going to this **destination** range goes to this **target**.

### The local route

Every route table starts with one route that AWS adds and you can't remove:

| Destination | Target | Meaning |
|---|---|---|
| `10.0.0.0/16` | `local` | Traffic to any address inside the VPC stays inside the VPC |

This is why instances in different subnets of the same VPC can already reach each other with no setup.

### Adding a route to the internet

| Destination | Target | Meaning |
|---|---|---|
| `10.0.0.0/16` | `local` | Traffic inside the VPC stays inside |
| `0.0.0.0/0` | `igw-0abc...` | Everything else goes out through the internet gateway |

`0.0.0.0/0` means every IPv4 address.

### Longest prefix match: the most specific route wins

A packet can match several routes. **The route with the biggest prefix number (the narrowest range) wins:**

```mermaid
flowchart TD
    P["Packet to 10.0.2.5"] --> Q{"Which routes match?"}
    Q --> R1["10.0.0.0/16 → local ✔ (/16)"]
    Q --> R2["0.0.0.0/0 → IGW ✔ (/0)"]
    R1 --> W["/16 is more specific → stays inside the VPC"]
    P2["Packet to 142.250.80.46 (google.com)"] --> Q2{"Which routes match?"}
    Q2 --> R3["10.0.0.0/16 ✖"]
    Q2 --> R4["0.0.0.0/0 → IGW ✔"]
    R4 --> W2["Goes out through the internet gateway"]
```

### Subnets are associated with route tables

- **Each subnet follows exactly one route table.**
- **One route table can serve many subnets.**
- Every VPC has a **main route table**. Any subnet you don't explicitly associate with another table uses it. In a new VPC, the main table has only the local route.

```mermaid
flowchart LR
    IGW["Internet gateway"]
    subgraph VPC["Your VPC"]
        A["Subnet A 10.0.1.0/24"] --> RTP["Custom route table<br/>10.0.0.0/16 → local<br/>0.0.0.0/0 → IGW"]
        B["Subnet B 10.0.2.0/24"] --> RTM["Main route table<br/>10.0.0.0/16 → local only"]
    end
    RTP --> IGW
```

**Leave the main route table private** (local route only). That way, a new subnet someone creates and forgets to associate is never public by accident. Make subnets public deliberately, with a custom table.

### Lab task: make subnet A route to the internet

There are three steps: create a route table, add the `0.0.0.0/0` route, and associate subnet A.

```bash
aws ec2 create-route-table --vpc-id "$VPC_ID" \
  --tag-specifications 'ResourceType=route-table,Tags=[{Key=Name,Value=escbash-lab-public-rt}]' \
  > /root/route-table.json
RT_ID=$(jq -r '.RouteTable.RouteTableId' /root/route-table.json)

aws ec2 create-route --route-table-id "$RT_ID" \
  --destination-cidr-block 0.0.0.0/0 --gateway-id "$IGW_ID"

aws ec2 associate-route-table --route-table-id "$RT_ID" --subnet-id "$SUBNET_A" \
  > /root/association.json

aws ec2 describe-route-tables --route-table-ids "$RT_ID" \
  --query 'RouteTables[0].{Routes:Routes[].[DestinationCidrBlock,GatewayId],Subnets:Associations[].SubnetId}'
```

---

## 7. Public and private subnets

### The definition is only about routing

There's no "public" checkbox or `--public` flag. The difference is entirely the route table:

- **Public subnet:** its route table has a route to an **internet gateway**.
- **Private subnet:** its route table has **no** route to an internet gateway.

```mermaid
flowchart LR
    Internet((Internet)) <--> IGW["Internet gateway"]
    subgraph VPC["Your VPC"]
        A["Subnet A<br/>route to IGW<br/>= PUBLIC"]
        B["Subnet B<br/>local route only<br/>= PRIVATE"]
        A <-->|local route| B
    end
    IGW <--> A
```

Subnet A became public the moment you associated it with the route table pointing to the IGW. Subnet B is still private. **Public and private subnets in the same VPC always reach each other** through the local route.

### An instance also needs a public IP

Being in a public subnet isn't enough. The instance's `10.0.1.x` address is private, and the internet can't route to it. The instance also needs a **public IPv4 address**:

- add `--associate-public-ip-address` to `run-instances`; or
- set the subnet to give public IPs automatically: `aws ec2 modify-subnet-attribute --subnet-id ... --map-public-ip-on-launch`; or
- attach an **Elastic IP**, a fixed public address you own until you release it.

**The full recipe for an instance the internet can reach:**

```mermaid
flowchart LR
    R["1. Public subnet<br/>route 0.0.0.0/0 → IGW"] --> IP["2. Public IP<br/>on the instance"] --> SG["3. Security group<br/>allows the port<br/>e.g. 443 from 0.0.0.0/0"] --> NACL["4. Network ACL<br/>allows it (default does)"] --> OK(("Reachable"))
```

If any one of these is missing, the instance isn't reachable.

AWS charges for every public IPv4 address, about **$0.005 per hour** (roughly $3.60 a month), whether in use or not. Give public IPs only to what really needs them, usually just load balancers.

### Why teams keep most things private

A database in a private subnet **can't be reached from the internet, even if a firewall rule is misconfigured**, because no route to it exists. That's a stronger guarantee than any firewall rule.

**The standard production layout:**

| Public subnets | Private subnets |
|---|---|
| Load balancers | Application servers, containers |
| NAT gateways | Databases, caches |
| (Rarely) a bastion host | Internal services and queues |

In modern setups, even web servers live in **private** subnets behind a load balancer. Only the load balancer is public. Engineers reach private instances through **SSM Session Manager**, instead of SSH through a public bastion host.

---

## 8. NAT gateways

### The problem

A database server in a private subnet is safe from the internet, but it still needs to download security updates. The private subnet has no route out.

The team needs **one-way access**: connections **from** the private instance to the internet are allowed, and connections **to** it from the internet stay impossible.

**Definition:** A **NAT gateway** (Network Address Translation) lets instances in private subnets start connections to the internet, while blocking every connection that starts from the internet.

### How it works

```mermaid
sequenceDiagram
    participant DB as Private instance<br/>10.0.2.20
    participant NAT as NAT gateway<br/>(public subnet, public IP 3.91.x.x)
    participant IGW as Internet gateway
    participant Repo as Package server<br/>on the internet

    DB->>NAT: request to Repo (route 0.0.0.0/0 → NAT)
    NAT->>IGW: same request, source rewritten to 3.91.x.x
    IGW->>Repo: request
    Repo-->>IGW: response to 3.91.x.x
    IGW-->>NAT: response
    NAT-->>DB: response, translated back to 10.0.2.20
    Note over Repo,NAT: A connection started from the internet<br/>reaches the NAT and is refused.<br/>The private IP is never visible.
```

1. The private instance sends its request. Its route table sends `0.0.0.0/0` to the NAT gateway.
2. The NAT gateway replaces the private source address with **its own public IP** and forwards the request through the internet gateway.
3. The response comes back to the NAT gateway, which passes it back to the instance.
4. Anyone on the internet only sees the NAT gateway's address, and the NAT gateway refuses connections it didn't start.

### Where the NAT gateway lives and how it's wired

**The NAT gateway lives in a public subnet**, because it needs the internet gateway for its own traffic.

```mermaid
flowchart LR
    Internet((Internet)) <--> IGW["Internet gateway"]
    subgraph VPC["Your VPC"]
        subgraph Pub["Public subnet<br/>route: 0.0.0.0/0 → IGW"]
            NAT["NAT gateway"]
        end
        subgraph Priv["Private subnet<br/>route: 0.0.0.0/0 → NAT"]
            DB["Database instance"]
        end
    end
    DB -->|outbound only| NAT
    NAT <--> IGW
```

There are two route table rows:

| Route table | Destination | Target |
|---|---|---|
| Private subnet's table | `0.0.0.0/0` | NAT gateway (`nat-...`) |
| Public subnet's table | `0.0.0.0/0` | Internet gateway (`igw-...`) |

The commands, for reference. The lab blocks them because a NAT gateway costs money:

```bash
aws ec2 allocate-address --domain vpc                          # Elastic IP for the NAT
aws ec2 create-nat-gateway --subnet-id <public-subnet> --allocation-id <eipalloc-...>
aws ec2 create-route --route-table-id <private-rt> \
  --destination-cidr-block 0.0.0.0/0 --nat-gateway-id <nat-...>
```

### Internet gateway vs NAT gateway

**The internet gateway is the VPC's only connection to the internet.** All internet traffic, in or out, goes through it. **A NAT gateway doesn't replace the internet gateway. It sits in front of it**, letting private instances use the internet gateway without being reachable themselves.

```mermaid
flowchart LR
    Internet((Internet))
    IGW["Internet gateway<br/>the VPC's connection<br/>to the internet"]
    Internet <--> IGW
    subgraph VPC["VPC"]
        subgraph Pub["Public subnet<br/>route: 0.0.0.0/0 → IGW"]
            Web["Load balancer<br/>public IP 54.1.2.3"]
            NAT["NAT gateway<br/>public IP 3.91.4.5"]
        end
        subgraph Priv["Private subnet<br/>route: 0.0.0.0/0 → NAT"]
            App["App server<br/>10.0.32.15<br/>no public IP"]
        end
    end
    IGW <-->|"in and out"| Web
    IGW <-->|"out, plus replies"| NAT
    App -->|"out only"| NAT
```

**Internet gateway:**

- Attached to the VPC. There's at most one per VPC.
- Lets resources **with a public IP** talk to the internet in **both directions**.
- **Swaps addresses for those resources.** An instance only knows its private IP (`10.0.1.15`). The internet gateway maps it to the instance's public IP (`54.1.2.3`) on the way out, and back on the way in. Each private IP is paired with exactly one public IP.
- Free, and needs no sizing.

**NAT gateway:**

- Placed in a **public subnet**, in one AZ.
- Lets resources **without a public IP** (in private subnets) start connections **out** to the internet.
- **Many** private instances share the NAT gateway's **one** public IP.
- Refuses any connection that starts from the internet.
- Sends its own traffic out **through the internet gateway**.
- About $0.045 per hour plus $0.045 per GB.

| | Internet gateway | NAT gateway |
|---|---|---|
| Direction | Both ways | **Outbound only** (plus replies) |
| Serves | Resources in public subnets with public IPs | Resources in private subnets |
| Lives in | Attached to the whole VPC | **A public subnet, in one AZ** |
| Address translation | Each private IP paired with one public IP | **Many** private IPs share **one** public IP |
| Instances need a public IP? | Yes | No. The NAT gateway uses its own. |
| Depends on the other? | No | **Yes**: needs an internet gateway in the VPC |
| Price (`us-east-1`) | **Free** | **~$0.045/hour (~$33/month) plus ~$0.045 per GB processed** |
| Limit | One per VPC | Several allowed; usually one per AZ |

#### Who can start a connection

| Resource | Can it reach the internet? | Can the internet reach it? | Path |
|---|---|---|---|
| In a public subnet **with** a public IP | Yes | **Yes** (if the SG allows) | Instance → IGW |
| In a public subnet **without** a public IP | No | No | No working path |
| In a private subnet with a route to a NAT gateway | **Yes** | **No** | Instance → NAT → IGW |
| In a private subnet with no NAT route | No | No | None (fully isolated) |

#### A request and its reply through the NAT gateway

```mermaid
sequenceDiagram
    participant App as App server 10.0.32.15
    participant NAT as NAT gateway (3.91.4.5)
    participant IGW as Internet gateway
    participant Site as pypi.org

    App->>NAT: from 10.0.32.15 to pypi.org
    Note over NAT: rewrites the source to 3.91.4.5<br/>and remembers who asked
    NAT->>IGW: from 3.91.4.5 to pypi.org
    IGW->>Site: request
    Site-->>IGW: reply to 3.91.4.5
    IGW-->>NAT: reply
    Note over NAT: looks up who asked
    NAT-->>App: reply delivered to 10.0.32.15
    Note over Site,NAT: A NEW connection started from the internet<br/>to 3.91.4.5 is dropped
```

#### Common points of confusion

1. **"Do I need both?"** For private instances to reach the internet, yes. A NAT gateway in a VPC with no internet gateway doesn't work.
2. **"Why must the NAT gateway be in a public subnet?"** Its own traffic has to reach the internet gateway, and only a public subnet's route table points there.
3. **"Can I attach the internet gateway to one subnet?"** No. It attaches to the whole VPC. Each subnet's route table decides whether that subnet uses it.
4. **"Does the internet gateway make my instances public?"** Not by itself. An instance needs a public route, a public IP, and a security group that allows the traffic.
5. **"Does traffic to S3 need a NAT gateway?"** No. Use the free S3 gateway endpoint. That traffic then never touches either gateway.
6. **"What about IPv6?"** IPv6 addresses are all public, so there's no NAT. Use an **egress-only internet gateway**, which allows outbound connections only and is free.

#### Which to use

| Resource | Put it in | Uses |
|---|---|---|
| Load balancer serving users | Public subnet | Internet gateway |
| App servers that call external APIs or download updates | Private subnet | NAT gateway (→ internet gateway) |
| Databases | Private data subnet | Neither (no internet route) |
| Anything talking to S3 or DynamoDB | Any subnet | Gateway endpoint (free) |
| Fully private ML or data workloads | Private subnet, VPC with no internet gateway | Interface endpoints only |

### High availability: one NAT gateway per AZ

A NAT gateway lives in **one AZ**. If all private subnets use a single NAT gateway in `us-east-1a`:

- when `us-east-1a` fails, private subnets in every AZ lose internet access;
- traffic from other AZs pays **cross-AZ data charges** to reach it.

Production setups use one NAT gateway per AZ, with each AZ's private route table pointing to its own:

```mermaid
flowchart TB
    IGW["Internet gateway"]
    subgraph AZa["us-east-1a"]
        NATa["NAT gateway a"] --> IGW
        PrivA["Private subnets a<br/>0.0.0.0/0 → NAT a"] --> NATa
    end
    subgraph AZb["us-east-1b"]
        NATb["NAT gateway b"] --> IGW
        PrivB["Private subnets b<br/>0.0.0.0/0 → NAT b"] --> NATb
    end
```

Trade-off: 3 AZs means 3 NAT gateways, about **$100 per month** before any data. Dev and staging environments often use a single NAT gateway to save money, and accept the risk.

### NAT gateway costs: the classic surprise bill

**Example:** private ECS tasks pull 2 TB of container images and send 1 TB of logs per month through a NAT gateway:

- **Processing:** 3,000 GB × $0.045 = **$135**
- **Hours:** 3 NAT gateways × ~$33 = **~$100**
- **Total ≈ $235 per month**, for traffic that never needed the internet

**How teams cut it:**

| Fix | Saves | Cost |
|---|---|---|
| **Gateway VPC endpoints** for **S3 and DynamoDB** | All NAT processing for S3 and DynamoDB traffic, often the largest share | **Free** |
| **Interface VPC endpoints** (PrivateLink) for ECR, CloudWatch Logs, SQS, Secrets Manager, and others | NAT processing for those services | ~$0.01/hour per AZ plus ~$0.01/GB, cheaper than NAT for heavy traffic |
| One NAT gateway in dev and staging | NAT hours | Less resilience |
| Delete forgotten NAT gateways | ~$33/month each | — |
| IPv6 with an **egress-only internet gateway** | NAT for IPv6 traffic | Free |

### VPC endpoints: private paths to AWS services

**Definition:** A **VPC endpoint** lets resources in private subnets reach AWS services, such as S3, ECR, or SQS, over the AWS network, without an internet gateway or NAT gateway.

```mermaid
flowchart LR
    subgraph VPC["VPC"]
        App["Private app"]
        GW["Gateway endpoint<br/>(route table entry)"]
        IF["Interface endpoint<br/>(network interface with a private IP)"]
    end
    App -->|S3, DynamoDB| GW --> S3[(S3 / DynamoDB)]
    App -->|ECR, Logs, SQS, Secrets Manager...| IF --> SVC[AWS service]
    App -.->|everything else| NAT[NAT gateway] -.-> Internet((Internet))
```

| | Gateway endpoint | Interface endpoint |
|---|---|---|
| Services | S3 and DynamoDB only | Most AWS services |
| How it works | A route in the route table | A network interface (ENI) with a private IP in your subnet |
| Cost | **Free** | Per hour per AZ, plus per GB |

---

## 9. Security groups and network ACLs

Routing decides **where** traffic can go. Firewalls decide **what is allowed through**. A VPC has two firewall layers in different places:

- **Security group (SG):** attached to each network interface (each instance, ECS task, RDS database, or load balancer). It filters traffic for that one resource.
- **Network ACL (NACL):** attached to a **subnet**. Every packet entering or leaving the subnet passes through it.

```mermaid
flowchart LR
    T((Traffic)) --> N["Network ACL<br/>at the subnet edge<br/>stateless"]
    subgraph Subnet
        N --> SG["Security group<br/>at the instance<br/>stateful"]
        SG --> I["EC2 instance"]
    end
```

### The key difference: state

**Security groups are stateful.** If an inbound request is allowed, the response is automatically allowed back out. You never write rules for return traffic.

**NACLs are stateless.** They check every packet on its own and remember nothing. Allowing inbound port 443 does nothing for the response packets. The **outbound** rules must allow them separately, or the replies are silently dropped.

```mermaid
sequenceDiagram
    participant C as Client
    participant N as NACL (stateless)
    participant S as Security group (stateful)
    participant I as Instance :443

    C->>N: request to port 443
    Note over N: inbound rule must allow 443
    N->>S: passes
    Note over S: inbound rule must allow 443
    S->>I: request
    I-->>S: response (to client's random port, e.g. 51234)
    Note over S: allowed automatically (remembers the request)
    S-->>N: response
    Note over N: OUTBOUND rule must allow ports 1024–65535,<br/>or the reply is silently dropped
    N-->>C: response
```

**Ephemeral ports:** the client's side of a connection uses a random high port, typically somewhere in 1024–65535. That's why stateless NACL rules for return traffic must allow that whole range.

### Comparison

| | Security group | Network ACL |
|---|---|---|
| Attached to | A network interface (instance, task, database) | A subnet |
| State | **Stateful**: replies allowed automatically | **Stateless**: replies need their own rule |
| Rule types | **Allow only** | **Allow and deny** |
| Evaluation | All rules together; any allow wins | **Numbered order, lowest first; first match wins** |
| Default (default VPC) | Default SG: all outbound allowed; inbound only from the same SG | Default NACL: **allow everything** in and out |
| New custom one | New SG: no inbound, all outbound | New custom NACL: **denies everything** until you add rules |
| Can reference other SGs | **Yes**, for example "allow 5432 from the app SG" | No, only CIDR ranges |
| Typical use | **All normal filtering** | Blocking specific IPs or ranges; extra subnet-wide guardrails |

### Security group chaining: the production pattern

Instead of allowing IP ranges, each tier's security group allows traffic **only from the security group of the tier in front of it**:

```mermaid
flowchart LR
    Internet((Internet)) -->|443| ALB["ALB<br/>sg-alb: allow 443 from 0.0.0.0/0"]
    ALB -->|8080| App["App servers<br/>sg-app: allow 8080 from sg-alb"]
    App -->|5432| DB[("Database<br/>sg-db: allow 5432 from sg-app")]
```

- When the app tier scales from 3 to 30 instances with new IP addresses, no rules change. Membership in `sg-app` is what matters.
- Even if someone launches a stray instance in the data subnet, it can't reach the database unless it's in `sg-app`.

### When teams use NACLs

The standard practice is to **do all normal filtering with security groups and leave NACLs on their allow-everything default**. Stateful rules are much harder to get wrong.

NACLs are needed for the job security groups can't do: **deny**. A security group has no deny rule, so "drop everything from this abusive IP" can't be written there. A NACL can do it, for every instance in the subnet at once:

| Rule # | Type | Protocol | Port | Source | Action |
|---|---|---|---|---|---|
| 90 | All traffic | All | All | `203.0.113.50/32` | **DENY** |
| 100 | All traffic | All | All | `0.0.0.0/0` | ALLOW |
| * | All traffic | All | All | `0.0.0.0/0` | DENY (built in) |

Rule 90 is checked before rule 100, so the abusive IP is dropped and everyone else is allowed.

```bash
aws ec2 create-network-acl-entry --network-acl-id acl-... \
  --ingress --rule-number 90 --protocol -1 \
  --cidr-block 203.0.113.50/32 --rule-action deny
```

For large-scale blocking (many IPs, bot traffic, HTTP attacks), teams use **AWS WAF** on the load balancer or CloudFront instead. It's built for that job.

---

## 10. Putting it all together: packet journeys

### Journey 1: a customer loads the web shop

```mermaid
sequenceDiagram
    participant U as Customer
    participant IGW as Internet gateway
    participant ALB as Load balancer<br/>(public subnet)
    participant App as App server<br/>(private subnet)
    participant DB as Database<br/>(private data subnet)

    U->>IGW: HTTPS to shop.example.com
    IGW->>ALB: public subnet route + sg-alb allows 443
    ALB->>App: local route + sg-app allows 8080 from sg-alb
    App->>DB: local route + sg-db allows 5432 from sg-app
    DB-->>App: rows
    App-->>ALB: HTML / JSON
    ALB-->>U: response
```

The app server and the database have no public IPs and no route from the internet. Only the load balancer is exposed.

### Journey 2: an app server downloads a security patch

```mermaid
flowchart LR
    App["App server 10.0.32.15<br/>(private)"] -->|"0.0.0.0/0 → NAT"| NAT["NAT gateway<br/>(public subnet)"]
    NAT -->|"0.0.0.0/0 → IGW"| IGW["Internet gateway"] --> Repo["Package repository"]
```

### Journey 3: an ECS task pulls its image and writes to S3

```mermaid
flowchart LR
    Task["ECS task<br/>(private subnet)"] -->|interface endpoint| ECR["ECR"]
    Task -->|gateway endpoint, free| S3[(S3)]
    Task -.->|no NAT needed| X["NAT gateway unused"]
```

---

## 11. Connecting VPCs and networks

As companies grow, they run many VPCs in many accounts, plus office networks and data centers.

| Option | What it does | Key facts |
|---|---|---|
| **VPC peering** | A private link between two VPCs | **Not transitive**: if A peers with B and B with C, A still can't reach C. Ranges must not overlap. Fine for a few VPCs. |
| **Transit Gateway** | A central router connecting many VPCs, VPNs, and Direct Connect | A hub-and-spoke design for dozens to thousands of VPCs. Charged per attachment-hour and per GB. |
| **PrivateLink** | Exposes one **service** privately to other VPCs or accounts | Consumers get only that service, not the whole network. Overlapping ranges are fine. |
| **Site-to-Site VPN** | An encrypted tunnel over the internet to an office or data center | Quick to set up; bandwidth limited per tunnel |
| **Direct Connect** | A dedicated private line to AWS | Consistent bandwidth and latency; takes weeks to provision |

```mermaid
flowchart TB
    subgraph Peering["VPC peering: not transitive"]
        direction LR
        PA[VPC A] <--> PB[VPC B] <--> PC[VPC C]
        PA -.-|"✖ no path A to C"| PC
    end
    subgraph TGW["Transit Gateway: hub and spoke"]
        direction TB
        Hub{{Transit Gateway}}
        V1[Prod VPC] <--> Hub
        V2[Staging VPC] <--> Hub
        V3[Shared services VPC] <--> Hub
        On[Office via VPN] <--> Hub
    end
```

This is why planning non-overlapping ranges early (section 3) matters. Peering, Transit Gateway routing, and VPNs all need unique ranges.

---

## 12. Observability and troubleshooting tools

| Tool | What it shows | Use it when |
|---|---|---|
| **VPC Flow Logs** | A record of each network flow: source, destination, port, bytes, and whether it was `ACCEPT` or `REJECT` | You need proof of what traffic happened and what was blocked |
| **Reachability Analyzer** | Checks whether a path exists between two resources, and names the blocking component | "Why can't A reach B?" |
| **Network Access Analyzer** | Finds unintended access, for example "anything reachable from the internet that shouldn't be" | Security reviews |

A Flow Log record:

```
2 123456789012 eni-0a1b2c3d 203.0.113.50 10.0.1.15 51234 22 6 10 840 1731200000 1731200060 REJECT OK
```

This says the IP `203.0.113.50` tried to reach port 22 (SSH) on `10.0.1.15`, and it was **rejected**.

---

## 13. Debugging: "I can't connect"

Check the layers in order, from the outside in:

```mermaid
flowchart TD
    A([Can't connect to the instance]) --> B{"Subnet route table has<br/>0.0.0.0/0 → IGW?<br/>(or NAT for outbound)"}
    B -->|no| B1["Add the route, or associate<br/>the right route table"]
    B -->|yes| C{"Instance has a public IP?<br/>(for internet access)"}
    C -->|no| C1["Add a public IP or Elastic IP,<br/>or go through a load balancer"]
    C -->|yes| D{"Security group allows<br/>the port from your source?"}
    D -->|no| D1["Add an inbound rule"]
    D -->|yes| E{"NACL allows inbound port<br/>AND outbound 1024–65535?"}
    E -->|no| E1["Fix the NACL rules<br/>(return traffic is the usual miss)"]
    E -->|yes| F{"Service listening?<br/>OS firewall?"}
    F --> F1["ss -tlnp, check the app,<br/>check iptables / firewalld"]
```

| Symptom | Usual cause | Fix |
|---|---|---|
| Connection times out from the internet | No route to the IGW, no public IP, or the SG doesn't allow the port | Check the route table, the public IP, and the SG inbound rules |
| Instance in a new VPC can't reach the internet | IGW not attached, or the subnet is still on the main route table | Attach the IGW, add the route, and associate the table |
| Private instance can't download updates | No NAT gateway route, or the NAT gateway is in a private subnet | Put the NAT gateway in a public subnet; route private `0.0.0.0/0` to it |
| SG looks correct, but replies never arrive | A custom NACL is missing the outbound ephemeral port rule | Allow outbound 1024–65535 (and inbound, for outbound-started connections) |
| `InvalidSubnet.Conflict` when creating a subnet | The range overlaps another subnet | Choose a range that doesn't overlap |
| `InvalidSubnet.Range` | The range is outside the VPC's CIDR | Choose a range inside the VPC |
| Can't peer two VPCs | Their CIDR ranges overlap | Re-plan ranges, or use PrivateLink |
| ECS or EKS tasks stuck, "insufficient IPs" | Subnet out of addresses | Use larger subnets, or add a secondary CIDR |
| Large NAT gateway bill | S3, ECR, and logs traffic going through NAT | Add gateway and interface VPC endpoints |
| App works in one AZ but not another | That AZ's subnet uses a different route table or NACL | Compare the route table and NACL associations per subnet |

---

## 14. Cost summary

Approximate `us-east-1` prices; check the AWS pricing page for your Region.

| Item | Cost |
|---|---|
| VPC, subnets, route tables, security groups, NACLs | **Free** |
| Internet gateway | **Free** (normal data transfer out to the internet applies) |
| NAT gateway | **~$0.045/hour + ~$0.045/GB processed** |
| Public IPv4 address (any, including Elastic IPs) | **~$0.005/hour** (~$3.60/month) |
| Gateway endpoint (S3, DynamoDB) | **Free** |
| Interface endpoint | ~$0.01/hour per AZ + ~$0.01/GB |
| Data between AZs in the same Region | ~$0.01/GB in each direction |
| Transit Gateway | Per attachment-hour + per GB |
| VPC Flow Logs | CloudWatch Logs or S3 ingestion and storage |

---

# Part 2: Deep dives

Sections 15–21 apply the building blocks to real systems: security, databases, APIs, ML workloads, scale, and how network setups differ by company size and industry.

---

## 15. Deep dive: VPC security in layers

### Defense in depth

No single control is trusted alone. Each layer assumes the one in front of it might fail:

```mermaid
flowchart LR
    U((Internet)) --> E["1. Edge<br/>CloudFront + WAF + Shield<br/>blocks attacks, bots, DDoS"]
    E --> L["2. Public subnet<br/>ALB only, TLS 443<br/>SG: CloudFront prefix list"]
    L --> A["3. Private app subnet<br/>SG: only from ALB SG<br/>no public IPs"]
    A --> D["4. Private data subnet<br/>SG: only from app SG<br/>no route to the internet"]
    A -.-> X["5. Egress control<br/>NAT + Network Firewall<br/>allowlist of domains"]
    D -.-> K["6. Data layer<br/>KMS encryption, IAM auth,<br/>audit logs"]
```

| Layer | Control | What it stops |
|---|---|---|
| Edge | **CloudFront**, **AWS WAF** (SQL injection, XSS, rate limits, bot rules), **AWS Shield** (DDoS) | Attacks before they reach your VPC |
| Network entry | Only the load balancer is public; its SG allows only 443 | Direct access to servers |
| Network inside | SG chaining (each tier accepts only the tier in front) | Lateral movement after one server is compromised |
| Routing | Data subnets have no internet route at all | Exposure through misconfigured firewalls |
| Egress | Restricted outbound rules, NAT with **AWS Network Firewall**, **Route 53 Resolver DNS Firewall** | Malware calling home, data being sent out |
| AWS API access | **VPC endpoint policies**, bucket policies requiring `aws:SourceVpce` | Copying data to an attacker's S3 bucket |
| Identity | IAM roles per workload, no long-lived keys | Stolen credentials being useful |
| Detection | Flow Logs, DNS query logs, **GuardDuty**, Security Hub | Unnoticed attacks |

### Inbound security best practices

- **Only load balancers, NAT gateways, and edge services get public IPs.**
- **Allow `0.0.0.0/0` inbound only on 443 (and 80 for redirects), and only on the load balancer.**
- **If CloudFront is in front, lock the ALB to CloudFront.** Allow only the AWS-managed prefix list `com.amazonaws.global.cloudfront.origin-facing` in the ALB's security group, so nobody can bypass CloudFront and WAF.
- **Never open SSH (22) or RDP (3389) to the internet.** Use **SSM Session Manager**: no open ports, IAM-controlled access, and every session logged.
- **Reference security groups, not IP ranges**, between tiers.

### Outbound (egress) security: often forgotten

New security groups allow **all outbound** traffic by default. If an attacker gets code running on an app server, it can send data anywhere on the internet. Mature teams restrict outbound traffic:

```mermaid
flowchart LR
    App["Private app server"] -->|"only 443"| NFW["AWS Network Firewall<br/>allow: *.stripe.com, api.github.com<br/>deny: everything else"]
    NFW --> NAT["NAT gateway"] --> IGW["Internet gateway"] --> OK["Allowed partners"]
    App -->|S3 via gateway endpoint| EP["S3 endpoint<br/>policy: only company buckets"]
    EP --> S3[(Company S3 buckets)]
    App -.-|"✖ blocked"| Bad["attacker.example.com"]
```

1. **Tighten security group egress rules.** For example, the app SG may send only to the DB SG on 5432 and to `0.0.0.0/0` on 443.
2. **Filter outbound domains** with AWS Network Firewall (an allowlist of domains) or Route 53 Resolver DNS Firewall (block known-bad domains).
3. **Use endpoint policies to prevent data exfiltration.** An S3 gateway endpoint policy can allow access only to your organization's buckets:

```json
{
  "Statement": [{
    "Effect": "Allow",
    "Principal": "*",
    "Action": "s3:*",
    "Resource": "*",
    "Condition": { "StringEquals": { "aws:ResourceOrgID": "o-abc123example" } }
  }]
}
```

4. **Lock buckets to the VPC.** In the bucket policy, deny access unless the request comes through your endpoint (`aws:SourceVpce`). Then stolen credentials can't download the bucket from a laptop.

### Isolation by account, not just by VPC

The strongest boundary in AWS is the **account**. Production teams use separate accounts for prod, staging, dev, security tooling, and shared networking, managed with AWS Organizations and Control Tower. **Service Control Policies (SCPs)** can forbid risky actions in every account, for example "no one may create an internet gateway in a data account".

---

## 16. Deep dive: databases in a VPC

### Where a database lives

```mermaid
flowchart TB
    subgraph VPC["VPC 10.0.0.0/16"]
        subgraph AZa["us-east-1a"]
            AppA["App tasks<br/>sg-app"]
            Pri[("Aurora / RDS primary<br/>10.0.128.10")]
        end
        subgraph AZb["us-east-1b"]
            AppB["App tasks<br/>sg-app"]
            Stb[("Standby / replica<br/>10.0.129.10")]
        end
        Proxy["RDS Proxy<br/>connection pooling"]
    end
    AppA --> Proxy
    AppB --> Proxy
    Proxy --> Pri
    Pri -.->|synchronous replication| Stb
```

| Best practice | Why |
|---|---|
| **A DB subnet group of private data subnets in at least 2 AZs** (3 is better) | RDS requires 2 AZs; Multi-AZ failover needs a subnet in another AZ |
| **`PubliclyAccessible = false`** | The database gets no public IP |
| **The DB security group allows only the app SG on the DB port** (5432 or 3306) | Only the application can connect |
| **No internet route in the data subnets** | Unreachable even if a security group is misconfigured |
| **Multi-AZ** for production | Automatic failover in about a minute if the primary's AZ fails |
| **Encryption at rest (KMS) and in transit** (`rds.force_ssl = 1`) | Protects data on disk and on the network |
| **Credentials in Secrets Manager with rotation**, or **IAM database authentication** | No passwords in code |
| **RDS Proxy** in front of the database for Lambda and auto-scaling containers | Pools connections, so scaling to 500 tasks doesn't open 10,000 connections |

### How engineers connect to a private database

They never make it public. Instead:

| Method | How it works |
|---|---|
| **SSM Session Manager port forwarding** | `aws ssm start-session --document-name AWS-StartPortForwardingSessionToRemoteHost` through a small private instance. No open inbound ports. |
| **AWS Client VPN** | Engineers' laptops join the VPC network |
| **Direct Connect or VPN from the office** | For corporate networks |
| **RDS Query Editor** (Aurora) | Run SQL from the console through the Data API |

### Scaling databases in the network

- **Read replicas** in other AZs spread read traffic. The app sends reads to the reader endpoint.
- **Cross-AZ traffic costs** about $0.01/GB each way between the app and the database. At high volume, prefer readers in the same AZ as the app.
- **Connection limits** are usually hit before CPU limits when apps scale out. Use RDS Proxy or app-side pooling.
- **Cross-Region read replicas** or Aurora Global Database for disaster recovery. These need non-overlapping CIDR ranges if the VPCs are ever connected.

### Services that aren't in your VPC

**DynamoDB and S3 don't live inside your VPC.** They're Regional AWS services. Reach them privately through **gateway endpoints** (free), with endpoint policies restricting which tables or buckets can be used.

**ElastiCache, OpenSearch, MSK (Kafka), and Redshift** follow the same pattern as RDS: private subnets, a subnet group across AZs, and SG access only from the app SG.

---

## 17. Deep dive: exposing APIs

### Public API: three standard setups

```mermaid
flowchart TB
    subgraph A["Setup A: CloudFront + ALB + containers (most common for web apps)"]
        direction LR
        U1((Users)) --> CF1["CloudFront + WAF"] --> ALB1["Public ALB<br/>SG: CloudFront prefix list"] --> ECS1["ECS / EKS / EC2<br/>private subnets"]
    end
    subgraph B["Setup B: API Gateway + VPC Link (managed API features)"]
        direction LR
        U2((Clients)) --> APIGW["API Gateway<br/>auth, throttling, API keys"] --> VL["VPC Link"] --> NLB["Private NLB / ALB"] --> SVC["Private services"]
    end
    subgraph C["Setup C: API Gateway + Lambda (serverless)"]
        direction LR
        U3((Clients)) --> APIGW2["API Gateway"] --> L["Lambda<br/>(in VPC only if it needs the DB)"] --> RP["RDS Proxy"] --> DB[(Database)]
    end
```

| Setup | Choose when | Network notes |
|---|---|---|
| **A: CloudFront + public ALB + private compute** | Web apps and APIs with steady traffic, running on containers | Only the ALB is public. Lock it to CloudFront. TLS certificates come from ACM. |
| **B: API Gateway + VPC Link + private load balancer** | You need API keys, usage plans, request validation, and per-client throttling, but run on containers | **No public load balancer at all.** REST APIs traditionally connect through an NLB; HTTP APIs can use an ALB, NLB, or Cloud Map. |
| **C: API Gateway + Lambda** | Spiky or low traffic, small team | Lambda runs outside your VPC unless it needs private resources such as RDS. If it's in a VPC, it needs endpoints or NAT to call AWS APIs. |

**Extra options at scale:**

- **NLB** for TCP, very high throughput, or static IPs (partners who need to allowlist your IPs).
- **AWS Global Accelerator** for static anycast IPs and faster global routing.
- **Multi-Region active-active** with Route 53 latency routing.

### Private (internal) APIs

Internal APIs, such as an admin service, internal microservices, or partner-only integrations, should never be on the internet:

| Need | Setup |
|---|---|
| Internal service used by other services in the same VPC | **Internal ALB** (no public IP), or **ECS Service Connect** / service mesh |
| Internal API used by many VPCs and accounts | **VPC Lattice** (service-to-service networking with IAM auth policies), or **PrivateLink** (an NLB plus an endpoint service) |
| API Gateway that only internal clients can call | **Private REST API** reachable only through an `execute-api` interface endpoint, with a resource policy that allows only that endpoint |
| Employees' internal tools | Internal ALB plus Client VPN, or Verified Access (identity-aware access without a VPN) |

```mermaid
flowchart LR
    subgraph Consumer["Consumer VPC (another team / account)"]
        C1[Client service] --> EP["Interface endpoint<br/>10.5.1.20"]
    end
    subgraph Provider["Provider VPC"]
        NLB2["NLB"] --> S2["Payments API<br/>private"]
    end
    EP -->|PrivateLink: only this service,<br/>overlapping CIDRs OK| NLB2
```

### API security checklist

- TLS everywhere, with certificates from ACM. Use TLS 1.2 or later.
- WAF rules: AWS managed rule groups, plus rate-based rules per IP.
- Authentication at the edge: Cognito, a JWT authorizer, or IAM. Clients don't reach the private network without it.
- Throttling: API Gateway usage plans, or WAF rate limits, so one client can't take down the service.
- Load balancer access logs and WAF logs go to a central log account.

---

## 18. Deep dive: ML training and inference networking

ML workloads add three networking concerns: **very large data and model files**, **GPU capacity that varies by AZ**, and **sensitive data in prompts and training sets**.

### Public inference: a model API for customers

```mermaid
flowchart LR
    U((Customers / apps)) --> CF["CloudFront + WAF<br/>rate limits, bot control"]
    CF --> GW["API Gateway<br/>API keys, usage plans,<br/>per-customer quotas"]
    GW --> VL["VPC Link"]
    subgraph VPC["Inference VPC"]
        VL --> NLB["Private NLB / ALB"]
        NLB --> GPU["GPU inference fleet<br/>(EKS / ECS on EC2 GPU)<br/>private subnets, 3 AZs"]
        GPU --> S3EP["S3 gateway endpoint<br/>(model weights)"]
        GPU --> ECREP["ECR interface endpoints<br/>(container images)"]
    end
    S3EP --> S3[(Model artifacts)]
```

| Concern | Best practice |
|---|---|
| Abuse and cost control | GPU time is expensive. Require API keys or auth, set per-customer quotas, and use WAF rate limits. |
| Exposure | GPU nodes in private subnets. Only API Gateway or the load balancer faces the internet. |
| Model download time and cost | Weights can be tens of GB. Pull them from S3 through the **free gateway endpoint**, never through NAT. Cache them on local NVMe or EFS/FSx. |
| GPU capacity | GPUs often run out in one AZ. Have subnets in **every AZ** so the scheduler can find capacity. |
| Long requests and streaming | Raise ALB idle timeouts for streaming responses (for example token streaming); NLBs suit long-lived connections. |
| Scaling | Scale on queue depth or GPU utilization, and keep warm capacity, because GPU nodes take minutes to start and load weights. |

**Managed option: SageMaker real-time endpoints.** AWS runs the instances. Clients call the `sagemaker-runtime` API, often through API Gateway or Lambda. To keep that traffic private, call it through a `sagemaker.runtime` **interface endpoint**.

### Private inference: internal or sensitive models

Use this when prompts or inputs contain customer data, health records, or code, and must never cross the public internet:

```mermaid
flowchart LR
    subgraph VPC["Private VPC (no internet gateway, no NAT)"]
        App["Internal app<br/>private subnet"]
        EP1["Interface endpoint<br/>sagemaker.runtime"]
        EP2["Interface endpoint<br/>bedrock-runtime"]
        App --> EP1
        App --> EP2
    end
    EP1 -->|PrivateLink| SM["SageMaker endpoint<br/>VpcConfig + network isolation"]
    EP2 -->|PrivateLink| BR["Amazon Bedrock<br/>foundation models"]
```

| Control | What it does |
|---|---|
| **No internet gateway or NAT** in the VPC | Nothing can reach the internet, in either direction |
| **Interface endpoints** for `bedrock-runtime`, `sagemaker.runtime`, ECR, CloudWatch Logs, STS, and KMS | All AWS calls stay on the AWS network |
| **Endpoint policies** | Allow only specific models or endpoints. For example, allow only the approved Bedrock model ARNs. |
| **SageMaker `VpcConfig`** | The model container's network interfaces live in your private subnets, so it can reach private resources such as a feature store |
| **SageMaker network isolation** (`EnableNetworkIsolation`) | The container can make **no** outbound network calls, so a malicious model can't leak data |
| **KMS encryption** | For model artifacts, endpoint storage, and logs |
| **Private package mirrors** | Python packages through CodeArtifact, and Hugging Face models copied into S3 or ECR in advance, so nothing downloads from the internet at runtime |

### Training networking

```mermaid
flowchart TB
    subgraph VPC["Training VPC"]
        subgraph Sub["Private subnet, one AZ<br/>(large: e.g. /20)"]
            N1["GPU node 1"] <-->|"all traffic, SG self-reference<br/>EFA for fast GPU-to-GPU"| N2["GPU node 2"]
            N2 <--> N3["GPU node 3"]
        end
        FSX["FSx for Lustre<br/>fast shared dataset storage"]
        N1 & N2 & N3 --> FSX
    end
    FSX <-->|"linked bucket,<br/>gateway endpoint"| S3[(Training data in S3)]
```

- **Distributed training needs node-to-node traffic.** Add a security group rule that allows all traffic **from the same security group** (a self-reference).
- **Keep training nodes in one AZ**, ideally in a cluster placement group. Cross-AZ traffic is slower, and it costs money per GB.
- **Use EFA (Elastic Fabric Adapter)** on supported GPU instances for fast GPU-to-GPU communication across nodes.
- **Large subnets**: each node, and in EKS each pod, takes an IP address.
- **Read data from S3 through the gateway endpoint**, or through FSx for Lustre linked to S3. Moving terabytes through a NAT gateway costs ~$45 per TB.

### Public vs private ML setups

| | Public inference API | Private inference | Training |
|---|---|---|---|
| Who calls it | External customers | Internal apps only | Batch jobs |
| Entry point | CloudFront/WAF → API Gateway → private LB | Interface endpoint inside the VPC | None (no inbound) |
| Internet egress | NAT only if needed; endpoints preferred | **None** | None, or a strict allowlist |
| Main network risk | Abuse, cost blowouts, DDoS | Data leaving the network | Data cost, slow node-to-node links |
| Key controls | Auth, quotas, WAF, private GPU subnets | No IGW or NAT, endpoint policies, network isolation | SG self-reference, EFA, one AZ, S3 endpoint |

---

## 19. Deep dive: scaling a VPC

### IP addresses are the first thing to run out

Every ENI uses one IP address: EC2 instances, ECS tasks, EKS pods (by default), Lambda's VPC interfaces, load balancer nodes, interface endpoints, and NAT gateways.

| Problem | Fix |
|---|---|
| Subnets too small for containers | Plan `/19` or `/20` private subnets from the start |
| EKS uses one VPC IP per pod | **Prefix delegation** (each node gets `/28` blocks, more pods per node), or **custom networking** with a secondary CIDR, often from `100.64.0.0/10`, just for pods |
| The VPC range itself is full | Add **secondary CIDR blocks** (up to 5 by default) |
| Company-wide IPv4 shortage | **IPv6 dual-stack**: practically unlimited addresses, no public IPv4 charges, and an egress-only internet gateway for outbound |
| Tracking ranges across hundreds of VPCs | **VPC IPAM** assigns non-overlapping ranges automatically |

### Default limits worth knowing

Most are soft limits that can be raised through Service Quotas.

| Resource | Default |
|---|---|
| VPCs per Region | 5 |
| Subnets per VPC | 200 |
| Routes per route table | 50 (can be raised to 1,000) |
| Inbound or outbound rules per security group | 60 each |
| Security groups per network interface | 5 (up to 16) |
| Rules per network ACL | 20 per direction (up to 40) |
| NAT gateway | Scales automatically to 100 Gbps; ~55,000 simultaneous connections to each unique destination |
| ENIs per instance | Depends on the instance type; this limits pods per node in EKS |

### DNS inside a VPC

- Every VPC has a built-in DNS resolver at the **VPC base address + 2**, for example `10.0.0.2`.
- Turn on **`enableDnsSupport`** and **`enableDnsHostnames`**. Interface endpoints with private DNS need both.
- **Route 53 private hosted zones** give internal names such as `db.internal.shop.com` that only resolve inside chosen VPCs.
- **Route 53 Resolver endpoints** connect DNS between the VPC and an office or data center (hybrid DNS).

### Scaling the network design itself

```mermaid
flowchart LR
    S1["1 VPC<br/>single team"] --> S2["Few VPCs<br/>peering"]
    S2 --> S3["Many VPCs and accounts<br/>Transit Gateway hub"]
    S3 --> S4["Enterprise<br/>TGW + central egress +<br/>central inspection + shared endpoints"]
```

---

## 20. Deep dive: multi-account and enterprise network designs

### Hub and spoke with central egress and inspection

Instead of a NAT gateway and firewall in every VPC, large companies route all outbound internet traffic through **one egress VPC**:

```mermaid
flowchart TB
    subgraph Spokes["Workload accounts (no IGW, no NAT)"]
        P["Prod VPC<br/>10.0.0.0/16"]
        S["Staging VPC<br/>10.1.0.0/16"]
        D["Data VPC<br/>10.2.0.0/16"]
    end
    TGW{{"Transit Gateway<br/>(network account)"}}
    P & S & D <--> TGW
    subgraph Egress["Egress + inspection VPC"]
        NFW["Network Firewall"] --> NAT["NAT gateways"] --> IGW["Internet gateway"]
    end
    subgraph Shared["Shared services VPC"]
        EPS["Central interface endpoints<br/>+ Route 53 private zones"]
        AD["Directory, CI runners, tooling"]
    end
    TGW <--> NFW
    TGW <--> EPS
    TGW <--> VPN["Site-to-Site VPN / Direct Connect<br/>to offices and data centers"]
    IGW <--> Internet((Internet))
```

| Pattern | What it is | Benefit |
|---|---|---|
| **Central egress VPC** | All spokes send `0.0.0.0/0` to the Transit Gateway, which sends it to shared NAT gateways | Fewer NAT gateways; one place for outbound control |
| **Central inspection** | AWS Network Firewall, or third-party firewalls behind a **Gateway Load Balancer**, inspects traffic between VPCs and to the internet | Consistent security policy everywhere |
| **Shared interface endpoints** | One set of endpoints, shared through Route 53 private hosted zones | Avoids paying for endpoints in every VPC |
| **Shared VPC (RAM subnet sharing)** | The network team owns one VPC and shares subnets with app accounts | App teams launch resources without managing networking |
| **VPC Lattice** | Service-to-service connectivity and IAM auth across VPCs and accounts | No routing or CIDR coordination needed for service calls |

### Multi-Region

- A separate VPC per Region, with non-overlapping ranges, for example `10.0.0.0/16` in `us-east-1` and `10.16.0.0/16` in `eu-west-1`.
- Transit Gateway **inter-Region peering** for private cross-Region traffic.
- Route 53 health checks with failover or latency routing for users.
- Data replication through Aurora Global Database, DynamoDB global tables, and S3 replication.

For the full multi-Region picture, see [`multi-region-and-ecr.md`](multi-region-and-ecr.md). It covers RPO and RTO, DR strategies, image replication, deploying in waves, databases accessed across Regions, and failover.

---

## 21. Reference setups and best-practice checklist

### Setups by company stage and need

| Setup | Network design |
|---|---|
| **Learning or prototype** | Default VPC is acceptable. Delete resources afterwards. |
| **Startup, one product** | One VPC per environment (in separate accounts if possible), 2–3 AZs, public and private subnets. One NAT gateway in dev; one per AZ in prod. S3 and DynamoDB gateway endpoints. CloudFront + ALB in front. |
| **Growing company** | An account per environment and per team, IPAM-planned ranges, a Transit Gateway once there are more than 3–4 VPCs, centralized logging and Flow Logs. |
| **Enterprise** | Control Tower landing zone, Transit Gateway hub, central egress and inspection, shared endpoints, Direct Connect to data centers, SCPs blocking risky network changes. |
| **Regulated (PCI, HIPAA)** | Sensitive workloads in isolated accounts and VPCs, no direct internet egress, interface endpoints for all AWS services, Network Firewall, Flow Logs kept in a separate log-archive account, encryption with customer-managed KMS keys. |
| **Private ML or data platform** | No internet gateway or NAT, PrivateLink to Bedrock, SageMaker, and S3, network-isolated training and inference, private package mirrors. |
| **Serverless-first** | Lambda outside the VPC by default. Only functions that need private resources (RDS, ElastiCache) are VPC-attached, with endpoints instead of NAT where possible. |

### Best-practice checklist

**Design**
- [ ] A `/16` per VPC, from a company-wide plan with no overlaps
- [ ] At least 2 AZs, preferably 3, for every tier
- [ ] Public, private app, and private data subnets, with large app subnets for containers
- [ ] The main route table left private; public subnets made public deliberately

**Security**
- [ ] Only load balancers and NAT gateways have public IPs
- [ ] SG chaining between tiers; no SSH or RDP from the internet; SSM for access
- [ ] Outbound traffic restricted where data is sensitive
- [ ] Endpoint policies and bucket policies against data exfiltration
- [ ] WAF on every public entry point
- [ ] Flow Logs on, sent to a central account

**Cost**
- [ ] S3 and DynamoDB gateway endpoints in every VPC
- [ ] Interface endpoints for high-traffic AWS services (ECR, Logs)
- [ ] NAT gateways per AZ in prod only; none forgotten in old environments
- [ ] Unused Elastic IPs and public IPv4 addresses released
- [ ] Cross-AZ traffic watched for chatty services

**Operations**
- [ ] All networking defined in code (Terraform, CloudFormation, or CDK), never clicked by hand
- [ ] Reachability Analyzer and Flow Logs used when debugging
- [ ] Quotas (IPs, routes, rules) monitored before they're hit

---

## 22. Full lab walkthrough

```mermaid
flowchart LR
    A["Inspect default VPC<br/>default-vpc.json, -id.txt, -subnets.json"] --> B["create-vpc<br/>10.0.0.0/16"]
    B --> C["create-subnet ×2<br/>10.0.1.0/24 (1a), 10.0.2.0/24 (1b)"]
    C --> D["create + attach<br/>internet gateway"]
    D --> E["create-route-table<br/>+ route 0.0.0.0/0 → IGW<br/>+ associate subnet A"]
    E --> F["Subnet A = public<br/>Subnet B = private"]
```

The lab tasks also save their responses under `/root/`. Use the exact file names each task asks for; the ones below are examples.

```bash
# 1. Default VPC
aws ec2 describe-vpcs --filters Name=isDefault,Values=true > /root/default-vpc.json
jq -r '.Vpcs[0].VpcId' /root/default-vpc.json > /root/default-vpc-id.txt
aws ec2 describe-subnets --filters Name=vpc-id,Values=$(cat /root/default-vpc-id.txt) > /root/default-subnets.json

# 2. Your VPC
aws ec2 create-vpc --cidr-block 10.0.0.0/16 > /root/vpc.json
VPC_ID=$(jq -r '.Vpc.VpcId' /root/vpc.json)

# 3. Two subnets in two AZs
aws ec2 create-subnet --vpc-id "$VPC_ID" --cidr-block 10.0.1.0/24 --availability-zone us-east-1a > /root/subnet-a.json
aws ec2 create-subnet --vpc-id "$VPC_ID" --cidr-block 10.0.2.0/24 --availability-zone us-east-1b > /root/subnet-b.json
SUBNET_A=$(jq -r '.Subnet.SubnetId' /root/subnet-a.json)

# 4. Internet gateway
aws ec2 create-internet-gateway > /root/igw.json
IGW_ID=$(jq -r '.InternetGateway.InternetGatewayId' /root/igw.json)
aws ec2 attach-internet-gateway --internet-gateway-id "$IGW_ID" --vpc-id "$VPC_ID"

# 5. Route table for the public subnet
aws ec2 create-route-table --vpc-id "$VPC_ID" > /root/route-table.json
RT_ID=$(jq -r '.RouteTable.RouteTableId' /root/route-table.json)
aws ec2 create-route --route-table-id "$RT_ID" --destination-cidr-block 0.0.0.0/0 --gateway-id "$IGW_ID"
aws ec2 associate-route-table --route-table-id "$RT_ID" --subnet-id "$SUBNET_A"

# Verify: which subnets use which route table
aws ec2 describe-route-tables --filters Name=vpc-id,Values="$VPC_ID" \
  --query 'RouteTables[].{Id:RouteTableId,Main:Associations[0].Main,Subnets:Associations[].SubnetId,Routes:Routes[].[DestinationCidrBlock,GatewayId]}'
```

Shell variables such as `$VPC_ID` are lost if the terminal restarts. Re-read them from the saved JSON files with `jq`.

---

## 23. Interview-style questions

1. **What makes a subnet public?**
   Its route table has a route to an internet gateway. Instances in it also need a public IP and security group rules to actually be reachable.

2. **How does a private instance download updates without being reachable from the internet?**
   Through a NAT gateway in a public subnet. The private route table sends `0.0.0.0/0` to the NAT, and the NAT only allows connections that start from inside.

3. **Security group vs NACL?**
   A security group is stateful, attached to an interface, allow-only, and can reference other SGs. A NACL is stateless, attached to a subnet, has numbered allow and deny rules, and needs explicit rules for return traffic. Use SGs for filtering and NACLs for explicit denies.

4. **Your NAT gateway bill is $2,000 a month. What do you check?**
   Which traffic goes through it, using Flow Logs or the NAT gateway metrics. Usually it's S3, ECR, and CloudWatch Logs. Add the free S3 and DynamoDB gateway endpoints and interface endpoints for the rest, remove unneeded NAT gateways in non-production environments, and look for cross-AZ NAT traffic.

5. **Why one NAT gateway per AZ?**
   A NAT gateway lives in one AZ. Sharing one makes it a single point of failure for every AZ, and adds cross-AZ data charges.

6. **Why plan non-overlapping CIDR ranges across the company?**
   Peering, Transit Gateway, and VPN routing need unique ranges. Overlaps force painful re-addressing, or PrivateLink workarounds.

7. **Can VPC A reach VPC C if A peers with B and B peers with C?**
   No. Peering isn't transitive. Use a Transit Gateway, or peer A and C directly.

8. **An EKS cluster stops scheduling pods with "insufficient IPs". Why?**
   Every pod gets a VPC IP address, and the subnets are full. Use larger subnets, add a secondary CIDR block, or enable prefix delegation.

9. **How do you let engineers reach private instances without a public bastion host?**
   SSM Session Manager. It needs no inbound ports and no public IP, and every session is logged.

---

## 24. Command cheat sheet

| Command | Purpose |
|---|---|
| `aws ec2 describe-vpcs [--filters Name=isDefault,Values=true]` | List VPCs |
| `aws ec2 create-vpc --cidr-block 10.0.0.0/16` | Create a VPC |
| `aws ec2 describe-subnets --filters Name=vpc-id,Values=...` | List subnets in a VPC |
| `aws ec2 create-subnet --vpc-id ... --cidr-block ... --availability-zone ...` | Create a subnet in one AZ |
| `aws ec2 modify-subnet-attribute --subnet-id ... --map-public-ip-on-launch` | Auto-assign public IPs in a subnet |
| `aws ec2 create-internet-gateway` / `attach-internet-gateway` | Create and attach an IGW |
| `aws ec2 create-route-table --vpc-id ...` | Create a route table |
| `aws ec2 create-route --route-table-id ... --destination-cidr-block 0.0.0.0/0 --gateway-id igw-...` | Route to the IGW |
| `aws ec2 create-route ... --nat-gateway-id nat-...` | Route to a NAT gateway |
| `aws ec2 associate-route-table --route-table-id ... --subnet-id ...` | Attach a subnet to a route table |
| `aws ec2 describe-route-tables --filters Name=vpc-id,Values=...` | Read routes and associations |
| `aws ec2 create-nat-gateway --subnet-id ... --allocation-id ...` | Create a NAT gateway (costs money) |
| `aws ec2 create-vpc-endpoint --vpc-id ... --service-name com.amazonaws.us-east-1.s3 --route-table-ids ...` | Free S3 gateway endpoint |
| `aws ec2 create-security-group` / `authorize-security-group-ingress` | Create an SG and add inbound rules |
| `aws ec2 create-network-acl-entry` | Add a NACL allow or deny rule |
| `aws ec2 create-flow-logs` | Turn on VPC Flow Logs |
| `aws ec2 delete-...` | Clean up in reverse order: instances, NAT gateway, detach and delete IGW, subnets, route tables, then the VPC |
