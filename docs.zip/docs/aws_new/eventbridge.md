# Amazon EventBridge: From Basics to Production Scale

This guide covers what EventBridge is, the core objects (event, bus, rule, pattern, target), how it differs from SQS and SNS, and the delivery, scaling, cost, and debugging knowledge production teams rely on.

The running example is an online shop. When a customer places an order, several independent programs need to react: the **orders** service (the producer), **email**, **fraud**, **analytics**, and **audit**.

---

## 1. The problem EventBridge solves

### Without events: direct calls

The order service calls every other service itself:

```mermaid
flowchart LR
    O[Order service] -->|call| E[Email service]
    O -->|call| F[Fraud service]
    O -->|call| A[Analytics]
    O -->|call| W[Warehouse]
    O -.->|"new team? change<br/>the order service again"| N[Loyalty points]
```

The problems grow with every new service:

- **Tight coupling.** The order service must know every consumer: its address, its API, and its failure behavior.
- **Every new consumer means a code change** and a redeploy of the order service.
- **Failures spread.** If the fraud service is slow, order creation becomes slow.
- **Ownership blurs.** The orders team ends up responsible for other teams' integrations.

### With events: announce once

The order service announces "an order was created" once, to one place, and moves on. Each consumer decides for itself what to listen to.

```mermaid
flowchart LR
    O[Order service] -->|"put-events: OrderCreated"| B{{Event bus}}
    B -->|rule: all orders| E[Email]
    B -->|"rule: total > 1000"| F[Fraud]
    B -->|rule: all orders| A[Analytics]
    B -->|rule: all orders| W[Warehouse]
    B -.->|"new rule only,<br/>no producer change"| N[Loyalty points]
```

This style is called **event-driven architecture**: producers publish facts about what happened, and consumers react to the facts independently. EventBridge is the AWS service that routes those facts.

---

## 2. Core definitions

### Event

**Definition:** An event is a small JSON record stating that something happened. It's a fact in the past tense (`OrderCreated`, not `CreateOrder`). It never asks a consumer to do something.

### Envelope and detail

Every event has the same outer structure, called the **envelope**. The sender fills in three fields. EventBridge adds the rest when it accepts the event:

```json
{
  "version": "0",
  "id": "6a7e8feb-b491-4cf7-a9f1-bf3703467718",
  "source": "shop.orders",
  "detail-type": "OrderCreated",
  "account": "111122223333",
  "region": "us-east-1",
  "time": "2026-08-28T09:15:00Z",
  "resources": [],
  "detail": { "orderId": "1001", "total": 250, "currency": "USD", "country": "IN" }
}
```

| Field | Who sets it | Meaning |
|---|---|---|
| `source` | **You** | Which program sent it. Dot-separated, most general part first: `shop.orders`. Names starting with `aws.` are reserved for AWS services. |
| `detail-type` | **You** | What kind of thing happened: `OrderCreated`, `OrderShipped`. |
| `detail` | **You** | The payload: any JSON object with the data consumers need. |
| `id` | EventBridge | A unique ID for this event. |
| `time` | EventBridge (or you) | When it happened. If you don't send a time, EventBridge uses the time it accepted the event. |
| `account`, `region` | EventBridge | Where the event was put. |
| `version` | EventBridge | The envelope format version, always `"0"`. |

```mermaid
flowchart LR
    S["Sender fills<br/>source, detail-type, detail"] -->|put-events| EB["EventBridge adds<br/>id, time, account, region, version"]
    EB --> Bus["Event on the bus"]
```

### Event bus

**Definition:** An event bus is a named channel in one Region that receives events and holds the rules that route them. A bus stores nothing for later. It routes each event the moment it arrives.

- **Default bus:** every account has one bus named `default` in each Region. AWS creates it and you can't delete it. AWS services publish their events here, for example EC2 state changes, S3 events (when enabled), and console sign-ins.
- **Custom bus:** a bus you create for your own applications, for example `orders` or `billing`.

### Rule and event pattern

**Definition:** A rule is attached to one bus. It holds an **event pattern**, a JSON filter. EventBridge checks every arriving event against every rule on that bus. When the pattern matches, the rule sends the event to its targets.

A rule can hold a **schedule** instead of a pattern, for example `rate(5 minutes)`. Scheduled rules work only on the default bus.

### Target

**Definition:** A target is the destination a rule sends matched events to: an SQS queue, a Lambda function, an SNS topic, a Step Functions state machine, another event bus, an HTTP API, and more. One rule can have up to 5 targets, and each target gets its own copy of every matched event.

### Resource policy

**Definition:** A resource policy is an IAM policy attached to the bus itself. It lists which other accounts or principals may publish events onto the bus. This is how a central bus receives events from many AWS accounts.

### How the objects relate

```mermaid
flowchart LR
    P1[Producer A] -->|put-events| Bus
    P2[Producer B] -->|put-events| Bus
    subgraph Bus["Event bus: orders"]
        R1["Rule: all-orders<br/>pattern: source = shop.orders"]
        R2["Rule: big-orders<br/>pattern: total > 1000"]
        R3["Rule: cancelled<br/>pattern: detail-type = OrderCancelled"]
    end
    R1 --> T1[(Audit queue)]
    R1 --> T2[Analytics Lambda]
    R2 --> T3[(Fraud queue)]
    R3 --> T4[Refund workflow]
```

---

## 3. EventBridge vs SQS vs SNS

All three move messages between programs. They differ in **who chooses the receiver**.

| | SQS | SNS | EventBridge |
|---|---|---|---|
| Model | Queue | Topic (publish/subscribe) | Bus with rules |
| Who picks the receiver | Sender picks the queue | Sender picks the topic | **Rules pick, based on the event's content** |
| Number of receivers | One worker processes each message | Every subscriber gets a copy | Every matching rule's targets get a copy |
| Stores messages? | **Yes**, up to 14 days, until a worker deletes them | No | No (except optional archives) |
| Consumer style | Pull: workers poll | Push | Push |
| Filtering | None (worker sees everything) | Subscription filter policies (simpler) | Rich patterns on any field, including AWS service events |
| Typical latency | Milliseconds | Tens of milliseconds | Tens to low hundreds of milliseconds (see section 9) |
| Best for | One team's backlog of work | Broadcasting one known message type, very high fan-out | Many event types, many independent consumers, reacting to AWS events |

```mermaid
flowchart TB
    subgraph SQS["SQS: one queue, one worker per message"]
        direction LR
        s1[Sender] --> q[[Queue]] --> w1[Worker]
    end
    subgraph SNS["SNS: one topic, every subscriber"]
        direction LR
        s2[Sender] --> t((Topic))
        t --> sub1[Subscriber 1]
        t --> sub2[Subscriber 2]
    end
    subgraph EB["EventBridge: rules choose by content"]
        direction LR
        s3[Sender] --> b{{Bus}}
        b -->|matches| r1[Target A]
        b -->|matches| r2[Target B]
        b -.->|no match| x[not sent]
    end
```

### They work together

The most common production pattern is **EventBridge → SQS → worker**. EventBridge decides who gets the event. SQS holds it safely until the worker is ready, absorbs bursts, and retries failed processing.

```mermaid
flowchart LR
    O[Order service] --> B{{orders bus}}
    B -->|"rule: total > 1000"| Q[[fraud-queue SQS]]
    Q --> W["Fraud workers<br/>(ECS / Lambda)"]
    Q -.->|fails 5 times| DLQ[[fraud-dlq]]
```

### EventBridge can fan out like SNS

EventBridge can send one event to many receivers in two ways:

1. **One rule with several targets**, up to 5. Each target gets a copy.
2. **Several rules that match the same event.** Each rule's targets get a copy.

```mermaid
flowchart LR
    subgraph SNS["SNS fan-out"]
        direction LR
        P1[Order service] --> T((orders topic))
        T --> S1[Email Lambda]
        T --> S2[[Fraud SQS]]
        T --> S3[Analytics HTTP endpoint]
    end
    subgraph EB["EventBridge fan-out"]
        direction LR
        P2[Order service] --> B{{orders bus}}
        B --> R1["Rule: all orders"]
        R1 --> E1[Email Lambda]
        R1 --> E3[Analytics API destination]
        B --> R2["Rule: total > 1000"]
        R2 --> E2[[Fraud SQS]]
    end
```

The difference is who decides what each receiver gets:

- **SNS:** each subscriber gets every message on the topic, unless it adds a filter policy.
- **EventBridge:** each rule's pattern decides, based on any field in the event.

### SNS doesn't always need SQS

SNS delivers directly to many endpoint types:

| SNS delivers to | Needs SQS? |
|---|---|
| Lambda | No |
| HTTP/HTTPS endpoint | No |
| Email or SMS | No |
| Mobile push (iOS, Android) | No |
| Firehose (to S3 or a data lake) | No |
| SQS queue | It *is* SQS |

Teams put SQS behind **both** SNS and EventBridge for the same reason: neither one stores messages. They push straight away, retry for a while if the receiver fails, then send to a dead-letter queue or drop the message. SQS gives the consumer a place where messages wait until it's ready:

```mermaid
flowchart LR
    P[Order service] --> X{"SNS topic<br/>or EventBridge bus"}
    X -->|push, retries for a while| L["Lambda<br/>(fine for light, fast work)"]
    X --> Q[["SQS queue<br/>holds messages up to 14 days"]]
    Q -->|worker pulls at its own pace| W["Fraud workers<br/>(can be slow, can restart)"]
```

Use SQS behind either one when the consumer:

- is slow or rate-limited (a database or partner API);
- may be down for a while (deployments, outages);
- needs to process at a controlled rate during bursts;
- needs its own retries and dead-letter queue for processing failures.

This is the **fan-out pattern**: one publish, and each consumer gets its own queue.

### SNS or EventBridge?

| Need | SNS | EventBridge |
|---|---|---|
| Broadcast one known message type to many subscribers | **Best fit** | Works |
| Very high throughput and fan-out (thousands of subscribers) | **Best fit**: millions of subscriptions per topic | Limited: 5 targets per rule, about 300 rules per bus |
| Lowest latency | **Tens of milliseconds** | Tens to low hundreds of milliseconds |
| Email, SMS, or mobile push to people | **Built in** | Only by targeting an SNS topic |
| Strict ordering | **SNS FIFO** topics | No FIFO option |
| Many event types, each consumer wants a different subset by content | Possible with filter policies, but awkward | **Best fit** |
| React to AWS service events | Not directly | **Built in** on the default bus |
| Send to SaaS tools or external APIs with auth and rate limits | Basic HTTP only | **API destinations** |
| Archive and replay past events | No | **Built in** |
| Route events across accounts through a central bus | Possible | **Designed for it** |

- Use **SNS** for simple, fast, high-volume broadcast, and anything that reaches people.
- Use **EventBridge** for content-based routing between services, and for reacting to AWS events.
- Add **SQS** behind either one whenever a consumer needs a buffer.

They're often combined: one EventBridge rule targets an SNS topic to page on-call people, and an SQS queue for a worker.

---

## 4. Buses in practice

### Why more than one bus

If every event in a company went onto one bus, the rule list would grow very long, and a careless pattern could catch other teams' events. Permissions would be coarse too: anyone allowed to publish shipping events could publish billing events.

```mermaid
flowchart LR
    AWS["AWS services<br/>EC2, S3, sign-in"] --> D{{default bus}}
    Ship[Shipping app] --> SB{{shipping bus}}
    Bill[Billing app] --> BB{{billing bus}}
    D --> DR[Rules for AWS events]
    SB --> SR[Shipping rules]
    BB --> BR[Billing rules]
```

A rule on one bus only sees events put on that bus.

**Common practice:**

- one custom bus per business domain: `orders`, `shipping`, `billing`;
- the default bus only for AWS service events and scheduled rules.

### Cross-account: the central bus pattern

Large companies run each team or environment in its own AWS account. A common design is a **central event bus** in a shared account. Each team's account forwards its events there through a rule whose target is the central bus. The central bus's resource policy allows those accounts to publish.

```mermaid
flowchart LR
    subgraph A1["Account: orders team"]
        OB{{orders bus}} -->|rule: forward all| X1[ ]
    end
    subgraph A2["Account: payments team"]
        PB{{payments bus}} -->|rule: forward all| X2[ ]
    end
    subgraph C["Account: central integration"]
        CB{{central bus<br/>resource policy allows<br/>A1 and A2}}
        CB --> Audit[(Audit archive)]
        CB --> Data[Data lake ingest]
        CB --> Sec[Security monitoring]
    end
    X1 --> CB
    X2 --> CB
    style X1 fill:none,stroke:none
    style X2 fill:none,stroke:none
```

A resource policy that lets another account publish:

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "AllowPaymentsAccountToPublish",
    "Effect": "Allow",
    "Principal": { "AWS": "arn:aws:iam::444455556666:root" },
    "Action": "events:PutEvents",
    "Resource": "arn:aws:events:us-east-1:111122223333:event-bus/central"
  }]
}
```

### The `--event-bus-name` trap

Most `aws events` commands default to the **default** bus when you leave out `--event-bus-name`. The classic mistake: you create a rule on `orders` but publish without `EventBusName`. The event lands on `default`, and your rule never sees it.

---

## 5. Publishing events with `put-events`

```bash
aws events put-events --entries '[
  {
    "EventBusName": "escbash-lab-orders",
    "Source": "shop.orders",
    "DetailType": "OrderCreated",
    "Detail": "{\"orderId\": \"1001\", \"total\": 250}"
  }
]'
```

Key points:

- **`--entries` is a JSON array.** One call can carry up to 10 events.
- **Entry field names are capitalized** (`Source`, `DetailType`, `Detail`, `EventBusName`). The delivered event uses lowercase names (`source`, `detail-type`, `detail`).
- **`Detail` is a string containing JSON**, not a JSON object, so every inner quote must be escaped. Put the array in a file and pass it with `file://` to avoid quoting mistakes:

  ```bash
  cat > /root/entries.json <<'EOF'
  [
    {
      "EventBusName": "escbash-lab-orders",
      "Source": "shop.orders",
      "DetailType": "OrderCreated",
      "Detail": "{\"orderId\": \"1001\", \"total\": 250}"
    },
    {
      "EventBusName": "escbash-lab-orders",
      "Source": "shop.orders",
      "DetailType": "OrderCreated",
      "Detail": "{\"orderId\": \"1002\", \"total\": 1500}"
    }
  ]
  EOF
  aws events put-events --entries file:///root/entries.json > /root/put-events.json
  ```

- **Always check `FailedEntryCount`.** If some entries are rejected, the command still exits successfully. Only `FailedEntryCount`, and the `ErrorCode` on each failed entry, show the problem. In code, retry just the failed entries.
- **Accepted doesn't mean delivered.** A bus accepts an event even if no rule matches it. Unmatched events are silently dropped.

### Events are a contract

Other teams write rules against your `source`, `detail-type`, and `detail` field names. Renaming `total` to `amount` silently breaks their rules, and no error is raised anywhere. Production teams:

- **Document every event**, for example in the EventBridge **Schema Registry** or a shared repository.
- **Only add fields; never rename or remove them** in a live event.
- **Version breaking changes** with a new `detail-type` (`OrderCreated.v2`), or a version field inside `detail`, and publish both versions during a migration period.
- **Keep events small but useful.** Include the IDs and the fields most consumers need. That lets consumers avoid calling back into your API for every event, but don't put entire database rows in the event.

---

## 6. Rules and event patterns

### Creating a rule

```bash
aws events put-rule --name escbash-lab-big-orders \
  --event-bus-name escbash-lab-orders \
  --event-pattern '{"source": ["shop.orders"], "detail": {"total": [{"numeric": [">", 1000]}]}}'
```

`put-rule` creates the rule, or updates it if a rule with the same name exists. A new rule starts `ENABLED`. Use `disable-rule` to pause it without deleting it.

### How matching works

| Rule | Example | Meaning |
|---|---|---|
| Values are always arrays | `{"detail-type": ["OrderCreated"]}` | Match this value |
| An array means OR | `{"detail-type": ["OrderCreated", "OrderCancelled"]}` | Either type |
| Several fields mean AND | `{"source": ["shop.orders"], "detail-type": ["OrderCreated"]}` | Both must match |
| Missing fields are ignored | `{"source": ["shop.orders"]}` | Every event from that source |
| Nested fields follow the event's shape | `{"detail": {"country": ["IN"]}}` | `detail.country` is `"IN"` |
| Matching is exact and case-sensitive | `"orderCreated"` ≠ `"OrderCreated"` | — |

### Comparison operators

| Operator | Example | Matches |
|---|---|---|
| `numeric` | `{"numeric": [">", 1000]}` or `{"numeric": [">=", 100, "<", 500]}` | Number comparisons and ranges |
| `prefix` | `{"prefix": "eu-"}` | Strings starting with `eu-` |
| `suffix` | `{"suffix": ".png"}` | Strings ending with `.png` |
| `anything-but` | `{"anything-but": ["test", "internal"]}` | Any value except these |
| `exists` | `{"exists": true}` / `{"exists": false}` | Field present or absent |
| `equals-ignore-case` | `{"equals-ignore-case": "ordercreated"}` | Case-insensitive match |
| `wildcard` | `{"wildcard": "orders/*/paid"}` | Simple `*` wildcards |
| `$or` | `{"$or": [{"detail": {"vip": [true]}}, {"detail": {"total": [{"numeric": [">", 1000]}]}}]}` | OR across different fields |

### Content-based routing

```mermaid
flowchart LR
    E1["OrderCreated<br/>total 420"] --> R1["Rule: source = shop.orders"]
    E2["OrderCreated<br/>total 1500"] --> R1
    E1 --> R2["Rule: total > 1000"]
    E2 --> R2
    R1 -->|both events| Audit[Audit target]
    R2 -->|only total 1500| Fraud[Fraud target]
```

Each rule checks every event independently. One event can match zero, one, or many rules.

### Test a pattern before deploying it

`test-event-pattern` checks a pattern against a sample event without creating anything:

```bash
aws events test-event-pattern \
  --event-pattern '{"detail": {"total": [{"numeric": [">", 1000]}]}}' \
  --event '{"id":"1","source":"shop.orders","detail-type":"OrderCreated","account":"111122223333","region":"us-east-1","time":"2026-08-28T09:15:00Z","resources":[],"detail":{"total":1500}}'
```

It returns `{"Result": true}` or `false`. Teams run this in CI against sample events, so a broken pattern never reaches production.

### Scheduled rules vs EventBridge Scheduler

A rule with `--schedule-expression "rate(5 minutes)"` or `"cron(0 2 * * ? *)"` fires on a timer instead of on events. Cron times are in UTC.

For new work, AWS recommends **EventBridge Scheduler**, a separate feature built for scheduling:

- one-time schedules ("run this at 2026-12-01 09:00");
- time zones, with daylight saving handled for you;
- millions of schedules per account;
- direct targets for hundreds of AWS API actions.

| Use | Choose |
|---|---|
| React when something happens (an order is created, an instance stops) | **Event pattern rule** |
| Run at fixed times (nightly report, cleanup every hour) | **Scheduler** (or a scheduled rule) |
| Run once at a future time per customer (send a reminder 24 hours after sign-up) | **Scheduler** one-time schedules |

Prefer an event pattern over polling on a schedule when the source emits events. "Check every 5 minutes whether any instance stopped" is slower and wastes calls. A rule on the EC2 state-change event reacts within seconds.

---

## 7. Targets and delivery

### Attaching a target

```bash
aws events put-targets \
  --rule escbash-lab-big-orders \
  --event-bus-name escbash-lab-orders \
  --targets '[{"Id": "fraud-queue", "Arn": "arn:aws:sqs:us-east-1:111122223333:fraud-queue"}]'
```

- **`Id`** is a label you choose. It must be unique within the rule, and you use it with `remove-targets`.
- **`Arn`** is the destination's full AWS name.
- A rule can have **up to 5 targets**. Each gets its own copy.
- **Permissions:** the target must allow EventBridge to deliver. SQS, SNS, and Lambda use a resource policy on the target. Other targets, such as Step Functions or another account's bus, use an IAM role that you give the rule.

### Common targets

| Target | What happens | Typical use |
|---|---|---|
| SQS queue | The event becomes a message that waits until a worker takes it | Durable buffering in front of workers. **The most common choice.** |
| Lambda function | Runs code for each event | Light reactions: notify, enrich, tag a resource |
| SNS topic | Publishes to every subscriber | Email or SMS paging, high fan-out |
| Step Functions | Starts a workflow run | Multi-step processes: refunds, onboarding |
| Another event bus | Forwards the event | Cross-account or cross-Region routing |
| API destination | Sends an HTTP request to an external URL | Calling SaaS tools such as Slack, PagerDuty, or a partner webhook |

### Retries and dead-letter queues

EventBridge pushes events to targets. If delivery fails, for example because Lambda is throttled or the queue's policy denies access, EventBridge retries with exponential backoff, **for up to 24 hours and 185 attempts by default**. You can lower both values per target.

```mermaid
flowchart LR
    R[Rule matches] --> T{"Deliver to target"}
    T -->|success| OK[Done]
    T -->|failure| Retry["Retry with backoff<br/>up to 24 h / 185 attempts"]
    Retry --> T
    Retry -->|gives up| DLQ[["Dead-letter queue (SQS)<br/>inspect and redrive"]]
    Retry -.->|no DLQ configured| Lost["Event lost"]
```

**Production rule:** attach a dead-letter queue to every important target, and alarm when it isn't empty. Without one, an event that fails every retry is gone.

The EventBridge DLQ only covers **delivery** failures: EventBridge couldn't hand the event to the target. If the event reaches SQS and your worker then fails to process it, that's the SQS queue's own DLQ, one step later in the path.

### Input transformation

By default, the target receives the whole event, envelope included. An **input transformer** builds a smaller or reshaped payload, so the target doesn't need to understand the EventBridge format:

```json
{
  "Id": "slack-alert",
  "Arn": "arn:aws:events:us-east-1:111122223333:api-destination/slack/abc",
  "InputTransformer": {
    "InputPathsMap": { "id": "$.detail.orderId", "total": "$.detail.total" },
    "InputTemplate": "{\"text\": \"Large order <id> for $<total> needs review\"}"
  }
}
```

### Delivery guarantees

These properties shape how consumers must be written:

| Property | What it means | What you must do |
|---|---|---|
| **At-least-once delivery** | A target can occasionally receive the same event twice | Make consumers **idempotent**: deduplicate on `id` or on a business key such as `orderId` |
| **No ordering guarantee** | `OrderShipped` may arrive before `OrderCreated` | Don't rely on order. Use timestamps or version numbers in `detail`, or use SQS FIFO or Kinesis where strict order matters. |
| **Accepted ≠ delivered** | An event with no matching rule is dropped silently | Watch the `MatchedEvents` and `FailedInvocations` metrics |
| **Asynchronous** | The producer never learns whether consumers succeeded | Use EventBridge for "tell others"; use a direct API call when the caller needs an answer |

---

## 8. Standard production designs

### Design 1: failure-only alerting

The CI pipeline publishes `DeployFinished` for every deploy. A rule matches only failures and pages the on-call engineer.

```json
{ "source": ["ci.pipeline"], "detail-type": ["DeployFinished"], "detail": { "status": ["failed"] } }
```

The pipeline doesn't decide who cares. When another team wants alerts for its services, it adds a rule, for example with `"detail": {"service": ["payments"], "status": ["failed"]}`. The pipeline doesn't change.

### Design 2: audit trail, with archive and replay

A catch-all rule (`{"source": ["shop.orders"]}`) sends every event to an S3 bucket, through Firehose, or to a queue. New `detail-type`s are covered automatically.

EventBridge also has a built-in **archive**. A bus can keep matching events for a set retention period, and you can **replay** them later onto the bus. Teams use replay to:

- recover after a consumer bug ("reprocess yesterday's orders after the fix");
- fill a new service with historical events;
- test a new rule against real past traffic.

### Design 3: automatic remediation

AWS services publish to the default bus with no setup. Some examples:

| Event | Automatic reaction |
|---|---|
| An EC2 instance in a production group stops | Lambda tags it, opens a ticket, and starts a replacement |
| A security group gets a rule open to `0.0.0.0/0` on port 22 | Lambda removes the rule and alerts security |
| An ECS task stops with an error | Post to the team's Slack channel with the `stoppedReason` |
| A GuardDuty finding with high severity appears | Start a Step Functions incident workflow |

Example pattern for a stopped EC2 instance:

```json
{
  "source": ["aws.ec2"],
  "detail-type": ["EC2 Instance State-change Notification"],
  "detail": { "state": ["stopped"] }
}
```

### One event, many consumers

```mermaid
flowchart LR
    CI[CI pipeline] --> Bus{{ops bus}}
    AWS[AWS services] --> Def{{default bus}}
    Bus -->|status = failed| Page["SNS: page on-call"]
    Bus -->|catch-all| Arch[("Audit archive")]
    Bus -->|status = failed| Roll["Lambda: start rollback"]
    Def -->|instance stopped| Rem["Lambda: remediate"]
```

One failed-deploy event pages a person, lands in the archive, and starts a rollback, because every matching rule gets its own copy. The sender made one `put-events` call and knows nothing about any of this.

### Related EventBridge features

| Feature | What it does | Use when |
|---|---|---|
| **EventBridge Pipes** | A point-to-point link from a source (SQS, Kinesis, DynamoDB Streams) to a target, with optional filtering and enrichment | Connecting one source to one target without writing glue Lambda code |
| **Schema Registry** | Stores event structures and can generate code types | Documenting event contracts across teams |
| **API destinations** | Calls external HTTP endpoints, with rate limiting and auth | Sending events to SaaS tools and partner webhooks |
| **Global endpoints** | Fail over event publishing to a second Region | Multi-Region resilience for critical event flows |

---

## 9. Scaling, limits, and cost

### Limits to know

Check current values in Service Quotas, because they vary by Region and change over time.

| Limit | Typical default | Notes |
|---|---|---|
| Event size | 256 KB per event (the lab uses 8 KB) | Put large payloads in S3 and send a pointer, the "claim check" pattern |
| Entries per `put-events` call | 10 | Batch to reduce API calls |
| `PutEvents` throughput | A soft per-Region limit in the thousands per second (10,000/s in `us-east-1`) | Throttled calls return errors that you must retry. Request increases before big launches. |
| Target invocations | A soft per-Region limit | Matters when one event fans out to many targets |
| Rules per bus | 300 (soft) | Another reason to split buses by domain |
| Targets per rule | 5 | Need more? Target an SNS topic or another bus. |

### When consumers can't keep up: do you need a queue?

EventBridge pushes events as fast as they arrive and stores nothing. If events arrive faster than the consumer can process them, put an SQS queue in between.

**Example:** 50,000 order events arrive in 1 minute. The fraud Lambda calls a database that handles about 100 requests per second.

**Without a queue**, EventBridge uses Lambda's asynchronous invoke, which has a small hidden internal queue:

```mermaid
flowchart LR
    Burst["50,000 events<br/>in 1 minute"] --> B{{EventBridge}}
    B -->|async invoke| LQ["Lambda's internal async queue<br/>(hidden, max 6 h)"]
    LQ --> L["Lambda scales up fast<br/>hits concurrency limit"]
    L -->|too many connections| DB[("Database<br/>overloaded")]
    L -.->|throttled| LQ
    LQ -.->|older than max age| Gone["Dropped<br/>(or DLQ if configured)"]
```

1. Lambda scales up to many concurrent copies, and the database is overwhelmed.
2. Invocations over the concurrency limit are throttled and wait in Lambda's async queue, retried for up to **6 hours** by default.
3. The backlog is hard to see, and the only rate control is a reserved-concurrency cap.
4. Function errors retry only **2 times** by default. Events past the maximum age are dropped unless an on-failure destination or DLQ is configured.

For other target types (HTTP APIs, Step Functions), EventBridge retries throttled deliveries for up to **24 hours**, then uses the DLQ or drops the event.

**With a queue**, the consumer sets its own pace:

```mermaid
flowchart LR
    Burst["50,000 events<br/>in 1 minute"] --> B{{EventBridge}}
    B -->|"fast: every event<br/>stored safely"| Q[["SQS fraud-queue<br/>holds up to 14 days"]]
    Q -->|"pulled at a steady rate<br/>max concurrency 10<br/>batches of 10"| L[Fraud Lambda / ECS workers]
    L -->|"~100 requests/s, safe"| DB[(Database)]
    Q -.->|failed 5 times| DLQ[["fraud-dlq<br/>inspect and redrive"]]
```

1. EventBridge's job finishes instantly. All events go into the queue at whatever rate they arrive.
2. The consumer pulls at a safe rate. Lambda on SQS can set **maximum concurrency**, and ECS workers scale on queue depth.
3. The backlog is visible through `ApproximateNumberOfMessagesVisible` and `ApproximateAgeOfOldestMessage`.
4. Messages wait up to **14 days**. Failures retry until `maxReceiveCount`, then move to the DLQ for redrive.
5. Batching (up to 10 messages per Lambda invocation) lowers cost.
6. You can pause consumers during an incident, and events wait safely.

At 100 per second, the burst drains in about 8–9 minutes with nothing lost.

| | EventBridge → Lambda directly | EventBridge → SQS → consumer |
|---|---|---|
| Burst handling | Lambda scales up fast, often too fast for the database | The queue absorbs it |
| Rate control | Only a reserved-concurrency cap | Max concurrency, batch size, number of workers |
| Backlog visibility | Limited (async event age metric) | Clear: queue depth and age of oldest message |
| How long events wait | Up to 6 hours (Lambda async) or 24 hours (EventBridge retries) | Up to 14 days |
| Failed processing | 2 retries by default, then dropped or DLQ | Retries until `maxReceiveCount`, then DLQ |
| Pause consumers safely | Hard | Easy |

**A direct target is fine** when volume is low or steady, the work is light and fast, the downstream system can handle the Lambda's maximum concurrency, and duplicates are harmless. Alerts, remediation Lambdas, and notifications are typical examples.

**Add a queue** when the consumer is slow or rate-limited, calls a database or partner API, must process every event, or might be down during deployments. That covers most business workloads: orders, payments, fraud, and data processing. The rule is the same as with SNS: neither service stores events, so SQS is the buffer.

### Can you set a delivery pace on the bus?

No. A bus has no setting that controls how fast it delivers. It routes each event the moment it arrives. Pace is controlled in other places:

```mermaid
flowchart LR
    P[Producer] --> B{{"Event bus<br/>no pace setting"}}
    B --> R[Rule]
    R --> API["API destination<br/>✔ invocation rate limit per second"]
    R --> Q[["SQS queue"]]
    Q --> C["Consumer<br/>✔ max concurrency<br/>✔ batch size<br/>✔ batching window"]
    R --> L["Lambda directly<br/>✔ reserved concurrency cap only"]
    R -.-> RP["Every target<br/>retry policy: max age, max attempts<br/>(controls retries, not pace)"]
```

| Target | How to control pace |
|---|---|
| External HTTP endpoint | **API destination** `--invocation-rate-limit-per-second`. Events above the rate wait and are retried. |
| Lambda, ECS workers, databases | **SQS queue** plus consumer settings: Lambda event source mapping `MaximumConcurrency`, `BatchSize`, and `MaximumBatchingWindowInSeconds`, or the ECS worker count |
| Lambda directly | **Reserved concurrency**: a blunt cap, with throttled events waiting in Lambda's hidden async queue for up to 6 hours |

- **Per-target retry policy** (`MaximumEventAgeInSeconds`, `MaximumRetryAttempts`) controls how long EventBridge keeps retrying after failures, not the normal delivery rate.
- **`disable-rule` doesn't pause safely.** Events that arrive while the rule is disabled don't match and are dropped, not held. To pause safely, keep the rule enabled, let events collect in SQS, and stop the consumers.

The bus routes, and the queue controls the pace.

### Scaling patterns

**1. Put SQS between EventBridge and slow or rate-limited consumers**, as described above.

**2. Batch your `put-events` calls.** Send up to 10 entries per call and retry only the failed entries, with backoff.

**3. Don't publish directly inside a database transaction.** If the database write succeeds but `put-events` fails, or the reverse, consumers see a different state from the database. Two standard fixes:

- **Transactional outbox:** write the event to an `outbox` table in the same database transaction, and let a separate process publish it.
- **Change data capture:** use DynamoDB Streams, with EventBridge Pipes, to publish when the data changes.

**4. Make every consumer idempotent.** At-least-once delivery, retries, and replays all produce duplicates. Store processed event IDs, or use conditional writes keyed on `orderId`.

**5. Keep patterns specific.** An overly broad rule that sends everything to Lambda multiplies cost and load.

### Latency: is EventBridge slow?

EventBridge is a bit slower than SNS or SQS, because it checks each event against every rule and then delivers to each target separately. Delivery usually takes tens to low hundreds of milliseconds. AWS cut EventBridge latency substantially in late 2024; check the documentation for current figures.

For most uses this doesn't matter, because EventBridge work happens **after** the user already has their answer:

```mermaid
sequenceDiagram
    participant U as Customer
    participant O as Order service
    participant B as EventBridge
    participant E as Email service
    U->>O: Place order
    O->>O: Save to database
    O->>B: put-events OrderCreated
    O-->>U: "Order confirmed" (user is done here)
    Note over B,E: EventBridge delay happens here,<br/>after the user has their answer
    B->>E: OrderCreated
    E->>E: Send confirmation email
```

The EventBridge hop is rarely the slowest step:

| Step | Typical time |
|---|---|
| EventBridge routing | Tens to low hundreds of ms |
| Lambda cold start | 100 ms to several seconds |
| SQS worker poll wait (long polling) | Up to 20 s if the queue was empty |
| The consumer's own work | Often the largest |
| Retries after a failure | Seconds to minutes |

**When latency does matter:**

| Need | Use instead |
|---|---|
| The user waits for another service's answer | A direct API call (HTTP or gRPC) |
| Fast broadcast to many subscribers | SNS |
| Ordered, high-rate streams (location, telemetry, market data) | Kinesis or MSK |
| Long multi-step flows | Step Functions, instead of chaining many bus hops |

### Cost

- **AWS service events on the default bus:** free to receive.
- **Custom events you publish:** about **$1 per million** events. Each 64 KB chunk of a payload counts as one event.
- **Cross-account delivery** counts as a custom event in the receiving account.
- **Rules and pattern matching:** no extra charge.
- **Archive, replay, API destinations, and Pipes** have their own small charges.

Example: a shop publishing 5 million order events a month pays about $5 for EventBridge. The targets (SQS, Lambda) are billed separately and usually cost more.

### Cost compared with SQS, SNS, and Kinesis

Approximate `us-east-1` standard prices; check the AWS pricing pages before relying on them.

| Service | Main charge | Free tier | Notes |
|---|---|---|---|
| **SQS** | ~$0.40 per million requests (FIFO ~$0.50) | 1M requests/month | Send, receive, and delete each count. Batching 10 per call cuts the count. |
| **SNS** | ~$0.50 per million publishes | 1M publishes/month | Delivery to SQS and Lambda is free. HTTP ~$0.60/M. Email and SMS cost much more. |
| **EventBridge** | ~$1.00 per million custom events | AWS service events on the default bus are free | No extra charge per rule or target |
| **Kinesis Data Streams** | Per shard-hour, or per GB (on-demand) | — | Cheapest per event at very high, steady volume |

For SQS, SNS, and EventBridge, every 64 KB of payload counts as one billable unit.

**Worked example: 10 million order events a month, 3 consumers.**

```mermaid
flowchart LR
    subgraph A["Option A: SNS fan-out ≈ $19/month"]
        direction LR
        P1[Orders] --> T((SNS topic<br/>~$4.50))
        T --> Q1[[SQS ~$4.80]]
        T --> Q2[[SQS ~$4.80]]
        T --> Q3[[SQS ~$4.80]]
    end
    subgraph B["Option B: EventBridge ≈ $24/month"]
        direction LR
        P2[Orders] --> E{{Bus<br/>~$10}}
        E --> R1[[SQS ~$4.80]]
        E --> R2[[SQS ~$4.80]]
        E --> R3[[SQS ~$4.80]]
    end
```

- **SNS option:**
  - SNS: 10M publishes, minus the 1M free ≈ $4.50.
  - Each queue: 10M sends, 1M batched receives, and 1M batched deletes ≈ 12M requests ≈ $4.80.
  - **Total ≈ $19.**
- **EventBridge option:**
  - EventBridge: 10M events ≈ $10.
  - The same SQS cost ≈ $14.40.
  - **Total ≈ $24.**

The difference is about $5 a month, while the consumers processing 30 million messages usually cost several times more than all the messaging together.

**How the gap grows** (routing or publishing cost only, before free tiers):

| Events per month | SQS (1 queue) | SNS | EventBridge |
|---|---|---|---|
| 1 million | ~$0.50 | ~$0.50 (often free) | ~$1 |
| 100 million | ~$50 | ~$50 | ~$100 |
| 1 billion | ~$500 | ~$500 | ~$1,000 |

At billions of events a month, high-volume streams (clickstream, telemetry, logs) usually go to Kinesis or MSK, and only important business events go through EventBridge.

**Hidden costs that often outweigh the messaging bill:**

| Cost | How to reduce it |
|---|---|
| One Lambda invocation per event (EventBridge or SNS calling Lambda directly) | Put SQS in between and process batches |
| Empty SQS receives | Long polling (`WaitTimeSeconds = 20`) |
| Large payloads | Keep events small; put big data in S3 and send a pointer |
| NAT gateway data charges | VPC endpoints for SQS, SNS, and EventBridge |
| Cross-Region or cross-account traffic | Route deliberately |
| SMS and email from SNS | Use them for alerts only |
| Overly broad rules | Specific patterns, so consumers get only what they need |

**Which is cheapest for the job:**

| Situation | Cheapest good choice |
|---|---|
| One producer, one consumer, a work queue | **SQS alone** |
| One message type broadcast to several consumers | **SNS + SQS** |
| Reacting to AWS service events | **EventBridge** (the events are free) |
| Many event types, content-based routing, many teams | **EventBridge**: the extra $1/M is usually worth the simpler design |
| Billions of events per month, streaming data | **Kinesis or MSK** |
| Under a few million events per month | **Any of them.** Costs are close to $0, so choose on features. |

---

## 10. Debugging: "my rule doesn't fire"

```mermaid
flowchart TD
    A([Rule did not fire]) --> B{"put-events<br/>FailedEntryCount = 0?"}
    B -->|no| B1["Read ErrorCode per entry<br/>malformed Detail, size, throttling"]
    B -->|yes| C{"Event on the same bus<br/>as the rule?"}
    C -->|no| C1["Add EventBusName<br/>(it went to default)"]
    C -->|yes| D{"test-event-pattern<br/>returns true?"}
    D -->|no| D1["Fix pattern: case, arrays,<br/>number vs string, nesting"]
    D -->|yes| E{"Rule ENABLED?"}
    E -->|no| E1[enable-rule]
    E -->|yes| F{"FailedInvocations<br/>metric > 0?"}
    F -->|yes| F1["Target permissions:<br/>SQS / Lambda resource policy<br/>or rule's IAM role"]
    F -->|no| G["Event reached target:<br/>check consumer logs"]
```

| Symptom | Usual cause | Fix |
|---|---|---|
| Rule never matches | Event published to `default`, but the rule is on the custom bus | Set `EventBusName` in the entries |
| Pattern looks right but doesn't match | Value not in an array: `"source": "shop.orders"` | Use `"source": ["shop.orders"]` |
| Numeric rule never matches | The producer sent `"total": "1500"`, a string | Send numbers as numbers; the event contract must say so |
| `detail-type` doesn't match | Case or spelling differs: `orderCreated` | Patterns are case-sensitive; check sample events |
| `put-events` returns `FailedEntryCount: 1` | `Detail` isn't a valid JSON string, or it's too large | Use a file with `file://` and validate the JSON |
| `MatchedEvents` rises but the target receives nothing | Target permission missing | Add the queue or Lambda resource policy, or the rule's IAM role |
| Consumer processes the same order twice | At-least-once delivery, retries, or replay | Deduplicate on event `id` or `orderId` |

**Metrics to alarm on:**

- **`FailedInvocations` above 0**, because a target is broken;
- **messages in the dead-letter queue**;
- **`ThrottledRules`**;
- **`MatchedEvents` dropping to 0** for a rule that should always fire, which usually means the producer changed its event shape.

---

## 11. The lab

The shell is in `us-east-1`. Resource names use the `escbash-lab-` prefix. The lab allows 2 custom buses, 5 rules, and 50 published events. Targets are described but not created.

```mermaid
flowchart LR
    A["create-event-bus<br/>escbash-lab-orders"] --> B["describe-event-bus<br/>→ /root/bus.json"]
    B --> C["list-event-buses (EventBuses only)<br/>→ /root/buses.json"]
    C --> D["put-events<br/>→ check FailedEntryCount"]
    D --> E["put-rule with patterns"]
    E --> F["list-rules / describe-rule"]
```

### Confirm the connection

```bash
aws sts get-caller-identity
```

### Task: create the orders bus

```bash
aws events create-event-bus --name escbash-lab-orders

aws events describe-event-bus --name escbash-lab-orders > /root/bus.json

aws events list-event-buses --query 'EventBuses' --output json > /root/buses.json
```

Check the results:

```bash
jq '{Name, Arn}' /root/bus.json
jq -r '.[].Name' /root/buses.json     # should print: default and escbash-lab-orders
```

`--query 'EventBuses'` keeps only the array, which is what the checker expects. Don't add `--name-prefix`, because the list must include `default`.

### Publish order events

```bash
cat > /root/entries.json <<'EOF'
[
  { "EventBusName": "escbash-lab-orders", "Source": "shop.orders", "DetailType": "OrderCreated",
    "Detail": "{\"orderId\": \"1001\", \"total\": 250}" },
  { "EventBusName": "escbash-lab-orders", "Source": "shop.orders", "DetailType": "OrderCreated",
    "Detail": "{\"orderId\": \"1002\", \"total\": 1500}" }
]
EOF
aws events put-events --entries file:///root/entries.json > /root/put-events.json
jq '.FailedEntryCount' /root/put-events.json   # must be 0
```

### Rules

```bash
aws events put-rule --name escbash-lab-all-orders \
  --event-bus-name escbash-lab-orders \
  --event-pattern '{"source": ["shop.orders"]}'

aws events put-rule --name escbash-lab-big-orders \
  --event-bus-name escbash-lab-orders \
  --event-pattern '{"source": ["shop.orders"], "detail": {"total": [{"numeric": [">", 1000]}]}}'

aws events list-rules --event-bus-name escbash-lab-orders > /root/rules.json
aws events describe-rule --name escbash-lab-big-orders --event-bus-name escbash-lab-orders
```

---

## 12. Interview-style questions

1. **When would you choose EventBridge over SNS?**
   When there are many event types and consumers want different subsets based on content, when you need to react to AWS service events, or when you need cross-account routing, archive and replay, or SaaS integration. SNS is simpler and faster for broadcasting one known message type to many subscribers.

2. **Why put SQS between EventBridge and a Lambda consumer?**
   For durability and flow control. The queue absorbs bursts, lets workers process at a steady rate, retries processing failures, and has its own dead-letter queue. EventBridge's retries only cover delivery.

3. **EventBridge delivers at least once. What does that mean for your consumer?**
   It may receive duplicates, so processing must be idempotent: deduplicate by event ID or by a business key with conditional writes.

4. **How do you change an event's structure without breaking other teams?**
   Treat events as a contract. Only add fields. For breaking changes, publish a new version (a new `detail-type` or a version field) alongside the old one, migrate consumers, then retire the old version.

5. **The order service writes to the database and then calls `put-events`. What can go wrong?**
   One can succeed while the other fails, leaving consumers out of sync with the database. Use a transactional outbox or change data capture, such as DynamoDB Streams through Pipes.

6. **A rule shows `MatchedEvents` but the SQS queue is empty. Why?**
   EventBridge lacks permission to send to the queue. The queue's resource policy must allow `events.amazonaws.com` to call `sqs:SendMessage`, scoped to the rule's ARN.

7. **How would you collect security events from 200 AWS accounts?**
   Use a central bus in a security account, with a resource policy allowing the organization's accounts to publish. Each account has a rule on its default bus that forwards relevant `aws.*` events to the central bus. The central bus routes them to the SIEM, an archive, and automated remediation.

---

## 13. Command cheat sheet

| Command | Purpose |
|---|---|
| `aws events create-event-bus --name X` | Create a custom bus |
| `aws events describe-event-bus --name X` | Read one bus (Name, Arn, Policy) |
| `aws events list-event-buses` | List all buses, including `default` |
| `aws events put-permission` / `remove-permission` | Manage the bus's resource policy |
| `aws events put-events --entries file://...` | Publish up to 10 events |
| `aws events put-rule --event-pattern ...` | Create or update a pattern rule |
| `aws events put-rule --schedule-expression "rate(5 minutes)"` | Create a scheduled rule (default bus) |
| `aws events test-event-pattern` | Check a pattern against a sample event |
| `aws events list-rules --event-bus-name X` | List rules on a bus |
| `aws events describe-rule --name R --event-bus-name X` | Read one rule |
| `aws events enable-rule` / `disable-rule` | Resume or pause a rule |
| `aws events put-targets` / `remove-targets` / `list-targets-by-rule` | Manage a rule's targets |
| `aws events create-archive` / `start-replay` | Archive events and replay them |
| `aws events delete-rule` / `delete-event-bus` | Clean up (remove targets first, then rules, then the bus) |
