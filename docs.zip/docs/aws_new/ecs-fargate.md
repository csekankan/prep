# AWS ECS and Fargate: From Basics to Production Scale

This guide covers what ECS is, the four core objects (cluster, task definition, task, service), what Fargate changes, how to choose between EC2, ECS, and EKS, and the scaling, reliability, cost, and debugging knowledge that production teams rely on.

The running example throughout is **`orders-api`**: the backend for an e-commerce checkout, packaged as a container image. It listens on port 8080, reads a database password from AWS Secrets Manager, and must stay up during traffic spikes such as a holiday sale.

---

## 1. The problem ECS solves

A **container image** is a packaged, read-only bundle of an application and everything it needs (code, runtime, libraries). An image does nothing on its own. To serve traffic, someone has to:

1. Pick a machine with enough free CPU and memory.
2. Pull the image and start a container from it.
3. Connect it to the network and the load balancer.
4. Restart it when it crashes.
5. Replace old containers with new ones when a new version ships, without downtime.
6. Add more containers when traffic grows and remove them when it drops.

Doing this by hand on EC2 instances is slow and error-prone. A **container orchestrator** is software that does all six steps automatically. **ECS (Elastic Container Service)** is the orchestrator built into AWS.

```mermaid
flowchart LR
    Dev[Developer pushes code] --> CI[CI pipeline builds image]
    CI --> ECR[(Amazon ECR<br/>image registry)]
    ECR --> ECS{{ECS orchestrator}}
    ECS -->|places + starts| T1[Task]
    ECS -->|places + starts| T2[Task]
    ECS -->|places + starts| T3[Task]
    ECS -.->|restarts on crash<br/>scales up/down<br/>rolls out new versions| T1
    ALB[Load balancer] --> T1 & T2 & T3
    Users((Users)) --> ALB
```

---

## 2. Core definitions

### Cluster

**Definition:** A cluster is a logical grouping of tasks and services in one AWS Region. It's an administrative boundary. It holds no compute of its own unless you attach EC2 instances or capacity providers to it.

**Industry practice:** Teams usually create one cluster per environment, such as `prod`, `staging`, and `dev`. Large companies sometimes create one cluster per business domain, such as `payments-prod`. The cluster itself costs nothing.

### Task definition

**Definition:** A task definition is a versioned JSON specification that describes how to run one or more containers together. It includes:

- the container images
- the CPU and memory for the whole task and for each container
- port mappings
- environment variables and secrets
- the logging configuration
- the IAM roles
- the network mode
- health checks

**Family and revision:** Every task definition belongs to a **family**, which is its name (for example `orders-api`). Each time you register a change, ECS creates a new, **immutable revision**: `orders-api:1`, `orders-api:2`, and so on. You can't edit an old revision, only register a new one. This makes rollback simple: point the service back at the previous revision.

**Industry practice:** The CI/CD pipeline registers a new revision on every release, with the image tag set to the git commit SHA (for example `orders-api:a1b2c3d`). Don't use `:latest` in production. If you do, two tasks started from the same revision could run different code.

### Task

**Definition:** A task is one running instance of a task definition revision. If the definition lists three containers, one task runs all three together, on the same host, sharing the same network interface.

A task runs until:

- its essential container exits,
- someone stops it, or
- it fails a health check while it belongs to a service.

**Industry practice:** One-off or scheduled work runs as a standalone task, started with `run-task` or by an EventBridge schedule. Examples: a database migration, a nightly report, or a batch import.

### Service

**Definition:** A service is a long-running controller that keeps a **desired count** of tasks running from a given task definition revision. It also:

- replaces tasks that stop or fail health checks,
- registers tasks with a load balancer target group,
- performs rolling or blue/green deployments when the revision changes,
- integrates with auto scaling to change the desired count.

**Industry practice:** Every always-on workload runs as a service: web apps, APIs, and queue consumers. `orders-api` runs as a service with a desired count of 6, spread across 3 Availability Zones.

### How the four objects relate

```mermaid
flowchart TB
    subgraph Cluster["Cluster: prod"]
        direction TB
        subgraph Service["Service: orders-api (desired count = 3)"]
            T1["Task 1<br/>orders-api:7"]
            T2["Task 2<br/>orders-api:7"]
            T3["Task 3<br/>orders-api:7"]
        end
        Job["Standalone task<br/>db-migration:2<br/>(runs once, then exits)"]
    end

    subgraph Family["Task definition family: orders-api"]
        R5["revision 5"]
        R6["revision 6"]
        R7["revision 7 (current)"]
    end

    R7 -->|service runs this revision| Service
    Service -.->|task dies → start replacement| T3
```

Key points from the diagram:

- A **service** always points at exactly one revision. Deploying means pointing it at a new one.
- Old revisions stay available, so a rollback just points the service back at `revision 6`.
- Standalone tasks live in the same cluster but no service watches them. When they exit, they stay stopped.

### Task vs service vs standalone task

A **task** is the running thing: it has an IP address, uses CPU and memory, and costs money. A **service** is not a running thing. It's a standing instruction to ECS, such as "always keep 3 tasks of `orders-api:7` running behind this load balancer." The service itself uses no compute. It only watches its tasks and fixes any gap.

A **standalone task** is a task started directly with `run-task`, with no service around it. It runs, finishes, and nothing restarts it. Use it for work that should run once: database migrations, nightly reports, one-time data fixes, and EventBridge-scheduled jobs.

```mermaid
flowchart LR
    subgraph A["Standalone task: run-task"]
        direction TB
        J1["Task running"] -->|crashes or finishes| J2["STOPPED<br/>(stays stopped)"]
    end
    subgraph B["Service: create-service --desired-count 3"]
        direction TB
        S{{"Service controller<br/>desired = 3"}}
        S -->|watches| X1["Task A"]
        S -->|watches| X2["Task B"]
        S -->|watches| X3["Task C ✖ crashed"]
        X3 -.->|service sees 2 of 3| S
        S -->|starts replacement| X4["Task D (new)"]
    end
```

| | Standalone task | Task inside a service |
|---|---|---|
| Started by | You: `run-task` or an EventBridge schedule | The service |
| If it crashes | Stays stopped | Replaced automatically |
| Count | Whatever you asked for, once | Kept at the desired count |
| Load balancer | Not connected | Registered and deregistered automatically |
| New version | You run a new task | Rolling or blue/green deployment |
| Typical use | Migrations, batch jobs, cron-style jobs | Web apps, APIs, queue workers |

### Task lifecycle

Every task moves through the same states. `describe-tasks` shows `lastStatus` (the current state) and `desiredStatus` (where ECS is trying to take it).

```mermaid
stateDiagram-v2
    [*] --> PROVISIONING: run-task / service starts it
    PROVISIONING --> PENDING: ENI attached, capacity found
    PENDING --> ACTIVATING: image pulled, containers created
    ACTIVATING --> RUNNING: containers started, registered with ALB
    RUNNING --> DEACTIVATING: stop requested / essential container exited
    DEACTIVATING --> STOPPING: deregistered from ALB
    STOPPING --> DEPROVISIONING: SIGTERM, then SIGKILL after stopTimeout
    DEPROVISIONING --> STOPPED: ENI detached
    STOPPED --> [*]
```

If a task never reaches `RUNNING`, the failure happened in the early states. Image pulls and secrets fetches happen during `PENDING`, which is why `CannotPullContainerError` and secrets errors show up there.

### Container definition fields worth knowing

| Field | Meaning |
|---|---|
| `essential` | If `true` and this container stops, ECS stops the whole task. The main app container is always essential. Helpers such as a log router may be non-essential. |
| `portMappings` | The ports the container listens on. In `awsvpc` mode, the host port always equals the container port. |
| `healthCheck` | A command run inside the container. Three failures in a row mark the container unhealthy. |
| `secrets` | Values pulled from Secrets Manager or SSM Parameter Store at start time and injected as environment variables. |
| `logConfiguration` | Where stdout and stderr go. Usually the `awslogs` driver, which sends them to CloudWatch Logs. |
| `stopTimeout` | How long ECS waits after sending SIGTERM before it sends SIGKILL. The Fargate maximum is 120 seconds. |
| `dependsOn` | Start order between containers, for example "start the app only after the proxy is healthy." |

---

## 3. Launch types and capacity

A task must run on a machine. The **launch type**, or more flexibly the **capacity provider**, decides which machine.

### Fargate

**Definition:** Fargate is serverless compute for containers. AWS provides an isolated micro-VM sized to the CPU and memory in your task definition. You never see or patch the host. Billing is per second, based on the vCPU and memory you request, with a 1-minute minimum.

- Sizes range from 0.25 vCPU / 0.5 GB up to 16 vCPU / 120 GB.
- CPU and memory must form a valid pair. For example, `cpu 256` allows `memory 512`, `1024`, or `2048`.
- Ephemeral storage is 20 GB by default and can be configured up to 200 GB.
- Fargate requires the `awsvpc` network mode.
- Fargate supports x86_64 and ARM64 (Graviton). ARM64 is roughly 20% cheaper for the same size.

#### What happens when you run a task on Fargate

```mermaid
sequenceDiagram
    participant You as You (run-task)
    participant ECS as ECS scheduler
    participant FG as Fargate capacity pool
    participant VM as Micro-VM (one per task)
    participant ECR as Image registry
    participant ALB as Load balancer

    You->>ECS: run-task: orders-api:7, cpu 256, memory 512, subnet
    ECS->>FG: need 0.25 vCPU / 0.5 GB, ARM64
    FG->>VM: allocate a dedicated micro-VM
    VM->>VM: attach ENI with a private IP in your subnet
    Note over VM: billing starts here
    VM->>ECR: pull image (no cache, full pull every time)
    VM->>VM: start containers
    VM-->>ECS: RUNNING
    ECS->>ALB: register task IP (if part of a service)
    Note over VM: on stop: SIGTERM, SIGKILL, VM destroyed, billing stops
```

#### Isolation: one task, one micro-VM

Every Fargate task gets its own micro-VM with its own kernel. Tasks never share a kernel, CPU, or memory with other tasks, including tasks from other AWS customers. This is stronger isolation than containers sharing one EC2 host. It's one reason security-sensitive teams like Fargate.

```mermaid
flowchart TB
    subgraph EC2Host["EC2 launch type: one instance, shared kernel"]
        direction LR
        K["Shared Linux kernel"]
        E1[Task A] --- K
        E2[Task B] --- K
        E3[Task C] --- K
        W["Unused CPU/memory<br/>(you still pay)"]
    end
    subgraph FargatePool["Fargate: each task isolated"]
        direction LR
        subgraph V1["micro-VM"]
            F1[Task A]
        end
        subgraph V2["micro-VM"]
            F2[Task B]
        end
        subgraph V3["micro-VM"]
            F3[Task C]
        end
    end
```

#### Right-sizing and billing

With the EC2 launch type, you pay for whole instances, even when tasks fill only part of them. With Fargate, you pay for exactly the CPU and memory each task requests, per second, from the start of the image pull until the task stops. The minimum charge is 1 minute.

Fargate bills for what you **request**, not what you use. A task that requests 2 vCPU but averages 10% CPU still pays for 2 vCPU. Right-sizing the request is your job.

Example: the lab task (0.25 vCPU, 0.5 GB, ARM64) costs roughly 1 cent per hour in `us-east-1`. Prices vary by Region.

#### Fargate vs Lambda

| | Lambda | Fargate |
|---|---|---|
| Unit | A function invocation | A container task |
| Max run time | 15 minutes | Unlimited |
| Packaging | Zip or container image | Container image |
| Scales | Per request, automatically | By changing the task count, through a service and auto scaling |
| Billing | Per invocation + duration (ms) | Per second while running |
| Idle cost | None, scales to zero | Pays while the task runs, even with no traffic |
| Best for | Event-driven, short, spiky work | Long-running services, steady traffic, long jobs |

#### What you still own on Fargate

```mermaid
flowchart LR
    subgraph You["You own"]
        Y1[Container image<br/>and its OS packages]
        Y2[App code]
        Y3[CPU / memory sizing]
        Y4[VPC, subnets,<br/>security groups]
        Y5[IAM roles]
        Y6[Scaling policies]
    end
    subgraph AWS["AWS owns"]
        A1[Host servers]
        A2[Host OS + kernel patching]
        A3[Container runtime]
        A4[Capacity planning]
        A5[Task isolation]
    end
```

Patching the host is AWS's job, but patching your **image** is still yours. If your base image has a vulnerable OpenSSL, Fargate won't fix it. Rebuild the image and redeploy.

#### Fargate limitations

- **No host access.** You can't SSH to the host, run privileged containers, or run daemons on every host. Use sidecars instead.
- **No GPUs.** GPU workloads need the EC2 launch type.
- **Size ceiling** of 16 vCPU / 120 GB per task.
- **No image cache.** Every task pulls the full image, so large images start slowly. Keep images small or use SOCI lazy loading.
- **Higher price per vCPU-hour** than a fully packed EC2 instance. At large, steady scale, EC2 can be cheaper.

### EC2 launch type

**Definition:** Your tasks run on EC2 instances that you register to the cluster. Each instance runs the ECS agent. You choose the instance types, patch the AMIs, and manage scaling of the instances.

**When teams choose it:**

- They need GPUs or specific instance families.
- They have very high, steady utilization, where bin-packing many tasks per instance is cheaper.
- They need access to the host, or daemon-style workloads (one task per instance).
- They need large local disks.

### Fargate Spot

**Definition:** Fargate Spot runs tasks on spare AWS capacity at up to about 70% off. AWS can reclaim the capacity with a **2-minute warning**, delivered as SIGTERM to your containers.

**Use it for:** stateless, interruption-tolerant work, such as queue workers, batch jobs, or some of the tasks behind a load balancer.

**Limitation:** Fargate Spot supports only x86_64. ARM64 tasks can't use it.

### Capacity providers

**Definition:** A capacity provider strategy tells a service how to split tasks across capacity types using a `base` and a `weight`.

**Industry pattern for `orders-api`:**

```json
"capacityProviderStrategy": [
  { "capacityProvider": "FARGATE",      "base": 2, "weight": 1 },
  { "capacityProvider": "FARGATE_SPOT",            "weight": 3 }
]
```

The first 2 tasks always run on regular Fargate, so there's a guaranteed floor. After that, tasks split 1:3 between regular Fargate and Spot, which saves money while keeping a stable core.

```mermaid
flowchart LR
    S["Service desired count = 10"] --> B["base = 2<br/>always FARGATE"]
    S --> R["remaining 8<br/>split by weight 1 : 3"]
    R --> F["2 tasks on FARGATE"]
    R --> SP["6 tasks on FARGATE_SPOT<br/>(~70% cheaper, can be reclaimed)"]
    B --> Total["Total: 4 on-demand + 6 Spot"]
    F --> Total
    SP --> Total
```

### Who manages what

```mermaid
flowchart TB
    subgraph EC2LT["EC2 launch type"]
        direction TB
        A1[Your app container] --> A2[ECS agent + Docker]
        A2 --> A3[EC2 instance OS + patching]
        A3 --> A4[Instance scaling + capacity]
    end
    subgraph FG["Fargate"]
        direction TB
        B1[Your app container] --> B2[AWS-managed micro-VM]
    end
    classDef you fill:#ffe0b2,stroke:#e65100
    classDef aws fill:#c8e6c9,stroke:#1b5e20
    class A1,A2,A3,A4,B1 you
    class B2 aws
```

Orange is your responsibility and green is AWS's. With Fargate, you only own the container.

---

## 4. Fargate vs EC2 in practice: billing, scaling, and spikes

This section uses a second example app, **QuickBite**, a food-ordering app with three parts:

1. **`api`**: the backend the mobile app calls (menus, orders, payments). It must always be up.
2. **`image-worker`**: resizes restaurant photos that are uploaded to an SQS queue.
3. **`daily-report`**: a standalone task that emails restaurants their daily sales at 02:00.

```mermaid
flowchart LR
    App((Mobile app)) --> ALB[Load balancer]
    ALB --> API["api service<br/>Fargate tasks"]
    API --> DB[(Database)]
    API -->|photo uploaded| Q[[SQS queue]]
    Q --> W["image-worker service<br/>Fargate tasks"]
    W --> S3[(S3 bucket)]
    Cron["EventBridge schedule<br/>02:00 daily"] --> R["daily-report<br/>standalone task"]
    R --> DB
```

### 4.1 What you decide on Fargate vs EC2

On both platforms, you still size each task and set the task counts. What Fargate removes is choosing and running the **servers** that hold the tasks.

| Decision | Fargate | ECS on EC2 |
|---|---|---|
| How big is each task? (`cpu 512`, `memory 1024`) | **You decide** | **You decide** |
| Min, max, and desired task count | **You decide** | **You decide** |
| When to scale (CPU target, schedule) | **You decide** | **You decide** |
| Which instance type? (`m7g.large`? `c7g.xlarge`?) | Not asked | **You decide** |
| How many instances, min and max? | Not asked | **You decide** |
| How much spare room to keep on the instances? | Not asked | **You decide** |
| Patching and replacing instances | Not asked | **You do it** |

QuickBite's decisions on Fargate:

| Part | cpu | memory | Min | Max | Scale on |
|---|---|---|---|---|---|
| `api` | 512 (0.5 vCPU) | 1024 (1 GB) | 2 (one per AZ) | 20 | Requests per task = 100 |
| `image-worker` | 1024 (1 vCPU) | 2048 (2 GB) | 0 | 10 | Messages waiting in the queue |
| `daily-report` | 256 (0.25 vCPU) | 512 (0.5 GB) | — | — | Runs once a day, standalone |

### 4.2 What you pay for

Both platforms run on VMs. The difference is what's on the bill:

- **EC2:** you pay for the **whole instance**, however full or empty it is. Rent a 4 vCPU / 16 GB instance, use 1 vCPU, and you still pay for 4.
- **Fargate:** you pay for exactly what each task **requests** in its task definition, only while it runs. The VM is created to match the task and destroyed when it stops. There's never an empty or half-full VM on the bill.

```mermaid
flowchart TB
    subgraph EC2["EC2: you pay for 2 whole instances"]
        direction LR
        subgraph I1["Instance 1: 4 vCPU / 16 GB"]
            a1[Task] ~~~ a2[Task] ~~~ w1["empty<br/>(paid)"]
        end
        subgraph I2["Instance 2: 4 vCPU / 16 GB"]
            a3[Task] ~~~ w2["empty<br/>(paid)"] ~~~ w3["empty<br/>(paid)"]
        end
    end
    subgraph FG["Fargate: you pay for 3 task-sized VMs"]
        direction LR
        f1[Task] ~~~ f2[Task] ~~~ f3[Task]
    end
    classDef waste fill:#ffcdd2,stroke:#b71c1c
    class w1,w2,w3 waste
```

**The Fargate formula:**

> **Bill = (vCPU + GB requested in the task definition) × number of running tasks × seconds they run**

For each task, the meter starts when the image pull begins and stops when the task stops. Time is billed per second, with a 1-minute minimum.

"Requested" means the `cpu` and `memory` values in the task definition, not HTTP requests:

| Thing | Do you pay for it? |
|---|---|
| **Task definition** (the recipe) | **No.** Registering one, or 100 revisions, is free. |
| **HTTP requests from users** | **No, not on Fargate.** A task serving 10 requests costs the same as one serving 10,000. Lambda is the service that bills per request. |
| **Running tasks** | **Yes**, per second, based on the task definition's `cpu` and `memory`. |
| **CPU your app doesn't use** | **Yes.** A task requesting 0.5 vCPU but using 10% of it still pays for 0.5 vCPU. Right-sizing is your job. |

**Worked example.** Approximate `us-east-1` ARM prices are about **$0.032 per vCPU-hour** and **$0.0036 per GB-hour**. Check the pricing page for your Region.

One `api` task (0.5 vCPU, 1 GB):

- CPU: 0.5 × $0.032 = $0.016 per hour
- Memory: 1 × $0.0036 = $0.0036 per hour
- **Total: about $0.02 per hour**

With an average of about 7 tasks through the day: 7 × 24 × $0.02 ≈ **$3.40 per day**, or about $100 per month.

**Other charges in the same app** (not Fargate, but on the same AWS bill):

- the load balancer
- the NAT gateway, if you use one
- CloudWatch Logs
- data transfer out to the internet
- ephemeral storage above the free 20 GB per task

### 4.3 How scaling works: one layer vs two

Fargate doesn't scale anything by itself. **ECS Service Auto Scaling** changes the service's desired task count based on traffic or a schedule. Fargate supplies a VM for each task ECS asks for.

```mermaid
flowchart LR
    T((Traffic rises)) --> CW["CloudWatch metric<br/>CPU or requests per task"]
    CW --> AS["ECS Service Auto Scaling<br/>desired count 2 → 4"]
    AS --> SVC[ECS service]
    SVC -->|asks for 2 more tasks| FG["Fargate creates<br/>2 new VMs"]
```

- **On Fargate, you scale one thing: tasks.** Every new task gets its own VM, so capacity always matches the task count.
- **On the EC2 launch type, you scale two things:** tasks, using the same ECS Service Auto Scaling, and instances, using an EC2 Auto Scaling group, because new tasks need free room on some instance.

```mermaid
flowchart TB
    subgraph F["Fargate: one layer"]
        direction LR
        F1["Desired count 4 → 6"] --> F2["2 new VMs created"] --> F3["Tasks running<br/>(~30–90 s)"]
    end
    subgraph E["EC2 launch type: two layers"]
        direction LR
        E1["Desired count 4 → 6"] --> E2{"Free room on<br/>existing instances?"}
        E2 -->|yes| E3["Tasks placed<br/>(seconds, image cached)"]
        E2 -->|no| E4["Tasks wait in PROVISIONING"]
        E4 --> E5["Capacity provider tells the<br/>Auto Scaling group to add an instance"]
        E5 --> E6["Instance boots, ECS agent joins<br/>(~2–5 min)"]
        E6 --> E3
    end
```

**Example: traffic doubles at 09:00.** Both setups start with 4 tasks of 1 vCPU each.

**Fargate:**

1. 09:00. CPU rises above the target, so auto scaling raises the desired count from 4 to 8.
2. Fargate creates 4 new VMs straight away.
3. Around 09:01 or 09:02, the new tasks pass health checks and start taking traffic.

**EC2 launch type** (2 instances of 4 vCPU each, 8 vCPU total, with 4 already in use):

1. 09:00. The desired count rises from 4 to 8.
2. The 4 new tasks fit into the existing free room. They start in seconds, because the image is already cached.
3. Both instances are now full. Traffic keeps rising, and the desired count goes to 10.
4. The 2 extra tasks wait. The capacity provider asks the Auto Scaling group for one more instance.
5. Around 09:03–09:05, the instance has booted and joined the cluster, and the waiting tasks start.

**Scaling down:**

- **Fargate:** tasks stop and billing for them stops immediately.
- **EC2:** an instance keeps costing money until every task on it is gone. If tasks are scattered across many instances, few instances ever become fully empty, so the savings come slowly.

| | Fargate | ECS on EC2 | Plain EC2 Auto Scaling (no ECS) |
|---|---|---|---|
| What scales | Tasks | Tasks, and instances under them | Whole instances, each running a full copy of the app |
| Who adds capacity | Fargate, per task | Capacity provider plus Auto Scaling group | Auto Scaling group |
| Time to add capacity | ~30–90 s | Seconds if room exists, ~2–5 min if not | ~2–5 min |
| Spare capacity you pay for | None | Usually 10–20% | Whatever the instance size leaves over |
| Billing when scaling down | Stops immediately | Only when an instance empties | When the instance terminates |

### 4.4 What "spare room" means on EC2

**Spare room** is unused CPU and memory on EC2 instances that are **already running** in the cluster. ECS can place new tasks straight onto that free space, without launching a new instance.

Example: 2 instances of 4 vCPU each, with every `api` task using 1 vCPU and 3 tasks on each instance:

```mermaid
flowchart LR
    subgraph I1["Instance 1: 4 vCPU"]
        direction TB
        a1["Task 1 vCPU"] ~~~ a2["Task 1 vCPU"] ~~~ a3["Task 1 vCPU"] ~~~ f1["FREE 1 vCPU"]
    end
    subgraph I2["Instance 2: 4 vCPU"]
        direction TB
        b1["Task 1 vCPU"] ~~~ b2["Task 1 vCPU"] ~~~ b3["Task 1 vCPU"] ~~~ f2["FREE 1 vCPU"]
    end
    classDef free fill:#c8e6c9,stroke:#1b5e20
    class f1,f2 free
```

```mermaid
flowchart TD
    N["Need 2 more tasks"] --> Q{"Free CPU/memory on<br/>running instances?"}
    Q -->|"yes = spare room"| Fast["Place tasks now<br/>start in seconds"]
    Q -->|"no = cluster full"| Slow["Launch new instance<br/>wait ~2–5 min<br/>then place tasks"]
```

Spare room isn't free. The empty space is part of instances you pay for every hour.

- **More spare room:** faster scaling, but a higher bill.
- **Less spare room:** a lower bill, but slower scaling when the cluster fills up.

EC2 teams usually keep about 10–20% of the cluster empty on purpose. They control this with the capacity provider's **target capacity**: `targetCapacity = 80` means "keep the instances about 80% full."

Fargate has no spare room, because there are no shared instances. You never pay for empty space, but every task takes the full 30–90 seconds to start.

### 4.5 Does the cost follow traffic?

Yes, indirectly. Fargate never counts requests or messages. But auto scaling turns traffic into a task count, and the task count is what you pay for:

```mermaid
flowchart LR
    R["More API requests<br/>or queue messages"] --> M["CloudWatch metric rises<br/>(requests per task, queue depth)"]
    M --> AS["Auto scaling raises<br/>desired task count"]
    AS --> T["More running tasks"]
    T --> B["Bigger Fargate bill"]
    style B fill:#ffe0b2,stroke:#e65100
```

**The bill rises in steps, not smoothly.** With the `api` policy targeting 100 requests per second per task:

| Traffic (requests/sec) | Tasks auto scaling runs | Fargate cost per hour |
|---|---|---|
| 0 | 2 (the minimum) | $0.04 |
| 150 | 2 | $0.04 |
| 210 | 3 | $0.06 |
| 800 | 8 | $0.16 |
| 1,600 | 16 | $0.32 |

Without auto scaling, traffic doesn't affect the bill at all. A service fixed at 4 tasks costs the same whether it serves 10 or 10,000 requests. Past its capacity, it just gets slow or returns errors.

**Fargate vs Lambda billing:**

| | Fargate | Lambda |
|---|---|---|
| What's billed | Running tasks × size × seconds | Each request × its duration × memory |
| Cost with zero traffic | The minimum task count (for example 2 tasks) | **$0** |
| Cost follows traffic | **Indirectly**, in steps, through auto scaling | **Directly**, per request |
| At high, steady traffic | Usually **cheaper**: one task serves many requests at once | Usually **more expensive**: you pay for every request |

### 4.6 Does the minimum task count always run?

Yes. While the service exists and its minimum is above 0, at least that many tasks run around the clock, and you pay for them every second, even with zero traffic. Auto scaling never goes below the minimum.

```mermaid
flowchart LR
    subgraph Range["api auto scaling range"]
        direction LR
        Min["min = 2<br/>always running,<br/>always billed"] --- Mid["auto scaling moves<br/>the count in between<br/>based on traffic"] --- Max["max = 20<br/>never more than this"]
    end
```

The minimum is a setting you control:

**1. Set it to 0 ("scale to zero").** The idle cost drops to $0.

- **Good for queue workers** such as `image-worker`. Messages wait safely in the queue until a task starts.
- **Risky for APIs.** With 0 tasks, the load balancer has nowhere to send the first request, so that user gets an HTTP 503 error. It's typically a minute or more before a task is running.

**2. Change it on a schedule:**

| Environment | Day | Night |
|---|---|---|
| Production `api` | min = 6 (ready for lunch rush) | min = 2 (still always up) |
| Staging and dev | min = 1 | min = 0 (nobody is using it) |

Setting dev and staging to 0 overnight and at weekends often cuts their cost by 60–70%.

**3. Stop everything on purpose.** Setting the desired count to 0, or deleting the service, stops all its tasks.

**Moments when fewer than the minimum run:**

- **A task crashes.** For about a minute you have one fewer task, until the service starts a replacement.
- **AWS retires a task for maintenance.** The service starts a replacement.
- **A deployment is running.** With `minimumHealthyPercent=100`, new tasks start before old ones stop, so you never drop below the minimum.

Production APIs use a minimum of at least 2, spread across Availability Zones. If one task or one zone fails, the other task keeps serving users while the replacement starts.

### 4.7 Billing for a short burst

At 10:00, a restaurant uploads 500 photos. `image-worker` scales from 0 to 10 tasks (1 vCPU / 2 GB each), clears the queue, and returns to 0.

```mermaid
gantt
    title image-worker: 500 photos arrive at 10:00
    dateFormat HH:mm
    axisFormat %H:%M
    section Queue
    500 messages waiting          :q1, 10:00, 10:07
    section Scaling
    Alarm notices backlog         :a1, 10:00, 10:01
    Queue empty, waiting to scale in :a2, 10:07, 10:12
    section 10 tasks (billed)
    Start (image pull + boot)     :crit, t1, 10:01, 10:02
    Processing photos             :t2, 10:02, 10:07
    Idle until scaled in          :t3, 10:07, 10:12
```

1. **10:00:** 500 messages land in the queue, and no workers are running, so the cost is $0.
2. **About 10:01:** a CloudWatch alarm on queue depth fires, and auto scaling sets the desired count to 10. The meter starts for each task.
3. **About 10:02–10:07:** the 10 workers process about 50 photos each.
4. **10:07:** the queue is empty, but auto scaling waits a few minutes before scaling in, so a brief lull doesn't remove workers too early.
5. **About 10:12:** the tasks stop and the meter stops.

Each task is billed for about **10–11 minutes**: startup, work, and the scale-in wait. Target-tracking policies scale in even more slowly (around 15 minutes), which is why queue workers usually use step scaling.

**Cost:**

- **Per task per hour:** 1 × $0.032 + 2 × $0.0036 ≈ $0.039
- **Per task for 11 minutes:** ≈ $0.007
- **All 10 tasks:** ≈ **$0.07** for the whole burst

To clear the same burst as quickly on EC2, 10 vCPU of capacity must either run all day (on the order of $8–10 per day, mostly idle) or take several minutes to boot.

### 4.8 Sudden, huge traffic spikes

Reactive auto scaling alone can't handle a sudden, huge spike on **any** container platform, not just Fargate:

```mermaid
gantt
    title Traffic jumps 10× at 0s: reactive scaling only
    dateFormat ss
    axisFormat %Ss
    section Traffic
    10× traffic hitting existing tasks :crit, t0, 00, 59s
    section Scaling
    Metric collected + alarm fires     :a1, 00, 60s
    New tasks start (image pull, boot) :a2, after a1, 60s
    Health checks pass                 :a3, after a2, 30s
```

| Platform | Time until new capacity serves traffic |
|---|---|
| Fargate | ~2–3 min (metric delay plus task start) |
| ECS on EC2, with spare room | ~1–1.5 min (same metric delay, faster task start) |
| ECS on EC2, without spare room | ~4–6 min (an instance must boot first) |
| Lambda | Seconds, but limited by concurrency ramp-up and cold starts |

Teams handle big spikes by being ready **before** the traffic arrives:

1. **Pre-scale for spikes you can predict.** Push notifications, TV ads, flash sales, and launches are scheduled. Raise the minimum with scheduled scaling beforehand. ECS **predictive scaling** can also learn daily and weekly patterns and add tasks before the usual peaks.
2. **Keep headroom.** Target 50–60% CPU instead of 90%, so running tasks can absorb about a 2× jump while new ones start.
3. **Keep spikes away from your tasks.**
   - A **CDN (CloudFront)** caches menus, images, and public pages at the edge.
   - A **queue (SQS)** takes non-urgent work. The API returns immediately and workers catch up.
4. **Protect the system during the gap.** Use rate limiting or load shedding: return HTTP 429 for low-priority requests such as browsing, so checkout keeps working.
5. **Make reactive scaling faster.** Use step scaling with big jumps, high-resolution (10-second) metrics, small images or SOCI, fast app startup, and tuned health checks.
6. **Check limits before the event.** Confirm the Fargate vCPU quota, subnet IP addresses, and database connections can handle the peak task count. Run a load test.

**Example: QuickBite sends a "50% off" push at 19:00.**

```mermaid
flowchart LR
    P["18:45<br/>scheduled scaling:<br/>api min 4 → 40"] --> R["19:00 push sent<br/>traffic 10× in 30 s"]
    R --> C["CloudFront serves<br/>menus and images"]
    R --> A["40 warm api tasks<br/>at ~50% CPU"]
    A --> Q[["Order emails go to SQS"]]
    A -.->|still rising| S["Step scaling<br/>adds more tasks"]
    R -.->|overflow| L["Rate limiter returns 429<br/>for browsing, keeps checkout up"]
```

The spike lands on capacity that was already running. Auto scaling only handles the extra traffic beyond the forecast.

**When Fargate really is a poor fit for spikes:**

- **Huge, unpredictable spikes** (for example 100× in seconds) for a service that can't be cached or queued. Lambda, or EC2 with a large warm buffer, fits better.
- **Scaling to hundreds of tasks within seconds.** Fargate limits how fast tasks launch, so 10 to 500 tasks takes several minutes. Pre-scaling is required.

### 4.9 Long-running and memory-heavy tasks

Fargate handles long-running tasks well. They're its main use, with no time limit like Lambda's 15 minutes. The micro-VM doesn't slow the app or limit memory in practice: it's sized to the request, and its overhead isn't counted against the task.

The real constraints are:

1. **There's a size ceiling** of 16 vCPU and 120 GB per task. Anything larger in a single process must run on EC2.
2. **Memory is a hard limit, fixed when the task starts.** Exceeding it kills the task with exit code 137. There's no swap and no borrowing from the host. A slow memory leak eventually kills the task, so set the limit with headroom and alert at about 85% use.
3. **AWS retires Fargate tasks for maintenance**, normally with around 14 days' notice. Service tasks are replaced automatically. A standalone task running for weeks is simply stopped, so long jobs must be able to restart or save their progress.
4. **Cost at steady, large sizes.** For one big task, Fargate costs roughly the same as a comparable EC2 instance (for example 8 vCPU / 60 GB vs an `r7g.2xlarge`). The gap grows at scale, because EC2 lets you pack many tasks per instance and use deeper reserved discounts.

| Workload | Good fit |
|---|---|
| Long-running API or worker, up to a few GB of memory each | **Fargate** |
| A long job that can restart from a saved point | **Fargate** (or Fargate Spot on x86) |
| A single process needing more than 120 GB, or a GPU or local NVMe disk | **EC2 launch type** |
| Many large, memory-heavy services running all day at steady load | **EC2 launch type** with reserved pricing |
| A stateful process that can't tolerate a restart | Neither as-is. Redesign it to save state, or run it on EC2 where you control maintenance |

### 4.10 The real benefits of Fargate

Scaling speed isn't Fargate's main advantage. EC2 is faster while it has spare room. Fargate's benefits are:

**1. No servers to operate.** This is the biggest one:

| Ongoing EC2 work | On Fargate |
|---|---|
| Patching the instance OS and rolling out new AMIs every few weeks | AWS does it |
| Updating the ECS agent and Docker on every instance | AWS does it |
| Choosing instance types and sizes, and revisiting them as services change | Not needed |
| Moving tasks off an instance before replacing it | Not needed |
| Tuning the Auto Scaling group, capacity provider, and spare-capacity buffer | Not needed |
| Debugging a broken instance (full disk, agent disconnected, kernel issue) | Not possible, and not your problem |

**2. You pay only for what tasks request.** There's no idle capacity on the bill, and billing drops the moment tasks scale down.

**3. Stronger isolation and a smaller attack surface.** Each task has its own micro-VM and kernel. There are no hosts to SSH into, so an attacker can't break into a host and then reach every container on it.

**4. Simpler scaling.** One layer instead of two. A classic EC2 failure, where tasks are stuck because the instance group hit its maximum size, can't happen.

**5. Simpler capacity planning.** You never work out how many tasks fit on an instance type.

**What Fargate costs you in return:** no GPUs, privileged containers, or host access; a 16 vCPU / 120 GB ceiling; slower scale-out than EC2 with spare room; and usually a higher bill than a large, well-packed EC2 fleet with Spot and Savings Plans.

### 4.11 When each one wins

**Case 1: Fargate wins (a small team with variable traffic).** A startup runs 8 microservices. Each runs 2 tasks of 0.5 vCPU / 1 GB during the day and 1 task at night.

On EC2, you provision for the worst moment:

- **Peak daytime load:** 16 tasks, which is 8 vCPU.
- **Deployments:** a rolling update briefly doubles the task count.
- **Resilience:** instances spread across 2 Availability Zones.

That's something like 4 instances of 4 vCPU each, running 24/7 and mostly half-empty, plus patching and instance scaling. On Fargate, you pay for 8 vCPU during the day, 4 vCPU at night, and the extra deployment tasks only for the few minutes a deployment lasts. EC2 means paying for roughly 2× the capacity used, plus the operations work.

**Case 2: EC2 wins (a large, steady, specialized fleet).** A video company runs 300 transcoding workers at 2 vCPU / 4 GB each, 24/7, at stable load. Some need GPUs.

- **Packing:** 8 workers per 16 vCPU instance, kept about 90% full.
- **Discounts:** EC2 Spot gives up to about 90% off and works on ARM. Fargate Spot is up to about 70% off and x86-only. EC2 Instance Savings Plans discount more deeply than Fargate's best option.
- **GPUs** are available. Fargate has none.
- **Faster scale-out:** instances keep images cached.

| Question | If yes, lean toward |
|---|---|
| Would your EC2 instances often sit half-empty (variable traffic, small services)? | **Fargate** |
| Is your team small, with no one dedicated to patching and scaling instances? | **Fargate** |
| Do you need GPUs, privileged containers, or host-level agents? | **EC2** |
| Is the fleet large and steady enough to keep instances about 80–90% full? | **EC2** |
| Do you want Spot discounts on ARM, or the deepest long-term discounts? | **EC2** |
| Must new tasks start within seconds during sudden spikes? | **EC2** (cached images) |

Mixed setups are common: steady baseline load on EC2, with Fargate for spiky, small, or new services, all in the same cluster through capacity providers. The common advice is to start on Fargate and move a workload to EC2 only for a specific reason, since images and task definitions stay almost the same.

The Spot and Savings Plan percentages are AWS's "up to" figures, and prices vary by Region. Check the AWS pricing pages before using these numbers in a real decision.

### 4.12 A day in production for QuickBite on Fargate

```mermaid
gantt
    title QuickBite api: number of tasks through the day
    dateFormat HH:mm
    axisFormat %H:%M
    section api tasks
    2 tasks (night)            :00:00, 07:00
    4 tasks (morning)          :07:00, 11:30
    12 tasks (lunch rush)      :11:30, 14:00
    5 tasks (afternoon)        :14:00, 18:30
    16 tasks (dinner rush)     :18:30, 21:30
    3 tasks (late)             :21:30, 23:59
```

| Time | What happens | What you do on Fargate |
|---|---|---|
| 02:00 | EventBridge starts `daily-report`. It runs for 3 minutes and exits. | Nothing. You pay for 3 minutes of 0.25 vCPU. |
| 07:00 | Traffic rises. Auto scaling moves `api` from 2 to 4 tasks. | Nothing |
| 10:00 | 500 photos arrive. `image-worker` goes from 0 to 10 tasks and back to 0 (see 4.7). | Nothing. About $0.07. |
| 11:30 | Lunch rush. `api` goes to 12 tasks. | Nothing |
| 15:00 | You deploy a bug fix. ECS starts new tasks, checks they're healthy, then stops the old ones. | Run one command or merge the PR |
| 16:10 | One `api` task crashes. The service starts a replacement in about a minute. | Nothing. You get an alert and can read the logs later. |
| 18:30 | Dinner rush. `api` goes to 16 tasks. | Nothing |
| 23:00 | Traffic drops back to 2–3 tasks. The bill drops at the same moment. | Nothing |

**The same day on ECS with EC2 instances** adds these questions on top:

- **Which instance type?** An `m7g.large` (2 vCPU / 8 GB) fits 4 `api` tasks but only 2 `image-worker` tasks. Do the services share instances or get separate groups?
- **How many instances?** Peak is 16 `api` tasks plus 10 workers (18 vCPU), plus deployment room: maybe 12 instances at peak.
- **10:00 photo burst:** if instances are full, the workers wait 2–5 minutes for new instances, so you probably keep spare instances all day.
- **23:00:** tasks drop to 3 but are spread across 5 instances, so none of them can be removed yet.
- **Every few weeks:** a new patched AMI must be rolled out by replacing each instance.

On Fargate, you only answer "how big is one copy, and how many copies should run under this load?" On EC2, you also answer "which machines should I rent, how do I keep them patched, and how do I avoid paying for empty space?"

---

## 5. Networking with `awsvpc`

**Definition:** In `awsvpc` network mode, each task gets its own **elastic network interface (ENI)**, with its own private IP address in your subnet and its own security groups. To the network, the task looks just like an EC2 instance.

Consequences that matter at scale:

- **Security groups apply per task.** You can allow the database to accept traffic only from the `orders-api` security group.
- **Load balancer target type must be `ip`, not `instance`.** The ALB routes straight to the task's IP address.
- **IP exhaustion is real.** Every task uses one IP address. A `/24` subnet has 251 usable addresses. During a deployment, old and new tasks run side by side (see section 7), so you need headroom. Production VPCs use `/19` or larger private subnets for container workloads.
- **Pulling images needs a route out.** The task has to reach ECR, or `public.ecr.aws` for public images. You have three options:
  - a public subnet with `assignPublicIp=ENABLED` (fine for labs, not for production);
  - a private subnet with a **NAT gateway**;
  - a private subnet with **VPC endpoints** for ECR (`ecr.api`, `ecr.dkr`), an S3 gateway endpoint, and CloudWatch Logs.

  The most common production setup is a private subnet with VPC endpoints. It avoids NAT data charges and keeps traffic off the internet.

### Standard production network layout

```mermaid
flowchart TB
    Internet((Internet)) --> ALB

    subgraph VPC["VPC 10.0.0.0/16"]
        subgraph Public["Public subnets (one per AZ)"]
            ALB["Application Load Balancer<br/>SG: allow 443 from 0.0.0.0/0"]
            NAT["NAT gateway<br/>(optional)"]
        end

        subgraph Private["Private subnets /19 (one per AZ)"]
            T1["Task ENI 10.0.32.14<br/>SG: allow 8080 from ALB SG"]
            T2["Task ENI 10.0.64.9<br/>SG: allow 8080 from ALB SG"]
        end

        subgraph Data["Database subnets"]
            DB[("RDS<br/>SG: allow 5432 from task SG")]
        end

        EP["VPC endpoints<br/>ecr.api · ecr.dkr · s3 · logs · secretsmanager"]
    end

    ALB -->|target type = ip| T1 & T2
    T1 & T2 --> DB
    T1 & T2 -->|image pull, logs, secrets| EP
    T1 & T2 -.->|other outbound traffic| NAT --> Internet
```

Notice that the security groups chain together: the internet can reach only the ALB, the ALB can reach only the tasks, and only the tasks can reach the database. Each layer accepts traffic only from the security group in front of it.

---

## 6. IAM: two roles that are often confused

| Role | Who uses it | What it's for |
|---|---|---|
| **Task execution role** | The ECS agent / Fargate platform | Pulling the image from private ECR, writing logs to CloudWatch, and reading secrets referenced in `secrets` at start time. |
| **Task role** | Your application code inside the container | Calling AWS APIs at runtime, for example writing to DynamoDB or reading from S3. |

```mermaid
sequenceDiagram
    participant ECS as ECS / Fargate platform
    participant Exec as Execution role
    participant ECR as ECR
    participant SM as Secrets Manager
    participant App as Your app (container)
    participant Task as Task role
    participant DDB as DynamoDB

    Note over ECS,SM: Startup: before your code runs
    ECS->>Exec: assume role
    ECS->>ECR: pull image
    ECS->>SM: fetch DB_PASSWORD
    ECS->>App: start container with secret as env var

    Note over App,DDB: Runtime: your code calling AWS
    App->>Task: SDK gets credentials automatically
    App->>DDB: PutItem on orders table
```

**Rule of least privilege:** Each service gets its own task role, scoped to exactly the resources it uses. `orders-api` can write to the `orders` DynamoDB table and nothing else. Never put long-lived access keys in environment variables. The SDK picks up the task role's credentials automatically.

---

## 7. Deployments

When a service's task definition revision changes, ECS replaces the old tasks with new ones.

### Rolling update (the default)

The update is controlled by two settings:

- **`minimumHealthyPercent`**: how low the count of running, healthy tasks can drop during the deployment.
- **`maximumPercent`**: how high the total count, old plus new, can go.

For `orders-api` with a desired count of 6, set `minimumHealthyPercent=100` and `maximumPercent=200`. ECS starts up to 6 new tasks, waits for them to pass ALB health checks, then drains and stops the old ones. Capacity never drops. The cost is that you briefly run 12 tasks, and need 12 IP addresses.

```mermaid
flowchart LR
    subgraph S1["1. Before"]
        direction TB
        a1[v1] ~~~ a2[v1] ~~~ a3[v1]
        a4[v1] ~~~ a5[v1] ~~~ a6[v1]
    end
    subgraph S2["2. New tasks start (12 running)"]
        direction TB
        b1[v1] ~~~ b2[v1] ~~~ b3[v1]
        b4[v1] ~~~ b5[v1] ~~~ b6[v1]
        c1[v2] ~~~ c2[v2] ~~~ c3[v2]
        c4[v2] ~~~ c5[v2] ~~~ c6[v2]
    end
    subgraph S3["3. v2 healthy → v1 drained"]
        direction TB
        d1[v2] ~~~ d2[v2] ~~~ d3[v2]
        d4[v2] ~~~ d5[v2] ~~~ d6[v2]
    end
    S1 --> S2 --> S3
    classDef old fill:#bbdefb,stroke:#0d47a1
    classDef new fill:#c8e6c9,stroke:#1b5e20
    class a1,a2,a3,a4,a5,a6,b1,b2,b3,b4,b5,b6 old
    class c1,c2,c3,c4,c5,c6,d1,d2,d3,d4,d5,d6 new
```

### Deployment circuit breaker

**Definition:** When enabled with rollback, ECS detects a deployment whose tasks keep failing to start or to pass health checks. It marks the deployment as failed and automatically rolls back to the last working revision. Every production service should have it turned on:

```bash
--deployment-configuration "deploymentCircuitBreaker={enable=true,rollback=true},minimumHealthyPercent=100,maximumPercent=200"
```

### Blue/green deployment

**Definition:** The new version (green) starts as a complete set of tasks behind a separate target group. Traffic then moves from blue to green, either all at once, in a canary step (for example 10% first), or linearly. You can roll back instantly by shifting traffic back to blue. ECS supports this natively and through CodeDeploy.

```mermaid
flowchart LR
    Users((Users)) --> L[ALB listener]
    L -->|"90% → 0%"| Blue["Blue target group<br/>v1 tasks"]
    L -->|"10% → 100%"| Green["Green target group<br/>v2 tasks"]
    Green -.-> Alarm{"CloudWatch alarms:<br/>5xx rate, p99 latency"}
    Alarm -->|breach| RB["Shift 100% back to blue"]
    Alarm -->|healthy after bake time| Done["Shift 100% to green,<br/>terminate blue"]
```

**Industry practice:** Payment and checkout paths often use a canary rollout with CloudWatch alarms tied to error rate and p99 latency. If an alarm fires during the bake time, the rollback is automatic.

### Graceful shutdown

When ECS stops a task, the sequence is:

1. ECS deregisters the task from the target group. The ALB stops sending new requests and waits up to the **deregistration delay** (default 300 seconds; often lowered to 30–60 seconds for fast APIs) for in-flight requests to finish.
2. ECS sends **SIGTERM** to each container.
3. After `stopTimeout`, ECS sends **SIGKILL**.

```mermaid
sequenceDiagram
    participant ECS
    participant ALB
    participant App as App container
    ECS->>ALB: deregister task
    Note over ALB: stop sending NEW requests<br/>wait for in-flight ones<br/>(deregistration delay, e.g. 30s)
    ECS->>App: SIGTERM
    Note over App: finish in-flight work<br/>close DB connections<br/>exit(0)
    alt app exits in time
        App-->>ECS: exited cleanly
    else stopTimeout passes (max 120s)
        ECS->>App: SIGKILL (in-flight work lost)
    end
```

Your application must handle SIGTERM: stop accepting work, finish in-flight requests, close database connections, then exit. Applications that ignore SIGTERM drop requests on every deployment.

---

## 8. Scaling

### Service Auto Scaling

ECS services scale their desired count through **Application Auto Scaling**. There are three policy types:

| Policy | How it works | Typical use |
|---|---|---|
| **Target tracking** | Keeps a metric near a target, for example average CPU at 60%. AWS creates and manages the alarms. | The default for most services. |
| **Step scaling** | Adds or removes a fixed number of tasks based on how far an alarm threshold is breached. | When you need aggressive, tiered reactions. |
| **Scheduled scaling** | Changes the min and max capacity at set times. | Known events: a sale starting at 09:00, business-hours traffic. |

**Choosing the metric:**

- **CPU utilization** works for CPU-bound services.
- **`ALBRequestCountPerTarget`** is often better for web APIs, because it scales on load directly, before CPU saturates.
- **Queue depth per task** is the standard metric for workers: the SQS `ApproximateNumberOfMessagesVisible` divided by the running task count, published as a custom metric.

**Example for `orders-api`:** min 6, max 60, target tracking on `ALBRequestCountPerTarget = 500`, plus a scheduled action that raises the minimum to 30 one hour before a planned sale.

### The scaling feedback loop

```mermaid
flowchart LR
    Traffic((Traffic)) --> ALB
    ALB --> Tasks[ECS tasks]
    ALB -->|RequestCountPerTarget| CW[CloudWatch metric]
    Tasks -->|CPU, memory| CW
    CW --> Alarm{"Above / below<br/>target?"}
    Alarm -->|above| Out["Raise desired count<br/>(fast cooldown)"]
    Alarm -->|below| In["Lower desired count<br/>(slow cooldown)"]
    Out --> Svc[ECS service]
    In --> Svc
    Svc -->|start / stop tasks| Tasks
    Sched["Scheduled action<br/>min = 30 at 08:00"] --> Svc
```

### Why scaling isn't instant

New Fargate tasks typically take 30–90 seconds or more to serve traffic. The time is spent on:

1. Provisioning capacity and attaching the ENI.
2. **Pulling the image.** This is usually the biggest factor. A 1.5 GB image is much slower than a 150 MB one.
3. Application startup, such as a JVM warming up or connection pools filling.
4. Passing ALB health checks. With the defaults (healthy threshold × interval), this alone can take a minute.

```mermaid
gantt
    title Time for one new task to serve traffic (typical)
    dateFormat ss
    axisFormat %Ss
    section Platform
    Capacity + ENI attach   :a1, 00, 10s
    Image pull (biggest)     :a2, after a1, 25s
    section Your app
    App startup              :a3, after a2, 15s
    section Load balancer
    Health checks pass       :a4, after a3, 20s
```

**Ways to reduce it:**

- Keep images small: multi-stage builds, distroless or slim base images.
- Use **SOCI** (Seekable OCI) lazy loading on Fargate, so containers start before the whole image is downloaded.
- Tune the health check interval and threshold, and set `healthCheckGracePeriodSeconds` so slow-starting apps aren't killed while booting.
- Scale out early and scale in slowly: a low target value, a short scale-out cooldown, and a longer scale-in cooldown.
- Pre-scale with scheduled actions before known peaks. Reactive scaling alone can't absorb a step change in traffic.

### Limits you'll hit at scale

- **Fargate vCPU quota per Region per account.** This is a soft limit. Check it in Service Quotas and request an increase well before a launch.
- **Task launch rate.** ECS throttles how fast it starts tasks. Bursting from 10 to 500 tasks is not instant.
- **Subnet IP addresses** (see section 5).
- **Downstream limits.** Scaling to 200 tasks, each with a 20-connection database pool, means 4,000 database connections. Use RDS Proxy or size the pools deliberately. In real systems, the container layer is rarely the bottleneck; the database is.

---

## 9. Service-to-service communication

| Option | What it is | When to use it |
|---|---|---|
| **Internal ALB** | A load balancer reachable only inside the VPC. | Simple, well understood, and L7 features such as path routing. |
| **ECS Service Connect** | Managed service mesh. ECS injects an Envoy proxy sidecar and gives services short names such as `http://inventory:8080`. Includes retries, outlier detection, and per-service metrics. | Many microservices that call each other. This is the current AWS-recommended default. |
| **Cloud Map service discovery** | DNS records for task IP addresses. | Lightweight discovery when you don't need a proxy. |

---

## 10. Observability

The minimum production setup:

- **Logs:** use the `awslogs` driver to send to CloudWatch Logs, or a **FireLens** sidecar (Fluent Bit) to send to OpenSearch, Datadog, Splunk, or S3. Write structured JSON logs that include a request ID.
- **Metrics:** enable **Container Insights** for per-task CPU, memory, network, and restart counts. Emit application metrics such as latency percentiles and error rates.
- **Traces:** an OpenTelemetry collector sidecar sending to AWS X-Ray or another backend.
- **Events:** ECS publishes task state changes to **EventBridge**. Alert on tasks stopping repeatedly, because it signals a crash loop.

**Alarms worth having on every service:**

- running task count below the desired count for more than 5 minutes
- ALB 5xx rate
- target p99 latency
- memory utilization above 85%, because Fargate kills tasks that hit their memory limit

---

## 11. Cost

| Lever | Typical saving | Trade-off |
|---|---|---|
| **Graviton (ARM64)** | About 20% | You must build ARM64 or multi-arch images. |
| **Fargate Spot** | Up to about 70% | 2-minute interruption warning; x86 only. |
| **Compute Savings Plans** | Up to about 50% for a 1–3 year commitment | Commitment risk. |
| **Right-sizing** | Varies, often large | Requires reviewing actual CPU and memory usage. Many tasks request 4× what they use. |
| **Scale-to-zero for non-prod** | Large | Scheduled actions set the dev/staging desired count to 0 at night. |
| **VPC endpoints instead of NAT** | Saves NAT per-GB processing charges | Endpoints have their own hourly cost; this pays off for heavy image or log traffic. |

**Fargate vs EC2 cost:** Fargate costs more per vCPU-hour than a well-packed EC2 instance, but it removes idle capacity and operational work. At very large, steady scale, many companies move baseline load to the EC2 launch type with capacity providers and keep Fargate for bursty or spiky workloads.

---

## 12. Choosing between EC2, ECS, and EKS

| | EC2 + scripts | ECS on Fargate | EKS |
|---|---|---|---|
| **You operate** | Everything: placement, restarts, instance replacement, rollouts | Almost nothing beyond your app | Cluster upgrades, add-ons, node groups (unless you use Fargate or Auto Mode), and the Kubernetes object model |
| **Control plane cost** | None | None | Hourly fee per cluster |
| **Portability** | High (plain Docker) | AWS-only concepts | Kubernetes runs on any cloud and on-premises |
| **Learning curve** | Low at first, high later | Low | High |
| **Ecosystem** | Minimal | AWS-integrated | Very large (Helm, Argo CD, operators, Karpenter) |

**How teams actually decide:**

- A small team, an AWS-only product, and up to a few dozen services: **ECS on Fargate**.
- An existing Kubernetes skill set, hundreds of services, a multi-cloud or on-premises requirement, or a need for Kubernetes-native tools: **EKS**, with budgeted platform-team time.
- Plain EC2 for containers: mostly legacy setups or unusual host-level requirements.

```mermaid
flowchart TD
    Start([Need to run containers on AWS]) --> Q1{"Team already runs<br/>Kubernetes, or needs<br/>multi-cloud / on-prem?"}
    Q1 -->|yes| Q2{"Can you staff platform<br/>work: upgrades, add-ons?"}
    Q2 -->|yes| EKS[EKS]
    Q2 -->|no| ECSF
    Q1 -->|no| Q3{"Need GPUs, host access,<br/>or very high steady use?"}
    Q3 -->|yes| ECSE["ECS on EC2<br/>(capacity providers)"]
    Q3 -->|no| ECSF["ECS on Fargate<br/>(default choice)"]
    Start -.->|single tiny app,<br/>legacy setup| EC2["Plain EC2 + Docker"]
```

A common senior-level answer is: "Choose the option with the least operational surface that meets the requirements. Moving from ECS to EKS later is a known, manageable migration, because the container images stay the same."

---

## 13. Debugging: common failures and their causes

Always start here. The answer is usually in the `stoppedReason` and the container `reason`/`exitCode`:

```bash
aws ecs describe-tasks --cluster <cluster> --tasks <task-arn> \
  --query 'tasks[0].{status:lastStatus,stoppedReason:stoppedReason,containers:containers[].{name:name,exit:exitCode,reason:reason}}'
```

```mermaid
flowchart TD
    A([Task stopped or never ran]) --> B{"Did it reach RUNNING?"}
    B -->|no| C{"stoppedReason mentions"}
    C -->|CannotPullContainer| C1["Network path to registry?<br/>Image tag exists?<br/>Execution role ECR access?"]
    C -->|ResourceInitializationError| C2["Execution role can read secret?<br/>Path to Secrets Manager?"]
    C -->|exec format error| C3["Image arch ≠ task arch<br/>build multi-arch"]
    B -->|yes| D{"Container exit code"}
    D -->|137| D1["Out of memory<br/>raise memory / fix leak"]
    D -->|1 or other| D2["App crashed<br/>read CloudWatch logs"]
    D -->|0, but keeps cycling| D3["Failing ALB health check<br/>path, port, SG, grace period"]
```

| Symptom | Usual cause | Fix |
|---|---|---|
| `CannotPullContainerError` | No route to the registry (private subnet without NAT or endpoints, or a public subnet without a public IP), a wrong image tag, or a missing ECR permission on the execution role | Add NAT or VPC endpoints, or set `assignPublicIp=ENABLED` in labs; check the tag and the execution role |
| `ResourceInitializationError: unable to pull secrets` | The execution role can't read the secret, or there's no network path to Secrets Manager | Grant `secretsmanager:GetSecretValue` (and `kms:Decrypt` if a customer-managed key is used); add an endpoint or NAT |
| Exit code **137**, `OutOfMemoryError` | The container exceeded its memory limit and was killed | Increase memory or fix the leak; for JVMs, set heap size relative to the container limit |
| `Essential container in task exited` | The app crashed at startup | Read the CloudWatch logs for that task |
| Tasks start, then cycle every few minutes | Failing ALB health checks: wrong path or port, app too slow to start, or a security group blocking the ALB | Fix the health check path, add `healthCheckGracePeriodSeconds`, allow the ALB security group on the app port |
| `exec format error` | Image architecture doesn't match the task platform, for example an amd64 image on ARM64 | Build multi-arch images with `docker buildx --platform linux/amd64,linux/arm64` |
| Service stuck at fewer tasks than desired | Quota reached, subnet out of IP addresses, or no capacity of the requested type | Check service events, Service Quotas, and free IPs in the subnet |

---

## 14. The lab: register, run, inspect, stop

Lab constraints: one Fargate task, `cpu 256` / `memory 512`, ARM64, and resource names prefixed `escbash-lab-`. Save every response under `/root/`.

```mermaid
flowchart LR
    F1["/root/web-container.json"] -->|file://| R["register-task-definition<br/>→ /root/taskdef.json"]
    R --> C["create-cluster<br/>→ /root/cluster.json"]
    C --> RT["run-task (subnet + public IP)<br/>→ /root/run-task.json"]
    RT --> W["wait tasks-running"]
    W --> D["describe-tasks<br/>→ /root/describe-task.json"]
    D --> S["stop-task<br/>→ /root/stop-task.json"]
```

### Step 1: container definition file

```bash
cat > /root/web-container.json <<'EOF'
[
  {
    "name": "web",
    "image": "public.ecr.aws/nginx/nginx:latest",
    "essential": true,
    "portMappings": [
      { "containerPort": 80, "protocol": "tcp" }
    ]
  }
]
EOF
```

### Step 2: register the task definition

```bash
aws ecs register-task-definition \
  --family escbash-lab-web \
  --container-definitions file:///root/web-container.json \
  --requires-compatibilities FARGATE \
  --network-mode awsvpc \
  --cpu 256 \
  --memory 512 \
  --runtime-platform cpuArchitecture=ARM64,operatingSystemFamily=LINUX \
  > /root/taskdef.json
```

### Step 3: create a cluster

```bash
aws ecs create-cluster --cluster-name escbash-lab-cluster > /root/cluster.json
```

### Step 4: run one task in a default-VPC subnet

```bash
SUBNET=$(aws ec2 describe-subnets \
  --filters Name=default-for-az,Values=true \
  --query 'Subnets[0].SubnetId' --output text)

aws ecs run-task \
  --cluster escbash-lab-cluster \
  --task-definition escbash-lab-web \
  --launch-type FARGATE \
  --count 1 \
  --network-configuration "awsvpcConfiguration={subnets=[$SUBNET],assignPublicIp=ENABLED}" \
  > /root/run-task.json

TASK_ARN=$(jq -r '.tasks[0].taskArn' /root/run-task.json)
```

`assignPublicIp=ENABLED` is what lets the task reach `public.ecr.aws` to pull the image from a default-VPC subnet.

### Step 5: wait for it and inspect it

```bash
aws ecs wait tasks-running --cluster escbash-lab-cluster --tasks "$TASK_ARN"
aws ecs describe-tasks --cluster escbash-lab-cluster --tasks "$TASK_ARN" > /root/describe-task.json
jq '.tasks[0] | {lastStatus, cpu, memory, platformFamily, attachments: [.attachments[].details[] | select(.name=="privateIPv4Address")]}' /root/describe-task.json
```

### Step 6: stop it

```bash
aws ecs stop-task --cluster escbash-lab-cluster --task "$TASK_ARN" --reason "lab complete" > /root/stop-task.json
```

---

## 15. A production-grade task definition (reference)

This is roughly what `orders-api` looks like at a real company. Compare it with the minimal lab version.

```json
{
  "family": "orders-api",
  "requiresCompatibilities": ["FARGATE"],
  "networkMode": "awsvpc",
  "cpu": "1024",
  "memory": "2048",
  "runtimePlatform": { "cpuArchitecture": "ARM64", "operatingSystemFamily": "LINUX" },
  "executionRoleArn": "arn:aws:iam::123456789012:role/orders-api-execution",
  "taskRoleArn": "arn:aws:iam::123456789012:role/orders-api-task",
  "containerDefinitions": [
    {
      "name": "app",
      "image": "123456789012.dkr.ecr.us-east-1.amazonaws.com/orders-api:a1b2c3d",
      "essential": true,
      "portMappings": [{ "containerPort": 8080, "protocol": "tcp", "name": "http" }],
      "environment": [{ "name": "APP_ENV", "value": "prod" }],
      "secrets": [
        { "name": "DB_PASSWORD", "valueFrom": "arn:aws:secretsmanager:us-east-1:123456789012:secret:orders/db-AbCdEf" }
      ],
      "healthCheck": {
        "command": ["CMD-SHELL", "curl -fs http://localhost:8080/healthz || exit 1"],
        "interval": 15, "timeout": 5, "retries": 3, "startPeriod": 30
      },
      "stopTimeout": 60,
      "readonlyRootFilesystem": true,
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/orders-api",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "app"
        }
      }
    }
  ]
}
```

What's different from the lab:

- The image is pinned to a commit SHA in private ECR.
- There are separate execution and task roles.
- Secrets come from Secrets Manager, not plain environment variables.
- A container health check is defined.
- `stopTimeout` allows graceful shutdown.
- The root filesystem is read-only for security.
- Logs are centralized.

---

## 16. Interview-style questions

1. **What is the difference between a task and a service?**
   A task is one running copy of a task definition. A service keeps a desired number of tasks running, replaces failed ones, connects them to a load balancer, and handles deployments.

2. **What is the difference between the task role and the execution role?**
   The execution role is used by ECS itself to pull images, write logs, and fetch secrets at startup. The task role is used by your application code to call AWS APIs at runtime.

3. **Your Fargate tasks in a private subnet fail with `CannotPullContainerError`. Why?**
   There's no network path to ECR. Add a NAT gateway or VPC endpoints for ECR API, ECR DKR, S3, and CloudWatch Logs.

4. **How do you deploy with zero downtime on ECS?**
   Use a rolling update with `minimumHealthyPercent=100` and `maximumPercent=200`, ALB health checks, graceful SIGTERM handling, a tuned deregistration delay, and the circuit breaker with rollback. Or use blue/green with canary traffic shifting.

5. **Traffic jumps 10× at 09:00 every Black Friday. How do you prepare?**
   - Raise the minimum task count with scheduled scaling before 09:00.
   - Confirm Fargate vCPU quotas and subnet IP headroom.
   - Keep images small, or use SOCI, for fast starts.
   - Scale on request count per target.
   - Protect the database with RDS Proxy and connection-pool limits.
   - Load-test the whole path beforehand.

6. **When would you pick EKS over ECS?**
   When the team already runs Kubernetes, needs its ecosystem, or has a real multi-cloud or on-premises portability requirement, and can staff the platform work.

7. **Why might a service scale to 200 tasks and then make things worse?**
   The downstream dependency, usually the database, runs out of connections or capacity. Scaling the stateless layer only moves the bottleneck. Cap the max task count, use connection pooling, and add caching or queues.

---

## 17. Command cheat sheet

| Command | Purpose |
|---|---|
| `aws ecs register-task-definition` | Register a new task definition revision |
| `aws ecs list-task-definitions --family-prefix X` | List revisions |
| `aws ecs deregister-task-definition` | Mark a revision inactive |
| `aws ecs create-cluster` | Create a cluster |
| `aws ecs run-task` | Start standalone tasks |
| `aws ecs wait tasks-running` / `tasks-stopped` | Block until a state is reached |
| `aws ecs describe-tasks` | Read task status, IP addresses, and stop reasons |
| `aws ecs stop-task` | Stop a task |
| `aws ecs create-service` / `update-service` | Create a service, or deploy a new revision or count |
| `aws ecs describe-services` | Read deployments and service events |
| `aws ecs execute-command` | Open a shell in a running container (ECS Exec) |
| `aws application-autoscaling register-scalable-target` / `put-scaling-policy` | Configure service auto scaling |
