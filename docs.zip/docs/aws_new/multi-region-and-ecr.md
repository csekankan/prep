# Container Images (ECR) and Multi-Region Systems on AWS

This guide covers:

1. **ECR image management:** tags, digests, versioning, promotion between environments, lifecycle rules, security, and rollback.
2. **Multi-Region fundamentals:** why companies run in several Regions, and the theory behind it (RPO, RTO, consistency, replication).
3. **Shipping updates to many Regions:** build once, replicate, and deploy in waves.
4. **Databases across Regions:** how an app in one Region reads and writes data that lives in another, and how failover works.
5. **Reference architectures, checklists, interview questions, and commands.**

The running example is an online shop. Its `orders-api` service runs on ECS in `us-east-1` (N. Virginia), `eu-west-1` (Ireland), and `ap-south-1` (Mumbai).

---

# Part 1: Managing container images in ECR

## 1. Core definitions

| Term | Definition | Example |
|---|---|---|
| **Registry** | The ECR store for one AWS account in one Region | `111122223333.dkr.ecr.us-east-1.amazonaws.com` |
| **Repository** | A named collection of versions of one image, usually one per service | `shop/orders-api` |
| **Image** | A packaged, read-only filesystem plus metadata that a container runs from | The `orders-api` build from commit `a1b2c3d` |
| **Tag** | A human-readable label pointing to an image. **Tags can be moved to another image** unless the repository makes them immutable. | `a1b2c3d`, `v2.4.0`, `latest` |
| **Digest** | A SHA-256 hash of the image's content. **It never changes**, and it identifies exactly one image. | `sha256:4f9c...e21b` |
| **Manifest** | A JSON document listing the image's layers and configuration. The digest is the hash of the manifest. | — |
| **Image index** (manifest list) | One tag that points to several platform-specific images, for example `linux/amd64` and `linux/arm64` | A multi-arch image |

```mermaid
flowchart LR
    subgraph Repo["Repository: shop/orders-api"]
        T1["tag: a1b2c3d"] --> D1["digest sha256:4f9c…<br/>(image built from commit a1b2c3d)"]
        T2["tag: v2.4.0"] --> D1
        T3["tag: prod-current"] -.->|"mutable tags can move"| D1
        T4["tag: 9e8f7a6"] --> D2["digest sha256:77ab…<br/>(next build)"]
    end
```

Several tags can point to the same image. **The digest is the only identifier that guarantees exactly which bytes run.**

## 2. Tagging and versioning best practices

### Rules production teams follow

1. **Tag every build with the git commit SHA** (`a1b2c3d`). Every running container can then be traced to its exact source code.
2. **Add a release version for humans** (`v2.4.0`), following semantic versioning: MAJOR.MINOR.PATCH.
3. **Turn on tag immutability.** Once `v2.4.0` is pushed, nobody can push a different image with the same tag:
   ```bash
   aws ecr put-image-tag-mutability --repository-name shop/orders-api --image-tag-mutability IMMUTABLE
   ```
4. **Never deploy `latest` to production.** It's mutable. Two tasks started an hour apart could run different code, and rollback becomes guesswork.
5. **For the strongest guarantee, deploy by digest:**
   ```
   111122223333.dkr.ecr.us-east-1.amazonaws.com/shop/orders-api@sha256:4f9c...e21b
   ```
   Many pipelines resolve the tag to a digest at deploy time and write the digest into the task definition or Kubernetes manifest.
6. **Build multi-arch images** (`linux/amd64` and `linux/arm64`) with `docker buildx`, so the same tag runs on x86 and Graviton.

### Build once, promote everywhere

**Never rebuild an image for each environment.** A rebuild can pull different dependency versions, so what you tested isn't what you ship. Build once, then **promote the same digest** through dev, staging, and prod:

```mermaid
flowchart LR
    Git["git commit a1b2c3d"] --> CI["CI build + unit tests<br/>+ vulnerability scan"]
    CI -->|push once| ECR[("ECR<br/>orders-api:a1b2c3d<br/>sha256:4f9c…")]
    ECR -->|same digest| Dev["Dev"]
    Dev -->|tests pass| Stg["Staging"]
    Stg -->|tests + approval| Prod["Prod"]
    Prod -.->|"add tag v2.4.0<br/>(no rebuild)"| ECR
```

Adding a tag to an existing image doesn't copy or rebuild anything:

```bash
MANIFEST=$(aws ecr batch-get-image --repository-name shop/orders-api \
  --image-ids imageTag=a1b2c3d --query 'images[0].imageManifest' --output text)
aws ecr put-image --repository-name shop/orders-api --image-tag v2.4.0 --image-manifest "$MANIFEST"
```

### Where repositories live

| Layout | How it works | Best for |
|---|---|---|
| **Central artifact account** | One "shared services" or "artifacts" account owns all ECR repositories. Workload accounts (dev, staging, prod) pull through a **repository policy** that grants them access. | Most companies: one source of truth, built once |
| **Per-environment registries** | Each environment account has its own ECR. Promotion copies or replicates the image into the next account. | Strict isolation (regulated industries): prod never pulls from a non-prod account |

Repository policy that lets the prod account pull:

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "AllowProdPull",
    "Effect": "Allow",
    "Principal": { "AWS": "arn:aws:iam::444455556666:root" },
    "Action": ["ecr:BatchGetImage", "ecr:GetDownloadUrlForLayer", "ecr:BatchCheckLayerAvailability"]
  }]
}
```

## 3. Lifecycle policies: cleaning up old images

Repositories fill up with thousands of images, and storage costs about **$0.10 per GB-month**. **Lifecycle policies** delete old images automatically:

```json
{
  "rules": [
    {
      "rulePriority": 1,
      "description": "Delete untagged images after 7 days",
      "selection": { "tagStatus": "untagged", "countType": "sinceImagePushed", "countUnit": "days", "countNumber": 7 },
      "action": { "type": "expire" }
    },
    {
      "rulePriority": 2,
      "description": "Keep only the newest 50 release images",
      "selection": { "tagStatus": "tagged", "tagPrefixList": ["v"], "countType": "imageCountMoreThan", "countNumber": 50 },
      "action": { "type": "expire" }
    },
    {
      "rulePriority": 3,
      "description": "Delete commit-only builds after 30 days",
      "selection": { "tagStatus": "any", "countType": "sinceImagePushed", "countUnit": "days", "countNumber": 30 },
      "action": { "type": "expire" }
    }
  ]
}
```

```bash
aws ecr put-lifecycle-policy --repository-name shop/orders-api --lifecycle-policy-text file://lifecycle.json
aws ecr start-lifecycle-policy-preview --repository-name shop/orders-api   # see what would be deleted first
```

ECR applies rules in priority order, and each image is handled by the first rule that selects it. In the policy above, release images (`v…`) fall under rule 2, so rule 3 only cleans up commit-only builds.

**Safety rules:**

- **Keep enough images to roll back.** Never delete the versions currently running in any Region, or the last several releases.
- **Preview before applying.** A wrong rule can delete production images.
- **Lifecycle policies aren't replicated.** Set them in every Region and account.

## 4. Image security

| Control | What it does | How |
|---|---|---|
| **Scan on push** | Checks OS packages for known vulnerabilities (CVEs) | Basic scanning, set per repository or registry |
| **Enhanced scanning** | Continuous scanning of OS **and** language packages (pip, npm, Maven), re-scanned as new CVEs are published | Amazon Inspector integration |
| **Block vulnerable deploys** | The pipeline fails if critical CVEs are found | A CI step reads the scan findings |
| **Image signing** | Proves the image came from your pipeline and wasn't changed | AWS Signer (Notation) or Sigstore cosign; verified at deploy by an EKS admission controller such as Kyverno |
| **Minimal base images** | Fewer packages means fewer CVEs and faster pulls | Distroless, Alpine, or slim images; multi-stage builds |
| **Pull-through cache** | Caches Docker Hub, GitHub, and Quay images inside ECR | Avoids public rate limits and outages, and scans public images |
| **Private access** | Image pulls stay inside AWS | ECR interface endpoints (`ecr.api`, `ecr.dkr`) plus the S3 gateway endpoint |
| **Encryption** | Images encrypted at rest | AES-256 by default, or customer-managed KMS keys |
| **Least privilege** | CI can push; runtime can only pull | Separate IAM roles; repository policies |

```bash
aws ecr create-pull-through-cache-rule \
  --ecr-repository-prefix docker-hub \
  --upstream-registry-url registry-1.docker.io \
  --credential-arn arn:aws:secretsmanager:us-east-1:111122223333:secret:ecr-pullthroughcache/docker-hub
# Then pull: 111122223333.dkr.ecr.us-east-1.amazonaws.com/docker-hub/library/nginx:1.27
```

## 5. Rollback

Because images are immutable and identified by digest, rollback means **pointing the service back at the previous image**, with no rebuild:

```mermaid
flowchart LR
    V1["Task def :41<br/>image @sha256:aaa (v2.3.0)"] -->|deploy| V2["Task def :42<br/>image @sha256:bbb (v2.4.0)"]
    V2 -->|"alarms fire:<br/>circuit breaker or pipeline<br/>redeploys :41"| V1
```

You need:

- the old image **still in ECR in every Region** (lifecycle rules must keep it);
- the old task definition revision, or manifest, **still registered**;
- **backward-compatible database changes** (Part 3, section 10), so the old code still works with the new schema.

---

# Part 2: Multi-Region fundamentals

## 6. Why run in more than one Region

| Reason | Example |
|---|---|
| **Disaster recovery** | A whole Region has a major outage; customers are served from another Region |
| **Latency** | Users in India are served from Mumbai (~20 ms) instead of Virginia (~200 ms) |
| **Data residency and compliance** | EU customer data must stay in the EU (GDPR); Indian payment data must stay in India (RBI rules) |
| **Blast radius** | A bad deploy or configuration in one Region doesn't affect the others |

**Multi-Region is expensive and complex.** Most applications are well served by **multi-AZ in one Region**, which already survives a data-center failure. Go multi-Region for a clear business reason, such as a strict uptime target, global latency, or regulation.

## 7. Key theory

### RPO and RTO

| Term | Question it answers | Example |
|---|---|---|
| **RPO** (Recovery Point Objective) | How much **data** can we lose? | "At most 1 second of orders" |
| **RTO** (Recovery Time Objective) | How long can we be **down**? | "Back within 5 minutes" |

```mermaid
flowchart LR
    LastGood["Last replicated data"] -->|"RPO = data lost"| Disaster(("Region fails"))
    Disaster -->|"RTO = downtime"| Recovered["Serving again in Region B"]
```

### The four disaster-recovery strategies

| Strategy | What runs in the second Region | Typical RPO | Typical RTO | Cost |
|---|---|---|---|---|
| **Backup and restore** | Nothing; only backups (snapshots, S3 copies, AMIs, images) | Hours | Hours to a day | $ |
| **Pilot light** | Data replicated live; compute is off or minimal | Seconds to minutes | Tens of minutes | $$ |
| **Warm standby** | A smaller, fully working copy of the app, scaled up on failover | Seconds | Minutes | $$$ |
| **Active-active (multi-site)** | Full capacity in every Region, all serving traffic | Near zero | Near zero (traffic shifts away) | $$$$ |

```mermaid
flowchart LR
    BR["Backup and restore<br/>cheap, slow"] --> PL["Pilot light"] --> WS["Warm standby"] --> AA["Active-active<br/>expensive, fastest"]
```

### Consistency across Regions

Light takes time to travel. Virginia to Ireland is about **70–80 ms** round trip, and Virginia to Mumbai about **180–200 ms**. That forces a choice for data replicated between Regions:

| | Synchronous replication | Asynchronous replication |
|---|---|---|
| How it works | A write is confirmed only after **every Region** has it | A write is confirmed locally, then copied to other Regions shortly after |
| Data loss on a Region failure | **None** (RPO = 0) | The last moments of writes (**replication lag**, usually under a second to seconds) |
| Write latency | **High**: every write waits for the slowest Region | **Low**: local speed |
| Used by | A few specialized databases (Aurora DSQL, DynamoDB's multi-Region strong-consistency mode) | Most cross-Region replication (Aurora Global Database, DynamoDB global tables by default, S3 replication) |

This trade-off is captured by the **CAP theorem** and its extension **PACELC**:

- During a **network partition**, a system must choose **consistency** (refuse some requests) or **availability** (answer, possibly with stale data).
- **Even without a partition**, it trades **latency** against **consistency**.

Most multi-Region systems choose **asynchronous replication, low latency, and eventual consistency**, and design the application to cope with that.

### Problems eventual consistency causes, and the standard fixes

| Problem | Example | Fix |
|---|---|---|
| **Stale read** | A user updates their address in Virginia, then their next request lands in Ireland and shows the old address | Route each user to a **home Region** (sticky routing), or read from the writer for a few seconds after a write |
| **Write conflict** | The same order is updated in two Regions at the same moment | One writer Region per record, **last-writer-wins** (DynamoDB global tables), or conflict-free designs: append-only events, idempotent operations |
| **Duplicate processing** | Failover replays events that were already handled | **Idempotent** consumers keyed on order or event ID |
| **Split brain** | Both Regions think they're the primary and accept writes | Use one controlled failover mechanism, with **fencing**: the old primary is blocked from writing |

### Design principles for multi-Region

1. **Region independence.** Each Region must serve requests without calling another Region in the request path. If `eu-west-1` calls `us-east-1` for every request, an outage in `us-east-1` takes both down.
2. **Static stability.** During an outage, the surviving Region should already have the capacity it needs, or keep working without making changes. Scaling up during a Region-wide event is risky, because everyone else is scaling up too.
3. **Fail over using data-plane actions, not control-plane actions.**
   - **Control plane:** creating and changing resources, such as `create-*` and `update-*` API calls.
   - **Data plane:** the running system doing its job, such as Route 53 answering DNS queries or a load balancer routing traffic.

   Control planes are more likely to be impaired during big events. Route 53 health checks and **Application Recovery Controller** routing controls work on the data plane, so failover keeps working.
4. **Practice failover regularly** ("game days"). An untested DR plan usually fails when it's needed.

---

# Part 3: Shipping updates to many Regions

## 8. Replicating images to every Region

Each ECS task or EKS node should **pull its image from ECR in its own Region**:

- **Faster:** no cross-Region transfer on every task start.
- **Cheaper:** no inter-Region data charges for each pull.
- **Region-independent:** if `us-east-1` is down, `eu-west-1` can still start tasks.

**ECR replication** copies images automatically to other Regions, and other accounts:

```mermaid
flowchart LR
    CI["CI pipeline"] -->|"push once"| Src[("ECR us-east-1<br/>source registry")]
    Src -->|"automatic replication<br/>(asynchronous)"| EU[("ECR eu-west-1")]
    Src -->|"automatic replication"| AP[("ECR ap-south-1")]
    Src --> ECSUS["ECS us-east-1"]
    EU --> ECSEU["ECS eu-west-1"]
    AP --> ECSAP["ECS ap-south-1"]
```

```json
{
  "rules": [{
    "destinations": [
      { "region": "eu-west-1",  "registryId": "111122223333" },
      { "region": "ap-south-1", "registryId": "111122223333" }
    ],
    "repositoryFilters": [{ "filter": "shop/", "filterType": "PREFIX_MATCH" }]
  }]
}
```

```bash
aws ecr put-replication-configuration --replication-configuration file://replication.json
```

Things to know:

- **Replication is asynchronous.** It usually finishes in minutes, but isn't instant. **The pipeline must wait until the image exists in a Region before deploying there:**
  ```bash
  until aws ecr describe-images --repository-name shop/orders-api \
        --image-ids imageTag=a1b2c3d --region eu-west-1 >/dev/null 2>&1; do
    echo "waiting for replication to eu-west-1..."; sleep 15
  done
  ```
- **The digest is identical in every Region**, so deploying by digest guarantees the same image everywhere.
- **Repository settings and lifecycle policies aren't copied by replication.** Use **repository creation templates**, or infrastructure as code, to give replicated repositories the same immutability, scanning, encryption, and lifecycle settings.
- **Only new pushes replicate.** Existing images aren't copied backwards when you add a rule.

## 9. Deploying in waves

**Never deploy to every Region at once.** A bad release would then break every Region together, which defeats the point of multi-Region. AWS deploys its own services in waves, and so do most large companies:

```mermaid
flowchart LR
    B["Build once<br/>scan, sign, push"] --> R["Replicate image<br/>to all Regions"]
    R --> S["Staging<br/>integration tests"]
    S --> W1["Wave 1: one small Region<br/>(e.g. ap-south-1)<br/>canary 10% → 100%"]
    W1 --> Bake1{"Bake 1–2 h<br/>alarms OK?"}
    Bake1 -->|yes| W2["Wave 2: eu-west-1"]
    Bake1 -->|no| RB["Automatic rollback,<br/>stop the pipeline"]
    W2 --> Bake2{"Bake<br/>alarms OK?"}
    Bake2 -->|yes| W3["Wave 3: us-east-1<br/>(largest)"]
    Bake2 -->|no| RB
```

| Practice | Why |
|---|---|
| **Same artifact everywhere** (one digest) | What you tested is exactly what runs in every Region |
| **Start with the smallest-traffic Region** | Limits the impact if something is wrong |
| **Canary within each Region** (10%, then 100%) | Catches problems before the whole Region is affected |
| **Bake time with automatic alarms** (error rate, latency, business metrics) | Some bugs only appear under real traffic over time |
| **Automatic rollback** | No human needed at 3 a.m. |
| **One Region at a time** | A failed wave stops before reaching the other Regions |
| **Avoid deploying during peak hours** in the target Region | Smaller impact if something goes wrong |

### Infrastructure and configuration per Region

| Concern | How teams handle it |
|---|---|
| Infrastructure (VPC, ECS, load balancers) | One template, deployed per Region with parameters: **CloudFormation StackSets**, Terraform modules with a per-Region configuration, or **CDK** stages |
| Kubernetes apps | **Argo CD** or Flux syncing the same manifests to each Region's cluster, with per-Region overlays (Kustomize or Helm values) |
| Region-specific settings (endpoints, feature flags, limits) | **SSM Parameter Store** or **AppConfig** in each Region. Parameter Store doesn't replicate, so deploy parameters through the pipeline. |
| Secrets | **Secrets Manager replica secrets**: one secret replicated to chosen Regions |
| Encryption keys | **KMS multi-Region keys**: the same key material in several Regions, so data encrypted in one Region can be decrypted in another |
| Tools | CodePipeline, GitHub Actions, or GitLab CI with one stage per Region; ECS deployment circuit breaker; CodeDeploy canaries |

## 10. Version skew: different Regions run different versions

During a wave rollout, `ap-south-1` may run v2.4.0 for hours while `us-east-1` still runs v2.3.0. Everything shared between Regions must work with **both versions at once**:

| Shared thing | Rule |
|---|---|
| **APIs** | Only add fields; never remove or rename fields in a live API. Version breaking changes (`/v2/orders`). |
| **Events** (EventBridge, SQS, Kafka) | Consumers ignore unknown fields; producers only add fields |
| **Database schema** | Use **expand and contract** migrations (below) |
| **Caches and sessions** | Both versions must read each other's cached data |

### Expand and contract: safe schema changes

Example: rename the column `address` to `shipping_address`:

```mermaid
flowchart LR
    E1["1. Expand<br/>add shipping_address<br/>(old code ignores it)"] --> E2["2. Deploy code that<br/>writes BOTH columns,<br/>reads the new one"]
    E2 --> E3["3. Backfill old rows"]
    E3 --> E4["4. Every Region on new code"]
    E4 --> E5["5. Contract<br/>drop old column<br/>(weeks later)"]
```

At every step, both the old and the new code versions work, so any Region can roll back.

**Feature flags** separate deploying code from turning features on. Ship code with the feature switched off in every Region, then enable it Region by Region, or for a percentage of users, through a flag service such as AppConfig or LaunchDarkly.

---

# Part 4: Databases and data across Regions

## 11. AWS options for multi-Region data

| Service | Model | Writes | Replication | Typical lag | Failover |
|---|---|---|---|---|---|
| **Aurora Global Database** | One primary Region, several read-only secondary Regions | **Primary Region only** (secondaries can use **write forwarding**) | Asynchronous, storage-level | Usually **under 1 second** | Managed switchover (planned) or failover (unplanned) promotes a secondary, typically in about a minute |
| **RDS cross-Region read replica** | One primary, read replicas in other Regions | Primary only | Asynchronous | Seconds or more | Manual promotion of a replica |
| **DynamoDB global tables** | **Multi-active**: every Region holds a full copy | **Every Region** | Asynchronous by default, last-writer-wins conflicts; a multi-Region strong-consistency mode is also available | Usually about **1 second** | Nothing to promote; route traffic to another Region |
| **Aurora DSQL** | Active-active distributed SQL | Every Region | **Synchronous**, strongly consistent | Not applicable (writes pay the cross-Region latency) | Built in |
| **ElastiCache Global Datastore** (Redis/Valkey) | One primary Region, secondary Regions for reads | Primary | Asynchronous | Usually under 1 second | Promote a secondary |
| **S3 Cross-Region Replication** | Bucket replicated to other Regions | Each bucket | Asynchronous; **Replication Time Control** has a 15-minute SLA | Seconds to minutes | **Multi-Region Access Points** route requests to a healthy Region |
| **Secrets Manager replicas / KMS multi-Region keys** | Secret or key copied to other Regions | Primary | Managed | Seconds | Use the replica |

## 12. How an app in one Region uses a database in another

### Pattern A: read locally, write to the primary Region

This is the most common design with Aurora Global Database.

```mermaid
flowchart TB
    subgraph US["us-east-1 (primary)"]
        AppUS["orders-api"] -->|reads + writes| W[("Aurora writer")]
    end
    subgraph EU["eu-west-1 (secondary)"]
        AppEU["orders-api"] -->|"reads, local, fast"| R[("Aurora read-only<br/>replica cluster")]
        AppEU -->|"writes: write forwarding<br/>or direct to primary<br/>(+70–80 ms)"| W
    end
    W -->|"storage replication<br/>usually under 1 s"| R
```

| | Detail |
|---|---|
| **Reads** | Local and fast, but may be slightly stale (replication lag) |
| **Writes** | Go to the primary Region and pay cross-Region latency. Either the database forwards them (**Aurora write forwarding**), or the app connects to the primary's writer endpoint over private inter-Region networking. |
| **Networking** | **Inter-Region VPC peering** or **Transit Gateway inter-Region peering**, with **non-overlapping CIDR ranges**. Cross-Region data transfer costs about $0.02/GB. |
| **Good for** | Read-heavy apps: catalogs, content, profiles |

**Read-your-own-writes problem:** a user saves something in Ireland (written in Virginia), and the next read in Ireland, from the replica, doesn't show it yet.

**Fixes:**

- read from the writer for a few seconds after that user writes;
- use Aurora's **read consistency setting** with write forwarding (session-level consistency);
- show the user the value they just submitted, without re-reading it.

### Pattern B: home Region per user (data partitioning)

```mermaid
flowchart LR
    U1(("EU customer")) -->|Route 53 / app routing| EU["eu-west-1<br/>owns EU customers' data"]
    U2(("US customer")) --> US["us-east-1<br/>owns US customers' data"]
    U3(("IN customer")) --> AP["ap-south-1<br/>owns Indian customers' data"]
    EU -.->|"async backup copy<br/>(if residency rules allow)"| US
```

- Each user's data has **one home Region**, which is the only place it's written.
- **No write conflicts**, local latency for most users, and it **naturally satisfies data residency** rules.
- **Challenges:** a global directory to find a user's home Region; a user travelling abroad has slower access; and failover for a Region's users needs a replica somewhere legally allowed.
- Common in fintech, SaaS (each tenant pinned to a Region), and messaging.

### Pattern C: multi-active everywhere

```mermaid
flowchart LR
    subgraph US["us-east-1"]
        AppUS["orders-api"] <--> DUS[("DynamoDB<br/>global table replica")]
    end
    subgraph EU["eu-west-1"]
        AppEU["orders-api"] <--> DEU[("replica")]
    end
    subgraph AP["ap-south-1"]
        AppAP["orders-api"] <--> DAP[("replica")]
    end
    DUS <-->|"async, ~1 s<br/>last writer wins"| DEU
    DEU <--> DAP
    DAP <--> DUS
```

- Every Region reads and writes **locally**. A Region outage just means routing users to another Region.
- **You must design for conflicts:**
  - make writes idempotent;
  - prefer append-only records (an order's events, not a single mutable row);
  - keep one writer per item where possible;
  - accept last-writer-wins, or use the strong-consistency mode for critical items.
- Good for sessions, carts, user preferences, and high-scale key-value data.

### Choosing a pattern

| Need | Pattern |
|---|---|
| Relational data, mostly reads, DR within about a minute | **A**: Aurora Global Database |
| Data residency, or tenant isolation | **B**: home Region per user or tenant |
| Lowest latency for writes worldwide, key-value data | **C**: DynamoDB global tables |
| Strong consistency with writes in several Regions, SQL | Aurora DSQL, or DynamoDB strong-consistency mode, accepting higher write latency |
| Just DR, with a small budget | Backups copied cross-Region (AWS Backup), restored when needed |

## 13. Failover: what actually happens

Example: warm standby with Aurora Global Database, where `us-east-1` is primary and `eu-west-1` is secondary.

```mermaid
sequenceDiagram
    participant R53 as Route 53 / ARC
    participant US as us-east-1 (primary)
    participant EU as eu-west-1 (standby)
    participant Ops as On-call / automation

    Note over US: Region impaired
    R53->>US: health checks fail
    Ops->>Ops: decide to fail over (runbook, or automatic)
    Ops->>EU: failover-global-cluster: promote EU to writer
    Note over EU: Aurora EU becomes the primary (~1 min)<br/>last ~1 s of writes may be lost (RPO)
    Ops->>EU: scale ECS services up (or already at full size)
    Ops->>R53: routing control: send traffic to EU
    R53-->>EU: users now served from eu-west-1
    Note over US,EU: Later: rebuild US as a secondary,<br/>then switch back in a planned switchover
```

**Checklist before you can fail over:**

- [ ] Images replicated to the standby Region's ECR (Part 3)
- [ ] Infrastructure already deployed there (VPC, ECS services, load balancers), not created during the incident
- [ ] Secrets and KMS keys replicated
- [ ] Configuration (Parameter Store and AppConfig) present in the standby Region
- [ ] DNS failover ready: Route 53 failover records, or Application Recovery Controller routing controls
- [ ] Capacity reserved or pre-scaled (static stability)
- [ ] **Tested in a game day within the last few months**

## 14. Global traffic routing

| Service | What it does | Use for |
|---|---|---|
| **Route 53 latency routing** | Sends each user to the Region with the lowest latency | Active-active |
| **Route 53 geolocation / geoproximity** | Routes by the user's country or location | Data residency, and pattern B |
| **Route 53 failover routing + health checks** | Sends traffic to the secondary when the primary is unhealthy | Active-passive |
| **Route 53 weighted routing** | Splits traffic by percentage | Gradual migration between Regions |
| **Application Recovery Controller (ARC)** | Highly reliable on/off switches for Region traffic, plus readiness checks | Controlled, tested failover |
| **AWS Global Accelerator** | Two static anycast IPs; routes over the AWS backbone to the nearest healthy Region, with fast failover | TCP/UDP apps, gaming, APIs that need static IPs |
| **CloudFront** | Global CDN, with origin failover between Regions | Web content and APIs |

## 15. What's global and what's per-Region in AWS

| Global (one copy for the account) | Per-Region (must be set up in each Region) |
|---|---|
| IAM users, roles, and policies | VPCs, subnets, security groups |
| Route 53 hosted zones | ECR repositories and lifecycle policies (replication copies images only) |
| CloudFront distributions | ECS clusters and services, EKS clusters |
| WAF for CloudFront | Load balancers, ACM certificates for load balancers |
| Organizations and SCPs | RDS and Aurora clusters (Global Database links them) |
| — | Secrets (unless replicated), KMS keys (unless multi-Region), Parameter Store |
| — | EventBridge buses (cross-Region rules can forward events), SQS queues (no built-in replication) |
| — | CloudWatch alarms and dashboards |

---

# Part 5: Reference architectures and checklists

## 16. Three common multi-Region setups

### Setup 1: active-passive warm standby

```mermaid
flowchart TB
    Users((Users)) --> R53["Route 53 failover<br/>+ health checks / ARC"]
    R53 -->|primary| USALB
    R53 -.->|on failover| EUALB
    subgraph US["us-east-1: ACTIVE"]
        USALB["ALB"] --> USECS["ECS: 20 tasks"] --> USDB[("Aurora writer")]
        USECR[("ECR")]
    end
    subgraph EU["eu-west-1: WARM STANDBY"]
        EUALB["ALB"] --> EUECS["ECS: 4 tasks<br/>(scale up on failover)"] --> EUDB[("Aurora secondary")]
        EUECR[("ECR replica")]
    end
    USDB -->|"replication under 1 s"| EUDB
    USECR -->|image replication| EUECR
```

- **RPO** about a second, **RTO** minutes. Moderate cost.
- **Common in:** most businesses that need DR without the complexity of active-active.

### Setup 2: active-active, reads local, writes to one Region

Both Regions serve traffic through Route 53 latency routing. Reads are local, and writes go to the primary Aurora cluster through write forwarding.

- **Good latency for reads, simple consistency.** Writes from far Regions are slower.
- **Common in:** e-commerce catalogs, media, content platforms.

### Setup 3: fully active-active, multi-writer

Every Region is a complete copy with DynamoDB global tables, stateless services, and an event bus per Region forwarding important events.

- **Highest availability and lowest latency**, but the most complex: conflict handling, idempotency, and careful testing.
- **Common in:** very large consumer apps, payments with careful design, and gaming backends.

## 17. Best-practice checklist

**Images (ECR)**
- [ ] Every build tagged with the git SHA; releases with semver; **immutable tags**
- [ ] Deploy by digest (or resolve tags to digests in the pipeline)
- [ ] Build once; promote the same digest through environments
- [ ] Scanning (enhanced, with Inspector); critical CVEs block deploys
- [ ] Images signed and verified at deploy (for regulated or high-security workloads)
- [ ] Lifecycle policies in every Region, keeping enough versions to roll back
- [ ] Pull-through cache for public images
- [ ] Replication to every Region where the service runs; the pipeline waits for it

**Deployments**
- [ ] Waves, one Region at a time, smallest first, with canaries and bake time
- [ ] Automatic rollback on alarms
- [ ] Backward-compatible APIs, events, and schemas (expand and contract)
- [ ] Feature flags to separate deploying from releasing
- [ ] The same infrastructure code in every Region, with per-Region parameters

**Data**
- [ ] RPO and RTO agreed with the business, and the DR strategy chosen to match
- [ ] Replication method chosen deliberately (Aurora Global, DynamoDB global tables, S3 CRR)
- [ ] Read-your-writes and conflict handling designed for
- [ ] Idempotent consumers everywhere
- [ ] Non-overlapping CIDRs for any cross-Region private connectivity

**Resilience**
- [ ] No cross-Region calls in the request path (Region independence)
- [ ] Standby Region pre-deployed and pre-scaled enough (static stability)
- [ ] Failover uses data-plane mechanisms (Route 53 health checks, ARC)
- [ ] Failover practiced in game days

## 18. Interview-style questions

1. **Why not deploy `latest`?**
   It's mutable. Different tasks can run different code, you can't tell what's running, and rollback is unreliable. Use immutable SHA or semver tags, and ideally digests.

2. **How do you guarantee the image tested in staging is the one in production?**
   Build once and promote the same digest. Never rebuild per environment. Tag immutability and deploying by digest enforce it.

3. **How do you deploy to 5 Regions safely?**
   Replicate the image, deploy one Region at a time starting with the smallest, canary inside each Region, bake with alarms, and roll back automatically. Keep APIs and schemas backward-compatible during the version skew.

4. **What's the difference between RPO and RTO?**
   RPO is how much data you can lose. RTO is how long you can be down. They drive the choice between backup-and-restore, pilot light, warm standby, and active-active.

5. **An app in `eu-west-1` needs data whose primary is in `us-east-1`. Options?**
   Read from a local replica (Aurora Global Database) and send writes to the primary, through write forwarding or private inter-Region networking. Or partition data by home Region. Or use multi-active DynamoDB global tables. Handle replication lag and read-your-writes.

6. **What is split brain, and how do you prevent it?**
   Two Regions both accept writes as primary, and their data diverges. Prevent it with one controlled failover mechanism, fencing the old primary, and managed promotion such as Aurora Global Database failover.

7. **Why should failover not depend on creating resources?**
   Control-plane APIs can be impaired during large events, and capacity may be scarce. Pre-deploy and pre-scale, then shift traffic with data-plane mechanisms.

8. **How do you rename a database column without downtime in a multi-Region rollout?**
   Expand and contract: add the new column, write both, backfill, move all reads to the new column, then drop the old one after every Region is on the new code.

## 19. Command reference

| Command | Purpose |
|---|---|
| `aws ecr create-repository --repository-name shop/orders-api --image-tag-mutability IMMUTABLE --image-scanning-configuration scanOnPush=true` | Create a repository with safe defaults |
| `aws ecr put-lifecycle-policy --repository-name ... --lifecycle-policy-text file://lifecycle.json` | Apply cleanup rules |
| `aws ecr start-lifecycle-policy-preview --repository-name ...` | Preview what would be deleted |
| `aws ecr put-replication-configuration --replication-configuration file://replication.json` | Replicate images to other Regions and accounts |
| `aws ecr describe-images --repository-name ... --image-ids imageTag=a1b2c3d --region eu-west-1` | Confirm an image exists in a Region (and read its digest) |
| `aws ecr batch-get-image` + `aws ecr put-image --image-tag v2.4.0` | Add a release tag to an existing image without rebuilding |
| `aws ecr set-repository-policy --repository-name ... --policy-text file://policy.json` | Allow other accounts to pull |
| `aws ecr create-pull-through-cache-rule ...` | Cache public registries in ECR |
| `aws rds create-global-cluster --global-cluster-identifier shop-global --source-db-cluster-identifier <arn>` | Turn an Aurora cluster into a global database |
| `aws rds switchover-global-cluster` / `failover-global-cluster` | Planned switchover or unplanned failover |
| `aws dynamodb update-table --table-name orders --replica-updates '[{"Create":{"RegionName":"eu-west-1"}}]'` | Add a DynamoDB global table replica |
| `aws secretsmanager replicate-secret-to-regions --secret-id ... --add-replica-regions Region=eu-west-1` | Replicate a secret |
| `aws kms create-key --multi-region` / `replicate-key` | Multi-Region KMS key |
