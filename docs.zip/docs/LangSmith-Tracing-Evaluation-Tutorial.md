# LangSmith for LLM Tracing, Evaluation & Monitoring — Complete Tutorial

> LangSmith is LangChain's hosted platform for **observability (tracing), evaluation, prompt management and production monitoring** of LLM apps. It works with LangChain/LangGraph out of the box, but also with plain OpenAI/Anthropic SDK code or any Python/TypeScript app.

> **Version note:** this tutorial uses the `langsmith` Python SDK (0.3+) evaluator style `(inputs, outputs, reference_outputs)` and the `openevals` / `agentevals` helper packages. Older code uses `(run, example)` evaluators and `LANGCHAIN_*` env vars — both still work. Pin your versions in production.

---

## Table of Contents

1. [What is LangSmith](#1-what-is-langsmith)
2. [Setup](#2-setup)
3. [Core Concepts: Projects, Traces, Runs](#3-core-concepts-projects-traces-runs)
4. [Tracing Your App](#4-tracing-your-app)
5. [Datasets and Examples](#5-datasets-and-examples)
6. [Evaluators](#6-evaluators)
7. [Running Experiments with `evaluate()`](#7-running-experiments-with-evaluate)
8. [End-to-End: Evaluating a RAG App](#8-end-to-end-evaluating-a-rag-app)
9. [Evaluating Agents (Trajectories & Tools)](#9-evaluating-agents-trajectories--tools)
10. [Pairwise Comparison & Human Annotation](#10-pairwise-comparison--human-annotation)
11. [Pytest / CI Integration](#11-pytest--ci-integration)
12. [Prompt Hub & Playground](#12-prompt-hub--playground)
13. [Production Monitoring & Online Evaluation](#13-production-monitoring--online-evaluation)
14. [LangSmith vs DeepEval vs Ragas vs Langfuse](#14-langsmith-vs-deepeval-vs-ragas-vs-langfuse)
15. [Cheat Sheet & Interview Questions](#15-cheat-sheet--interview-questions)

---

## 1. What is LangSmith

```
             ┌──────────────────────────── LangSmith ────────────────────────────┐
  your app ─►│  TRACING        →  DATASETS     →  EXPERIMENTS   →  MONITORING      │
  (SDK)      │  every LLM/tool    goldens from    evaluate()       dashboards,     │
             │  call as a tree    traces / CSV    + evaluators     online evals,   │
             │                                    + comparison     alerts          │
             │  PROMPT HUB  ·  PLAYGROUND  ·  ANNOTATION QUEUES  ·  FEEDBACK        │
             └───────────────────────────────────────────────────────────────────┘
```

| Capability | What you get |
|---|---|
| Tracing | Every LLM call, retriever, tool, and chain step as a nested tree with inputs, outputs, latency, tokens, cost, errors |
| Datasets | Versioned collections of input / reference-output examples |
| Evaluation | Run your app over a dataset, score with code / LLM-as-judge / human evaluators, compare experiments side by side |
| Prompt Hub | Versioned prompts, pulled by name/tag from code |
| Playground | Try prompts/models against dataset examples in the UI |
| Annotation queues | Humans review and label runs |
| Monitoring | Dashboards (latency, cost, error rate, feedback), online evaluators on live traffic, alerts |

**Pricing/hosting:** SaaS (US and EU regions) with a free developer tier and paid team plans; self-hosted / BYOC for enterprise. It's **not open source** (the SDK is). Check the LangSmith site for current pricing.

---

## 2. Setup

```bash
pip install -U langsmith openai openevals agentevals langchain-openai
```

```bash
export LANGSMITH_TRACING=true
export LANGSMITH_API_KEY="lsv2_..."          # Settings → API Keys
export LANGSMITH_PROJECT="my-first-project"  # traces go here (default: "default")
# export LANGSMITH_ENDPOINT="https://eu.api.smith.langchain.com"   # EU region
export OPENAI_API_KEY="sk-..."
```

With `LANGSMITH_TRACING=true`, **LangChain and LangGraph apps are traced automatically** — no code changes.

---

## 3. Core Concepts: Projects, Traces, Runs

| Concept | Meaning |
|---|---|
| **Project** | A bucket of traces (e.g., one per app / environment: `support-bot-prod`, `support-bot-dev`) |
| **Trace** | One end-to-end request (e.g., one user question) |
| **Run** (span) | One step inside a trace: an LLM call, retriever, tool, chain. Runs nest into a tree. |
| **Run type** | `llm`, `chain`, `tool`, `retriever`, `embedding`, `prompt`, `parser` — controls how the UI renders it |
| **Thread** | Multiple traces grouped into a conversation (via `session_id` / `thread_id` metadata) |
| **Feedback** | A score attached to a run (from a user 👍, an evaluator, or an annotator) |
| **Dataset / Example** | Test inputs + reference outputs |
| **Experiment** | Results of running a target function over a dataset with evaluators |

```
Trace: "rag_pipeline"  (chain, 1.8s, $0.0012)
 ├── retrieve           (retriever, 0.2s)   inputs: query   outputs: 3 docs
 ├── ChatOpenAI         (llm, 1.5s, 812 tokens)
 └── format_answer      (parser, 0.01s)
```

---

## 4. Tracing Your App

### 4.1 Wrap the OpenAI client

```python
from openai import OpenAI
from langsmith.wrappers import wrap_openai

client = wrap_openai(OpenAI())   # every call is now traced as an `llm` run

client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Hello!"}],
)
```

(`wrap_anthropic` exists for the Anthropic SDK.)

### 4.2 `@traceable` for your own functions

```python
from langsmith import traceable

@traceable(run_type="retriever")
def retrieve(query: str) -> list[str]:
    return ["Refunds are allowed within 30 days."]

@traceable(run_type="llm")   # optional — wrap_openai already traces the call
def generate(query: str, docs: list[str]) -> str:
    ctx = "\n".join(docs)
    r = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "system", "content": f"Answer from context:\n{ctx}"},
                  {"role": "user", "content": query}],
    )
    return r.choices[0].message.content

@traceable(name="rag_pipeline", tags=["v1"], metadata={"top_k": 3})
def rag(query: str) -> str:
    return generate(query, retrieve(query))

rag("What is the refund window?")
```

Nested `@traceable` calls automatically become child runs.

### 4.3 Adding metadata, tags, threads at runtime

```python
from langsmith import traceable
import langsmith as ls

@traceable
def chat(question: str, user_id: str, session_id: str):
    ...

chat("hi", user_id="u_42", session_id="s_7",
     langsmith_extra={"metadata": {"user_id": "u_42", "session_id": "s_7"}, "tags": ["beta"]})

# or temporarily set context
with ls.tracing_context(project_name="experiments", tags=["ab-test-b"]):
    rag("...")
```

Using `session_id` / `thread_id` metadata groups traces into a **thread** (a conversation view).

### 4.4 LangChain / LangGraph

```python
from langchain_openai import ChatOpenAI
ChatOpenAI(model="gpt-4o-mini").invoke("Hello")   # traced automatically with LANGSMITH_TRACING=true
```

Pass `config={"tags": [...], "metadata": {...}, "run_name": "..."}` to `.invoke()` to enrich runs.

### 4.5 Other tracing options

- **OpenTelemetry** ingestion — send OTel spans from any language/framework.
- Integrations: OpenAI Agents SDK, Vercel AI SDK, Anthropic, Instructor, LlamaIndex, CrewAI, etc.
- **Masking:** hide sensitive inputs/outputs (`LANGSMITH_HIDE_INPUTS=true`, or custom `hide_inputs`/`hide_outputs` functions on the `Client`).
- **Sampling:** `LANGSMITH_TRACING_SAMPLING_RATE=0.1` to trace 10% of production traffic.

### 4.6 User feedback

Attach end-user 👍/👎 to a trace:

```python
from langsmith import Client, get_current_run_tree

ls_client = Client()

@traceable
def answer(q: str):
    run = get_current_run_tree()
    out = rag(q)
    return out, run.id

out, run_id = answer("What is the refund window?")
ls_client.create_feedback(run_id, key="user_thumbs", score=1, comment="helpful")
```

---

## 5. Datasets and Examples

A **dataset** is a list of **examples**, each with `inputs`, optional `outputs` (reference), and `metadata`.

### 5.1 Create in code

```python
from langsmith import Client

client = Client()

dataset = client.create_dataset(
    dataset_name="support-bot-qa",
    description="Refund/shipping/warranty questions with reference answers",
)

client.create_examples(
    dataset_id=dataset.id,
    examples=[
        {"inputs": {"question": "How long do I have to return an item?"},
         "outputs": {"answer": "Within 30 days of purchase, if unused."},
         "metadata": {"topic": "refund"}},
        {"inputs": {"question": "How much is express shipping?"},
         "outputs": {"answer": "$15, 1-2 business days within the US."},
         "metadata": {"topic": "shipping"}},
        {"inputs": {"question": "Do you sell gift cards?"},
         "outputs": {"answer": "I don't know."},
         "metadata": {"topic": "out_of_scope"}},
    ],
)
```

### 5.2 Other ways to build datasets

- **Upload CSV / JSONL** in the UI or `client.upload_csv(...)`.
- **From production traces:** in the UI, select runs → "Add to dataset" (the best source of realistic examples — especially failures and 👎 traces).
- **Automation rules:** automatically add traces matching a filter (e.g., negative feedback) to a dataset.
- **Synthetic generation** in the UI, or generate with Ragas/DeepEval and upload.

### 5.3 Versioning & splits

- Every change creates a new **dataset version**; experiments record which version they used. You can tag versions (`client.update_dataset_tag(...)`) and evaluate against `as_of="prod"`.
- **Splits** (e.g., `train`, `test`, `hard`) let you evaluate a subset: `data=client.list_examples(dataset_name="support-bot-qa", splits=["hard"])`.
- **Schemas:** define JSON schemas for inputs/outputs so bad examples are rejected.

---

## 6. Evaluators

An **evaluator** is a function that scores one example run. LangSmith supports four kinds:

| Type | How it scores | Example |
|---|---|---|
| **Code / heuristic** | Python logic | exact match, JSON valid, contains citation, latency < 2s |
| **LLM-as-judge** | An LLM grades with a prompt | correctness, helpfulness, groundedness |
| **Human** | Annotators in the UI / annotation queues | expert review |
| **Pairwise** | Compare two experiments' outputs | "Is A better than B?" |

Plus **summary evaluators** that score a whole experiment (e.g., precision/recall/F1 across all examples).

### 6.1 Evaluator signature

```python
def my_evaluator(inputs: dict, outputs: dict, reference_outputs: dict) -> bool | float | dict:
    ...
```

- `inputs` = example inputs, `outputs` = what your target returned, `reference_outputs` = example's reference outputs.
- You can also accept `run` and `example` objects (full run tree — useful for latency, intermediate steps).
- Return a `bool`, a number, or a dict `{"key": "name", "score": 0.8, "comment": "why"}` (or a list of dicts for multiple metrics). The function name is used as the key if you return a bare value.

### 6.2 Code evaluators

```python
def exact_match(outputs: dict, reference_outputs: dict) -> bool:
    return outputs["answer"].strip().lower() == reference_outputs["answer"].strip().lower()

def concise(outputs: dict) -> bool:
    return len(outputs["answer"].split()) <= 60

def latency_under_2s(run, example) -> dict:
    secs = (run.end_time - run.start_time).total_seconds()
    return {"key": "latency_ok", "score": secs < 2, "comment": f"{secs:.2f}s"}
```

### 6.3 LLM-as-judge with `openevals`

`openevals` provides prebuilt judge prompts and a factory:

```python
from openevals.llm import create_llm_as_judge
from openevals.prompts import CORRECTNESS_PROMPT, CONCISENESS_PROMPT

correctness_judge = create_llm_as_judge(
    prompt=CORRECTNESS_PROMPT,
    model="openai:gpt-4o",
    feedback_key="correctness",
)

def correctness(inputs: dict, outputs: dict, reference_outputs: dict):
    return correctness_judge(
        inputs=inputs,
        outputs=outputs,
        reference_outputs=reference_outputs,
    )   # → {"key": "correctness", "score": True/False, "comment": "..."}
```

Other prebuilt prompts include conciseness, hallucination, and RAG-oriented ones (groundedness, retrieval relevance, helpfulness). Use `continuous=True` for 0–1 scores or `choices=[0, 0.5, 1]` for discrete ones.

### 6.4 Custom LLM judge (structured output)

```python
from typing_extensions import TypedDict, Annotated
from langchain_openai import ChatOpenAI

class Grade(TypedDict):
    reasoning: Annotated[str, ..., "Explain your reasoning step by step."]
    grounded: Annotated[bool, ..., "True if every claim is supported by the documents."]

grader = ChatOpenAI(model="gpt-4o", temperature=0).with_structured_output(Grade, method="json_schema", strict=True)

def groundedness(inputs: dict, outputs: dict) -> dict:
    docs = "\n\n".join(outputs["documents"])
    g = grader.invoke([
        {"role": "system", "content": "You check whether an answer is fully supported by the documents."},
        {"role": "user", "content": f"DOCUMENTS:\n{docs}\n\nANSWER:\n{outputs['answer']}"},
    ])
    return {"key": "groundedness", "score": g["grounded"], "comment": g["reasoning"]}
```

### 6.5 Using DeepEval or Ragas metrics inside LangSmith

Any metric library can be an evaluator — just wrap it:

```python
from deepeval.metrics import FaithfulnessMetric
from deepeval.test_case import LLMTestCase

def deepeval_faithfulness(inputs: dict, outputs: dict) -> dict:
    m = FaithfulnessMetric()
    m.measure(LLMTestCase(input=inputs["question"], actual_output=outputs["answer"],
                          retrieval_context=outputs["documents"]))
    return {"key": "faithfulness", "score": m.score, "comment": m.reason}
```

### 6.6 Summary evaluators

```python
def pass_rate(outputs: list[dict], reference_outputs: list[dict]) -> dict:
    hits = sum(o["answer"].strip().lower() == r["answer"].strip().lower()
               for o, r in zip(outputs, reference_outputs))
    return {"key": "exact_match_rate", "score": hits / len(outputs)}
```

---

## 7. Running Experiments with `evaluate()`

### 7.1 The basic call

```python
from langsmith import Client

client = Client()

def target(inputs: dict) -> dict:
    return {"answer": rag(inputs["question"])}   # your app

results = client.evaluate(
    target,
    data="support-bot-qa",                    # dataset name (or list of examples)
    evaluators=[correctness, concise, exact_match],
    summary_evaluators=[pass_rate],
    experiment_prefix="rag-gpt4o-mini-k3",
    metadata={"model": "gpt-4o-mini", "top_k": 3, "prompt_version": "v2"},
    max_concurrency=4,
    num_repetitions=1,                        # >1 to measure variance of a stochastic app
)

results.to_pandas()   # local inspection
```

Each call creates an **experiment** in the UI under the dataset, with per-example outputs, evaluator scores, comments (judge reasoning) and links to full traces.

### 7.2 Comparing experiments

Run `evaluate()` again with a different config (`experiment_prefix="rag-gpt4o-k5"`), then in the UI select both experiments → **Compare**: side-by-side outputs, score deltas, and highlighted regressions/improvements per example.

### 7.3 Re-scoring an existing experiment

Add a new evaluator later without re-running the app:

```python
from langsmith import evaluate
evaluate("rag-gpt4o-mini-k3-<id>", evaluators=[groundedness])   # pass the experiment name/ID
```

### 7.4 Evaluating LangChain runnables / LangGraph graphs directly

```python
client.evaluate(
    chain.invoke,                # or graph.invoke
    data="support-bot-qa",
    evaluators=[correctness],
)
```

Make sure the example `inputs` keys match what the runnable expects (or adapt with a small target wrapper).

### 7.5 Async

`client.aevaluate(async_target, data=..., evaluators=[...])` for async apps — much faster for large datasets.

---

## 8. End-to-End: Evaluating a RAG App

### 8.1 App (traced)

```python
# rag_app.py
from langsmith import traceable
from langsmith.wrappers import wrap_openai
from openai import OpenAI
import numpy as np

client = wrap_openai(OpenAI())

DOCS = [
    "Refund policy: customers may request a full refund within 30 days of purchase. Items must be unused.",
    "Shipping: we ship to 40 countries. Standard shipping takes 5-7 business days.",
    "Express shipping costs $15 and takes 1-2 business days within the US.",
    "Warranty: electronics carry a 1-year limited warranty covering manufacturing defects.",
    "Support hours: Monday to Friday, 9am to 6pm EST. Email support@acme.com.",
]

def _embed(texts):
    r = client.embeddings.create(model="text-embedding-3-small", input=texts)
    return np.array([d.embedding for d in r.data])

DOC_EMB = _embed(DOCS)

@traceable(run_type="retriever")
def retrieve(question: str, k: int = 3) -> list[str]:
    q = _embed([question])[0]
    sims = DOC_EMB @ q / (np.linalg.norm(DOC_EMB, axis=1) * np.linalg.norm(q))
    return [DOCS[i] for i in np.argsort(-sims)[:k]]

@traceable(name="rag")
def rag(question: str, k: int = 3) -> dict:
    docs = retrieve(question, k)
    r = client.chat.completions.create(
        model="gpt-4o-mini", temperature=0,
        messages=[
            {"role": "system", "content": "Answer ONLY from the context. If the answer isn't there, say you don't know.\n\nContext:\n" + "\n".join(docs)},
            {"role": "user", "content": question},
        ],
    )
    return {"answer": r.choices[0].message.content, "documents": docs}
```

Returning `documents` in the output lets evaluators inspect retrieval without digging into child runs.

### 8.2 The four RAG evaluators

```python
# rag_evaluators.py
from typing_extensions import TypedDict, Annotated
from langchain_openai import ChatOpenAI

judge = ChatOpenAI(model="gpt-4o", temperature=0)

def _bool_judge(name: str, instructions: str):
    class Out(TypedDict):
        reasoning: Annotated[str, ..., "Step-by-step reasoning"]
        score: Annotated[bool, ..., "Final verdict"]
    llm = judge.with_structured_output(Out, method="json_schema", strict=True)
    def run(prompt: str) -> dict:
        r = llm.invoke([{"role": "system", "content": instructions}, {"role": "user", "content": prompt}])
        return {"key": name, "score": r["score"], "comment": r["reasoning"]}
    return run

_correct = _bool_judge("correctness",
    "Grade whether the STUDENT ANSWER is factually consistent with the GROUND TRUTH. Extra correct info is fine.")
_relevant = _bool_judge("relevance",
    "Grade whether the ANSWER directly and helpfully addresses the QUESTION.")
_grounded = _bool_judge("groundedness",
    "Grade whether every claim in the ANSWER is supported by the FACTS. Unsupported claims → False.")
_retrieval = _bool_judge("retrieval_relevance",
    "Grade whether the FACTS contain information relevant to the QUESTION. Irrelevant only → False.")

def correctness(inputs, outputs, reference_outputs):
    return _correct(f"QUESTION: {inputs['question']}\nGROUND TRUTH: {reference_outputs['answer']}\nSTUDENT ANSWER: {outputs['answer']}")

def relevance(inputs, outputs):
    return _relevant(f"QUESTION: {inputs['question']}\nANSWER: {outputs['answer']}")

def groundedness(inputs, outputs):
    return _grounded(f"FACTS: {' '.join(outputs['documents'])}\nANSWER: {outputs['answer']}")

def retrieval_relevance(inputs, outputs):
    return _retrieval(f"QUESTION: {inputs['question']}\nFACTS: {' '.join(outputs['documents'])}")
```

| Evaluator | Compares | Catches |
|---|---|---|
| correctness | answer vs reference | wrong answers |
| relevance | answer vs question | off-topic / evasive answers |
| groundedness | answer vs retrieved docs | hallucination |
| retrieval_relevance | docs vs question | bad retrieval |

### 8.3 Run experiments

```python
# run_eval.py
from langsmith import Client
from rag_app import rag
from rag_evaluators import correctness, relevance, groundedness, retrieval_relevance

client = Client()

for k in [1, 3, 5]:
    client.evaluate(
        lambda inputs, k=k: rag(inputs["question"], k=k),
        data="support-bot-qa",
        evaluators=[correctness, relevance, groundedness, retrieval_relevance],
        experiment_prefix=f"rag-k{k}",
        metadata={"top_k": k, "model": "gpt-4o-mini"},
        max_concurrency=4,
    )
```

Open the dataset in LangSmith → compare `rag-k1`, `rag-k3`, `rag-k5`. Click any failing cell to open the trace and see exactly which documents were retrieved and what the judge reasoned.

---

## 9. Evaluating Agents (Trajectories & Tools)

Agent evaluation in LangSmith typically has three levels:

| Level | Question | How |
|---|---|---|
| **Final response** | Did the agent give the right answer / complete the task? | LLM-judge on final output vs reference |
| **Trajectory** | Did it call the right tools in a sensible order? | `agentevals` trajectory match or trajectory LLM-judge |
| **Single step** | Given this state, did it pick the right next action? | Evaluate one node (e.g., the router) in isolation |

### 9.1 A LangGraph agent

```python
# agent.py
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent

@tool
def get_weather(city: str) -> str:
    """Get current weather for a city."""
    return {"paris": "18°C cloudy", "tokyo": "22°C sunny"}.get(city.lower(), "20°C")

@tool
def convert_currency(amount: float, src: str, dst: str) -> str:
    """Convert an amount between ISO currency codes."""
    rate = {("USD", "EUR"): 0.93, ("EUR", "USD"): 1.08}.get((src, dst), 1)
    return f"{amount * rate:.2f} {dst}"

agent = create_react_agent(ChatOpenAI(model="gpt-4o-mini", temperature=0),
                           tools=[get_weather, convert_currency])
```

### 9.2 Dataset with reference trajectories

```python
from langsmith import Client
client = Client()

ds = client.create_dataset(dataset_name="travel-agent")
client.create_examples(dataset_id=ds.id, examples=[
    {"inputs": {"question": "What's the weather in Paris?"},
     "outputs": {"answer": "18°C and cloudy", "tools": ["get_weather"]}},
    {"inputs": {"question": "Convert 100 USD to EUR"},
     "outputs": {"answer": "93 EUR", "tools": ["convert_currency"]}},
    {"inputs": {"question": "Tell me a fun travel fact"},
     "outputs": {"answer": "any reasonable fact", "tools": []}},
])
```

### 9.3 Target + evaluators

```python
from agentevals.trajectory.llm import create_trajectory_llm_as_judge, TRAJECTORY_ACCURACY_PROMPT
from openevals.llm import create_llm_as_judge
from openevals.prompts import CORRECTNESS_PROMPT
from agent import agent

def target(inputs: dict) -> dict:
    result = agent.invoke({"messages": [("user", inputs["question"])]})
    msgs = result["messages"]
    tools_called = [tc["name"] for m in msgs for tc in (getattr(m, "tool_calls", None) or [])]
    return {"answer": msgs[-1].content, "tools": tools_called, "messages": msgs}

# 1. Final answer
_correct = create_llm_as_judge(prompt=CORRECTNESS_PROMPT, model="openai:gpt-4o", feedback_key="correctness")
def final_answer(inputs, outputs, reference_outputs):
    return _correct(inputs=inputs["question"], outputs=outputs["answer"],
                    reference_outputs=reference_outputs["answer"])

# 2. Exact tool sequence (deterministic)
def tool_sequence(outputs, reference_outputs) -> bool:
    return outputs["tools"] == reference_outputs["tools"]

# 3. Trajectory quality (LLM judge over full message history)
_traj = create_trajectory_llm_as_judge(prompt=TRAJECTORY_ACCURACY_PROMPT, model="openai:gpt-4o")
def trajectory_quality(outputs):
    return _traj(outputs=outputs["messages"])

client.evaluate(
    target,
    data="travel-agent",
    evaluators=[final_answer, tool_sequence, trajectory_quality],
    experiment_prefix="react-agent-gpt4o-mini",
)
```

`agentevals` also has `create_trajectory_match_evaluator(trajectory_match_mode="strict" | "unordered" | "subset" | "superset")` to compare against a full reference message trajectory, including tool arguments.

### 9.4 Tips for agents

- **Mock tools** with deterministic fake data so experiments are repeatable.
- Use `num_repetitions=3+` — agents are stochastic; look at pass rate.
- Check the **trace tree** of failures: you'll see each LLM decision, each tool input/output, and where it went wrong.
- Track **step count, tokens and cost** per experiment (available in the experiment view) alongside quality.

---

## 10. Pairwise Comparison & Human Annotation

### 10.1 Pairwise evaluation

When absolute scoring is hard (e.g., "which summary is better?"), compare two experiments head to head:

```python
from langsmith import evaluate

def prefer_better(inputs: dict, outputs: list[dict]) -> list[int]:
    a, b = outputs[0]["answer"], outputs[1]["answer"]
    verdict = judge.invoke(
        f"Question: {inputs['question']}\nAnswer A: {a}\nAnswer B: {b}\n"
        "Which answer is more helpful and correct? Reply only 'A' or 'B'."
    ).content.strip()
    return [1, 0] if verdict.startswith("A") else [0, 1]

evaluate(("rag-k3-<id>", "rag-k5-<id>"), evaluators=[prefer_better], randomize_order=True)
```

`randomize_order=True` reduces the judge's position bias.

### 10.2 Annotation queues (human evaluation)

1. Create an **annotation queue** in the UI with a rubric (feedback keys, e.g., `correct`, `tone 1–5`).
2. Send runs to it — manually, from an experiment, or via automation rules (e.g., all 👎 traces).
3. Reviewers step through runs, score them, optionally edit the output and **add it to a dataset** as a corrected reference.

Human labels are also how you **calibrate LLM judges**: compare judge scores to human scores on the same runs.

---

## 11. Pytest / CI Integration

LangSmith has a pytest plugin that logs each test as an experiment row.

```python
# tests/test_rag.py
import pytest
from langsmith import testing as t
from rag_app import rag
from rag_evaluators import groundedness, correctness

@pytest.mark.langsmith
@pytest.mark.parametrize("question, reference", [
    ("How long do I have to return an item?", "Within 30 days of purchase, if unused."),
    ("How much is express shipping?", "$15, 1-2 business days within the US."),
])
def test_rag_answer(question, reference):
    t.log_inputs({"question": question})
    t.log_reference_outputs({"answer": reference})

    out = rag(question)
    t.log_outputs(out)

    g = groundedness({"question": question}, out)
    c = correctness({"question": question}, out, {"answer": reference})
    t.log_feedback(key="groundedness", score=g["score"])
    t.log_feedback(key="correctness", score=c["score"])

    assert g["score"], g["comment"]
    assert c["score"], c["comment"]
```

```bash
pytest tests/test_rag.py --langsmith-output
```

Results show up as an experiment in LangSmith (dataset auto-created from the test file), while pytest still gives a pass/fail exit code for CI.

GitHub Actions:

```yaml
- name: LLM evals
  env:
    LANGSMITH_API_KEY: ${{ secrets.LANGSMITH_API_KEY }}
    LANGSMITH_TRACING: "true"
    OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
  run: pytest tests/ --langsmith-output
```

Alternative CI pattern: a script that runs `client.evaluate(...)`, reads `results.to_pandas()`, and exits non-zero if average scores fall below thresholds.

---

## 12. Prompt Hub & Playground

### 12.1 Versioned prompts

```python
from langsmith import Client
from langchain_core.prompts import ChatPromptTemplate

client = Client()

prompt = ChatPromptTemplate.from_messages([
    ("system", "Answer ONLY from the context. If unsure, say you don't know.\n\nContext:\n{context}"),
    ("user", "{question}"),
])
client.push_prompt("support-rag-prompt", object=prompt)      # creates a new commit

p = client.pull_prompt("support-rag-prompt")                 # latest
p_prod = client.pull_prompt("support-rag-prompt:prod")       # by tag (set tags in the UI)
```

Pulling prompts by tag lets non-engineers update prompts in the UI and promote them (`dev` → `prod`) without a code deploy — with evaluation in between.

### 12.2 Playground

- Open any LLM run or prompt in the **Playground**, tweak the prompt/model/params, re-run.
- Run a prompt over an **entire dataset** from the playground with evaluators attached — quick prompt experiments without writing code.

---

## 13. Production Monitoring & Online Evaluation

### 13.1 Dashboards

Per project: trace volume, latency (p50/p99), error rate, token usage, **cost**, feedback scores over time. Custom dashboards can filter by metadata (model, prompt version, customer tier).

### 13.2 Online evaluators

Attach evaluators to a **project** so they run automatically on (a sample of) live traces:

- **LLM-as-judge** rules configured in the UI (e.g., "flag answers not grounded in retrieved docs", "detect toxic responses").
- **Code evaluators** (Python) for format/latency/PII checks.
- Filter + sampling rate (e.g., 10% of traces where `metadata.env == "prod"`).

Since production traffic has **no reference outputs**, online evaluators must be **reference-free**: groundedness, relevance, toxicity, format, refusal detection.

### 13.3 Automation rules & alerts

- Rule examples: "if feedback `user_thumbs` = 0 → add to annotation queue", "if online `groundedness` = False → add to `hard-cases` dataset".
- **Alerts** on error rate, latency, or feedback-score thresholds (webhooks / PagerDuty / Slack).

### 13.4 The improvement flywheel

```
 production traces ──► online evals + user feedback ──► failures to annotation queue
        ▲                                                       │
        │                                                       ▼
  deploy new version ◄── offline experiments pass ◄── corrected examples added to dataset
```

This loop is LangSmith's main value: real failures become regression tests.

---

## 14. LangSmith vs DeepEval vs Ragas vs Langfuse

| Aspect | LangSmith | DeepEval | Ragas | Langfuse |
|---|---|---|---|---|
| Type | Hosted platform (SDK open source) | Open-source library (+ Confident AI platform) | Open-source library | Open-source platform (self-host or cloud) |
| Main strength | Tracing + experiments + monitoring, deep LangChain/LangGraph integration | Pytest-style metrics, G-Eval/DAG, agent metrics | RAG metrics, synthetic test sets | Open-source tracing, prompt mgmt, evals |
| Built-in metrics | Few (bring your own via openevals/agentevals or custom) | 50+ | ~30, RAG focused | Few built-in; LLM-judge templates |
| UI for traces/experiments | Excellent | Via Confident AI | Light | Very good |
| Self-host | Enterprise only | N/A (library) | N/A (library) | Yes, free |
| Framework lock-in | Works anywhere, best with LangChain | None | None | None |

**Common combinations:**
- LangSmith for tracing/experiments + DeepEval or Ragas metrics as evaluators.
- Langfuse (self-hosted) + Ragas/DeepEval when data must stay in-house.

---

## 15. Cheat Sheet & Interview Questions

### 15.1 Cheat sheet

```python
# env: LANGSMITH_TRACING=true  LANGSMITH_API_KEY=...  LANGSMITH_PROJECT=...

from langsmith import Client, traceable, evaluate
from langsmith.wrappers import wrap_openai
from langsmith import testing as t                      # pytest plugin helpers
from openevals.llm import create_llm_as_judge
from openevals.prompts import CORRECTNESS_PROMPT, CONCISENESS_PROMPT
from agentevals.trajectory.match import create_trajectory_match_evaluator
from agentevals.trajectory.llm import create_trajectory_llm_as_judge

client = Client()
client.create_dataset(dataset_name="...")
client.create_examples(dataset_id=..., examples=[{"inputs": {...}, "outputs": {...}}])
client.evaluate(target, data="...", evaluators=[...], experiment_prefix="...", max_concurrency=4)
client.create_feedback(run_id, key="user_thumbs", score=1)
client.push_prompt("name", object=prompt); client.pull_prompt("name:prod")

@traceable(run_type="retriever" | "llm" | "tool" | "chain")
def step(...): ...

def evaluator(inputs, outputs, reference_outputs) -> bool | float | dict: ...
```

### 15.2 Interview questions

1. **Trace vs run?** A trace is one end-to-end request; runs are the nested steps (LLM call, retriever, tool) inside it.
2. **How do you add tracing to non-LangChain code?** `wrap_openai` / `wrap_anthropic` for SDK clients, `@traceable` for your functions, or OpenTelemetry.
3. **What is an experiment?** The result of running a target over a dataset version with evaluators — outputs, scores, traces — comparable with other experiments.
4. **Evaluator types?** Code/heuristic, LLM-as-judge, human (annotation queues), pairwise; plus summary evaluators over the whole experiment.
5. **Offline vs online evaluation?** Offline = experiments on a curated dataset with references (pre-deploy, CI). Online = reference-free evaluators on live traces (monitoring).
6. **How do you evaluate an agent in LangSmith?** Final-response correctness, trajectory evaluators (match against reference tool calls or LLM-judge the trajectory), and single-step evals of key decisions; inspect traces for failures.
7. **How do you build a good dataset?** Start with hand-written examples, add failing/👎 production traces via rules and annotation queues, use splits, version and tag datasets.
8. **How do you reduce LLM-judge bias in pairwise evals?** Randomise order, use structured output with reasoning, calibrate against human labels, use a stronger judge than the app model.
9. **Why use Prompt Hub tags?** Decouple prompt changes from code deploys; promote a tested prompt version (`dev` → `prod`) after experiments pass.
10. **LangSmith vs DeepEval?** LangSmith is a platform (tracing, datasets, experiment UI, monitoring); DeepEval is a metrics/testing library. They complement each other — DeepEval metrics can run as LangSmith evaluators.
