# DeepEval for LLM, RAG & Agent Evaluation — Complete Tutorial

> Covers lectures 112–125: DeepEval intro, Goldens & `LLMTestCase`, the evaluation pipeline, G-Eval / DAG / QAG metrics (concept + implementation), RAG evaluation, and AI-agent evaluation.

---

## Table of Contents

1. [Introduction to DeepEval (112)](#1-introduction-to-deepeval-112)
2. [Goldens, LLMTestCases and the Evaluation Pipeline (113)](#2-goldens-llmtestcases-and-the-evaluation-pipeline-113)
3. [The Complete LLM Evaluation Pipeline (114)](#3-the-complete-llm-evaluation-pipeline-114)
4. [Metrics Overview: G-Eval, DAG, QAG (115)](#4-metrics-overview-g-eval-dag-qag-115)
5. [G-Eval: How It Works (116)](#5-g-eval-how-it-works-116)
6. [G-Eval: Implementation (117)](#6-g-eval-implementation-117)
7. [DAG: How It Works (118)](#7-dag-how-it-works-118)
8. [DAG: Implementation (119)](#8-dag-implementation-119)
9. [QAG Explained + Custom QAG Metric (120)](#9-qag-explained--custom-qag-metric-120)
10. [RAG Evaluation Metrics (121)](#10-rag-evaluation-metrics-121)
11. [Evaluating a RAG Pipeline with DeepEval (122)](#11-evaluating-a-rag-pipeline-with-deepeval-122)
12. [Understanding AI Agent Evaluation (123)](#12-understanding-ai-agent-evaluation-123)
13. [Agentic Evaluation Metrics (124)](#13-agentic-evaluation-metrics-124)
14. [Evaluating an AI Agent with DeepEval (125)](#14-evaluating-an-ai-agent-with-deepeval-125)
15. [Cheat Sheet & Interview Questions](#15-cheat-sheet--interview-questions)

---

## 1. Introduction to DeepEval (112)

### Why evaluate LLM apps at all?

Traditional software has deterministic outputs, so you write `assert add(2, 2) == 4`. LLM apps are **non-deterministic** and their outputs are **open-ended text**, so:

- Exact-match assertions don't work ("Paris" vs "The capital is Paris.").
- Classic NLP scores (BLEU, ROUGE) measure word overlap, not meaning or correctness.
- A prompt tweak, model upgrade, or retriever change can silently degrade quality.

You need **semantic, criteria-based scoring** that can run in CI like unit tests. That is what DeepEval provides.

### What is DeepEval?

DeepEval (by Confident AI) is an open-source **"Pytest for LLMs"**:

| Feature | What it gives you |
|---|---|
| 50+ ready metrics | Answer relevancy, faithfulness, hallucination, bias, toxicity, contextual precision/recall, tool correctness, task completion, … |
| Custom metrics | G-Eval (criteria in plain English), DAG (decision trees), or fully custom `BaseMetric` |
| Pytest integration | `deepeval test run test_x.py`, `assert_test(...)` — fits CI/CD |
| Datasets & Goldens | Versioned evaluation datasets, synthetic data generation |
| Tracing | `@observe` decorators for component-level evaluation of RAG/agents |
| Any judge model | OpenAI by default; Azure, Anthropic, Gemini, Ollama, or any custom LLM |
| Confident AI (optional) | Hosted dashboard for test-run history, regression comparison |

### LLM-as-a-judge

Most DeepEval metrics use an LLM (the **judge / evaluation model**) to score the output of **your** LLM (the **system under test**). The core design problem DeepEval solves is making the judge *reliable*: well-structured prompts, decomposition into small yes/no questions (QAG), chain-of-thought steps (G-Eval), and decision trees (DAG).

### Install & setup

```bash
pip install -U deepeval
export OPENAI_API_KEY="sk-..."        # default judge model is an OpenAI model

# optional: log results to Confident AI dashboard
deepeval login
```

Use a different judge:

```bash
deepeval set-azure-openai --openai-endpoint=... --openai-api-key=... --deployment-name=... --openai-api-version=...
deepeval set-ollama deepseek-r1:8b      # local judge
deepeval unset-ollama
```

Or pass `model="gpt-4o"` (or a custom `DeepEvalBaseLLM` instance) to any metric.

### Hello world

```python
# test_hello.py
from deepeval import assert_test
from deepeval.test_case import LLMTestCase
from deepeval.metrics import AnswerRelevancyMetric

def test_answer_relevancy():
    test_case = LLMTestCase(
        input="What if these shoes don't fit?",
        actual_output="We offer a 30-day full refund at no extra cost.",
    )
    metric = AnswerRelevancyMetric(threshold=0.7)
    assert_test(test_case, [metric])
```

```bash
deepeval test run test_hello.py
```

---

## 2. Goldens, LLMTestCases and the Evaluation Pipeline (113)

These three concepts are the vocabulary of DeepEval. Get them clear and everything else falls into place.

### 2.1 Golden

A **Golden** is a *reference example* stored in your dataset **before** your app runs. It contains the input and (optionally) what a good answer looks like — but **not** the actual output, because that is generated fresh at evaluation time.

```python
from deepeval.dataset import Golden

golden = Golden(
    input="What is the refund window?",
    expected_output="Customers can request a refund within 30 days of purchase.",
    context=["Refund policy: refunds allowed within 30 days of purchase."],  # ground-truth facts
)
```

Key fields: `input`, `expected_output`, `context`, `expected_tools`, `additional_metadata`, `comments`.

### 2.2 LLMTestCase

An **LLMTestCase** is a *single unit of evaluation*: a Golden **plus** what your app actually produced at runtime.

```python
from deepeval.test_case import LLMTestCase

test_case = LLMTestCase(
    input="What is the refund window?",
    actual_output="You can get a refund within 30 days.",          # from YOUR app
    expected_output="Customers can request a refund within 30 days of purchase.",
    retrieval_context=["Refunds allowed within 30 days of purchase."],  # what YOUR retriever returned
    context=["Refund policy: refunds allowed within 30 days of purchase."],  # ground truth
    tools_called=[],      # for agents (what tools your agent actually called)
    expected_tools=[],    # for agents (what tools it should have called)
)
```

| Parameter | Who provides it | Used by |
|---|---|---|
| `input` | Golden | almost every metric |
| `actual_output` | **your app at runtime** | almost every metric |
| `expected_output` | Golden (human / synthetic) | correctness, contextual precision/recall |
| `context` | Golden (ideal ground truth) | hallucination |
| `retrieval_context` | **your retriever at runtime** | faithfulness, contextual metrics |
| `tools_called` | **your agent at runtime** | tool correctness |
| `expected_tools` | Golden | tool correctness |

> **`context` vs `retrieval_context`** — the classic confusion. `context` is the *ideal* information (ground truth). `retrieval_context` is what your RAG retriever *actually* fetched. Faithfulness checks the answer against `retrieval_context`; Hallucination checks against `context`.

There is also `ConversationalTestCase` (a list of `Turn`s) for multi-turn chatbots, and `MLLMTestCase` for multimodal.

### 2.3 Golden → Test Case

```
Golden (static, in dataset)          Your LLM App              LLMTestCase (dynamic)
┌───────────────────────┐                                    ┌──────────────────────────┐
│ input                 │ ───────► run app(input) ─────────► │ input                    │
│ expected_output       │                │                   │ actual_output     ◄─ new │
│ context               │                └─ retriever ─────► │ retrieval_context ◄─ new │
│ expected_tools        │                └─ tool calls ────► │ tools_called      ◄─ new │
└───────────────────────┘                                    │ expected_output, context │
                                                             └──────────────────────────┘
```

Why separate them? Because goldens are **reusable**: every time you change the prompt/model/retriever, you regenerate test cases from the *same* goldens and compare scores — an apples-to-apples regression test.

### 2.4 EvaluationDataset

```python
from deepeval.dataset import EvaluationDataset, Golden

dataset = EvaluationDataset(goldens=[
    Golden(input="What is the refund window?", expected_output="30 days."),
    Golden(input="Do you ship internationally?", expected_output="Yes, to 40 countries."),
])

# load / save
dataset.save_as(file_type="json", directory="./data")
dataset = EvaluationDataset()
dataset.add_goldens_from_json_file(file_path="./data/goldens.json")
dataset.add_goldens_from_csv_file(file_path="./data/goldens.csv",
                                  input_col_name="question",
                                  expected_output_col_name="answer")
# or push/pull from Confident AI
dataset.push(alias="refund-bot-v1")
dataset.pull(alias="refund-bot-v1")
```

### 2.5 Generating goldens synthetically

When you don't have a labelled dataset, generate one from your documents:

```python
from deepeval.synthesizer import Synthesizer

synthesizer = Synthesizer()  # uses the judge model to generate
goldens = synthesizer.generate_goldens_from_docs(
    document_paths=["policies/refund.pdf", "policies/shipping.md"],
)
dataset = EvaluationDataset(goldens=goldens)
```

The synthesizer chunks docs, builds contexts, generates questions, then **evolves** them (multi-hop, reasoning, comparative, hypothetical) to make harder test inputs.

---

## 3. The Complete LLM Evaluation Pipeline (114)

> This is the "big picture" lecture. Every later section is just one box of this diagram.

### 3.1 The pipeline

```
 ┌──────────────┐   ┌───────────────┐   ┌────────────────┐   ┌──────────────┐   ┌────────────────┐
 │ 1. Define    │──►│ 2. Build      │──►│ 3. Run app on  │──►│ 4. Score with│──►│ 5. Analyze &   │
 │ criteria &   │   │ dataset of    │   │ each golden →  │   │ metrics      │   │ iterate        │
 │ metrics      │   │ Goldens       │   │ LLMTestCases   │   │ (LLM judge)  │   │ (regressions)  │
 └──────────────┘   └───────────────┘   └────────────────┘   └──────────────┘   └───────┬────────┘
        ▲                                                                               │
        └──────────────────── change prompt / model / retriever / tools ◄──────────────┘
```

1. **Define what "good" means.** Pick 2–5 metrics tied to your use case. Too many metrics = noise. Typically: 1–2 generic (relevancy, faithfulness) + 1–3 custom (G-Eval / DAG) for business-specific criteria.
2. **Build goldens.** Real production queries (best), human-written, or synthetic. Cover happy paths, edge cases, adversarial inputs. 50–200 goldens is a good start.
3. **Generate test cases.** Run the *current version* of your app over every golden.
4. **Score.** Each metric produces a `score` (0–1), a `reason`, and `success = score >= threshold`.
5. **Analyze & iterate.** Look at failing cases, read the reasons, fix, rerun. Track scores over time / across versions.

### 3.2 Each metric's output

```python
metric.measure(test_case)
print(metric.score)       # 0.0 – 1.0
print(metric.reason)      # judge's explanation (include_reason=True by default)
print(metric.is_successful())  # score >= threshold
```

Common metric arguments:

| Arg | Meaning |
|---|---|
| `threshold` | pass mark (default 0.5) |
| `model` | judge model, e.g. `"gpt-4o"` or custom `DeepEvalBaseLLM` |
| `include_reason` | ask judge for a reason |
| `strict_mode` | binary: score is 1 or 0, threshold forced to 1 |
| `async_mode` | run judge calls concurrently (default `True`) |
| `verbose_mode` | print intermediate steps (great for debugging) |

### 3.3 Three ways to run evaluation

**A. One-off, standalone metric**

```python
metric = AnswerRelevancyMetric()
metric.measure(test_case)
```

**B. `evaluate()` — bulk, in a script/notebook**

```python
from deepeval import evaluate
from deepeval.dataset import EvaluationDataset
from deepeval.test_case import LLMTestCase
from deepeval.metrics import AnswerRelevancyMetric, GEval
from deepeval.test_case import LLMTestCaseParams

def my_app(question: str) -> str:
    ...  # your LLM call

dataset = EvaluationDataset()
dataset.add_goldens_from_json_file("data/goldens.json")

for golden in dataset.goldens:
    dataset.add_test_case(LLMTestCase(
        input=golden.input,
        actual_output=my_app(golden.input),
        expected_output=golden.expected_output,
    ))

correctness = GEval(
    name="Correctness",
    criteria="Determine whether the actual output is factually correct based on the expected output.",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT, LLMTestCaseParams.EXPECTED_OUTPUT],
)

results = evaluate(test_cases=dataset.test_cases,
                   metrics=[AnswerRelevancyMetric(), correctness])
```

**C. Pytest / CI — `assert_test` + `deepeval test run`**

```python
# tests/test_llm_app.py
import pytest
from deepeval import assert_test
from deepeval.dataset import EvaluationDataset
from deepeval.test_case import LLMTestCase
from deepeval.metrics import AnswerRelevancyMetric
from my_app import my_app

dataset = EvaluationDataset()
dataset.add_goldens_from_json_file("data/goldens.json")

@pytest.mark.parametrize("golden", dataset.goldens)
def test_app(golden):
    test_case = LLMTestCase(input=golden.input, actual_output=my_app(golden.input))
    assert_test(test_case, [AnswerRelevancyMetric(threshold=0.7)])
```

```bash
deepeval test run tests/test_llm_app.py -n 4      # 4 parallel processes
deepeval test run tests/test_llm_app.py -c         # use cache, skip already-evaluated cases
deepeval test run tests/test_llm_app.py -i         # ignore errors (e.g. judge rate limits)
```

GitHub Actions snippet:

```yaml
- name: Run LLM evals
  env:
    OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
  run: |
    pip install deepeval
    deepeval test run tests/test_llm_app.py
```

### 3.4 End-to-end vs component-level evaluation

- **End-to-end (black box):** treat the whole app as one function, evaluate final `input → actual_output`. Simple; tells you *that* it's broken.
- **Component-level (white box):** use tracing (`@observe`) to attach metrics to the retriever, the generator, each tool call, etc. Tells you *where* it's broken. Covered in sections 11 and 14.

### 3.5 Practical tips

- **Pin the judge model** (`model="gpt-4o"`) — changing judges changes scores.
- Judges cost money: `N goldens × M metrics × ~2–5 LLM calls`. Use `-c` caching and a cheaper judge for quick iterations.
- **Calibrate**: hand-label ~30 cases and check the metric agrees with humans before trusting it in CI.
- Read `reason` fields on failures — they're the actual debugging signal.

---

## 4. Metrics Overview: G-Eval, DAG, QAG (115)

All LLM-judge metrics in DeepEval are built on one of three techniques:

| | **G-Eval** | **DAG** | **QAG** |
|---|---|---|---|
| Full name | Generative Evaluation (from the G-Eval paper) | Deep Acyclic Graph | Question-Answer Generation |
| Idea | Judge writes evaluation steps (CoT) from your criteria, then scores 1–10; scores weighted by token probabilities | You build a **decision tree**; judge only makes small decisions at each node; leaves hold fixed scores | Break the evaluation into **closed-ended yes/no questions**; score = fraction of "yes" |
| You write | Criteria in plain English (or explicit steps) | Nodes: tasks, binary / non-binary judgements, verdicts | (built-in metrics) or custom `BaseMetric` |
| Strength | Very flexible, fast to create, good for subjective criteria (tone, helpfulness, correctness) | **Deterministic & explainable**; great for objective, rule-like requirements (format, structure, must-contain) | Most **reliable/reproducible** for factual checks; no arbitrary 1–10 scale |
| Weakness | Less deterministic; score can drift between runs | More effort to design | Needs decomposition (claims/statements) — not suited to vague criteria |
| Used by | `GEval`, conversational G-Eval | `DAGMetric` | Faithfulness, Answer Relevancy, Contextual Precision/Recall/Relevancy, Hallucination, Summarization, Bias, Toxicity |

### Choosing

```
Is the criterion objective, multi-step, rule-like? (format, required sections, "if X then must Y")
   └─ yes → DAG
   └─ no  → Can it be decomposed into atomic facts/statements to verify?
               └─ yes → QAG (use built-in metric, or custom BaseMetric)
               └─ no  → G-Eval (subjective / holistic: tone, coherence, helpfulness)
```

You can **combine** them: a DAG leaf can delegate to a G-Eval metric (see section 8).

---

## 5. G-Eval: How It Works (116)

G-Eval is from the paper *"G-Eval: NLG Evaluation using GPT-4 with Better Human Alignment"* (Liu et al., 2023).

### 5.1 Algorithm

#### Summary

| Step | What happens | LLM call? | Output |
|---|---|---|---|
| 0 | You define `criteria` (or `evaluation_steps`) and `evaluation_params` | — | Metric config |
| 1 | Judge converts `criteria` into 3–5 concrete evaluation steps (chain-of-thought) | Yes (skipped if `evaluation_steps` given) | List of steps |
| 2 | Judge applies the steps to the selected test-case fields and emits a score 0–10 + reason | Yes | Integer score token + logprobs |
| 3 | Score = probability-weighted average over candidate score tokens: \( \sum_i p(i)\cdot i \) | No (math) | e.g. 8.2 |
| 4 | Normalize to 0–1 and compare with `threshold` | No | `score`, `reason`, `success` |

#### The flow

```
 criteria ──► [LLM call 1] ──► evaluation steps          (skipped if you pass evaluation_steps)
                                      │
 test case ───────────────────────────┤
                                      ▼
                              [LLM call 2] ──► "score: 8" + probabilities of tokens 0..10
                                                         │
                                                         ▼
                                      expected value = Σ p(i)·i = 8.2
                                                         │
                                                         ▼
                                      ÷10 → 0.82 → compare with threshold → pass / fail
```

#### Step 0 — You give the criteria

```python
GEval(
    name="Correctness",
    criteria="Check whether the actual output is factually correct compared to the expected output.",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT, LLMTestCaseParams.EXPECTED_OUTPUT],
)
```

#### Step 1 — Judge turns criteria into evaluation steps (LLM call #1)

DeepEval asks the judge: *"Given these criteria, write 3–4 concrete steps to evaluate an output."* The judge returns something like:

```
1. Identify the key facts in the expected output.
2. Check whether each key fact appears in the actual output.
3. Penalize any fact in the actual output that contradicts the expected output.
4. Extra correct details are acceptable.
```

**Why?** Vague criteria → inconsistent grading. A checklist forces the judge to reason the same way every time (chain-of-thought).
If you pass `evaluation_steps=[...]` yourself, this step is **skipped** — which is why custom steps give more stable scores.

#### Step 2 — Judge applies the steps to the test case (LLM call #2)

DeepEval sends the steps plus only the fields listed in `evaluation_params`:

```
Evaluation steps: 1. ... 2. ... 3. ... 4. ...
Expected Output: "World War II ended in 1945."
Actual Output:   "WW2 ended in 1945 when Japan surrendered."
Return a score from 0 to 10 and a reason.
```

Judge replies:

```json
{"score": 8, "reason": "The actual output correctly states 1945 and adds accurate context."}
```

#### Step 3 — Probability-weighted score (the tricky part)

When the LLM writes the token "8", it actually assigned a probability (logprob) to **every** possible score token first:

| Score token | Probability |
|---|---|
| 10 | 0.05 |
| 9 | 0.25 |
| 8 | 0.55 |
| 7 | 0.15 |

Taking only "8" throws away the information that the judge leaned towards 9 quite a lot. G-Eval uses the **expected value** instead:

\[
\text{score} = \sum_i p(i)\cdot i = 0.05\cdot10 + 0.25\cdot9 + 0.55\cdot8 + 0.15\cdot7 = 8.2
\]

**Why?** LLMs keep outputting the same few integers ("7" or "8") for almost everything, so raw scores can't tell a *good* answer from a *great* one. The weighted score is finer-grained (8.2 vs 8.6) and agrees better with human graders. If the judge model doesn't expose logprobs, DeepEval falls back to the plain integer (8).

#### Step 4 — Normalize and compare with the threshold

\[
8.2 / 10 = 0.82 \;\ge\; \text{threshold } (0.5) \;\Rightarrow\; \textbf{PASS}
\]

```python
metric.score            # 0.82
metric.reason           # "The actual output correctly states 1945..."
metric.is_successful()  # True
```

#### Why not just ask "rate this 1–10"?

| Plain "rate 1–10" | G-Eval |
|---|---|
| Vague criteria, so the judge improvises differently each time | Explicit steps, so it reasons the same way each time |
| Coarse integer scores, clustered on 7 and 8 | Probability-weighted scores such as 7.3 or 8.6, which separate answers better |
| No reasoning | Gives a reason you can read to debug |

**In one line:** G-Eval = *work out how to grade → grade → average over the judge's uncertainty* → a smoother, more human-like score.

### 5.2 Demo intuition

Criteria: *"Check whether the actual output is factually correct based on the expected output."*

Generated steps might be:
1. Identify the key facts in the expected output.
2. Check whether each key fact appears in the actual output.
3. Penalise any contradicting facts heavily.
4. Minor omissions of detail are acceptable.

Input: "When did WW2 end?", expected: "1945", actual: "World War II ended in 1945 with Japan's surrender."
→ score ≈ 0.9+, reason: "The actual output states 1945, matching the expected output, and adds accurate context."

### 5.3 Best practices

- **Prefer explicit `evaluation_steps`** in production. Auto-generated steps change between runs → scores less stable.
- Only include the `evaluation_params` the criteria actually needs. Don't pass `EXPECTED_OUTPUT` to a "tone" metric.
- Refer to params by their names in your criteria/steps ("actual output", "expected output") — the judge sees them labelled that way.
- Use a strong judge (GPT-4-class). G-Eval is sensitive to judge quality.
- Add a `rubric` to anchor score ranges (reduces ambiguity).

---

## 6. G-Eval: Implementation (117)

### 6.1 Basic G-Eval from criteria

```python
from deepeval.metrics import GEval
from deepeval.test_case import LLMTestCase, LLMTestCaseParams

correctness = GEval(
    name="Correctness",
    criteria="Determine whether the actual output is factually correct based on the expected output.",
    evaluation_params=[
        LLMTestCaseParams.INPUT,
        LLMTestCaseParams.ACTUAL_OUTPUT,
        LLMTestCaseParams.EXPECTED_OUTPUT,
    ],
    threshold=0.6,
    model="gpt-4o",
    verbose_mode=True,   # prints generated steps
)

tc = LLMTestCase(
    input="When did World War II end?",
    actual_output="It ended in 1946.",
    expected_output="World War II ended in 1945.",
)
correctness.measure(tc)
print(correctness.score, correctness.reason)
# ~0.1  "The actual output states 1946, which contradicts the expected 1945."
```

### 6.2 With explicit evaluation steps (recommended)

```python
correctness = GEval(
    name="Correctness",
    evaluation_steps=[
        "Check whether the facts in 'actual output' contradict any facts in 'expected output'.",
        "Heavily penalize omission of critical details from 'expected output'.",
        "Vague language or differing opinions are OK.",
        "Extra correct information not in 'expected output' should not be penalized.",
    ],
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT, LLMTestCaseParams.EXPECTED_OUTPUT],
)
```

> Pass **either** `criteria` **or** `evaluation_steps`. If both are given, steps win.

### 6.3 With a rubric

```python
from deepeval.metrics.g_eval import Rubric

professionalism = GEval(
    name="Professionalism",
    criteria="Assess whether the actual output is professional and appropriate for a customer-support context.",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
    rubric=[
        Rubric(score_range=(0, 2), expected_outcome="Rude, slang, or offensive."),
        Rubric(score_range=(3, 6), expected_outcome="Neutral but casual or slightly unpolished."),
        Rubric(score_range=(7, 9), expected_outcome="Professional with minor issues."),
        Rubric(score_range=(10, 10), expected_outcome="Fully professional, empathetic and clear."),
    ],
)
```

### 6.4 A few useful custom G-Evals

```python
# 1. Helpfulness / completeness for a support bot
helpfulness = GEval(
    name="Helpfulness",
    evaluation_steps=[
        "Identify what the user in 'input' is trying to achieve.",
        "Check whether 'actual output' gives actionable steps that achieve it.",
        "Penalize answers that deflect, are generic, or ask unnecessary clarifying questions.",
    ],
    evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
)

# 2. PII leakage
pii_leak = GEval(
    name="PII Leakage",
    evaluation_steps=[
        "Check whether 'actual output' contains personal identifiable information: names, emails, phone numbers, addresses, SSN, card numbers.",
        "Score 10 if none is present; score 0 if any real-looking PII is present.",
    ],
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
    strict_mode=True,
)

# 3. Grounded-in-retrieval (G-Eval flavour of faithfulness)
grounded = GEval(
    name="Groundedness",
    evaluation_steps=[
        "List the factual claims in 'actual output'.",
        "For each claim, check whether it is supported by 'retrieval context'.",
        "Penalize every unsupported claim.",
    ],
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT, LLMTestCaseParams.RETRIEVAL_CONTEXT],
)
```

### 6.5 Running a batch

```python
from deepeval import evaluate

test_cases = [
    LLMTestCase(input="How do I reset my password?",
                actual_output="Go to Settings → Security → Reset password and follow the email link."),
    LLMTestCase(input="How do I reset my password?",
                actual_output="lol just make a new account"),
]
evaluate(test_cases=test_cases, metrics=[helpfulness, professionalism])
```

### 6.6 Under the hood (simplified)

```python
# Pseudocode of what GEval.measure() does
steps = evaluation_steps or judge(f"Given criteria: {criteria}, generate 3-4 evaluation steps.")
prompt = f"""
Evaluation steps: {steps}
{rubric_text}
Test case:
  Input: {tc.input}
  Actual Output: {tc.actual_output}
  Expected Output: {tc.expected_output}
Return JSON: {{"score": <0-10>, "reason": "..."}}
"""
response, logprobs = judge_with_logprobs(prompt)
score = weighted_sum(logprobs for score tokens) / 10  # expected value, normalized 0..1
```

---

## 7. DAG: How It Works (118)

### 7.1 The problem DAG solves

G-Eval asks the judge for *one holistic number*. For objective, multi-condition requirements this is fragile:

> "A meeting summary must have the headings *Intro*, *Body*, *Conclusion*, in that order, and the conclusion must contain action items."

A single G-Eval prompt may give 0.7 one run, 0.5 the next. **DAG (Deep Acyclic Graph)** instead turns the rubric into a **decision tree** where the judge makes small, easy, nearly deterministic decisions, and the *final score is fixed by the path taken*.

#### Core idea

- You encode the rubric as a graph of nodes. Each judgement node asks the judge one narrow question (yes/no or pick-one-option).
- The judge's answer selects an outgoing edge. Traversal ends at a `VerdictNode` whose score **you** fixed in advance.
- So the judge does classification, not scoring. Narrow classification questions have low variance, so the metric is near-deterministic.

| | G-Eval | DAG |
|---|---|---|
| Who decides the score? | The judge LLM ("I think it's 7") | **You**, in advance, at each leaf of the tree |
| What does the judge do? | One big holistic judgement | Many tiny yes/no or multiple-choice answers |
| Same input, two runs | Score may drift (0.7 vs 0.6) | Almost always the same path → same score |
| Explaining a score | Read the judge's reason | Read the path: "headings ✓ → order ✗ → 4/10" |

### 7.2 Node types

| Node | Purpose | Output |
|---|---|---|
| `TaskNode` | Do some processing (e.g., "extract all headings") — produces text for downstream nodes | `output_label` text passed to children |
| `BinaryJudgementNode` | Yes/No question | Routes to `VerdictNode(verdict=True/False)` |
| `NonBinaryJudgementNode` | Multiple-choice question | Routes to `VerdictNode(verdict="<option string>")` |
| `VerdictNode` | Leaf (or bridge). Holds a `score` (0–10), **or** a `child` (another judgement node or a G-Eval / other metric) | Final score |

Rules:
- Graph is **acyclic** — no loops.
- Judgement nodes' children must be `VerdictNode`s.
- A `VerdictNode` has **either** `score` **or** `child`, not both.
- `BinaryJudgementNode` must have exactly one `True` and one `False` verdict.

### 7.3 Example tree (meeting summary format)

```mermaid
flowchart TD
    TC["Test case<br/>actual_output = the summary"] --> T

    T["TaskNode<br/>Extract all headings from actual_output<br/>output_label = Summary headings"]
    T --> B

    B{"BinaryJudgementNode<br/>Do the headings contain<br/>Intro, Body and Conclusion?"}
    B -- False --> V0["VerdictNode<br/>score = 0"]
    B -- True --> N

    N{"NonBinaryJudgementNode<br/>Are they in the order<br/>Intro, Body, Conclusion?"}
    N -- "Yes" --> V10["VerdictNode<br/>score = 10"]
    N -- "Two are out of order" --> V4["VerdictNode<br/>score = 4"]
    N -- "All out of order" --> V2["VerdictNode<br/>score = 2"]
```

Plain-text version (for viewers without Mermaid):

```
TaskNode: "Extract all headings from actual_output"   → output_label="Summary headings"
   │
   ▼
BinaryJudgementNode: "Do the headings contain Intro, Body, Conclusion?"
   ├── False → VerdictNode(score=0)
   └── True  → NonBinaryJudgementNode: "Are they in order Intro → Body → Conclusion?"
                   ├── "Yes"                        → VerdictNode(score=10)
                   ├── "Two are out of order"       → VerdictNode(score=4)
                   └── "All out of order"           → VerdictNode(score=2)
```

### 7.4 How scoring flows

| Step | Node | What the judge does | Output |
|---|---|---|---|
| 1 | `TaskNode` | Processing only: extracts the headings from `actual_output` | List of headings, passed down as "Summary headings" |
| 2 | `BinaryJudgementNode` | Answers one yes/no question about that list | `True` / `False`, which selects the next edge |
| 3 | `NonBinaryJudgementNode` | Picks exactly one option from a fixed list | One option string, which selects the next edge |
| 4 | `VerdictNode` | Nothing; it's a leaf with a preset score | score ÷ 10 = metric score |

1. Root `TaskNode` runs once (LLM extracts headings).
2. Each judgement node receives the task output (+ the test-case params you configured) and picks one verdict.
3. Traversal continues until a `VerdictNode` with a `score` is reached; that score / 10 is the metric score.
4. The reason is built from the path: "Headings present ✓ → order correct ✓ → 10/10".

#### Walkthrough: four summaries through the same tree

| Summary headings | Step 1: extracted | Step 2: all three present? | Step 3: order | Leaf | Final score |
|---|---|---|---|---|---|
| Intro, Body, Conclusion | `[Intro, Body, Conclusion]` | True | "Yes" | 10 | **1.0** ✅ |
| Body, Intro, Conclusion | `[Body, Intro, Conclusion]` | True | "Two are out of order" | 4 | **0.4** ❌ |
| Conclusion, Body, Intro | `[Conclusion, Body, Intro]` | True | "All out of order" | 2 | **0.2** ❌ |
| Intro, Body (no conclusion) | `[Intro, Body]` | **False** | never asked | 0 | **0.0** ❌ |

The last row short-circuits: once a check fails, the later questions are never asked, so there are fewer LLM calls.

Path taken for the second row (`Body, Intro, Conclusion`):

```mermaid
flowchart LR
    T["Extract headings<br/>Body, Intro, Conclusion"] --> B{"All 3 present?"}
    B -- "True" --> N{"Order?"}
    N -- "Two are out of order" --> V["score = 4<br/>final = 0.4"]
```

Reason generated from the path: *"All three headings present, but two are out of order, score 4/10."*

Notice:
- The judge **never invents a number**. It only extracts, answers yes/no, or picks one option. The numbers 10, 4, 2 and 0 were **written by you**.
- Each question is so simple ("are these 3 words present?") that the judge almost never gets it wrong, so the metric is **near-deterministic**.
- The **reason is the path**, so a failure tells you exactly which rule was broken.


### 7.5 DAG vs G-Eval in one line

- **G-Eval**: "Here's what I care about, judge, give me a number."
- **DAG**: "Here's the exact flowchart; judge, just answer each small question."

---

## 8. DAG: Implementation (119)

### 8.1 The meeting-summary DAG

```python
from deepeval.test_case import LLMTestCase, LLMTestCaseParams
from deepeval.metrics import DAGMetric
from deepeval.metrics.dag import (
    DeepAcyclicGraph,
    TaskNode,
    BinaryJudgementNode,
    NonBinaryJudgementNode,
    VerdictNode,
)

correct_order_node = NonBinaryJudgementNode(
    criteria="Are the summary headings in the correct order: 'intro' => 'body' => 'conclusion'?",
    children=[
        VerdictNode(verdict="Yes", score=10),
        VerdictNode(verdict="Two are out of order", score=4),
        VerdictNode(verdict="All out of order", score=2),
    ],
)

correct_headings_node = BinaryJudgementNode(
    criteria="Do the summary headings contain all three: 'intro', 'body', and 'conclusion'?",
    children=[
        VerdictNode(verdict=False, score=0),
        VerdictNode(verdict=True, child=correct_order_node),
    ],
)

extract_headings_node = TaskNode(
    instructions="Extract all headings in `actual_output`",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
    output_label="Summary headings",
    children=[correct_headings_node, correct_order_node],
)

dag = DeepAcyclicGraph(root_nodes=[extract_headings_node])

format_correctness = DAGMetric(name="Format Correctness", dag=dag, threshold=0.7)

tc = LLMTestCase(
    input="Summarize this meeting transcript: ...",
    actual_output="""
Intro:
Alice opened the Q3 planning meeting.
Body:
The team discussed the hiring plan and budget.
Conclusion:
Action items: Bob to share the budget sheet by Friday.
""",
)
format_correctness.measure(tc)
print(format_correctness.score, format_correctness.reason)
```

### 8.2 Hybrid DAG: delegate a leaf to G-Eval

Structure is checked deterministically; **content quality** is then judged by G-Eval only if the structure is valid.

```python
from deepeval.metrics import GEval

summary_quality = GEval(
    name="Summary Quality",
    criteria="Evaluate whether the 'actual output' accurately and concisely summarizes the 'input' transcript without inventing facts.",
    evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT],
)

correct_order_node = NonBinaryJudgementNode(
    criteria="Are the summary headings in the correct order: 'intro' => 'body' => 'conclusion'?",
    children=[
        VerdictNode(verdict="Yes", child=summary_quality),   # ← leaf delegates to G-Eval
        VerdictNode(verdict="Two are out of order", score=4),
        VerdictNode(verdict="All out of order", score=2),
    ],
)
```

### 8.3 A business-rule DAG: customer-support refund replies

Rule: *If the user asks for a refund, the reply must (a) state the 30-day policy, (b) if purchase > 30 days, politely decline and offer store credit.*

```python
is_refund_q = BinaryJudgementNode(
    criteria="Is the 'input' a request for a refund?",
    children=[
        VerdictNode(verdict=False, score=10),   # rule not applicable → pass
        VerdictNode(verdict=True, child=BinaryJudgementNode(
            criteria="Does the 'actual output' mention the 30-day refund policy?",
            children=[
                VerdictNode(verdict=False, score=0),
                VerdictNode(verdict=True, child=NonBinaryJudgementNode(
                    criteria=("Based on 'input', was the purchase older than 30 days, and how did "
                              "the 'actual output' respond?"),
                    children=[
                        VerdictNode(verdict="Within 30 days and refund offered", score=10),
                        VerdictNode(verdict="Older than 30 days, declined and offered store credit", score=10),
                        VerdictNode(verdict="Older than 30 days, declined without store credit", score=5),
                        VerdictNode(verdict="Policy applied incorrectly", score=0),
                    ],
                )),
            ],
        )),
    ],
)

# Judgement nodes can also read test-case params directly
is_refund_q.evaluation_params = [LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT]

refund_policy_metric = DAGMetric(
    name="Refund Policy Compliance",
    dag=DeepAcyclicGraph(root_nodes=[is_refund_q]),
)
```

> Tip: Set `evaluation_params` on each judgement node that needs to "see" the test case (in the constructor where supported). Use `verbose_mode=True` on the `DAGMetric` to print the path taken — essential for debugging trees.

### 8.4 Design checklist

- Start from your written rubric; each bullet usually becomes a node.
- Put **cheap, decisive checks first** (format, presence) so bad outputs short-circuit to low scores.
- Keep each node's criteria **atomic** — one question per node.
- Non-binary verdict strings must be **mutually exclusive and exhaustive**.
- Use `TaskNode`s to extract/structure data once, then reuse the label in multiple judgements.

---

## 9. QAG Explained + Custom QAG Metric (120)

### 9.1 Idea

**QAG (Question-Answer Generation)** avoids asking the judge for an arbitrary score. Instead:

1. **Extract** atomic units from the output (claims, statements, verdict-able items).
2. **Ask closed-ended questions** about each unit — "Is claim X supported by the context? yes / no / idk".
3. **Score = (# yes) / (# total)** — a mathematically defined ratio.
4. Judge then writes a reason from the verdicts.

Because each judgement is a tiny yes/no, the result is far more **reproducible** than "rate 1–10".

#### Algorithm

| Step | What happens | LLM call? | Output |
|---|---|---|---|
| 1 | Extract atomic units from the text being judged (claims from `actual_output`, sentences from `expected_output`, etc.) | Yes | List of N units |
| 2 | For each unit, ask a closed-ended question against the evidence (`retrieval_context`, `input`, …) | Yes (batched) | N verdicts: `yes` / `no` / `idk` |
| 3 | Score = (# yes) / N | No (math) | 0–1 |
| 4 | Judge summarises the failing verdicts into a reason | Yes | `reason` |

The judge never outputs the score itself; the score is a count over its verdicts.

#### G-Eval vs DAG vs QAG: who produces the number?

| Technique | The judge… | The number comes from… |
|---|---|---|
| G-Eval | gives a 0–10 score directly | the judge (probability-weighted) |
| DAG | answers small questions along a path | **you** (scores written on the leaves) |
| QAG | answers yes/no for each extracted claim | **counting**: yes ÷ total |

#### Why counting is more reliable

- "Is *'opened in 1901'* supported by this paragraph?" is easy and objective, so two runs almost always agree.
- "Rate the faithfulness of this answer from 1–10" is vague, so two runs often disagree.
- If one yes/no flips, the score moves by only 1/N, so it's **stable** for longer outputs.
- The verdict list is a ready-made explanation: you can see *which* claim failed.

### 9.2 Built-in metrics that use QAG

| Metric | Units extracted | Question asked | Score |
|---|---|---|---|
| Faithfulness | claims in `actual_output`; truths in `retrieval_context` | Does any truth contradict this claim? | non-contradicted claims / total claims |
| Answer Relevancy | statements in `actual_output` | Is this statement relevant to `input`? | relevant / total statements |
| Contextual Relevancy | statements in each retrieval node | Is this statement relevant to `input`? | relevant / total |
| Contextual Recall | sentences in `expected_output` | Can this be attributed to `retrieval_context`? | attributable / total |
| Hallucination | each `context` item | Does `actual_output` agree with it? | contradictions / total (lower is better) |
| Summarization | questions generated from the source | Can the summary answer it? (+ alignment check) | min(alignment, coverage) |
| Bias / Toxicity | opinions in output | Is this opinion biased/toxic? | biased / total (lower is better) |

### 9.3 Worked example: Faithfulness

```
retrieval_context: "The Eiffel Tower is 330 m tall and located in Paris. It opened in 1889."
actual_output:     "The Eiffel Tower, in Paris, is 330 m tall and opened in 1901."

Step 1 – claims:     [ "in Paris", "330 m tall", "opened in 1901" ]
Step 2 – verdicts:   [ yes,        yes,          no (context says 1889) ]
Step 3 – score:      2 / 3 = 0.67
Reason: "The output incorrectly states the tower opened in 1901; context says 1889."
```

### 9.4 Building your own QAG metric (custom `BaseMetric`)

Example: **Policy Coverage** — checks that the answer covers each required point from a checklist (great for compliance answers).

```python
# policy_coverage_metric.py
from typing import List
from pydantic import BaseModel
from openai import OpenAI
from deepeval.metrics import BaseMetric
from deepeval.test_case import LLMTestCase

client = OpenAI()

class Verdict(BaseModel):
    point: str
    verdict: str   # "yes" | "no"
    reason: str

class Verdicts(BaseModel):
    verdicts: List[Verdict]

def judge(prompt: str, schema):
    resp = client.beta.chat.completions.parse(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
        response_format=schema,
        temperature=0,
    )
    return resp.choices[0].message.parsed


class PolicyCoverageMetric(BaseMetric):
    def __init__(self, required_points: List[str], threshold: float = 0.8):
        self.required_points = required_points
        self.threshold = threshold

    def measure(self, test_case: LLMTestCase) -> float:
        points = "\n".join(f"- {p}" for p in self.required_points)
        prompt = f"""For EACH required point below, answer strictly "yes" if the
answer clearly covers it, otherwise "no". Give a one-sentence reason.

Required points:
{points}

Answer:
{test_case.actual_output}
"""
        result: Verdicts = judge(prompt, Verdicts)
        self.verdicts = result.verdicts
        yes = sum(v.verdict.lower() == "yes" for v in self.verdicts)
        self.score = yes / len(self.verdicts) if self.verdicts else 0
        missing = [v.point for v in self.verdicts if v.verdict.lower() != "yes"]
        self.reason = (f"Covered {yes}/{len(self.verdicts)} points."
                       + (f" Missing: {missing}" if missing else ""))
        self.success = self.score >= self.threshold
        return self.score

    async def a_measure(self, test_case: LLMTestCase) -> float:
        return self.measure(test_case)

    def is_successful(self) -> bool:
        return self.success

    @property
    def __name__(self):
        return "Policy Coverage"
```

```python
from deepeval import evaluate
from deepeval.test_case import LLMTestCase
from policy_coverage_metric import PolicyCoverageMetric

metric = PolicyCoverageMetric(required_points=[
    "Mentions the 30-day refund window",
    "Explains the item must be unused",
    "Tells the user how to start a return",
])

tc = LLMTestCase(
    input="Can I return my jacket?",
    actual_output="Yes, within 30 days. Just go to Orders → Return item.",
)
evaluate([tc], [metric])
# score = 2/3 → fails threshold 0.8; reason lists "item must be unused" as missing
```

Required `BaseMetric` contract: set `self.threshold`, `self.score`, `self.success`, (`self.reason`), implement `measure`, `a_measure`, `is_successful`, and a `__name__` property. You can also use DeepEval's own model wrappers (`deepeval.models`) instead of the raw OpenAI client so the metric respects the configured judge.

---

## 10. RAG Evaluation Metrics (121)

A RAG pipeline has two parts that fail independently, so evaluate them separately.

```
   input ──► [ RETRIEVER ] ──► retrieval_context ──► [ GENERATOR (LLM) ] ──► actual_output
               ▲                                       ▲
     Contextual Precision                      Faithfulness
     Contextual Recall                         Answer Relevancy
     Contextual Relevancy
```

### 10.1 Generator metrics

| Metric | Question it answers | Params needed | QAG computation |
|---|---|---|---|
| **Answer Relevancy** | Does the answer address the question? | `input`, `actual_output` | relevant statements / total statements |
| **Faithfulness** | Is every claim in the answer supported by the retrieved context? (hallucination w.r.t. retrieval) | `actual_output`, `retrieval_context` | truthful claims / total claims |

### 10.2 Retriever metrics

| Metric | Question it answers | Params needed | Computation |
|---|---|---|---|
| **Contextual Precision** | Are the **relevant** chunks **ranked higher** than irrelevant ones? (ranking quality) | `input`, `expected_output`, `retrieval_context` | weighted cumulative precision (see below) |
| **Contextual Recall** | Did we retrieve **everything needed** to produce the expected answer? | `input`, `expected_output`, `retrieval_context` | attributable sentences of expected_output / total |
| **Contextual Relevancy** | How much of the retrieved context is **actually relevant** (noise level)? | `input`, `retrieval_context` | relevant statements / total statements in context |

**Contextual Precision formula** (rank-aware):

\[
\text{CP} = \frac{1}{\#\text{relevant nodes}} \sum_{k=1}^{n} \left( \frac{\#\text{relevant in top }k}{k} \cdot r_k \right)
\]

where \( r_k = 1 \) if node \(k\) is relevant, else 0.
Example: relevance of ranks = [1, 0, 1] → (1/1·1 + 1/2·0 + 2/3·1)/2 = (1 + 0.667)/2 = **0.83**. If order were [0, 1, 1] → (0 + 1/2 + 2/3)/2 = **0.58**. Same chunks, worse ranking, lower score.

#### Contextual Precision step by step

**Why rank matters:** LLMs weight earlier context more heavily (and suffer from "lost in the middle"). Relevant chunks ranked below irrelevant ones are more likely to be ignored, and if you later reduce `top_k` they get cut off. Contextual Precision is a rank-aware metric, similar to Average Precision in information retrieval.

Question: *"What is the refund window?"* The retriever returns 3 chunks:

| Rank k | Chunk | Relevant? (judge, using `expected_output`) | Relevant so far | Precision@k | Count it? (only if relevant) |
|---|---|---|---|---|---|
| 1 | "Refunds allowed within 30 days" | ✅ 1 | 1 | 1/1 = 1.00 | **1.00** |
| 2 | "We ship to 40 countries" | ❌ 0 | 1 | 1/2 = 0.50 | — (skip) |
| 3 | "Refunds require unused items" | ✅ 1 | 2 | 2/3 = 0.67 | **0.67** |

Score = average of the counted values = (1.00 + 0.67) / 2 = **0.83**

Now the **same three chunks**, but the irrelevant one is ranked first:

| Rank k | Relevant? | Relevant so far | Precision@k | Counted |
|---|---|---|---|---|
| 1 | ❌ 0 | 0 | 0/1 = 0.00 | — |
| 2 | ✅ 1 | 1 | 1/2 = 0.50 | **0.50** |
| 3 | ✅ 1 | 2 | 2/3 = 0.67 | **0.67** |

Score = (0.50 + 0.67) / 2 = **0.58**. Same chunks, worse ranking, lower score. That's the whole point of this metric: it measures **ordering**, which is what a **reranker** fixes.

#### The three retriever metrics compared

| Metric | Question | Unit judged | Measures | IR equivalent |
|---|---|---|---|---|
| **Contextual Recall** | Is every sentence of `expected_output` supported by the retrieved chunks? | Sentences of `expected_output` | Coverage | Recall |
| **Contextual Precision** | Are relevant chunks ranked above irrelevant ones? | Each chunk (with its rank) | Ranking quality | Average Precision |
| **Contextual Relevancy** | What fraction of retrieved statements is relevant to `input`? | Statements inside chunks | Noise level | Precision (unranked) |

### 10.3 Diagnosing with the metrics

| Symptom | Likely cause | Fix |
|---|---|---|
| Low **Contextual Recall** | Needed info not retrieved | Better embeddings, hybrid search (BM25 + vector), larger `top_k`, better chunking, query rewriting |
| Low **Contextual Precision** | Right chunks retrieved but ranked low | Add a reranker (Cohere, cross-encoder), tune hybrid weights |
| Low **Contextual Relevancy** | Too much noise in context | Smaller `top_k`, smaller chunks, metadata filtering |
| Low **Faithfulness** | LLM invents facts beyond context | Stronger grounding prompt ("answer only from context, else say I don't know"), lower temperature, better model |
| Low **Answer Relevancy** | Answer rambles / misses the question | Prompt for conciseness, answer-first format |

Other useful RAG metrics: `HallucinationMetric` (against ground-truth `context`), custom G-Eval "Correctness" against `expected_output`, and `RAGAS` composite metric (DeepEval ships a `RagasMetric` wrapper).

> **Note on `expected_output`:** precision and recall need it. If you don't have labelled answers, use the Synthesizer (section 2.5) to generate goldens from your docs, or start with the reference-free metrics (Answer Relevancy, Faithfulness, Contextual Relevancy).

---

## 11. Evaluating a RAG Pipeline with DeepEval (122)

A complete, runnable example: a small RAG app over company policy docs, evaluated end-to-end and component-level.

### 11.1 The RAG app

```python
# rag_app.py
from openai import OpenAI
import numpy as np

client = OpenAI()

DOCS = [
    "Refund policy: customers may request a full refund within 30 days of purchase. Items must be unused.",
    "Shipping: we ship to 40 countries. Standard shipping takes 5-7 business days.",
    "Express shipping costs $15 and takes 1-2 business days within the US.",
    "Warranty: electronics carry a 1-year limited warranty covering manufacturing defects.",
    "Support hours: Monday to Friday, 9am to 6pm EST. Email support@acme.com.",
]

def embed(texts):
    r = client.embeddings.create(model="text-embedding-3-small", input=texts)
    return np.array([d.embedding for d in r.data])

DOC_EMB = embed(DOCS)

def retrieve(query: str, k: int = 3) -> list[str]:
    q = embed([query])[0]
    sims = DOC_EMB @ q / (np.linalg.norm(DOC_EMB, axis=1) * np.linalg.norm(q))
    return [DOCS[i] for i in np.argsort(-sims)[:k]]

def generate(query: str, context: list[str]) -> str:
    ctx = "\n".join(f"- {c}" for c in context)
    r = client.chat.completions.create(
        model="gpt-4o-mini",
        temperature=0,
        messages=[
            {"role": "system", "content": "Answer ONLY using the context. If the answer isn't there, say you don't know."},
            {"role": "user", "content": f"Context:\n{ctx}\n\nQuestion: {query}"},
        ],
    )
    return r.choices[0].message.content

def rag(query: str) -> tuple[str, list[str]]:
    ctx = retrieve(query)
    return generate(query, ctx), ctx
```

### 11.2 Goldens

```python
# goldens.py
from deepeval.dataset import EvaluationDataset, Golden

dataset = EvaluationDataset(goldens=[
    Golden(input="How long do I have to return an item?",
           expected_output="You can request a full refund within 30 days of purchase if the item is unused."),
    Golden(input="How much is express shipping and how fast is it?",
           expected_output="Express shipping costs $15 and takes 1-2 business days within the US."),
    Golden(input="Does my laptop have a warranty?",
           expected_output="Yes, electronics have a 1-year limited warranty covering manufacturing defects."),
    Golden(input="When can I contact support?",
           expected_output="Monday to Friday, 9am-6pm EST, via support@acme.com."),
    Golden(input="Do you sell gift cards?",
           expected_output="I don't know; the information is not available."),   # out-of-scope test
])
```

### 11.3 End-to-end evaluation

```python
# eval_rag.py
from deepeval import evaluate
from deepeval.test_case import LLMTestCase, LLMTestCaseParams
from deepeval.metrics import (
    AnswerRelevancyMetric, FaithfulnessMetric,
    ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric,
    GEval,
)
from rag_app import rag
from goldens import dataset

JUDGE = "gpt-4o"

metrics = [
    AnswerRelevancyMetric(threshold=0.7, model=JUDGE),
    FaithfulnessMetric(threshold=0.8, model=JUDGE),
    ContextualPrecisionMetric(threshold=0.7, model=JUDGE),
    ContextualRecallMetric(threshold=0.7, model=JUDGE),
    ContextualRelevancyMetric(threshold=0.5, model=JUDGE),
    GEval(
        name="Correctness",
        evaluation_steps=[
            "Check whether facts in 'actual output' contradict 'expected output'.",
            "Penalize omission of key facts from 'expected output'.",
            "If 'expected output' says the info is unknown, the 'actual output' must also decline to answer.",
        ],
        evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT, LLMTestCaseParams.EXPECTED_OUTPUT],
        model=JUDGE,
    ),
]

test_cases = []
for g in dataset.goldens:
    answer, ctx = rag(g.input)
    test_cases.append(LLMTestCase(
        input=g.input,
        actual_output=answer,
        expected_output=g.expected_output,
        retrieval_context=ctx,
    ))

results = evaluate(test_cases=test_cases, metrics=metrics)

# Summarise per metric
from collections import defaultdict
agg = defaultdict(list)
for tr in results.test_results:
    for md in tr.metrics_data:
        agg[md.name].append(md.score)
for name, scores in agg.items():
    print(f"{name:25s} avg={sum(scores)/len(scores):.2f}")
```

Typical output for this toy app: Contextual Relevancy will be lowish (k=3 brings in noise for a 5-doc corpus) — try `k=2` and rerun to see the trade-off against Contextual Recall.

### 11.4 Pytest version for CI

```python
# tests/test_rag.py
import pytest
from deepeval import assert_test
from deepeval.test_case import LLMTestCase
from deepeval.metrics import FaithfulnessMetric, AnswerRelevancyMetric, ContextualRecallMetric
from rag_app import rag
from goldens import dataset

@pytest.mark.parametrize("golden", dataset.goldens)
def test_rag(golden):
    answer, ctx = rag(golden.input)
    tc = LLMTestCase(input=golden.input, actual_output=answer,
                     expected_output=golden.expected_output, retrieval_context=ctx)
    assert_test(tc, [FaithfulnessMetric(0.8), AnswerRelevancyMetric(0.7), ContextualRecallMetric(0.7)])
```

```bash
deepeval test run tests/test_rag.py
```

### 11.5 Component-level evaluation with tracing

Attach metrics to the *retriever* and *generator* spans separately with `@observe`:

```python
# rag_traced.py
from deepeval.tracing import observe, update_current_span
from deepeval.test_case import LLMTestCase
from deepeval.metrics import ContextualRelevancyMetric, FaithfulnessMetric, AnswerRelevancyMetric
from rag_app import retrieve as _retrieve, generate as _generate

@observe(type="retriever", metrics=[ContextualRelevancyMetric()])
def retrieve(query: str):
    ctx = _retrieve(query)
    update_current_span(test_case=LLMTestCase(input=query, actual_output="", retrieval_context=ctx))
    return ctx

@observe(type="llm", metrics=[FaithfulnessMetric(), AnswerRelevancyMetric()])
def generate(query: str, ctx: list[str]):
    out = _generate(query, ctx)
    update_current_span(test_case=LLMTestCase(input=query, actual_output=out, retrieval_context=ctx))
    return out

@observe()
def rag(query: str):
    return generate(query, retrieve(query))
```

```python
from deepeval.dataset import EvaluationDataset
from goldens import dataset
from rag_traced import rag

for golden in dataset.evals_iterator():   # runs and scores every span's metrics
    rag(golden.input)
```

Now a failure report tells you whether the **retriever** or the **generator** span failed.

### 11.6 Experimenting

Run the same goldens over variants and compare:

| Variant | Ctx Precision | Ctx Recall | Ctx Relevancy | Faithfulness | Answer Rel. |
|---|---|---|---|---|---|
| k=3, no rerank | | | | | |
| k=2, no rerank | | | | | |
| k=5 + reranker → top 2 | | | | | |
| chunk 256 vs 512 | | | | | |

Use `evaluate(..., hyperparameters={"top_k": 3, "model": "gpt-4o-mini", "chunk_size": 512})` so the dashboard (Confident AI) can compare runs by configuration.

---

## 12. Understanding AI Agent Evaluation (123)

### 12.1 Why agents are harder

An agent is an LLM in a loop: **reason → pick tool → call tool → observe → repeat → answer**. Compared to single-shot LLM or RAG:

- Output is a **trajectory**, not just text. Two runs can reach the same answer by different paths.
- Failures can occur at **any step**: wrong plan, wrong tool, wrong arguments, misreading tool output, infinite loops, giving up early.
- Final answer can be right **by luck** despite a bad process (or wrong despite a good process because a tool failed).
- Cost and latency matter: 12 tool calls for a 2-call task is a defect.

### 12.2 Anatomy of an agent (what to evaluate)

```
                ┌───────────────────────── Agent (trace) ──────────────────────────┐
user input ───► │ REASONING / PLANNING ──► TOOL SELECTION ──► ARGUMENTS ──► TOOL    │──► final output
                │        ▲                                                  │      │
                │        └──────────── observation (tool result) ◄──────────┘      │
                └──────────────────────────────────────────────────────────────────┘
 Layers to evaluate:
  1. Reasoning layer  – plan quality, plan adherence
  2. Action layer     – tool correctness, argument correctness
  3. Execution layer  – task completion, step efficiency
  4. Output layer     – answer relevancy, correctness, faithfulness to tool results, safety
```

### 12.3 End-to-end vs component-level for agents

| | End-to-end | Component-level |
|---|---|---|
| Scope | Whole trace: input → final output (+ list of tools called) | Individual spans: each LLM call, tool, retriever, sub-agent |
| Metrics | Task Completion, Step Efficiency, Plan Adherence, Tool Correctness on full trajectory | Argument correctness per tool span, faithfulness of a summariser span, G-Eval on a router span |
| Answers | "Did it accomplish the goal efficiently?" | "Which step broke?" |

### 12.4 Single-turn vs multi-turn

- **Single-turn agent**: one user request → agent runs → answer. Use `LLMTestCase` with `tools_called` / tracing.
- **Multi-turn (conversational) agent**: chatbot that keeps state across turns. Use `ConversationalTestCase` with `Turn`s and conversational metrics (Knowledge Retention, Role Adherence, Conversation Completeness, Turn Relevancy, conversational G-Eval).

### 12.5 Recording a trajectory

DeepEval represents tool calls with `ToolCall`:

```python
from deepeval.test_case import ToolCall

ToolCall(
    name="get_weather",
    description="Get current weather for a city",
    input_parameters={"city": "Paris", "unit": "celsius"},
    output={"temp": 18, "condition": "cloudy"},
)
```

You either build these manually from your agent's logs, or let **tracing** (`@observe(type="tool")`) capture them automatically.

---

## 13. Agentic Evaluation Metrics (124)

### 13.1 Metric map

| Layer | Metric | What it checks | Needs |
|---|---|---|---|
| Action | **ToolCorrectnessMetric** | Did the agent call the expected tools (optionally same args / output / order)? Deterministic, not LLM-judged by default. | `tools_called`, `expected_tools` |
| Action | **ArgumentCorrectnessMetric** | Were the tool arguments correct/sensible given the input? (LLM-judged, reference-free) | `input`, `tools_called` |
| Execution | **TaskCompletionMetric** | Did the agent accomplish the task implied by the input? Judge infers the task and the outcome from the trace. | trace (or `input`, `actual_output`, `tools_called`) |
| Execution | **StepEfficiencyMetric** | Did it complete the task without redundant/unnecessary steps? | trace |
| Reasoning | **PlanQualityMetric** | Was the agent's plan logical, complete, and efficient for the task? | trace |
| Reasoning | **PlanAdherenceMetric** | Did the agent follow its own plan? | trace |
| Output | AnswerRelevancy, G-Eval Correctness, Faithfulness (to tool outputs) | Quality of final answer | test case |
| Multi-turn | Knowledge Retention, Role Adherence, Conversation Completeness, Turn Relevancy | Conversation quality | `ConversationalTestCase` |

> The reasoning/efficiency metrics (Plan Quality, Plan Adherence, Step Efficiency) are newer additions and work from traces; check your installed `deepeval` version (`pip show deepeval`) if an import fails.

### 13.2 Tool Correctness in detail

```python
from deepeval.metrics import ToolCorrectnessMetric
from deepeval.test_case import LLMTestCase, ToolCall, ToolCallParams

tc = LLMTestCase(
    input="What's the weather in Paris and convert 20 EUR to USD?",
    actual_output="It's 18°C in Paris. 20 EUR is about 21.6 USD.",
    tools_called=[ToolCall(name="get_weather", input_parameters={"city": "Paris"}),
                  ToolCall(name="web_search", input_parameters={"q": "EUR to USD"})],
    expected_tools=[ToolCall(name="get_weather", input_parameters={"city": "Paris"}),
                    ToolCall(name="currency_convert", input_parameters={"amount": 20, "from": "EUR", "to": "USD"})],
)

metric = ToolCorrectnessMetric(
    evaluation_params=[ToolCallParams.INPUT_PARAMETERS],  # also compare args (default: names only)
    should_consider_ordering=False,   # True → order of calls matters
    should_exact_match=False,         # True → tools_called must equal expected_tools exactly (score 0 or 1)
)
metric.measure(tc)
print(metric.score, metric.reason)  # 0.5 – currency_convert expected but web_search used
```

Scoring: (# expected tools correctly called) / (# expected tools). With `should_consider_ordering=True` it uses longest-common-subsequence over the sequences. Newer versions can also accept `available_tools` and use an LLM to judge whether a different tool choice was still optimal.

### 13.3 Task Completion

The judge (1) extracts the **task** from the input, (2) extracts the **outcome** from the trace/output and tool calls, (3) scores how well the outcome satisfies the task (0–1).

```python
from deepeval.metrics import TaskCompletionMetric

tc = LLMTestCase(
    input="Book me the cheapest flight from NYC to London next Friday.",
    actual_output="I found a $420 flight but couldn't complete the booking because payment failed.",
    tools_called=[ToolCall(name="search_flights", input_parameters={"from": "NYC", "to": "LON", "date": "2026-11-13"}),
                  ToolCall(name="book_flight", input_parameters={"flight_id": "BA178"},
                           output={"error": "payment_declined"})],
)
TaskCompletionMetric(threshold=0.7).measure(tc)   # low score: task (book) not completed
```

### 13.4 Argument Correctness

LLM-judged, reference-free: for each tool call, "given the user input, were these arguments right?"

```python
from deepeval.metrics import ArgumentCorrectnessMetric

tc = LLMTestCase(
    input="What's the weather in Tokyo in Fahrenheit?",
    actual_output="It's 64°F.",
    tools_called=[ToolCall(name="get_weather", input_parameters={"city": "Tokyo", "unit": "celsius"})],
)
ArgumentCorrectnessMetric().measure(tc)   # fails: user asked for fahrenheit
```

### 13.5 Custom agent metrics with G-Eval / DAG

Agent-specific policies are perfect G-Eval/DAG material:

```python
from deepeval.metrics import GEval
from deepeval.test_case import LLMTestCaseParams

safe_actions = GEval(
    name="Destructive Action Confirmation",
    evaluation_steps=[
        "Identify whether any call in 'tools called' is destructive (delete, refund, transfer money, send email).",
        "If so, check whether 'actual output' or the trajectory shows the agent asked the user for confirmation first.",
        "Score 10 if no destructive action or confirmation was obtained; 0 if a destructive action was taken without confirmation.",
    ],
    evaluation_params=[LLMTestCaseParams.INPUT, LLMTestCaseParams.ACTUAL_OUTPUT, LLMTestCaseParams.TOOLS_CALLED],
)
```

---

## 14. Evaluating an AI Agent with DeepEval (125)

Complete example: a travel-assistant agent with three tools, evaluated (A) end-to-end with manual test cases and (B) with tracing at component level.

### 14.1 The agent (OpenAI function calling)

```python
# agent.py
import json
from openai import OpenAI

client = OpenAI()

# --- tools ---
def get_weather(city: str) -> dict:
    fake = {"paris": 18, "tokyo": 22, "london": 12}
    return {"city": city, "temp_c": fake.get(city.lower(), 20)}

def search_flights(origin: str, destination: str, date: str) -> list[dict]:
    return [{"id": "AF123", "price": 480}, {"id": "BA456", "price": 420}]

def convert_currency(amount: float, src: str, dst: str) -> dict:
    rates = {("EUR", "USD"): 1.08, ("USD", "EUR"): 0.93}
    return {"amount": round(amount * rates.get((src, dst), 1), 2), "currency": dst}

TOOLS = {"get_weather": get_weather, "search_flights": search_flights, "convert_currency": convert_currency}

TOOL_SCHEMAS = [
    {"type": "function", "function": {
        "name": "get_weather", "description": "Get current weather for a city",
        "parameters": {"type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]}}},
    {"type": "function", "function": {
        "name": "search_flights", "description": "Search flights between two cities on a date (YYYY-MM-DD)",
        "parameters": {"type": "object", "properties": {
            "origin": {"type": "string"}, "destination": {"type": "string"}, "date": {"type": "string"}},
            "required": ["origin", "destination", "date"]}}},
    {"type": "function", "function": {
        "name": "convert_currency", "description": "Convert an amount between currencies (ISO codes)",
        "parameters": {"type": "object", "properties": {
            "amount": {"type": "number"}, "src": {"type": "string"}, "dst": {"type": "string"}},
            "required": ["amount", "src", "dst"]}}},
]

SYSTEM = "You are a travel assistant. Use tools when needed. Be concise. Today is 2026-11-10."

def run_agent(user_input: str, max_steps: int = 6):
    """Returns (final_answer, list_of_tool_call_records)."""
    messages = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": user_input}]
    calls = []
    for _ in range(max_steps):
        resp = client.chat.completions.create(model="gpt-4o-mini", messages=messages,
                                              tools=TOOL_SCHEMAS, temperature=0)
        msg = resp.choices[0].message
        if not msg.tool_calls:
            return msg.content, calls
        messages.append(msg)
        for tc in msg.tool_calls:
            args = json.loads(tc.function.arguments)
            result = TOOLS[tc.function.name](**args)
            calls.append({"name": tc.function.name, "args": args, "output": result})
            messages.append({"role": "tool", "tool_call_id": tc.id, "content": json.dumps(result)})
    return "I couldn't finish the task within the step limit.", calls
```

### 14.2 Goldens with expected tools

```python
# agent_goldens.py
from deepeval.dataset import EvaluationDataset, Golden
from deepeval.test_case import ToolCall

dataset = EvaluationDataset(goldens=[
    Golden(
        input="What's the weather in Paris?",
        expected_output="It's about 18°C in Paris.",
        expected_tools=[ToolCall(name="get_weather", input_parameters={"city": "Paris"})],
    ),
    Golden(
        input="Find me the cheapest flight from NYC to London on 2026-11-20 and tell me the price in EUR.",
        expected_output="The cheapest is BA456 at $420, about €390.6.",
        expected_tools=[
            ToolCall(name="search_flights",
                     input_parameters={"origin": "NYC", "destination": "London", "date": "2026-11-20"}),
            ToolCall(name="convert_currency", input_parameters={"amount": 420, "src": "USD", "dst": "EUR"}),
        ],
    ),
    Golden(
        input="Tell me a fun fact about travel.",
        expected_output="Any reasonable fun fact; no tools needed.",
        expected_tools=[],      # agent should NOT call tools
    ),
])
```

### 14.3 (A) End-to-end evaluation

```python
# eval_agent.py
from deepeval import evaluate
from deepeval.test_case import LLMTestCase, LLMTestCaseParams, ToolCall
from deepeval.metrics import (
    ToolCorrectnessMetric, TaskCompletionMetric, ArgumentCorrectnessMetric,
    AnswerRelevancyMetric, GEval,
)
from agent import run_agent
from agent_goldens import dataset

def to_toolcalls(records):
    return [ToolCall(name=r["name"], input_parameters=r["args"], output=r["output"]) for r in records]

test_cases = []
for g in dataset.goldens:
    answer, records = run_agent(g.input)
    test_cases.append(LLMTestCase(
        input=g.input,
        actual_output=answer,
        expected_output=g.expected_output,
        tools_called=to_toolcalls(records),
        expected_tools=g.expected_tools or [],
    ))

grounded_in_tools = GEval(
    name="Grounded in Tool Results",
    evaluation_steps=[
        "Extract every number/fact in 'actual output'.",
        "Check that each one is supported by the outputs in 'tools called' (or is common knowledge if no tools were called).",
        "Penalize any fabricated or altered value.",
    ],
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT, LLMTestCaseParams.TOOLS_CALLED],
)

metrics = [
    ToolCorrectnessMetric(threshold=0.8),
    ArgumentCorrectnessMetric(threshold=0.7),
    TaskCompletionMetric(threshold=0.7),
    AnswerRelevancyMetric(threshold=0.7),
    grounded_in_tools,
]

evaluate(test_cases=test_cases, metrics=metrics)
```

What to look for:
- **Tool Correctness** fails if the agent skipped `convert_currency` and did the math itself, or called tools for the fun-fact question.
- **Argument Correctness** catches `"date": "next friday"` or `"origin": "New York City"` vs expected format issues.
- **Task Completion** catches "found flights but forgot the EUR conversion".
- **Grounded in Tool Results** catches the agent inventing a price.

> Strict argument matching (`ToolCallParams.INPUT_PARAMETERS`) can be brittle — `"NYC"` vs `"New York"` fails. Start with name-only Tool Correctness + LLM-judged Argument Correctness, then tighten.

### 14.4 (B) Tracing-based (component-level) evaluation

Instrument the agent with `@observe` so DeepEval captures the whole trace — the LLM steps, each tool span, and the overall agent span — automatically.

```python
# agent_traced.py
import json
from deepeval.tracing import observe, update_current_span, update_current_trace
from deepeval.test_case import LLMTestCase
from deepeval.metrics import ArgumentCorrectnessMetric
import agent as base

@observe(type="tool")
def get_weather(city: str):
    return base.get_weather(city)

@observe(type="tool")
def search_flights(origin: str, destination: str, date: str):
    return base.search_flights(origin, destination, date)

@observe(type="tool")
def convert_currency(amount: float, src: str, dst: str):
    return base.convert_currency(amount, src, dst)

TOOLS = {"get_weather": get_weather, "search_flights": search_flights, "convert_currency": convert_currency}

@observe(type="llm", model="gpt-4o-mini")
def call_llm(messages):
    return base.client.chat.completions.create(
        model="gpt-4o-mini", messages=messages, tools=base.TOOL_SCHEMAS, temperature=0
    ).choices[0].message

@observe(type="agent", available_tools=list(TOOLS))
def travel_agent(user_input: str, max_steps: int = 6) -> str:
    messages = [{"role": "system", "content": base.SYSTEM}, {"role": "user", "content": user_input}]
    for _ in range(max_steps):
        msg = call_llm(messages)
        if not msg.tool_calls:
            update_current_trace(input=user_input, output=msg.content)
            return msg.content
        messages.append(msg)
        for tc in msg.tool_calls:
            result = TOOLS[tc.function.name](**json.loads(tc.function.arguments))
            messages.append({"role": "tool", "tool_call_id": tc.id, "content": json.dumps(result)})
    return "I couldn't finish the task within the step limit."
```

Run with trace-level metrics (task completion, step efficiency, plan metrics work off the captured trace):

```python
# eval_agent_traced.py
from deepeval.metrics import TaskCompletionMetric, StepEfficiencyMetric
from agent_goldens import dataset
from agent_traced import travel_agent

for golden in dataset.evals_iterator(metrics=[TaskCompletionMetric(), StepEfficiencyMetric()]):
    travel_agent(golden.input)
```

You can also attach span-level metrics by passing `metrics=[...]` to a specific `@observe(...)` and calling `update_current_span(test_case=LLMTestCase(...))` inside it — e.g., put `ArgumentCorrectnessMetric` on the agent span, or a G-Eval on a "router" LLM span.

### 14.5 Pytest / CI for agents

```python
# tests/test_agent.py
import pytest
from deepeval import assert_test
from deepeval.test_case import LLMTestCase, ToolCall
from deepeval.metrics import ToolCorrectnessMetric, TaskCompletionMetric
from agent import run_agent
from agent_goldens import dataset

@pytest.mark.parametrize("golden", dataset.goldens)
def test_agent(golden):
    answer, records = run_agent(golden.input)
    tc = LLMTestCase(
        input=golden.input, actual_output=answer,
        tools_called=[ToolCall(name=r["name"], input_parameters=r["args"], output=r["output"]) for r in records],
        expected_tools=golden.expected_tools or [],
    )
    assert_test(tc, [ToolCorrectnessMetric(threshold=0.8), TaskCompletionMetric(threshold=0.7)])
```

### 14.6 Agent-eval best practices

- **Mock or freeze tools** (fixed fake data like above) so evals measure the agent, not flaky APIs.
- Evaluate **both** outcome (task completion) and process (tool/argument correctness, efficiency). Outcome-only hides lucky passes.
- Include **negative goldens**: questions that must *not* trigger tools, or destructive actions that must require confirmation.
- Track **cost/latency/steps** per run alongside quality scores.
- Run each golden **multiple times** (agents are stochastic) and look at pass rate, not a single run.
- For multi-turn agents, use `ConversationalTestCase` + conversation simulator to generate realistic dialogues.

---

## 15. Cheat Sheet & Interview Questions

### 15.1 Imports cheat sheet

```python
from deepeval import evaluate, assert_test
from deepeval.test_case import LLMTestCase, LLMTestCaseParams, ToolCall, ToolCallParams
from deepeval.test_case import ConversationalTestCase, Turn
from deepeval.dataset import EvaluationDataset, Golden
from deepeval.synthesizer import Synthesizer
from deepeval.metrics import (
    GEval, DAGMetric, BaseMetric,
    AnswerRelevancyMetric, FaithfulnessMetric, HallucinationMetric,
    ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric,
    ToolCorrectnessMetric, TaskCompletionMetric, ArgumentCorrectnessMetric,
    BiasMetric, ToxicityMetric, SummarizationMetric,
)
from deepeval.metrics.dag import DeepAcyclicGraph, TaskNode, BinaryJudgementNode, NonBinaryJudgementNode, VerdictNode
from deepeval.tracing import observe, update_current_span, update_current_trace
```

### 15.2 Which metric for which question?

| I want to know… | Metric |
|---|---|
| Does the answer address the question? | AnswerRelevancy |
| Is the answer correct vs a reference? | G-Eval "Correctness" |
| Does the answer stick to retrieved docs? | Faithfulness |
| Did the retriever find everything needed? | Contextual Recall |
| Are the best chunks ranked first? | Contextual Precision |
| How noisy is the retrieved context? | Contextual Relevancy |
| Does output follow a strict format/rule? | DAG |
| Subjective quality (tone, helpfulness)? | G-Eval |
| Did the agent use the right tools? | Tool Correctness |
| Were the tool arguments right? | Argument Correctness |
| Did the agent achieve the goal? | Task Completion |
| Did it waste steps? | Step Efficiency |

### 15.3 Interview questions

1. **Golden vs LLMTestCase?** Golden = static reference data (input, expected output, context, expected tools) without `actual_output`. Test case = golden + runtime outputs (`actual_output`, `retrieval_context`, `tools_called`). Separation lets you re-run the same goldens against every app version.
2. **`context` vs `retrieval_context`?** Ground truth vs what the retriever actually returned. Hallucination uses `context`, Faithfulness uses `retrieval_context`.
3. **Why does G-Eval weight by token probabilities?** LLMs cluster on a few integers; expected value over score-token probabilities gives finer, more human-aligned scores.
4. **When to choose DAG over G-Eval?** Objective, multi-condition rules where you need deterministic, explainable scoring; G-Eval for holistic/subjective criteria.
5. **What is QAG and why is it reliable?** Decompose output into atomic claims/statements, ask closed yes/no questions, score as a ratio — no arbitrary scale, small judgements are reproducible.
6. **Contextual precision vs recall?** Precision = are relevant chunks ranked higher (ranking quality); recall = did we retrieve all info needed for the expected answer (coverage).
7. **RAG faithfulness is low but contextual recall is high — what's wrong?** Retrieval is fine; the generator is hallucinating. Fix prompt grounding / model / temperature.
8. **How do you evaluate an agent beyond the final answer?** Trajectory metrics: tool correctness, argument correctness, step efficiency, plan quality/adherence; component-level tracing to locate failing spans.
9. **How do you make LLM-judge evals trustworthy?** Pin judge model, explicit evaluation steps/rubrics, use QAG/DAG for objective checks, calibrate against human labels, use strict mode for binary requirements, monitor score variance across runs.
10. **How do you put LLM evals in CI?** Pytest files with `assert_test`, `deepeval test run` in the pipeline, fixed golden dataset, thresholds per metric, caching to control cost, fail the build on regression.

---

## 16. Decision Guide: Which Metric to Choose

```mermaid
flowchart TD
    Start["What are you checking?"] --> Q1{"Tool calls of an agent?"}
    Q1 -- Yes --> Q1a{"Plain right tool / right args?"}
    Q1a -- Yes --> TC["ToolCorrectnessMetric<br/>ArgumentCorrectnessMetric"]
    Q1a -- "No, conditional rules" --> DAG1["DAG<br/>e.g. delete tool → must confirm first"]

    Q1 -- No --> Q2{"Is there a standard built-in metric?<br/>RAG grounding, relevancy, retrieval"}
    Q2 -- Yes --> QAG["Built-in QAG metrics<br/>Faithfulness, AnswerRelevancy,<br/>ContextualPrecision / Recall / Relevancy"]

    Q2 -- No --> Q3{"Objective rules with if/then<br/>or fixed structure?"}
    Q3 -- Yes --> DAG2["DAG<br/>e.g. must refuse if not in docs,<br/>headings in order, must cite"]

    Q3 -- No --> Q4{"Checklist of facts/points<br/>to count?"}
    Q4 -- Yes --> QAGc["Custom QAG (BaseMetric)<br/>e.g. covers 3 required policy points"]

    Q4 -- No --> GE["G-Eval<br/>e.g. tone, helpfulness, correctness vs expected"]
```

| Situation | Choose | Example |
|---|---|---|
| Did the agent call the right tools / args? | ToolCorrectness, ArgumentCorrectness | Expected `get_weather(city="Paris")` |
| Tool use with conditional rules | DAG | Used `delete_account` → asked for confirmation? |
| Answer grounded in retrieved docs? | Faithfulness (QAG) | RAG bot invents a date not in context |
| Retriever fetched the right chunks? | Contextual Precision / Recall / Relevancy (QAG) | Refund chunk ranked 5th |
| If/then business rules, format, structure | DAG | Pharmacy bot must warn + say "consult doctor" |
| Count required points covered | Custom QAG | Summary covers parties, payment, termination |
| Subjective / holistic quality | G-Eval | Is the reply polite and helpful? |

Typical combination: built-in QAG metrics for RAG quality + one DAG for business rules + one G-Eval for overall quality.
