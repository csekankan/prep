# LangMem — Long-Term Memory for AI Agents (Deep Dive + Production System Design)

> Based on the `langmem_qs` quickstart notebook (Groq `qwen3-32b` + Gemini embeddings + LangGraph), extended into a full deep dive: memory concepts, every LangMem API, hot-path vs background memory, procedural memory (prompt optimization), and a FAANG-scale memory system design.

> **Version note:** LangMem is pre-1.0 (`langmem>=0.0.30`) and LangGraph v1 moved `create_react_agent` → `langchain.agents.create_agent`. APIs can shift — pin versions.

---

## Table of Contents

1. [Why Agents Need Memory](#1-why-agents-need-memory)
2. [Types of Memory](#2-types-of-memory)
3. [LangGraph Building Blocks: Checkpointer vs Store](#3-langgraph-building-blocks-checkpointer-vs-store)
4. [LangMem Architecture](#4-langmem-architecture)
5. [Quickstart Walkthrough (the notebook)](#5-quickstart-walkthrough-the-notebook)
6. [Hot Path vs Background Memory](#6-hot-path-vs-background-memory)
7. [Semantic Memory Deep Dive: Collections vs Profiles](#7-semantic-memory-deep-dive-collections-vs-profiles)
8. [Background Memory: Store Manager + ReflectionExecutor](#8-background-memory-store-manager--reflectionexecutor)
9. [Episodic Memory](#9-episodic-memory)
10. [Procedural Memory: Prompt Optimization](#10-procedural-memory-prompt-optimization)
11. [Multi-Tenancy with Namespaces](#11-multi-tenancy-with-namespaces)
12. [Going to Production: Postgres + pgvector](#12-going-to-production-postgres--pgvector)
13. [FAANG-Scale Memory System Design](#13-faang-scale-memory-system-design)
14. [Pitfalls, Cheat Sheet & Interview Questions](#14-pitfalls-cheat-sheet--interview-questions)

---

## 1. Why Agents Need Memory

LLMs are **stateless**. Every call sees only what's in the prompt. Without memory:

- The user repeats preferences every session ("I prefer dark mode", "I'm vegetarian").
- The agent can't learn from mistakes or feedback.
- Personalization is impossible.

```mermaid
flowchart LR
    subgraph NoMemory["Without long-term memory"]
        U1["Session 1: I prefer dark mode"] --> A1["Agent: OK"]
        U2["Session 2: What mode do I like?"] --> A2["Agent: I don't know"]
    end
    subgraph WithMemory["With LangMem"]
        V1["Session 1: I prefer dark mode"] --> B1["Agent saves memory"]
        B1 --> S[("Memory store")]
        V2["Session 2: What mode do I like?"] --> B2["Agent searches store"]
        S --> B2
        B2 --> R["Agent: Dark mode"]
    end
```

### Short-term vs long-term

| | Short-term (thread) memory | Long-term memory |
|---|---|---|
| Scope | One conversation (`thread_id`) | Across all conversations of a user/org |
| Contents | Raw message history | Extracted facts, preferences, examples, rules |
| LangGraph primitive | **Checkpointer** (`MemorySaver`, `PostgresSaver`) | **Store** (`InMemoryStore`, `PostgresStore`) |
| Lifetime | Until thread ends / is trimmed | Persistent, updated over time |
| Problem it solves | "What did you just say?" | "What do you know about me?" |

---

## 2. Types of Memory

LangMem borrows the cognitive-science split used in the CoALA paper:

```mermaid
flowchart TD
    M["Agent long-term memory"] --> SEM["Semantic<br/>FACTS"]
    M --> EPI["Episodic<br/>EXPERIENCES"]
    M --> PRO["Procedural<br/>HOW TO BEHAVE"]

    SEM --> S1["User prefers dark mode<br/>User is a Python dev in Berlin"]
    EPI --> E1["Last time user asked for a refund,<br/>this sequence of steps worked"]
    PRO --> P1["System prompt rules:<br/>Always answer in bullet points"]

    SEM -.stored as.-> ST1["Store items (collection or profile)"]
    EPI -.stored as.-> ST2["Store items (few-shot examples)"]
    PRO -.stored as.-> ST3["Updated system prompt"]
```

| Type | What it stores | Example | LangMem tool |
|---|---|---|---|
| **Semantic** | Facts & preferences | "User is allergic to peanuts" | `create_manage_memory_tool`, `create_memory_manager`, `create_memory_store_manager` |
| **Episodic** | Past interactions/experiences, usually as successful examples | "Here's how I solved a similar bug last week" | Same managers with an `Episode` schema |
| **Procedural** | Behavior / instructions | Prompt evolves: "be more concise" | `create_prompt_optimizer`, `create_multi_prompt_optimizer` |

---

## 3. LangGraph Building Blocks: Checkpointer vs Store

LangMem sits **on top of** LangGraph's two persistence primitives.

```mermaid
flowchart TB
    subgraph Agent["LangGraph agent"]
        G["Graph execution"]
    end

    G <--> CP[("Checkpointer<br/>key: thread_id<br/>value: full graph state / messages")]
    G <--> ST[("Store<br/>key: (namespace tuple, key)<br/>value: JSON document<br/>+ optional vector index")]

    CP --- T1["thread-a: [msg1, msg2, ...]"]
    CP --- T2["thread-b: [msg1, ...]"]

    ST --- N1["('memories', 'user-42') / uuid-1 → {content: 'prefers dark mode'}"]
    ST --- N2["('memories', 'user-42') / uuid-2 → {content: 'lives in Berlin'}"]
    ST --- N3["('memories', 'user-77') / uuid-3 → {...}"]
```

### The Store data model

| Concept | Meaning | Example |
|---|---|---|
| **Namespace** | Tuple path, like a folder | `("memories", "user-42")` |
| **Key** | Unique ID within namespace | `"2d849c44-..."` |
| **Value** | JSON dict | `{"content": "User prefers dark mode"}` |
| **Index** | Embedding config for semantic search | `{"embed": embeddings, "dims": 3072}` |

Core operations:

```python
store.put(("memories", "user-42"), "pref-1", {"content": "User prefers dark mode"})
store.get(("memories", "user-42"), "pref-1")
store.search(("memories", "user-42"), query="UI theme", limit=5)   # semantic search
store.search(("memories", "user-42"), filter={"type": "preference"})
store.delete(("memories", "user-42"), "pref-1")
```

`store.search` with a `query` embeds the query and does vector similarity over items in that namespace prefix.

### 3.1 Where does the Store actually save data?

"Store" is an interface (`BaseStore`). **Where data lives depends on which implementation you pick.** Your code (`put`, `get`, `search`) stays the same.

```mermaid
flowchart TB
    APP["Your agent code<br/>store.put / get / search"] --> IF["BaseStore interface"]
    IF --> IM["InMemoryStore<br/>Python dict in RAM"]
    IF --> PG["PostgresStore<br/>Postgres tables + pgvector"]
    IF --> RD["RedisStore<br/>Redis (JSON + vector search)"]
    IF --> MG["MongoDBStore<br/>MongoDB / Atlas Vector Search"]
    IF --> PL["LangGraph Platform<br/>managed Postgres"]
```

| Implementation | Where data lives | Survives restart? | Shared across servers? | Use for |
|---|---|---|---|---|
| `InMemoryStore` | Python process RAM (a dict) | **No** | **No** | Notebooks, tests (the quickstart) |
| `PostgresStore` | Your Postgres database (`store` table for values, `store_vectors` table with pgvector embeddings) | Yes | Yes | **Default production choice** |
| `RedisStore` | Redis (RedisJSON + RediSearch vector index) | Yes (with persistence) | Yes | Low latency, already using Redis |
| `MongoDBStore` | MongoDB collection (+ Atlas Vector Search) | Yes | Yes | Mongo-based stacks |
| LangGraph Platform | Managed Postgres run by LangChain | Yes | Yes | Deploying on LangGraph Platform; no setup |

The table names above (`store`, `store_vectors`) are what `PostgresStore.setup()` creates in current versions; check your DB after `setup()`.

#### Example: InMemoryStore (RAM, the notebook)

```python
from langgraph.store.memory import InMemoryStore

store = InMemoryStore(index={"embed": "openai:text-embedding-3-small", "dims": 1536})
store.put(("memories", "kjana"), "pref-theme", {"content": "Prefers dark mode"})
print(store.search(("memories", "kjana"), query="theme"))
# restart Python → everything is gone
```

#### Example: PostgresStore (persistent)

```bash
pip install "langgraph-checkpoint-postgres" "psycopg[binary,pool]"
docker run -d --name pg -e POSTGRES_PASSWORD=pass -p 5432:5432 pgvector/pgvector:pg16
```

```python
from langgraph.store.postgres import PostgresStore

DB_URI = "postgresql://postgres:pass@localhost:5432/postgres"

with PostgresStore.from_conn_string(
    DB_URI,
    index={"embed": "openai:text-embedding-3-small", "dims": 1536, "fields": ["content"]},
) as store:
    store.setup()   # creates tables + pgvector index (run once)
    store.put(("memories", "kjana"), "pref-theme", {"content": "Prefers dark mode"})
    print(store.search(("memories", "kjana"), query="theme"))
# restart Python → data is still in Postgres
```

Look at it directly in the database:

```sql
SELECT prefix, key, value FROM store;
-- memories.kjana | pref-theme | {"content": "Prefers dark mode"}
```

#### Example: RedisStore

```bash
pip install langgraph-checkpoint-redis
docker run -d -p 6379:6379 redis/redis-stack-server:latest
```

```python
from langgraph.store.redis import RedisStore

with RedisStore.from_conn_string(
    "redis://localhost:6379",
    index={"embed": "openai:text-embedding-3-small", "dims": 1536, "fields": ["content"]},
) as store:
    store.setup()
    store.put(("memories", "kjana"), "pref-theme", {"content": "Prefers dark mode"})
```

#### Plugging any of them into the agent

```python
agent = create_agent(
    model=llm,
    tools=[create_manage_memory_tool(namespace=("memories", "{user_id}"))],
    store=store,                 # ← InMemoryStore, PostgresStore, RedisStore... same code
    checkpointer=checkpointer,
)
```

---

## 4. LangMem Architecture

LangMem is a set of helpers that do **three jobs** around a LangGraph agent and its Store:

| Job | Question it answers | LangMem APIs |
|---|---|---|
| **A. Agent manages memory itself** | "Should I save or look up something right now?" | `create_manage_memory_tool`, `create_search_memory_tool` |
| **B. Automatic extraction** | "What facts are in this conversation worth keeping?" | `create_memory_manager`, `create_memory_store_manager`, `ReflectionExecutor` |
| **C. Improve the agent's instructions** | "How should the system prompt change based on feedback?" | `create_prompt_optimizer` |

### 4.1 Where each piece sits

```mermaid
flowchart LR
    U["User"] --> AG

    subgraph Turn["During the chat turn"]
        AG["Agent LLM"]
        AG -- "A: tool call<br/>manage_memory" --> STORE
        AG -- "A: tool call<br/>search_memory" --> STORE
        STORE -- "results" --> AG
    end

    AG --> R["Reply to user"]

    subgraph After["After the turn (background)"]
        RE["ReflectionExecutor<br/>waits until chat is quiet"]
        SM["Memory store manager<br/>(extraction LLM)"]
        RE --> SM
    end

    R -. "B: conversation" .-> RE
    SM -- "B: insert / update / delete" --> STORE[("LangGraph Store<br/>long-term memory")]

    subgraph Offline["Offline (periodic)"]
        FB["Conversations + feedback"] --> PO["Prompt optimizer<br/>(LLM)"]
    end
    PO -- "C: new system prompt" --> AG
```

### 4.2 Each job explained

**A. Agent manages memory itself (hot path)**
- LangMem gives the agent two tools. The agent LLM decides on its own when to call them, just like any other tool.
- `manage_memory(action="create" | "update" | "delete", content=...)` writes to the Store.
- `search_memory(query=...)` reads from the Store.
- Used in your notebook: "I prefer dark mode. Remember that." → the agent called `manage_memory`.

**B. Automatic extraction (background)**
- A separate LLM reads the finished conversation and pulls out facts, without the agent's involvement.
- `create_memory_manager`: input is messages, output is a list of memories. **It does not save anything**; you store the result yourself.
- `create_memory_store_manager`: same, but it **also reads existing memories from the Store and writes the changes back**.
- `ReflectionExecutor`: wraps the store manager and delays it, so it runs once after the user stops typing instead of on every message.

```mermaid
flowchart LR
    C["Conversation"] --> MM["create_memory_manager"]
    MM --> L["List of memories<br/>(you save them)"]

    C2["Conversation"] --> SM["create_memory_store_manager"]
    SM <--> ST[("Store")]
```

**C. Improve the agent's instructions (procedural memory)**
- `create_prompt_optimizer` takes past conversations plus feedback (👍/👎, comments) and the current system prompt.
- Returns a rewritten system prompt, for example adding "answer in bullet points" after users complained about long answers.
- Doesn't touch the Store; you deploy the new prompt (after evals).

### 4.3 "Core" vs "Stateful" (the official terms)

The LangMem docs group the same APIs by **whether they touch the Store**:

| Group | Meaning | APIs |
|---|---|---|
| **Core** (stateless) | Pure functions: input → output. No storage. Usable with any database. | `create_memory_manager`, `create_prompt_optimizer` |
| **Stateful** | Read and write the LangGraph Store directly | `create_manage_memory_tool`, `create_search_memory_tool`, `create_memory_store_manager`, `ReflectionExecutor` |

### 4.4 Summary table

| API | Layer | When it runs | Who decides what to save |
|---|---|---|---|
| `create_manage_memory_tool` | Stateful | During the conversation (hot path) | The agent LLM, via tool call |
| `create_search_memory_tool` | Stateful | During the conversation | The agent LLM |
| `create_memory_manager` | Core | Whenever you call it | A separate extraction LLM; you persist results |
| `create_memory_store_manager` | Stateful | Usually after the conversation (background) | A separate extraction LLM; persists to store |
| `ReflectionExecutor` | Stateful | Delayed / debounced | Wraps a store manager |
| `create_prompt_optimizer` | Core | Offline / periodic | Optimizer LLM rewrites prompt |

### 4.5 Who decides what gets stored?

| Approach | Who decides | How you steer it |
|---|---|---|
| **Memory tool** (the notebook) | The **agent LLM** decides on each turn whether to call `manage_memory` | The tool's `instructions`, plus your system prompt |
| **Background manager** (`create_memory_store_manager`) | A **separate extraction LLM** reads the whole conversation and decides | `instructions` and `schemas` (e.g., only save prefs, facts, goals) |
| **Manual** | **Your code** decides (`store.put(...)`) | Fully deterministic |

In the notebook, the agent saved "dark mode" only because the user said *"Remember that."* For a softer statement like *"ugh, light mode hurts my eyes"*, it might not call the tool. That inconsistency is why production systems add background extraction.

#### Approach 1: Memory tool (agent decides)

```python
from langchain.agents import create_agent
from langmem import create_manage_memory_tool, create_search_memory_tool

memory_tool = create_manage_memory_tool(
    namespace=("memories", "{user_id}"),
    instructions="Save coding preferences, tech stack, and project commands. "
                 "Never save secrets, API keys, or personal data.",
)

agent = create_agent(
    model=llm,
    tools=[memory_tool, create_search_memory_tool(namespace=("memories", "{user_id}"))],
    system_prompt="You are a coding assistant. When the user reveals a lasting preference, "
                  "save it with manage_memory without being asked.",
    store=store,
    checkpointer=checkpointer,
)

agent.invoke(
    {"messages": [{"role": "user", "content": "ugh, light mode hurts my eyes"}]},
    config={"configurable": {"thread_id": "t-1", "user_id": "kjana"}},
)
```

The system prompt line ("save it … without being asked") makes the agent more likely to save implicit preferences.

#### Approach 2: Background manager (extraction LLM decides)

```python
from pydantic import BaseModel, Field
from langmem import create_memory_store_manager

class CodingPreference(BaseModel):
    """A lasting coding preference or project fact."""
    category: str = Field(description="One of: style, stack, command, workflow")
    content: str = Field(description="The preference or fact, one sentence")

manager = create_memory_store_manager(
    "openai:gpt-4o-mini",
    namespace=("memories", "{user_id}"),
    schemas=[CodingPreference],
    instructions="Extract only coding style, tech stack, project commands and workflow preferences. "
                 "Ignore small talk. Never extract secrets or personal data.",
    store=store,
)

conversation = [
    {"role": "user", "content": "ugh, light mode hurts my eyes. Also we run tests with make test."},
    {"role": "assistant", "content": "Noted! Switching examples to dark theme."},
]
manager.invoke({"messages": conversation}, config={"configurable": {"user_id": "kjana"}})
# Store now has: {category: "workflow", content: "Prefers dark mode"},
#                {category: "command",  content: "Runs tests with `make test`"}
```

`schemas` restricts the **shape** of what's saved; `instructions` restricts **what kind** of facts.

**Two LLM roles, not necessarily two models.** The example above only shows the extractor. In a full app there are two separate LLM calls with different prompts:

| Role | Job | Prompt it gets |
|---|---|---|
| Agent LLM | Chats with the user and writes the reply | "You are a helpful coding assistant…" |
| Background (extraction) LLM | Reads the finished chat and extracts memories | "Extract coding preferences from this conversation…" |

They can be the same model (e.g., both `gpt-4o-mini`, as in section 8.2), but in production you usually pick a strong model for replies and a cheap one for extraction:

```python
agent_llm = init_chat_model("openai:gpt-4o")              # user-facing, high quality

memory_manager = create_memory_store_manager(
    "openai:gpt-4o-mini",                                 # background, cheap
    namespace=("memories", "{user_id}"),
)
```

Different providers work too, e.g., Claude for chat and Groq Qwen for extraction.

#### Approach 3: Manual (your code decides)

```python
import uuid

def on_settings_changed(user_id: str, theme: str):
    store.put(
        ("memories", user_id),
        "pref-theme",                                   # fixed key → overwritten, never duplicated
        {"category": "workflow", "content": f"Prefers {theme} mode"},
    )

def on_project_opened(user_id: str, repo: str, test_cmd: str):
    store.put(
        ("memories", user_id),
        str(uuid.uuid4()),
        {"category": "command", "content": f"In {repo}, run tests with `{test_cmd}`"},
    )

on_settings_changed("kjana", "dark")
```

Use manual writes for facts your app already knows for certain (settings, profile, repo config). No LLM, no cost, no mistakes.

#### Combining them (typical production setup)

```mermaid
flowchart LR
    S["App events<br/>(settings, profile)"] -->|"Manual: store.put"| ST[("Store")]
    U["User: 'remember X'"] -->|"Memory tool: agent decides"| ST
    C["Every finished conversation"] -->|"Background manager: extractor decides"| ST
```

#### Memory tool vs background manager: both write to the Store, so how do they differ?

| | Memory tool | Background manager |
|---|---|---|
| Who decides | The **same agent** that's chatting | A **separate LLM** whose only job is extraction |
| When | **During** the turn, before the reply | **After** the conversation, in the background |
| What it sees | Current message + recent history | The **whole conversation** |
| User waits? | **Yes**, the tool call adds latency | **No** |
| Reliability | Can forget to save while busy answering | Runs on every conversation |
| Freshness | Immediate (next turn) | Seconds to minutes later |
| Duplicates | May create near-duplicates | Compares with existing memories and updates instead |

Example: *"ugh, light mode hurts my eyes. Can you fix this CSS bug?"* The agent focuses on the CSS and may never call `manage_memory`. The background manager reads the full chat afterwards and saves "Prefers dark mode".

### 4.6 `create_memory_manager` vs `create_memory_store_manager`

Both use an LLM to extract memories. The difference is **who handles storage**.

```mermaid
flowchart LR
    subgraph MM["create_memory_manager"]
        DB1[("Your DB")] -- "you load existing" --> M1["Extraction LLM"]
        C1["Conversation"] --> M1
        M1 -- "returns list" --> YOU["Your code<br/>(filter / save)"]
        YOU --> DB1
    end
    subgraph SM["create_memory_store_manager"]
        C2["Conversation"] --> M2["Extraction LLM"]
        M2 <-- "searches + writes automatically" --> ST[("LangGraph Store")]
    end
```

| | `create_memory_manager` | `create_memory_store_manager` |
|---|---|---|
| Reads existing memories | **You** pass them (`"existing": [...]`) | **It** searches the Store |
| Saves results | **No**, it returns a list | **Yes**, it writes to the Store |
| Needs LangGraph Store? | No; any DB | Yes |
| Namespace | Not applicable | `namespace=("memories", "{user_id}")` |

```python
from langmem import create_memory_manager, create_memory_store_manager

# 1. Plain manager: you handle storage
manager = create_memory_manager("openai:gpt-4o-mini")
existing = my_db.load(user_id)                                    # you read
memories = manager.invoke({"messages": convo, "existing": existing})
my_db.save(user_id, memories)                                     # you write

# 2. Store manager: storage handled for you
store_manager = create_memory_store_manager("openai:gpt-4o-mini",
                                            namespace=("memories", "{user_id}"))
store_manager.invoke({"messages": convo}, config={"configurable": {"user_id": "kjana"}})
```

#### Why not always use `create_memory_store_manager`?

If you use the LangGraph Store, mostly you should. Use the plain `create_memory_manager` when:

| Situation | Why the plain manager |
|---|---|
| Memories live in your own DB (existing Postgres tables, DynamoDB, Pinecone, profile service) | The store manager can only write to a LangGraph Store |
| You must check before saving (PII filter, dedupe, human approval, audit log) | You get the list first and decide what to save |
| Large-scale pipelines | Extraction workers only produce memories; a separate service writes them with its own IDs, versioning and cache invalidation (section 13) |
| Testing / evals | Pure function: messages in, memories out; no DB needed |
| Batch / offline jobs | E.g., extracting memories from historical chat logs in a data warehouse |

**Rule of thumb:** store manager for LangGraph apps and prototypes; plain manager when you own the storage or need control over each write.

---

## 5. Quickstart Walkthrough (the notebook)

### 5.1 Full code

```python
import os
from langchain_groq import ChatGroq
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langgraph.checkpoint.memory import MemorySaver
from langgraph.prebuilt import create_react_agent
from langgraph.store.memory import InMemoryStore
from langgraph.config import get_store
from langmem import create_manage_memory_tool

# 1. Prompt function: inject relevant memories before every LLM call
def prompt(state):
    store = get_store()
    memories = store.search(("memories",), query=state["messages"][-1].content)
    system_msg = f"""You are a helpful assistant.
## Memories
<memories>
{memories}
</memories>
"""
    return [{"role": "system", "content": system_msg}, *state["messages"]]

# 2. Models
embeddings = GoogleGenerativeAIEmbeddings(
    model="gemini-embedding-001",
    google_api_key=os.environ["GOOGLE_API_KEY"],
)
llm = ChatGroq(model="qwen/qwen3-32b", groq_api_key=os.environ["GROQ_API_KEY"], temperature=0)

# 3. Long-term memory (vector-indexed store) + short-term memory (checkpointer)
store = InMemoryStore(index={"embed": embeddings, "dims": 3072})
checkpointer = MemorySaver()

# 4. Agent with a memory tool
agent = create_react_agent(
    llm,
    prompt=prompt,
    tools=[create_manage_memory_tool(namespace=("memories",))],
    store=store,
    checkpointer=checkpointer,
)
```

### 5.2 What each piece does

| Piece | Role |
|---|---|
| `prompt(state)` | Runs before each LLM call. Searches the store with the latest user message and puts matching memories into the system prompt (**retrieval = memory RAG**). |
| `GoogleGenerativeAIEmbeddings` (3072 dims) | Turns memories and queries into vectors for semantic search. `dims` must match the model output. |
| `InMemoryStore(index=...)` | Long-term memory with a vector index. **Lost on restart.** |
| `MemorySaver` | Short-term memory per `thread_id`. **Lost on restart.** |
| `create_manage_memory_tool` | Gives the agent a `manage_memory` tool with actions create / update / delete. |
| `create_react_agent` | ReAct loop: LLM → tool call → tool result → LLM. |

### 5.3 The run, step by step

```mermaid
sequenceDiagram
    autonumber
    actor U as User
    participant A as Agent (LLM)
    participant P as prompt()
    participant S as Store
    participant C as Checkpointer

    Note over U,C: thread-a
    U->>A: "Do you know which display mode I prefer?"
    A->>P: build prompt
    P->>S: search("display mode")
    S-->>P: [] (empty)
    A-->>U: "I don't have that. Want me to remember it?"
    A->>C: save thread-a messages

    U->>A: "I prefer dark mode. Remember that."
    A->>A: decides to call manage_memory
    A->>S: put(("memories",), uuid, {"content": "User prefers dark mode"})
    A-->>U: "Got it, I'll remember."

    Note over U,C: thread-b (NEW conversation, empty history)
    U->>A: "Do you remember me? What are my preferences?"
    A->>P: build prompt
    P->>S: search("preferences")
    S-->>P: ["User prefers dark mode"]
    A-->>U: "You prefer dark mode."
```

Key insight from the notebook: **thread-b has no message history** (new `thread_id`, so the checkpointer is empty), yet the agent knows the preference because it lives in the **store**, which is shared across threads.

### 5.4 Inspecting memories

```python
for m in store.search(("memories",), limit=100):
    print(m.namespace, m.key, m.value)
# ('memories',) 2d849c44-... {'content': 'User prefers dark mode'}
```

### 5.5 Problems with the quickstart (fix before production)

| Issue | Why it matters | Fix |
|---|---|---|
| Namespace `("memories",)` is global | **All users share memories**: user B would see user A's preferences | `("memories", "{user_id}")` (section 11) |
| `InMemoryStore` / `MemorySaver` | Data lost on restart; single process only | `PostgresStore` + `PostgresSaver` (section 12) |
| Memory saving depends on the agent choosing to call the tool | Inconsistent; adds latency to the user's turn | Background extraction (section 8) |
| Memories injected as raw Python repr | Noisy prompt | Format: `"\n".join(m.value["content"] for m in memories)` |
| API keys hard-coded in the notebook | Leaked secrets | Environment variables / secret manager |
| `create_react_agent` deprecated | Removed in LangGraph v2 | `langchain.agents.create_agent` (5.6) |

### 5.6 LangGraph v1 version (`create_agent` + middleware)

```python
from langchain.agents import create_agent
from langchain.agents.middleware import dynamic_prompt, ModelRequest

@dynamic_prompt
def memory_prompt(request: ModelRequest) -> str:
    store = request.runtime.store
    user_id = request.runtime.context["user_id"]
    query = request.state["messages"][-1].content
    items = store.search(("memories", user_id), query=query, limit=5)
    facts = "\n".join(f"- {i.value['content']}" for i in items) or "None"
    return f"You are a helpful assistant.\n\nKnown facts about the user:\n{facts}"

agent = create_agent(
    model=llm,
    tools=[create_manage_memory_tool(namespace=("memories", "{user_id}"))],
    middleware=[memory_prompt],
    store=store,
    checkpointer=checkpointer,
)
```

---

## 6. Hot Path vs Background Memory

The most important design decision in any memory system: **when** do you extract and save memories?

```mermaid
flowchart LR
    subgraph Hot["HOT PATH (during the turn)"]
        H1["User message"] --> H2["Agent LLM"]
        H2 -->|"tool call: manage_memory"| H3[("Store")]
        H2 --> H4["Reply to user"]
    end

    subgraph Bg["BACKGROUND (after the turn)"]
        B1["User message"] --> B2["Agent LLM"] --> B3["Reply to user"]
        B3 -.async.-> B4["Queue / ReflectionExecutor"]
        B4 --> B5["Extraction LLM"]
        B5 --> B6[("Store")]
    end
```

| | Hot path (memory tools) | Background (store manager) |
|---|---|---|
| Latency for user | **Higher**: extra tool call(s) in the turn | **None**: runs after reply |
| Freshness | Immediate (next turn sees it) | Delayed (seconds to minutes) |
| Consistency | Depends on agent remembering to call the tool | Systematic: every conversation processed |
| Context available | Only current turn | Whole conversation, so better extraction |
| Cost | Bloats agent prompt with tool definitions | Separate cheaper model possible |
| Best for | Explicit commands: "remember that…" | Implicit facts, preferences, summaries |

**Production pattern:** both. Hot path for explicit "remember X" requests, background for everything else.

---

## 7. Semantic Memory Deep Dive: Collections vs Profiles

Two ways to shape semantic memory:

```mermaid
flowchart TB
    subgraph Collection["COLLECTION: many small documents"]
        C1["'Prefers dark mode'"]
        C2["'Lives in Berlin'"]
        C3["'Uses Python 3.12'"]
        C4["'Allergic to peanuts'"]
    end
    subgraph Profile["PROFILE: one structured document"]
        P1["UserProfile {<br/> name: 'Asha',<br/> city: 'Berlin',<br/> theme: 'dark',<br/> languages: ['Python']<br/>}"]
    end
```

| | Collection | Profile |
|---|---|---|
| Shape | Unbounded list of memories | Single schema-validated document |
| Retrieval | Semantic search (top-k) | Direct `get` by key, always fully loaded |
| Update | Insert new / update / delete items | Patch fields in place |
| Strength | Captures anything, high recall | Compact, fast, no duplicates |
| Weakness | Duplicates, contradictions, grows forever | Only what the schema defines |
| Use for | Open-ended knowledge, episodes | Core user attributes, settings |

### 7.1 Collection with `create_memory_manager`

```python
from langmem import create_memory_manager

manager = create_memory_manager(
    "anthropic:claude-3-5-haiku-latest",
    instructions="Extract user preferences and personal facts. Skip small talk.",
    enable_inserts=True,     # can create new memories
    enable_deletes=True,     # can remove outdated/contradicted memories
)

conversation = [
    {"role": "user", "content": "I moved from Pune to Berlin last month. Still learning German."},
    {"role": "assistant", "content": "Exciting! How's it going?"},
]
memories = manager.invoke({"messages": conversation})
# [ExtractedMemory(id='...', content=Memory(content='User lives in Berlin, moved from Pune last month')),
#  ExtractedMemory(id='...', content=Memory(content='User is learning German'))]
```

Passing existing memories lets it **update instead of duplicate**:

```python
new_convo = [{"role": "user", "content": "Actually I relocated again, to Munich."}]
updated = manager.invoke({"messages": new_convo, "existing": memories})
# The Berlin memory is UPDATED to Munich (same id), not duplicated
```

### 7.2 Profile with a Pydantic schema

```python
from pydantic import BaseModel
from langmem import create_memory_manager

class UserProfile(BaseModel):
    name: str | None = None
    city: str | None = None
    preferred_theme: str | None = None
    languages: list[str] = []
    dietary_restrictions: list[str] = []

profile_manager = create_memory_manager(
    "anthropic:claude-3-5-haiku-latest",
    schemas=[UserProfile],
    instructions="Maintain a single up-to-date profile of the user.",
    enable_inserts=False,    # keep exactly ONE profile document, update it in place
)
```

### 7.3 How the manager decides insert / update / delete

```mermaid
flowchart TD
    IN["New conversation + existing memories"] --> LLM["Extraction LLM<br/>(tool-calling with schemas)"]
    LLM --> D{"For each fact"}
    D -->|"New info"| INS["INSERT new memory"]
    D -->|"Refines/changes existing"| UPD["UPDATE memory (same id)"]
    D -->|"Contradicts / obsolete"| DEL["DELETE memory"]
    D -->|"Already known / trivial"| SKIP["No-op"]
```

Internally the LLM is given the existing memories (with IDs) and the schemas as tools; it returns tool calls (patch / insert / remove). It can run multiple reflection steps to refine.

---

## 8. Background Memory: Store Manager + ReflectionExecutor

### 8.1 `create_memory_store_manager`

Same extraction logic as `create_memory_manager`, but it **searches the store for relevant existing memories itself and writes results back**.

```python
from langmem import create_memory_store_manager

memory_manager = create_memory_store_manager(
    "anthropic:claude-3-5-haiku-latest",
    namespace=("memories", "{user_id}"),       # {user_id} filled from config at runtime
    instructions="Extract user preferences, facts and goals.",
)
```

```mermaid
sequenceDiagram
    participant App
    participant SM as Store manager
    participant ST as Store
    participant L as Extraction LLM

    App->>SM: invoke(messages, config{user_id})
    SM->>ST: search(("memories", user_id), query=conversation)
    ST-->>SM: relevant existing memories
    SM->>L: conversation + existing memories + schemas
    L-->>SM: insert / update / delete operations
    SM->>ST: put / delete
```

### 8.2 Wiring it into an agent (background)

```python
from langchain.chat_models import init_chat_model
from langgraph.func import entrypoint
from langgraph.store.memory import InMemoryStore
from langgraph.config import get_store
from langmem import create_memory_store_manager, ReflectionExecutor

store = InMemoryStore(index={"dims": 1536, "embed": "openai:text-embedding-3-small"})
llm = init_chat_model("openai:gpt-4o-mini")

memory_manager = create_memory_store_manager(
    "openai:gpt-4o-mini",
    namespace=("memories", "{user_id}"),
)
executor = ReflectionExecutor(memory_manager, store=store)

@entrypoint(store=store)
def chat(messages: list, config):
    user_id = config["configurable"]["user_id"]
    memories = get_store().search(("memories", user_id), query=messages[-1]["content"], limit=5)
    facts = "\n".join(f"- {m.value['content']}" for m in memories)

    reply = llm.invoke([
        {"role": "system", "content": f"You are helpful. Known about the user:\n{facts}"},
        *messages,
    ])

    # Schedule memory extraction AFTER replying; debounce 30s
    executor.submit(
        {"messages": messages + [{"role": "assistant", "content": reply.content}]},
        config=config,
        after_seconds=30,
    )
    return reply.content

chat.invoke([{"role": "user", "content": "I'm vegetarian and love spicy food."}],
            config={"configurable": {"user_id": "user-42"}})
```

### 8.3 Why debounce? (ReflectionExecutor)

```mermaid
gantt
    title Debounced memory extraction (after_seconds=30)
    dateFormat ss
    axisFormat %S s
    section User messages
    msg 1          :m1, 00, 1s
    msg 2          :m2, 10, 1s
    msg 3          :m3, 20, 1s
    section Executor
    timer reset at each msg :active, 00, 20s
    quiet 30s then extract once :crit, 20, 30s
```

- Users send bursts of messages. Extracting after **every** message wastes LLM calls and creates churn (insert → update → update).
- `ReflectionExecutor` **cancels the pending job and reschedules** when a new message arrives for the same thread. Extraction runs once the conversation goes quiet, over the full context.
- On LangGraph Platform it can run as a remote background run; locally it uses a thread pool.

---

## 9. Episodic Memory

Episodic memory stores **experiences**, typically successful interactions to reuse as few-shot examples.

```python
from pydantic import BaseModel, Field
from langmem import create_memory_store_manager

class Episode(BaseModel):
    """A successful interaction worth repeating."""
    observation: str = Field(description="The situation and context")
    thoughts: str = Field(description="Key reasoning that led to success")
    action: str = Field(description="What was done")
    result: str = Field(description="Outcome and why it worked")

episode_manager = create_memory_store_manager(
    "anthropic:claude-3-5-sonnet-latest",
    namespace=("episodes", "{user_id}"),
    schemas=[Episode],
    instructions="Extract episodes where the user expressed satisfaction or the task succeeded.",
    enable_inserts=True,
)
```

```mermaid
flowchart LR
    Q["New task: debug a failing<br/>Docker build"] --> S["search episodes<br/>('docker build failure')"]
    S --> E[("Episodes store")]
    E --> F["Top-2 similar past successes"]
    F --> P["Inject as few-shot examples<br/>in system prompt"]
    P --> LLM["Agent solves faster,<br/>same proven approach"]
```

---

## 10. Procedural Memory: Prompt Optimization

Procedural memory = **how the agent behaves**, encoded in its system prompt. LangMem can **rewrite the prompt** from conversations + feedback.

```mermaid
flowchart LR
    P0["System prompt v1"] --> AG["Agent runs in production"]
    AG --> TR["Trajectories (conversations)"]
    FB["User feedback<br/>👍/👎, comments"] --> OPT
    TR --> OPT["Prompt optimizer LLM"]
    OPT --> P1["System prompt v2"]
    P1 -->|"eval gate passes"| AG
```

```python
from langmem import create_prompt_optimizer

optimizer = create_prompt_optimizer(
    "anthropic:claude-3-5-sonnet-latest",
    kind="metaprompt",                                   # "gradient" | "metaprompt" | "prompt_memory"
    config={"max_reflection_steps": 3, "min_reflection_steps": 0},
)

trajectories = [
    ([{"role": "user", "content": "Explain Kubernetes"},
      {"role": "assistant", "content": "<long 900-word essay>"}],
     {"score": 0, "comment": "Too long. I wanted 3 bullet points."}),
    ([{"role": "user", "content": "What is a pod?"},
      {"role": "assistant", "content": "- Smallest deployable unit\n- One or more containers\n- Shared network"}],
     {"score": 1, "comment": "Perfect"}),
]

new_prompt = optimizer.invoke({
    "trajectories": trajectories,
    "prompt": "You are a helpful DevOps assistant.",
})
# → "You are a helpful DevOps assistant. Answer concisely, preferably as 3-5 bullet points ..."
```

| `kind` | How it works | Cost | Use when |
|---|---|---|---|
| `prompt_memory` | Single pass: extract lessons, append | Low | Quick, simple fixes |
| `metaprompt` | Reflect over trajectories, then rewrite | Medium | Default choice |
| `gradient` | Separate critique ("gradient") step, then targeted edit | Higher | Precise, minimal edits |

`create_multi_prompt_optimizer` optimizes several prompts in a multi-agent system together and attributes blame to the right agent's prompt.

> **Always gate prompt updates with evals** (DeepEval/LangSmith dataset). An optimizer can overfit to a few loud complaints.

---

## 11. Multi-Tenancy with Namespaces

```mermaid
flowchart TD
    ROOT["Store"] --> ORG1["('org-acme',)"]
    ROOT --> ORG2["('org-globex',)"]
    ORG1 --> U1["('org-acme', 'user-42', 'memories')"]
    ORG1 --> U2["('org-acme', 'user-77', 'memories')"]
    ORG1 --> SH["('org-acme', 'shared', 'policies')"]
    U1 --> I1["prefers dark mode"]
    U1 --> I2["works on payments team"]
    SH --> I3["refund policy is 30 days"]
```

Template variables are filled from `config["configurable"]` at runtime, so **the LLM can never choose another user's namespace**:

```python
tool = create_manage_memory_tool(namespace=("{org_id}", "{user_id}", "memories"))

agent.invoke(
    {"messages": [{"role": "user", "content": "Remember I prefer dark mode"}]},
    config={"configurable": {"thread_id": "t-1", "org_id": "org-acme", "user_id": "user-42"}},
)
```

| Namespace level | Holds | Who writes |
|---|---|---|
| `(org, user, "memories")` | Personal facts | Agent / background extractor |
| `(org, user, "episodes")` | Personal successful episodes | Background extractor |
| `(org, "shared", "policies")` | Org-wide knowledge | Admins / ingestion pipeline (read-only for agent) |
| `("global", "prompts")` | Procedural memory (prompts) | Prompt optimizer + eval gate |

Security rule: **derive `user_id` from the authenticated session server-side**, never from the request body or the LLM.

---

## 12. Going to Production: Postgres + pgvector

```python
from langgraph.store.postgres import PostgresStore
from langgraph.checkpoint.postgres import PostgresSaver
from langchain.agents import create_agent
from langmem import create_manage_memory_tool, create_search_memory_tool

DB_URI = "postgresql://user:pass@db:5432/agent?sslmode=require"

with PostgresStore.from_conn_string(
    DB_URI,
    index={"dims": 1536, "embed": "openai:text-embedding-3-small", "fields": ["content"]},
) as store, PostgresSaver.from_conn_string(DB_URI) as checkpointer:
    store.setup()          # creates tables + pgvector index (run once / in migrations)
    checkpointer.setup()

    agent = create_agent(
        model="openai:gpt-4o-mini",
        tools=[
            create_manage_memory_tool(namespace=("memories", "{user_id}")),
            create_search_memory_tool(namespace=("memories", "{user_id}")),
        ],
        store=store,
        checkpointer=checkpointer,
    )
```

| Dev | Production |
|---|---|
| `InMemoryStore` | `PostgresStore` (pgvector) or LangGraph Platform store |
| `MemorySaver` | `PostgresSaver` (or Redis checkpointer) |
| Hard-coded keys | Secret manager (AWS Secrets Manager, GCP Secret Manager, Vault) |
| One process | Many stateless app replicas sharing DB |
| `fields` unset | `fields=["content"]` so only the text is embedded |

Async apps: use `AsyncPostgresStore` / `AsyncPostgresSaver`.

---

## 13. FAANG-Scale Memory System Design

**Problem:** design long-term memory for an AI assistant with **100M users, 1B messages/day**, p99 added latency < 100 ms for memory retrieval, strict privacy (GDPR delete), and multi-region.

### 13.1 Requirements

| Functional | Non-functional |
|---|---|
| Remember facts/preferences across sessions | Retrieval p99 < 100 ms |
| User can view / edit / delete memories | Writes are async; eventual consistency OK (seconds) |
| Explicit "remember this" works immediately | 99.9% availability; degrade gracefully (answer without memory) |
| Org/shared knowledge + personal memory | Strict tenant isolation, encryption, GDPR/CCPA delete within SLA |
| Procedural improvements to prompts | Cost-efficient: extraction must be cheap at 1B msgs/day |

### 13.2 High-level architecture

```mermaid
flowchart TB
    Client["Clients (web / mobile)"] --> GW["API Gateway<br/>auth, rate limit"]
    GW --> CHAT["Chat / Agent Service<br/>(stateless, autoscaled)"]

    CHAT -->|"1. read profile"| CACHE[("Redis<br/>profile + hot memories")]
    CHAT -->|"2. semantic recall"| MEMAPI["Memory Service API"]
    MEMAPI --> VDB[("Vector DB<br/>sharded by user_id")]
    MEMAPI --> PDB[("Profile / metadata DB<br/>Postgres / DynamoDB / Spanner")]
    CHAT -->|"3. LLM call"| LLMGW["LLM Gateway<br/>(LiteLLM / Portkey)"]
    CHAT -->|"4. thread state"| CKPT[("Checkpointer<br/>Redis / Postgres")]

    CHAT -->|"5. publish turn event"| BUS[["Kafka / Kinesis<br/>conversation-events<br/>partitioned by user_id"]]
    BUS --> EXT["Memory Extraction Workers<br/>(LangMem store manager)<br/>debounced per thread"]
    EXT --> LLMGW
    EXT --> MEMAPI

    BUS --> PII["PII / Safety filter"]
    PII --> EXT

    CRON["Nightly Consolidation Jobs"] --> MEMAPI
    FB["Feedback events"] --> PO["Prompt Optimizer + Eval Gate"]
    PO --> PROMPTS[("Prompt registry<br/>versioned")]
    PROMPTS --> CHAT

    DEL["Privacy Service<br/>GDPR delete / export"] --> MEMAPI
    DEL --> CKPT
```

### 13.2.1 How write and read connect (simplified)

Two separate paths, connected **only through the database**:
- **Write path** (Kafka, background): after a chat, extract memories and **save** them to the vector DB.
- **Read path** (next request): before calling the LLM, **read** memories from the vector DB and put them in the prompt.

```mermaid
flowchart LR
    subgraph Write["WRITE: after chat (background)"]
        C1["Chat turn finished"] --> K[["Kafka<br/>partitioned by user_id"]]
        K --> W["Extraction worker<br/>batches per user, LangMem"]
        W --> V[("Vector DB + profile DB")]
    end

    subgraph Read["READ: next request"]
        U["User sends new message"] --> A["Agent service"]
        V -->|"search(user_id, query)"| A
        A --> P["Prompt = system + memories + message"]
        P --> L["LLM"]
    end
```

**Monday:** the user says *"I prefer pytest."*
1. The agent replies.
2. The turn is published to Kafka with key `user_id=kjana` (same user → same partition → ordered).
3. A worker waits, **batches** that user's recent turns, and runs LangMem extraction once.
4. It saves "Prefers pytest" to the vector DB under `kjana`.

**Friday:** the user says *"Write a test for refund()."*
1. The agent service searches the vector DB: `kjana` + "write a test" → "Prefers pytest".
2. It builds the prompt:

   ```
   System: You are a coding assistant.
   Known about user:
   - Prefers pytest
   User: Write a test for refund()
   ```

3. The LLM writes a pytest test.

The LLM receives **one prompt** that already **contains** the memories. It never queries the database itself; your code fetches memories and pastes them into the prompt (the same thing the notebook's `prompt()` function does).

### 13.3 Read path (synchronous, latency-critical)

```mermaid
sequenceDiagram
    autonumber
    participant C as Client
    participant A as Agent Service
    participant R as Redis
    participant M as Memory Service
    participant V as Vector DB
    participant L as LLM

    C->>A: message (JWT → user_id)
    par in parallel
        A->>R: GET profile:user_id
        R-->>A: profile (cache hit ~1 ms)
    and
        A->>M: recall(user_id, query, k=8)
        M->>V: ANN search in user partition
        V-->>M: top-k (~10-30 ms)
        M-->>A: memories (rerank, dedupe)
    end
    A->>A: build prompt (budget: ≤ 800 memory tokens)
    A->>L: generate (stream)
    L-->>C: streamed tokens
    A--)A: publish turn event (fire-and-forget)
```

Latency tricks:
- **Parallel** profile fetch + vector recall, both bounded by a **timeout (e.g., 80 ms)**. On timeout, answer **without memory** rather than fail.
- **Profile always loaded** (small, cached); **collection memories** only top-k by similarity.
- **Token budget** for memory in prompt; rerank by `similarity × recency × importance`.
- Skip recall entirely for trivial turns ("thanks!") using a cheap classifier.

### 13.4 Write path (asynchronous, cost-critical)

```mermaid
flowchart LR
    E["Turn event"] --> K[["Kafka partition<br/>(hash user_id)"]]
    K --> D["Debouncer<br/>(per thread, 30-120s)"]
    D --> G{"Worth extracting?<br/>cheap classifier"}
    G -- No --> X["Drop (≈70% of turns)"]
    G -- Yes --> PII["PII redaction /<br/>sensitive-category filter"]
    PII --> EX["LangMem store manager<br/>small model"]
    EX --> OPS["insert / update / delete ops"]
    OPS --> IDEM["Idempotent upsert<br/>(event_id, memory_id, version)"]
    IDEM --> V[("Vector DB")]
    IDEM --> P[("Profile DB")]
    IDEM --> INV["Invalidate Redis cache"]
```

- **Partition by `user_id`** gives per-user ordering, so no two workers update the same user's memories concurrently.
- **Debounce per thread** (ReflectionExecutor idea at scale) cuts extraction calls by 5–10×.
- **Gate with a cheap classifier**: most turns contain nothing memorable.
- **Small/cheap model** for extraction (e.g., Haiku / GPT-4o-mini / fine-tuned 8B), big model only for the user-facing reply.
- **Idempotency**: Kafka is at-least-once, so upserts keyed by `(memory_id, version)`.
- **Explicit "remember X"** goes through the **hot path** tool (immediate write + cache invalidation) so the user sees it on the next turn.

### 13.5 Data model

```mermaid
erDiagram
    USER ||--o| PROFILE : has
    USER ||--o{ MEMORY : has
    USER ||--o{ EPISODE : has
    MEMORY {
        uuid memory_id PK
        string tenant_id
        string user_id
        string type "preference | fact | goal"
        text content
        vector embedding
        float importance
        int access_count
        timestamp created_at
        timestamp last_accessed_at
        timestamp expires_at
        string source_thread_id
        int version
        bool user_editable
    }
    PROFILE {
        string user_id PK
        json attributes "name, city, theme, languages"
        int version
        timestamp updated_at
    }
    EPISODE {
        uuid episode_id PK
        string user_id
        text observation
        text action
        text result
        vector embedding
    }
```

### 13.6 Storage choices

| Component | Options | Why |
|---|---|---|
| Vector memories | pgvector (to ~100M vectors with partitioning), Milvus, Pinecone, OpenSearch k-NN, Vertex Vector Search, Turbopuffer | ANN search per user; filter on `user_id` |
| Profile | DynamoDB / Spanner / Postgres | Key-value by `user_id`, strongly consistent |
| Cache | Redis / Memcached | Profiles + hot memories, TTL 10–60 min |
| Thread state | Redis (hot) + Postgres/S3 (cold) | High write rate, short-lived |
| Events | Kafka / Kinesis / Pub/Sub | Decouple write path, replay for reprocessing |

**Sharding:** shard vector + profile data by `hash(user_id)`. Every query is scoped to one user, so there are **no cross-shard queries**. For pgvector, use one HNSW index per partition, or a namespace per tenant in managed vector DBs.

### 13.7 Back-of-envelope sizing

| Quantity | Estimate |
|---|---|
| Users | 100M; ~20M DAU |
| Turns/day | 1B → ~11.6k/s avg, ~35k/s peak |
| Recall QPS | ≈ turns → ~35k/s peak (minus skipped trivial turns) |
| Extraction calls/day | 1B × 30% (gate) ÷ 5 (debounce) ≈ **60M/day** (~700/s) |
| Memories/user | cap ~500 → 100M × 500 = **50B** worst case; realistically ~5–10B after consolidation |
| Storage per memory | ~200 B text + 1536-dim float32 (6 KB) → quantize to int8/PQ (~1.5 KB) |
| Vector storage | 10B × 1.5 KB ≈ **15 TB** → sharded cluster |

These numbers drive the big decisions: **quantized embeddings**, **per-user caps + consolidation**, **aggressive gating** of extraction.

### 13.8 Memory lifecycle: consolidation, decay, conflicts

```mermaid
stateDiagram-v2
    [*] --> Extracted
    Extracted --> Active: passes dedupe + PII filter
    Active --> Active: accessed (importance↑, last_accessed updated)
    Active --> Updated: new conflicting info (newer wins, version++)
    Updated --> Active
    Active --> Merged: nightly consolidation (similar memories clustered)
    Merged --> Active
    Active --> Decayed: not accessed for N days and low importance
    Decayed --> Deleted: TTL expired
    Active --> Deleted: user deletes / GDPR request
    Deleted --> [*]
```

- **Dedupe on write:** before insert, search similar memories (cosine > 0.9) and update instead of insert. LangMem's manager does this when given existing memories.
- **Conflict resolution:** "lives in Berlin" vs "lives in Munich": prefer the newer one; keep history with `version` for audit.
- **Consolidation job:** nightly, cluster a user's memories and summarize into fewer, richer ones (LangMem manager over the memory list itself).
- **Decay:** score = `importance × e^(−λ·days_since_access)`; evict below threshold or past `expires_at`.

### 13.9 Privacy, safety, compliance

| Concern | Control |
|---|---|
| Tenant isolation | Namespace/partition key from authenticated session; row-level security; tests that try cross-user reads |
| Sensitive data | Do not store health, religion, sexual orientation, credentials, card numbers unless explicitly allowed; PII detector (Presidio / Bedrock Guardrails) before write |
| Memory poisoning / prompt injection | Treat memories as **untrusted data**: wrap in `<memories>` tags, never as instructions; validate extraction outputs; don't let documents/tools write memories without filtering |
| User control | "Manage memories" UI: view, edit, delete, pause memory |
| GDPR / CCPA delete | Privacy service deletes across vector DB, profile DB, cache, checkpoints, Kafka-derived stores, backups (crypto-shredding with per-user keys) |
| Encryption | At rest (KMS), in transit (TLS), per-tenant keys for enterprise |
| Audit | Log memory writes with source thread and model version |

### 13.10 Failure modes & degradation

| Failure | Behavior |
|---|---|
| Vector DB slow / down | Timeout → answer with profile only (or no memory); alert |
| Redis down | Fall back to profile DB; higher latency but correct |
| Extraction workers lagging | Kafka buffers; memory freshness degrades, chat unaffected |
| Bad extraction model release | Version memories by `model_version`; roll back + reprocess from Kafka/event log |
| Prompt optimizer regression | Prompt registry versioning + eval gate + canary rollout + instant rollback |

### 13.11 Evaluating the memory system

| Metric | How |
|---|---|
| **Recall accuracy** | Golden conversations: "session 1 states fact → session 2 asks about it"; check answer (DeepEval G-Eval / LangSmith judge) |
| **Extraction precision** | Sample extracted memories; human/LLM judge: correct, useful, not sensitive? |
| **Contradiction rate** | Count conflicting memories per user |
| **Retrieval relevance** | Contextual relevancy of injected memories to the query |
| **Personalization lift** | A/B test: thumbs-up rate, task success, retention with vs without memory |
| **Latency / cost** | p99 recall latency, extraction $ per 1k users per day |

---

## 14. Pitfalls, Cheat Sheet & Interview Questions

### 14.1 Common pitfalls

| Pitfall | Fix |
|---|---|
| Global namespace like the quickstart's `("memories",)` | Always include `{user_id}` (and `{org_id}`) |
| `dims` mismatch with embedding model | Gemini `gemini-embedding-001` = 3072, OpenAI `text-embedding-3-small` = 1536 |
| Memory store grows forever | Caps, consolidation, TTL/decay |
| Duplicate / contradictory memories | Pass existing memories to manager; dedupe on write |
| Extraction on every message | Debounce (ReflectionExecutor) + gating |
| Injecting all memories into prompt | Top-k + token budget + rerank |
| Treating memories as instructions | Wrap as data; guard against injection |
| Secrets in notebooks | Env vars / secret manager; rotate leaked keys |

### 14.2 Cheat sheet

```python
from langgraph.store.memory import InMemoryStore
from langgraph.store.postgres import PostgresStore
from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.config import get_store
from langmem import (
    create_manage_memory_tool, create_search_memory_tool,      # hot path
    create_memory_manager, create_memory_store_manager,         # extraction
    ReflectionExecutor,                                         # debounced background
    create_prompt_optimizer, create_multi_prompt_optimizer,     # procedural
)

store = InMemoryStore(index={"dims": 1536, "embed": "openai:text-embedding-3-small"})
store.put(ns, key, {"content": "..."}); store.search(ns, query="...", limit=5)

create_manage_memory_tool(namespace=("memories", "{user_id}"))
create_memory_store_manager("openai:gpt-4o-mini", namespace=("memories", "{user_id}"))
ReflectionExecutor(manager, store=store).submit({"messages": msgs}, config=cfg, after_seconds=30)
create_prompt_optimizer("anthropic:claude-3-5-sonnet-latest", kind="metaprompt")
```

### 14.3 Interview questions

1. **Checkpointer vs Store?** Checkpointer = per-thread conversation state (short-term). Store = cross-thread namespaced JSON documents with vector search (long-term).
2. **Semantic vs episodic vs procedural memory?** Facts/preferences vs past experiences (few-shot examples) vs behavior rules (system prompt).
3. **Hot path vs background memory?** Hot path = agent writes via tool during the turn (fresh, but adds latency and is inconsistent). Background = separate extractor after the turn (no latency, systematic, delayed). Production uses both.
4. **Collection vs profile?** Many searchable documents vs one schema-validated document; profile for core attributes, collection for open-ended facts.
5. **How does LangMem avoid duplicate memories?** The manager receives existing memories and can update/delete them by ID instead of inserting new ones.
6. **Why debounce extraction?** Users send bursts; extracting once after the conversation settles is cheaper and sees full context.
7. **How do you isolate users?** Namespace templates (`{user_id}`) filled from server-side authenticated config; partition storage by user; never let the LLM choose namespaces.
8. **How would you scale memory to 100M users?** Async write path via Kafka partitioned by user, gated + debounced extraction with a cheap model, vector DB sharded by user with quantized embeddings, Redis-cached profiles, timeouts with graceful degradation, consolidation and decay jobs.
9. **What are memory security risks?** Cross-tenant leakage, storing sensitive PII, memory poisoning via prompt injection, incomplete GDPR deletion.
10. **How do you evaluate memory?** Multi-session golden tests for recall, extraction precision sampling, contradiction rate, retrieval relevance, A/B personalization lift, latency and cost.
