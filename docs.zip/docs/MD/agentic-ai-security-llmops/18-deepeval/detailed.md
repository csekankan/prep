# 18 — DeepEval: Goldens, Test Cases, G-Eval, DAG, QAG, RAG & Agent Evals

> **One sentence:** DeepEval is "**pytest for LLMs**". You write `LLMTestCase`s (or generate them from **Goldens**), attach metrics (built-in or custom: **G-Eval**, **DAG**, QAG-based), and run them in CI with `deepeval test run`.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Introduction to DeepEval for evaluations | Basics |
| Goldens, LLMTestCases and evaluation pipeline | Basics, Code §1 |
| (IMPORTANT) The complete LLM evaluation pipeline explained | Deep dive |
| DeepEval metrics overview: G-Eval, DAG, QAG | Deep dive |
| Custom metrics: G-Eval demo / implementation | Code §2 |
| Custom metrics: DAG demo / implementation | Code §3 |
| Custom metrics: QAG explained | Deep dive |
| RAG evals metrics explained | Code §4 |
| Evaluation of RAG with DeepEval | Code §4 |
| Understanding AI agents evaluations | Basics, Code §5 |
| Agentic evals metrics explained | Code §5 |
| Evaluation of AI agent with DeepEval | Code §5–§6 |

---

## Basics

| Concept | Meaning |
|---------|---------|
| **Golden** | Dataset entry *before* running the app: `input` (+ `expected_output`, `context`) |
| **LLMTestCase** | Golden **plus** your app's `actual_output` and `retrieval_context` (+ `tools_called`) |
| **EvaluationDataset** | A collection of goldens/test cases (push/pull from Confident AI) |
| **Metric** | Scores a test case 0–1, with a `threshold` for pass/fail and a `reason` |
| **`evaluate()` / `assert_test()`** | Run in a script or in pytest |

**Analogy:** A Golden is an **exam question with an answer key**. A test case is the **student's answer sheet** for that question. Metrics are the **graders**.

---

## Code

### 1. Goldens → test cases → evaluate

```python
from deepeval.dataset import EvaluationDataset, Golden
from deepeval.test_case import LLMTestCase
from deepeval.metrics import AnswerRelevancyMetric
from deepeval import evaluate

goldens = [Golden(input="What's our refund window?", expected_output="30 days")]
dataset = EvaluationDataset(goldens=goldens)

for g in dataset.goldens:
    out, ctx = my_rag(g.input)
    dataset.add_test_case(LLMTestCase(input=g.input, actual_output=out,
                                      expected_output=g.expected_output, retrieval_context=ctx))

evaluate(test_cases=dataset.test_cases, metrics=[AnswerRelevancyMetric(threshold=0.7)])
```

Pytest style (CI):

```python
# test_rag.py
import pytest
from deepeval import assert_test

@pytest.mark.parametrize("tc", dataset.test_cases)
def test_rag(tc):
    assert_test(tc, [AnswerRelevancyMetric(threshold=0.7)])
```

```bash
deepeval test run test_rag.py -n 4      # parallel
```

### 2. G-Eval (custom criteria with an LLM judge)

```python
from deepeval.metrics import GEval
from deepeval.test_case import LLMTestCaseParams

correctness = GEval(
    name="Correctness",
    criteria="Determine whether the actual output is factually correct based on the expected output.",
    # or explicit steps (more stable than criteria):
    evaluation_steps=[
        "Check whether facts in 'actual output' contradict 'expected output'.",
        "Heavily penalize omission of key details.",
        "Vague language or differing opinions are OK.",
    ],
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT, LLMTestCaseParams.EXPECTED_OUTPUT],
    threshold=0.6,
    model="gpt-4o",
)
correctness.measure(tc); print(correctness.score, correctness.reason)
```

### 3. DAG metric (deterministic decision tree + LLM judgments)

```python
from deepeval.metrics.dag import (DeepAcyclicGraph, TaskNode, BinaryJudgementNode,
                                  NonBinaryJudgementNode, VerdictNode)
from deepeval.metrics import DAGMetric

# Example: grade a meeting summary
has_headings = BinaryJudgementNode(
    criteria="Does the summary contain the headings: 'Intro', 'Action Items', 'Decisions'?",
    children=[
        VerdictNode(verdict=False, score=0),
        VerdictNode(verdict=True, child=NonBinaryJudgementNode(
            criteria="Are the headings in the correct order: Intro, Decisions, Action Items?",
            children=[
                VerdictNode(verdict="All correct", score=10),
                VerdictNode(verdict="Two out of order", score=4),
                VerdictNode(verdict="All out of order", score=2),
            ])),
    ])
extract = TaskNode(instructions="Extract all headings from the actual output.",
                   evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
                   output_label="headings", children=[has_headings])

dag = DAGMetric(name="Summary format", dag=DeepAcyclicGraph(root_nodes=[extract]), threshold=0.5)
```

DAG = **explicit rubric logic**. Each node asks the LLM one narrow question, and the tree determines the score. That's far more consistent than one big "rate 1–10" prompt.

### 4. RAG metrics

```python
from deepeval.metrics import (FaithfulnessMetric, AnswerRelevancyMetric,
     ContextualPrecisionMetric, ContextualRecallMetric, ContextualRelevancyMetric)

rag_metrics = [
    FaithfulnessMetric(threshold=0.8),          # generator: claims supported by retrieval_context
    AnswerRelevancyMetric(threshold=0.7),       # generator: statements relevant to input
    ContextualPrecisionMetric(threshold=0.7),   # retriever: relevant nodes ranked first (needs expected_output)
    ContextualRecallMetric(threshold=0.7),      # retriever: expected_output covered by context
    ContextualRelevancyMetric(threshold=0.7),   # retriever: share of context relevant to input
]
evaluate(dataset.test_cases, rag_metrics)
```

### 5. Agent metrics

```python
from deepeval.test_case import ToolCall
from deepeval.metrics import ToolCorrectnessMetric, TaskCompletionMetric, ArgumentCorrectnessMetric

tc = LLMTestCase(
    input="Book a table for 2 at 7pm at Luigi's",
    actual_output="Booked Luigi's for 2 at 7pm. Confirmation #A12.",
    tools_called=[ToolCall(name="search_restaurant", input_parameters={"name": "Luigi's"}),
                  ToolCall(name="book_table", input_parameters={"party": 2, "time": "19:00"})],
    expected_tools=[ToolCall(name="search_restaurant"), ToolCall(name="book_table")],
)
evaluate([tc], [ToolCorrectnessMetric(), TaskCompletionMetric(threshold=0.7), ArgumentCorrectnessMetric()])
```

### 6. Tracing-based agent evals (component level)

```python
from deepeval.tracing import observe, update_current_span
from deepeval.metrics import TaskCompletionMetric

@observe(type="tool")
def book_table(party, time): ...

@observe(type="agent", metrics=[TaskCompletionMetric()])
def agent(query: str):
    ...
    update_current_span(test_case=LLMTestCase(input=query, actual_output=answer))
    return answer
```

---

## Deep dive

### The complete LLM evaluation pipeline

```mermaid
flowchart LR
  A[Curate goldens<br/>prod logs + synthetic + experts] --> B[Run app on goldens<br/>→ test cases]
  B --> C[Metrics<br/>RAG / agent / custom]
  C --> D[Report + compare<br/>vs baseline]
  D --> E{Pass thresholds?}
  E -->|yes| F[Deploy]
  E -->|no| G[Fix prompt / retriever / model]
  G --> B
  F --> H[Online monitoring<br/>sample prod traces]
  H --> A
```

### Three techniques behind custom metrics

| Technique | How it works | Strength | Weakness |
|-----------|-------------|----------|----------|
| **G-Eval** | LLM generates (or you give) **evaluation steps**, a form-filling prompt scores 1–10, and the score is weighted by **token probabilities** of the score tokens (normalized to 0–1) | Flexible, fast to write | Can be subjective/unstable |
| **DAG** | You define a **decision tree** of narrow LLM judgments and fixed scores at the leaves | Deterministic structure, explainable | More effort to build |
| **QAG** (Question-Answer Generation) | Break the output into **closed yes/no questions** (e.g. "is claim X supported by context?"), then score = fraction of "yes" | Precise, low variance, used inside faithfulness/relevancy | Needs a well-defined decomposition |

Most built-in DeepEval RAG metrics are **QAG-based**: extract statements/claims, then do yes/no verdicts per claim, then compute a ratio.

## Advanced

- **`strict_mode=True`** turns scores binary (0/1) for hard gates.
- **`include_reason`** gives explanations that help debugging but cost extra tokens.
- **Custom judge model:** subclass `DeepEvalBaseLLM` to use Azure, Bedrock, or local models.
- **Synthetic goldens:** `Synthesizer().generate_goldens_from_docs(...)` with "evolutions" (reasoning, multi-context, comparative) for harder cases.
- **Conversational metrics:** `ConversationalTestCase` + turn-level metrics (role adherence, knowledge retention, conversation completeness).
- **Red-teaming** (DeepTeam, the sister project) covers vulnerabilities like bias, PII leakage, and jailbreaks.

## Production & scale

- Run fast deterministic metrics on every PR and the full LLM-judge suite nightly or pre-release.
- Cache test cases (app outputs) separately from metric runs, so you can re-score without re-running the app.
- Track metric trends over time (Confident AI platform or your own dashboard).

## FAANG insights

- Mature teams evaluate at **three levels**: component (retriever recall@k, tool selection), end-to-end (task success), and business (resolution rate, CSAT).
- Rubric-style metrics (DAG-like) are preferred for **policy compliance** because legal and safety teams can read and approve the tree.
- Interview: *"How do you evaluate an agent that takes 10 steps?"* Cover trajectory metrics (tool correctness, step efficiency), outcome metrics (task completion), per-step span metrics, and cost/latency.

## Interview questions

1. **Golden vs LLMTestCase?** An input + expectation vs the same plus the actual output and context from running the app.
2. **Why are DAG metrics more stable than G-Eval?** They decompose judgment into narrow binary/categorical questions with fixed scores.
3. **What's QAG?** Closed-ended question generation for scoring, which reduces judge subjectivity.

## Checklist

- [ ] Goldens versioned and reviewed
- [ ] Retriever + generator + agent metrics
- [ ] At least one domain-specific G-Eval/DAG metric
- [ ] `deepeval test run` in CI with thresholds
