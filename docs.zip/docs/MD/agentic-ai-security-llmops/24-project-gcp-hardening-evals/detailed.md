# 24 — Project 1 Hardening: Guardrails, Gateways, Evaluation Pipeline

> **One sentence:** Take the GCP agentic RAG app from section 23 and make it **production-grade**: wrap it with input/output guardrails, route all LLM calls through a gateway, and build a two-phase **evaluation pipeline** that scores retrieval and generation before every release.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Why we need guardrails | Basics |
| Integrating guardrails in our system | Code §1 |
| Why we need gateways | Basics |
| Integrating gateways in our app | Code §2 |
| Why we need to evaluate our app | Basics |
| Different LLM evaluation terminologies | Basics (see [17](../17-llm-evaluation-ragas/detailed.md)) |
| Various evaluation frameworks | Basics (table) |
| Token efficiency and experiment notebook setup | Code §3 |
| Faithfulness, answer relevancy, context precision | Code §3 |
| Context recall, answer and tool correctness | Code §3 |
| Understanding evaluations integration process | Deep dive |
| Eval pipeline phase 1 | Code §4 |
| Eval pipeline phase 2 | Code §5 |
| Final evaluation app testing | Code §6 |

---

## Basics

### Why each layer exists

| Layer | Without it… |
|-------|-------------|
| **Guardrails** | Jailbreaks, PII leaks, off-topic use, hallucinated answers reach users |
| **Gateway** | Provider outage = downtime, no cost visibility, keys scattered |
| **Evals** | Every prompt/model/chunking change is a blind gamble |

### Evaluation frameworks at a glance

| Framework | Strength |
|-----------|----------|
| RAGAS | RAG metrics, synthetic test sets |
| DeepEval | Pytest-style, custom G-Eval/DAG, agent metrics |
| LangSmith evals | Tied to traces + datasets + experiments UI |
| TruLens | RAG triad + feedback functions |
| Arize Phoenix | OSS tracing + evals |
| Promptfoo | CLI, config-driven, red-teaming |

---

## Code

### 1. Guardrails integrated into the graph

```python
from guardrails import Guard
from guardrails.hub import DetectPII, DetectJailbreak, ToxicLanguage

input_guard = Guard().use_many(
    DetectJailbreak(on_fail="exception"),
    DetectPII(pii_entities=["EMAIL_ADDRESS", "PHONE_NUMBER", "CREDIT_CARD"], on_fail="fix"),
)
output_guard = Guard().use_many(
    ToxicLanguage(on_fail="exception"),
    DetectPII(on_fail="fix"),
)

def input_rail(state):
    try:
        res = input_guard.validate(state["question"])
        return {"question": res.validated_output, "blocked": False}
    except Exception:
        return {"blocked": True, "answer": "Sorry, I can't help with that request."}

def output_rail(state):
    res = output_guard.validate(state["answer"])
    return {"answer": res.validated_output}

g.add_node("input_rail", input_rail); g.add_node("output_rail", output_rail)
g.add_edge(START, "input_rail")
g.add_conditional_edges("input_rail", lambda s: END if s["blocked"] else "planner")
g.add_edge("responder", "output_rail"); g.add_edge("output_rail", END)
```

Add a **grounding check** on the output (LLM judge or Bedrock/Model Armor style). If the answer isn't supported by `docs`, replace it with "I couldn't find that in the documents".

### 2. Gateway integration

```python
from langchain_openai import ChatOpenAI
llm = ChatOpenAI(
    base_url=os.environ["GATEWAY_URL"],        # Portkey / Bifrost / TensorZero OpenAI endpoint
    api_key=os.environ["GATEWAY_KEY"],
    model=os.environ.get("LLM_MODEL", "openai/gpt-4o-mini"),
    default_headers={"x-tenant": "acme", "x-app": "rag-api"},
    timeout=30, max_retries=0,                 # retries live in the gateway (one layer only!)
)
```

Gateway config: fallback chain (primary → secondary provider), 10 s timeout, semantic cache for FAQs, and per-app budget.

### 3. Eval notebook setup + metrics

```python
from ragas import evaluate, EvaluationDataset, SingleTurnSample
from ragas.metrics import Faithfulness, ResponseRelevancy, LLMContextPrecisionWithReference, \
                          LLMContextRecall, FactualCorrectness
from ragas.run_config import RunConfig

goldens = load_jsonl("evals/goldens.jsonl")      # {question, reference, tags}
samples = []
for g_ in goldens:
    out = graph.invoke({"question": g_["question"]})
    samples.append(SingleTurnSample(user_input=g_["question"], response=out["answer"],
                                    retrieved_contexts=[d["text"] for d in out["docs"]],
                                    reference=g_["reference"]))
res = evaluate(EvaluationDataset(samples=samples),
               metrics=[Faithfulness(), ResponseRelevancy(), LLMContextPrecisionWithReference(),
                        LLMContextRecall(), FactualCorrectness()],
               llm=judge, embeddings=embs,
               run_config=RunConfig(max_workers=8, timeout=120))
df = res.to_pandas(); df.to_csv("evals/results_run_042.csv")
print(df.groupby(df["tags"]).mean(numeric_only=True))     # slice by tag
```

**Token efficiency:** log judge tokens per metric, use a cheaper judge for daily runs, and cache `(sample_hash, metric)` → score.

### 4. Eval pipeline phase 1: retrieval (component-level)

```python
def recall_at_k(goldens, k=6):
    hits = 0
    for g_ in goldens:
        ids = {d["source"] + str(d["page"]) for d in retriever({"question": g_["question"],
                 "sub_queries": [g_["question"]]})["docs"][:k]}
        hits += bool(ids & set(g_["relevant_ids"]))
    return hits / len(goldens)
```

Phase 1 runs **without the LLM generator**. It's cheap and fast, and it isolates retrieval and re-ranking quality (recall@k, MRR, context precision).

### 5. Eval pipeline phase 2: end-to-end generation

Full graph run, then faithfulness, relevancy, correctness, guardrail-block rate on the attack set, and latency/cost per question.

```python
THRESHOLDS = {"faithfulness": 0.85, "answer_relevancy": 0.80, "context_recall": 0.75}
scores = df.mean(numeric_only=True).to_dict()
failed = {k: v for k, v in scores.items() if k in THRESHOLDS and v < THRESHOLDS[k]}
if failed:
    raise SystemExit(f"Eval gate failed: {failed}")
```

### 6. Final testing as an app

- Wrap the pipeline as `python -m evals.run --suite smoke|full`.
- A CI job runs `smoke` (20 goldens + 20 attacks) on every PR and `full` nightly, and uploads the CSV + summary as artifacts or LangSmith experiments.
- Optionally add an eval dashboard (Streamlit) to compare runs.

---

## Deep dive: evaluation integration process

```mermaid
flowchart LR
  CH[Code / prompt / config change] --> CI[CI]
  CI --> P1[Phase 1: retrieval metrics]
  P1 -->|pass| P2[Phase 2: E2E metrics + attack suite]
  P2 -->|pass| DEP[Deploy to Cloud Run]
  P1 -->|fail| X[Block]
  P2 -->|fail| X
  DEP --> MON[Online sampling + feedback]
  MON --> GS[Add failures to goldens]
  GS --> CI
```

## Advanced

- **Guardrail placement order:** cheap regex PII → jailbreak classifier → (LLM) → grounding check → output PII. Measure each one's latency.
- **Gateway + guardrail:** some gateways run guardrails as hooks, which centralizes policy across apps.
- **Eval drift:** re-baseline when the judge model changes, because scores aren't comparable across judges.

## Production & scale

- Measure **latency overhead per layer**. Target maybe less than 300 ms total for guardrails on the hot path.
- Track cost per answer = LLM + embeddings + re-rank + judge (sampled).
- Online evals on 5% of traffic, plus a user 👍/👎 widget.

## FAANG insights

- "**No launch without evals**" is a common internal rule. A model upgrade is treated like a schema migration: run the suite, compare slices, then roll out gradually.
- Interview: *"You switched from GPT-4o to a cheaper model. How do you decide if it's OK?"* Run the same goldens and attack suite, compare per-slice metrics with confidence intervals, check cost and latency, then canary.

## Interview questions

1. **Why split evals into retrieval and generation phases?** Isolating the failure source is cheaper and faster, and it tells you what to fix.
2. **Why should retries happen in one layer only?** To avoid retry amplification and runaway costs.
3. **What goes in an eval gate?** Thresholds on key metrics, attack block rate, and latency and cost budgets.

## Checklist

- [ ] Input + output + grounding rails in the graph
- [ ] All LLM calls via the gateway, single retry layer
- [ ] Goldens with tags, two-phase pipeline, CI gate
- [ ] Failures feed back into goldens
