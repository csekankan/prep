# 14 — TensorZero: Gateway + Optimization Flywheel (M1–M5)

> **One sentence:** TensorZero is an open-source, Rust-based LLM gateway where you declare **functions** (tasks) and **variants** (prompt + model combos) in a `tensorzero.toml`. Every inference and its **feedback** is stored in ClickHouse, which enables routing, fallbacks, A/B tests, and data-driven optimization.

## Lecture map

| Module | Lecture | Covered in |
|--------|---------|-----------|
| M1_P1 | Introduction to TensorZero and setting up LLM gateways | Basics, Code §1 |
| M1_P2 | TOML and direct vs LLM gateway request comparison | Code §2–§3 |
| M1_P3 | TensorZero client, episodes and exploring UI | Code §3, Deep dive |
| M2_P1 | Routing architecture and types of routing | Code §4, Deep dive |
| M2_P2 | Fallback routing practical demo and benchmarking latency | Code §4, Production |
| M3_P1 | Prompt templates using MiniJinja and structured JSON output | Code §5 |
| M3_P2 | Unified tool calling demo | Code §6 |
| M4 | A/B testing and feedback loop | Code §7 |
| M5 | Gateway-powered customer support chatbot project | Code §8 |

---

## Basics

| Concept | Plain English |
|---------|---------------|
| **Model** | A model name + ordered list of **providers** (routing/fallback) |
| **Function** | A task your app performs, e.g. `draft_reply`. Type `chat` or `json` |
| **Variant** | One implementation of a function (model + templates + params) |
| **Episode** | A group of related inferences (a conversation / workflow) |
| **Metric / feedback** | Signal about quality (boolean, float, comment, demonstration) |
| **UI** | Web app to browse inferences, episodes, metrics, run optimizations |

**Analogy:** Most gateways are **traffic routers**. TensorZero is a **router plus a lab notebook**: it records every experiment so you can learn which variant actually works best.

Architecture: `app → TensorZero gateway (Rust, ~sub-ms overhead) → providers`, logging to **ClickHouse**. The UI reads ClickHouse.

---

## Code

### 1. Run with Docker Compose

```yaml
# docker-compose.yml (simplified)
services:
  clickhouse:
    image: clickhouse/clickhouse-server
    environment: { CLICKHOUSE_USER: chuser, CLICKHOUSE_PASSWORD: chpassword }
  gateway:
    image: tensorzero/gateway
    volumes: ["./config:/app/config:ro"]
    command: --config-file /app/config/tensorzero.toml
    environment:
      TENSORZERO_CLICKHOUSE_URL: http://chuser:chpassword@clickhouse:8123/tensorzero
      OPENAI_API_KEY: ${OPENAI_API_KEY}
      ANTHROPIC_API_KEY: ${ANTHROPIC_API_KEY}
    ports: ["3000:3000"]
  ui:
    image: tensorzero/ui
    ports: ["4000:4000"]
```

### 2. `tensorzero.toml`

```toml
[models.smart]
routing = ["openai", "anthropic"]            # fallback order

[models.smart.providers.openai]
type = "openai"
model_name = "gpt-4o"

[models.smart.providers.anthropic]
type = "anthropic"
model_name = "claude-sonnet-4-5"

[functions.draft_reply]
type = "chat"
system_schema = "functions/draft_reply/system_schema.json"

[functions.draft_reply.variants.gpt4o_v1]
type = "chat_completion"
model = "smart"
system_template = "functions/draft_reply/v1/system.minijinja"
temperature = 0.3
weight = 0.5

[functions.draft_reply.variants.mini_v1]
type = "chat_completion"
model = "openai::gpt-4o-mini"               # shorthand: provider::model
system_template = "functions/draft_reply/v1/system.minijinja"
weight = 0.5

[metrics.resolved]
type = "boolean"
optimize = "max"
level = "episode"
```

### 3. Direct call vs gateway call

```python
# Direct: provider-specific, no logging/fallback
from openai import OpenAI
OpenAI().chat.completions.create(model="gpt-4o", messages=[...])

# Via TensorZero native client
from tensorzero import TensorZeroGateway
with TensorZeroGateway.build_http(gateway_url="http://localhost:3000") as t0:
    r = t0.inference(
        function_name="draft_reply",
        input={"system": {"company": "Acme", "tone": "friendly"},
               "messages": [{"role": "user", "content": "My order is late"}]},
    )
    print(r.content, r.inference_id, r.episode_id, r.variant_name)

    # continue the same episode
    t0.inference(function_name="draft_reply", episode_id=r.episode_id, input={...})

# Or OpenAI-compatible endpoint
client = OpenAI(base_url="http://localhost:3000/openai/v1", api_key="x")
client.chat.completions.create(model="tensorzero::function_name::draft_reply", messages=[...])
```

### 4. Routing and fallback

- **Model-level routing:** `routing = ["openai", "azure", "anthropic"]`. On error, try the next provider.
- **Variant-level fallback / sampling:** weights split traffic, and if a variant fails, another one is tried.
- **Retries:** `retries = { num_retries = 2, max_delay_s = 10 }` per variant.
- **Timeouts:** per-provider and per-variant `timeouts` (non-streaming total, streaming TTFT).

Benchmark latency by measuring client-side latency with and without the gateway. TensorZero's overhead is typically **under 1 ms p99**, which is one of its selling points.

### 5. MiniJinja templates + JSON functions

```jinja
{# functions/draft_reply/v1/system.minijinja #}
You are a {{ tone }} support agent for {{ company }}.
Never promise refunds over $100. Keep replies under 120 words.
```

```toml
[functions.classify_ticket]
type = "json"
output_schema = "functions/classify_ticket/output_schema.json"

[functions.classify_ticket.variants.v1]
type = "chat_completion"
model = "openai::gpt-4o-mini"
json_mode = "strict"
```

```python
r = t0.inference(function_name="classify_ticket", input={...})
r.output.parsed   # dict validated against output_schema
```

Templates live in config, not in app code, so you can **change prompts without redeploying the app**, and each prompt version is a variant you can compare.

### 6. Unified tool calling

```toml
[tools.get_order_status]
description = "Look up an order status by ID"
parameters = "tools/get_order_status.json"
strict = true

[functions.support_agent]
type = "chat"
tools = ["get_order_status"]
tool_choice = "auto"
```

The same tool definition works across OpenAI, Anthropic, Gemini, and others, because the gateway translates formats.

### 7. A/B testing and feedback

```python
r = t0.inference(function_name="draft_reply", input={...})
# later, after the conversation:
t0.feedback(metric_name="resolved", episode_id=r.episode_id, value=True)
t0.feedback(metric_name="comment", inference_id=r.inference_id, value="too long")
```

The UI then shows metric values **per variant**. Shift weights to the winner, or use built-in experimentation (adaptive / bandit-style) where it's available.

### 8. Customer support chatbot (M5)

```mermaid
flowchart LR
  UI[Chat UI] --> API[FastAPI]
  API --> T0[TensorZero gateway]
  T0 --> CL[classify_ticket json fn]
  T0 --> SA[support_agent chat fn + tools]
  SA --> DB[(Orders DB)]
  T0 --> CH[(ClickHouse)]
  API -->|thumbs up/down| T0
```

---

## Deep dive

- **Why functions and variants?** They separate the **interface** (what the app needs: inputs and output schema) from the **implementation** (prompt + model). That's the same idea as an interface and its implementations in software, applied to prompts.
- **Data model:** every inference row stores the input, output, variant, latency, and tokens, and feedback rows join by `inference_id` / `episode_id`. That makes it a ready-made **training dataset**.
- **Optimization recipes:** supervised fine-tuning on high-metric inferences, DPO, dynamic in-context learning (DICL, which retrieves similar good examples into the prompt), and best-of-N / mixture-of-N variants.

## Advanced

- **Inference-time strategies as variants:** `best_of_n_sampling`, `mixture_of_n`, `dicl`, `chain_of_thought`, all declared in TOML.
- **Episode-level metrics** (e.g. "ticket resolved") are more meaningful than per-message metrics, but they're delayed. Plan your feedback plumbing for that.
- **Schema evolution:** changing `system_schema` breaks old variants. Version functions (`draft_reply_v2`) if needed.

## Production & scale

- ClickHouse handles billions of rows. Set a TTL on raw inferences and keep aggregates longer.
- Run the gateway stateless behind a load balancer. The config is a read-only mount, and GitOps controls changes.
- Monitor per-variant latency, error rate, and metric to spot regressions early.

## FAANG insights

- The **"every inference is a labeled training example"** flywheel is exactly how large companies keep improving assistants: log → collect feedback → curate → fine-tune or distill → A/B → ship.
- Interview: *"How would you safely roll out a new prompt?"* Ship it as a variant with 5% weight, define success metrics, run guardrail evals offline first, ramp up, and keep auto-rollback ready.

## Interview questions

1. **Function vs variant?** The task interface vs one concrete prompt + model implementation.
2. **Inference-level vs episode-level feedback?** Feedback on one call vs the outcome of the whole interaction.
3. **Why store inferences in ClickHouse?** Columnar, fast analytics over massive logs for evals and optimization.

## Checklist

- [ ] Functions have schemas, and prompts live in templates
- [ ] Fallback routing per model
- [ ] Feedback wired for at least one business metric
- [ ] Variants evaluated before weight increases
