# 23 — Project 1: Agentic RAG on GCP (Qdrant, FlashRank, LangGraph, Cloud Run)

> **One sentence:** Build a production-style **agentic RAG** system end to end: ingest and parse documents on GCP, store vectors in Qdrant, use a LangGraph **planner → retriever → re-ranker → responder** graph, serve it with FastAPI + UI, containerize it into Artifact Registry, and deploy to **Cloud Run**.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Project introduction | Basics |
| Understanding data ingestion pipeline | Deep dive §Ingestion |
| Understanding RAG architecture | Basics (diagram) |
| Moving to next phase of project | — |
| Enabling GCP, Qdrant and other AI services | Code §1 |
| Understanding requirements and goals | Basics |
| Setting up GCP permissions | Code §1 |
| Understanding IAM roles and .env setup | Code §1, Advanced |
| Data ingestion process / code setup | Code §2 |
| Data parsing | Code §2 |
| Final data processing | Code §2 |
| Testing data ingestion pipeline | Code §2 |
| Agentic RAG intuition | Deep dive |
| Planner and responder node | Code §3 |
| FlashRank re-ranking | Code §4 |
| Qdrant and re-rank service | Code §4 |
| Retriever node and building agentic graph | Code §5 |
| API and UI development | Code §6 |
| Local testing and assignments | Code §6 |
| Docker container in Artifact Registry | Code §7 |
| Cloud Run app deployment | Code §7 |

---

## Basics

### Requirements and goals

- Answer questions over a private document corpus (PDFs, docs) **with citations**.
- Handle complex questions that need **multiple retrievals** (agentic RAG, not one-shot).
- Run serverless and autoscaling (Cloud Run), with secrets in Secret Manager.
- Later (section 24): add guardrails, a gateway, and evals.

### Architecture

```mermaid
flowchart TB
  subgraph Ingestion
    GCS[(GCS bucket: raw docs)] --> P[Parser<br/>Document AI / unstructured / PyMuPDF]
    P --> CH[Chunker + metadata]
    CH --> EMB[Embeddings<br/>Vertex AI text-embedding]
    EMB --> QD[(Qdrant collection)]
  end
  subgraph Serving [Cloud Run]
    UI[UI] --> API[FastAPI]
    API --> G[LangGraph]
    G --> PL[Planner node]
    PL --> RT[Retriever node]
    RT --> QD
    RT --> RR[FlashRank re-ranker]
    RR --> RS[Responder node]
    RS --> LLM[Gemini / GPT]
  end
```

### Classic vs agentic RAG

| Classic RAG | Agentic RAG |
|-------------|-------------|
| Embed query → top-k → answer | **Plan** sub-queries → retrieve per sub-query → **re-rank** → evaluate sufficiency → maybe retrieve again → answer |
| One shot | Iterative, self-correcting |
| Fails on multi-hop questions | Handles "compare X in 2023 vs Y in 2024" |

---

## Code

### 1. GCP setup

```bash
gcloud config set project $PROJECT_ID
gcloud services enable run.googleapis.com artifactregistry.googleapis.com \
  aiplatform.googleapis.com secretmanager.googleapis.com storage.googleapis.com \
  cloudbuild.googleapis.com documentai.googleapis.com

# Service account for the app (least privilege)
gcloud iam service-accounts create rag-app-sa
for role in roles/aiplatform.user roles/storage.objectViewer roles/secretmanager.secretAccessor; do
  gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:rag-app-sa@$PROJECT_ID.iam.gserviceaccount.com" --role=$role
done

echo -n "$QDRANT_API_KEY" | gcloud secrets create qdrant-api-key --data-file=-
```

```bash
# .env (local only, never commit)
GOOGLE_CLOUD_PROJECT=my-proj
GOOGLE_CLOUD_LOCATION=us-central1
QDRANT_URL=https://xxx.cloud.qdrant.io
QDRANT_API_KEY=...
GCS_BUCKET=rag-raw-docs
```

Local auth: `gcloud auth application-default login` (ADC). In Cloud Run, the attached service account is used automatically, so **no key files are needed**.

### 2. Ingestion pipeline

```python
# ingest.py
from google.cloud import storage
from qdrant_client import QdrantClient, models
from langchain_google_vertexai import VertexAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
import fitz, hashlib, io

emb = VertexAIEmbeddings(model_name="text-embedding-005")
qd = QdrantClient(url=QDRANT_URL, api_key=QDRANT_API_KEY)
COL = "docs_v1"
qd.recreate_collection(COL, vectors_config=models.VectorParams(size=768, distance=models.Distance.COSINE))
qd.create_payload_index(COL, "source", models.PayloadSchemaType.KEYWORD)

def parse_pdf(data: bytes) -> list[dict]:
    doc = fitz.open(stream=data, filetype="pdf")
    return [{"text": p.get_text(), "page": i + 1} for i, p in enumerate(doc)]

splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150)

def ingest_bucket(bucket):
    for blob in storage.Client().bucket(bucket).list_blobs():
        pages = parse_pdf(blob.download_as_bytes())
        chunks, metas = [], []
        for p in pages:
            for c in splitter.split_text(p["text"]):
                chunks.append(c); metas.append({"source": blob.name, "page": p["page"], "text": c})
        vecs = emb.embed_documents(chunks)                      # batched
        pts = [models.PointStruct(
                 id=hashlib.md5(f"{m['source']}|{m['page']}|{m['text'][:64]}".encode()).hexdigest(),
                 vector=v, payload=m) for v, m in zip(vecs, metas)]
        qd.upsert(COL, pts, wait=True)

if __name__ == "__main__":
    ingest_bucket(GCS_BUCKET)
    print(qd.count(COL))        # test: count > 0, sample search returns relevant chunk
```

Deterministic IDs make re-ingestion **idempotent**: an upsert overwrites instead of duplicating.

### 3. Planner and responder nodes

```python
from pydantic import BaseModel
from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages
from langchain.chat_models import init_chat_model

llm = init_chat_model("google_genai:gemini-2.5-flash")   # or vertexai / openai

class Plan(BaseModel):
    sub_queries: list[str]

class State(TypedDict):
    question: str
    sub_queries: list[str]
    docs: list[dict]
    answer: str

def planner(state: State):
    plan = llm.with_structured_output(Plan).invoke(
        f"Break this question into 1-4 focused search queries:\n{state['question']}")
    return {"sub_queries": plan.sub_queries}

def responder(state: State):
    ctx = "\n\n".join(f"[{i+1}] ({d['source']} p{d['page']}) {d['text']}" for i, d in enumerate(state["docs"]))
    ans = llm.invoke(f"Answer using ONLY the context. Cite like [1]. If missing, say you don't know.\n\n"
                     f"Context:\n{ctx}\n\nQuestion: {state['question']}").content
    return {"answer": ans}
```

### 4. Qdrant + FlashRank re-rank service

```python
from flashrank import Ranker, RerankRequest
ranker = Ranker(model_name="ms-marco-MiniLM-L-12-v2", cache_dir="/tmp/flashrank")

def search(q: str, k: int = 20) -> list[dict]:
    hits = qd.query_points(COL, query=emb.embed_query(q), limit=k, with_payload=True).points
    return [{"id": h.id, "text": h.payload["text"], "meta": h.payload, "score": h.score} for h in hits]

def rerank(q: str, docs: list[dict], top_n: int = 5) -> list[dict]:
    req = RerankRequest(query=q, passages=[{"id": d["id"], "text": d["text"], "meta": d["meta"]} for d in docs])
    return ranker.rerank(req)[:top_n]
```

**Why re-rank?** Bi-encoder (embedding) search is fast but coarse. A **cross-encoder** reads the query and passage *together* and scores relevance much more accurately. Retrieve 20–50, re-rank, and keep 3–5. FlashRank is a tiny, CPU-only ONNX re-ranker, so it's ideal for Cloud Run.

### 5. Retriever node + graph

```python
from langgraph.graph import StateGraph, START, END

def retriever(state: State):
    pool = {}
    for sq in state["sub_queries"]:
        for d in search(sq):
            pool[d["id"]] = d                                  # dedupe across sub-queries
    top = rerank(state["question"], list(pool.values()), top_n=6)
    return {"docs": [r["meta"] for r in top]}

g = StateGraph(State)
g.add_node("planner", planner); g.add_node("retriever", retriever); g.add_node("responder", responder)
g.add_edge(START, "planner"); g.add_edge("planner", "retriever")
g.add_edge("retriever", "responder"); g.add_edge("responder", END)
graph = g.compile()
```

Extension: add a **grader** node ("is the context sufficient?") with a conditional edge back to the planner (max 2 loops).

### 6. API + UI + local testing

```python
# app.py
from fastapi import FastAPI
from pydantic import BaseModel
app = FastAPI()

class Ask(BaseModel):
    question: str

@app.post("/ask")
async def ask(body: Ask):
    out = await graph.ainvoke({"question": body.question})
    return {"answer": out["answer"], "sources": [{"source": d["source"], "page": d["page"]} for d in out["docs"]]}

@app.get("/healthz")
def health(): return {"ok": True}
```

UI: Streamlit or a simple React/HTML page calling `/ask`. Local run: `uv run uvicorn app:app --reload`.

### 7. Docker → Artifact Registry → Cloud Run

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY --from=ghcr.io/astral-sh/uv:latest /uv /usr/local/bin/uv
COPY pyproject.toml uv.lock ./
RUN uv sync --frozen --no-dev
COPY . .
RUN uv run python -c "from flashrank import Ranker; Ranker(model_name='ms-marco-MiniLM-L-12-v2', cache_dir='/app/models')"
ENV PORT=8080
CMD ["uv", "run", "uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8080"]
```

```bash
gcloud artifacts repositories create rag-repo --repository-format=docker --location=us-central1
gcloud auth configure-docker us-central1-docker.pkg.dev
IMG=us-central1-docker.pkg.dev/$PROJECT_ID/rag-repo/rag-api:v1
docker build --platform linux/amd64 -t $IMG . && docker push $IMG
# (or: gcloud builds submit --tag $IMG)

gcloud run deploy rag-api --image $IMG --region us-central1 \
  --service-account rag-app-sa@$PROJECT_ID.iam.gserviceaccount.com \
  --set-secrets QDRANT_API_KEY=qdrant-api-key:latest \
  --set-env-vars QDRANT_URL=$QDRANT_URL,GOOGLE_CLOUD_PROJECT=$PROJECT_ID \
  --memory 2Gi --cpu 2 --min-instances 0 --max-instances 10 --concurrency 20 \
  --no-allow-unauthenticated
```

---

## Deep dive

### Ingestion details

- **Parsing quality is the #1 RAG quality lever.** Tables, headers, and multi-column PDFs need layout-aware parsers (Document AI, Unstructured, Docling, LlamaParse).
- **Chunking:** recursive 500–1000 tokens with 10–15% overlap is a good default. Structure-aware chunking (by headings) is better for manuals.
- **Metadata:** source, page, section, doc date, ACL/tenant, and embedding model version.

### Agentic RAG intuition

The planner turns a vague or multi-part question into targeted searches (query decomposition). The re-ranker fixes embedding noise, and the responder is constrained to cite. Each step is a **separately testable component** (section 24 evaluates them).

## Advanced

- **Hybrid search:** dense + sparse (BM25/SPLADE) in Qdrant, fused with RRF. This helps a lot with IDs, codes, and names.
- **IAM:** separate service accounts for ingestion (write to Qdrant, read GCS) and serving (read only). Use **Workload Identity Federation** in CI instead of JSON keys.
- **Cold starts:** pre-download models into the image, use `--min-instances 1` for latency-sensitive apps, and turn on startup CPU boost.

## Production & scale

- Cloud Run concurrency × instances = max parallel requests. LLM calls are I/O bound, so higher concurrency (20–80) is fine.
- Re-ingest incrementally on GCS object-finalize events (Eventarc → Cloud Run job).
- Log the retrieval scores and the final answer per request for evals.

## FAANG insights

- In design interviews, RAG answers that mention **parsing, chunking strategy, hybrid retrieval, re-ranking, citations, ACL filtering, freshness, and evals** stand out from "embed and top-k".
- Use serverless (Cloud Run) for spiky internal tools and GKE for steady high-QPS or GPU-heavy self-hosted models.

## Interview questions

1. **Bi-encoder vs cross-encoder?** Separate embeddings (fast, scalable) vs joint query-doc scoring (accurate, slow), so use them as retrieve-then-re-rank.
2. **How do you make ingestion idempotent?** Deterministic chunk IDs plus upserts, and delete stale IDs on doc removal.
3. **Why a planner node?** Query decomposition for multi-hop or compound questions.

## Checklist

- [ ] Least-privilege service accounts, secrets in Secret Manager
- [ ] Idempotent, batched ingestion with rich metadata
- [ ] Retrieve-k → re-rank → top-n
- [ ] Answers cite sources
- [ ] Image pre-bakes models, health check endpoint
