# 25 — Project 2 (Part 1): Production Agentic AI on AWS — Architecture + Terraform

> **One sentence:** Design a secure, production-grade multi-agent AI platform on AWS and provision **all of its infrastructure as code with Terraform**: networking, compute, database, cache, queue, secrets, container registry, and IAM.

## Lecture map

| # | Lecture | Covered in |
|---|---------|-----------|
| 01 | Problem statement | Basics |
| 02 | What students will learn in this project | Basics |
| 03 | Most asked questions | FAANG insights / Interview |
| 04 | Project architecture explained | Deep dive |
| 05 | How Terraform works | Basics, Deep dive |
| 06 | Installing and setting up Terraform and AWS CLI | Code §1 |
| 07 | Terraform infrastructure setup for AWS | Code §2–§4 |

Part 2 (app code, CI/CD, deployment) is in [section 26](../26-project-aws-app-cicd/detailed.md).

---

## Basics

### Problem statement

A company wants an AI assistant that:
- runs **multiple specialized agents** (e.g. research, support, analytics),
- is **secure** (auth, guardrails, red-team tested),
- is **reliable** (retries, DB pooling, queues for long tasks),
- is **observable and evaluated** (LangSmith),
- is **reproducible** (Terraform, Docker, GitHub Actions CI/CD).

### Terraform in plain English

Terraform reads `.tf` files describing **desired state** ("I want 1 VPC, 2 subnets, 1 database"), compares that with **current state** (stored in a state file), and makes a **plan** of the API calls needed to close the gap.

| Command | What it does |
|---------|-------------|
| `terraform init` | Download providers, configure the backend |
| `terraform fmt` / `validate` | Format and syntax check |
| `terraform plan` | Show the diff (create/update/destroy) |
| `terraform apply` | Execute the plan |
| `terraform destroy` | Delete everything it manages |

| Concept | Meaning |
|---------|---------|
| **Provider** | Plugin for an API (aws, google, databricks) |
| **Resource** | Something to create (`aws_db_instance`) |
| **Data source** | Read existing things (`data "aws_availability_zones"`) |
| **Variable / output** | Inputs / exported values |
| **Module** | Reusable group of resources |
| **State** | Terraform's record of what exists (store it remotely and lock it!) |

---

## Code

### 1. Install + configure

```bash
brew tap hashicorp/tap && brew install hashicorp/tap/terraform
brew install awscli
aws configure          # or: aws configure sso  (preferred over long-lived keys)
aws sts get-caller-identity
```

### 2. Project layout

```
infra/
├── backend.tf        # remote state
├── providers.tf
├── variables.tf
├── network.tf        # VPC, subnets, NAT, SGs
├── ecr.tf
├── ecs.tf            # cluster, task def, service, ALB
├── rds.tf            # Postgres (+ pgvector)
├── redis.tf          # ElastiCache
├── sqs.tf
├── secrets.tf
├── iam.tf
└── outputs.tf
```

### 3. Remote state + provider

```hcl
# backend.tf
terraform {
  required_version = ">= 1.6"
  required_providers { aws = { source = "hashicorp/aws", version = "~> 5.0" } }
  backend "s3" {
    bucket         = "acme-tf-state"
    key            = "agentic-ai/prod.tfstate"
    region         = "us-east-1"
    dynamodb_table = "tf-locks"        # or use_lockfile = true (newer TF versions)
    encrypt        = true
  }
}
provider "aws" {
  region = var.region
  default_tags { tags = { project = "agentic-ai", env = var.env } }
}
```

### 4. Core infrastructure (abridged)

```hcl
# network.tf
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"
  name    = "agentic-${var.env}"
  cidr    = "10.0.0.0/16"
  azs             = ["us-east-1a", "us-east-1b"]
  public_subnets  = ["10.0.1.0/24", "10.0.2.0/24"]
  private_subnets = ["10.0.11.0/24", "10.0.12.0/24"]
  enable_nat_gateway = true
  single_nat_gateway = true        # cheaper for dev; one per AZ in prod
}

resource "aws_security_group" "app" {
  vpc_id = module.vpc.vpc_id
  ingress { from_port = 8000, to_port = 8000, protocol = "tcp", security_groups = [aws_security_group.alb.id] }
  egress  { from_port = 0, to_port = 0, protocol = "-1", cidr_blocks = ["0.0.0.0/0"] }
}

# ecr.tf
resource "aws_ecr_repository" "api" {
  name = "agentic-api"
  image_scanning_configuration { scan_on_push = true }
  image_tag_mutability = "IMMUTABLE"
}

# rds.tf
resource "aws_db_instance" "pg" {
  identifier              = "agentic-${var.env}"
  engine                  = "postgres"
  engine_version          = "16"
  instance_class          = "db.t4g.medium"
  allocated_storage       = 50
  db_name                 = "agentic"
  username                = "app"
  manage_master_user_password = true            # password in Secrets Manager
  db_subnet_group_name    = aws_db_subnet_group.pg.name
  vpc_security_group_ids  = [aws_security_group.db.id]
  storage_encrypted       = true
  multi_az                = var.env == "prod"
  backup_retention_period = 7
  deletion_protection     = var.env == "prod"
}

# redis.tf
resource "aws_elasticache_replication_group" "redis" {
  replication_group_id       = "agentic-${var.env}"
  description                = "cache + rate limits + memory"
  engine                     = "redis"
  node_type                  = "cache.t4g.small"
  num_cache_clusters         = 2
  automatic_failover_enabled = true
  transit_encryption_enabled = true
  at_rest_encryption_enabled = true
  subnet_group_name          = aws_elasticache_subnet_group.redis.name
  security_group_ids         = [aws_security_group.redis.id]
}

# sqs.tf
resource "aws_sqs_queue" "dlq"  { name = "agent-jobs-dlq" }
resource "aws_sqs_queue" "jobs" {
  name                       = "agent-jobs"
  visibility_timeout_seconds = 900
  redrive_policy = jsonencode({ deadLetterTargetArn = aws_sqs_queue.dlq.arn, maxReceiveCount = 3 })
}

# secrets.tf
resource "aws_secretsmanager_secret" "llm" { name = "agentic/${var.env}/llm-keys" }

# ecs.tf (abridged)
resource "aws_ecs_cluster" "main" { name = "agentic-${var.env}" }
resource "aws_ecs_task_definition" "api" {
  family                   = "agentic-api"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu = 1024
  memory = 2048
  execution_role_arn       = aws_iam_role.exec.arn
  task_role_arn            = aws_iam_role.task.arn       # app permissions (least privilege)
  container_definitions = jsonencode([{
    name  = "api", image = "${aws_ecr_repository.api.repository_url}:${var.image_tag}",
    portMappings = [{ containerPort = 8000 }],
    secrets = [{ name = "LLM_KEYS", valueFrom = aws_secretsmanager_secret.llm.arn }],
    environment = [{ name = "REDIS_HOST", value = aws_elasticache_replication_group.redis.primary_endpoint_address },
                   { name = "SQS_URL",    value = aws_sqs_queue.jobs.url }],
    logConfiguration = { logDriver = "awslogs", options = {
      awslogs-group = "/ecs/agentic-api", awslogs-region = var.region, awslogs-stream-prefix = "api" } }
  }])
}
```

```bash
cd infra
terraform init
terraform plan -var env=dev -var image_tag=bootstrap -out tf.plan
terraform apply tf.plan
terraform output
```

---

## Deep dive

### Project architecture

```mermaid
flowchart TB
  U[Users] --> CF[CloudFront + WAF]
  CF --> FE[Frontend<br/>S3 static / Amplify]
  CF --> ALB[ALB]
  ALB --> API[ECS Fargate: FastAPI<br/>auth, guardrails, cache, agents]
  API --> RDS[(RDS Postgres<br/>users, chats, pgvector)]
  API --> RED[(ElastiCache Redis<br/>cache, rate limit, memory)]
  API --> SQS[[SQS jobs]] --> WRK[ECS worker<br/>long-running agents]
  API --> GW[TensorZero gateway<br/>ECS service]
  GW --> LLMs[(OpenAI / Anthropic / Bedrock)]
  API -.-> LS[LangSmith]
  API --> SM[Secrets Manager]
  RT[PyRIT dashboard] -.attacks.-> ALB
  GH[GitHub Actions] -->|OIDC| ECR[ECR] --> API
```

### How Terraform works internally

1. **Parse** HCL into a configuration graph.
2. **Refresh** state by reading real resources through provider APIs.
3. Build a **dependency DAG** (implicit through references, explicit through `depends_on`).
4. **Diff** desired against current state to get the plan.
5. **Apply** by walking the DAG in parallel (default 10), calling provider CRUD, and updating state after each resource.

## Advanced

- **State is sensitive:** it can contain secrets. Encrypt the bucket, restrict access, and never commit `terraform.tfstate`.
- **Environments:** separate state per env (directories or workspaces), with Terragrunt or modules + `tfvars`.
- **Drift:** someone clicks in the console. `terraform plan` in CI on a schedule detects drift.
- **Policy as code:** `tflint`, `checkov`/`tfsec`/`trivy config`, and OPA/Sentinel to block public S3 buckets, unencrypted DBs, and `0.0.0.0/0` ingress.
- **`prevent_destroy`** lifecycle on databases.

## Production & scale

- Multi-AZ RDS, Redis with failover, ECS service autoscaling on CPU/requests, and ALB health checks.
- Cost: NAT gateways and idle RDS are the classic surprise bills. Use a single NAT in dev and **destroy dev stacks** nightly.
- Use VPC endpoints for ECR/S3/Secrets Manager so traffic avoids NAT, which cuts cost and improves security.

## FAANG insights

- **Everything as code, nothing clicked** is the baseline expectation. Interviewers ask *"How do you promote infra changes safely?"* Answer: PR → plan output posted as a comment → review → apply from CI with OIDC credentials → drift detection.
- Long agent tasks go **async** (queue + worker + status polling or webhooks). Never hold an HTTP request open for minutes.

## Most asked questions (from the course) + answers

1. **Why ECS Fargate instead of Lambda?** Long-running agents, streaming responses, larger images, and steady traffic. Lambda has a 15-minute limit and cold starts with heavy ML deps.
2. **Why both Postgres and Redis?** Durable source of truth vs ephemeral fast cache, rate limits, and sessions.
3. **Why a queue?** Decouples slow multi-agent jobs, gives retries + a DLQ, and smooths spikes.
4. **Can I use Bedrock instead of OpenAI?** Yes. Swap the provider in the gateway config, and IAM covers auth.

## Interview questions

1. **What is Terraform state and why lock it?** The mapping from configuration to real resources. Locking prevents concurrent applies from corrupting it.
2. **`plan` vs `apply`?** Preview the diff vs execute it.
3. **How do you keep secrets out of Terraform?** Managed passwords (`manage_master_user_password`) and Secrets Manager references, plus encrypted remote state.

## Checklist

- [ ] Remote, encrypted, locked state
- [ ] Private subnets for app/DB/cache
- [ ] Least-privilege task role, secrets from Secrets Manager
- [ ] ECR scan on push, immutable tags
- [ ] Security scanners on `.tf` in CI
