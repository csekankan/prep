# 02 — LangChain v1 Fundamentals

> **One sentence:** LangChain v1 cut the framework down to a few core pieces: `init_chat_model` (any provider), `@tool` (functions the model can call), messages (the conversation), and `create_agent` (a production ReAct loop built on LangGraph, extended with middleware).

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Introduction to LangChain updates | Basics |
| Creating virtual environment with uv | Code §1 |
| Agents with LangChain | Code §5, Deep dive |
| LangChain model integration | Code §2 |
| Streaming and batch with LangChain | Code §3 |
| Tools in LangChain | Code §4 |
| Messages in LangChain | Code §6 |

---

## Basics

### What changed in v1?

| Old (0.x) | New (v1) |
|-----------|----------|
| Dozens of agent types (`initialize_agent`, `AgentExecutor`) | **One**: `langchain.agents.create_agent` |
| Chains everywhere (`LLMChain`, …) | LCEL / plain Python + LangGraph under the hood |
| Callbacks for customization | **Middleware** (`before_model`, `after_model`, `wrap_tool_call`, …) |
| Provider-specific message formats | Standard **content blocks** (text, image, reasoning, tool calls) |
| Legacy stuff in main package | Moved to `langchain-classic` |

**Analogy:** v0 was a giant toolbox with 200 tools. v1 is a **power drill with swappable bits**: one agent loop, plus middleware you snap on.

### Core vocabulary

| Term | Plain English |
|------|---------------|
| **Chat model** | Wrapper around an LLM API that speaks in messages |
| **Message** | `SystemMessage`, `HumanMessage`, `AIMessage`, `ToolMessage` |
| **Tool** | Python function + schema the model can choose to call |
| **Agent** | Loop: model → (tool calls?) → run tools → model → … → final answer |
| **Runnable** | Anything with `.invoke / .stream / .batch / .ainvoke` |

---

## Code

### 1. Project setup with `uv`

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh     # install uv
uv init agentic-course && cd agentic-course
uv venv --python 3.12                                # creates .venv
source .venv/bin/activate
uv add langchain langchain-openai langchain-anthropic langgraph python-dotenv
uv run python main.py                                # runs inside the venv
```

`uv` is a Rust-based replacement for pip/venv/pip-tools/poetry that is **10–100× faster**. It writes `pyproject.toml` plus a `uv.lock`, which gives you reproducible installs, and that matters in CI.

### 2. Model integration (provider-agnostic)

```python
from dotenv import load_dotenv; load_dotenv()
from langchain.chat_models import init_chat_model

gpt    = init_chat_model("openai:gpt-4o-mini", temperature=0)
claude = init_chat_model("anthropic:claude-sonnet-4-5")
local  = init_chat_model("ollama:llama3.1")

print(gpt.invoke("One-line definition of an AI agent").content)

# configurable at runtime (great for A/B and fallbacks)
model = init_chat_model(configurable_fields=("model", "temperature"))
model.invoke("hi", config={"configurable": {"model": "openai:gpt-4o"}})
```

### 3. Streaming and batch

```python
# Streaming: tokens as they arrive (UX: time-to-first-token)
for chunk in gpt.stream("Explain RAG in 3 bullets"):
    print(chunk.content, end="", flush=True)

# Batch: many independent prompts in parallel (throughput)
answers = gpt.batch(
    ["Define LLM", "Define RAG", "Define MCP"],
    config={"max_concurrency": 5},
)

# Async variants for web servers
# await gpt.ainvoke(...), gpt.astream(...), gpt.abatch(...)
```

### 4. Tools

```python
from langchain.tools import tool
from pydantic import BaseModel, Field

@tool
def get_weather(city: str) -> str:
    """Get current weather for a city."""          # docstring = description the LLM sees
    return f"It's 24°C and sunny in {city}"

class SearchArgs(BaseModel):
    query: str = Field(description="search query")
    k: int = Field(default=3, ge=1, le=10)          # validation = security

@tool(args_schema=SearchArgs)
def search_docs(query: str, k: int = 3) -> list[str]:
    """Search internal docs."""
    return [f"doc about {query}"] * k

model_with_tools = gpt.bind_tools([get_weather, search_docs])
ai_msg = model_with_tools.invoke("Weather in Paris?")
print(ai_msg.tool_calls)  # [{'name': 'get_weather', 'args': {'city': 'Paris'}, 'id': '...'}]
```

### 5. Agents with `create_agent`

```python
from langchain.agents import create_agent

agent = create_agent(
    model="openai:gpt-4o-mini",
    tools=[get_weather, search_docs],
    system_prompt="You are a concise assistant. Use tools when needed.",
)

result = agent.invoke({"messages": [{"role": "user", "content": "Weather in Tokyo?"}]})
print(result["messages"][-1].content)

# stream agent steps (updates per node) — great for UIs
for step in agent.stream({"messages": [("user", "weather in Rome")]}, stream_mode="updates"):
    print(step)
```

### 6. Messages

```python
from langchain.messages import SystemMessage, HumanMessage, AIMessage, ToolMessage

msgs = [
    SystemMessage("You are a pirate."),
    HumanMessage("Hi!"),
    AIMessage("Arr, ahoy!"),
    HumanMessage("What's 2+2?"),
]
resp = gpt.invoke(msgs)
print(resp.content, resp.usage_metadata)   # {'input_tokens':.., 'output_tokens':.., 'total_tokens':..}

# Multimodal content blocks
HumanMessage(content=[
    {"type": "text", "text": "Describe this image"},
    {"type": "image", "url": "https://example.com/cat.png"},
])
```

---

## Deep dive

### What `create_agent` actually is

`create_agent` builds a **LangGraph `StateGraph`** with two nodes, `model` and `tools`, plus a conditional edge:

```mermaid
flowchart LR
  S((start)) --> M[model node]
  M -->|tool_calls present| T[tools node]
  T --> M
  M -->|no tool_calls| E((end))
```

That means you get LangGraph features for free: checkpointing (`checkpointer=`), streaming, interrupts, and LangSmith tracing.

### How tool calling works on the wire

1. LangChain turns your function signature and docstring into **JSON Schema**.
2. The provider API receives `tools=[...]`. The model returns structured `tool_calls` with `id`, `name`, and `args`.
3. The agent runs the tool and appends a `ToolMessage(tool_call_id=id, content=result)`.
4. The model sees the result and either calls more tools or answers.

The **docstring and arg descriptions are prompt engineering**. Bad descriptions cause wrong tool choices.

### Streaming modes

| `stream_mode` | What you get |
|---------------|--------------|
| `"values"` | Full state after each step |
| `"updates"` | Only the delta per node |
| `"messages"` | LLM tokens + metadata (token streaming in agents) |
| `"custom"` | Your own events via `get_stream_writer()` |

---

## Advanced

- **Parallel tool calls:** models can return several tool calls in one turn, and LangChain runs them concurrently. Make tools **idempotent and thread-safe**.
- **`ToolRuntime` / injected args:** tools can receive state, context, or a store without the LLM seeing those params. Use this for `user_id`, so the model can never spoof it.
- **Dynamic model selection:** middleware can swap the model per request (cheap model for simple turns, a strong one for hard turns).
- **Error handling:** wrap tool errors and return them as `ToolMessage` content so the model can recover, instead of crashing the loop.
- **Rate limits:** `InMemoryRateLimiter` on the chat model, or use a gateway (sections 13–16).

## Production & scale

- Use **async** (`ainvoke`) in FastAPI. Sync calls block the event loop.
- `batch` with `max_concurrency` respects provider rate limits. For huge offline jobs, use the **provider batch APIs** instead (about 50% cheaper).
- Pin versions in `uv.lock`, since LangChain minor releases can change behavior.
- Track `usage_metadata` per request so you can attribute cost per tenant.

## FAANG insights

- Big teams often **wrap or replace** framework agents with thin in-house loops for control. What they keep from LangChain/LangGraph are the **concepts**: typed state, checkpoints, and middleware hooks.
- Tool schemas get **code-reviewed like public APIs**. Each tool description is versioned and evaluated.
- Interview angle: *"How do you stop an agent from looping forever?"* Answer: a recursion/step limit (`recursion_limit`), a token budget, duplicate-call detection, and a timeout.

## Interview questions

1. **`invoke` vs `stream` vs `batch`?** One answer vs incremental chunks vs many inputs in parallel.
2. **Why should `user_id` be an injected arg rather than a tool param?** Because the LLM could hallucinate or be manipulated into passing another user's ID.
3. **What does `create_agent` compile to?** A LangGraph graph with model and tool nodes in a loop.

## Checklist

- [ ] `uv.lock` committed
- [ ] Every tool has a clear docstring and a validated Pydantic schema
- [ ] `recursion_limit` and timeouts set
- [ ] Token usage logged per request
