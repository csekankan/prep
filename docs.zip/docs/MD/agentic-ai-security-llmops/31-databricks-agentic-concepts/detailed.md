# 31 — Databricks for Agentic AI: Delta Lake, Unity Catalog, Vector Search, Apps, AI Gateway

> **One sentence:** Databricks gives you one governed platform for **data (Delta Lake)**, **permissions and lineage (Unity Catalog)**, **retrieval (Vector Search with Delta Sync)**, **model access control (AI Gateway)**, and **hosting (Databricks Apps)**, which is exactly what an enterprise agentic RAG system needs.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Introduction | Basics |
| Agentic AI overview | Basics |
| Databricks overview | Basics |
| The agentic AI side of our project | Deep dive |
| Why Delta Lake is needed | Basics |
| Delta Lake explained | Code §1, Deep dive |
| Data governance explained with Unity Catalog | Code §2 |
| Databricks Apps and Vector Search index | Code §3, §5 |
| Delta Sync in Databricks Vector Search | Code §3 |
| Unity AI Gateway explained | Code §4 |

---

## Basics

### Databricks building blocks

| Component | Plain English |
|-----------|---------------|
| **Workspace** | Your Databricks environment (notebooks, jobs, clusters, SQL) |
| **Compute** | Clusters / serverless / SQL warehouses |
| **Delta Lake** | Open table format on cloud storage with ACID transactions + time travel |
| **Unity Catalog (UC)** | Central governance: `catalog.schema.table`, grants, lineage, audit |
| **Mosaic AI Vector Search** | Managed vector index, can **auto-sync** from a Delta table |
| **Model Serving** | Endpoints for foundation models, external models, and your agents |
| **AI Gateway** | Governance on serving endpoints: rate limits, usage tracking, guardrails, inference tables |
| **Databricks Apps** | Host Streamlit/Dash/Gradio/FastAPI apps inside the workspace with SSO |
| **Asset Bundles** | Infra/code as YAML for CI/CD (section 32) |

### Why Delta Lake (vs plain Parquet files)?

| Problem with raw files in a data lake | Delta fix |
|--------------------------------------|-----------|
| Half-written files when jobs crash | **ACID** transaction log |
| Concurrent writers corrupt data | Optimistic concurrency |
| "What did this table look like yesterday?" | **Time travel** (`VERSION AS OF`) |
| Schema drift breaks pipelines | Schema enforcement and evolution |
| Need upserts/deletes (GDPR) | `MERGE`, `DELETE`, `UPDATE` |
| Downstream needs only changes | **Change Data Feed (CDF)**, which Vector Search Delta Sync relies on |

---

## Code

### 1. Delta Lake

```python
# Databricks notebook (PySpark)
df = spark.read.format("binaryFile").load("/Volumes/main/hr/raw_docs/")      # UC Volume
chunks = parse_and_chunk(df)                                                 # id, text, source, access

(chunks.write.format("delta").mode("overwrite")
       .option("delta.enableChangeDataFeed", "true")                         # needed for Delta Sync
       .saveAsTable("main.hr.policy_chunks"))
```

```sql
-- Upsert new/changed chunks
MERGE INTO main.hr.policy_chunks t
USING updates s ON t.id = s.id
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;

DESCRIBE HISTORY main.hr.policy_chunks;
SELECT * FROM main.hr.policy_chunks VERSION AS OF 3;
OPTIMIZE main.hr.policy_chunks ZORDER BY (source);
```

### 2. Unity Catalog governance

```sql
CREATE CATALOG IF NOT EXISTS main;
CREATE SCHEMA  IF NOT EXISTS main.hr;

GRANT USE CATALOG ON CATALOG main TO `hr-app-users`;
GRANT USE SCHEMA, SELECT ON SCHEMA main.hr TO `hr-app-users`;
GRANT MODIFY ON TABLE main.hr.policy_chunks TO `hr-ingestion-sp`;

-- Row-level security: only managers see manager docs
CREATE FUNCTION main.hr.access_filter(access STRING)
RETURN access = 'all-employees' OR is_account_group_member('managers');
ALTER TABLE main.hr.policy_chunks SET ROW FILTER main.hr.access_filter ON (access);

-- Column mask for PII
CREATE FUNCTION main.hr.mask_email(e STRING) RETURN
  CASE WHEN is_account_group_member('hr-admins') THEN e ELSE '***' END;
ALTER TABLE main.hr.employees ALTER COLUMN email SET MASK main.hr.mask_email;
```

UC also provides **lineage** (which table fed which index, model, or app), **audit logs** (system tables), and **tags/classification**. UC governs tables, volumes, models, functions, vector indexes, and connections.

### 3. Vector Search with Delta Sync

```python
from databricks.vector_search.client import VectorSearchClient
vsc = VectorSearchClient()

vsc.create_endpoint(name="hr-vs-endpoint", endpoint_type="STANDARD")

index = vsc.create_delta_sync_index(
    endpoint_name="hr-vs-endpoint",
    index_name="main.hr.policy_chunks_index",
    source_table_name="main.hr.policy_chunks",
    pipeline_type="TRIGGERED",                       # or CONTINUOUS
    primary_key="id",
    embedding_source_column="text",                  # Databricks computes embeddings
    embedding_model_endpoint_name="databricks-gte-large-en",
)

index.sync()                                         # for TRIGGERED pipelines
res = index.similarity_search(query_text="maternity leave policy",
                              columns=["id", "text", "source"], num_results=5,
                              filters={"access": "all-employees"},
                              query_type="HYBRID")    # dense + keyword
```

| Index type | How data gets in |
|-----------|------------------|
| **Delta Sync (managed embeddings)** | Point at a Delta table + text column. Databricks embeds and syncs automatically |
| **Delta Sync (self-managed embeddings)** | Your table already has a vector column |
| **Direct Vector Access** | You upsert/delete vectors through the API (no Delta table) |

### 4. AI Gateway on serving endpoints

```python
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import (AiGatewayConfig, AiGatewayRateLimit,
     AiGatewayUsageTrackingConfig, AiGatewayInferenceTableConfig, AiGatewayGuardrails,
     AiGatewayGuardrailParameters, AiGatewayGuardrailPiiBehavior)

w = WorkspaceClient()
w.serving_endpoints.put_ai_gateway(
    name="hr-llm",
    rate_limits=[AiGatewayRateLimit(calls=100, renewal_period="minute", key="user")],
    usage_tracking_config=AiGatewayUsageTrackingConfig(enabled=True),
    inference_table_config=AiGatewayInferenceTableConfig(enabled=True,
        catalog_name="main", schema_name="hr", table_name_prefix="hr_llm"),
    guardrails=AiGatewayGuardrails(
        input=AiGatewayGuardrailParameters(safety=True,
              pii=AiGatewayGuardrailPiiBehavior(behavior="BLOCK")),
        output=AiGatewayGuardrailParameters(safety=True)),
)
```

Features: **external model endpoints** (OpenAI, Anthropic, Bedrock behind a Databricks endpoint, with keys in secrets), **permissions** (who can query), **rate limits**, **usage tracking** (system tables), **inference tables** (request/response logging to Delta, which feeds evals), **guardrails**, and **traffic splitting / fallbacks**. (Feature names and availability evolve, so check the current docs.)

### 5. Databricks App (UI for the agent)

```python
# app.py (Streamlit) — runs as a Databricks App with its own service principal
import streamlit as st
from databricks.sdk import WorkspaceClient
w = WorkspaceClient()                                    # auth injected by the Apps runtime

q = st.chat_input("Ask HR")
if q:
    resp = w.serving_endpoints.query(name="hr-agent-endpoint",
                                     messages=[{"role": "user", "content": q}])
    st.write(resp.choices[0].message.content)
```

```yaml
# app.yaml
command: ["streamlit", "run", "app.py"]
env:
  - name: SERVING_ENDPOINT
    valueFrom: serving-endpoint          # resource declared in the app config
```

---

## Deep dive: the agentic side of the project

```mermaid
flowchart LR
  SRC[(Docs in UC Volume)] --> ETL[Job: parse + chunk]
  ETL --> DT[(Delta table + CDF)]
  DT -->|Delta Sync| VS[(Vector Search index)]
  APP[Databricks App] --> AG[Agent: LangGraph / Mosaic AI Agent Framework]
  AG --> VS
  AG --> GW[Serving endpoint + AI Gateway]
  GW --> LLM[(Foundation / external model)]
  GW --> IT[(Inference tables)]
  IT --> EV[Agent Evaluation / MLflow]
  UC[Unity Catalog] -.governs.-> DT & VS & GW & APP
```

- **Delta Sync** reads the table's **Change Data Feed**, so inserts, updates, and deletes in the Delta table propagate to the index. That makes freshness and right-to-delete automatic.
- **MLflow** (tracing + agent evaluation) closes the loop: inference tables → eval datasets → judges → improvements.

## Advanced

- **Identity:** the app runs as a **service principal**. Decide between app-identity access (simple) and **on-behalf-of user** access (row filters apply per user, which matters for HR).
- **Cost:** vector search endpoints and continuous sync pipelines bill continuously. Use TRIGGERED for docs that rarely change.
- **Embedding model changes** mean re-creating the index, so version index names.

## Production & scale

- Use `OPTIMIZE` + auto-compaction on source tables, and monitor sync lag.
- Inference tables + system tables give per-user and per-endpoint cost and quality dashboards.
- Rate limit per user and per endpoint at the AI Gateway to prevent runaway agent loops.

## FAANG insights

- The pitch for lakehouse AI is **governance in one place**: the same grants, lineage, and audit for tables, vectors, models, and apps. In interviews, connect "who can retrieve this chunk" to **row filters on the source table**.
- *"How do you handle a GDPR delete for RAG?"* Delete from the Delta source, CDF propagates it to the index, then purge caches and logs per policy.

## Interview questions

1. **Why does Vector Search Delta Sync need Change Data Feed?** To incrementally apply inserts, updates, and deletes to the index.
2. **UC three-level namespace?** `catalog.schema.object`.
3. **What do inference tables give you?** Logged requests and responses in Delta for monitoring, evals, and fine-tuning data.

## Checklist

- [ ] Source Delta table with CDF + primary key
- [ ] UC grants, row filters, column masks
- [ ] Delta Sync index (TRIGGERED or CONTINUOUS deliberately chosen)
- [ ] AI Gateway: rate limits, usage tracking, inference tables, guardrails
- [ ] App identity model decided
