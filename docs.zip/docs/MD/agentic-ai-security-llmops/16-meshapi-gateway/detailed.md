# 16 — MeshAPI Gateway: RAG, Multi-Agent, Multimodal, MCP, CLI Agent

> **One sentence:** MeshAPI is presented in the course as a **unified AI API gateway**: one key and an OpenAI-compatible endpoint for many models, plus built-in extras (RAG, image/audio/video generation, an MCP server, and a CLI coding agent). Here you build RAG and LangChain multi-agent apps on top of it.

> **Accuracy note:** MeshAPI is a newer, smaller product, so endpoint paths, model IDs, and feature names below follow the **generic OpenAI-compatible pattern**. Check the exact names against MeshAPI's own docs and dashboard before relying on them.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Introduction to MeshAPI gateway | Basics |
| Basics of MeshAPI | Code §1 |
| Building RAG with MeshAPI | Code §2 |
| Building multi-agents with MeshAPI and LangChain | Code §3 |
| MeshAPI features exploration | Basics (table) |
| Inbuilt RAG, image, audio, video generation | Code §4 |
| MeshAPI MCP server | Code §5 |
| MeshAPI CLI coding agent and assignment | Code §6 |

---

## Basics

### "Aggregator gateway" vs "infrastructure gateway"

| Type | Examples | You get |
|------|----------|---------|
| **Infrastructure gateway** (self-hosted) | Bifrost, TensorZero, LiteLLM, Portkey OSS | Control, run in your VPC, your provider keys |
| **Aggregator / hosted gateway** | OpenRouter, MeshAPI-style services | **One account, one key, many models**, unified billing, extra hosted features |

**Analogy:** An infrastructure gateway is **your own switchboard**. An aggregator is a **prepaid international SIM**: one card that works in every country, and the carrier handles the contracts.

### Typical feature set to explore

| Feature | Why it matters |
|---------|----------------|
| Unified chat/completions across vendors | Swap models by string |
| Embeddings | RAG without a second vendor |
| Hosted RAG / file search | Prototype without a vector DB |
| Image / audio / video generation | Multimodal from one API |
| Usage dashboard, budgets | Cost control |
| MCP server | Use the gateway's capabilities as tools in Claude/Cursor/agents |
| CLI coding agent | Terminal agent backed by any model on the gateway |

---

## Code

### 1. Basics (OpenAI-compatible)

```python
import os
from openai import OpenAI

mesh = OpenAI(base_url=os.environ["MESHAPI_BASE_URL"],   # e.g. https://<meshapi-host>/v1
              api_key=os.environ["MESHAPI_API_KEY"])

print([m.id for m in mesh.models.list().data][:20])      # discover available model IDs

r = mesh.chat.completions.create(model="gpt-4o-mini",    # use an ID from models.list()
        messages=[{"role": "user", "content": "Hello from MeshAPI"}])
print(r.choices[0].message.content, r.usage)
```

### 2. RAG with MeshAPI (bring-your-own vector store)

```python
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader

emb = OpenAIEmbeddings(model="text-embedding-3-small",
                       base_url=os.environ["MESHAPI_BASE_URL"], api_key=os.environ["MESHAPI_API_KEY"])
llm = ChatOpenAI(model="gpt-4o-mini",
                 base_url=os.environ["MESHAPI_BASE_URL"], api_key=os.environ["MESHAPI_API_KEY"])

docs = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=100).split_documents(
    PyPDFLoader("handbook.pdf").load())
vs = InMemoryVectorStore.from_documents(docs, emb)
retriever = vs.as_retriever(search_kwargs={"k": 4})

def rag(q):
    ctx = "\n\n".join(d.page_content for d in retriever.invoke(q))
    return llm.invoke(f"Answer only from context.\n\n{ctx}\n\nQ: {q}").content
```

### 3. Multi-agent with LangChain on MeshAPI

```python
from langchain.agents import create_agent
from langchain.tools import tool

def mesh_model(name):  # different vendors behind one gateway
    return ChatOpenAI(model=name, base_url=os.environ["MESHAPI_BASE_URL"],
                      api_key=os.environ["MESHAPI_API_KEY"])

researcher = create_agent(mesh_model("gpt-4o-mini"), tools=[web_search],
                          system_prompt="Research and return bullet facts.")
writer = create_agent(mesh_model("claude-sonnet-4-5"), tools=[],
                      system_prompt="Write a polished answer from given facts.")

@tool
def research(topic: str) -> str:
    """Research a topic."""
    return researcher.invoke({"messages": [("user", topic)]})["messages"][-1].content

@tool
def write(facts: str) -> str:
    """Write final answer from facts."""
    return writer.invoke({"messages": [("user", facts)]})["messages"][-1].content

lead = create_agent(mesh_model("gpt-4o"), tools=[research, write],
                    system_prompt="First research, then write.")
```

Picking a model per agent from one gateway is the main advantage here: a cheap model for research and a strong writer for the final text.

### 4. Hosted RAG + multimodal generation (pattern)

```python
# Images (OpenAI-compatible images endpoint, if supported)
img = mesh.images.generate(model="<image-model-id>", prompt="isometric data center, neon")
# Audio TTS
speech = mesh.audio.speech.create(model="<tts-model-id>", voice="alloy", input="Welcome!")
# Video: usually an async job API -> submit, poll status, download URL (check MeshAPI docs)
```

### 5. MCP server

Add the gateway's MCP server to an MCP client (Claude Desktop / Cursor / LangGraph):

```json
{
  "mcpServers": {
    "meshapi": {
      "command": "npx",
      "args": ["-y", "<meshapi-mcp-package>"],
      "env": { "MESHAPI_API_KEY": "..." }
    }
  }
}
```

Then the agent can call gateway capabilities (generate an image, query hosted RAG, list models) as tools.

### 6. CLI coding agent + assignment

The CLI agent is a terminal coding assistant (similar to Claude Code / Codex CLI) that uses any gateway model.

**Assignment idea:** build a "docs Q&A" CLI that (1) ingests a folder, (2) answers questions using RAG via the gateway, (3) falls back to a second model on error, and (4) prints token cost per question.

---

## Deep dive

- **How aggregators work:** they hold provider contracts, translate request formats, meter usage, and bill you. Some add their own caching or routing ("auto" model selection).
- **Data path:** your prompts go through a **third party**. Read the data retention and training policy, and check SOC 2 / DPA status.

## Advanced

- **Vendor risk:** an aggregator outage takes down every model you use through it. Keep a **direct-provider fallback** for critical paths.
- **Price transparency:** compare the aggregator's per-token price with direct pricing. Markups or credit systems vary.
- **Hosted RAG limits:** hosted file search is quick for prototypes but offers less control over chunking, filters, ACLs, and evals.

## Production & scale

- Use separate keys per environment and service, and set budgets.
- Log `usage` from responses to your own observability stack, so you don't rely only on the vendor dashboard.
- Keep the code gateway-agnostic (an OpenAI-compatible client with a configurable base URL), so switching gateways is just a config change.

## FAANG insights

- Big companies rarely send production traffic through third-party aggregators, because of data governance. They use them for **prototyping and model scouting**. Internal gateways handle production.
- Interview: *"Startup vs enterprise gateway choice?"* Startups optimize for speed (hosted aggregator), while enterprises optimize for control, compliance, and cost (self-hosted gateway, direct contracts).

## Interview questions

1. **Aggregator vs self-hosted gateway?** Convenience and breadth vs control, data residency, and cost at scale.
2. **Why keep gateway-agnostic code?** To avoid lock-in and make failover easy.
3. **What should you check before sending PII through a hosted gateway?** Its DPA, retention, training-use policy, region, and certifications.

## Checklist

- [ ] Model IDs taken from `models.list()`, not hard-coded guesses
- [ ] Direct-provider fallback for critical flows
- [ ] Data policy reviewed
- [ ] Usage logged to your own stack
