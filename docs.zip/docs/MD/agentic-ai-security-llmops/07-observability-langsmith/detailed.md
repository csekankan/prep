# 07 — Observability for LLM Apps: LangSmith + LangGraph Studio

> **One sentence:** LLM apps fail **silently**: a wrong answer still returns HTTP 200. So you need **traces** of every prompt, retrieval, tool call, token count, and latency to debug, evaluate, and control cost.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Introduction to observability | Basics |
| Frameworks for observability | Basics (comparison) |
| Introduction to LangSmith | Code §1 |
| Manual and custom tracing | Code §2–§3 |
| Simple and agentic RAG tracing | Code §4 |
| LangGraph app development | Code §5 |
| App execution with LangGraph Studio | Code §5, Deep dive |

---

## Basics

### Classic observability vs LLM observability

| Classic (services) | LLM apps add… |
|--------------------|---------------|
| Logs, metrics, traces | **Prompts, completions, retrieved chunks, tool args** |
| Latency, error rate | **Tokens, cost, time-to-first-token, quality scores** |
| Errors are exceptions | Errors are **wrong / unsafe / hallucinated** answers |
| Debug with stack traces | Debug with **run trees** and **replays** |

### Key terms

| Term | Meaning |
|------|---------|
| **Trace** | One end-to-end request |
| **Run / span** | One step inside it (LLM call, retriever, tool, chain) |
| **Run tree** | Parent/child nesting of spans |
| **Project** | Bucket of traces (per app/env) |
| **Dataset** | Saved inputs (+ reference outputs) for evals |
| **Feedback** | Scores attached to runs (user 👍, LLM judge, heuristics) |

### Framework landscape

| Tool | Type | Notes |
|------|------|-------|
| **LangSmith** | SaaS (self-host on enterprise) | Deepest LangChain/LangGraph integration, evals, prompt hub |
| **Langfuse** | Open-source, self-hostable | Popular OSS choice, OTel-based |
| **Pydantic Logfire** | SaaS, OTel-native | Great for Python/FastAPI + LLM (section 08) |
| **Arize Phoenix** | OSS | OpenInference spans, strong on evals/RAG |
| **Helicone / Portkey** | Proxy/gateway-based | Logging via the gateway (section 13) |
| **Datadog / Grafana LLM obs** | APM vendors | Unified with infra monitoring |

---

## Code

### 1. LangSmith setup (zero-code for LangChain)

```bash
export LANGSMITH_TRACING=true
export LANGSMITH_API_KEY=lsv2_...
export LANGSMITH_PROJECT=rag-dev
# optional: LANGSMITH_ENDPOINT for EU/self-hosted
```

### 2. Tracing plain Python with `@traceable`

```python
from langsmith import traceable
from langsmith.wrappers import wrap_openai
from openai import OpenAI

client = wrap_openai(OpenAI())            # every OpenAI call becomes an LLM span

@traceable(run_type="retriever", name="vector_search")
def retrieve(q: str) -> list[dict]:
    return [{"page_content": "LangSmith is...", "metadata": {"src": "docs"}}]

@traceable(run_type="chain", name="rag_pipeline",
           tags=["v2"], metadata={"tenant": "acme"})
def rag(q: str) -> str:
    docs = retrieve(q)
    ctx = "\n".join(d["page_content"] for d in docs)
    r = client.chat.completions.create(model="gpt-4o-mini",
        messages=[{"role": "user", "content": f"Context:\n{ctx}\n\nQ: {q}"}])
    return r.choices[0].message.content

rag("What is LangSmith?")
```

### 3. Custom / manual spans and feedback

```python
from langsmith import Client, trace
from langsmith.run_helpers import get_current_run_tree

with trace(name="rerank", run_type="tool", inputs={"n": 20}) as rt:
    ranked = do_rerank()
    rt.end(outputs={"top": ranked[:3]})

@traceable
def answer(q):
    run = get_current_run_tree()
    run_id = run.id
    ...
    return out, run_id

Client().create_feedback(run_id, key="user_thumbs", score=1, comment="helpful")
```

**Privacy:** hide inputs/outputs with `LANGSMITH_HIDE_INPUTS=true` / `LANGSMITH_HIDE_OUTPUTS=true`, or with custom `hide_inputs=` functions on the client, to keep PII out of traces.

### 4. Agentic RAG trace shape

```
rag_agent (chain)
├── agent (llm)            → decides to call retrieve
├── tools
│   └── retrieve (retriever) → 5 docs
├── grade_documents (llm)  → "relevant: 3/5"
├── rewrite_query (llm)    → only if grading failed
└── generate (llm)         → final answer, 812 tokens, 1.9s
```

Use this tree to answer: *Was retrieval bad, or generation bad?* (That's the single most useful RAG debugging question.)

### 5. LangGraph Studio (local dev server)

```bash
uv add "langgraph-cli[inmem]"
langgraph dev            # reads langgraph.json, opens Studio in browser
```

Studio lets you **visualize the graph**, send inputs, step through nodes, **edit state and re-run from a checkpoint** (time-travel), and see interrupts for HITL testing.

---

## Deep dive

- **How tracing works:** the SDK builds a run tree using context variables (`contextvars`), so nested `@traceable` calls automatically become children. Runs are sent **asynchronously in batches** by a background thread, so they don't block your request. Call `client.flush()` / `wait_for_all_tracers()` in serverless functions before exit.
- **Distributed tracing:** pass `langsmith-trace` headers between services (`run_tree.to_headers()`) to stitch traces across microservices.
- **OpenTelemetry:** LangSmith can ingest OTel spans, and the OTel GenAI semantic conventions (`gen_ai.*` attributes) are becoming the standard.

## Advanced

- **Sampling:** trace 100% in dev and maybe 5–20% in prod, plus **100% of errors and flagged runs**. Configure with `LANGSMITH_SAMPLING_RATE`.
- **Online evaluators:** automatically run LLM-judge rules on sampled prod traces (e.g. "was this answer grounded?") and send failures to an **annotation queue** for human review.
- **Datasets from prod:** filter bad traces, add them to a dataset, and use them as regression tests. This is the flywheel.
- **Prompt versioning:** the prompt hub links prompt versions to traces, so you can see which prompt caused a regression.

## Production & scale

| Metric | Why |
|--------|-----|
| p50/p95 latency, **TTFT** | UX |
| Tokens in/out per request, **cost per tenant** | Budget |
| Tool error rate, retries | Reliability |
| Guardrail block rate | Security and false positives |
| Online eval scores (faithfulness, relevance) | Quality drift |
| Feedback rate 👍/👎 | Ground-truth signal |

Alert on **drift**, not only thresholds: compare the cost per request this week with last week.

## FAANG insights

- At scale, teams **separate** high-volume telemetry (OTel → their APM) from **rich LLM payload storage** (sampled and PII-scrubbed in an LLM observability tool).
- **Trace → dataset → eval → deploy** is the core loop that LLM platform teams build.
- Interview: *"Users say the bot got worse last Tuesday. How do you investigate?"* Filter traces by date, compare prompt/model versions, run the eval suite on before/after, and inspect retrieval vs generation spans.

## Interview questions

1. **Why are LLM failures "silent"?** Wrong outputs are still successful HTTP responses, so you need quality metrics.
2. **What's in a span for an LLM call?** Model, params, prompt, completion, tokens, latency, cost, and errors.
3. **How do you avoid logging PII in traces?** Masking hooks, redaction before tracing, sampling, and access controls.

## Checklist

- [ ] Tracing on in all envs (separate projects)
- [ ] PII masking configured
- [ ] Cost, latency, and quality dashboards
- [ ] Bad traces feed datasets
- [ ] Flush tracers in serverless
