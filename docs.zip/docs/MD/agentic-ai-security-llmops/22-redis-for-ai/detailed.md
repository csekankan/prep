# 22 — Redis for AI: Exact & Semantic Caching, Agent Memory, Rate Limiting, RAG Caching

> **One sentence:** Redis is an in-memory data store with vector search, which makes it the Swiss-army knife for LLM apps: **exact cache** (hash → answer), **semantic cache** (similar question → answer), **conversation memory**, **rate limiting / cost control**, and **RAG result caching**, all at sub-millisecond latency.

## Lecture map

| # | Lecture | Covered in |
|---|---------|-----------|
| 01 | Redis setup and prerequisites | Code §1 |
| 02 | Introduction to Redis for AI & LLM caching | Basics |
| 03 | Exact match LLM caching | Code §2 |
| 04 | Semantic caching with embeddings | Code §3 |
| 05 | AI agent conversation memory with Redis | Code §4 |
| 06 | Rate limiting & API cost control | Code §5 |
| 07 | RAG caching and final web application demo | Code §6 |

---

## Basics

| Use | Redis structure | Win |
|-----|-----------------|-----|
| Exact cache | `STRING` with TTL (`SET key val EX 3600`) | 0 tokens on repeat questions |
| Semantic cache | Vector index (Redis Query Engine / RedisVL) | Hits on paraphrases |
| Chat memory | `LIST` / JSON per session, or LangGraph `RedisSaver` | Fast, TTL-based sessions |
| Rate limit | `INCR` + `EXPIRE` (fixed window) or `ZSET` (sliding window) | Abuse + budget control |
| Token budget | `INCRBY tokens:{user}:{day}` | Denial-of-wallet protection |
| RAG cache | Cache retrieval results / embeddings | Skip the vector DB + embedding call |

**Analogy:** Redis is the **sticky-note wall next to your desk**. Before you call the expensive expert (the LLM), check if the answer is already on a sticky note.

---

## Code

### 1. Setup

```bash
docker run -d --name redis -p 6379:6379 redis:8       # Redis 8 includes vector search/JSON
# or redis/redis-stack for older versions (+ RedisInsight on 8001)
uv add redis redisvl openai
```

```python
import redis
r = redis.Redis(host="localhost", port=6379, decode_responses=True)
r.ping()
```

### 2. Exact-match LLM cache

```python
import hashlib, json
from openai import OpenAI
oa = OpenAI()

def cache_key(model, messages, temperature, prompt_version="v1"):
    blob = json.dumps({"m": model, "msgs": messages, "t": temperature, "pv": prompt_version},
                      sort_keys=True)
    return "llm:exact:" + hashlib.sha256(blob.encode()).hexdigest()

def cached_chat(messages, model="gpt-4o-mini", temperature=0, ttl=3600):
    k = cache_key(model, messages, temperature)
    if (hit := r.get(k)):
        return json.loads(hit) | {"cache": "hit"}
    resp = oa.chat.completions.create(model=model, messages=messages, temperature=temperature)
    out = {"text": resp.choices[0].message.content, "usage": resp.usage.total_tokens}
    r.set(k, json.dumps(out), ex=ttl)
    return out | {"cache": "miss"}
```

Only cache **deterministic-ish** calls (temperature 0) and include everything that changes the output in the key.

### 3. Semantic cache (RedisVL)

```python
from redisvl.extensions.cache.llm import SemanticCache      # older: redisvl.extensions.llmcache
from redisvl.utils.vectorize import OpenAITextVectorizer

scache = SemanticCache(
    name="llmcache",
    redis_url="redis://localhost:6379",
    distance_threshold=0.1,                 # cosine distance; lower = stricter
    ttl=86400,
    vectorizer=OpenAITextVectorizer(model="text-embedding-3-small"),
)

def semantic_chat(q, tenant="acme"):
    if hits := scache.check(prompt=q, filter_expression=None, num_results=1):
        return hits[0]["response"]
    ans = oa.chat.completions.create(model="gpt-4o-mini",
            messages=[{"role": "user", "content": q}]).choices[0].message.content
    scache.store(prompt=q, response=ans, metadata={"tenant": tenant})
    return ans

semantic_chat("What is your refund policy?")
semantic_chat("How do refunds work?")     # likely a cache hit
```

### 4. Conversation memory

```python
def add_msg(session, role, content, ttl=86400, max_len=50):
    key = f"chat:{session}"
    r.rpush(key, json.dumps({"role": role, "content": content}))
    r.ltrim(key, -max_len, -1)                  # sliding window
    r.expire(key, ttl)

def history(session):
    return [json.loads(x) for x in r.lrange(f"chat:{session}", 0, -1)]

# LangGraph: durable checkpoints in Redis
# from langgraph.checkpoint.redis import RedisSaver
# with RedisSaver.from_conn_string("redis://localhost:6379") as cp: cp.setup(); graph = b.compile(checkpointer=cp)
```

### 5. Rate limiting and cost control

```python
import time

def fixed_window(user, limit=20, window=60):
    k = f"rl:{user}:{int(time.time() // window)}"
    n = r.incr(k)
    if n == 1: r.expire(k, window)
    return n <= limit

def sliding_window(user, limit=20, window=60):
    k, now = f"rls:{user}", time.time()
    p = r.pipeline()
    p.zremrangebyscore(k, 0, now - window)
    p.zadd(k, {f"{now}": now})
    p.zcard(k)
    p.expire(k, window)
    _, _, count, _ = p.execute()
    return count <= limit

def charge_tokens(user, tokens, daily_budget=200_000):
    k = f"tok:{user}:{time.strftime('%Y%m%d')}"
    used = r.incrby(k, tokens); r.expire(k, 172800)
    return used <= daily_budget        # False -> block / downgrade model
```

For strict atomicity under high concurrency, implement token-bucket checks as a **Lua script** (`r.register_script(...)`).

### 6. RAG caching + web app

```python
def cached_retrieve(q, k=5, ttl=600):
    key = "rag:ret:" + hashlib.sha256(f"{q}|{k}|idx_v3".encode()).hexdigest()
    if (hit := r.get(key)): return json.loads(hit)
    docs = vector_search(q, k)
    r.set(key, json.dumps(docs), ex=ttl)
    return docs

def cached_embed(text, model="text-embedding-3-small"):
    key = f"emb:{model}:" + hashlib.sha256(text.encode()).hexdigest()
    if (hit := r.get(key)): return json.loads(hit)
    v = oa.embeddings.create(model=model, input=text).data[0].embedding
    r.set(key, json.dumps(v)); return v
```

```mermaid
flowchart LR
  U[User] --> API[FastAPI]
  API --> RL{Rate limit OK?}
  RL -- no --> E[429]
  RL -- yes --> SC{Semantic cache hit?}
  SC -- yes --> U
  SC -- no --> RC[Retrieval cache / vector DB]
  RC --> LLM
  LLM --> SC2[store in cache] --> U
  API <--> MEM[(Redis chat memory)]
```

---

## Deep dive

- **Vector search in Redis:** HNSW or FLAT indexes over HASH/JSON documents, with hybrid filtering by TAG/NUMERIC fields (e.g. `@tenant:{acme}`).
- **Distance threshold tuning:** too loose returns **wrong answers** for similar-looking but different questions ("cancel order" vs "cancel subscription"). Too strict means a low hit rate. Tune on labeled paraphrase pairs.
- **Eviction:** set `maxmemory` + `allkeys-lru` (or LFU) for pure caches. Use **separate Redis instances/DBs** for cache vs memory vs rate limits, so cache eviction doesn't delete sessions.

## Advanced

- **Cache poisoning:** if an attacker gets a bad answer cached, everyone receives it. Only cache **guardrail-passed** responses, scope by tenant, and add a TTL.
- **Personalized answers must never go into a shared semantic cache.** Include `user_id` in a filter, or skip caching.
- **Cache invalidation for RAG:** include the index version in keys, and bump the version on re-ingestion.
- **Stampede protection:** use a lock (`SET key lock NX EX 30`) so only one request computes on a miss.

## Production & scale

- Managed Redis (ElastiCache/MemoryDB, Memorystore, Redis Cloud), replicas + cluster mode for scale.
- Track hit rate, tokens saved (cost avoided), p99 latency, and evictions.
- Typical results: semantic cache hit rates of 20–60% for FAQ/support bots and near zero for open-ended chat. **Measure before investing.**

## FAANG insights

- At scale, **provider-side prompt caching** (OpenAI/Anthropic prefix caching) and **app-side response caching** complement each other. Interviewers like candidates who know both exist.
- Rate limiting by **tokens and cost**, not just requests, is the LLM-specific twist on classic API design.
- Interview: *"Design a cache for an LLM support bot."* Cover exact + semantic tiers, tenant scoping, TTL + version keys, guardrail-gated writes, threshold tuning, and hit-rate metrics.

## Interview questions

1. **Exact vs semantic cache?** A hash of the full request vs embedding similarity. Semantic gets more hits but risks wrong answers.
2. **Fixed vs sliding window rate limit?** Simple but bursty at window edges vs smooth and more memory per user.
3. **How do you avoid serving another tenant's cached answer?** Tenant in the key/filter, plus no caching of personalized responses.

## Checklist

- [ ] Cache keys include model, params, prompt version, tenant
- [ ] Semantic threshold tuned on labeled pairs
- [ ] Only safe (guardrail-passed) responses cached
- [ ] Token budgets per user/day
- [ ] Separate Redis roles + eviction policies
