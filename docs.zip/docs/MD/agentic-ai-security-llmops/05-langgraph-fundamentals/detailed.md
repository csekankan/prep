# 05 — LangGraph Fundamentals: Chatbots, ReAct Agents, Memory, HITL

> **One sentence:** LangGraph models an agent as a **state machine**: nodes are functions, edges decide what runs next, and a **checkpointer** saves state after every step. That gives you memory, pause/resume, time-travel, and fault tolerance.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Introduction to LangGraph | Basics |
| Project structure and environment setup | Code §0 |
| Building basic AI chatbots with LangGraph | Code §1 |
| Building ReAct agent with LangGraph | Code §2 |
| Memory implementation in AI agents | Code §3 |
| Human-in-the-loop implementation | Code §4 |

---

## Basics

| Concept | Plain English |
|---------|---------------|
| **State** | A typed dict shared by all nodes (e.g. `messages`) |
| **Reducer** | How updates merge into state (`add_messages` appends instead of overwriting) |
| **Node** | A Python function `state -> partial state update` |
| **Edge** | Fixed transition A → B |
| **Conditional edge** | A function decides the next node (routing) |
| **Checkpointer** | Saves state per `thread_id` after each super-step |
| **Thread** | One conversation / run history |
| **Store** | Long-term memory shared **across threads** |

**Analogy:** A LangChain chain is a **train track**, where you always go A→B→C. LangGraph is a **subway map with switches**, where you can loop, branch, wait at a station for a human, and every station keeps a **save point**.

---

## Code

### 0. Project structure

```
langgraph-course/
├── pyproject.toml          # uv-managed
├── .env                    # OPENAI_API_KEY, LANGSMITH_API_KEY, ...
├── langgraph.json          # for LangGraph Studio / Platform
└── src/agent/
    ├── state.py
    ├── nodes.py
    ├── tools.py
    └── graph.py            # exports `graph`
```

```json
// langgraph.json
{ "dependencies": ["."], "graphs": { "agent": "./src/agent/graph.py:graph" }, "env": ".env" }
```

### 1. Basic chatbot

```python
from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain.chat_models import init_chat_model

llm = init_chat_model("openai:gpt-4o-mini")

class State(TypedDict):
    messages: Annotated[list, add_messages]   # reducer: append

def chatbot(state: State):
    return {"messages": [llm.invoke(state["messages"])]}

builder = StateGraph(State)
builder.add_node("chatbot", chatbot)
builder.add_edge(START, "chatbot")
builder.add_edge("chatbot", END)
graph = builder.compile()

print(graph.invoke({"messages": [("user", "Hi!")]})["messages"][-1].content)
```

### 2. ReAct agent, built by hand

```python
from langgraph.prebuilt import ToolNode, tools_condition
from langchain.tools import tool

@tool
def multiply(a: int, b: int) -> int:
    """Multiply two ints."""
    return a * b

@tool
def web_search(q: str) -> str:
    """Search the web."""
    return "LangGraph 1.0 was released in Oct 2025."

tools = [multiply, web_search]
llm_tools = llm.bind_tools(tools)

def agent(state: State):
    return {"messages": [llm_tools.invoke(state["messages"])]}

b = StateGraph(State)
b.add_node("agent", agent)
b.add_node("tools", ToolNode(tools))
b.add_edge(START, "agent")
b.add_conditional_edges("agent", tools_condition)   # -> "tools" or END
b.add_edge("tools", "agent")                          # loop back = ReAct
react = b.compile()
```

ReAct means **Re**ason + **Act**: think, call a tool, observe the result, and repeat until done.

### 3. Memory (short-term and long-term)

```python
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.store.memory import InMemoryStore

# short-term: per-thread conversation memory
graph = b.compile(checkpointer=InMemorySaver())
cfg = {"configurable": {"thread_id": "user-42-session-1"}}
graph.invoke({"messages": [("user", "My name is Kunal")]}, cfg)
graph.invoke({"messages": [("user", "What's my name?")]}, cfg)   # remembers

# inspect / time-travel
snap = graph.get_state(cfg)
history = list(graph.get_state_history(cfg))

# long-term: cross-thread store
store = InMemoryStore()
def remember(state, *, store):
    store.put(("users", "42"), "profile", {"name": "Kunal", "lang": "en"})
    return {}
graph = b.compile(checkpointer=InMemorySaver(), store=store)
```

Production checkpointers: `PostgresSaver` / `AsyncPostgresSaver` (`langgraph-checkpoint-postgres`), `SqliteSaver`, and `RedisSaver`.

### 4. Human-in-the-loop with `interrupt`

```python
from langgraph.types import interrupt, Command

def approve_refund(state: State):
    amount = state["refund_amount"]
    if amount > 100:
        decision = interrupt({"question": f"Approve refund of ${amount}?"})
        if decision != "yes":
            return {"messages": [("assistant", "Refund rejected by reviewer.")]}
    return {"messages": [("assistant", f"Refunded ${amount}.")]}

# run → pauses → returns __interrupt__
graph.invoke(inputs, cfg)
# resume with human answer
graph.invoke(Command(resume="yes"), cfg)
```

---

## Deep dive

### Execution model (Pregel / BSP)

LangGraph runs in **super-steps** (Bulk Synchronous Parallel, the model from Google's Pregel):

1. Every node scheduled in this step runs (**in parallel** if there are several).
2. Their updates are applied to state through the **reducers**.
3. A **checkpoint** is written.
4. Edges decide which nodes are scheduled next.

This explains several behaviors:
- Parallel branches need reducers. Without one you get `InvalidUpdateError: Can receive only one value per step`.
- `interrupt()` re-runs the **whole node** on resume, so code before `interrupt()` must be idempotent.
- Crash recovery resumes from the last checkpoint, and with "pending writes" the nodes that already succeeded aren't re-run.

### `add_messages` reducer

- Appends new messages.
- If a message has the **same `id`** as an existing one, it **replaces** it (this is how you edit history).
- `RemoveMessage(id=...)` deletes a message.

### Routing with `Command`

```python
def router(state) -> Command[Literal["billing", "tech"]]:
    return Command(goto="billing", update={"route": "billing"})
```

`Command` updates state and routes at the same time, which is useful for handoffs (section 06).

---

## Advanced

- **`recursion_limit`** (default 25 super-steps) is your infinite-loop breaker. Set it per request with `config={"recursion_limit": 50}`.
- **Subgraphs:** compile a graph and use it as a node in another graph. Each subgraph can have private state.
- **`Send` API:** map-reduce fan-out, e.g. `[Send("summarize", {"doc": d}) for d in docs]`.
- **Durability modes:** `"exit"`, `"async"`, `"sync"`. They trade checkpoint-write latency against crash safety.
- **Message trimming:** `trim_messages(strategy="last", max_tokens=...)` in the model node, as an alternative to summarization.
- **Security:** state is persisted, so **never put raw secrets in state**. Checkpoints are often readable by ops staff.

## Production & scale

- Postgres checkpointer with a connection pool. Index by `thread_id` and prune old checkpoints (TTL).
- Checkpoint size grows with message history. Large tool outputs belong in blob storage, with **only references in state**.
- Use `astream(stream_mode="messages")` for token streaming to the UI.
- Horizontal scale: graphs are stateless between steps (state lives in the DB), so any worker can resume any thread.

## FAANG insights

- The pattern most teams converge on is **"durable execution"** (like Temporal or AWS Step Functions) applied to LLM agents. LangGraph checkpoints are that idea.
- Interview: *"How do you resume a 30-minute agent run after a pod restart?"* Answer: persistent checkpoints, idempotent nodes, and pending writes.
- Interview: *"Short-term vs long-term memory?"* Thread-scoped checkpointer vs cross-thread store (namespaced by user).

## Interview questions

1. **What's a reducer and why do you need it?** It defines how concurrent or sequential updates merge into a state key.
2. **What happens to code before `interrupt()` on resume?** It runs again, so make it idempotent.
3. **Checkpointer vs Store?** Per-thread snapshots vs a cross-thread key-value/vector store.

## Checklist

- [ ] Typed state with reducers on list fields
- [ ] Persistent checkpointer + `thread_id` strategy
- [ ] `recursion_limit` set
- [ ] Nodes idempotent (especially around `interrupt`)
- [ ] No secrets in state
