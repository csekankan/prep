# 11 — Guardrails AI: Hub, Validators, OnFailAction, Streaming, LangChain

> **One sentence:** Guardrails AI wraps LLM calls in a **`Guard`** made of **validators** from the Guardrails Hub (PII, toxicity, competitor mentions, regex, JSON schema…). Each validator has an **`on_fail`** policy (exception, fix, reask, filter, refrain, noop) that decides what happens when a check fails.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Introduction to Guardrails AI | Basics |
| Why learn Guardrails AI | Basics |
| Guardrails Hub and validators explained | Basics, Code §1 |
| OnFailAction overview | Basics |
| Types of OnFailAction explained | Basics (table) |
| Basic setup and validators installation from hub | Code §1 |
| Validators implementation explained | Code §2, §6 |
| OnFailAction implementation, parts 1 & 2 | Code §3 |
| Input and output structure validation | Code §4 |
| Orchestration & real-time streaming with Guard object | Code §5 |
| Using Guardrails AI with LangChain | Code §7 |
| Ways to implement guardrails in your applications | Deep dive |

---

## Basics

**Analogy:** A `Guard` is an **airport security line**. Each validator is a **scanner** (metal detector, X-ray, sniffer dog). `on_fail` is the **officer's response**: arrest (exception), confiscate the item (fix/filter), send back to repack (reask), or deny boarding (refrain).

### OnFailAction types

| Action | What happens | Use when |
|--------|-------------|----------|
| `EXCEPTION` | Raise `ValidationError` | Hard security policy, so you can fail closed |
| `FIX` | Replace with the validator's `fix_value` (e.g. masked PII) | Deterministic fix exists |
| `REASK` | Re-prompt the LLM with the error, up to `num_reasks` | Format/content the LLM can correct |
| `FIX_REASK` | Try fix, then reask if the fix still fails | Best effort |
| `FILTER` | Drop the failing field/value (structured output) | Optional fields |
| `REFRAIN` | Return `None` / empty output | "Better say nothing" |
| `NOOP` | Log only, pass output through | Shadow mode / monitoring |
| `CUSTOM` | Your own function `(value, fail_result) -> new_value` | Anything else |

---

## Code

### 1. Setup + hub install

```bash
uv add guardrails-ai
guardrails configure                          # Hub API key (free), telemetry opt-in/out
guardrails hub install hub://guardrails/detect_pii
guardrails hub install hub://guardrails/toxic_language
guardrails hub install hub://guardrails/competitor_check
guardrails hub install hub://guardrails/regex_match
guardrails hub install hub://guardrails/valid_length
```

### 2. Basic validators

```python
from guardrails import Guard, OnFailAction
from guardrails.hub import DetectPII, ToxicLanguage, CompetitorCheck, RegexMatch

guard = Guard().use_many(
    DetectPII(pii_entities=["EMAIL_ADDRESS", "PHONE_NUMBER"], on_fail=OnFailAction.FIX),
    ToxicLanguage(threshold=0.5, validation_method="sentence", on_fail=OnFailAction.EXCEPTION),
    CompetitorCheck(competitors=["AcmeCorp", "Globex"], on_fail=OnFailAction.FIX),
)

out = guard.validate("Email me at john@x.com, we beat AcmeCorp!")
print(out.validation_passed, out.validated_output)
# True "Email me at <EMAIL_ADDRESS>, we beat [COMPETITOR]!"
```

### 3. OnFailAction in practice

```python
from guardrails.errors import ValidationError

# EXCEPTION -> fail closed
strict = Guard().use(ToxicLanguage(on_fail="exception"))
try:
    strict.validate("you are an idiot")
except ValidationError as e:
    print("blocked:", e)

# REASK -> LLM fixes its own output
reask_guard = Guard().use(RegexMatch(regex=r"^[A-Z][a-z]+$", on_fail="reask"))
res = reask_guard(model="gpt-4o-mini",
                  messages=[{"role": "user", "content": "Give one capitalized fruit name only"}],
                  num_reasks=2)

# CUSTOM
def soften(value, fail_result):
    return "I'd rather not say that. " + (fail_result.fix_value or "")
Guard().use(ToxicLanguage(on_fail=soften))

# NOOP -> shadow mode, inspect logs
shadow = Guard().use(DetectPII(on_fail="noop"))
r = shadow.validate("call 555-123-4567")
print(r.validation_summaries)       # see what *would* have failed
```

### 4. Input and output structure validation

```python
from pydantic import BaseModel, Field
from guardrails.hub import ValidLength

class Profile(BaseModel):
    name: str = Field(json_schema_extra={"validators": [ValidLength(min=1, max=50, on_fail="fix")]})
    bio: str = Field(json_schema_extra={"validators": [DetectPII(on_fail="fix")]})
    age: int = Field(ge=18, le=100)

guard = Guard.for_pydantic(Profile)
res = guard(model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Generate a profile for a 30yo engineer"}])
print(res.validated_output)   # dict that matches Profile, with PII fixed

# Input validation: validate the prompt before it reaches the LLM
in_guard = Guard().use(DetectPII(on_fail="exception"), on="messages")
```

### 5. Streaming with the Guard object

```python
guard = Guard().use(ToxicLanguage(validation_method="sentence", on_fail="fix"))
for chunk in guard(model="gpt-4o-mini",
                   messages=[{"role": "user", "content": "Tell me a story"}],
                   stream=True):
    print(chunk.validated_output, end="", flush=True)
```

Validators that work per sentence accumulate chunks until a sentence boundary, validate it, and then emit. That gives you **real-time validation** with a small buffering delay.

### 6. Writing a custom validator

```python
from guardrails.validators import Validator, register_validator, PassResult, FailResult

@register_validator(name="no-internal-urls", data_type="string")
class NoInternalUrls(Validator):
    def _validate(self, value: str, metadata: dict):
        if "corp.internal" in value:
            return FailResult(error_message="internal URL leaked",
                              fix_value=value.replace("corp.internal", "[redacted]"))
        return PassResult()

Guard().use(NoInternalUrls(on_fail="fix"))
```

### 7. With LangChain (LCEL)

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

guard = Guard().use(CompetitorCheck(competitors=["AcmeCorp"], on_fail="fix"))
chain = (ChatPromptTemplate.from_template("Answer: {q}")
         | ChatOpenAI(model="gpt-4o-mini")
         | StrOutputParser()
         | guard.to_runnable())
chain.invoke({"q": "Who makes the best rockets?"})
```

---

## Deep dive

### Ways to implement guardrails in your app

| Mode | How | Pros / cons |
|------|-----|-------------|
| **Validate-only** | `guard.validate(text)` on any string | Works with any LLM/framework, but no reask |
| **Wrapped LLM call** | `guard(model=..., messages=...)` (LiteLLM under the hood) | Reask, streaming, history; ties you to Guard's call path |
| **LangChain runnable** | `guard.to_runnable()` in LCEL | Composes with chains |
| **Guardrails Server** | `guardrails start --config config.py` → OpenAI-compatible endpoint | Central service, language-agnostic, scales separately |
| **Remote validators** | Heavy ML validators run on hosted inference endpoints | No local GPU needed, adds network latency |

### Validation flow

```mermaid
flowchart LR
  P[Prompt] --> IV[Input validators] --> L[LLM]
  L --> PAR[Parse to schema] --> OV[Output validators per field]
  OV -->|pass| OUT[validated_output]
  OV -->|fail| ACT{on_fail}
  ACT -->|fix/filter| OUT
  ACT -->|reask| L
  ACT -->|exception| ERR[raise]
```

`guard.history` keeps every iteration (prompts, raw outputs, validator results), which is useful for debugging reask loops.

## Advanced

- **ML validators** (toxicity, PII NER, jailbreak) download models locally the first time. Pre-bake them into your Docker image to avoid cold starts.
- **Reask cost:** each reask is a full LLM call. Cap `num_reasks` (1–2) and track the reask rate.
- **Shadow → enforce rollout:** launch new validators with `NOOP`, measure the false-positive rate, then flip to `EXCEPTION` or `FIX`.
- **Validator ordering:** put fast deterministic validators (regex, length) first and ML validators after.

## Production & scale

- Run **Guardrails Server** as a sidecar or central service, so polyglot services share one policy.
- Monitor per-validator latency, failure rate, and the distribution of on_fail actions.
- Hub validators are third-party code, so **pin their versions** and review them (supply-chain risk, LLM03).

## FAANG insights

- The **shadow mode → enforce** rollout is standard for any safety classifier at big companies. Never launch a blocking filter without measuring false positives on real traffic.
- Interview: *"An LLM must output valid JSON for a payment API 99.99% of the time."* Answer: strict schema (constrained decoding), validator + reask fallback, a dead-letter queue for failures, and alerts on the reask rate.

## Interview questions

1. **FIX vs REASK?** FIX is deterministic and free. REASK costs an LLM call but can repair semantic errors.
2. **When would you use NOOP?** Shadow-testing a new validator in production.
3. **Validate-only vs wrapped call?** Validate-only is framework-agnostic. Wrapped calls enable reask and streaming validation.

## Checklist

- [ ] Hub validators pinned and models pre-baked in the image
- [ ] Each validator has a deliberate `on_fail`
- [ ] New validators start in NOOP
- [ ] `num_reasks` capped and reask rate monitored
