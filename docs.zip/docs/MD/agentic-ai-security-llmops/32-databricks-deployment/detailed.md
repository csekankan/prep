# 32 — Databricks Deployment: Workspace, Unity Catalog, OIDC, Asset Bundles, CI/CD, Apps

> **One sentence:** Deploy the agentic RAG system to Databricks the way a platform team would: initialize the workspace and Unity Catalog, authenticate CI with **OIDC (no secrets)**, describe everything in **Databricks Asset Bundles**, run a GitHub Actions pipeline, build the vector index, grant the app's service principal access, ship the **Databricks App**, and clean up.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Setting the stage for deployment | Basics |
| Initializing the Databricks workspace, Unity Catalog and OIDC | Code §1–§2 |
| Setting up Databricks Asset Bundles and CI/CD | Code §3–§4 |
| Running the CI/CD pipeline | Code §4 |
| Vector index creation and data ingestion | Code §5 |
| Granting the Databricks App's service principal access in Unity Catalog | Code §6 |
| Deploying agentic RAG on Databricks Apps | Code §7 |
| Happy ending: final clean up | Code §8 |

---

## Basics

### Deployment flow

```mermaid
flowchart LR
  DEV[Developer push] --> GH[GitHub Actions]
  GH -->|OIDC token| DBX[Databricks workspace]
  GH --> B[databricks bundle validate/deploy]
  B --> J[Jobs: ingestion]
  B --> APP[Databricks App]
  J --> DT[(Delta table)]
  DT --> VS[(Vector index)]
  APP --> SP[App service principal]
  SP -->|UC grants| DT & VS & EP[Serving endpoint]
```

### Why OIDC?

Long-lived personal access tokens in GitHub secrets can leak and are hard to rotate. With **OIDC workload identity federation**, GitHub issues a short-lived signed token for each workflow run, and Databricks trusts it through a **federation policy** bound to your repo/branch/environment. No stored secret is needed.

### What are Asset Bundles?

A **bundle** is a folder with `databricks.yml` describing jobs, pipelines, apps, model serving endpoints, schemas, and so on, with **targets** (dev/staging/prod). Think of it as "Terraform-lite for Databricks resources plus your code". The CLI deploys it: `databricks bundle deploy -t prod`.

---

## Code

### 1. Workspace + Unity Catalog init

```bash
brew install databricks/tap/databricks      # Databricks CLI (v0.2xx+)
databricks auth login --host https://<workspace>.cloud.databricks.com
databricks current-user me
```

```sql
CREATE CATALOG IF NOT EXISTS agentic_rag;
CREATE SCHEMA  IF NOT EXISTS agentic_rag.core;
CREATE VOLUME  IF NOT EXISTS agentic_rag.core.raw_docs;
```

Create service principals (account console or CLI): `sp-cicd` (deploys) and the app's own SP (auto-created by Databricks Apps).

### 2. OIDC federation for GitHub Actions

Create a **service principal federation policy** (account console → service principal → federation policies, or the CLI/API) with:
- **Issuer:** `https://token.actions.githubusercontent.com`
- **Audience:** your Databricks account ID (or as instructed by the docs)
- **Subject:** `repo:<org>/<repo>:environment:prod` (or `ref:refs/heads/main`)

```yaml
# in the workflow
permissions: { id-token: write, contents: read }
env:
  DATABRICKS_HOST: https://<workspace>.cloud.databricks.com
  DATABRICKS_CLIENT_ID: ${{ vars.DATABRICKS_SP_CLIENT_ID }}   # not a secret
  DATABRICKS_AUTH_TYPE: github-oidc
```

### 3. Asset Bundle

```yaml
# databricks.yml
bundle:
  name: agentic-rag

variables:
  catalog: { default: agentic_rag }
  schema:  { default: core }

resources:
  jobs:
    ingest_docs:
      name: ingest-docs-${bundle.target}
      tasks:
        - task_key: parse_chunk
          notebook_task: { notebook_path: ./src/ingest/parse_chunk.py,
                           base_parameters: { catalog: "${var.catalog}", schema: "${var.schema}" } }
          environment_key: default
        - task_key: build_index
          depends_on: [{ task_key: parse_chunk }]
          spark_python_task: { python_file: ./src/ingest/build_index.py }
          environment_key: default
      environments:
        - environment_key: default
          spec: { client: "2", dependencies: ["databricks-vectorsearch", "langchain-text-splitters"] }

  apps:
    rag_app:
      name: agentic-rag-app-${bundle.target}
      source_code_path: ./src/app
      description: Agentic RAG chat UI

targets:
  dev:
    mode: development
    default: true
    workspace: { host: https://<workspace>.cloud.databricks.com }
  prod:
    mode: production
    workspace: { host: https://<workspace>.cloud.databricks.com, root_path: /Workspace/agentic-rag/prod }
    run_as: { service_principal_name: <sp-cicd-application-id> }
```

```bash
databricks bundle validate -t dev
databricks bundle deploy -t dev
databricks bundle run ingest_docs -t dev
```

### 4. GitHub Actions CI/CD

```yaml
# .github/workflows/deploy.yml
name: deploy
on:
  pull_request:
  push: { branches: [main] }
permissions: { id-token: write, contents: read }

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: databricks/setup-cli@main
      - run: databricks bundle validate -t dev
        env: { DATABRICKS_HOST: "${{ vars.DATABRICKS_HOST }}", DATABRICKS_CLIENT_ID: "${{ vars.DATABRICKS_SP_CLIENT_ID }}",
               DATABRICKS_AUTH_TYPE: github-oidc }
      - run: pip install -r requirements-dev.txt && pytest -q

  deploy-prod:
    needs: validate
    if: github.ref == 'refs/heads/main'
    environment: prod                       # approvals + matches OIDC subject
    runs-on: ubuntu-latest
    env: { DATABRICKS_HOST: "${{ vars.DATABRICKS_HOST }}", DATABRICKS_CLIENT_ID: "${{ vars.DATABRICKS_SP_CLIENT_ID }}",
           DATABRICKS_AUTH_TYPE: github-oidc }
    steps:
      - uses: actions/checkout@v4
      - uses: databricks/setup-cli@main
      - run: databricks bundle deploy -t prod
      - run: databricks bundle run ingest_docs -t prod
      - run: databricks bundle run rag_app -t prod      # (re)deploys/starts the app
```

Typical first-run failures: an OIDC subject mismatch (environment vs branch), the SP lacking workspace access or `CREATE` on the catalog, or a missing UC grant for the job's run-as identity.

### 5. Vector index + ingestion

```python
# src/ingest/build_index.py
from databricks.vector_search.client import VectorSearchClient
vsc = VectorSearchClient()
EP, IDX, SRC = "rag-vs-endpoint", "agentic_rag.core.chunks_index", "agentic_rag.core.chunks"

if EP not in [e["name"] for e in vsc.list_endpoints().get("endpoints", [])]:
    vsc.create_endpoint_and_wait(name=EP, endpoint_type="STANDARD")

try:
    idx = vsc.get_index(EP, IDX)
    idx.sync()
except Exception:
    vsc.create_delta_sync_index_and_wait(
        endpoint_name=EP, index_name=IDX, source_table_name=SRC,
        pipeline_type="TRIGGERED", primary_key="id",
        embedding_source_column="text", embedding_model_endpoint_name="databricks-gte-large-en")
```

The script is idempotent (create if missing, otherwise sync), so it's safe to re-run in CI.

### 6. Grant the app's service principal access (UC)

```sql
-- find the app SP's application ID in the App's details page
GRANT USE CATALOG ON CATALOG agentic_rag TO `<app-sp-application-id>`;
GRANT USE SCHEMA  ON SCHEMA  agentic_rag.core TO `<app-sp-application-id>`;
GRANT SELECT      ON TABLE   agentic_rag.core.chunks TO `<app-sp-application-id>`;
GRANT SELECT      ON TABLE   agentic_rag.core.chunks_index TO `<app-sp-application-id>`;   -- vector index
```

Also grant **CAN QUERY** on the model serving endpoint (endpoint permissions) and declare it as an app **resource**. Least privilege: the app SP gets **read** only, and the ingestion job identity gets write.

### 7. Deploy the agentic RAG app

```python
# src/app/app.py (FastAPI or Streamlit)
from databricks.sdk import WorkspaceClient
from databricks.vector_search.client import VectorSearchClient
import os, streamlit as st

w = WorkspaceClient()
vsc = VectorSearchClient()       # uses app SP credentials from the environment
idx = vsc.get_index("rag-vs-endpoint", "agentic_rag.core.chunks_index")

def retrieve(q):
    r = idx.similarity_search(query_text=q, columns=["text", "source"], num_results=5, query_type="HYBRID")
    return r["result"]["data_array"]

def answer(q):
    ctx = "\n\n".join(f"[{s}] {t}" for t, s, *_ in retrieve(q))
    resp = w.serving_endpoints.query(name=os.environ["SERVING_ENDPOINT"], messages=[
        {"role": "system", "content": "Answer only from context and cite [source]."},
        {"role": "user", "content": f"{ctx}\n\nQ: {q}"}])
    return resp.choices[0].message.content

if q := st.chat_input("Ask"):
    st.chat_message("user").write(q)
    st.chat_message("assistant").write(answer(q))
```

```yaml
# src/app/app.yaml
command: ["streamlit", "run", "app.py", "--server.port", "8000"]
env:
  - name: SERVING_ENDPOINT
    value: databricks-meta-llama-3-3-70b-instruct    # or your AI-Gateway-governed endpoint
```

For agentic behavior, wrap retrieval as a tool in a LangGraph agent, or log the agent with MLflow (`mlflow.pyfunc` / `ResponsesAgent`) and deploy it to Model Serving, with the App calling that endpoint.

### 8. Cleanup

```bash
databricks bundle destroy -t dev        # removes bundle-managed jobs/apps
databricks bundle destroy -t prod
```

```python
vsc.delete_index("rag-vs-endpoint", "agentic_rag.core.chunks_index")
vsc.delete_endpoint("rag-vs-endpoint")        # vector endpoints bill while running!
```

```sql
DROP SCHEMA agentic_rag.core CASCADE;
DROP CATALOG agentic_rag CASCADE;
```

Then remove the federation policy and CI service principal if you no longer need them.

---

## Deep dive

- **Bundle deployment mechanics:** the CLI uploads files to the workspace (`root_path`), then creates or updates resources through the REST APIs, tracking state in `.databricks/` / remote bundle state. In recent CLI versions this is Terraform-backed under the hood, or uses direct deployment.
- **`mode: development`** prefixes resource names with your user and pauses schedules, so dev deploys don't collide. **`mode: production`** enforces `run_as` and checks.
- **Identity chain:** GitHub OIDC → CI SP (deploys) → job run_as SP (writes data) → app SP (reads data and queries models). Each identity has the minimum grants.

## Advanced

- **Promotion:** the same bundle with different targets. Use separate workspaces or catalogs per environment (`agentic_rag_dev`, `agentic_rag_prod`) for isolation.
- **Secrets:** use Databricks secret scopes (or UC connections / service credentials) for external API keys, referenced in app or job config.
- **Testing:** unit tests run locally. Integration tests run `bundle deploy -t staging` + `bundle run` + smoke queries against the app endpoint.
- **On-behalf-of-user auth** in Apps lets UC row filters apply per user, which matters for sensitive data.

## Production & scale

- Use a serverless job environment for ingestion, and TRIGGERED sync after ingestion (cheaper than CONTINUOUS for daily updates).
- Watch vector endpoint utilization and query latency, and scale the endpoint type if needed.
- Use AI Gateway rate limits and inference tables on the serving endpoint the app calls (section 31).

## FAANG insights

- **Keyless CI (OIDC)** plus **declarative deployment** (bundles/Terraform) plus **least-privilege service identities** is the modern baseline in every major cloud org. Expect interviewers to probe all three.
- *"Walk me through how a code change reaches production."* PR → validate + tests → approval on the prod environment → OIDC auth → bundle deploy → ingestion run → smoke evals → monitor.

## Interview questions

1. **Why OIDC over PATs in CI?** Short-lived, scoped, non-exportable credentials with no secret rotation burden.
2. **What does `mode: development` do in bundles?** Prefixes resources per user and pauses schedules for safe dev iterations.
3. **Which identity needs SELECT on the vector index?** The app's service principal (or the end user under on-behalf-of auth).

## Checklist

- [ ] UC catalog/schema/volume created per environment
- [ ] OIDC federation policy bound to repo + environment
- [ ] Bundle with dev/prod targets and `run_as` in prod
- [ ] Idempotent index build script
- [ ] App SP has read-only grants + endpoint CAN QUERY
- [ ] `bundle destroy` + vector endpoint deletion in cleanup
