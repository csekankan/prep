# 08 — Pydantic Logfire: OpenTelemetry-Native LLM Observability

> **One sentence:** Logfire is an observability platform from the Pydantic team, built on **OpenTelemetry**. One `logfire.configure()` plus a few `instrument_*()` calls gives you traces for FastAPI, databases, HTTP, **and** LLM calls in a single view.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Introduction to Pydantic Logfire | Basics |
| Setting up Logfire | Code §1 |
| Basics of tracing LLMs with Logfire | Code §2 |
| Tracing a simple RAG | Code §3 |
| Tracing a ReAct agent | Code §4 |
| Creating agentic workflow | Code §5 |
| Testing trace and agentic app execution | Code §6 |

---

## Basics

### Why Logfire next to LangSmith?

| | LangSmith | Logfire |
|---|-----------|---------|
| Focus | LLM app dev + evals | **Full-stack** app observability (web + DB + LLM) |
| Standard | Own SDK (+ OTel ingest) | **OpenTelemetry native** |
| Query | UI filters | **SQL** over traces |
| Best with | LangChain/LangGraph | FastAPI, Pydantic AI, OpenAI SDK, any Python |

**Analogy:** LangSmith is a **specialist doctor for the AI brain**. Logfire is the **full-body scan**: it shows the slow SQL query *and* the slow LLM call in the same trace.

---

## Code

### 1. Setup

```bash
uv add logfire
logfire auth                    # login (browser)
logfire projects new            # or `logfire projects use <name>`
# CI/prod: set LOGFIRE_TOKEN env var (write token)
```

```python
import logfire
logfire.configure(service_name="rag-api", environment="dev")
logfire.info("hello {user}", user="kunal")         # structured log
with logfire.span("doing work {step}", step=1):
    ...
```

### 2. Tracing LLM calls

```python
from openai import OpenAI
import logfire

logfire.configure()
logfire.instrument_openai()              # also: instrument_anthropic(), instrument_pydantic_ai()

client = OpenAI()
client.chat.completions.create(model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Hi"}])
# → span with model, messages, response, token usage, latency
```

### 3. Tracing a simple RAG

```python
logfire.instrument_httpx()               # embedding/vector DB HTTP calls

@logfire.instrument("retrieve {query=}")
def retrieve(query: str, k: int = 4):
    hits = qdrant.query_points("docs", query=embed(query), limit=k).points
    logfire.info("retrieved", n=len(hits), scores=[h.score for h in hits])
    return hits

@logfire.instrument("rag_answer")
def answer(q: str):
    docs = retrieve(q)
    ctx = "\n\n".join(d.payload["text"] for d in docs)
    return client.chat.completions.create(model="gpt-4o-mini",
        messages=[{"role": "system", "content": "Answer only from context."},
                  {"role": "user", "content": f"{ctx}\n\nQ: {q}"}]).choices[0].message.content
```

### 4. Tracing a ReAct agent

- **LangChain/LangGraph:** Logfire receives their OpenTelemetry spans. Use the OpenInference / OpenLLMetry instrumentors, or set `LANGSMITH_OTEL_ENABLED=true` and point the OTLP exporter at Logfire.
- **Pydantic AI** (first-class):

```python
from pydantic_ai import Agent
logfire.instrument_pydantic_ai()

agent = Agent("openai:gpt-4o-mini", system_prompt="Use tools.")

@agent.tool_plain
def get_stock(ticker: str) -> float:
    """Get stock price."""
    return 123.4

agent.run_sync("Price of AAPL?")   # spans: agent run → model request → tool call → model request
```

### 5. Agentic workflow + FastAPI

```python
from fastapi import FastAPI
app = FastAPI()
logfire.instrument_fastapi(app)
logfire.instrument_asyncpg()        # or instrument_sqlalchemy / instrument_redis

@app.post("/ask")
async def ask(q: str):
    with logfire.span("workflow", question=q):
        plan = await planner(q)
        results = [await run_step(s) for s in plan.steps]
        return await synthesize(results)
```

### 6. Testing traces

```python
from logfire.testing import CaptureLogfire

def test_rag_creates_spans(capfire: CaptureLogfire):    # pytest fixture
    answer("What is X?")
    names = [s["name"] for s in capfire.exporter.exported_spans_as_dict()]
    assert "rag_answer" in names
```

---

## Deep dive

- **OTel model:** `TracerProvider` → `Span`s with attributes → `BatchSpanProcessor` → OTLP exporter → Logfire backend. `logfire.configure()` wires all of it up.
- **Message templates:** `"retrieve {query=}"` is both a **span name template** and attribute capture. Spans group by template, which keeps cardinality low.
- **SQL explore:** traces live in a queryable store (`records` table). For example:

```sql
SELECT span_name, avg(duration) AS avg_s, count(*)
FROM records
WHERE attributes->>'gen_ai.request.model' = 'gpt-4o-mini'
GROUP BY span_name ORDER BY avg_s DESC;
```

- **Scrubbing:** Logfire auto-scrubs attributes that match patterns like `password`, `api_key`, and `token`. Extend it with `scrubbing=logfire.ScrubbingOptions(extra_patterns=[...])`.

## Advanced

- **Sampling:** `logfire.configure(sampling=logfire.SamplingOptions(head=0.1))` for head sampling. Tail sampling keeps error traces.
- **Vendor-neutral:** because everything is OTel, you can dual-export to Datadog, Jaeger, or Grafana Tempo.
- **Baggage / context propagation:** pass `tenant_id` across async tasks and services so every span is filterable.
- **Pydantic validation spans:** `logfire.instrument_pydantic()` records validation failures, which is great for spotting structured-output drift.

## Production & scale

- Use `environment=` and `service_version=` so you can compare deploys.
- Watch attribute cardinality: don't use user text as a span *name*, only as an attribute.
- Set alerts with SQL-based conditions (e.g. p95 `rag_answer` > 5 s, or error rate > 2%).

## FAANG insights

- OpenTelemetry is the **lingua franca** at large companies. LLM telemetry that speaks OTel slots into existing on-call tooling, which is the main argument for OTel-native tools.
- Interview: *"How do you trace one user request across a gateway, an agent service, a vector DB, and an LLM provider?"* Use W3C trace-context propagation, one trace ID, and spans per hop.

## Interview questions

1. **What's OpenTelemetry?** A vendor-neutral standard and SDK for traces, metrics, and logs.
2. **Span name vs attributes?** The name is a low-cardinality template, and attributes carry high-cardinality details.
3. **Why does full-stack tracing matter for RAG?** Latency often comes from the vector DB or embeddings, not the LLM.

## Checklist

- [ ] `configure()` with service name, environment, and version
- [ ] LLM + HTTP + DB + web framework instrumented
- [ ] Scrubbing patterns extended for your PII
- [ ] Trace tests with `capfire`
