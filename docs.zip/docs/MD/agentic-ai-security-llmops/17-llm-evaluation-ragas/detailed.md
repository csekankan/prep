# 17 — LLM Evaluation + RAGAS

> **One sentence:** Evaluation turns "it seems to work" into **numbers you can track**. RAGAS scores RAG pipelines on faithfulness, answer relevancy, context precision, and context recall (plus agent/tool metrics), usually with an **LLM as the judge**.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Introduction to LLM evaluation | Basics |
| RAGAS demo | (placeholder) |
| Terminologies for understanding RAGAS | Basics (vocab) |
| Understanding evaluation metrics for RAGAS | Deep dive |
| Token efficiency and experiment notebook setup | Code §1, Production |
| Faithfulness, answer relevancy, context precision | Deep dive, Code §2 |
| Context recall, answer and tool correctness | Deep dive, Code §3 |

> Sections 24 (project hardening) repeat these lectures in a project context.

---

## Basics

### Why evals?

LLM outputs are **non-deterministic and open-ended**. Unit tests with exact string matching don't work. You need:
- **Offline evals:** a fixed dataset, run before every release (regression testing).
- **Online evals:** sample production traffic and score it continuously.

### Vocabulary

| Term | Meaning |
|------|---------|
| **Sample** | One test case: `user_input`, `response`, `retrieved_contexts`, `reference` |
| **Reference / ground truth** | Ideal answer (or ideal contexts) written by a human |
| **Reference-free metric** | Doesn't need ground truth (e.g. faithfulness) |
| **LLM-as-judge** | An LLM scores outputs using a rubric |
| **Evaluator LLM** | The judge model (should be strong and ideally ≠ the generator) |
| **Experiment** | One run of your app + metrics over a dataset, versioned |

### The RAG triad (what can go wrong)

```mermaid
flowchart LR
  Q[Question] -->|context precision / recall| C[Retrieved context]
  C -->|faithfulness| A[Answer]
  Q -->|answer relevancy| A
  A -->|answer correctness| R[Reference]
```

---

## Code

### 1. Setup

```bash
uv add ragas langchain-openai datasets pandas
```

```python
from ragas import EvaluationDataset, SingleTurnSample, evaluate
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

judge = LangchainLLMWrapper(ChatOpenAI(model="gpt-4o", temperature=0))
embs = LangchainEmbeddingsWrapper(OpenAIEmbeddings(model="text-embedding-3-small"))
```

### 2. Core RAG metrics

```python
from ragas.metrics import (Faithfulness, ResponseRelevancy,
                           LLMContextPrecisionWithReference, LLMContextRecall)

samples = [SingleTurnSample(
    user_input="When was the Eiffel Tower completed?",
    retrieved_contexts=["The Eiffel Tower was completed in 1889 for the World's Fair."],
    response="It was completed in 1889.",
    reference="1889",
)]
ds = EvaluationDataset(samples=samples)

result = evaluate(ds, metrics=[Faithfulness(), ResponseRelevancy(),
                               LLMContextPrecisionWithReference(), LLMContextRecall()],
                  llm=judge, embeddings=embs)
print(result)            # {'faithfulness': 1.0, 'answer_relevancy': 0.97, ...}
df = result.to_pandas()  # per-sample scores for debugging
```

### 3. Answer correctness + tool / agent metrics

```python
from ragas.metrics import FactualCorrectness, ToolCallAccuracy, AgentGoalAccuracyWithReference
from ragas.dataset_schema import MultiTurnSample
from ragas.messages import HumanMessage, AIMessage, ToolMessage, ToolCall

sample = MultiTurnSample(
    user_input=[
        HumanMessage(content="Weather in Paris?"),
        AIMessage(content="", tool_calls=[ToolCall(name="get_weather", args={"city": "Paris"})]),
        ToolMessage(content="22C sunny"),
        AIMessage(content="It's 22°C and sunny in Paris."),
    ],
    reference_tool_calls=[ToolCall(name="get_weather", args={"city": "Paris"})],
)
await ToolCallAccuracy().multi_turn_ascore(sample)    # 1.0
```

### 4. Build a dataset from your app

```python
def build_samples(questions, refs, rag_app):
    out = []
    for q, ref in zip(questions, refs):
        res = rag_app(q)  # must return answer + contexts
        out.append(SingleTurnSample(user_input=q, response=res["answer"],
                                    retrieved_contexts=res["contexts"], reference=ref))
    return EvaluationDataset(samples=out)
```

RAGAS can also **generate synthetic test sets** from your documents (`TestsetGenerator`), which is useful for bootstrapping. Have humans review them.

---

## Deep dive: how each metric is computed

| Metric | Needs reference? | How it works | Low score means |
|--------|------------------|-------------|-----------------|
| **Faithfulness** | No | Judge splits the answer into **claims** and checks each one against the contexts. Score = supported / total | Hallucination |
| **Answer (response) relevancy** | No | Judge generates N questions from the answer, embeds them, and takes the mean cosine similarity to the real question | Off-topic or evasive answer |
| **Context precision** | Yes (or no, with the LLM variant) | Are the *relevant* chunks ranked **high**? Mean precision@k over relevant positions | Retriever/reranker ranks noise first |
| **Context recall** | Yes | Fraction of reference claims attributable to the retrieved contexts | Retriever missed needed info |
| **Factual / answer correctness** | Yes | Claim-level F1 between answer and reference (+ semantic similarity) | Wrong answer |
| **Tool call accuracy** | Yes | Compare predicted vs reference tool names + args (order-aware) | Wrong tool/args |
| **Agent goal accuracy** | Yes / No | Judge decides whether the user's goal was achieved | Agent failed task |

### Diagnosing with the triad

| Faithfulness | Context recall | Diagnosis |
|-------------|----------------|-----------|
| High | Low | Model is honest but **retrieval misses info** → fix chunking/embeddings/k |
| Low | High | Info was retrieved but **model hallucinated** → fix prompt/model, add grounding guardrail |
| Low | Low | Both broken, so start with retrieval |

## Advanced

- **Judge bias:** position bias, verbosity bias, and self-preference (GPT judging GPT). Mitigate with a different judge family, calibration against human labels, and low temperature.
- **Metric variance:** LLM judges are noisy. Use ≥100 samples for decisions, and report **confidence intervals**.
- **Non-LLM metrics** (cheap, deterministic): `NonLLMContextRecall`, BLEU/ROUGE, exact match, and string presence. Use them where they apply.
- **Custom metrics:** `AspectCritic` (binary rubric) and `RubricsScore` for domain rules ("mentions the refund policy ID").

## Production & scale

### Token efficiency

Each LLM metric makes **one or more judge calls per sample**. For example, faithfulness = 1 claim-extraction call + 1 verification call.
- 500 samples × 4 metrics × ~2 calls ≈ **4,000 judge calls** per experiment.
- Cut cost with a cheaper judge for screening (`gpt-4o-mini`), a strong judge only on disagreements, caching judge results per (sample hash, metric version), and `RunConfig(max_workers=…, timeout=…)` to control concurrency.

### Experiment hygiene

- Version **dataset + app config (prompt, model, k, chunk size) + judge model + metric version** together.
- Track experiments in LangSmith / MLflow / RAGAS experiment tracking and compare runs side by side.
- Gate deploys in CI: fail if faithfulness drops more than 3 points from baseline.

## FAANG insights

- Big teams maintain **"golden sets"** per product (hundreds to thousands of curated cases) plus **slice metrics** (by language, tenant, and query type). Averages hide regressions in small but critical slices.
- Human eval is still the gold standard. LLM judges are calibrated against it periodically (e.g. Cohen's kappa).
- Interview: *"Your RAG answers are wrong. How do you debug?"* Walk through the triad table above.

## Interview questions

1. **Faithfulness vs factual correctness?** Faithfulness means the answer is supported by the retrieved context. Factual correctness means it matches the reference. You can have faithful but wrong (bad context) or correct but unfaithful (the model knew the answer anyway).
2. **Context precision vs recall?** Precision is whether the ranking puts relevant chunks first. Recall is whether all the needed info was retrieved.
3. **How do you reduce eval cost?** Cache, use a smaller judge, sample, and run only the relevant metrics.

## Checklist

- [ ] Golden set with references, sliced by category
- [ ] Triad metrics + correctness tracked per experiment
- [ ] Judge model pinned and calibrated
- [ ] CI regression gate
