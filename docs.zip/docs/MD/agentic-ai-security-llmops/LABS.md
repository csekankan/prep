# Secure Agentic AI — Labs

Companion projects for this folder. Each lab uses **only the standard library** plus pytest, has **tests** and a **demo script**, and runs offline with no API keys. Fake LLMs and toy embeddings stand in for real models so the *mechanics* are easy to see, and each README lists exercises for swapping in real components.

## New labs for this course

| Lab | Concepts practiced | Markdown |
|-----|-------------------|----------|
| [guardrails-pipeline-lab](../mini-projects/guardrails-pipeline-lab/) | Injection detection through obfuscation, PII redact/mask/hash, topic scope, grounding, OnFailAction (exception/fix/filter/refrain/noop/reask), block rate vs false-positive rate | [04](./04-langchain-middleware-guardrails/detailed.md), [09](./09-nemo-guardrails-basics/detailed.md), [10](./10-nemo-rails-hr-bot/detailed.md), [11](./11-guardrails-ai/detailed.md), [12](./12-aws-bedrock-guardrails/detailed.md) |
| [semantic-cache-lab](../mini-projects/semantic-cache-lab/) | Exact + semantic cache, tenant scoping, TTL, index-version invalidation, safe writes, single-flight, token budgets, threshold tuning | [22](./22-redis-for-ai/detailed.md), [13](./13-llm-gateways-portkey/detailed.md), [27](./27-project-hr-hybrid-rag-gcp/detailed.md) |
| [agent-memory-lab](../mini-projects/agent-memory-lab/) | Buffer/window/token/summary memory, namespaced store, Mem0-style ADD/UPDATE/DELETE/NOOP, poisoning defenses, routing, context budgets, GDPR delete | [19](./19-agent-memory-patterns/detailed.md), [20](./20-mem0-langmem/detailed.md), [05](./05-langgraph-fundamentals/detailed.md) |
| [red-team-harness-lab](../mini-projects/red-team-harness-lab/) | PyRIT-style targets, converters, scorers; single-turn, Crescendo, XPIA attacks; ASR reports; CI gate | [21](./21-pyrit-red-teaming/detailed.md), [26](./26-project-aws-app-cicd/detailed.md), [27](./27-project-hr-hybrid-rag-gcp/detailed.md) |
| [agent-governor-lab](../mini-projects/agent-governor-lab/) | Policy-as-code, default deny, HITL approvals with separation of duties, budgets, kill switch, hash-chained audit log | [30](./30-ai-governance/detailed.md), [04](./04-langchain-middleware-guardrails/detailed.md), [01](./01-intro-genai-security-architecture/detailed.md) |

## Existing labs that also fit this course

| Lab | Concepts | Markdown |
|-----|----------|----------|
| [llm-serving-gateway-lab](../mini-projects/llm-serving-gateway-lab/) | Rate limits, circuit breaker, hedged upstream calls, trace IDs | [13](./13-llm-gateways-portkey/detailed.md)–[16](./16-meshapi-gateway/detailed.md) |
| [rag-evaluation-pipeline-lab](../mini-projects/rag-evaluation-pipeline-lab/) | Faithfulness / recall / relevance metrics, CI `--fail-under` | [17](./17-llm-evaluation-ragas/detailed.md), [18](./18-deepeval/detailed.md), [24](./24-project-gcp-hardening-evals/detailed.md) |
| [agent-tool-loop-lab](../mini-projects/agent-tool-loop-lab/) | The raw agent loop, tool dispatch | [02](./02-langchain-v1-fundamentals/detailed.md), [05](./05-langgraph-fundamentals/detailed.md) |
| [rate-limiter-lab](../mini-projects/rate-limiter-lab/) | Token bucket, sliding window | [22](./22-redis-for-ai/detailed.md) |
| [bm25-search-lab](../mini-projects/bm25-search-lab/), [vector-retrieval-lab](../mini-projects/vector-retrieval-lab/) | Sparse + dense retrieval (the parts of hybrid RAG) | [23](./23-project-gcp-agentic-rag/detailed.md), [27](./27-project-hr-hybrid-rag-gcp/detailed.md) |

## Suggested order

```mermaid
flowchart LR
  G[guardrails-pipeline-lab] --> R[red-team-harness-lab]
  R -->|attack your own guards| G
  G --> GOV[agent-governor-lab]
  C[semantic-cache-lab] --> M[agent-memory-lab]
  M --> GOV
```

Build the guardrails first, then try to break them with the red-team harness. Successful attacks become regression tests for the guardrails.

## Smoke all labs

```bash
cd MD/mini-projects
for d in guardrails-pipeline-lab semantic-cache-lab agent-memory-lab red-team-harness-lab agent-governor-lab; do
  echo "=== $d ==="
  (cd "$d" && pip install -q -e ".[dev]" && pytest -q && python scripts/demo.py > /dev/null) || exit 1
done
```
