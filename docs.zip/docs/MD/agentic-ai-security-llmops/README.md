# Secure Agentic AI, LLMOps & Production GenAI — Course Notes

> **One sentence:** How to build agentic AI apps (LangChain, LangGraph, Deep Agents, Claude Code) and make them **safe** (guardrails, red teaming, governance), **observable** (LangSmith, Logfire), **cheap and reliable** (gateways, caching, memory), **measurable** (RAGAS, DeepEval), and **deployable** (GCP, AWS + Terraform, Databricks).

Course size: **32 sections • 279 lectures • 83h 10m**. Every section folder has a **`detailed.md`** with the same layout:

| Section | What you get |
|---------|--------------|
| **Lecture map** | The lectures that section covers |
| **Basics** | The idea in plain English, with an analogy |
| **Code** | Small runnable snippets you can copy |
| **Deep dive** | How it works under the hood |
| **Advanced** | Edge cases, tradeoffs, design choices |
| **Production & scale** | Latency, cost, SLOs, failure modes |
| **FAANG insights** | How big teams actually do it, plus interview angles |
| **Interview questions** | Practice questions with short answers |
| **Checklist** | What to verify before you ship |

> **Version note:** These libraries move fast (LangChain v1, LangGraph 1.x, PyRIT, Deep Agents, TensorZero). The snippets target late-2025/2026 APIs. If an import fails, check the library's changelog first. The **concepts** stay stable even when the API names change.

**Hands-on labs:** see **[LABS.md](./LABS.md)** for five offline, tested Python labs (guardrails, semantic caching, agent memory, red teaming, governance) plus existing labs that fit this course.

---

## Sections

### Part A — Foundations
| # | Section | Folder |
|---|---------|--------|
| 01 | Course intro, GenAI security, agentic architecture | [01-intro-genai-security-architecture](./01-intro-genai-security-architecture/detailed.md) |
| 02 | LangChain v1 fundamentals (uv, agents, models, streaming, tools, messages) | [02-langchain-v1-fundamentals](./02-langchain-v1-fundamentals/detailed.md) |
| 03 | Structured output: Pydantic, TypedDict, dataclass | [03-langchain-structured-output](./03-langchain-structured-output/detailed.md) |
| 04 | LangChain middleware: summarization, HITL, guardrails | [04-langchain-middleware-guardrails](./04-langchain-middleware-guardrails/detailed.md) |
| 05 | LangGraph fundamentals: chatbot, ReAct, memory, HITL | [05-langgraph-fundamentals](./05-langgraph-fundamentals/detailed.md) |
| 06 | LangGraph advanced: LangSmith debugging, multi-agent, MCP | [06-langgraph-multiagent-mcp](./06-langgraph-multiagent-mcp/detailed.md) |

### Part B — Observability
| # | Section | Folder |
|---|---------|--------|
| 07 | Observability + LangSmith + LangGraph Studio | [07-observability-langsmith](./07-observability-langsmith/detailed.md) |
| 08 | Pydantic Logfire | [08-pydantic-logfire](./08-pydantic-logfire/detailed.md) |

### Part C — Guardrails
| # | Section | Folder |
|---|---------|--------|
| 09 | Guardrail landscape + NeMo Guardrails basics | [09-nemo-guardrails-basics](./09-nemo-guardrails-basics/detailed.md) |
| 10 | NeMo input/output rails, PII, secured HR bot | [10-nemo-rails-hr-bot](./10-nemo-rails-hr-bot/detailed.md) |
| 11 | Guardrails AI (Hub, validators, OnFailAction, streaming) | [11-guardrails-ai](./11-guardrails-ai/detailed.md) |
| 12 | AWS Bedrock Guardrails (M1–M5) | [12-aws-bedrock-guardrails](./12-aws-bedrock-guardrails/detailed.md) |

### Part D — LLM Gateways
| # | Section | Folder |
|---|---------|--------|
| 13 | Gateway concepts + Portkey | [13-llm-gateways-portkey](./13-llm-gateways-portkey/detailed.md) |
| 14 | TensorZero (M1–M5) | [14-tensorzero](./14-tensorzero/detailed.md) |
| 15 | Bifrost gateway + mini RAG with Qdrant | [15-bifrost-gateway](./15-bifrost-gateway/detailed.md) |
| 16 | MeshAPI gateway | [16-meshapi-gateway](./16-meshapi-gateway/detailed.md) |

### Part E — Evaluation
| # | Section | Folder |
|---|---------|--------|
| 17 | LLM evaluation + RAGAS | [17-llm-evaluation-ragas](./17-llm-evaluation-ragas/detailed.md) |
| 18 | DeepEval: G-Eval, DAG, QAG, RAG and agent evals | [18-deepeval](./18-deepeval/detailed.md) |

### Part F — Memory & Caching
| # | Section | Folder |
|---|---------|--------|
| 19 | Memory patterns for agents | [19-agent-memory-patterns](./19-agent-memory-patterns/detailed.md) |
| 20 | Mem0 and LangMem | [20-mem0-langmem](./20-mem0-langmem/detailed.md) |
| 22 | Redis for AI: caching, memory, rate limiting | [22-redis-for-ai](./22-redis-for-ai/detailed.md) |

### Part G — Red Teaming
| # | Section | Folder |
|---|---------|--------|
| 21 | PyRIT red teaming (12 modules) | [21-pyrit-red-teaming](./21-pyrit-red-teaming/detailed.md) |

### Part H — End-to-End Projects
| # | Section | Folder |
|---|---------|--------|
| 23 | Project 1: Agentic RAG on GCP (Qdrant, FlashRank, Cloud Run) | [23-project-gcp-agentic-rag](./23-project-gcp-agentic-rag/detailed.md) |
| 24 | Project 1 hardening: guardrails, gateways, evals | [24-project-gcp-hardening-evals](./24-project-gcp-hardening-evals/detailed.md) |
| 25 | Project 2 (part 1): AWS architecture + Terraform | [25-project-aws-terraform-infra](./25-project-aws-terraform-infra/detailed.md) |
| 26 | Project 2 (part 2): production app, CI/CD, red-team dashboard | [26-project-aws-app-cicd](./26-project-aws-app-cicd/detailed.md) |
| 27 | Project 3: Secure HR hybrid RAG on GCP (Model Armor) | [27-project-hr-hybrid-rag-gcp](./27-project-hr-hybrid-rag-gcp/detailed.md) |

### Part I — Agentic Coding & Frameworks
| # | Section | Folder |
|---|---------|--------|
| 28 | Claude Code: agents, teams, hooks, skills, plugins | [28-claude-code](./28-claude-code/detailed.md) |
| 29 | Deep Agents: backends, context engineering, subagents | [29-deep-agents](./29-deep-agents/detailed.md) |

### Part J — Governance & Enterprise Platforms
| # | Section | Folder |
|---|---------|--------|
| 30 | AI Governance + Sentience Governor | [30-ai-governance](./30-ai-governance/detailed.md) |
| 31 | Databricks for agentic AI: Delta Lake, Unity Catalog, Vector Search, AI Gateway | [31-databricks-agentic-concepts](./31-databricks-agentic-concepts/detailed.md) |
| 32 | Databricks deployment: OIDC, Asset Bundles, CI/CD, Apps | [32-databricks-deployment](./32-databricks-deployment/detailed.md) |

---

## Suggested learning path

```mermaid
flowchart TD
  A[01 Security + architecture] --> B[02-04 LangChain v1]
  B --> C[05-06 LangGraph]
  C --> D[07-08 Observability]
  D --> E[09-12 Guardrails]
  E --> F[13-16 Gateways]
  F --> G[17-18 Evaluation]
  G --> H[19-20, 22 Memory + Redis]
  E --> R[21 PyRIT red teaming]
  H --> P1[23-24 GCP project]
  R --> P2[25-26 AWS project]
  P1 --> P3[27 HR hybrid RAG]
  C --> CC[28-29 Claude Code + Deep Agents]
  E --> GOV[30 Governance]
  P3 --> DB[31-32 Databricks]
```

## The one diagram to remember

Most sections slot into one place in a production agent's request path:

```mermaid
flowchart LR
  U[User] --> IG[Input guardrails<br/>09-12, 27]
  IG --> CACHE{Cache hit?<br/>22}
  CACHE -- yes --> U
  CACHE -- no --> AG[Agent / graph<br/>02-06, 29]
  AG <--> MEM[Memory<br/>19-20]
  AG <--> TOOLS[Tools / MCP / RAG<br/>06, 23]
  AG --> GW[LLM gateway<br/>13-16]
  GW --> LLM[(Providers)]
  AG --> OG[Output guardrails]
  OG --> U
  AG -.traces.-> OBS[Observability<br/>07-08]
  OBS -.datasets.-> EV[Evals<br/>17-18]
  RT[Red team<br/>21] -.attacks.-> IG
  GOVN[Governance<br/>30] -.policy.-> AG
```

## Notes on the source outline

- A few lectures appear twice in the outline: "Introduction to Portkey and project setup", "What is memory and why its needed", and "Mem0 Quick start Explained" (the last two also show up inside the PyRIT list). Each is covered once, in its natural section.
- "RAGAS DEMO" and "MEMORY DEMO" are 4-second placeholders, so they have no dedicated content.

## Related docs in this repo

- [../llm-ops/llm-ops-production.md](../llm-ops/llm-ops-production.md)
- [../observability/](../observability/)
- [../caching-and-performance/](../caching-and-performance/)
- [../FAANG_INSIDER_KNOWLEDGE.md](../FAANG_INSIDER_KNOWLEDGE.md)
