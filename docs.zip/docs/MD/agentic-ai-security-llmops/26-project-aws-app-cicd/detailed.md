# 26 — Project 2 (Part 2): Production App Code, Multi-Agent System, CI/CD, Deployment

> **One sentence:** Write the **application layer** for the AWS platform (config, retries, DB pooling, auth, guardrails, caching, memory, queueing, a multi-agent system, LangSmith evals, a TensorZero gateway, and a PyRIT red-team dashboard), then ship it with **GitHub Actions CI/CD** and test it end to end.

## Lecture map

| # | Lecture | Covered in |
|---|---------|-----------|
| 08 | App requirements and configuration | Code §1 |
| 09 | Retry logic and database connection pool | Code §2 |
| 10 | Authentication, guardrails and caching | Code §3 |
| 11 | Memory and queueing | Code §4 |
| 12 | Multi-agent AI system | Code §5 |
| 13 | LLM evaluation using LangSmith and output formats | Code §6 |
| 14 | FastAPI main code and Dockerfile | Code §7 |
| 15 | TensorZero configuration | Code §8 |
| 16 | PyRIT red-teaming dashboard | Code §9 |
| 17 | Frontend code and GitHub configuration | Code §10 |
| 18 | GitHub Actions CI/CD | Code §10 |
| 19 | Full deployment of the project | Code §11 |
| 20 | Full testing of the project | Code §12 |
| 21 | How to make this project better? | Advanced |

---

## Basics

Request lifecycle for one chat message:

```mermaid
sequenceDiagram
  participant FE as Frontend
  participant API as FastAPI
  participant A as Auth
  participant G as Guardrails
  participant C as Redis
  participant MA as Multi-agent
  participant T0 as TensorZero
  participant DB as Postgres
  FE->>API: POST /chat (JWT)
  API->>A: verify JWT, rate limit
  API->>G: input rails
  API->>C: semantic cache?
  alt miss
    API->>MA: run supervisor graph
    MA->>T0: LLM calls (fallback, A/B)
    MA->>DB: memory + results
    API->>G: output rails
    API->>C: store
  end
  API-->>FE: streamed answer
```

---

## Code

### 1. Config (typed, env-driven)

```python
# app/config.py
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    env: str = "dev"
    database_url: str
    redis_url: str
    sqs_url: str | None = None
    gateway_url: str = "http://tensorzero:3000"
    jwt_secret: str
    jwt_alg: str = "HS256"
    rate_limit_per_min: int = 30
    langsmith_project: str = "agentic-prod"

settings = Settings()
```

### 2. Retries + DB connection pool

```python
from tenacity import retry, stop_after_attempt, wait_exponential_jitter, retry_if_exception_type
import httpx
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker

@retry(stop=stop_after_attempt(3), wait=wait_exponential_jitter(initial=0.5, max=8),
       retry=retry_if_exception_type((httpx.TimeoutException, httpx.HTTPStatusError)))
async def call_tool_api(client: httpx.AsyncClient, url: str, payload: dict):
    r = await client.post(url, json=payload, timeout=10)
    r.raise_for_status()
    return r.json()

engine = create_async_engine(settings.database_url, pool_size=10, max_overflow=20,
                             pool_pre_ping=True, pool_recycle=1800)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
```

Pool sizing: `pool_size × tasks ≤ RDS max_connections`. With many ECS tasks, use **RDS Proxy** / PgBouncer.

### 3. Auth + guardrails + caching

```python
from fastapi import Depends, HTTPException, Header
import jwt

async def current_user(authorization: str = Header(...)):
    try:
        token = authorization.removeprefix("Bearer ")
        claims = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_alg])
        return {"id": claims["sub"], "tenant": claims["tenant"], "role": claims.get("role", "user")}
    except jwt.PyJWTError:
        raise HTTPException(401, "invalid token")

async def guarded(user, text):
    if not sliding_window(user["id"], settings.rate_limit_per_min):   # Redis (section 22)
        raise HTTPException(429, "rate limited")
    try:
        return input_guard.validate(text).validated_output             # Guardrails AI (section 11)
    except Exception:
        raise HTTPException(400, "request blocked by policy")
```

In production, prefer **Cognito / Auth0 / OIDC** with RS256 and JWKS rotation over shared HS256 secrets.

### 4. Memory + queueing

```python
import boto3, json, uuid
sqs = boto3.client("sqs")

async def enqueue_job(user, task):
    job_id = str(uuid.uuid4())
    await save_job(job_id, user["id"], status="queued")
    sqs.send_message(QueueUrl=settings.sqs_url,
                     MessageBody=json.dumps({"job_id": job_id, "user": user, "task": task}),
                     MessageGroupId=user["id"] if settings.sqs_url.endswith(".fifo") else None)
    return job_id

# worker.py: long-poll, process, ack only on success
while True:
    msgs = sqs.receive_message(QueueUrl=URL, MaxNumberOfMessages=5, WaitTimeSeconds=20)
    for m in msgs.get("Messages", []):
        body = json.loads(m["Body"])
        if already_done(body["job_id"]):            # idempotency
            sqs.delete_message(QueueUrl=URL, ReceiptHandle=m["ReceiptHandle"]); continue
        run_multi_agent(body)
        sqs.delete_message(QueueUrl=URL, ReceiptHandle=m["ReceiptHandle"])
```

Memory: short-term in Redis (session window) and long-term in Postgres/pgvector (facts per user), as in sections 19–20.

### 5. Multi-agent system

```python
from langchain.agents import create_agent
from langgraph.graph import StateGraph, MessagesState, START
from langgraph.types import Command

research = create_agent(gw_llm("research"), tools=[web_search, kb_search], system_prompt=RESEARCH_PROMPT)
analyst  = create_agent(gw_llm("analyst"),  tools=[sql_readonly, python_sandbox], system_prompt=ANALYST_PROMPT)
writer   = create_agent(gw_llm("writer"),   tools=[], system_prompt=WRITER_PROMPT)

class Route(BaseModel):
    next: Literal["research", "analyst", "writer", "FINISH"]

def supervisor(state: MessagesState) -> Command:
    r = gw_llm("router").with_structured_output(Route).invoke(state["messages"])
    return Command(goto="__end__" if r.next == "FINISH" else r.next)

def wrap(agent, name):
    def node(state):
        out = agent.invoke(state)
        return Command(goto="supervisor", update={"messages": [out["messages"][-1]]})
    return node

g = StateGraph(MessagesState)
g.add_node("supervisor", supervisor)
for n, a in [("research", research), ("analyst", analyst), ("writer", writer)]:
    g.add_node(n, wrap(a, n))
g.add_edge(START, "supervisor")
mas = g.compile(checkpointer=postgres_saver)
```

### 6. LangSmith evaluation + output formats

```python
from langsmith import Client, evaluate
ls = Client()
ds = ls.create_dataset("agentic-goldens")
ls.create_examples(dataset_id=ds.id,
    inputs=[{"q": "Summarize Q3 revenue drivers"}], outputs=[{"must_include": ["revenue", "Q3"]}])

def contains_keywords(run, example):
    out = run.outputs["answer"].lower()
    ok = all(k in out for k in example.outputs["must_include"])
    return {"key": "keywords", "score": int(ok)}

def is_valid_json(run, example):
    try: json.loads(run.outputs["answer"]); return {"key": "json_format", "score": 1}
    except Exception: return {"key": "json_format", "score": 0}

evaluate(lambda x: {"answer": run_app(x["q"])}, data="agentic-goldens",
         evaluators=[contains_keywords, is_valid_json], experiment_prefix="mas-v3")
```

Output formats: markdown for UI, JSON (Pydantic) for API consumers, with streaming SSE for chat.

### 7. FastAPI main + Dockerfile

```python
# app/main.py
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app):
    await init_db(); yield; await engine.dispose()

app = FastAPI(lifespan=lifespan)

@app.post("/chat")
async def chat(req: ChatReq, user=Depends(current_user)):
    text = await guarded(user, req.message)
    if (hit := scache.check(prompt=text)): return {"answer": hit[0]["response"], "cached": True}
    async def gen():
        async for ev in mas.astream({"messages": [("user", text)]},
                                    {"configurable": {"thread_id": f"{user['id']}:{req.session}"}},
                                    stream_mode="messages"):
            yield f"data: {json.dumps({'t': ev[0].content})}\n\n"
    return StreamingResponse(gen(), media_type="text/event-stream")

@app.post("/jobs")
async def jobs(req: JobReq, user=Depends(current_user)):
    return {"job_id": await enqueue_job(user, req.task)}

@app.get("/healthz")
async def health(): return {"ok": True}
```

```dockerfile
FROM python:3.12-slim AS base
RUN useradd -m app
WORKDIR /app
COPY --from=ghcr.io/astral-sh/uv:latest /uv /usr/local/bin/uv
COPY pyproject.toml uv.lock ./
RUN uv sync --frozen --no-dev
COPY app ./app
USER app
EXPOSE 8000
HEALTHCHECK CMD python -c "import urllib.request;urllib.request.urlopen('http://localhost:8000/healthz')"
CMD ["uv", "run", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "2"]
```

### 8. TensorZero configuration

```toml
[models.router]
routing = ["openai", "bedrock"]
[models.router.providers.openai]
type = "openai"
model_name = "gpt-4o-mini"
[models.router.providers.bedrock]
type = "aws_bedrock"
model_id = "anthropic.claude-3-5-haiku-20241022-v1:0"
region = "us-east-1"

[functions.writer]
type = "chat"
[functions.writer.variants.sonnet]
type = "chat_completion"
model = "anthropic::claude-sonnet-4-5"
weight = 0.8
[functions.writer.variants.gpt4o]
type = "chat_completion"
model = "openai::gpt-4o"
weight = 0.2
```

### 9. PyRIT red-team dashboard

A separate ECS service (Streamlit/FastAPI) that runs PyRIT suites (section 21) against the **staging** `/chat` endpoint through `HTTPTarget`, stores results, and charts ASR by attack type and release. It's protected by admin auth and never exposed publicly.

### 10. Frontend + GitHub Actions CI/CD

```yaml
# .github/workflows/deploy.yml
name: ci-cd
on: { push: { branches: [main] }, pull_request: {} }
permissions: { id-token: write, contents: read }
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v5
      - run: uv sync --frozen && uv run ruff check . && uv run pytest -q
      - run: uv run python -m evals.run --suite smoke        # eval gate
  deploy:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with: { role-to-assume: "${{ secrets.AWS_DEPLOY_ROLE }}", aws-region: us-east-1 }   # OIDC, no keys
      - uses: aws-actions/amazon-ecr-login@v2
        id: ecr
      - run: |
          IMG=${{ steps.ecr.outputs.registry }}/agentic-api:${{ github.sha }}
          docker build -t $IMG . && docker push $IMG
          echo "IMG=$IMG" >> $GITHUB_ENV
      - run: |
          cd infra && terraform init && terraform apply -auto-approve -var image_tag=${{ github.sha }} -var env=prod
```

Frontend: a React/Next.js app built in CI, uploaded to S3, and served through CloudFront (invalidate on deploy).

### 11. Full deployment

1. `terraform apply` (base infra).
2. Push the image to ECR, then update the ECS service (new task definition revision → rolling deploy).
3. Run DB migrations (Alembic) as a one-off ECS task.
4. Seed goldens, then run the smoke eval + PyRIT smoke suite against prod.

### 12. Full testing

| Layer | Test |
|-------|------|
| Unit | Tools, guards, config parsing |
| Integration | API + Postgres + Redis (docker-compose / testcontainers) |
| Eval | Goldens through the full graph (LangSmith experiment) |
| Security | PyRIT suite, auth bypass attempts, rate limit |
| Load | Locust/k6: p95 latency, error rate, autoscaling behavior |
| Chaos | Kill a provider (gateway fallback), kill a task (ECS reschedules), Redis down (degrade gracefully) |

---

## Advanced — how to make this project better

- **Blue/green or canary deploys** with CodeDeploy + ALB weighted target groups.
- **Bedrock Guardrails** as an extra managed layer, with IAM-enforced guardrail usage.
- **OpenTelemetry** to CloudWatch/X-Ray alongside LangSmith.
- **Per-tenant encryption keys** (KMS) and data partitioning.
- **Prompt registry** + TensorZero feedback-driven variant optimization.
- **Cost guardrails:** per-tenant token budgets and model downgrade when over budget.

## Production & scale

- ECS autoscaling on ALB request count per target. Scale workers on SQS `ApproximateNumberOfMessagesVisible`.
- RDS Proxy for connection storms, and Redis cluster mode when memory exceeds a single node.
- SLOs: chat p95 TTFT < 2 s, availability 99.9%, eval scores ≥ baseline.

## FAANG insights

- The interview version of this project is *"Design ChatGPT Enterprise for 10k companies."* Cover tenancy, auth/SSO, data isolation, gateway, async jobs, memory, safety, evals, cost controls, and observability, plus **deployment safety** (canary + eval gate).
- **OIDC from CI to the cloud (no static keys)** is the expected security baseline.

## Interview questions

1. **Why put retries in the gateway and not the app?** One layer avoids amplification, and the policy is centralized.
2. **How do you make SQS processing safe?** Idempotency keys, visibility timeout longer than processing time, a DLQ, and deleting only on success.
3. **What runs in CI before deploy?** Lint, unit tests, a security scan, the eval smoke suite, and a Terraform plan.

## Checklist

- [ ] Typed settings, no secrets in the image
- [ ] Retries + jitter, pooled DB, RDS Proxy at scale
- [ ] JWT/OIDC auth, rate limits, guardrails, tenant-scoped cache
- [ ] Async jobs with idempotency + DLQ
- [ ] CI: tests + eval gate + OIDC deploy
- [ ] PyRIT suite against staging
