# 28 — Claude Code: Ecosystem, Agents, Agent Teams, Hooks, Skills & Plugins

> **One sentence:** Claude Code is Anthropic's **agentic coding tool** that runs in your terminal or IDE. It reads your repo, edits files, runs commands, and can be extended with **subagents** (specialists), **hooks** (deterministic scripts on lifecycle events), **skills** (on-demand instruction packs), **MCP servers**, and **plugins** that bundle all of these.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Claude ecosystem | Basics |
| Claude Code working | Deep dive |
| Agents with Claude Code | Code §2 |
| Agent views in Claude Code | Code §3 |
| Agent teams in Claude Code | Code §4 |
| Hooks in Claude Code | Code §5 |
| Skills and plugins | Code §6–§7 |

---

## Basics

### The Claude ecosystem

| Surface | What it is |
|---------|-----------|
| **Claude.ai / apps** | Chat product (Projects, Artifacts, connectors) |
| **Claude API** | Messages API, tool use, prompt caching, batch, files |
| **Claude Code** | Agentic coding CLI + IDE extensions + web/background agents |
| **Claude Agent SDK** | The harness behind Claude Code, as a library for your own agents (Python/TS) |
| **MCP** | Open protocol for tools/data that Claude (and others) connect to |
| **Models** | Opus (most capable), Sonnet (balanced), Haiku (fast/cheap) |

### Extension points

| Feature | Where | When it runs | Use for |
|---------|-------|--------------|---------|
| `CLAUDE.md` | Repo root / `~/.claude/` | Always loaded into context | Project conventions, commands |
| **Slash commands** | `.claude/commands/*.md` | When you type `/name` | Reusable prompts |
| **Subagents** | `.claude/agents/*.md` | When Claude delegates | Isolated specialist contexts |
| **Skills** | `.claude/skills/<name>/SKILL.md` | Loaded **on demand** when relevant | Procedures + scripts + assets |
| **Hooks** | `settings.json` | On lifecycle events, **deterministically** | Guardrails, formatting, logging |
| **MCP servers** | `.mcp.json` | Tools available to the agent | External systems |
| **Plugins** | Marketplace / repo | Install bundles of the above | Sharing across teams |

---

## Code

### 1. Basics

```bash
npm install -g @anthropic-ai/claude-code    # or the native installer
cd my-repo && claude                         # interactive
claude -p "explain src/auth.py"              # headless / one-shot (CI friendly)
/init                                        # generate CLAUDE.md
/agents  /hooks  /mcp  /permissions  /plugin # manage extensions
```

```markdown
<!-- CLAUDE.md -->
# Project
- Python 3.12, uv. Run tests: `uv run pytest -q`
- Never edit files under `migrations/` by hand
- Use Pydantic v2 models for all API schemas
```

### 2. Subagents

```markdown
<!-- .claude/agents/security-reviewer.md -->
---
name: security-reviewer
description: Reviews code changes for security issues. Use proactively after edits to auth, API, or SQL code.
tools: Read, Grep, Glob, Bash
model: sonnet
---
You are a senior application security engineer.
Check for: injection (SQL/command/prompt), authz gaps, secrets in code, unsafe deserialization,
SSRF, missing input validation. Output a prioritized list with file:line and a fix.
```

Each subagent has its **own context window**, a restricted tool list, and an optional model. The main agent delegates, either automatically (based on `description`) or when you ask ("use the security-reviewer agent").

### 3. Agent views

- `/agents` opens a UI to create, edit, and list project-level and user-level agents.
- During a run you see **subagent activity** (which agent is working, its tool calls, and its summary).
- Background tasks / agent views let you monitor several running agents and switch between them. The exact UI changes between versions, so check `claude --help` and `/help`.

### 4. Agent teams

Agent teams let **multiple Claude Code instances coordinate**: a lead agent splits the work and teammates execute in parallel with a shared task list and messaging.

- Typical setup: one lead (planner/reviewer) plus teammates for frontend, backend, and tests.
- Best for **parallelizable work** (multiple modules, research + implementation).
- Costs scale with the number of agents. Each teammate is a full session.
- This feature is newer or experimental and may need enabling in settings, so check the current docs.

### 5. Hooks

```json
// .claude/settings.json
{
  "hooks": {
    "PreToolUse": [{
      "matcher": "Bash",
      "hooks": [{ "type": "command", "command": "python3 .claude/hooks/block_dangerous.py" }]
    }],
    "PostToolUse": [{
      "matcher": "Edit|Write",
      "hooks": [{ "type": "command", "command": "uv run ruff format \"$CLAUDE_PROJECT_DIR\" -q" }]
    }],
    "UserPromptSubmit": [{
      "hooks": [{ "type": "command", "command": "python3 .claude/hooks/scan_prompt_for_secrets.py" }]
    }],
    "Stop": [{
      "hooks": [{ "type": "command", "command": "uv run pytest -q || echo 'tests failing' >&2" }]
    }]
  }
}
```

```python
# .claude/hooks/block_dangerous.py
import json, sys, re
event = json.load(sys.stdin)                       # hook receives JSON on stdin
cmd = event.get("tool_input", {}).get("command", "")
if re.search(r"rm\s+-rf\s+/|curl .*\|\s*sh|git push --force", cmd):
    print("Blocked dangerous command by policy", file=sys.stderr)
    sys.exit(2)                                    # exit 2 = block; stderr fed back to Claude
sys.exit(0)
```

Hook events include `PreToolUse`, `PostToolUse`, `UserPromptSubmit`, `Notification`, `Stop`, `SubagentStop`, `PreCompact`, `SessionStart`, and `SessionEnd`. Hooks can also return JSON to allow, deny, or ask, and to add context.

### 6. Skills

```
.claude/skills/release-notes/
├── SKILL.md
├── template.md
└── scripts/collect_commits.sh
```

```markdown
---
name: release-notes
description: Generate release notes from git history. Use when the user asks for a changelog or release notes.
---
1. Run `scripts/collect_commits.sh <from_tag> <to_tag>`.
2. Group commits by type (feat, fix, perf, docs).
3. Fill `template.md`. Keep each bullet under 20 words.
```

**Progressive disclosure:** only the `name` and `description` sit in context until the skill is relevant. Then Claude reads `SKILL.md`, and supporting files are loaded only if needed, which keeps context small.

### 7. Plugins

A plugin bundles commands, agents, skills, hooks, and MCP servers:

```
my-plugin/
├── .claude-plugin/plugin.json
├── commands/  agents/  skills/  hooks/hooks.json  .mcp.json
```

Install with `/plugin marketplace add <org/repo>` → `/plugin install <name>`. Teams share standard tooling (e.g. "company security plugin") this way.

---

## Deep dive: how Claude Code works

```mermaid
flowchart LR
  U[You] --> L[Agent loop]
  L --> M[Claude model]
  M -->|tool_use| T{Permission check<br/>+ PreToolUse hooks}
  T -->|allowed| X[Tools: Read, Edit, Write, Bash, Grep, Glob, WebFetch, Task, MCP]
  X --> P[PostToolUse hooks]
  P --> L
  M -->|done| S[Stop hooks] --> U
  L --> C[Context mgmt: CLAUDE.md, compaction, subagents]
```

- **Agentic search:** Claude explores the repo with Grep/Glob/Read (like a developer) rather than relying only on a pre-built vector index.
- **Permissions:** `allow` / `ask` / `deny` rules per tool and pattern (e.g. `Bash(npm test:*)`), plus modes (default, plan, accept-edits, bypass, which is dangerous).
- **Context compaction:** long sessions are summarized automatically (`/compact`). Subagents keep the main context clean.
- **Headless mode:** `claude -p ... --output-format json` for CI bots (PR review, issue triage).

## Advanced

- **Security:** treat repo content as untrusted. A malicious README or dependency can contain prompt injections. Use deny rules for network and secrets paths, PreToolUse hooks for dangerous commands, and containers or devcontainers for untrusted code.
- **Hooks are deterministic, prompts aren't.** Anything that *must* happen (formatting, blocking `.env` reads, running tests) belongs in a hook.
- **Skills vs subagents:** a skill is *knowledge and procedure* loaded into the current agent. A subagent is a *separate worker* with its own context.

## Production & scale

- Commit `.claude/` (agents, skills, settings) to share team conventions, and keep personal settings in `settings.local.json`.
- Use the Claude Agent SDK / headless mode in GitHub Actions for automated PR reviews, and cap turns and cost.
- Track usage and cost per developer or team (admin console / OpenTelemetry export).

## FAANG insights

- Large engineering orgs standardize AI coding tools with **org-managed policies** (managed settings), approved MCP servers, and hooks that enforce compliance (no secrets, license checks).
- Interview: *"How would you safely let an AI agent run shell commands in CI?"* Use an ephemeral container, least-privilege tokens, an allow-listed command set (hooks/permissions), network egress limits, and logging.

## Interview questions

1. **Hook vs skill vs subagent?** Deterministic script on an event vs on-demand instructions vs an isolated specialist agent.
2. **How does a PreToolUse hook block an action?** Exit code 2 (or a JSON deny decision). Its stderr is shown to Claude.
3. **Why do subagents help with long tasks?** Separate context windows avoid context pollution and overflow.

## Checklist

- [ ] `CLAUDE.md` with commands + conventions
- [ ] Security hooks (dangerous Bash, secret files)
- [ ] Specialist subagents with minimal tools
- [ ] Skills for repeatable procedures
- [ ] Permissions deny-list for sensitive paths
