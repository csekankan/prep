# 30 — AI Governance + Sentience Governor with LangChain Agents

> **One sentence:** AI governance is the **policies, controls, and evidence** that make AI systems lawful, safe, and accountable. In code it shows up as a **governor layer** that watches every agent step (LLM calls, tool calls), enforces policy (allow, deny, require approval), and writes an audit trail. The course implements this with Sentience Governor through LangChain callbacks.

> **Accuracy note:** "Sentience Governor" is a niche/newer tool. The code below shows the **governor pattern** with LangChain's real callback and middleware APIs. Map the class and method names to the Sentience Governor SDK version used in the course.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Why AI governance is important? | Basics |
| What is AI governance? | Basics, Deep dive |
| Sentience Governor explained | Deep dive |
| Introduction to implementation of Sentience Governor with LangChain agents | Code §1 |
| Implementation of Sentience Governor with LangChain agents using callbacks | Code §2–§3 |
| Adding guardrails with Sentience Governor in LangChain agents | Code §4 |

---

## Basics

### Why it matters

- **Regulation:** EU AI Act (risk tiers, obligations for high-risk and general-purpose AI), plus sector rules (HIPAA, GDPR, financial model-risk rules like SR 11-7).
- **Liability:** agents take actions. "The AI did it" isn't a legal defense.
- **Trust:** enterprises won't adopt agents without audit trails and controls.
- **Incidents:** data leaks, biased decisions, runaway spending, unauthorized actions.

### What AI governance covers

| Pillar | Questions | Artifacts |
|--------|-----------|-----------|
| **Inventory** | What AI systems/models/agents do we run? | AI registry, model cards |
| **Risk assessment** | What can go wrong and how bad is it? | Risk tiering, impact assessments |
| **Policy** | What's allowed? | Acceptable-use policy, tool permission matrix |
| **Controls** | How do we enforce it? | Guardrails, IAM, HITL, budgets |
| **Monitoring** | Is it working? | Traces, eval dashboards, alerts |
| **Accountability** | Who owns it, and what happened? | Owners, audit logs, incident process |

Frameworks: **NIST AI RMF** (Govern, Map, Measure, Manage), **ISO/IEC 42001** (AI management system), **EU AI Act**, and **OWASP LLM Top 10** (technical risks).

---

## Code

### 1. The governor pattern

```mermaid
flowchart LR
  A[Agent] -->|on_llm_start / on_tool_start| G[Governor]
  G --> P{Policy engine}
  P -->|allow| A
  P -->|deny| X[Raise / block]
  P -->|require_approval| H[Human approval]
  G --> AU[(Audit log)]
  G --> M[Metrics: cost, violations]
```

### 2. Governor via LangChain callbacks

```python
import time, json, uuid
from langchain_core.callbacks import BaseCallbackHandler

class PolicyViolation(Exception): ...

POLICY = {
    "allowed_tools": {"search_kb", "get_order", "create_ticket"},
    "approval_required": {"issue_refund"},
    "max_llm_calls": 15,
    "max_cost_usd": 0.50,
    "blocked_patterns": ["ssn", "password"],
}

class Governor(BaseCallbackHandler):
    raise_error = True                       # make exceptions stop the run

    def __init__(self, user_id, audit_sink):
        self.user_id, self.audit = user_id, audit_sink
        self.llm_calls, self.cost, self.run_id = 0, 0.0, str(uuid.uuid4())

    def _log(self, event, **data):
        self.audit.write(json.dumps({"ts": time.time(), "run": self.run_id,
                                     "user": self.user_id, "event": event, **data}) + "\n")

    def on_chat_model_start(self, serialized, messages, **kw):
        self.llm_calls += 1
        if self.llm_calls > POLICY["max_llm_calls"]:
            self._log("deny", reason="llm_call_budget"); raise PolicyViolation("LLM call budget exceeded")
        self._log("llm_start", n=self.llm_calls)

    def on_llm_end(self, response, **kw):
        usage = (response.llm_output or {}).get("token_usage", {})
        self.cost += usage.get("total_tokens", 0) * 0.0000006      # use a real price table
        if self.cost > POLICY["max_cost_usd"]:
            self._log("deny", reason="cost_budget"); raise PolicyViolation("Cost budget exceeded")

    def on_tool_start(self, serialized, input_str, **kw):
        name = serialized.get("name")
        if name in POLICY["approval_required"]:
            self._log("approval_required", tool=name, args=input_str)
            raise PolicyViolation(f"{name} requires human approval")
        if name not in POLICY["allowed_tools"]:
            self._log("deny", tool=name); raise PolicyViolation(f"Tool {name} not allowed")
        if any(p in input_str.lower() for p in POLICY["blocked_patterns"]):
            self._log("deny", tool=name, reason="sensitive_args"); raise PolicyViolation("Sensitive args")
        self._log("tool_start", tool=name, args=input_str[:500])

    def on_tool_end(self, output, **kw):
        self._log("tool_end", output_preview=str(output)[:200])
```

### 3. Attaching it to an agent

```python
from langchain.agents import create_agent

agent = create_agent("openai:gpt-4o-mini", tools=[search_kb, get_order, issue_refund])
gov = Governor(user_id="u-42", audit_sink=open("audit.jsonl", "a"))
try:
    agent.invoke({"messages": [("user", "Refund order 991")]}, config={"callbacks": [gov]})
except PolicyViolation as e:
    print("Governed:", e)
```

> **Callbacks observe, middleware controls.** Callbacks are great for audit and metrics, and they can block by raising. For **modifying** behavior (redacting, routing to HITL, swapping models), LangChain v1 **middleware** (`wrap_tool_call`, `HumanInTheLoopMiddleware`) is the cleaner enforcement point. Many governors use both.

### 4. Guardrails through the governor

```python
from langchain.agents.middleware import wrap_tool_call, HumanInTheLoopMiddleware, PIIMiddleware

@wrap_tool_call
def governed_tool(request, handler):
    name = request.tool_call["name"]
    decision = policy_engine.evaluate(user=ctx_user(), action=f"tool:{name}",
                                      args=request.tool_call["args"])
    audit(decision)
    if decision == "deny":
        return ToolMessage(content=f"Action {name} denied by policy.",
                           tool_call_id=request.tool_call["id"])
    return handler(request)

agent = create_agent("openai:gpt-4o-mini", tools=[...], middleware=[
    PIIMiddleware("email", strategy="redact", apply_to_input=True, apply_to_output=True),
    governed_tool,
    HumanInTheLoopMiddleware(interrupt_on={"issue_refund": True}),
], checkpointer=InMemorySaver())
```

Externalize policy so non-engineers can review it, e.g. as YAML or OPA/Rego:

```yaml
# policy.yaml
tools:
  issue_refund: { require_approval_if: "args.amount > 100", roles: [support_lead] }
  delete_account: { deny: true }
budgets: { per_run_usd: 0.5, per_user_day_usd: 5 }
data: { redact: [email, phone, ssn], allowed_regions: [eu-west-1] }
```

---

## Deep dive

- **Policy decision point (PDP) vs policy enforcement point (PEP):** the governor/policy engine *decides*, and callbacks or middleware *enforce*. Keeping them separate means one policy can serve many agents and frameworks.
- **Audit log requirements:** append-only, tamper-evident (hash chaining or WORM storage), with who, what, when, inputs (redacted), decision, and model/prompt version.
- **Governance metadata on every trace:** `agent_id`, `owner`, `risk_tier`, `policy_version`.

## Advanced

- **Risk tiers drive controls:** a low-risk internal summarizer needs logging only. A high-risk credit decision agent needs HITL, bias evals, explainability, and documentation.
- **Model/agent cards:** intended use, limitations, eval results, red-team results, and owners.
- **Kill switch:** you must be able to disable an agent or tool globally in seconds (feature flag at the governor).
- **Third-party models and MCP servers** fall under vendor risk management.

## Production & scale

- Run the governor in-process for latency, with policy fetched from a central service and cached with a TTL.
- Stream audit events to a SIEM (Splunk, Chronicle, Sentinel) and alert on denials and approval spikes.
- Do periodic governance reviews: sample traces, re-run evals and red-team suites, and update risk assessments.

## FAANG insights

- Big companies run **Responsible AI review boards** and require launch reviews for AI features, which are enforced by platform tooling (you can't get a production API key for a high-risk use without sign-off).
- Interview: *"How would you make an autonomous agent auditable?"* Use a central policy engine, enforcement hooks at every tool call, immutable audit logs, versioned prompts and models, HITL for high-risk actions, and a kill switch.

## Interview questions

1. **Callbacks vs middleware for governance?** Callbacks are best for observation/audit (they can block by raising). Middleware can modify, route, or interrupt.
2. **What's in the NIST AI RMF?** The Govern, Map, Measure, and Manage functions.
3. **What makes an audit log trustworthy?** Append-only, tamper-evident, complete context, and access-controlled.

## Checklist

- [ ] AI system inventory with owners + risk tier
- [ ] Policy externalized and versioned
- [ ] Enforcement on every tool and LLM call
- [ ] Immutable audit log → SIEM
- [ ] Budgets, HITL, kill switch
