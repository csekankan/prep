# 15 — Bifrost AI Gateway + Mini RAG with Qdrant Cloud

> **One sentence:** Bifrost (by Maxim AI) is an open-source, **Go-based, high-throughput** LLM gateway with an OpenAI-compatible API, a web UI, provider fallbacks, streaming, request logging, **virtual keys** (budgets and governance), and built-in **MCP** support. In this section you put it in front of a small Qdrant RAG app.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Introduction to Bifrost AI gateway | Basics |
| Setting up Bifrost and other LLM providers | Code §1 |
| Problem without gateways | Basics |
| Our first Bifrost call | Code §2 |
| Fallback, streaming and logging with Bifrost | Code §3 |
| Playing with virtual keys and MCP | Code §4 |
| Mini RAG with Qdrant Cloud: data ingestion | Code §5 |
| Mini RAG with Qdrant Cloud: data retrieval | Code §6 |

---

## Basics

### Problem without gateways (recap with code smell)

```python
# every service does this
try:
    r = openai_client.chat.completions.create(...)
except RateLimitError:
    time.sleep(2); r = openai_client.chat.completions.create(...)
except APIError:
    r = anthropic_client.messages.create(...)          # different API shape!
    text = r.content[0].text                           # different parsing!
log_cost(r)                                            # different usage fields!
```

Duplicated, inconsistent, untested failover logic, and secrets copied into every service.

### Why Bifrost specifically

| Feature | Notes |
|---------|-------|
| Performance | Written in Go. Its makers claim microsecond-level overhead at thousands of RPS |
| Drop-in | OpenAI-compatible (plus Anthropic/GenAI-compatible) endpoints |
| UI | Configure providers, keys, and see logs at `http://localhost:8080` |
| Governance | Virtual keys with budgets, rate limits, model allow-lists |
| MCP | Gateway can connect to MCP servers and expose tools to models |
| Observability | Built-in request logs, Prometheus metrics, OTel |

---

## Code

### 1. Run Bifrost

```bash
npx -y @maximhq/bifrost            # quickest
# or
docker run -p 8080:8080 -v $(pwd)/data:/app/data maximhq/bifrost
```

Open `http://localhost:8080` and add providers (OpenAI, Anthropic, Gemini, Groq, Bedrock, Ollama…) with their API keys. Config is persisted in `data/` (a `config.json` / SQLite store).

### 2. First call

```bash
curl http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model": "openai/gpt-4o-mini", "messages": [{"role":"user","content":"Hello Bifrost"}]}'
```

```python
from openai import OpenAI
client = OpenAI(base_url="http://localhost:8080/v1", api_key="dummy")   # keys live in the gateway
r = client.chat.completions.create(model="anthropic/claude-sonnet-4-5",
        messages=[{"role": "user", "content": "Hi"}])
```

The model string is `provider/model`, so you switch providers by changing a string.

### 3. Fallback, streaming, logging

```python
r = client.chat.completions.create(
    model="openai/gpt-4o-mini",
    messages=[{"role": "user", "content": "Summarize MCP"}],
    extra_body={"fallbacks": ["anthropic/claude-haiku-4-5", "groq/llama-3.3-70b-versatile"]},
)

for chunk in client.chat.completions.create(model="openai/gpt-4o-mini",
                                            messages=[...], stream=True):
    print(chunk.choices[0].delta.content or "", end="")
```

Logs tab: every request with provider, model, latency, tokens, cost, status, and which fallback served it.

### 4. Virtual keys + MCP

- **Virtual key:** create one in the UI (e.g. `vk-support-team`) with a monthly budget, rate limit, and allowed models. Clients pass it as a header (e.g. `x-bf-vk: vk-support-team`). Check the docs for the exact header name in your version.
- **MCP:** register MCP servers (stdio or HTTP) in the gateway. The gateway lists their tools and can inject them into requests, so **tool access is governed centrally** (per virtual key) instead of per app.

```python
client = OpenAI(base_url="http://localhost:8080/v1", api_key="dummy",
                default_headers={"x-bf-vk": "vk-support-team"})
```

### 5. Mini RAG: ingestion into Qdrant Cloud

```python
from qdrant_client import QdrantClient, models
from openai import OpenAI
from langchain_text_splitters import RecursiveCharacterTextSplitter
import uuid, pathlib

oa = OpenAI(base_url="http://localhost:8080/v1", api_key="dummy")   # embeddings via gateway too
qd = QdrantClient(url=QDRANT_URL, api_key=QDRANT_API_KEY)

COL = "mini_rag"
qd.recreate_collection(COL, vectors_config=models.VectorParams(size=1536, distance=models.Distance.COSINE))

splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=100)
points = []
for f in pathlib.Path("docs").glob("*.md"):
    for i, chunk in enumerate(splitter.split_text(f.read_text())):
        emb = oa.embeddings.create(model="openai/text-embedding-3-small", input=chunk).data[0].embedding
        points.append(models.PointStruct(id=str(uuid.uuid4()), vector=emb,
                      payload={"text": chunk, "source": f.name, "chunk": i}))
qd.upsert(COL, points=points, wait=True)
```

### 6. Retrieval + generation

```python
def ask(q: str, k: int = 4):
    qv = oa.embeddings.create(model="openai/text-embedding-3-small", input=q).data[0].embedding
    hits = qd.query_points(COL, query=qv, limit=k, with_payload=True).points
    ctx = "\n\n".join(f"[{h.payload['source']}] {h.payload['text']}" for h in hits)
    r = oa.chat.completions.create(model="openai/gpt-4o-mini",
        messages=[{"role": "system", "content": "Answer ONLY from context. Cite [source]. If unknown, say so."},
                  {"role": "user", "content": f"Context:\n{ctx}\n\nQuestion: {q}"}],
        extra_body={"fallbacks": ["anthropic/claude-haiku-4-5"]})
    return r.choices[0].message.content
```

Batch the embeddings (send a list as `input`) in real ingestion, because one call per chunk is slow.

---

## Deep dive

- **Why Go?** Goroutines plus low GC overhead give high concurrency with predictable latency. Python gateways (LiteLLM) are more flexible but heavier at very high RPS.
- **Connection pooling and buffering:** gateways keep warm HTTP/2 connections to providers, which often makes them *faster* than naive direct calls.
- **Qdrant basics:** HNSW index, payload filters (`must=[FieldCondition(key="tenant", match=MatchValue(value="acme"))]`), named vectors, and hybrid sparse+dense search.

## Advanced

- Put **tenant ID in the Qdrant payload and always filter by it**, since vector DBs don't enforce row-level security for you.
- Gateway-level MCP means **one place to audit tool calls**, which is a big governance win.
- Embedding model changes require **re-indexing**. Store `embedding_model` in the payload or collection name.

## Production & scale

- Run Bifrost replicas behind a load balancer, with config in a shared store.
- Export Prometheus metrics: requests, latency, errors per provider, and fallback rate.
- Qdrant: set `on_disk` for large collections, scalar or binary quantization for memory, and snapshots for backup.

## FAANG insights

- Gateway choice is less important than **having exactly one**. Interviewers look for "centralize keys, retries, budgets, and logging".
- For RAG, the classic interview follow-up is *"How do you keep the index fresh?"* Use CDC/event-driven upserts, idempotent IDs (hash of source + chunk), and deletes for removed docs.

## Interview questions

1. **What does a virtual key enable?** Per-consumer budgets, limits, model allow-lists, and revocation without touching provider keys.
2. **Why route embeddings through the gateway too?** Unified cost tracking, fallback, and key management.
3. **How do you isolate tenants in a vector DB?** Mandatory payload filter, or a collection/shard per tenant.

## Checklist

- [ ] Providers configured only in the gateway
- [ ] Fallback list per critical model
- [ ] Virtual keys per team with budgets
- [ ] Batched embeddings + deterministic chunk IDs
- [ ] Tenant filter on every vector query
