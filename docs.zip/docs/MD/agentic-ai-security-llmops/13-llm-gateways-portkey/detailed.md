# 13 — LLM Gateways + Portkey

> **One sentence:** An LLM gateway is a **reverse proxy for model APIs**. Your app calls one endpoint, and the gateway handles provider keys, retries, timeouts, fallbacks, load balancing, caching, logging, and budgets, so you don't re-implement them in every service.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| What is an LLM gateway and terminologies | Basics |
| Introduction to Portkey and project setup (appears twice in the outline) | Code §1 |
| Our first experiment with Portkey | Code §2 |
| User tracing, retry, timeout and fallback | Code §3–§4 |
| Load balancing and caching | Code §5–§6 |
| LangChain integration with Portkey | Code §7 |

---

## Basics

### Problems a gateway solves

| Without gateway | With gateway |
|-----------------|--------------|
| Provider keys in every service | Keys **vaulted** once; apps get virtual keys |
| Each team writes its own retry logic | Central retry/backoff/timeout |
| OpenAI outage = your outage | **Fallback** to Anthropic/Azure |
| Hit rate limits on one key | **Load balance** across keys/regions |
| Same question = full price every time | **Cache** (exact + semantic) |
| No idea who spent $40k | **Per-user/team cost attribution**, budgets |
| N SDKs for N providers | **One OpenAI-compatible API** |

### Terminology

| Term | Meaning |
|------|---------|
| **Virtual key** | Gateway-issued alias for a real provider key (rotatable, budgeted, scoped) |
| **Config** | JSON routing policy (strategy, targets, retry, cache) |
| **Fallback** | Try target A, and on error try B |
| **Load balance** | Split traffic by weights |
| **Conditional routing** | Route by metadata (user tier, region) |
| **Simple cache / semantic cache** | Exact-match vs embedding-similarity cache |
| **Trace ID / metadata** | Tags to group and filter logs |

**Analogy:** A gateway is a **telephone switchboard operator**. You dial one number, and the operator connects you to whichever line is open, retries busy lines, and logs every call.

---

## Code

### 1. Setup

```bash
uv add portkey-ai openai langchain-openai
export PORTKEY_API_KEY=...
```

In the Portkey dashboard, add provider credentials to get **virtual keys** (or "providers" / Model Catalog slugs in newer versions), e.g. `openai-prod-xxx` and `anthropic-xxx`.

### 2. First call

```python
from portkey_ai import Portkey

client = Portkey(api_key=PORTKEY_API_KEY, virtual_key="openai-prod-xxx")
r = client.chat.completions.create(model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Hello via gateway"}])
print(r.choices[0].message.content)
```

Using the plain OpenAI SDK (no code change except base URL + headers):

```python
from openai import OpenAI
from portkey_ai import PORTKEY_GATEWAY_URL, createHeaders
client = OpenAI(base_url=PORTKEY_GATEWAY_URL, api_key="x",
                default_headers=createHeaders(api_key=PORTKEY_API_KEY, virtual_key="openai-prod-xxx"))
```

### 3. User tracing + metadata

```python
client = Portkey(api_key=PORTKEY_API_KEY, virtual_key="openai-prod-xxx",
                 trace_id="checkout-flow-8812",
                 metadata={"_user": "user_42", "team": "support", "env": "prod"})
```

`_user` is a special key for per-user analytics. Filter logs by any metadata key.

### 4. Retry, timeout, fallback (config)

```python
config = {
    "strategy": {"mode": "fallback", "on_status_codes": [429, 500, 502, 503, 504]},
    "request_timeout": 10000,                         # ms
    "retry": {"attempts": 3, "on_status_codes": [429, 503]},
    "targets": [
        {"virtual_key": "openai-prod-xxx",   "override_params": {"model": "gpt-4o"}},
        {"virtual_key": "anthropic-xxx",     "override_params": {"model": "claude-sonnet-4-5"}},
    ],
}
client = Portkey(api_key=PORTKEY_API_KEY, config=config)
```

Configs can also be saved in the UI and referenced by ID (`config="pc-xxxx"`), which lets you change routing **without redeploying**.

### 5. Load balancing

```python
config = {
    "strategy": {"mode": "loadbalance"},
    "targets": [
        {"virtual_key": "openai-key-1", "weight": 0.7},
        {"virtual_key": "openai-key-2", "weight": 0.2},
        {"virtual_key": "azure-openai", "weight": 0.1},
    ],
}
```

Strategies nest. For example, load balance **between** two fallback groups.

### 6. Caching

```python
config = {"cache": {"mode": "semantic", "max_age": 3600},   # or "simple"
          "virtual_key": "openai-prod-xxx"}
client = Portkey(api_key=PORTKEY_API_KEY, config=config)
# Force refresh for one call:
client.with_options(cache_force_refresh=True).chat.completions.create(...)
```

### 7. LangChain integration

```python
from langchain_openai import ChatOpenAI
from portkey_ai import createHeaders, PORTKEY_GATEWAY_URL

llm = ChatOpenAI(api_key="x", base_url=PORTKEY_GATEWAY_URL,
                 default_headers=createHeaders(api_key=PORTKEY_API_KEY, config="pc-fallback-01",
                                               trace_id="lc-agent", metadata={"_user": "u1"}))
llm.invoke("hi")   # works inside create_agent / LangGraph too
```

---

## Deep dive

```mermaid
sequenceDiagram
  participant App
  participant GW as Gateway
  participant C as Cache
  participant O as OpenAI
  participant A as Anthropic
  App->>GW: POST /chat/completions (config, metadata)
  GW->>C: lookup(hash or embedding)
  C-->>GW: miss
  GW->>O: request (timeout 10s)
  O-->>GW: 503
  GW->>O: retry (exp backoff)
  O-->>GW: 503
  GW->>A: fallback (translated to Anthropic format)
  A-->>GW: 200
  GW->>C: store
  GW-->>App: 200 (OpenAI format) + x-portkey-trace-id
```

- **Format translation:** the gateway converts OpenAI-style requests to each provider's native API and back.
- **Semantic cache:** embeds the prompt and returns a cached answer if the cosine similarity is above a threshold. That's great for FAQs, and **dangerous** for personalized or time-sensitive answers.

## Advanced

- **Retry storms:** app-level retries × gateway retries × SDK retries multiply load (3×3×3 = 27 calls). Retry in **one** layer only.
- **Fallback quality drift:** the backup model may behave differently, so run evals on every fallback target.
- **Cache keys must include** model, temperature, system prompt version, **tenant/user ID** (for personalized data), and tool definitions. Otherwise you can leak data across tenants.
- **Gateway guardrails:** Portkey supports guardrail hooks (before/after request) that can deny or flag a request.
- **Gateway as a single point of failure:** run it HA and multi-AZ, or use client-side failover to direct providers.

## Production & scale

- Gateways add 5–30 ms of overhead. Self-hosted OSS gateways (Portkey OSS, Bifrost, LiteLLM) in the same VPC minimize it.
- Track per-virtual-key budgets and rate limits, and alert at 80%.
- Log retention plus PII policies apply to gateway logs too.

## FAANG insights

- Every large company builds an **internal model gateway** (often called an "AI platform" or "model proxy"). It's the control point for cost, compliance, provider contracts, and model rollout.
- Interview: *"Design a multi-provider LLM platform for 200 teams."* Cover the gateway, virtual keys per team, quotas, fallback, caching, an audit log, eval gating for new models, and a cost dashboard.

## Interview questions

1. **Fallback vs load balance?** Sequential on failure vs weighted parallel distribution.
2. **Risk of semantic caching?** Wrong or stale answers, and cross-tenant leakage if keys aren't scoped.
3. **Why virtual keys?** You can rotate and revoke them and budget per consumer without sharing provider secrets.

## Checklist

- [ ] One retry layer
- [ ] Fallback targets evaluated
- [ ] Cache scoped by tenant + prompt version
- [ ] Metadata for user/team cost attribution
- [ ] Gateway deployed HA
