# 03 — Structured Output: Pydantic, TypedDict, Dataclass

> **One sentence:** Structured output makes the LLM return **data your code can trust** (typed fields, enums, ranges) instead of free text you have to regex-parse. That is both a reliability feature and a security feature.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Pydantic structured output | Code §1 |
| TypedDict structured output | Code §2 |
| Data class structured output | Code §3 |

---

## Basics

| Schema type | Validation at runtime? | Defaults / descriptions | Best for |
|-------------|-----------------------|-------------------------|----------|
| **Pydantic `BaseModel`** | ✅ full (types, ranges, regex, custom validators) | ✅ `Field(description=...)` | Production, anything security-sensitive |
| **`TypedDict`** | ❌ (just a dict) | ✅ via `Annotated[...]` | Lightweight, streaming partial dicts |
| **`@dataclass`** | ❌ basic | ✅ | Existing dataclass-based codebases |
| **JSON Schema dict** | Provider-side only | ✅ | Cross-language contracts |

**Analogy:** Free text is a **handwritten note**. Structured output is a **filled-in form with checkboxes**, and Pydantic is the clerk who **rejects the form** if a box is wrong.

---

## Code

### 1. Pydantic (recommended)

```python
from typing import Literal
from pydantic import BaseModel, Field, field_validator
from langchain.chat_models import init_chat_model

class Ticket(BaseModel):
    """A classified support ticket."""
    category: Literal["billing", "bug", "account", "other"]
    priority: int = Field(ge=1, le=5, description="1=lowest, 5=highest")
    summary: str = Field(max_length=200)
    contains_pii: bool

    @field_validator("summary")
    @classmethod
    def no_urls(cls, v: str) -> str:
        if "http" in v:
            raise ValueError("summary must not contain URLs")
        return v

model = init_chat_model("openai:gpt-4o-mini", temperature=0)
structured = model.with_structured_output(Ticket)
t: Ticket = structured.invoke("My card was charged twice!! email me at a@b.com")
print(t.category, t.priority, t.contains_pii)

# Get raw + parsed + parsing_error (don't crash on bad output)
safe = model.with_structured_output(Ticket, include_raw=True)
out = safe.invoke("...")
out["parsed"], out["parsing_error"], out["raw"]
```

### 2. TypedDict

```python
from typing_extensions import TypedDict, Annotated

class Movie(TypedDict):
    """Movie info."""
    title: Annotated[str, ..., "Movie title"]          # ... = required
    year: Annotated[int, ..., "Release year"]
    rating: Annotated[float, None, "Rating 0-10"]      # None default = optional

movie = model.with_structured_output(Movie).invoke("Tell me about Inception")
print(movie["title"])   # plain dict

# TypedDict streams partial dicts nicely
for partial in model.with_structured_output(Movie).stream("About Interstellar"):
    print(partial)
```

### 3. Dataclass

```python
from dataclasses import dataclass

@dataclass
class Contact:
    name: str
    email: str
    phone: str | None = None

c = model.with_structured_output(Contact).invoke("John, john@x.com, 555-1234")
```

### 4. Structured output in agents (`response_format`)

```python
from langchain.agents import create_agent
from langchain.agents.structured_output import ToolStrategy, ProviderStrategy

agent = create_agent(
    model="openai:gpt-4o-mini",
    tools=[],
    response_format=ToolStrategy(Ticket),     # or ProviderStrategy(Ticket) / just Ticket
)
res = agent.invoke({"messages": [("user", "App crashes on login")]})
res["structured_response"]   # -> Ticket instance
```

---

## Deep dive

### Three ways providers enforce structure

| Method | How | Reliability |
|--------|-----|-------------|
| **Native JSON schema / "strict" mode** (`ProviderStrategy`, `method="json_schema"`) | **Constrained decoding**: the provider masks tokens that would break the schema | Highest (schema-valid by construction) |
| **Tool-calling** (`ToolStrategy`, `method="function_calling"`) | Schema passed as a fake tool and the model "calls" it | High, works on most models |
| **JSON mode + parse** (`method="json_mode"`) | Model told to output JSON, then parsed afterward | Lowest, needs retries |

**Constrained decoding** works like this: at each step the sampler only allows tokens that keep the output a valid prefix of the grammar (a JSON Schema compiled to a finite-state machine or grammar). Libraries like Outlines, XGrammar, and llguidance do this for self-hosted models.

### Schema → prompt

Field names, types, and `description`s are serialized into the request. **Descriptions steer the model**, so treat them as prompt text. Enums (`Literal`) are your best friend: they turn open-ended generation into classification.

---

## Advanced

- **Schema-valid ≠ correct.** The JSON can be perfectly valid while `priority=5` is still wrong. You still need evals (sections 17–18).
- **Nested and recursive models:** supported, but deep nesting hurts accuracy. Flatten where you can.
- **Reasoning vs structure:** forcing JSON immediately can hurt reasoning quality. Fix it with a `reasoning: str` field **first** in the schema (field order matters for autoregressive models), or do a two-step "think, then format".
- **Retries:** on `ValidationError`, re-ask with the error message (Guardrails AI `REASK`, section 11).
- **Security:** structured output is an **output guardrail**. If downstream code uses `category` to route, a `Literal` makes injection of arbitrary routes impossible.

## Production & scale

- Prefer **native strict mode** where it's available: zero parse failures and no retry cost.
- Log parse-failure rate per model and version as an SLO. A spike usually means a model update.
- Keep schemas **versioned**, and add fields as optional to stay backward compatible.

## FAANG insights

- Large teams put structured output at **every LLM → code boundary**. Free text is only allowed at the final LLM → human boundary.
- A common interview prompt: *"Extract entities from 10M documents reliably."* Good answers mention strict schemas, batch APIs, a validation + retry queue, sampling for human QA, and cost per doc.

## Interview questions

1. **Pydantic vs TypedDict?** Pydantic validates at runtime. TypedDict is only a type hint (lighter, and it streams well).
2. **Why put a `reasoning` field first?** The model generates tokens left to right, so reasoning before the answer improves the answer.
3. **What's constrained decoding?** Masking invalid tokens during sampling so the output must match a grammar.

## Checklist

- [ ] Every LLM → code boundary uses a schema
- [ ] `Literal` / enums for routing fields
- [ ] Parse errors handled (`include_raw=True`) and metered
- [ ] Field-level validators for security rules
