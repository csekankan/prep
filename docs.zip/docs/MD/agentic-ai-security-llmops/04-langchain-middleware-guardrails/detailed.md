# 04 — LangChain Middleware: Summarization, Human-in-the-Loop, Guardrails

> **One sentence:** Middleware lets you plug code in **around every model call and tool call** of a LangChain agent, so you can compress context, pause for human approval, redact PII, or block unsafe content without rewriting the agent loop.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Middleware summarization | Code §2 |
| Human-in-the-loop middleware | Code §3 |
| Introduction to guardrails and implementation | Code §4–§5, Deep dive |

---

## Basics

**Analogy:** The agent loop is a **conveyor belt**. Middleware is a set of **inspection stations** you bolt onto the belt: one shrinks oversized packages (summarization), one needs a supervisor's signature (HITL), and one scans for contraband (guardrails).

### Hook points

```mermaid
flowchart LR
  BA[before_agent] --> BM[before_model]
  BM --> WM[wrap_model_call]
  WM --> AM[after_model]
  AM -->|tool calls| WT[wrap_tool_call]
  WT --> BM
  AM -->|done| AA[after_agent]
```

| Hook | Typical use |
|------|-------------|
| `before_agent` | Input guardrails, load user profile |
| `before_model` | Trim/summarize messages, inject context |
| `wrap_model_call` | Retry, fallback model, dynamic model/tool selection, caching |
| `after_model` | Output checks, HITL interrupt on tool calls |
| `wrap_tool_call` | Tool retries, arg validation, sandboxing, logging |
| `after_agent` | Final output guardrail, analytics |

---

## Code

### 1. Built-in middleware overview

```python
from langchain.agents import create_agent
from langchain.agents.middleware import (
    SummarizationMiddleware,
    HumanInTheLoopMiddleware,
    PIIMiddleware,
    ModelCallLimitMiddleware,
    ToolCallLimitMiddleware,
    ModelFallbackMiddleware,
)
```

### 2. Summarization middleware (keeping long chats inside the context window)

```python
from langgraph.checkpoint.memory import InMemorySaver

agent = create_agent(
    model="openai:gpt-4o",
    tools=[...],
    middleware=[
        SummarizationMiddleware(
            model="openai:gpt-4o-mini",          # cheap model does the summarizing
            trigger=("tokens", 4000),           # when history exceeds this
            keep=("messages", 20),              # keep last N messages verbatim
        ),
    ],
    checkpointer=InMemorySaver(),
)
```

> Parameter names have changed across releases (`max_tokens_before_summary` / `messages_to_keep` in early v1, `trigger` / `keep` later). Check the version you have installed.

**How it works:** when the history passes the threshold, older messages are replaced by a single summary message. The summarizer is careful **not to split an AIMessage from its ToolMessages**, because providers reject orphaned tool results.

### 3. Human-in-the-loop middleware

```python
from langgraph.types import Command

agent = create_agent(
    model="openai:gpt-4o",
    tools=[send_email, read_inbox, delete_file],
    middleware=[
        HumanInTheLoopMiddleware(interrupt_on={
            "send_email": {"allowed_decisions": ["approve", "edit", "reject"]},
            "delete_file": True,           # all decisions allowed
            "read_inbox": False,           # never interrupt
        }),
    ],
    checkpointer=InMemorySaver(),          # REQUIRED: state must persist while paused
)

cfg = {"configurable": {"thread_id": "t-1"}}
res = agent.invoke({"messages": [("user", "Email bob the Q3 report")]}, cfg)
print(res["__interrupt__"])                 # pending action(s) for review

# Human approves (or edits args / rejects with a message)
agent.invoke(Command(resume={"decisions": [{"type": "approve"}]}), cfg)
# edit:   {"type": "edit", "edited_action": {"name": "send_email", "args": {...}}}
# reject: {"type": "reject", "message": "Don't send externally"}
```

### 4. Built-in PII guardrail

```python
agent = create_agent(
    model="openai:gpt-4o-mini",
    tools=[...],
    middleware=[
        PIIMiddleware("email", strategy="redact", apply_to_input=True),
        PIIMiddleware("credit_card", strategy="mask", apply_to_input=True),
        PIIMiddleware("api_key", detector=r"sk-[a-zA-Z0-9]{32}", strategy="block"),
    ],
)
```

| Strategy | Effect |
|----------|--------|
| `redact` | `[REDACTED_EMAIL]` |
| `mask` | `****-****-****-1234` |
| `hash` | deterministic hash (lets you join records without the raw value) |
| `block` | raise an error and stop the run |

### 5. Custom guardrail middleware

```python
from langchain.agents.middleware import AgentMiddleware, AgentState, before_agent, after_agent
from langgraph.runtime import Runtime

BANNED = ["ignore previous instructions", "system prompt", "jailbreak"]

@before_agent(can_jump_to=["end"])
def block_injection(state: AgentState, runtime: Runtime):
    text = state["messages"][-1].content.lower()
    if any(b in text for b in BANNED):
        return {"messages": [{"role": "assistant",
                              "content": "I can't help with that request."}],
                "jump_to": "end"}
    return None

class OutputSafety(AgentMiddleware):
    def after_agent(self, state, runtime):
        last = state["messages"][-1]
        verdict = judge_model.invoke(f"Is this response safe? yes/no:\n{last.content}")
        if "no" in verdict.content.lower():
            last.content = "Sorry, I can't provide that."
        return None

agent = create_agent("openai:gpt-4o-mini", tools=[], middleware=[block_injection, OutputSafety()])
```

---

## Deep dive

- **Ordering:** `before_*` hooks run in list order, `after_*` hooks run in **reverse** order, and `wrap_*` hooks nest like decorators (the first in the list is outermost). Put cheap deterministic guardrails **first** so they short-circuit before expensive LLM checks.
- **State:** middleware can declare extra state fields (`state_schema`), which is how summarization or call counters persist across steps through the checkpointer.
- **Jumps:** `jump_to` (`"end"`, `"model"`, `"tools"`) lets a guardrail end the run early.
- **HITL mechanics:** HITL is built on LangGraph `interrupt()`. The graph raises an interrupt and the checkpointer saves state. On `Command(resume=...)`, execution continues from that exact node, so nothing is re-run.

## Advanced

- **Deterministic vs model-based guardrails:** regex and keyword checks are fast, cheap, and easy to bypass (Base64, typos, other languages). LLM judges catch more but add cost, latency, and their own injection risk. Use **both**.
- **Summaries can lose security context:** if the summary drops "user is NOT authorized for X", the agent may forget. Keep **auth facts in state**, not in the message history.
- **HITL fatigue:** if you interrupt too often, humans rubber-stamp everything. Interrupt on **risk** (amount > $X, external recipient), not on every call.
- **Context editing middleware:** clear old tool outputs, which are often the largest token consumers, instead of summarizing dialog.

## Production & scale

- Use a persistent checkpointer (`PostgresSaver`) for HITL. Approvals can take hours.
- Emit a metric for every guardrail block (name, reason). A sudden spike means either an attack or a false-positive regression.
- Summarization saves tokens but costs an extra LLM call, so tune the trigger with real conversation-length distributions.

## FAANG insights

- In big companies, "guardrails as middleware" usually means a **shared policy library** that every agent team must include. Platform teams own it, and product teams can't remove it.
- HITL is typically surfaced through **existing approval systems** (tickets, Slack approvals) rather than custom UIs.
- Interview angle: *"Where would you put PII redaction: before the LLM, before logging, or both?"* The answer is **both**, plus a third place: before writing to long-term memory.

## Interview questions

1. **Why does HITL need a checkpointer?** The run pauses and must resume later, possibly in a different process.
2. **Order of `after_model` hooks?** Reverse of registration.
3. **Mask vs hash vs redact?** Mask keeps partial info for UX, hash keeps joinability, redact removes it completely.

## Checklist

- [ ] Cheap guardrails first, LLM-judge guardrails after
- [ ] HITL only on irreversible or high-risk tools
- [ ] Persistent checkpointer in prod
- [ ] PII redacted before LLM, logs, and memory
- [ ] Model/tool call limits set
