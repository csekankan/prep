# 29 — Deep Agents: Planning, Virtual Filesystem, Backends, Context Engineering, Subagents

> **One sentence:** "Deep agents" (LangChain's `deepagents` package) take the recipe behind Claude Code and Deep Research and make it reusable: a **detailed system prompt + a planning tool (todos) + a filesystem for offloading context + subagents**, all on top of LangGraph. That lets agents handle long, multi-step tasks without drowning in context.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| What are deep agents and basic implementation | Basics, Code §1 |
| Deep agents customization | Code §2 |
| Deep agents vs Claude SDK | Deep dive |
| Backend in deep agents | Code §3 |
| Context engineering: input context and memory | Code §4, Deep dive |
| Skills context engineering | Code §5 |
| Subagents in deep agents | Code §6 |
| Deep agents project with all features | Code §7 |

---

## Basics

### Shallow vs deep agents

| Shallow (simple ReAct loop) | Deep agent |
|-----------------------------|-----------|
| Tool call → observe → repeat | **Plans** with a todo list, **writes notes/files**, **delegates** to subagents |
| All results pile into messages | Large results **offloaded to files** and read back when needed |
| Fails on 50-step tasks | Designed for long-horizon tasks (research, coding, reports) |

### Built-in tools

| Tool | Purpose |
|------|---------|
| `write_todos` | Create/update a plan (a scratchpad that keeps the agent on track) |
| `ls`, `read_file`, `write_file`, `edit_file`, `glob`, `grep` | Filesystem for context offloading |
| `task` | Spawn a **subagent** with an isolated context |
| (optional) `execute` | Run shell commands when the backend supports sandboxes |

**Analogy:** A shallow agent is someone keeping everything in their head. A deep agent is a **project manager with a notebook, a filing cabinet, and a team of interns**.

---

## Code

### 1. Basic deep agent

```bash
uv add deepagents tavily-python
```

```python
from deepagents import create_deep_agent
from tavily import TavilyClient

tavily = TavilyClient()

def internet_search(query: str, max_results: int = 5) -> dict:
    """Search the web for up-to-date information."""
    return tavily.search(query, max_results=max_results)

agent = create_deep_agent(
    tools=[internet_search],
    system_prompt="You are an expert researcher. Plan with todos, save findings to files, "
                  "then write a final report to /report.md.",
)
result = agent.invoke({"messages": [{"role": "user", "content": "Compare LangGraph vs CrewAI in 2026"}]})
print(result["files"].get("/report.md"))     # default backend keeps files in graph state
```

### 2. Customization

```python
from langchain.chat_models import init_chat_model

agent = create_deep_agent(
    model=init_chat_model("anthropic:claude-sonnet-4-5"),   # default is a Claude model
    tools=[internet_search],
    system_prompt=RESEARCH_PROMPT,
    middleware=[...],                                       # any LangChain v1 middleware
    interrupt_on={"write_file": True},                      # HITL on file writes
    checkpointer=InMemorySaver(),
)
```

### 3. Backends (where the "filesystem" lives)

```python
from deepagents.backends import StateBackend, FilesystemBackend, StoreBackend, CompositeBackend
from langgraph.store.memory import InMemoryStore

# StateBackend (default): files live in LangGraph state, ephemeral per thread
# FilesystemBackend: real disk under a root dir (careful: real side effects)
# StoreBackend: LangGraph Store -> persists across threads (long-term memory)
# CompositeBackend: route paths to different backends

agent = create_deep_agent(
    tools=[internet_search],
    store=InMemoryStore(),
    backend=lambda rt: CompositeBackend(
        default=StateBackend(rt),
        routes={"/memories/": StoreBackend(rt)},          # only /memories persists
    ),
)
```

| Backend | Persistence | Risk |
|---------|-------------|------|
| State | Per thread (checkpointer) | Lowest |
| Store | Cross-thread | Memory poisoning, needs namespacing |
| Filesystem | Real disk | Path traversal, overwrites, so use a **root dir + virtual mode** |
| Sandbox (Modal/Daytona/Runloop etc.) | Isolated VM/container | Best for code execution |

### 4. Context engineering: input context + memory

```python
SYSTEM = """You are a research agent.
## Workflow
1. Write a todo plan with write_todos.
2. For each sub-question, delegate to the `researcher` subagent.
3. Save raw findings to /notes/<topic>.md (do NOT keep long text in chat).
4. Read notes back and write /report.md with citations.
## Memory
- Before starting, read /memories/preferences.md if it exists.
- When the user states a lasting preference, append it to /memories/preferences.md.
"""
```

Context engineering levers:
- **Write** (offload to files), **Select** (read back only what's needed), **Compress** (summarization middleware), **Isolate** (subagents).
- Large tool results are automatically evicted to files in recent versions, so the message history stays small.

### 5. Skills (progressive disclosure)

```
skills/
└── sec-filing-analysis/
    ├── SKILL.md         # name, description, steps
    └── ratios.py
```

```python
agent = create_deep_agent(tools=[...], skills=["./skills"], backend=FilesystemBackend(root_dir="."))
```

Only skill **names and descriptions** go into the prompt. The agent reads `SKILL.md` when a task matches, which is the same idea as Claude Code skills (section 28).

### 6. Subagents

```python
researcher = {
    "name": "researcher",
    "description": "Researches ONE focused sub-question and returns a concise summary with sources.",
    "system_prompt": "You are a meticulous researcher. Return <=300 words + source URLs.",
    "tools": [internet_search],
    # "model": "openai:gpt-4o-mini",   # optional cheaper model
}
critic = {
    "name": "critic",
    "description": "Critiques a draft report for gaps, unsupported claims and bias.",
    "system_prompt": "Be harsh. List concrete issues with line references.",
}
agent = create_deep_agent(tools=[internet_search], system_prompt=SYSTEM, subagents=[researcher, critic])
```

The `task` tool launches a subagent with a **fresh context** containing only its instructions. Only its **final answer** returns to the parent, which is the key to context isolation. A general-purpose subagent is included by default.

### 7. Full project (all features)

```mermaid
flowchart TB
  U[User] --> MA[Main deep agent<br/>todos + files + HITL]
  MA -->|task| R1[researcher #1]
  MA -->|task| R2[researcher #2]
  MA -->|task| C[critic]
  R1 & R2 --> FS[(/notes/*.md)]
  MA --> FS
  MA --> MEM[(/memories/ → Store)]
  MA --> REP[/report.md/]
  MA -.traces.-> LS[LangSmith]
```

Run it with `langgraph dev` to watch todos, files, and subagent calls in Studio.

---

## Deep dive

### Deep Agents vs Claude Agent SDK

| | `deepagents` (LangChain) | Claude Agent SDK (Anthropic) |
|---|--------------------------|------------------------------|
| Model support | Any (LangChain chat models) | Claude models |
| Runtime | LangGraph (checkpoints, Studio, LangSmith) | Claude Code harness (built-in tools, permissions, hooks) |
| Filesystem | Pluggable backends (state, store, disk, sandbox) | Real local filesystem + bash |
| Extensibility | LangChain middleware, tools, MCP adapters | Hooks, MCP, skills, subagents |
| Best for | Model-agnostic production agents in Python/JS stacks | Coding/ops agents, Claude-first teams |

### Why a todo tool works

`write_todos` doesn't *do* anything externally. It forces the model to externalize its plan, which gets re-read every turn. This reduces drift on long tasks (a context-engineering trick, essentially cheap "attention steering").

## Advanced

- **Subagent fan-out cost:** each subagent is a full agent loop. Cap the number of subagents per task and use cheaper models for leaf work.
- **Filesystem security:** with `FilesystemBackend`, restrict `root_dir`, disallow `..`, and add HITL on writes outside `/notes`.
- **Memory poisoning:** `/memories/` written from web content can persist injections. Only write user-stated facts there, and review them.
- **Determinism:** pin prompts and models, and save todos and files as artifacts for audits.

## Production & scale

- Deploy as a LangGraph app (LangGraph Platform / self-hosted server) for long-running threads with a persistent checkpointer.
- Stream todo updates to the UI so users see progress on long tasks.
- Budget: max subagents, max tokens, and a wall-clock timeout per run.

## FAANG insights

- The pattern (planner + scratchpad + subagents + file-based memory) underlies most "deep research" and coding-agent products. Interviewers expect you to explain **context isolation** and **offloading** as the reasons they work.
- Interview: *"Your agent fails on 40-step tasks. Why, and how do you fix it?"* Context bloat and drift. Fix with a todo plan, offloading to files, subagents, summarization, and checkpoints.

## Interview questions

1. **Four components of a deep agent?** A detailed system prompt, a planning tool, a filesystem, and subagents.
2. **Why only return the subagent's final answer?** It keeps the parent context small and focused.
3. **StateBackend vs StoreBackend?** Per-thread ephemeral files vs cross-thread persistent memory.

## Checklist

- [ ] Detailed workflow system prompt
- [ ] Offload large content to files
- [ ] Subagents with narrow descriptions and tools
- [ ] Safe backend choice (sandbox for code)
- [ ] Budgets + HITL on risky writes
