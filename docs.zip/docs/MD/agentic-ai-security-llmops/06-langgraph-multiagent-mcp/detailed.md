# 06 — LangGraph Advanced: LangSmith Debugging, Multi-Agent, MCP

> **One sentence:** Once a single agent gets too many tools or responsibilities, you **split it into specialists** (multi-agent), connect them to tools through a **standard protocol** (MCP), and debug the whole thing with **traces** (LangSmith).

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| Debugging, monitoring and observability with LangSmith | Code §1 (more in section 07) |
| Multi-agent implementation with LangGraph | Code §2–§3, Deep dive |
| MCP implementation with LangGraph | Code §4–§5 |

---

## Basics

### Why multi-agent?

| Symptom of one big agent | Multi-agent fix |
|--------------------------|-----------------|
| 30+ tools, so the model picks the wrong one | Each specialist gets 3–8 tools |
| One giant prompt, so instructions conflict | Focused prompts per agent |
| Hard to test | Test each agent separately |
| One model for everything | Cheap model for routing, strong model for reasoning |

### Common architectures

```mermaid
flowchart TB
  subgraph Supervisor
    S[Supervisor] --> A1[Research agent]
    S --> A2[Math agent]
    S --> A3[Writer agent]
    A1 & A2 & A3 --> S
  end
```

| Pattern | How control flows | Good for |
|---------|-------------------|----------|
| **Supervisor** | Central router delegates and collects results | Most business apps |
| **Hierarchical** | Supervisors of supervisors | Large orgs of agents |
| **Network / swarm** | Agents **hand off** directly to each other | Customer support (triage → billing → tech) |
| **Agents as tools** | Main agent calls sub-agents like tools | Simple delegation, context isolation |

### What is MCP?

The **Model Context Protocol** is an open standard (from Anthropic, now widely adopted) for exposing **tools, resources, and prompts** to any LLM app. Think of it as **USB-C for AI tools**: write a tool server once, and Claude, Cursor, LangGraph, and other clients can all use it.

| MCP piece | Plain English |
|-----------|---------------|
| **Server** | Process exposing tools/resources (e.g. a GitHub MCP server) |
| **Client** | Your app/agent connecting to servers |
| **Transport** | `stdio` (local subprocess) or **Streamable HTTP** (remote) |
| **Tools / Resources / Prompts** | Callable functions / readable data / prompt templates |

---

## Code

### 1. Turn on LangSmith tracing

```bash
export LANGSMITH_TRACING=true
export LANGSMITH_API_KEY=lsv2_...
export LANGSMITH_PROJECT=multi-agent-course
```

Every graph run now shows up as a trace tree: nodes → LLM calls → tool calls, with tokens, latency, and inputs/outputs.

### 2. Supervisor with agents as tools (simple and robust)

```python
from langchain.agents import create_agent
from langchain.tools import tool

research_agent = create_agent("openai:gpt-4o-mini", tools=[web_search],
                              system_prompt="You research facts. Return concise findings.")
math_agent = create_agent("openai:gpt-4o-mini", tools=[multiply, add],
                          system_prompt="You solve math step by step.")

@tool
def ask_researcher(question: str) -> str:
    """Delegate factual research questions."""
    r = research_agent.invoke({"messages": [("user", question)]})
    return r["messages"][-1].content

@tool
def ask_math(problem: str) -> str:
    """Delegate arithmetic problems."""
    r = math_agent.invoke({"messages": [("user", problem)]})
    return r["messages"][-1].content

supervisor = create_agent("openai:gpt-4o", tools=[ask_researcher, ask_math],
                          system_prompt="Route sub-tasks to specialists, then synthesize.")
```

### 3. Handoffs with `Command` (swarm style)

```python
from typing import Literal
from langgraph.types import Command
from langgraph.graph import StateGraph, MessagesState, START

def triage(state: MessagesState) -> Command[Literal["billing", "tech", "__end__"]]:
    intent = classifier.invoke(state["messages"]).intent   # structured output
    return Command(goto=intent if intent in ("billing", "tech") else "__end__")

def billing(state: MessagesState) -> Command[Literal["triage"]]:
    reply = billing_agent.invoke(state)
    return Command(goto="triage", update={"messages": reply["messages"][-1:]})

g = StateGraph(MessagesState)
g.add_node("triage", triage); g.add_node("billing", billing); g.add_node("tech", tech)
g.add_edge(START, "triage")
app = g.compile()
```

Prebuilt helpers exist too: `langgraph-supervisor` (`create_supervisor`) and `langgraph-swarm` (`create_swarm`, `create_handoff_tool`).

### 4. Writing an MCP server (FastMCP)

```python
# math_server.py
from mcp.server.fastmcp import FastMCP
mcp = FastMCP("Math")

@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

if __name__ == "__main__":
    mcp.run(transport="stdio")          # or "streamable-http"
```

### 5. Using MCP tools in LangGraph

```python
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent

client = MultiServerMCPClient({
    "math":    {"command": "python", "args": ["math_server.py"], "transport": "stdio"},
    "weather": {"url": "http://localhost:8000/mcp", "transport": "streamable_http"},
})
tools = await client.get_tools()            # MCP tools -> LangChain tools
agent = create_agent("openai:gpt-4o-mini", tools)
await agent.ainvoke({"messages": [("user", "what's (3+5) and weather in NYC?")]})
```

---

## Deep dive

### Context isolation is the real win

Each sub-agent starts with a **clean context** (only its task), so the supervisor's context stays small. That's why "agents as tools" often beats sharing one message list: shared lists grow fast and confuse the model.

### MCP protocol under the hood

- JSON-RPC 2.0 messages: `initialize` → `tools/list` → `tools/call`.
- The server advertises **capabilities**, and the client converts tool JSON schemas into model tool definitions.
- Streamable HTTP supports sessions and server-sent events for progress notifications.
- Auth: OAuth 2.1 for remote servers, as defined in the MCP spec.

## Advanced

### MCP security (important!)

| Threat | What happens | Mitigation |
|--------|-------------|------------|
| **Tool poisoning** | Malicious tool *description* contains hidden instructions | Pin and review server versions, scan descriptions |
| **Rug pull** | Server changes tool behavior after you approved it | Version pinning, hash tool manifests |
| **Confused deputy / token passthrough** | Server uses your token for unintended APIs | Per-server scoped OAuth, no token passthrough |
| **Cross-server shadowing** | One server's tool description manipulates calls to another server | Separate agents per trust level |
| **Command injection in stdio servers** | Unsanitized args passed to shell | Run servers in containers/sandboxes |

### Multi-agent pitfalls

- **Telephone game:** information gets lost in each handoff. Pass structured artifacts, not paraphrases.
- **Cost explosion:** N agents × M turns. Add budgets per agent.
- **Infinite ping-pong** between agents: use `recursion_limit` and handoff counters.

## Production & scale

- Run remote MCP servers as **separate services** with their own auth, rate limits, and logs.
- Cache `tools/list` results, since listing on every request adds latency.
- In LangSmith, tag runs with `agent_name`, `tenant`, and `version` so you can filter per specialist.

## FAANG insights

- Anthropic's own multi-agent research system found that **orchestrator + parallel sub-agents** beat a single agent on breadth-first research tasks, at roughly **15× the tokens** of a chat. Only use multi-agent when the task value justifies it.
- Many teams prefer **"single agent + good tools"** until it clearly fails. Interviewers reward that restraint.
- MCP adoption at large companies usually goes through an **internal MCP registry** with security review, much like an internal package registry.

## Interview questions

1. **Supervisor vs swarm?** Central routing vs peer-to-peer handoffs. A supervisor is easier to control, and a swarm has lower latency per handoff.
2. **Why multi-agent at all?** Tool overload, context isolation, specialization, and parallelism.
3. **Name two MCP-specific attacks.** Tool poisoning and rug pulls (also token passthrough).

## Checklist

- [ ] Start with a single agent and split only when evals show a need
- [ ] Sub-agents get clean, minimal context
- [ ] MCP servers pinned, reviewed, sandboxed, and least-privilege
- [ ] Per-agent budgets + tracing tags
