# 20 — Memory Frameworks: Mem0 and LangMem

> **One sentence:** **Mem0** is a drop-in memory layer: `add()` conversations, and it extracts, deduplicates, and stores facts, then `search()` returns the relevant ones. **LangMem** is LangChain's toolkit of memory **tools and background managers** built on the LangGraph Store, covering semantic, episodic, and procedural memory.

## Lecture map

| Lecture | Covered in |
|---------|-----------|
| What is memory and why it's needed in LLM applications | Basics |
| Mem0 quick start explained | Code §1 |
| Mem0 core concepts explained | Deep dive (Mem0) |
| LangMem quick start explained | Code §3 |
| LangMem core concepts explained | Deep dive (LangMem) |

---

## Basics

| | Mem0 | LangMem |
|---|------|---------|
| Shape | Memory **service/SDK** (OSS + managed platform) | **Library** of primitives for LangGraph agents |
| Write | `m.add(messages, user_id=...)`, where an LLM extracts facts | Agent tools (`manage_memory`) or a background `MemoryManager` / reflection executor |
| Read | `m.search(query, user_id=...)` | `search_memory` tool / `store.search(namespace, query=...)` |
| Storage | Vector DB (Qdrant, Chroma, pgvector…) + optional graph (Neo4j) | LangGraph `BaseStore` (InMemory, Postgres) |
| Procedural memory | Limited | ✅ prompt optimizer |
| Best for | Any framework, quick personalization | LangGraph-native agents |

---

## Code

### 1. Mem0 quick start

```bash
uv add mem0ai
```

```python
from mem0 import Memory
m = Memory()     # defaults: OpenAI LLM + embeddings, local vector store

messages = [
    {"role": "user", "content": "Hi, I'm Kunal. I'm vegetarian and allergic to peanuts."},
    {"role": "assistant", "content": "Got it! I'll remember that."},
]
m.add(messages, user_id="kunal", metadata={"source": "onboarding"})

hits = m.search("What can I cook for dinner?", user_id="kunal", limit=5)
for h in hits["results"]:
    print(h["memory"], h["score"])
# "Is vegetarian", "Allergic to peanuts"

m.get_all(user_id="kunal")
m.update(memory_id=hits["results"][0]["id"], data="Vegan since 2025")
m.delete(memory_id=...); m.delete_all(user_id="kunal")     # GDPR
m.history(memory_id=...)                                     # audit trail of changes
```

Custom config (production-ish):

```python
config = {
    "llm": {"provider": "openai", "config": {"model": "gpt-4o-mini", "temperature": 0}},
    "embedder": {"provider": "openai", "config": {"model": "text-embedding-3-small"}},
    "vector_store": {"provider": "qdrant", "config": {"host": "localhost", "port": 6333,
                                                      "collection_name": "mem0"}},
    # "graph_store": {"provider": "neo4j", "config": {...}},   # relationships
}
m = Memory.from_config(config)
```

### 2. Mem0 in a chat loop

```python
def chat(user_id, msg):
    mems = m.search(msg, user_id=user_id, limit=5)["results"]
    mem_txt = "\n".join(f"- {x['memory']}" for x in mems)
    reply = llm.invoke([
        {"role": "system", "content": f"Known facts about user:\n{mem_txt}"},
        {"role": "user", "content": msg}]).content
    m.add([{"role": "user", "content": msg}, {"role": "assistant", "content": reply}], user_id=user_id)
    return reply
```

### 3. LangMem quick start (hot-path memory tools)

```bash
uv add langmem langgraph
```

```python
from langgraph.store.memory import InMemoryStore
from langgraph.prebuilt import create_react_agent
from langmem import create_manage_memory_tool, create_search_memory_tool

store = InMemoryStore(index={"dims": 1536, "embed": "openai:text-embedding-3-small"})

agent = create_react_agent(
    "openai:gpt-4o-mini",
    tools=[create_manage_memory_tool(namespace=("memories", "{user_id}")),
           create_search_memory_tool(namespace=("memories", "{user_id}"))],
    store=store,
)
cfg = {"configurable": {"user_id": "kunal"}}
agent.invoke({"messages": [("user", "Remember I prefer dark mode")]}, cfg)
agent.invoke({"messages": [("user", "What UI theme do I like?")]}, cfg)
```

`{user_id}` in the namespace is filled from config at runtime, which isolates each user.

### 4. LangMem background extraction (semantic memory with schemas)

```python
from pydantic import BaseModel
from langmem import create_memory_store_manager

class UserFact(BaseModel):
    subject: str
    predicate: str
    object: str

manager = create_memory_store_manager(
    "openai:gpt-4o-mini",
    namespace=("facts", "{user_id}"),
    schemas=[UserFact],
    instructions="Extract durable user preferences and facts. Ignore small talk.",
)
# after a conversation (or debounced via ReflectionExecutor):
await manager.ainvoke({"messages": conversation}, config=cfg)
```

### 5. LangMem procedural memory (prompt optimization)

```python
from langmem import create_prompt_optimizer

optimizer = create_prompt_optimizer("openai:gpt-4o", kind="metaprompt")
better_prompt = optimizer.invoke({
    "trajectories": [(conversation, {"feedback": "Too verbose; use bullet points"})],
    "prompt": current_system_prompt,
})
```

---

## Deep dive

### Mem0 core concepts

```mermaid
flowchart LR
  IN[New messages] --> EX[LLM: extract candidate facts]
  EX --> SR[Search similar existing memories]
  SR --> DEC{LLM decides per fact}
  DEC -->|ADD| V[(Vector store)]
  DEC -->|UPDATE| V
  DEC -->|DELETE| V
  DEC -->|NOOP| X[skip]
  V --> H[(History DB: audit)]
```

- **Two-phase pipeline:** extraction, then an **update phase** where the LLM compares new facts with existing ones and chooses ADD / UPDATE / DELETE / NOOP. That's how it avoids duplicates and handles contradictions ("moved to Bangalore" replaces "lives in Pune").
- **Scopes:** `user_id`, `agent_id`, `run_id` (session). Combine them for fine-grained memory.
- **Graph memory (Mem0g):** entities and relations in Neo4j/Memgraph for multi-hop questions ("Who is my manager's manager?").
- **Memory types:** mostly semantic/episodic facts. You can add custom categories and custom extraction prompts.

### LangMem core concepts

- **Store namespaces:** tuples like `("memories", user_id)`. Items are JSON + embeddings and searchable by semantic query and filters.
- **Hot path vs background:** tools let the agent manage memory while it runs, and `MemoryStoreManager` + `ReflectionExecutor` process conversations after the fact (debounced, so it runs once after the conversation goes idle).
- **Memory shapes:** **collections** (many small facts, unbounded) vs **profiles** (one schema-validated document that gets updated in place).
- **Procedural:** prompt optimizers (`metaprompt`, `gradient`, `prompt_memory`) learn instructions from feedback.

## Advanced

- **Extraction quality = memory quality.** Write explicit instructions about what counts as a durable fact, and test them with evals.
- **Contradictions and time:** store timestamps, prefer recency, and keep history for audits.
- **Retrieval budget:** limit memories injected (top 5–10) and drop low scores (a threshold).
- **Security:** memory writes from **tool outputs / documents** are an injection vector. Restrict writes to user-stated facts, or add a validation step.

## Production & scale

- Mem0: run the vector DB as a managed service, use a cheap LLM for extraction, and make `add()` **async / background** so chat latency isn't affected.
- LangMem: `AsyncPostgresStore` with pgvector, and index only the fields you search.
- Deletion: implement per-user purge across the vector store, history DB, graph, and caches.

## FAANG insights

- Personalization memory is **product-critical and privacy-critical**. Big products expose a "memory settings" page where users can view, edit, or delete memories, plus "temporary chat" modes. Design for that from day one.
- Interview: *"Mem0-style extraction vs storing raw chat history?"* Extraction is compact and handles updates and contradictions, but it's lossy and costs LLM calls. Raw history has full fidelity, but it's noisy and expensive to retrieve from. Many systems keep both.

## Interview questions

1. **How does Mem0 avoid duplicate memories?** An LLM update phase compares new facts with similar existing ones (ADD/UPDATE/DELETE/NOOP).
2. **LangMem profile vs collection?** One updatable structured doc vs many independent memory items.
3. **Why run memory extraction in the background?** To keep user-facing latency low and batch the extraction cost.

## Checklist

- [ ] Memories scoped by user (and agent/session when needed)
- [ ] Extraction prompt + evals
- [ ] Async/background writes
- [ ] Delete-all-for-user implemented
- [ ] Write-path injection defenses
