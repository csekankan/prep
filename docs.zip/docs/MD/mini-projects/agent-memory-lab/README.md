# Agent memory lab

A dependency-free version of the memory patterns behind LangGraph checkpoints, LangMem, and Mem0. It covers **short-term** strategies (buffer, sliding window, token buffer, running summary), a **namespaced long-term store** for semantic and episodic recall, and **Mem0-style fact reconciliation** (ADD / UPDATE / DELETE / NOOP with history). On top of those it adds **memory-poisoning defenses**, **memory routing**, **per-slot context budgets**, and **right-to-be-forgotten** deletes.

## Curriculum

| Topic | Markdown |
|-------|----------|
| Memory types (buffer through procedural) | [`19-agent-memory-patterns`](../../agentic-ai-security-llmops/19-agent-memory-patterns/detailed.md) |
| Mem0 and LangMem | [`20-mem0-langmem`](../../agentic-ai-security-llmops/20-mem0-langmem/detailed.md) |
| LangGraph checkpointer vs store | [`05-langgraph-fundamentals`](../../agentic-ai-security-llmops/05-langgraph-fundamentals/detailed.md) |
| Summarization middleware | [`04-langchain-middleware-guardrails`](../../agentic-ai-security-llmops/04-langchain-middleware-guardrails/detailed.md) |

## Quick start

```bash
cd MD/mini-projects/agent-memory-lab
pip install -e ".[dev]"
pytest -q
python scripts/demo.py
```

## What you practice

- **Trimming correctly:** windows and summaries never leave a `tool` message without its assistant tool call, because real providers reject that.
- **Contradictions:** "moved to Bangalore" replaces "lives in Pune" (an UPDATE), and the old value is kept in history for audits.
- **Isolation:** every item lives under a namespace such as `("memories", user_id)`, and empty namespaces are rejected.
- **Poisoning:** instruction-like text from documents, web pages, email, or tools is refused. Secrets are never stored, and procedural memory accepts only user feedback.
- **Budgets:** the system prompt, profile, episodes, and recent turns each get a token budget.
- **GDPR:** `delete_namespace` and `forget_user` purge a user from every store.

## Layout

```
src/agent_memory_lab/
  short_term.py    # BufferMemory, WindowMemory, TokenBufferMemory, SummaryMemory
  long_term.py     # MemoryStore (namespaced, similarity search)
  facts.py         # FactMemory: ADD/UPDATE/DELETE/NOOP + history
  write_policy.py  # validate_write (poisoning + secrets)
  router.py        # route(query) -> {recent, profile, episodic}
  assemble.py      # build_context with ContextBudget
  tokens.py        # rough token counter
```

## Exercises

1. Replace `FactMemory.decide` with an LLM call that returns ADD/UPDATE/DELETE/NOOP as structured output, keeping the tests as the contract.
2. Add time decay to `MemoryStore.search` (score × e^(−age/τ)) and a nightly consolidation job that merges near-duplicates.
3. Write a "knowledge retention" eval: plant a fact at turn 1, chat for 30 turns, and check whether the assembled context still contains it under each memory strategy.
