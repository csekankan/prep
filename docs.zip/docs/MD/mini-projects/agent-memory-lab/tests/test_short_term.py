from agent_memory_lab import BufferMemory, SummaryMemory, TokenBufferMemory, WindowMemory


def convo(mem, n):
    for i in range(n):
        mem.add("user", f"question {i}")
        mem.add("assistant", f"answer {i}")
    return mem


def test_buffer_keeps_everything():
    assert len(convo(BufferMemory(), 10).context()) == 20


def test_window_keeps_last_k():
    ctx = convo(WindowMemory(k=4), 10).context()
    assert [m["content"] for m in ctx] == ["question 8", "answer 8", "question 9", "answer 9"]


def test_window_never_starts_with_orphan_tool_message():
    mem = WindowMemory(k=3)
    mem.add("user", "weather?")
    mem.add("assistant", "", tool_calls=[{"name": "get_weather"}])
    mem.add("tool", "22C")
    mem.add("tool", "humid")
    mem.add("assistant", "22C and humid")
    assert mem.context()[0]["role"] != "tool"


def test_token_buffer_respects_budget():
    mem = TokenBufferMemory(max_tokens=40)
    for i in range(20):
        mem.add("user", "x" * 40)  # ~10 tokens + 4 overhead each
    assert len(mem.context()) == 2


def test_summary_memory_folds_old_messages():
    seen = []

    def summarizer(summary, msgs):
        seen.append(len(msgs))
        return (summary + " " + " ".join(m["content"] for m in msgs)).strip()

    mem = convo(SummaryMemory(summarizer=summarizer, trigger=6, keep=2), 5)
    ctx = mem.context()
    assert ctx[0]["role"] == "system" and "question 0" in ctx[0]["content"]
    assert len(mem.messages) <= 6 and mem.summarize_calls >= 1
    assert ctx[-1]["content"] == "answer 4"


def test_summary_does_not_split_tool_pairs():
    mem = SummaryMemory(summarizer=lambda s, m: "S", trigger=3, keep=2)
    mem.add("user", "q")
    mem.add("assistant", "", tool_calls=[{"name": "t"}])
    mem.add("tool", "r1")
    mem.add("tool", "r2")
    assert [m["role"] for m in mem.messages] == ["assistant", "tool", "tool"]
    assert mem.summary == "S"
