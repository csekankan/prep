# Guardrails pipeline lab

A dependency-free guardrails engine. It runs **input and output rails** around an LLM call, detects prompt injection **through obfuscation** (base64, rot13, leetspeak, character spacing, Cyrillic look-alikes, zero-width characters), and finds PII with **redact / mask / hash** strategies (Luhn-checked cards). It also has a topic-scope rail and a lexical **grounding** check, and implements the full Guardrails-AI-style **OnFailAction** semantics (exception, fix, filter, refrain, noop, reask).

## Curriculum

| Topic | Markdown |
|-------|----------|
| LangChain middleware guardrails | [`04-langchain-middleware-guardrails`](../../agentic-ai-security-llmops/04-langchain-middleware-guardrails/detailed.md) |
| NeMo input/output rails, PII | [`09`](../../agentic-ai-security-llmops/09-nemo-guardrails-basics/detailed.md), [`10`](../../agentic-ai-security-llmops/10-nemo-rails-hr-bot/detailed.md) |
| Guardrails AI OnFailAction | [`11-guardrails-ai`](../../agentic-ai-security-llmops/11-guardrails-ai/detailed.md) |
| Bedrock grounding, FP/FN tradeoff | [`12-aws-bedrock-guardrails`](../../agentic-ai-security-llmops/12-aws-bedrock-guardrails/detailed.md) |

## Quick start

```bash
cd MD/mini-projects/guardrails-pipeline-lab
pip install -e ".[dev]"
pytest -q
python scripts/demo.py
```

## What you practice

- **Why keyword filters fail:** `test_naive_detector_is_bypassed_by_base64` shows the bypass, and `normalize.views()` fixes it.
- **Validator ordering:** FIX output feeds the next validator, and REFRAIN or EXCEPTION short-circuits the rest.
- **Shadow mode:** NOOP records failures without enforcing them. This is how you roll out a new filter safely.
- **Bounded reask:** the guard re-prompts with the validation error and blocks once the budget runs out.
- **Measuring guards:** `evaluate_guard` reports attack block rate (recall) **and** false-positive rate on benign traffic.

## Layout

```
src/guardrails_lab/
  actions.py      # OnFailAction enum
  normalize.py    # decoded/normalized views of text
  validators.py   # PromptInjection, PIIDetector, TopicScope, MaxLength, Groundedness
  guard.py        # Guard: ordered validators + on_fail handling + reask loop
  pipeline.py     # GuardedApp (input -> LLM -> output), metrics, evaluate_guard
scripts/demo.py   # secured HR assistant
tests/
```

## Exercises

1. Add a `Validator` that calls a classifier model and returns its confidence, then compare its recall and FPR against `PromptInjection`.
2. Make `PromptInjection` work across turns, scoring the last N user messages together (this defends against Crescendo-style attacks).
3. Run the input validators in parallel threads and measure the latency difference.
