from collections.abc import Callable
from dataclasses import dataclass, field

from guardrails_lab.actions import OnFailAction
from guardrails_lab.validators import Validator


class GuardValidationError(Exception):
    def __init__(self, validator: str, reason: str):
        super().__init__(f"{validator}: {reason}")
        self.validator = validator
        self.reason = reason


@dataclass
class Failure:
    validator: str
    reason: str
    action: OnFailAction


@dataclass
class GuardOutcome:
    passed: bool
    output: str | None
    failures: list[Failure] = field(default_factory=list)
    reasks: int = 0

    @property
    def blocked(self) -> bool:
        return self.output is None


class _Reask(Exception):
    def __init__(self, reason: str):
        self.reason = reason


@dataclass
class Guard:
    """Runs validators in order. FIX/FILTER outputs feed the next validator; REFRAIN/EXCEPTION stop."""

    validators: list[Validator] = field(default_factory=list)

    def use(self, *validators: Validator) -> "Guard":
        self.validators.extend(validators)
        return self

    def _run(self, text: str, allow_reask: bool) -> GuardOutcome:
        current: str | None = text
        failures: list[Failure] = []
        for v in self.validators:
            res = v.validate(current)
            if res.passed:
                continue
            failures.append(Failure(v.name, res.reason, v.on_fail))
            match v.on_fail:
                case OnFailAction.EXCEPTION:
                    raise GuardValidationError(v.name, res.reason)
                case OnFailAction.REFRAIN:
                    return GuardOutcome(False, None, failures)
                case OnFailAction.FIX:
                    current = res.fix_value if res.fix_value is not None else current
                case OnFailAction.FILTER:
                    current = res.filter_value
                    if current is None:
                        return GuardOutcome(False, None, failures)
                case OnFailAction.REASK:
                    if allow_reask:
                        raise _Reask(f"{v.name}: {res.reason}")
                    return GuardOutcome(False, None, failures)
                case OnFailAction.NOOP:
                    pass
        enforced = [f for f in failures if f.action != OnFailAction.NOOP]
        return GuardOutcome(not enforced, current, failures)

    def validate(self, text: str) -> GuardOutcome:
        return self._run(text, allow_reask=False)

    def __call__(self, llm: Callable[[str], str], prompt: str, num_reasks: int = 1) -> GuardOutcome:
        """Call the LLM, validate, and on REASK failures re-prompt with the error (bounded)."""
        current_prompt = prompt
        for attempt in range(num_reasks + 1):
            raw = llm(current_prompt)
            try:
                outcome = self._run(raw, allow_reask=attempt < num_reasks)
                outcome.reasks = attempt
                return outcome
            except _Reask as r:
                current_prompt = (f"{prompt}\n\nYour previous answer failed validation ({r.reason}). "
                                  f"Previous answer:\n{raw}\nFix it.")
        raise AssertionError("unreachable")
