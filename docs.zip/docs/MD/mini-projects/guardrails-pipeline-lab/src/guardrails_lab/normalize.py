"""Produce decoded/normalized views of text so keyword detectors can't be bypassed by encoding."""

import base64
import binascii
import codecs
import re
import unicodedata

ZERO_WIDTH = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u2060\ufeff"), None)
LEET = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s"})
CONFUSABLES = str.maketrans({"а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "х": "x", "і": "i", "ѕ": "s"})
B64_TOKEN = re.compile(r"[A-Za-z0-9+/]{16,}={0,2}")


def _try_b64(token: str) -> str | None:
    try:
        raw = base64.b64decode(token + "=" * (-len(token) % 4), validate=True)
        text = raw.decode("utf-8")
    except (binascii.Error, UnicodeDecodeError, ValueError):
        return None
    return text if text.isprintable() else None


def collapse_spacing(text: str) -> str:
    """'i g n o r e' -> 'ignore' (character-spacing obfuscation)."""
    return re.sub(r"\b(?:\w ){3,}\w\b", lambda m: m.group(0).replace(" ", ""), text)


def views(text: str) -> list[str]:
    base = unicodedata.normalize("NFKC", text).translate(ZERO_WIDTH).translate(CONFUSABLES).lower()
    out = {base, base.translate(LEET), collapse_spacing(base), codecs.decode(base, "rot13")}
    for token in B64_TOKEN.findall(text):
        if decoded := _try_b64(token):
            out.add(decoded.lower())
    return list(out)
