import hashlib
import re
from dataclasses import dataclass, field

from guardrails_lab.actions import OnFailAction
from guardrails_lab.normalize import views


@dataclass
class ValidationResult:
    passed: bool
    reason: str = ""
    fix_value: str | None = None
    filter_value: str | None = None


@dataclass
class Validator:
    on_fail: OnFailAction = OnFailAction.EXCEPTION
    name: str = field(init=False, default="validator")

    def validate(self, text: str) -> ValidationResult:  # pragma: no cover - interface
        raise NotImplementedError


INJECTION_PATTERNS = [
    r"ignore (all |any )?(previous|prior|above) (instructions|rules)",
    r"disregard (the|your) (system|previous) (prompt|instructions)",
    r"(reveal|print|show|repeat) (me )?(your|the) (system prompt|hidden instructions|initial instructions)",
    r"you are now (dan|in developer mode)",
    r"pretend (you have|there are) no (rules|restrictions)",
    r"jailbreak",
]


@dataclass
class PromptInjection(Validator):
    """Pattern detector that runs over decoded views (base64, rot13, leetspeak, spacing, confusables)."""

    patterns: list[str] = field(default_factory=lambda: list(INJECTION_PATTERNS))
    normalize: bool = True

    def __post_init__(self) -> None:
        self.name = "prompt_injection"
        self._compiled = [re.compile(p) for p in self.patterns]

    def validate(self, text: str) -> ValidationResult:
        candidates = views(text) if self.normalize else [text.lower()]
        for view in candidates:
            for rx in self._compiled:
                if rx.search(view):
                    return ValidationResult(False, f"injection pattern: {rx.pattern}")
        return ValidationResult(True)


def _luhn_ok(number: str) -> bool:
    digits = [int(d) for d in re.sub(r"\D", "", number)][::-1]
    total = sum(d if i % 2 == 0 else (d * 2 - 9 if d * 2 > 9 else d * 2) for i, d in enumerate(digits))
    return len(digits) >= 13 and total % 10 == 0


PII_PATTERNS: dict[str, str] = {
    "EMAIL": r"[\w.+-]+@[\w-]+\.[\w.]+",
    "SSN": r"\b\d{3}-\d{2}-\d{4}\b",
    "CREDIT_CARD": r"\b(?:\d[ -]?){13,19}\b",
    "PHONE": r"(?<!\d)(?:\+?\d{1,3}[ .-]?)?(?:\(\d{3}\)|\d{3})[ .-]?\d{3}[ .-]?\d{4}(?!\d)",
    "API_KEY": r"\bsk-[A-Za-z0-9]{20,}\b",
}


@dataclass
class PIIDetector(Validator):
    """Detects PII; fix_value applies strategy: redact | mask | hash."""

    entities: list[str] = field(default_factory=lambda: list(PII_PATTERNS))
    strategy: str = "redact"

    def __post_init__(self) -> None:
        self.name = "pii"
        unknown = set(self.entities) - PII_PATTERNS.keys()
        if unknown:
            raise ValueError(f"unknown entities: {unknown}")
        if self.strategy not in {"redact", "mask", "hash"}:
            raise ValueError("strategy must be redact | mask | hash")

    def _replace(self, label: str, value: str) -> str:
        if self.strategy == "redact":
            return f"<{label}>"
        if self.strategy == "mask":
            keep = re.sub(r"\W", "", value)[-4:]
            return "*" * max(len(value) - 4, 0) + keep
        return f"<{label}:{hashlib.sha256(value.encode()).hexdigest()[:10]}>"

    def find(self, text: str) -> list[tuple[str, str]]:
        found = []
        for label in self.entities:
            for m in re.finditer(PII_PATTERNS[label], text):
                if label == "CREDIT_CARD" and not _luhn_ok(m.group(0)):
                    continue
                found.append((label, m.group(0)))
        return found

    def validate(self, text: str) -> ValidationResult:
        hits = self.find(text)
        if not hits:
            return ValidationResult(True)
        fixed = text
        for label, value in sorted(hits, key=lambda h: -len(h[1])):
            fixed = fixed.replace(value, self._replace(label, value))
        kept = [s for s in _sentences(text) if not any(v in s for _, v in hits)]
        return ValidationResult(False, f"PII found: {sorted({l for l, _ in hits})}",
                                fix_value=fixed, filter_value=" ".join(kept) or None)


@dataclass
class TopicScope(Validator):
    """Keep a domain bot on-topic: deny listed topics, require at least one allowed keyword."""

    allowed_keywords: list[str] = field(default_factory=list)
    denied_keywords: list[str] = field(default_factory=list)
    refusal: str = "I can only help with questions in my area."

    def __post_init__(self) -> None:
        self.name = "topic_scope"

    def validate(self, text: str) -> ValidationResult:
        low = text.lower()
        if hit := next((k for k in self.denied_keywords if k in low), None):
            return ValidationResult(False, f"denied topic: {hit}", fix_value=self.refusal)
        if self.allowed_keywords and not any(k in low for k in self.allowed_keywords):
            return ValidationResult(False, "off-topic", fix_value=self.refusal)
        return ValidationResult(True)


@dataclass
class MaxLength(Validator):
    max_chars: int = 2000

    def __post_init__(self) -> None:
        self.name = "max_length"

    def validate(self, text: str) -> ValidationResult:
        if len(text) <= self.max_chars:
            return ValidationResult(True)
        return ValidationResult(False, f"length {len(text)} > {self.max_chars}", fix_value=text[: self.max_chars])


STOP = set("a an the is are was were of to in on for and or with that this it be by as at from".split())


def _sentences(text: str) -> list[str]:
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]


def _content_words(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOP and len(w) > 2}


@dataclass
class Groundedness(Validator):
    """Lexical grounding check: each answer sentence must share enough content words with the context."""

    context: str = ""
    min_overlap: float = 0.5

    def __post_init__(self) -> None:
        self.name = "groundedness"

    def validate(self, text: str) -> ValidationResult:
        ctx = _content_words(self.context)
        sentences = _sentences(text)
        unsupported = []
        for s in sentences:
            words = _content_words(s)
            if words and len(words & ctx) / len(words) < self.min_overlap:
                unsupported.append(s)
        if not unsupported:
            return ValidationResult(True)
        supported = [s for s in sentences if s not in unsupported]
        return ValidationResult(False, f"{len(unsupported)}/{len(sentences)} sentences unsupported",
                                fix_value="I couldn't find that in the provided documents.",
                                filter_value=" ".join(supported) or None)
