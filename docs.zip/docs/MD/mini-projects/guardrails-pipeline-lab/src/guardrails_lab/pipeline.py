from collections import Counter
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field

from guardrails_lab.guard import Guard, GuardValidationError

BLOCKED_REPLY = "Sorry, I can't help with that request."


@dataclass
class GuardMetrics:
    requests: int = 0
    input_blocks: int = 0
    output_blocks: int = 0
    fixes: int = 0
    by_validator: Counter = field(default_factory=Counter)


@dataclass
class GuardedApp:
    """Input guard -> LLM -> output guard, with per-validator metrics."""

    llm: Callable[[str], str]
    input_guard: Guard
    output_guard: Guard
    metrics: GuardMetrics = field(default_factory=GuardMetrics)

    def _check(self, guard: Guard, text: str, stage: str) -> str | None:
        try:
            outcome = guard.validate(text)
        except GuardValidationError as e:
            self.metrics.by_validator[e.validator] += 1
            setattr(self.metrics, f"{stage}_blocks", getattr(self.metrics, f"{stage}_blocks") + 1)
            return None
        for f in outcome.failures:
            self.metrics.by_validator[f.validator] += 1
        if outcome.blocked:
            setattr(self.metrics, f"{stage}_blocks", getattr(self.metrics, f"{stage}_blocks") + 1)
        elif outcome.output != text:
            self.metrics.fixes += 1
        return outcome.output

    def ask(self, user_message: str) -> str:
        self.metrics.requests += 1
        safe_in = self._check(self.input_guard, user_message, "input")
        if safe_in is None:
            return BLOCKED_REPLY
        safe_out = self._check(self.output_guard, self.llm(safe_in), "output")
        return BLOCKED_REPLY if safe_out is None else safe_out


@dataclass
class GuardEval:
    attack_block_rate: float   # recall on attacks
    false_positive_rate: float  # benign messages wrongly blocked
    missed: list[str]
    false_positives: list[str]


def _is_blocked(guard: Guard, text: str) -> bool:
    try:
        return not guard.validate(text).passed
    except GuardValidationError:
        return True


def evaluate_guard(guard: Guard, attacks: Iterable[str], benign: Iterable[str]) -> GuardEval:
    attacks, benign = list(attacks), list(benign)
    missed = [a for a in attacks if not _is_blocked(guard, a)]
    fps = [b for b in benign if _is_blocked(guard, b)]
    return GuardEval(
        attack_block_rate=1 - len(missed) / len(attacks) if attacks else 1.0,
        false_positive_rate=len(fps) / len(benign) if benign else 0.0,
        missed=missed,
        false_positives=fps,
    )
