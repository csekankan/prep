from enum import Enum


class OnFailAction(str, Enum):
    """What a guard does when a validator fails (mirrors Guardrails AI semantics)."""

    EXCEPTION = "exception"  # raise, fail closed
    FIX = "fix"              # replace text with the validator's fix_value
    FILTER = "filter"        # drop the offending segments (or the whole value)
    REFRAIN = "refrain"      # return no output at all
    NOOP = "noop"            # record only (shadow mode)
    REASK = "reask"          # ask the LLM again with the error message
