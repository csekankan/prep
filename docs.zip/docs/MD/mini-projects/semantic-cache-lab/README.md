# Semantic cache lab

An in-memory version of the Redis/RedisVL caching stack for LLM apps. It covers the **exact cache** (hash of the full request), the **semantic cache** (embedding similarity), and the production rules that keep both safe: **tenant scoping**, **TTL**, **index-version invalidation**, **guardrail-gated writes**, **no shared caching of personal answers**, **single-flight stampede protection**, **daily token budgets**, and **threshold tuning** on labeled paraphrase pairs.

## Curriculum

| Topic | Markdown |
|-------|----------|
| Redis exact/semantic caching, rate and cost control | [`22-redis-for-ai`](../../agentic-ai-security-llmops/22-redis-for-ai/detailed.md) |
| Gateway caching (Portkey) | [`13-llm-gateways-portkey`](../../agentic-ai-security-llmops/13-llm-gateways-portkey/detailed.md) |
| Cache + access-level scoping in an HR bot | [`27-project-hr-hybrid-rag-gcp`](../../agentic-ai-security-llmops/27-project-hr-hybrid-rag-gcp/detailed.md) |

## Quick start

```bash
cd MD/mini-projects/semantic-cache-lab
pip install -e ".[dev]"
pytest -q
python scripts/demo.py
```

## What you practice

- **Key design:** `exact_key` includes the model, temperature, prompt version, tools, and **tenant**.
- **Similarity vs intent:** "cancel my order" and "cancel my subscription" look alike but must **miss**. `sweep_thresholds` shows the precision/recall tradeoff and counts **false hits** (wrong answers served).
- **Safety:** `is_safe` gates writes, so a poisoned or unsafe answer is never cached. `personal=True` scopes the exact cache to the user and skips the semantic cache entirely.
- **Concurrency:** ten simultaneous identical misses produce exactly **one** LLM call.
- **Cost:** `tokens_saved`, `hit_rate`, and `TokenBudget` provide denial-of-wallet protection.

## Layout

```
src/semantic_cache_lab/
  embed.py    # hashed bag-of-words embeddings (swap for a real model)
  cache.py    # ExactCache, SemanticCache, exact_key
  service.py  # CachedLLMService: exact -> semantic -> single-flight LLM -> safe write-back
  budget.py   # TokenBudget (per user per day)
  tune.py     # sweep_thresholds, pick_threshold
  clock.py    # FakeClock for TTL tests
```

## Exercises

1. Replace `embed` with a real embedding model, then re-run the sweep. How does the best threshold move?
2. Port `SemanticCache` to RedisVL `SemanticCache` with a `tenant` tag filter, keeping the tests green through an adapter.
3. Add LRU eviction with a max-entries cap and measure the effect on hit rate with Zipf-distributed traffic.
