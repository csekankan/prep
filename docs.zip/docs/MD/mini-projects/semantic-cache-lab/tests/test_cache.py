import threading
import time

import pytest

from semantic_cache_lab import (
    CachedLLMService,
    ExactCache,
    FakeClock,
    LLMResponse,
    SemanticCache,
    TokenBudget,
    cosine,
    embed,
    exact_key,
    sweep_thresholds,
)
from semantic_cache_lab.service import BudgetExceeded
from semantic_cache_lab.tune import pick_threshold


def make_service(clock=None, **kw):
    clock = clock or FakeClock()
    calls = []

    def llm(prompt):
        calls.append(prompt)
        return LLMResponse(f"answer to: {prompt}", tokens=100)

    svc = CachedLLMService(llm=llm, exact=ExactCache(ttl=60, clock=clock),
                           semantic=SemanticCache(threshold=0.8, ttl=60, clock=clock), **kw)
    return svc, calls, clock


def test_embedding_similarity_shape():
    assert cosine(embed("What is your refund policy?"), embed("How do refunds work?")) > 0.8
    assert cosine(embed("cancel my order"), embed("cancel my subscription")) < 0.8


def test_exact_key_includes_tenant_and_prompt_version():
    base = dict(model="m", messages=[{"role": "user", "content": "hi"}], temperature=0, prompt_version="v1")
    assert exact_key(**base, tenant="a") != exact_key(**base, tenant="b")
    assert exact_key(**base, tenant="a") != exact_key(**{**base, "prompt_version": "v2"}, tenant="a")


def test_exact_then_semantic_hits():
    svc, calls, _ = make_service()
    svc.ask("What is your refund policy?", tenant="acme", user="u1")
    svc.ask("What is your refund policy?", tenant="acme", user="u2")
    svc.ask("How do refunds work?", tenant="acme", user="u3")
    assert len(calls) == 1
    assert svc.stats.exact_hits == 1 and svc.stats.semantic_hits == 1
    assert svc.stats.tokens_saved > 0 and svc.stats.hit_rate == pytest.approx(2 / 3)


def test_different_intent_misses():
    svc, calls, _ = make_service()
    svc.ask("cancel my order", tenant="acme", user="u1")
    svc.ask("cancel my subscription", tenant="acme", user="u1")
    assert len(calls) == 2


def test_tenant_isolation():
    svc, calls, _ = make_service()
    svc.ask("What is your refund policy?", tenant="acme", user="u1")
    svc.ask("What is your refund policy?", tenant="globex", user="u9")
    assert len(calls) == 2


def test_personal_answers_never_shared():
    svc, calls, _ = make_service()
    svc.ask("What is my leave balance?", tenant="acme", user="alice", personal=True)
    svc.ask("What is my leave balance?", tenant="acme", user="bob", personal=True)
    svc.ask("What is my leave balance?", tenant="acme", user="alice", personal=True)
    assert len(calls) == 2
    assert len(svc.semantic) == 0


def test_ttl_expiry():
    svc, calls, clock = make_service()
    svc.ask("refund policy", tenant="acme", user="u1")
    clock.advance(61)
    svc.ask("refund policy", tenant="acme", user="u1")
    assert len(calls) == 2


def test_index_version_bump_invalidates():
    svc, calls, _ = make_service()
    svc.ask("refund policy", tenant="acme", user="u1")
    svc.index_version = "v2"
    svc.ask("refund policy", tenant="acme", user="u1")
    assert len(calls) == 2


def test_unsafe_responses_not_cached():
    svc, calls, _ = make_service(is_safe=lambda t: "refund" not in t)
    svc.ask("refund policy", tenant="acme", user="u1")
    svc.ask("refund policy", tenant="acme", user="u1")
    assert len(calls) == 2 and svc.stats.rejected_writes == 2


def test_single_flight_under_concurrency():
    clock = FakeClock()
    calls = []

    def slow_llm(prompt):
        calls.append(prompt)
        time.sleep(0.05)
        return LLMResponse("ok", 10)

    svc = CachedLLMService(llm=slow_llm, exact=ExactCache(clock=clock), semantic=SemanticCache(clock=clock))
    threads = [threading.Thread(target=svc.ask, args=("same question",), kwargs={"tenant": "t", "user": "u"})
               for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert len(calls) == 1


def test_token_budget_blocks_after_limit():
    svc, calls, _ = make_service(budget=TokenBudget(daily_limit=250, clock=FakeClock()), estimated_tokens=100)
    svc.ask("q one", tenant="t", user="u")
    svc.ask("q two different", tenant="t", user="u")
    with pytest.raises(BudgetExceeded):
        svc.ask("q three unrelated", tenant="t", user="u")
    assert svc.stats.budget_denials == 1


def test_threshold_sweep():
    pairs = [
        ("What is your refund policy?", "How do refunds work?", True),
        ("refund policy", "refunds policy please", True),
        ("cancel my order", "cancel my subscription", False),
        ("reset password", "change email address", False),
        ("delete my account", "delete my account photo", False),
    ]
    points = sweep_thresholds(pairs)
    loose, strict = points[0], points[-1]
    assert loose.false_hits >= 1 and strict.false_hits == 0
    best = pick_threshold(points, min_precision=1.0)
    assert best.false_hits == 0 and best.recall == 1.0 and best.threshold > loose.threshold
