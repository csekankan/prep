"""Support-bot traffic replay through exact + semantic caches, then a threshold sweep."""

from semantic_cache_lab import CachedLLMService, ExactCache, LLMResponse, SemanticCache, sweep_thresholds
from semantic_cache_lab.tune import pick_threshold


def llm(prompt: str) -> LLMResponse:
    return LLMResponse(f"[LLM] answer for '{prompt}'", tokens=420)


svc = CachedLLMService(llm=llm, exact=ExactCache(), semantic=SemanticCache(threshold=0.8))
traffic = [
    ("acme", "u1", "What is your refund policy?", False),
    ("acme", "u2", "What is your refund policy?", False),
    ("acme", "u3", "How do refunds work?", False),
    ("acme", "u4", "cancel my order", False),
    ("acme", "u5", "cancel my subscription", False),
    ("globex", "u6", "What is your refund policy?", False),
    ("acme", "u1", "What is my order status?", True),
]
for tenant, user, q, personal in traffic:
    before = svc.stats.llm_calls
    svc.ask(q, tenant=tenant, user=user, personal=personal)
    print(f"{tenant:7} {q:32} -> {'LLM' if svc.stats.llm_calls > before else 'CACHE'}")

s = svc.stats
print(f"\nhit rate {s.hit_rate:.0%}, llm calls {s.llm_calls}, tokens spent {s.tokens_spent}, saved {s.tokens_saved}")

pairs = [
    ("What is your refund policy?", "How do refunds work?", True),
    ("refund policy", "refunds policy please", True),
    ("cancel my order", "cancel my subscription", False),
    ("reset password", "change email address", False),
    ("shipping time to india", "how long does shipping to india take", True),
    ("delete my account", "delete my account photo", False),
    ("refund policy for shoes", "refund policy for electronics", False),
]
print("\nthreshold  precision  recall  false_hits")
points = sweep_thresholds(pairs)
for p in points:
    print(f"{p.threshold:9.2f}  {p.precision:9.2f}  {p.recall:6.2f}  {p.false_hits:10}")
print("pick:", pick_threshold(points, min_precision=1.0))
