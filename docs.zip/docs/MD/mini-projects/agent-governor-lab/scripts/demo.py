"""A scripted support agent whose tool calls are governed: allow, deny, hold for approval, kill switch."""

from agent_governor_lab import AuditLog, GovernedExecutor, Policy, PolicyEngine, RunState, User
from agent_governor_lab.sample import POLICY, make_tools

agent_user = User("alice", frozenset({"support"}))
lead = User("lena", frozenset({"support_lead"}))
gov = GovernedExecutor(make_tools(), PolicyEngine(Policy.from_dict(POLICY)), AuditLog())
run = RunState(agent_user)

# What an LLM might decide to call, including one injected "delete_account" step.
planned = [
    ("search_kb", {"query": "refund policy for damaged items"}),
    ("get_order", {"order_id": "A-1001"}),
    ("issue_refund", {"order_id": "A-1001", "amount": 249}),
    ("delete_account", {"user_id": "u-77"}),
    ("send_email", {"to": "customer@gmail.com", "body": "Your refund is on the way"}),
]

pending = []
for tool, args in planned:
    out = gov.execute(run, tool, args)
    print(f"{tool:15} -> {out.status:8} {out.content}")
    if out.approval_id:
        pending.append(out.approval_id)

print("\nHuman review:")
print("  approve refund ->", gov.approve(pending[0], lead).content)
print("  reject email   ->", gov.reject(pending[1], lead, "use the ticketing system for external mail").content)

print("\nIncident! Kill switch on issue_refund.")
gov.kill("issue_refund")
print("  issue_refund   ->", gov.execute(run, "issue_refund", {"order_id": "A-2", "amount": 5}).content)

print(f"\ndecisions: {dict(gov.decisions)}   run: {run.tool_calls} calls, ${run.cost_usd:.3f}")
print("audit chain valid:", gov.audit.verify())
print("kill-switch audit entry:", {k: v for k, v in gov.audit.entries("kill_switch")[-1].items() if k != "prev_hash"})
