import pytest

from agent_governor_lab import (
    ApprovalError,
    AuditLog,
    Condition,
    GovernedExecutor,
    Policy,
    PolicyEngine,
    PolicyError,
    RunState,
    User,
)
from agent_governor_lab.sample import POLICY, make_tools

AGENT = User("alice", frozenset({"support"}))
LEAD = User("lena", frozenset({"support_lead"}))
OTHER_SUPPORT = User("sam", frozenset({"support"}))


@pytest.fixture
def gov():
    return GovernedExecutor(make_tools(), PolicyEngine(Policy.from_dict(POLICY)), AuditLog())


def test_condition_language():
    assert Condition.parse("args.amount > 100").matches({"amount": 250})
    assert not Condition.parse("args.amount > 100").matches({"amount": 50})
    assert Condition.parse("args.to not_endswith @acme.com").matches({"to": "x@gmail.com"})
    assert Condition.parse("args.amount > 100").matches({})  # missing field = risky
    with pytest.raises(PolicyError):
        Condition.parse("__import__('os').system('rm -rf /')")


def test_policy_validation():
    with pytest.raises(PolicyError):
        Policy.from_dict({"tools": {"x": {"require_approval_if": "args.a > 1"}}})  # no approver_roles
    with pytest.raises(PolicyError):
        Policy.from_dict({"tools": {"x": {"rolez": ["typo"]}}})


def test_default_deny_and_explicit_deny(gov):
    run = RunState(AGENT)
    assert gov.execute(run, "drop_database", {}).status == "denied"
    out = gov.execute(run, "delete_account", {"user_id": "u1"})
    assert out.status == "denied" and "denied by policy" in out.content


def test_role_check(gov):
    guest = RunState(User("g", frozenset({"guest"})))
    assert gov.execute(guest, "search_kb", {"query": "returns"}).status == "ok"   # no roles = everyone
    assert gov.execute(guest, "get_order", {"order_id": "o1"}).status == "denied"


def test_small_refund_allowed_large_needs_approval(gov):
    run = RunState(AGENT)
    assert gov.execute(run, "issue_refund", {"order_id": "o1", "amount": 40}).status == "ok"
    out = gov.execute(run, "issue_refund", {"order_id": "o2", "amount": 400})
    assert out.status == "pending" and out.approval_id
    done = gov.approve(out.approval_id, LEAD)
    assert done.status == "ok" and "$400" in done.content


def test_separation_of_duties_and_approver_role(gov):
    out = gov.execute(RunState(LEAD), "issue_refund", {"order_id": "o3", "amount": 500})
    with pytest.raises(ApprovalError, match="separation of duties"):
        gov.approve(out.approval_id, LEAD)
    with pytest.raises(ApprovalError, match="lacks an approver role"):
        gov.approve(out.approval_id, OTHER_SUPPORT)


def test_approval_is_single_use_and_reject_works(gov):
    out = gov.execute(RunState(AGENT), "send_email", {"to": "cust@gmail.com", "body": "hi"})
    assert gov.reject(out.approval_id, LEAD, "external recipient").status == "denied"
    with pytest.raises(ApprovalError):
        gov.approve(out.approval_id, LEAD)
    internal = gov.execute(RunState(AGENT), "send_email", {"to": "ops@acme.com", "body": "hi"})
    assert internal.status == "ok"


def test_budgets(gov):
    run = RunState(AGENT)
    statuses = [gov.execute(run, "search_kb", {"query": str(i)}).status for i in range(7)]
    assert statuses == ["ok"] * 5 + ["denied"] * 2
    run2 = RunState(AGENT)
    results = [gov.execute(run2, "issue_refund", {"order_id": f"o{i}", "amount": 10}).status for i in range(6)]
    assert results.count("ok") == 5 and results[-1] == "denied"  # 5 x $0.01 = cost cap


def test_kill_switch_blocks_new_calls_and_pending_approvals(gov):
    run = RunState(AGENT)
    pending = gov.execute(run, "issue_refund", {"order_id": "o9", "amount": 999})
    gov.kill("issue_refund")
    assert gov.execute(run, "issue_refund", {"order_id": "o10", "amount": 5}).status == "denied"
    assert gov.approve(pending.approval_id, LEAD).status == "denied"  # re-checked at approval time
    gov.kill()
    assert gov.execute(run, "search_kb", {"query": "x"}).status == "denied"


def test_audit_chain_and_tamper_detection(gov):
    run = RunState(AGENT)
    gov.execute(run, "search_kb", {"query": "refund policy"})
    gov.execute(run, "issue_refund", {"order_id": "o1", "amount": 20})
    assert gov.audit.verify() == (True, None)
    gov.audit._entries[1]["tool"] = "something_else"
    ok, bad = gov.audit.verify()
    assert not ok and bad == 1


def test_audit_redacts_sensitive_args(gov):
    gov.tools["charge_card"] = lambda card_number, email: "charged"
    gov.policy.tools["charge_card"] = gov.policy.tools["search_kb"]
    gov.execute(RunState(AGENT), "charge_card", {"card_number": "4111111111111111", "email": "a@b.com"})
    logged = gov.audit.entries("tool_executed")[-1]["args"]
    assert "4111" not in str(logged) and "a@b.com" not in str(logged)
    assert logged["card_number"].startswith("sha256:")


def test_every_entry_carries_policy_version(gov):
    gov.execute(RunState(AGENT), "search_kb", {"query": "x"})
    assert all(e["policy_version"] == POLICY["version"] for e in gov.audit.entries("decision"))
