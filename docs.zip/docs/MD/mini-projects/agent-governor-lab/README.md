# Agent governor lab

A governance layer for agent tool calls. A **policy decision point** reads a reviewable policy dict and returns allow, deny, or require-approval. A **policy enforcement point** wraps every tool call. Around those, the lab covers **default deny**, **role checks**, **human-in-the-loop approvals** with **separation of duties**, **re-checking policy at approval time**, **per-run call and cost budgets**, a **kill switch** (per tool or global), and an **append-only hash-chained audit log** with argument redaction and a policy version on every entry.

## Curriculum

| Topic | Markdown |
|-------|----------|
| AI governance and the governor pattern | [`30-ai-governance`](../../agentic-ai-security-llmops/30-ai-governance/detailed.md) |
| HITL middleware, `wrap_tool_call` | [`04-langchain-middleware-guardrails`](../../agentic-ai-security-llmops/04-langchain-middleware-guardrails/detailed.md) |
| Excessive agency, least privilege | [`01-intro-genai-security-architecture`](../../agentic-ai-security-llmops/01-intro-genai-security-architecture/detailed.md) |

## Quick start

```bash
cd MD/mini-projects/agent-governor-lab
pip install -e ".[dev]"
pytest -q
python scripts/demo.py
```

## What you practice

- **Code enforces, prompts don't.** The refund cap lives in policy (`args.amount > 100`), not in the system prompt.
- **A safe condition language.** The policy uses a small parser rather than `eval`, and missing fields count as risky.
- **Denials go back to the model.** A denied call returns a message (like a `ToolMessage`), so the agent can recover instead of crashing.
- **Time-of-check vs time-of-use.** An approval granted after a kill switch or budget change is re-checked and denied.
- **Forensics.** `AuditLog.verify()` pinpoints the first tampered entry, and card numbers and emails are fingerprinted rather than stored.

## Layout

```
src/agent_governor_lab/
  policy.py    # Policy.from_dict, Condition (safe mini-language), validation
  engine.py    # PolicyEngine.decide -> ALLOW / DENY / REQUIRE_APPROVAL
  governor.py  # GovernedExecutor: execute, approve, reject, kill
  audit.py     # hash-chained AuditLog, redaction
  sample.py    # support-agent policy + tools
```

## Exercises

1. Wire `GovernedExecutor.execute` into a LangChain v1 `@wrap_tool_call` middleware, and route `pending` outcomes to `HumanInTheLoopMiddleware`.
2. Load the policy from YAML and add a CI test that fails if any tool lacks an explicit rule.
3. Ship audit entries to a write-once (WORM) sink and anchor the latest hash somewhere external, such as a daily signed digest.
