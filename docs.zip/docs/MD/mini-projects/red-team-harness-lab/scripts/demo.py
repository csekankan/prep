"""Run the default suite against three versions of the HR bot and compare attack success rates."""

from redteam_lab import run_suite
from redteam_lab.runner import TARGETS
from redteam_lab.suite import default_suite

print(f"{'target':12} {'ASR':>6}   by category")
for name in ("vulnerable", "naive", "strong"):
    r = run_suite(TARGETS[name], default_suite())
    cats = ", ".join(f"{k}={v:.0%}" for k, v in r.breakdown("category").items())
    print(f"{name:12} {r.asr:6.0%}   {cats}")

naive = run_suite(TARGETS["naive"], default_suite())
print("\nNaive keyword filter, ASR by converter (encoding bypasses):")
for k, v in naive.breakdown("converter").items():
    print(f"  {k:12} {v:.0%}")

print("\nExample successful attacks against the naive filter:")
for a in [a for a in naive.attempts if a.success][:4]:
    print(f"  [{a.category}/{a.converter}] {a.prompt[:50]!r} -> {a.response[:60]!r}")
