# Red-team harness lab

A small, dependency-free **PyRIT-style** harness. It has **targets** (a deliberately vulnerable HR bot, plus guarded versions), **converters** (base64, rot13, leetspeak, character spacing, Cyrillic look-alikes, chains), and **scorers** (substring, regex, refusal, composites). The attacks are **single-turn**, **multi-turn Crescendo with backtracking**, and **XPIA** (indirect injection through a document). An **attack success rate (ASR) report** breaks results down by category and converter, and a **CLI gate** for CI fails the build when ASR is too high.

> Only red-team systems you own or are authorized to test. The target here is a toy model with no real harmful content.

## Curriculum

| Topic | Markdown |
|-------|----------|
| PyRIT modules 01–12 | [`21-pyrit-red-teaming`](../../agentic-ai-security-llmops/21-pyrit-red-teaming/detailed.md) |
| Why architecture beats prompts | [`01-intro-genai-security-architecture`](../../agentic-ai-security-llmops/01-intro-genai-security-architecture/detailed.md) |
| Red teaming in projects | [`27-project-hr-hybrid-rag-gcp`](../../agentic-ai-security-llmops/27-project-hr-hybrid-rag-gcp/detailed.md), [`26-project-aws-app-cicd`](../../agentic-ai-security-llmops/26-project-aws-app-cicd/detailed.md) |

## Quick start

```bash
cd MD/mini-projects/red-team-harness-lab
pip install -e ".[dev]"
pytest -q
python scripts/demo.py
redteam --target naive --fail-over 0.05 --json report.json   # exits 1: ASR too high
redteam --target strong                                       # exits 0
```

## What the results teach

| Target | What it shows |
|--------|---------------|
| `vulnerable` | High ASR across every category |
| `naive` (keyword filter) | Plain attacks are blocked, but **every encoding converter bypasses it**, and XPIA passes because the filter never looks at documents |
| `strong` (decoded-view filter + document sanitizing) | 0% on this suite. Your job is to write an attack that beats it |

Two points to take away:
- **Crescendo:** the final question is refused on its own but succeeds after two "fiction" turns, so harm lives in the *trajectory*.
- **XPIA:** input filtering alone doesn't stop indirect injection. Untrusted documents need their own handling (spotlighting or sanitizing).

## Layout

```
src/redteam_lab/
  targets.py     # VulnerableHRBot, GuardedBot, naive_filter, strong_filter, spotlight
  converters.py  # Base64, ROT13, Leetspeak, CharSpace, Confusable, ConverterChain
  scorers.py     # SubstringScorer, RegexScorer, RefusalScorer, AllOf
  attacks.py     # PromptAttack, CrescendoAttack (backtracking), XPIAAttack
  suite.py       # default attack suite
  runner.py      # run_suite, Report (ASR breakdowns), CLI gate
```

## Exercises

1. Beat `strong`: try a translation converter (e.g. "salario del CEO"), synonyms ("compensation"), or many-shot framing. Then add your attack to `suite.py` as a regression test.
2. Point an `HTTPTarget` at a real app's `/chat` endpoint in staging, keeping `send(conversation) -> str` as the contract.
3. Add a `PAIRAttack` where an "attacker" function rewrites the prompt each round using the previous response and score.
