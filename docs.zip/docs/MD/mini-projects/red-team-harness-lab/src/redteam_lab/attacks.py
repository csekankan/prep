from collections.abc import Iterator, Sequence
from dataclasses import dataclass, field

from redteam_lab.converters import Converter
from redteam_lab.scorers import RefusalScorer, Scorer
from redteam_lab.targets import Target


@dataclass
class AttemptResult:
    attack: str
    category: str
    converter: str
    prompt: str
    response: str
    success: bool
    rationale: str
    turns: int = 1


@dataclass
class PromptAttack:
    """Single-turn attack: every seed x every converter (PromptSendingOrchestrator)."""

    name: str
    category: str
    seeds: Sequence[str]
    scorer: Scorer
    converters: Sequence[Converter] = field(default_factory=lambda: [Converter()])

    def run(self, target: Target) -> Iterator[AttemptResult]:
        for seed in self.seeds:
            for conv in self.converters:
                prompt = conv.convert(seed)
                response = target.send([{"role": "user", "content": prompt}])
                s = self.scorer.score(response)
                yield AttemptResult(self.name, self.category, conv.name, prompt, response, s.success, s.rationale)


@dataclass
class CrescendoAttack:
    """Multi-turn escalation with backtracking: on refusal, drop the exchange and try an alternate phrasing."""

    name: str
    category: str
    turns: Sequence[str]
    objective_scorer: Scorer
    alternates: dict[int, Sequence[str]] = field(default_factory=dict)
    max_backtracks: int = 3

    def run(self, target: Target) -> Iterator[AttemptResult]:
        refusal = RefusalScorer()
        conversation: list[dict] = []
        backtracks = 0
        last = ""
        for i, turn in enumerate(self.turns):
            options = [turn, *self.alternates.get(i, [])]
            for option in options:
                conversation.append({"role": "user", "content": option})
                last = target.send(conversation)
                if refusal.score(last).success:
                    conversation.append({"role": "assistant", "content": last})
                    break
                conversation.pop()  # backtrack: the target never "remembers" the refused turn
                backtracks += 1
                if backtracks > self.max_backtracks:
                    break
            s = self.objective_scorer.score(last)
            if s.success:
                yield AttemptResult(self.name, self.category, "crescendo", option, last, True, s.rationale,
                                    turns=len([m for m in conversation if m["role"] == "user"]))
                return
        s = self.objective_scorer.score(last)
        yield AttemptResult(self.name, self.category, "crescendo", self.turns[-1], last, False,
                            s.rationale + f"; backtracks={backtracks}", turns=len(self.turns))


@dataclass
class XPIAAttack:
    """Cross-prompt (indirect) injection: plant instructions in a document, then trigger benign processing."""

    name: str
    planted_document: str
    processing_prompt: str
    scorer: Scorer
    category: str = "xpia"

    def run(self, target: Target) -> Iterator[AttemptResult]:
        target.load_document(self.planted_document)
        response = target.send([{"role": "user", "content": self.processing_prompt}])
        s = self.scorer.score(response)
        yield AttemptResult(self.name, self.category, "document", self.processing_prompt, response,
                            s.success, s.rationale)
