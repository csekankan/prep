"""Prompt converters: transform an attack prompt before sending (PyRIT PromptConverter equivalents)."""

import base64
import codecs
from dataclasses import dataclass


class Converter:
    name = "identity"

    def convert(self, prompt: str) -> str:
        return prompt


class Base64Converter(Converter):
    name = "base64"

    def convert(self, prompt: str) -> str:
        return base64.b64encode(prompt.encode()).decode()


class ROT13Converter(Converter):
    name = "rot13"

    def convert(self, prompt: str) -> str:
        return codecs.encode(prompt, "rot13")


class LeetspeakConverter(Converter):
    name = "leetspeak"
    TABLE = str.maketrans({"a": "4", "e": "3", "i": "1", "o": "0", "s": "5", "t": "7"})

    def convert(self, prompt: str) -> str:
        return prompt.lower().translate(self.TABLE)


class CharSpaceConverter(Converter):
    name = "char_space"

    def convert(self, prompt: str) -> str:
        return "  ".join(" ".join(word) for word in prompt.split())


class ConfusableConverter(Converter):
    """Swap Latin letters for visually identical Cyrillic ones."""

    name = "confusable"
    TABLE = str.maketrans({"a": "а", "e": "е", "o": "о", "p": "р", "c": "с"})

    def convert(self, prompt: str) -> str:
        return prompt.translate(self.TABLE)


@dataclass
class ConverterChain(Converter):
    converters: tuple[Converter, ...]

    @property
    def name(self) -> str:  # type: ignore[override]
        return "+".join(c.name for c in self.converters)

    def convert(self, prompt: str) -> str:
        for c in self.converters:
            prompt = c.convert(prompt)
        return prompt
