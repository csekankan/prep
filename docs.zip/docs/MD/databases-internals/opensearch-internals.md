# OpenSearch Internals: Write Path, Search Path & Tuning

How a document gets in, how a query gets answered, and which knobs trade latency, throughput, durability, and freshness. Everything here applies to Elasticsearch too unless marked **OpenSearch-only**.

> **Unifying idea:** Every write lands in **two places** — a fast volatile buffer (for search) and a durable translog (for safety). Every search **fans out to all shards** unless routing narrows it. Almost every config is a trade between those two facts.

---

## Part 1: Building Blocks

### Cluster block diagram

```mermaid
flowchart TB
  Client[Client / SDK]
  subgraph Cluster
    direction TB
    CM[Cluster manager node<br/>cluster state, shard allocation]
    subgraph Coord[Coordinating role]
      CO[Coordinating node<br/>routes, scatters, merges]
    end
    subgraph DataNodes[Data nodes]
      direction LR
      subgraph N1[Node 1]
        P0[(Primary 0)]
        R1[(Replica 1)]
      end
      subgraph N2[Node 2]
        P1[(Primary 1)]
        R2[(Replica 2)]
      end
      subgraph N3[Node 3]
        P2[(Primary 2)]
        R0[(Replica 0)]
      end
    end
  end
  Client --> CO
  CM -.cluster state.-> CO
  CM -.cluster state.-> DataNodes
  CO --> N1
  CO --> N2
  CO --> N3
```

| Term | Meaning |
|------|---------|
| **Index** | Logical collection, split into N primary shards |
| **Shard** | One Lucene index; the unit of distribution and parallelism |
| **Replica** | Full copy of a primary on a different node; serves reads, takes over on failure |
| **Segment** | Immutable mini-index inside a shard; a shard = many segments |
| **Routing** | `shard = hash(_routing) % number_of_shards` (default `_routing = _id`) |

### Inside one shard

```
 ┌──────────────────────────── Shard (Lucene index) ────────────────────────────┐
 │                                                                              │
 │  JVM heap                  OS page cache                     Disk            │
 │  ┌───────────────┐        ┌───────────────────────┐        ┌──────────────┐  │
 │  │ Indexing      │refresh │ seg_4 (new, unsynced) │ flush  │ seg_1..seg_3 │  │
 │  │ buffer        │──────► │ searchable            │──────► │ committed    │  │
 │  │ NOT searchable│        └───────────────────────┘        └──────────────┘  │
 │  │ NOT durable   │                                         ┌──────────────┐  │
 │  └───────────────┘                                         │ translog     │  │
 │        ▲                                                   │ fsynced      │  │
 │        └────────── replay on crash ─────────────────────── │ per request  │  │
 │                                                            └──────────────┘  │
 └──────────────────────────────────────────────────────────────────────────────┘
```

### Inside one segment

```
 Internal doc# (0,1,2...) — local integers, not your _id
   ├─ Inverted index   field:term → [doc#...]      (search / filter)
   │     city:pune  → [0, 1]
   │     _id:"5"    → [1]                          (_id is just another term)
   ├─ Stored fields    doc# → _source JSON         (fetch phase)
   ├─ Doc values       doc# → column value         (sort / aggs, on disk, columnar)
   └─ Live-docs bitmap doc# → deleted?             (updates = delete + re-add)
```

### Durability ladder

| Layer | Fast | Searchable | Survives process crash | Survives power loss |
|-------|:----:|:----------:|:----------------------:|:-------------------:|
| Indexing buffer (heap) | ✓ | ✗ | ✗ | ✗ |
| Segment after refresh (page cache) | ✓ | ✓ | ✓ | ✗ |
| Translog after fsync | ✓ | ✗ | ✓ | ✓ |
| Segment after flush (fsync) | — | ✓ | ✓ | ✓ |

---

## Part 2: Write Path

### Block view

```mermaid
flowchart LR
  C[Client] --> CO[Coordinating node]
  CO -->|"hash(_id) % N"| P[Primary shard]
  P --> B[Indexing buffer]
  P --> T[(Translog)]
  P -->|forward op| R[Replica shards]
  B -->|refresh| S[Searchable segment]
  S -->|merge| M[Bigger segments]
  S -->|flush| D[(Committed on disk)]
```

### Step-by-step flow

```mermaid
sequenceDiagram
  participant C as Client
  participant CO as Coordinating node
  participant P as Primary shard
  participant R as Replica shard
  C->>CO: PUT /idx/_doc/5
  CO->>CO: optional ingest pipeline
  CO->>CO: shard = hash("5") % 3 → 1
  CO->>P: route to primary 1
  P->>P: check wait_for_active_shards
  P->>P: analyze text → terms
  P->>P: 1. index into Lucene buffer
  P->>P: 2. append translog, fsync
  P->>R: 3. forward op (with seq#)
  R->>R: buffer + translog fsync
  R-->>P: ack
  P-->>CO: ack
  CO-->>C: 201 Created
  Note over P,R: later: refresh (1s) → searchable<br/>later: flush → segments fsynced, translog trimmed<br/>background: merge small segments
```

### Timeline of one document

```
 t=0        write → buffer + translog(fsync) → ack     durable, NOT searchable
 t≤1s       refresh → new segment in page cache        searchable, segment not fsynced
 minutes    merge → small segments combined            deleted docs physically purged
 ~512MB tl  flush → Lucene commit (fsync), new translog generation
```

### Update and delete

```
 UPDATE doc 5
   1. GET current doc (real-time, from shard)
   2. apply change
   3. mark old doc# deleted (live-docs bitmap)
   4. index new version → new doc# in buffer
   → space reclaimed only when the old segment is merged
```

### Bulk write path

```mermaid
flowchart LR
  B[_bulk: 5000 docs] --> CO[Coordinating node]
  CO -->|group by shard| S0[shard 0 batch]
  CO -->|group by shard| S1[shard 1 batch]
  CO -->|group by shard| S2[shard 2 batch]
  S0 --> A[Per-item results<br/>partial failure possible]
  S1 --> A
  S2 --> A
```

One translog fsync per shard-batch, not per document. That's why bulk is far faster than single-document writes.

---

## Part 3: Search Path

### Block view

```mermaid
flowchart LR
  C[Client] --> CO[Coordinating node]
  CO -->|query| S0[Shard 0 copy]
  CO -->|query| S1[Shard 1 copy]
  CO -->|query| S2[Shard 2 copy]
  S0 -->|top-K doc#s + scores| CO
  S1 -->|top-K doc#s + scores| CO
  S2 -->|top-K doc#s + scores| CO
  CO -->|fetch winners only| F[Shards holding winners]
  F -->|_source| CO
  CO --> C
```

### Query-then-fetch flow

```mermaid
sequenceDiagram
  participant C as Client
  participant CO as Coordinating node
  participant S0 as Shard 0
  participant S1 as Shard 1
  participant S2 as Shard 2
  C->>CO: search city=Pune AND brand=Nike AND color=red, size=10
  Note over CO: pick one copy per shard<br/>(adaptive replica selection / preference)
  Note over CO: can_match pre-filter may skip shards<br/>(e.g. time range outside shard's min/max)
  par QUERY phase
    CO->>S0: query
    CO->>S1: query
    CO->>S2: query
  end
  S0-->>CO: top 10 (doc#, score)
  S1-->>CO: top 10 (doc#, score)
  S2-->>CO: [] early exit
  Note over CO: merge 30 candidates → global top 10
  par FETCH phase
    CO->>S0: fetch doc#s
    CO->>S1: fetch doc#s
  end
  S0-->>CO: _source
  S1-->>CO: _source
  CO-->>C: hits
```

### What each shard does in the query phase

```mermaid
flowchart TD
  Q[Parse query] --> F{Filter context?}
  F -->|yes| QC[Check node query cache<br/>bitset per segment]
  F -->|no, scoring| SC[Score with BM25]
  QC --> I[Intersect posting lists<br/>rarest term first, skip lists]
  SC --> I
  I --> SEG[Repeat per segment<br/>sequential, or concurrent in OpenSearch]
  SEG --> TOP[Keep top size+from in a priority queue]
  TOP --> AGG[Compute aggregations<br/>from doc values]
  AGG --> OUT[Return doc#s, scores, partial aggs]
```

Worked example with 3 field values on 3 shards:

```
 Shard 0:  pune[1,4] ∩ nike[1,4] ∩ red[1]    = [1]
 Shard 1:  pune[2,5] ∩ nike[5]   ∩ red[2,5]  = [5]
 Shard 2:  pune[]  → stop                     = []
 Coordinator merges → [1, 5] → fetch _source from shard 0 and shard 1
```

`city:pune` lives in two shards because docs are routed by `_id`, not by field value. So every shard must be asked.

### GET vs search

```
 GET /idx/_doc/5         hash("5") % 3 → 1 shard → lookup _id term → _source
                         real-time (sees unrefreshed docs), no scoring

 _mget [1,5,6]           group ids by shard → one request per shard

 _search ids:[5]         still a search → ALL shards → only sees refreshed docs
```

### Deep pagination

```
 from=10000, size=10 on 5 shards
   each shard returns 10010 candidates → coordinator sorts 50050 → keeps 10
   cost grows with from × shards  →  use search_after + PIT instead
```

---

## Part 4: Configuration and Performance Impact

### Where each knob acts

```mermaid
flowchart LR
  subgraph Index time
    A1[number_of_shards]
    A2[routing]
    A3[mappings]
  end
  subgraph Write path
    B1[index_buffer_size]
    B2[translog.durability]
    B3[refresh_interval]
    B4[wait_for_active_shards]
    B5[number_of_replicas]
  end
  subgraph Background
    C1[merge policy]
    C2[flush_threshold_size]
  end
  subgraph Search path
    D1[caches]
    D2[max_result_window]
    D3[track_total_hits]
    D4[preference]
    D5[concurrent segment search]
  end
```

### Shard and replica layout

| Setting | Default | What it does | Performance impact |
|---------|---------|--------------|--------------------|
| `index.number_of_shards` | 1 | Number of primaries. **Fixed at creation** (change via `_split`, `_shrink`, reindex) | More shards = more write parallelism, but each search fans out wider and each shard costs heap. Aim for roughly 10–50 GB per shard |
| `index.number_of_replicas` | 1 | Copies per primary. Changeable live | More replicas = more read throughput and HA, but every write is repeated on each copy. Set to 0 during a one-off bulk load, restore after |
| `_routing` / `index.routing_partition_size` | `_id` | Which field decides the shard | Routing by tenant or user → queries hit 1 shard instead of N. Risk: hot shards. `routing_partition_size` spreads one key over a few shards |
| `index.routing.allocation.total_shards_per_node` | unbounded | Max shards of this index on one node | Prevents two hot primaries landing on the same node |

### Write freshness and durability

| Setting | Default | What it does | Performance impact |
|---------|---------|--------------|--------------------|
| `index.refresh_interval` | `1s` | How often buffer → searchable segment | Lower = fresher search, more tiny segments, more merge CPU. `30s` can roughly double ingest throughput. `-1` disables (bulk loads) |
| `?refresh=` (per request) | `false` | `true` forces a refresh now; `wait_for` blocks until the next one | `true` in a hot path creates a segment per request — very expensive. Prefer `wait_for` |
| `index.translog.durability` | `request` | `request` = fsync before ack. `async` = fsync on a timer | `async` cuts write latency, but up to `sync_interval` of acked writes can be lost on a crash |
| `index.translog.sync_interval` | `5s` | fsync period when `async` | Bigger = faster, larger loss window |
| `index.translog.flush_threshold_size` | `512mb` | Translog size that triggers a flush | Bigger = fewer expensive flushes, but slower crash recovery (more to replay) |
| `indices.memory.index_buffer_size` | `10%` of heap | Node-wide indexing buffer shared by active shards | Too small → forced early refreshes and tiny segments. Raise for ingest-heavy nodes |
| `wait_for_active_shards` | `1` (primary only) | Copies that must be up before a write starts | Higher = safer against writing to a lone copy, but writes fail or stall when replicas are down. Does **not** mean "acked by N copies" |

### Merging

| Setting | Default | What it does | Performance impact |
|---------|---------|--------------|--------------------|
| `index.merge.policy.segments_per_tier` | `10` | Segments allowed per size tier before merging | Lower = fewer segments (faster search), more merge I/O |
| `index.merge.policy.max_merged_segment` | `5gb` | Largest segment produced by natural merges | Bigger segments = faster search on read-mostly data |
| `index.merge.scheduler.max_thread_count` | based on CPUs | Concurrent merge threads per shard | Set to `1` on spinning disks; leave default on SSD |
| `_forcemerge?max_num_segments=1` | — | Manual merge to N segments | Great for **read-only** indices (old log days). Never on indices still being written |

### Search-side

| Setting | Default | What it does | Performance impact |
|---------|---------|--------------|--------------------|
| `indices.queries.cache.size` | `10%` heap | Node query cache: filter-clause bitsets per segment | Put non-scoring clauses in `filter`, not `must`, so they're cacheable |
| `indices.requests.cache.size` + `index.requests.cache.enable` | `1%` heap, on | Shard request cache: whole shard results, by default only `size=0` (aggregation) requests | Dashboards with repeated aggs get near-free. Invalidated on every refresh, so it helps less with `1s` refresh |
| `index.max_result_window` | `10000` | Max `from + size` | Raising it allows deep pages that cost memory on every shard. Use `search_after` + point-in-time |
| `track_total_hits` (per request) | `10000` | Stop counting matches after N | `true` forces an exact count over every match — slow on large indices. `false` is fastest |
| `preference` (per request) | adaptive replica selection | Which shard copy serves the query | `_local`, or a fixed string per user, improves cache hit rate and gives consistent pagination |
| `search.max_buckets` | `65535` | Cap on aggregation buckets | Guards the heap against runaway `terms` aggs |
| `thread_pool.search.queue_size` | `1000` | Pending searches per node before rejecting (HTTP 429) | Bigger queue hides overload as latency instead of rejecting. Fix the load, don't just raise it |
| `thread_pool.write.queue_size` | `10000` | Pending write batches per node | Same: 429s on bulk mean back off and retry, not raise the limit |

### Mapping choices that change performance

| Choice | Effect |
|--------|--------|
| `dynamic: strict` | Stops mapping explosion (thousands of fields → heap and cluster-state bloat) |
| `keyword` vs `text` | `keyword` = exact match, sort, aggs. `text` = analyzed full-text. Use multi-fields for both |
| `index: false` on a field | Not searchable, saves index size and write CPU |
| `doc_values: false` | Can't sort or aggregate on it, saves disk |
| `fielddata: true` on `text` | Loads terms into heap — classic OOM cause. Aggregate on a `keyword` sub-field instead |
| `_source.enabled: false` | Saves disk, but breaks reindex, update, and highlighting. Rarely worth it |
| `index.codec: best_compression` | Smaller stored fields, slightly slower fetch. Good for logs |
| `nested` type | Correct per-object matching, but each nested object is a hidden Lucene doc → more docs, slower queries |

### OpenSearch-only features

| Setting | What it does | Impact |
|---------|--------------|--------|
| `index.replication.type: SEGMENT` | Replicas copy finished segments from the primary instead of re-indexing every document | Much less CPU on replicas, higher ingest throughput. Replicas become searchable slightly after the primary |
| Remote-backed storage (`index.remote_store.enabled`) | Segments and translog are uploaded to object storage such as S3 | Durability no longer depends on local replicas. Adds upload latency on refresh and flush |
| Concurrent segment search | Searches segments inside one shard in parallel threads | Lower latency for heavy queries and aggs on large shards, at the cost of more CPU per query |
| Searchable snapshots | Query indices directly from snapshots | Cheap cold tier, slow first-hit latency |

---

## Part 5: Tuning Recipes

```mermaid
flowchart TD
  Start{What's the workload?} --> Bulk[One-off bulk load]
  Start --> Logs[Continuous logs / events]
  Start --> App[User-facing search]
  Bulk --> B1["replicas: 0<br/>refresh_interval: -1<br/>translog.durability: async<br/>bulk 5–15 MB per request<br/>restore all settings after"]
  Logs --> L1["refresh_interval: 30s<br/>best_compression codec<br/>daily or rollover indices + ISM<br/>forcemerge old indices<br/>segment replication (OpenSearch)"]
  App --> A1["refresh_interval: 1s (default)<br/>replicas ≥ 1 for read scale<br/>filters in filter context<br/>track_total_hits small or false<br/>search_after for paging<br/>routing by tenant if multi-tenant"]
```

| Goal | Turn up | Turn down |
|------|---------|-----------|
| Ingest throughput | `refresh_interval`, `index_buffer_size`, bulk size, `flush_threshold_size` | replicas (temporarily), `durability: request` → `async` |
| Search latency | replicas, `preference` stickiness, routing, forcemerge on read-only data | shard count (fewer, bigger shards), `track_total_hits`, deep `from` |
| Freshness | — | `refresh_interval` |
| Durability | replicas, `durability: request`, `wait_for_active_shards` | `sync_interval` |
| Recovery speed | — | `flush_threshold_size`, shard size |

---

## Part 6: Pitfalls

1. **Oversharding.** 1,000 tiny shards = huge cluster state, wide fan-out, wasted heap. Size shards by data, not by node count.
2. **`?refresh=true` on every write.** It creates one segment per request, and merges can't keep up.
3. **Leaving bulk-load settings on.** Replicas left at 0 = no HA. Refresh left at `-1` = new data never visible.
4. **Exact counts everywhere.** `track_total_hits: true` on a large index scans every match.
5. **Scoring clauses used as filters.** `must` for a yes/no condition skips the query cache and wastes BM25 work.
6. **`fielddata` on text fields.** Heap blowup. Aggregate on `keyword`.
7. **Expecting `wait_for_active_shards` to mean quorum acks.** It's a pre-flight check only.
8. **Custom routing without passing it on GET.** The GET hashes `_id`, hits the wrong shard, and returns 404.

---

## Interview one-liners

- **Why is GET faster than search?** `_id` → hash → exactly one shard, one term lookup, no scoring, no merge phase.
- **Why does refresh not make data durable?** It writes a segment to the OS page cache without fsync. The translog provides durability.
- **What is flush?** A Lucene commit: fsync the segments, then start a new translog generation so the old one can be trimmed.
- **Why are updates expensive?** Segments are immutable, so an update is delete + reindex, and space is reclaimed only on merge.
- **Document vs segment replication?** Document replication re-runs indexing on every copy. Segment replication (OpenSearch) indexes once and ships the segment files.

Related: [Elasticsearch interview section](../interview-questions/database-technologies.md#elasticsearch) · [Cache & search compared](../database-comparisons/cache-and-search-compared.md) · [Storage & indexing](./storage-and-indexing.md)
