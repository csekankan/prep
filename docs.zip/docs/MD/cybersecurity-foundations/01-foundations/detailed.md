# 01 — Foundations: CIA Triad, IAM, Federation, Governance, Cryptography, Hashing

> **One sentence:** Every security decision protects at least one of **Confidentiality, Integrity, Availability**. Identity decides *who* may touch data, governance decides *what the rules are*, and cryptography *enforces* confidentiality and integrity mathematically.

## Lecture map

| Lecture | Section |
|---------|---------|
| The CIA Triad + Practice Activity | §1 |
| Identity and Access Management I & II | §2 |
| Identity Federation | §3 |
| Security Governance: Policies, Standards and Procedures | §4 |
| Security Governance: GDPR, HIPAA, PCI-DSS and Intellectual Property | §5 |
| Cryptography + Practice Activity | §6 |
| Hashing and Digital Signatures + Lab + Practice | §7 |
| Quiz (Foundations) | Interview questions |

---

## §1 The CIA Triad

**Analogy:** Think of a bank vault. **Confidentiality** means only authorized people can see inside. **Integrity** means nobody can quietly swap the gold for lead. **Availability** means the vault opens when a legitimate customer needs their money.

| Pillar | Question it answers | Typical controls | Typical attacks |
|--------|--------------------|------------------|-----------------|
| Confidentiality | Can unauthorized parties read it? | Encryption (AES, TLS), access control, data classification, DLP, masking/tokenization | Eavesdropping, data breach, shoulder-surfing, insider exfiltration |
| Integrity | Can it be altered without detection? | Hashing, HMAC, digital signatures, checksums, version control, DB constraints, WORM storage | MITM tampering, SQL injection `UPDATE`, log tampering, supply-chain poisoning |
| Availability | Is it there when needed? | Redundancy, multi-AZ/region, backups, DDoS protection, capacity planning, rate limiting | DoS/DDoS, ransomware, hardware failure, misconfiguration |

### Extended models (senior-level)

- **Parkerian Hexad** adds **Possession/Control**, **Authenticity** and **Utility**. Example: an encrypted backup tape that is stolen is still confidential, but you lost *possession* of it. Ransomware that encrypts data without leaking it destroys *utility*.
- **AAA**: Authentication, Authorization, Accounting (auditing). Often taught next to CIA.
- **Non-repudiation**: the sender cannot deny having sent a message. You get this from digital signatures, not from symmetric MACs, because both parties share the MAC key.

### Trade-offs (what interviewers actually probe)

- **C vs A:** Strict encryption with a single key custodian improves confidentiality. But if the HSM cluster fails, payments stop. Banks solve this with HSM clusters across sites plus **dual control** key ceremonies.
- **I vs A:** Strong consistency (synchronous replication) protects integrity of ledgers but adds latency and reduces availability during a network partition (the CAP theorem). Core banking ledgers choose integrity. Social feeds choose availability.
- **C vs I:** End-to-end encryption hides content from the server, so the server cannot scan for malware (integrity of the platform).

### Practice activity: classify the incident

| Scenario | Pillar violated | Why |
|----------|-----------------|-----|
| Attacker reads customer PANs from an unencrypted S3 bucket | C | Unauthorized disclosure |
| Insider changes wire beneficiary account before release | I | Unauthorized modification |
| Botnet floods the net-banking login page | A | Service denied |
| Ransomware encrypts the file server | A (and I) | Data unusable; files altered |
| Ransomware with double extortion (leak + encrypt) | C + I + A | All three |
| Expired TLS certificate causes mobile app outage | A | Service unusable even though nothing leaked |
| Developer commits AWS key to a public GitHub repo | C | Credential disclosure leads to wider compromise |
| Audit log deleted by an admin | I (accountability) | Evidence altered |

---

## §2 Identity and Access Management (IAM I & II)

**Analogy:** IAM is the hotel front desk. **Identification** is saying your name. **Authentication** is showing your passport. **Authorization** is the key card that opens only room 1204 and the gym. **Accounting** is the log of every door you opened.

### The IAM lifecycle (Joiner–Mover–Leaver)

```mermaid
flowchart LR
  J[Joiner: HR creates record] --> P[Provision: accounts + birthright roles]
  P --> U[Use: authN + authZ + logging]
  U --> M[Mover: role change → remove old access]
  M --> R[Review: periodic access certification]
  R --> U
  U --> L[Leaver: deprovision within SLA]
```

- **Banks:** Leaver access must be revoked the same day (often within hours for privileged users). Access recertification happens quarterly for privileged accounts and semi-annually for others. Auditors (SOX, internal audit) sample these.
- **Mover risk:** "privilege creep". An employee who moves from Trading to Operations and keeps trading access breaks **segregation of duties (SoD)**. Rogue-trader incidents (Barings, Société Générale) are textbook examples.

### Authentication factors

| Factor | Examples | Weakness |
|--------|----------|----------|
| Something you know | Password, PIN, security questions | Phishing, reuse, guessing |
| Something you have | TOTP app, hardware key (YubiKey), smart card, phone | Theft, SIM swap (for SMS) |
| Something you are | Fingerprint, face, iris | Cannot be rotated; privacy issues |
| Somewhere you are / something you do | Geolocation, device posture, typing cadence | Spoofable; used as risk signals |

**MFA strength ranking (weakest → strongest):** SMS OTP < email OTP < TOTP < push notification (vulnerable to MFA fatigue, as in the Uber 2022 breach) < number-matching push < **FIDO2/WebAuthn passkeys** (phishing-resistant, because the signature is bound to the origin domain).

### Authorization concepts

- **Least privilege:** grant the minimum access needed, for the minimum time.
- **Need to know:** even with a clearance, access is granted only for a specific task.
- **Segregation of duties:** no single person can complete a sensitive transaction end-to-end. Example: maker–checker in payments, where one person creates a wire and another approves it.
- **Just-in-time (JIT) access:** privileges are granted for a short window and auto-revoked.
- **Privileged Access Management (PAM):** vaulted admin credentials (CyberArk, HashiCorp Vault, BeyondTrust), session recording, password checkout and rotation after each use.
- **Break-glass accounts:** emergency accounts stored offline, with alerting on any use.

### Passwords done right (NIST SP 800-63B)

- Minimum 8 characters (15+ for admins), allow up to 64+.
- **No forced periodic rotation** unless there is evidence of compromise.
- Check new passwords against breached-password lists.
- No composition rules ("must contain a symbol"). Length matters more.
- Store with a slow, salted hash: **Argon2id**, scrypt, bcrypt, or PBKDF2 (see §7).

### IAM II: centralized identity

| Component | Role |
|-----------|------|
| Directory (Active Directory, LDAP, Entra ID) | Source of identities and groups |
| IdP (Okta, Entra ID, Ping) | Authenticates users and issues tokens/assertions |
| IGA (SailPoint, Saviynt) | Governance: request/approve, certification, SoD rules |
| PAM (CyberArk) | Privileged credentials and sessions |
| CIAM (Auth0, Cognito) | Customer identities at scale |

**Workload identity (FAANG level):** services also need identities. Use SPIFFE/SPIRE, AWS IAM roles, GCP service accounts with Workload Identity Federation, and mTLS between services. **Never use long-lived static keys.**

---

## §3 Identity Federation

**Analogy:** Federation is a passport. Your country (the IdP) vouches for you, and other countries (service providers) trust that passport without issuing you their own ID.

### Protocols

| Protocol | Format | Use | Notes |
|----------|--------|-----|-------|
| SAML 2.0 | XML assertions, signed | Enterprise web SSO (Workday, Salesforce) | Watch for XML signature wrapping attacks |
| OAuth 2.0 | Access tokens | **Delegated authorization** (an app acting on your behalf) | Not an authentication protocol by itself |
| OpenID Connect (OIDC) | JWT ID token on top of OAuth 2.0 | Modern authentication (login with Google) | Validate `iss`, `aud`, `exp`, `nonce`, signature |
| Kerberos | Tickets | Windows/AD internal SSO | Golden/silver ticket attacks |
| SCIM | REST/JSON | Provisioning users across SaaS | Automates joiner/leaver |

### SAML SP-initiated flow

```mermaid
sequenceDiagram
  participant U as User browser
  participant SP as Service Provider
  participant IdP as Identity Provider
  U->>SP: Access app
  SP->>U: Redirect with AuthnRequest
  U->>IdP: AuthnRequest
  IdP->>U: Login + MFA
  IdP->>U: Signed SAML Response (assertion)
  U->>SP: POST assertion to ACS URL
  SP->>SP: Validate signature, audience, time, InResponseTo
  SP->>U: Session cookie
```

### OAuth 2.0 / OIDC: Authorization Code + PKCE (the only flow to use for public clients)

1. The client generates `code_verifier` and sends `code_challenge = SHA256(verifier)`.
2. The user authenticates at the authorization server and is redirected back with a `code`.
3. The client exchanges `code + code_verifier` for tokens.
4. **Implicit flow and Resource Owner Password flow are deprecated** (OAuth 2.1).

### Federation attacks to know

- **Golden SAML** (SolarWinds 2020): the attacker steals the ADFS token-signing key and forges assertions for any user.
- **Token theft / session hijacking:** stolen refresh tokens bypass MFA. Defenses: token binding, short lifetimes, continuous access evaluation.
- **OAuth consent phishing:** a malicious app requests `Mail.Read` scope.
- **JWT pitfalls:** `alg: none`, RS256→HS256 key confusion, not validating `aud`.

**Bank lens:** Federation with third parties (fintech partners, payment processors) runs through formal third-party risk assessment. Banks often use **FAPI** (Financial-grade API) profiles of OAuth/OIDC for Open Banking (PSD2 in the EU, UK Open Banking, Account Aggregator in India), which require mTLS or `private_key_jwt` client authentication and signed request objects.

---

## §4 Security Governance: Policies, Standards, Procedures

**Analogy:** The **policy** is the constitution ("we protect customer data"). **Standards** are the laws ("AES-256 for data at rest"). **Procedures** are the step-by-step instructions ("how to rotate a KMS key"). **Guidelines** are advice ("prefer passphrases").

| Document | Mandatory? | Level | Example | Owner |
|----------|-----------|-------|---------|-------|
| Policy | Yes | Strategic, high-level, rarely changes | Information Security Policy | Board / CISO |
| Standard | Yes | Specific, measurable requirement | Cryptography Standard: TLS 1.2+ only | Security architecture |
| Baseline | Yes | Minimum configuration for a system | CIS Benchmark for RHEL 9 | Platform team |
| Procedure | Yes | Step-by-step instructions | Incident escalation runbook | Operations |
| Guideline | No | Recommendation | Secure coding tips | Any |

### Governance structure

- **Board / Risk Committee** sets risk appetite.
- **CISO** owns the security program. In banks the CISO usually reports outside IT (to the CRO or CEO) to avoid conflicts of interest.
- **Three Lines of Defense (banks):**
  1. **First line:** business and IT own and manage risk.
  2. **Second line:** Risk and Compliance oversee and challenge.
  3. **Third line:** Internal Audit gives independent assurance.

### Frameworks

| Framework | What it is |
|-----------|-----------|
| ISO/IEC 27001 | Certifiable ISMS (management system); Annex A has 93 controls (2022 revision) |
| NIST CSF 2.0 | Govern, Identify, Protect, Detect, Respond, Recover |
| NIST SP 800-53 | Detailed control catalog (US federal) |
| CIS Controls v8 | 18 prioritized technical controls |
| COBIT | IT governance |
| SOC 2 | Attestation report on Trust Services Criteria (security, availability, confidentiality, processing integrity, privacy) |

---

## §5 Regulations: GDPR, HIPAA, PCI-DSS, Intellectual Property

### GDPR (EU General Data Protection Regulation)

- **Scope:** personal data of people in the EU, wherever the processor is located.
- **Principles:** lawfulness, purpose limitation, data minimization, accuracy, storage limitation, integrity and confidentiality, accountability.
- **Rights:** access, rectification, erasure ("right to be forgotten"), portability, objection, and rights around automated decision-making.
- **Breach notification:** to the supervisory authority **within 72 hours** of becoming aware.
- **Fines:** up to **€20M or 4% of global annual turnover**, whichever is higher.
- **Roles:** controller, processor, DPO (Data Protection Officer). DPIA (Data Protection Impact Assessment) for high-risk processing.

### HIPAA (US healthcare)

- Protects **PHI** (Protected Health Information).
- **Privacy Rule**, **Security Rule** (administrative, physical, technical safeguards), **Breach Notification Rule** (within 60 days; breaches affecting 500+ people are reported to HHS and the media).
- Covered entities plus **Business Associates**, which require a BAA (Business Associate Agreement).

### PCI-DSS v4.0 (payment cards) — the most important one for banks

12 requirements in 6 goals:

| Goal | Requirements |
|------|-------------|
| Build and maintain a secure network | 1. Network security controls · 2. Secure configurations |
| Protect account data | 3. Protect stored account data · 4. Encrypt in transit over open networks |
| Vulnerability management | 5. Anti-malware · 6. Secure systems and software |
| Strong access control | 7. Restrict by need-to-know · 8. Identify and authenticate · 9. Restrict physical access |
| Monitor and test | 10. Log and monitor · 11. Test security regularly |
| Policy | 12. Information security policy and programs |

Key facts:
- **Never store** sensitive authentication data (CVV2, full track data, PIN block) after authorization.
- PAN must be unreadable at rest: tokenization, truncation, strong encryption, or keyed hashing.
- Display masking: at most the first 6 and last 4 digits.
- **Scope reduction** is the biggest lever. Segment the **CDE (Cardholder Data Environment)** and tokenize so fewer systems are in scope.
- Levels by transaction volume. Level 1 (>6M transactions per year) needs an annual ROC by a QSA.

### Other regulations you should name in a bank interview

- **SOX** (financial reporting integrity, ITGCs: access, change, operations).
- **GLBA** (US financial privacy).
- **NYDFS 23 NYCRR 500** (MFA, CISO, 72-hour notification).
- **DORA** (EU Digital Operational Resilience Act, in force January 2025).
- **SWIFT CSP** (Customer Security Programme).
- **FFIEC** guidance.
- **RBI** Cyber Security Framework (India), **MAS TRM** (Singapore).
- **CCPA/CPRA** (California), **DPDP Act 2023** (India).

### Intellectual property

| Type | Protects | Duration (typical) |
|------|----------|--------------------|
| Copyright | Expression (code, docs) | Author's life + 70 years |
| Patent | Inventions | 20 years from filing |
| Trademark | Brand names, logos | Renewable indefinitely |
| Trade secret | Confidential business info (source code, algorithms, a trading model) | As long as it stays secret |

Security relevance: protecting trade secrets requires "reasonable measures" (NDAs, access control, DLP). Insider theft of source code or trading algorithms is a top insider-threat case. Software licensing compliance (open-source licenses like GPL/AGPL) is part of SCA.

---

## §6 Cryptography

**Analogy:** Symmetric crypto is one key that locks and unlocks the same box, so you have to hand the key over somehow. Asymmetric crypto is a padlock you hand out freely (public key) while only you hold the key that opens it (private key).

### Building blocks

| Type | Algorithms (use) | Avoid | Purpose |
|------|------------------|-------|---------|
| Symmetric block cipher | **AES-128/256** in **GCM** mode (AEAD), ChaCha20-Poly1305 | DES, 3DES, RC4, AES-ECB | Bulk encryption |
| Asymmetric | RSA-3072+, **ECDSA P-256**, **Ed25519**, X25519 (ECDH) | RSA-1024, raw RSA without OAEP/PSS | Key exchange, signatures |
| Hash | SHA-256/384, SHA-3, BLAKE2/3 | MD5, SHA-1 | Integrity |
| MAC | HMAC-SHA256, GMAC, Poly1305 | Home-made `hash(key‖msg)` (vulnerable to length extension) | Integrity + authenticity with a shared key |
| KDF / password hashing | Argon2id, scrypt, bcrypt, PBKDF2; HKDF for key derivation | Plain SHA-256 for passwords | Derive keys / store passwords |
| Post-quantum | **ML-KEM (Kyber, FIPS 203)**, **ML-DSA (Dilithium, FIPS 204)**, SLH-DSA (FIPS 205) | — | Quantum-resistant |

### Modes of operation

- **ECB** encrypts identical blocks to identical ciphertext (the famous "ECB penguin"). Never use it.
- **CBC** needs an unpredictable IV and is vulnerable to padding-oracle attacks if errors leak.
- **CTR** turns a block cipher into a stream cipher. A nonce must never repeat.
- **GCM** is CTR plus authentication (AEAD). **Reusing a nonce with the same key is catastrophic**: it leaks the XOR of the plaintexts and lets attackers forge tags.

### Hybrid encryption (how TLS and PGP actually work)

```mermaid
flowchart LR
  A[Generate random AES key] --> B[Encrypt data with AES-GCM]
  A --> C[Encrypt AES key with recipient RSA/ECDH public key]
  B & C --> D[Send ciphertext + wrapped key]
```

Asymmetric crypto is slow, so it only protects (wraps) a symmetric key. **Envelope encryption** in AWS KMS / GCP KMS follows the same pattern. A **KEK** (key-encryption key) held in KMS/HSM wraps per-object **DEKs** (data-encryption keys).

### PKI (Public Key Infrastructure)

- **Certificate Authority (CA)** signs certificates binding a public key to an identity (X.509).
- **Chain of trust:** Root CA (offline, in an HSM) → Intermediate CA → Leaf certificate.
- **Revocation:** CRL, OCSP, OCSP stapling. Short-lived certificates (for example 90 days with ACME / Let's Encrypt) reduce reliance on revocation.
- **Certificate Transparency logs** help detect mis-issued certificates.

### Key management (bank grade)

- Keys live in **HSMs** (Thales Luna, Entrust nShield, AWS CloudHSM) validated to **FIPS 140-2/3 Level 3**.
- **Dual control and split knowledge:** no single person can reconstruct a master key. Key components are held by separate custodians (for example 2-of-3 or 3-of-5 key shares).
- Lifecycle: generation → distribution → storage → rotation → revocation → destruction.
- Payment-specific: TR-31 key blocks, DUKPT for PIN pads, PIN blocks (ISO 9564), card verification keys.

### Practice activity: pick the primitive

| Need | Answer |
|------|--------|
| Encrypt a 10 GB database backup | AES-256-GCM with a DEK; wrap the DEK with KMS (envelope) |
| Prove a software release came from us | Digital signature (Ed25519/ECDSA); Sigstore/cosign |
| Two microservices authenticate each other | mTLS with short-lived certificates (SPIFFE) |
| Verify a webhook from a payment gateway | HMAC-SHA256 over the body with a shared secret; constant-time compare |
| Store user passwords | Argon2id with a unique salt (+ optional pepper in an HSM) |
| Exchange a key over an untrusted network | ECDHE (X25519), authenticated by certificates |

---

## §7 Hashing and Digital Signatures

### Hash function properties

1. **Deterministic:** same input, same output.
2. **Fixed-length output** (SHA-256 → 256 bits).
3. **Pre-image resistance:** given `h`, you cannot find `m`.
4. **Second pre-image resistance:** given `m1`, you cannot find `m2` with the same hash.
5. **Collision resistance:** you cannot find any `m1 ≠ m2` with the same hash. MD5 and SHA-1 are broken here (SHAttered, 2017).
6. **Avalanche effect:** flipping one bit changes about 50% of the output bits.

### Hashing ≠ encryption ≠ encoding

| | Reversible? | Key? | Purpose |
|--|------------|------|---------|
| Encoding (Base64) | Yes | No | Data transport format. **Not security.** |
| Encryption | Yes (with key) | Yes | Confidentiality |
| Hashing | No | No | Integrity / fingerprint |
| MAC | No | Yes (shared) | Integrity + authenticity |
| Signature | Verify only | Private key signs, public verifies | Integrity + authenticity + non-repudiation |

### Digital signature flow

```mermaid
sequenceDiagram
  participant S as Signer
  participant V as Verifier
  S->>S: h = SHA256(message)
  S->>S: sig = Sign(private_key, h)
  S->>V: message + sig + certificate
  V->>V: Validate certificate chain to trusted root
  V->>V: Verify(public_key, SHA256(message), sig)
  V->>V: Valid → authentic + unaltered + non-repudiable
```

### Lab: hashing (macOS/Linux)

```bash
# Create a file and hash it
echo "Transfer 100 USD to account 12345" > txn.txt
shasum -a 256 txn.txt          # macOS
sha256sum txn.txt              # Linux
md5 txn.txt                    # macOS (legacy, for demonstration only)

# Avalanche effect: change one character
echo "Transfer 900 USD to account 12345" > txn2.txt
shasum -a 256 txn.txt txn2.txt   # completely different digests

# Verify a downloaded ISO against a published checksum
echo "<published_sha256>  ubuntu.iso" | shasum -a 256 -c -

# HMAC
echo -n "payload" | openssl dgst -sha256 -hmac "shared-secret"

# Digital signature with OpenSSL (Ed25519)
openssl genpkey -algorithm ed25519 -out priv.pem
openssl pkey -in priv.pem -pubout -out pub.pem
openssl pkeyutl -sign -inkey priv.pem -rawin -in txn.txt -out txn.sig
openssl pkeyutl -verify -pubin -inkey pub.pem -rawin -in txn.txt -sigfile txn.sig
```

Windows PowerShell:

```powershell
Get-FileHash .\txn.txt -Algorithm SHA256
```

### Password storage in Python

```python
from argon2 import PasswordHasher

ph = PasswordHasher(time_cost=3, memory_cost=64 * 1024, parallelism=4)
stored = ph.hash("correct horse battery staple")   # salt is embedded in the output
ph.verify(stored, "correct horse battery staple")  # raises on mismatch
if ph.check_needs_rehash(stored):
    stored = ph.hash("correct horse battery staple")
```

```python
import hmac, hashlib

def verify_webhook(body: bytes, header_sig: str, secret: bytes) -> bool:
    expected = hmac.new(secret, body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header_sig)
```

**Why salt?** It defeats precomputed rainbow tables, and identical passwords get different hashes. **Why slow?** A GPU can compute billions of SHA-256 hashes per second. Argon2id is memory-hard, so each guess costs real RAM.

### Practice activity

1. Hash `hello` and `Hello` with SHA-256 and count how many hex characters match. (Expect about 1 in 16, which is random chance.)
2. Explain why an attacker who steals an unsalted MD5 password database can crack most passwords in hours.
3. Explain why a signature proves non-repudiation while HMAC does not.

---

## Bank / FAANG lens

- **Google BeyondCorp / zero trust:** no trusted internal network. Every request is authenticated and authorized based on user and device identity, posture and context.
- **AWS:** IAM policies evaluated with explicit deny > explicit allow > implicit deny. SCPs at the organization level. KMS envelope encryption by default.
- **Banks:** maker–checker on every money-moving action, HSM-backed keys, quarterly access recertification evidence for SOX and PCI auditors, and PAM session recording for every DBA on production.

## Interview questions (Quiz: Foundations)

1. **Define the CIA triad and give a control for each.** C: encryption/ACLs. I: hashing/signatures. A: redundancy/DDoS protection.
2. **Authentication vs authorization?** AuthN proves who you are. AuthZ decides what you can do. OAuth is authorization; OIDC adds authentication.
3. **Why is SMS OTP weak?** SIM swap, SS7 interception, and it is phishable. Prefer FIDO2.
4. **What is SoD? Give a banking example.** Maker–checker for wires. The developer cannot deploy their own change to production without approval.
5. **Symmetric vs asymmetric?** One shared key and fast, versus a key pair and slow. Combine them in hybrid encryption.
6. **Why AES-GCM over AES-CBC?** Built-in authentication (AEAD), no padding oracle, parallelizable. Never reuse a nonce.
7. **Hash vs MAC vs signature?** See the table in §7.
8. **How do you store passwords?** Argon2id/bcrypt with a per-user salt, optional pepper in an HSM, rehash on parameter upgrade.
9. **What is PCI-DSS scope reduction?** Segment the CDE and tokenize PAN so most systems never see card data.
10. **GDPR breach notification timeline?** 72 hours to the supervisory authority.
11. **What is Golden SAML?** Theft of the IdP signing key that allows forging assertions for any user.
12. **Policy vs standard vs procedure?** Why/what (mandatory, high-level), measurable requirement, step-by-step how.
13. **What is non-repudiation and which primitive gives it?** The sender cannot deny sending. Digital signatures (private key held by one party only).
14. **Explain envelope encryption.** A DEK encrypts the data; a KEK in KMS/HSM encrypts the DEK. You rotate the KEK without re-encrypting all the data.
