# Cybersecurity Foundations — FAANG & Bank-Level Study Guide

> **One sentence:** A complete, interview-ready companion to a full cybersecurity course: from the CIA triad to packet forensics, GRC risk management, and SOC careers, written to the bar used by FAANG security teams and Tier-1 banks.

## How to use this guide

1. Read each module's **Basics** section first. It gives you the mental model and an analogy.
2. Then read the **Deep dive**. That is the level an L5/L6 (senior) security engineer or bank security architect should know.
3. Do the **Labs**. Every lab in the course has a matching hands-on section with commands you can run.
4. Close each module with the **Interview questions** and the **Bank/FAANG lens**. The lens covers how the topic shows up in regulated or hyperscale environments.

## Modules

| # | Module | File |
|---|--------|------|
| 01 | Foundations: CIA, IAM, Federation, Governance, Crypto, Hashing | [01-foundations/detailed.md](01-foundations/detailed.md) |
| 02 | Network Security: OSI/TCP-IP, DNS, TLS/IPSec/VPN/SSH, NMAP, NAT, Firewalls, Wireless | [02-network-security/detailed.md](02-network-security/detailed.md) |
| 03 | Cyber Attacks: Passwords, DoS/DDoS, DNS, MITM, Social Engineering, Phishing | [03-cyber-attacks/detailed.md](03-cyber-attacks/detailed.md) |
| 04 | Web Application Security: Architecture, SQLi, Blind SQLi, XSS, Vuln Mgmt | [04-web-application-security/detailed.md](04-web-application-security/detailed.md) |
| 05 | Malware: Viruses, Worms, Trojans, Ransomware, Rootkits, Antimalware | [05-malware/detailed.md](05-malware/detailed.md) |
| 06 | Kill Chain, Incident Response, IDS/IPS, Snort | [06-kill-chain-ir-ids-snort/detailed.md](06-kill-chain-ir-ids-snort/detailed.md) |
| 07 | Network Forensics: Packet Analysis, tcpdump, Wireshark | [07-network-forensics/detailed.md](07-network-forensics/detailed.md) |
| 08 | Access Control Models: DAC, MAC, RBAC, ABAC | [08-access-control-models/detailed.md](08-access-control-models/detailed.md) |
| 09 | GRC & Risk Management (5-step process, case study) | [09-grc-risk-management/detailed.md](09-grc-risk-management/detailed.md) |
| 10 | Security Controls, GenAI for Security, Careers & Interviews | [10-controls-genai-careers/detailed.md](10-controls-genai-careers/detailed.md) |

## Lecture map (every course lecture → where it is covered)

| Course lecture | Module § |
|----------------|----------|
| Welcome / Course Companion Study Guide | This README |
| The CIA Triad + Practice | 01 §1 |
| Identity and Access Management I & II | 01 §2 |
| Identity Federation | 01 §3 |
| Security Governance: Policies, Standards, Procedures | 01 §4 |
| Security Governance: GDPR, HIPAA, PCI-DSS, IP | 01 §5 |
| Cryptography + Practice | 01 §6 |
| Hashing and Digital Signatures + Lab + Practice | 01 §7 |
| Quiz (Foundations) | 01 Interview questions |
| Introduction: OSI and TCP/IP | 02 §1 |
| Application and Transport Layers | 02 §2 |
| Lab: Email Forensic Investigation (SMTP) + Practice | 02 §3 |
| DNS | 02 §4 |
| The Network Layer | 02 §5 |
| The Link Layer | 02 §6 |
| Security Protocols: SSL/TLS, IPSec, VPNs, SSH | 02 §7 |
| Lab Setup: macOS (Apple Silicon) / Windows VirtualBox | 02 §8 |
| NMAP Port Scanning + Demo + Lab + Solution | 02 §9 |
| NAT | 02 §10 |
| Firewalls | 02 §11 |
| Wireless Networks and Security | 02 §12 |
| Quiz (Network Security) | 02 Interview questions |
| Password Attacks | 03 §1 |
| DoS and DDoS | 03 §2 |
| DNS Attacks | 03 §3 |
| Network Attacks | 03 §4 |
| Man in the Middle | 03 §5 |
| Social Engineering | 03 §6 |
| Lab: Phishing Attack and Investigation | 03 §7 |
| Quiz (Cyber Attacks) | 03 Interview questions |
| Web Application Architecture | 04 §1 |
| SQL Injection + Lab | 04 §2 |
| Blind SQL Injection + Lab | 04 §3 |
| Mitigating SQL Injection | 04 §4 |
| XSS | 04 §5 |
| Vulnerability Management | 04 §6 |
| Quiz (Web App Security) | 04 Interview questions |
| Malware: Introduction | 05 §1 |
| Viruses and Worms | 05 §2 |
| Trojans | 05 §3 |
| Spyware, Adware, Ransomware | 05 §4 |
| Logic Bombs and Rootkits | 05 §5 |
| Antimalware | 05 §6 |
| Quiz (Malware) | 05 Interview questions |
| Cyber Kill Chain (Begin, Progression, C2) | 06 §1 |
| Case Study: Target Incident | 06 §2 |
| Incident Response Lifecycle | 06 §3 |
| IDS / IPS | 06 §4 |
| SNORT + Labs (Writing Rules, Sensitive Web Access) | 06 §5–§6 |
| Network Forensics: Intro | 07 §1 |
| Packet and Protocol Analysis | 07 §2 |
| Lab: Forensics with tcpdump + Solution | 07 §3 |
| Wireshark Overview / Display / Capture Filters | 07 §4–§5 |
| Lab Wireshark: Credentials Breach + Solution | 07 §6 |
| Lab Wireshark: ACME Corporate Data Breach + Solution | 07 §7 |
| Why IAM Matters | 08 §1 |
| Access Control Models: Overview | 08 §2 |
| DAC and MAC | 08 §3 |
| RBAC + Practice | 08 §4 |
| ABAC | 08 §5 |
| Selecting the Right Model + Quiz | 08 §6 |
| Why GRC Matters / GRC in Action | 09 §1 |
| Security Policies: Key Policies | 09 §2 |
| Change Management | 09 §3 |
| Risk in Cyber Security / Risk Mgmt Process | 09 §4 |
| Risk Mgmt Steps 1–5 | 09 §5–§9 |
| Practice + Solution: Risk Management Case Study | 09 §10 |
| Security Controls for Mitigating Risk / By Function + Practice | 10 §1 |
| Generative AI for Cyber Security | 10 §2 |
| GenAI for Ransomware Identification + Practice + Solution | 10 §3 |
| Choosing Your Career / Security Analyst / SOC Analyst / Roadmap | 10 §4 |
| Interview Questions and Conclusion / Bonus | 10 §5 |

## The one-page mental model

```mermaid
flowchart TB
  G[GRC: policies, risk, compliance] --> C[Controls: preventive, detective, corrective]
  C --> I[Identity: IAM, federation, access models]
  C --> N[Network: segmentation, firewalls, TLS]
  C --> A[Application: secure SDLC, SQLi/XSS defenses]
  C --> E[Endpoint: antimalware, EDR]
  I & N & A & E --> D[Detection: IDS/IPS, SIEM, Snort]
  D --> R[Response: IR lifecycle, forensics]
  R -->|lessons learned| G
```

**The thread through every module:** security is a loop. **Governance** decides what matters (risk). **Controls** reduce risk across identity, network, application and endpoint layers. **Detection** finds the risk that gets through, **response** contains it, and **lessons learned** feed back into governance.

## What "FAANG / bank level" means here

| Dimension | Typical company | FAANG | Tier-1 bank |
|-----------|-----------------|-------|-------------|
| Identity | Passwords + MFA | Phishing-resistant MFA (FIDO2), zero trust (BeyondCorp) | FIDO2 + PAM vaulting + quarterly access recertification |
| Crypto | TLS on the edge | mTLS everywhere, KMS/HSM, key rotation automation | FIPS 140-2/3 Level 3 HSMs, dual control, split knowledge |
| Network | Perimeter firewall | Identity-aware proxies, micro-segmentation | Segmented CDE (PCI), DMZ tiers, strict egress allow-lists |
| AppSec | Periodic pen-test | SAST/DAST/SCA in CI, bug bounty, threat modeling per design review | Same + regulator-mandated pen-tests, SWIFT CSP controls |
| Detection | AV + logs | Detection-as-code, petabyte-scale telemetry | 24×7 SOC, SIEM with regulatory retention (5–7 yrs) |
| Governance | Ad hoc | Internal standards, SOC 2, ISO 27001 | SOX, PCI-DSS, GLBA, FFIEC, DORA (EU), NYDFS 500, RBI/MAS rules |
| Change | Informal | Code review + progressive rollout | CAB approvals, segregation of duties, audit trail |
