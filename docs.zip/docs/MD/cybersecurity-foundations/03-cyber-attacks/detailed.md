# 03 — Cyber Attacks: Passwords, DoS/DDoS, DNS, Network Attacks, MITM, Social Engineering, Phishing

> **One sentence:** Attackers go after the weakest link: human trust (phishing), reused credentials, unauthenticated protocols (ARP, DNS), or raw capacity (DDoS). Each attack maps to a CIA pillar and a specific set of defenses.

## Lecture map

| Lecture | Section |
|---------|---------|
| Password Attacks | §1 |
| DoS and DDoS | §2 |
| DNS Attacks | §3 |
| Network Attacks | §4 |
| Man in the Middle Attack | §5 |
| Social Engineering | §6 |
| Lab: Phishing Attack and Investigation | §7 |
| Quiz (Cyber Attacks) | Interview questions |

---

## §1 Password Attacks

| Attack | How | Defense |
|--------|-----|---------|
| **Brute force** (online) | Try every combination against the login | Rate limiting, lockout/backoff, CAPTCHA, MFA |
| **Dictionary** | Wordlists (rockyou.txt) + mutation rules | Breached-password check, length requirements |
| **Credential stuffing** | Replay username/password pairs leaked from other sites | MFA, breached-credential detection, bot management, device fingerprinting |
| **Password spraying** | A few common passwords (`Winter2026!`) across **many** accounts to avoid lockout | Smart lockout, MFA, ban common passwords, detect one IP → many users |
| **Offline cracking** | Crack stolen hashes with GPUs (hashcat) | Slow salted hashes (Argon2id/bcrypt) |
| **Rainbow tables** | Precomputed hash → password chains | **Salts** |
| **Pass-the-hash** | Reuse an NTLM hash without knowing the password | Credential Guard, disable NTLM, LAPS, tiered admin model |
| **Pass-the-ticket / Kerberoasting** | Steal Kerberos tickets; crack service-account TGS offline | Long random service-account passwords (gMSA), AES-only Kerberos, monitor 4769 events |
| **Keylogging / infostealers** | Malware captures passwords and session cookies (RedLine, Lumma) | EDR, phishing-resistant MFA, short session lifetimes |
| **MFA fatigue / push bombing** | Spam push prompts until the user approves | Number matching, FIDO2, alert on many denials |
| **SIM swap** | Hijack a phone number to receive SMS OTP | No SMS MFA for high-value accounts; carrier PIN |

```bash
# Authorized lab: crack an MD5 vs a bcrypt hash and compare speeds
hashcat -m 0    md5.txt    rockyou.txt      # MD5: billions of guesses/sec
hashcat -m 3200 bcrypt.txt rockyou.txt      # bcrypt: thousands/sec
hydra -l admin -P rockyou.txt ssh://192.168.56.101 -t 4
```

**Detection logic (SIEM):**
- Spraying: `count(distinct user) > 20 by src_ip where result=failure within 10m`.
- Stuffing: high failure ratio + many distinct usernames + residential proxy/ASN diversity + headless user agents.
- Windows event IDs: **4625** (failed logon), **4624** (success), **4740** (lockout), **4771/4768/4769** (Kerberos).

**Bank lens:** Online banking login uses risk-based authentication (device binding, behavioral biometrics, geovelocity "impossible travel"), bot management at the edge, and step-up authentication for transactions (PSD2 SCA with dynamic linking: the OTP is bound to the amount and payee).

---

## §2 DoS and DDoS

**Analogy:** A DoS is one person blocking a shop door. A DDoS is 100,000 hired people (a botnet) standing in the queue so real customers can't get in.

### Categories

| Category | Layer | Examples | Measured in |
|----------|-------|----------|-------------|
| **Volumetric** | L3/L4 | UDP flood, **amplification**: DNS (~28–54×), NTP monlist (~556×), memcached (up to ~51,000×), CLDAP, SSDP | Gbps / Tbps |
| **Protocol / state exhaustion** | L3/L4 | **SYN flood**, Ping of Death, Smurf, fragmentation, ACK flood | Packets per second |
| **Application** | L7 | HTTP GET/POST floods, Slowloris, expensive search queries, login floods, **HTTP/2 Rapid Reset (CVE-2023-44487)** | Requests per second |

### Reflection / amplification

```mermaid
flowchart LR
  A[Attacker / botnet] -->|small query, spoofed src = victim IP| R1[Open DNS/NTP/memcached reflectors]
  R1 -->|large responses| V[Victim]
```

It works because **UDP has no handshake**, so the source IP can be spoofed. The fix at internet scale is **BCP 38 ingress filtering** (ISPs drop packets with spoofed source addresses).

### SYN flood and SYN cookies

The attacker sends many SYNs with spoofed sources. The server fills its half-open (backlog) queue. **SYN cookies** encode connection state in the SYN-ACK sequence number, so the server allocates nothing until the final ACK arrives.

```bash
sysctl -w net.ipv4.tcp_syncookies=1
```

### Defenses (layered)

1. **Upstream scrubbing / CDN:** Cloudflare, Akamai Prolexic, AWS Shield Advanced, Google Cloud Armor. Anycast spreads the load globally.
2. **Rate limiting** and WAF rules (per IP, per session, per API key).
3. **Autoscaling** plus caching (but watch the cost: "economic denial of sustainability").
4. **Bot management** (JavaScript challenges, fingerprinting).
5. **Architecture:** no single origin IP exposed, origin locked to accept only CDN IPs, and graceful degradation (serve a static page).
6. **Runbook:** DDoS playbook with the ISP/scrubbing provider contacts, BGP diversion to scrubbing centers, communication templates.

**Real-world scale:** Record DDoS attacks are measured in **multiple Tbps** and **hundreds of millions of requests per second** (Mirai IoT botnet 2016 against Dyn DNS; Cloudflare/Google/AWS have reported HTTP/2 Rapid Reset attacks of 200M+ RPS). Banks are frequent targets of hacktivist DDoS (Operation Ababil 2012–2013 against US banks; the NoName057(16) campaigns).

---

## §3 DNS Attacks

| Attack | Description | Defense |
|--------|-------------|---------|
| **DNS cache poisoning** | Inject forged answers into a resolver cache (Kaminsky 2008) | Source-port + TXID randomization, **DNSSEC** validation |
| **DNS spoofing (local)** | Forge responses on the LAN (often after ARP spoofing) | DoH/DoT, DNSSEC, TLS certificate validation |
| **DNS hijacking** | Change the registrar/NS records or router DNS settings (Sea Turtle campaign) | Registrar lock, MFA on registrar accounts, monitoring NS/DS changes |
| **DNS tunneling** | Exfiltrate data/C2 inside queries: `aGVsbG8.evil.com` | Detect long/high-entropy subdomains, high TXT/NULL query volume, protective DNS |
| **DNS amplification** | Open resolvers reflect `ANY` queries | Close open resolvers, response rate limiting |
| **Subdomain takeover** | Dangling CNAME points to a deprovisioned cloud resource | Inventory DNS; delete records before resources |
| **Typosquatting / homoglyphs** | `paypa1.com`, `bаnk.com` (Cyrillic а) | Brand monitoring, register look-alikes, IDN display policies |
| **NXDOMAIN / random subdomain attack** | Flood the authoritative server with random names | Anycast DNS, rate limiting |
| **DGA (domain generation algorithm)** | Malware computes thousands of C2 domains daily | ML-based DGA detection, sinkholing |

**Detection query (DNS tunneling, pseudo-SPL):**

```text
index=dns | eval len=len(query) | where len>50
| stats count dc(query) as uniq avg(len) by src_ip, domain
| where uniq>200
```

---

## §4 Network Attacks

| Attack | Layer | Mechanism | Defense |
|--------|-------|-----------|---------|
| **IP spoofing** | 3 | Forged source address | BCP 38, uRPF |
| **ARP poisoning** | 2 | Unsolicited ARP replies map the gateway IP to the attacker MAC | DAI, static ARP for critical hosts, 802.1X |
| **MAC flooding** | 2 | Overflow the CAM table | Port security |
| **VLAN hopping** | 2 | DTP / double tagging | Disable DTP, unused native VLAN |
| **Rogue DHCP** | 2/7 | Hand out an attacker gateway/DNS | DHCP snooping |
| **Session hijacking** | 4/7 | Predict/steal TCP sequence numbers or session cookies | TLS, random ISNs, `Secure`/`HttpOnly` cookies, token binding |
| **Replay** | 7 | Resend captured authentication | Nonces, timestamps, TLS |
| **Smurf** | 3 | ICMP echo to a broadcast address with a spoofed victim source | `no ip directed-broadcast` |
| **Ping of Death / Teardrop** | 3 | Oversized/overlapping fragments | Patched stacks |
| **BGP hijack** | 3 (inter-AS) | Announce someone else's prefix | RPKI ROV, prefix filtering, monitoring (BGPStream) |
| **Lateral movement** | — | After initial access: SMB/WinRM/RDP, PsExec, WMI | Segmentation, tiered admin, EDR, disable SMBv1, LAPS |

---

## §5 Man-in-the-Middle (MITM)

**Analogy:** Someone intercepts your letters at the post office, reads or edits them, re-seals them, and forwards them. Neither side notices.

### Techniques

1. **ARP spoofing** on the LAN (Ettercap, Bettercap).
2. **Rogue AP / evil twin** on Wi-Fi.
3. **DNS spoofing** that sends the victim to the attacker's server.
4. **SSL stripping:** downgrade HTTPS to HTTP on the first request (Moxie Marlinspike, 2009).
5. **Rogue certificate:** if the user clicks through warnings, or the attacker installs a root CA on the device.
6. **BGP / ISP-level interception.**
7. **Adversary-in-the-Middle (AiTM) phishing:** a reverse proxy (Evilginx, EvilProxy) sits between the victim and the real login page and steals **session cookies after MFA**. This is the dominant technique against M365/Okta today.

```bash
# Authorized lab
bettercap -iface eth0
> net.probe on
> set arp.spoof.targets 192.168.56.102
> arp.spoof on
> net.sniff on
```

### Defenses

| Layer | Control |
|-------|---------|
| Transport | TLS everywhere, **HSTS preload**, certificate pinning in mobile apps |
| Identity | **FIDO2/passkeys** (origin-bound, so they defeat AiTM proxies), token binding, conditional access requiring compliant devices |
| Network | DAI, 802.1X, WPA3-Enterprise with EAP-TLS, VPN/ZTNA on untrusted Wi-Fi |
| Detection | Impossible travel, session token reuse from a new IP/ASN, duplicate MAC/ARP alerts |

---

## §6 Social Engineering

**Principles of influence (Cialdini), as attackers use them:**

| Principle | Example |
|-----------|---------|
| Authority | "This is the CFO; wire this now." |
| Urgency / scarcity | "Account suspended in 2 hours." |
| Social proof | "Everyone in your team already completed this form." |
| Liking / familiarity | A LinkedIn recruiter persona (Lazarus Group "Operation Dream Job") |
| Reciprocity | Free gift card, then a request |
| Fear / intimidation | "Your computer is infected — call this number." |

### Attack types

- **Phishing** (mass), **spear phishing** (targeted), **whaling** (executives).
- **Business Email Compromise (BEC):** CEO fraud or vendor invoice fraud. FBI IC3 reports **billions of dollars per year** in losses, more than ransomware.
- **Vishing** (voice; now with **deepfake voice**. In the 2024 Arup Hong Kong case a deepfake video call led to a ~US$25M transfer), **smishing** (SMS), **quishing** (QR codes).
- **Pretexting**, **baiting** (USB drops), **tailgating/piggybacking**, **dumpster diving**, **shoulder surfing**.
- **Help-desk social engineering:** MGM Resorts 2023. Attackers called the help desk, impersonated an employee, got MFA reset, and the result was ransomware and roughly $100M of impact.
- **Watering hole:** compromise a site the target group visits.

### Defenses

- Security awareness training plus **phishing simulations** with metrics: click rate, **report rate** (the metric that matters most), time to report.
- **Out-of-band verification** for payment changes: call back a known number, never the number in the email. Banks mandate callback for any beneficiary change.
- Help-desk identity verification (video plus ID, manager approval) before MFA resets.
- Technical controls: DMARC `p=reject`, external-sender banners, link rewriting/sandboxing, attachment detonation, blocking macros from the internet (Mark of the Web).
- A "report phish" button that feeds SOC automation (SOAR).

---

## §7 Lab: Phishing Attack and Investigation (no installation)

### Scenario

A finance analyst receives: *"From: DocuSign <dse@docusign-secure.net> — Please review and sign: Q4 Vendor Payment Update."* There is a button linking to `hxxps://docusign-secure[.]net/login?u=analyst@bank.com`.

### Investigation playbook

```mermaid
flowchart TD
  R[User reports email] --> H[Pull headers: SPF/DKIM/DMARC, origin IP]
  H --> U[Extract URLs/attachments, defang]
  U --> T[Threat intel: VirusTotal, urlscan.io, WHOIS domain age]
  T --> S[Sandbox detonation: any.run / Joe Sandbox]
  S --> D{Malicious?}
  D -- No --> C[Close, give feedback to user]
  D -- Yes --> Scope[Search mail logs: who else received it? who clicked?]
  Scope --> Contain[Purge from mailboxes, block domain/URL/IP/hash, reset creds + revoke sessions for clickers]
  Contain --> Report[IOC sharing (FS-ISAC), lessons learned]
```

### Online tools (no install)

| Tool | Use |
|------|-----|
| MXToolbox Header Analyzer / Google Admin Toolbox Messageheader | Parse headers |
| urlscan.io | Safe screenshot and DOM of the URL |
| VirusTotal | URL/file/hash reputation |
| WHOIS / DomainTools | Domain age (newly registered = suspicious) |
| AbuseIPDB | IP reputation |
| any.run / Hybrid Analysis | Interactive sandbox |
| PhishTank / OpenPhish | Known phishing URLs |

### Findings template

| Field | Value |
|-------|-------|
| Sender | `dse@docusign-secure.net` (look-alike; real is `docusign.net`) |
| Domain age | 3 days |
| SPF/DKIM/DMARC | pass/pass/none for the look-alike domain → not a spoof of DocuSign, but impersonation |
| URL | Credential-harvest page cloning the M365 login, AiTM kit |
| Recipients / clicks | 42 received, 5 clicked, 2 submitted credentials |
| Actions | Purged; domain blocked at proxy/DNS; 2 users' passwords reset + **sessions revoked** + MFA methods reviewed; inbox rules checked (attackers add forwarding rules) |
| IOCs | Domain, IP, URL path, kit fingerprint |
| MITRE ATT&CK | T1566.002 (spearphishing link), T1557 (AiTM), T1078 (valid accounts) |

**Key lesson:** After an AiTM phish, **a password reset alone is not enough**. You must revoke refresh tokens and sessions, and check for malicious OAuth app consents and mailbox forwarding rules.

---

## Bank / FAANG lens

- **Banks:** BEC and payment-redirection fraud are top loss drivers, so beneficiary-change callback and maker–checker controls are mandatory. DDoS readiness gets tested in regulator exercises. Threat intel is shared via **FS-ISAC**.
- **FAANG:** Google eliminated successful account phishing among employees after rolling out hardware security keys company-wide. That's the canonical argument for FIDO2.

## Interview questions (Quiz: Cyber Attacks)

1. **Credential stuffing vs password spraying?** Leaked pairs replayed vs common passwords tried across many accounts.
2. **How do salts defeat rainbow tables?** Each hash requires its own table, which makes precomputation infeasible.
3. **Explain DNS amplification and its root cause.** UDP spoofing plus open resolvers plus large responses. BCP 38 fixes it at the source.
4. **How do SYN cookies work?** State is encoded in the ISN, so the backlog isn't consumed.
5. **Why doesn't TOTP stop AiTM phishing, but FIDO2 does?** The proxy relays the OTP in real time and steals the session cookie. FIDO2 signs the origin, so a fake domain gets a useless signature.
6. **What is BEC and the top control?** Email fraud requesting payments. Out-of-band callback verification plus DMARC.
7. **How do you detect DNS tunneling?** Long, high-entropy subdomains, high query volume to one domain, unusual record types.
8. **First three actions after a user enters credentials on a phishing site?** Revoke sessions/tokens and reset the password, check MFA methods and inbox rules, then scope other recipients and block IOCs.
9. **What is an evil twin attack?** A rogue AP mimicking a legitimate SSID. Defend with EAP-TLS server validation and WIPS.
10. **L3/4 vs L7 DDoS: which is harder to mitigate and why?** L7, because requests look legitimate and are cheap for the attacker but expensive for the server.
