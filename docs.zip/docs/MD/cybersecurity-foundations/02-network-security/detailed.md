# 02 — Network Security: OSI/TCP-IP, DNS, Security Protocols, NMAP, NAT, Firewalls, Wireless

> **One sentence:** To defend a network you must know what each layer carries, how attackers abuse it, and which control (TLS, IPSec, firewall, segmentation, WPA3) protects it.

## Lecture map

| Lecture | Section |
|---------|---------|
| Introduction: OSI and TCP/IP | §1 |
| Application and Transport Layers | §2 |
| Lab: Email Forensic Investigation (SMTP) + Practice | §3 |
| DNS | §4 |
| The Network Layer | §5 |
| The Link Layer | §6 |
| Security Protocols: SSL/TLS, IPSec, VPNs, SSH | §7 |
| Lab Setup: macOS (Apple Silicon) / Windows VirtualBox | §8 |
| NMAP Port Scanning + Demo + Lab + Solution | §9 |
| NAT | §10 |
| Firewalls | §11 |
| Wireless Networks and Security | §12 |
| Quiz (Network Security) | Interview questions |

---

## §1 OSI and TCP/IP models

**Analogy:** Sending a letter. You write the content (application), put it in an envelope with a tracking number (transport), address it to a city and street (network), and the postal van drives it to the next sorting office (link/physical). Each layer only cares about its own envelope. This wrapping is called **encapsulation**.

| OSI # | OSI layer | TCP/IP layer | PDU | Protocols | Devices | Attacks |
|-------|-----------|--------------|-----|-----------|---------|---------|
| 7 | Application | Application | Data | HTTP, DNS, SMTP, FTP, SSH | WAF, proxy | SQLi, XSS, phishing |
| 6 | Presentation | Application | Data | TLS (encoding/encryption), JPEG | — | SSL stripping |
| 5 | Session | Application | Data | RPC, NetBIOS | — | Session hijacking |
| 4 | Transport | Transport | Segment / datagram | TCP, UDP, QUIC | L4 firewall, LB | SYN flood, port scan |
| 3 | Network | Internet | Packet | IPv4, IPv6, ICMP, IPSec, BGP, OSPF | Router, L3 switch | IP spoofing, BGP hijack, Smurf |
| 2 | Data link | Link | Frame | Ethernet, 802.11, ARP, VLAN (802.1Q) | Switch, AP | ARP spoofing, MAC flooding, VLAN hopping |
| 1 | Physical | Link | Bits | Copper, fiber, radio | Hub, repeater | Wiretapping, jamming |

Mnemonic (7→1): **"All People Seem To Need Data Processing."**

```mermaid
flowchart TB
  A[HTTP data] --> B[TCP header + data = segment]
  B --> C[IP header + segment = packet]
  C --> D[Ethernet header + packet + FCS = frame]
  D --> E[Bits on the wire]
```

---

## §2 Application and Transport Layers

### Common ports to memorize

| Port | Protocol | Secure alternative |
|------|----------|--------------------|
| 20/21 | FTP | SFTP (22) / FTPS (990) |
| 22 | SSH / SFTP | — |
| 23 | Telnet | SSH |
| 25 | SMTP (server-to-server) | STARTTLS; 587 submission; 465 SMTPS |
| 53 | DNS (UDP, TCP for large responses/zone transfers) | DoT 853, DoH 443 |
| 67/68 | DHCP | — |
| 80 | HTTP | HTTPS 443 |
| 110 / 143 | POP3 / IMAP | 995 / 993 |
| 123 | NTP | NTS |
| 161/162 | SNMP | SNMPv3 |
| 389 | LDAP | LDAPS 636 |
| 445 | SMB | SMB 3 with signing/encryption |
| 1433 / 3306 / 5432 | MSSQL / MySQL / PostgreSQL | TLS; never internet-facing |
| 3389 | RDP | Behind a VPN/bastion with NLA + MFA |
| 6379 / 27017 / 9200 | Redis / MongoDB / Elasticsearch | Commonly found exposed with no auth — classic breach source |

### TCP vs UDP

| | TCP | UDP |
|--|-----|-----|
| Connection | 3-way handshake | Connectionless |
| Reliability | ACKs, retransmit, ordering | Best effort |
| Flow / congestion control | Yes (windowing) | No |
| Header | 20+ bytes | 8 bytes |
| Use | HTTP/1.1–2, SSH, SMTP | DNS, VoIP, streaming, QUIC (HTTP/3) |
| Abuse | SYN flood, RST injection, session hijack | Amplification/reflection DDoS (DNS, NTP, memcached) |

### TCP 3-way handshake and flags

```mermaid
sequenceDiagram
  Client->>Server: SYN (seq=x)
  Server->>Client: SYN-ACK (seq=y, ack=x+1)
  Client->>Server: ACK (ack=y+1)
  Note over Client,Server: Established — data flows
  Client->>Server: FIN
  Server->>Client: ACK, then FIN
  Client->>Server: ACK (TIME_WAIT)
```

Flags: **SYN, ACK, FIN, RST, PSH, URG** (plus ECE, CWR). Scanners abuse unusual combinations (NULL, FIN, Xmas = FIN+PSH+URG).

### HTTP essentials for security

- Methods: GET (idempotent; no secrets in the URL because URLs get logged), POST, PUT, DELETE, PATCH, OPTIONS (CORS preflight).
- Status codes: 2xx success, 3xx redirect, 4xx client error (401 unauthenticated, 403 forbidden), 5xx server error.
- Security headers: `Strict-Transport-Security`, `Content-Security-Policy`, `X-Content-Type-Options: nosniff`, `X-Frame-Options`/`frame-ancestors`, `Referrer-Policy`, cookie flags `Secure; HttpOnly; SameSite=Lax|Strict`.

---

## §3 Lab: Email Forensic Investigation (SMTP)

**Goal:** Decide whether an email is genuine or a spoofed phishing email by reading its full headers.

### How SMTP delivery works

```mermaid
flowchart LR
  MUA[Sender mail client] -->|587 submission| MSA[Sender MTA]
  MSA -->|DNS MX lookup, port 25| MX[Recipient MX]
  MX --> MDA[Mailbox] -->|IMAP/POP3| R[Recipient client]
```

SMTP has **no built-in sender authentication**. The `From:` header is just text. Three DNS-based controls add authentication:

| Control | What it checks | DNS record example |
|---------|---------------|--------------------|
| **SPF** | Is the sending IP authorized for the envelope `MAIL FROM` domain? | `v=spf1 include:_spf.google.com -all` |
| **DKIM** | Cryptographic signature over headers/body by the signing domain | `selector._domainkey.bank.com TXT "v=DKIM1; k=rsa; p=..."` |
| **DMARC** | SPF or DKIM must pass **and align** with the visible `From:` domain; sets a policy | `_dmarc.bank.com TXT "v=DMARC1; p=reject; rua=mailto:dmarc@bank.com"` |

### Investigation steps

1. Get the raw source ("Show original" in Gmail, "View message source" in Outlook).
2. Read the `Received:` headers **bottom-up**. The lowest one is closest to the true origin. Note the first external IP.
3. Check `Authentication-Results:` for `spf=`, `dkim=`, `dmarc=`.
4. Compare `From:`, `Reply-To:` and `Return-Path:`. A mismatch (for example `From: ceo@bank.com`, `Reply-To: ceo.bank@gmail.com`) is a red flag.
5. Look up the origin IP (WHOIS, AbuseIPDB, VirusTotal).
6. Extract URLs and attachments. Defang them (`hxxps://evil[.]com`), detonate them in a sandbox, and hash the attachments.
7. Check `Message-ID` domain consistency and `X-Mailer`.

### Sample header analysis

```text
Return-Path: <billing@paypa1-secure.com>
Received: from mail.paypa1-secure.com (unknown [185.220.101.45])
        by mx.google.com with ESMTP id ...
Authentication-Results: mx.google.com;
       spf=pass (domain of billing@paypa1-secure.com designates 185.220.101.45)
       dkim=none;
       dmarc=fail (p=REJECT) header.from=paypal.com
From: "PayPal Service" <service@paypal.com>
Reply-To: support@paypa1-secure.com
Subject: Urgent: Your account will be suspended
```

**Verdict:** Phishing. SPF passes only for the look-alike domain (`paypa1` uses the digit 1). DMARC fails for the visible `paypal.com`. Reply-To diverts responses. The source IP is in a known Tor exit range. Urgency language.

```bash
dig +short TXT paypal.com | grep spf
dig +short TXT _dmarc.paypal.com
dig +short TXT selector1._domainkey.example.com
whois 185.220.101.45
```

**Practice activity:** For a sample `.eml`, record the origin IP, SPF/DKIM/DMARC results, From/Reply-To mismatch, URLs, attachment hashes, and the verdict in an IR ticket.

---

## §4 DNS (Domain Name System)

**Analogy:** The internet's phone book. It turns `bank.com` into `203.0.113.10`.

### Resolution flow

```mermaid
sequenceDiagram
  participant C as Client stub
  participant R as Recursive resolver
  participant Root as Root server
  participant TLD as .com TLD
  participant Auth as bank.com authoritative
  C->>R: A bank.com?
  R->>Root: bank.com?
  Root-->>R: Ask .com NS
  R->>TLD: bank.com?
  TLD-->>R: Ask ns1.bank.com
  R->>Auth: bank.com?
  Auth-->>R: A 203.0.113.10 (TTL 300)
  R-->>C: 203.0.113.10 (cached)
```

| Record | Meaning |
|--------|---------|
| A / AAAA | IPv4 / IPv6 address |
| CNAME | Alias (watch for dangling CNAME → **subdomain takeover**) |
| MX | Mail server |
| TXT | SPF, DKIM, DMARC, domain verification |
| NS | Authoritative name servers |
| SOA | Zone authority info |
| PTR | Reverse lookup |
| CAA | Which CAs may issue certificates for the domain |

Security features: **DNSSEC** (signed records provide integrity, not confidentiality), **DoH/DoT** (confidentiality of queries), **protective DNS / RPZ** (block known-bad domains). Attacks are covered in module 03.

---

## §5 The Network Layer

### IPv4 addressing and subnetting

- 32 bits, dotted decimal. CIDR `/24` means 256 addresses, 254 usable hosts.
- **Private ranges (RFC 1918):** `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`. Plus `127.0.0.0/8` loopback and `169.254.0.0/16` link-local. `169.254.169.254` is the cloud metadata service, a **prime SSRF target** (Capital One 2019).

Quick subnetting table:

| CIDR | Hosts (usable) | Mask |
|------|----------------|------|
| /30 | 2 | 255.255.255.252 |
| /28 | 14 | 255.255.255.240 |
| /24 | 254 | 255.255.255.0 |
| /20 | 4,094 | 255.255.240.0 |
| /16 | 65,534 | 255.255.0.0 |

Example: `10.20.30.77/26` has network `10.20.30.64`, broadcast `10.20.30.127`, usable hosts `.65–.126`.

### IPv4 header fields that matter in forensics

TTL (OS fingerprinting: Linux starts at 64, Windows at 128, network gear at 255), Protocol (1 = ICMP, 6 = TCP, 17 = UDP), Source/Destination IP, fragmentation flags (fragmentation attacks used to evade IDS), and Identification.

### IPv6

128-bit addresses, no broadcast, NDP replaces ARP, SLAAC auto-configuration. **Security gotcha:** many networks run IPv6 by accident. Firewalls that filter only IPv4 leave IPv6 wide open, and rogue Router Advertisements enable MITM.

### Routing and ICMP

- **Routing protocols:** OSPF (interior), **BGP** (between autonomous systems on the internet). **BGP hijacking** (for example Pakistan Telecom / YouTube 2008, the 2018 Amazon Route 53 / MyEtherWallet hijack) reroutes traffic. Defenses: RPKI route origin validation, prefix filtering.
- **ICMP:** ping (echo), traceroute (TTL exceeded), destination unreachable. Abused for ping sweeps, Smurf attacks and ICMP tunneling (data exfiltration). Don't block all ICMP: Path MTU Discovery needs type 3 code 4.

---

## §6 The Link Layer

- **MAC address:** 48 bits; the first 24 bits are the vendor OUI.
- **ARP** maps IP → MAC. It has no authentication, which makes **ARP spoofing / poisoning** easy (module 03).
- **Switches** learn MACs into a CAM table. **MAC flooding** overflows the table so the switch acts like a hub and the attacker can sniff all traffic.
- **VLANs (802.1Q)** separate broadcast domains. **VLAN hopping** happens through switch spoofing (DTP) or double tagging.

**Defenses:**

| Attack | Control |
|--------|---------|
| ARP spoofing | **Dynamic ARP Inspection (DAI)** + DHCP snooping |
| Rogue DHCP | **DHCP snooping** (trusted ports only) |
| MAC flooding | **Port security** (max MACs per port) |
| VLAN hopping | Disable DTP, set an unused native VLAN, prune trunks |
| Rogue devices | **802.1X** port-based NAC with certificates |

---

## §7 Security Protocols: SSL/TLS, IPSec, VPNs, SSH

### TLS 1.3 (the default for everything)

```mermaid
sequenceDiagram
  Client->>Server: ClientHello (supported ciphers, key_share X25519, SNI)
  Server->>Client: ServerHello (key_share) + {Certificate, CertVerify, Finished} encrypted
  Client->>Server: {Finished}
  Note over Client,Server: 1-RTT; forward secrecy via ephemeral ECDHE
```

- TLS 1.3 removed RSA key exchange, CBC ciphers, SHA-1, compression and renegotiation. **Forward secrecy** is mandatory.
- Only 5 cipher suites, for example `TLS_AES_128_GCM_SHA256`, `TLS_AES_256_GCM_SHA384`, `TLS_CHACHA20_POLY1305_SHA256`.
- 0-RTT resumption is replayable, so allow it only for idempotent requests.
- **Disable:** SSLv2/3, TLS 1.0/1.1 (POODLE, BEAST). PCI-DSS requires TLS 1.2+.
- **mTLS:** the client also presents a certificate. Used for service-to-service traffic and for bank API partners.
- **HSTS** (+ preload) prevents SSL stripping. **Certificate pinning** in mobile banking apps hinders MITM proxies.

```bash
openssl s_client -connect bank.com:443 -servername bank.com -tls1_3 </dev/null
nmap --script ssl-enum-ciphers -p 443 bank.com
```

### IPSec

| Component | Function |
|-----------|---------|
| IKEv2 | Negotiates SAs and keys (UDP 500/4500 with NAT-T) |
| AH (Authentication Header) | Integrity + authentication; **no encryption**; breaks with NAT |
| ESP (Encapsulating Security Payload) | Encryption + integrity (the one you use) |
| Transport mode | Protects payload only (host-to-host) |
| Tunnel mode | Encapsulates the entire IP packet (site-to-site VPN gateways) |

### VPNs

- **Site-to-site** (IPSec): branch ↔ data center, or on-prem ↔ AWS VPC (often with Direct Connect plus an IPSec overlay for encryption).
- **Remote access:** IPSec/IKEv2, SSL VPN, **WireGuard** (modern, small codebase, Noise protocol).
- **Split vs full tunnel:** full tunnel sends all traffic through corporate inspection, which banks prefer.
- **The trend:** **ZTNA** (Zero Trust Network Access) replaces flat VPN access with per-application, identity-aware access. VPN appliances (Pulse/Ivanti, Fortinet, Citrix) are among the most-exploited edge devices, so patch them within days.

### SSH

- Port 22. Key-based authentication (Ed25519). Disable password login and root login.
- Use a **bastion / jump host** or SSM Session Manager / IAP. Prefer **SSH certificates** (short-lived, signed by a CA) over static `authorized_keys`.

```bash
ssh-keygen -t ed25519 -C "kjana@laptop"
ssh -J bastion.bank.internal app01.bank.internal
# /etc/ssh/sshd_config
PasswordAuthentication no
PermitRootLogin no
AllowGroups ssh-admins
```

---

## §8 Lab Setup (VirtualBox)

### macOS Apple Silicon (M1/M2/M3/M4)

1. Install **VirtualBox 7.1+** (it supports Arm64 hosts). Alternatives: **UTM** or **VMware Fusion** (free for personal use).
2. You need **ARM64 guest images**: Kali Linux ARM64 installer, Ubuntu Server ARM64. x86 images (Metasploitable 2, many CTF VMs) will not run natively. Use UTM emulation (slow) or a cloud lab instead.
3. Network: create a **Host-only** or **NAT Network** so attacker and target VMs see each other but are isolated from your home LAN.
4. Snapshot each VM after setup.

### Windows (x86-64)

1. Enable virtualization (VT-x/AMD-V) in BIOS. If you use VirtualBox, disable Hyper-V conflicts or use VirtualBox 7 with Hyper-V support.
2. Install VirtualBox and the Extension Pack.
3. Import the Kali VirtualBox `.ova` and a vulnerable target (Metasploitable 2, DVWA, OWASP Juice Shop in Docker).
4. Network: **Host-only adapter** (`192.168.56.0/24`) for the attacker ↔ target lab. Add a second NAT adapter on Kali only for updates.

**Golden rule:** Only scan or attack systems you own or have **written authorization** for. Unauthorized scanning can violate the CFAA (US), the Computer Misuse Act (UK), or the IT Act 2000 (India).

---

## §9 NMAP Port Scanning

### Port states

| State | Meaning |
|-------|--------|
| open | A service is accepting connections |
| closed | Reachable, but nothing is listening (RST) |
| filtered | No response or ICMP unreachable: a firewall is dropping |
| unfiltered | Reachable (ACK scan), state unknown |
| open\|filtered | UDP/NULL/FIN scans with no response |

### Scan types

| Flag | Scan | How it works | Notes |
|------|------|-------------|-------|
| `-sS` | SYN ("half-open") | SYN → SYN/ACK = open → send RST | Default as root; stealthier |
| `-sT` | TCP connect | Full handshake | Default without root; gets logged |
| `-sU` | UDP | Empty/protocol payload; ICMP unreachable = closed | Slow |
| `-sA` | ACK | Maps firewall rules (stateful or not) | |
| `-sN/-sF/-sX` | NULL/FIN/Xmas | RFC 793 trick; doesn't work against Windows | |
| `-sn` | Ping sweep | Host discovery only | |
| `-Pn` | Skip discovery | Treat all hosts as up | When ICMP is blocked |

### Command cheat sheet

```bash
nmap -sn 192.168.56.0/24                       # who is alive
sudo nmap -sS -p- --min-rate 1000 192.168.56.101   # all 65535 TCP ports
nmap -sV -sC -O -p 21,22,80,445 192.168.56.101     # versions, default scripts, OS
sudo nmap -sU --top-ports 50 192.168.56.101
nmap -A -T4 192.168.56.101                     # aggressive: -O -sV -sC --traceroute
nmap --script vuln 192.168.56.101
nmap -oA scans/target 192.168.56.101           # normal, XML, grepable outputs
```

Timing: `-T0` (paranoid) … `-T5` (insane). Evasion (for authorized red teams): `-f` (fragment), `-D RND:10` (decoys), `--source-port 53`.

### Lab: NMAP port scanning and solution

**Task:** Against the Metasploitable target, find live hosts, open ports, service versions, and one known-vulnerable service.

**Solution walkthrough:**

```bash
nmap -sn 192.168.56.0/24
# → 192.168.56.101 up
sudo nmap -sS -sV -p- 192.168.56.101
# 21/tcp  open ftp       vsftpd 2.3.4       ← backdoored version (CVE-2011-2523)
# 22/tcp  open ssh       OpenSSH 4.7p1
# 23/tcp  open telnet
# 80/tcp  open http      Apache 2.2.8
# 139/445 open netbios   Samba 3.x          ← usermap_script (CVE-2007-2447)
# 3306    open mysql     MySQL 5.0.51a
# 5432    open postgresql
nmap --script ftp-vsftpd-backdoor -p 21 192.168.56.101
```

**Report findings like a bank pen-tester:** asset, port/service, version, CVE, CVSS, evidence, business impact, remediation (upgrade, disable Telnet, restrict DB ports to the app tier).

**Defender view:** Detect scans with IDS signatures (many SYNs to many ports from one source), firewall logs, and honeypots. Run your own continuous external attack surface scans (Shodan, Censys, or internal tooling).

---

## §10 NAT (Network Address Translation)

- **Static NAT:** 1 private ↔ 1 public (for published servers).
- **Dynamic NAT:** a pool of public IPs.
- **PAT / NAT overload:** many private IPs share 1 public IP, tracked by source port. This is what your home router does.
- **DNAT / port forwarding:** public `:443` → internal `10.0.1.10:8443`.

**Security notes:**
- NAT is **not a firewall**. It hides internal addressing as a side effect, but stateful filtering is what actually protects you.
- NAT complicates forensics: you need **NAT translation logs** (timestamp + source port) to map a public IP back to an internal host. Banks retain these for incident investigations and law-enforcement requests.
- Cloud: AWS NAT Gateway gives private subnets outbound-only internet access. Pair it with **egress filtering** (proxy or Network Firewall allow-list) to stop exfiltration and C2.

---

## §11 Firewalls

| Generation | Inspects | Example |
|-----------|----------|---------|
| Packet filter (stateless) | IP/port/protocol per packet | Router ACLs, AWS NACLs |
| Stateful | Connection state table | iptables/nftables conntrack, AWS Security Groups |
| Application / proxy | Full L7 content | Squid, web proxies |
| NGFW | App-ID, user-ID, IPS, TLS inspection, URL filtering | Palo Alto, Fortinet, Check Point |
| WAF | HTTP specifics (SQLi, XSS, bots) | AWS WAF, Cloudflare, F5, ModSecurity + OWASP CRS |
| Host-based | Per-endpoint | Windows Defender Firewall, `ufw` |

### Rule design principles

1. **Default deny** (implicit deny at the end).
2. Rules are evaluated **top-down, first match wins**. Put specific rules before general ones.
3. **Egress filtering** matters as much as ingress (blocks C2 and exfiltration).
4. Every rule has an owner, a ticket and a business justification. Review rules periodically (PCI requires a review every 6 months).
5. Log denies **and** allows on critical segments.

### Example: iptables / nftables

```bash
# iptables: default drop, allow established, SSH from admin subnet, HTTPS from anywhere
iptables -P INPUT DROP
iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -p tcp --dport 22 -s 10.10.0.0/24 -j ACCEPT
iptables -A INPUT -p tcp --dport 443 -j ACCEPT
iptables -A INPUT -j LOG --log-prefix "DROP: "
```

### Network architecture (bank)

```mermaid
flowchart LR
  Internet --> DDoS[DDoS scrubbing / CDN] --> WAF --> EFW[External firewall]
  EFW --> DMZ[DMZ: web tier, reverse proxies]
  DMZ --> IFW[Internal firewall]
  IFW --> APP[App tier]
  APP --> DBFW[DB firewall] --> CDE[(CDE / core banking DB)]
  Users[Corporate users] --> NAC[802.1X NAC] --> IFW
```

**Defense in depth with dual vendors:** some banks run firewalls from two different vendors in series, so one vendor's zero-day doesn't open the whole path.

**AWS Security Groups vs NACLs:** SGs are stateful, attach to an ENI, and are allow-only. NACLs are stateless, attach to a subnet, support allow/deny, and use ordered rules.

---

## §12 Wireless Networks and Security

| Standard | Encryption | Status |
|----------|-----------|--------|
| WEP | RC4 with a 24-bit IV | **Broken** (cracked in minutes) |
| WPA (TKIP) | RC4 + TKIP | Deprecated |
| WPA2-Personal (PSK) | AES-CCMP | Vulnerable to offline dictionary attack on the captured 4-way handshake; KRACK (2017) |
| WPA2-Enterprise | 802.1X / EAP (EAP-TLS, PEAP) + RADIUS | Good if certificates are validated |
| **WPA3-Personal** | **SAE** (Dragonfly) — resists offline dictionary attacks, forward secrecy | Recommended |
| **WPA3-Enterprise** | 192-bit mode (CNSA suite) | Best for enterprises/banks |

### Wireless attacks

- **Evil twin / rogue AP:** an AP with the same SSID captures credentials. Defense: WIDS/WIPS, EAP-TLS with server certificate validation.
- **Deauthentication attack:** forged deauth frames knock clients off to capture handshakes. Defense: **802.11w Protected Management Frames** (mandatory in WPA3).
- **Handshake capture + offline crack** (aircrack-ng, hashcat mode 22000).
- **WPS PIN brute force** (Reaver). Disable WPS.
- **Karma / probe-request** attacks; Bluetooth attacks (BlueBorne).

```bash
# Authorized lab only
airmon-ng start wlan0
airodump-ng wlan0mon
aireplay-ng --deauth 5 -a <BSSID> wlan0mon
hashcat -m 22000 capture.hc22000 rockyou.txt
```

**Enterprise/bank design:** WPA3-Enterprise with EAP-TLS (device certificates from MDM), a separate guest SSID isolated to internet only, wireless kept **outside the PCI CDE** (or tightly segmented and quarterly rogue-AP scanning per PCI 11.2), and WIPS on all APs.

---

## Bank / FAANG lens

- **Google:** BeyondCorp plus an identity-aware proxy; the corporate network is not trusted.
- **Meta/Amazon:** micro-segmentation with service mesh mTLS, and an egress proxy allow-list for production.
- **Banks:** PCI CDE segmentation tested by a penetration test at least annually (every 6 months for service providers), network diagrams kept current, firewall rule recertification, SWIFT infrastructure in a dedicated secure zone, and TLS inspection at the egress proxy (with exceptions for privacy-sensitive categories such as health and banking sites).

## Interview questions (Quiz: Network Security)

1. **Walk through what happens when you type `https://bank.com`.** DNS → TCP handshake → TLS 1.3 handshake (SNI, certificate validation, ECDHE) → HTTP request → response, with HSTS and caching along the way.
2. **TCP vs UDP; why is UDP used for DDoS amplification?** Connectionless, so the source IP can be spoofed and small queries return large responses.
3. **Explain a SYN scan and why it's "stealthy".** It never completes the handshake, so older applications don't log it. IDS still sees it.
4. **Difference between stateful and stateless firewalls?** A connection-tracking table versus per-packet rules. Security Groups vs NACLs.
5. **Why is NAT not security?** It's address translation. Filtering comes from the stateful firewall.
6. **IPSec AH vs ESP; transport vs tunnel?** See §7.
7. **SPF vs DKIM vs DMARC?** IP authorization, cryptographic signature, alignment plus policy.
8. **How does TLS 1.3 provide forward secrecy?** Ephemeral (EC)DHE keys are discarded after the session. A later private-key compromise can't decrypt past traffic.
9. **What does 169.254.169.254 mean in a cloud SSRF?** The instance metadata service. Mitigate with IMDSv2 (session tokens, hop limit 1).
10. **WPA2-PSK vs WPA3-SAE?** WPA3 resists offline dictionary attacks and provides forward secrecy.
11. **How do you defend against ARP spoofing on a corporate LAN?** DAI + DHCP snooping + 802.1X, and encryption (TLS) so spoofing yields nothing readable.
12. **What is a DMZ?** A screened subnet between two firewalls hosting public-facing services.
