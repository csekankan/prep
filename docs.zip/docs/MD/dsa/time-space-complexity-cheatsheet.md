# Time & Space Complexity — The "Where Do I Get Stuck?" Cheatsheet

> Goal: be able to derive the complexity of *any* solution in under a minute — including the hard ones
> (Dijkstra, Dijkstra with extra state, 3-dimensional DP, bitmask DP, backtracking, amortized structures).

---

## 0. The One Formula That Solves 90% of Cases

```
Time  = (number of STATES) × (work per STATE)
Space = (number of STATES stored at once) + (recursion depth) + (auxiliary structures)
```

- **DP / memoization** → states = size of the memo table; work = number of transitions per state.
- **Graph search** → states = nodes (or `(node, extra variables)`); work = edges out of each state (+ heap cost).
- **Recursion without memo** → states = nodes in the recursion tree = `branching ^ depth`.
- **Loops** → states = number of iterations; work = cost of the loop body (watch for hidden costs!).

Whenever you are stuck, ask these 3 questions:

1. **What uniquely identifies a "state"?** (which variables change?)
2. **How many distinct values can each variable take?** → multiply them.
3. **From one state, how many next states do I try, and what does each try cost?**

---

## 1. Input Size → Allowed Complexity (≈10⁸ simple ops/sec)

| n (input size) | Max acceptable complexity | Typical technique |
|---|---|---|
| n ≤ 10–12 | O(n!), O(n · n!) | Permutations, brute force |
| n ≤ 20–25 | O(2ⁿ), O(n · 2ⁿ), O(n² · 2ⁿ) | Subsets, bitmask DP |
| n ≤ 100 | O(n⁴) | 4-nested loops, small DP |
| n ≤ 500 | O(n³) | Floyd-Warshall, interval DP |
| n ≤ 5,000 | O(n²) | 2D DP, all pairs |
| n ≤ 10⁵ – 10⁶ | O(n log n) | Sorting, heap, Dijkstra, segment tree |
| n ≤ 10⁷ – 10⁸ | O(n) | Two pointers, prefix sums, hashing |
| n ≥ 10⁹ | O(log n), O(√n), O(1) | Binary search, math |

Use this **backwards** in interviews: read constraints → guess the target complexity → guess the algorithm.
For Python, budget ≈10⁷ simple ops/sec (roughly 10× slower than C++/Java).

---

## 2. Loop Patterns (the building blocks)

| Code pattern | Complexity | Why |
|---|---|---|
| `for i in range(n)` | O(n) | |
| Two nested loops `0..n` | O(n²) | |
| `for i in range(n): for j in range(i, n)` | O(n²) | n + (n−1) + … + 1 = n(n+1)/2 |
| `while n > 0: n //= 2` | O(log n) | halving |
| `i = 1; while i < n: i *= 2` | O(log n) | doubling |
| `for i in range(n): j = 1; while j < n: j *= 2` | O(n log n) | |
| `for i in 1..n: for j in range(i, n, i)` | **O(n log n)** | harmonic: n/1 + n/2 + … + n/n = n·Hₙ ≈ n ln n (enumerating multiples / divisors of every number) |
| `i = 2; while i*i <= n` | O(√n) | |
| `while n > 1: n = sqrt(n)` | O(log log n) | |
| Sieve of Eratosthenes | O(n log log n) | |
| Two pointers, both only move forward | O(n) | each pointer moves ≤ n total |
| Sliding window (left & right move forward) | O(n) | amortized, NOT O(n²) even with inner `while` |

### Trap: "inner while loop ⇒ O(n²)" is often WRONG

```python
left = 0
for right in range(n):          # n times
    while window_invalid():     # looks nested...
        left += 1               # ...but left only moves forward, ≤ n TOTAL
```
Total work = n (right moves) + n (left moves) = **O(n)**. Same argument for **monotonic stack**:
each element is pushed once and popped at most once → O(n).

> Rule: **Count total movements of each pointer / total pushes+pops, not iterations per outer loop.**

---

## 3. Recursion

### 3.1 Recursion tree method (no memo)

```
Time ≈ (branching factor) ^ (depth) × (work per call)
```

| Recursion | Branching | Depth | Time | Space (stack) |
|---|---|---|---|---|
| `fib(n) = fib(n-1) + fib(n-2)` | 2 | n | O(2ⁿ) (tight: O(1.618ⁿ)) | O(n) |
| Subsets (take / skip) | 2 | n | O(2ⁿ) | O(n) |
| Permutations | n, n−1, … | n | O(n!) | O(n) |
| Binary search | 1 | log n | O(log n) | O(log n) recursive / O(1) iterative |
| Merge sort | 2 | log n | O(n log n) (n work per level) | O(n) |
| Tree DFS | — | h | O(n) | O(h): O(log n) balanced, O(n) skewed |

**Space of recursion = maximum depth, NOT total number of calls.** (fib is O(2ⁿ) time but O(n) space.)

### 3.2 Master Theorem — `T(n) = a·T(n/b) + O(nᵈ)`

| Condition | Result | Example |
|---|---|---|
| d > log_b(a) | O(nᵈ) | `T(n) = 2T(n/2) + n²` → O(n²) |
| d = log_b(a) | O(nᵈ log n) | Merge sort: `2T(n/2) + n` → O(n log n) |
| d < log_b(a) | O(n^(log_b a)) | Karatsuba: `3T(n/2) + n` → O(n^1.585) |

Quick ones to memorize:

| Recurrence | Result |
|---|---|
| `T(n) = T(n/2) + O(1)` | O(log n) |
| `T(n) = T(n/2) + O(n)` | O(n) (n + n/2 + n/4 … = 2n) — quickselect average |
| `T(n) = 2T(n/2) + O(1)` | O(n) — tree traversal |
| `T(n) = 2T(n/2) + O(n)` | O(n log n) |
| `T(n) = T(n-1) + O(1)` | O(n) |
| `T(n) = T(n-1) + O(n)` | O(n²) — quicksort worst case, selection sort |
| `T(n) = 2T(n-1) + O(1)` | O(2ⁿ) — Tower of Hanoi |

---

## 4. Dynamic Programming — The Hard Part Made Mechanical

### 4.1 The recipe

```
1. Write the state:      dp[a][b][c]
2. Range of each var:    a ∈ [0, A), b ∈ [0, B), c ∈ [0, C)
3. #states             = A × B × C
4. Transitions/state   = T   (how many choices / the size of the inner loop)
5. Time                = A × B × C × T
6. Space               = A × B × C   (or smaller with rolling arrays)
```

### 4.2 Classic DPs

| Problem | State | #States | Transition | Time | Space (optimized) |
|---|---|---|---|---|---|
| Climbing stairs / Fibonacci | `dp[i]` | n | O(1) | O(n) | O(1) |
| House robber | `dp[i]` | n | O(1) | O(n) | O(1) |
| Coin change (min coins) | `dp[amount]` | A | loop over k coins | O(A·k) | O(A) |
| 0/1 Knapsack | `dp[i][w]` | n·W | O(1) (take/skip) | O(n·W) | O(W) |
| LCS / Edit distance | `dp[i][j]` | n·m | O(1) | O(n·m) | O(min(n, m)) |
| LIS (basic) | `dp[i]` | n | loop over j < i | O(n²) | O(n) |
| LIS (patience + binary search) | — | n | O(log n) | O(n log n) | O(n) |
| Longest palindromic substring | `dp[i][j]` | n² | O(1) | O(n²) | O(n²) / O(1) expand-around-center |
| Matrix chain / Burst balloons (interval DP) | `dp[i][j]` | n² | loop over split k | **O(n³)** | O(n²) |
| Palindrome partitioning II | `dp[i]` + `isPal[i][j]` | n + n² | O(n) | O(n²) | O(n²) |
| Word break | `dp[i]` | n | loop all j < i, slice + hash O(n) | O(n³) | O(n) |
| Word break (j limited to max word length L) | `dp[i]` | n | L choices × slice O(L) | O(n·L²) | O(n) |
| Unique paths (grid) | `dp[r][c]` | R·C | O(1) | O(R·C) | O(C) |
| TSP (bitmask DP) | `dp[mask][i]` | 2ⁿ·n | loop over next j | **O(2ⁿ · n²)** | O(2ⁿ · n) |
| Digit DP | `dp[pos][tight][sum]` | D·2·S | 10 digits | O(D·2·S·10) | same |
| DP on trees | `dp[node][0/1]` | 2n | children (sum = n−1 total) | O(n) | O(n) |

> **Trap:** In tree DP / graph DP, "loop over children" is *not* multiplied by n — the sum of all
> children over all nodes = n − 1 edges. Total = O(n), not O(n²).

### 4.3 DP with 3 changing variables (where people get stuck)

**Example A — Best Time to Buy & Sell Stock with at most K transactions**

```
dp(i, k, holding)
  i       ∈ [0, n)       → n values
  k       ∈ [0, K]       → K+1 values
  holding ∈ {0, 1}       → 2 values
```
- States = n · (K+1) · 2
- Transitions = 2 (do nothing / buy-or-sell) → O(1)
- **Time = O(n·K)**, **Space = O(n·K)** → rolling over `i` gives **O(K)**.

**Example B — Cherry Pickup (two people walking a grid at once)**

```
dp(r1, c1, r2)      # c2 is DERIVED: r1 + c1 = r2 + c2  (same number of steps)
```
- Naive 4 variables (r1, c1, r2, c2) → n⁴ states. But c2 is determined by the others → **n³ states**.
- Transitions = 4 (each person moves down/right) → O(1)
- **Time = O(n³)**, **Space = O(n³)** (or O(n²) by iterating over step count).

> **Key trick:** if one variable can be computed from the others, it is **not** a dimension of the state.
> Always check for derived variables before multiplying.

**Example C — Number of ways to roll `d` dice with `f` faces to reach `target`**

```
dp(i, sum)          i ∈ [0, d], sum ∈ [0, target]   → d · target states
transition: loop face 1..f                          → f
Time = O(d · target · f)    Space = O(target) with rolling array
```
(With prefix sums the inner loop becomes O(1) → O(d · target).)

**Example D — Out of Boundary Paths `dp(moves, r, c)`**

- States = M · R · C; transitions = 4 → **Time O(M·R·C)**, **Space O(R·C)** rolling over moves.

**Example E — Paint House with K colors `dp(i, color)`**

- States = n·K; transition = loop over K previous colors → **O(n·K²)**.
- Optimization: keep only best & second best of previous row → **O(n·K)**.

### 4.4 Memoization pitfalls (hidden costs)

| Mistake | Effect |
|---|---|
| Passing **slices / substrings** (`s[i:]`) as the memo key | Each call costs O(n) to build + hash → multiply by n |
| Using a **tuple / list as key** that you rebuild every call | O(len) per call |
| `@lru_cache` on a function with a **list / set** argument | `TypeError: unhashable` — converting to `tuple`/`frozenset` each call costs O(size) |
| Forgetting the memo is touched once per state, but each state loops `T` times | You must multiply by T |
| Python recursion depth with n = 10⁵ | Stack overflow → switch to bottom-up |

> **Pass indices, not substrings.** `dp(i, j)` beats `dp(s[i:j])` by a factor of n.

---

## 5. Graph Algorithms

### 5.1 Reference table

| Algorithm | Time | Space | Notes |
|---|---|---|---|
| BFS / DFS (adjacency list) | O(V + E) | O(V) | adjacency **matrix** → O(V²) |
| BFS on grid R×C | O(R·C) | O(R·C) | V = RC, E ≈ 4RC |
| Topological sort (Kahn / DFS) | O(V + E) | O(V) | |
| 0-1 BFS (deque) | O(V + E) | O(V) | edge weights only 0 or 1 |
| **Dijkstra (binary heap)** | **O((V + E) log V)** | O(V + E) | standard answer |
| Dijkstra (lazy, push duplicates) | O(E log E) = O(E log V) | O(E) heap | log E ≤ 2·log V since E ≤ V² |
| Dijkstra (array, no heap) | O(V²) | O(V) | better for very dense graphs (E ≈ V²) |
| Dijkstra (Fibonacci heap) | O(E + V log V) | O(V) | theoretical |
| Bellman-Ford | O(V · E) | O(V) | negative edges |
| Bellman-Ford limited to K edges | O(K · E) | O(V) | "cheapest flight within K stops" alternative |
| SPFA | avg O(E), worst O(V·E) | O(V) | |
| Floyd-Warshall | O(V³) | O(V²) | all pairs |
| Kruskal | O(E log E) | O(V) | sorting dominates; DSU is ~O(1) |
| Prim (heap) | O(E log V) | O(V + E) | |
| Union-Find (path compression + rank) | O(α(n)) ≈ O(1) per op | O(n) | α = inverse Ackermann ≤ 4 |
| Tarjan / Kosaraju (SCC, bridges) | O(V + E) | O(V) | |
| A* | worst O(E log V) | O(V) | depends on heuristic |

### 5.2 Why Dijkstra is O((V + E) log V) — derive it, don't memorize it

```python
dist = [inf] * V; dist[src] = 0
heap = [(0, src)]
while heap:
    d, u = heappop(heap)              # (1)
    if d > dist[u]: continue          # (2) stale entry → skip
    for v, w in adj[u]:               # (3)
        if d + w < dist[v]:
            dist[v] = d + w
            heappush(heap, (dist[v], v))  # (4)
```

- Each node is **finalized once**; when finalized, its edges are scanned → total edge scans = **E**.
- Each edge scan can cause **at most 1 push** → at most **E pushes** (+1 for the source).
- Each push / pop on a heap of size ≤ E costs **O(log E)**.
- Total = O((V + E) · log E) = **O((V + E) log V)** because log E ≤ log V² = 2 log V.
- **Space**: dist array O(V) + heap can hold up to O(E) stale entries → **O(V + E)**.

> **Stuck point:** "Why not V log V?" — because every *edge relaxation* may push into the heap, not
> every node. The heap work is driven by **edges**.

> **Stuck point:** forgetting line (2) doesn't break correctness (stale pops can't relax anything),
> but each stale pop rescans `adj[u]` → up to O(E) pops × deg(u) wasted work. Always keep the stale check.

### 5.3 Dijkstra / BFS on a **state graph** (2 or 3 changing variables)

**This is the #1 place people get stuck.** The trick:

```
Treat (node, var1, var2, ...) as ONE node of a new, bigger graph.

V' = V × |var1| × |var2| × ...          (number of states)
E' = E × |var1| × |var2| × ...          (each original edge exists for every combination of extra vars)
     (+ any extra "state-only" transitions, e.g. "refuel", "use a coupon")

Dijkstra time = O((V' + E') log V')
BFS time      = O(V' + E')
Space         = O(V' + E')   (dist table V', heap up to E')
```

#### Example 1 — Cheapest Flights Within K Stops (2 variables: node, stops)

```
state = (city, stops_used)       city ∈ V, stops ∈ [0, K+1]
V' = V · (K+2)        E' = E · (K+2)
Dijkstra: O(E·K · log(V·K))           Space: O(V·K + E·K)
Bellman-Ford K+1 rounds: O(K · E)     Space: O(V)        ← usually the better answer
(K stops = K+1 edges; copy dist each round so one round can't chain multiple edges)
```

#### Example 2 — Shortest Path with Obstacle Elimination (grid, LC 1293)

```
state = (r, c, eliminations_left)     V' = R·C·(K+1),  each state has 4 moves
BFS (all edges weight 1): O(R·C·K)    Space: O(R·C·K)
Note: if K ≥ R + C − 3 (cells strictly between corners on a Manhattan path), answer is R + C − 2 → O(1).
```

#### Example 3 — Dijkstra with 3 variables: (node, fuel, coupons)

> "Travel from src to dst. Each road costs time and fuel. Tank capacity F. At some cities you can
> refuel. You also have C discount coupons that halve a road's cost."

```
state = (node, fuel, coupons_left)
  node    → V values
  fuel    → F+1 values
  coupons → C+1 values

V' = V · (F+1) · (C+1)
Transitions from one state:
  - for each outgoing edge: use it normally            → deg(u)
  - for each outgoing edge: use it with a coupon       → deg(u)
  - refuel by 1 unit (if city allows)                  → 1
E' ≈ (2E + V) · (F+1) · (C+1)

Time  = O( E·F·C · log(V·F·C) )
Space = O( V·F·C )  for dist table   (+ heap up to E·F·C in lazy Dijkstra)
```

**Plug in numbers before committing:** V = 100, E = 1000, F = 100, C = 10
→ V' = 100·101·11 ≈ 1.1·10⁵ states, E' ≈ 2·1000·101·11 ≈ 2.2·10⁶ edges,
log₂(V') ≈ 17 → ≈ 4·10⁷ ops ✅ fine.
If F = 10⁵ instead → E' ≈ 2.2·10⁹ ✗ — you must compress the fuel dimension.

#### Example 4 — Shortest Path Visiting All Nodes (bitmask state, LC 847)

```
state = (node, visited_mask)    V' = n · 2ⁿ
each state has deg(node) edges  E' = E · 2ⁿ  ≤ n² · 2ⁿ
BFS: O(n² · 2ⁿ)     Space: O(n · 2ⁿ)          (n ≤ 12 → 12²·4096 ≈ 6·10⁵ ✅)
```

#### Example 5 — Dijkstra on grid ("Path With Minimum Effort", "Swim in Rising Water")

```
V = R·C,  E = 4·R·C
Dijkstra: O(R·C · log(R·C))
Alternative: binary search on answer + BFS: O(R·C · log(maxValue))
```

#### Example 6 — Bus Routes / "nodes connected by groups"

- BFS over stops connecting via each route: if you re-scan a route every time you reach one of its
  stops → each route of length L is scanned up to L times → O(Σ L²) ✗.
- **Mark each route as used once** → each route scanned once → O(Σ route lengths) ✅.

> **Rule:** in any state-graph problem, the dominant cost is **(#states) × (transitions per state)**.
> Write both down explicitly, multiply, plug in max constraints, then decide.

---

## 6. Backtracking

| Problem | Time | Space (excluding output) | Why |
|---|---|---|---|
| Subsets | O(n · 2ⁿ) | O(n) | 2ⁿ subsets × O(n) copy each |
| Permutations | O(n · n!) | O(n) | n! leaves × O(n) copy |
| Combinations C(n, k) | O(k · C(n,k)) | O(k) | |
| Combination sum (target T, min value m) | O(n^(T/m + 1)) loose bound | O(T/m) | depth ≤ T/m, branching ≤ n |
| N-Queens | O(n!) | O(n) | row by row, ≤ n, n−1, … choices |
| Sudoku | O(9^(empty cells)) worst | O(81) | |
| Word Search (grid R×C, word L) | O(R·C · 4 · 3^(L−1)) | O(L) | first step 4 dirs, then 3 (can't go back) |
| Generate parentheses | O(4ⁿ / √n) | O(n) | Catalan Cₙ ≈ 4ⁿ / n^1.5 results × O(n) per string |
| Palindrome partitioning | O(n · 2ⁿ) | O(n) | 2ⁿ⁻¹ ways to cut |

> **Stuck point:** "Why multiply by n?" — because **copying the current path** into the result
> (`res.append(path[:])`) costs O(n). If the question asks for *count* only, drop the factor n.

**Output space:** if you return all 2ⁿ subsets, the output alone is O(n·2ⁿ). Interviewers usually
want "auxiliary space" → recursion depth + current path = O(n). **State which one you mean.**

---

## 7. Data Structure Operation Costs

| Structure | Access | Search | Insert | Delete | Notes |
|---|---|---|---|---|---|
| Array / Python list | O(1) | O(n) | O(1)* end / O(n) middle | O(1) end / O(n) middle | *amortized append |
| Hash map / set | — | O(1) avg, O(n) worst | O(1) avg | O(1) avg | worst case on collisions |
| Linked list | O(n) | O(n) | O(1) at known node | O(1) at known node | |
| Deque | O(1) ends | O(n) | O(1) ends | O(1) ends | |
| Binary heap | O(1) top | O(n) | O(log n) | O(log n) pop | `heapify` is **O(n)**, not n log n |
| Balanced BST / TreeMap / SortedList | O(log n) | O(log n) | O(log n) | O(log n) | |
| Trie | — | O(L) | O(L) | O(L) | space O(total chars × alphabet) |
| Segment tree | — | O(log n) query | O(log n) update | — | build O(n), space O(4n) |
| Fenwick (BIT) | — | O(log n) prefix | O(log n) | — | space O(n) |
| Union-Find | — | O(α(n)) | O(α(n)) | — | |
| Sorting | — | — | — | — | O(n log n) time; Python Timsort O(n) space |
| Counting / radix sort | — | — | — | — | O(n + k) / O(d·(n + b)) |

---

## 8. Hidden Costs That Silently Add a Factor of n

| Code (Python, similar elsewhere) | Real cost |
|---|---|
| `x in my_list` | O(n) — use a set |
| `my_list.pop(0)` / `insert(0, x)` | O(n) — use `deque` |
| `s[i:j]`, `arr[i:j]` | O(j − i) copy |
| `s += c` inside a loop (strings are immutable) | O(n²) total — use list + `''.join` |
| `sorted(...)` / `.sort()` inside a loop of k iterations | O(k · n log n) |
| `min(list)` / `max(list)` / `sum(list)` inside a loop | O(n) each |
| `list.index(x)`, `list.remove(x)`, `list.count(x)` | O(n) |
| `str(n)` / `int(s)` on big numbers | not O(1) — at least O(digits), quadratic in older CPython |
| Hashing a string / tuple key | O(length) |
| Copying `path[:]`, `dict.copy()`, `set(...)` | O(size) |
| Java `String.substring` (Java 7u6+) | O(length) copy |
| Recursion in Python | each frame is heavy; depth limit ~1000 by default |

---

## 9. Amortized Analysis (looks expensive, isn't)

| Case | Looks like | Actually | Argument |
|---|---|---|---|
| Dynamic array append | O(n) on resize | **O(1) amortized** | doubling: total copies 1 + 2 + 4 + … < 2n |
| Monotonic stack / queue | O(n²) | **O(n)** | each element pushed once, popped once |
| Sliding window with inner `while` | O(n²) | **O(n)** | left pointer moves ≤ n total |
| Union-Find with path compression | O(log n) | **O(α(n))** | |
| Hash map rehashing | O(n) sometimes | **O(1) amortized** | same doubling argument |
| BFS where each node enqueued once | — | O(V + E) | mark visited **when pushing**, not when popping |

> **Stuck point (BFS):** mark visited **when you enqueue**. Marking when you dequeue lets a node be
> enqueued once per incoming edge → O(E) queue entries in total instead of O(V) (O(V²) in dense graphs),
> and if you don't skip already-visited pops, their neighbors get rescanned too.

---

## 10. Binary Search on the Answer

```
Time = O( log(range) × cost_of_check )
```

| Problem | Range | Check | Total |
|---|---|---|---|
| Koko eating bananas | max(piles) = M | O(n) | O(n log M) |
| Split array largest sum | sum(arr) = S | O(n) | O(n log S) |
| Min days to make bouquets | max(day) = D | O(n) | O(n log D) |
| Path with min effort (BS + BFS) | max height H | O(R·C) | O(R·C · log H) |
| Kth smallest in sorted n×n matrix | max − min = R | O(n) staircase count | O(n log R) |

> **Stuck point:** the log is over the **value range**, not over n.

---

## 11. Space Complexity Checklist

Add up **all** of these:

1. **Input copies** you create (sorting a copy, building adjacency list → O(V + E)).
2. **DP / memo table** → #states (minus dimensions you can roll).
3. **Recursion stack** → max depth (DFS on skewed tree / linked list-like graph = O(n)).
4. **Queues / heaps / stacks** → max simultaneous size
   (BFS queue on a complete binary tree ≈ n/2; lazy Dijkstra heap ≤ E).
5. **Visited sets / dist arrays** → #states.
6. **Output** — mention separately ("O(n) auxiliary, O(n·2ⁿ) including output").

**Rolling array rule:** if `dp[i]` only depends on `dp[i−1]` (or a fixed window of previous rows),
that dimension shrinks to O(1) (or O(window)).

```
dp[i][j]   depends on dp[i-1][*]        → O(m) space instead of O(n·m)
dp[i][j][k] depends on dp[i-1][*][*]    → O(J·K) instead of O(I·J·K)
```

Interval DP (`dp[i][j]` depends on shorter intervals in all directions) usually **cannot** be rolled.

---

## 12. Worked "Derive It Yourself" Examples

### 12.1 Two-variable DP with inner loop — Burst Balloons
```
dp[l][r] = max over k in (l, r) of dp[l][k] + dp[k][r] + nums[l]*nums[k]*nums[r]
States: n²   Transitions: n   →  Time O(n³), Space O(n²)
```

### 12.2 Number of Islands II (online union-find)
```
k additions, each: 4 neighbors × α(R·C)
Time O(R·C + k · α(R·C)) ≈ O(R·C + k)     Space O(R·C)
```

### 12.3 Top-K frequent elements
```
Counting: O(n)
Heap of size k over u unique: O(u log k)      → O(n + u log k)
Bucket sort: O(n)                              Space O(n)
```

### 12.4 Merge K sorted lists (N total nodes)
```
Heap of size k, each of N nodes pushed & popped once → O(N log k)   Space O(k)
Divide & conquer pairwise merging: log k levels × N work → O(N log k)
Naive merge one-by-one: N·k
```

### 12.5 LRU cache
```
HashMap + doubly linked list → get/put O(1), space O(capacity)
```

### 12.6 Word Ladder (BFS over words)
```
N words, length L, alphabet 26
Each word: try L positions × 26 letters, each forms a string O(L) and hashes O(L)
Time O(N · L² · 26)       Space O(N · L)
```

### 12.7 Minimum cost to reach city with discounts (Dijkstra, state = (node, discounts_left))
```
V' = V·(D+1), E' = 2·E·(D+1) (normal + discounted edge)
Time O(E·D · log(V·D))     Space O(V·D)
```

### 12.8 Swim in Rising Water
```
Dijkstra on grid (max instead of sum): O(n² log n)
Binary search + BFS: O(n² log n²) = O(n² log n)
Union-Find sorted by height: O(n² log n) for the sort + O(n² α)
```

---

## 13. 60-Second Interview Script

When asked "What's the complexity?", say it in this order:

1. "The **state** is `(…)`. Variable A has up to X values, B has Y values → **X·Y states**."
2. "From each state I try **T** transitions, each costing **c** (heap log / O(1) / substring O(L))."
3. "So time is **X·Y·T·c**. Plugging constraints: … ≈ 10⁷, which fits."
4. "Space: **memo/dist table X·Y**, plus **recursion depth / queue size** …, plus **output** if relevant."
5. "Could optimize by rolling dimension A → space Y" / "by removing derived variable" / "by pruning when …".

---

## 14. Final Cheat Card

```
Loops:          count total pointer movements, not iterations per loop
Recursion:      branching^depth  (space = depth)
Divide&Conquer: Master theorem
DP:             #states × transitions;  drop derived variables;  roll dimensions for space
Graph:          BFS/DFS O(V+E);  Dijkstra O((V+E) log V)
State graph:    V' = V × Π|extra vars|,  E' = E × Π|extra vars|  → then apply the graph formula
Backtracking:   #leaves × cost to copy path
Binary search on answer: log(value range) × check
Amortized:      each element enters & leaves once → O(n)
Hidden costs:   slicing, string concat, `in list`, pop(0), sort in loop, hashing long keys
Space:          table + recursion depth + queue/heap + (output)
```
