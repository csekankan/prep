# Production-Grade Multi-Region on AWS: Build and Deploy "Shortly" Across Regions

> A hands-on, FAANG-style tutorial built around **one small project**: a global URL shortener called **Shortly**.
> The app is tiny on purpose. The focus is everything around it: **VPC design, load balancers, compute (ECS Fargate and EC2), RDS/Aurora and DynamoDB replication, global routing, scaling, deployment, and failover**.
> The code doesn't have to run as-is. Every piece is explained so you understand **how it works and why it's built that way**.
> Companion: `AWS_MULTI_REGION_DEPLOYMENT_TUTORIAL.md` (strategies, runbooks, interview prep).

**Contents**

| Part | Topic |
|---|---|
| 1 | The project: what Shortly does and why it's a good multi-region example |
| 2 | Target architecture (global + regional) |
| 3 | Design decisions: active-active, data ownership, capacity math |
| 4 | Repository layout |
| 5 | Networking: VPC, public/private/data subnets, NAT, endpoints, security groups, cross-region peering |
| 6 | Load balancing: ALB, target groups, TLS, WAF |
| 7 | Compute option A: ECS on Fargate |
| 8 | Compute option B: EC2 Auto Scaling Group (and ECS on EC2) |
| 9 | Data option A: DynamoDB Global Tables |
| 10 | Data option B: Aurora Global Database vs RDS cross-region replicas |
| 11 | The application code (FastAPI) and how each piece uses the region |
| 12 | Global traffic: Route 53, health checks, Global Accelerator, CloudFront |
| 13 | Scaling: autoscaling, N+1 regional capacity, hot keys, quotas |
| 14 | Deployment: build once, regional waves |
| 15 | Walkthroughs: life of a request, replication timelines, a region failing |
| 16 | Observability and operations |
| 17 | Production readiness checklist |

---

# Part 1: The Project

## 1.1 What Shortly does

| Endpoint | What it does | Traffic share |
|---|---|---|
| `POST /v1/links` (API key required) | Create a short code for a long URL | ~1% |
| `GET /{code}` | Redirect (HTTP 302) to the long URL and record a click | ~98% |
| `GET /v1/links/{code}/stats` | Total clicks for a link, across all regions | ~1% |
| `POST /v1/accounts` | Sign up and get an API key | tiny |

## 1.2 Why it's a great multi-region teaching project

It's small, but it has every hard problem in miniature:

- **Read-heavy hot path** (redirects) that must be fast everywhere, which is the reason to run active-active.
- **Writes that can happen anywhere** (create link), so you have to avoid ID collisions across regions.
- **Counters** (clicks), the classic multi-region conflict problem.
- **Relational data with a single owner** (accounts, API keys, billing), so we use one writer region.
- **Async work** (click aggregation) through regional queues.
- **Read-your-writes**: you create a link in Oregon, and someone clicks it in Virginia 200 ms later.

## 1.3 Target numbers (what "production-grade" means here)

| Target | Value |
|---|---|
| Redirect p99 latency (in-region) | < 50 ms |
| Availability | 99.99% (about 52 minutes of downtime a year) |
| RTO (region loss) | < 5 minutes for redirects and link creation; < 15 minutes for signups |
| RPO | ~1 second (async replication) |
| Peak traffic | 50,000 redirects/s globally |

---

# Part 2: Target Architecture

## 2.1 The global picture

```
                                   Users (worldwide)
                                          │
                         ┌────────────────┴────────────────┐
                         │  Route 53: sho.rt (latency-based │
                         │  routing + health checks + ARC)  │
                         │  optional: CloudFront / Global   │
                         │  Accelerator in front            │
                         └────────┬───────────────┬────────┘
                                  │               │
               ┌──────────────────▼──┐         ┌──▼──────────────────┐
               │   us-east-1 (N.Va)  │         │  us-west-2 (Oregon) │
               │   ACTIVE            │         │  ACTIVE             │
               │   Aurora WRITER     │         │  Aurora reader      │
               └──────────┬──────────┘         └──────────┬──────────┘
                          │                               │
      DynamoDB Global Tables (links, link_stats)  ◀──── multi-active, ~1 s ────▶
      Aurora Global Database (accounts)           ───── storage-level, <1 s ───▶
      S3 (ALB logs, backups)                      ───── Cross-Region Replication ▶
      ECR images                                  ───── registry replication ───▶
      Secrets Manager, KMS multi-region keys      ───── replicas ───────────────▶
      VPC peering (private, for cross-region writes to Aurora writer)
```

## 2.2 One region, in detail

Both regions are **identical** (same Terraform modules, different inputs).

```
Region us-east-1 — VPC 10.10.0.0/16
┌──────────────────────────────────────────────────────────────────────────────────────────┐
│                    AZ a                     AZ b                     AZ c                │
│  PUBLIC     ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐         │
│  /24        │ ALB node         │    │ ALB node         │    │ ALB node         │ ◀── IGW │
│             │ NAT GW (+EIP)    │    │ NAT GW (+EIP)    │    │ NAT GW (+EIP)    │         │
│             └────────┬─────────┘    └────────┬─────────┘    └────────┬─────────┘         │
│  PRIVATE-APP┌────────▼─────────┐    ┌────────▼─────────┐    ┌────────▼─────────┐         │
│  /20        │ ECS tasks / EC2  │    │ ECS tasks / EC2  │    │ ECS tasks / EC2  │         │
│             │ api + worker     │    │ api + worker     │    │ api + worker     │         │
│             └────────┬─────────┘    └────────┬─────────┘    └────────┬─────────┘         │
│  PRIVATE-   ┌────────▼─────────┐    ┌────────▼─────────┐    ┌────────▼─────────┐         │
│  DATA /24   │ Aurora writer    │    │ Aurora reader    │    │ (spare/reader)   │         │
│  (no internet)                                                                         │
│             └──────────────────┘    └──────────────────┘    └──────────────────┘         │
│                                                                                          │
│  VPC endpoints: DynamoDB, S3 (gateway) · ECR, SQS, Logs, Secrets, STS, SSM (interface)   │
│  Regional services: SQS click-events queue + DLQ · CloudWatch · WAF on ALB               │
└──────────────────────────────────────────────────────────────────────────────────────────┘
```

**How a redirect flows in one region:**

1. DNS sends the user to the closest healthy region's **ALB** (public subnets).
2. **WAF** checks the request (rate limits, bad patterns).
3. The ALB forwards to a healthy **API task** in a private-app subnet (any AZ).
4. The task looks up the code in its **in-memory cache**, and on a miss reads **DynamoDB in its own region** through the **gateway endpoint** (no NAT, no internet).
5. It returns `302 Location: https://long-url...` and drops a click event on the **regional SQS queue**.
6. A **worker** in the same region batches click events and increments that region's counter in DynamoDB.

Nothing in this path leaves the region. That's the most important property of the design.

---

# Part 3: Design Decisions (The "Why")

## 3.1 Active-active, but with clear data ownership

| Data | Store | Who can write | Why |
|---|---|---|---|
| Links (`code → url`) | DynamoDB Global Table | **Any region** | Codes include a region tag, so two regions can never create the same code. No conflicts possible. |
| Click counters | DynamoDB Global Table | **Each region writes only its own row** (`code#region`) | No two regions update the same item, so last-writer-wins never loses counts. |
| Accounts, API keys, billing | Aurora PostgreSQL Global | **Only the primary region** | Relational, transactional, rarely written. Single writer = no conflicts. |
| Click events in flight | SQS (regional) | Local region | Queues never cross regions. |

> **The FAANG rule:** in a multi-active system, design so that **every item has exactly one writer at a time**. Then replication only has to copy data, never resolve conflicts.

## 3.2 Why both DynamoDB and Aurora?

- **DynamoDB** is the right tool for the hot path: single-digit-ms key lookups, effectively unlimited scale, and built-in multi-active replication.
- **Aurora** is the right tool for relational data with transactions (account + API key + plan in one transaction, joins for billing reports).
- Many real systems mix both. If you only want one, Part 10 explains how to run everything on either.

## 3.3 Capacity math: N+1 regions

If a region fails, its traffic moves to the remaining regions. **They must be able to absorb it immediately** (static stability: no waiting for scale-up during a crisis).

```
capacity each region must handle = peak global traffic / (N − 1)
```

| Regions (N) | Each region serves normally | Each region must be able to serve | Overprovisioning |
|---|---|---|---|
| 2 | 50% | 100% | 2x |
| 3 | 33% | 50% | 1.5x |
| 4 | 25% | 33% | 1.33x |

With 50,000 RPS peak and 2 regions, **each region must handle 50,000 RPS on its own**. That's why big companies prefer 3+ regions: it's cheaper per unit of resilience.

How to apply it:

- **Compute:** set autoscaling *minimums* so that each region at normal load runs at about 40–50% utilization (2 regions) and can absorb a doubling while autoscaling catches up.
- **DynamoDB:** on-demand tables scale automatically, but sudden 2x jumps on a cold table can throttle. Pre-warm (set warm throughput) or use provisioned capacity with headroom.
- **Aurora readers:** size the secondary region so it can be promoted and handle all writes and reads.
- **Quotas:** raise Fargate vCPU, EC2 instance limits, and ALB limits in **each** region to the full-failover numbers.

## 3.4 Why not "one primary + DR region"?

Because a standby region that never takes traffic **rots**. Config drifts, quotas are wrong, caches are cold, and nobody notices until the day you need it. Active-active means **both regions are proven working every minute**. Shortly is active-active for everything except Aurora writes.

---

# Part 4: Repository Layout

```
shortly/
├── app/
│   ├── main.py            # FastAPI app, routes
│   ├── config.py          # region-aware settings
│   ├── ids.py             # region-tagged short codes
│   ├── links.py           # DynamoDB link repository (+ owner-region fallback)
│   ├── stats.py           # per-region counters
│   ├── accounts.py        # Aurora: writer + local reader
│   ├── events.py          # publish click events to regional SQS
│   ├── worker.py          # consume clicks, batch increments
│   └── health.py          # live / ready
├── migrations/            # Alembic (runs once, against the writer)
├── Dockerfile
├── infra/
│   ├── modules/
│   │   ├── network/          # VPC, subnets, IGW, NAT, routes, endpoints, flow logs
│   │   ├── alb/              # ALB, listeners, target group, WAF, access logs
│   │   ├── ecs_service/      # Fargate cluster, task def, service, autoscaling
│   │   ├── ec2_asg/          # launch template, ASG, instance refresh, scaling
│   │   ├── sqs/              # queue + DLQ
│   │   └── regional_dns/     # region hostname + health check
│   └── live/prod/
│       ├── global/           # KMS MRK, ECR + replication, DynamoDB global tables, secrets
│       ├── us-east-1/
│       │   ├── network/
│       │   └── app/
│       ├── us-west-2/
│       │   ├── network/
│       │   └── app/
│       ├── peering/          # cross-region VPC peering + routes
│       ├── data/             # Aurora Global Database
│       └── dns/              # global records, health checks, ARC
└── .github/workflows/deploy.yml
```

**Apply order:** `global → us-*/network → peering → data → us-*/app → dns`.
Each folder has **its own Terraform state**, so a mistake in one region's apply can't touch the other region.

---

# Part 5: Networking (the foundation everything sits on)

## 5.1 The three subnet tiers, and why

| Tier | Contains | Route to internet | Why separate |
|---|---|---|---|
| **Public** | ALB nodes, NAT gateways | In and out through the Internet Gateway (IGW) | Only things that *must* be reachable from the internet live here |
| **Private-app** | ECS tasks or EC2 instances | **Out only**, via the NAT gateway in the same AZ | Apps can call external APIs and pull updates, but nothing on the internet can reach them directly |
| **Private-data** | Aurora, ElastiCache | **None** | Databases never need the internet. No route = no exfiltration path even if misconfigured |

## 5.2 CIDR plan

Non-overlapping per region, so regions can be connected privately (peering / Transit Gateway). Leave room to grow.

| Region | VPC | Public (/24 × 3) | Private-app (/20 × 3) | Private-data (/24 × 3) |
|---|---|---|---|---|
| us-east-1 | `10.10.0.0/16` | `10.10.0.0`, `.1.0`, `.2.0` | `10.10.16.0`, `.32.0`, `.48.0` | `10.10.200.0`, `.201.0`, `.202.0` |
| us-west-2 | `10.20.0.0/16` | `10.20.0.0`, `.1.0`, `.2.0` | `10.20.16.0`, `.32.0`, `.48.0` | `10.20.200.0`, `.201.0`, `.202.0` |

Why app subnets are **/20** (4,091 usable IPs each): with Fargate (`awsvpc` mode), **every task gets its own IP**. During a deploy you briefly run double the tasks. Small subnets are a common reason deployments get stuck with "no IPs available".

## 5.3 The network module

```hcl
# infra/modules/network/variables.tf
variable "name"     { type = string }          # e.g. "shortly-prod-use1"
variable "cidr"     { type = string }          # e.g. "10.10.0.0/16"
variable "az_count" {
  type    = number
  default = 3
}
```

```hcl
# infra/modules/network/main.tf
data "aws_availability_zones" "this" {
  state = "available"
}

locals {
  azs = slice(data.aws_availability_zones.this.names, 0, var.az_count)

  public_cidrs = [for i in range(var.az_count) : cidrsubnet(var.cidr, 8, i)]        # /24
  app_cidrs    = [for i in range(var.az_count) : cidrsubnet(var.cidr, 4, i + 1)]    # /20
  data_cidrs   = [for i in range(var.az_count) : cidrsubnet(var.cidr, 8, 200 + i)]  # /24
}

resource "aws_vpc" "this" {
  cidr_block           = var.cidr
  enable_dns_support   = true
  enable_dns_hostnames = true          # required for interface endpoints' private DNS
  tags = { Name = var.name }
}

# ---------- Public tier ----------
resource "aws_internet_gateway" "this" {
  vpc_id = aws_vpc.this.id
  tags   = { Name = "${var.name}-igw" }
}

resource "aws_subnet" "public" {
  count                   = var.az_count
  vpc_id                  = aws_vpc.this.id
  cidr_block              = local.public_cidrs[count.index]
  availability_zone       = local.azs[count.index]
  map_public_ip_on_launch = false      # nothing gets a public IP by accident
  tags = { Name = "${var.name}-public-${local.azs[count.index]}", tier = "public" }
}

resource "aws_route_table" "public" {
  vpc_id = aws_vpc.this.id
  tags   = { Name = "${var.name}-public" }
}

resource "aws_route" "public_internet" {
  route_table_id         = aws_route_table.public.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_internet_gateway.this.id
}

resource "aws_route_table_association" "public" {
  count          = var.az_count
  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}

# ---------- NAT: one per AZ ----------
# A single NAT is cheaper but makes one AZ a dependency of all others.
# If AZ-a dies, apps in AZ-b and AZ-c lose outbound internet. One NAT per AZ keeps AZs independent.
resource "aws_eip" "nat" {
  count  = var.az_count
  domain = "vpc"
  tags   = { Name = "${var.name}-nat-${local.azs[count.index]}" }
}

resource "aws_nat_gateway" "this" {
  count         = var.az_count
  allocation_id = aws_eip.nat[count.index].id
  subnet_id     = aws_subnet.public[count.index].id
  tags          = { Name = "${var.name}-nat-${local.azs[count.index]}" }
  depends_on    = [aws_internet_gateway.this]
}

# ---------- Private-app tier ----------
resource "aws_subnet" "app" {
  count             = var.az_count
  vpc_id            = aws_vpc.this.id
  cidr_block        = local.app_cidrs[count.index]
  availability_zone = local.azs[count.index]
  tags = { Name = "${var.name}-app-${local.azs[count.index]}", tier = "app" }
}

resource "aws_route_table" "app" {
  count  = var.az_count                 # one per AZ so each AZ uses ITS OWN NAT
  vpc_id = aws_vpc.this.id
  tags   = { Name = "${var.name}-app-${local.azs[count.index]}" }
}

resource "aws_route" "app_nat" {
  count                  = var.az_count
  route_table_id         = aws_route_table.app[count.index].id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id         = aws_nat_gateway.this[count.index].id
}

resource "aws_route_table_association" "app" {
  count          = var.az_count
  subnet_id      = aws_subnet.app[count.index].id
  route_table_id = aws_route_table.app[count.index].id
}

# ---------- Private-data tier (no internet route at all) ----------
resource "aws_subnet" "data" {
  count             = var.az_count
  vpc_id            = aws_vpc.this.id
  cidr_block        = local.data_cidrs[count.index]
  availability_zone = local.azs[count.index]
  tags = { Name = "${var.name}-data-${local.azs[count.index]}", tier = "data" }
}

resource "aws_route_table" "data" {
  vpc_id = aws_vpc.this.id
  tags   = { Name = "${var.name}-data" }
}

resource "aws_route_table_association" "data" {
  count          = var.az_count
  subnet_id      = aws_subnet.data[count.index].id
  route_table_id = aws_route_table.data.id
}

resource "aws_db_subnet_group" "this" {
  name       = "${var.name}-db"
  subnet_ids = aws_subnet.data[*].id
}

# ---------- VPC endpoints ----------
# Gateway endpoints (free): traffic to DynamoDB/S3 stays on the AWS network and skips NAT.
# For Shortly this matters a lot: every redirect reads DynamoDB.
resource "aws_vpc_endpoint" "dynamodb" {
  vpc_id            = aws_vpc.this.id
  service_name      = "com.amazonaws.${data.aws_region.current.name}.dynamodb"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = aws_route_table.app[*].id
}

resource "aws_vpc_endpoint" "s3" {
  vpc_id            = aws_vpc.this.id
  service_name      = "com.amazonaws.${data.aws_region.current.name}.s3"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = aws_route_table.app[*].id
}

data "aws_region" "current" {}

# Interface endpoints (hourly + per-GB cost): private IPs in your subnets for AWS APIs.
# Needed so image pulls, logs, secrets, and queues work without NAT and keep working if NAT has issues.
resource "aws_security_group" "endpoints" {
  name   = "${var.name}-endpoints"
  vpc_id = aws_vpc.this.id
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.cidr]
  }
}

resource "aws_vpc_endpoint" "interface" {
  for_each            = toset(["ecr.api", "ecr.dkr", "logs", "sqs", "secretsmanager", "sts", "ssm", "ssmmessages", "ec2messages"])
  vpc_id              = aws_vpc.this.id
  service_name        = "com.amazonaws.${data.aws_region.current.name}.${each.key}"
  vpc_endpoint_type   = "Interface"
  subnet_ids          = aws_subnet.app[*].id
  security_group_ids  = [aws_security_group.endpoints.id]
  private_dns_enabled = true
}

# ---------- Flow logs (security + debugging "why can't A reach B?") ----------
resource "aws_flow_log" "this" {
  vpc_id               = aws_vpc.this.id
  traffic_type         = "REJECT"          # ALL is useful but costly; REJECT catches misconfigurations
  log_destination_type = "cloud-watch-logs"
  log_destination      = aws_cloudwatch_log_group.flow.arn
  iam_role_arn         = aws_iam_role.flow.arn
}

resource "aws_cloudwatch_log_group" "flow" {
  name              = "/vpc/${var.name}/flow"
  retention_in_days = 30
}
# (aws_iam_role.flow omitted: allows vpc-flow-logs.amazonaws.com to write to the log group)
```

```hcl
# infra/modules/network/outputs.tf
output "vpc_id"               { value = aws_vpc.this.id }
output "vpc_cidr"             { value = aws_vpc.this.cidr_block }
output "public_subnet_ids"    { value = aws_subnet.public[*].id }
output "app_subnet_ids"       { value = aws_subnet.app[*].id }
output "data_subnet_ids"      { value = aws_subnet.data[*].id }
output "app_route_table_ids"  { value = aws_route_table.app[*].id }
output "data_route_table_id"  { value = aws_route_table.data.id }
output "db_subnet_group_name" { value = aws_db_subnet_group.this.name }
output "nat_public_ips"       { value = aws_eip.nat[*].public_ip }   # give these to partners for allowlists
```

Use it per region:

```hcl
# infra/live/prod/us-east-1/network/main.tf
provider "aws" { region = "us-east-1" }

module "network" {
  source = "../../../../modules/network"
  name   = "shortly-prod-use1"
  cidr   = "10.10.0.0/16"
}

output "network" { value = module.network }
```

```hcl
# infra/live/prod/us-west-2/network/main.tf
provider "aws" { region = "us-west-2" }

module "network" {
  source = "../../../../modules/network"
  name   = "shortly-prod-usw2"
  cidr   = "10.20.0.0/16"
}

output "network" { value = module.network }
```

## 5.4 Security groups: a chain, not a wall

Security groups (SGs) are **stateful** firewalls attached to network interfaces. Production rule: **reference other SGs, not CIDRs**, so access follows the role, not the IP.

```
Internet ──443──▶ [sg-alb] ──8000──▶ [sg-app] ──5432──▶ [sg-db]
                                         │
                                         └──443──▶ VPC endpoints / NAT
```

```hcl
# lives in the app stack of each region
resource "aws_security_group" "alb" {
  name   = "${var.name}-alb"
  vpc_id = var.vpc_id

  ingress {
    description = "HTTPS from anywhere"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "HTTP, only to redirect to HTTPS"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_security_group" "app" {
  name   = "${var.name}-app"
  vpc_id = var.vpc_id
}

resource "aws_vpc_security_group_egress_rule" "alb_to_app" {
  security_group_id            = aws_security_group.alb.id
  referenced_security_group_id = aws_security_group.app.id
  from_port                    = 8000
  to_port                      = 8000
  ip_protocol                  = "tcp"
}

resource "aws_vpc_security_group_ingress_rule" "app_from_alb" {
  security_group_id            = aws_security_group.app.id
  referenced_security_group_id = aws_security_group.alb.id
  from_port                    = 8000
  to_port                      = 8000
  ip_protocol                  = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "app_out" {
  security_group_id = aws_security_group.app.id
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"         # outbound via NAT/endpoints; tighten with an egress proxy if required
}
```

The **DB security group** allows the local app SG **and** the other region's app subnets. Security group references don't work across regions, so the remote side uses CIDRs:

```hcl
resource "aws_security_group" "db" {
  name   = "shortly-prod-use1-db"
  vpc_id = var.vpc_id
}

resource "aws_vpc_security_group_ingress_rule" "db_from_local_app" {
  security_group_id            = aws_security_group.db.id
  referenced_security_group_id = var.local_app_sg_id
  from_port                    = 5432
  to_port                      = 5432
  ip_protocol                  = "tcp"
}

resource "aws_vpc_security_group_ingress_rule" "db_from_remote_app" {
  for_each          = toset(var.remote_app_cidrs)   # the other region's private-app subnets
  security_group_id = aws_security_group.db.id
  cidr_ipv4         = each.value
  from_port         = 5432
  to_port           = 5432
  ip_protocol       = "tcp"
}
```

**NACLs** (subnet-level, stateless) are usually left at default-allow, with SGs doing the real work. Some companies add a deny-by-default NACL on the data tier as defense in depth. If you do, remember NACLs are stateless: you must allow return traffic on ephemeral ports (1024–65535).

## 5.5 Cross-region private connectivity

**Why we need it:** an API task in `us-west-2` that handles a signup must write to the **Aurora writer in `us-east-1`**. That traffic should go over AWS's private backbone, not the internet.

Note: **Aurora Global Database and DynamoDB Global Tables replicate on their own**, through AWS-managed channels. They do **not** need your peering. Peering is only for *your app* talking to a resource in the other region.

| Option | Good for | Limits |
|---|---|---|
| **Inter-region VPC peering** | 2–3 VPCs, simple | Not transitive; a full mesh grows as n² |
| **Transit Gateway + inter-region TGW peering** | Many VPCs/accounts, central routing, inspection | More cost (attachment + per-GB), more setup |
| **PrivateLink** | Exposing one service to other VPCs | Service-specific, not general routing |

Large companies use **Transit Gateway** (often managed by a central network team, shared via AWS RAM). For Shortly's two VPCs, peering is enough:

```hcl
# infra/live/prod/peering/main.tf
provider "aws" {
  alias  = "use1"
  region = "us-east-1"
}
provider "aws" {
  alias  = "usw2"
  region = "us-west-2"
}

data "terraform_remote_state" "use1" {
  backend = "s3"
  config  = { bucket = "acme-tfstate-prod", key = "prod/us-east-1/network.tfstate", region = "us-east-1" }
}
data "terraform_remote_state" "usw2" {
  backend = "s3"
  config  = { bucket = "acme-tfstate-prod", key = "prod/us-west-2/network.tfstate", region = "us-east-1" }
}

locals {
  use1 = data.terraform_remote_state.use1.outputs.network
  usw2 = data.terraform_remote_state.usw2.outputs.network
}

resource "aws_vpc_peering_connection" "use1_usw2" {
  provider    = aws.use1
  vpc_id      = local.use1.vpc_id
  peer_vpc_id = local.usw2.vpc_id
  peer_region = "us-west-2"
  tags        = { Name = "shortly-prod-use1-usw2" }
}

resource "aws_vpc_peering_connection_accepter" "usw2" {
  provider                  = aws.usw2
  vpc_peering_connection_id = aws_vpc_peering_connection.use1_usw2.id
  auto_accept               = true
}

# Routes: app + data tiers in each region know how to reach the other VPC.
resource "aws_route" "use1_to_usw2" {
  for_each                  = toset(concat(local.use1.app_route_table_ids, [local.use1.data_route_table_id]))
  provider                  = aws.use1
  route_table_id            = each.value
  destination_cidr_block    = local.usw2.vpc_cidr
  vpc_peering_connection_id = aws_vpc_peering_connection.use1_usw2.id
}

resource "aws_route" "usw2_to_use1" {
  for_each                  = toset(concat(local.usw2.app_route_table_ids, [local.usw2.data_route_table_id]))
  provider                  = aws.usw2
  route_table_id            = each.value
  destination_cidr_block    = local.use1.vpc_cidr
  vpc_peering_connection_id = aws_vpc_peering_connection.use1_usw2.id
}
```

Aurora endpoint DNS names resolve to **private IPs** even from outside the VPC, so the `us-west-2` app can resolve the `us-east-1` writer name and route to it over peering.

> **Design rule:** cross-region calls are allowed only on **rare, non-critical-path** operations (signups, API key creation). Redirects never cross regions. If the peering link breaks, redirects and link creation keep working everywhere.

---

# Part 6: Load Balancing

## 6.1 Which load balancer

| Type | Layer | Use for |
|---|---|---|
| **ALB** (Application) | HTTP/HTTPS (L7) | Web APIs: path/host routing, WAF, OIDC auth, HTTP/2, gRPC. **Shortly uses this.** |
| **NLB** (Network) | TCP/UDP/TLS (L4) | Extreme throughput, static IPs per AZ, non-HTTP protocols, PrivateLink |
| **GWLB** (Gateway) | L3 | Inline firewalls and appliances |

## 6.2 How an ALB actually works (what people get wrong)

- An ALB is **many nodes**, one or more per AZ, in your **public subnets**. DNS returns IPs of those nodes.
- It **scales automatically**, but scaling takes minutes. For a known event (launch, failover drill), traffic can jump faster than it scales. For huge planned spikes, ask AWS to **pre-warm** (or use LCU capacity reservation).
- **Cross-zone load balancing** is on by default for ALBs: every node spreads across targets in all AZs.
- **Deregistration delay**: when a task is being removed, the ALB stops sending new requests but lets in-flight requests finish for N seconds. Too long slows deploys, too short drops requests.
- **Health checks** decide which targets receive traffic. Combined with Route 53, an ALB with zero healthy targets makes the whole region "unhealthy" for DNS.

## 6.3 The ALB module

```hcl
# infra/modules/alb/main.tf
variable "name"              { type = string }
variable "vpc_id"            { type = string }
variable "public_subnet_ids" { type = list(string) }
variable "alb_sg_id"         { type = string }
variable "certificate_arn"   { type = string }   # ACM certs are REGIONAL: one per region
variable "target_type"       { type = string }   # "ip" for Fargate, "instance" for EC2
variable "logs_bucket"       { type = string }

resource "aws_lb" "this" {
  name                       = var.name
  load_balancer_type         = "application"
  internal                   = false
  subnets                    = var.public_subnet_ids
  security_groups            = [var.alb_sg_id]
  idle_timeout               = 60
  drop_invalid_header_fields = true       # blocks HTTP request smuggling tricks
  enable_deletion_protection = true

  access_logs {
    bucket  = var.logs_bucket
    prefix  = var.name
    enabled = true
  }
}

resource "aws_lb_target_group" "api" {
  name                 = "${var.name}-api"
  port                 = 8000
  protocol             = "HTTP"
  vpc_id               = var.vpc_id
  target_type          = var.target_type
  deregistration_delay = 20               # redirects are fast; no need to wait long
  slow_start           = 30               # new targets ramp up (warm caches, JIT, pools)

  health_check {
    path                = "/health/ready"
    matcher             = "200"
    interval            = 10
    timeout             = 3
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }
}

resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.this.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type = "redirect"
    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.this.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = var.certificate_arn
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.api.arn
  }
}

# ---------- WAF: first line of defense, per region ----------
resource "aws_wafv2_web_acl" "this" {
  name  = var.name
  scope = "REGIONAL"

  default_action {
    allow {}
  }

  rule {
    name     = "rate-limit-per-ip"
    priority = 1
    action {
      block {}
    }
    statement {
      rate_based_statement {
        limit              = 3000          # requests per 5 minutes per IP
        aggregate_key_type = "IP"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "rate-limit"
      sampled_requests_enabled   = true
    }
  }

  rule {
    name     = "aws-common"
    priority = 2
    override_action {
      none {}
    }
    statement {
      managed_rule_group_statement {
        vendor_name = "AWS"
        name        = "AWSManagedRulesCommonRuleSet"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "aws-common"
      sampled_requests_enabled   = true
    }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = var.name
    sampled_requests_enabled   = true
  }
}

resource "aws_wafv2_web_acl_association" "this" {
  resource_arn = aws_lb.this.arn
  web_acl_arn  = aws_wafv2_web_acl.this.arn
}

output "alb_arn"          { value = aws_lb.this.arn }
output "alb_arn_suffix"   { value = aws_lb.this.arn_suffix }
output "alb_dns_name"     { value = aws_lb.this.dns_name }
output "alb_zone_id"      { value = aws_lb.this.zone_id }
output "target_group_arn" { value = aws_lb_target_group.api.arn }
output "tg_arn_suffix"    { value = aws_lb_target_group.api.arn_suffix }
```

## 6.4 TLS certificates in two regions

```hcl
# in each region's app stack
resource "aws_acm_certificate" "api" {
  domain_name               = "sho.rt"
  subject_alternative_names = ["use1.sho.rt"]      # usw2 stack uses "usw2.sho.rt"
  validation_method         = "DNS"
  lifecycle { create_before_destroy = true }
}
```

Both regions present a valid cert for `sho.rt`. The region-specific names (`use1.sho.rt`, `usw2.sho.rt`) let health checks, canaries, and engineers hit **one region directly**.

---

# Part 7: Compute Option A — ECS on Fargate (default choice)

## 7.1 Choosing compute

| Option | You manage | Scaling speed | Cost at scale | Pick when |
|---|---|---|---|---|
| **ECS on Fargate** | Task definitions only | ~30–60 s per task | Higher per vCPU | Default for most services; small teams; spiky load |
| **ECS on EC2** (capacity providers) | Instances (AMIs, patching) + tasks | Instance boot + task | Lower (Graviton, Spot, Savings Plans) | Large steady fleets, GPUs, special instance types |
| **EC2 Auto Scaling (no orchestrator)** | Everything | Instance boot (1–3 min) | Lowest overhead | Simple single-app fleets, legacy apps |
| **EKS** (Kubernetes) | Cluster + add-ons + workloads | Pod fast, node slower | Good at scale | Org-wide platform, multi-cloud, K8s skills |
| **Lambda** | Code | Instant (with cold starts) | Great at low/spiky load | Event-driven, low steady traffic |

Shortly runs the **API and worker on Fargate**. Part 8 shows the same service on **EC2**.

## 7.2 How Fargate fits the network

- Each task gets an **ENI with a private IP** in a private-app subnet (`awsvpc` mode).
- The ALB target group uses `target_type = "ip"` and registers task IPs directly.
- Tasks pull images from **ECR in their own region** (via the ECR interface endpoints + S3 gateway endpoint, since image layers are stored in S3).
- Tasks get AWS credentials from the **task role**; no keys in env vars.

## 7.3 The ECS service module

```hcl
# infra/modules/ecs_service/main.tf
variable "name"              { type = string }      # shortly-prod-use1
variable "region"            { type = string }
variable "image"             { type = string }      # region-local ECR URI + tag
variable "app_subnet_ids"    { type = list(string) }
variable "app_sg_id"         { type = string }
variable "target_group_arn"  { type = string }
variable "alb_arn_suffix"    { type = string }
variable "tg_arn_suffix"     { type = string }
variable "min_tasks"         { type = number }
variable "max_tasks"         { type = number }
variable "env"               { type = map(string) }
variable "secrets"           { type = map(string) } # name => secret ARN (region-local replica)
variable "task_role_arn"     { type = string }
variable "execution_role_arn"{ type = string }

resource "aws_ecs_cluster" "this" {
  name = var.name
  setting {
    name  = "containerInsights"
    value = "enabled"
  }
}

resource "aws_ecs_cluster_capacity_providers" "this" {
  cluster_name       = aws_ecs_cluster.this.name
  capacity_providers = ["FARGATE", "FARGATE_SPOT"]
  default_capacity_provider_strategy {
    capacity_provider = "FARGATE"
    weight            = 1
    base              = 2
  }
}

resource "aws_cloudwatch_log_group" "api" {
  name              = "/ecs/${var.name}/api"
  retention_in_days = 30
}

resource "aws_ecs_task_definition" "api" {
  family                   = "${var.name}-api"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 512
  memory                   = 1024
  task_role_arn            = var.task_role_arn
  execution_role_arn       = var.execution_role_arn

  runtime_platform {
    cpu_architecture        = "ARM64"      # Graviton: ~20% cheaper
    operating_system_family = "LINUX"
  }

  container_definitions = jsonencode([{
    name         = "api"
    image        = var.image
    essential    = true
    portMappings = [{ containerPort = 8000, protocol = "tcp" }]
    command      = ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "2"]
    environment  = [for k, v in var.env : { name = k, value = v }]
    secrets      = [for k, v in var.secrets : { name = k, valueFrom = v }]
    stopTimeout  = 25                      # graceful shutdown window (> ALB deregistration delay)
    healthCheck = {
      command     = ["CMD-SHELL", "python -c \"import urllib.request; urllib.request.urlopen('http://localhost:8000/health/live')\""]
      interval    = 15
      timeout     = 3
      retries     = 3
      startPeriod = 10
    }
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = aws_cloudwatch_log_group.api.name
        awslogs-region        = var.region
        awslogs-stream-prefix = "api"
      }
    }
  }])
}

resource "aws_ecs_service" "api" {
  name                              = "api"
  cluster                           = aws_ecs_cluster.this.id
  task_definition                   = aws_ecs_task_definition.api.arn
  desired_count                     = var.min_tasks
  launch_type                       = "FARGATE"
  health_check_grace_period_seconds = 30
  enable_execute_command            = true     # "ssh" into tasks via SSM for debugging

  network_configuration {
    subnets          = var.app_subnet_ids      # spread across all 3 AZs
    security_groups  = [var.app_sg_id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = var.target_group_arn
    container_name   = "api"
    container_port   = 8000
  }

  deployment_minimum_healthy_percent = 100      # never drop below current capacity
  deployment_maximum_percent         = 200      # start new tasks before stopping old

  deployment_circuit_breaker {
    enable   = true
    rollback = true                             # failed deploy auto-reverts in THIS region
  }

  alarms {
    enable      = true
    rollback    = true
    alarm_names = ["${var.name}-api-5xx"]       # roll back if errors spike after deploy
  }

  lifecycle {
    ignore_changes = [desired_count]            # autoscaling owns it
  }
}

# ---------- Autoscaling ----------
resource "aws_appautoscaling_target" "api" {
  service_namespace  = "ecs"
  resource_id        = "service/${aws_ecs_cluster.this.name}/${aws_ecs_service.api.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  min_capacity       = var.min_tasks
  max_capacity       = var.max_tasks
}

# Scale on requests per task: the most direct signal for an I/O-bound API.
resource "aws_appautoscaling_policy" "api_rps" {
  name               = "${var.name}-api-rps"
  service_namespace  = "ecs"
  resource_id        = aws_appautoscaling_target.api.resource_id
  scalable_dimension = aws_appautoscaling_target.api.scalable_dimension
  policy_type        = "TargetTrackingScaling"
  target_tracking_scaling_policy_configuration {
    target_value = 800                          # req/min per task, from load tests
    predefined_metric_specification {
      predefined_metric_type = "ALBRequestCountPerTarget"
      resource_label         = "${var.alb_arn_suffix}/${var.tg_arn_suffix}"
    }
    scale_out_cooldown = 30
    scale_in_cooldown  = 300                    # scale in slowly, avoid flapping
  }
}

# A second policy on CPU protects against expensive requests. ECS scales out if EITHER says so.
resource "aws_appautoscaling_policy" "api_cpu" {
  name               = "${var.name}-api-cpu"
  service_namespace  = "ecs"
  resource_id        = aws_appautoscaling_target.api.resource_id
  scalable_dimension = aws_appautoscaling_target.api.scalable_dimension
  policy_type        = "TargetTrackingScaling"
  target_tracking_scaling_policy_configuration {
    target_value = 55
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
  }
}

output "cluster_name" { value = aws_ecs_cluster.this.name }
```

The **worker** service uses the same image with `command = ["python", "-m", "app.worker"]`, no load balancer, runs on `FARGATE_SPOT` with a `FARGATE` base (it's fine if Spot interrupts it; SQS redelivers), and scales on queue backlog:

```hcl
resource "aws_appautoscaling_policy" "worker_backlog" {
  name               = "${var.name}-worker-backlog"
  service_namespace  = "ecs"
  resource_id        = aws_appautoscaling_target.worker.resource_id
  scalable_dimension = "ecs:service:DesiredCount"
  policy_type        = "TargetTrackingScaling"
  target_tracking_scaling_policy_configuration {
    target_value = 500        # visible messages per worker task
    customized_metric_specification {
      metrics {
        id = "backlog_per_task"
        expression  = "visible / IF(tasks < 1, 1, tasks)"
        return_data = true
      }
      metrics {
        id = "visible"
        metric_stat {
          metric {
            namespace   = "AWS/SQS"
            metric_name = "ApproximateNumberOfMessagesVisible"
            dimensions {
              name  = "QueueName"
              value = var.queue_name
            }
          }
          stat = "Sum"
        }
        return_data = false
      }
      metrics {
        id = "tasks"
        metric_stat {
          metric {
            namespace   = "ECS/ContainerInsights"
            metric_name = "RunningTaskCount"
            dimensions {
              name  = "ClusterName"
              value = aws_ecs_cluster.this.name
            }
            dimensions {
              name  = "ServiceName"
              value = "worker"
            }
          }
          stat = "Average"
        }
        return_data = false
      }
    }
  }
}
```

## 7.4 IAM: least privilege, region-scoped

```hcl
data "aws_iam_policy_document" "task" {
  statement {
    sid     = "LinksAndStatsLocalReplica"
    actions = ["dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:UpdateItem", "dynamodb:Query", "dynamodb:BatchGetItem"]
    resources = [
      "arn:aws:dynamodb:${var.region}:${var.account_id}:table/shortly-prod-links",
      "arn:aws:dynamodb:${var.region}:${var.account_id}:table/shortly-prod-link-stats",
    ]
  }
  statement {
    sid     = "OwnerRegionFallbackReadOnly"     # read a just-created link from the region that made it
    actions = ["dynamodb:GetItem"]
    resources = ["arn:aws:dynamodb:*:${var.account_id}:table/shortly-prod-links"]
  }
  statement {
    sid       = "LocalQueue"
    actions   = ["sqs:SendMessage", "sqs:ReceiveMessage", "sqs:DeleteMessage", "sqs:ChangeMessageVisibility"]
    resources = [var.queue_arn]
  }
}
```

---

# Part 8: Compute Option B — EC2 Auto Scaling Group

Same service, but on plain EC2 instances. Useful to understand because it's what ECS-on-EC2 and EKS nodes are built from.

## 8.1 How it works

- A **launch template** describes an instance: AMI, instance type, IAM role, security group, and **user data** (boot script).
- An **Auto Scaling Group (ASG)** keeps N instances running across the private-app subnets in 3 AZs, replaces unhealthy ones, and registers them with the ALB target group (`target_type = "instance"`).
- **Deployments** use **instance refresh**: a new launch template version is rolled out gradually, keeping a minimum healthy percentage, and can roll back automatically.
- **No SSH, no bastion**: engineers connect with **SSM Session Manager** (that's why the network module has `ssm`, `ssmmessages`, `ec2messages` endpoints).

## 8.2 The EC2 module

```hcl
# infra/modules/ec2_asg/main.tf
variable "name"             { type = string }
variable "region"           { type = string }
variable "image"            { type = string }
variable "app_subnet_ids"   { type = list(string) }
variable "app_sg_id"        { type = string }
variable "target_group_arn" { type = string }
variable "alb_arn_suffix"   { type = string }
variable "tg_arn_suffix"    { type = string }
variable "min_size"         { type = number }
variable "max_size"         { type = number }
variable "instance_profile" { type = string }
variable "env"              { type = map(string) }

# Always-latest Amazon Linux 2023 (ARM) from the public SSM parameter, resolved PER REGION.
# AMI IDs differ by region: never hardcode them.
data "aws_ssm_parameter" "al2023" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-arm64"
}

resource "aws_launch_template" "api" {
  name_prefix   = "${var.name}-api-"
  image_id      = data.aws_ssm_parameter.al2023.value
  instance_type = "c7g.large"

  iam_instance_profile { name = var.instance_profile }
  vpc_security_group_ids = [var.app_sg_id]

  metadata_options {
    http_tokens                 = "required"   # IMDSv2 only (blocks SSRF credential theft)
    http_put_response_hop_limit = 2            # containers on the host can still reach IMDS
  }

  monitoring { enabled = true }

  block_device_mappings {
    device_name = "/dev/xvda"
    ebs {
      volume_size = 20
      volume_type = "gp3"
      encrypted   = true
    }
  }

  user_data = base64encode(templatefile("${path.module}/user_data.sh.tftpl", {
    region = var.region
    image  = var.image
    env    = var.env
  }))

  tag_specifications {
    resource_type = "instance"
    tags          = { Name = "${var.name}-api", service = "shortly-api" }
  }
}

resource "aws_autoscaling_group" "api" {
  name                      = "${var.name}-api"
  vpc_zone_identifier       = var.app_subnet_ids        # 3 AZs; ASG balances across them
  min_size                  = var.min_size
  max_size                  = var.max_size
  target_group_arns         = [var.target_group_arn]
  health_check_type         = "ELB"                     # replace instances the ALB marks unhealthy
  health_check_grace_period = 90
  default_instance_warmup   = 60
  capacity_rebalance        = true

  # Mix instance types so one capacity shortage doesn't block scaling during a failover.
  mixed_instances_policy {
    instances_distribution {
      on_demand_base_capacity                  = var.min_size
      on_demand_percentage_above_base_capacity = 50
      spot_allocation_strategy                 = "price-capacity-optimized"
    }
    launch_template {
      launch_template_specification {
        launch_template_id = aws_launch_template.api.id
        version            = aws_launch_template.api.latest_version
      }
      override { instance_type = "c7g.large" }
      override { instance_type = "c6g.large" }
      override { instance_type = "m7g.large" }
    }
  }

  # Rolling deploys: a new launch template version triggers this automatically.
  instance_refresh {
    strategy = "Rolling"
    preferences {
      min_healthy_percentage = 90
      max_healthy_percentage = 120
      instance_warmup        = 60
      checkpoint_percentages = [10, 50, 100]   # pause points to watch metrics
      checkpoint_delay       = 300
      auto_rollback          = true
    }
  }

  tag {
    key                 = "Name"
    value               = "${var.name}-api"
    propagate_at_launch = true
  }

  lifecycle {
    ignore_changes = [desired_capacity]
  }
}

resource "aws_autoscaling_policy" "rps" {
  name                   = "${var.name}-api-rps"
  autoscaling_group_name = aws_autoscaling_group.api.name
  policy_type            = "TargetTrackingScaling"
  target_tracking_configuration {
    target_value = 3000
    predefined_metric_specification {
      predefined_metric_type = "ALBRequestCountPerTarget"
      resource_label         = "${var.alb_arn_suffix}/${var.tg_arn_suffix}"
    }
  }
}
```

```bash
# infra/modules/ec2_asg/user_data.sh.tftpl
#!/bin/bash
set -euo pipefail
dnf install -y docker
systemctl enable --now docker

REGISTRY="$(echo '${image}' | cut -d/ -f1)"
aws ecr get-login-password --region ${region} | docker login --username AWS --password-stdin "$REGISTRY"

docker run -d --name api --restart always -p 8000:8000 \
%{ for k, v in env ~}
  -e ${k}='${v}' \
%{ endfor ~}
  '${image}' \
  uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2
```

The app fetches secrets itself from **Secrets Manager in its own region** at startup (via the instance role), so no secrets are baked into user data or the launch template.

## 8.3 ECS on EC2 (the middle ground)

Instead of `docker run` in user data, register the ASG as an **ECS capacity provider**. ECS then places tasks onto instances and **managed scaling** grows the ASG when tasks don't fit. You get ECS deployments and service discovery with EC2 pricing (Graviton, Spot, Savings Plans). Typical at large scale where Fargate's premium adds up.

```hcl
resource "aws_ecs_capacity_provider" "ec2" {
  name = "${var.name}-ec2"
  auto_scaling_group_provider {
    auto_scaling_group_arn         = aws_autoscaling_group.ecs_hosts.arn
    managed_termination_protection = "ENABLED"
    managed_scaling {
      status          = "ENABLED"
      target_capacity = 80        # keep 20% spare room on hosts for fast task placement
    }
  }
}
```

(The host ASG uses the ECS-optimized AMI, from the SSM parameter `/aws/service/ecs/optimized-ami/amazon-linux-2023/arm64/recommended/image_id`, and user data `echo ECS_CLUSTER=<name> >> /etc/ecs/ecs.config`.)

---

# Part 9: Data Option A — DynamoDB Global Tables (the hot path)

## 9.1 How global tables replicate

```
us-west-2 app writes item X                          us-east-1
   │                                                     ▲
   ▼                                                     │
DynamoDB (usw2 replica) ── commit locally (ms) ──▶ change captured ──▶ replicated ──▶ DynamoDB (use1 replica)
                                                      async, usually ~1 s
```

- Every replica is a **full read/write table**. Writes commit **locally** first (fast), then replicate asynchronously.
- **Conflict rule (default mode): last writer wins**, based on a timestamp. If two regions update the same item within the replication window, one update silently disappears.
- **Strongly consistent reads** are only strongly consistent **within one region**. Across regions, reads are eventually consistent.
- AWS also offers a **multi-Region strong consistency** mode for global tables (writes are synchronously replicated, with higher write latency and some feature limits). Check region support and limits before choosing it. Shortly doesn't need it because its design avoids conflicts.
- TTL deletes, GSIs, and item updates all replicate. Billing: you pay for writes in **every** replica region.

## 9.2 Table design for Shortly

```
Table: shortly-prod-links       (PK = code)
┌──────────┬──────────────────────────────┬────────────┬──────────┬────────────┐
│ code (PK)│ url                          │ owner_id   │ region   │ created_at │
├──────────┼──────────────────────────────┼────────────┼──────────┼────────────┤
│ aZ3k9Qw  │ https://example.com/very/... │ acct_123   │ us-west-2│ 1731300000 │
└──────────┴──────────────────────────────┴────────────┴──────────┴────────────┘
   last character "w" = created in us-west-2 → codes from different regions can't collide

Table: shortly-prod-link-stats  (PK = code, SK = region)
┌──────────┬────────────┬────────┐
│ code (PK)│ region (SK)│ clicks │
├──────────┼────────────┼────────┤
│ aZ3k9Qw  │ us-east-1  │ 18,204 │   ← only us-east-1 workers ever write this item
│ aZ3k9Qw  │ us-west-2  │  9,977 │   ← only us-west-2 workers ever write this item
└──────────┴────────────┴────────┘
   total clicks = sum over all rows for the code (a single Query)
```

**Why this design avoids every conflict:**

- **Links:** a code is created once, by one region (its tag says which), and never updated concurrently.
- **Counters:** if both regions did `ADD clicks 1` to the *same* item, replication would apply last-writer-wins on the **whole item**, so counts would be lost. With one row per region, each row has a single writer. This is a simple form of a CRDT counter (a "G-counter").

## 9.3 Terraform

```hcl
# infra/live/prod/global/dynamodb.tf
resource "aws_dynamodb_table" "links" {
  provider         = aws.use1
  name             = "shortly-prod-links"
  billing_mode     = "PAY_PER_REQUEST"
  hash_key         = "code"
  stream_enabled   = true
  stream_view_type = "NEW_AND_OLD_IMAGES"   # required for global table replication

  attribute {
    name = "code"
    type = "S"
  }

  point_in_time_recovery { enabled = true }  # replication is NOT a backup: a bad delete replicates too

  server_side_encryption {
    enabled     = true
    kms_key_arn = aws_kms_key.primary.arn
  }

  replica {
    region_name            = "us-west-2"
    kms_key_arn            = aws_kms_replica_key.usw2.arn
    point_in_time_recovery = true
  }

  deletion_protection_enabled = true
}

resource "aws_dynamodb_table" "link_stats" {
  provider         = aws.use1
  name             = "shortly-prod-link-stats"
  billing_mode     = "PAY_PER_REQUEST"
  hash_key         = "code"
  range_key        = "region"
  stream_enabled   = true
  stream_view_type = "NEW_AND_OLD_IMAGES"

  attribute {
    name = "code"
    type = "S"
  }
  attribute {
    name = "region"
    type = "S"
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = aws_kms_key.primary.arn
  }

  replica {
    region_name = "us-west-2"
    kms_key_arn = aws_kms_replica_key.usw2.arn
  }
}
```

> **Adding a third region** (e.g. `eu-west-1`) is one more `replica {}` block. DynamoDB backfills the existing data into the new replica automatically.

## 9.4 Capacity and hot keys

- **On-demand** handles most traffic shapes, but each partition has limits (about 3,000 reads/s and 1,000 writes/s per partition). A viral link concentrates traffic on **one key**.
- Shortly protects against hot keys with an **in-process cache** in every task (a viral link is served from memory, with a short TTL), and **batched counter increments** in the worker (1,000 clicks become a single `ADD 1000`).
- For extreme read hot spots, put **DAX** (DynamoDB Accelerator, a regional cache cluster) or **CloudFront** (Part 12.4) in front.

---

# Part 10: Data Option B — Aurora Global Database vs RDS Cross-Region Replicas

## 10.1 Your relational choices

| | **Aurora Global Database** | **RDS (PostgreSQL/MySQL) cross-region read replica** | **DynamoDB Global Tables** |
|---|---|---|---|
| Replication | Storage-level, dedicated infrastructure | Database engine's own async replication | Item-level, multi-active |
| Typical lag | < 1 s | Seconds to minutes under load | ~1 s |
| Writers | 1 (optional write forwarding from secondaries) | 1 | All regions |
| Load on primary | Very low | Replication work on the primary engine | n/a |
| Planned switchover | Yes, no data loss (managed) | Manual: promote replica, re-point, rebuild | n/a (always multi-active) |
| Unplanned failover | One API call, ~1–2 min, loses lag window | Promote replica (minutes), loses lag window | Just route traffic elsewhere |
| Cost | Higher | Lower | Pay per request in each region |
| Best for | Tier-1 relational, fast RTO | Tier-2 relational, cost-sensitive | Key-value at scale, multi-active |

**Shortly's choice:** Aurora PostgreSQL Global for accounts (Tier-1 for signups, low volume). Part 10.4 shows the RDS alternative.

## 10.2 How Aurora Global replication works

```
us-east-1 (primary cluster)                                us-west-2 (secondary cluster)
┌────────────────────────────┐                             ┌────────────────────────────┐
│ writer instance            │                             │ reader instances           │
│   │ redo log               │                             │   ▲ apply to cache         │
│   ▼                        │   dedicated replication     │   │                        │
│ Aurora storage (6 copies,  │ ─────── servers, <1 s ────▶ │ Aurora storage (6 copies,  │
│ 3 AZs)                     │                             │ 3 AZs)                     │
└────────────────────────────┘                             └────────────────────────────┘
```

- Replication ships **storage-level redo records**, not SQL. The writer barely notices it.
- The secondary has its **own** 6-copy, 3-AZ storage. It survives on its own if `us-east-1` disappears.
- **Write forwarding** (optional) lets a secondary accept writes and forward them to the primary. It's convenient, but each write still pays the cross-region round trip, and you need to understand its consistency settings. Shortly instead connects to the writer directly over peering.

## 10.3 Terraform for Aurora Global

```hcl
# infra/live/prod/data/aurora.tf
resource "aws_rds_global_cluster" "accounts" {
  provider                  = aws.use1
  global_cluster_identifier = "shortly-prod-accounts"
  engine                    = "aurora-postgresql"
  engine_version            = "16.4"     # must support Global Database in both regions
  database_name             = "shortly"
  storage_encrypted         = true
  deletion_protection       = true
}

resource "aws_rds_cluster" "use1" {
  provider                        = aws.use1
  cluster_identifier              = "shortly-prod-use1-accounts"
  global_cluster_identifier       = aws_rds_global_cluster.accounts.id
  engine                          = aws_rds_global_cluster.accounts.engine
  engine_version                  = aws_rds_global_cluster.accounts.engine_version
  master_username                 = "shortly_admin"
  master_password                 = random_password.db.result    # also written to Secrets Manager
  db_subnet_group_name            = local.use1.db_subnet_group_name   # private-DATA subnets
  vpc_security_group_ids          = [aws_security_group.db_use1.id]
  kms_key_id                      = local.kms["us-east-1"]
  storage_encrypted               = true
  backup_retention_period         = 14
  preferred_backup_window         = "03:00-04:00"
  deletion_protection             = true
  enabled_cloudwatch_logs_exports = ["postgresql"]
  lifecycle {
    ignore_changes = [global_cluster_identifier, replication_source_identifier]
  }
}

resource "aws_rds_cluster_instance" "use1" {
  provider                     = aws.use1
  count                        = 2          # writer + 1 reader (Multi-AZ inside the region)
  identifier                   = "shortly-prod-use1-accounts-${count.index}"
  cluster_identifier           = aws_rds_cluster.use1.id
  instance_class               = "db.r7g.large"
  engine                       = aws_rds_cluster.use1.engine
  engine_version               = aws_rds_cluster.use1.engine_version
  performance_insights_enabled = true
  promotion_tier               = count.index
}

resource "aws_rds_cluster" "usw2" {
  provider                  = aws.usw2
  cluster_identifier        = "shortly-prod-usw2-accounts"
  global_cluster_identifier = aws_rds_global_cluster.accounts.id
  engine                    = aws_rds_global_cluster.accounts.engine
  engine_version            = aws_rds_global_cluster.accounts.engine_version
  db_subnet_group_name      = local.usw2.db_subnet_group_name
  vpc_security_group_ids    = [aws_security_group.db_usw2.id]
  kms_key_id                = local.kms["us-west-2"]
  storage_encrypted         = true
  deletion_protection       = true
  skip_final_snapshot       = true
  depends_on                = [aws_rds_cluster_instance.use1]
  lifecycle {
    ignore_changes = [global_cluster_identifier, replication_source_identifier]
  }
}

resource "aws_rds_cluster_instance" "usw2" {
  provider                     = aws.usw2
  count                        = 2          # same size as primary, so it can take over at full load
  identifier                   = "shortly-prod-usw2-accounts-${count.index}"
  cluster_identifier           = aws_rds_cluster.usw2.id
  instance_class               = "db.r7g.large"
  engine                       = aws_rds_cluster.usw2.engine
  engine_version               = aws_rds_cluster.usw2.engine_version
  performance_insights_enabled = true
}
```

**Finding the writer after a failover.** Apps connect to a **stable writer name**, never to a specific cluster endpoint:

- Use Aurora's **global writer endpoint** when your engine version supports it (it follows the primary automatically), or
- A private Route 53 record `db-writer.shortly.internal` (in a private hosted zone associated with **both** VPCs) that the failover runbook flips.

Each region reads from its **local reader endpoint**. Add **RDS Proxy** per region in front of the local cluster for connection pooling when you have many tasks (hundreds of Fargate tasks × pool size quickly exceeds Postgres's connection limit).

## 10.4 Alternative: RDS PostgreSQL with a cross-region read replica

Cheaper, simpler, slower failover. Fine for Tier-2 data.

```hcl
resource "aws_db_instance" "primary" {
  provider                = aws.use1
  identifier              = "shortly-prod-use1-pg"
  engine                  = "postgres"
  engine_version          = "16.4"
  instance_class          = "db.r7g.large"
  allocated_storage       = 200
  storage_type            = "gp3"
  multi_az                = true                 # sync standby in another AZ
  db_subnet_group_name    = local.use1.db_subnet_group_name
  vpc_security_group_ids  = [aws_security_group.db_use1.id]
  username                = "shortly_admin"
  password                = random_password.db.result
  storage_encrypted       = true
  kms_key_id              = local.kms["us-east-1"]
  backup_retention_period = 14                   # required for creating replicas
  deletion_protection     = true
}

resource "aws_db_instance" "usw2_replica" {
  provider               = aws.usw2
  identifier             = "shortly-prod-usw2-pg"
  replicate_source_db    = aws_db_instance.primary.arn   # ARN = cross-region replica
  instance_class         = "db.r7g.large"
  multi_az               = true
  db_subnet_group_name   = local.usw2.db_subnet_group_name
  vpc_security_group_ids = [aws_security_group.db_usw2.id]
  storage_encrypted      = true
  kms_key_id             = local.kms["us-west-2"]
  skip_final_snapshot    = true
}
```

Failover = `aws rds promote-read-replica --db-instance-identifier shortly-prod-usw2-pg`. The replica becomes a standalone primary. The old primary does **not** automatically become a replica; you build a new replica in the other direction afterwards. That's why RTO and operational effort are higher than with Aurora Global.

## 10.5 Using only one database

- **DynamoDB-only:** store accounts and API keys in a global table too, with `owner_region` on each account so only one region writes it (home-region pattern). Fully active-active, no cross-region writes. You lose SQL joins and multi-table transactions across regions.
- **Aurora-only:** store links in Aurora too. Reads are local (readers in each region), but every link creation becomes a cross-region write from non-primary regions (~70 ms more), and the primary region's writer becomes a scaling and availability bottleneck for creation.

---

# Part 11: The Application Code

Short and focused on how each piece uses its region.

## 11.1 Config

```python
# app/config.py
from functools import lru_cache
from pydantic_settings import BaseSettings

REGION_TAGS = {"us-east-1": "e", "us-west-2": "w", "eu-west-1": "u"}
TAG_TO_REGION = {v: k for k, v in REGION_TAGS.items()}


class Settings(BaseSettings):
    app_region: str                       # injected per region by Terraform
    links_table: str = "shortly-prod-links"
    stats_table: str = "shortly-prod-link-stats"
    clicks_queue_url: str
    db_writer_host: str                   # stable writer name (global writer endpoint or private DNS)
    db_reader_host: str                   # LOCAL reader
    db_secret_arn: str                    # region-local replica of the secret
    public_base_url: str = "https://sho.rt"


@lru_cache
def settings() -> Settings:
    return Settings()
```

## 11.2 Region-tagged codes (no cross-region collisions, no coordination)

```python
# app/ids.py
import secrets
import string

from app.config import REGION_TAGS, TAG_TO_REGION, settings

ALPHABET = string.ascii_letters + string.digits   # base62


def new_code(length: int = 6) -> str:
    body = "".join(secrets.choice(ALPHABET) for _ in range(length))
    return body + REGION_TAGS[settings().app_region]


def owner_region(code: str) -> str | None:
    return TAG_TO_REGION.get(code[-1])
```

**How it works:** 62⁶ ≈ 56 billion codes per region. A conditional write (`attribute_not_exists`) prevents collisions **within** a region. The region tag prevents collisions **across** regions. No global counter, no lock, no cross-region call.

## 11.3 Links repository with owner-region fallback

```python
# app/links.py
import time

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from cachetools import TTLCache

from app.config import settings
from app.ids import new_code, owner_region

_cfg = Config(retries={"mode": "adaptive", "max_attempts": 3}, connect_timeout=1, read_timeout=1)
_clients: dict[str, object] = {}
_cache: TTLCache = TTLCache(maxsize=200_000, ttl=60)   # hot links served from memory


def ddb(region: str):
    if region not in _clients:
        _clients[region] = boto3.client("dynamodb", region_name=region, config=_cfg)
    return _clients[region]


def create_link(url: str, owner_id: str) -> str:
    s = settings()
    for _ in range(3):
        code = new_code()
        try:
            ddb(s.app_region).put_item(
                TableName=s.links_table,
                Item={
                    "code": {"S": code},
                    "url": {"S": url},
                    "owner_id": {"S": owner_id},
                    "region": {"S": s.app_region},
                    "created_at": {"N": str(int(time.time()))},
                },
                ConditionExpression="attribute_not_exists(code)",
            )
            return code
        except ClientError as e:
            if e.response["Error"]["Code"] != "ConditionalCheckFailedException":
                raise
    raise RuntimeError("could not allocate a code")


def resolve(code: str) -> str | None:
    if (url := _cache.get(code)) is not None:
        return url

    s = settings()
    item = ddb(s.app_region).get_item(TableName=s.links_table, Key={"code": {"S": code}}).get("Item")

    # Read-your-writes across regions: a link created in another region <1 s ago may not have
    # replicated yet. The code's tag tells us exactly which region to ask. Rare, bounded, read-only.
    if item is None:
        home = owner_region(code)
        if home and home != s.app_region:
            try:
                item = ddb(home).get_item(
                    TableName=s.links_table, Key={"code": {"S": code}}, ConsistentRead=True
                ).get("Item")
            except Exception:
                item = None          # home region down: behave like "not found yet", never hang

    if item is None:
        return None
    url = item["url"]["S"]
    _cache[code] = url
    return url
```

> **Why the fallback is safe:** it only happens on a local miss for a code tagged with another region, it's read-only, and it has a 1-second timeout. If that region is down, the link will appear as soon as replication catches up (or it was lost in the RPO window).

## 11.4 Click events and per-region counters

```python
# app/events.py
import json

import boto3

from app.config import settings

_sqs = boto3.client("sqs", region_name=settings().app_region)


def publish_click(code: str) -> None:
    # Fire-and-forget to the LOCAL queue. A failed publish loses one click, never a redirect.
    try:
        _sqs.send_message(QueueUrl=settings().clicks_queue_url, MessageBody=json.dumps({"code": code}))
    except Exception:
        pass
```

```python
# app/worker.py
import json
from collections import Counter

import boto3

from app.config import settings

s = settings()
sqs = boto3.client("sqs", region_name=s.app_region)
ddb = boto3.client("dynamodb", region_name=s.app_region)


def run() -> None:
    while True:
        resp = sqs.receive_message(QueueUrl=s.clicks_queue_url, MaxNumberOfMessages=10, WaitTimeSeconds=20)
        msgs = resp.get("Messages", [])
        if not msgs:
            continue

        counts = Counter(json.loads(m["Body"])["code"] for m in msgs)   # batch: N clicks → 1 write
        for code, n in counts.items():
            ddb.update_item(
                TableName=s.stats_table,
                Key={"code": {"S": code}, "region": {"S": s.app_region}},   # ONLY this region's row
                UpdateExpression="ADD clicks :n",
                ExpressionAttributeValues={":n": {"N": str(n)}},
            )

        sqs.delete_message_batch(
            QueueUrl=s.clicks_queue_url,
            Entries=[{"Id": str(i), "ReceiptHandle": m["ReceiptHandle"]} for i, m in enumerate(msgs)],
        )


if __name__ == "__main__":
    run()
```

```python
# app/stats.py
import boto3

from app.config import settings


def total_clicks(code: str) -> dict:
    s = settings()
    ddb = boto3.client("dynamodb", region_name=s.app_region)
    rows = ddb.query(
        TableName=s.stats_table,
        KeyConditionExpression="code = :c",
        ExpressionAttributeValues={":c": {"S": code}},
    )["Items"]
    by_region = {r["region"]["S"]: int(r["clicks"]["N"]) for r in rows}
    return {"code": code, "total": sum(by_region.values()), "by_region": by_region}
```

> `ADD` is not idempotent: if the worker crashes after `update_item` but before `delete_message_batch`, those clicks count twice. For analytics counters that's usually acceptable. If not, add a dedupe table keyed by message ID, or accept approximate counts and reconcile from logs.

## 11.5 Accounts: local reads, primary writes

```python
# app/accounts.py
import hashlib
import json
import secrets

import boto3
from cachetools import TTLCache
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from app.config import settings

s = settings()
_creds = json.loads(
    boto3.client("secretsmanager", region_name=s.app_region).get_secret_value(SecretId=s.db_secret_arn)["SecretString"]
)


def _url(host: str) -> str:
    return f"postgresql+asyncpg://{_creds['username']}:{_creds['password']}@{host}:5432/shortly"


# Writer may be in ANOTHER region (over VPC peering): small pool, tight timeouts, recycle after failover.
writer = create_async_engine(_url(s.db_writer_host), pool_size=2, max_overflow=2, pool_pre_ping=True,
                             pool_recycle=300, connect_args={"timeout": 3, "command_timeout": 3})
# Reader is LOCAL: used on every authenticated request (via cache).
reader = create_async_engine(_url(s.db_reader_host), pool_size=5, max_overflow=5, pool_pre_ping=True,
                             connect_args={"timeout": 2})

_key_cache: TTLCache = TTLCache(maxsize=100_000, ttl=300)


def _hash(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()


async def account_for_key(api_key: str) -> str | None:
    h = _hash(api_key)
    if h in _key_cache:
        return _key_cache[h]
    async with reader.connect() as conn:
        row = (await conn.execute(text("SELECT account_id FROM api_keys WHERE key_hash = :h AND revoked = false"),
                                  {"h": h})).first()
    account_id = row[0] if row else None
    if account_id:
        _key_cache[h] = account_id
    return account_id


async def create_account(email: str) -> tuple[str, str]:
    api_key = "sk_" + secrets.token_urlsafe(32)
    async with writer.begin() as conn:      # one transaction on the PRIMARY region's writer
        account_id = (await conn.execute(
            text("INSERT INTO accounts (email) VALUES (:e) RETURNING id"), {"e": email})).scalar_one()
        await conn.execute(text("INSERT INTO api_keys (account_id, key_hash) VALUES (:a, :h)"),
                           {"a": account_id, "h": _hash(api_key)})
    _key_cache[_hash(api_key)] = str(account_id)   # read-your-writes in THIS region, before replication
    return str(account_id), api_key
```

**What happens if the writer region is down?** `create_account` fails fast (3 s timeout) with a 503 "signups temporarily unavailable". Redirects, link creation, and stats keep working in every region. That's a deliberate **graceful degradation**: the rare operation degrades, the core product doesn't.

## 11.6 Routes and health

```python
# app/main.py
from fastapi import Depends, FastAPI, Header, HTTPException, Response
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, HttpUrl

from app import accounts, events, links, stats
from app.config import settings
from app.health import router as health_router

app = FastAPI()
app.include_router(health_router)


@app.middleware("http")
async def region_header(request, call_next):
    response = await call_next(request)
    response.headers["X-Region"] = settings().app_region
    return response


async def require_account(x_api_key: str = Header(...)) -> str:
    account_id = await accounts.account_for_key(x_api_key)
    if not account_id:
        raise HTTPException(401, "invalid api key")
    return account_id


class CreateLink(BaseModel):
    url: HttpUrl


@app.post("/v1/links", status_code=201)
async def create(body: CreateLink, account_id: str = Depends(require_account)):
    code = links.create_link(str(body.url), account_id)
    return {"code": code, "short_url": f"{settings().public_base_url}/{code}"}


@app.get("/v1/links/{code}/stats")
async def link_stats(code: str, account_id: str = Depends(require_account)):
    return stats.total_clicks(code)


@app.post("/v1/accounts", status_code=201)
async def signup(email: str):
    try:
        account_id, api_key = await accounts.create_account(email)
    except Exception:
        raise HTTPException(503, "signups temporarily unavailable")
    return {"account_id": account_id, "api_key": api_key}


@app.get("/{code}")
async def redirect(code: str):
    url = links.resolve(code)
    if url is None:
        raise HTTPException(404)
    events.publish_click(code)
    return RedirectResponse(url, status_code=302, headers={"Cache-Control": "private, max-age=60"})
```

> In real code, the boto3 calls would run via `asyncio.to_thread` or use `aioboto3` so they don't block the event loop. They're kept synchronous here for readability.

```python
# app/health.py
from fastapi import APIRouter, Response
from sqlalchemy import text

from app import links
from app.accounts import reader
from app.config import settings

router = APIRouter()


@router.get("/health/live")
def live():
    return {"ok": True}


@router.get("/health/ready")
async def ready(response: Response):
    # LOCAL dependencies only. Never the cross-region writer: if it were included, a us-east-1
    # DB problem would mark us-west-2 unhealthy too, and DNS would have nowhere to send traffic.
    s = settings()
    ok = True
    try:
        links.ddb(s.app_region).describe_table(TableName=s.links_table)
    except Exception:
        ok = False
    try:
        async with reader.connect() as conn:
            await conn.execute(text("SELECT 1"))
    except Exception:
        pass              # accounts reader down degrades auth, but redirects still work: stay in rotation
    if not ok:
        response.status_code = 503
    return {"ok": ok, "region": s.app_region}
```

## 11.7 Dockerfile

```dockerfile
FROM python:3.12-slim AS base
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
WORKDIR /app
RUN useradd --create-home --uid 10001 app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app ./app
USER app
EXPOSE 8000
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

One image, built once for `linux/arm64`, runs as the API (default command) or the worker (`python -m app.worker`) in any region. **The only thing that differs between regions is environment variables.**

---

# Part 12: Global Traffic

## 12.1 Route 53 latency routing with health checks

```hcl
# infra/live/prod/dns/main.tf
locals {
  regions = {
    "us-east-1" = { short = "use1", app = data.terraform_remote_state.app_use1.outputs }
    "us-west-2" = { short = "usw2", app = data.terraform_remote_state.app_usw2.outputs }
  }
}

# Region-specific names: point straight at each ALB (used by health checks, canaries, engineers).
resource "aws_route53_record" "regional" {
  for_each = local.regions
  zone_id  = var.zone_id
  name     = "${each.value.short}.sho.rt"
  type     = "A"
  alias {
    name                   = each.value.app.alb_dns_name
    zone_id                = each.value.app.alb_zone_id
    evaluate_target_health = true
  }
}

resource "aws_route53_health_check" "regional" {
  for_each          = local.regions
  fqdn              = "${each.value.short}.sho.rt"
  type              = "HTTPS"
  port              = 443
  resource_path     = "/health/ready"
  request_interval  = 10
  failure_threshold = 3
  measure_latency   = true
}

# The public name: each user gets the lowest-latency HEALTHY region.
resource "aws_route53_record" "apex" {
  for_each        = local.regions
  zone_id         = var.zone_id
  name            = "sho.rt"
  type            = "A"
  set_identifier  = each.key
  health_check_id = aws_route53_health_check.regional[each.key].id

  latency_routing_policy {
    region = each.key
  }

  alias {
    name                   = each.value.app.alb_dns_name
    zone_id                = each.value.app.alb_zone_id
    evaluate_target_health = true
  }
}
```

**How failover happens automatically:**

1. Route 53 health checkers (from many locations) probe `use1.sho.rt/health/ready` every 10 s.
2. After 3 failures (~30 s), the check turns unhealthy.
3. Route 53 stops returning the `us-east-1` record. Latency routing hands out `us-west-2` to everyone.
4. Clients pick up the new answer when their cached DNS expires (alias to ALB = 60 s TTL). Most traffic moves within ~1–2 minutes; a long tail of misbehaving resolvers takes longer.

For **human-controlled** failover (recommended for partial or ambiguous failures), add **Route 53 ARC routing controls** as described in the companion guide. Turning a control off drains a region using a data-plane call.

## 12.2 Global Accelerator (faster, no DNS caching)

Global Accelerator gives you **two static anycast IPs**. Users connect to the nearest AWS edge location, and traffic rides the AWS backbone to the nearest healthy region. Failover takes **seconds** because no DNS change is involved, and you can shift traffic with **traffic dials** (e.g. send 10% to a region during a drill).

Use it when you need fast failover, static IPs for customer allowlists, or non-HTTP protocols.

## 12.3 Comparing global entry points

| | Route 53 latency | Global Accelerator | CloudFront |
|---|---|---|---|
| Failover speed | ~1–2 min (+DNS tail) | Seconds | Per request for GET/HEAD (origin groups) |
| Static IPs | No | Yes (2 anycast) | No |
| Caching | No | No | Yes |
| Extra cost | Very low | Hourly + per GB | Per request + per GB |

## 12.4 CloudFront for redirects (the scale trick)

Redirects for popular links are perfect for edge caching. With CloudFront in front, a viral link is answered by hundreds of edge locations and never reaches your ALBs:

- Origin: `sho.rt` regional ALBs (an origin group with `use1` primary, `usw2` secondary, failing over on 5xx).
- Cache `GET /{code}` responses for a short TTL (e.g. 60 s) by returning `Cache-Control: public, max-age=60` for redirects.
- **Trade-off:** clicks served from cache never hit your app, so you count them from **CloudFront logs** (real-time logs into Kinesis) instead of the SQS path. Big companies do exactly this.

---

# Part 13: Scaling

## 13.1 Scaling every layer

| Layer | Scales how | Watch out for |
|---|---|---|
| Route 53 / Global Accelerator | Managed, effectively unlimited | DNS caching tail |
| ALB | Auto, in minutes | Sudden 2x jumps during failover; pre-warm or LCU reservation for known events |
| API tasks / instances | Target tracking on requests per target + CPU | Min capacity must cover failover (N+1) |
| Workers | Backlog per task | Spot interruptions (fine, SQS redelivers) |
| DynamoDB | On-demand; per-partition limits | Hot keys, cold-table bursts; use caching, warm throughput |
| Aurora | Add readers (reader autoscaling), scale instance class for the writer | Writer is the ceiling; connection limits (use RDS Proxy) |
| SQS | Effectively unlimited (standard queues) | Message age alarms |
| NAT | Up to large bandwidth per gateway; one per AZ | Per-GB cost; use VPC endpoints |

## 13.2 Failover capacity, concretely (2 regions, 50,000 RPS global peak)

| | Normal (each region) | After losing a region (survivor) |
|---|---|---|
| RPS | 25,000 | 50,000 |
| API tasks at 800 req/s capacity each, 60% target | ~52 | ~104 |
| Minimum tasks configured | **70** (so the first minutes are survivable) | autoscaling to 104+ |
| `max_tasks` | 150 | 150 |
| Fargate vCPU quota needed | 150 tasks × 0.5 vCPU = 75 vCPU | same, in **both** regions |

Rule: **the survivor must absorb a sudden doubling without waiting for anything.** Either keep minimums high (static stability) or prove in a game day that autoscaling plus the ALB can ramp fast enough.

## 13.3 Load shedding and graceful degradation

When overloaded, it's better to serve most users well than everyone badly:

- WAF rate limits per IP and per API key.
- Prioritize redirects over stats and signups (separate target groups or route-level concurrency limits).
- Shed analytics: if the clicks queue is unavailable, drop clicks, not redirects (already in the code).
- Return `503` with `Retry-After` quickly instead of letting requests pile up (Little's Law: slow requests multiply concurrency).

## 13.4 Cells: the next step after regions

At very large scale, FAANG-style systems split each region into **cells**: several fully independent copies of the stack (own ALB, tasks, tables), with a thin routing layer mapping each customer to a cell. A bad deploy or poison request then affects one cell (say 5% of customers), not a whole region. Shortly doesn't need cells, but the same modules (`network` excluded) can be instantiated per cell.

---

# Part 14: Deployment

## 14.1 Flow

```
git push main
  │
  ├─ build + unit tests + security scan
  ├─ docker buildx (arm64) → push to ECR us-east-1 (tag = git SHA, immutable)
  ├─ ECR replication → ECR us-west-2 (wait until the image exists there)
  ├─ run DB migrations once (expand-only), against the writer
  │
  ├─ STAGING: deploy both regions → integration tests per region hostname
  │
  ├─ PROD wave 1: us-west-2
  │     ECS rolling deploy (circuit breaker + alarm rollback)
  │     smoke tests against usw2.sho.rt
  │     bake 30 min, watch 5xx / p99 / DLQ alarms
  │
  └─ PROD wave 2: us-east-1   (same steps)
```

Key rules:

- **Same image digest** everywhere. Each region pulls from its **own** ECR.
- **One region at a time.** A bad release only ever hits one region; Route 53 health checks plus the circuit breaker contain it.
- **Infra changes follow the same waves:** `terraform apply` per region folder, never both prod regions in one run.
- With **EC2**, the "deploy" is a new launch template version with the new image tag; the ASG instance refresh rolls it out with checkpoints and auto-rollback.

## 14.2 Minimal pipeline (GitHub Actions)

```yaml
name: deploy
on:
  push:
    branches: [main]
permissions:
  id-token: write
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    outputs:
      tag: ${{ steps.t.outputs.tag }}
    steps:
      - uses: actions/checkout@v4
      - id: t
        run: echo "tag=${GITHUB_SHA::12}" >> "$GITHUB_OUTPUT"
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::111111111111:role/gha-build
          aws-region: us-east-1
      - uses: aws-actions/amazon-ecr-login@v2
        id: ecr
      - run: |
          docker buildx build --platform linux/arm64 \
            -t ${{ steps.ecr.outputs.registry }}/shortly/api:${{ steps.t.outputs.tag }} --push .
      - name: wait for replication
        run: |
          for i in $(seq 1 30); do
            aws ecr describe-images --region us-west-2 --repository-name shortly/api \
              --image-ids imageTag=${{ steps.t.outputs.tag }} && exit 0
            sleep 10
          done
          exit 1

  deploy:
    needs: build
    runs-on: ubuntu-latest
    strategy:
      max-parallel: 1
      fail-fast: true
      matrix:
        region: [us-west-2, us-east-1]
    environment: prod-${{ matrix.region }}
    steps:
      - uses: actions/checkout@v4
      - uses: hashicorp/setup-terraform@v3
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::222222222222:role/gha-deploy
          aws-region: ${{ matrix.region }}
      - name: terraform apply (this region only)
        working-directory: infra/live/prod/${{ matrix.region }}/app
        run: |
          terraform init -input=false
          terraform apply -input=false -auto-approve -var image_tag=${{ needs.build.outputs.tag }}
      - name: smoke + bake
        run: |
          ./scripts/smoke.sh ${{ matrix.region }}
          ./scripts/bake.sh ${{ matrix.region }} 1800
```

---

# Part 15: Walkthroughs (How It All Works Together)

## 15.1 Life of "create a link" in Oregon, clicked in Virginia

```
t=0 ms      Alice (Seattle) → DNS sho.rt → latency routing → us-west-2 ALB
t=5 ms      WAF ok → ALB → API task (AZ b)
t=6 ms      API key → in-process cache miss → local Aurora READER (usw2) → account found → cached
t=10 ms     new_code() = "aZ3k9Qw" (tag "w") → PutItem to DynamoDB usw2 with attribute_not_exists → OK
t=12 ms     201 {"short_url": "https://sho.rt/aZ3k9Qw"}

t=300 ms    Bob (New York) clicks → DNS → us-east-1 ALB → API task
t=302 ms    cache miss → GetItem DynamoDB use1 → NOT FOUND (replication still in flight)
t=303 ms    code tag "w" → GetItem DynamoDB usw2 (ConsistentRead) via peering-free public AWS endpoint → found
t=375 ms    302 → long URL (one-time ~70 ms penalty) · cached in this task for 60 s · click → use1 SQS

t≈1,000 ms  Global table replication lands the item in use1. All further lookups are local.
```

> The cross-region fallback goes to DynamoDB's regional **public AWS endpoint** over the AWS network (through NAT, since the gateway endpoint only covers the local region). It doesn't need peering.

## 15.2 Click counting across regions

```
us-east-1 workers:  batch {aZ3k9Qw: 140} → ADD clicks 140 on (aZ3k9Qw, us-east-1)
us-west-2 workers:  batch {aZ3k9Qw:  60} → ADD clicks  60 on (aZ3k9Qw, us-west-2)

Both rows replicate to both regions (~1 s).
GET /v1/links/aZ3k9Qw/stats in either region → Query PK=aZ3k9Qw → 140 + 60 = 200 ✔
(If both regions had updated ONE shared row, last-writer-wins would have reported 140 or 60.)
```

## 15.3 Signup from Oregon (cross-region write)

```
API task (usw2) → db-writer name → resolves to Aurora writer private IP in use1
               → VPC peering → Aurora writer (use1): INSERT account + key in one transaction (~75 ms)
Aurora storage replication → usw2 secondary (<1 s)
Meanwhile: the new key is already in the usw2 task's cache, so Alice can use it immediately.
```

## 15.4 A region fails: us-east-1 goes dark at 14:00

```
14:00:00  use1 ALB/tasks stop responding.
14:00:30  Route 53 health checks for use1 → unhealthy (3 × 10 s).
14:00:30  Route 53 answers sho.rt with usw2 only.
14:01–02  Most clients' DNS caches expire → traffic shifts to usw2.
          usw2: ALB request count doubles → tasks at ~85% → autoscaling adds tasks (min was sized for this).

What keeps working immediately:
  ✔ Redirects (DynamoDB usw2 replica has everything up to ~1 s before 14:00)
  ✔ Link creation (writes to DynamoDB usw2, codes tagged "w")
  ✔ Stats (usw2 rows exact; use1 rows frozen at their last replicated value)
  ✔ API key auth (local Aurora reader + cache)
  ✘ Signups → 503 (writer is in use1)

14:05     Incident commander confirms a regional event (not our deploy). Decision: promote Aurora.
14:06     aws rds failover-global-cluster ... --target-db-cluster-identifier <usw2 cluster> --allow-data-loss
14:08     usw2 Aurora is the writer. db-writer name → usw2. Signups work again.

Data impact (RPO):
  - DynamoDB writes in use1 during the last ~1 s before 14:00 may be missing in usw2 until use1 recovers.
    When use1 comes back, its replica re-syncs and those items replicate (no conflict: unique codes / own rows).
  - Aurora: commits in the last <1 s before failover may be lost. Reconcile from the old primary later.
  - Clicks sitting in use1's SQS queue are processed when use1 recovers.
```

## 15.5 Recovery and failback

1. `us-east-1` recovers. DynamoDB replicas resync automatically (both directions).
2. Route 53 health checks go green, and `us-east-1` starts receiving traffic again automatically. If you want a human gate here, use ARC routing controls so a region only rejoins when someone turns it back on.
3. Aurora: the old primary is re-added as a **secondary** of the new global cluster. Once replication lag is ~0, run a **planned switchover** back to `us-east-1` during low traffic (no data loss).
4. Post-incident review: measured RTO (here ~2 minutes for the core product, 8 minutes for signups) and RPO against targets.

---

# Part 16: Observability and Operations

## 16.1 Golden signals, per region

| Signal | Source | Alarm |
|---|---|---|
| Redirect latency p99 | ALB `TargetResponseTime` | > 100 ms for 5 min |
| Error rate | ALB `HTTPCode_Target_5XX_Count` / requests | > 0.5% |
| Healthy targets | ALB `HealthyHostCount` | < min expected |
| DynamoDB throttles | `ThrottledRequests`, `ReadThrottleEvents` | > 0 sustained |
| DynamoDB replication | `ReplicationLatency` (per receiving region) | > 5 s |
| Aurora replication | `AuroraGlobalDBReplicationLag` | > 2 s |
| Clicks backlog | SQS `ApproximateAgeOfOldestMessage` | > 5 min |
| DLQ | `ApproximateNumberOfMessagesVisible` on DLQ | > 0 |
| NAT | `ErrorPortAllocation`, `PacketsDropCount` | > 0 |
| Health checks | Route 53 `HealthCheckStatus` | region unhealthy |

Every log line, metric, and trace carries `region` and `az`. Dashboards show both regions side by side: the first question in every incident is "**one region or all?**"

## 16.2 Synthetic canaries

CloudWatch Synthetics canaries run **in both regions** and test **both** regional hostnames plus the global name: create a link, resolve it, check stats. If a canary in `us-west-2` sees `use1.sho.rt` failing **and** so does the canary in `us-east-1`, it's real.

## 16.3 Operational hygiene

- **Drift detection:** nightly `terraform plan` per region folder; alert on any diff.
- **Quota monitoring:** Service Quotas + CloudWatch alarms on usage vs limit, per region.
- **Game days:** quarterly. Drain a region with ARC/Global Accelerator in production at low traffic and measure. Use **AWS FIS** to inject task failures, AZ problems, and cross-region network disruption in staging.
- **Runbooks** with real ARNs, stored where they're reachable when a region is down.

---

# Part 17: Production Readiness Checklist

**Network**
- [ ] Non-overlapping /16 per region; 3 AZs; public / private-app / private-data tiers
- [ ] One NAT gateway per AZ; per-AZ app route tables
- [ ] Data tier has no internet route
- [ ] Gateway endpoints (DynamoDB, S3) and interface endpoints (ECR, Logs, SQS, Secrets, STS, SSM)
- [ ] Security groups chained ALB → app → DB; remote-region access by CIDR only where needed
- [ ] Cross-region peering / Transit Gateway with routes in app + data tiers
- [ ] VPC flow logs on

**Load balancing and edge**
- [ ] ALB in public subnets, HTTPS only (HTTP redirects), modern TLS policy, deletion protection
- [ ] Regional ACM certs in each region; region-specific hostnames
- [ ] WAF with rate limits + managed rules on each ALB
- [ ] Route 53 latency records + health checks on `/health/ready` (local dependencies only)
- [ ] ARC routing controls or Global Accelerator traffic dials for manual drain

**Compute**
- [ ] Same module and image in every region; region differs only by inputs
- [ ] Tasks/instances spread across 3 AZs in private subnets
- [ ] Autoscaling on requests per target + CPU; minimums sized for N+1 failover
- [ ] Circuit breaker + alarm rollback (ECS) or instance refresh with auto rollback (EC2)
- [ ] IMDSv2, no SSH, SSM access; least-privilege, region-scoped IAM
- [ ] Quotas raised in every region to failover levels

**Data**
- [ ] DynamoDB Global Tables with PITR, encryption with multi-region KMS keys
- [ ] Every item has a single writer (region-tagged IDs, per-region counter rows)
- [ ] Aurora Global (or RDS cross-region replica) with stable writer name and local reader
- [ ] Replication lag alarms (DynamoDB, Aurora, S3)
- [ ] Backups/PITR tested by actually restoring (replication is not a backup)

**App**
- [ ] Region-aware config; region in every log/metric/trace
- [ ] Hot path never crosses regions; cross-region calls only for rare operations, with tight timeouts
- [ ] Read-your-writes fallback (owner-region lookup or sticky routing)
- [ ] Graceful degradation when the writer region is unavailable
- [ ] Idempotent / at-least-once-safe workers; DLQs

**Delivery and operations**
- [ ] Build once, deploy per region in waves with bake time
- [ ] Migrations once, against the writer, expand/contract
- [ ] Canaries from both regions; dashboards per region
- [ ] Failover / switchover / failback runbooks rehearsed; measured RTO/RPO meet targets
