# Multi-Region Deployment on AWS: Strategies, Setup, and Code

> Companion to `FASTAPI_TDD_DOCKER_DEEP_DIVE.md`. Same project: the **text summarization service** (send a URL, get a summary).
> Goal: run it in **more than one AWS region** so a regional outage, a bad deploy, or a latency problem doesn't take you down.
> Style: concepts first, then real Terraform / Python / CI code that matches what production teams actually run.

**How to read this guide**

| Part | What you get |
|---|---|
| **1. Why and when** | Reasons to go multi-region, and reasons not to |
| **2. The vocabulary** | RTO, RPO, blast radius, static stability, control plane vs data plane |
| **3. The four DR strategies** | Backup & restore, pilot light, warm standby, active-active |
| **4. Reference architecture** | What we build, region by region |
| **5. Foundations** | Accounts, regions, IaC layout, naming |
| **6. Step-by-step setup (Terraform)** | KMS, ECR, network, Aurora Global, DynamoDB Global Tables, S3, secrets, ECS, Route 53 |
| **7. App changes (FastAPI)** | Region awareness, read/write routing, health checks, idempotency, workers |
| **8. CI/CD** | Build once, deploy in waves, bake time, automatic rollback |
| **9. Traffic management** | Route 53 policies, Global Accelerator, CloudFront, ARC |
| **10. Failover and failback runbooks** | Exact steps and commands |
| **11. Observability** | Per-region SLOs, replication lag, synthetic canaries |
| **12. Testing resilience** | Game days, AWS FIS, chaos |
| **13. Cost** | What doubles, what doesn't, how to save |
| **14. Pitfalls** | 15 mistakes teams make |
| **15. Interview prep + checklist** | Questions, answers, go-live checklist |

---

# Part 1: Why and When

## 1.1 Reasons to go multi-region

| Reason | What it really means |
|---|---|
| **Disaster recovery** | A whole region (or a key regional service) has an outage. You keep serving from another region. |
| **Latency** | Users in Europe hitting `us-east-1` pay 80–120 ms per round trip. A nearby region cuts that. |
| **Data residency / compliance** | EU user data must stay in the EU (GDPR, contracts, regulators). |
| **Safer deploys** | Deploy to one region first. If it breaks, only part of your traffic is hurt. |
| **Business requirement** | Contracts with a 99.99% SLA, or regulators (banks, health) that require a tested DR plan. |

## 1.2 Reasons NOT to (yet)

Multi-region is **expensive and complex**. Most outages are not regional; they are **your own bad deploy, a bad config, or a bad migration**. Multi-region does not fix those (a bad migration replicates to every region in under a second).

Do these first, in a single region:

1. **Multi-AZ everything** (ALB, ECS/EKS across 3 AZs, Aurora Multi-AZ, ElastiCache replicas). This survives a data center failure and is cheap.
2. **Backups you have actually restored** (point-in-time recovery, AWS Backup).
3. **Safe deploys** (canary, circuit breaker, automatic rollback).
4. **Infrastructure as code** so you *could* rebuild elsewhere.

> **Rule of thumb:** Multi-AZ gives you about 99.95–99.99%. Multi-region is what you add when the business has priced a regional outage and decided it costs more than running a second region.

## 1.3 The honest trade-off

| You gain | You pay with |
|---|---|
| Survive a regional outage | ~1.3x to 2x+ infra cost, more moving parts |
| Lower latency for far-away users | Data consistency problems (replication lag, conflicts) |
| Smaller blast radius for deploys | Slower, more complex pipelines |
| Compliance | Data model has to know where each user "lives" |

---

# Part 2: The Vocabulary

## 2.1 RTO and RPO

- **RTO (Recovery Time Objective):** how long you can be **down**. "We must be back within 15 minutes."
- **RPO (Recovery Point Objective):** how much **data** you can lose. "We can lose at most 1 minute of writes."

```
        last good backup/replica point          disaster            service restored
                 |<------- RPO (data lost) ------->|<------- RTO (downtime) ------->|
---------------------------------------------------X-----------------------------------> time
```

Every strategy in Part 3 is just a different price for a different RTO/RPO.

## 2.2 Blast radius

How much breaks when one thing fails. Regions are the biggest **isolation boundary** AWS gives you: they share almost nothing. Industry teams also split by **account** and by **cell** (Part 5) to make the blast radius smaller.

## 2.3 Static stability

> A statically stable system **keeps working during a failure without having to make changes**.

Example: your standby region already runs enough tasks to take full traffic. During an outage you don't need to call "scale up" APIs, which may be slow or overloaded exactly when everyone is failing over.

This is the most important idea in AWS resilience design. Remember it for interviews.

## 2.4 Control plane vs data plane

| | Control plane | Data plane |
|---|---|---|
| What it does | Creates/changes resources (`CreateService`, `ChangeResourceRecordSets`) | Serves the actual work (DNS answers, packets, queries) |
| Availability | Lower, more complex | Higher, simpler, designed to keep working |
| Example | Editing a Route 53 record (the control plane is centralized in `us-east-1`) | Route 53 answering DNS queries, evaluating health checks |

> **Industry rule:** your failover path must use **data-plane** actions only. Don't rely on "we'll edit DNS during the outage." Use **health checks** or **Route 53 ARC routing controls** (which are data-plane operations) so failover still works if a control plane is impaired.

## 2.5 Active-passive vs active-active

- **Active-passive:** one region takes traffic, the other waits. Simple data model (one writer).
- **Active-active:** all regions take traffic. Better latency and no "cold" failover, but **writes in two places** cause conflicts unless you design for it.

## 2.6 Failover vs switchover

- **Switchover (planned):** both regions are healthy. You move the primary on purpose (maintenance, a drill). **No data loss.**
- **Failover (unplanned):** the primary is broken. You promote the secondary and **accept losing whatever hadn't replicated yet** (your RPO).

---

# Part 3: The Four DR Strategies (AWS Well-Architected)

| Strategy | What runs in region 2 | Typical RPO | Typical RTO | Cost |
|---|---|---|---|---|
| **Backup & restore** | Nothing. Only backups copied there. | Hours | Hours (rebuild from IaC + restore) | $ |
| **Pilot light** | Data is replicated live. Compute is off or at zero. | Seconds–minutes | 10s of minutes | $$ |
| **Warm standby** | A scaled-down but **working** copy of the whole stack | Seconds | Minutes | $$$ |
| **Multi-site active-active** | Full stack, taking real traffic | ~0 to seconds | ~0 to seconds | $$$$ |

## 3.1 Backup & restore

```
us-east-1 (live)                         us-west-2
┌─────────────────────┐   AWS Backup     ┌────────────────────┐
│ ALB → ECS → Aurora  │ ── copy job ───▶ │ snapshots, S3 copy │
│            S3       │ ── S3 CRR ─────▶ │ (no compute)       │
└─────────────────────┘                  └────────────────────┘
```

- On disaster: run Terraform in `us-west-2`, restore the DB from the copied snapshot, point DNS.
- Good for internal tools and batch systems.
- **The trap:** teams never test the restore. A restore you've never run will take far longer than your RTO.

## 3.2 Pilot light

```
us-east-1 (live)                         us-west-2 (pilot light)
┌─────────────────────┐                  ┌───────────────────────────┐
│ ALB → ECS (10 tasks)│                  │ ALB → ECS (0 tasks)       │
│ Aurora writer       │ ── <1s lag ────▶ │ Aurora secondary (reader) │
│ S3                  │ ── CRR ────────▶ │ S3 replica                │
└─────────────────────┘                  └───────────────────────────┘
```

- The "pilot light" is the **data** that is always on. Compute is turned up only during a disaster.
- **Weakness:** scaling from 0 to 10 tasks during a regional event depends on control-plane calls and capacity being available. That is *not* statically stable.

## 3.3 Warm standby (the most common industry choice)

```
us-east-1 (primary, 100% traffic)        us-west-2 (warm standby, 0% traffic)
┌─────────────────────┐                  ┌───────────────────────────┐
│ ALB → ECS (10 tasks)│                  │ ALB → ECS (3 tasks)       │
│ Aurora writer       │ ── <1s lag ────▶ │ Aurora secondary          │
│ DynamoDB replica    │ ◀── global ────▶ │ DynamoDB replica          │
│ SQS + workers       │                  │ SQS + workers (min)       │
└─────────────────────┘                  └───────────────────────────┘
```

- Everything is deployed and **handles real requests** (you send synthetic traffic or a tiny share of real traffic to prove it).
- On failover: promote the DB, shift traffic, and autoscaling grows the tasks. For full static stability, run it at 100% capacity ("hot standby").
- **Why teams pick it:** minutes of RTO, seconds of RPO, single-writer database (no conflicts), and much cheaper than active-active.

## 3.4 Multi-site active-active

```
                     Route 53 latency routing / Global Accelerator
                       ┌───────────────┴───────────────┐
us-east-1 (50%)        ▼                               ▼       eu-west-1 (50%)
┌──────────────────────────┐                ┌──────────────────────────┐
│ ALB → ECS (full)         │                │ ALB → ECS (full)         │
│ DynamoDB Global Table ◀──┼── multi-active ┼──▶ DynamoDB Global Table │
│ (or Aurora: writes go to │                │                          │
│  one region / home region)│               │                          │
└──────────────────────────┘                └──────────────────────────┘
```

Three ways teams handle **writes** in active-active:

| Pattern | How it works | Use when |
|---|---|---|
| **Read local, write global** | Reads served locally; writes go to the single primary region (cross-region hop) | Read-heavy apps (our summarizer: most traffic is `GET /summaries/{id}`) |
| **Home region (region pinning / partitioning)** | Each user/tenant "lives" in one region. All their writes go there. | Data residency, SaaS tenants, banking |
| **Multi-writer with conflict resolution** | Any region writes; DB resolves conflicts (DynamoDB last-writer-wins) | Data that tolerates last-writer-wins: carts, sessions, preferences, counters via CRDT-style design |

> **Interview line:** "Active-active is easy for stateless compute and hard for state. The real design question is: who owns each write?"

## 3.5 Which one for our summarizer?

- **Tier-1 path** (`POST /summaries`, `GET /summaries/{id}`): **warm standby**, moving to **active-active reads** later.
- **Job state and idempotency keys:** DynamoDB Global Tables (any region can read; writes owned by the home region).
- **Relational data** (users, billing): Aurora Global Database, single writer.
- **Article cache / summaries blobs:** S3 with Cross-Region Replication.

This mix (different strategy per component) is what real companies do. Not every piece needs the same RTO.

---

# Part 4: Reference Architecture

```
                                   ┌──────────────────────────────┐
                                   │ Route 53 (api.example.com)   │
                                   │  latency/failover records    │
                                   │  + health checks             │
                                   │  + ARC routing controls      │
                                   └──────────────┬───────────────┘
                     ┌────────────────────────────┴───────────────────────────┐
                     ▼                                                        ▼
        ┌──────── us-east-1 (primary) ────────┐              ┌──────── us-west-2 (standby) ────────┐
        │ WAF → ALB (3 AZ)                     │              │ WAF → ALB (3 AZ)                     │
        │   └─ ECS Fargate: api (FastAPI)      │              │   └─ ECS Fargate: api (FastAPI)      │
        │   └─ ECS Fargate: worker             │              │   └─ ECS Fargate: worker             │
        │ SQS: summarize-jobs (+DLQ)           │              │ SQS: summarize-jobs (+DLQ)           │
        │ ElastiCache (Valkey/Redis) primary ──┼─ Global DS ─▶│ ElastiCache secondary               │
        │ Aurora PostgreSQL writer ────────────┼─ storage ───▶│ Aurora secondary (read-only)         │
        │ DynamoDB: jobs, idempotency ◀────────┼─ Global Tbl ▶│ DynamoDB replica                     │
        │ S3: summaries ───────────────────────┼─ CRR ───────▶│ S3: summaries replica                │
        │ Secrets Manager (primary) ───────────┼─ replica ───▶│ Secrets Manager replica              │
        │ KMS multi-region key (primary) ──────┼─ replica ───▶│ KMS replica key                      │
        │ ECR (primary) ───────────────────────┼─ replication▶│ ECR replica                          │
        │ CloudWatch, X-Ray                    │              │ CloudWatch, X-Ray                    │
        └──────────────────────────────────────┘              └──────────────────────────────────────┘
```

**Key design rules baked into this picture**

1. **Each region is self-sufficient at request time.** A request served in `us-west-2` never needs to call `us-east-1` to succeed (except writes to the Aurora primary, handled in Part 7).
2. **Replication is asynchronous** everywhere. That's what keeps regions independent, and it's why RPO is "seconds", not zero.
3. **Queues are regional.** A job enqueued in region A is processed in region A. Job *state* is global (DynamoDB) so any region can answer "is it done?".
4. **No shared single points of failure** across regions (no single NAT, no single Redis, no "global" service that lives in one region).

---

# Part 5: Foundations (Do This Before Any Code)

## 5.1 Accounts (AWS Organizations)

Industry standard is **many accounts**, not one:

```
Organization (management account: billing only)
├── Security OU      → log-archive, security-tooling (GuardDuty, Security Hub delegated admin)
├── Infrastructure OU→ network (Transit Gateway, shared DNS), shared-services (ECR, CI roles)
├── Workloads OU
│   ├── summarizer-dev
│   ├── summarizer-staging
│   └── summarizer-prod      ← both regions live inside this account
└── Sandbox OU
```

- One prod account holds **both regions**. (Some very large companies use one account per region per service; that's a later step.)
- Use **Control Tower** or **Account Factory for Terraform (AFT)** to create accounts with guardrails.
- Use a **Service Control Policy (SCP)** to deny all regions you don't use. This reduces attack surface and stops surprise resources:

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "DenyUnapprovedRegions",
    "Effect": "Deny",
    "NotAction": [
      "iam:*", "organizations:*", "route53:*", "route53-recovery-control-config:*",
      "cloudfront:*", "globalaccelerator:*", "sts:*", "support:*", "waf:*", "budgets:*"
    ],
    "Resource": "*",
    "Condition": {
      "StringNotEquals": { "aws:RequestedRegion": ["us-east-1", "us-west-2"] }
    }
  }]
}
```

> Global services (IAM, Route 53, CloudFront, Global Accelerator) are excluded because their APIs live in `us-east-1` or `us-west-2` regardless of where you use them.

## 5.2 Picking regions

| Factor | What to check |
|---|---|
| **Distance** | Far enough not to share a disaster (power grid, weather), close enough for acceptable replication lag. `us-east-1` + `us-west-2` (~60–70 ms) is the classic US pair. `eu-west-1` + `eu-central-1` for EU. |
| **Service availability** | Every service you use (Aurora version, Bedrock model, instance types) must exist in both regions. |
| **Quotas** | Service quotas are **per region**. Request the same limits (Fargate vCPU, EIPs, ALBs) in the standby region **before** you need them. |
| **Compliance** | Data residency rules can force the pair (e.g. both in EU). |
| **Price** | Prices differ by region (sometimes 10–20%). |

## 5.3 IP address plan

Use **non-overlapping CIDRs** per region so you can peer them later (Transit Gateway inter-region peering or VPC peering):

| Env | us-east-1 | us-west-2 |
|---|---|---|
| prod | `10.10.0.0/16` | `10.20.0.0/16` |
| staging | `10.110.0.0/16` | `10.120.0.0/16` |

## 5.4 Infrastructure as Code layout

Industry practice: **one Terraform state per region per layer**. If a `terraform apply` goes wrong, it only touches one region (small blast radius, also for your IaC).

```
infra/
├── modules/
│   ├── network/            # VPC, subnets, NAT, endpoints
│   ├── app/                # ALB, ECS cluster, api + worker services, SQS, autoscaling, alarms
│   └── regional-health/    # Route 53 health checks, CloudWatch alarms
└── live/
    └── prod/
        ├── global/         # KMS MRK, ECR + replication, DynamoDB global tables, S3 + CRR, secrets, CI OIDC role
        ├── us-east-1/
        │   ├── network/
        │   └── app/
        ├── us-west-2/
        │   ├── network/
        │   └── app/
        ├── data/           # Aurora Global Database (spans both regions)
        └── dns/            # Route 53 records, health checks, ARC
```

**Apply order:** `global → */network → data → */app → dns`.

Many teams use **Terragrunt** to keep these DRY (one `terragrunt.hcl` per folder, shared inputs). Plain Terraform is shown below so nothing is hidden.

## 5.5 Remote state per region

```hcl
# live/prod/us-west-2/app/backend.tf
terraform {
  backend "s3" {
    bucket         = "acme-tfstate-prod"           # bucket itself has versioning + CRR
    key            = "prod/us-west-2/app.tfstate"
    region         = "us-east-1"
    use_lockfile   = true                          # S3 native locking (Terraform 1.10+)
    encrypt        = true
  }
}
```

> Watch out: if your **state bucket** only lives in `us-east-1` and `us-east-1` is down, you can't run Terraform for `us-west-2`. Replicate the state bucket to the other region and document how to switch the backend in an emergency. Your DR path should **not depend on Terraform** anyway (static stability).

## 5.6 Naming and tagging

```
<app>-<env>-<region-short>-<resource>
summarizer-prod-use1-api
summarizer-prod-usw2-api
```

Default tags on every provider:

```hcl
provider "aws" {
  region = var.region
  default_tags {
    tags = {
      app         = "summarizer"
      env         = "prod"
      region_role = var.is_primary ? "primary" : "standby"
      owner       = "platform-team"
      managed_by  = "terraform"
    }
  }
}
```

---

# Part 6: Step-by-Step Setup (Terraform)

Assumes Terraform >= 1.10 and AWS provider >= 5.x. Regions: **`us-east-1` (primary)** and **`us-west-2` (standby)**.

## Step 1: Providers with aliases (for cross-region stacks)

Stacks that touch both regions (`global/`, `data/`, `dns/`) use provider aliases:

```hcl
# live/prod/global/providers.tf
terraform {
  required_version = ">= 1.10"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.80" }
  }
}

provider "aws" {
  alias  = "primary"
  region = "us-east-1"
}

provider "aws" {
  alias  = "secondary"
  region = "us-west-2"
}

data "aws_caller_identity" "current" {
  provider = aws.primary
}

locals {
  app        = "summarizer"
  env        = "prod"
  account_id = data.aws_caller_identity.current.account_id
}
```

## Step 2: Multi-Region KMS key

A **multi-region key** has the same key ID and key material in each region. Data encrypted in `us-east-1` can be decrypted in `us-west-2` **without a cross-region call**. Needed for encrypted Aurora Global, DynamoDB replicas, S3 replication, and replicated secrets.

```hcl
# live/prod/global/kms.tf
resource "aws_kms_key" "primary" {
  provider                = aws.primary
  description             = "${local.app}-${local.env} multi-region key"
  multi_region            = true
  enable_key_rotation     = true
  deletion_window_in_days = 30
}

resource "aws_kms_alias" "primary" {
  provider      = aws.primary
  name          = "alias/${local.app}-${local.env}"
  target_key_id = aws_kms_key.primary.key_id
}

resource "aws_kms_replica_key" "secondary" {
  provider                = aws.secondary
  description             = "${local.app}-${local.env} replica key"
  primary_key_arn         = aws_kms_key.primary.arn
  deletion_window_in_days = 30
}

resource "aws_kms_alias" "secondary" {
  provider      = aws.secondary
  name          = "alias/${local.app}-${local.env}"
  target_key_id = aws_kms_replica_key.secondary.key_id
}

output "kms_key_arn" {
  value = {
    "us-east-1" = aws_kms_key.primary.arn
    "us-west-2" = aws_kms_replica_key.secondary.arn
  }
}
```

## Step 3: ECR with cross-region replication

Build the image **once**, push to the primary region, and let ECR copy it. Each region pulls from its **local** registry, so a `us-east-1` ECR outage can't stop `us-west-2` from scaling.

```hcl
# live/prod/global/ecr.tf
resource "aws_ecr_repository" "api" {
  provider             = aws.primary
  name                 = "${local.app}/api"
  image_tag_mutability = "IMMUTABLE"          # a tag always means the same image
  image_scanning_configuration { scan_on_push = true }
  encryption_configuration {
    encryption_type = "KMS"
    kms_key         = aws_kms_key.primary.arn
  }
}

resource "aws_ecr_replication_configuration" "this" {
  provider = aws.primary
  replication_configuration {
    rule {
      destination {
        region      = "us-west-2"
        registry_id = local.account_id
      }
      repository_filter {
        filter      = "${local.app}/"
        filter_type = "PREFIX_MATCH"
      }
    }
  }
}

resource "aws_ecr_lifecycle_policy" "api" {
  provider   = aws.primary
  repository = aws_ecr_repository.api.name
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "keep last 50 images"
      selection    = { tagStatus = "any", countType = "imageCountMoreThan", countNumber = 50 }
      action       = { type = "expire" }
    }]
  })
}
```

> The replicated repository in `us-west-2` is created automatically on first replication. Set lifecycle policies there too (a small separate resource with `provider = aws.secondary` once it exists, or use a repository creation template).

## Step 4: Regional network (run once per region)

```hcl
# modules/network/main.tf
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"

  name = "${var.app}-${var.env}-${var.region_short}"
  cidr = var.vpc_cidr
  azs  = slice(data.aws_availability_zones.available.names, 0, 3)

  public_subnets   = [for i in range(3) : cidrsubnet(var.vpc_cidr, 8, i)]
  private_subnets  = [for i in range(3) : cidrsubnet(var.vpc_cidr, 8, i + 10)]
  database_subnets = [for i in range(3) : cidrsubnet(var.vpc_cidr, 8, i + 20)]

  enable_nat_gateway     = true
  one_nat_gateway_per_az = true      # a single NAT is a hidden single point of failure
  create_database_subnet_group = true
}

data "aws_availability_zones" "available" { state = "available" }

# VPC endpoints: keep AWS API traffic off NAT, cheaper and fewer failure points
module "endpoints" {
  source  = "terraform-aws-modules/vpc/aws//modules/vpc-endpoints"
  version = "~> 5.0"
  vpc_id  = module.vpc.vpc_id

  endpoints = {
    s3       = { service = "s3", service_type = "Gateway", route_table_ids = module.vpc.private_route_table_ids }
    dynamodb = { service = "dynamodb", service_type = "Gateway", route_table_ids = module.vpc.private_route_table_ids }
    ecr_api  = { service = "ecr.api", private_dns_enabled = true, subnet_ids = module.vpc.private_subnets }
    ecr_dkr  = { service = "ecr.dkr", private_dns_enabled = true, subnet_ids = module.vpc.private_subnets }
    sqs      = { service = "sqs", private_dns_enabled = true, subnet_ids = module.vpc.private_subnets }
    secrets  = { service = "secretsmanager", private_dns_enabled = true, subnet_ids = module.vpc.private_subnets }
    logs     = { service = "logs", private_dns_enabled = true, subnet_ids = module.vpc.private_subnets }
  }
}

output "vpc_id"               { value = module.vpc.vpc_id }
output "private_subnets"      { value = module.vpc.private_subnets }
output "public_subnets"       { value = module.vpc.public_subnets }
output "db_subnet_group_name" { value = module.vpc.database_subnet_group_name }
output "vpc_cidr"             { value = var.vpc_cidr }
```

```hcl
# live/prod/us-east-1/network/main.tf
provider "aws" { region = "us-east-1" }

module "network" {
  source       = "../../../../modules/network"
  app          = "summarizer"
  env          = "prod"
  region_short = "use1"
  vpc_cidr     = "10.10.0.0/16"
}
```

```hcl
# live/prod/us-west-2/network/main.tf
provider "aws" { region = "us-west-2" }

module "network" {
  source       = "../../../../modules/network"
  app          = "summarizer"
  env          = "prod"
  region_short = "usw2"
  vpc_cidr     = "10.20.0.0/16"
}
```

> Same module, different inputs. **Regions must be identical except for their inputs.** Drift between regions is the #1 reason failovers fail.

## Step 5: Aurora Global Database (relational data)

How it works:

- One **primary cluster** (read/write) and one or more **secondary clusters** (read-only).
- Replication happens at the **storage layer**, typically **under 1 second** of lag, with almost no load on the writer.
- **Switchover** (planned, no data loss) and **failover** (unplanned, lose the lag window) are single API calls.
- Optional **write forwarding**: a secondary accepts writes and forwards them to the primary. Useful, but each write pays cross-region latency.

```hcl
# live/prod/data/main.tf
data "terraform_remote_state" "net_use1" {
  backend = "s3"
  config  = { bucket = "acme-tfstate-prod", key = "prod/us-east-1/network.tfstate", region = "us-east-1" }
}
data "terraform_remote_state" "net_usw2" {
  backend = "s3"
  config  = { bucket = "acme-tfstate-prod", key = "prod/us-west-2/network.tfstate", region = "us-east-1" }
}
data "terraform_remote_state" "global" {
  backend = "s3"
  config  = { bucket = "acme-tfstate-prod", key = "prod/global.tfstate", region = "us-east-1" }
}

locals {
  engine         = "aurora-postgresql"
  engine_version = "16.4"   # pick a version supported for Global Database in BOTH regions
}

resource "aws_rds_global_cluster" "main" {
  provider                  = aws.primary
  global_cluster_identifier = "summarizer-prod-global"
  engine                    = local.engine
  engine_version            = local.engine_version
  database_name             = "summarizer"
  storage_encrypted         = true
  deletion_protection       = true
}

# --- primary (us-east-1) ---
resource "aws_security_group" "db_use1" {
  provider = aws.primary
  name     = "summarizer-prod-use1-db"
  vpc_id   = data.terraform_remote_state.net_use1.outputs.vpc_id
  ingress {
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = [data.terraform_remote_state.net_use1.outputs.vpc_cidr]
  }
}

resource "random_password" "db" {
  length  = 32
  special = false
}

resource "aws_rds_cluster" "primary" {
  provider                  = aws.primary
  cluster_identifier        = "summarizer-prod-use1"
  engine                    = aws_rds_global_cluster.main.engine
  engine_version            = aws_rds_global_cluster.main.engine_version
  global_cluster_identifier = aws_rds_global_cluster.main.id
  master_username           = "summarizer_admin"
  master_password           = random_password.db.result   # stored in Secrets Manager in Step 8
  db_subnet_group_name      = data.terraform_remote_state.net_use1.outputs.db_subnet_group_name
  vpc_security_group_ids    = [aws_security_group.db_use1.id]
  storage_encrypted         = true
  kms_key_id                = data.terraform_remote_state.global.outputs.kms_key_arn["us-east-1"]
  backup_retention_period   = 14
  deletion_protection       = true
  copy_tags_to_snapshot     = true
  enabled_cloudwatch_logs_exports = ["postgresql"]

  lifecycle {
    ignore_changes = [global_cluster_identifier, replication_source_identifier]
  }
}

resource "aws_rds_cluster_instance" "primary" {
  provider             = aws.primary
  count                = 2                                  # writer + reader in different AZs
  identifier           = "summarizer-prod-use1-${count.index}"
  cluster_identifier   = aws_rds_cluster.primary.id
  instance_class       = "db.r7g.large"
  engine               = aws_rds_cluster.primary.engine
  engine_version       = aws_rds_cluster.primary.engine_version
  performance_insights_enabled = true
}

# --- secondary (us-west-2) ---
resource "aws_security_group" "db_usw2" {
  provider = aws.secondary
  name     = "summarizer-prod-usw2-db"
  vpc_id   = data.terraform_remote_state.net_usw2.outputs.vpc_id
  ingress {
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = [data.terraform_remote_state.net_usw2.outputs.vpc_cidr]
  }
}

resource "aws_rds_cluster" "secondary" {
  provider                  = aws.secondary
  cluster_identifier        = "summarizer-prod-usw2"
  engine                    = aws_rds_global_cluster.main.engine
  engine_version            = aws_rds_global_cluster.main.engine_version
  global_cluster_identifier = aws_rds_global_cluster.main.id
  db_subnet_group_name      = data.terraform_remote_state.net_usw2.outputs.db_subnet_group_name
  vpc_security_group_ids    = [aws_security_group.db_usw2.id]
  storage_encrypted         = true
  kms_key_id                = data.terraform_remote_state.global.outputs.kms_key_arn["us-west-2"]
  deletion_protection       = true
  skip_final_snapshot       = true
  # no master_username/password: inherited from the primary

  depends_on = [aws_rds_cluster_instance.primary]

  lifecycle {
    # after a failover/switchover the roles flip; don't let Terraform fight that
    ignore_changes = [global_cluster_identifier, replication_source_identifier]
  }
}

resource "aws_rds_cluster_instance" "secondary" {
  provider           = aws.secondary
  count              = 2              # warm standby: same size as primary = statically stable
  identifier         = "summarizer-prod-usw2-${count.index}"
  cluster_identifier = aws_rds_cluster.secondary.id
  instance_class     = "db.r7g.large"
  engine             = aws_rds_cluster.secondary.engine
  engine_version     = aws_rds_cluster.secondary.engine_version
  performance_insights_enabled = true
}

output "db_endpoints" {
  value = {
    "us-east-1" = { writer = aws_rds_cluster.primary.endpoint,   reader = aws_rds_cluster.primary.reader_endpoint }
    "us-west-2" = { writer = aws_rds_cluster.secondary.endpoint, reader = aws_rds_cluster.secondary.reader_endpoint }
  }
}
```

**About the writer endpoint after failover.** Each cluster's own writer endpoint changes role when the primary moves. Two industry options:

1. Use the Aurora **global writer endpoint** (a managed DNS name that always points at the current primary cluster's writer), if available for your engine version.
2. Or keep your own **private Route 53 record** `db-writer.summarizer.internal` that your failover runbook updates (prefer a pre-created failover record with health checks over editing during an incident).

The app (Part 7) always uses a **"writer" name** and a **"local reader" name**, never a hardcoded cluster endpoint.

## Step 6: DynamoDB Global Tables (job state, idempotency keys)

- **Multi-active:** every replica accepts reads and writes. Replication is usually about a second.
- **Conflict rule:** **last writer wins** (by timestamp) for the default, eventually consistent mode. Newer AWS versions also offer a multi-region strong consistency mode with higher write latency; check whether your regions support it before relying on it.
- Great for: job status, sessions, idempotency records, feature flags.

```hcl
# live/prod/global/dynamodb.tf
resource "aws_dynamodb_table" "jobs" {
  provider         = aws.primary
  name             = "summarizer-prod-jobs"
  billing_mode     = "PAY_PER_REQUEST"
  hash_key         = "job_id"
  stream_enabled   = true                       # required for global tables
  stream_view_type = "NEW_AND_OLD_IMAGES"

  attribute {
    name = "job_id"
    type = "S"
  }

  ttl {
    attribute_name = "expires_at"
    enabled        = true
  }

  point_in_time_recovery { enabled = true }

  server_side_encryption {
    enabled     = true
    kms_key_arn = aws_kms_key.primary.arn
  }

  replica {
    region_name            = "us-west-2"
    kms_key_arn            = aws_kms_replica_key.secondary.arn
    point_in_time_recovery = true
    propagate_tags         = true
  }

  deletion_protection_enabled = true
}

resource "aws_dynamodb_table" "idempotency" {
  provider         = aws.primary
  name             = "summarizer-prod-idempotency"
  billing_mode     = "PAY_PER_REQUEST"
  hash_key         = "key"
  stream_enabled   = true
  stream_view_type = "NEW_AND_OLD_IMAGES"

  attribute {
    name = "key"
    type = "S"
  }

  ttl {
    attribute_name = "expires_at"
    enabled        = true
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = aws_kms_key.primary.arn
  }

  replica {
    region_name = "us-west-2"
    kms_key_arn = aws_kms_replica_key.secondary.arn
  }
}
```

> **Gotcha:** conditional writes (`attribute_not_exists(key)`) are only checked **within one region**. Two regions can both "win" the same idempotency key within the replication window. That's why idempotency checks should happen in the **user's home region** (Part 7.5).

## Step 7: S3 with Cross-Region Replication (summary blobs, article cache)

```hcl
# live/prod/global/s3.tf
resource "aws_s3_bucket" "summaries_use1" {
  provider = aws.primary
  bucket   = "acme-summarizer-prod-use1-summaries"
}

resource "aws_s3_bucket" "summaries_usw2" {
  provider = aws.secondary
  bucket   = "acme-summarizer-prod-usw2-summaries"
}

# versioning is required on both sides for replication
resource "aws_s3_bucket_versioning" "use1" {
  provider = aws.primary
  bucket   = aws_s3_bucket.summaries_use1.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_versioning" "usw2" {
  provider = aws.secondary
  bucket   = aws_s3_bucket.summaries_usw2.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "use1" {
  provider = aws.primary
  bucket   = aws_s3_bucket.summaries_use1.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.primary.arn
    }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "usw2" {
  provider = aws.secondary
  bucket   = aws_s3_bucket.summaries_usw2.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_replica_key.secondary.arn
    }
    bucket_key_enabled = true
  }
}

data "aws_iam_policy_document" "replication_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["s3.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "replication" {
  provider           = aws.primary
  name               = "summarizer-prod-s3-replication"
  assume_role_policy = data.aws_iam_policy_document.replication_assume.json
}

data "aws_iam_policy_document" "replication" {
  statement {
    actions   = ["s3:GetReplicationConfiguration", "s3:ListBucket"]
    resources = [aws_s3_bucket.summaries_use1.arn, aws_s3_bucket.summaries_usw2.arn]
  }
  statement {
    actions = [
      "s3:GetObjectVersionForReplication", "s3:GetObjectVersionAcl", "s3:GetObjectVersionTagging",
    ]
    resources = ["${aws_s3_bucket.summaries_use1.arn}/*", "${aws_s3_bucket.summaries_usw2.arn}/*"]
  }
  statement {
    actions   = ["s3:ReplicateObject", "s3:ReplicateDelete", "s3:ReplicateTags"]
    resources = ["${aws_s3_bucket.summaries_use1.arn}/*", "${aws_s3_bucket.summaries_usw2.arn}/*"]
  }
  statement {
    actions   = ["kms:Decrypt", "kms:Encrypt", "kms:GenerateDataKey"]
    resources = [aws_kms_key.primary.arn, aws_kms_replica_key.secondary.arn]
  }
}

resource "aws_iam_role_policy" "replication" {
  provider = aws.primary
  role     = aws_iam_role.replication.id
  policy   = data.aws_iam_policy_document.replication.json
}

resource "aws_s3_bucket_replication_configuration" "use1_to_usw2" {
  provider   = aws.primary
  depends_on = [aws_s3_bucket_versioning.use1, aws_s3_bucket_versioning.usw2]
  role       = aws_iam_role.replication.arn
  bucket     = aws_s3_bucket.summaries_use1.id

  rule {
    id     = "to-usw2"
    status = "Enabled"
    filter {}

    delete_marker_replication { status = "Enabled" }

    source_selection_criteria {
      sse_kms_encrypted_objects { status = "Enabled" }
    }

    destination {
      bucket        = aws_s3_bucket.summaries_usw2.arn
      storage_class = "STANDARD"
      encryption_configuration {
        replica_kms_key_id = aws_kms_replica_key.secondary.arn
      }
      # Replication Time Control: 99.99% of objects within 15 minutes, with metrics
      replication_time {
        status = "Enabled"
        time { minutes = 15 }
      }
      metrics {
        status = "Enabled"
        event_threshold { minutes = 15 }
      }
    }
  }
}
```

- For **active-active**, add the reverse rule (`usw2 → use1`) so writes in either region replicate (bi-directional replication; S3 avoids loops via replica metadata).
- **S3 Multi-Region Access Points** give one global endpoint that routes to the nearest bucket and supports failover controls. Useful if you don't want the app to know bucket names per region.

## Step 8: Secrets Manager replication

```hcl
# live/prod/global/secrets.tf
resource "aws_secretsmanager_secret" "llm_api_key" {
  provider   = aws.primary
  name       = "summarizer/prod/llm-api-key"
  kms_key_id = aws_kms_key.primary.arn

  replica {
    region     = "us-west-2"
    kms_key_id = aws_kms_replica_key.secondary.arn
  }
}

resource "aws_secretsmanager_secret" "db" {
  provider   = aws.primary
  name       = "summarizer/prod/db"
  kms_key_id = aws_kms_key.primary.arn

  replica {
    region     = "us-west-2"
    kms_key_id = aws_kms_replica_key.secondary.arn
  }
}
```

- The app reads secrets from its **local region** (`AWS_REGION`), so a `us-east-1` Secrets Manager outage doesn't block `us-west-2`.
- Rotation runs on the primary secret and the new value replicates.

## Step 9: The regional app stack (ECS Fargate)

The same module runs in each region. The only difference between primary and standby is **inputs** (task counts, `is_primary`).

```hcl
# modules/app/variables.tf
variable "region"            { type = string }
variable "region_short"      { type = string }
variable "is_primary"        { type = bool }
variable "image_uri"         { type = string }   # <acct>.dkr.ecr.<region>.amazonaws.com/summarizer/api:<git-sha>
variable "api_min_tasks"     { type = number }
variable "api_max_tasks"     { type = number }
variable "worker_min_tasks"  { type = number }
variable "worker_max_tasks"  { type = number }
variable "vpc_id"            { type = string }
variable "public_subnets"    { type = list(string) }
variable "private_subnets"   { type = list(string) }
variable "certificate_arn"   { type = string }   # ACM certs are regional: one per region
variable "db_writer_host"    { type = string }
variable "db_reader_host"    { type = string }
variable "jobs_table"        { type = string }
variable "idempotency_table" { type = string }
variable "summaries_bucket"  { type = string }
variable "secret_arns"       { type = map(string) }
```

```hcl
# modules/app/main.tf  (condensed: focus on the multi-region-relevant parts)
locals {
  name = "summarizer-prod-${var.region_short}"
  common_env = [
    { name = "AWS_REGION",          value = var.region },
    { name = "APP_REGION",          value = var.region },
    { name = "PRIMARY_REGION",      value = "us-east-1" },
    { name = "DB_WRITER_HOST",      value = var.db_writer_host },
    { name = "DB_READER_HOST",      value = var.db_reader_host },
    { name = "JOBS_TABLE",          value = var.jobs_table },
    { name = "IDEMPOTENCY_TABLE",   value = var.idempotency_table },
    { name = "SUMMARIES_BUCKET",    value = var.summaries_bucket },
    { name = "JOBS_QUEUE_URL",      value = aws_sqs_queue.jobs.url },
  ]
}

resource "aws_ecs_cluster" "this" {
  name = local.name
  setting {
    name  = "containerInsights"
    value = "enabled"
  }
}

# --- regional queue: jobs never cross regions ---
resource "aws_sqs_queue" "jobs_dlq" {
  name                      = "${local.name}-jobs-dlq"
  message_retention_seconds = 1209600
}

resource "aws_sqs_queue" "jobs" {
  name                       = "${local.name}-jobs"
  visibility_timeout_seconds = 300
  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.jobs_dlq.arn
    maxReceiveCount     = 5
  })
}

# --- ALB ---
resource "aws_lb" "api" {
  name               = "${local.name}-api"
  load_balancer_type = "application"
  subnets            = var.public_subnets
  security_groups    = [aws_security_group.alb.id]
  drop_invalid_header_fields = true
}

resource "aws_lb_target_group" "api" {
  name        = "${local.name}-api"
  port        = 8000
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_id
  deregistration_delay = 30

  health_check {
    path                = "/health/ready"
    healthy_threshold   = 2
    unhealthy_threshold = 3
    interval            = 10
    timeout             = 5
    matcher             = "200"
  }
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.api.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = var.certificate_arn
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.api.arn
  }
}

# --- API task + service ---
resource "aws_ecs_task_definition" "api" {
  family                   = "${local.name}-api"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 1024
  memory                   = 2048
  execution_role_arn       = aws_iam_role.execution.arn
  task_role_arn            = aws_iam_role.task.arn
  runtime_platform {
    cpu_architecture        = "ARM64"
    operating_system_family = "LINUX"
  }

  container_definitions = jsonencode([{
    name         = "api"
    image        = var.image_uri
    essential    = true
    portMappings = [{ containerPort = 8000 }]
    command      = ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
    environment  = local.common_env
    secrets = [
      { name = "DB_SECRET",   valueFrom = var.secret_arns["db"] },
      { name = "LLM_API_KEY", valueFrom = var.secret_arns["llm"] },
    ]
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = aws_cloudwatch_log_group.api.name
        awslogs-region        = var.region
        awslogs-stream-prefix = "api"
      }
    }
  }])
}

resource "aws_ecs_service" "api" {
  name            = "api"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.api.arn
  desired_count   = var.api_min_tasks
  launch_type     = "FARGATE"

  network_configuration {
    subnets         = var.private_subnets
    security_groups = [aws_security_group.api.id]
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.api.arn
    container_name   = "api"
    container_port   = 8000
  }

  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200

  deployment_circuit_breaker {
    enable   = true
    rollback = true          # a bad deploy rolls itself back in this region
  }

  deployment_controller { type = "ECS" }

  lifecycle {
    ignore_changes = [desired_count]   # autoscaling owns this
  }
}

resource "aws_appautoscaling_target" "api" {
  service_namespace  = "ecs"
  resource_id        = "service/${aws_ecs_cluster.this.name}/${aws_ecs_service.api.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  min_capacity       = var.api_min_tasks
  max_capacity       = var.api_max_tasks
}

resource "aws_appautoscaling_policy" "api_cpu" {
  name               = "${local.name}-api-cpu"
  service_namespace  = aws_appautoscaling_target.api.service_namespace
  resource_id        = aws_appautoscaling_target.api.resource_id
  scalable_dimension = aws_appautoscaling_target.api.scalable_dimension
  policy_type        = "TargetTrackingScaling"
  target_tracking_scaling_policy_configuration {
    target_value = 50          # leave headroom for a sudden failover surge
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
    scale_out_cooldown = 60
    scale_in_cooldown  = 300
  }
}

# Worker service: same pattern, scaled on queue depth (ApproximateNumberOfMessagesVisible).
# Omitted for brevity; it uses the same image with command ["python", "-m", "app.worker"].

output "alb_dns_name" { value = aws_lb.api.dns_name }
output "alb_zone_id"  { value = aws_lb.api.zone_id }
output "alb_arn"      { value = aws_lb.api.arn }
output "jobs_queue"   { value = aws_sqs_queue.jobs.url }
```

The task IAM role should only allow **its own region's** queue and both table replicas:

```hcl
data "aws_iam_policy_document" "task" {
  statement {
    actions   = ["sqs:SendMessage", "sqs:ReceiveMessage", "sqs:DeleteMessage", "sqs:ChangeMessageVisibility", "sqs:GetQueueAttributes"]
    resources = [aws_sqs_queue.jobs.arn]
  }
  statement {
    actions = ["dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:UpdateItem", "dynamodb:Query"]
    resources = [
      "arn:aws:dynamodb:${var.region}:*:table/${var.jobs_table}",
      "arn:aws:dynamodb:${var.region}:*:table/${var.idempotency_table}",
    ]
  }
  statement {
    actions   = ["s3:GetObject", "s3:PutObject"]
    resources = ["arn:aws:s3:::${var.summaries_bucket}/*"]
  }
}
```

Now instantiate it in each region:

```hcl
# live/prod/us-east-1/app/main.tf
provider "aws" { region = "us-east-1" }

module "app" {
  source            = "../../../../modules/app"
  region            = "us-east-1"
  region_short      = "use1"
  is_primary        = true
  image_uri         = "${local.account_id}.dkr.ecr.us-east-1.amazonaws.com/summarizer/api:${var.image_tag}"
  api_min_tasks     = 6
  api_max_tasks     = 60
  worker_min_tasks  = 4
  worker_max_tasks  = 40
  vpc_id            = data.terraform_remote_state.net.outputs.vpc_id
  public_subnets    = data.terraform_remote_state.net.outputs.public_subnets
  private_subnets   = data.terraform_remote_state.net.outputs.private_subnets
  certificate_arn   = aws_acm_certificate.api.arn
  db_writer_host    = "db-writer.summarizer.internal"
  db_reader_host    = data.terraform_remote_state.data.outputs.db_endpoints["us-east-1"].reader
  jobs_table        = "summarizer-prod-jobs"
  idempotency_table = "summarizer-prod-idempotency"
  summaries_bucket  = "acme-summarizer-prod-use1-summaries"
  secret_arns       = { db = "...use1 arn...", llm = "...use1 arn..." }
}
```

```hcl
# live/prod/us-west-2/app/main.tf
provider "aws" { region = "us-west-2" }

module "app" {
  source            = "../../../../modules/app"
  region            = "us-west-2"
  region_short      = "usw2"
  is_primary        = false
  image_uri         = "${local.account_id}.dkr.ecr.us-west-2.amazonaws.com/summarizer/api:${var.image_tag}"
  # Warm standby: smaller min, SAME max. For full static stability set min = primary's min.
  api_min_tasks     = 2
  api_max_tasks     = 60
  worker_min_tasks  = 1
  worker_max_tasks  = 40
  vpc_id            = data.terraform_remote_state.net.outputs.vpc_id
  public_subnets    = data.terraform_remote_state.net.outputs.public_subnets
  private_subnets   = data.terraform_remote_state.net.outputs.private_subnets
  certificate_arn   = aws_acm_certificate.api.arn
  db_writer_host    = "db-writer.summarizer.internal"
  db_reader_host    = data.terraform_remote_state.data.outputs.db_endpoints["us-west-2"].reader
  jobs_table        = "summarizer-prod-jobs"
  idempotency_table = "summarizer-prod-idempotency"
  summaries_bucket  = "acme-summarizer-prod-usw2-summaries"
  secret_arns       = { db = "...usw2 replica arn...", llm = "...usw2 replica arn..." }
}
```

> **ACM certificates are regional.** Each ALB needs a cert issued in its own region (both can be for `api.example.com`). CloudFront is the exception: its certs must be in `us-east-1`.

## Step 10: ElastiCache Global Datastore (optional)

If you cache summaries in Valkey/Redis:

- **Global Datastore** gives one primary cluster and up to two read-only secondary clusters in other regions, with sub-second replication, and promotion on failover.
- Simpler and often better: **treat cache as regional and disposable**. Each region has its own cache that warms up from local reads. A cold cache after failover is a load spike, not data loss. Plan DB capacity for it.

```hcl
resource "aws_elasticache_global_replication_group" "cache" {
  provider                           = aws.primary
  global_replication_group_id_suffix = "summarizer-prod"
  primary_replication_group_id       = aws_elasticache_replication_group.use1.id
}

resource "aws_elasticache_replication_group" "usw2" {
  provider                    = aws.secondary
  replication_group_id        = "summarizer-prod-usw2"
  description                 = "secondary cache"
  global_replication_group_id = aws_elasticache_global_replication_group.cache.global_replication_group_id
  num_cache_clusters          = 2
  subnet_group_name           = aws_elasticache_subnet_group.usw2.name
}
```

## Step 11: Route 53 health checks and DNS records

Choose the routing policy that matches your strategy:

| Strategy | Route 53 policy |
|---|---|
| Active-passive (warm standby) | **Failover** (PRIMARY / SECONDARY) + health checks |
| Active-active by geography | **Latency-based** + health checks |
| Gradual shift / canary region | **Weighted** + health checks |
| Data residency | **Geolocation** (EU users → EU region) |

### Health checks

```hcl
# live/prod/dns/health.tf
resource "aws_route53_health_check" "use1" {
  fqdn              = "use1.api.example.com"   # region-specific name pointing straight at the ALB
  port              = 443
  type              = "HTTPS"
  resource_path     = "/health/ready"
  failure_threshold = 3
  request_interval  = 10
  measure_latency   = true
  regions           = ["us-east-1", "us-west-1", "eu-west-1"]   # checkers from several places
  tags = { Name = "summarizer-prod-use1" }
}

resource "aws_route53_health_check" "usw2" {
  fqdn              = "usw2.api.example.com"
  port              = 443
  type              = "HTTPS"
  resource_path     = "/health/ready"
  failure_threshold = 3
  request_interval  = 10
  measure_latency   = true
  regions           = ["us-east-1", "us-west-1", "eu-west-1"]
  tags = { Name = "summarizer-prod-usw2" }
}
```

> Region-specific hostnames (`use1.api.example.com`) are also how your on-call engineers and synthetic canaries test **one region directly**.

### Option A: Failover records (active-passive)

```hcl
resource "aws_route53_record" "api_primary" {
  zone_id         = var.zone_id
  name            = "api.example.com"
  type            = "A"
  set_identifier  = "primary-use1"
  health_check_id = aws_route53_health_check.use1.id

  failover_routing_policy { type = "PRIMARY" }

  alias {
    name                   = data.terraform_remote_state.app_use1.outputs.alb_dns_name
    zone_id                = data.terraform_remote_state.app_use1.outputs.alb_zone_id
    evaluate_target_health = true
  }
}

resource "aws_route53_record" "api_secondary" {
  zone_id         = var.zone_id
  name            = "api.example.com"
  type            = "A"
  set_identifier  = "secondary-usw2"
  health_check_id = aws_route53_health_check.usw2.id

  failover_routing_policy { type = "SECONDARY" }

  alias {
    name                   = data.terraform_remote_state.app_usw2.outputs.alb_dns_name
    zone_id                = data.terraform_remote_state.app_usw2.outputs.alb_zone_id
    evaluate_target_health = true
  }
}
```

### Option B: Latency records (active-active)

```hcl
resource "aws_route53_record" "api_latency" {
  for_each = {
    "us-east-1" = { hc = aws_route53_health_check.use1.id, app = data.terraform_remote_state.app_use1.outputs }
    "us-west-2" = { hc = aws_route53_health_check.usw2.id, app = data.terraform_remote_state.app_usw2.outputs }
  }

  zone_id         = var.zone_id
  name            = "api.example.com"
  type            = "A"
  set_identifier  = each.key
  health_check_id = each.value.hc

  latency_routing_policy { region = each.key }

  alias {
    name                   = each.value.app.alb_dns_name
    zone_id                = each.value.app.alb_zone_id
    evaluate_target_health = true
  }
}
```

> **DNS TTL:** alias records use the target's TTL (ALB: 60 s). Clients and resolvers sometimes cache longer than they should. Expect **1–5 minutes** for most traffic to move, with a long tail. If you need faster, sub-minute shifts, use **Global Accelerator** (Part 9).

## Step 12: Route 53 Application Recovery Controller (ARC) — the "big red switch"

Automatic health-check failover is great for clean failures. Real regional problems are often **partial** (elevated errors, slow dependencies). Industry teams prefer a **human-decided, one-command, data-plane** failover. ARC routing controls give exactly that.

- A **cluster** of five redundant regional endpoints. Flipping a control is a **data-plane** call, so it works even if a control plane is impaired.
- Each **routing control** is an ON/OFF switch tied to a Route 53 health check.
- **Safety rules** prevent mistakes (e.g. "at least one region must be ON").

```hcl
# live/prod/dns/arc.tf  (ARC config APIs live in us-west-2)
resource "aws_route53recoverycontrolconfig_cluster" "this" {
  name = "summarizer-prod"
}

resource "aws_route53recoverycontrolconfig_control_panel" "this" {
  name        = "summarizer-prod"
  cluster_arn = aws_route53recoverycontrolconfig_cluster.this.arn
}

resource "aws_route53recoverycontrolconfig_routing_control" "use1" {
  name              = "use1"
  cluster_arn       = aws_route53recoverycontrolconfig_cluster.this.arn
  control_panel_arn = aws_route53recoverycontrolconfig_control_panel.this.arn
}

resource "aws_route53recoverycontrolconfig_routing_control" "usw2" {
  name              = "usw2"
  cluster_arn       = aws_route53recoverycontrolconfig_cluster.this.arn
  control_panel_arn = aws_route53recoverycontrolconfig_control_panel.this.arn
}

resource "aws_route53recoverycontrolconfig_safety_rule" "at_least_one_on" {
  name              = "at-least-one-region-on"
  control_panel_arn = aws_route53recoverycontrolconfig_control_panel.this.arn
  wait_period_ms    = 5000
  asserted_controls = [
    aws_route53recoverycontrolconfig_routing_control.use1.arn,
    aws_route53recoverycontrolconfig_routing_control.usw2.arn,
  ]
  rule_config {
    inverted  = false
    threshold = 1
    type      = "ATLEAST"
  }
}

# health checks that simply mirror the ON/OFF state of each control
resource "aws_route53_health_check" "arc_use1" {
  type                = "RECOVERY_CONTROL"
  routing_control_arn = aws_route53recoverycontrolconfig_routing_control.use1.arn
}

resource "aws_route53_health_check" "arc_usw2" {
  type                = "RECOVERY_CONTROL"
  routing_control_arn = aws_route53recoverycontrolconfig_routing_control.usw2.arn
}
```

Attach `aws_route53_health_check.arc_use1.id` to the `use1` DNS record (instead of, or combined via a `CALCULATED` health check with, the HTTP health check). Turning a control **OFF** drains that region from DNS.

> AWS has also been adding higher-level orchestration to ARC (for example region switch plans that run the DB failover, scaling, and routing steps for you). Evaluate it, but understand the manual steps in Part 10 first.

---

# Part 7: App Changes (FastAPI)

Infrastructure alone doesn't make an app multi-region. The code has to know **where it is**, **where writes go**, and **what "healthy" means**.

## 7.1 Region-aware settings

```python
# app/config.py
from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_region: str                     # where this task runs, e.g. "us-west-2"
    primary_region: str = "us-east-1"   # where the Aurora writer currently lives

    db_writer_host: str                 # always a stable name, never a cluster endpoint
    db_reader_host: str                 # local region reader
    db_name: str = "summarizer"
    db_secret: str                      # JSON injected by ECS from Secrets Manager

    jobs_table: str
    idempotency_table: str
    summaries_bucket: str
    jobs_queue_url: str

    db_connect_timeout_s: float = 3.0
    cross_region_write_timeout_s: float = 2.0

    @property
    def is_primary(self) -> bool:
        return self.app_region == self.primary_region


@lru_cache
def get_settings() -> Settings:
    return Settings()
```

## 7.2 Read local, write to the primary

Two engines: a **writer** (may be cross-region) and a **local reader**.

```python
# app/db.py
import json
from collections.abc import AsyncIterator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.config import get_settings

s = get_settings()
creds = json.loads(s.db_secret)


def _url(host: str) -> str:
    return f"postgresql+asyncpg://{creds['username']}:{creds['password']}@{host}:5432/{s.db_name}"


writer_engine = create_async_engine(
    _url(s.db_writer_host),
    pool_size=5,
    max_overflow=5,
    pool_pre_ping=True,
    pool_recycle=300,           # re-resolve DNS after a failover moves the writer
    connect_args={"timeout": s.db_connect_timeout_s, "command_timeout": s.cross_region_write_timeout_s},
)

reader_engine = create_async_engine(
    _url(s.db_reader_host),
    pool_size=10,
    max_overflow=10,
    pool_pre_ping=True,
    connect_args={"timeout": s.db_connect_timeout_s},
)

WriterSession = async_sessionmaker(writer_engine, expire_on_commit=False)
ReaderSession = async_sessionmaker(reader_engine, expire_on_commit=False)


async def write_session() -> AsyncIterator[AsyncSession]:
    async with WriterSession() as session:
        yield session


async def read_session() -> AsyncIterator[AsyncSession]:
    async with ReaderSession() as session:
        yield session
```

**Why `pool_recycle` and `pool_pre_ping` matter:** after a failover, the writer DNS name points to a new IP. Old pooled connections point to the dead (or now read-only) instance. Pre-ping drops dead connections; recycle forces fresh DNS lookups. Also make sure the JVM-style "cache DNS forever" problem doesn't exist in your stack (Python resolves each connect, but some proxies/sidecars cache).

**Handle "read-only" errors after failover.** Writes that land on a demoted instance fail with `cannot execute ... in a read-only transaction`. Treat that as **retryable**: dispose the pool and retry once.

```python
# app/db_retry.py
from sqlalchemy.exc import DBAPIError

from app.db import writer_engine

READ_ONLY_MARKERS = ("read-only transaction", "cannot execute", "recovery is in progress")


async def run_write_with_failover_retry(fn, *args, **kwargs):
    try:
        return await fn(*args, **kwargs)
    except DBAPIError as exc:
        if any(m in str(exc.orig).lower() for m in READ_ONLY_MARKERS):
            await writer_engine.dispose()     # drop connections to the old primary
            return await fn(*args, **kwargs)  # one retry; caller must be idempotent
        raise
```

## 7.3 Read-your-writes across regions

Problem: user creates a summary (write goes to `us-east-1`), then the next `GET` lands in `us-west-2` whose replica is ~1 s behind → **404**.

Industry fixes (pick one):

| Fix | How |
|---|---|
| **Sticky region per user** | Keep a user on one region for a session (cookie or home region). Most common. |
| **Read from writer after write** | For a few seconds after a user writes, read their data from the writer. |
| **Version token** | Return a version/LSN with the write; the reader waits or falls back if its replica is older. |
| **Use DynamoDB for that path** | Job status lives in DynamoDB Global Tables; a strongly consistent read in the writing region is exact. |

A simple "recent writer" approach:

```python
# app/routes/summaries.py
from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.db import read_session, write_session

router = APIRouter()
RECENT_WRITE_COOKIE = "rw_until"


def pick_session(request: Request):
    import time
    recent = float(request.cookies.get(RECENT_WRITE_COOKIE, "0")) > time.time()
    return write_session if recent else read_session


@router.get("/summaries/{summary_id}")
async def get_summary(summary_id: str, request: Request):
    session_dep = pick_session(request)
    async for session in session_dep():
        return await load_summary(session, summary_id)


@router.post("/summaries", status_code=202)
async def create_summary(payload: dict, response: Response, session: AsyncSession = Depends(write_session)):
    import time
    job = await create_job(session, payload)
    response.set_cookie(RECENT_WRITE_COOKIE, str(time.time() + 5), max_age=5, httponly=True, secure=True)
    return job
```

## 7.4 Health checks that don't cause cascading failover

This is where many teams get burned.

| Endpoint | Checks | Used by |
|---|---|---|
| `/health/live` | Process is up (no dependencies) | ECS container health check (restart if dead) |
| `/health/ready` | **Local** critical dependencies: local DB reader, local DynamoDB, local SQS | ALB target group, Route 53 health check |
| `/health/deep` | Everything, including cross-region writer and the LLM provider | Dashboards and alarms only. **Never** wired to routing. |

Rules:

- **Don't** fail `/health/ready` because the **cross-region** writer or a **third-party** API is down. If you do, both regions fail health checks together (they share that dependency) and Route 53 has nowhere to send traffic. (Route 53 "fails open" when all records are unhealthy, but you've still flapped everything.)
- **Do** cache the result for a few seconds so health checks don't hammer the DB.

```python
# app/routes/health.py
import asyncio
import time

import boto3
from fastapi import APIRouter, Response
from sqlalchemy import text

from app.config import get_settings
from app.db import reader_engine

router = APIRouter()
s = get_settings()
ddb = boto3.client("dynamodb", region_name=s.app_region)

_cache: dict[str, tuple[float, bool, dict]] = {}
CACHE_TTL_S = 5


async def _check_db() -> bool:
    async with reader_engine.connect() as conn:
        await asyncio.wait_for(conn.execute(text("SELECT 1")), timeout=1.0)
    return True


async def _check_dynamo() -> bool:
    await asyncio.wait_for(
        asyncio.to_thread(ddb.describe_table, TableName=s.jobs_table), timeout=1.0
    )
    return True


async def _ready() -> tuple[bool, dict]:
    now = time.monotonic()
    if (hit := _cache.get("ready")) and now - hit[0] < CACHE_TTL_S:
        return hit[1], hit[2]

    results = await asyncio.gather(_check_db(), _check_dynamo(), return_exceptions=True)
    detail = {
        "region": s.app_region,
        "db_reader": results[0] is True,
        "dynamodb": results[1] is True,
    }
    ok = all(v is True for v in results)
    _cache["ready"] = (now, ok, detail)
    return ok, detail


@router.get("/health/live")
async def live():
    return {"status": "ok", "region": s.app_region}


@router.get("/health/ready")
async def ready(response: Response):
    ok, detail = await _ready()
    if not ok:
        response.status_code = 503
    return detail
```

## 7.5 Idempotency in a multi-region world

Client retries can land in a **different region** than the first attempt (DNS changed, failover happened). DynamoDB Global Tables replicate the key, but the conditional check is regional.

The safe pattern: **check idempotency in the user's home region**, and make the job itself idempotent.

```python
# app/idempotency.py
import time

import boto3
from botocore.exceptions import ClientError

from app.config import get_settings

s = get_settings()
TTL_S = 24 * 3600


def _table_client(region: str):
    return boto3.client("dynamodb", region_name=region)


def claim_key(key: str, request_hash: str, home_region: str) -> dict | None:
    """Return None if we claimed the key, or the stored record if it already exists."""
    client = _table_client(home_region)   # usually == s.app_region; cross-region only for pinned users
    try:
        client.put_item(
            TableName=s.idempotency_table,
            Item={
                "key": {"S": key},
                "request_hash": {"S": request_hash},
                "status": {"S": "IN_PROGRESS"},
                "region": {"S": s.app_region},
                "expires_at": {"N": str(int(time.time()) + TTL_S)},
            },
            ConditionExpression="attribute_not_exists(#k)",
            ExpressionAttributeNames={"#k": "key"},
        )
        return None
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "ConditionalCheckFailedException":
            raise
        existing = client.get_item(
            TableName=s.idempotency_table, Key={"key": {"S": key}}, ConsistentRead=True
        )
        return existing.get("Item")
```

Where does `home_region` come from? A small, globally replicated `users` record (or a claim in the JWT) that says `"home_region": "us-east-1"`. This is the same idea as **cell-based architecture**: each user belongs to one cell; any region can route to it.

## 7.6 Workers: regional queues, global job state

```python
# app/worker.py
import asyncio
import json
import logging

import boto3

from app.config import get_settings

s = get_settings()
log = logging.getLogger("worker")
sqs = boto3.client("sqs", region_name=s.app_region)
ddb = boto3.client("dynamodb", region_name=s.app_region)


def mark(job_id: str, status: str, **extra):
    expr = "SET #s = :s, processed_region = :r"
    values = {":s": {"S": status}, ":r": {"S": s.app_region}}
    for k, v in extra.items():
        expr += f", {k} = :{k}"
        values[f":{k}"] = {"S": v}
    ddb.update_item(
        TableName=s.jobs_table,
        Key={"job_id": {"S": job_id}},
        UpdateExpression=expr,
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues=values,
    )


async def handle(msg: dict):
    body = json.loads(msg["Body"])
    job_id = body["job_id"]
    mark(job_id, "RUNNING")
    summary_key = await summarize_and_store(body["url"], job_id)   # writes to the LOCAL S3 bucket
    mark(job_id, "DONE", summary_key=summary_key)


async def main():
    while True:
        resp = await asyncio.to_thread(
            sqs.receive_message,
            QueueUrl=s.jobs_queue_url,
            MaxNumberOfMessages=10,
            WaitTimeSeconds=20,
            VisibilityTimeout=300,
        )
        for msg in resp.get("Messages", []):
            try:
                await handle(msg)
                await asyncio.to_thread(
                    sqs.delete_message, QueueUrl=s.jobs_queue_url, ReceiptHandle=msg["ReceiptHandle"]
                )
            except Exception:
                log.exception("job failed; SQS will redeliver, then DLQ")


if __name__ == "__main__":
    asyncio.run(main())
```

**What happens to in-flight jobs when a region dies?** Messages sitting in that region's SQS are stuck until it recovers. Industry options:

1. **Accept it** for non-critical jobs; they finish when the region recovers.
2. **Re-drive from job state:** a sweeper in the healthy region finds jobs in DynamoDB that are `PENDING/RUNNING` with `region = failed region` and older than N minutes, and re-enqueues them locally. Because jobs are idempotent, double processing is safe.

```python
# app/sweeper.py  (runs in every region; only acts on jobs owned by an unhealthy region)
def requeue_orphans(failed_region: str, older_than_s: int = 600):
    # Query a GSI on (region, status) for stale jobs, then sqs.send_message to the LOCAL queue
    # and conditionally update owner region so only one sweeper claims each job.
    ...
```

## 7.7 Observability: tag everything with the region

```python
# app/middleware.py
from starlette.middleware.base import BaseHTTPMiddleware

from app.config import get_settings

s = get_settings()


class RegionHeaderMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        response.headers["X-Served-By-Region"] = s.app_region
        return response
```

Add `region` to every log line, metric dimension, and trace attribute. During an incident the first question is always "**is it one region or all of them?**"

## 7.8 Database migrations

- Migrations run **once**, against the **writer** (primary region), from CI. Never from app startup in each region.
- They replicate to all regions in about a second, so a bad migration hurts **everywhere at once**. Multi-region does not protect you here.
- Use **expand → migrate → contract**: add the new column (both old and new code work), deploy code to all regions, backfill, then remove the old column in a later release.

---

# Part 8: CI/CD (Build Once, Deploy in Waves)

## 8.1 The industry pattern

```
commit → build + test → push image to ECR (primary) → replicated to all regions
      → deploy STAGING (all regions)
      → deploy PROD wave 1: one region (the smallest / "canary" region)
           → bake 30–60 min, watch alarms; auto-rollback on alarm
      → deploy PROD wave 2: next region
           → bake
      → done
```

Principles used at AWS and most large companies:

- **Never deploy to all regions at once.** Regional isolation is useless if a bad deploy hits every region in the same minute.
- **Build once, promote the same artifact** (same image digest) through every stage.
- **Bake time** with automated alarm checks between waves.
- **Automatic rollback** (ECS circuit breaker + CloudWatch alarm rollback).
- **One-box / canary inside a region** for big changes (CodeDeploy blue/green with canary traffic shifting).

## 8.2 GitHub Actions workflow

```yaml
# .github/workflows/deploy.yml
name: build-and-deploy

on:
  push:
    branches: [main]

permissions:
  id-token: write      # OIDC to AWS, no long-lived keys
  contents: read

env:
  ECR_REPO: summarizer/api
  PRIMARY_REGION: us-east-1

jobs:
  build:
    runs-on: ubuntu-latest
    outputs:
      image_tag: ${{ steps.meta.outputs.tag }}
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }

      - name: Test
        run: |
          pip install -r requirements-dev.txt
          pytest -q

      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::111111111111:role/gha-build
          aws-region: ${{ env.PRIMARY_REGION }}

      - uses: aws-actions/amazon-ecr-login@v2
        id: ecr

      - id: meta
        run: echo "tag=${GITHUB_SHA::12}" >> "$GITHUB_OUTPUT"

      - name: Build and push (arm64)
        run: |
          docker buildx build --platform linux/arm64 \
            -t ${{ steps.ecr.outputs.registry }}/${ECR_REPO}:${{ steps.meta.outputs.tag }} \
            --push .

      - name: Wait for ECR replication to us-west-2
        run: |
          for i in $(seq 1 30); do
            if aws ecr describe-images --region us-west-2 \
                 --repository-name "$ECR_REPO" \
                 --image-ids imageTag=${{ steps.meta.outputs.tag }} >/dev/null 2>&1; then
              echo "replicated"; exit 0
            fi
            sleep 10
          done
          echo "image not replicated in time"; exit 1

  migrate:
    needs: build
    runs-on: ubuntu-latest
    environment: prod-migrations
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::222222222222:role/gha-deploy
          aws-region: us-east-1
      - name: Run Alembic against the writer (one-off ECS task in the primary region)
        run: ./scripts/run-migration-task.sh ${{ needs.build.outputs.image_tag }}

  deploy-prod:
    needs: [build, migrate]
    runs-on: ubuntu-latest
    strategy:
      max-parallel: 1             # waves: one region at a time
      fail-fast: true             # a failure stops later waves
      matrix:
        region: [us-west-2, us-east-1]    # standby/smaller region first = canary wave
    environment: prod-${{ matrix.region }}   # per-region approval / protection rules
    steps:
      - uses: actions/checkout@v4

      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::222222222222:role/gha-deploy
          aws-region: ${{ matrix.region }}

      - name: Render task definition with the region-local image
        id: render
        run: |
          ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
          IMAGE="$ACCOUNT.dkr.ecr.${{ matrix.region }}.amazonaws.com/${ECR_REPO}:${{ needs.build.outputs.image_tag }}"
          aws ecs describe-task-definition --task-definition summarizer-prod-api \
            --query taskDefinition > td.json || true
          echo "image=$IMAGE" >> "$GITHUB_OUTPUT"

      - uses: aws-actions/amazon-ecs-render-task-definition@v1
        id: td
        with:
          task-definition: td.json
          container-name: api
          image: ${{ steps.render.outputs.image }}

      - uses: aws-actions/amazon-ecs-deploy-task-definition@v2
        with:
          task-definition: ${{ steps.td.outputs.task-definition }}
          service: api
          cluster: summarizer-prod-${{ matrix.region == 'us-east-1' && 'use1' || 'usw2' }}
          wait-for-service-stability: true

      - name: Smoke test this region directly
        run: |
          HOST=${{ matrix.region == 'us-east-1' && 'use1' || 'usw2' }}.api.example.com
          curl -fsS "https://$HOST/health/ready"
          ./scripts/smoke.sh "https://$HOST"

      - name: Bake and watch alarms
        run: ./scripts/bake.sh ${{ matrix.region }} 1800   # 30 min; exits non-zero if alarms fire
```

> The family name above is simplified. In practice task definition families are per region (`summarizer-prod-usw2-api`), and many teams let **Terraform** own the task definition and have CI only bump `image_tag` (then `terraform apply` per region per wave). Both are common; pick one owner for the task definition.

## 8.3 The bake script

```bash
#!/usr/bin/env bash
# scripts/bake.sh <region> <seconds>
set -euo pipefail
REGION="$1"; DURATION="$2"; END=$(( $(date +%s) + DURATION ))
ALARMS=("summarizer-prod-api-5xx-rate" "summarizer-prod-api-p99-latency" "summarizer-prod-worker-dlq-depth")

while [ "$(date +%s)" -lt "$END" ]; do
  for a in "${ALARMS[@]}"; do
    STATE=$(aws cloudwatch describe-alarms --region "$REGION" --alarm-names "$a" \
            --query 'MetricAlarms[0].StateValue' --output text)
    if [ "$STATE" = "ALARM" ]; then
      echo "Alarm $a fired in $REGION, failing the wave"
      exit 1
    fi
  done
  sleep 30
done
echo "Bake passed in $REGION"
```

ECS can also roll back on alarms by itself:

```hcl
resource "aws_ecs_service" "api" {
  # ...
  alarms {
    enable      = true
    rollback    = true
    alarm_names = ["summarizer-prod-${var.region_short}-api-5xx-rate"]
  }
}
```

## 8.4 Infrastructure changes follow the same waves

```
terraform plan (all regions) → review → apply staging → apply prod us-west-2 → bake → apply prod us-east-1
```

Never `terraform apply` both prod regions in one run.

---

# Part 9: Traffic Management Options

| Tool | Layer | Failover speed | Notes |
|---|---|---|---|
| **Route 53** (failover / latency / weighted) | DNS | 1–5 min (TTL + health check) | Cheapest, universal, client caching can delay |
| **Route 53 ARC** routing controls | DNS, human-triggered | Same as DNS, but decision is one data-plane call | Industry standard "big red button" |
| **Global Accelerator** | Anycast IP, TCP/UDP | Seconds (no DNS caching) | Two static IPs, traffic dials per region, good for APIs and non-HTTP |
| **CloudFront** | CDN, HTTP | Origin failover per request (GET/HEAD/OPTIONS only) | Great for static/cached content; use with Route 53 for APIs with writes |

## 9.1 Global Accelerator for fast, cache-free failover

```hcl
resource "aws_globalaccelerator_accelerator" "api" {
  name            = "summarizer-prod"
  ip_address_type = "IPV4"
  enabled         = true
}

resource "aws_globalaccelerator_listener" "https" {
  accelerator_arn = aws_globalaccelerator_accelerator.api.id
  protocol        = "TCP"
  port_range {
    from_port = 443
    to_port   = 443
  }
}

resource "aws_globalaccelerator_endpoint_group" "use1" {
  listener_arn            = aws_globalaccelerator_listener.https.id
  endpoint_group_region   = "us-east-1"
  traffic_dial_percentage = 100        # set to 0 to drain the region instantly
  health_check_path       = "/health/ready"
  health_check_protocol   = "HTTPS"
  endpoint_configuration {
    endpoint_id                    = data.terraform_remote_state.app_use1.outputs.alb_arn
    weight                         = 100
    client_ip_preservation_enabled = true
  }
}

resource "aws_globalaccelerator_endpoint_group" "usw2" {
  listener_arn            = aws_globalaccelerator_listener.https.id
  endpoint_group_region   = "us-west-2"
  traffic_dial_percentage = 100
  health_check_path       = "/health/ready"
  health_check_protocol   = "HTTPS"
  endpoint_configuration {
    endpoint_id = data.terraform_remote_state.app_usw2.outputs.alb_arn
    weight      = 100
  }
}
```

Point `api.example.com` at the accelerator. Users connect to the nearest AWS edge and ride the AWS backbone to the closest healthy region.

## 9.2 CloudFront origin failover (read paths)

```hcl
resource "aws_cloudfront_distribution" "web" {
  # ...
  origin_group {
    origin_id = "api-group"
    failover_criteria { status_codes = [500, 502, 503, 504] }
    member { origin_id = "api-use1" }
    member { origin_id = "api-usw2" }
  }
  # origins "api-use1" and "api-usw2" point at use1.api.example.com / usw2.api.example.com
}
```

Origin groups only fail over **GET, HEAD, OPTIONS**. For POSTs, rely on Route 53 / Global Accelerator behind CloudFront.

---

# Part 10: Failover and Failback Runbooks

Write these down, store them **outside** the primary region (a wiki that lives in one region is a bad place for your DR runbook), and practice them quarterly.

## 10.1 Decide: fail over or wait?

```
Is the impact limited to one region?           ── no ──▶ It's probably us (deploy/config/data). Roll back, don't fail over.
        │ yes
Is it one AZ?                                  ── yes ─▶ Multi-AZ handles it. Consider zonal shift (ARC), not regional failover.
        │ no
Is the expected time-to-fix > our RTO?         ── no ──▶ Wait, communicate, keep watching.
        │ yes
Is the standby region healthy and ready?       ── no ──▶ Fix the standby first (or partial failover).
        │ yes
FAIL OVER (incident commander approves)
```

> **Real-world lesson:** most painful incidents come from failing over for the wrong reason (e.g. a bad deploy that is also in the other region) or failing over and back repeatedly ("flapping"). Make failover a **deliberate human decision** with automation doing the steps.

## 10.2 Planned switchover (drills, maintenance) — no data loss

```bash
# 0. Pre-checks
aws cloudwatch get-metric-statistics --region us-west-2 \
  --namespace AWS/RDS --metric-name AuroraGlobalDBReplicationLag \
  --dimensions Name=DBClusterIdentifier,Value=summarizer-prod-usw2 \
  --start-time "$(date -u -v-10M +%FT%TZ)" --end-time "$(date -u +%FT%TZ)" \
  --period 60 --statistics Maximum

# 1. Scale the standby to full capacity BEFORE moving traffic
aws ecs update-service --region us-west-2 --cluster summarizer-prod-usw2 --service api --desired-count 6
aws application-autoscaling register-scalable-target --region us-west-2 \
  --service-namespace ecs --resource-id service/summarizer-prod-usw2/api \
  --scalable-dimension ecs:service:DesiredCount --min-capacity 6 --max-capacity 60

# 2. Switch over the database (Aurora waits for full sync, so no data loss)
aws rds switchover-global-cluster \
  --global-cluster-identifier summarizer-prod-global \
  --target-db-cluster-identifier arn:aws:rds:us-west-2:222222222222:cluster:summarizer-prod-usw2

# 3. Wait until the new primary is writable
aws rds describe-global-clusters --global-cluster-identifier summarizer-prod-global \
  --query 'GlobalClusters[0].GlobalClusterMembers[].{arn:DBClusterArn,writer:IsWriter}'

# 4. Point the writer name at the new primary (if not using the Aurora global writer endpoint)
#    and update PRIMARY_REGION config (SSM parameter / feature flag), then roll tasks.

# 5. Move traffic with ARC routing controls (data plane, uses the cluster endpoints)
aws route53-recovery-cluster update-routing-control-states \
  --region us-west-2 \
  --endpoint-url https://<one-of-the-5-cluster-endpoints> \
  --update-routing-control-state-entries \
    RoutingControlArn=<usw2-control-arn>,RoutingControlState=On \
    RoutingControlArn=<use1-control-arn>,RoutingControlState=Off

# 6. Verify
curl -s https://api.example.com/health/ready     # region should be us-west-2
# watch 5xx, p99, queue depth, DLQ in both regions for 30 minutes
```

## 10.3 Unplanned failover (region is impaired)

```bash
# 1. Declare the incident, assign an incident commander, start comms (status page).

# 2. Drain the bad region from traffic FIRST (data-plane call)
aws route53-recovery-cluster update-routing-control-state \
  --region ap-northeast-1 \
  --endpoint-url https://<a-cluster-endpoint-NOT-in-the-failed-region> \
  --routing-control-arn <use1-control-arn> \
  --routing-control-state Off
#   (the safety rule guarantees usw2 stays ON)

# 3. Promote the secondary database. --allow-data-loss = accept losing the replication lag window (your RPO)
aws rds failover-global-cluster --region us-west-2 \
  --global-cluster-identifier summarizer-prod-global \
  --target-db-cluster-identifier arn:aws:rds:us-west-2:222222222222:cluster:summarizer-prod-usw2 \
  --allow-data-loss

# 4. Repoint the writer name / PRIMARY_REGION (same as switchover step 4).

# 5. Confirm the standby has scaled (if statically stable, it already has capacity).

# 6. Re-drive orphaned jobs from the failed region (sweeper, Part 7.6).

# 7. Record the exact failover time. Writes committed in us-east-1 in the last ~seconds before
#    the outage may be missing; reconcile them after recovery (see failback).
```

> Keep a **copy of these commands with real ARNs** pre-filled in the runbook. During an incident nobody should be looking up ARNs.

## 10.4 Failback (returning to the original region)

Failback is a **planned switchover in reverse**, but with one extra problem: the old primary may contain writes that never replicated.

1. Wait until the old region is fully healthy for a sustained period (hours, not minutes).
2. Aurora: after an unplanned failover, the old primary is typically rebuilt/re-added as a secondary. Check for **lost writes**: AWS can keep a snapshot of the old primary; compare with the new primary and reconcile business-critical rows (payments, orders) manually or with scripts.
3. Let the old region catch up as a secondary (replication lag back to ~0).
4. Run the **planned switchover** (Part 10.2) back to the original region, during low traffic.
5. Restore the standby to warm-standby sizing.
6. Write the post-incident review: what was the real RTO/RPO vs target?

---

# Part 11: Observability for Multi-Region

## 11.1 What to watch

| Signal | Metric | Alarm idea |
|---|---|---|
| Aurora replication lag | `AuroraGlobalDBReplicationLag` (ms) | > 2,000 ms for 5 min |
| Aurora RPO lag | `AuroraGlobalDBRPOLag` | over your RPO target |
| DynamoDB replication | `ReplicationLatency` (per replica region) | > 5 s |
| S3 replication | `ReplicationLatency`, `OperationsPendingReplication`, `OperationsFailedReplication` | failures > 0 |
| ElastiCache global | `GlobalDatastoreReplicationLag` | > 1 s |
| Health checks | Route 53 `HealthCheckStatus` | any region unhealthy |
| Per-region SLO | ALB 5xx rate, p99 latency, per region | burn-rate alarms |
| Queue health | `ApproximateAgeOfOldestMessage`, DLQ depth, per region | backlog growing |
| Standby readiness | standby running task count, quota headroom | below failover capacity |

## 11.2 Synthetic canaries from outside each region

Run **CloudWatch Synthetics canaries** in each region that hit **both** regional hostnames and the global name:

- `us-east-1` canary → `use1.api.example.com`, `usw2.api.example.com`, `api.example.com`
- `us-west-2` canary → same three

If both canaries say `use1` is broken, it's real. If only the `us-east-1` canary says so, the problem may be the canary's own region.

## 11.3 Cross-region dashboards

- Use **CloudWatch cross-account cross-region** dashboards (or Grafana / Datadog) with region as a top-level dimension.
- Host your **observability and alerting outside** the region it monitors, or in both. An alerting system that lives only in `us-east-1` goes silent exactly when `us-east-1` breaks.

## 11.4 Drift detection

Regions slowly drift (someone hotfixes one region by hand). Run a daily job:

```bash
for r in us-east-1 us-west-2; do
  (cd infra/live/prod/$r/app && terraform plan -detailed-exitcode -lock=false) || echo "DRIFT in $r"
done
```

Also compare running image digests across regions; they should match after a wave completes.

---

# Part 12: Testing Resilience

> "**A DR plan you haven't tested is a DR hope.**"

## 12.1 The testing ladder

| Level | What | How often |
|---|---|---|
| 1. Tabletop | Walk through the runbook on a whiteboard | Quarterly |
| 2. Component failover | Aurora switchover in staging; kill a region's ECS service in staging | Monthly |
| 3. Region evacuation in staging | Full failover + failback in staging | Monthly |
| 4. Production game day | Planned switchover in prod during low traffic | Quarterly / twice a year |
| 5. Continuous chaos | Automated fault injection with guardrails | Ongoing |

## 12.2 AWS Fault Injection Service (FIS)

FIS can inject faults like stopping ECS tasks, failing over Aurora, disrupting network connectivity, and pausing replication (scenario library includes AZ and cross-region connectivity scenarios). Always add **stop conditions** tied to alarms.

```hcl
resource "aws_fis_experiment_template" "kill_api_tasks_usw2" {
  description = "Stop 50% of API tasks in us-west-2 and verify autoscaling + no 5xx spike"
  role_arn    = aws_iam_role.fis.arn

  stop_condition {
    source = "aws:cloudwatch:alarm"
    value  = aws_cloudwatch_metric_alarm.api_5xx_usw2.arn
  }

  action {
    name      = "stop-tasks"
    action_id = "aws:ecs:stop-task"
    target {
      key   = "Tasks"
      value = "api-tasks"
    }
  }

  target {
    name           = "api-tasks"
    resource_type  = "aws:ecs:task"
    selection_mode = "PERCENT(50)"
    resource_tag {
      key   = "service"
      value = "summarizer-api"
    }
  }
}
```

## 12.3 Game day checklist

- [ ] Announce the window; have rollback ready.
- [ ] Record start time; measure **actual RTO** (time to healthy traffic in the other region) and **actual RPO** (lag at switch time).
- [ ] Verify customers saw no or minimal errors (synthetic canaries, 5xx graphs).
- [ ] Verify workers, queues, cron jobs, and webhooks all moved (people forget cron jobs!).
- [ ] Verify third-party allowlists include the standby region's NAT IPs (people forget this too).
- [ ] Fail back.
- [ ] Write down every surprise and fix it before the next drill.

---

# Part 13: Cost

## 13.1 What it costs by strategy (rough multipliers vs single region)

| Strategy | Approx. cost |
|---|---|
| Backup & restore | 1.05–1.1x (storage + snapshot copies) |
| Pilot light | 1.2–1.4x (replicated DB + idle infra) |
| Warm standby | 1.4–1.7x |
| Active-active / hot standby | 1.8–2.2x+ |

## 13.2 Where the money goes

| Item | Note |
|---|---|
| **Inter-region data transfer** | Replication traffic (Aurora, S3 CRR, DynamoDB) is billed per GB. Often the surprise line item. |
| **DynamoDB Global Tables** | Replicated writes are charged in every replica region. |
| **Aurora secondary** | Instances in the secondary region + replicated I/O. |
| **NAT gateways** | Per AZ, per region. Use VPC endpoints to cut NAT data charges. |
| **Idle compute** | The warm standby's minimum tasks. |
| **S3 RTC** | Extra per-GB fee for the 15-minute replication SLA. |

## 13.3 Saving money without losing resilience

- Use **Graviton (ARM64)** everywhere (Fargate, RDS): ~20% cheaper.
- Standby compute on **Fargate Spot** for workers (not for the API tier you'll need in a hurry).
- **Different tiers per component:** active-active for the API, pilot light for analytics, backup & restore for internal admin tools.
- Only replicate data you need for DR (S3 replication filters by prefix/tag).
- Don't replicate caches; let them warm.

---

# Part 14: Pitfalls (What Goes Wrong in Real Life)

1. **Hidden dependency on the primary region.** The standby calls a service, secret, bucket, or SSO provider that lives only in `us-east-1`. Find these with a game day that **blocks** the primary region from the standby (FIS network disruption or security-group deny).
2. **Quotas not raised in the standby.** Failover starts, Fargate hits the vCPU quota, scaling stops.
3. **Regions drifted.** Different env vars, a missing IAM permission, an old task definition. Use the same module and drift detection.
4. **Deep health checks wired to routing.** A shared dependency fails → both regions go unhealthy at once.
5. **Failover depends on control-plane calls.** "We'll create the ASG during the outage." Pre-provision instead (static stability).
6. **DNS cached by clients.** Some mobile apps and JVMs cache DNS for a long time. Set sane TTLs, use Global Accelerator for critical APIs.
7. **Cron jobs running in both regions.** After failover, both regions send the daily email. Use a leader lock (DynamoDB conditional write in the primary region) or enable schedulers by region role.
8. **Third-party IP allowlists** only contain the primary region's NAT IPs.
9. **Writer endpoint hardcoded** to `summarizer-prod-use1.cluster-xxx.rds.amazonaws.com`. After failover the app writes to a read-only cluster.
10. **Connection pools pointing at the old primary.** Fix with pre-ping, recycle, and retry on read-only errors.
11. **Bad migration replicated everywhere.** Multi-region is not a backup. Keep PITR and tested restores.
12. **Deploying to all regions at once.** A bad release takes down both. Waves + bake time.
13. **Last-writer-wins surprises** in DynamoDB Global Tables when the same item is updated in two regions. Use home-region ownership for items that matter.
14. **Runbook lives in the failed region** (wiki, CI, secrets vault, VPN). Make sure the people and tools needed for failover work without the primary.
15. **Never failing back.** Teams fail over, then stay half-broken for weeks because failback was never practiced.

---

# Part 15: Interview Prep and Go-Live Checklist

## 15.1 Questions and strong answers

**Q: How would you design a multi-region architecture for this service?**
> Start from RTO/RPO per component. Stateless API in both regions behind Route 53 with health checks and ARC routing controls. Single-writer Aurora Global Database for relational data, DynamoDB Global Tables for job state and idempotency, S3 CRR for blobs, regional SQS queues. Warm standby first; read-local/write-primary active-active later. Deploy in waves, test with game days.

**Q: What's the difference between RTO and RPO, and how do you hit an RPO of ~1 second?**
> RTO is downtime, RPO is data loss. ~1 s RPO needs continuous async replication like Aurora Global Database or DynamoDB Global Tables. RPO = 0 needs synchronous cross-region writes, which adds a cross-region round trip to every write. Most businesses choose seconds of RPO instead.

**Q: Active-active vs active-passive?**
> Active-passive has a single writer, so no conflicts, but failover takes minutes and the passive side may not be truly ready. Active-active gives better latency and instant failover, but you must solve write ownership (home region, single writer, or conflict resolution). I'd make compute active-active and keep writes single-owner.

**Q: What is static stability and why does it matter?**
> The system keeps working during a failure without needing to make changes. The standby already has capacity, data, and config. Failover is a data-plane traffic flip, not a series of control-plane calls that may fail during a regional event.

**Q: How do you avoid a failover making things worse?**
> Human-decided failover with automated steps; check whether the problem is regional or self-inflicted; health checks only on local dependencies; safety rules preventing both regions from being off; no flapping (hysteresis, sustained health before failback).

**Q: How do you handle a user who writes in one region and reads in another?**
> Sticky routing per user or home region; read-your-writes by reading from the writer for a short window after a write; or version tokens. For job status I use DynamoDB with a consistent read in the owning region.

**Q: How do you deploy safely across regions?**
> Build once, promote the same image digest. Staging, then one prod region, bake with alarm checks, then the next. ECS circuit breaker and alarm-based rollback. Migrations run once on the writer using expand/contract.

**Q: What breaks most often in real multi-region failovers?**
> Hidden dependencies on the primary region, quotas, configuration drift, hardcoded endpoints, cron jobs, and stale connection pools. The fix is regular game days that actually block the primary region.

**Q: Why not just make everything active-active?**
> Cost (roughly 2x), complexity in the data layer, conflict handling, and more expensive testing. Many components don't need a seconds-level RTO. Tier your components.

## 15.2 Go-live checklist

**Foundations**
- [ ] RTO/RPO agreed per component with the business
- [ ] Regions chosen; all services/versions available in both
- [ ] Service quotas matched in the standby region
- [ ] Non-overlapping CIDRs; SCP restricting regions
- [ ] Terraform: same modules per region, separate state per region, state bucket replicated

**Data**
- [ ] KMS multi-region keys
- [ ] Aurora Global Database; replication lag alarm
- [ ] DynamoDB Global Tables; PITR on; replication latency alarm
- [ ] S3 CRR (+RTC if needed); replication failure alarm
- [ ] Secrets replicated; app reads from local region
- [ ] Backups/PITR still in place (multi-region ≠ backup)

**Compute and traffic**
- [ ] ECR replication; tasks pull from local registry
- [ ] Regional ACM certs, ALBs, WAF rules
- [ ] Route 53 health checks on `/health/ready` (local deps only)
- [ ] Routing policy chosen (failover / latency / weighted)
- [ ] ARC routing controls + safety rules (or Global Accelerator traffic dials)
- [ ] Standby capacity meets your static-stability target

**Application**
- [ ] Region-aware config; region in logs/metrics/traces
- [ ] Writer and local-reader DB connections; failover-safe pools
- [ ] Read-your-writes strategy
- [ ] Idempotent endpoints and jobs; home-region idempotency checks
- [ ] Regional queues; orphaned-job re-drive
- [ ] Cron/scheduled jobs run in exactly one region

**Delivery and operations**
- [ ] CI builds once and deploys in regional waves with bake time
- [ ] Automatic rollback (circuit breaker + alarms)
- [ ] Migrations run once, expand/contract
- [ ] Failover, switchover, and failback runbooks with real ARNs, stored outside the primary
- [ ] Synthetic canaries from both regions
- [ ] Alerting and dashboards survive a single-region outage
- [ ] Game day done; actual RTO/RPO measured and meeting targets

---

## Appendix: Quick reference commands

```bash
# Aurora global cluster status
aws rds describe-global-clusters --global-cluster-identifier summarizer-prod-global

# Planned switchover (no data loss)
aws rds switchover-global-cluster --global-cluster-identifier summarizer-prod-global \
  --target-db-cluster-identifier <target-cluster-arn>

# Unplanned failover (accepts data loss up to the replication lag)
aws rds failover-global-cluster --global-cluster-identifier summarizer-prod-global \
  --target-db-cluster-identifier <target-cluster-arn> --allow-data-loss

# DynamoDB global table replicas
aws dynamodb describe-table --table-name summarizer-prod-jobs --query 'Table.Replicas'

# ARC: read and flip routing controls (data plane)
aws route53-recovery-cluster get-routing-control-state \
  --routing-control-arn <arn> --endpoint-url <cluster-endpoint> --region <endpoint-region>
aws route53-recovery-cluster update-routing-control-state \
  --routing-control-arn <arn> --routing-control-state Off \
  --endpoint-url <cluster-endpoint> --region <endpoint-region>

# Global Accelerator: drain a region instantly
aws globalaccelerator update-endpoint-group --region us-west-2 \
  --endpoint-group-arn <arn> --traffic-dial-percentage 0

# Which region served me?
curl -sI https://api.example.com/health/live | grep -i x-served-by-region
```
