# Deploying AI Apps on Kubernetes (production)

## Why Kubernetes for AI apps

- Many **cooperating workloads**: API pods, ingestion jobs, online-eval CronJobs, the improvement
  pipeline (Argo Workflows), vector DB, maybe self-hosted models on GPUs — one platform runs them all.
- **Autoscaling**, self-healing, rolling/canary releases, resource isolation.
- **GitOps**: the cluster's desired state lives in git; every change is reviewed and revertible.
- Same manifests on EKS (AWS), AKS (Azure), GKE (GCP), or on-prem.

## The production picture

```
                         ┌──────────────────────────── Kubernetes cluster (EKS) ───────────────────────────────┐
  users ─► DNS ─► ALB/   │  namespace: ai-apps                                                                 │
          NGINX Ingress ─┼─► Service ─► Rollout (canary) ─► pods: support-copilot (FastAPI + LangGraph)         │
          (TLS, WAF)     │                  │  HPA scales 3..20 pods        │ /metrics → Prometheus            │
                         │                  │  PDB keeps ≥2 up              │ traces  → OTel → Langfuse/LangSmith│
                         │                  ▼                               │                                  │
                         │   ConfigMap (release config)   Secret (from AWS Secrets Manager via External Secrets)│
                         │   ServiceAccount ──IRSA──► IAM role (Bedrock, S3) — no static AWS keys              │
                         │                                                                                     │
                         │  CronJobs: online-monitor (hourly), kb-reindex (nightly)                            │
                         │  Argo Workflows: flywheel (curate → train → eval gate → publish)                    │
                         │  Argo CD: syncs this folder from git   Argo Rollouts: canary + auto-rollback        │
                         │  namespace: data   → Qdrant (StatefulSet via Helm) or managed Qdrant Cloud          │
                         │  namespace: models → vLLM on GPU nodes (optional, self-hosted LLM)                  │
                         └─────────────────────────────────────────────────────────────────────────────────────┘
        outside: RDS Postgres (checkpoints + pgvector), LLM providers (OpenAI / Bedrock), S3 (datasets, docs)
```

## Kubernetes objects — what each one is for

| Object | Purpose in an AI app | File |
|---|---|---|
| **Deployment / Rollout** | runs N identical API pods; Rollout adds canary steps + automated analysis | `k8s/base/rollout.yaml` |
| **Service** | stable virtual IP/DNS for pods; *stable* and *canary* services split traffic | `k8s/base/service.yaml` |
| **Ingress** | HTTPS entry, host/path routing, TLS certs; also used for canary traffic weights | `k8s/base/ingress.yaml` |
| **ConfigMap** | non-secret config: model id, prompt version, k, thresholds (from release manifest) | `k8s/base/configmap.yaml` |
| **Secret / ExternalSecret** | API keys pulled from AWS Secrets Manager / Vault — never in git | `k8s/base/externalsecret.yaml` |
| **ServiceAccount + IRSA** | pod identity → AWS IAM role for Bedrock/S3 without access keys | `k8s/base/serviceaccount.yaml` |
| **HPA** | scale on CPU or custom metrics (in-flight requests); KEDA for queue-based scaling | `k8s/base/hpa.yaml` |
| **PodDisruptionBudget** | keep minimum pods during node upgrades/drains | `k8s/base/pdb.yaml` |
| **NetworkPolicy** | pods may only talk to what they need (egress to LLM APIs, DB, vector DB) | `k8s/base/networkpolicy.yaml` |
| **ServiceMonitor** | tells Prometheus to scrape `/metrics` | `k8s/base/servicemonitor.yaml` |
| **AnalysisTemplate** | canary health checks: error rate, latency, guardrail spikes, smoke-eval Job | `k8s/base/analysis-templates.yaml` |
| **CronJob** | scheduled online evals and KB re-indexing | `k8s/cronjobs.yaml` |
| **Workflow (Argo)** | the improvement pipeline DAG | `k8s/argo-workflow-flywheel.yaml` |
| **Application (Argo CD)** | GitOps: keep the cluster in sync with the overlay in git | `k8s/argocd-application.yaml` |

## AI-specific Kubernetes considerations

1. **Long requests.** LLM calls take 2–30 s; streaming responses can last a minute.
   Set ingress/proxy timeouts (≥ 120 s), `terminationGracePeriodSeconds` ≥ longest request, and a
   `preStop` sleep so in-flight requests finish during rollouts.
2. **I/O-bound, not CPU-bound.** Pods mostly wait on the LLM API. CPU-based HPA under-scales;
   prefer **concurrent in-flight requests per pod** (custom metric via Prometheus Adapter, or KEDA).
3. **Shared state.** Multiple replicas ⇒ the LangGraph checkpointer must be **Postgres/Redis**,
   not SQLite or memory (`CHECKPOINT_PG_URL` in the ConfigMap).
4. **Rate limits are global.** 20 pods × retries can hammer the provider. Budget concurrency per pod,
   and use a shared limiter (Redis) or an **LLM gateway** (LiteLLM proxy, Kong AI Gateway, Portkey)
   as its own Deployment for routing, fallbacks, keys and cost tracking.
5. **Canary must check quality, not just errors.** A release can return HTTP 200 with worse answers.
   The Rollout runs a **smoke-eval Job** (DeepEval on a small golden set against the canary Service)
   in addition to error/latency queries → auto-rollback if any fails.
6. **Egress control.** NetworkPolicy + egress gateway allow-list LLM endpoints — limits data
   exfiltration if a prompt injection turns a tool into a weapon.
7. **Self-hosted models (optional).** vLLM / TGI / NVIDIA NIM on GPU node pools
   (`nvidia.com/gpu` resource, taints/tolerations, model weights from S3 cached on local NVMe).
   Scale on queue depth / tokens-per-second; GPU nodes are expensive — scale to zero when idle.
8. **Ingestion is a separate workload.** Jobs/CronJobs with their own resources and identity
   (write access to the vector DB) — the API pods get read-only credentials.

## Environments with Kustomize overlays

```
k8s/base/                 everything common
k8s/overlays/staging/     1 replica min, staging hostnames, staging secrets, cheaper model
k8s/overlays/prod/        3+ replicas, prod hostnames, prod secrets, pinned image digest + release config
```
`kustomize build k8s/overlays/prod` renders the final YAML. The publish step of the LLMOps pipeline
edits **only** `overlays/prod` (image digest + release config) and commits; Argo CD applies it.

## Release flow end-to-end

```
 git push (app code) ─► CI: unit tests → offline eval gate → build image → push to ECR (digest)
                         └─► commit new digest to overlays/staging ─► Argo CD sync ─► staging smoke evals
 flywheel / human ─► 05_publish_release ─► commit to overlays/prod (digest + release.json)
                         └─► Argo CD sync ─► Argo Rollouts canary:
                                10% traffic → analysis (errors, p95, guardrail spike, smoke-eval Job)
                                50% traffic → analysis
                               100% → post-promotion hook → MLflow alias "champion"
                             any analysis fails ─► automatic rollback to stable + Slack alert
```

## Useful commands

```bash
kustomize build 11_kubernetes/k8s/overlays/prod | kubectl diff -f -     # what would change
kubectl argo rollouts get rollout support-copilot -n ai-apps --watch    # watch a canary
kubectl argo rollouts abort support-copilot -n ai-apps                  # manual rollback
kubectl argo rollouts promote support-copilot -n ai-apps                # skip a pause step
argo submit -n ai-pipelines 11_kubernetes/k8s/argo-workflow-flywheel.yaml -p trigger=manual
```
