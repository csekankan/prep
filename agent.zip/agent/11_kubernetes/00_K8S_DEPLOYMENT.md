# Deploying AI Apps on Kubernetes (production)

**Kubernetes** (often written **k8s**) is a system that runs your containers across a group of machines (a
**cluster**). You describe what you want, for example "keep 3 copies of the support-copilot container
running, reachable at this address", in YAML files called **manifests**. Kubernetes continuously works to
make reality match: it restarts crashed containers, moves them off failed machines, and adds copies when
you ask for more.

Key vocabulary used throughout this page:
- **Pod**: the smallest unit Kubernetes runs, usually one container of your app. "3 replicas" means 3 pods.
- **Node**: one machine (a VM) in the cluster. Pods run on nodes.
- **Namespace**: a named folder inside the cluster that groups related resources (`ai-apps`, `data`,
  `models`), with its own permissions and quotas.

## Why Kubernetes for AI apps

- **Many cooperating workloads on one platform.** A production AI app isn't one program. It's API pods
  serving users, **ingestion jobs** loading documents into the vector database, scheduled
  **online-evaluation jobs** scoring quality, the improvement pipeline (Argo Workflows, see
  `10_llmops_pipeline/`), the vector database itself, and maybe self-hosted models on GPU machines.
  Kubernetes runs all of them with the same tools, logs, and permissions model.
- **Autoscaling, self-healing, safe releases, resource isolation.** It adds pods when traffic rises
  (**autoscaling**), replaces crashed pods automatically (**self-healing**), replaces old pods with new ones
  gradually (**rolling** release) or tests a new version on a slice of traffic first (**canary** release),
  and caps the CPU and memory each workload may use so a runaway job can't starve the API.
- **GitOps.** The cluster's desired state lives in a git repository. Every change is a reviewed commit, and
  undoing a change is a `git revert`. A tool (Argo CD) keeps the cluster in sync with git.
- **Portability.** The same manifests run on **EKS** (AWS), **AKS** (Azure), **GKE** (Google Cloud), or
  your own on-premises servers.

## The production picture

```
                         ┌──────────────────────────── Kubernetes cluster (EKS) ───────────────────────────────┐
  users ─► DNS ─► ALB/   │  namespace: ai-apps                                                                 │
          NGINX Ingress ─┼─► Service ─► Rollout (canary) ─► pods: support-copilot (FastAPI + LangGraph)         │
          (TLS, WAF)     │                  │  HPA scales 3..20 pods        │ /metrics → Prometheus            │
                         │                  │  PDB keeps ≥2 up              │ traces  → OTel → Langfuse/LangSmith│
                         │                  ▼                               │                                  │
                         │   ConfigMap (release config)   Secret (from AWS Secrets Manager via External Secrets)│
                         │   ServiceAccount ──IRSA──► IAM role (Bedrock, S3) — no static AWS keys              │
                         │                                                                                     │
                         │  CronJobs: online-monitor (hourly), kb-reindex (nightly)                            │
                         │  Argo Workflows: flywheel (curate → train → eval gate → publish)                    │
                         │  Argo CD: syncs this folder from git   Argo Rollouts: canary + auto-rollback        │
                         │  namespace: data   → Qdrant (StatefulSet via Helm) or managed Qdrant Cloud          │
                         │  namespace: models → vLLM on GPU nodes (optional, self-hosted LLM)                  │
                         └─────────────────────────────────────────────────────────────────────────────────────┘
        outside: RDS Postgres (checkpoints + pgvector), LLM providers (OpenAI / Bedrock), S3 (datasets, docs)
```

**How to read it:** follow a user request from the left. It's resolved by **DNS**, enters through a load
balancer, and is routed to the app's pods, which are managed by a canary-capable Rollout. Inside the box,
everything the app needs (configuration, secrets, AWS permissions, metrics, traces) is attached to those
pods. The lower half of the box shows the background workloads that share the cluster. The line under the
box lists the managed services outside the cluster that the app depends on.

**Terms in this diagram:**
- **ALB / NGINX Ingress (TLS, WAF)**: the front door. An **ALB** is AWS's Application Load Balancer, and
  **NGINX Ingress** is a popular in-cluster alternative. It terminates **TLS** (decrypts HTTPS traffic) and
  can apply a **WAF** (web application firewall, which blocks common attacks such as SQL injection and
  floods of bot traffic).
- **FastAPI + LangGraph**: the app itself. **FastAPI** is a Python web framework, and **LangGraph** runs the
  agent logic.
- **HPA scales 3..20 pods**: the **Horizontal Pod Autoscaler** keeps between 3 and 20 copies, based on load.
- **PDB keeps ≥2 up**: a **PodDisruptionBudget** stops planned maintenance (such as node upgrades) from taking
  down more than a set number of pods at once, so at least 2 always keep serving.
- **OTel**: **OpenTelemetry**, the standard format for traces. Traces flow to Langfuse or LangSmith.
- **External Secrets**: an operator that copies secrets from AWS Secrets Manager into Kubernetes Secrets, so
  they never sit in git.
- **IRSA**: **IAM Roles for Service Accounts**. Pods get AWS permissions through an IAM role, with no
  long-lived AWS access keys stored anywhere (explained in the table below).
- **Qdrant (StatefulSet via Helm)**: the vector database. A **StatefulSet** is the Kubernetes object for
  workloads that need stable identities and their own persistent disks (databases). **Helm** is a package
  manager that installs complex software like this from a "chart".
- **vLLM on GPU nodes**: **vLLM** is a high-performance server for running open-weight LLMs yourself, on
  machines with GPUs.
- **RDS Postgres**: AWS's managed Postgres, used here for agent checkpoints (saved agent state) and pgvector
  (vector search inside Postgres).

## Kubernetes objects: what each one is for

| Object | Purpose in an AI app | File |
|---|---|---|
| **Deployment / Rollout** | runs N identical API pods; Rollout adds canary steps and automated analysis | `k8s/base/rollout.yaml` |
| **Service** | stable virtual IP and DNS name for pods; *stable* and *canary* services split traffic | `k8s/base/service.yaml` |
| **Ingress** | HTTPS entry, host/path routing, TLS certificates; also sets canary traffic weights | `k8s/base/ingress.yaml` |
| **ConfigMap** | non-secret config: model id, prompt version, k, thresholds (from the release manifest) | `k8s/base/configmap.yaml` |
| **Secret / ExternalSecret** | API keys pulled from AWS Secrets Manager / Vault, never in git | `k8s/base/externalsecret.yaml` |
| **ServiceAccount + IRSA** | pod identity mapped to an AWS IAM role for Bedrock/S3, without access keys | `k8s/base/serviceaccount.yaml` |
| **HPA** | scales on CPU or custom metrics (in-flight requests); KEDA for queue-based scaling | `k8s/base/hpa.yaml` |
| **PodDisruptionBudget** | keeps a minimum number of pods during node upgrades and drains | `k8s/base/pdb.yaml` |
| **NetworkPolicy** | pods may only talk to what they need (egress to LLM APIs, DB, vector DB) | `k8s/base/networkpolicy.yaml` |
| **ServiceMonitor** | tells Prometheus to scrape `/metrics` | `k8s/base/servicemonitor.yaml` |
| **AnalysisTemplate** | canary health checks: error rate, latency, guardrail spikes, smoke-eval Job | `k8s/base/analysis-templates.yaml` |
| **CronJob** | scheduled online evals and KB re-indexing | `k8s/cronjobs.yaml` |
| **Workflow (Argo)** | the improvement pipeline DAG | `k8s/argo-workflow-flywheel.yaml` |
| **Application (Argo CD)** | GitOps: keeps the cluster in sync with the overlay in git | `k8s/argocd-application.yaml` |

More detail on the objects that confuse newcomers most:

- **Deployment vs Rollout.** A **Deployment** is the standard way to run N identical pods and replace them
  gradually on updates. A **Rollout** comes from the **Argo Rollouts** add-on. It does the same, but can
  send, say, 10% of traffic to the new version, pause, run health checks, and only then continue.
- **Service.** Pods come and go, and their IP addresses change. A **Service** gives a group of pods one
  stable name (for example `support-copilot.ai-apps.svc`) and load-balances across them. For canaries there
  are two Services, one pointing at the stable pods and one at the canary pods, so traffic can be split
  between them.
- **ConfigMap vs Secret.** Both inject settings into pods as environment variables or files. Use a
  **ConfigMap** for non-sensitive values (`MODEL_ID=gpt-4o-mini`, `RETRIEVAL_K=6`) and a **Secret** for
  sensitive ones. An **ExternalSecret** syncs a Secret automatically from a real secret manager.
- **ServiceAccount and IRSA.** A **ServiceAccount** is a pod's identity inside Kubernetes. IRSA links that
  identity to an AWS IAM role. AWS then hands the pod short-lived credentials that rotate automatically, so
  there's no `AWS_SECRET_ACCESS_KEY` that could leak.
- **HPA and KEDA.** The HPA adds or removes pods based on a metric. **KEDA** (Kubernetes Event-Driven
  Autoscaling) extends this to external signals, for example "1 worker pod per 50 messages waiting in the
  queue", and can scale all the way down to zero.
- **Drain.** To upgrade or remove a node, Kubernetes **drains** it: it evicts the pods there so they restart
  elsewhere. The PDB limits how many are evicted at the same time.
- **NetworkPolicy.** A firewall rule between pods. *Egress* means outgoing traffic. *Example:* the API pod may
  call the LLM provider, Postgres, and Qdrant, and nothing else.
- **ServiceMonitor.** Tells Prometheus to collect ("scrape") the metrics at the pods' `/metrics` URL.
- **AnalysisTemplate.** Defines the checks a canary must pass, for example "error rate under 2%, p95 latency
  under 6 s, and the smoke-eval job passes".
- **DAG.** A **directed acyclic graph**: a set of steps with dependencies and no cycles. That's the shape of
  a pipeline such as curate, then train, then evaluate.

## AI-specific Kubernetes considerations

1. **Long requests.** LLM calls take 2–30 seconds, and a streamed response can last a minute. Default
   timeouts in load balancers are often 30–60 seconds, which would cut answers off mid-stream. So:
   - set ingress and proxy timeouts to at least 120 s;
   - set `terminationGracePeriodSeconds` (how long Kubernetes waits after asking a pod to stop before killing
     it) to longer than your longest request;
   - add a `preStop` hook that sleeps a few seconds, so the load balancer stops sending new traffic before
     the pod starts shutting down.

   *Example:* without these, every deploy cuts off the dozens of users who are mid-answer at that moment.
2. **I/O-bound, not CPU-bound.** The pods spend most of their time *waiting* for the LLM API, not computing.
   A pod handling 50 concurrent conversations may show only 10% CPU, so a CPU-based HPA never scales up,
   even while requests queue. Scale on **concurrent in-flight requests per pod** instead, exposed as a
   custom metric through the **Prometheus Adapter** (which makes Prometheus metrics available to the HPA),
   or with KEDA.
3. **Shared state.** With several replicas, consecutive messages of one conversation can land on different
   pods. The LangGraph **checkpointer** (which saves conversation and agent state) must therefore use a
   shared database such as **Postgres or Redis**, not SQLite or memory, which only one pod could see. It's
   configured via `CHECKPOINT_PG_URL` in the ConfigMap.
4. **Rate limits are global.** The provider's limit applies to your whole account, not per pod. With 20 pods
   all retrying at once, you can hammer the provider and make things worse. Limit concurrency per pod, and
   either share a rate limiter through Redis or route all calls through an **LLM gateway**, a separate
   service in front of the providers that handles routing, fallbacks, API keys, and cost tracking in one
   place. Examples: **LiteLLM proxy**, **Kong AI Gateway**, **Portkey**.
5. **A canary must check quality, not just errors.** A new release can return HTTP 200 (success) on every
   request while giving *worse answers*. So the Rollout also runs a **smoke-eval Job**: DeepEval on a small
   set of golden test questions, sent to the canary Service. If error rate, latency, or the smoke eval fails,
   the rollout rolls back automatically.
6. **Egress control.** A NetworkPolicy plus an **egress gateway** (a single controlled exit point for
   outgoing traffic) allow-lists the LLM endpoints and nothing else. If a prompt injection tricks an agent's
   tool into sending data to `evil.com`, the network simply refuses the connection.
7. **Self-hosted models (optional).** To run open models yourself, use **vLLM**, **TGI** (Hugging Face Text
   Generation Inference), or **NVIDIA NIM** on a pool of GPU nodes:
   - pods request GPUs with the `nvidia.com/gpu` resource;
   - **taints and tolerations** keep ordinary pods off the expensive GPU nodes (a taint repels pods, and only
     pods with a matching toleration may land there);
   - model weights are downloaded from S3 and cached on fast local **NVMe** disks, so restarts don't
     re-download 100 GB.

   Scale on queue depth or tokens per second rather than CPU, and scale GPU nodes to zero when idle. A single
   GPU node can cost several dollars an hour.
8. **Ingestion is a separate workload.** Document ingestion runs as **Jobs/CronJobs** with their own
   resources and their own identity, which has *write* access to the vector database. The API pods get
   *read-only* credentials, so a compromised API pod can't corrupt or delete the knowledge base.

## Environments with Kustomize overlays

**Kustomize** builds environment-specific YAML from a shared base plus small per-environment patches, called
**overlays**, without copying files.

```
k8s/base/                 everything common
k8s/overlays/staging/     1 replica min, staging hostnames, staging secrets, cheaper model
k8s/overlays/prod/        3+ replicas, prod hostnames, prod secrets, pinned image digest + release config
```

`kustomize build k8s/overlays/prod` renders the final YAML for production. The publish step of the LLMOps
pipeline edits **only** `overlays/prod` (the image digest and the release config) and commits it, and
Argo CD applies it. An **image digest** is the exact fingerprint of a container image (`sha256:...`). Unlike
a tag such as `v1.8`, it can never be moved to point at different code.

## Release flow end to end

```
 git push (app code) ─► CI: unit tests → offline eval gate → build image → push to ECR (digest)
                         └─► commit new digest to overlays/staging ─► Argo CD sync ─► staging smoke evals
 flywheel / human ─► 05_publish_release ─► commit to overlays/prod (digest + release.json)
                         └─► Argo CD sync ─► Argo Rollouts canary:
                                10% traffic → analysis (errors, p95, guardrail spike, smoke-eval Job)
                                50% traffic → analysis
                               100% → post-promotion hook → MLflow alias "champion"
                             any analysis fails ─► automatic rollback to stable + Slack alert
```

**How to read it:** there are two entry points.
- **A code change** (top line). **CI** (continuous integration) runs unit tests and the offline evaluation
  gate, builds the container image, and pushes it to **ECR** (AWS's container registry). Then it updates the
  staging overlay, Argo CD deploys to staging, and smoke evals run there.
- **A release** (from the improvement flywheel, or a person running `05_publish_release`). It commits to the
  production overlay. Argo CD syncs, and Argo Rollouts starts the canary: 10% of traffic, then checks, then
  50%, then checks, then 100%. After full promotion, a **post-promotion hook** (a step that runs after
  success) moves the MLflow registry alias `champion` to this release. If any check fails along the way,
  traffic returns to the stable version and Slack is notified.

## Useful commands

```bash
kustomize build 11_kubernetes/k8s/overlays/prod | kubectl diff -f -     # what would change
kubectl argo rollouts get rollout support-copilot -n ai-apps --watch    # watch a canary
kubectl argo rollouts abort support-copilot -n ai-apps                  # manual rollback
kubectl argo rollouts promote support-copilot -n ai-apps                # skip a pause step
argo submit -n ai-pipelines 11_kubernetes/k8s/argo-workflow-flywheel.yaml -p trigger=manual
```

- The first command shows exactly what would change in production *before* you apply it, like a dry run.
- `get rollout ... --watch` shows the canary's live progress (current traffic split, analysis results).
- `abort` stops a canary and sends all traffic back to the stable version.
- `promote` skips the current pause and moves to the next step (use it when you've verified things by hand).
- `argo submit` starts the improvement pipeline manually.
