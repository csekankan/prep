"""
04 — SELF-REFLECTION LOOP (generate → critique → revise)
=========================================================

CONCEPT DEEP DIVE
-----------------
Not every loop is a tool loop. A REFLECTION loop improves quality by having the model
grade its own (or another model's) output against explicit criteria, then revise.

    generate ──► critique ──► (good enough OR max rounds?) ──yes──► END
        ▲                              │ no
        └────────── revise ◄───────────┘

When it helps: writing, code generation (with tests as the critic!), structured reports.
When it doesn't: factual questions — a model can't reliably critique facts it doesn't know.
  The best critics are EXTERNAL signals: unit tests, linters, schema validators, retrieval
  checks. "LLM critiquing LLM" is the weakest form; ground it whenever you can.

Design details that matter:
- The critic returns STRUCTURED feedback (score + concrete issues), not prose, so the
  router can decide deterministically.
- Always bound rounds (2–3). Quality plateaus fast; cost grows linearly.
- Use a separate, stricter system prompt for the critic. Same prompt = rubber-stamping.
"""

from typing import TypedDict

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel, Field

load_dotenv()
MAX_ROUNDS = 3
PASS_SCORE = 8

writer = init_chat_model("openai:gpt-4o-mini", temperature=0.7)
critic_llm = init_chat_model("openai:gpt-4o", temperature=0)  # stronger model as judge


class Critique(BaseModel):
    score: int = Field(ge=1, le=10, description="Overall quality vs the rubric.")
    issues: list[str] = Field(description="Specific, actionable problems. Empty if none.")


critic = critic_llm.with_structured_output(Critique)


class State(TypedDict):
    task: str
    draft: str
    critique: Critique | None
    rounds: int


def generate(state: State) -> dict:
    feedback = ""
    if state.get("critique"):
        feedback = "\nFix these issues from the reviewer:\n- " + "\n- ".join(state["critique"].issues)
    draft = writer.invoke(f"Task: {state['task']}{feedback}\nPrevious draft:\n{state.get('draft', '')}")
    return {"draft": draft.content, "rounds": state.get("rounds", 0) + 1}


def review(state: State) -> dict:
    rubric = "Rubric: accurate, under 120 words, has a concrete example, no jargon without definition."
    return {"critique": critic.invoke(f"{rubric}\n\nTask: {state['task']}\n\nDraft:\n{state['draft']}")}


def should_continue(state: State) -> str:
    if state["critique"].score >= PASS_SCORE or state["rounds"] >= MAX_ROUNDS:
        return END
    return "generate"


builder = StateGraph(State)
builder.add_node("generate", generate)
builder.add_node("review", review)
builder.add_edge(START, "generate")
builder.add_edge("generate", "review")
builder.add_conditional_edges("review", should_continue, ["generate", END])
graph = builder.compile()

if __name__ == "__main__":
    final = graph.invoke({"task": "Explain RAG to a product manager.", "rounds": 0, "critique": None})
    print(final["draft"], "\nscore:", final["critique"].score, "rounds:", final["rounds"])
