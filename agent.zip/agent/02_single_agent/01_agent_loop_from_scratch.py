"""
01 — THE AGENT LOOP FROM SCRATCH (no frameworks)
=================================================

CONCEPT DEEP DIVE: WHAT IS AN AGENT?
------------------------------------
    agent = LLM + tools + a loop + a stopping condition (+ memory)

The canonical pattern is ReAct (Reason + Act, Yao et al. 2022):

        ┌──────────────────────────────────────────────┐
        │                                              │
        ▼                                              │
   [ THINK ]  model reads history, decides next step   │
        │                                              │
        ├── wants a tool? ──► [ ACT ] run tool ──► [ OBSERVE ] append result
        │
        └── no tool call ──► FINAL ANSWER (loop ends)

Modern models do ReAct natively through tool calling — you no longer parse "Thought:/Action:"
text with regexes. The "thought" is implicit (or in a reasoning trace).

WHY BUILD IT BY HAND FIRST?
Frameworks hide this ~30-line loop. Once you see it, LangChain/LangGraph stop being magic
and you'll know exactly where to add guardrails, budgets, logging, and human approval.

FAILURE MODES OF AGENT LOOPS (and the mitigation in this file)
- Infinite loops / repeating the same call    → MAX_ITERATIONS + duplicate-call detection
- Runaway cost                                → token budget check
- Tool crashes kill the run                   → catch exceptions, return error as observation
- Context window overflow on long runs        → truncate long tool outputs
- Model "gives up" silently                   → explicit final-answer instructions in system prompt
"""

import json

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.tools import tool

load_dotenv()

MAX_ITERATIONS = 8          # Hard cap on think→act cycles. Most tasks need 1–4.
MAX_TOTAL_TOKENS = 20_000   # Budget guard. In prod, budget in dollars per request/user.
MAX_TOOL_OUTPUT_CHARS = 2_000


@tool
def search_web(query: str) -> str:
    """Search the web for current facts. Returns short snippets."""
    # Stubbed. In real life: Tavily, Brave, SerpAPI, Exa...
    return f"[snippet] Results for '{query}': LangGraph 1.0 was released in 2025."


@tool
def word_count(text: str) -> int:
    """Count words in a piece of text."""
    return len(text.split())


TOOLS = {t.name: t for t in [search_web, word_count]}

SYSTEM_PROMPT = """You are a research assistant.
- Use tools when you need facts you don't know or need to compute something.
- Do not call the same tool with the same arguments twice.
- When you have enough information, reply with the final answer and no tool calls.
- If the task is impossible with your tools, say so plainly."""


def run_agent(task: str) -> str:
    llm = init_chat_model("openai:gpt-4o-mini", temperature=0).bind_tools(list(TOOLS.values()))
    messages = [SystemMessage(SYSTEM_PROMPT), HumanMessage(task)]
    seen_calls: set[str] = set()
    tokens_used = 0

    for step in range(1, MAX_ITERATIONS + 1):
        # ---------------- THINK ----------------
        ai: AIMessage = llm.invoke(messages)
        messages.append(ai)
        tokens_used += (ai.usage_metadata or {}).get("total_tokens", 0)
        print(f"[step {step}] tool_calls={[c['name'] for c in ai.tool_calls]} tokens={tokens_used}")

        # ---------------- STOP CONDITION ----------------
        # No tool calls means the model believes it's done. This is the "natural" exit.
        if not ai.tool_calls:
            return ai.content

        if tokens_used > MAX_TOTAL_TOKENS:
            return "Stopped: token budget exceeded. Partial progress: " + str(ai.content)

        # ---------------- ACT + OBSERVE ----------------
        for call in ai.tool_calls:
            signature = f"{call['name']}:{json.dumps(call['args'], sort_keys=True)}"
            if signature in seen_calls:
                # Feed the problem back as an observation rather than crashing —
                # the model usually corrects itself on the next THINK step.
                observation = "You already called this with the same args. Use the earlier result."
            elif call["name"] not in TOOLS:
                observation = f"Error: unknown tool {call['name']}. Available: {list(TOOLS)}"
            else:
                seen_calls.add(signature)
                try:
                    observation = str(TOOLS[call["name"]].invoke(call["args"]))
                except Exception as exc:  # noqa: BLE001 — tool errors become observations
                    observation = f"Tool error: {exc}"
            messages.append(
                ToolMessage(content=observation[:MAX_TOOL_OUTPUT_CHARS], tool_call_id=call["id"])
            )

    # Hitting the cap is a signal worth alerting on in production — it usually means a bad
    # prompt, a confusing tool, or a task the agent can't do.
    return "Stopped: reached max iterations without a final answer."


if __name__ == "__main__":
    print(run_agent("When was LangGraph 1.0 released? Then count the words in your answer."))
