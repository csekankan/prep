"""
03 — THE AGENT LOOP AS AN EXPLICIT LANGGRAPH
=============================================

CONCEPT DEEP DIVE: LANGGRAPH CORE PRIMITIVES
--------------------------------------------
1. STATE — a typed dict shared by all nodes. It's the agent's working memory for a run.
   Each key can have a REDUCER that says how updates merge. `add_messages` APPENDS new
   messages (and updates by id) instead of overwriting the list.

2. NODES — plain functions: `def node(state) -> partial_state_update`. A node returns ONLY
   the keys it changes. Nodes can be LLM calls, tool executors, or plain Python.

3. EDGES — wiring.
     - normal edge:      A → B always
     - conditional edge: a router function inspects state and returns the next node name.
   CYCLES are allowed — that's what makes loops (agents) possible, and what differentiates
   LangGraph from DAG-only pipeline tools.

4. COMPILE — turns the builder into a runnable graph (same .invoke/.stream API as LCEL).
   You attach a checkpointer here for persistence, and interrupts for human-in-the-loop.

5. SUPER-STEPS & RECURSION LIMIT — each node execution is a step. `recursion_limit` in the
   config (default 25) is the built-in infinite-loop guard. Hitting it raises
   GraphRecursionError — catch it and return a graceful message.

The graph we build:

        START
          │
          ▼
       ┌──────┐   has tool calls   ┌───────┐
       │agent │ ─────────────────► │ tools │
       └──────┘ ◄───────────────── └───────┘
          │ no tool calls
          ▼
         END

We also add a custom state field (`steps`) to show that state is more than messages —
you can track budgets, retrieved docs, plans, flags, anything.
"""

from typing import Annotated, TypedDict

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_core.messages import AnyMessage, SystemMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.errors import GraphRecursionError
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

load_dotenv()

MAX_AGENT_STEPS = 6


@tool
def search_kb(query: str) -> str:
    """Search the internal knowledge base for policy information."""
    return "Refund policy: full refund within 30 days of delivery with receipt."


tools = [search_kb]
llm = init_chat_model("openai:gpt-4o-mini", temperature=0).bind_tools(tools)


class AgentState(TypedDict):
    # Annotated[type, reducer] — the reducer controls merge semantics.
    messages: Annotated[list[AnyMessage], add_messages]
    # No reducer → last write wins.
    steps: int


def agent_node(state: AgentState) -> dict:
    """THINK: call the model with the full message history."""
    system = SystemMessage("You answer policy questions. Use search_kb before answering.")
    response = llm.invoke([system, *state["messages"]])
    # Return only what changed. add_messages appends `response` to the list.
    return {"messages": [response], "steps": state.get("steps", 0) + 1}


def route_after_agent(state: AgentState) -> str:
    """ROUTER: decides the next node. This is the loop's control logic, in plain Python —
    the big advantage of LangGraph: control flow is code you can test, not prompt magic."""
    last = state["messages"][-1]
    if state["steps"] >= MAX_AGENT_STEPS:
        return END  # custom budget guard on top of recursion_limit
    if getattr(last, "tool_calls", None):
        return "tools"
    return END


builder = StateGraph(AgentState)
builder.add_node("agent", agent_node)
# ToolNode is a prebuilt node that executes all tool_calls in the last AIMessage (in
# parallel), catches errors, and appends ToolMessages. Same as our hand-written ACT step.
builder.add_node("tools", ToolNode(tools))

builder.add_edge(START, "agent")
builder.add_conditional_edges("agent", route_after_agent, ["tools", END])
builder.add_edge("tools", "agent")  # ← THE LOOP: after acting, think again

graph = builder.compile(checkpointer=InMemorySaver())


if __name__ == "__main__":
    config = {"configurable": {"thread_id": "t1"}, "recursion_limit": 15}
    try:
        out = graph.invoke(
            {"messages": [("user", "Can I return shoes I got 2 weeks ago?")], "steps": 0}, config
        )
        print(out["messages"][-1].content)
    except GraphRecursionError:
        print("Agent looped too long; escalate to human.")

    # Time travel / debugging: every checkpoint is inspectable. In production this is how
    # you answer "why did the agent do that?" — replay the exact state at each step.
    for snapshot in graph.get_state_history(config):
        print(snapshot.next, len(snapshot.values.get("messages", [])))

    # Visualize the graph (renders Mermaid text you can paste into mermaid.live)
    print(graph.get_graph().draw_mermaid())
