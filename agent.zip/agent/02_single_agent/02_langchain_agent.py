"""
02 — THE SAME AGENT WITH LANGCHAIN's create_agent
==================================================

CONCEPT DEEP DIVE: LANGCHAIN vs LANGGRAPH (people confuse these constantly)
---------------------------------------------------------------------------
- LANGCHAIN = the toolbox. Model wrappers (init_chat_model), prompts, output parsers,
  document loaders, text splitters, vector store integrations, retrievers, tools.
  Plus a high-level `create_agent` for the common "tool-calling loop" case.
- LANGGRAPH = the runtime/orchestrator. A low-level framework for stateful, cyclic graphs:
  explicit state, nodes, edges, checkpoints (persistence), interrupts (human-in-the-loop),
  streaming, and durable execution. In LangChain 1.x, `create_agent` is itself BUILT ON
  LangGraph — it's a pre-made graph.

Rule of thumb:
  - Standard tool-calling agent?            → create_agent (this file)
  - Custom control flow, branches, multiple
    agents, approval steps, retries per node? → raw LangGraph (next file)

MIDDLEWARE (LangChain 1.x)
`create_agent` accepts middleware: hooks that run before/after the model call or around
tool calls. This is where production concerns plug in without rewriting the loop:
summarize long history, human approval for risky tools, PII redaction, model fallback,
call limits. Conceptually identical to web-framework middleware.
"""

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver

load_dotenv()


@tool
def get_order_status(order_id: str) -> str:
    """Look up shipping status for an order ID like ORD-1001."""
    return f"{order_id}: shipped, arriving 2026-11-14"


@tool
def issue_refund(order_id: str, amount: float) -> str:
    """Issue a refund. Irreversible — only call after the user explicitly confirms."""
    return f"Refunded ${amount:.2f} for {order_id}"


agent = create_agent(
    model="openai:gpt-4o-mini",
    tools=[get_order_status, issue_refund],
    system_prompt=(
        "You are a support agent for ShopCo. Be brief. "
        "Never issue a refund without explicit user confirmation in the same conversation."
    ),
    # CHECKPOINTER = short-term memory/persistence. After every step LangGraph saves the
    # state under a `thread_id`. Same thread_id → conversation continues; it also lets you
    # resume after crashes and pause for human approval. InMemorySaver is for demos;
    # use SqliteSaver / PostgresSaver in production.
    checkpointer=InMemorySaver(),
    # Production example (uncomment to explore):
    # middleware=[
    #     HumanInTheLoopMiddleware(interrupt_on={"issue_refund": True}),  # pause before refunds
    #     SummarizationMiddleware(model="openai:gpt-4o-mini", max_tokens_before_summary=4000),
    #     ModelCallLimitMiddleware(run_limit=10),                           # bound the loop
    # ],
)


if __name__ == "__main__":
    config = {"configurable": {"thread_id": "customer-42"}}

    r1 = agent.invoke({"messages": [{"role": "user", "content": "Where's ORD-1001?"}]}, config)
    print(r1["messages"][-1].content)

    # Second turn, same thread_id → the agent remembers ORD-1001 without us resending it.
    r2 = agent.invoke({"messages": [{"role": "user", "content": "When will it arrive again?"}]}, config)
    print(r2["messages"][-1].content)

    # stream_mode="updates" shows each node's output as it happens — great for UIs that
    # display "Calling get_order_status…" progress.
    for update in agent.stream(
        {"messages": [{"role": "user", "content": "Status of ORD-2002?"}]}, config, stream_mode="updates"
    ):
        print(update)
