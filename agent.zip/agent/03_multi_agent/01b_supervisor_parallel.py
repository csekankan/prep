"""
01b — PARALLEL SUPERVISOR: one supervisor, many workers at the same time
=========================================================================

Read 01_supervisor.py first. The only change here: instead of picking ONE next worker, the
supervisor returns a LIST of assignments, and every assignment runs IN PARALLEL.

    SEQUENTIAL (01_supervisor.py)            PARALLEL (this file)

    supervisor → researcher                  supervisor ─┬─► researcher("EV sales 2024")    ┐
    supervisor → researcher                              ├─► researcher("solar installs")   ├─ same super-step
    supervisor → analyst                                 └─► ...                            ┘
    supervisor → FINISH                      supervisor ───► analyst("compute ratio")
                                             supervisor ───► FINISH
    4 supervisor calls, 3 worker hops         3 supervisor calls, 2 worker "rounds"

CONCEPT DEEP DIVE
-----------------
1. `Send(node_name, payload)` — returned from a conditional edge, it schedules ONE run of
   `node_name` with `payload` as that run's private input. Return a list of Sends → LangGraph
   runs them all in the same super-step, concurrently (sync nodes run in a thread pool; async
   nodes run on the event loop). The SAME node can be sent multiple times with different tasks
   — two researchers on two topics.

2. BARRIER — the edge `worker → supervisor` fires only after EVERY parallel run in the
   super-step finishes. The supervisor then sees all results at once.

3. REDUCERS make the merge safe — all parallel workers write to `messages` in the same step.
   `add_messages` appends all of them. With a plain `list` (no reducer) LangGraph would raise
   InvalidUpdateError because it can't choose which write wins.

4. ONLY PARALLELIZE INDEPENDENT WORK — the analyst needs the researchers' facts, so it must
   wait for the next round. The supervisor prompt says so explicitly; the LLM is the
   dependency planner here. If a step needs another step's output, it can't be in the same round.

5. COST & LIMITS — parallel saves wall-clock time, NOT tokens (same total work). Cap fan-out
   width (MAX_PARALLEL) and use `max_concurrency` in config to respect provider rate limits.
   Failure in one branch fails the super-step by default — wrap worker bodies so one bad
   branch reports an error message instead of killing the others.
"""

from typing import Annotated, Literal, TypedDict

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain.chat_models import init_chat_model
from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langchain_core.tools import tool
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.types import Send
from pydantic import BaseModel, Field

load_dotenv()
MAX_SUPERVISOR_TURNS = 5
MAX_PARALLEL = 4


# ------------------------- workers (same as 01_supervisor.py) -------------------------
@tool
def web_search(query: str) -> str:
    """Search the web for facts and figures."""
    if "solar" in query.lower():
        return "Global solar installations 2024: ~600 GW added."
    return "Global EV sales 2024: 17M units."


@tool
def python_calc(expression: str) -> str:
    """Compute numeric expressions. Digits and + - * / ( ) only."""
    if not set(expression) <= set("0123456789+-*/(). "):
        return "Error: invalid characters."
    return str(eval(expression))  # noqa: S307 — whitelisted


WORKER_AGENTS = {
    "researcher": create_agent(
        "openai:gpt-4o-mini",
        tools=[web_search],
        system_prompt="You are a researcher. Answer ONLY your assigned task with web_search. Cite facts. No math.",
    ),
    "analyst": create_agent(
        "openai:gpt-4o-mini",
        tools=[python_calc],
        system_prompt="You are an analyst. Use python_calc for every computation on facts in the conversation.",
    ),
}


# ------------------------- state -------------------------
class Assignment(BaseModel):
    worker: Literal["researcher", "analyst"]
    task: str = Field(description="Specific, self-contained instruction for this worker.")


class TeamState(TypedDict):
    # Reducer is what makes parallel writes safe (see concept 3).
    messages: Annotated[list[AnyMessage], add_messages]
    assignments: list[Assignment]
    turns: int


class WorkerInput(TypedDict):
    """Private payload delivered by Send. A worker gets the conversation so far plus ITS task,
    not the other parallel workers' tasks."""

    messages: list[AnyMessage]
    worker: str
    task: str


# ------------------------- supervisor -------------------------
class Plan(BaseModel):
    reasoning: str = Field(description="One sentence: what's missing and what can run in parallel.")
    assignments: list[Assignment] = Field(
        description="Tasks to run IN PARALLEL this round. Must be independent of each other. Empty list = FINISH."
    )


SUPERVISOR_PROMPT = """You manage a team that can work in parallel.
- researcher: finds facts via web search. You may assign several researchers at once, one topic each.
- analyst: calculates using facts ALREADY present in the conversation. Cannot search.

Each round, assign every task that can run NOW, in parallel.
Rules:
- Tasks in the same round must NOT depend on each other's output.
- The analyst can only run after the facts it needs appear in the conversation.
- Return an empty assignments list when the user's question is fully answered."""

planner = init_chat_model("openai:gpt-4o-mini", temperature=0).with_structured_output(Plan)


def supervisor(state: TeamState) -> dict:
    if state.get("turns", 0) >= MAX_SUPERVISOR_TURNS:
        return {"assignments": []}
    plan = planner.invoke([("system", SUPERVISOR_PROMPT), *state["messages"]])
    return {"assignments": plan.assignments[:MAX_PARALLEL], "turns": state.get("turns", 0) + 1}


def fan_out(state: TeamState):
    """Conditional edge: a list of Sends = parallel branches; END when nothing is assigned."""
    if not state["assignments"]:
        return END
    return [
        Send("worker", {"messages": state["messages"], "worker": a.worker, "task": a.task})
        for a in state["assignments"]
    ]


def worker(inp: WorkerInput) -> dict:
    """One generic node runs any worker type. Each parallel run receives its own WorkerInput."""
    agent = WORKER_AGENTS[inp["worker"]]
    try:
        result = agent.invoke({"messages": [*inp["messages"], HumanMessage(f"Your task: {inp['task']}")]})
        content = result["messages"][-1].content
    except Exception as exc:  # noqa: BLE001 — one failed branch shouldn't sink the others
        content = f"Worker failed on '{inp['task']}': {exc}"
    return {"messages": [AIMessage(content=f"[{inp['task']}] {content}", name=inp["worker"])]}


builder = StateGraph(TeamState)
builder.add_node("supervisor", supervisor)
builder.add_node("worker", worker)
builder.add_edge(START, "supervisor")
builder.add_conditional_edges("supervisor", fan_out, ["worker", END])
builder.add_edge("worker", "supervisor")  # barrier: runs once after ALL parallel workers finish
graph = builder.compile()


if __name__ == "__main__":
    question = "How many EVs were sold globally in 2024, how much solar capacity was added, and what's EVs per GW?"
    config = {"recursion_limit": 25, "max_concurrency": MAX_PARALLEL}

    # stream_mode="updates" makes the parallelism visible: several `worker` updates per round.
    for step in graph.stream({"messages": [("user", question)], "turns": 0}, config, stream_mode="updates"):
        for node, update in step.items():
            if node == "supervisor":
                print(f"\nSUPERVISOR → {[(a.worker, a.task) for a in update['assignments']] or 'FINISH'}")
            else:
                print(f"  {node}: {update['messages'][-1].content[:100]}")
