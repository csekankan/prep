# Multi-Agent Systems — Concepts

## Why multiple agents at all?

A single agent with 30 tools and a 3-page system prompt degrades: it picks wrong tools,
forgets instructions, and the context fills with irrelevant tool output. Splitting work gives:

- **Specialization** — each agent has a focused prompt and 2–5 tools.
- **Context isolation** — the researcher's 20 search results don't pollute the writer's context.
- **Parallelism** — independent subtasks run concurrently.
- **Modularity** — test, evaluate, and swap agents independently.

## Why NOT (read this twice)

- More LLM calls → more **cost and latency** (multi-agent research systems can use ~10x+ tokens of a single chat).
- More places to fail; errors **compound** across hand-offs (90% × 90% × 90% = 73%).
- Harder to debug and evaluate.
- Agents miscommunicate: the sub-agent gets a vague task, returns the wrong thing.

> Start single-agent. Go multi-agent when you can point to a *specific* failure that
> specialization or context isolation fixes.

## The main architectures

```
1. SUPERVISOR (hub & spoke)          2. HANDOFF / SWARM (peer-to-peer)
        ┌──────────┐                      ┌────────┐ handoff ┌────────┐
        │supervisor│                      │ triage │ ──────► │billing │
        └──┬───┬───┘                      └────────┘ ◄────── └────────┘
     ┌─────┘   └─────┐                         │  handoff       ▲
  ┌──▼───┐       ┌───▼──┐                      ▼                │
  │agentA│       │agentB│                   ┌────────┐ ─────────┘
  └──────┘       └──────┘                   │tech    │
  Central router decides who works next.    Active agent decides who goes next.
  Easy to reason about; supervisor is a     Fewer hops, lower latency; harder to
  bottleneck/extra LLM call each hop.       control globally.

3. PLAN-AND-EXECUTE                     4. HIERARCHICAL
  planner → [step1, step2, step3]         top supervisor → team supervisors → workers
  executor runs steps; replanner          Used when one supervisor has too many workers.
  adjusts plan after each step.

5. PARALLEL FAN-OUT / MAP-REDUCE         6. DEBATE / CRITIC
  orchestrator → N workers in parallel    generator ↔ critic loop (see 02_single_agent/04)
  (LangGraph `Send`) → aggregator
```

## Communication: what passes between agents?

- **Shared state** (LangGraph default): all agents read/write the same state object. Simple, but
  everyone sees everything.
- **Message passing / scoped state**: each agent gets only a task description and returns only
  a result. Better context isolation. Sub-agent = "a tool that happens to be an agent".
- **Handoff payload**: when transferring, pass a *summary* + the task, not the full transcript.

## Engineering checklist

- Every agent: clear role, narrow toolset, explicit output contract (Pydantic).
- Supervisor prompt lists each worker's **capabilities and when to use them**.
- Global bounds: total steps, total tokens, wall-clock timeout.
- Trace with agent names as span names so you can see *who* did *what*.
- Evaluate each agent alone (unit) AND the whole system end-to-end (integration).

## Files

- `01_supervisor.py` — supervisor routes between researcher/analyst using structured output.
- `01b_supervisor_parallel.py` — same supervisor, but assigns several independent tasks per round that run in parallel via `Send`.
- `02_handoff_swarm.py` — agents transfer control via `Command(goto=...)`.
- `03_plan_and_execute.py` — planner + executor + replanner, with parallel fan-out via `Send`.
