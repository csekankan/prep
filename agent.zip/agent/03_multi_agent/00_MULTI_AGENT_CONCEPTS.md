# Multi-Agent Systems: Concepts

An **agent** is an LLM running in a loop: it reads the task, decides on an action (usually calling a
**tool**, which is a function your code exposes, such as `search_web` or `lookup_order`), sees the result,
and repeats until it's done. A **multi-agent system** splits a job across several such agents, each with its
own instructions and tools, which pass work between them.

## Why multiple agents at all?

A single agent with 30 tools and a 3-page system prompt degrades in predictable ways:
- **It picks the wrong tools.** With 30 similar-sounding tool descriptions to choose from, mistakes become
  common.
- **It forgets instructions.** Rule 14 on page 2 of the prompt gets less attention than the text around it.
- **Its context fills with irrelevant tool output.** The **context** is all the text the model sees on a
  call. After a few searches, it's full of raw results that have nothing to do with the current step.

Splitting the work gives you:

- **Specialization.** Each agent has a focused prompt and only 2–5 tools. *Example:* a "billing agent" knows
  refund rules and has `get_invoice` and `issue_refund`. It never sees the shipping tools, so it can't misuse
  them.
- **Context isolation.** The researcher's 20 raw search results stay in the researcher's own context. It
  hands the writer a 1-paragraph summary, so the writer's context stays clean and focused on writing.
- **Parallelism.** Independent subtasks run at the same time. *Example:* researching three competitors with
  three agents in parallel takes about as long as researching one.
- **Modularity.** You can test, evaluate, and swap each agent on its own, like separate functions in normal
  code.

## Why NOT (read this twice)

- **More LLM calls mean more cost and more latency.** Every agent, and every hand-off, is extra model calls.
  Multi-agent research systems can use 10× or more the tokens of a single chat for the same question.
- **More places to fail, and errors compound.** If each hand-off works 90% of the time, a chain of three
  hand-offs works only \(0.9 \times 0.9 \times 0.9 = 0.73\), or 73% of the time. Small per-step error rates
  multiply into large end-to-end failure rates.
- **Harder to debug and evaluate.** When the final answer is wrong, you have to work out which agent made
  the mistake, and why.
- **Agents miscommunicate.** The coordinator passes a vague task ("look into pricing"), and the sub-agent
  returns something correct but useless ("here's the history of pricing theory").

> Start with a single agent. Go multi-agent only when you can point to a *specific* failure that
> specialization or context isolation would fix, for example "with all 25 tools loaded, the agent calls the
> wrong refund tool 15% of the time."

## The main architectures

```
1. SUPERVISOR (hub & spoke)          2. HANDOFF / SWARM (peer-to-peer)
        ┌──────────┐                      ┌────────┐ handoff ┌────────┐
        │supervisor│                      │ triage │ ──────► │billing │
        └──┬───┬───┘                      └────────┘ ◄────── └────────┘
     ┌─────┘   └─────┐                         │  handoff       ▲
  ┌──▼───┐       ┌───▼──┐                      ▼                │
  │agentA│       │agentB│                   ┌────────┐ ─────────┘
  └──────┘       └──────┘                   │tech    │
  Central router decides who works next.    Active agent decides who goes next.
  Easy to reason about; supervisor is a     Fewer hops, lower latency; harder to
  bottleneck/extra LLM call each hop.       control globally.

3. PLAN-AND-EXECUTE                     4. HIERARCHICAL
  planner → [step1, step2, step3]         top supervisor → team supervisors → workers
  executor runs steps; replanner          Used when one supervisor has too many workers.
  adjusts plan after each step.

5. PARALLEL FAN-OUT / MAP-REDUCE         6. DEBATE / CRITIC
  orchestrator → N workers in parallel    generator ↔ critic loop (see 02_single_agent/04)
  (LangGraph `Send`) → aggregator
```

**How to read it:** each sketch shows who decides what happens next. In the boxes, arrows show which agent
hands control to which. The six patterns are explained below, each with an example.

**1. Supervisor (hub and spoke).** One **supervisor** agent receives every request and decides which worker
agent should act next. Each worker reports back to the supervisor, which then decides again: another worker,
or finish.
- *Example:* a research assistant. The supervisor sends "find the data" to the researcher, gets results back,
  then sends "build the chart" to the analyst.
- *Pros:* easy to understand and control, because all routing happens in one place.
- *Cons:* the supervisor is a **bottleneck**, and every hop through it costs an extra LLM call.
- *See:* `01_supervisor.py` and `01b_supervisor_parallel.py`.

**2. Hand-off / swarm (peer to peer).** There's no central boss. Whichever agent is currently active decides
whether to keep working or to **hand off** control directly to another agent.
- *Example:* customer support. A triage agent hears "I was charged twice" and hands off straight to billing.
  Billing discovers it's really a login problem and hands off to tech support.
- *Pros:* fewer hops, so lower latency.
- *Cons:* harder to enforce global rules, and agents can bounce a user back and forth.
- *See:* `02_handoff_swarm.py`.

**3. Plan-and-execute.** A **planner** writes a step-by-step plan up front, an **executor** carries out the
steps, and a **replanner** looks at the results after each step and adjusts the remaining plan.
- *Example:* "Compare our Q3 sales with our two biggest competitors." Plan: fetch our numbers, fetch
  competitor A, fetch competitor B, compare. If competitor B's data isn't public, the replanner swaps in an
  estimate from news articles.
- *Pros:* the plan is visible and easy to inspect, and execution can use a cheaper model.
- *See:* `03_plan_and_execute.py`.

**4. Hierarchical.** Supervisors of supervisors: a top supervisor routes to team supervisors, and each team
supervisor manages its own workers. Use it when one supervisor would have too many workers to choose between
reliably (say, more than 6–8).
- *Example:* a "report team" with a research sub-team (web, papers, internal docs) and a writing sub-team
  (drafter, editor).

**5. Parallel fan-out / map-reduce.** An **orchestrator** splits the job into N independent pieces, runs N
workers at the same time (**fan-out**), and an **aggregator** combines their results. The name comes from the
classic data-processing pattern: **map** (process each piece separately), then **reduce** (combine).
In LangGraph, the `Send` API launches the parallel workers.
- *Example:* summarize 40 customer interviews. 40 workers each summarize one interview in parallel, and an
  aggregator merges them into the top 5 themes.

**6. Debate / critic.** A **generator** produces a draft, and a **critic** reviews it and lists problems. The
generator revises, and they loop until the critic approves or a round limit is hit.
- *Example:* a generator writes SQL, and a critic checks it for missing `WHERE` clauses and wrong joins.
- *See:* `02_single_agent/04_reflection_loop.py`.

## Communication: what passes between agents?

- **Shared state** (LangGraph's default): every agent reads and writes one common state object, such as the
  full message list. It's simple, but everyone sees everything. The writer agent ends up reading the
  researcher's 20 raw search results, which defeats context isolation.
- **Message passing / scoped state**: each agent receives only a task description and returns only a result.
  This gives much better context isolation. A useful way to think about it: *a sub-agent is just a tool that
  happens to be an agent.* The caller sends input and gets output, without seeing the sub-agent's internal
  steps.
- **Hand-off payload**: when transferring control, pass a *summary* plus the task, not the full transcript.
  *Example:* triage hands off to billing with "Customer Priya, order ORD-1001, charged twice on Nov 3, wants
  the duplicate refunded", not 30 messages of back-and-forth.

## Engineering checklist

- **Every agent has a clear role, a narrow toolset, and an explicit output contract.** An **output contract**
  is a fixed structure the agent must return, defined with **Pydantic** (a Python library for typed, validated
  data). For example: `{"answer": str, "sources": list[str], "confidence": float}`. Downstream code can then
  rely on the shape.
- **The supervisor prompt lists each worker's capabilities and when to use it.** "researcher: finds facts on
  the web; use it for any question needing current data" beats a bare list of agent names.
- **Set global bounds**: a limit on total steps, total tokens, and wall-clock time for the whole run. Without
  them, two agents can hand a task back and forth forever.
- **Trace with agent names as span names.** In your tracing tool (LangSmith or Langfuse), each step should be
  labeled with the agent that ran it (`researcher.search`, `writer.draft`), so you can see *who* did *what*
  when debugging.
- **Evaluate at two levels**: each agent alone (like a unit test: "given this task, does the researcher
  return relevant sources?") *and* the whole system end to end (like an integration test: "is the final
  report correct?").

## Files

- `01_supervisor.py`: a supervisor routes between a researcher and an analyst, choosing with structured
  output.
- `01b_supervisor_parallel.py`: the same supervisor, but it assigns several independent tasks per round, and
  they run in parallel via `Send`.
- `02_handoff_swarm.py`: agents transfer control to each other via `Command(goto=...)`.
- `03_plan_and_execute.py`: planner, executor, and replanner, with parallel fan-out via `Send`.
