"""
03 — PLAN-AND-EXECUTE with PARALLEL FAN-OUT (Send) and REPLANNING
==================================================================

CONCEPT DEEP DIVE
-----------------
ReAct decides one step at a time — good for exploration, bad for long tasks (it loses the
big picture and wastes calls). PLAN-AND-EXECUTE separates:

  PLANNER   (strong model, called rarely)  → produces an explicit list of steps
  EXECUTORS (cheap model, called often)    → each executes one step
  REPLANNER (strong model)                 → looks at results: done? adjust plan?

Benefits: cost (strong model only plans), transparency (plan can be shown to/approved by a
human), and PARALLELISM — independent steps run concurrently.

PARALLELISM IN LANGGRAPH: `Send`
A conditional edge can return a list of `Send("node", payload)` objects. LangGraph runs that
node once per Send IN PARALLEL with its own private input (map step). Results merge back into
state via a reducer — here `operator.add` concatenates lists (reduce step). This is the
map-reduce / orchestrator-worker pattern.

   planner ──► [Send(executor, step1), Send(executor, step2), ...] ──► replanner ──► END
                         (parallel)                                       │
                                                                          └─► back to planner if needed
"""

import operator
from typing import Annotated, TypedDict

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langgraph.graph import END, START, StateGraph
from langgraph.types import Send
from pydantic import BaseModel, Field

load_dotenv()
MAX_REPLANS = 2

planner_llm = init_chat_model("openai:gpt-4o", temperature=0)
executor_llm = init_chat_model("openai:gpt-4o-mini", temperature=0)


class Plan(BaseModel):
    steps: list[str] = Field(description="Independent research steps, each answerable on its own. Max 4.")


class Verdict(BaseModel):
    done: bool
    final_answer: str = Field(description="Full answer if done, else empty.")
    missing: list[str] = Field(description="New steps needed if not done.")


class State(TypedDict):
    goal: str
    plan: list[str]
    # Reducer operator.add: each parallel executor appends its result; nothing is overwritten.
    results: Annotated[list[str], operator.add]
    replans: int
    answer: str


class StepInput(TypedDict):
    """Private input for one executor — it does NOT see the whole state (context isolation)."""

    goal: str
    step: str


def planner(state: State) -> dict:
    plan = planner_llm.with_structured_output(Plan).invoke(
        f"Goal: {state['goal']}\nAlready known: {state.get('results', [])}\nMake a plan."
    )
    return {"plan": plan.steps}


def fan_out(state: State) -> list[Send]:
    # One Send per step → executors run in parallel.
    return [Send("executor", {"goal": state["goal"], "step": s}) for s in state["plan"]]


def executor(inp: StepInput) -> dict:
    # In a real system this would be a tool-using agent (search, SQL, code).
    out = executor_llm.invoke(f"Overall goal: {inp['goal']}\nDo only this step, concisely: {inp['step']}")
    return {"results": [f"[{inp['step']}] {out.content}"]}


def replanner(state: State) -> dict:
    v = planner_llm.with_structured_output(Verdict).invoke(
        f"Goal: {state['goal']}\nResults:\n" + "\n".join(state["results"]) + "\nIs the goal fully achieved?"
    )
    if v.done or state.get("replans", 0) >= MAX_REPLANS:
        return {"answer": v.final_answer or "\n".join(state["results"])}
    return {"plan": v.missing, "replans": state.get("replans", 0) + 1}


def after_replan(state: State):
    return END if state.get("answer") else fan_out(state)


builder = StateGraph(State)
builder.add_node("planner", planner)
builder.add_node("executor", executor)
builder.add_node("replanner", replanner)
builder.add_edge(START, "planner")
builder.add_conditional_edges("planner", fan_out, ["executor"])
builder.add_edge("executor", "replanner")  # waits for ALL parallel executors (a barrier)
builder.add_conditional_edges("replanner", after_replan, ["executor", END])
graph = builder.compile()

if __name__ == "__main__":
    out = graph.invoke({"goal": "Compare Chroma, pgvector and Pinecone for a startup's RAG app.", "results": [], "replans": 0})
    print(out["answer"])
