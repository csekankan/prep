"""
01 — SUPERVISOR PATTERN in LangGraph
=====================================

CONCEPT DEEP DIVE
-----------------
A supervisor is an LLM whose only job is ROUTING: given the conversation so far, which
worker should act next, or are we done?

             ┌──────────────► researcher ──┐
   START ─► supervisor                     ├──► back to supervisor ─► ... ─► FINISH
             └──────────────► analyst ─────┘

Key design decisions (annotated in code below):
1. Router uses STRUCTURED OUTPUT (a Literal of worker names) — never parse free text to
   pick a route; a typo becomes a crash.
2. Workers are themselves agents (create_agent), each with its own tools and prompt.
   Each is a "subgraph" — a graph used as a node.
3. Workers return only their FINAL message to the shared state (context isolation),
   tagged with their name so the supervisor knows who said what.
4. A hard cap on supervisor turns prevents ping-pong between workers.

Alternative: `langgraph-supervisor` package offers `create_supervisor(...)` prebuilt. We
build it by hand so every decision is visible.
"""

from typing import Annotated, Literal, TypedDict

from dotenv import load_dotenv
from langchain.agents import create_agent
from langchain.chat_models import init_chat_model
from langchain_core.messages import AIMessage, AnyMessage
from langchain_core.tools import tool
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from pydantic import BaseModel, Field

load_dotenv()
MAX_SUPERVISOR_TURNS = 6
WORKERS = ["researcher", "analyst"]


# ------------------------- worker tools -------------------------
@tool
def web_search(query: str) -> str:
    """Search the web for facts and figures."""
    return "EV sales 2024: 17M units globally; 2025 forecast: 20M (+18%)."


@tool
def python_calc(expression: str) -> str:
    """Compute numeric expressions, e.g. growth rates. Digits and + - * / ( ) only."""
    if not set(expression) <= set("0123456789+-*/(). "):
        return "Error: invalid characters."
    return str(eval(expression))  # noqa: S307 — whitelisted


# ------------------------- worker agents -------------------------
# Each worker is a full tool-calling agent with a NARROW role.
researcher = create_agent(
    "openai:gpt-4o-mini",
    tools=[web_search],
    system_prompt="You are a researcher. Find facts with web_search. Report facts with sources. Do no math.",
)
analyst = create_agent(
    "openai:gpt-4o-mini",
    tools=[python_calc],
    system_prompt="You are a data analyst. Use python_calc for every computation. Do not search.",
)


# ------------------------- shared state -------------------------
class TeamState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    next: str
    turns: int


# ------------------------- supervisor -------------------------
class Route(BaseModel):
    """Who should act next."""

    reasoning: str = Field(description="One sentence on why.")  # reasoning first = mini-CoT
    next: Literal["researcher", "analyst", "FINISH"]


SUPERVISOR_PROMPT = f"""You manage a team: {WORKERS}.
- researcher: finds facts on the web. Cannot compute.
- analyst: does calculations on facts already found. Cannot search.
Given the conversation, choose who acts next. Choose FINISH when the user's question is fully answered.
Never send the same worker the same task twice in a row."""

router_llm = init_chat_model("openai:gpt-4o-mini", temperature=0).with_structured_output(Route)


def supervisor(state: TeamState) -> dict:
    if state.get("turns", 0) >= MAX_SUPERVISOR_TURNS:
        return {"next": "FINISH"}
    decision = router_llm.invoke([("system", SUPERVISOR_PROMPT), *state["messages"]])
    return {"next": decision.next, "turns": state.get("turns", 0) + 1}


def make_worker_node(name: str, agent):
    def node(state: TeamState) -> dict:
        result = agent.invoke({"messages": state["messages"]})
        # Context isolation: only the worker's final answer goes into shared state,
        # not its internal tool chatter. `name` lets the supervisor attribute it.
        final = result["messages"][-1].content
        return {"messages": [AIMessage(content=final, name=name)]}

    return node


builder = StateGraph(TeamState)
builder.add_node("supervisor", supervisor)
builder.add_node("researcher", make_worker_node("researcher", researcher))
builder.add_node("analyst", make_worker_node("analyst", analyst))

builder.add_edge(START, "supervisor")
builder.add_conditional_edges(
    "supervisor",
    lambda s: s["next"],
    {"researcher": "researcher", "analyst": "analyst", "FINISH": END},
)
for w in WORKERS:
    builder.add_edge(w, "supervisor")  # workers always report back

graph = builder.compile()

if __name__ == "__main__":
    out = graph.invoke(
        {"messages": [("user", "What were global EV sales in 2024 and what's the forecast growth in units?")], "turns": 0},
        {"recursion_limit": 30},
    )
    for m in out["messages"]:
        print(f"{getattr(m, 'name', None) or m.type}: {m.content}\n")
