"""
02 — HANDOFF / SWARM PATTERN with Command
==========================================

CONCEPT DEEP DIVE
-----------------
In a swarm there is no central boss. The ACTIVE agent decides to keep the conversation or
hand it to a peer. This mirrors a real support desk: triage → billing → tech.

Mechanism in LangGraph: a node can return `Command(goto="other_node", update={...})`,
which BOTH updates state AND chooses the next node — routing and state change in one
atomic step. A "handoff tool" is just a tool the LLM can call that results in such a
Command. To the model, transferring is just another tool call.

Advantages vs supervisor:
  - Fewer LLM calls (no router hop between every step) → lower latency/cost.
  - The user can talk directly to the specialist across turns (track `active_agent`).
Disadvantages:
  - No global view; agents can bounce users around ("transfer ping-pong").
    Mitigate with a transfer counter and clear "when to transfer" rules in each prompt.

Prebuilt alternative: `langgraph-swarm` package (`create_swarm`, `create_handoff_tool`).
Here we implement a minimal version to expose the mechanics.
"""

from typing import Annotated, Literal, TypedDict

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_core.messages import AnyMessage, ToolMessage
from langchain_core.tools import tool
from langgraph.graph import START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.types import Command

load_dotenv()
MAX_TRANSFERS = 3
AgentName = Literal["triage", "billing", "tech"]


class SwarmState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    active_agent: str
    transfers: int


# Handoff "tools" — their schema is what the model sees; we intercept them ourselves.
@tool
def transfer_to_billing(reason: str) -> str:
    """Transfer to the billing specialist for charges, refunds, invoices."""
    return reason


@tool
def transfer_to_tech(reason: str) -> str:
    """Transfer to technical support for bugs, errors, outages, integrations."""
    return reason


@tool
def lookup_invoice(customer_id: str) -> str:
    """Fetch the latest invoice for a customer."""
    return "Invoice INV-77: $49 charged twice on 2026-11-01."


PROMPTS = {
    "triage": "You are triage. Greet, understand the issue, then transfer. Never solve issues yourself.",
    "billing": "You are billing. Resolve charge questions using lookup_invoice. Transfer to tech only for technical bugs.",
    "tech": "You are tech support. Troubleshoot step by step. Transfer to billing only for money questions.",
}
TOOLS = {
    "triage": [transfer_to_billing, transfer_to_tech],
    "billing": [lookup_invoice, transfer_to_tech],
    "tech": [transfer_to_billing],
}
HANDOFFS = {"transfer_to_billing": "billing", "transfer_to_tech": "tech"}
base_llm = init_chat_model("openai:gpt-4o-mini", temperature=0)


def make_agent(name: str):
    llm = base_llm.bind_tools(TOOLS[name])
    tool_map = {t.name: t for t in TOOLS[name]}

    def node(state: SwarmState) -> Command:
        msgs = [("system", PROMPTS[name]), *state["messages"]]
        # Inner loop: an agent may call its own tools several times before answering
        # or handing off. Bounded at 5 for safety.
        new_msgs = []
        for _ in range(5):
            ai = llm.invoke(msgs + new_msgs)
            new_msgs.append(ai)
            if not ai.tool_calls:
                # Final answer for this turn. Graph ends; user replies next turn and we
                # resume with the same active_agent (stored in state).
                return Command(goto="__end__", update={"messages": new_msgs, "active_agent": name})
            for call in ai.tool_calls:
                if call["name"] in HANDOFFS:
                    target = HANDOFFS[call["name"]]
                    if state.get("transfers", 0) >= MAX_TRANSFERS:
                        new_msgs.append(ToolMessage("Transfer limit reached; resolve it yourself or escalate to a human.", tool_call_id=call["id"]))
                        continue
                    new_msgs.append(ToolMessage(f"Transferred to {target}.", tool_call_id=call["id"]))
                    # THE HANDOFF: update state and jump to another agent atomically.
                    return Command(
                        goto=target,
                        update={"messages": new_msgs, "active_agent": target, "transfers": state.get("transfers", 0) + 1},
                    )
                result = tool_map[call["name"]].invoke(call["args"])
                new_msgs.append(ToolMessage(str(result), tool_call_id=call["id"]))
        return Command(goto="__end__", update={"messages": new_msgs})

    return node


def entry_router(state: SwarmState) -> Command:
    # Multi-turn continuity: returning users go straight to whoever was helping them.
    return Command(goto=state.get("active_agent") or "triage")


builder = StateGraph(SwarmState)
builder.add_node("entry", entry_router, destinations=("triage", "billing", "tech"))
for name in ("triage", "billing", "tech"):
    # `destinations` declares possible Command targets so the graph can be visualized/validated.
    builder.add_node(name, make_agent(name), destinations=("billing", "tech", "__end__"))
builder.add_edge(START, "entry")
graph = builder.compile()

if __name__ == "__main__":
    out = graph.invoke({"messages": [("user", "I was charged twice, customer id C-9")], "transfers": 0, "active_agent": ""})
    print("handled by:", out["active_agent"])
    print(out["messages"][-1].content)
