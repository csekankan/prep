"""
03 — TOOL CALLING: the bridge from "text generator" to "agent"
===============================================================

CONCEPT DEEP DIVE
-----------------
The model can't execute anything. "Tool calling" works like this:

  1. You describe tools to the model: name + description + JSON schema of arguments.
  2. The model, instead of answering, may return a TOOL CALL: {"name": "get_weather",
     "args": {"city": "Pune"}, "id": "call_abc"}.
  3. YOUR code executes the function and sends the result back as a ToolMessage that
     references the same id.
  4. The model reads the result and either calls another tool or answers.

Steps 2–4 repeated in a loop = an AGENT (see 02_single_agent/).

Why this matters:
- The model chooses WHICH tool and WHAT arguments → tool descriptions are prompts.
  Write them like docs for a junior engineer: when to use, when NOT to use, arg formats.
- The model can hallucinate arguments (wrong IDs, invented fields) → validate args
  (Pydantic does this) and return helpful error strings so the model can self-correct.
- Tools are your security boundary. The model is untrusted; a tool that deletes data
  must check permissions itself, not rely on the prompt saying "don't delete".

Tool design principles:
- Few, well-named, orthogonal tools beat many overlapping ones (models get confused
  choosing between `search_docs` and `find_documents`).
- Return concise, structured results. Dumping 50KB of JSON wastes context and money.
- Make tools idempotent where possible; agents retry.
- Errors are data: return "Error: order 999 not found. Valid IDs look like ORD-1234."
  instead of raising — the model can recover from a message, not from a crash.
"""

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_core.messages import HumanMessage, ToolMessage
from langchain_core.tools import tool

load_dotenv()

FAKE_ORDERS = {"ORD-1001": {"status": "shipped", "eta": "2026-11-14"}}


# The @tool decorator turns a function into a tool: the function name becomes the tool name,
# the docstring becomes the description, and type hints become the argument JSON schema.
@tool
def get_order_status(order_id: str) -> str:
    """Look up the shipping status of a customer order.

    Use this when the user asks where their order is or when it will arrive.
    order_id format: 'ORD-' followed by 4 digits, e.g. ORD-1001.
    """
    order = FAKE_ORDERS.get(order_id)
    if order is None:
        return f"Error: order {order_id} not found. Ask the user to double-check the ID."
    return f"Order {order_id}: status={order['status']}, eta={order['eta']}"


@tool
def calculator(expression: str) -> str:
    """Evaluate a basic arithmetic expression like '12 * (3 + 4)'. Use for any math."""
    # NEVER use bare eval() on model output in production — that's remote code execution.
    # Here we whitelist characters as a minimal sandbox; prefer a real math parser.
    allowed = set("0123456789+-*/(). ")
    if not set(expression) <= allowed:
        return "Error: only digits and + - * / ( ) are allowed."
    return str(eval(expression))  # noqa: S307 — sandboxed by whitelist above


tools = [get_order_status, calculator]
tools_by_name = {t.name: t for t in tools}

# bind_tools attaches the tool schemas to every request this model makes.
llm = init_chat_model("openai:gpt-4o-mini", temperature=0).bind_tools(tools)


def one_round_of_tool_calling() -> None:
    """Shows ONE manual think→act→observe cycle. The next folder turns this into a loop."""
    messages = [HumanMessage("Where is my order ORD-1001?")]

    ai_msg = llm.invoke(messages)
    messages.append(ai_msg)

    # ai_msg.tool_calls is a list because models can request PARALLEL tool calls
    # (e.g. look up 3 orders at once). Always handle the list, never assume one.
    for call in ai_msg.tool_calls:
        result = tools_by_name[call["name"]].invoke(call["args"])
        # tool_call_id links the result to the request — required by the API.
        messages.append(ToolMessage(content=result, tool_call_id=call["id"]))

    final = llm.invoke(messages)
    print(final.content)


if __name__ == "__main__":
    one_round_of_tool_calling()
