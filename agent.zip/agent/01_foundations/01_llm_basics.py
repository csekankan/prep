"""
01 — LLM BASICS: what actually happens when you "call a model"
===============================================================

CONCEPT DEEP DIVE
-----------------
An LLM is a function:   next_token_probabilities = f(all_previous_tokens)

Everything else — chat, tools, agents, RAG — is built on top of that one primitive by
*arranging text in the context window* cleverly. That's why the modern name for the
discipline is "context engineering".

Key terms you must own:

- TOKEN: a sub-word chunk (~4 chars of English). You pay per token, latency scales with
  tokens, and the context window is measured in tokens.
- CONTEXT WINDOW: max tokens the model can see at once (input + output). Big windows do NOT
  mean perfect recall — models suffer "lost in the middle": facts in the middle of long
  context are used less reliably than facts at the start/end.
- MESSAGES / ROLES: chat models take a list of messages:
    system    → standing instructions, persona, rules (highest priority by convention)
    user      → the human's input
    assistant → the model's previous replies (and tool-call requests)
    tool      → results of tools the model asked to call
  The API is stateless: YOU resend the whole history every call. "Memory" is just you
  deciding what goes in that list.
- TEMPERATURE: randomness of sampling. 0 ≈ deterministic-ish (extraction, classification,
  agents). 0.7+ = creative writing. Even at 0, outputs are not guaranteed identical.
- MAX TOKENS: caps output length → caps cost and latency.
- STREAMING: receive tokens as generated; huge perceived-latency win for chat UIs.

Cost & latency intuition:
    latency ≈ time_to_first_token + output_tokens × time_per_token
    cost    ≈ input_tokens × in_price + output_tokens × out_price
→ Output tokens are slow and expensive; ask for concise outputs.
"""

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_core.messages import HumanMessage, SystemMessage

load_dotenv()

# init_chat_model is LangChain's provider-agnostic factory. "openai:gpt-4o-mini" could be
# swapped for "anthropic:claude-sonnet-4-5" or "ollama:llama3" without touching other code.
# Provider-agnosticism matters in production: models get deprecated, prices change, and you
# want to A/B test models cheaply.
llm = init_chat_model("openai:gpt-4o-mini", temperature=0, max_tokens=300)


def basic_call() -> None:
    messages = [
        # The system prompt is where you encode behavior. Good system prompts are specific:
        # role, audience, constraints, output format, and what to do when unsure.
        SystemMessage(
            "You are a concise tutor for software engineers. "
            "Answer in at most 3 sentences. If you are unsure, say so."
        ),
        HumanMessage("What is a vector embedding?"),
    ]
    response = llm.invoke(messages)

    # response is an AIMessage. Beyond .content it carries metadata you should log in prod:
    # token usage (for cost tracking), finish reason (did it hit max_tokens?), model name.
    print(response.content)
    print(response.usage_metadata)  # {'input_tokens': .., 'output_tokens': .., 'total_tokens': ..}


def streaming_call() -> None:
    # .stream() yields chunks as they are generated. In a web app you forward these over
    # Server-Sent Events (SSE) or websockets. Users perceive streaming answers as ~2x faster.
    for chunk in llm.stream("Explain the context window in one paragraph."):
        print(chunk.content, end="", flush=True)


def conversation_is_just_a_list() -> None:
    # Demonstrates statelessness: the model "remembers" turn 1 only because we resend it.
    # This is the seed of every memory system (see 05_memory/). When history grows past
    # the context window you must trim, summarize, or retrieve — never just append forever.
    history = [SystemMessage("You are helpful.")]
    for user_text in ["My name is Priya.", "What's my name?"]:
        history.append(HumanMessage(user_text))
        ai = llm.invoke(history)
        history.append(ai)
        print(f"user: {user_text}\nai:   {ai.content}\n")


if __name__ == "__main__":
    basic_call()
