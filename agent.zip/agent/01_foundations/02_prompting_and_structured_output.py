"""
02 — PROMPTING PATTERNS & STRUCTURED OUTPUT
============================================

CONCEPT DEEP DIVE: PROMPTING
----------------------------
Prompting techniques that actually move metrics in production:

1. Clear role + task + constraints + output format. Ambiguity is the #1 cause of bad output.
2. FEW-SHOT examples: show 2–5 input→output pairs. Most effective for format and tone.
   Pick diverse examples, including an edge case, or the model overfits to one pattern.
3. CHAIN-OF-THOUGHT (CoT): "think step by step" before answering. Helps on multi-step
   reasoning. Modern "reasoning models" (o-series, Claude extended thinking) do this
   internally — don't add CoT instructions to them, it can hurt.
4. DELIMITERS: wrap untrusted/variable input in tags like <document>...</document>. This
   helps the model separate instructions from data — a first line of defense against
   prompt injection (see 06_guardrails/).
5. "ESCAPE HATCH": explicitly allow "I don't know" / "insufficient information". Without
   it, models fill gaps with plausible fiction (hallucination).
6. PROMPTS ARE CODE: version them, review them, eval them. Never edit a prod prompt without
   running the eval set.

CONCEPT DEEP DIVE: STRUCTURED OUTPUT
------------------------------------
Free-text output is for humans. When CODE consumes the output, demand a schema.

Three levels of enforcement (weakest → strongest):
  a) "Respond in JSON" in the prompt          → often breaks (trailing text, bad quotes)
  b) Tool/function-calling with a schema       → model fills arguments of a fake "tool"
  c) Native constrained decoding (json_schema) → provider guarantees schema-valid tokens

LangChain's `.with_structured_output(PydanticModel)` picks the best available method and
parses into a validated Pydantic object. Pydantic `Field(description=...)` text is sent to
the model — descriptions ARE prompt engineering.
"""

from typing import Literal

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field

load_dotenv()
llm = init_chat_model("openai:gpt-4o-mini", temperature=0)


# ---------------------------------------------------------------------------
# Prompt templates: separate the static instruction from the variable input.
# Templates make prompts testable and versionable (store them in files/registry).
# ---------------------------------------------------------------------------
TRIAGE_PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You triage customer support tickets.\n"
            "Rules:\n"
            "- Classify into exactly one category.\n"
            "- urgency is 'high' only if money is lost or the service is down.\n"
            "- If the ticket is not a support request, use category 'other'.\n\n"
            # Few-shot examples embedded in the system prompt.
            "Examples:\n"
            "Ticket: 'I was charged twice this month' -> billing, high\n"
            "Ticket: 'How do I change my avatar?' -> account, low\n",
        ),
        # Delimiters around untrusted input.
        ("human", "<ticket>\n{ticket}\n</ticket>"),
    ]
)


class TicketTriage(BaseModel):
    """Structured triage result. The docstring is also sent to the model as the schema description."""

    category: Literal["billing", "technical", "account", "other"] = Field(
        description="The single best-fitting category."
    )
    urgency: Literal["low", "medium", "high"]
    summary: str = Field(description="One-sentence neutral summary, max 20 words.")
    # Asking for reasoning BEFORE the final field would act like CoT; asking for a
    # confidence lets you route low-confidence cases to humans.
    confidence: float = Field(ge=0, le=1, description="Your confidence in the category.")


# LCEL (LangChain Expression Language): `prompt | model` composes Runnables into a chain.
# Every Runnable supports .invoke / .stream / .batch / .ainvoke — uniform interface, free
# batching and async, and automatic tracing in LangSmith.
triage_chain = TRIAGE_PROMPT | llm.with_structured_output(TicketTriage)


if __name__ == "__main__":
    result: TicketTriage = triage_chain.invoke(
        {"ticket": "Your API has been returning 500s for an hour, our checkout is down!"}
    )
    # result is a validated Python object — no json.loads, no KeyError surprises.
    print(result.model_dump())

    # Production pattern: route on confidence.
    if result.confidence < 0.6:
        print("→ send to human queue")

    # .batch runs many inputs concurrently (bounded by max_concurrency) — use it for evals
    # and offline jobs instead of a Python for-loop.
    results = triage_chain.batch(
        [{"ticket": "Reset my password pls"}, {"ticket": "Refund for order 123?"}],
        config={"max_concurrency": 5},
    )
