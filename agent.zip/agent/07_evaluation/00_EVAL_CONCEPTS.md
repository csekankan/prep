# Evaluating LLM Apps — Concepts

> "You can't improve what you don't measure" — and with LLMs, *vibes lie*. A prompt tweak
> that fixes the example you're staring at often breaks five you aren't.

## Kinds of evaluation

| Kind | When | Examples |
|------|------|----------|
| **Unit / assertion** | every commit | output is valid JSON, contains citation, refuses off-topic |
| **Reference-based** | offline | compare to expected answer (exact match, semantic similarity) |
| **LLM-as-judge** | offline + online | faithfulness, relevancy, rubric scoring with G-Eval |
| **Human eval** | periodically | expert labels; used to *calibrate* the LLM judges |
| **Online / production** | continuously | sampled traces scored by judges, user feedback, A/B tests |
| **Red-teaming** | before launch + periodically | jailbreaks, injections, PII leakage, bias |

## The RAG metric quartet (DeepEval / Ragas names)

```
              question ──► RETRIEVER ──► context ──► GENERATOR ──► answer
                                │                         │
   Contextual PRECISION: are relevant chunks        FAITHFULNESS: is the answer supported
     ranked at the top?                               by the context? (hallucination)
   Contextual RECALL: does context contain          ANSWER RELEVANCY: does the answer
     everything needed for the expected answer?       address the question?
   Contextual RELEVANCY: how much of the
     context is actually relevant? (noise)
```

Diagnose by component: low recall → fix chunking/retrieval/k; low precision → add reranking;
low faithfulness with good context → fix prompt / model; low relevancy → prompt or query rewriting.

## Agent metrics

- **Task completion** — did the agent achieve the goal?
- **Tool correctness** — did it call the right tools (and with correct args)?
- **Step efficiency** — number of steps / tokens / cost vs an ideal path.
- **Trajectory eval** — judge the whole sequence of actions, not just the final answer.

## LLM-as-judge pitfalls

- Position bias, verbosity bias (longer = "better"), self-preference (judging its own model family).
- Mitigate: strong judge model, explicit rubric with evaluation steps (G-Eval), binary/low-cardinality
  scores, and **calibrate against ~50 human labels** — measure judge/human agreement.

## The eval dataset ("goldens")

- Start with 30–100 hand-written cases: happy path, edge cases, out-of-scope, adversarial.
- Augment with synthetic generation (DeepEval `Synthesizer`) from your docs — then *review* them.
- Every production bug becomes a new golden. The dataset is a living asset; version it.

## Workflow

1. Run evals locally while iterating (`deepeval test run`).
2. Gate PRs in CI with thresholds (`03_ci_eval_gate.py`).
3. Track scores over time (Confident AI / LangSmith dashboards) to catch regressions.
4. **Error analysis**: read failures, categorize, fix the biggest category. Metrics tell you *that*
   something broke; reading traces tells you *why*.
