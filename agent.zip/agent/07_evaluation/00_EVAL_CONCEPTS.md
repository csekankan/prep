# Evaluating LLM Apps: Concepts

> "You can't improve what you don't measure." With LLMs, *vibes lie*: a prompt tweak that fixes the
> one example you're staring at often quietly breaks five you aren't looking at.

**What evaluation means here.** An **eval** is an automated test for an AI app. Normal unit tests check
"for input X the output must equal Y". LLM output is free text that varies from run to run, so evals
usually check *properties* of the output instead ("is it supported by the documents?", "does it answer
the question?"), often on a 0–1 score, against a fixed set of test questions.

*Example of why this matters:* you change the system prompt to make answers friendlier. You try three
questions and they look great. Without evals you ship it. With evals, you run 80 saved questions and see
that correct-answer rate dropped from 88% to 79%, because the friendlier prompt made the model more
willing to guess when it didn't know.

---

## Kinds of evaluation

| Kind | When it runs | What it checks (examples) |
|------|------|----------|
| **Unit / assertion** | every commit | output is valid JSON, contains a citation, refuses an off-topic question |
| **Reference-based** | offline (before shipping) | compares the output to an expected answer |
| **LLM-as-judge** | offline and online | faithfulness, relevancy, rubric scores (G-Eval) |
| **Human eval** | periodically | expert labels, used to *calibrate* (check and tune) the LLM judges |
| **Online / production** | continuously | sampled real traffic scored by judges, user feedback, A/B tests |
| **Red-teaming** | before launch and periodically | jailbreaks, injections, PII leakage, bias |

What each kind means:

- **Unit / assertion evals** are cheap, deterministic checks written in plain code. They don't judge
  quality, only hard rules. *Example:* `assert json.loads(output)["category"] in {"refund", "shipping"}`.
  Run them on every commit because they cost almost nothing.
- **Reference-based evals** compare the answer to a known correct answer. **Exact match** works for short
  factual answers ("42", "Paris"). For longer answers, **semantic similarity** turns both texts into
  embeddings (lists of numbers that capture meaning) and measures how close they are, so "Refunds take 5
  business days" and "You'll get your money back within five working days" count as a match.
- **LLM-as-judge** uses a second (usually strong) LLM to grade the answer against a written rubric. It can
  judge things code can't, such as "is this answer supported by the documents?". **G-Eval** is a specific
  technique: you give the judge explicit evaluation steps ("1. List the claims in the answer. 2. Check each
  claim against the context. 3. Score 1 if all claims are supported"), which makes its scores more
  consistent.
- **Human eval** means domain experts label a sample of answers. It's slow and expensive, so you don't use
  it for every change. You use it to check that your LLM judges agree with humans.
- **Online evals** score a sample of *real* production conversations (for example 5% of them) with the
  same judges, plus thumbs-up/down feedback and **A/B tests** (two versions running side by side on split
  traffic).
- **Red-teaming** means deliberately attacking your own app: **jailbreaks** (prompts designed to make the
  model break its rules), **prompt injections** (hidden instructions in documents), attempts to extract
  personal data (**PII leakage**), and probes for biased answers.

---

## The RAG metric quartet (DeepEval / Ragas names)

A RAG app has two parts that can fail independently: the **retriever** (searches your documents and
returns the most relevant **chunks**, which are short passages) and the **generator** (the LLM that writes
the answer from those chunks). Good metrics tell you *which* part failed.

```
              question ──► RETRIEVER ──► context ──► GENERATOR ──► answer
                                │                         │
   Contextual PRECISION: are relevant chunks        FAITHFULNESS: is the answer supported
     ranked at the top?                               by the context? (hallucination)
   Contextual RECALL: does context contain          ANSWER RELEVANCY: does the answer
     everything needed for the expected answer?       address the question?
   Contextual RELEVANCY: how much of the
     context is actually relevant? (noise)
```

**How to read it:** the left-hand metrics grade the retriever (did it fetch the right material?). The
right-hand metrics grade the generator (did it use that material well?). Together they point you at the
part that needs fixing.

Each metric with an example. Question: *"How long do refunds take for orders paid by card?"* The policy
says: "Card refunds take 5–7 business days; PayPal refunds take 24 hours."

- **Contextual recall**: does the retrieved context contain *everything* needed for the correct answer?
  If retrieval returned only the PayPal paragraph, recall is low: the answer can't be right because the
  needed fact never reached the model.
- **Contextual precision**: are the relevant chunks **ranked near the top**? If the card-refund chunk is
  5th out of 5, behind four chunks about shipping, precision is low. Models pay less attention to material
  buried in the middle.
- **Contextual relevancy**: what fraction of the retrieved text is relevant at all? Five chunks of which
  one is useful means lots of **noise**, which costs tokens and can distract the model.
- **Faithfulness**: is every claim in the answer supported by the retrieved context? If the answer says
  "3 business days", which appears nowhere in the context, that's a **hallucination** (an invented fact)
  and faithfulness is low.
- **Answer relevancy**: does the answer address the question asked? "Our refund policy is designed to be
  fair to all customers" is faithful but doesn't answer "how long".

**Diagnose by component. Each low score points to a different fix:**
- **Low recall**: the right information isn't being found. Fix how documents are split into chunks
  (**chunking**), the retrieval method, or retrieve more chunks (raise **k**, the number of chunks
  returned).
- **Low precision**: the right chunk is found but ranked too low. Add a **reranker**, a second model that
  re-sorts the retrieved chunks by how well they actually match the question.
- **Low faithfulness while the context is good**: the model is ignoring or embellishing the sources. Fix
  the prompt ("answer only from the context; say you don't know otherwise") or use a stronger model.
- **Low answer relevancy**: the prompt is unclear, or the user's question needs **query rewriting**
  (having the LLM rephrase a vague question into a clear search query before retrieval).

---

## Agent metrics

Agents take several steps (thinking, calling tools, reading results), so judging only the final answer
misses a lot.

- **Task completion**: did the agent achieve the user's goal? *Example:* the user asked to change a
  delivery address; was the address actually changed in the system?
- **Tool correctness**: did it call the right tools, with correct arguments? Calling
  `update_address(order="ORD-1001", ...)` for the wrong order is a failure even if the reply sounds
  confident.
- **Step efficiency**: how many steps, tokens, and dollars did it use compared with an ideal path? An agent
  that gets there in 12 tool calls when 3 would do is slow and expensive, and is often confused.
- **Trajectory eval**: judge the whole sequence of actions (the **trajectory**), not only the final answer.
  An agent might reach the right answer by luck after calling a dangerous tool it shouldn't have touched.

---

## LLM-as-judge pitfalls

LLM judges are useful but have known biases:

- **Position bias**: when comparing two answers, judges tend to prefer whichever is shown first (or second,
  depending on the model). Fix: run the comparison both ways round and average.
- **Verbosity bias**: judges tend to rate longer answers as better, even when the extra text adds nothing.
- **Self-preference**: a judge tends to favor answers written by its own model family.

How to reduce these:
- Use a **strong judge model**.
- Write an **explicit rubric with evaluation steps** (the G-Eval approach described above).
- Prefer **binary or low-cardinality scores** ("supported: yes/no", or a 1–3 scale) over 1–10. "Low
  cardinality" means few possible values. Judges are far more consistent at yes/no than at telling a 6
  from a 7.
- **Calibrate against about 50 human labels.** Have experts label 50 answers, run the judge on the same
  50, and measure how often they agree. If agreement is 92%, you can trust the judge for that metric. If
  it's 65%, fix the rubric before relying on it.

---

## The eval dataset ("goldens")

A **golden** is one test case: an input question plus the expected answer (and often the expected source
document). The collection of goldens is your eval dataset.

- **Start with 30–100 hand-written cases** covering:
  - the **happy path** (normal, common questions),
  - **edge cases** (unusual but valid: "I paid with two cards, how long is my refund?"),
  - **out-of-scope** questions the bot should decline,
  - **adversarial** inputs (attempts to trick or break it).
- **Add synthetic cases.** Tools such as DeepEval's `Synthesizer` read your documents and generate
  question-answer pairs automatically. This is fast, but generated cases can be wrong or unrealistic, so
  a person must review them before they count.
- **Every production bug becomes a new golden.** Once fixed, that bug is tested forever. The dataset is a
  living asset: keep it under version control like code, so you know which version a score came from.

---

## Workflow

1. **Run evals locally while you iterate** (`deepeval test run`), the same way you'd run unit tests.
2. **Gate pull requests in CI.** **CI** (continuous integration) runs automatically on every pull
   request. Make it fail when a score drops below a threshold, so a regression can't be merged. See
   `03_ci_eval_gate.py`.
3. **Track scores over time** on a dashboard (Confident AI or LangSmith). A slow drift from 0.91 to 0.84
   over a month is easy to miss in a single run but obvious on a chart. A drop like this is called a
   **regression**.
4. **Do error analysis.** Read the failures, group them into categories, and fix the biggest category
   first. Metrics tell you *that* something broke. Reading the **traces** (the step-by-step record of each
   request) tells you *why*.
