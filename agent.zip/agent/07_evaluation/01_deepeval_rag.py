"""
01 — EVALUATING RAG WITH DEEPEVAL
==================================

CONCEPT DEEP DIVE: DEEPEVAL BUILDING BLOCKS
-------------------------------------------
- LLMTestCase: one interaction to score.
      input              → the user question
      actual_output      → what YOUR app answered
      expected_output    → reference answer (needed for some metrics, e.g. contextual recall)
      retrieval_context  → chunks YOUR retriever returned (needed for RAG metrics)
      context            → ground-truth context (for HallucinationMetric)
- Metric: scores a test case 0–1 and passes if score >= threshold. Most metrics are
  LLM-as-judge under the hood and return a `.reason` — read the reasons, they're gold for
  debugging.
- Golden: a dataset row WITHOUT actual_output. At eval time you run your app on each
  golden to produce test cases. Separating goldens from outputs lets you re-run the same
  dataset against every new version of the app.
- evaluate(): batch-run metrics on many test cases (for scripts/notebooks).
- assert_test(): pytest-style; fails the test if any metric fails (for CI).
  Run with: `deepeval test run 07_evaluation/01_deepeval_rag.py`

GEval: define a CUSTOM metric in natural language. Under the hood it turns your criteria
into evaluation steps (chain-of-thought) and scores with token probabilities for a smoother
score. Use it for business-specific quality: tone, policy compliance, completeness.
"""

import pytest
from deepeval import assert_test, evaluate
from deepeval.dataset import EvaluationDataset, Golden
from deepeval.metrics import (
    AnswerRelevancyMetric,
    ContextualPrecisionMetric,
    ContextualRecallMetric,
    FaithfulnessMetric,
    GEval,
)
from deepeval.test_case import LLMTestCase, LLMTestCaseParams

JUDGE = "gpt-4o"  # Judge should be at least as strong as the model being judged.


# ---------------------------------------------------------------- the app under test
def my_rag_app(question: str) -> tuple[str, list[str]]:
    """Replace with your real pipeline; must return (answer, retrieved_chunks).
    Returning the retrieved chunks is why you should design apps to be OBSERVABLE —
    you can't evaluate the retriever if the app hides what it retrieved."""
    chunks = ["Customers can request a full refund within 30 days of delivery. Items must be unused."]
    return "You can get a full refund within 30 days of delivery if the item is unused [policies.md].", chunks


# ---------------------------------------------------------------- the dataset
GOLDENS = [
    Golden(
        input="Can I return headphones after 3 weeks?",
        expected_output="Yes, refunds are allowed within 30 days of delivery if the item is unused.",
    ),
    Golden(
        input="Who is the CEO?",  # out-of-scope → correct behavior is refusal
        expected_output="I don't know based on the available documents.",
    ),
]
dataset = EvaluationDataset(goldens=GOLDENS)


# ---------------------------------------------------------------- metrics
metrics = [
    # GENERATOR metrics
    FaithfulnessMetric(threshold=0.8, model=JUDGE, include_reason=True),
    AnswerRelevancyMetric(threshold=0.7, model=JUDGE),
    # RETRIEVER metrics (need expected_output + retrieval_context)
    ContextualPrecisionMetric(threshold=0.7, model=JUDGE),
    ContextualRecallMetric(threshold=0.7, model=JUDGE),
    # CUSTOM business metric via G-Eval
    GEval(
        name="Policy-compliant support answer",
        evaluation_steps=[
            "Check the answer cites a source in square brackets when it states a policy.",
            "Check the answer does not promise anything not stated in the retrieval context.",
            "If the question is outside the documents, the answer must refuse politely.",
            "Penalize answers longer than 3 sentences.",
        ],
        evaluation_params=[
            LLMTestCaseParams.INPUT,
            LLMTestCaseParams.ACTUAL_OUTPUT,
            LLMTestCaseParams.RETRIEVAL_CONTEXT,
        ],
        threshold=0.7,
        model=JUDGE,
    ),
]


def build_test_cases() -> list[LLMTestCase]:
    cases = []
    for g in dataset.goldens:
        answer, chunks = my_rag_app(g.input)
        cases.append(
            LLMTestCase(
                input=g.input,
                actual_output=answer,
                expected_output=g.expected_output,
                retrieval_context=chunks,
            )
        )
    return cases


# ---------------------------------------------------------------- mode 1: pytest / CI
@pytest.mark.parametrize("test_case", build_test_cases())
def test_rag(test_case: LLMTestCase):
    assert_test(test_case, metrics)


# ---------------------------------------------------------------- mode 2: script / notebook
if __name__ == "__main__":
    results = evaluate(test_cases=build_test_cases(), metrics=metrics)
    # Each metric exposes .score and .reason per test case — do ERROR ANALYSIS on the reasons.


# ---------------------------------------------------------------- bootstrapping goldens
def synthesize_goldens():
    """Synthetic data generation from your docs. Great for coverage; ALWAYS human-review
    a sample — synthetic questions skew easy and miss how real users phrase things."""
    from deepeval.synthesizer import Synthesizer

    synth = Synthesizer(model=JUDGE)
    goldens = synth.generate_goldens_from_docs(
        document_paths=["data/policies.md"],
        include_expected_output=True,
    )
    return EvaluationDataset(goldens=goldens)
