"""
03 — EVALS AS A CI GATE (regression testing for prompts and models)
====================================================================

CONCEPT DEEP DIVE
-----------------
Treat prompt/model/retrieval changes like code changes: they must pass tests before merge.

     PR opened ──► CI job ──► run app on golden set ──► compute metrics ──► compare to thresholds
                                                                         and to main-branch baseline
                                                     ──► fail PR if regression > tolerance

Practical tips:
- Keep a FAST tier (≈30 goldens, deterministic checks + 1–2 judge metrics) on every PR, and a
  FULL tier (hundreds of goldens, all metrics, red-team) nightly or pre-release.
- Compare against the BASELINE, not just absolute thresholds: "faithfulness dropped 0.91 → 0.84"
  is the signal that matters.
- LLM judges are noisy: use temperature 0, average over the dataset, and allow a small tolerance.
- Cache app outputs per commit so re-running metrics doesn't re-call the app.

Example GitHub Actions step:

    - name: LLM evals
      run: deepeval test run apps/support_copilot/evals/test_support_copilot.py
      env:
        OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}

The script below shows the baseline-comparison logic DeepEval doesn't do for you out of the box.
"""

import json
import sys
from pathlib import Path

BASELINE_FILE = Path("eval_baseline.json")
TOLERANCE = 0.03  # allowed drop before failing


def gate(current: dict[str, float]) -> int:
    if not BASELINE_FILE.exists():
        BASELINE_FILE.write_text(json.dumps(current, indent=2))
        print("No baseline found; saved current scores as baseline.")
        return 0

    baseline = json.loads(BASELINE_FILE.read_text())
    failures = []
    for metric, score in current.items():
        base = baseline.get(metric)
        if base is not None and score < base - TOLERANCE:
            failures.append(f"{metric}: {base:.3f} → {score:.3f}")

    if failures:
        print("EVAL REGRESSION:\n  " + "\n  ".join(failures))
        return 1
    print("Evals OK:", current)
    return 0


if __name__ == "__main__":
    # In practice: aggregate mean scores per metric from deepeval's evaluate() results.
    current_scores = {"faithfulness": 0.92, "answer_relevancy": 0.88, "contextual_recall": 0.81}
    sys.exit(gate(current_scores))
