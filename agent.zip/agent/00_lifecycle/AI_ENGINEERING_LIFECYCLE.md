# The AI Engineering Lifecycle

Classic ML lifecycle: *collect data → train model → deploy*.
AI engineering (building on foundation models) flips it: the model already exists; your job is
**system design, context engineering, evaluation, and operations** around it.

```
 ┌─────────┐   ┌──────┐   ┌───────────┐   ┌──────────┐   ┌────────┐   ┌────────┐   ┌─────────┐   ┌─────────┐
 │1 Define │──►│2 Data│──►│3 Prototype│──►│4 Evaluate│──►│5 Harden│──►│6 Deploy│──►│7 Observe│──►│8 Improve│
 └─────────┘   └──────┘   └───────────┘   └──────────┘   └────────┘   └────────┘   └─────────┘   └────┬────┘
      ▲                                         ▲                                                    │
      └─────────────────────────────────────────┴──────────── feedback loop ─────────────────────────┘
```

---

## 1. Define the problem (most skipped, most important)

Questions to answer in writing before touching code:

- **Who is the user and what job are they doing?** "Support agents answering refund questions" not "a chatbot".
- **What does success look like, measurably?** e.g. "≥85% answers rated correct, ≤5% hallucination, p95 latency < 4s, cost < $0.01/query".
- **Is an LLM even the right tool?** If a regex, SQL query, or rules engine works, use it.
- **What's the risk profile?** Medical/financial/legal → stricter guardrails, human review.
- **Autonomy level** — pick the *lowest* that works:

| Level | Pattern | Example |
|-------|---------|---------|
| 0 | Single LLM call | Summarize this email |
| 1 | Chain / workflow (fixed steps) | Extract → classify → route |
| 2 | Single agent with tools (loop) | Support bot that looks up orders |
| 3 | Multi-agent | Research team: researcher + writer + critic |

> Anthropic's "Building effective agents" guidance: prefer **workflows** (predictable code paths)
> when the steps are known; use **agents** (LLM decides the path) only when the path is open-ended.

## 2. Data & context

- Gather the **knowledge sources** (docs, tickets, DB tables) → this becomes RAG.
- Build an **eval dataset FIRST**: 30–100 realistic questions with expected answers / expected
  context. Mine real logs if you have them. Include adversarial and out-of-scope cases.
- Decide data freshness, access control (who can see which docs?), and PII handling.

## 3. Prototype

- Start with the strongest model to find the **ceiling** of quality; optimize cost later.
- Prompt → add RAG → add tools → add agent loop → (only if needed) multi-agent.
- Keep prompts in versioned files, not scattered strings.
- Use structured outputs (Pydantic) wherever code consumes model output.

## 4. Evaluate (the core discipline)

- **Offline evals**: run the eval set on every change (DeepEval / Ragas / LangSmith).
  - RAG: faithfulness, answer relevancy, contextual precision/recall.
  - Agents: task completion, tool-call correctness, steps taken, cost.
  - Safety: toxicity, bias, PII leaks, jailbreak resistance (red-teaming).
- **Error analysis** > metrics: read 50 failures by hand, bucket them, fix the biggest bucket.
- Gate merges in CI on eval thresholds (see `07_evaluation/03_ci_eval_gate.py`).

## 5. Harden

- Guardrails (input, tool, output) — `06_guardrails/`.
- Bounded loops, timeouts, retries with backoff, fallbacks to cheaper/alternate models.
- Prompt-injection defenses for anything that reads untrusted content (web pages, emails, docs).
- Least-privilege tools; human-in-the-loop for irreversible actions (refunds, emails, deletes).

## 6. Deploy

- Serve behind an API (FastAPI), stream tokens for UX, async for concurrency.
- Persist agent state (LangGraph checkpointer → Postgres/Redis) so runs survive restarts.
- Feature flags / canary / A-B for prompt and model changes — prompts are code.

## 7. Observe

- Trace every run: prompt, retrieved docs, tool calls, tokens, latency, cost (LangSmith / Langfuse).
- Online evals: sample production traffic and score it with LLM-as-judge.
- Collect user feedback (thumbs up/down) and link it to traces.
- Dashboards + alerts: error rate, p95 latency, cost/day, guardrail trigger rate.

## 8. Improve

- Turn production failures into new eval cases (the eval set grows forever).
- Iterate: prompt → retrieval (chunking, reranking) → tools → model choice → fine-tuning (last resort).
- Cost optimization: model routing (small model for easy queries), caching, shorter context.

---

## Mapping to this repo

| Lifecycle stage | Where to look |
|-----------------|---------------|
| Define | this file, `apps/*/README.md` |
| Data | `04_rag/01_rag_from_scratch.py`, `apps/support_copilot/ingest.py` |
| Prototype | `01_foundations/`, `02_single_agent/`, `03_multi_agent/` |
| Evaluate | `07_evaluation/`, `apps/support_copilot/evals/` |
| Harden | `06_guardrails/`, `08_production/02_reliability_patterns.py` |
| Deploy | `apps/support_copilot/api.py`, `08_production/PRODUCTION_CONCEPTS.md` |
| Observe | `08_production/01_observability.py` |
| Improve | `07_evaluation/`, feedback endpoint in `apps/support_copilot/api.py` |
