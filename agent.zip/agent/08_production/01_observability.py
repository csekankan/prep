"""
01 — OBSERVABILITY: tracing, metadata, and feedback
====================================================

CONCEPT DEEP DIVE
-----------------
LLM apps are non-deterministic, multi-step, and fail "softly" (a plausible wrong answer
raises no exception). Traditional logs aren't enough; you need TRACES that capture the
full tree of what happened for each request.

LangSmith: for LangChain/LangGraph, tracing is ZERO-CODE — set env vars:
    LANGSMITH_TRACING=true
    LANGSMITH_API_KEY=...
    LANGSMITH_PROJECT=my-app
Every chain, graph node, LLM call, retriever and tool becomes a span automatically.

For non-LangChain code, decorate functions with @traceable (LangSmith) or @observe (Langfuse).

What to attach to traces:
  - tags:     ["prod", "v2-prompt"]                 → filter & compare versions
  - metadata: {"user_id", "tenant", "prompt_version"} → slice metrics by segment
  - run_name: human-readable span names              → readable trace trees
  - feedback: user thumbs up/down linked to run_id   → find bad traces fast, build eval sets
"""

import time
import uuid

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langsmith import Client, traceable

load_dotenv()
llm = init_chat_model("openai:gpt-4o-mini", temperature=0)


@traceable(run_type="retriever", name="kb_search")
def retrieve(query: str) -> list[str]:
    # Custom (non-LangChain) code gets its own span with inputs/outputs captured.
    return ["Refunds within 30 days."]


@traceable(name="support_answer")
def answer(question: str) -> str:
    docs = retrieve(question)
    # Passing config with tags/metadata attaches them to this LLM span.
    return llm.invoke(
        f"Context: {docs}\nQ: {question}",
        config={"tags": ["prod", "prompt-v3"], "metadata": {"prompt_version": "v3"}, "run_name": "generate"},
    ).content


def record_feedback(run_id: str, thumbs_up: bool, comment: str = "") -> None:
    """Called from your /feedback API endpoint. Links the user's rating to the exact trace —
    negative-feedback traces are the best source of new eval cases."""
    Client().create_feedback(run_id=run_id, key="user_rating", score=1 if thumbs_up else 0, comment=comment)


# ---------------------------------------------------------------- minimal homegrown metrics
class RequestMetrics:
    """What to emit per request to your metrics system (Prometheus/Datadog/CloudWatch),
    in addition to traces. Alert on: error rate, p95 latency, cost/hour, guardrail block
    rate, refusal rate ("I don't know" spikes = retrieval broke)."""

    def __init__(self):
        self.request_id = str(uuid.uuid4())
        self.start = time.perf_counter()
        self.tokens_in = self.tokens_out = 0
        self.flags: list[str] = []

    def add_usage(self, usage: dict | None):
        if usage:
            self.tokens_in += usage.get("input_tokens", 0)
            self.tokens_out += usage.get("output_tokens", 0)

    def cost_usd(self, in_price_per_m=0.15, out_price_per_m=0.60) -> float:
        # Keep a price table per model in config; prices change.
        return self.tokens_in / 1e6 * in_price_per_m + self.tokens_out / 1e6 * out_price_per_m

    def finish(self) -> dict:
        return {
            "request_id": self.request_id,
            "latency_ms": round((time.perf_counter() - self.start) * 1000),
            "tokens_in": self.tokens_in,
            "tokens_out": self.tokens_out,
            "cost_usd": round(self.cost_usd(), 6),
            "flags": self.flags,
        }
