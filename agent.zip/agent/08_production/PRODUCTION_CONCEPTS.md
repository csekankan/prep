# Production Concepts for AI Systems

A prototype that answers questions in a notebook is maybe 20% of the work. The other 80% is making it
**correct, fast, cheap, safe, and debuggable** when thousands of real users hit it every day. This file
explains the core ideas you need for that, each with a plain-language definition and an example. The
code that demonstrates them lives in `01_observability.py` and `02_reliability_patterns.py`.

---

## 1. Context engineering (the meta-skill)

**What it is.** An LLM knows nothing about your request except the text you send it in that one call.
That text is called the **context** (or the **context window**, which is the maximum amount of text the
model can read at once, measured in **tokens**; one token is roughly ¾ of an English word). Context
engineering means deliberately deciding *what* goes into that text and *in what order*.

**Why it matters.** Almost every quality problem in an AI app ("it ignored my instruction", "it made up
a policy", "it used the wrong tool") traces back to the context: something important was missing,
buried, or drowned out by irrelevant text. Every piece is a design decision:

- the **system prompt** (the standing instructions: role, rules, tone),
- **tool descriptions** (what each function does and when to call it),
- **retrieved chunks** (passages pulled from your documents by RAG, see `04_rag/`),
- **memories** (saved facts about the user, see `05_memory/`),
- the **conversation history**,
- **examples** of good answers (called *few-shot examples*).

### Principles

**Minimal sufficient context.** Include everything the model needs for this request, and nothing more.
Two reasons. First, cost: you pay per token, every call. Second, quality: the model spreads its
attention over everything you send, so 20 irrelevant paragraphs make it more likely to miss the one
relevant sentence.
*Example:* a support bot that pastes the entire 80-page refund policy into every prompt costs about
40,000 tokens per question and still sometimes quotes the wrong section. Retrieving only the 3 most
relevant paragraphs (about 1,200 tokens) is ~30× cheaper and usually *more* accurate.

**Order matters.** Models pay the most attention to the **beginning** and the **end** of the context and
the least to the middle. Researchers call this the "lost in the middle" effect. The tendency to weight
the most recent text heavily is called **recency**. So put the instructions at the start (system prompt),
put the facts the answer depends on near the end (just before the user's question), and don't bury a
key rule on page 4 of a long document dump.
*Example:* a rule "never promise a refund over $500" placed between two long retrieved documents gets
ignored now and then. Moving it into the system prompt, and repeating it in one line right before the
question, fixes it.

**Compaction.** Conversations and agent runs grow every turn, and eventually they don't fit (or become
expensive and slow). Compaction means shrinking old content while keeping what matters:
- *Summarize* older turns into a short running summary ("User is asking about order ORD-1001, which
  arrived damaged; they want a replacement, not a refund").
- *Offload* large tool outputs. Instead of putting a 5,000-line log file into the context, save it to a
  file or the agent's state and give the model a short reference plus the 20 relevant lines.

**Sub-agents for context isolation.** When a task requires reading a lot of material, give it to a
separate agent with its own fresh context. It reads 50 pages and returns a 1-paragraph result, and only
that paragraph enters the main agent's context. The main agent stays focused and cheap. See
`03_multi_agent/` for how this is wired.

---

## 2. Observability

**What it is.** Observability is being able to answer "what exactly happened in this request, and why?"
after the fact, without re-running it. In normal web apps you look at logs. In AI apps that's not enough,
because one user question can trigger many hidden steps: a retrieval, three LLM calls, two tool calls,
and a retry.

**Traces and spans.** A **trace** is the full record of one request. It is a tree of **spans**, where each
span is one step: an LLM call, a retrieval, a tool call, or a node in a LangGraph graph. Each span records
its inputs, outputs, number of tokens, **latency** (how long it took), cost, and any error.

```
trace: "Where is my order ORD-1001?"            total 3.4 s, $0.004
├── span: retrieve_docs        0.3 s   -> 3 chunks (ids: faq_12, policy_4, faq_31)
├── span: llm_call (decide)    1.1 s   -> wants tool lookup_order(ORD-1001)
├── span: tool lookup_order    0.2 s   -> {"status": "shipped", "eta": "Nov 14"}
└── span: llm_call (answer)    1.8 s   -> "Your order shipped and should arrive Nov 14."
```

**How to read it:** each indented line is one step inside the request, with its timing and result. If a
user reports a wrong answer, you open this trace and can see immediately whether retrieval found the
wrong document, the tool returned bad data, or the model misread correct data. Each of those has a
different fix.

**Tools.**
- **LangSmith**: the tracing product from the LangChain team. It works with LangChain and LangGraph
  automatically once you set the environment variable `LANGSMITH_TRACING=true` (plus an API key).
- **Langfuse**: an open-source alternative that you can host yourself, useful when data can't leave
  your network.
- **Arize Phoenix**: another open-source tracing and evaluation tool.
- **OpenTelemetry GenAI conventions**: OpenTelemetry is the industry-standard format for traces in
  general software. Its "GenAI semantic conventions" define standard field names for LLM calls (model,
  tokens, and so on), so any compatible backend can display your traces.

**What to log on every request.**

| Field | What it is | Why you want it |
|---|---|---|
| `request_id` | unique id for this request | find the exact trace when a user complains |
| `user_id`, `thread_id` | who asked, and which conversation | per-user debugging, abuse detection |
| `model`, `prompt_version` | which model and which version of the prompt answered | compare quality after a change |
| `tokens_in` / `tokens_out` | tokens sent and received | cost, and spotting prompts that grew |
| `cost`, `latency` | dollars and seconds | budgets and speed targets |
| `guardrail_flags` | which safety checks fired | spot attacks or over-blocking |
| `retrieved_doc_ids` | which documents RAG used | debug wrong or outdated answers |
| `feedback` | user thumbs up or down, linked to the trace | find real failures to fix |

*Example:* after a prompt change, thumbs-down feedback rises from 4% to 9%. Because every log line has
`prompt_version`, you filter by version, confirm that the new prompt is the cause, and roll back in
minutes instead of guessing.

---

## 3. Reliability

LLM calls fail far more often than database calls: providers rate-limit you, have outages, respond
slowly, and sometimes return malformed output. Reliability patterns make your app survive all of that.

| Problem | Pattern |
|---|---|
| Rate limits or server errors (HTTP 429 / 5xx) | Retry with exponential backoff and jitter (the `tenacity` library) |
| Provider outage | Model fallback chain (`llm.with_fallbacks([backup_llm])`) |
| Slow calls | A timeout on every LLM and tool call; stream the answer to the user |
| Agent loops that never end | `recursion_limit`, plus step and token budgets |
| Crash in the middle of a run | Durable checkpointer (Postgres), then resume from the last step |
| Bad structured output | Validate it, and retry with the error message ("reask") |

**Retry with exponential backoff and jitter.** Providers limit how many requests you may send per
minute. Past the limit they answer **HTTP 429** ("too many requests"), and when overloaded they answer
**5xx** server errors (500, 502, 503 and so on). Both are usually temporary, so the right move is to wait
and try again. **Exponential backoff** means each wait doubles (1 s, 2 s, 4 s, 8 s), giving the provider
time to recover. **Jitter** adds a small random amount to each wait, so that 500 clients that failed at
the same instant don't all retry at the same instant and cause a fresh spike.
*Example:* your batch job hits a 429 at 10:00:00. It retries after 1.3 s, then 2.1 s, then 4.4 s, and
succeeds on the third try. The Python library **tenacity** gives you this with one decorator. Only retry
errors that can heal by themselves: retrying a 400 "bad request" just fails again.

**Model fallback chain.** If your main provider is down, automatically send the request to a backup
model (another provider, or another region). In LangChain, `primary_llm.with_fallbacks([backup_llm])`
tries the primary and moves to the backup on error.
*Example:* during a 40-minute outage of provider A, requests transparently go to provider B. Users notice
slightly different wording, but nobody sees an error page.

**Timeouts and streaming.** Without a **timeout**, one stuck call can hang a user's request (and a server
worker) for minutes. Set an explicit limit on every LLM and tool call, for example 30 seconds. Separately,
**stream** the answer: send tokens to the browser as they are generated instead of waiting for the whole
answer. A 6-second answer that starts appearing after 0.5 s *feels* fast.

**Bounding agent loops.** An agent decides its own next step, so a confused agent can call the same tool
forever. LangGraph's `recursion_limit` caps the number of steps in one run (for example 25). Add a token
or dollar budget too, so one bad run can't cost $40.

**Durable checkpointer.** A **checkpointer** saves the agent's state after every step. If it saves to a
real database such as Postgres (rather than to memory), a crash or deploy in the middle of a 10-step run
doesn't lose the work. The run resumes from step 7 instead of starting over (and re-paying for steps 1–6).

**Validation and "reask".** When code depends on the model returning structured data (JSON matching a
schema), the output is sometimes wrong: a missing field, or text instead of a number. Validate it with
**Pydantic** (a Python library that checks data against a typed schema). If validation fails, call the
model again and include the error message. This is called a **reask**: "Your previous output failed
validation: field `amount` must be a number, got 'twenty'. Return corrected JSON." Models fix their own
mistake on the second try most of the time.

---

## 4. Cost and latency optimization

**Model routing / cascading.** Not every question needs your biggest, most expensive model. **Routing**
means a cheap classifier (a small model, or even rules) decides how hard a query is and sends easy ones
to a small model and hard ones to a large model. **Cascading** means trying the small model first and
escalating to the large one only if the answer looks low-confidence or fails a check.
*Example:* 70% of support questions are simple ("what are your opening hours?"). Sending those to a model
that costs 1/20th as much cuts the total bill by about 60%, with no visible quality drop.

**Prompt caching (on the provider's side).** Providers such as Anthropic, OpenAI, and AWS Bedrock can
remember the processed form of the *beginning* of your prompt. If the next call starts with exactly the
same text (the same system prompt, tool definitions, and reference documents), those cached tokens are
billed at a large discount (often 50–90% off) and processed faster. The rule: keep the static part
**identical and at the front**, and put the changing part (the user's question) at the end. Even one
changed character early on (say, a timestamp in the system prompt) breaks the cache.

**Semantic caching.** Your own cache of past answers, looked up by *meaning* rather than by exact text.
Each query is turned into an **embedding** (a list of numbers that represents its meaning, see `04_rag/`).
If a new query's embedding is very close to a cached one, you return the cached answer without calling
the LLM at all.
*Example:* "How do I reset my password?" and "password reset steps?" hit the same cached answer.
Be careful with personalized or time-sensitive questions: "What's my balance?" must never return
someone else's cached answer.

**Shorter outputs.** The model produces output one token at a time, so generating output is much slower
than reading input. Output tokens usually dominate latency (and cost more per token). Asking for "3
bullet points" instead of "a detailed explanation" can halve the response time.

**Parallelize independent calls.** If an agent needs three things that don't depend on each other
(search the docs, look up the order, check the account), run them at the same time instead of one after
another. In LangChain use `.batch()`, in plain Python `asyncio.gather()`, in LangGraph the `Send` API.
Three 1-second calls then take about 1 second instead of 3.

**Batch APIs for offline jobs.** For work that doesn't need an immediate answer (scoring 100,000 old
tickets overnight), providers offer **batch APIs**: you upload a file of requests and get results within
hours, at roughly 50% of the normal price.

---

## 5. MCP: Model Context Protocol

**What it is.** MCP is an open standard, originally published by Anthropic, for connecting AI
applications to tools and data. Think "USB-C for AI tools": before USB-C, every device needed its own
cable. Before MCP, every AI app had to write its own integration for GitHub, for Postgres, for Jira, and
so on.

**How it works.** You write a tool integration once, as an **MCP server**, for example a GitHub server,
a Postgres server, a Jira server, or one for your internal API. Any **MCP client** (Cursor, Claude Desktop,
or your own LangGraph agent through the `langchain-mcp-adapters` package) can then connect to it and use
it. A server can expose three kinds of things:
- **tools**: actions the model can call (for example `create_issue`, `run_query`),
- **resources**: data the app can read (for example a file or a database table),
- **prompts**: reusable prompt templates.

*Example:* your company writes one MCP server for its internal ticket system. Engineers can use it from
Cursor, the support team's chatbot can use it, and a nightly agent can use it, all without three separate
integrations.

**Security.** MCP servers perform real actions with real credentials. Treat them like any other tool:
give each server the **least privilege** it needs (read-only database user if it only reads), and assume
any text a tool returns could contain a **prompt injection** (hidden instructions planted in data, see
`06_guardrails/`).

**A2A (Agent-to-Agent protocol).** The complementary standard: MCP connects an agent to *tools*, while
A2A lets an agent talk to *other agents*, possibly built by other teams or vendors, for example your
travel-booking agent delegating to an airline's agent.

---

## 6. Deployment architecture (typical)

```
 client ──► API gateway (auth, rate-limit) ──► FastAPI service (stateless, async, SSE streaming)
                                                   │
                       ┌───────────────────────────┼──────────────────────────────┐
                       ▼                           ▼                              ▼
                 LangGraph runtime          Vector DB (pgvector/Qdrant)     Mem0 / memory store
                 + Postgres checkpointer    + ingestion workers             (background writes)
                       │
                       ▼
          LLM providers (primary + fallback)     Tracing (LangSmith/Langfuse)   Queue for HITL approvals
```

**How to read it:** a request comes in from the left. The **API gateway** is the front door: it checks who
the caller is (**auth**, authentication) and stops anyone sending too many requests (**rate limiting**).
It then forwards the request to your **FastAPI** service (FastAPI is a popular Python web framework). That
service runs the agent logic, which may read the vector database, read or write memories, and call LLM
providers. Every step is recorded in tracing. Risky actions wait in a queue for human approval.

**Terms in this diagram:**
- **Stateless**: the API server keeps nothing in its own memory between requests. All state lives in
  databases. That way you can run 10 copies behind a load balancer and any copy can serve any request.
- **Async**: the server handles other requests while waiting for a slow LLM response, instead of blocking
  one worker per request. One process can then serve hundreds of concurrent conversations.
- **SSE streaming**: **Server-Sent Events**, a simple web standard for the server to push a stream of
  messages over one HTTP connection. It's how tokens appear word by word in a chat UI.
- **LangGraph runtime + Postgres checkpointer**: the agent's step-by-step logic, with state saved to
  Postgres after every step (see section 3).
- **Vector DB (pgvector / Qdrant)**: a database that finds text by meaning. **pgvector** is an extension
  that adds this to Postgres. **Qdrant** is a dedicated vector database. See `04_rag/VECTOR_DB_SERVERS.md`.
- **Ingestion workers**: background jobs that read your documents, split them into chunks, embed them, and
  load them into the vector DB.
- **Mem0 / memory store (background writes)**: long-term memory about users (see `05_memory/`). Writes
  happen in the background after the answer is sent, so they don't slow the user down.
- **HITL approvals**: **human-in-the-loop**. Before an irreversible action (issue a refund, send an email),
  the agent pauses and puts the request in a queue for a person to approve.

**Design rules:**
- **Prompts and model names live in config or a registry, not in code.** Then you can change a prompt
  without redeploying, roll back instantly, and run an **A/B test** (send 10% of traffic to the new
  prompt and compare quality metrics).
- **Separate ingestion from serving.** Ingestion is heavy batch work that runs on a schedule. Serving must
  answer in seconds. If they share machines, a big nightly re-index slows down live users.
- **Multi-tenancy: put `tenant_id` everywhere.** A **tenant** is one customer organization in a shared
  system. Every vector search filter, every memory namespace, and every log line must include the tenant,
  so customer A can never retrieve customer B's documents. One missing filter is a data breach.

---

## 7. Fine-tuning: when (rarely, and last)

**What it is.** **Fine-tuning** means continuing to train a model on your own examples, so that the
behavior is baked into its weights instead of described in the prompt.

**Try the cheaper levers first, in this order:**
1. Improve the prompt (clearer instructions, a few examples).
2. Improve the context (better retrieval with RAG, better tool results).
3. Add or improve tools.
4. Try a stronger model.
5. Only then fine-tune.

Each step is cheaper, faster to iterate, and easier to undo than the next.

**Fine-tuning is good for:**
- a **consistent format or style** (always produce this exact JSON shape, always write in the brand voice);
- **domain jargon** the base model handles poorly;
- **distillation**: training a small, cheap model to imitate a big model's answers on your task, so you
  get near-big-model quality at small-model price and speed;
- **latency**: a fine-tuned small model can replace a long prompt with many examples, so each call is
  shorter and faster.

**Fine-tuning is not for adding facts.** If the model needs to know your current price list or this
week's policy, use RAG. Facts change, and a fine-tuned model can't cite where a fact came from and will
still make things up confidently.

**You need an eval set first.** An **eval set** is a fixed collection of test questions with known good
answers (see `07_evaluation/`). Without one, you can't tell whether the fine-tuned model is better or
merely different.

*Example:* a team fine-tuned to "teach the model our product catalog". A month later the catalog changed,
and the model kept recommending discontinued items. They switched to RAG over the catalog and used
fine-tuning only to make a small model output the required JSON format reliably.

---

## 8. Security and compliance checklist

- **Secrets in a secret manager, never in prompts.** API keys and passwords belong in a service such as
  AWS Secrets Manager or HashiCorp Vault. Anything placed in a prompt can be repeated back by the model
  to a clever user.
- **Redact PII before LLM calls and before logging.** **PII** is personally identifiable information:
  names, emails, phone numbers, card numbers, national IDs. Replace it with placeholders
  (`<EMAIL_1>`) before it leaves your system or lands in log files that many engineers can read.
- **Retention policies and deletion.** Decide how long traces and memories are kept (for example 30
  days), and give users an endpoint to delete their data. Laws such as the EU's **GDPR** require it.
- **Read the provider's data-usage terms.** Check whether the provider stores your prompts or uses them
  for training. For sensitive data, ask for a **zero data retention** agreement, where the provider
  promises not to store requests at all.
- **Audit log of every tool action.** Record every action an agent takes (refund issued, email sent,
  record deleted), with the user it acted for and the time. When something goes wrong, you can see who
  triggered what, and you can prove it to auditors.
