# Production Concepts for AI Systems

## 1. Context engineering (the meta-skill)

Everything the model sees is a design decision: system prompt, tool descriptions, retrieved
chunks, memories, history, examples. Principles:

- **Minimal sufficient context** — every irrelevant token dilutes attention and costs money.
- **Order matters** — instructions at the start, critical facts near the end (recency), avoid burying key info in the middle.
- **Compaction** — summarize long histories; offload large tool outputs to files/state and pass references.
- **Sub-agents for context isolation** — let a sub-agent read 50 pages and return 1 paragraph.

## 2. Observability

Trace = a tree of spans (LLM calls, retrievals, tool calls, graph nodes) with inputs, outputs,
tokens, latency, cost, errors. Tools: **LangSmith** (native for LangChain/LangGraph — set
`LANGSMITH_TRACING=true`), **Langfuse** (open source), Arize Phoenix, OpenTelemetry GenAI conventions.

Log per request: `request_id, user_id, thread_id, model, prompt_version, tokens_in/out, cost,
latency, guardrail_flags, retrieved_doc_ids, feedback`.

## 3. Reliability

| Problem | Pattern |
|---|---|
| Rate limits / 5xx | Retry with exponential backoff + jitter (tenacity) |
| Provider outage | Model fallback chain (`llm.with_fallbacks([backup_llm])`) |
| Slow calls | Timeouts on every LLM/tool call; stream to user |
| Agent loops | recursion_limit, step and token budgets |
| Crash mid-run | Durable checkpointer (Postgres) → resume from last step |
| Bad structured output | Validation + retry with the error message ("reask") |

## 4. Cost & latency optimization

- **Model routing / cascading**: classify query difficulty; send easy ones to a small model.
- **Prompt caching** (provider-side): keep the static prefix (system prompt, tools, docs) identical
  across calls → big discounts and lower latency on cached tokens.
- **Semantic caching**: cache answers keyed by query embedding; return cached answer when a new
  query is very similar (careful with personalized/fresh data).
- **Shorter outputs**: output tokens dominate latency.
- **Parallelize** independent calls (`.batch`, `asyncio.gather`, LangGraph `Send`).
- **Batch APIs** for offline jobs (≈50% cheaper, async).

## 5. MCP — Model Context Protocol

An open standard (originally from Anthropic) for connecting AI apps to tools and data.
Think "USB-C for AI tools": write a tool server once (MCP server: GitHub, Postgres, Jira, your
internal API), and any MCP client (Cursor, Claude Desktop, your LangGraph agent via
`langchain-mcp-adapters`) can use it. Exposes **tools**, **resources** (readable data),
and **prompts**. Security: MCP servers execute real actions → apply the same least-privilege
and injection precautions as any tool.

A2A (Agent-to-Agent protocol) is the complementary standard for agents talking to *other agents*
across services/vendors.

## 6. Deployment architecture (typical)

```
 client ──► API gateway (auth, rate-limit) ──► FastAPI service (stateless, async, SSE streaming)
                                                   │
                       ┌───────────────────────────┼──────────────────────────────┐
                       ▼                           ▼                              ▼
                 LangGraph runtime          Vector DB (pgvector/Qdrant)     Mem0 / memory store
                 + Postgres checkpointer    + ingestion workers             (background writes)
                       │
                       ▼
          LLM providers (primary + fallback)     Tracing (LangSmith/Langfuse)   Queue for HITL approvals
```

- Prompts and model names in config/registry, not code → change without redeploy, A/B test.
- Separate ingestion (batch, scheduled) from serving.
- Multi-tenancy: tenant_id in every vector metadata filter, memory namespace, and log line.

## 7. Fine-tuning: when (rarely, and last)

Order of levers: prompt → RAG/context → tools → better model → **fine-tune**.
Fine-tune for: consistent format/style, domain jargon, distilling a big model's behavior into a
small cheap one, latency. Not for: adding facts (use RAG). Requires a good eval set first — otherwise
you can't tell if it helped.

## 8. Security & compliance checklist

- Secrets in a secret manager; never in prompts.
- PII redaction before LLM calls and before logging.
- Data retention policies for traces and memories; user deletion endpoints.
- Provider data-usage terms (zero data retention agreements for sensitive data).
- Audit log of every tool action an agent takes, attributed to the user it acted for.
