"""
02 — RELIABILITY & COST PATTERNS: retries, fallbacks, timeouts, routing, caching
=================================================================================

CONCEPT DEEP DIVE
-----------------
LLM APIs are a flaky, slow, metered dependency. Treat them like any unreliable network
service — plus a few LLM-specific tricks:

1. RETRY with exponential backoff + jitter on 429 (rate limit) and 5xx. Do NOT retry on
   400 (bad request) — it will fail again and waste money.
2. FALLBACK to another model/provider when the primary is down.
3. TIMEOUT every call; a hung request holds a worker forever.
4. MODEL ROUTING: cheap model for easy requests, strong model for hard ones.
5. SEMANTIC CACHE: reuse answers for near-duplicate questions.
6. STRUCTURED-OUTPUT REPAIR: on validation error, retry once with the error message.
"""

import hashlib
from typing import Literal

import numpy as np
from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_openai import OpenAIEmbeddings
from pydantic import BaseModel, ValidationError
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_random_exponential

load_dotenv()

# ---------------------------------------------------------------- 1-3. retries, timeouts, fallbacks
# Most LangChain chat models accept timeout and max_retries directly (built-in backoff).
primary = init_chat_model("openai:gpt-4o-mini", temperature=0, timeout=20, max_retries=3)
backup = init_chat_model("anthropic:claude-haiku-4-5", temperature=0, timeout=20, max_retries=2)

# with_fallbacks returns a Runnable that tries `primary`, and on exception tries `backup`.
# Fallback prompts may need adapting per provider — test both paths in evals!
resilient_llm = primary.with_fallbacks([backup])


class TransientError(Exception):
    pass


# For your own tool calls / HTTP APIs, use tenacity:
@retry(
    retry=retry_if_exception_type(TransientError),
    wait=wait_random_exponential(multiplier=1, max=30),  # jitter avoids thundering herds
    stop=stop_after_attempt(4),
    reraise=True,
)
def call_flaky_tool(payload: dict) -> dict:
    ...


# ---------------------------------------------------------------- 4. model routing
class Difficulty(BaseModel):
    level: Literal["simple", "complex"]


router = init_chat_model("openai:gpt-4o-mini", temperature=0).with_structured_output(Difficulty)
strong = init_chat_model("openai:gpt-4o", temperature=0)


def routed_answer(question: str) -> str:
    """The routing call costs a little but can save a lot if most traffic is simple.
    Validate with evals: quality on 'simple' routes must not drop."""
    level = router.invoke(f"Is this question simple (lookup/short) or complex (multi-step reasoning)? {question}").level
    model = primary if level == "simple" else strong
    return model.invoke(question).content


# ---------------------------------------------------------------- 5. semantic cache
class SemanticCache:
    """Exact-match cache misses "refund policy?" vs "what's your refund policy". A semantic
    cache matches by embedding similarity. Risks: serving a cached answer to a question that's
    similar but different ("refund for digital goods?") → keep the threshold high (≈0.95),
    scope by tenant/user where answers are personal, and set TTLs for freshness."""

    def __init__(self, threshold: float = 0.95):
        self.embedder = OpenAIEmbeddings(model="text-embedding-3-small")
        self.threshold = threshold
        self.vectors: list[np.ndarray] = []
        self.answers: list[str] = []

    def get(self, query: str) -> str | None:
        if not self.vectors:
            return None
        q = np.array(self.embedder.embed_query(query))
        sims = [float(q @ v / (np.linalg.norm(q) * np.linalg.norm(v))) for v in self.vectors]
        best = int(np.argmax(sims))
        return self.answers[best] if sims[best] >= self.threshold else None

    def put(self, query: str, answer: str) -> None:
        self.vectors.append(np.array(self.embedder.embed_query(query)))
        self.answers.append(answer)


def cache_key(model: str, prompt: str) -> str:
    """Exact-match cache key. Include model + prompt version: changing either must invalidate."""
    return hashlib.sha256(f"{model}|{prompt}".encode()).hexdigest()


# ---------------------------------------------------------------- 6. structured output repair
class Extraction(BaseModel):
    order_id: str
    amount: float


def extract_with_repair(text: str) -> Extraction:
    structured = primary.with_structured_output(Extraction)
    try:
        return structured.invoke(text)
    except ValidationError as err:
        # "Reask": show the model its own error. Usually fixes it in one retry.
        return structured.invoke(f"{text}\n\nYour previous output was invalid: {err}. Fix it.")
