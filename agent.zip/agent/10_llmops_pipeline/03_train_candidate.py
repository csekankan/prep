"""
03 — TRAIN: build a CANDIDATE release from new data
====================================================

CONCEPT DEEP DIVE
-----------------
"Train" picks the cheapest lever that addresses the observed root causes (from curation):

  root cause            lever (cheapest first)                         function below
  ---------------------------------------------------------------------------------------
  missing/stale docs    REINDEX the knowledge base                     reindex()
  retrieval misses      TUNE retrieval (k, threshold, hybrid)           tune_retrieval()
  reasoning/format      OPTIMIZE PROMPT on the dev split                optimize_prompt()
  persistent style/     FINE-TUNE a small model on curated examples     fine_tune_openai() /
  format errors at scale, or cost reduction (distill big → small)       fine_tune_bedrock()

Every run is TRACKED (MLflow): parameters, dataset versions, metrics, artifacts. Six weeks later,
"why is v1.8 better than v1.7?" has an answer.

DEV vs TEST: tune/optimize on a DEV split of the goldens; the eval gate (04_) scores on the
held-out TEST split. Optimizing on the same data you gate on = overfitting the gate.
"""

import itertools
import json
import time

import mlflow

mlflow.set_experiment("support-copilot-candidates")


# ---------------------------------------------------------------- lever 1: reindex
def reindex(collection_version: str) -> dict:
    """Re-ingest into a NEW versioned collection (blue/green index): the champion keeps serving
    from the old collection until the new release is promoted. Rollback = keep using the old name.
    See 04_rag/05_qdrant_server.py (upsert_documents) or Bedrock KB start_ingestion_job."""
    new_collection = f"support_chunks_{collection_version}"
    # ingest_all_documents(collection=new_collection)
    return {"collection": new_collection}


# ---------------------------------------------------------------- lever 2: retrieval tuning
def tune_retrieval(dev_set: list[dict], evaluate_fn) -> dict:
    """Small grid search. evaluate_fn(config, dataset) → dict of metric means (e.g. contextual recall)."""
    best, best_score = None, -1.0
    for k, threshold, hybrid in itertools.product([3, 4, 6], [0.2, 0.3, 0.4], [False, True]):
        cfg = {"k": k, "min_relevance": threshold, "hybrid": hybrid}
        with mlflow.start_run(nested=True, run_name=f"retrieval-{k}-{threshold}-{hybrid}"):
            m = evaluate_fn(cfg, dev_set)
            mlflow.log_params(cfg)
            mlflow.log_metrics(m)
        # Optimize recall but never accept a precision collapse.
        score = m["contextual_recall"] if m["contextual_precision"] >= 0.7 else 0
        if score > best_score:
            best, best_score = cfg, score
    return best


# ---------------------------------------------------------------- lever 3: prompt optimization
def optimize_prompt(base_prompt: str, failures: list[dict], dev_set: list[dict], evaluate_fn, llm) -> str:
    """Simple 'LLM as prompt engineer' loop (the idea behind DSPy / TextGrad / OPRO):
    show a strong model the current prompt + failing cases, ask for an improved prompt,
    keep it only if it beats the current one on the DEV set."""
    current, current_score = base_prompt, evaluate_fn({"prompt": base_prompt}, dev_set)["mean"]
    for round_ in range(3):
        proposal = llm.invoke(
            "You improve system prompts for a support assistant.\n"
            f"Current prompt:\n<prompt>{current}</prompt>\n"
            f"Failing cases (question, bad answer, correct answer):\n{json.dumps(failures[:15], indent=1)}\n"
            "Return ONLY the improved prompt. Keep all safety rules."
        ).content
        score = evaluate_fn({"prompt": proposal}, dev_set)["mean"]
        with mlflow.start_run(nested=True, run_name=f"prompt-round-{round_}"):
            mlflow.log_metric("dev_mean", score)
            mlflow.log_text(proposal, "prompt.txt")
        if score > current_score:
            current, current_score = proposal, score
    return current


# ---------------------------------------------------------------- lever 4a: fine-tune (OpenAI)
def fine_tune_openai(train_path: str, val_path: str, base_model: str = "gpt-4o-mini-2024-07-18") -> str:
    """Supervised fine-tuning on curated chat examples (02_curate_dataset.to_sft_example format).
    Needs ~50–100+ high-quality examples to help; thousands for big gains. Returns the new model id."""
    from openai import OpenAI

    client = OpenAI()
    train_file = client.files.create(file=open(train_path, "rb"), purpose="fine-tune")
    val_file = client.files.create(file=open(val_path, "rb"), purpose="fine-tune")
    job = client.fine_tuning.jobs.create(
        model=base_model, training_file=train_file.id, validation_file=val_file.id,
        suffix="shopco-support", hyperparameters={"n_epochs": 3},
    )
    while job.status not in ("succeeded", "failed", "cancelled"):
        time.sleep(60)
        job = client.fine_tuning.jobs.retrieve(job.id)
    if job.status != "succeeded":
        raise RuntimeError(f"fine-tune {job.status}: {job.error}")
    return job.fine_tuned_model  # e.g. "ft:gpt-4o-mini-2024-07-18:shopco:shopco-support:abc123"


# ---------------------------------------------------------------- lever 4b: fine-tune (Bedrock)
def fine_tune_bedrock(train_s3: str, output_s3: str, role_arn: str, base_model_id: str) -> str:
    """Bedrock model customization: data in S3 (JSONL), runs in your AWS account, the custom
    model stays private. Serve it via provisioned throughput or on-demand (model-dependent)."""
    import boto3

    bedrock = boto3.client("bedrock")
    name = f"shopco-support-{int(time.time())}"
    bedrock.create_model_customization_job(
        jobName=name,
        customModelName=name,
        roleArn=role_arn,                       # IAM role Bedrock assumes to read/write S3
        baseModelIdentifier=base_model_id,
        customizationType="FINE_TUNING",
        trainingDataConfig={"s3Uri": train_s3},
        outputDataConfig={"s3Uri": output_s3},
        hyperParameters={"epochCount": "2", "batchSize": "1", "learningRate": "0.00001"},
    )
    while (status := bedrock.get_model_customization_job(jobIdentifier=name)["status"]) == "InProgress":
        time.sleep(120)
    if status != "Completed":
        raise RuntimeError(f"Bedrock customization {status}")
    return bedrock.get_custom_model(modelIdentifier=name)["modelArn"]


# ---------------------------------------------------------------- assemble the candidate
def build_candidate(champion: dict, curation: dict, dev_set: list[dict], evaluate_fn, llm) -> dict:
    """Start from the champion's manifest and change only what the evidence calls for."""
    candidate = json.loads(json.dumps(champion))  # deep copy
    causes = curation["root_causes"]
    with mlflow.start_run(run_name="build-candidate") as run:
        mlflow.log_dict(curation["goldens"], "goldens_pointer.json")
        if causes.get("missing_knowledge"):
            candidate["retrieval"].update(reindex(time.strftime("%Y%m%d%H%M")))
        if causes.get("retrieval_miss"):
            candidate["retrieval"].update(tune_retrieval(dev_set, evaluate_fn))
        if causes.get("reasoning") or causes.get("format"):
            failures = [c for c in curation["_cases"] if c["root_cause"] in ("reasoning", "format")]
            candidate["prompt"]["text"] = optimize_prompt(champion["prompt"]["text"], failures, dev_set, evaluate_fn, llm)
        if curation["training"]["rows"] >= 200 and causes.get("format", 0) > 20:
            candidate["model"]["id"] = fine_tune_openai(curation["training"]["path"], curation["training"]["path"])
        candidate["dataset"] = {"goldens": curation["goldens"]["path"], "goldens_sha256": curation["goldens"]["sha256"]}
        candidate["mlflow_run_id"] = run.info.run_id
        mlflow.log_dict(candidate, "candidate_manifest.json")
    return candidate
