"""
01 — ONLINE MONITOR: score production, detect drift, raise alerts
==================================================================

Runs as a Kubernetes CronJob every hour (11_kubernetes/k8s/cronjobs.yaml).

CONCEPT DEEP DIVE
-----------------
Offline evals (pre-deploy) answer "is this release good on KNOWN questions?".
Online evals answer "is it good on TODAY'S REAL questions?" — users ask new things, docs go
stale, providers silently update models. Quality decays without any code change.

What this job does each run:
  1. SAMPLE recent production traces (e.g. 5% or max 200) — judging every request is too costly.
  2. SCORE them reference-free (no expected answer exists for live traffic):
       faithfulness (answer vs retrieved context), answer relevancy (answer vs question).
  3. COMPUTE operational signals: negative-feedback rate, refusal rate, guardrail block rate.
  4. DETECT DRIFT: are today's questions semantically far from what the KB/eval set covers?
  5. PUBLISH metrics to Prometheus (Pushgateway) → Grafana dashboards + Alertmanager rules.
  6. FLAG bad traces into a review queue → input for 02_curate_dataset.py.
  7. ALERT directly for severe breaches (belt and braces alongside Prometheus rules).

Metrics are labeled with `release` so canary vs stable can be compared (Argo Rollouts reads them).
"""

import os
import statistics
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import httpx
import numpy as np
from deepeval.metrics import AnswerRelevancyMetric, FaithfulnessMetric
from deepeval.test_case import LLMTestCase
from langchain_openai import OpenAIEmbeddings
from prometheus_client import CollectorRegistry, Gauge, push_to_gateway

PUSHGATEWAY = os.environ.get("PUSHGATEWAY_URL", "pushgateway.monitoring:9091")
SLACK_WEBHOOK = os.environ.get("SLACK_WEBHOOK_URL", "")
SAMPLE_SIZE = int(os.environ.get("SAMPLE_SIZE", "200"))
JUDGE = os.environ.get("JUDGE_MODEL", "gpt-4o")

SLO = {"faithfulness": 0.80, "answer_relevancy": 0.75, "negative_feedback_rate": 0.15, "drift_score": 0.35}


@dataclass
class Trace:
    trace_id: str
    release: str
    question: str
    answer: str
    contexts: list[str]
    feedback: int | None        # 1 thumbs up, 0 thumbs down, None no feedback
    guardrail_flags: list[str]


# ---------------------------------------------------------------- 1. sample traces
def fetch_traces(since: datetime, limit: int) -> list[Trace]:
    """Pull from your tracing backend. Langfuse example:
        from langfuse import Langfuse
        lf = Langfuse(); page = lf.fetch_traces(from_timestamp=since, limit=limit, tags=["prod"])
    LangSmith: Client().list_runs(project_name=..., start_time=since, is_root=True).
    Map each trace to (question, answer, retrieved contexts, feedback, flags, release tag)."""
    raise NotImplementedError("wire to Langfuse / LangSmith / your log store")


# ---------------------------------------------------------------- 2. score
def score(traces: list[Trace]) -> dict[str, list[float]]:
    faith = FaithfulnessMetric(model=JUDGE, async_mode=False)
    relev = AnswerRelevancyMetric(model=JUDGE, async_mode=False)
    out = {"faithfulness": [], "answer_relevancy": []}
    for t in traces:
        tc = LLMTestCase(input=t.question, actual_output=t.answer, retrieval_context=t.contexts or ["(none)"])
        if t.contexts:  # faithfulness only meaningful when the answer used retrieved context
            faith.measure(tc)
            out["faithfulness"].append(faith.score)
        relev.measure(tc)
        out["answer_relevancy"].append(relev.score)
        t.scores = {"faithfulness": faith.score if t.contexts else None, "answer_relevancy": relev.score}
    return out


# ---------------------------------------------------------------- 4. drift
_embedder = OpenAIEmbeddings(model="text-embedding-3-small")


def drift_score(questions: list[str], reference_centroids: np.ndarray) -> float:
    """Share of today's questions that are FAR from every cluster of known questions.
    reference_centroids: k-means centroids of eval-set + last month's questions (precomputed, normalized).
    A rising score means users ask about things the KB and eval set don't cover → new docs or goldens needed."""
    q = np.array(_embedder.embed_documents(questions))
    q = q / np.linalg.norm(q, axis=1, keepdims=True)
    nearest_sim = (q @ reference_centroids.T).max(axis=1)
    return float((nearest_sim < 0.5).mean())


# ---------------------------------------------------------------- 5–7. publish, flag, alert
def publish(metrics_by_release: dict[str, dict[str, float]]) -> None:
    registry = CollectorRegistry()
    gauges = {
        name: Gauge(f"copilot_online_{name}", f"Online {name} (sampled, LLM-judged)", ["release"], registry=registry)
        for name in ("faithfulness", "answer_relevancy", "negative_feedback_rate", "refusal_rate", "drift_score")
    }
    for release, metrics in metrics_by_release.items():
        for name, value in metrics.items():
            gauges[name].labels(release=release).set(value)
    push_to_gateway(PUSHGATEWAY, job="online_monitor", registry=registry)


def flag_for_review(traces: list[Trace]) -> list[str]:
    """Bad = thumbs down OR low judge score. These become curation candidates."""
    flagged = [
        t.trace_id for t in traces
        if t.feedback == 0
        or (getattr(t, "scores", {}).get("faithfulness") or 1) < 0.5
        or getattr(t, "scores", {}).get("answer_relevancy", 1) < 0.5
    ]
    # e.g. Langfuse: add to an annotation queue / dataset "review-queue"; or write IDs to S3.
    return flagged


def alert(breaches: dict[str, tuple[float, float]], release: str, n_flagged: int) -> None:
    if not breaches or not SLACK_WEBHOOK:
        return
    lines = [f"*{k}*: {v:.3f} (SLO {s})" for k, (v, s) in breaches.items()]
    httpx.post(SLACK_WEBHOOK, json={"text": f":rotating_light: Quality SLO breach on `{release}`\n"
                                            + "\n".join(lines) + f"\n{n_flagged} traces queued for review."}, timeout=10)


def run(reference_centroids: np.ndarray) -> None:
    since = datetime.now(timezone.utc) - timedelta(hours=1)
    traces = fetch_traces(since, SAMPLE_SIZE)
    by_release: dict[str, list[Trace]] = {}
    for t in traces:
        by_release.setdefault(t.release, []).append(t)

    results = {}
    for release, group in by_release.items():
        s = score(group)
        rated = [t for t in group if t.feedback is not None]
        metrics = {
            "faithfulness": statistics.mean(s["faithfulness"]) if s["faithfulness"] else 1.0,
            "answer_relevancy": statistics.mean(s["answer_relevancy"]),
            "negative_feedback_rate": sum(t.feedback == 0 for t in rated) / max(len(rated), 1),
            "refusal_rate": sum("don't know" in t.answer.lower() for t in group) / len(group),
            "drift_score": drift_score([t.question for t in group], reference_centroids),
        }
        results[release] = metrics

        breaches = {}
        for name, threshold in SLO.items():
            bad = metrics[name] > threshold if name in ("negative_feedback_rate", "drift_score") else metrics[name] < threshold
            if bad:
                breaches[name] = (metrics[name], threshold)
        alert(breaches, release, len(flag_for_review(group)))

    publish(results)
