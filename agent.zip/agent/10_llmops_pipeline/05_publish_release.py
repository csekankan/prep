"""
05 — PUBLISH: create an immutable, versioned release and hand it to deployment
===============================================================================

CONCEPT DEEP DIVE
-----------------
Publishing turns a passing candidate into something deployable and auditable:

  1. SEMVER bump      major: behavior contract change (new tools, new scope)
                      minor: model/prompt/index change that passed the gate
                      patch: config tweak (threshold), guardrail fix
  2. MANIFEST         write release_manifest.yaml (see example) — every artifact pinned by id/hash/digest
  3. REGISTRY         register in MLflow Model Registry under name "support-copilot" with alias
                      "challenger". Promotion to "champion" happens only after the canary succeeds.
  4. PROMPT REGISTRY  publish prompt text as an immutable version (git tag / Langfuse / Bedrock Prompt Management)
  5. GITOPS COMMIT    update the prod overlay in the deployment repo (image digest + release config).
                      Argo CD notices the commit and starts the canary (11_kubernetes/).
                      Nobody runs `kubectl apply` by hand in prod — git is the source of truth,
                      so every deploy is reviewed, auditable, and revertible with `git revert`.
"""

import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import mlflow
import yaml
from mlflow import MlflowClient

DEPLOY_REPO = Path("deploy-repo")        # git clone of the GitOps repo (separate from app code)
PROD_OVERLAY = DEPLOY_REPO / "apps/support-copilot/overlays/prod"


def bump(version: str, level: str) -> str:
    major, minor, patch = map(int, version.split("."))
    return {"major": f"{major + 1}.0.0", "minor": f"{major}.{minor + 1}.0", "patch": f"{major}.{minor}.{patch + 1}"}[level]


def change_level(champion: dict, candidate: dict) -> str:
    if candidate.get("tools") != champion.get("tools"):
        return "major"
    if any(candidate[k] != champion[k] for k in ("model", "prompt", "retrieval")):
        return "minor"
    return "patch"


def publish(candidate: dict, champion: dict, report: dict, image_digest: str) -> dict:
    version = bump(champion["version"], change_level(champion, candidate))
    manifest = {
        **candidate,
        "version": version,
        "parent": champion["version"],
        "created_at": datetime.now(timezone.utc).isoformat(),
        "artifacts_image": image_digest,
        "evaluation": {"passed": report["passed"], "summary": report["summary"]},
    }

    # --- MLflow registry: version + alias "challenger" ---
    client = MlflowClient()
    with mlflow.start_run(run_id=candidate.get("mlflow_run_id")):
        mlflow.log_dict(manifest, "release_manifest.json")
        mlflow.log_dict(report, "eval_report.json")
        run_id = mlflow.active_run().info.run_id
    mv = mlflow.register_model(f"runs:/{run_id}/release_manifest.json", "support-copilot")
    client.set_model_version_tag("support-copilot", mv.version, "semver", version)
    client.set_registered_model_alias("support-copilot", "challenger", mv.version)

    # --- GitOps: write config + image into the prod overlay and commit ---
    (PROD_OVERLAY / "release.json").write_text(json.dumps(manifest, indent=2))
    kustomization = yaml.safe_load((PROD_OVERLAY / "kustomization.yaml").read_text())
    kustomization["images"] = [{"name": "support-copilot", "digest": image_digest.split("@")[-1]}]
    (PROD_OVERLAY / "kustomization.yaml").write_text(yaml.safe_dump(kustomization, sort_keys=False))

    subprocess.run(["git", "-C", str(DEPLOY_REPO), "add", "-A"], check=True)
    subprocess.run(["git", "-C", str(DEPLOY_REPO), "commit", "-m", f"release support-copilot {version}"], check=True)
    subprocess.run(["git", "-C", str(DEPLOY_REPO), "tag", f"support-copilot-{version}"], check=True)
    subprocess.run(["git", "-C", str(DEPLOY_REPO), "push", "--follow-tags"], check=True)
    # In many teams this opens a PR instead of pushing, so a human approves prod changes.
    return manifest


def promote_to_champion(registry_version: str) -> None:
    """Called by the post-canary hook when the rollout completes successfully."""
    MlflowClient().set_registered_model_alias("support-copilot", "champion", registry_version)
