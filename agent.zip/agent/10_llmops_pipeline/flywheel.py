"""
FLYWHEEL ORCHESTRATOR — the whole loop in one readable function
=================================================================

On Kubernetes each step below is a container step in an Argo Workflow
(11_kubernetes/k8s/argo-workflow-flywheel.yaml); on AWS, a Step Functions state machine or a
SageMaker Pipeline. This file keeps the same steps as plain Python so the flow is easy to follow.

TRIGGERS (any of these starts a run):
  - alert from the online monitor (quality SLO breach)       → Alertmanager webhook → Argo Events
  - new reviewed data batch (e.g. >= 50 approved cases)        → scheduled check
  - knowledge-base docs changed                                → S3/SharePoint event
  - weekly schedule                                            → CronWorkflow

Each step is IDEMPOTENT and passes POINTERS (S3 paths, versions, run IDs) — not data —
to the next step, so any step can be retried or resumed independently.
"""

import json

from langchain.chat_models import init_chat_model

# The step functions (curate, build_candidate, run_eval, gate, publish) live in the numbered files
# of this folder. Module names starting with digits can't be imported with a plain `import`; in a
# real repo name them curate.py, train.py, gate.py, publish.py and import them directly.


def run_flywheel(trigger: dict, champion_manifest: dict) -> dict:
    log = {"trigger": trigger, "steps": []}

    # 1. CURATE — reviewed failures → new dataset versions (goldens + SFT)
    curation = curate(  # noqa: F821 — from 02_curate_dataset
        reviewed_file=trigger["reviewed_batch"],
        current_goldens=load_jsonl(champion_manifest["dataset"]["goldens"]),
        current_training=load_jsonl("datasets/sft/latest.jsonl"),
        system_prompt=champion_manifest["prompt"]["text"],
    )
    log["steps"].append({"curate": {k: v for k, v in curation.items() if k != "_cases"}})
    if not curation["root_causes"]:
        return {**log, "result": "nothing to improve"}

    # Split goldens into DEV (for tuning) and TEST (for gating) — fixed seed, never mixed.
    goldens = load_jsonl(curation["goldens"]["path"])
    dev, test = goldens[::2], goldens[1::2]

    # 2. TRAIN — build a candidate using the cheapest effective levers
    candidate = build_candidate(  # noqa: F821 — from 03_train_candidate
        champion_manifest, curation, dev, evaluate_fn=evaluate_config,
        llm=init_chat_model("openai:gpt-4o", temperature=0.2),
    )
    log["steps"].append({"train": candidate.get("mlflow_run_id")})

    # 3. EVAL GATE — candidate vs champion on held-out TEST split
    target = max(curation["root_causes"], key=curation["root_causes"].get)
    target_metric = {"retrieval_miss": "contextual_recall", "missing_knowledge": "answer_relevancy",
                     "reasoning": "faithfulness", "format": "g_eval_format"}.get(target, "faithfulness")
    report = gate(run_eval(candidate, test), run_eval(champion_manifest, test), target_metric)  # noqa: F821
    log["steps"].append({"gate": {"passed": report["passed"], "reasons": report["reasons"]}})
    if not report["passed"]:
        notify(f"Candidate rejected: {report['reasons']}")
        return {**log, "result": "rejected"}

    # 4. BUILD + PUBLISH — container image (only if code changed) + manifest + registry + GitOps commit
    image = trigger.get("image_digest") or champion_manifest["artifacts"]["image"]
    manifest = publish(candidate, champion_manifest, report, image)  # noqa: F821 — from 05_publish_release
    log["steps"].append({"publish": manifest["version"]})

    # 5. DEPLOY happens outside this process: Argo CD syncs the commit, Argo Rollouts runs the
    #    canary with automated analysis (rollback on bad metrics). A post-rollout hook calls
    #    promote_to_champion() when the canary reaches 100%.
    notify(f"Released support-copilot {manifest['version']} → canary started")
    return {**log, "result": "published", "version": manifest["version"]}


# ---------------------------------------------------------------- small helpers
def load_jsonl(path: str) -> list[dict]:
    with open(path) as f:
        return [json.loads(line) for line in f if line.strip()]


def evaluate_config(config: dict, dataset: list[dict]) -> dict:
    """Run the app with `config` overrides on `dataset` and return metric means (DeepEval)."""
    raise NotImplementedError


def notify(text: str) -> None:
    print("[notify]", text)  # Slack / Teams webhook in production
