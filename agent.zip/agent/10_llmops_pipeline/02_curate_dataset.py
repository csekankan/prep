"""
02 — CURATE: turn production failures into versioned training & eval data
==========================================================================

CONCEPT DEEP DIVE
-----------------
The single most valuable asset of an AI product is its DATASET of real cases with known-good
answers. Models and prompts are replaceable; your curated data is not.

From flagged traces (thumbs-down, low judge scores, drift clusters) we produce two datasets:

  GOLDENS (eval set)          → "does the system handle this?"  Used by the eval gate forever.
  TRAINING EXAMPLES (SFT)     → "this is how to answer."        Used only if we fine-tune.

Rules that keep data trustworthy:
  1. HUMAN IN THE LOOP — a reviewer writes/approves the correct answer. Never auto-label with the
     same model you're evaluating (you'd train/eval on its own mistakes).
  2. PII SCRUB before storing — eval data lives for years and is shared widely.
  3. DEDUPE — near-duplicate questions inflate scores; dedupe by embedding similarity.
  4. NO LEAKAGE — a case is in goldens (test) OR training, never both. Otherwise the eval gate
     measures memorization, not quality.
  5. VERSION IMMUTABLY — goldens@v14 never changes; edits create v15. Store a content hash.
  6. SLICES — tag each case with a category so scores can be reported per slice.

Root-cause triage decides WHERE a failure goes:
  retrieval miss (answer in docs, not retrieved)  → retrieval config / chunking fix + golden
  missing knowledge (not in docs)                 → ticket to docs team + "should refuse" golden
  wrong reasoning / format / tone                 → prompt fix or training example + golden
  unsafe output                                   → guardrail update + red-team golden
"""

import hashlib
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
from langchain_openai import OpenAIEmbeddings

from apps.support_copilot.guardrails import redact

DATASETS = Path("datasets")  # in prod: s3://shopco-llmops/datasets/ with bucket versioning


@dataclass
class ReviewedCase:
    """Output of the human review UI (Langfuse annotation queue, Label Studio, Argilla...)."""

    trace_id: str
    question: str
    model_answer: str
    corrected_answer: str        # written/approved by a human reviewer
    root_cause: str              # retrieval_miss | missing_knowledge | reasoning | format | unsafe
    category: str                # slice: policy | order | off_topic | injection ...
    approved: bool


def load_reviewed(path: Path) -> list[ReviewedCase]:
    return [ReviewedCase(**json.loads(line)) for line in path.read_text().splitlines()]


def dedupe(cases: list[ReviewedCase], existing_questions: list[str], threshold: float = 0.92) -> list[ReviewedCase]:
    emb = OpenAIEmbeddings(model="text-embedding-3-small")
    pool = existing_questions[:]
    pool_vecs = [np.array(v) for v in emb.embed_documents(pool)] if pool else []
    kept = []
    for c in cases:
        v = np.array(emb.embed_query(c.question))
        if any(float(v @ p / (np.linalg.norm(v) * np.linalg.norm(p))) > threshold for p in pool_vecs):
            continue
        kept.append(c)
        pool_vecs.append(v)
    return kept


def split_goldens_vs_training(cases: list[ReviewedCase], golden_ratio: float = 0.5, seed: int = 7):
    """Unsafe/off-topic/missing-knowledge cases always go to goldens (they test behavior, and we
    don't want to fine-tune on them). The rest is split randomly with a fixed seed (reproducible)."""
    rng = random.Random(seed)
    goldens, training = [], []
    for c in cases:
        if c.root_cause in ("unsafe", "missing_knowledge") or rng.random() < golden_ratio:
            goldens.append(c)
        else:
            training.append(c)
    return goldens, training


def to_golden(c: ReviewedCase) -> dict:
    return {"input": redact(c.question)[0], "expected_output": redact(c.corrected_answer)[0],
            "category": c.category, "source_trace": c.trace_id}


def to_sft_example(c: ReviewedCase, system_prompt: str) -> dict:
    """OpenAI / Bedrock chat fine-tuning format: one JSON object per line with `messages`."""
    return {"messages": [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": redact(c.question)[0]},
        {"role": "assistant", "content": redact(c.corrected_answer)[0]},
    ]}


def publish_dataset_version(name: str, rows: list[dict], previous_rows: list[dict]) -> dict:
    """Append-only: new version = previous rows + new rows. Returns pointer used by later stages."""
    all_rows = previous_rows + rows
    payload = "\n".join(json.dumps(r, sort_keys=True) for r in all_rows)
    sha = hashlib.sha256(payload.encode()).hexdigest()
    version = len(list((DATASETS / name).glob("v*.jsonl"))) + 1
    path = DATASETS / name / f"v{version}.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload)
    return {"name": name, "version": version, "path": str(path), "sha256": sha, "rows": len(all_rows)}


def curate(reviewed_file: Path, current_goldens: list[dict], current_training: list[dict], system_prompt: str) -> dict:
    cases = [c for c in load_reviewed(reviewed_file) if c.approved]
    cases = dedupe(cases, [g["input"] for g in current_goldens])
    goldens, training = split_goldens_vs_training(cases)
    return {
        "goldens": publish_dataset_version("goldens", [to_golden(c) for c in goldens], current_goldens),
        "training": publish_dataset_version("sft", [to_sft_example(c, system_prompt) for c in training], current_training),
        "root_causes": {rc: sum(c.root_cause == rc for c in cases) for rc in {c.root_cause for c in cases}},
        "_cases": [asdict(c) for c in cases],
    }
