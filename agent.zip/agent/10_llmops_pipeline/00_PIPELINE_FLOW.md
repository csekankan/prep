# The LLMOps Pipeline: how an AI app improves itself safely in production

**LLMOps** means the practices and tooling for running LLM applications in production and improving them
over time. This folder implements the full loop: notice that answers got worse, figure out why, build a
better version, prove that it *is* better, and roll it out without breaking anything for users.

## First: what does "training" mean for an LLM app?

In classic machine learning, "training" means updating a model's weights on data. For an LLM app you usually
do **not** retrain the foundation model (GPT, Claude, Llama). That's expensive, and the provider owns it.
Instead, "training" an LLM application means improving any of the **five artifacts** that determine how it
behaves:

| Artifact | How it's "trained" | Cost | How often |
|---|---|---|---|
| **Knowledge index** (RAG) | re-ingest changed docs, re-chunk, re-embed | low | on every doc change |
| **Prompts** | rewrite, or auto-optimize against the eval set | low | weekly |
| **Retrieval config** | tune k, the score threshold, hybrid weights, the reranker | low | when metrics dip |
| **Guardrail policy** | add denied topics, PII patterns, thresholds | low | after incidents |
| **Model** | switch model, or **fine-tune** on curated examples (OpenAI / Bedrock customization / LoRA) | high | monthly, only with evidence |

What each one means, with an example:

- **Knowledge index.** The searchable store of your documents used by **RAG** (retrieval-augmented
  generation: search your documents, then give the matches to the model). "Training" it means re-reading
  changed documents, splitting them into chunks again, and recomputing their **embeddings** (the number
  lists used for meaning-based search). *Example:* the refund window changes from 30 to 14 days. Until the
  index is rebuilt, the bot keeps saying 30.
- **Prompts.** The instructions sent to the model. You can rewrite them by hand, or **auto-optimize** them:
  a tool such as DSPy tries prompt variations and keeps whichever scores best on your eval set.
- **Retrieval config.** The knobs of search:
  - **k**: how many chunks to retrieve.
  - **threshold**: the minimum similarity score for a chunk to count as relevant.
  - **hybrid weights**: how much to trust keyword search versus meaning-based search.
  - **reranker**: a second model that re-sorts the results by relevance.

  *Example:* answers are missing details, and evaluation shows the needed chunk was often 6th; raising k
  from 4 to 8 fixes it.
- **Guardrail policy.** The safety rules: topics to refuse, PII patterns to mask, sensitivity thresholds.
  Usually updated after an incident ("the bot gave tax advice; add 'tax advice' as a denied topic").
- **Model.** Switching to a different model, or **fine-tuning** (continuing training on your own curated
  examples). **LoRA** (Low-Rank Adaptation) is a cheap fine-tuning method that trains a small add-on of
  extra weights instead of the whole model. This is the most expensive lever, so use it only when the data
  clearly shows the cheaper ones aren't enough.

**A release is one specific combination of all five, pinned and versioned** (see `release_manifest.yaml`).
"Pinned" means each part is referenced by an exact version that never changes: `prompt support@v7`, not
"the current prompt". You deploy releases, roll back releases, and compare releases. You never make "a
quick prompt edit in production", because then nobody can say which version produced yesterday's bad
answers, or how to get back to the good one.

## The flywheel

A **flywheel** is a loop that gets stronger each time it turns. Here, more production traffic produces more
examples of failures, which produce better releases, which serve users better.

```
        ┌──────────────────────────────────────────────────────────────────────────────────┐
        │                                                                                  │
        ▼                                                                                  │
 ┌──────────────┐  traces,    ┌───────────────┐  scores   ┌──────────────┐  alert   ┌──────┴───────┐
 │ 1 PRODUCTION │ ──feedback─►│ 2 MONITOR     │ ────────► │ 3 ALERT      │ ───────► │ 4 CURATE     │
 │ (k8s, canary)│             │ online evals, │           │ SLO breached │          │ failures →   │
 └──────▲───────┘             │ drift, cost   │           │ Slack/Pager  │          │ new goldens, │
        │                     └───────────────┘           └──────────────┘          │ train data   │
        │                                                                           └──────┬───────┘
 ┌──────┴───────┐  promote    ┌───────────────┐  pass     ┌──────────────┐  candidate ┌─────▼────────┐
 │ 8 DEPLOY     │ ◄────────── │ 7 PUBLISH     │ ◄──────── │ 6 EVAL GATE  │ ◄───────── │ 5 TRAIN      │
 │ canary →     │             │ versioned     │           │ candidate vs │            │ reindex /    │
 │ auto-rollback│             │ release       │   fail ──►│ champion     │──► stop    │ prompt opt / │
 └──────────────┘             └───────────────┘           └──────────────┘            │ fine-tune    │
                                                                                      └──────────────┘
```

**How to read it:** start at box 1 and go clockwise. The top row *detects* problems: production produces
logs, monitoring scores them, and an alert fires when quality drops. The right side and bottom row *fix*
them: failures become new data, a candidate release is built, it must beat the current version in testing,
and only then is it published and rolled out gradually. The arrow from 8 back to 1 closes the loop. The
"fail ──► stop" branch at box 6 is the safety valve: a candidate that isn't better never reaches users.

**Terms in this diagram:**
- **Traces**: the step-by-step record of each request (prompt, retrieved documents, tool calls, tokens,
  latency).
- **Canary**: rolling a new release out to a small share of users first (see stage 8).
- **Online evals**: automatic quality scoring of a sample of real production conversations, usually by an
  LLM acting as a judge.
- **Drift**: the kind of questions users ask changes over time (for example a new product launches and
  nobody wrote docs for it), so the system meets topics it wasn't built for.
- **SLO breached**: an **SLO** (service level objective) is a target you commit to, such as "faithfulness at
  least 0.80" or "p95 latency under 6 s". "Breached" means the measured value crossed it.
- **Slack/Pager**: alerts go to a chat channel or page the on-call engineer (for example through PagerDuty).
- **Goldens**: test cases with known good answers. The eval set is made of goldens.
- **Prompt opt**: automatic prompt optimization (see the "Prompts" artifact above).
- **Champion vs candidate**: the **champion** is the release in production now. The **candidate** (also
  called the **challenger**) is the new one that has to beat it.

### Stage by stage

| # | Stage | Trigger | Output | File |
|---|---|---|---|---|
| 1 | Production | user traffic | traces (prompt, docs, tools, tokens, latency), feedback | `apps/support_copilot/api.py`, `metrics.py` |
| 2 | Monitor | CronJob, hourly | quality scores, drift, cost metrics, exported to Prometheus | `01_online_monitor.py` |
| 3 | Alert | a metric crosses its threshold | Slack/PagerDuty alert, plus a queue of flagged traces | `alerts/prometheus-rules.yaml` |
| 4 | Curate | an alert, or weekly | versioned dataset: new goldens and fine-tune examples (human-reviewed) | `02_curate_dataset.py` |
| 5 | Train | a new dataset version or a doc change | candidate release (new index / prompt / model) | `03_train_candidate.py` |
| 6 | Eval gate | a candidate is created | pass/fail report against the current champion | `04_evaluate_and_gate.py` |
| 7 | Publish | the gate passed | immutable release manifest, registry entry, image tag, GitOps commit | `05_publish_release.py` |
| 8 | Deploy | a GitOps commit | canary at 10%, then 50%, then 100%, with auto-rollback on bad metrics | `11_kubernetes/k8s/rollout-canary.yaml` |

Notes on each stage:

1. **Production** serves users and records everything needed to debug later, including thumbs-up/down
   feedback linked to each trace.
2. **Monitor** runs as a **CronJob** (a Kubernetes job on a schedule) every hour. It samples recent traces,
   scores them, and exports the scores to **Prometheus** (an open-source metrics database), so they can be
   graphed and alerted on.
3. **Alert** fires when a score crosses a threshold (see the table in the next section), and saves the
   offending traces in a queue so humans can look at real examples instead of just a number.
4. **Curate** turns flagged failures into data. A person reviews each one, writes the correct answer, and
   adds it as a new golden test case, and possibly as a fine-tuning example. The dataset gets a new version
   number. Human review matters here, because training on unreviewed model output can bake mistakes in.
5. **Train** builds a **candidate release** by updating whichever artifact addresses the failures:
   re-indexing documents, optimizing the prompt, or fine-tuning.
6. **Eval gate** runs both the candidate and the champion on the full eval set. The candidate passes only
   if it's better (or at least no worse) on every metric that matters. *Example:* the candidate improves
   faithfulness from 0.82 to 0.88 but drops answer relevancy from 0.86 to 0.79, so it fails the gate.
7. **Publish** writes an **immutable** (never edited afterwards) release manifest, registers the release in
   the model registry, tags the container image, and commits the new configuration to git.
8. **Deploy** happens through **GitOps**: Argo CD notices the git commit and updates the cluster. The canary
   sends 10% of traffic to the new release, checks the metrics, then moves to 50%, then 100%. If metrics get
   worse at any step, it automatically rolls back to the previous release.

The whole loop is orchestrated by `flywheel.py` when running locally, and by an **Argo Workflow** (a
pipeline engine for Kubernetes) in the cluster (`11_kubernetes/k8s/argo-workflow-flywheel.yaml`).

## Alerts: what counts as "bad results"?

| Signal | How it's measured | Example alert threshold |
|---|---|---|
| Faithfulness (hallucination) | LLM judge on sampled traces | mean < 0.80 over 1 hour |
| Answer relevancy | LLM judge | mean < 0.75 over 1 hour |
| Negative feedback rate | thumbs-down / total | > 15% over 2 hours |
| Refusal rate ("I don't know") | string match | > 25% (retrieval broken) or < 2% (hallucinating?) |
| Guardrail block rate | counter | 3× the 7-day baseline (an attack, or false positives) |
| Query drift | embedding distance of today's queries from a reference set | > threshold: new topics not in the KB |
| Latency | p95 histogram | > 6 s for 10 minutes |
| Error rate | 5xx / total | > 2% for 5 minutes |
| Cost | tokens × price | > daily budget × 1.2 |

How to interpret each signal:

- **Faithfulness**: the share of an answer's claims that are supported by the retrieved documents. Low
  faithfulness means the model is making things up (**hallucinating**).
- **Answer relevancy**: whether the answer addresses the question at all.
- **Negative feedback rate**: users' own verdict. It's noisy (many people never click), but a jump from 6%
  to 18% is a strong signal.
- **Refusal rate needs two thresholds.** Too many "I don't know" answers (over 25%) usually means retrieval
  broke and the model isn't getting documents. Too *few* (under 2%) is also suspicious: real users always ask
  some questions the docs can't answer, so near-zero refusals suggests the model is guessing instead of
  admitting it doesn't know.
- **Guardrail block rate** compared with its own 7-day **baseline** (the normal level). Three times the
  normal rate means either someone is attacking the bot, or a recent change made the guardrail block
  innocent questions (**false positives**).
- **Query drift**: each query is turned into an embedding, and you measure how far today's queries sit from a
  reference set of typical past queries. A large distance means users are asking about something new.
  *Example:* after a new subscription product launches, drift jumps, because the knowledge base has no
  documents about it yet.
- **Latency at p95**: the time that 95% of requests beat. A **histogram** metric records how many requests
  fell into each time bucket, so percentiles can be computed from it.
- **Error rate**: the share of requests that failed with a **5xx** (server error) status.
- **Cost**: tokens used multiplied by the price per token, compared with the daily budget plus 20%
  headroom.

**Two alert destinations, because the problems need different responses:**
- **Page a human (operations)** for errors, latency, or a cost explosion. Something is broken *right now*
  and needs immediate action.
- **Open a quality ticket and trigger curation (AI team)** for gradual quality drift. Nobody needs to be
  woken at 3 a.m., but the improvement loop should start.

## Versioning: what gets a version

```
dataset:   goldens@v14          (s3://.../datasets/goldens/v14.jsonl, content hash)
index:     kb_policies@2026-11-12T03:00Z (vector collection name / KB ingestion job id)
prompt:    support@v7           (prompt registry / git)
model:     gpt-4o-mini-2024-07-18  OR ft:gpt-4o-mini:shopco:support:abc123  OR bedrock ARN
guardrail: shopco-support@3
release:   support-copilot@1.8.0 = all of the above + eval report + image digest
```

**How to read it:** every artifact that affects behavior has an exact version, and a release is the bundle of
all of them plus the evaluation report that justified it and the **image digest**. A digest is the unique
fingerprint (a SHA-256 hash) of the exact container image, which is more precise than a tag like `latest`
that can be moved to point at a different image. The `ft:` model ID is what a fine-tuned OpenAI model looks
like. A **content hash** of the dataset file proves the data wasn't changed after the fact.

*Why this matters, by example:* on Tuesday, complaints rise. You look up what's running: release 1.8.0.
You compare it with 1.7.2 and see only the prompt changed (v6 to v7). You roll back to 1.7.2 in one step
and investigate calmly.

**Where each version is stored:**
- **git**: prompts and configs.
- **S3 with versioning**, or **DVC** (Data Version Control, git-like versioning for large data files):
  datasets.
- **MLflow** or **SageMaker Model Registry**: models and releases, with the aliases `champion` and
  `challenger`.
- **Container registry**: the app images.
- **Argo CD**: records which release is running in which environment.

## Open-source vs AWS mapping

| Need | Open-source / k8s | AWS-native |
|---|---|---|
| Orchestration | Argo Workflows, Prefect, Airflow | Step Functions, SageMaker Pipelines |
| Tracing | Langfuse, Phoenix, OTel | CloudWatch + X-Ray, AgentCore Observability |
| Metrics and alerts | Prometheus, Alertmanager, Grafana | CloudWatch metrics/alarms, SNS |
| Registry | MLflow | SageMaker Model Registry, Bedrock custom models |
| Fine-tuning | HF TRL / LoRA on GPU nodes | Bedrock model customization, SageMaker training |
| Deploy | Argo CD + Argo Rollouts on k8s | EKS (same) / ECS + CodeDeploy canaries |
| Event triggers | Argo Events | EventBridge |

Both columns do the same jobs; pick based on where your team already runs things. A few names explained:
- **Prefect** and **Airflow**: Python workflow schedulers.
- **OTel** (OpenTelemetry): the standard format for traces and metrics.
- **X-Ray**: AWS's tracing service.
- **Grafana**: dashboards.
- **HF TRL**: Hugging Face's library for fine-tuning language models, including methods such as **SFT**
  (supervised fine-tuning on example answers) and **DPO** (learning from pairs of preferred and rejected
  answers).
- **ECS**: AWS's simpler container service.
- **CodeDeploy**: AWS's deployment service, which can do canary rollouts.
- **Argo Events**: triggers Argo Workflows from events such as alerts, webhooks, or new files.
