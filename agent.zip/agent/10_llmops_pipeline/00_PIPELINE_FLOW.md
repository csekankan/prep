# The LLMOps Pipeline — how an AI app improves itself safely in production

## First: what does "training" mean for an LLM app?

You usually do NOT retrain the foundation model. "Training" an LLM application means improving
any of the **five artifacts** that determine its behavior:

| Artifact | How it's "trained" | Cost | How often |
|---|---|---|---|
| **Knowledge index** (RAG) | re-ingest changed docs, re-chunk, re-embed | low | on every doc change |
| **Prompts** | rewrite / auto-optimize against the eval set | low | weekly |
| **Retrieval config** | tune k, threshold, hybrid weights, reranker | low | when metrics dip |
| **Guardrail policy** | add denied topics, PII patterns, thresholds | low | after incidents |
| **Model** | switch model, or **fine-tune** on curated examples (OpenAI / Bedrock customization / LoRA) | high | monthly, only with evidence |

A **release** = one specific combination of all five, pinned and versioned (see `release_manifest.yaml`).
You deploy releases, roll back releases, and compare releases — never "a prompt edit in prod".

## The flywheel

```
        ┌──────────────────────────────────────────────────────────────────────────────────┐
        │                                                                                  │
        ▼                                                                                  │
 ┌──────────────┐  traces,    ┌───────────────┐  scores   ┌──────────────┐  alert   ┌──────┴───────┐
 │ 1 PRODUCTION │ ──feedback─►│ 2 MONITOR     │ ────────► │ 3 ALERT      │ ───────► │ 4 CURATE     │
 │ (k8s, canary)│             │ online evals, │           │ SLO breached │          │ failures →   │
 └──────▲───────┘             │ drift, cost   │           │ Slack/Pager  │          │ new goldens, │
        │                     └───────────────┘           └──────────────┘          │ train data   │
        │                                                                           └──────┬───────┘
 ┌──────┴───────┐  promote    ┌───────────────┐  pass     ┌──────────────┐  candidate ┌─────▼────────┐
 │ 8 DEPLOY     │ ◄────────── │ 7 PUBLISH     │ ◄──────── │ 6 EVAL GATE  │ ◄───────── │ 5 TRAIN      │
 │ canary →     │             │ versioned     │           │ candidate vs │            │ reindex /    │
 │ auto-rollback│             │ release       │   fail ──►│ champion     │──► stop    │ prompt opt / │
 └──────────────┘             └───────────────┘           └──────────────┘            │ fine-tune    │
                                                                                      └──────────────┘
```

### Stage-by-stage

| # | Stage | Trigger | Output | File |
|---|---|---|---|---|
| 1 | Production | user traffic | traces (prompt, docs, tools, tokens, latency), feedback | `apps/support_copilot/api.py`, `metrics.py` |
| 2 | Monitor | CronJob hourly | quality scores, drift, cost metrics → Prometheus | `01_online_monitor.py` |
| 3 | Alert | metric crosses threshold | Slack/PagerDuty alert + flagged traces queue | `alerts/prometheus-rules.yaml` |
| 4 | Curate | alert, or weekly | versioned dataset: new goldens + fine-tune examples (human-reviewed) | `02_curate_dataset.py` |
| 5 | Train | new dataset version or doc change | candidate release (new index / prompt / model) | `03_train_candidate.py` |
| 6 | Eval gate | candidate created | pass/fail report vs current champion | `04_evaluate_and_gate.py` |
| 7 | Publish | gate passed | immutable release manifest, registry entry, image tag, GitOps commit | `05_publish_release.py` |
| 8 | Deploy | GitOps commit | canary 10% → 50% → 100%, auto-rollback on bad metrics | `11_kubernetes/k8s/rollout-canary.yaml` |

The whole loop is orchestrated by `flywheel.py` locally, and by an Argo Workflow on Kubernetes
(`11_kubernetes/k8s/argo-workflow-flywheel.yaml`).

## Alerts: what counts as "bad results"?

| Signal | How measured | Example alert threshold |
|---|---|---|
| Faithfulness (hallucination) | LLM judge on sampled traces | mean < 0.80 over 1h |
| Answer relevancy | LLM judge | mean < 0.75 over 1h |
| Negative feedback rate | thumbs-down / total | > 15% over 2h |
| Refusal rate ("I don't know") | string match | > 25% (retrieval broken) or < 2% (hallucinating?) |
| Guardrail block rate | counter | 3x the 7-day baseline (attack or false positives) |
| Query drift | embedding distance of today's queries vs reference set | > threshold → new topics not in KB |
| Latency | p95 histogram | > 6 s for 10 min |
| Error rate | 5xx / total | > 2% for 5 min |
| Cost | tokens × price | > daily budget × 1.2 |

Two alert destinations:
- **Page a human** (ops): errors, latency, cost explosion → something is broken now.
- **Open a quality ticket + trigger curation** (AI team): quality drift → improve the system.

## Versioning — what gets a version

```
dataset:   goldens@v14          (s3://.../datasets/goldens/v14.jsonl, content hash)
index:     kb_policies@2026-11-12T03:00Z (vector collection name / KB ingestion job id)
prompt:    support@v7           (prompt registry / git)
model:     gpt-4o-mini-2024-07-18  OR ft:gpt-4o-mini:shopco:support:abc123  OR bedrock ARN
guardrail: shopco-support@3
release:   support-copilot@1.8.0 = all of the above + eval report + image digest
```

Tools that hold these: git (prompts, configs), S3 with versioning or DVC (datasets),
MLflow / SageMaker Model Registry (models + releases with aliases `champion` / `challenger`),
container registry (images), Argo CD (what's running where).

## Open-source vs AWS mapping

| Need | Open-source / k8s | AWS-native |
|---|---|---|
| Orchestration | Argo Workflows, Prefect, Airflow | Step Functions, SageMaker Pipelines |
| Tracing | Langfuse, Phoenix, OTel | CloudWatch + X-Ray, AgentCore Observability |
| Metrics + alerts | Prometheus + Alertmanager + Grafana | CloudWatch metrics/alarms + SNS |
| Registry | MLflow | SageMaker Model Registry, Bedrock custom models |
| Fine-tuning | HF TRL / LoRA on GPU nodes | Bedrock model customization, SageMaker training |
| Deploy | Argo CD + Argo Rollouts on k8s | EKS (same) / ECS + CodeDeploy canaries |
| Event triggers | Argo Events | EventBridge |
