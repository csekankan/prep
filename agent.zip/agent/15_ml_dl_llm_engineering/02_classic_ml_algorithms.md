# 02 — Classic ML Algorithms (With the Math, Slowly)

> **Why it matters:** linear and logistic regression contain *every* core idea of deep learning —
> a model, a loss, a gradient, an update rule, regularization. A neural network is just many of
> these stacked. Learn them well here and modules 04–08 become easy.
>
> Deeper math: [linear algebra](../14_math_for_ml_dl_llm/01_linear_algebra.md),
> [gradients](../14_math_for_ml_dl_llm/02_calculus_gradients.md),
> [optimization](../14_math_for_ml_dl_llm/05_optimization.md),
> [classical ML math](../14_math_for_ml_dl_llm/08_classical_ml_math.md).

## In plain words

Imagine you're a new real-estate agent guessing house prices. At first your guesses are way off. Each
time a house sells, you compare your guess with the real price and adjust your mental rule a little:
"I'm underpricing big houses — I should give size more weight." After a few hundred sales, your
guesses are good.

That loop — **guess, measure the error, nudge the rule, repeat** — is exactly how every algorithm in
this module (and every neural network later) learns. The "rule" is a set of numbers (weights), the
"error" is the loss, and the "nudge" is gradient descent.

| Algorithm | Everyday analogy |
|---|---|
| Linear regression | "price ≈ $300 per sq ft + $50k base" — a weighted checklist |
| Logistic regression | a credit officer's scorecard that turns points into a probability of default |
| Decision tree | a game of 20 questions: "income > 50k? → has defaulted before? → …" |
| Random forest | asking 500 slightly different experts and taking a vote |
| Gradient boosting | a team where each new member focuses on fixing the mistakes of the previous ones |
| k-nearest neighbors | "you're probably like the 5 customers most similar to you" |
| k-means | sorting a pile of socks into k piles by color without being told the colors |

## Architecture at a glance: the training loop

```mermaid
flowchart LR
  D[(Training data<br/>X, y)] --> F["Model<br/>ŷ = f(X; w)"]
  W[(Weights w<br/>start random/zero)] --> F
  F --> L[Loss<br/>compare ŷ with y]
  L --> G[Gradient<br/>which way to nudge each weight]
  G --> U[Update<br/>w ← w − η · gradient]
  U --> W
  L -->|loss stops improving| DONE[Trained model]
```

**How to read it:** the loop runs thousands of times. Each pass, the model predicts, the loss scores
the predictions, the gradient says how to change each weight to reduce the loss, and the update
applies a small step. Swap "linear model" for "transformer" and this is still the exact loop used to
train GPT.

## 1. Linear regression — predicting a number

### Intuition

You want to predict house price from size. Plot the data and draw the "best" straight line.

$$
\hat{y} = w x + b
$$

**Read it as:** "price = (price per square foot) × size + base price." $w$ is the slope, $b$ the
intercept. With many features (size, rooms, age), each gets its own weight:

$$
\hat{y} = w_1 x_1 + w_2 x_2 + \dots + w_d x_d + b = \mathbf{w}^\top \mathbf{x} + b
$$

**Read it as:** a **dot product** — multiply each feature by its weight and add them up. In code:
`sum(w[j] * x[j] for j in range(d)) + b`, or `w @ x + b` in NumPy.

For all $n$ rows at once, stack them into a matrix $X$ of shape $(n, d)$:

$$
\hat{\mathbf{y}} = X\mathbf{w} + b
$$

That's one matrix–vector multiply producing $n$ predictions. This "batch everything into a matmul"
trick is why GPUs matter later.

### The loss: Mean Squared Error (MSE)

$$
L(\mathbf{w}, b) = \frac{1}{n}\sum_{i=1}^{n}\big(\hat{y}_i - y_i\big)^2
$$

**Read it as:** "for every row, take (prediction − truth), square it, then average."

Why square? (1) errors above and below don't cancel out, (2) big errors are punished much more than
small ones, (3) it's smooth, so it has clean derivatives. It also has a probabilistic meaning: if
noise is Gaussian, minimizing MSE = maximum likelihood (see module 03 of the math course).

### Worked example by hand

Data: $(x, y) = (1, 2), (2, 4), (3, 7)$. Try $w = 2, b = 0$:

| $x$ | $y$ | $\hat{y} = 2x$ | error | error² |
|---|---|---|---|---|
| 1 | 2 | 2 | 0 | 0 |
| 2 | 4 | 4 | 0 | 0 |
| 3 | 7 | 6 | −1 | 1 |

$L = (0 + 0 + 1)/3 = 0.333$. Can we do better? That's what the optimizer answers.

### Finding the best weights, option A: the closed form

Because MSE is a bowl-shaped (convex) function of $\mathbf{w}$, we can set the derivative to zero and
solve directly. Folding $b$ into $\mathbf{w}$ by adding a column of 1s to $X$:

$$
\mathbf{w}^* = (X^\top X)^{-1} X^\top \mathbf{y}
$$

**Read it as:** the "normal equation". It's exact, but inverting a $d \times d$ matrix costs about
$O(d^3)$ and needs all data in memory. Fine for $d = 100$; impossible for a neural network with
$d = 10^9$ parameters. So we need a method that scales.

### Option B: gradient descent (the method behind all of deep learning)

**Intuition:** you're blindfolded on a hilly field and want to reach the lowest point. Feel the slope
under your feet and take a small step downhill. Repeat.

The **gradient** $\nabla L$ is a vector of partial derivatives — one per parameter — that points
in the direction of steepest *increase*. So we step the opposite way:

$$
\mathbf{w} \leftarrow \mathbf{w} - \eta\, \nabla_{\mathbf{w}} L
$$

**Read it as:** "new weights = old weights − learning rate × slope." $\eta$ (eta) is the step size.

For MSE, the gradients are (derivation: chain rule on $(\hat{y}-y)^2$ gives $2(\hat{y}-y)\cdot\frac{\partial \hat{y}}{\partial w}$):

$$
\frac{\partial L}{\partial \mathbf{w}} = \frac{2}{n} X^\top(\hat{\mathbf{y}} - \mathbf{y}),
\qquad
\frac{\partial L}{\partial b} = \frac{2}{n}\sum_i (\hat{y}_i - y_i)
$$

**Read it as:** "each weight's slope = average of (error × that weight's input feature)." If a feature
was large on rows where we over-predicted, decrease its weight. Intuitive!

**One step by hand** on the data above, starting at $w=2, b=0$, $\eta = 0.1$:
errors $= (0, 0, -1)$.
$\partial L/\partial w = \frac{2}{3}(1\cdot0 + 2\cdot0 + 3\cdot(-1)) = -2$,
$\partial L/\partial b = \frac{2}{3}(-1) = -0.667$.
New $w = 2 - 0.1(-2) = 2.2$, new $b = 0 + 0.0667 = 0.067$.
New predictions $(2.27, 4.47, 6.67)$, new loss $= (0.071 + 0.218 + 0.111)/3 = 0.133$. Down from 0.333. ✔

### Code: gradient descent from scratch

```python
import numpy as np

rng = np.random.default_rng(0)
X = rng.uniform(0, 10, size=(200, 1))
y = 3.0 * X[:, 0] + 5.0 + rng.normal(0, 1, 200)      # true w=3, b=5, plus noise

w, b, lr = 0.0, 0.0, 0.01
for step in range(2000):
    y_hat = X[:, 0] * w + b
    err = y_hat - y
    dw = 2 * np.mean(err * X[:, 0])
    db = 2 * np.mean(err)
    w -= lr * dw
    b -= lr * db
    if step % 500 == 0:
        print(step, round(np.mean(err**2), 3), round(w, 3), round(b, 3))
# converges to w≈3.0, b≈5.0
```

### The learning rate, visually

```
 η too small:  ●→●→●→●→●→●→●→●→ ... (slow, may never arrive in budget)
 η just right: ●───►●──►●─►●►●  (converges)
 η too large:  ●        ●            (overshoots, bounces, loss explodes to NaN)
                 ╲    ╱   ╲      ╱
                   ●        ●
```

### Batch, stochastic, mini-batch

| Variant | Gradient computed on | Pros | Cons |
|---|---|---|---|
| Batch GD | all $n$ rows per step | exact gradient | slow per step, memory |
| Stochastic GD (SGD) | 1 row per step | fast, noisy (noise helps escape bad spots) | very noisy |
| **Mini-batch** | $B$ rows (32–4096) | GPU-friendly, good balance | — **this is what everyone uses** |

One **epoch** = one full pass over the training data.

## 2. Logistic regression — predicting a class

### From scores to probabilities

For spam/not spam we want $P(y = 1 \mid \mathbf{x})$, a number in $[0,1]$. A linear score
$z = \mathbf{w}^\top\mathbf{x} + b$ can be any real number, so squash it with the **sigmoid**:

$$
\sigma(z) = \frac{1}{1 + e^{-z}}
$$

| $z$ | −5 | −2 | 0 | 2 | 5 |
|---|---|---|---|---|---|
| $\sigma(z)$ | 0.007 | 0.12 | 0.5 | 0.88 | 0.993 |

**Read it as:** big positive score → near 1; big negative → near 0; zero → 50/50. The score $z$ is
called the **logit** (log-odds): $z = \log\frac{p}{1-p}$. A weight $w_j = 0.7$ means "one unit more
of feature $j$ multiplies the odds by $e^{0.7} \approx 2$." That's why logistic regression is loved
in regulated industries — it's explainable.

### Why not MSE? Use cross-entropy (log loss)

$$
L = -\frac{1}{n}\sum_{i=1}^{n}\Big[\,y_i \log \hat{p}_i + (1-y_i)\log(1-\hat{p}_i)\Big]
$$

**Read it as:** "if the true label is 1, the loss is $-\log \hat{p}$; if it's 0, the loss is
$-\log(1-\hat{p})$." So you're penalized by how *surprised* you were by the true answer:

| true $y$ | predicted $\hat{p}$ | loss $-\log(\cdot)$ |
|---|---|---|
| 1 | 0.9 | 0.105 (confident and right: tiny loss) |
| 1 | 0.5 | 0.693 |
| 1 | 0.1 | 2.303 (confident and wrong: big loss) |
| 1 | 0.001 | 6.9 |

This comes from maximum likelihood: we choose $\mathbf{w}$ that makes the observed labels most
probable. **This same loss, generalized to many classes, is exactly what trains GPT** (module 08) —
there, the "classes" are the ~100k tokens in the vocabulary.

### The beautiful gradient

Combining sigmoid + cross-entropy, the derivative simplifies to:

$$
\frac{\partial L}{\partial \mathbf{w}} = \frac{1}{n} X^\top(\hat{\mathbf{p}} - \mathbf{y})
$$

Same shape as linear regression: (prediction − truth) × input. The same "error × input" pattern
appears in the last layer of every neural net.

### Multi-class: softmax

With $K$ classes, compute $K$ scores $z_1..z_K$ and turn them into probabilities that sum to 1:

$$
\text{softmax}(\mathbf{z})_k = \frac{e^{z_k}}{\sum_{j=1}^{K} e^{z_j}}
$$

Example: $\mathbf{z} = (2, 1, 0.1)$ → $e^{\mathbf{z}} = (7.39, 2.72, 1.11)$, sum $= 11.22$ →
probabilities $(0.66, 0.24, 0.10)$. Loss = $-\log(\text{prob of the true class})$.

> Practical: compute softmax as `exp(z - max(z))` to avoid overflow. Subtracting a constant doesn't
> change the result.

### Decision threshold

The model outputs a probability; *you* pick the threshold. 0.5 is a default, not a law. For fraud,
you might flag at 0.1 (catch more, accept false alarms). Module 03 covers choosing it from costs.

## 3. Overfitting, underfitting, and the bias–variance trade-off

Fit polynomials of degree 1, 3 and 15 to 20 noisy points from a curve:

```
 degree 1 (underfit)     degree 3 (good)        degree 15 (overfit)
   ·   ·  ___——            ·  _—·—_               ·╭╮ ·╭─╮
  ·__——·                  _—·     —_·            ╭╯╰─╯· ╰╮╭·
 —· ·                   ·—          ·           ·╯       ╰╯
 train err: high         train err: low         train err: ~0
 test err:  high         test err:  low         test err:  HUGE
```

The expected test error decomposes into three parts:

$$
\mathbb{E}\big[(y - \hat{f}(x))^2\big] = \underbrace{\text{Bias}^2}_{\text{too simple}} + \underbrace{\text{Variance}}_{\text{too sensitive to the training sample}} + \underbrace{\sigma^2}_{\text{irreducible noise}}
$$

**Read it as:**
- **Bias:** systematic error from wrong assumptions (a line can't fit a curve). Fix: a more flexible
  model, better features.
- **Variance:** the model changes a lot if you retrain on a different sample — it learned the noise.
  Fix: more data, regularization, simpler model, ensembling.
- **Noise:** label noise you can never remove.

| Symptom | Train error | Val error | Diagnosis | Fixes |
|---|---|---|---|---|
| Both high | high | high | underfitting (bias) | bigger model, more features, train longer |
| Big gap | low | high | overfitting (variance) | more data, regularization, dropout, early stopping |
| Both low | low | low | 🎉 | ship it (after the test set check) |

> Deep-learning twist: very large neural nets can be past the "overfit" point and still generalize
> well ("double descent"). LLMs are trained in a regime where more parameters + more data keeps helping.
> The classic trade-off is still the right mental model for small/medium models.

## 4. Regularization — penalizing complexity

Add a penalty on the size of the weights to the loss:

$$
L_{\text{ridge}} = \text{MSE} + \lambda \sum_j w_j^2 \quad (\text{L2}), \qquad
L_{\text{lasso}} = \text{MSE} + \lambda \sum_j |w_j| \quad (\text{L1})
$$

**Read it as:** "be accurate, but keep weights small." $\lambda$ controls the trade-off: 0 = no
penalty, huge = all weights forced to ~0.

| | L2 (Ridge, "weight decay") | L1 (Lasso) |
|---|---|---|
| Effect | shrinks all weights smoothly | drives many weights to **exactly 0** |
| Use | default; correlated features | automatic feature selection, sparse models |
| In deep learning | **weight decay** in AdamW — used in every LLM | rare |

Why does L2 help? Its gradient adds $2\lambda w$, so each update is
$w \leftarrow w(1 - 2\eta\lambda) - \eta\nabla\text{MSE}$: the weight "decays" toward zero every step
unless the data keeps pushing it back. Only features that genuinely help survive at large values.

## 5. Decision trees and ensembles (the tabular champions)

### Decision trees

A tree asks yes/no questions: "income > 50k?" → "age < 30?" → predict. It learns splits greedily:
at each node, try every feature and threshold, and pick the split that makes the children
**purest**. Purity is measured with **Gini impurity** or **entropy**:

$$
\text{Gini} = 1 - \sum_k p_k^2, \qquad \text{Entropy} = -\sum_k p_k \log_2 p_k
$$

Example: a node with 50 spam / 50 ham has Gini $= 1 - (0.25 + 0.25) = 0.5$ (worst).
A node with 90/10 has Gini $= 1 - (0.81 + 0.01) = 0.18$. A pure node has 0. The split chosen is the
one that reduces weighted impurity the most.

Trees are interpretable and need no feature scaling, but a single deep tree overfits badly (high variance).

### Random forests (bagging)

Train hundreds of trees, each on a **bootstrap sample** (random rows with replacement) and random
feature subsets, then **average** their votes. Averaging many noisy-but-different models reduces
variance: if each tree's error were independent, averaging $M$ trees divides variance by $M$.

### Gradient boosting (XGBoost, LightGBM, CatBoost)

Build trees **sequentially**: each new small tree predicts the *residual errors* of the ensemble so far.

$$
F_m(\mathbf{x}) = F_{m-1}(\mathbf{x}) + \nu \cdot h_m(\mathbf{x})
$$

**Read it as:** "new model = old model + a small step ($\nu$ = learning rate, e.g. 0.05) × a tree
fitted to what the old model got wrong." Technically, $h_m$ fits the negative gradient of the loss —
it's gradient descent in *function space*.

| | Random forest | Gradient boosting |
|---|---|---|
| Trees built | in parallel, independent | sequentially, each fixes the last |
| Reduces mainly | variance | bias (and variance with regularization) |
| Tuning effort | low | medium (learning rate, depth, n_trees, early stopping) |
| Accuracy on tabular data | very good | usually **the best** |

## 6. Other algorithms worth knowing

| Algorithm | Idea in one line | Math core | Use when |
|---|---|---|---|
| **k-Nearest Neighbors** | predict the majority label of the $k$ closest training points | distance $\lVert\mathbf{x}-\mathbf{x}'\rVert_2$ | small data, baselines; it's the ancestor of **vector search in RAG** |
| **Naive Bayes** | assume features independent given the class | Bayes: $P(y\mid\mathbf{x}) \propto P(y)\prod_j P(x_j\mid y)$ | text classification baselines, very fast |
| **SVM** | find the boundary with the widest margin between classes | maximize $2/\lVert\mathbf{w}\rVert$ s.t. $y_i(\mathbf{w}^\top\mathbf{x}_i+b)\ge1$; kernels for curves | small/medium data, high dimensions |
| **k-Means** (unsupervised) | find $k$ cluster centers | minimize $\sum_i \lVert\mathbf{x}_i - \boldsymbol{\mu}_{c(i)}\rVert^2$; alternate assign/update | segmentation, vector index partitioning (IVF) |
| **PCA** (unsupervised) | project onto the directions of max variance | eigenvectors of the covariance matrix / SVD | compression, visualization, denoising |
| **Isolation Forest** | anomalies are easy to isolate with random splits | average path length | fraud/anomaly detection |

### k-Means in 10 lines

```python
import numpy as np

def kmeans(X, k, iters=50, seed=0):
    rng = np.random.default_rng(seed)
    centers = X[rng.choice(len(X), k, replace=False)]
    for _ in range(iters):
        dists = ((X[:, None, :] - centers[None, :, :]) ** 2).sum(-1)   # (n, k)
        labels = dists.argmin(1)                                       # assign step
        centers = np.array([X[labels == j].mean(0) for j in range(k)]) # update step
    return labels, centers
```

## 7. Picking an algorithm

```
 Is the data tabular (rows × meaningful columns)?
   ├─ yes ─► baseline: logistic/linear regression ─► then gradient boosting (LightGBM/XGBoost)
   └─ no ─► images / audio / text / sequences?
              └─ yes ─► deep learning (pretrained model + fine-tune; modules 04–09)
 Need explanations for regulators? ─► linear models, shallow trees, or GBM + SHAP values
 No labels? ─► clustering, anomaly detection, or self-supervised pretraining
```

## 8. Key takeaways

- **Model + loss + gradient descent** is the universal recipe; linear/logistic regression show it in miniature.
- Cross-entropy loss and softmax here are exactly what LLMs use at vocabulary scale.
- Bias–variance explains when to make a model bigger vs regularize it.
- For tabular data, gradient-boosted trees are the default strong model.

## Interview questions

1. *Why cross-entropy instead of MSE for classification?* — MSE with a sigmoid gives a non-convex loss
   and tiny gradients when predictions are confidently wrong; cross-entropy is convex for logistic
   regression and gives gradient $\hat{p}-y$, strong when wrong.
2. *L1 vs L2?* — L1 yields sparse weights (its gradient is constant $\pm\lambda$, pushing small weights
   all the way to 0); L2 shrinks smoothly.
3. *Bagging vs boosting?* — bagging averages independent high-variance models; boosting sequentially
   fits residuals to reduce bias.
4. *Why does gradient descent need feature scaling?* — features on different scales make the loss
   surface a long thin valley; one learning rate is too big for one direction and too small for the
   other, causing zig-zagging.
