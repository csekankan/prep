# 03 — ML in Practice: Data, Features, Validation, Metrics

> **Why it matters:** most failed ML projects don't fail because of the algorithm. They fail from
> leaked data, the wrong metric, a bad split, or training data that doesn't match production.
> This module is the "engineering discipline" half of ML.

## In plain words

Think of a student preparing for an exam:

| Exam analogy | ML concept |
|---|---|
| Textbook exercises they practice on | **training set** |
| Mock exams used to decide what to study more | **validation set** |
| The real final exam, seen only once | **test set** |
| Memorizing the answer key instead of learning | **overfitting** |
| Accidentally seeing the final exam questions beforehand | **data leakage** |
| Grading only "did they finish?" instead of "did they get it right?" | **wrong metric** |
| Studying 2019 exams when the 2025 syllabus changed | **distribution shift** |

A student who scores 100% because they saw the answers learned nothing. A model with leaked data is
the same: brilliant in the notebook, useless in production.

## Architecture at a glance: a leak-free ML pipeline

```mermaid
flowchart LR
  RAW[(Raw data)] --> SPLIT{Split FIRST<br/>random / by time / by group}
  SPLIT --> TR[(Train)]
  SPLIT --> VA[(Validation)]
  SPLIT --> TE[(Test<br/>locked away)]
  TR --> FIT[Fit preprocessing<br/>scaler, imputer, encoder<br/>on train ONLY]
  FIT --> MOD[Train model]
  MOD --> EVV[Evaluate on validation<br/>metrics, slices, errors]
  VA --> EVV
  EVV -->|iterate: features,<br/>hyperparameters| FIT
  EVV -->|final choice| EVT[One evaluation<br/>on test]
  TE --> EVT
  EVT --> SHIP[Ship preprocessing<br/>+ model as one artifact]
```

**How to read it:** split before doing anything else, learn every transformation only from the
training split, iterate against validation as often as you like, and open the test set exactly once.
The arrow back from validation is where 90% of the work happens.

## 1. Data splits — your unit tests

```
 ┌───────────────────────── all labeled data ──────────────────────────┐
 │        train (60–80%)           │ validation (10–20%) │ test (10–20%)│
 │  fit parameters (weights)       │ choose hyperparams, │ touched ONCE │
 │                                 │ models, features    │ at the end   │
 └─────────────────────────────────┴─────────────────────┴──────────────┘
```

- **Train:** the model learns from it.
- **Validation:** you learn from it (which model, which features, which learning rate). Because
  *you* adapt to it, its score becomes optimistic over time.
- **Test:** the honest final estimate. If you tune on the test set, it's no longer a test set — it's
  a second validation set and your reported number is a lie.

### Choosing the split strategy

| Data | Split | Why |
|---|---|---|
| i.i.d. rows (independent) | random, **stratified** for classification | keeps class ratios equal in every split |
| Time-dependent (sales, fraud, churn) | **by time**: train on past, validate on future | production always predicts the future; random splits leak tomorrow into today |
| Groups (multiple rows per user/patient) | **group split** (all rows of a user in one split) | otherwise the model memorizes the user, not the pattern |
| Very small data | **k-fold cross-validation** | uses every row for both training and validation |

### k-fold cross-validation

Split training data into $k$ folds (typically 5). Train $k$ times, each time holding out a different
fold for validation; report the mean and standard deviation of the $k$ scores.

```
 fold:   1     2     3     4     5
 run 1: [VAL] [tr ] [tr ] [tr ] [tr ]
 run 2: [tr ] [VAL] [tr ] [tr ] [tr ]
 ...
 run 5: [tr ] [tr ] [tr ] [tr ] [VAL]     score = mean ± std over the 5 runs
```

The **std** matters: model A at 0.84 ± 0.03 vs model B at 0.85 ± 0.03 is not a real difference.

## 2. Data leakage — the #1 silent bug

Leakage = information available during training that **won't be available at prediction time**.
The symptom: amazing offline metrics, terrible production performance.

| Leak | Example | Fix |
|---|---|---|
| Target leakage | predicting "will churn" using `cancellation_reason` (only filled after churn) | for every feature ask: "would I know this at prediction time?" |
| Train/test contamination | fitting the scaler/imputer/vocabulary on all data before splitting | split first; fit preprocessing on train only (use a `Pipeline`) |
| Temporal leakage | random split on time series; features computed with future data (e.g. "30-day avg" centered on today) | time-based split; point-in-time-correct feature joins |
| Duplicate leakage | same customer/image/near-duplicate text in train and test | dedupe, group split |
| LLM benchmark contamination | test questions appeared in pretraining data | held-out private evals, n-gram overlap checks |

> Rule of thumb: if a model looks too good to be true (99.8% on a hard problem), assume leakage until
> proven otherwise. Check feature importances — a single dominant feature is a red flag.

## 3. Feature engineering and preprocessing

| Data type | Technique | Why |
|---|---|---|
| Numeric | **standardize**: $x' = (x - \mu)/\sigma$ | gradient descent, kNN, SVM, neural nets need comparable scales (trees don't) |
| Skewed numeric (income, counts) | $\log(1 + x)$ | compresses long tails |
| Missing values | impute (median/mode) **+ add an "is_missing" flag** | missingness is often informative |
| Categorical, few values | one-hot encoding | `color=red` → `[1,0,0]` |
| Categorical, many values (zip, user_id) | target encoding (with CV!), hashing, or **embeddings** | one-hot would create 40k columns |
| Dates | day-of-week, hour, month, "days since X", holidays | models don't understand timestamps |
| Text (classic) | TF-IDF, n-grams | bag-of-words features for linear models |
| Text/images (modern) | **pretrained embeddings** | a vector from a neural net as features |
| Interactions | ratios, differences (`debt / income`) | linear models can't create these themselves |

**TF-IDF** in one formula: a word's weight in a document is
$\text{tf}(t,d)\cdot\log\frac{N}{\text{df}(t)}$ — frequent in this document, rare across all
documents ⇒ important. "the" gets ~0 weight; "chargeback" gets a lot.

## 4. Metrics — choosing what "good" means

### Regression

| Metric | Formula | Use |
|---|---|---|
| MAE | $\frac{1}{n}\sum\lvert y-\hat{y}\rvert$ | robust to outliers; in the target's units ("off by $12k on average") |
| RMSE | $\sqrt{\frac{1}{n}\sum(y-\hat{y})^2}$ | punishes big errors more |
| MAPE | $\frac{100}{n}\sum\left\lvert\frac{y-\hat{y}}{y}\right\rvert$ | percent error; breaks when $y \approx 0$ |
| $R^2$ | $1 - \frac{\sum(y-\hat{y})^2}{\sum(y-\bar{y})^2}$ | fraction of variance explained; 0 = predicting the mean |

### Classification: the confusion matrix

```
                    predicted positive   predicted negative
 actual positive         TP                    FN   (missed)
 actual negative         FP (false alarm)      TN
```

$$
\text{Precision} = \frac{TP}{TP+FP}, \quad
\text{Recall} = \frac{TP}{TP+FN}, \quad
F_1 = \frac{2 \cdot P \cdot R}{P + R}
$$

**Read it as:**
- **Precision:** "of everything I flagged, how much was really positive?" (avoid false alarms)
- **Recall:** "of all real positives, how many did I catch?" (avoid misses)
- **F1:** harmonic mean — high only if both are high.

### Why accuracy lies

Fraud rate 0.5%. A model that always says "not fraud" has **99.5% accuracy** and catches zero fraud.
On imbalanced data, use precision/recall, PR-AUC, or cost-based metrics.

### Worked example

1,000 transactions, 20 frauds. Model flags 50; 15 of those are fraud.
TP = 15, FP = 35, FN = 5, TN = 945.
Precision = 15/50 = 0.30. Recall = 15/20 = 0.75. F1 = 2·0.3·0.75/1.05 = 0.43. Accuracy = 96% (meaningless here).

### Threshold-free metrics

- **ROC-AUC:** probability that a random positive is scored higher than a random negative. 0.5 =
  random, 1.0 = perfect. Can look great on very imbalanced data.
- **PR-AUC (average precision):** area under the precision–recall curve. Better for rare positives.
- **Log loss / Brier score:** measures **calibration** — when the model says 0.8, is it right 80% of the time?
  Matters when probabilities feed downstream decisions (pricing, risk).

### Picking the threshold from business costs

If a missed fraud costs \$500 and a false alarm (manual review) costs \$5, flag when

$$
p \cdot 500 > (1-p)\cdot 5 \;\Rightarrow\; p > \frac{5}{505} \approx 0.01
$$

**Read it as:** flag whenever the expected cost of ignoring exceeds the expected cost of reviewing.
This only works if probabilities are calibrated (use `CalibratedClassifierCV` if they're not).

### Ranking / recommendation / retrieval metrics

| Metric | Meaning |
|---|---|
| Precision@k / Recall@k | of the top $k$ results, how many are relevant / how many relevant items did we get |
| MRR | average of $1/\text{rank}$ of the first relevant item |
| NDCG@k | rewards relevant items more when they're ranked higher |

These are the same metrics used to evaluate RAG retrievers (`04_rag/`, `07_evaluation/`).

## 5. Imbalanced data

| Technique | How | Caveat |
|---|---|---|
| Class weights | weight the loss: rare class errors count more (`class_weight="balanced"`) | simplest, try first |
| Resampling | undersample majority / oversample minority (SMOTE) | only on train split, never on val/test |
| Threshold tuning | pick the threshold on validation using PR curve or costs | often the biggest win |
| Better metric | PR-AUC, recall@precision | stops you optimizing the wrong thing |
| Focal loss (DL) | down-weight easy examples | used in object detection |

## 6. Hyperparameter tuning

Parameters are learned (weights). **Hyperparameters** are chosen by you (learning rate, tree depth,
$\lambda$, number of layers).

| Method | Idea | When |
|---|---|---|
| Grid search | try every combination | ≤ 2–3 hyperparameters |
| Random search | sample combinations randomly | better than grid in most cases — few hyperparameters really matter, random covers each one more densely |
| Bayesian optimization (Optuna, Hyperopt) | model "hyperparams → score" and try promising points next | expensive training runs |
| Early stopping | stop when validation loss stops improving | always, for iterative models (GBM, NNs) |

Tune on validation (or with CV). Use a log scale for learning rate and $\lambda$: try
$10^{-4}, 10^{-3}, 10^{-2}$, not $0.001, 0.002, 0.003$.

## 7. Error analysis — the highest-leverage habit

After evaluating, **look at the mistakes**. Pull 100 wrong predictions and categorize them:

| Error category | Count | Action |
|---|---|---|
| Label is actually wrong | 23 | fix labels (cheap, big win) |
| Blurry / low-quality input | 31 | add augmentation or reject low-quality inputs |
| Rare subgroup (e.g. non-English) | 28 | collect more data for that slice |
| Genuinely ambiguous | 18 | accept, or route to a human |

Also measure metrics **per slice** (country, device, new vs returning users). A model at 92% overall
may be at 60% for one segment — a fairness problem and a business problem.

## 8. A production-shaped scikit-learn pipeline

```python
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.ensemble import HistGradientBoostingClassifier

df = pd.read_csv("churn.csv")
y = df.pop("churned")
num_cols = ["tenure_days", "monthly_spend", "support_tickets"]
cat_cols = ["plan", "country", "device"]

preprocess = ColumnTransformer([
    ("num", Pipeline([("impute", SimpleImputer(strategy="median", add_indicator=True)),
                      ("scale", StandardScaler())]), num_cols),
    ("cat", OneHotEncoder(handle_unknown="ignore", min_frequency=20), cat_cols),
])

model = Pipeline([
    ("prep", preprocess),                      # fitted on train folds only -> no leakage
    ("clf", HistGradientBoostingClassifier(learning_rate=0.05, max_iter=500,
                                           early_stopping=True, class_weight="balanced")),
])

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, df, y, cv=cv, scoring="average_precision")
print(f"PR-AUC: {scores.mean():.3f} ± {scores.std():.3f}")

model.fit(df, y)                               # final fit, then save the WHOLE pipeline
import joblib; joblib.dump(model, "churn_model.joblib")
```

Why save the whole pipeline: preprocessing *is part of the model*. If production scales features
differently from training, predictions are garbage (training–serving skew, module 10).

## 9. Key takeaways

- Split by how the model will be used (time, groups); keep the test set sacred.
- Leakage is the most common reason for "great offline, bad online".
- Pick metrics from the business decision; accuracy is usually wrong on imbalanced data.
- Look at errors and slices, not just one aggregate number.
- Ship preprocessing + model as one artifact.

## Interview questions

1. *Your model has 0.99 AUC offline and 0.62 in production. What do you check?* — leakage (features
   unavailable at serving time), training–serving skew in preprocessing, time-based drift, a different
   population in production, label definition mismatch.
2. *Precision vs recall for cancer screening?* — recall (missing a cancer is far worse than a follow-up
   test); then optimize precision subject to a recall floor.
3. *Why random search over grid search?* — with a fixed budget, random search tries more distinct
   values of each important hyperparameter.
