# 09 — Using & Adapting LLMs in Practice

> **Why it matters:** as an engineer you rarely pretrain a model. You *choose* one, *steer* it with
> prompts and retrieval, *adapt* it with fine-tuning when needed, *shrink* it with quantization, and
> *prove* it works with evals. This module is the practical toolkit, with the math that tells you
> what fits on which GPU.

## In plain words

Think of a pretrained LLM as a brilliant new hire who has read everything but knows nothing about
*your* company.

| Technique | Analogy | Changes the model's weights? |
|---|---|---|
| **Prompting** | giving clear instructions and a few examples for the task | no |
| **RAG** | handing them the right company documents before each question (open-book exam) | no |
| **Fine-tuning** | sending them on a training course so the skill/style becomes habit | yes |
| **Quantization** | the same person, but notes compressed into shorthand so they fit in a smaller briefcase | yes (precision, not knowledge) |
| **Distillation** | the expert trains a junior who's cheaper to employ | a new, smaller model |

The most common mistake: fine-tuning to teach **facts**. Fine-tuning teaches *behavior and format*;
RAG supplies *knowledge*. (Open-book beats memorizing for facts that change.)

## 1. Architecture at a glance: the decision path

```mermaid
flowchart TD
  S[New LLM use case] --> P{Does a good prompt<br/>+ few examples work?}
  P -->|yes| DONE[Ship prompt + evals]
  P -->|no: lacks knowledge| R{Is the missing piece<br/>facts / private data / fresh data?}
  R -->|yes| RAG[Add RAG<br/>retrieve docs into the prompt]
  RAG --> E1{Good enough?}
  E1 -->|yes| DONE
  E1 -->|no| FT
  R -->|no: behavior, format,<br/>style, narrow skill, latency/cost| FT[Fine-tune<br/>LoRA / QLoRA on a smaller model]
  FT --> E2{Beats the prompted<br/>big model on evals?}
  E2 -->|yes| DONE2[Ship fine-tuned model<br/>+ RAG if needed]
  E2 -->|no| DATA[Improve data quality,<br/>not hyperparameters]
  DATA --> FT
```

**How to read it:** go left to right in cost and complexity. Each step must be justified by an eval
that the previous step failed. Many production systems end up as **RAG + a well-prompted model**;
fine-tuning is added for consistent format, domain style, tool-calling reliability, or to replace a
large expensive model with a small cheap one.

| | Prompting | RAG | Fine-tuning |
|---|---|---|---|
| Adds new knowledge | only what fits in the prompt | ✅ yes, updatable instantly | weakly, goes stale, can increase hallucination |
| Changes style/format/behavior | somewhat | no | ✅ strongly |
| Data needed | 0–20 examples | a document corpus | 500–50,000 high-quality examples |
| Cost to change | minutes | re-index documents | a training run + evals |
| Explainability | prompt is readable | ✅ can cite sources | opaque |
| Latency/cost at inference | long prompts cost tokens | retrieval + longer prompts | ✅ can use a smaller model, shorter prompts |

## 2. Choosing a model

| Question | Why it matters |
|---|---|
| API (closed) or open-weights? | data residency, cost at scale, customization, vendor lock-in (see `13_sovereign_ai_infra_course/`) |
| Size (1B / 8B / 70B / frontier)? | quality vs latency and GPU cost |
| Context length needed? | long documents vs KV cache cost (module 08) |
| Licensing | commercial use restrictions on some open models |
| Tool calling / structured output support | agents (`02_single_agent/`) need this to be reliable |
| **Your own eval scores** | public leaderboards don't measure your task |

Rule: prototype with the strongest model to learn what's *possible*, then try smaller/cheaper models
against the same eval set.

## 3. Prompting techniques that matter

| Technique | Plain words | Example |
|---|---|---|
| Clear role + task + constraints | tell it exactly what to do and not do | "You are a support agent. Answer only from the context. If unsure, say so." |
| Few-shot examples | show 2–5 input→output pairs | the model copies the pattern (in-context learning) |
| Structured output | ask for JSON with a schema; use the API's structured-output mode | reliable parsing |
| Chain of thought | "think step by step" or reasoning models | better on math/logic; costs tokens |
| Decomposition | split a big task into steps/calls | easier to evaluate each step |
| Delimiters | wrap data in tags `<doc>...</doc>` | reduces prompt injection risk (`12_ai_security_governance/`) |

**Why few-shot works (in-context learning):** attention lets the model find the pattern in the examples
and apply it to the new input — no weight updates. It's a learned skill from pretraining on text that
naturally contains patterns.

## 4. RAG in one diagram (details in `04_rag/`)

```mermaid
flowchart LR
  subgraph OFFLINE["Indexing (offline)"]
    D[Documents] --> CH[Chunk<br/>~300–800 tokens]
    CH --> EM[Embedding model<br/>text → vector]
    EM --> VDB[(Vector DB)]
  end
  subgraph ONLINE["Query time"]
    Q[User question] --> QE[Embed question]
    QE --> S[Similarity search<br/>top-k by cosine]
    VDB --> S
    S --> RR[Rerank<br/>cross-encoder]
    RR --> PR[Prompt = instructions<br/>+ retrieved chunks + question]
    PR --> LLM[LLM] --> A[Answer with citations]
  end
```

The math is module 07's cosine similarity: retrieve chunks whose embedding vectors point in the same
direction as the question's. Vector databases use approximate nearest-neighbor indexes (HNSW graphs,
IVF clustering = k-means from module 02) to search millions of vectors in milliseconds.

## 5. Fine-tuning: full vs parameter-efficient

### Full fine-tuning

Update all weights. Needs ~16 bytes/param (module 08): 112 GB for 7B. Risk: **catastrophic forgetting**
(the model gets good at your task and worse at everything else).

### LoRA (Low-Rank Adaptation)

**Idea:** freeze the original weight matrix $W$ and learn a small *correction* expressed as the
product of two thin matrices:

$$
W' = W + \Delta W = W + \frac{\alpha}{r} B A, \qquad B \in \mathbb{R}^{d \times r},\; A \in \mathbb{R}^{r \times k},\; r \ll d
$$

```
          frozen                trainable (tiny)
 x ──►  [   W   ]  ─────────┐
 (k)    (d × k)             (+) ──► h (d)
   └──► [ A ] ──► [ B ] ────┘
        (r × k)   (d × r)        r = 8..64, e.g. 16
```

**Read it as:** "the change needed to adapt the model is simple" — it lives in a low-dimensional
subspace, so a rank-$r$ update captures it. $B$ starts at zero, so training begins exactly at the
original model. $\alpha/r$ is a scaling knob.

**Parameter math** for one $4096 \times 4096$ projection with $r = 16$:
full $= 16.8$M parameters; LoRA $= 16 \times (4096 + 4096) = 131$k → **0.78%**.
Applied to all attention and MLP projections of a 7B model: ~40M trainable parameters instead of 7B.

**Plain words:** instead of rewriting a whole textbook, you add a few sticky notes in the margins.
The textbook stays intact (no forgetting), the notes are tiny (a 50–200 MB adapter file), and you can
swap different note sets for different customers on the same base model.

| Benefit | Why |
|---|---|
| Memory | gradients and Adam state only for ~0.5% of params |
| Storage | adapters are MBs, not GBs; one base model + many adapters |
| Serving | multi-LoRA serving: vLLM can host hundreds of adapters on one base model |
| No extra latency | after training, merge: $W \leftarrow W + \frac{\alpha}{r}BA$ |

### QLoRA

Load the frozen base model in **4-bit** (NF4 format), train LoRA adapters in bf16 on top. A 7B model
fine-tunes in ~6–10 GB of GPU memory — a single consumer GPU.

### Fine-tuning with Hugging Face PEFT (LoRA/QLoRA)

```python
import torch
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from trl import SFTTrainer, SFTConfig

base = "meta-llama/Llama-3.1-8B-Instruct"
bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                         bnb_4bit_compute_dtype=torch.bfloat16)          # QLoRA
model = AutoModelForCausalLM.from_pretrained(base, quantization_config=bnb, device_map="auto")
model = prepare_model_for_kbit_training(model)
tok = AutoTokenizer.from_pretrained(base)

lora = LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, task_type="CAUSAL_LM",
                  target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                                  "gate_proj", "up_proj", "down_proj"])
model = get_peft_model(model, lora)
model.print_trainable_parameters()        # ~42M trainable of ~8B (≈0.5%)

# each row: {"messages": [{"role": "user", ...}, {"role": "assistant", ...}]}
ds = load_dataset("json", data_files={"train": "train.jsonl", "eval": "eval.jsonl"})

trainer = SFTTrainer(
    model=model, processing_class=tok,
    train_dataset=ds["train"], eval_dataset=ds["eval"],
    args=SFTConfig(output_dir="out", num_train_epochs=2, per_device_train_batch_size=4,
                   gradient_accumulation_steps=4, learning_rate=2e-4,
                   lr_scheduler_type="cosine", warmup_ratio=0.03, bf16=True,
                   logging_steps=10, eval_strategy="steps", eval_steps=100,
                   assistant_only_loss=True),             # loss only on assistant tokens
)
trainer.train()
model.save_pretrained("adapter/")          # ~100 MB adapter
```

### Fine-tuning data: what actually matters

| Do | Don't |
|---|---|
| a few thousand **clean, consistent, diverse** examples | scrape 100k noisy examples |
| match the exact format you'll use in production (system prompt, tools) | train on one format, serve another |
| include hard cases and "I don't know"/refusal examples | only easy happy paths |
| hold out an eval set **before** training; dedupe against it | evaluate on training data |
| version the dataset (module 10) | overwrite `train.jsonl` in place |

Typical settings: LoRA $r$ 8–64, lr $1\times10^{-4}$–$2\times10^{-4}$ (full FT: ~$1\times10^{-5}$),
1–3 epochs (more → overfitting/memorization).

## 6. Quantization — making models smaller and faster

### The idea

Store weights with fewer bits. Map floats to integers with a **scale** (and sometimes a zero point):

$$
q = \text{round}\!\left(\frac{w}{s}\right), \qquad s = \frac{\max|w|}{127} \;\text{(symmetric int8)}, \qquad \hat{w} = q \cdot s
$$

**Worked example:** weights $(-1.2,\ 0.3,\ 2.5,\ -0.7)$. Scale $s = 2.5/127 = 0.0197$.
$q = (-61,\ 15,\ 127,\ -36)$ — four int8 values (1 byte each, vs 2 for bf16).
Dequantized: $(-1.201,\ 0.295,\ 2.500,\ -0.709)$. Errors under 0.01.

**Plain words:** like saving a photo as a JPEG: smaller file, nearly the same picture. Outliers are the
enemy — one huge weight makes the scale big and crushes the precision for all the small ones. That's
why real methods quantize in small **groups** (e.g. 128 weights share a scale) and handle outlier
channels specially.

### Formats and methods

| Precision | Bytes/param | 7B model | 70B model | Quality impact |
|---|---|---|---|---|
| fp16/bf16 | 2 | 14 GB | 140 GB | baseline |
| int8 / fp8 | 1 | 7 GB | 70 GB | ~none with good methods |
| int4 (GPTQ, AWQ, GGUF Q4_K_M) | ~0.5–0.6 | ~4 GB | ~38 GB | small; task-dependent |
| 2–3 bit | ~0.3 | ~3 GB | ~28 GB | noticeable |

| Method | How | Where |
|---|---|---|
| GPTQ | uses a small calibration set to choose quantized values that minimize output error layer by layer | GPU serving |
| AWQ | protects the ~1% most important ("salient") channels by scaling | GPU serving (vLLM) |
| GGUF (llama.cpp) | many k-quant formats, CPU/Mac friendly | laptops, edge, Ollama |
| bitsandbytes NF4 | 4-bit normal-float, for QLoRA training | fine-tuning |
| FP8 (H100+) | hardware-native 8-bit float | high-throughput serving and training |
| KV-cache quantization | store K/V in 8-bit | longer context / more users per GPU |

**Always eval after quantizing** — quality loss is uneven: math, code, and non-English often degrade
first.

## 7. GPU memory sizing (the cheat sheet)

**Inference:**

$$
\text{memory} \approx \underbrace{N \times \text{bytes/param}}_{\text{weights}} + \underbrace{\text{KV per token} \times \text{context} \times \text{concurrent seqs}}_{\text{KV cache}} + \text{overhead (~10–20\%)}
$$

| Scenario | Weights | KV cache | Fits on |
|---|---|---|---|
| 8B bf16, 8 users × 8k context (GQA, 128 KB/token) | 16 GB | 8 GB | 1× 40–48 GB GPU |
| 8B int4, 1 user × 4k | 5 GB | 0.5 GB | laptop / 8 GB consumer GPU |
| 70B bf16, 32 users × 8k (GQA, 320 KB/token) | 140 GB | 84 GB | 4× 80 GB (tensor parallel) |
| 70B int4, 4 users × 8k | 38 GB | 10 GB | 1× 80 GB |

**Training / fine-tuning:**

| Method | 7B memory (approx., before activations) |
|---|---|
| Full FT, mixed precision AdamW | ~112 GB → multi-GPU with FSDP |
| LoRA on bf16 base | ~16 GB weights + small adapter state → 1× 24–40 GB |
| QLoRA on 4-bit base | ~5 GB weights + adapter state → 1× 12–16 GB |

## 8. Distillation

Train a small **student** model to imitate a big **teacher**. Instead of one-hot labels, the student
learns from the teacher's full probability distribution (soft labels), which carries more information
("this is a cat, but it looks a bit like a fox"):

$$
\mathcal{L} = (1-\lambda)\,\text{CE}(y, p_s) + \lambda\, T^2\, \text{KL}\big(p_t^{(T)} \,\|\, p_s^{(T)}\big)
$$

**Read it as:** match the true label *and* match the teacher's softened beliefs ($T$ = temperature).
In LLM practice, the most common form is simpler: generate high-quality answers with the big model and
SFT the small model on them (check the big model's license terms first).

## 9. Evaluating LLM systems

LLM outputs are open-ended, so evaluation combines several methods (details in `07_evaluation/`):

```mermaid
flowchart LR
  G[Golden dataset<br/>100–1,000 real cases<br/>+ edge cases] --> RUN[Run system]
  RUN --> D[Deterministic checks<br/>JSON valid, exact match,<br/>regex, unit tests for code]
  RUN --> J[LLM-as-judge<br/>rubric: faithfulness,<br/>relevance, tone]
  RUN --> H[Human review<br/>sample + disagreements]
  D --> SC[Scorecard per version]
  J --> SC
  H --> SC
  SC --> GATE{Beats current<br/>production?}
  GATE -->|yes| SHIP[Promote]
  GATE -->|no| BACK[Iterate]
```

| Metric family | Examples |
|---|---|
| Task correctness | exact match, F1, pass@k (code), accuracy on labeled cases |
| RAG quality | context precision/recall (retriever), faithfulness / groundedness (answer uses only the context), answer relevance |
| Safety | refusal rate on harmful prompts, over-refusal on benign prompts, jailbreak success rate |
| Operational | latency p50/p95, tokens per request, cost per request |

LLM-as-judge pitfalls: position bias (prefers the first answer), verbosity bias (prefers longer),
self-preference. Mitigate with clear rubrics, swapping order, and calibrating the judge against human
labels.

## 10. Key takeaways

- Prompt → RAG → fine-tune, each justified by a failed eval. RAG for knowledge, fine-tuning for behavior.
- LoRA learns a low-rank correction $BA$ (≈0.5% of params); QLoRA puts the frozen base in 4-bit.
- Quantization = scale + round; group-wise scales handle outliers; always re-evaluate.
- Size GPUs with weights + KV cache + overhead; KV cache often dominates at high concurrency.
- A versioned golden eval set is the most valuable asset in an LLM project.

## Interview questions

1. *A team wants to fine-tune on their wiki so the bot "knows" company policies. Advice?* — use RAG for
   facts (updatable, citable, less hallucination); fine-tune only if format/behavior is the problem.
2. *Why does LoRA work with such a small rank?* — the weight update needed for adaptation has low
   "intrinsic dimension"; most of the change lies in a few directions.
3. *Will a 70B model fit on one 80 GB GPU?* — not in bf16 (140 GB); yes in int4 (~38 GB) with room for
   a modest KV cache.
4. *How do you detect regression after quantization?* — run the same golden eval set and compare per
   category (math, code, languages), not just an average.
