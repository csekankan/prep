# 08 — How LLMs Are Built: Pretraining, Alignment, Inference

> **Why it matters:** "the model hallucinated", "the context is too long", "it's too slow",
> "fine-tune or RAG?", "why does temperature change answers?" — every one of these everyday
> engineering questions has its answer in how LLMs are trained and served.
>
> Deeper math: [probability](../14_math_for_ml_dl_llm/03_probability_statistics.md),
> [information theory](../14_math_for_ml_dl_llm/04_information_theory.md),
> [ML systems math](../14_math_for_ml_dl_llm/09_ml_systems_math.md) (memory, roofline, cost).

## In plain words

Building a chat LLM is like educating a person in three stages:

| Stage | Analogy | What happens | Result |
|---|---|---|---|
| **Pretraining** | reading the entire library for years | predict the next word on trillions of words | a *base model*: knows a lot, but just continues text ("autocomplete on steroids") |
| **Supervised fine-tuning (SFT)** | an apprenticeship with worked examples | train on (instruction → ideal answer) pairs | an *instruct model*: follows instructions and chat format |
| **Preference tuning (RLHF / DPO)** | a mentor saying "this answer is better than that one" | learn from comparisons of good vs bad answers | an *aligned assistant*: helpful, honest, refuses harmful requests |

Ask a base model "What is the capital of France?" and it may reply "What is the capital of Germany?
What is the capital of Spain?" — because lists of quiz questions are common on the internet. SFT
teaches it that a question should be followed by an answer.

## 1. Architecture at a glance: the LLM lifecycle

```mermaid
flowchart LR
  subgraph DATA["Data (months of engineering)"]
    W[Web crawl, books,<br/>code, papers] --> F[Filter, dedupe,<br/>quality score, PII removal]
    F --> TOK[Tokenize →<br/>trillions of tokens]
  end
  subgraph PRE["Pretraining (weeks–months, 1k–100k GPUs)"]
    TOK --> P[Next-token prediction<br/>cross-entropy]
    P --> BASE[(Base model)]
  end
  subgraph POST["Post-training (days–weeks)"]
    BASE --> SFT[SFT on<br/>instruction data]
    SFT --> PREF[Preference tuning<br/>RLHF / DPO / RL on verifiable tasks]
    PREF --> CHAT[(Chat model)]
  end
  subgraph SHIP["Ship"]
    CHAT --> EV[Evals + red teaming]
    EV --> Q[Quantize, optimize]
    Q --> SERVE[Serve: vLLM / TensorRT-LLM<br/>KV cache, batching]
  end
```

**How to read it:** most of the compute goes into pretraining, but most of the *behavior* you notice
(tone, format, refusals, tool use) comes from post-training. Data quality work is the least
glamorous and among the most important parts.

## 2. Pretraining: next-token prediction

### The objective

Given tokens $x_1, \dots, x_{t-1}$, the model outputs a probability for every vocabulary token as the
next one. Training minimizes the average negative log-probability of the token that actually came next:

$$
\mathcal{L} = -\frac{1}{T}\sum_{t=1}^{T}\log P_\theta(x_t \mid x_1, \dots, x_{t-1})
$$

**Read it as:** "for every position in the text, how surprised was the model by the real next token?
Average that surprise; make it smaller." It's the multi-class cross-entropy from module 02, with
~100k classes.

**Why such a simple objective learns so much:** to predict the next token of
*"The derivative of x² is"* you need calculus; of a Python file, you need to understand code; of a
detective novel's last chapter, you need to track the plot. Minimizing prediction error on diverse
text forces the model to build internal representations of grammar, facts, and reasoning.

### Perplexity

$$
\text{PPL} = e^{\mathcal{L}}
$$

**Read it as:** "the model is as uncertain as if it were choosing uniformly among PPL options."
Loss 2.0 → PPL 7.4: on average, as unsure as picking from ~7 equally likely tokens. Random guessing
over a 50k vocabulary would be PPL 50,000 (loss 10.8 — the initial loss you should see).

### Data: the real secret sauce

| Step | Why |
|---|---|
| Crawl (Common Crawl, code, books, papers, curated sources) | breadth |
| Language ID, quality classifiers, heuristic filters | the web is mostly junk |
| **Deduplication** (exact + near-duplicate, MinHash) | duplicates waste compute and cause memorization |
| PII and toxicity filtering, license filtering | legal, safety |
| Benchmark decontamination | otherwise eval scores are fake |
| Mixing ratios (web/code/math/multilingual) and annealing on high-quality data at the end | strongly affects capabilities |

## 3. Scaling laws and compute budgets

### Loss falls predictably with scale

Empirically, loss follows a power law in parameters $N$ and training tokens $D$:

$$
L(N, D) \approx E + \frac{A}{N^{\alpha}} + \frac{B}{D^{\beta}}
$$

**Read it as:** there's an irreducible floor $E$ (the inherent randomness of language), and two terms
that shrink as you add parameters or data. Each 10× more compute buys a predictable drop in loss — so
labs can forecast a 100M-dollar run's result from small experiments.

**Chinchilla rule (2022):** for a fixed compute budget, the optimal model is trained on roughly
**20 tokens per parameter**. A 70B model "wants" ~1.4T tokens. Modern models are deliberately trained
far beyond that (LLaMA-3 8B saw 15T tokens, ~1,900 tokens/param) because a smaller model trained
longer is **cheaper to serve** — and serving cost dominates over the model's lifetime.

### Training compute: the 6ND rule

$$
C \approx 6 \cdot N \cdot D \;\text{FLOPs}
$$

**Read it as:** each token costs ~2N FLOPs forward (one multiply + one add per parameter) and ~4N
backward (module 04: backward ≈ 2× forward). So 6 FLOPs per parameter per token.

**Worked example — LLaMA-2 7B on 2T tokens:**
$C = 6 \times 7\times10^9 \times 2\times10^{12} = 8.4\times10^{22}$ FLOPs.
An A100 does 312 TFLOP/s in bf16; real jobs reach ~40% utilization (MFU) → $1.25\times10^{14}$ FLOP/s.
Time $= 8.4\times10^{22} / 1.25\times10^{14} \approx 6.7\times10^{8}$ GPU-seconds ≈ **187,000 A100-hours**.
Meta reported 184,320 A100-hours. ✔ The back-of-envelope works.

### Training memory: 16 bytes per parameter

| Item | Bytes/param (mixed precision + AdamW) |
|---|---|
| bf16 weights | 2 |
| bf16 gradients | 2 |
| fp32 master weights | 4 |
| Adam first moment $m$ | 4 |
| Adam second moment $v$ | 4 |
| **Total** | **16** (+ activations) |

A 7B model needs ~112 GB before activations — more than one 80 GB GPU. Hence distributed training:

| Technique | Splits | Plain words |
|---|---|---|
| Data parallel (DDP) | the batch | every GPU has a full copy, processes different data, averages gradients |
| **FSDP / ZeRO** | weights, grads, optimizer state | each GPU stores only a slice; gathers what it needs just in time |
| Tensor parallel | each matrix | split one big matmul across GPUs in a node (needs fast NVLink) |
| Pipeline parallel | layers | GPU 1 has layers 1–10, GPU 2 has 11–20, … like an assembly line |
| Activation checkpointing | — | don't store activations; recompute them in backward (≈ +33% compute, much less memory) |

See `13_sovereign_ai_infra_course/03_distributed_training/` for the infrastructure side.

## 4. Post-training: from autocomplete to assistant

### Supervised fine-tuning (SFT)

Same next-token loss, but on curated conversations formatted with a **chat template**:

```
<|system|>You are a helpful assistant.<|end|>
<|user|>Explain DNS in one sentence.<|end|>
<|assistant|>DNS translates human-readable domain names into IP addresses.<|end|>
```

Loss is computed **only on the assistant tokens** (the model shouldn't learn to imitate users).
Tens of thousands to a few million high-quality examples. Quality beats quantity: 1,000 excellent
examples can beat 50,000 mediocre ones.

### RLHF (Reinforcement Learning from Human Feedback)

```mermaid
flowchart LR
  P[Prompt] --> M[SFT model generates<br/>2+ answers]
  M --> H[Human picks the better one<br/>A ≻ B]
  H --> RM[Train reward model<br/>score answers]
  RM --> PPO[Optimize the LLM with RL PPO<br/>to get high reward,<br/>stay close to SFT model]
  PPO --> M
```

**Step 1 — Reward model.** Given a preferred answer $y_w$ and a rejected one $y_l$, train a model $r$
so that the preferred one scores higher (Bradley–Terry model):

$$
\mathcal{L}_{RM} = -\log \sigma\big(r(x, y_w) - r(x, y_l)\big)
$$

**Read it as:** logistic regression on "is A better than B?", where the input is the score difference.

**Step 2 — RL.** Maximize reward while staying close to the original (reference) model:

$$
\max_\theta\; \mathbb{E}\big[r(x, y)\big] - \beta\,\text{KL}\big(\pi_\theta \,\|\, \pi_{\text{ref}}\big)
$$

**Read it as:** "get high scores from the reward model, but don't drift far from how the SFT model
talks." Without the KL leash, the model finds loopholes in the reward model (**reward hacking**) —
e.g. very long, flattering, confident answers that the reward model happens to like.

### DPO (Direct Preference Optimization) — RLHF without RL

DPO skips the reward model and PPO, optimizing the preferences directly:

$$
\mathcal{L}_{DPO} = -\log\sigma\!\left(\beta\left[\log\frac{\pi_\theta(y_w\mid x)}{\pi_{\text{ref}}(y_w\mid x)} - \log\frac{\pi_\theta(y_l\mid x)}{\pi_{\text{ref}}(y_l\mid x)}\right]\right)
$$

**Read it as:** "raise the probability of the preferred answer and lower the rejected one, *relative to
the reference model*." Simpler, stable, needs only a dataset of (prompt, chosen, rejected) — popular for
open models and enterprise fine-tuning.

### RL on verifiable rewards (reasoning models)

For math and code, the reward can be checked automatically (did the unit tests pass? is the final
answer correct?). Training with RL on such tasks — letting the model generate long chains of thought
and rewarding correct outcomes — produces "reasoning" models that think before answering. More
inference-time thinking tokens → better answers on hard problems (**test-time compute scaling**).

## 5. Inference: how text is generated

### The generation loop

```mermaid
sequenceDiagram
  participant U as User prompt (500 tokens)
  participant M as Model
  participant C as KV cache
  U->>M: PREFILL: process all 500 tokens in parallel
  M->>C: store K,V for 500 tokens
  M-->>U: first token  (time-to-first-token, TTFT)
  loop DECODE: one token at a time
    M->>C: read all past K,V, append new K,V
    M-->>U: next token  (inter-token latency)
  end
```

| Phase | Work | Bottleneck | Metric |
|---|---|---|---|
| **Prefill** | all prompt tokens at once — big matmuls | GPU compute (FLOPs) | time to first token (TTFT) |
| **Decode** | one token per step, but must read *all* weights each step | **memory bandwidth** | inter-token latency / tokens per second |

**Plain words:** prefill is like reading the whole question at once (fast, parallel). Decode is like
writing the answer word by word, where for every single word you must flip through the entire
encyclopedia (all weights) again.

### Why decoding is memory-bound

At batch size 1, generating one token reads every weight once. A 7B model in bf16 = 14 GB. An H100
reads ~3.35 TB/s:

$$
\text{max tokens/s} \approx \frac{\text{memory bandwidth}}{\text{model bytes}} = \frac{3350\text{ GB/s}}{14\text{ GB}} \approx 240 \text{ tokens/s}
$$

That's why **quantization** (fewer bytes per weight) and **batching** (many users share one read of
the weights) are the two biggest serving levers (module 11).

### The KV cache

Without caching, generating token 1,000 would recompute keys and values for the previous 999 tokens.
The KV cache stores them. Its size:

$$
\text{KV bytes per token} = 2 \times L \times n_{kv\_heads} \times d_{head} \times \text{bytes per value}
$$

(2 = one K and one V.)

| Model | $L$ | KV heads | $d_{head}$ | Per token (bf16) | 4k context | 128k context |
|---|---|---|---|---|---|---|
| LLaMA-2 7B (MHA) | 32 | 32 | 128 | 512 KB | 2 GB | 64 GB |
| LLaMA-3 8B (GQA) | 32 | 8 | 128 | 128 KB | 0.5 GB | 16 GB |

**Read it as:** per user, per conversation. 50 concurrent users at 4k context on LLaMA-2 7B need 100 GB
of KV cache — more than the model weights. That's why GQA exists and why serving engines like vLLM
manage KV memory in pages (PagedAttention), like an OS manages RAM.

### Decoding strategies: turning probabilities into text

The model outputs logits $z$ for every token. **Temperature** $T$ rescales them before softmax:

$$
p_i = \frac{e^{z_i / T}}{\sum_j e^{z_j / T}}
$$

Worked example, logits $(2, 1, 0)$ for tokens ("Paris", "Lyon", "pizza"):

| Temperature | Probabilities | Behavior |
|---|---|---|
| $T \to 0$ (greedy) | (1.00, 0.00, 0.00) | always the top token; deterministic, can get repetitive |
| $T = 0.5$ | (0.87, 0.12, 0.02) | focused |
| $T = 1.0$ | (0.67, 0.24, 0.09) | the model's true distribution |
| $T = 2.0$ | (0.51, 0.31, 0.19) | creative / chaotic |

| Strategy | Rule | Use |
|---|---|---|
| Greedy | pick the argmax | extraction, classification, deterministic tests |
| Top-k | sample only among the $k$ most likely tokens | cut off the long tail of nonsense |
| **Top-p (nucleus)** | sample among the smallest set of tokens whose probabilities sum to $p$ (e.g. 0.9) | adapts to the model's confidence; common default |
| Beam search | keep the best $b$ partial sequences | translation; rarely for chat |
| Constrained / structured | mask tokens that would break a JSON schema or grammar | reliable JSON / tool calls |
| Speculative decoding | small "draft" model proposes several tokens, big model verifies them in one pass | 2–3× faster with identical output distribution |

## 6. Mixture of Experts (MoE)

```
                     ┌──► Expert 1 (MLP) ──┐
 token ─► Router ────┼──► Expert 2 (MLP) ──┼──► weighted sum ─► next layer
 (picks top-2 of 8)  ├──► Expert 3 (MLP)   │     (only 2 experts actually run)
                     └──► ... Expert 8     ┘
```

Replace each MLP with $E$ expert MLPs and a small router that sends each token to the top-$k$ (often 2).
**Plain words:** a hospital with many specialists; a triage nurse sends each patient to the two most
relevant doctors instead of all of them.

Mixtral 8×7B: ~47B total parameters, but only ~13B are active per token → quality of a big model at
the compute cost of a medium one. The catch: **all** experts must sit in GPU memory, and routing must
be balanced (an auxiliary load-balancing loss).

## 7. Why LLMs hallucinate (and what actually helps)

The model is trained to produce **plausible continuations**, not true ones. When it lacks the fact,
the most plausible-sounding continuation is a confident fabrication — there's no built-in
"I don't know" unless training rewarded it.

| Cause | Mitigation |
|---|---|
| Fact not in training data / outdated | **RAG**: put the facts in the prompt (`04_rag/`) |
| Rare fact, weakly memorized | RAG; ask for citations; verify |
| Pressure to answer | instruct + train to abstain; reward "I don't know" |
| Sampling randomness | lower temperature for factual tasks |
| Long reasoning chains | tools (calculator, code execution), self-consistency, verification steps |

## 8. Key takeaways

- Pretraining = next-token cross-entropy on trillions of tokens; post-training (SFT + preference
  tuning) creates the assistant behavior.
- Compute ≈ 6·params·tokens; training memory ≈ 16 bytes/param; scaling laws make results predictable.
- Inference = compute-bound prefill + memory-bound decode; the KV cache grows with context × users.
- Temperature/top-p control randomness; constrained decoding makes structured output reliable.
- Hallucination is a consequence of the training objective; grounding (RAG) and verification help most.

## Interview questions

1. *Estimate GPU-hours to train a 13B model on 1T tokens on H100s.* —
   $6 \times 13\times10^9 \times 10^{12} = 7.8\times10^{22}$ FLOPs; H100 ≈ 989 TFLOP/s × 40% MFU ≈
   $4\times10^{14}$ → ~$2\times10^{8}$ s ≈ 54k GPU-hours.
2. *Why is decoding slower per token than prefill?* — decode processes one token per step but must read
   all weights and the KV cache each step; it's memory-bandwidth bound with low arithmetic intensity.
3. *Why the KL penalty in RLHF?* — prevents reward hacking and preserves the language quality and
   knowledge of the reference model.
4. *DPO vs RLHF?* — DPO optimizes preferences directly with a classification-style loss: no reward model,
   no RL sampling loop; simpler and more stable, though RL can still win with good reward signals.
5. *How much KV cache for 32 users × 8k tokens on LLaMA-3 8B?* — 128 KB × 8,192 × 32 ≈ 32 GB.
