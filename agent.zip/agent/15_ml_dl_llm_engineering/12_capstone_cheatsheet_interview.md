# 12 — Capstone, Cheat Sheet & Interview Prep

> **Why it matters:** understanding comes from building one thing end to end. This module gives you a
> capstone that touches every module, a one-page formula sheet, and a bank of interview questions
> including a full ML system-design walkthrough.

## In plain words

Modules 01–11 taught the parts of a car: engine (models), fuel (data), dashboard (metrics), factory
(MLOps), and roads (deployment). The capstone is **driving the car across town** — you'll hit every
part and discover how they connect.

## Part 1 — Capstone: Support Ticket Triage & Answer Assistant

### The scenario

A SaaS company receives 5,000 support tickets/day. Goals:
1. **Route** each ticket to the right team (billing, bug, account, how-to) and flag urgency.
2. **Draft an answer** for how-to tickets from the help-center docs, for a human agent to approve.

### Architecture

```mermaid
flowchart LR
  subgraph INGEST["Ingest"]
    T[New ticket] --> V[Validate + PII redaction]
  end
  subgraph ROUTE["Routing (classic ML → DL)"]
    V --> CL[Classifier<br/>v1: TF-IDF + LogReg<br/>v2: fine-tuned small transformer]
    CL --> UR[Urgency score<br/>calibrated probability]
  end
  subgraph DRAFT["Answer drafting (LLM)"]
    CL -->|how-to| RET[Retrieve help docs<br/>embeddings + vector DB]
    RET --> LLM[LLM drafts answer<br/>with citations]
    LLM --> GR[Guardrails: groundedness,<br/>no PII, tone]
  end
  subgraph HUMAN["Human in the loop"]
    UR --> Q[Agent queue, sorted by urgency]
    GR --> Q
    Q --> AG[Agent approves / edits / reroutes]
  end
  subgraph LOOP["MLOps loop"]
    AG -->|corrections = new labels| DL[(Versioned dataset)]
    DL --> TRN[Retrain + eval gate]
    TRN --> REG[(Model registry)]
    REG --> CL
    AG --> MON[Monitoring: routing accuracy,<br/>draft acceptance rate, drift, cost]
  end
```

**How to read it:** the classifier and the LLM each solve a different sub-problem. Every human
correction becomes a new labeled example — the system gets better the more it's used.

### Milestones (each maps to a module)

| # | Milestone | Modules | Done when |
|---|---|---|---|
| 1 | Frame: metric = macro-F1 for routing; recall@top-urgency for urgency; draft acceptance rate | 01 | one-page spec with baseline (keyword rules) |
| 2 | Data: 20k historical tickets with final team; time-based split; dedupe; PII redaction | 03 | train/val/test frozen + DVC versioned |
| 3 | Baseline: TF-IDF + logistic regression pipeline | 02, 03 | macro-F1 measured; confusion matrix + error analysis of 100 mistakes |
| 4 | Gradient boosting with metadata features (plan, product area, customer age) | 02, 03 | compare with baseline per class |
| 5 | Fine-tune a small transformer (e.g. a 100M-parameter encoder) or LoRA on a small LLM | 04–07, 09 | beats baseline by a meaningful margin on the test set; latency measured |
| 6 | RAG drafting: chunk help center, embed, retrieve, generate with citations | 07–09 | golden set of 100 how-to tickets; faithfulness + relevance scored |
| 7 | Evals + guardrails: LLM-judge rubric calibrated on 50 human labels | 09 | eval report per release |
| 8 | MLOps: MLflow tracking, registry, CI eval gate, drift report on ticket topics | 10 | one-command retrain → gate → register |
| 9 | Serve: FastAPI classifier + vLLM (or API) for drafting; Docker; metrics | 11 | p95 latency, cost per ticket, dashboards |
| 10 | Roll out: shadow for a week, then canary to one support team | 11 | acceptance rate and routing accuracy compared with control |

### Step 3 starter code (baseline)

```python
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import classification_report, ConfusionMatrixDisplay

df = pd.read_parquet("tickets.parquet").sort_values("created_at")
cut1, cut2 = int(len(df) * 0.8), int(len(df) * 0.9)           # time-based split
train, val, test = df[:cut1], df[cut1:cut2], df[cut2:]

clf = make_pipeline(TfidfVectorizer(ngram_range=(1, 2), min_df=3, sublinear_tf=True),
                    LogisticRegression(max_iter=2000, class_weight="balanced", C=4.0))
clf.fit(train.text, train.team)
print(classification_report(val.team, clf.predict(val.text), digits=3))
```

### Stretch goals

- Active learning: send the tickets the model is least sure about (probability near the decision
  boundary) to humans for labeling first.
- Cost router: answer simple how-tos with a small model, escalate complex ones to a larger model.
- Topic drift: cluster weekly ticket embeddings with k-means; alert when a new cluster appears
  (e.g., an outage).

## Part 2 — One-Page Formula Cheat Sheet

### Core ML

| Concept | Formula | Plain words |
|---|---|---|
| Learning | $\theta^* = \arg\min_\theta \frac{1}{n}\sum_i \ell(f(x_i;\theta), y_i)$ | find settings with the smallest average error |
| Linear model | $\hat{y} = \mathbf{w}^\top\mathbf{x} + b$ | weighted sum of features |
| MSE | $\frac{1}{n}\sum(\hat{y}-y)^2$ | average squared error |
| Gradient descent | $\theta \leftarrow \theta - \eta\nabla_\theta L$ | step downhill |
| Sigmoid | $\sigma(z) = \frac{1}{1+e^{-z}}$ | squash to (0, 1) |
| Softmax | $\frac{e^{z_k}}{\sum_j e^{z_j}}$ | scores → probabilities |
| Cross-entropy | $-\sum_k y_k \log \hat{p}_k$ | surprise at the true answer |
| L2 / L1 penalty | $\lambda\sum w^2$ / $\lambda\sum\lvert w\rvert$ | keep weights small / sparse |
| Bias–variance | $\text{Err} = \text{Bias}^2 + \text{Var} + \sigma^2$ | too simple vs too sensitive vs noise |
| Precision / Recall | $\frac{TP}{TP+FP}$ / $\frac{TP}{TP+FN}$ | how many flags are right / how many positives caught |
| F1 | $\frac{2PR}{P+R}$ | balance of both |
| Gini | $1 - \sum p_k^2$ | node impurity for trees |
| Cosine similarity | $\frac{\mathbf{a}\cdot\mathbf{b}}{\lVert\mathbf{a}\rVert\lVert\mathbf{b}\rVert}$ | same direction = similar meaning |

### Deep learning

| Concept | Formula | Plain words |
|---|---|---|
| Layer | $\mathbf{h} = \phi(W\mathbf{x} + \mathbf{b})$ | linear + nonlinearity |
| Backprop | $\boldsymbol\delta_\ell = (W_{\ell+1}^\top\boldsymbol\delta_{\ell+1}) \odot \phi'(\mathbf{z}_\ell)$; $\nabla W_\ell = \boldsymbol\delta_\ell\,\mathbf{h}_{\ell-1}^\top$ | error flows back; gradient = error × input |
| He init | $\text{Var}(w) = 2/n_{in}$ | more inputs → smaller initial weights |
| Adam | $\theta \leftarrow \theta - \eta\,\hat{m}/(\sqrt{\hat{v}}+\epsilon)$ | momentum + per-parameter step size |
| Residual | $\mathbf{h}_{\ell+1} = \mathbf{h}_\ell + F(\mathbf{h}_\ell)$ | add a correction; gradient highway |
| RMSNorm | $\gamma \odot \mathbf{x}/\sqrt{\text{mean}(x^2)+\epsilon}$ | rescale each token vector |
| Conv output size | $\lfloor (W - K + 2P)/S \rfloor + 1$ | spatial size after a conv |
| Grad clipping | $\mathbf{g} \cdot \min(1, c/\lVert\mathbf{g}\rVert)$ | cap the step size |

### Transformers & LLMs

| Concept | Formula | Plain words |
|---|---|---|
| Attention | $\text{softmax}(QK^\top/\sqrt{d_k} + M)V$ | soft lookup: match, normalize, average |
| Params per block | $\approx 12d^2$ | attention $4d^2$ + MLP $8d^2$ |
| Next-token loss | $-\frac{1}{T}\sum_t \log P(x_t \mid x_{<t})$ | surprise at each real next token |
| Perplexity | $e^{\mathcal{L}}$ | effective number of choices |
| Training FLOPs | $\approx 6ND$ | 6 × params × tokens |
| Chinchilla | $D \approx 20N$ | compute-optimal tokens per parameter |
| Training memory | $\approx 16$ bytes/param | weights, grads, master copy, Adam m and v |
| Decode speed bound | bandwidth / model bytes | each token reads all weights |
| KV cache / token | $2 \cdot L \cdot n_{kv} \cdot d_{head} \cdot \text{bytes}$ | grows with context × users |
| Temperature | $\text{softmax}(z/T)$ | low = focused, high = random |
| LoRA | $W + \frac{\alpha}{r}BA$ | small low-rank correction |
| Quantization | $q = \text{round}(w/s)$, $\hat{w} = qs$ | fewer bits with a scale |
| DPO | $-\log\sigma(\beta[\Delta_{\text{chosen}} - \Delta_{\text{rejected}}])$ | prefer chosen over rejected vs reference |

### Production

| Concept | Formula | Plain words |
|---|---|---|
| Little's Law | $L = \lambda W$ | concurrency = rate × time in system |
| PSI | $\sum (a_i - e_i)\ln(a_i/e_i)$ | drift; > 0.2 is significant |
| A/B sample size | $n \approx 16p(1-p)/\delta^2$ per arm | small lifts need lots of traffic |
| Cost per 1M tokens | GPU \$/h ÷ (tokens/h ÷ $10^6$) | only cheap if the GPU stays busy |

## Part 3 — Interview Question Bank

### Fundamentals

1. Explain the bias–variance trade-off with an example. How do you diagnose each from learning curves?
2. Why do we need a validation set *and* a test set?
3. Derive the gradient of logistic regression's loss. Why is it $(\hat{p} - y)x$?
4. When is accuracy a bad metric? What would you use for fraud detection?
5. What's data leakage? Give three real examples.
6. Random forest vs gradient boosting: how they differ and when you'd use each.
7. How does k-fold cross-validation work, and when must you *not* shuffle?

### Deep learning

8. Walk through backprop for a two-layer network.
9. Why do deep networks need nonlinear activations? Why ReLU over sigmoid?
10. Vanishing/exploding gradients: causes and at least four fixes.
11. BatchNorm vs LayerNorm. Why do transformers use LayerNorm/RMSNorm?
12. Explain Adam. Why AdamW? Why warmup?
13. Your loss is NaN after 2,000 steps. What do you check?
14. How does dropout work at training vs inference time?

### Transformers & LLMs

15. Explain self-attention with Q, K, V. Why scale by $\sqrt{d_k}$?
16. Why did transformers replace RNNs?
17. What's the causal mask and why does it allow parallel training?
18. Estimate the parameter count of a model with $d = 4096$, 32 layers, 32k vocab.
19. How does RoPE encode position? Why does it help with longer contexts?
20. Prefill vs decode: what bounds each? What is the KV cache, and how big is it?
21. RLHF vs DPO. What is reward hacking?
22. Why do LLMs hallucinate? What reduces it in a product?
23. Temperature, top-k, top-p: what does each do?
24. RAG vs fine-tuning for a company knowledge assistant.
25. Explain LoRA and why low rank works. What is QLoRA?
26. Will a 70B model fit on a single 80 GB GPU? Under what conditions?

### MLOps & deployment

27. Data drift vs concept drift. How do you detect each with delayed labels?
28. What is training–serving skew and how do you prevent it?
29. Design an eval gate for a model release.
30. Shadow vs canary vs A/B tests.
31. How would you autoscale an LLM serving cluster?
32. Self-host an open model vs use an API: walk through the cost and risk analysis.

## Part 4 — System Design Walkthrough: "Design an internal AI assistant for 20,000 employees"

### 1. Clarifying questions

- What tasks? (Q&A over internal docs, summarizing, drafting) → mostly RAG.
- Data sensitivity and residency? (HR, legal docs; EU staff) → permission-aware retrieval, possibly
  self-hosted model.
- Latency target? (first token < 1 s), availability (99.9%), languages?
- Success metric? (answer acceptance, deflected IT/HR tickets, time saved)

### 2. Back-of-envelope sizing

- 20,000 employees × 30% daily active × 10 questions = **60,000 requests/day**.
- Peak ≈ 5× the average: $60{,}000 / 86{,}400 \times 5 \approx$ **3.5 req/s** at peak.
- Each request: ~3,000 input tokens (retrieved chunks) + 400 output tokens.
- Daily tokens: $60{,}000 \times 3{,}400 \approx 204$M tokens/day.
- Concurrency (Little's Law): 3.5 req/s × ~10 s per response ≈ **35 concurrent streams**.
- Self-hosted 70B in FP8 on 2× H100 with tensor parallelism might handle ~30–60 concurrent streams at
  acceptable latency → 2 replicas + 1 for failover ≈ **6 H100s**. Compare with API cost:
  204M tokens/day × list price per token. Prefix caching of system prompts cuts prefill cost.

### 3. Architecture

```mermaid
flowchart LR
  U[Employee<br/>SSO] --> GW[Gateway: auth, rate limit,<br/>PII + injection filters]
  GW --> ORCH[Orchestrator]
  ORCH --> RET[Hybrid retrieval<br/>BM25 + vectors<br/>filtered by user's ACL groups]
  RET --> VDB[(Vector index<br/>+ ACL metadata)]
  ORCH --> RR[Reranker]
  ORCH --> LLM[LLM serving<br/>vLLM or provider API]
  LLM --> OG[Output guardrails:<br/>groundedness, citations, DLP]
  OG --> U
  ORCH --> TR[(Traces, feedback,<br/>cost metrics)]
  SRC[(SharePoint, Confluence,<br/>Drive, Jira)] --> ING[Ingestion: parse, chunk,<br/>embed, capture ACLs,<br/>incremental sync]
  ING --> VDB
```

### 4. Key trade-offs

| Decision | Option A | Option B | Choice |
|---|---|---|---|
| Model | frontier API | self-hosted open 70B | API to start for quality and speed; self-host if residency or volume requires |
| Retrieval | vectors only | hybrid BM25 + vectors + reranker | hybrid: internal docs have many exact terms (product codes, acronyms) |
| Permissions | filter after retrieval | filter **during** retrieval by ACL | during — never let unauthorized chunks reach the prompt |
| Freshness | nightly full re-index | incremental sync via change events | incremental for edited docs, nightly reconciliation |
| Fine-tuning | yes | no | no at first; revisit for tone/format once there's feedback data |

### 5. Evaluation and operations

- Golden set of 300 real questions with reference answers and source docs, per department.
- Metrics: retrieval recall@5, faithfulness, answer relevance, refusal correctness, latency, cost/request.
- Release gate in CI; canary to one department; thumbs up/down + "report wrong answer" feed new eval cases.

### 6. Failure modes ("debug this")

| Symptom | Likely cause | Fix |
|---|---|---|
| Confident wrong answers citing old policies | stale index; outdated docs ranking well | freshness boost, doc expiry, incremental sync |
| Users see snippets from docs they can't access | ACLs not enforced in retrieval | ACL-filtered queries, regular permission audits |
| Slow first token at 9 am | prefill load spikes, cold replicas | prefix caching, scheduled pre-scaling, chunked prefill |
| Costs triple in a month | prompts grew (more chunks), no caching | cap context, rerank to top-5, cache, route easy queries to a smaller model |

### 7. Senior vs staff-level answers

- **Senior:** a solid RAG pipeline, evals, and serving plan with numbers.
- **Staff:** also covers the org and risk side — data ownership and permissions model, governance and
  audit (`12_ai_security_governance/`), build-vs-buy, a multi-quarter roadmap (Q&A → actions/agents),
  cost controls, and how success is measured and reported.

## Part 5 — Course takeaways

- **One recipe everywhere:** model + loss + gradient descent, from linear regression (02) to GPT (08).
- **Generalization is the goal:** honest splits, no leakage, and the right metric matter more than the
  algorithm (03).
- **Depth needs engineering:** initialization, normalization, residuals, AdamW, and warmup are what make
  deep networks and transformers trainable (05).
- **Attention is a soft lookup:** query·key scores → softmax → weighted sum of values; a transformer
  is that plus an MLP, stacked with residuals (07).
- **LLMs = next-token prediction at scale + post-training;** inference is limited by memory bandwidth
  and the KV cache (08).
- **Prompt → RAG → fine-tune,** each step justified by an eval (09).
- **Models decay without code changes:** version data and models, gate every release on evals,
  monitor drift (10).
- **Serving is capacity math:** Little's Law, batching, quantization, and safe rollouts (11).

## Part 6 — Suggested learning path after this course

| Week | Do |
|---|---|
| 1–2 | Re-implement modules 02 and 04 from memory (linear/logistic regression, MLP with backprop) |
| 3 | Kaggle tabular competition with a proper validation strategy (module 03) |
| 4–5 | Build the MiniGPT from module 07 and train it on a small text corpus |
| 6 | LoRA fine-tune a small open model on a task you care about; evaluate before and after (module 09) |
| 7–8 | Ship the capstone end to end with MLflow, CI eval gate, Docker, and monitoring (modules 10–11) |

Recommended references: *Deep Learning* (Goodfellow et al.), Andrej Karpathy's "Neural Networks: Zero
to Hero" videos, *Designing Machine Learning Systems* (Chip Huyen), the "Attention Is All You Need"
paper, and the Chinchilla, LoRA, and DPO papers.
