# ML → Deep Learning → LLMs → MLOps → Deployment — An Engineer's Course

> For software engineers who want to understand AI **deeply**, not just call an API.
> Every module goes: **why it exists → intuition → the math (explained slowly) → technique →
> practical code → how it breaks → interview-level notes.**

You already know how to build software. This course reuses that knowledge everywhere it can:

| You know (SDE) | ML equivalent |
|---|---|
| A function `f(x) -> y` you write by hand | A model `f(x; θ) -> ŷ` whose logic is **learned** from data |
| Unit tests | Validation / test sets and evaluation metrics |
| Bugs | Data leakage, overfitting, distribution shift |
| Config / constants | Hyperparameters (learning rate, batch size, depth) |
| Compiling | Training (expensive, done once, produces an artifact) |
| The binary / artifact | Model weights file (`.safetensors`, `.onnx`, `.pt`) |
| Running the binary | Inference |
| CI/CD | CI/CD **+ CT** (continuous training) and eval gates |
| Logs and metrics | Logs, metrics **+ data/prediction drift monitoring** |

## Roadmap

```
 PART A — MACHINE LEARNING
   01 Why ML? ─► 02 Classic ML algorithms ─► 03 ML in practice (data, metrics, validation)
                                                      │
 PART B — DEEP LEARNING                               ▼
   04 Neural networks from scratch ─► 05 Training deep nets ─► 06 CNNs, RNNs and why attention
                                                      │
 PART C — LLMs                                        ▼
   07 Attention & Transformers ─► 08 How LLMs are built ─► 09 Using & adapting LLMs in practice
                                                      │
 PART D — PRODUCTION                                  ▼
   10 MLOps (data, experiments, registry, CI/CD/CT, monitoring) ─► 11 Deployment & serving
                                                      │
                                                      ▼
   12 Capstone project, cheat sheet, interview questions
```

| # | Module | You will be able to |
|---|---|---|
| 01 | [Why ML? The need for learning from data](01_why_ml.md) | explain when rules fail, the types of learning, and the ML workflow; decide when *not* to use ML |
| 02 | [Classic ML algorithms](02_classic_ml_algorithms.md) | derive linear/logistic regression, gradient descent, regularization, bias–variance; know trees, ensembles, kNN, SVM, k-means, PCA |
| 03 | [ML in practice](03_ml_in_practice.md) | split data correctly, avoid leakage, choose metrics, cross-validate, tune, handle imbalance, build a scikit-learn pipeline |
| 04 | [Neural networks from scratch](04_neural_networks_from_scratch.md) | explain why depth helps, do forward and backward passes by hand with real numbers, write an MLP in NumPy |
| 05 | [Training deep networks](05_training_deep_networks.md) | pick optimizers and LR schedules, use init/normalization/dropout/residuals, debug a training run, write a PyTorch loop |
| 06 | [CNNs, RNNs and the road to attention](06_cnn_rnn_road_to_attention.md) | compute convolution shapes and params, understand RNN/LSTM, and see exactly why attention replaced recurrence |
| 07 | [Attention & Transformers](07_attention_transformers.md) | tokenize, embed, compute attention by hand, explain multi-head, positions/RoPE, causal masks, count parameters, code a block |
| 08 | [How LLMs are built](08_how_llms_are_built.md) | explain pretraining, scaling laws, compute and memory budgets, SFT, RLHF/DPO, decoding, KV cache, MoE |
| 09 | [Using & adapting LLMs in practice](09_llms_in_practice.md) | choose prompt vs RAG vs fine-tune, do LoRA/QLoRA, quantize, evaluate, and size GPU memory |
| 10 | [MLOps](10_mlops.md) | version data and models, track experiments, use a registry, build CI/CD/CT, detect drift, run LLMOps |
| 11 | [Deployment & serving](11_deployment_serving.md) | pick batch/online/streaming, serve with FastAPI/ONNX/Triton/vLLM, do latency and cost math, roll out safely |
| 12 | [Capstone, cheat sheet & interview prep](12_capstone_cheatsheet_interview.md) | ship one end-to-end project and answer the common ML/DL/LLM system-design questions |

## How every module is structured

| Block | Purpose |
|---|---|
| **Why it matters** | the engineering problem this topic solves |
| **In plain words** | an everyday analogy so the idea clicks before any formula |
| **Architecture at a glance** + **How to read it** | a diagram of the moving parts and a walkthrough of the flow |
| **Theory + math** | each formula followed by "Read it as" in plain English and a worked example with real numbers |
| **Practical code** | the smallest runnable code that makes the idea concrete |
| **Production notes** | what changes at scale, and how it breaks |
| **Key takeaways** + **Interview questions** | what to remember, and how it gets asked |

## How to read the math

Every formula is followed by a **"Read it as"** line in plain English and, usually, a tiny worked
example with real numbers. If you want a full derivation, each module links to the matching
module in [`../14_math_for_ml_dl_llm/`](../14_math_for_ml_dl_llm/README.md).

Notation used throughout:

| Symbol | Meaning | SDE translation |
|---|---|---|
| $x$, $\mathbf{x}$ | one input (scalar, vector) | one row of features |
| $X$ | matrix of inputs, shape $(n, d)$ | a table: $n$ rows, $d$ columns |
| $y$, $\hat{y}$ | true label, predicted label | expected vs actual output |
| $\theta$, $W$, $\mathbf{b}$ | parameters (weights, bias) | the numbers training adjusts |
| $L$ or $\mathcal{L}$ | loss | "how wrong are we", a single number |
| $\nabla_\theta L$ | gradient of loss w.r.t. parameters | which direction makes the loss go up fastest |
| $\eta$ | learning rate | step size |
| $\sigma(\cdot)$ | sigmoid | squashes any number into (0, 1) |
| $\mathbb{E}[\cdot]$ | expected value | the average over many samples |
| $\sum_i$ | sum over $i$ | a `for` loop that accumulates |
| $\prod_i$ | product over $i$ | a `for` loop that multiplies |

## Setup (optional — everything is readable without running)

```bash
python -m venv .venv && source .venv/bin/activate
pip install numpy pandas scikit-learn matplotlib torch transformers peft datasets \
            mlflow fastapi uvicorn onnx onnxruntime evidently
```

## How this connects to the rest of the repo

| Topic here | Where it shows up elsewhere |
|---|---|
| Math foundations | `14_math_for_ml_dl_llm/` |
| Embeddings, similarity, retrieval | `04_rag/`, `05_memory/` |
| LLM calls, prompting, sampling | `01_foundations/` |
| Evaluation, LLM-as-judge | `07_evaluation/` |
| MLOps / LLMOps pipeline | `10_llmops_pipeline/` |
| Kubernetes deployment, canary | `11_kubernetes/` |
| GPUs, distributed training, inference scaling | `13_sovereign_ai_infra_course/` |
| Security of deployed models | `12_ai_security_governance/` |
