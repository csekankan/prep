# 01 — Why ML? The Need for Learning From Data

> **Why it matters:** before learning *how* models work, you need a sharp sense of *when* a
> learned function beats a hand-written one — and when it is an expensive mistake.

## In plain words

Think about how a child learns what a "dog" is. Nobody gives them a rulebook ("four legs, fur,
tail, barks…" — a cat has most of those too). Instead, parents point and say "dog", "not a dog",
"dog" hundreds of times, and the child's brain figures out the pattern on its own.

**Machine learning is the same idea for computers:** instead of writing the rules, you show many
examples with the right answers, and an algorithm finds the rules for you.

| Everyday example | Rules approach | ML approach |
|---|---|---|
| Email spam filter | list of banned phrases (spammers get around it within days) | learn from millions of emails marked "spam" / "not spam" |
| Netflix recommendations | "people who like action get action movies" | learn from what millions of similar viewers watched |
| Bank fraud alert | "flag purchases over $5,000" | learn what *your* normal spending looks like and flag unusual patterns |
| Phone face unlock | impossible to write by hand | learn from many photos of faces |

## Architecture at a glance

```mermaid
flowchart LR
  subgraph TRAIN["Training time (once, expensive)"]
    D[(Examples:<br/>inputs + correct answers)] --> ALG[Learning algorithm<br/>minimize the loss]
    ALG --> M[(Model file<br/>learned parameters θ)]
  end
  subgraph INFER["Inference time (every request, cheap)"]
    X[New input] --> P["Model f(x; θ)"]
    M --> P
    P --> Y[Prediction ŷ]
  end
  Y -.later: true answer arrives.-> D
```

**How to read it:** training turns examples into a model file — like compiling source code into a
binary. Inference runs that file on new inputs. When the true answers for those inputs show up later,
they become new training examples, which is why ML systems keep improving (or keep degrading if you
ignore them).

## 1. The problem with hand-written rules

As an SDE you solve problems by writing explicit logic:

```python
def is_spam(email: str) -> bool:
    if "free money" in email.lower():
        return True
    if email.count("!") > 5:
        return True
    return False
```

This works for a week. Then spammers write "fr33 m0ney", use one `!`, embed text in images, and
your rule list grows to 4,000 `if` statements that contradict each other. Three things broke:

1. **The rules are unknown.** You can't write down how you recognize a face, a sarcastic review,
   or a fraudulent transaction. You *know* it when you see it, but you can't write it as code.
2. **The world changes.** Spam, fraud, and user taste drift. Rules rot.
3. **There are too many interacting signals.** A fraud decision may depend on 300 features with
   non-obvious interactions ("small amount" is normal, unless it's at 3am, from a new device, after
   a password reset).

**Machine learning flips the process:**

```
 Traditional programming:   rules + data  ──► program ──► answers
 Machine learning:          data + answers ──► training ──► rules (the model)
```

You give examples of inputs with the correct outputs, and an algorithm *searches* for a function
that maps one to the other.

## 2. What "learning" means, precisely

A model is a function with adjustable numbers (parameters) $\theta$:

$$
\hat{y} = f(\mathbf{x};\, \theta)
$$

**Read it as:** "the prediction $\hat{y}$ is what function $f$ outputs for input $\mathbf{x}$ when its
knobs are set to $\theta$."

We define a **loss** that measures how wrong a prediction is, e.g. squared error
$\ell(\hat{y}, y) = (\hat{y} - y)^2$. Learning = finding the knob settings that make the average
loss over the training data as small as possible:

$$
\theta^* = \arg\min_{\theta} \; \frac{1}{n}\sum_{i=1}^{n} \ell\big(f(\mathbf{x}_i;\theta),\, y_i\big)
$$

**Read it as:** "loop over all $n$ training examples, compute how wrong we are on each, average
those numbers, and pick the $\theta$ that makes that average smallest." $\arg\min$ means "the
argument that minimizes" — we want the *settings*, not the minimum value itself.

This one equation is the whole field. Every model in this course — linear regression, a CNN, GPT —
is a different choice of:

| Choice | Examples |
|---|---|
| **Model family** $f$ | line, tree, neural network, transformer |
| **Loss** $\ell$ | squared error, cross-entropy, contrastive loss |
| **Optimizer** (how to search $\theta$) | closed form, gradient descent, Adam |
| **Data** | labeled rows, images, text from the internet |

### But minimizing training loss is not the goal

The real goal is to do well on **data you have never seen** (generalization). A model that memorizes
the training set — like a hash map from inputs to outputs — has zero training loss and is useless.
Most of ML practice (module 03) is about guarding against this.

## 3. Types of learning

| Type | You have | You learn | Examples |
|---|---|---|---|
| **Supervised** | inputs **with** labels $(\mathbf{x}, y)$ | $f: \mathbf{x} \to y$ | spam/not spam, house price, image class |
| — Classification | $y$ is a category | class probabilities | fraud detection, sentiment |
| — Regression | $y$ is a number | a real value | demand forecast, ETA |
| **Unsupervised** | inputs only | structure in data | customer segments (clustering), anomaly detection, compression |
| **Self-supervised** | raw data; labels created from the data itself | general representations | **LLM pretraining**: predict the next word; BERT: fill the blank |
| **Reinforcement learning** | an environment and a reward | a policy (what action to take) | games, robotics, **RLHF** for chat models |
| **Semi-supervised** | a few labels + lots of unlabeled data | supervised task, cheaper | medical imaging |

Self-supervised learning is the key unlock for LLMs: the internet has trillions of words and
*every* word is a free label ("given the words before, predict this one"). No human labeling needed.

## 4. AI vs ML vs DL vs LLM

```
┌──────────────────────────────── Artificial Intelligence ─────────────────────────────────┐
│ any technique that makes machines act intelligently (incl. search, rules, planning)      │
│   ┌──────────────────────────── Machine Learning ─────────────────────────────────────┐  │
│   │ systems that learn from data (linear models, trees, SVMs, neural nets)            │  │
│   │   ┌──────────────────────── Deep Learning ──────────────────────────────────┐     │  │
│   │   │ neural nets with many layers that learn their own features              │     │  │
│   │   │   ┌──────────────── Large Language Models ─────────────────────┐        │     │  │
│   │   │   │ huge transformers trained on text to predict the next token │        │     │  │
│   │   │   └────────────────────────────────────────────────────────────┘        │     │  │
│   │   └─────────────────────────────────────────────────────────────────────────┘     │  │
│   └───────────────────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────────────────┘
```

### Why deep learning was needed

Classic ML needs **features**: a human decides what to measure (e.g. "number of exclamation marks",
"account age in days"). For tabular business data this works great. For raw images, audio, and text
it doesn't — what's the feature for "contains a cat"?

| | Classic ML | Deep learning |
|---|---|---|
| Features | hand-engineered by humans | **learned** from raw data, layer by layer |
| Best on | tabular data, small/medium datasets | images, audio, text, very large datasets |
| Data needed | hundreds to millions of rows | usually much more |
| Compute | CPU, seconds to minutes | GPU, hours to months |
| Interpretability | often good (coefficients, tree splits) | hard |
| Typical winner on spreadsheets | gradient-boosted trees (XGBoost/LightGBM) | rarely better |

A deep network learns a **hierarchy**: in an image model, layer 1 detects edges, layer 2 corners and
textures, layer 3 parts (eyes, wheels), later layers whole objects. Nobody programmed that; it falls
out of minimizing the loss.

### Why LLMs were needed

Earlier NLP built one model per task (one for sentiment, one for translation, one for NER), each with
its own labeled dataset. LLMs showed that one model, pretrained to predict the next token on enough
text, learns grammar, facts, reasoning patterns, and code — and can then do many tasks from a prompt.
The path that got us there is modules 06 → 07 → 08.

## 5. When NOT to use ML

ML adds cost: data pipelines, training, monitoring, non-determinism, and a new class of bugs. Use
plain code when:

- **The rules are known and stable.** Tax calculation, input validation, routing tables.
- **You need guaranteed correctness.** A model is right *most* of the time; a sort function always.
- **You have no data** (or no labels and no way to get them).
- **The cost of an error is high and you can't detect it.** If wrong predictions are silent and
  catastrophic, ML is risky without a human in the loop.
- **A simple heuristic gets 95% of the value.** Ship the heuristic first. It's also your baseline.

> Rule from Google's "Rules of ML": *"Don't be afraid to launch a product without machine learning."*
> A heuristic gives you a baseline, a pipeline, and logged data you can later train on.

## 6. The ML workflow (the map for this whole course)

```mermaid
flowchart LR
  A[Frame the problem<br/>what to predict, metric, baseline] --> B[Collect & label data]
  B --> C[Explore & clean<br/>EDA, features]
  C --> D[Split: train / val / test]
  D --> E[Train models]
  E --> F[Evaluate on validation<br/>tune, iterate]
  F -->|not good enough| C
  F --> G[Final test-set check]
  G --> H[Deploy<br/>batch or online]
  H --> I[Monitor<br/>drift, quality, cost]
  I -->|degrades| B
```

**How to read it:** the first half (A→G) is modules 02–09; deploy and monitor (H→I) are modules 10–11.
The loop back from monitoring to data is why ML systems are never "done" — unlike most software,
they degrade even if nobody touches the code, because the *world* changes.

### Framing checklist (do this before touching data)

| Question | Bad answer | Good answer |
|---|---|---|
| What exactly is predicted? | "churn" | "probability a paying user cancels in the next 30 days" |
| What decision does it drive? | "insights" | "send a retention offer if p > 0.3" |
| What metric? | "accuracy" | "recall at 5% precision cost; offer cost $5, churn cost $120" |
| What's the baseline? | none | "users inactive 14+ days → 0.62 recall today" |
| Latency / volume? | unknown | "nightly batch, 2M users" |
| Where do labels come from? | "we'll figure it out" | "cancellation events, available 30 days later" |

## 7. A first end-to-end example (5 minutes, scikit-learn)

```python
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import classification_report

X, y = load_breast_cancer(return_X_y=True)          # 569 rows, 30 numeric features
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42)

model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
model.fit(X_train, y_train)                          # "training" = minimizing the loss
print(classification_report(y_test, model.predict(X_test)))   # ~97% accuracy
```

Everything in those 10 lines — why we split, why we scale, what `fit` minimizes, what the report
numbers mean — is explained in modules 02 and 03.

## 8. Key takeaways

- ML = **search for a function** using data, a loss, and an optimizer.
- The goal is **generalization** to unseen data, not low training loss.
- Deep learning removes manual feature engineering for raw, high-dimensional data.
- LLMs are deep learning + self-supervision (next-token prediction) + enormous scale.
- Always start with a baseline and a clearly framed metric; sometimes the baseline wins.

## Interview questions

1. *When would you not use ML?* — known stable rules, no data, need for guaranteed correctness,
   heuristic is good enough.
2. *Supervised vs self-supervised?* — self-supervised creates labels from the data itself (next token,
   masked token), so it scales to unlabeled data.
3. *Why do trees still beat deep learning on tabular data?* — tabular features are already meaningful,
   heterogeneous, and datasets are small; trees handle that with little tuning, while neural nets'
   advantage (learning features from raw signals) doesn't apply.
