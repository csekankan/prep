# 05 — Training Deep Networks: Making Them Actually Learn

> **Why it matters:** a 2-layer net trains with plain SGD. A 100-layer net or a 70B-parameter LLM
> won't — gradients vanish or explode, loss spikes, runs diverge. The techniques here (Adam, warmup,
> normalization, residuals, mixed precision) are exactly what makes transformers trainable.
>
> Deeper math: [optimization](../14_math_for_ml_dl_llm/05_optimization.md),
> [math of deep learning](../14_math_for_ml_dl_llm/06_math_of_deep_learning.md).

## In plain words

Remember the children's game **"telephone"**: a message is whispered down a line of 50 people. By the
end it's garbled or lost. Training a deep network has the same problem — the error signal is passed
backwards through every layer, and after many layers it fades to nothing (vanishing gradients) or
grows into nonsense (exploding gradients).

The techniques in this module are fixes for that game:

| Technique | Telephone-game fix |
|---|---|
| Good initialization | everyone starts by speaking at a normal volume, not whispering or shouting |
| Normalization (LayerNorm) | each person repeats the message at a standard volume before passing it on |
| Residual connections | also pass the *original written note* down the line, so nothing important is lost |
| Adam optimizer | each person adjusts how loudly they speak based on their own recent history |
| Learning-rate warmup | start the game slowly until everyone understands the rules |
| Gradient clipping | if anyone starts shouting, cap their volume |
| Dropout | randomly skip people during practice so the line doesn't depend on any one person |

## Architecture at a glance: anatomy of a training step

```mermaid
flowchart LR
  DL[DataLoader<br/>mini-batch] --> FWD[Forward pass<br/>bf16 autocast]
  FWD --> LOSS[Loss]
  LOSS --> BWD[Backward pass<br/>gradients]
  BWD --> ACC{Accumulated<br/>k micro-batches?}
  ACC -->|no| DL
  ACC -->|yes| CLIP[Clip gradient norm]
  CLIP --> SCHED[Set LR from schedule<br/>warmup → cosine]
  SCHED --> OPT[AdamW step<br/>+ weight decay]
  OPT --> ZERO[Zero gradients]
  ZERO --> LOG[Log loss, LR,<br/>grad norm, throughput]
  LOG --> EVAL{Eval interval?}
  EVAL -->|yes| VAL[Validation + checkpoint<br/>early stopping]
  EVAL -->|no| DL
  VAL --> DL
```

**How to read it:** this is the exact shape of the PyTorch loop in section 11, and of LLM training
loops at any scale. Distributed training (module 08) only changes *where* each box runs.

## 1. The core problem: signals through many layers

Backprop multiplies one factor per layer on the way back:

$$
\frac{\partial L}{\partial \mathbf{h}_1} = \frac{\partial L}{\partial \mathbf{h}_N}\prod_{\ell=2}^{N}\frac{\partial \mathbf{h}_\ell}{\partial \mathbf{h}_{\ell-1}}
$$

**Read it as:** the gradient reaching layer 1 is a product of $N-1$ terms. If each is ~0.5, after 50
layers you get $0.5^{50} \approx 10^{-15}$ — **vanishing gradients**, early layers stop learning.
If each is ~1.5, you get $1.5^{50} \approx 6\times10^{8}$ — **exploding gradients**, loss becomes NaN.

Sigmoid makes this worse: its derivative is at most 0.25, so even in the best case each layer
shrinks the gradient by 4×. That's a big reason deep nets didn't work before ~2010.

Almost every technique below exists to keep that product near 1.

## 2. Weight initialization

Goal: keep the variance of activations (forward) and gradients (backward) roughly constant from layer
to layer.

For a layer with $n_{in}$ inputs, the output is a sum of $n_{in}$ terms $w_i x_i$. If weights and
inputs are independent with mean 0, $\text{Var}(\text{out}) = n_{in}\,\text{Var}(w)\,\text{Var}(x)$.
To keep $\text{Var}(\text{out}) = \text{Var}(x)$ we need $\text{Var}(w) = 1/n_{in}$.

| Scheme | Weight variance | For |
|---|---|---|
| Xavier / Glorot | $\frac{2}{n_{in} + n_{out}}$ | tanh, sigmoid |
| **He / Kaiming** | $\frac{2}{n_{in}}$ | ReLU (ReLU zeroes half the inputs, so double it) |
| GPT-2 style | $\mathcal{N}(0, 0.02^2)$, residual projections scaled by $1/\sqrt{2N_{layers}}$ | transformers |

**Read it as:** "the more inputs a neuron has, the smaller each weight must start." Frameworks do this
by default (`nn.Linear` uses a Kaiming-uniform variant), but custom architectures often get it wrong.

## 3. Optimizers: beyond plain SGD

### SGD with momentum

$$
\mathbf{v} \leftarrow \beta\mathbf{v} + \nabla L, \qquad \theta \leftarrow \theta - \eta\mathbf{v}
$$

**Read it as:** keep a running "velocity" — an exponentially weighted average of past gradients
($\beta \approx 0.9$ ≈ averaging the last ~10 steps). Consistent directions build up speed; noisy
zig-zags cancel out. Like a ball rolling downhill instead of a hiker re-deciding every step.

### Adam (and AdamW) — the default for deep learning

Adam keeps two running averages per parameter:

$$
\begin{aligned}
\mathbf{m} &\leftarrow \beta_1 \mathbf{m} + (1-\beta_1)\,\mathbf{g} &&\text{(mean of gradients: direction)}\\
\mathbf{v} &\leftarrow \beta_2 \mathbf{v} + (1-\beta_2)\,\mathbf{g}^2 &&\text{(mean of squared gradients: scale)}\\
\hat{\mathbf{m}} &= \frac{\mathbf{m}}{1-\beta_1^t},\quad \hat{\mathbf{v}} = \frac{\mathbf{v}}{1-\beta_2^t} &&\text{(bias correction for early steps)}\\
\theta &\leftarrow \theta - \eta\,\frac{\hat{\mathbf{m}}}{\sqrt{\hat{\mathbf{v}}} + \epsilon}
\end{aligned}
$$

**Read it as:** each parameter gets its own effective learning rate. Parameters with consistently
large gradients get smaller steps (divided by a big $\sqrt{v}$); rarely-updated parameters (e.g. the
embedding of a rare word) get relatively larger steps. Defaults: $\beta_1 = 0.9$, $\beta_2 = 0.999$
(LLMs often use 0.95), $\epsilon = 10^{-8}$.

**Bias correction:** $\mathbf{m}$ starts at 0, so early averages are too small. At step 1 with
$\beta_1 = 0.9$, $m = 0.1g$; dividing by $1 - 0.9^1 = 0.1$ recovers $g$.

**AdamW** applies weight decay directly to weights ($\theta \leftarrow \theta - \eta\lambda\theta$)
instead of adding it to the gradient (where Adam's division would distort it). **AdamW is what nearly
every transformer/LLM uses**, typically with $\lambda = 0.1$.

### Memory cost (important for LLMs)

Adam stores $\mathbf{m}$ and $\mathbf{v}$ for every parameter: **2 extra copies of the model**. For a
7B model in fp32 that's 56 GB just for optimizer state. Module 08 does the full budget.

| Optimizer | Extra state per param | Typical use |
|---|---|---|
| SGD | 0 | rarely for transformers |
| SGD + momentum | 1 | CNNs (ResNet on ImageNet) |
| Adam / AdamW | 2 | transformers, almost everything else |
| 8-bit Adam, Adafactor | ~0.5–1 | memory-constrained fine-tuning |

## 4. Learning rate schedules

The learning rate is the most important hyperparameter. A fixed one is rarely best.

```
 lr
  │      ┌──────╮
  │     ╱        ╲__              Warmup: start tiny, ramp up linearly
  │    ╱            ╲__           (Adam's v estimates are noisy at first; big early
  │   ╱                ╲__         steps can wreck a transformer).
  │  ╱                    ╲___    Cosine decay: smoothly lower lr so the model settles
  │ ╱                         ╲_   into a minimum instead of bouncing around it.
  └─────────────────────────────── step
   warmup        cosine decay to ~10% of peak
```

$$
\eta_t = \eta_{\min} + \tfrac{1}{2}(\eta_{\max} - \eta_{\min})\left(1 + \cos\frac{\pi\, t}{T}\right)
$$

**Read it as:** a half cosine wave from $\eta_{\max}$ at $t=0$ down to $\eta_{\min}$ at $t=T$.
Typical LLM pretraining: warmup ~2,000 steps, peak lr $3\times10^{-4}$ (smaller for bigger models),
cosine to 10% of peak. Fine-tuning uses a much lower peak ($1\times10^{-5}$–$2\times10^{-4}$).

**LR range test:** train briefly while increasing lr exponentially; pick a value ~10× below where loss
starts to explode.

## 5. Normalization

### Batch Normalization (CNNs)

For each feature, normalize across the mini-batch, then let the network rescale:

$$
\hat{x} = \frac{x - \mu_{\text{batch}}}{\sqrt{\sigma^2_{\text{batch}} + \epsilon}}, \qquad y = \gamma\hat{x} + \beta
$$

Keeps each layer's input distribution stable, allowing higher learning rates. Downsides: depends on
batch size, behaves differently at train vs inference (uses running averages — a classic bug if you
forget `model.eval()`), awkward for variable-length sequences.

### Layer Normalization and RMSNorm (transformers)

Normalize across the **features of a single example** instead of across the batch:

$$
\text{LayerNorm}(\mathbf{x}) = \gamma \odot \frac{\mathbf{x} - \mu}{\sqrt{\sigma^2 + \epsilon}} + \beta,
\qquad
\text{RMSNorm}(\mathbf{x}) = \gamma \odot \frac{\mathbf{x}}{\sqrt{\frac{1}{d}\sum_i x_i^2 + \epsilon}}
$$

**Read it as:** rescale each token's vector so its values have a standard size. RMSNorm skips the mean
subtraction — cheaper, works as well, and is used by LLaMA, Mistral, and most modern LLMs.
Independent of batch size, identical in training and inference.

| | BatchNorm | LayerNorm / RMSNorm |
|---|---|---|
| Normalizes over | batch dimension | feature dimension (per example) |
| Batch-size dependent | yes | no |
| Train ≠ inference | yes (running stats) | no |
| Used in | CNNs | transformers, RNNs |

## 6. Residual connections — the trick that made depth work

$$
\mathbf{h}_{\ell+1} = \mathbf{h}_\ell + F(\mathbf{h}_\ell)
$$

**Read it as:** each block computes a *correction* $F$ and **adds** it to its input, instead of
replacing it. The derivative is

$$
\frac{\partial \mathbf{h}_{\ell+1}}{\partial \mathbf{h}_\ell} = I + \frac{\partial F}{\partial \mathbf{h}_\ell}
$$

The identity term $I$ means the gradient always has a direct "highway" back to early layers, even if
$F$'s gradient is tiny. That fixes the vanishing-product problem from section 1. ResNet (2015) used
this to train 152 layers; **every transformer block uses two residual connections**.

```
  x ──────────────────────┐
  │                       │  (identity / skip)
  └─► Norm ─► F (attn/MLP)┴─(+)─► out      ← "pre-norm" residual block (GPT-2+, LLaMA)
```

## 7. Regularization in deep learning

| Technique | How | Notes |
|---|---|---|
| Weight decay (AdamW) | shrink weights each step | standard everywhere |
| **Dropout** | randomly zero activations with probability $p$ during training; scale the rest by $\frac{1}{1-p}$ | forces redundancy; acts like an ensemble. Off at inference (`model.eval()`). LLM pretraining often uses $p=0$ (data is huge, one epoch) |
| Early stopping | keep the checkpoint with best validation loss | simplest, very effective |
| Data augmentation | flips, crops, color jitter, mixup; for text: back-translation, paraphrase | "free" extra data |
| Label smoothing | train toward 0.9/0.1 instead of 1/0 | reduces overconfidence |
| More data | the best regularizer | |

## 8. Gradient clipping

If the global gradient norm exceeds a threshold, scale it down:

$$
\mathbf{g} \leftarrow \mathbf{g}\cdot\min\!\left(1,\; \frac{c}{\lVert\mathbf{g}\rVert}\right)
$$

**Read it as:** keep the direction, cap the step size. Prevents one bad batch from blowing up the
model. LLMs typically clip at $c = 1.0$. A rising rate of clipped steps is an early warning of
instability.

## 9. Mixed precision and numerics

| Format | Bits | Range | Use |
|---|---|---|---|
| fp32 | 32 | huge | master weights, optimizer state |
| fp16 | 16 | small (max 65,504) — needs loss scaling | older GPUs |
| **bf16** | 16 | same range as fp32, less precision | **default for training on A100/H100** |
| fp8 | 8 | tiny | H100/B200 training and inference, with per-tensor scaling |
| int8 / int4 | 8 / 4 | integers + scale factors | quantized inference (module 09) |

**Mixed precision** = do matmuls in bf16 (2× less memory traffic, much faster tensor cores), keep a
master fp32 copy of weights for the update (tiny updates like $10^{-7}$ would vanish in bf16).

## 10. Batch size and gradient accumulation

Larger batches give less noisy gradients and better GPU utilization, but need more memory. If the
batch doesn't fit, **accumulate**: run $k$ small batches, sum gradients, then step once — mathematically
the same as one batch $k\times$ larger.

Rule of thumb when changing batch size: scale the learning rate roughly proportionally (linear scaling
rule) or by $\sqrt{k}$ for Adam, and re-tune warmup.

## 11. A complete, production-shaped PyTorch training loop

```python
import math, torch, torch.nn as nn
from torch.utils.data import DataLoader

def train(model, train_ds, val_ds, epochs=10, peak_lr=3e-4, wd=0.1,
          batch_size=64, accum_steps=4, warmup=500, clip=1.0, device="cuda"):
    model.to(device)
    train_dl = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=4)
    val_dl = DataLoader(val_ds, batch_size=batch_size)

    # no weight decay on biases and norm gains (standard practice)
    decay = [p for n, p in model.named_parameters() if p.dim() >= 2]
    no_decay = [p for n, p in model.named_parameters() if p.dim() < 2]
    opt = torch.optim.AdamW([{"params": decay, "weight_decay": wd},
                             {"params": no_decay, "weight_decay": 0.0}],
                            lr=peak_lr, betas=(0.9, 0.95))

    total = epochs * len(train_dl) // accum_steps
    def lr_at(step):                                  # warmup + cosine
        if step < warmup:
            return peak_lr * step / warmup
        progress = (step - warmup) / max(1, total - warmup)
        return 0.1 * peak_lr + 0.45 * peak_lr * (1 + math.cos(math.pi * progress))

    loss_fn, step, best_val = nn.CrossEntropyLoss(), 0, float("inf")
    for epoch in range(epochs):
        model.train()                                  # dropout ON
        for i, (x, y) in enumerate(train_dl):
            x, y = x.to(device), y.to(device)
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                loss = loss_fn(model(x), y) / accum_steps
            loss.backward()
            if (i + 1) % accum_steps == 0:
                gnorm = torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
                for g in opt.param_groups:
                    g["lr"] = lr_at(step)
                opt.step(); opt.zero_grad(set_to_none=True); step += 1

        model.eval()                                   # dropout OFF, BN uses running stats
        with torch.no_grad():
            val = sum(loss_fn(model(x.to(device)), y.to(device)).item()
                      for x, y in val_dl) / len(val_dl)
        print(f"epoch {epoch} val_loss {val:.4f} grad_norm {gnorm:.2f}")
        if val < best_val:                             # early-stopping checkpoint
            best_val = val
            torch.save(model.state_dict(), "best.pt")
```

## 12. Debugging a training run (the playbook)

**Step 0 — sanity checks before a long run:**

1. Initial loss should match theory: for $K$ classes with random init, $\approx \ln K$
   (10 classes → 2.30; a 50k vocab LLM → 10.8). Way off ⇒ init or label bug.
2. **Overfit one batch.** Train on 1 batch of 8 examples; loss should go to ~0. If not, the model,
   loss, or labels are broken — no point training on the full data.
3. Check data visually: decode a batch back to images/text and look at it alongside labels.

**Reading the curves:**

| Symptom | Likely cause | Fix |
|---|---|---|
| Loss flat from the start | lr too low, dead ReLUs, labels shuffled vs inputs, frozen params | LR range test; verify data pipeline; check `requires_grad` |
| Loss → NaN | lr too high, fp16 overflow, `log(0)`, division by zero | lower lr, warmup, bf16, gradient clipping, epsilons |
| Loss spikes then recovers (LLMs) | bad data batch, too high lr, Adam instability | skip batch, lower lr, lower $\beta_2$ to 0.95, clip |
| Train ↓, val ↑ | overfitting | more data/augmentation, dropout, weight decay, early stop |
| Train and val both high, flat | underfitting | bigger model, longer training, higher lr |
| Val better than train | dropout/augmentation only on train; or val easier/leaked | usually fine; check for leakage |
| Great val, bad in prod | train/serve skew, distribution shift | module 10 |

**What to log every N steps:** loss (train/val), learning rate, global grad norm, % of clipped steps,
throughput (samples/s or tokens/s), GPU memory, and periodically sample predictions.

## 13. Key takeaways

- Deep nets fail because gradient products vanish or explode; init, normalization, and residuals
  keep them near 1.
- AdamW + warmup + cosine decay + gradient clipping + bf16 is the standard modern recipe.
- LayerNorm/RMSNorm (not BatchNorm) and pre-norm residual blocks are what transformers use.
- Always overfit one batch and check the initial loss before launching a long run.

## Interview questions

1. *Why does Adam need warmup?* — early second-moment estimates are based on few samples and can be
   tiny, giving huge effective step sizes; warmup keeps early updates small until the estimates settle.
2. *Why LayerNorm instead of BatchNorm in transformers?* — sequences vary in length, batches can be
   small, and inference is often batch size 1; LayerNorm is per-token and batch-independent.
3. *How do residual connections help gradient flow?* — the identity path adds $I$ to each layer's
   Jacobian, so gradients reach early layers without being multiplied by many small factors.
4. *You doubled the batch size. What else changes?* — learning rate (scale up), number of steps per
   epoch (halves), warmup in steps, and memory; generalization can drop at very large batch sizes.
