# 06 — CNNs, RNNs, and the Road to Attention

> **Why it matters:** transformers didn't appear from nowhere. They fixed specific, painful limits of
> CNNs and RNNs. If you understand those limits, the design of attention (module 07) feels inevitable
> instead of magical. Also: CNNs still power most vision systems, and the ideas of weight sharing and
> inductive bias are everywhere.

## In plain words

Three ways to read, explained with everyday tasks:

- **CNN = looking at a photo with a magnifying glass.** You slide a small magnifying glass across the
  picture looking for the same small patterns everywhere (edges, corners, textures), then zoom out
  and combine them into bigger shapes (eyes, wheels), then whole objects (face, car).
- **RNN = reading a book one word at a time while keeping notes in a small notebook.** After each
  word you update the notebook. Problem: the notebook is small, so by page 10 you've forgotten
  details from page 1. And you can't read page 2 until you've finished page 1 — no teamwork possible.
- **Attention = reading with the whole book open on the table.** For every word, you can instantly
  flip back to any earlier page that's relevant. Nothing has to squeeze through a small notebook, and
  many readers can work on different pages at the same time (parallel on GPUs).

That last point is why transformers (module 07) won.

## Architecture at a glance

```mermaid
flowchart TB
  subgraph CNN["CNN (images)"]
    I[Image 224×224×3] --> C1[Conv + ReLU<br/>edges]
    C1 --> C2[Conv + pool<br/>textures]
    C2 --> C3[Conv + pool<br/>parts]
    C3 --> GAP[Global avg pool] --> FC[Linear → class scores]
  end
  subgraph RNN["RNN / LSTM (sequences)"]
    W1[word 1] --> R1[cell] --> R2[cell] --> R3[cell] --> OUTR[final state<br/>= whole sentence<br/>squeezed into one vector]
    W2[word 2] --> R2
    W3[word 3] --> R3
  end
  subgraph ATT["RNN + attention (2014) → Transformer (2017)"]
    Q[decoder step<br/>query] --> SC[score against ALL<br/>encoder states]
    SC --> SM[softmax weights] --> CTX[weighted sum<br/>= context]
  end
```

**How to read it:** the CNN builds a feature hierarchy from local patterns. The RNN passes one state
along a chain (sequential, and a bottleneck at the end). Attention removes the bottleneck by letting
each step look at all states directly — module 07 removes the chain entirely.

## 1. The idea of inductive bias

An MLP treats its input as an unordered bag of numbers. Feed it a 224×224×3 image and the first layer
alone needs $150{,}528 \times 1{,}000 \approx 150$M weights — and it doesn't know that neighboring
pixels are related, or that a cat in the top-left is still a cat in the bottom-right.

**Inductive bias** = assumptions built into the architecture so it needs less data:

| Architecture | Built-in assumption | Good for |
|---|---|---|
| MLP | none | tabular / already-featurized inputs |
| CNN | locality + translation equivariance (same pattern anywhere) | images, audio spectrograms |
| RNN | sequential order; the past summarizes into a state | sequences (historically: text, speech) |
| Transformer | almost none — every token can look at every token; learns structure from data | text, then everything (images, audio, proteins) once data is large |

Less bias = needs more data but has a higher ceiling. That's the story of the last decade.

## 2. Convolutional Neural Networks (CNNs)

### The convolution operation

Slide a small filter (kernel), e.g. 3×3, across the image. At each position, multiply element-wise
and sum — a dot product between the filter and that patch:

$$
\text{out}[i,j] = \sum_{u=0}^{k-1}\sum_{v=0}^{k-1} K[u,v]\cdot X[i+u,\, j+v] + b
$$

**Read it as:** "how much does this patch look like the filter?" A filter is a pattern detector.

Worked example — a vertical edge detector on a 4×4 image:

```
 image X              kernel K            output (2×2, stride 1, no padding)
 0 0 9 9              1 0 -1              (0+0-9)+(0+0-9)+(0+0-9) = -27   ...
 0 0 9 9              1 0 -1
 0 0 9 9              1 0 -1              → large magnitude where brightness changes
 0 0 9 9                                     left-to-right: an edge
```

Nobody hand-designs filters anymore — they're **learned** by backprop, exactly like MLP weights.

### Why it works: two key properties

1. **Local connectivity:** each output looks at a small patch (3×3), not the whole image.
2. **Weight sharing:** the same filter is used at every position. A 3×3×3 filter has 27 weights + 1
   bias regardless of image size. Detecting "edge" in one place means detecting it everywhere.

### Shapes and parameter counts (you will be asked this)

Output spatial size:

$$
W_{out} = \left\lfloor \frac{W_{in} - K + 2P}{S} \right\rfloor + 1
$$

**Read it as:** input width, minus kernel size, plus padding on both sides, divided by stride, plus 1.

Example: 224×224×3 input, 64 filters of 3×3, padding 1, stride 1 →
$W_{out} = (224 - 3 + 2)/1 + 1 = 224$. Output: 224×224×64.
Parameters: $64 \times (3 \times 3 \times 3 + 1) = 1{,}792$. Compare with ~150M for the MLP layer.

### Building blocks

| Block | What it does |
|---|---|
| Conv + ReLU | detect patterns |
| Pooling (max/avg 2×2) | downsample by 2×, adds small translation invariance |
| Stride 2 conv | learned downsampling (modern replacement for pooling) |
| BatchNorm | stabilize training |
| Residual block | enable 50–150+ layers (ResNet) |
| Global average pool + linear | turn the final feature map into class scores |

### Receptive field and the feature hierarchy

Each 3×3 layer grows the area of the original image a neuron "sees" by 2 pixels; downsampling
multiplies it. Deep layers see the whole image:

```
 layer 1: edges, colors        layer 3: textures, corners      layer 5+: eyes, wheels, faces
 [ / | — ]                     [ ▦ ◢ ◣ ]                       [ 👁  ⚙  🙂 ]
```

### CNN milestones

| Year | Model | Idea |
|---|---|---|
| 1998 | LeNet | conv + pool for digits |
| 2012 | **AlexNet** | GPUs + ReLU + dropout on ImageNet; started the deep learning boom |
| 2014 | VGG | just stack 3×3 convs deeper |
| 2015 | **ResNet** | residual connections → 152 layers |
| 2019 | EfficientNet | scale depth/width/resolution together |
| 2020 | **Vision Transformer (ViT)** | split an image into 16×16 patches, treat them as tokens, use a transformer |

### Minimal PyTorch CNN

```python
import torch.nn as nn

class SmallCNN(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),   # 32×32×32
            nn.Conv2d(32, 64, 3, padding=1, stride=2), nn.BatchNorm2d(64), nn.ReLU(),  # 16×16×64
            nn.Conv2d(64, 128, 3, padding=1, stride=2), nn.BatchNorm2d(128), nn.ReLU(), # 8×8×128
        )
        self.head = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(128, num_classes))

    def forward(self, x):          # x: (batch, 3, 32, 32)
        return self.head(self.features(x))
```

### Transfer learning (what you'll actually do in practice)

Don't train from scratch. Take a model pretrained on ImageNet, replace the last layer, fine-tune:

```python
import torchvision, torch.nn as nn
model = torchvision.models.resnet50(weights="IMAGENET1K_V2")
for p in model.parameters():
    p.requires_grad = False                     # freeze the feature extractor
model.fc = nn.Linear(model.fc.in_features, 5)   # new head for your 5 classes
# train only model.fc first; then optionally unfreeze the last block with a small lr
```

With a few hundred images per class, this often beats a from-scratch model trained on 100× more data.
**This exact idea — pretrain big, adapt small — is the business model of LLMs.**

## 3. Recurrent Neural Networks (RNNs)

### The idea: a loop with memory

Text is a sequence of variable length. An RNN reads one token at a time and keeps a **hidden state**
$\mathbf{h}_t$ that summarizes everything so far:

$$
\mathbf{h}_t = \tanh\big(W_{hh}\mathbf{h}_{t-1} + W_{xh}\mathbf{x}_t + \mathbf{b}\big), \qquad
\hat{\mathbf{y}}_t = W_{hy}\mathbf{h}_t
$$

**Read it as:** "new memory = squash(old memory transformed + current input transformed)." The **same
weights** are used at every step (weight sharing across time, like a CNN shares across space).

```
       y1        y2        y3
       ▲         ▲         ▲
 h0 ─► [RNN] ─► [RNN] ─► [RNN] ─► h3      same weights in every box
       ▲         ▲         ▲
      "the"    "cat"     "sat"
```

As code, it's literally a `for` loop:

```python
h = np.zeros(hidden)
for x_t in sequence:
    h = np.tanh(W_hh @ h + W_xh @ x_t + b)
```

### Problem 1: vanishing gradients through time

Backprop through time multiplies by $W_{hh}$ (and tanh's derivative) once per step. Over 100 tokens,
that's the vanishing/exploding product from module 05, section 1. In practice, plain RNNs forget
anything more than ~10–20 tokens back. In "The **keys** to the old cabinet in the hallway **are**…",
the model must remember "keys" (plural) across 8 words.

### LSTM: a gated memory cell

The LSTM (1997) adds a separate **cell state** $\mathbf{c}_t$ with gates that decide what to keep,
write, and output:

$$
\begin{aligned}
\mathbf{f}_t &= \sigma(W_f[\mathbf{h}_{t-1}, \mathbf{x}_t] + \mathbf{b}_f) &&\text{forget gate: what to erase}\\
\mathbf{i}_t &= \sigma(W_i[\mathbf{h}_{t-1}, \mathbf{x}_t] + \mathbf{b}_i) &&\text{input gate: what to write}\\
\tilde{\mathbf{c}}_t &= \tanh(W_c[\mathbf{h}_{t-1}, \mathbf{x}_t] + \mathbf{b}_c) &&\text{candidate content}\\
\mathbf{c}_t &= \mathbf{f}_t \odot \mathbf{c}_{t-1} + \mathbf{i}_t \odot \tilde{\mathbf{c}}_t &&\text{update memory}\\
\mathbf{o}_t &= \sigma(W_o[\mathbf{h}_{t-1}, \mathbf{x}_t] + \mathbf{b}_o) &&\text{output gate}\\
\mathbf{h}_t &= \mathbf{o}_t \odot \tanh(\mathbf{c}_t)
\end{aligned}
$$

**Read it as:** gates are sigmoids (0 = closed, 1 = open) acting like soft `if` statements. The key
line is $\mathbf{c}_t = \mathbf{f}_t \odot \mathbf{c}_{t-1} + \dots$: it's **additive**, like a
residual connection. If the forget gate stays near 1, information (and gradient) flows through many
steps unchanged. GRUs are a simpler 2-gate variant.

LSTMs powered Google Translate, Siri, and keyboard prediction around 2014–2017.

## 4. Sequence-to-sequence and the bottleneck

For translation, an **encoder** RNN reads the source sentence into a final hidden state, and a
**decoder** RNN generates the target from it:

```
 Encoder:  "the" → "black" → "cat" → "sleeps" ──► [ single vector c ] ──► Decoder: "le" "chat" "noir" "dort"
                                                   ▲
                                                   the bottleneck: the entire sentence
                                                   squeezed into e.g. 512 numbers
```

Quality collapsed on long sentences: you can't fit a 50-word paragraph into one fixed-size vector.

## 5. Attention: let the decoder look back

Bahdanau et al. (2014): instead of one vector, keep **all** encoder hidden states
$\mathbf{h}_1..\mathbf{h}_n$. At each decoder step, compute how relevant each source word is to what
we're generating now, and take a weighted average:

$$
e_{t,i} = \text{score}(\mathbf{s}_t, \mathbf{h}_i), \qquad
\alpha_{t,i} = \frac{e^{e_{t,i}}}{\sum_j e^{e_{t,j}}}, \qquad
\mathbf{c}_t = \sum_i \alpha_{t,i}\,\mathbf{h}_i
$$

**Read it as:**
1. Score each source position against the current decoder state (how relevant is it?).
2. Softmax the scores into weights that sum to 1.
3. The context vector is the weighted average of source states.

When generating "noir", attention puts most weight on "black". The model learns soft alignment
without anyone labeling which words correspond.

**This is a soft, differentiable dictionary lookup:** the decoder state is a *query*, encoder states are
*keys* (to match against) and *values* (to retrieve). Module 07 generalizes exactly this.

## 6. Why recurrence had to go

Even with attention, RNNs had a fatal engineering problem:

| Limitation | Why it hurts |
|---|---|
| **Sequential computation** | $\mathbf{h}_t$ needs $\mathbf{h}_{t-1}$. You can't parallelize across the sequence, so GPUs (built for huge parallel matmuls) sit mostly idle. Training on billions of tokens becomes impractically slow. |
| Long paths | information from token 1 reaches token 500 only after 499 squashing steps |
| Fixed-size state | everything must still pass through $\mathbf{h}_t$ |

**"Attention Is All You Need" (2017)** asked: what if we drop the recurrence entirely and let every
token attend to every other token directly, in parallel?

| | RNN | CNN (1D over text) | Self-attention |
|---|---|---|---|
| Compute per layer | $O(n \cdot d^2)$ | $O(k \cdot n \cdot d^2)$ | $O(n^2 \cdot d)$ |
| Sequential steps | $O(n)$ ❌ | $O(1)$ | $O(1)$ ✅ |
| Path length between any two tokens | $O(n)$ | $O(\log_k n)$ | $O(1)$ ✅ |

($n$ = sequence length, $d$ = hidden size, $k$ = kernel size.)

**Read it as:** self-attention costs more when sequences are very long ($n^2$ — that's why context
length is expensive), but it's fully parallel and any token can directly reach any other. On GPUs, that
trade was overwhelmingly worth it, and it unlocked training on internet-scale data.

## 7. Key takeaways

- CNNs = local filters + weight sharing; great inductive bias for images; transfer learning is the norm.
- RNNs process sequences with a recurrent state but suffer vanishing gradients and can't parallelize.
- LSTMs add gated, additive memory (an early cousin of residual connections).
- Attention = soft lookup: query vs keys → softmax weights → weighted sum of values.
- Transformers removed recurrence to get parallelism and direct long-range connections.

## Interview questions

1. *Parameters in a conv layer with 128 input channels, 256 output channels, 3×3 kernels?* —
   $256 \times (3\cdot3\cdot128 + 1) = 295{,}168$.
2. *Why are CNNs translation-equivariant?* — the same filter is applied at every position, so shifting
   the input shifts the feature map.
3. *Why did LSTMs mitigate vanishing gradients?* — the cell state update is additive, gated by a forget
   gate that can stay ≈ 1, giving a near-identity gradient path through time.
4. *What's the main reason transformers replaced RNNs?* — parallelism across the sequence during
   training (plus $O(1)$ path length), which made scaling to huge data feasible.
