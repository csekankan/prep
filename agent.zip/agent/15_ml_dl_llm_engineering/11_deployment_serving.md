# 11 — Deployment & Serving: From Model File to Production Traffic

> **Why it matters:** a model only creates value when it answers real requests — fast enough, cheaply
> enough, and safely. This module covers how to choose a serving pattern, package and optimize models,
> serve LLMs efficiently, do capacity and cost math, and roll out without breaking things.
>
> Infra deep dives: `11_kubernetes/` (Docker, Kustomize, canary, GitOps) and
> `13_sovereign_ai_infra_course/04_serving_inference/` (GPU inference scaling).
> Math: [ML systems math](../14_math_for_ml_dl_llm/09_ml_systems_math.md).

## In plain words

Serving a model is like running a **restaurant kitchen**:

| Kitchen | Model serving |
|---|---|
| Cooking every dish to order | **online** (real-time) inference |
| Meal prep on Sunday for the whole week | **batch** inference (score everything nightly) |
| Conveyor-belt sushi | **streaming** inference (process events as they flow) |
| A food truck with a small menu | **edge** inference (on phone/device, small model) |
| Cooking several orders in one pan | **batching** requests on a GPU |
| Prepped ingredients in the fridge | **caching** features, embeddings, or whole responses |
| Trying a new dish on 5% of customers first | **canary** rollout |

Pick the pattern from the business need, not from what's fashionable: if predictions are only needed
in tomorrow's email campaign, a nightly batch job is far simpler and cheaper than a 24/7 API.

## 1. Architecture at a glance: serving patterns

```mermaid
flowchart TB
  subgraph BATCH["Batch (nightly/hourly)"]
    B1[(Warehouse)] --> B2[Spark / Python job<br/>loads model] --> B3[(Predictions table)] --> B4[Apps read results]
  end
  subgraph ONLINE["Online (request/response)"]
    O1[Client] --> O2[API gateway<br/>auth, rate limit] --> O3[Model server] --> O1
    O3 <--> O4[(Online feature store / cache)]
  end
  subgraph STREAM["Streaming"]
    S1[Kafka / Kinesis events] --> S2[Stream processor<br/>Flink + model] --> S3[Alerts / actions]
  end
  subgraph EDGE["Edge / on-device"]
    E1[Phone / browser / IoT<br/>quantized small model]
  end
```

| Pattern | Latency | Example | Pros | Cons |
|---|---|---|---|---|
| **Batch** | hours | churn scores for a CRM, nightly recommendations | simple, cheap, easy to retry and validate | stale; can't use real-time context |
| **Online** | ms – seconds | fraud check at checkout, chatbots, search ranking | fresh, uses request context | needs high availability, autoscaling, latency budgets |
| **Streaming** | seconds | anomaly detection on IoT/telemetry, real-time fraud signals | near real-time on event flows | operationally complex |
| **Edge** | ms, offline-capable | keyboard prediction, on-device speech | privacy, no network cost | small models only, hard to update |

Hybrid is common: precompute heavy parts in batch (user embeddings), combine with fresh signals online.

## 2. Packaging a model

### Model formats

| Format | What | Use |
|---|---|---|
| `joblib` / pickle | serialized Python object | scikit-learn; **never load untrusted pickles** (arbitrary code execution) |
| PyTorch `state_dict` / `.safetensors` | raw weights (safetensors = safe, fast, memory-mapped) | the standard for sharing LLM weights |
| TorchScript / `torch.export` | traced graph runnable without Python model code | C++ serving |
| **ONNX** | framework-neutral graph | ONNX Runtime on CPU/GPU, often 2–5× faster than eager Python for small models |
| TensorRT engine | compiled, fused, hardware-specific | max NVIDIA performance |
| GGUF | quantized LLM weights | llama.cpp / Ollama on CPU and Macs |

### Export to ONNX and serve with ONNX Runtime

```python
import torch, onnxruntime as ort, numpy as np

model.eval()
dummy = torch.randn(1, 30)
torch.onnx.export(model, dummy, "model.onnx", input_names=["x"], output_names=["logits"],
                  dynamic_axes={"x": {0: "batch"}, "logits": {0: "batch"}})

sess = ort.InferenceSession("model.onnx", providers=["CPUExecutionProvider"])
logits = sess.run(None, {"x": np.random.randn(8, 30).astype(np.float32)})[0]
```

### A production-shaped online API (FastAPI)

```python
# serve.py
import joblib, time, logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from prometheus_client import Histogram, Counter, make_asgi_app
import pandas as pd

MODEL_VERSION = "churn-v17"
model = joblib.load("churn_model.joblib")      # load ONCE at startup, not per request

LATENCY = Histogram("predict_latency_seconds", "latency", ["model"])
PRED = Counter("predictions_total", "predictions", ["model", "label"])

class Features(BaseModel):                     # input validation = first line of defense
    tenure_days: int = Field(ge=0, le=20000)
    monthly_spend: float = Field(ge=0)
    support_tickets: int = Field(ge=0)
    plan: str
    country: str
    device: str

app = FastAPI()
app.mount("/metrics", make_asgi_app())

@app.get("/healthz")
def health():                                  # liveness/readiness probe target
    return {"status": "ok", "model": MODEL_VERSION}

@app.post("/predict")
def predict(f: Features):
    start = time.perf_counter()
    try:
        p = float(model.predict_proba(pd.DataFrame([f.model_dump()]))[0, 1])
    except Exception:
        logging.exception("prediction failed")
        raise HTTPException(500, "prediction failed")
    label = "churn" if p > 0.3 else "stay"
    LATENCY.labels(MODEL_VERSION).observe(time.perf_counter() - start)
    PRED.labels(MODEL_VERSION, label).inc()
    # log inputs + output + version for monitoring and future training (mind PII)
    logging.info({"model": MODEL_VERSION, "features": f.model_dump(), "p": p})
    return {"churn_probability": p, "label": label, "model_version": MODEL_VERSION}
```

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY serve.py churn_model.joblib ./
USER 1000
EXPOSE 8000
CMD ["uvicorn", "serve:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "2"]
```

Return the **model version** in every response and log it — it's how you debug "why did user X get
this answer last Tuesday?"

## 3. Reference architecture for online ML serving

```mermaid
flowchart LR
  C[Clients] --> GW[API gateway<br/>authN/Z, rate limits,<br/>request validation]
  GW --> RT[Router / traffic splitter<br/>canary %, A/B, shadow]
  RT --> M1[Model server v17<br/>pods / GPU nodes]
  RT --> M2[Model server v18<br/>canary 5%]
  RT -.mirror.-> SH[Shadow v19<br/>responses discarded]
  M1 <--> FS[(Online features<br/>Redis)]
  M1 <--> CA[(Response / embedding<br/>cache)]
  M1 --> LOGS[(Prediction logs<br/>→ data lake)]
  M1 --> MET[Metrics + traces<br/>Prometheus / OTel]
  MET --> HPA[Autoscaler<br/>HPA / KEDA]
  HPA --> M1
```

**How to read it:** the gateway protects the system; the router decides *which model version* serves
each request (that's how canaries and A/B tests work); model servers fetch fresh features and use
caches; every prediction is logged for monitoring and future training; metrics drive autoscaling.

## 4. Latency and capacity math

### Latency budget

A 200 ms checkout budget for a fraud check might split like: network 20 ms + feature lookups 30 ms +
model 40 ms + business rules 10 ms + safety margin 100 ms. Design to **p99**, not average — at
1,000 requests/s, a 1% slow tail hits 10 users every second.

### Little's Law — the one formula for capacity

$$
L = \lambda \times W
$$

**Read it as:** *concurrent requests in the system = arrival rate × time each request spends inside.*

- Classic model: 200 req/s × 0.05 s = **10** concurrent requests → a few CPU workers.
- LLM chatbot: 20 req/s, each response 400 tokens at 50 tokens/s = 8 s → **160** concurrent sequences.
  If one GPU replica serves 64 concurrent sequences within your latency target, you need
  $\lceil 160/64 \rceil = 3$ replicas, plus headroom for peaks and failures → **4–5**.

**Plain words:** like a coffee shop — if 20 customers arrive per minute and each stays 8 minutes, you
need seats for 160 people.

### Throughput vs latency: batching

GPUs are fast at big matrix multiplies and wasteful at tiny ones. Grouping requests into a batch
multiplies throughput with a small latency cost:

| Batch size | Latency per request | Throughput |
|---|---|---|
| 1 | 10 ms | 100 req/s |
| 8 | 14 ms | ~570 req/s |
| 32 | 25 ms | ~1,280 req/s |

**Dynamic batching** (Triton, TorchServe, Ray Serve): wait up to a few ms to collect requests, then run
them together. Tune `max_batch_size` and `max_queue_delay` against your p99 target.

## 5. Serving LLMs

LLM serving is different: requests have wildly different lengths, generation is token-by-token, and
the KV cache (module 08) is the main memory consumer.

### Continuous batching

```
 Static batching (wasteful):                Continuous batching (vLLM, TGI, TensorRT-LLM):
 slot 1: AAAAAAAAAAAAAAAAAAAAAA             slot 1: AAAAAAAAAAAAAAAAAAAAAA
 slot 2: BBBBB................ (idle)       slot 2: BBBBBDDDDDDDDFFFFFFFF
 slot 3: CCCCCCCCC............ (idle)       slot 3: CCCCCCCCCEEEEEEEEEEEGG
 → all wait for the longest request         → a finished slot is refilled immediately,
                                              at every decode step
```

**Plain words:** a bus that lets passengers on and off at every stop, instead of waiting until everyone
reaches the final destination before boarding new ones. Typically 5–20× more throughput.

### PagedAttention (vLLM)

Store the KV cache in fixed-size blocks ("pages") allocated on demand, like OS virtual memory, instead
of reserving max-context memory per request. Almost no wasted memory → many more concurrent users per
GPU, and shared prefixes (same system prompt) can share pages (**prefix caching**).

### The LLM serving toolbox

| Technique | Improves | Plain words |
|---|---|---|
| Continuous batching | throughput | keep the GPU full every step |
| PagedAttention + prefix caching | memory, TTFT | don't waste or recompute shared prompt KV |
| Quantization (FP8/INT4/AWQ) | memory, decode speed | fewer bytes to read per token (module 09) |
| Speculative decoding | latency | a small model drafts, the big model verifies several tokens at once |
| Tensor parallelism | fits big models, latency | split each layer across GPUs in a node |
| Chunked prefill | p99 latency | split long prompts so they don't stall other users' decoding |
| Prefill/decode disaggregation | efficiency at scale | separate GPU pools for compute-bound prefill and memory-bound decode |
| Streaming responses (SSE) | perceived latency | show tokens as they're generated |
| Semantic / exact caching | cost, latency | reuse answers for repeated or near-identical questions |
| Model routing | cost | small model for easy requests, large model for hard ones |

### Serving an open model with vLLM

```bash
vllm serve meta-llama/Llama-3.1-8B-Instruct \
  --dtype bfloat16 --max-model-len 16384 \
  --gpu-memory-utilization 0.90 --enable-prefix-caching \
  --enable-lora --lora-modules support=./adapter     # multi-LoRA from module 09
```

```python
from openai import OpenAI                     # vLLM exposes an OpenAI-compatible API
client = OpenAI(base_url="http://localhost:8000/v1", api_key="unused")
stream = client.chat.completions.create(
    model="support",                          # the LoRA adapter name
    messages=[{"role": "user", "content": "How do I reset my password?"}],
    temperature=0.2, max_tokens=300, stream=True)
for chunk in stream:
    print(chunk.choices[0].delta.content or "", end="")
```

### LLM serving metrics

| Metric | Meaning | Typical target (chat) |
|---|---|---|
| TTFT | time to first token | < 0.5–1 s |
| ITL / TPOT | time between output tokens | < 50 ms (≥ 20 tokens/s feels fluent) |
| End-to-end latency | TTFT + ITL × output tokens | depends on answer length |
| Throughput | total output tokens/s per GPU | maximize subject to the latency SLOs |
| KV cache utilization | % of KV memory in use | sustained > 90% → queuing, add replicas |
| Cost per 1M tokens | GPU $/hour ÷ tokens per hour | compare with API pricing |

### Cost math: self-host vs API

$$
\text{cost per 1M tokens} = \frac{\text{GPU \$ per hour}}{\text{tokens per hour}/10^6}
$$

Example: one H100 at \$3/hour running an 8B model at a sustained 2,500 output tokens/s
= 9M tokens/hour → **≈ \$0.33 per 1M tokens**. But that assumes the GPU is busy. At 10% utilization,
it's \$3.30 per 1M. **Self-hosting wins at high, steady volume** (or when data residency requires it);
APIs win for spiky or low volume and for frontier-quality needs.

## 6. Scaling and reliability

| Concern | Practice |
|---|---|
| Autoscaling signal | CPU models: CPU/RPS. GPU/LLM: **queue depth, concurrent requests, KV-cache usage** — GPU utilization % is a poor signal |
| Cold starts | big model images and weights take minutes to load → keep min replicas warm, pre-pull images, cache weights on local NVMe |
| Health checks | readiness only after the model is loaded and a warm-up inference has run |
| Timeouts and retries | timeouts at every hop; retries with backoff only for idempotent calls; cap `max_tokens` |
| Graceful degradation | fall back to a smaller model, a cached answer, or a rules-based default |
| Rate limiting | per user/tenant, in **tokens** for LLMs, not just requests |
| Multi-region | latency, data residency, failover |
| Security | authN/Z, input validation, prompt-injection defenses, output filtering, no PII in logs (`12_ai_security_governance/`) |

```yaml
# Kubernetes: scale an LLM deployment on queue length with KEDA (sketch)
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata: { name: llm-server }
spec:
  scaleTargetRef: { name: llm-server }
  minReplicaCount: 2                 # stay warm: model load takes minutes
  maxReplicaCount: 10
  triggers:
    - type: prometheus
      metadata:
        serverAddress: http://prometheus:9090
        query: avg(vllm:num_requests_waiting)
        threshold: "5"
```

## 7. Rolling out safely

```mermaid
flowchart LR
  OFF[Offline eval gate<br/>module 10] --> SH[Shadow<br/>copy of live traffic,<br/>responses discarded]
  SH --> CAN[Canary<br/>1% → 5% → 25%]
  CAN --> AB[A/B test<br/>business metrics]
  AB --> FULL[100% rollout]
  CAN -->|SLO or quality breach| RB[Automatic rollback]
  AB -->|loses| RB
```

| Strategy | How | Catches | Risk to users |
|---|---|---|---|
| **Shadow** | send a copy of real traffic to the new model; log, don't return | crashes, latency, output distribution differences | none |
| **Canary** | small % of real users get the new model; auto-rollback on alerts | real-world errors and SLO breaches | small |
| **Blue/green** | two full environments; switch traffic at once; instant switch back | deployment/config issues | brief, all users |
| **A/B test** | random split; compare business metrics with statistics | whether it's actually *better* for the business | controlled |
| **Interleaving** (ranking) | mix results from both models in one list | ranking preference, with far less traffic than A/B | low |

### How much traffic does an A/B test need?

For a conversion rate $p$ and a minimum detectable absolute change $\delta$ (≈80% power, 5%
significance), each arm needs roughly:

$$
n \approx \frac{16\, p(1-p)}{\delta^2}
$$

Example: baseline conversion 5%, want to detect a lift to 5.5% ($\delta = 0.005$):
$n \approx 16 \times 0.05 \times 0.95 / 0.000025 \approx 30{,}400$ users **per arm**.
**Plain words:** small improvements need lots of traffic to tell apart from luck. Decide the sample size
*before* starting, and don't stop the test early the moment it looks good ("peeking" inflates false wins).

## 8. Deployment checklist

- [ ] Serving pattern chosen from the business need (batch vs online vs streaming vs edge)
- [ ] Model + preprocessing packaged as one versioned artifact; safe format (no untrusted pickles)
- [ ] Input validation, timeouts, rate limits (tokens for LLMs), auth
- [ ] Model version in responses and logs; prediction logging with PII handling
- [ ] Latency SLOs at p95/p99 tested under load; capacity planned with Little's Law + headroom
- [ ] Autoscaling on the right signal; warm minimum replicas; readiness after warm-up
- [ ] Shadow → canary → A/B with automatic rollback; previous version kept warm
- [ ] Monitoring for service, data drift, predictions, and business metrics (module 10)
- [ ] Fallback path when the model or provider is down
- [ ] Cost per prediction / per 1M tokens tracked

## 9. Key takeaways

- Choose batch/online/streaming/edge from the freshness and latency the business needs.
- Package preprocessing with the model; return and log the model version.
- Little's Law ($L = \lambda W$) sizes concurrency; design for p99; batching trades a little latency
  for a lot of throughput.
- LLM serving = continuous batching + paged KV cache + quantization + streaming; scale on queue depth.
- Roll out through shadow → canary → A/B with automatic rollback; size A/B tests in advance.

## Interview questions

1. *Design serving for a fraud model with a 100 ms budget at 5k req/s.* — online, CPU or small GPU
   model (GBM/ONNX), online feature store, precomputed aggregates via streaming, horizontal autoscaling,
   p99 latency tests, fallback rules if the model times out, shadow/canary rollout, drift monitoring.
2. *Why is GPU utilization a bad autoscaling metric for LLMs?* — decode is memory-bound and continuous
   batching keeps utilization high even when queues are growing; queue depth and KV usage reflect
   user-facing saturation.
3. *Your LLM endpoint's TTFT spikes when long documents arrive. Fixes?* — chunked prefill, prefix caching,
   separate prefill/decode pools, limit max input length, route long-context requests to dedicated replicas.
4. *Shadow vs canary?* — shadow has zero user impact but can't measure user reactions; canary exposes a
   small share of real users to measure real outcomes with limited blast radius.
