# 07 — Attention & Transformers

> **Why it matters:** every modern LLM (GPT, Claude, Gemini, LLaMA, Mistral) is a stack of the same
> transformer block. If you understand this module — tokens, embeddings, attention, the block, the
> mask — you understand the engine of modern AI.
>
> Deeper math: [linear algebra](../14_math_for_ml_dl_llm/01_linear_algebra.md) (dot products, matmul),
> [information theory](../14_math_for_ml_dl_llm/04_information_theory.md) (softmax, cross-entropy),
> [math of transformers & LLMs](../14_math_for_ml_dl_llm/07_math_of_transformers_llms.md).

## In plain words

Imagine reading the sentence: *"The animal didn't cross the street because **it** was too tired."*
To understand "it", your brain glances back and decides "it" = "animal" (not "street").

**Attention is that glance, done with math.** Every word asks a question ("who am I referring to?"),
every other word advertises what it offers ("I'm a noun, an animal"), and each word then gathers
information from the words that answer its question best.

A good everyday analogy is a **search engine inside the sentence**:

| Search engine | Attention |
|---|---|
| Your search text | **Query** — what this token is looking for |
| Page titles/tags | **Keys** — what each token advertises |
| Page contents | **Values** — the information each token actually hands over |
| Ranking by relevance | dot product $q \cdot k$, then softmax |
| Reading the top results | weighted sum of values |

A transformer is just: *turn words into vectors → let every word "search" the others (attention) →
let each word "think" on its own (MLP) → repeat 12–100 times → predict the next word.*

## 1. Architecture at a glance

```mermaid
flowchart TB
  T["Text: 'The cat sat'"] --> TK[Tokenizer<br/>text → token IDs]
  TK --> EMB[Token embedding lookup<br/>ID → vector of size d]
  EMB --> POS[+ position information<br/>RoPE / learned / sinusoidal]
  POS --> B1
  subgraph STACK["× N transformer blocks (12 for GPT-2 small, 32 for LLaMA-7B, 80+ for 70B models)"]
    B1[RMSNorm] --> ATT[Masked multi-head<br/>self-attention]
    ATT --> R1((+))
    R1 --> N2[RMSNorm] --> MLP[Feed-forward MLP<br/>SwiGLU]
    MLP --> R2((+))
  end
  R2 --> FN[Final norm]
  FN --> LM[LM head: linear d → vocab size]
  LM --> SM[Softmax → probability of every next token]
  SM --> OUT["'on' 41%, 'down' 22%, ..."]
```

**How to read it:** text becomes token IDs, IDs become vectors, and the vectors flow up through N
identical blocks. In each block, **attention** mixes information *between* tokens and the **MLP**
transforms each token *on its own*. The `+` circles are residual connections (module 05): each block
adds a correction to its input instead of replacing it. At the top, the last token's vector is turned
into a probability for every word in the vocabulary.

## 2. Tokenization — text to integers

Models can't read text; they read integers. A **tokenizer** splits text into pieces from a fixed
vocabulary (typically 32k–200k pieces) and maps each piece to an ID.

| Approach | "unbelievable" | Problem |
|---|---|---|
| Characters | u, n, b, e, l, … (12 tokens) | sequences too long; each token carries little meaning |
| Whole words | unbelievable (1 token) | vocabulary explodes; unknown words ("unbelievabler") break it |
| **Subwords (BPE)** | un, believ, able (3 tokens) | ✅ best of both — common words are 1 token, rare words split into known pieces |

### Byte-Pair Encoding (BPE) in plain words

Start with individual bytes/characters. Repeatedly find the **most frequent adjacent pair** in the
training text and merge it into a new token. Stop when the vocabulary hits the target size.

```
 corpus: "low lower lowest"
 start:  l o w _ l o w e r _ l o w e s t
 merge 1 (l,o)  → lo w _ lo w e r _ lo w e s t
 merge 2 (lo,w) → low _ low e r _ low e s t
 merge 3 (e,r)  → low _ low er _ low e s t   ... and so on
```

### Why SDEs should care

- **Cost and limits are in tokens**, not characters. English ≈ 4 characters/token ≈ 0.75 words/token.
  Many non-English languages and code use more tokens for the same content (more cost, less context).
- Weird model behaviors come from tokenization: counting letters in "strawberry" is hard because the
  model sees `str|aw|berry`, not letters. Numbers may split oddly (`12345` → `123|45`), hurting arithmetic.

```python
import tiktoken
enc = tiktoken.get_encoding("cl100k_base")
ids = enc.encode("Transformers are unbelievable!")
print(ids, [enc.decode([i]) for i in ids])
# e.g. [9140, 388, 527, 41612, 0] ['Transform', 'ers', ' are', ' unbelievable', '!']
```

## 3. Embeddings — integers to meaning

An **embedding table** is a matrix $E$ of shape `(vocab_size, d)`. Token ID $i$ becomes row $i$:
a vector of $d$ numbers (768 in GPT-2 small, 4096 in LLaMA-7B). It's literally an array lookup:
`x = E[token_id]`.

The table starts random and is learned by backprop. After training, similar tokens end up with
similar vectors, and directions carry meaning:

```
           royalty ▲
                   │   king ●────────► queen ●
                   │        │  (+female)      │
                   │   man  ●────────► woman  ●
                   └─────────────────────────────► gender
   vector("king") − vector("man") + vector("woman") ≈ vector("queen")
```

**Similarity** between two embeddings is measured with the dot product or cosine similarity:

$$
\cos(\mathbf{a}, \mathbf{b}) = \frac{\mathbf{a}\cdot\mathbf{b}}{\lVert\mathbf{a}\rVert\,\lVert\mathbf{b}\rVert}
$$

**Read it as:** 1 = same direction (same meaning), 0 = unrelated, −1 = opposite. This is exactly how
RAG finds relevant documents (`04_rag/`) — and exactly how attention compares tokens.

## 4. Self-attention, step by step

### Step 1: three projections

Each token's vector $\mathbf{x}$ is multiplied by three learned matrices to make three new vectors:

$$
\mathbf{q} = \mathbf{x}W_Q, \qquad \mathbf{k} = \mathbf{x}W_K, \qquad \mathbf{v} = \mathbf{x}W_V
$$

**Read it as:** the same token plays three roles — what it's *looking for* (query), what it
*advertises* (key), and what it *hands over* if chosen (value). For all $n$ tokens at once, stack the
rows: $Q = XW_Q$, $K = XW_K$, $V = XW_V$, each of shape $(n, d_k)$.

### Step 2: the attention formula

$$
\text{Attention}(Q, K, V) = \text{softmax}\!\left(\frac{QK^\top}{\sqrt{d_k}} + M\right)V
$$

**Read it as, piece by piece:**

| Piece | Shape | Meaning |
|---|---|---|
| $QK^\top$ | $(n, n)$ | score table: row $i$, column $j$ = how relevant token $j$ is to token $i$ (a dot product) |
| $/\sqrt{d_k}$ | | keep scores at a sane scale (explained below) |
| $+M$ | $(n, n)$ | the mask: $-\infty$ where token $i$ is not allowed to look (the future) |
| softmax (per row) | $(n, n)$ | turn each row of scores into weights that sum to 1 |
| $\times V$ | $(n, d_k)$ | each token's output = weighted average of all value vectors |

### Worked example with real numbers

Three tokens, $d_k = 2$. Suppose the projections produced:

```
        Q            K            V
 t1  [1, 0]       [1, 0]       [10,  0]
 t2  [0, 1]       [0, 1]       [ 0, 10]
 t3  [1, 1]       [1, 1]       [ 5,  5]
```

**Scores** $QK^\top$ (row = who is asking, column = who is being looked at):

```
         t1   t2   t3
 t1  [   1,   0,   1 ]     t1's query [1,0] matches keys t1 and t3
 t2  [   0,   1,   1 ]
 t3  [   1,   1,   2 ]     t3 matches itself most
```

**Scale** by $1/\sqrt{2} = 0.707$, then **softmax** each row. For row t1: scores
$(0.707, 0, 0.707)$ → $e^{(\cdot)} = (2.03, 1.00, 2.03)$ → divide by the sum 5.06 →
weights **$(0.40, 0.20, 0.40)$**.

**Output for t1** $= 0.40\cdot[10,0] + 0.20\cdot[0,10] + 0.40\cdot[5,5] = [6.0, 4.0]$.

Token t1's new vector is now a blend of information from the tokens most relevant to it.

**With a causal mask** (GPT-style: no peeking at the future), t1 can only see itself: weights $(1, 0, 0)$,
output $[10, 0]$. Token t2 sees t1 and t2: scores $(0, 0.707)$ → weights $(0.33, 0.67)$ → output
$[3.3, 6.7]$.

### Why divide by $\sqrt{d_k}$?

If $\mathbf{q}$ and $\mathbf{k}$ have $d_k$ components each with variance 1, their dot product has
variance $d_k$. With $d_k = 128$, scores land around ±11; softmax of such big numbers is almost
one-hot (all weight on one token) and its gradient is ~0, so learning stalls. Dividing by
$\sqrt{d_k}$ brings the variance back to 1.

**Plain words:** it's turning the volume down so softmax doesn't "shout" one winner from the start.

### The causal mask

```
 Token can see →   t1  t2  t3  t4
 t1               [ ✔   ✗   ✗   ✗ ]      M = 0 where ✔,  −∞ where ✗
 t2               [ ✔   ✔   ✗   ✗ ]      e^(−∞) = 0, so masked tokens
 t3               [ ✔   ✔   ✔   ✗ ]      get exactly zero weight
 t4               [ ✔   ✔   ✔   ✔ ]
```

**Why:** during training we predict *every* next token in a sequence in parallel. Without the mask,
token 3 could just look at token 4 and copy the answer. The mask makes one forward pass equal to $n$
separate "predict the next token from the past" problems — a huge training efficiency win.

### NumPy implementation

```python
import numpy as np

def softmax(x, axis=-1):
    x = x - x.max(axis=axis, keepdims=True)        # numerical stability
    e = np.exp(x)
    return e / e.sum(axis=axis, keepdims=True)

def causal_self_attention(X, Wq, Wk, Wv):
    Q, K, V = X @ Wq, X @ Wk, X @ Wv               # (n, d_k) each
    scores = Q @ K.T / np.sqrt(K.shape[-1])         # (n, n)
    n = X.shape[0]
    mask = np.triu(np.ones((n, n)), k=1) * -1e9     # -inf above the diagonal
    weights = softmax(scores + mask)                # each row sums to 1
    return weights @ V, weights                     # (n, d_k), (n, n)
```

## 5. Multi-head attention

One attention computation can only focus on one kind of relationship at a time. **Multi-head**
attention runs $h$ smaller attentions in parallel, each with its own $W_Q, W_K, W_V$, then
concatenates and mixes them:

$$
\text{MultiHead}(X) = \text{Concat}(\text{head}_1, \dots, \text{head}_h)\,W_O, \quad
\text{head}_i = \text{Attention}(XW_Q^{(i)}, XW_K^{(i)}, XW_V^{(i)})
$$

```
                       ┌─ head 1: "which noun does this pronoun refer to?" ─┐
 X (n × 768) ──split──►├─ head 2: "what's the previous word?"               ├─► concat ─► W_O ─► (n × 768)
                       ├─ head 3: "matching bracket / quote"                │
                       └─ ... 12 heads × 64 dims each                       ┘
```

**Plain words:** like a team reading the same document, each person highlighting something different
(grammar, names, dates), then pooling their notes. With $d = 768$ and $h = 12$, each head works in
$d_k = 64$ dimensions — same total compute as one big head.

### MQA and GQA — sharing keys/values to save memory

At inference, every past token's K and V are cached (the **KV cache**, module 08). That cache is the
main memory cost of long contexts. So modern models share K/V across heads:

| Variant | Query heads | K/V heads | KV-cache size | Used by |
|---|---|---|---|---|
| Multi-head (MHA) | 32 | 32 | 1× | GPT-2/3, LLaMA-1 |
| **Grouped-query (GQA)** | 32 | 8 | ¼ | LLaMA-2 70B, LLaMA-3, Mistral |
| Multi-query (MQA) | 32 | 1 | 1/32 | PaLM, Falcon |

## 6. Position information

Attention by itself is **order-blind**: "dog bites man" and "man bites dog" give each token the same
set of things to look at. We must inject position.

| Method | How | Notes |
|---|---|---|
| Sinusoidal (original 2017) | add fixed sine/cosine waves of different frequencies to embeddings | no parameters; weak extrapolation |
| Learned absolute (GPT-2) | a second embedding table indexed by position 0..1023 | can't go beyond trained length |
| **RoPE** (LLaMA, Mistral, most LLMs) | **rotate** each query/key vector by an angle proportional to its position | the dot product depends only on the *relative* distance; can be stretched for longer contexts |
| ALiBi | subtract a penalty proportional to distance from attention scores | good length extrapolation |

### RoPE in plain words

Split each query/key into pairs of numbers and treat each pair as a 2D arrow. At position $m$, rotate
the arrow by angle $m\theta$. When comparing a query at position $m$ with a key at position $n$, the
dot product only depends on the **angle difference** $(m-n)\theta$ — i.e., how far apart they are,
not where they are. Different pairs rotate at different speeds ($\theta_i = 10000^{-2i/d}$), like the
second, minute, and hour hands of a clock, so the model can sense both near and far distances.

```
 position 0:  →        position 1:  ↗        position 2:  ↑        (one pair, rotating)
 q·k depends on the angle between them = relative distance
```

"Context extension" tricks (e.g. extending a 4k-trained model to 128k) mostly rescale these rotation
frequencies.

## 7. The feed-forward network (MLP)

After attention mixes information between tokens, each token passes **independently** through a
2-layer MLP, usually 4× wider than $d$:

$$
\text{FFN}(\mathbf{x}) = W_2\,\phi(W_1\mathbf{x}) \qquad \text{or (SwiGLU)} \qquad W_2\big(\text{SiLU}(W_1\mathbf{x}) \odot W_3\mathbf{x}\big)
$$

**Plain words:** attention is the *meeting* where tokens share information; the MLP is each token
going back to its desk to *think* about what it heard. Research suggests much of the model's factual
knowledge ("Paris is the capital of France") is stored in these MLP weights — and they hold about
**two thirds of all parameters**.

## 8. The full transformer block

```
            x  (n × d)
            │
     ┌──────┤
     │      ▼
     │   RMSNorm
     │      ▼
     │   Multi-head causal self-attention      ← tokens talk to each other
     │      ▼
     └────►(+)                                 ← residual: x = x + attn(norm(x))
            │
     ┌──────┤
     │      ▼
     │   RMSNorm
     │      ▼
     │   MLP (SwiGLU, ~4× wider)               ← each token thinks alone
     │      ▼
     └────►(+)                                 ← residual: x = x + mlp(norm(x))
            │
            ▼  same shape (n × d) — so blocks can be stacked N times
```

**The "residual stream" mental model:** think of the vector for each token as a shared whiteboard
running up through the network. Each attention and MLP layer *reads* the whiteboard and *writes* a
small addition to it. Nothing is overwritten; by the top, the whiteboard holds everything needed to
predict the next token.

## 9. Three transformer families

```mermaid
flowchart LR
  subgraph ENC["Encoder-only (BERT)"]
    E1[sees whole input<br/>both directions] --> E2[good for understanding:<br/>classification, embeddings, NER]
  end
  subgraph ED["Encoder-decoder (T5, original Transformer)"]
    D1[encoder reads input] --> D2[decoder generates output,<br/>cross-attends to encoder]
  end
  subgraph DEC["Decoder-only (GPT, LLaMA, Claude)"]
    G1[causal mask:<br/>sees only the past] --> G2[generates text token by token;<br/>does any task via prompting]
  end
```

| Family | Attention | Training objective | Typical use today |
|---|---|---|---|
| Encoder-only | bidirectional | fill in masked words | embedding models for search/RAG, classifiers |
| Encoder–decoder | encoder bidirectional + decoder causal with **cross-attention** | text-to-text | translation, some summarization |
| **Decoder-only** | causal | predict next token | **all major chat LLMs** — simplest to scale, one model for every task |

**Cross-attention** = queries come from the decoder, keys/values from the encoder output. It's how a
translation decoder "looks at" the source sentence (the 2014 attention from module 06, generalized).

## 10. Counting parameters (and checking against real models)

Per block, with hidden size $d$:

| Part | Matrices | Parameters |
|---|---|---|
| Attention | $W_Q, W_K, W_V, W_O$, each $d \times d$ | $4d^2$ |
| MLP (4× expansion) | $d \times 4d$ and $4d \times d$ | $8d^2$ |
| Norms, biases | small | ≈ 0 |
| **Block total** | | $\approx 12d^2$ |

Whole model: $\approx 12\,L\,d^2 + V d$ (embeddings), with $L$ layers and vocabulary $V$.

**GPT-2 small:** $d = 768$, $L = 12$, $V = 50{,}257$.
Blocks: $12 \times 12 \times 768^2 = 84.9$M. Embeddings: $50{,}257 \times 768 = 38.6$M, positions 0.8M.
Total ≈ **124M** ✔ (the official number).

**LLaMA-2 7B:** $d = 4096$, $L = 32$, SwiGLU hidden 11,008 (3 matrices), $V = 32{,}000$, untied input/output embeddings.
Attention $4 \times 4096^2 = 67$M, MLP $3 \times 4096 \times 11{,}008 = 135$M → 202M per layer × 32 = 6.48B.
Embeddings $2 \times 32{,}000 \times 4096 = 0.26$B. Total ≈ **6.7B** ✔.

## 11. Compute cost and why context is expensive

| Part | FLOPs per token per layer | Grows with |
|---|---|---|
| Projections + MLP | $\approx 24 d^2$ | model size |
| Attention scores ($QK^\top$ and $\times V$) | $\approx 4 n d$ | **context length** $n$ |

The full $n \times n$ score matrix means attention memory and compute grow **quadratically** with
sequence length. Doubling context from 64k to 128k makes the attention part 4× more expensive.

**FlashAttention** computes exactly the same result but in tiles that stay in fast on-chip GPU memory,
never materializing the full $n \times n$ matrix in slow memory — 2–4× faster, linear memory. It's an
engineering (I/O) optimization, not a math approximation. Every serious stack uses it.

## 12. A minimal GPT in PyTorch (~70 lines)

```python
import torch, torch.nn as nn, torch.nn.functional as F

class CausalSelfAttention(nn.Module):
    def __init__(self, d, n_heads):
        super().__init__()
        self.n_heads, self.d_head = n_heads, d // n_heads
        self.qkv = nn.Linear(d, 3 * d, bias=False)    # W_Q, W_K, W_V fused
        self.proj = nn.Linear(d, d, bias=False)       # W_O

    def forward(self, x):                              # x: (B, T, d)
        B, T, d = x.shape
        q, k, v = self.qkv(x).split(d, dim=-1)
        # (B, T, d) -> (B, heads, T, d_head)
        q, k, v = (t.view(B, T, self.n_heads, self.d_head).transpose(1, 2) for t in (q, k, v))
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True)  # FlashAttention when available
        y = y.transpose(1, 2).contiguous().view(B, T, d)
        return self.proj(y)

class MLP(nn.Module):
    def __init__(self, d):
        super().__init__()
        self.up, self.down = nn.Linear(d, 4 * d), nn.Linear(4 * d, d)
    def forward(self, x):
        return self.down(F.gelu(self.up(x)))

class Block(nn.Module):
    def __init__(self, d, n_heads):
        super().__init__()
        self.ln1, self.attn = nn.LayerNorm(d), CausalSelfAttention(d, n_heads)
        self.ln2, self.mlp = nn.LayerNorm(d), MLP(d)
    def forward(self, x):
        x = x + self.attn(self.ln1(x))     # tokens talk
        x = x + self.mlp(self.ln2(x))      # tokens think
        return x

class MiniGPT(nn.Module):
    def __init__(self, vocab, d=384, n_heads=6, n_layers=6, max_len=256):
        super().__init__()
        self.tok = nn.Embedding(vocab, d)
        self.pos = nn.Embedding(max_len, d)
        self.blocks = nn.Sequential(*[Block(d, n_heads) for _ in range(n_layers)])
        self.ln_f = nn.LayerNorm(d)
        self.head = nn.Linear(d, vocab, bias=False)
        self.head.weight = self.tok.weight             # weight tying: saves V*d params

    def forward(self, idx, targets=None):              # idx: (B, T) token IDs
        T = idx.shape[1]
        x = self.tok(idx) + self.pos(torch.arange(T, device=idx.device))
        logits = self.head(self.ln_f(self.blocks(x)))  # (B, T, vocab)
        if targets is None:
            return logits, None
        # every position predicts the NEXT token: targets = idx shifted left by 1
        loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1))
        return logits, loss

    @torch.no_grad()
    def generate(self, idx, max_new_tokens, temperature=1.0):
        for _ in range(max_new_tokens):
            logits, _ = self(idx[:, -self.pos.num_embeddings:])
            probs = F.softmax(logits[:, -1, :] / temperature, dim=-1)
            idx = torch.cat([idx, torch.multinomial(probs, 1)], dim=1)
        return idx
```

Train this on a few MB of Shakespeare with the loop from module 05 (`x = text[i:i+T]`,
`y = text[i+1:i+T+1]`) and in ~15 minutes on one GPU it writes convincing fake Shakespeare. That
is, structurally, GPT. The difference to GPT-4-class models is scale, data, and post-training
(module 08).

## 13. Key takeaways

- Tokens → embeddings → N × (attention + MLP with residuals and norms) → next-token probabilities.
- Attention = soft lookup: query·key scores, scaled, masked, softmaxed, used to average values.
- Multi-head = several lookups in parallel; GQA shares K/V to shrink the KV cache.
- Position comes from RoPE (relative rotations) in most modern LLMs.
- Parameters ≈ $12Ld^2$; attention cost grows with $n^2$, which is why long context is expensive.

## Interview questions

1. *Why scale by $\sqrt{d_k}$?* — dot-product variance grows with $d_k$; unscaled scores saturate
   softmax and kill gradients.
2. *Why a causal mask?* — so each position only uses the past, enabling parallel training on all
   next-token predictions and matching how generation works at inference.
3. *Encoder vs decoder?* — bidirectional vs causal attention; encoders for understanding/embeddings,
   decoders for generation.
4. *What does the MLP do if attention already mixes tokens?* — attention moves information between
   positions; the MLP applies per-token nonlinear transformations and stores much of the knowledge.
5. *Where do most parameters live in a 7B model?* — about two thirds in the MLPs, one third in attention,
   a few percent in embeddings.
