# 10 — MLOps: Turning Models Into Reliable Systems

> **Why it matters:** Google's well-known paper *"Hidden Technical Debt in ML Systems"* showed that the
> model code is a tiny box in the middle of a huge system: data collection, feature pipelines,
> validation, serving, monitoring. Most ML projects that die, die here — not in the notebook.

## In plain words

Regular software is a **recipe**: same code, same output, forever. An ML system is a recipe **plus
ingredients that keep changing** (data). Even if nobody touches the code, the dish can go bad because
the ingredients changed (customer behavior shifted, a sensor was recalibrated, a new product launched).

So MLOps = DevOps + three extra things:

| DevOps has | MLOps adds | Why |
|---|---|---|
| version control for code | **versioning for data and models** | you must be able to reproduce *exactly* which data made which model |
| CI/CD (build, test, deploy) | **CT — continuous training** + eval gates | models must be retrained as the world changes, and tested on *quality*, not just "does it run" |
| monitoring uptime, latency, errors | **monitoring data and prediction quality** | a model can return HTTP 200 with confidently wrong answers |

Example: a food-delivery ETA model trained before a city introduced new traffic rules starts
under-estimating delivery times by 8 minutes. No exception, no alert on the server dashboard — only
drift monitoring catches it.

## 1. Architecture at a glance: an end-to-end MLOps platform

```mermaid
flowchart LR
  subgraph DATA["Data layer"]
    SRC[(Sources: DBs, events,<br/>logs, labels)] --> ING[Ingestion + validation<br/>schema, ranges, nulls]
    ING --> LAKE[(Versioned data lake<br/>DVC / Delta / lakeFS)]
    LAKE --> FS[(Feature store<br/>offline + online)]
  end
  subgraph TRAIN["Training pipeline (orchestrated: Airflow / Kubeflow / Step Functions)"]
    FS --> PREP[Build training set<br/>point-in-time correct]
    PREP --> TR[Train + tune]
    TR --> EV[Evaluate: metrics,<br/>slices, fairness, vs prod]
    TR -.log.-> EXP[(Experiment tracking<br/>MLflow / W&B)]
  end
  subgraph REG["Release"]
    EV -->|passes gate| MR[(Model registry<br/>versions + stages)]
    MR --> CD[CD: package, deploy<br/>shadow → canary → full]
  end
  subgraph PROD["Production"]
    CD --> SERVE[Serving<br/>batch / online]
    FS -->|online features| SERVE
    SERVE --> LOG[(Prediction logs)]
    LOG --> MON[Monitoring: latency, errors,<br/>data drift, prediction drift,<br/>quality when labels arrive]
  end
  MON -->|drift / decay / schedule| TR
  LOG -->|join with labels| LAKE
```

**How to read it:** data flows left to right into a model; predictions flow back into logs; logs plus
eventual labels flow back into the data lake. Monitoring closes the loop by triggering retraining.
Each box is a place where things break if it's missing.

## 2. MLOps maturity levels

| Level | What it looks like | Pain |
|---|---|---|
| **0 — Manual** | notebook → pickle file → someone copies it to a server | no reproducibility, model rots silently, "it worked on my laptop" |
| **1 — Pipeline automation** | training is a scripted, orchestrated pipeline; models are versioned in a registry; retraining on schedule or trigger | code changes to the pipeline are still manual |
| **2 — CI/CD for pipelines** | pipeline code is tested and deployed via CI/CD; automatic eval gates; canary rollouts; full lineage | — this is the target for important models |

Start at level 1 for anything in production. Level 2 for models that matter to revenue or risk.

## 3. Reproducibility: version everything

A model is a function of **code + data + config + environment + randomness**. To reproduce model v17,
you need all five pinned:

| Ingredient | Tool / practice |
|---|---|
| Code | git commit SHA |
| Data | DVC, lakeFS, Delta Lake time travel, or immutable dated snapshots with content hashes |
| Config / hyperparameters | config file in git (Hydra, YAML), logged to the tracker |
| Environment | lockfile + container image digest |
| Randomness | fixed seeds (and note: GPU kernels can still be non-deterministic) |

### Data versioning with DVC

```bash
dvc init
dvc add data/train.parquet                # creates data/train.parquet.dvc (a small hash pointer)
git add data/train.parquet.dvc .gitignore && git commit -m "data v3: Oct labels"
dvc push                                  # actual bytes go to S3/GCS, not git
# later: git checkout <old-commit> && dvc pull   → exact old dataset back
```

**Plain words:** git stores a *receipt* (the hash), the object store keeps the *goods* (the data).

## 4. Experiment tracking

Without tracking, after two weeks you'll have 40 runs and no idea which settings produced the good one.

```python
import mlflow, mlflow.sklearn
from sklearn.metrics import average_precision_score

mlflow.set_experiment("churn")
with mlflow.start_run(run_name="lgbm-lr0.05"):
    mlflow.log_params({"learning_rate": 0.05, "max_depth": 6, "data_version": "v3"})
    mlflow.set_tag("git_sha", git_sha)
    model.fit(X_train, y_train)
    ap = average_precision_score(y_val, model.predict_proba(X_val)[:, 1])
    mlflow.log_metric("val_pr_auc", ap)
    mlflow.log_artifact("reports/slice_metrics.html")
    mlflow.sklearn.log_model(model, "model", registered_model_name="churn")  # → registry
```

What to log: params, metrics (overall + per slice), data version, git SHA, environment, plots,
the model artifact, and the eval report.

## 5. Feature stores and training–serving skew

### The skew problem

```
 TRAINING (Python, batch, last year)          SERVING (Java service, real time)
 avg_spend_30d = SQL window over               avg_spend_30d = re-implemented by another team,
   transactions table, includes refunds          excludes refunds, uses UTC vs local time
                      │                                          │
                      └────────── different numbers ─────────────┘
                     model sees inputs it was never trained on → silent accuracy drop
```

**Training–serving skew** = features computed differently in training and production. It's one of the
most common causes of "great offline, bad online".

### Feature store: one definition, two outputs

```mermaid
flowchart LR
  DEF[Feature definition<br/>written once] --> OFF[(Offline store<br/>warehouse / parquet<br/>full history)]
  DEF --> ON[(Online store<br/>Redis / DynamoDB<br/>latest value, ms latency)]
  OFF -->|point-in-time join| TRAINSET[Training sets]
  ON -->|lookup by entity id| API[Real-time serving]
```

**Point-in-time correctness:** when building a training row for an event on March 3rd, join feature
values *as they were on March 3rd* — never later values (that's temporal leakage, module 03).

Tools: Feast (open source), Tecton, Databricks/SageMaker/Vertex feature stores. For small teams,
shared feature code in one library used by both training and serving is often enough.

## 6. The model registry

A registry is a catalog of model versions with metadata and lifecycle stages:

```
 churn  v15  ─ archived
        v16  ─ production   (PR-AUC 0.61, data v2, sha a1b2c3)
        v17  ─ staging      (PR-AUC 0.64, data v3, sha d4e5f6)  ← candidate, under canary
        v18  ─ none         (failed eval gate: recall on "enterprise" slice dropped 9%)
```

It answers: *what's running in production, who approved it, what data trained it, and what do we
roll back to?* Serving loads models by alias (`churn@production`), never by file path.

## 7. CI/CD/CT for ML

```mermaid
flowchart LR
  PR[Pull request:<br/>code or config] --> CI[CI: lint, unit tests,<br/>data schema tests,<br/>train on small sample]
  CI --> MERGE[Merge]
  MERGE --> CT[CT pipeline: full training<br/>on latest data]
  TRIG[Triggers: schedule,<br/>drift alert, new labels] --> CT
  CT --> GATE{Eval gate:<br/>beats prod overall<br/>AND on key slices?<br/>latency OK? fairness OK?}
  GATE -->|no| STOP[Block + report]
  GATE -->|yes| REGI[Register as candidate]
  REGI --> SHADOW[Shadow deploy]
  SHADOW --> CANARY[Canary 5% → 25% → 100%<br/>auto-rollback on bad metrics]
```

### What to test in ML (beyond normal unit tests)

| Test | Example |
|---|---|
| Data schema / quality | columns exist, types correct, `age` in [0, 120], null rate < 2%, no duplicate IDs (Great Expectations, Pandera) |
| Feature logic | unit test `avg_spend_30d` on a hand-made fixture |
| Training smoke test | trains on 1% of data in CI, loss decreases |
| Model quality gate | new model ≥ production on golden set; no slice regresses > X% |
| Invariance tests | changing a name in the input doesn't change the sentiment prediction |
| Directional tests | increasing "days since last login" shouldn't *decrease* churn probability |
| Performance | p95 latency and memory within budget on target hardware |
| Reproducibility | retrain with same seed/data → metrics within tolerance |

### Example eval gate (GitHub Actions step)

```yaml
- name: Evaluate candidate vs production
  run: |
    python eval.py --candidate runs:/$RUN_ID/model --baseline models:/churn@production \
                   --data data/golden.parquet --out report.json
    python - <<'EOF'
    import json, sys
    r = json.load(open("report.json"))
    ok = (r["candidate"]["pr_auc"] >= r["baseline"]["pr_auc"] - 0.005
          and all(s["delta_recall"] > -0.03 for s in r["slices"])
          and r["candidate"]["p95_ms"] < 50)
    sys.exit(0 if ok else 1)
    EOF
```

## 8. Monitoring: what can go wrong after deployment

| Kind of change | Plain words | Example | Detect with |
|---|---|---|---|
| **Data drift** (covariate shift) | inputs look different | new marketing channel brings younger users | compare feature distributions (PSI, KS test) |
| **Concept drift** | same inputs, different correct answer | during a recession, the same income profile defaults more | quality metrics once labels arrive; proxy metrics |
| **Prediction drift** | output distribution changes | fraud model suddenly flags 3× more | monitor prediction mean/histogram |
| **Upstream breakage** | a pipeline bug | a field silently becomes all nulls, units change cm→m | data validation on every batch/request |
| **Feedback loops** | the model changes the data it later trains on | recommender only shows what it already likes | exploration traffic, holdout groups |

### Measuring drift: Population Stability Index (PSI)

Bin a feature using the training distribution (expected $e_i$) and compare to production (actual $a_i$):

$$
\text{PSI} = \sum_i (a_i - e_i)\,\ln\frac{a_i}{e_i}
$$

**Worked example** with 4 bins:

| Bin | Expected (train) | Actual (prod) | $(a-e)\ln(a/e)$ |
|---|---|---|---|
| 1 | 0.25 | 0.10 | 0.137 |
| 2 | 0.25 | 0.20 | 0.011 |
| 3 | 0.25 | 0.30 | 0.009 |
| 4 | 0.25 | 0.40 | 0.070 |
| | | **PSI** | **0.228** |

Rule of thumb: < 0.1 stable, 0.1–0.2 moderate shift, **> 0.2 significant** → investigate. PSI is a
symmetric version of KL divergence (see the math course, module 04).

**Kolmogorov–Smirnov (KS) test:** the maximum gap between the two cumulative distributions; gives a
p-value. Careful: with millions of rows, tiny meaningless shifts become "statistically significant" —
use effect-size thresholds, not just p-values.

```python
from evidently import Report
from evidently.presets import DataDriftPreset

report = Report([DataDriftPreset()])
result = report.run(reference_data=train_df, current_data=last_week_df)
result.save_html("drift_report.html")
```

### The monitoring dashboard (four layers)

| Layer | Metrics | Alert example |
|---|---|---|
| Service | QPS, p50/p95/p99 latency, error rate, saturation | p99 > 200 ms for 5 min |
| Data | null rates, ranges, PSI per feature, schema violations | PSI > 0.2 on top-10 features |
| Model | prediction distribution, confidence, % abstentions | positive rate doubles vs last week |
| Business / quality | precision/recall once labels arrive, conversion, revenue, complaints | weekly recall drops > 5% |

**Delayed labels problem:** fraud labels may arrive 60 days later (chargebacks). Monitor drift and
proxies now, true quality later.

### When to retrain

| Strategy | When it fits |
|---|---|
| Scheduled (daily/weekly/monthly) | steady drift, cheap training |
| Triggered (drift or quality alert) | expensive training, sudden changes |
| Online / continual learning | very fast-changing (ads, recommendations); harder to make safe |

Always retrain → evaluate → gate → canary. Never auto-deploy a retrained model without the gate.

## 9. LLMOps: what changes for LLM applications

```mermaid
flowchart LR
  subgraph VERSIONED["Versioned together as a 'release'"]
    PM[Prompt templates] --- MD[Model + version<br/>or adapter]
    MD --- RC[RAG config:<br/>embedding model, chunking,<br/>index version, top-k]
    RC --- TL[Tools + guardrails]
  end
  VERSIONED --> EVAL[Offline evals:<br/>golden set, LLM-judge,<br/>safety suite]
  EVAL --> DEPLOY[Canary deploy]
  DEPLOY --> TRACE[Tracing every call:<br/>prompt, retrieved docs,<br/>tool calls, tokens, cost]
  TRACE --> FB[User feedback +<br/>sampled human review]
  FB --> DS[Curate new eval cases<br/>+ fine-tuning data]
  DS --> EVAL
```

| Classic MLOps | LLMOps |
|---|---|
| you train the model | you mostly *select* a model; prompts, RAG, and tools are the "code" |
| version data + model | version **prompts, model ID, retrieval index, tools, guardrails** — any change can shift behavior |
| numeric metrics (AUC) | rubric-based evals, LLM-as-judge, human review, safety suites |
| cost = infrastructure | cost = **tokens** (per request; watch prompt growth) |
| drift in input features | drift in user intents/topics (cluster embeddings of queries), new jailbreak patterns |
| model provider stable | API models get updated/deprecated → pin versions, re-run evals on upgrades |
| logs | full **traces** (LangSmith, Langfuse, Phoenix, OpenTelemetry GenAI conventions) |

See `10_llmops_pipeline/` for a working monitor → curate → train → eval-gate → publish pipeline,
and `07_evaluation/` for eval tooling.

## 10. Key takeaways

- ML systems decay without code changes; MLOps adds data/model versioning, continuous training, and
  quality monitoring to DevOps.
- Reproducibility needs code + data + config + environment + seeds pinned.
- Feature stores (or shared feature code) prevent training–serving skew; joins must be point-in-time.
- Every deploy passes an eval gate on overall metrics **and** key slices, then shadow/canary.
- Monitor four layers: service, data, model, business. Use PSI/KS for drift; plan for delayed labels.
- LLMOps versions prompts, models, retrieval, and tools as one release and evaluates with rubrics and traces.

## Interview questions

1. *Accuracy dropped in production but no code changed. How do you investigate?* — check upstream data
   (schema, nulls, units), feature drift (PSI on top features), prediction drift, training–serving skew,
   label pipeline changes, and seasonality/business events; then slice the errors.
2. *Data drift vs concept drift?* — data drift: $P(x)$ changes; concept drift: $P(y \mid x)$ changes.
   Only concept drift necessarily hurts the model, but you usually detect data drift first.
3. *How do you safely roll out a new model?* — offline eval gate → shadow (compare outputs, no user
   impact) → canary with automatic rollback → A/B test on business metrics → full rollout; keep the
   previous version warm.
4. *What would you version in an LLM app?* — prompt templates, model name/version, decoding params,
   embedding model, chunking + index version, tools/schemas, guardrail configs, and the eval set.
