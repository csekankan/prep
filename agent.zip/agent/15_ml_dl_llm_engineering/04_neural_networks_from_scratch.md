# 04 — Neural Networks From Scratch

> **Why it matters:** every deep learning model — CNNs, transformers, GPT — is built from the same
> parts: linear layers, nonlinearities, a loss, and backpropagation. Here you compute them by hand
> with real numbers, then write them in ~60 lines of Python, including a tiny autograd engine.
>
> Deeper math: [math of deep learning](../14_math_for_ml_dl_llm/06_math_of_deep_learning.md),
> [chain rule](../14_math_for_ml_dl_llm/02_calculus_gradients.md).

## In plain words

Picture a **factory assembly line** sorting fruit photos into "apple" or "orange":

- **Station 1** workers each look for one simple thing: a red patch, a round edge, a bumpy texture.
- **Station 2** workers combine station 1's notes: "round edge + red patch = maybe apple skin".
- **Final station** combines everything into a decision: "apple, 92% sure".

Each worker is a **neuron**; each station is a **layer**. Nobody tells the workers what to look for.
At first they guess randomly. When the final answer is wrong, a manager walks **backwards** down the
line telling each worker how much they contributed to the mistake and which way to adjust — that walk
backwards is **backpropagation**. After thousands of photos, the workers have taught themselves
useful specialties.

| Neural network term | Factory analogy |
|---|---|
| Weight | how much a worker trusts each note they receive |
| Bias | a worker's default leaning before reading any notes |
| Activation (ReLU) | a worker only speaks up if their evidence is strong enough |
| Loss | how wrong the final decision was |
| Gradient | each worker's share of the blame, and in which direction |
| Learning rate | how big an adjustment each worker makes after feedback |

## Architecture at a glance

```mermaid
flowchart LR
  X[Input x<br/>pixels / features] --> L1[Layer 1<br/>W1·x + b1 → ReLU]
  L1 --> L2[Layer 2<br/>W2·h1 + b2 → ReLU]
  L2 --> OUT[Output layer<br/>W3·h2 + b3 → softmax]
  OUT --> P[Probabilities]
  P --> LOSS[Loss vs true label]
  LOSS -. "backward: gradients flow right → left" .-> OUT
  OUT -.-> L2
  L2 -.-> L1
```

**How to read it:** solid arrows are the forward pass (making a prediction); dotted arrows are the
backward pass (computing how each weight should change). Every training step does one of each, then
updates all weights.

## 1. Why we need neural networks

Logistic regression draws a **straight line** (a hyperplane) between classes. Many problems aren't
linearly separable. The classic example is XOR:

```
  x2                     XOR:  (0,0)→0  (1,1)→0
  1 │  ●(1)     ○(0)           (0,1)→1  (1,0)→1
    │
  0 │  ○(0)     ●(1)     No single straight line separates ● from ○.
    └──────────────── x1
       0         1
```

Classic ML fixes this with hand-made features (add $x_1 \cdot x_2$). A neural network **learns
the features itself**: the hidden layer transforms the input into a new space where a straight line
*does* work.

## 2. The neuron

$$
a = \phi\big(\mathbf{w}^\top\mathbf{x} + b\big)
$$

**Read it as:** a neuron is logistic regression with a pluggable squashing function $\phi$ (the
**activation**). Weighted sum of inputs, plus bias, through a nonlinearity.

A **layer** is many neurons reading the same input. Stacking their weight vectors as rows of a
matrix $W$ (shape: `out × in`) gives:

$$
\mathbf{h} = \phi(W\mathbf{x} + \mathbf{b})
$$

A layer with 512 inputs and 256 outputs has $512 \times 256 + 256 = 131{,}328$ parameters.

## 3. The multi-layer perceptron (MLP)

```
 input x (d)      hidden h1 (256)      hidden h2 (256)      output (K classes)
   ●  ─────W1────►  ●  ───────W2─────►   ●  ──────W3──────►  ●  → softmax → probabilities
   ●                ●                    ●                   ●
   ●                ●                    ●                   ●
          linear + ReLU         linear + ReLU         linear (logits)
```

$$
\mathbf{h}_1 = \text{ReLU}(W_1\mathbf{x} + \mathbf{b}_1),\quad
\mathbf{h}_2 = \text{ReLU}(W_2\mathbf{h}_1 + \mathbf{b}_2),\quad
\mathbf{z} = W_3\mathbf{h}_2 + \mathbf{b}_3,\quad
\hat{\mathbf{p}} = \text{softmax}(\mathbf{z})
$$

### Why the nonlinearity is essential

Without $\phi$, two layers are $W_2(W_1\mathbf{x}) = (W_2W_1)\mathbf{x}$ — just one matrix. A
100-layer linear network is still a linear model. The nonlinearity is what lets layers build on each
other.

### Activation functions

| Name | Formula | Derivative | Notes |
|---|---|---|---|
| Sigmoid | $\frac{1}{1+e^{-x}}$ | $\sigma(1-\sigma)$, max 0.25 | saturates → vanishing gradients in deep nets; used for gates and binary outputs |
| Tanh | $\tanh x$ | $1-\tanh^2 x$ | zero-centered, still saturates; used in LSTMs |
| **ReLU** | $\max(0,x)$ | 1 if $x>0$ else 0 | cheap, no saturation for $x>0$; default for CNNs/MLPs. Risk: "dead" neurons stuck at 0 |
| Leaky ReLU | $\max(0.01x, x)$ | 1 or 0.01 | fixes dead neurons |
| **GELU** | $x\,\Phi(x)$ | smooth | BERT, GPT-2/3 |
| **SiLU/Swish** | $x\,\sigma(x)$ | smooth | LLaMA/Mistral (inside SwiGLU) |

### Universal approximation (and why depth still matters)

The **universal approximation theorem**: an MLP with one hidden layer and enough neurons can
approximate any continuous function on a bounded domain as closely as you like.

**Read it as:** each ReLU neuron adds a "kink"; enough kinks can trace any curve. But "enough" can be
astronomically many. **Depth** is more efficient: each layer reuses features from the layer below
(edges → shapes → objects), so a deep network can represent the same function with exponentially
fewer neurons than a shallow one. That's why "deep" learning.

## 4. The forward pass and backpropagation — by hand

### The setup

A tiny network: 2 inputs → 2 hidden ReLU neurons → 1 sigmoid output, binary cross-entropy loss.

```
 x = [1, 2], true label y = 1

 W1 = [[0.1,  0.2],      b1 = [0, 0]        W2 = [0.6, 0.9]     b2 = 0
       [0.3, -0.4]]
```

### Forward pass

| Step | Formula | Value |
|---|---|---|
| hidden pre-activation | $\mathbf{z}_1 = W_1\mathbf{x} + \mathbf{b}_1$ | $[0.1·1 + 0.2·2,\; 0.3·1 − 0.4·2] = [0.5, −0.5]$ |
| hidden activation | $\mathbf{h} = \text{ReLU}(\mathbf{z}_1)$ | $[0.5, 0]$ |
| output logit | $z_2 = W_2\mathbf{h} + b_2$ | $0.6·0.5 + 0.9·0 = 0.3$ |
| probability | $p = \sigma(z_2)$ | $1/(1+e^{-0.3}) = 0.5744$ |
| loss | $L = -\log p$ (since $y=1$) | $0.5544$ |

### Backward pass (chain rule, from the loss backwards)

The **chain rule** says: if $L$ depends on $z_2$, which depends on $W_2$, then
$\frac{\partial L}{\partial W_2} = \frac{\partial L}{\partial z_2}\cdot\frac{\partial z_2}{\partial W_2}$.
Backprop is just applying this rule from the output back to every weight, **reusing** the
intermediate results so nothing is computed twice.

| Step | Formula | Value |
|---|---|---|
| output error | $\delta_2 = \frac{\partial L}{\partial z_2} = p - y$ | $0.5744 − 1 = −0.4256$ |
| grad of $W_2$ | $\delta_2 \cdot \mathbf{h}$ | $[−0.2128,\; 0]$ |
| grad of $b_2$ | $\delta_2$ | $−0.4256$ |
| error sent back to $\mathbf{h}$ | $\delta_2 \cdot W_2$ | $[−0.2554,\; −0.3830]$ |
| through ReLU | $\boldsymbol{\delta}_1 = (\delta_2 W_2) \odot \text{ReLU}'(\mathbf{z}_1)$ | $[−0.2554,\; 0]$ ← neuron 2 had $z<0$, so no gradient |
| grad of $W_1$ | $\boldsymbol{\delta}_1 \mathbf{x}^\top$ (outer product) | $[[−0.2554, −0.5107], [0, 0]]$ |
| grad of $\mathbf{b}_1$ | $\boldsymbol{\delta}_1$ | $[−0.2554, 0]$ |

($\odot$ means element-wise multiply.)

### Update (learning rate $\eta = 0.5$)

$W \leftarrow W - \eta \cdot \text{grad}$:

- $W_2 = [0.6 + 0.1064,\; 0.9] = [0.7064, 0.9]$, $b_2 = 0.2128$
- $W_1$ row 1 $= [0.1 + 0.1277,\; 0.2 + 0.2554] = [0.2277, 0.4554]$, $b_1 = [0.1277, 0]$

### Forward again

$z_{1,1} = 0.2277 + 0.9107 + 0.1277 = 1.2661$, $z_2 = 0.7064·1.2661 + 0.2128 = 1.1072$,
$p = \sigma(1.1072) = 0.7516$, $L = 0.2856$.

**Loss dropped from 0.554 to 0.286 in one step.** That's training. Real training repeats this
millions of times over mini-batches.

### Things to notice

1. **"Error × input" again.** Every weight gradient is (error arriving at the neuron) × (input to the
   neuron) — same as logistic regression.
2. **Gradients flow backward through the same weights** ($\delta_2 \cdot W_2$). In matrix form:
   $\boldsymbol{\delta}_{\ell} = (W_{\ell+1}^\top \boldsymbol{\delta}_{\ell+1}) \odot \phi'(\mathbf{z}_\ell)$.
3. **ReLU blocks gradient where $z < 0$.** If a neuron is always negative, it never learns ("dead ReLU").
4. **Backward costs ~2× forward.** One matmul for the weight gradient, one for passing error back.
   So training ≈ 3× the compute of inference — the source of the "6 × params × tokens" rule in module 08.

## 5. Computational graphs and autograd

Frameworks (PyTorch, JAX) don't hard-code these formulas. They record every operation in a graph
during the forward pass, then walk it backwards, each node applying its local derivative. You can
build this in ~40 lines — it's the best way to demystify `loss.backward()`:

```python
import math

class Value:
    """A scalar that remembers how it was computed, so it can backpropagate."""
    def __init__(self, data, parents=(), op=""):
        self.data, self.grad = data, 0.0
        self._parents, self._op = parents, op
        self._backward = lambda: None

    def __add__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        out = Value(self.data + other.data, (self, other), "+")
        def _backward():                     # d(a+b)/da = 1, d(a+b)/db = 1
            self.grad += out.grad
            other.grad += out.grad
        out._backward = _backward
        return out

    def __mul__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        out = Value(self.data * other.data, (self, other), "*")
        def _backward():                     # d(ab)/da = b, d(ab)/db = a
            self.grad += other.data * out.grad
            other.grad += self.data * out.grad
        out._backward = _backward
        return out

    def relu(self):
        out = Value(max(0.0, self.data), (self,), "relu")
        def _backward():
            self.grad += (out.data > 0) * out.grad
        out._backward = _backward
        return out

    def sigmoid(self):
        s = 1 / (1 + math.exp(-self.data))
        out = Value(s, (self,), "sigmoid")
        def _backward():
            self.grad += s * (1 - s) * out.grad
        out._backward = _backward
        return out

    def log(self):
        out = Value(math.log(self.data), (self,), "log")
        def _backward():
            self.grad += (1 / self.data) * out.grad
        out._backward = _backward
        return out

    def backward(self):
        order, seen = [], set()
        def topo(v):                         # visit parents before children
            if v not in seen:
                seen.add(v)
                for p in v._parents:
                    topo(p)
                order.append(v)
        topo(self)
        self.grad = 1.0                      # dL/dL = 1
        for v in reversed(order):
            v._backward()

# Reproduce the hand calculation above:
x1, x2 = Value(1.0), Value(2.0)
w11, w12, w21, w22 = Value(0.1), Value(0.2), Value(0.3), Value(-0.4)
v1, v2 = Value(0.6), Value(0.9)
h1 = (w11 * x1 + w12 * x2).relu()
h2 = (w21 * x1 + w22 * x2).relu()
p = (v1 * h1 + v2 * h2).sigmoid()
loss = p.log() * -1
loss.backward()
print(round(loss.data, 4), round(v1.grad, 4), round(w12.grad, 4))   # 0.5544 -0.2128 -0.5107
```

**Why `+=` for gradients?** If a value is used in two places, its total gradient is the sum of both
paths (multivariable chain rule). Forgetting this is a classic bug; it's also why PyTorch requires
`optimizer.zero_grad()` every step — gradients accumulate by default.

## 6. A vectorized MLP in NumPy

Scalar autograd is for understanding; real code uses matrices so a whole mini-batch is one matmul.

```python
import numpy as np
from sklearn.datasets import make_moons

X, y = make_moons(n_samples=1000, noise=0.2, random_state=0)   # non-linear 2-class data
y = y.reshape(-1, 1)
rng = np.random.default_rng(0)

# He initialization: keeps activation variance stable through ReLU layers (module 05)
W1 = rng.normal(0, np.sqrt(2 / 2), (2, 32));   b1 = np.zeros(32)
W2 = rng.normal(0, np.sqrt(2 / 32), (32, 1));  b2 = np.zeros(1)
sigmoid = lambda z: 1 / (1 + np.exp(-z))
lr = 0.5

for epoch in range(2001):
    # forward (row-vector convention: X @ W)
    z1 = X @ W1 + b1            # (n, 32)
    h = np.maximum(0, z1)       # ReLU
    z2 = h @ W2 + b2            # (n, 1)
    p = sigmoid(z2)
    loss = -np.mean(y * np.log(p + 1e-9) + (1 - y) * np.log(1 - p + 1e-9))

    # backward
    n = len(X)
    dz2 = (p - y) / n                    # (n, 1)
    dW2 = h.T @ dz2;  db2 = dz2.sum(0)
    dh = dz2 @ W2.T                      # (n, 32)
    dz1 = dh * (z1 > 0)
    dW1 = X.T @ dz1;  db1 = dz1.sum(0)

    # update
    W1 -= lr * dW1; b1 -= lr * db1; W2 -= lr * dW2; b2 -= lr * db2
    if epoch % 500 == 0:
        acc = ((p > 0.5) == y).mean()
        print(f"epoch {epoch:4d}  loss {loss:.3f}  acc {acc:.3f}")
# reaches ~97% accuracy; logistic regression tops out around 86% on this data
```

**Shape discipline** is the most useful debugging habit in deep learning. Write the shape next to
every line. If `dW1` doesn't have the same shape as `W1`, the math is wrong.

## 7. Same thing in PyTorch

```python
import torch, torch.nn as nn

Xt = torch.tensor(X, dtype=torch.float32)
yt = torch.tensor(y, dtype=torch.float32)

model = nn.Sequential(nn.Linear(2, 32), nn.ReLU(), nn.Linear(32, 1))
loss_fn = nn.BCEWithLogitsLoss()          # sigmoid + BCE fused: numerically stable
opt = torch.optim.SGD(model.parameters(), lr=0.5)

for epoch in range(2001):
    logits = model(Xt)                    # forward: builds the graph
    loss = loss_fn(logits, yt)
    opt.zero_grad()                       # clear accumulated grads
    loss.backward()                       # autograd: the Value class, on tensors, on GPU
    opt.step()                            # W -= lr * W.grad
```

Every training loop you'll ever see — including LLM pretraining — is these five lines plus
data loading, a better optimizer, and distributed tricks.

## 8. What neural networks learn: representations

The hidden layer output $\mathbf{h}$ is a **learned representation** (an embedding) of the input.
After training on the moons data, plotting $\mathbf{h}$ shows the two classes pulled apart so a
straight line separates them. Scale this idea up:

- An image classifier's second-to-last layer gives image embeddings (used for similarity search).
- A language model's hidden states give text embeddings (used in RAG, `04_rag/`).
- **Transfer learning:** reuse those representations for a new task with little data — the reason
  pretrained models dominate (modules 06–09).

## 9. Key takeaways

- A neural net = stacked linear layers + nonlinearities; nonlinearity is what makes depth useful.
- Backprop = chain rule applied backwards, reusing intermediate values; gradient = error × input.
- Autograd records the forward graph and walks it backwards; gradients accumulate (`+=`).
- Training costs ~3× inference per example (forward + 2× backward).
- Hidden layers learn representations — the basis of embeddings and transfer learning.

## Interview questions

1. *Why can't you initialize all weights to zero?* — every neuron in a layer computes the same output
   and receives the same gradient, so they stay identical forever (symmetry is never broken).
2. *What is a dead ReLU, and how do you fix it?* — a neuron whose pre-activation is always negative
   gets zero gradient and never recovers. Fixes: Leaky ReLU/GELU, lower learning rate, proper init.
3. *Why `BCEWithLogitsLoss` instead of `Sigmoid` + `BCELoss`?* — computing $\log(\sigma(z))$ separately
   underflows for large $|z|$; the fused version uses the log-sum-exp trick.
4. *What does `loss.backward()` actually do?* — topologically sorts the recorded graph and calls each
   op's local backward in reverse, accumulating `.grad` on leaf tensors.
