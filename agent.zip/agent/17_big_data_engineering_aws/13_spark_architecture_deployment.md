# 13 — Spark Architecture, Cluster Managers & Deployment Modes

> **Why it matters:** "Which deploy mode?", "how many executors?", and "why did the driver OOM?" are
> daily questions. Sizing executors correctly can halve cost. Picking client mode for a production job
> can kill it when your laptop sleeps. This module covers the runtime architecture and the sizing math.

## In plain words

A **film shoot**:
- **Driver** = the director: holds the script (your program), breaks it into scenes (stages) and shots
  (tasks), assigns them, and tracks progress. If the director leaves, the shoot stops.
- **Executors** = camera crews on location: each crew has several cameras (cores) shooting shots in
  parallel and a storage van (cache/memory).
- **Cluster manager** = the studio that rents out crews and equipment (YARN, Kubernetes, Standalone).

## Architecture at a glance

```mermaid
flowchart TB
  subgraph DRV["Driver process"]
    SC[SparkSession / SparkContext]
    DAG[DAGScheduler<br/>jobs → stages]
    TS[TaskScheduler<br/>stages → tasks → slots]
    BMM[BlockManagerMaster<br/>tracks cached blocks]
    UI[Spark UI :4040]
  end
  CM[Cluster manager<br/>YARN RM / K8s API / Standalone master]
  subgraph E1["Executor 1 (JVM)"]
    T11[task thread] 
    T12[task thread]
    BM1[BlockManager<br/>cache + shuffle files]
  end
  subgraph E2["Executor 2 (JVM)"]
    T21[task thread]
    T22[task thread]
    BM2[BlockManager]
  end
  SC -->|request executors| CM
  CM -->|launch| E1 & E2
  E1 & E2 -->|register| DRV
  TS -->|serialized tasks| T11 & T12 & T21 & T22
  T11 -.status, metrics, results.-> DRV
  BM1 <-->|shuffle fetch| BM2
```

**How to read it:** the driver plans and schedules; executors execute and store. The cluster manager only
provides containers/pods. After executors register, **the driver talks to executors directly**. Shuffle
data moves executor-to-executor; results of `collect()` flow to the driver.

## 1. Components

| Component | Responsibilities | Failure impact |
|---|---|---|
| **Driver** | runs `main()`, builds DAG, schedules tasks, tracks cache/shuffle locations, collects results, hosts UI | driver dies = application dies (YARN may retry the AM in cluster mode) |
| **Executor** | runs tasks in threads (one per core), caches data, stores/serves shuffle files | tasks rescheduled; cached partitions recomputed; shuffle outputs regenerated unless an external shuffle service holds them |
| **Cluster manager** | allocates resources | YARN RM HA on EMR with 3 primaries |
| **External shuffle service** | serves shuffle files independently of executors (NodeManager aux service on YARN) | lets dynamic allocation remove idle executors without losing shuffle data |

### Spark's distributed nature and in-memory computation

- **Distributed:** a dataset's partitions are spread across executors; a task processes one partition where it lives.
- **In-memory:** within a stage, records stream through pipelined operators in memory without materialization;
  cached data and broadcasts live in executor memory. Disk is used for shuffle files and spills.

## 2. Run modes and cluster managers

| Cluster manager | How executors start | Notes |
|---|---|---|
| `local[n]` | threads in one JVM | dev/test |
| **Standalone** | Spark Master + Worker daemons on each node | simple, Spark-only cluster; static resources; no multi-framework sharing |
| **YARN** | containers from the ResourceManager | EMR default; shares the cluster with Hive/Tez/MapReduce; queues, security (Kerberos) |
| **Kubernetes** | pods via the K8s API | EMR on EKS, Spark Operator; containerized dependencies |
| Mesos | deprecated, removed in Spark 4 | — |

### Standalone vs YARN

| | Standalone | YARN |
|---|---|---|
| Daemons | Spark Master + Workers | ResourceManager + NodeManagers |
| Other frameworks | no | MapReduce, Hive on Tez, Flink, ... |
| Scheduling | FIFO across apps (+ core caps) | Capacity/Fair queues, preemption |
| Security | basic | Kerberos, ACLs, Ranger |
| Data locality with HDFS | yes | yes |
| On AWS | self-managed on EC2 (rare) | EMR |

```bash
# Standalone (for understanding)
$SPARK_HOME/sbin/start-master.sh                      # UI :8080, spark://host:7077
$SPARK_HOME/sbin/start-worker.sh spark://master:7077 --cores 4 --memory 8g
spark-submit --master spark://master:7077 --total-executor-cores 8 job.py
```

## 3. Spark on YARN — the full picture

```mermaid
flowchart LR
  subgraph CLIENTMODE["CLIENT mode"]
    direction TB
    CL1[Client machine<br/>e.g. EMR primary / notebook<br/>DRIVER runs here]
    RM1[YARN RM]
    AM1[AM container<br/>executor launcher only]
    EX1[Executors]
    CL1 --> RM1 --> AM1 --> EX1
    EX1 <-->|tasks/results| CL1
  end
  subgraph CLUSTERMODE["CLUSTER mode"]
    direction TB
    CL2[Client<br/>submits and can exit]
    RM2[YARN RM]
    AM2[AM container<br/>DRIVER runs inside]
    EX2[Executors]
    CL2 --> RM2 --> AM2 --> EX2
    EX2 <--> AM2
  end
```

## 4. Deployment modes: client vs cluster

| | Client mode | Cluster mode |
|---|---|---|
| Driver location | the machine running `spark-submit` / notebook | inside the YARN AM container on a cluster node |
| Driver logs | your terminal | YARN logs (`yarn logs -applicationId`, S3 on EMR) |
| Client disconnect | **application dies** | keeps running |
| Network | driver ↔ executors traffic crosses to client (bad if client is remote) | all inside the cluster |
| Interactive shells/notebooks | required (`pyspark`, Jupyter, Livy sessions run client-style drivers) | not possible |
| Production batch | ❌ | ✅ |
| EMR Steps default | `spark-submit --deploy-mode cluster` recommended | |

**Picking the right mode (scenario):** a nightly job is submitted from an Airflow worker using
`--deploy-mode client`. When the Airflow worker restarts during a deploy, the job dies halfway and leaves
partial output. Fix: cluster mode (or EMR Serverless / EMR Steps), plus idempotent writes so retries are safe.

## 5. Executor sizing — the math

### Inputs

Example cluster: **10 core nodes of r7g.4xlarge** (16 vCPU, 128 GiB). EMR's `yarn-site` offers most of that
memory to YARN (check `yarn.nodemanager.resource.memory-mb`; assume ≈ 112 GiB here) after reserving room for
the OS and daemons.

### Step by step

1. **Cores per executor:** ~4–5. More cores per JVM → GC and HDFS/S3 client contention; 1 core → no
   in-JVM sharing of broadcasts/cache, more JVM overhead. Choose **5**.
2. **Usable cores per node:** leave 1 for OS/daemons → 15. Executors per node = 15 / 5 = **3**.
3. **Total executors:** 10 × 3 = 30, minus 1 slot for the AM/driver in cluster mode → **29**.
4. **Memory per executor container:** 112 GiB / 3 ≈ 37 GiB.
5. **Split heap vs overhead:** overhead = max(384 MB, 10%) → heap ≈ 37 / 1.1 ≈ **33 GiB**, overhead ≈ 4 GiB.
   For PySpark with heavy UDFs/Arrow, raise overhead to 15–20% (or set `spark.executor.pyspark.memory`).

```bash
spark-submit --master yarn --deploy-mode cluster \
  --num-executors 29 --executor-cores 5 \
  --executor-memory 33g --conf spark.executor.memoryOverhead=4g \
  --driver-memory 8g --driver-cores 2 \
  --conf spark.sql.shuffle.partitions=435 \      # ≈ 29 × 5 × 3 (2–3 tasks per core)
  s3://$BUCKET/code/job.py
```

### Sanity checks

- Parallel task slots = 29 × 5 = **145**. Shuffle partitions ≈ 2–4× slots, or let AQE decide.
- Per-task memory ≈ unified memory / cores = (33 GiB − 300 MB) × 0.6 / 5 ≈ **3.9 GiB** per concurrent task.
  If a partition needs more (skewed joins), tasks spill.
- **Driver memory** matters for `collect()`, `toPandas()`, broadcast building (the driver collects the
  broadcast table first), and plans with very many files/partitions.

### EMR helpers

- EMR sets sensible `spark.executor.memory/cores` defaults per instance type.
- `maximizeResourceAllocation=true` (classification `spark`) → one fat executor per node using all resources.
  Simple, but often worse than ~5-core executors.
- **Dynamic allocation** (on by default on EMR): executors are added when tasks are pending and removed after
  `spark.dynamicAllocation.executorIdleTimeout` (60 s). Set `minExecutors/maxExecutors` to bound it.

## 6. Where to run Spark on AWS — decision guide

| | EMR on EC2 | EMR Serverless | EMR on EKS | AWS Glue ETL | Databricks on AWS |
|---|---|---|---|---|---|
| You size | nodes + executors | executors (or let it auto-scale) | pods/nodes | workers (DPU: G.1X = 4 vCPU/16 GB, G.2X = 8/32, ...) | clusters / serverless |
| Startup | ~7–10 min (cluster) | ~1–2 min (pre-initialized capacity: seconds) | pods in seconds if nodes exist | ~seconds–1 min (Glue 4/5) | serverless: seconds |
| Idle cost | yes (unless auto-terminate) | none | node pool cost | none | depends |
| Control & tuning | full (any config, bootstrap, HDFS) | most Spark confs | full | moderate; Glue-specific features (DynamicFrame, bookmarks) | full + Photon engine |
| Best for | long-running/shared clusters, custom stacks | spiky batch jobs | K8s-standardized orgs | catalog-centric ETL, small teams | lakehouse platform, notebooks, ML |

## 7. Spark UI deep read with YARN (EMR)

1. YARN RM UI (`:8088`) → application → **ApplicationMaster** link → live Spark UI (proxied).
2. After completion → Spark History Server (`:18080`) or the EMR console's persistent application UI.
3. **Executors tab:** if "Task time (GC time)" shows GC > 10%, there's memory pressure. Many dead executors →
   Spot interruptions or OOM kills (check YARN logs for exit code 137/143).

## Key takeaways

- Driver = planning + scheduling (+ collected results); executors = tasks + cache + shuffle files.
- Standalone is Spark-only; YARN (EMR) adds queues, sharing, and security; K8s for containerized platforms.
- Client mode: driver on the submitter (interactive). Cluster mode: driver in the AM (production).
- Sizing recipe: ~5 cores per executor, leave 1 core per node, heap ≈ container / 1.1, shuffle partitions ≈ 2–4× slots.
- On AWS choose among EMR (EC2/Serverless/EKS), Glue, and Databricks by control vs ops trade-off.

## Interview scenarios

1. *Driver OOM in a job that only writes to S3.* — something is pulling data to the driver: `collect()`,
   `toPandas()`, a big broadcast (driver builds it), huge numbers of files/partitions in planning, or
   accumulators/metrics. Remove the collect, raise the broadcast threshold carefully or disable auto-broadcast,
   increase `spark.driver.memory`, compact small files.
2. *Choose a cluster manager for a company with Hive, Spark, and Flink sharing hardware.* — YARN (EMR), with Capacity
   queues per team, or EMR on EKS if they're standardized on Kubernetes.
3. *Executors with 16 cores and 120 GB each run slowly with long GC pauses.* — fat executors: big heaps → long
   GC, and too many threads contend on I/O. Use ~5 cores and ~30–40 GB executors.
4. *Why must production jobs avoid client mode from a laptop?* — the driver dies with the laptop and every
   result/heartbeat crosses a slow, unreliable network.
