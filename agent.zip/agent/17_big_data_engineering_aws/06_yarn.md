# 06 — YARN: Yet Another Resource Negotiator

> **Why it matters:** YARN is the operating system of a Hadoop cluster. It decides which application
> gets how much CPU and memory on which node. Spark on EMR runs on YARN, so "container killed by YARN
> for exceeding memory limits", stuck ACCEPTED applications, and queue fairness are all YARN problems
> you'll debug in real life.

## In plain words

A **co-working space**:

- **ResourceManager** = the front desk. It knows every room (node) and how many desks (vCPU/memory) are
  free, and assigns desks according to company rules (queues).
- **NodeManager** = the floor manager on each floor. It opens rooms, checks nobody uses more desks than
  booked, and reports back to the front desk.
- **ApplicationMaster** = a team lead who arrives first, gets one desk, then asks the front desk for more
  desks for their team, and supervises their work.
- **Container** = one booked desk bundle: "2 vCPU + 4 GB for this task".

## Architecture at a glance

```mermaid
flowchart TB
  CL[Client<br/>spark-submit / hadoop jar]
  subgraph RMBOX["ResourceManager (primary node)"]
    SCH[Scheduler<br/>Capacity / Fair / FIFO<br/>pure allocation]
    ASM[ApplicationsManager<br/>accepts apps, launches + restarts AMs]
  end
  subgraph N1["Node 1 — NodeManager"]
    AM[Container 0:<br/>ApplicationMaster]
    C1[Container: task]
  end
  subgraph N2["Node 2 — NodeManager"]
    C2[Container: task]
    C3[Container: task]
  end
  CL -->|1. submit app| ASM
  ASM -->|2. launch AM container| N1
  AM -->|3. register + request containers<br/>heartbeat| SCH
  SCH -->|4. container grants<br/>node + resources| AM
  AM -->|5. launch containers| N2
  AM --> C1
  N1 -. "6. node heartbeat: resources, health" .-> RMBOX
  N2 -.-> RMBOX
  C2 & C3 -.progress.-> AM
```

**How to read it:** the RM only allocates resources; it doesn't track individual tasks. Each
application's **own** AM negotiates containers and monitors its tasks. This split is why YARN scales to
thousands of nodes and can run MapReduce, Spark, Tez, and Flink side by side.

## 1. Why YARN exists (Hadoop 1 → Hadoop 2)

Hadoop 1 had a **JobTracker** that did resource management **and** task tracking for every job, plus
fixed **map slots and reduce slots** per node.

| Hadoop 1 problem | YARN fix |
|---|---|
| JobTracker overloaded beyond ~4,000 nodes | per-application AM handles task tracking |
| Fixed map/reduce slots → idle reduce slots during map phase | generic containers (memory + vCPU) |
| Only MapReduce | any framework (Spark, Tez, Flink...) |
| JobTracker = SPOF | RM HA (active/standby via ZooKeeper), AM restarts |

## 2. Components in detail

| Component | Runs | Responsibilities |
|---|---|---|
| **ResourceManager** | primary node | global resource allocation; **Scheduler** (decides who gets what) + **ApplicationsManager** (accepts submissions, starts the first container for each AM, restarts failed AMs) |
| **NodeManager** | every worker | launches containers, enforces limits (cgroups / memory monitor), reports node health, serves shuffle data (aux service) |
| **ApplicationMaster** | a container | one per app: requests containers (with locality preferences), launches tasks, handles task failures, reports progress |
| **Container** | worker | an allocation of memory + vCPU on one node, running a process (JVM, Python...) |
| **Timeline / History servers** | primary | job history after completion (MR JobHistory, Spark History Server) |

## 3. Step-by-step application lifecycle

```mermaid
sequenceDiagram
  participant C as Client
  participant RM as ResourceManager
  participant NM1 as NodeManager (node A)
  participant AM as ApplicationMaster
  participant NM2 as NodeManager (node B)
  C->>RM: 1. request new application ID
  RM-->>C: application_1731391200000_0007
  C->>C: 2. upload jars/py files/config to staging (HDFS/S3)
  C->>RM: 3. submit app context (queue, AM resources, launch command)
  RM->>RM: 4. Scheduler finds space for AM container
  RM->>NM1: 5. launch container 0 = AM
  NM1->>AM: 6. localize resources, start AM process
  AM->>RM: 7. register (tracking URL)
  loop allocate heartbeat (~1 s)
    AM->>RM: 8. ask: N containers, X GB, Y vCPU, prefer nodes [A,B] (data locality)
    RM-->>AM: 9. grants: container tokens for node B ...
  end
  AM->>NM2: 10. start container with launch context (token-authenticated)
  NM2->>NM2: 11. run task, enforce memory limit
  NM2-->>AM: 12. status / completion
  AM->>RM: 13. unregister when done
  RM->>NM1: 14. clean up AM container
```

App states you'll see: `NEW → SUBMITTED → ACCEPTED → RUNNING → FINISHED/FAILED/KILLED`.
**Stuck in ACCEPTED** = the app was admitted to a queue but there's no room for the AM container (queue
full, `maximum-am-resource-percent` hit, or the cluster has no free memory).

## 4. Resource model and the numbers that bite

| Property | Meaning |
|---|---|
| `yarn.nodemanager.resource.memory-mb` | memory a node offers to containers (EMR sets this per instance type, leaving room for the OS and daemons) |
| `yarn.nodemanager.resource.cpu-vcores` | vCPUs offered |
| `yarn.scheduler.minimum-allocation-mb` | requests are rounded **up** to a multiple of this |
| `yarn.scheduler.maximum-allocation-mb` | largest single container |
| `yarn.nodemanager.vmem-check-enabled` | virtual memory check (often disabled; EMR disables it) |

**Worked example — rounding waste.** Node offers 24,576 MB; minimum allocation 1,024 MB. Spark asks for
executor 4 GB + overhead 410 MB = 4,506 MB → rounded up to 5,120 MB. Containers per node:
\(\lfloor 24{,}576 / 5{,}120 \rfloor = 4\), leaving 4,096 MB idle. Asking for 4 GB + 1 GB overhead = 5,120 MB
uses the same space but avoids container kills. Size requests to fit node memory evenly.

**Container killed:** `Container killed by YARN for exceeding physical memory limits. 5.6 GB of 5.5 GB
physical memory used.` → the process (JVM heap + off-heap + Python workers) exceeded the container. Fix:
raise `spark.executor.memoryOverhead`, reduce cores per executor, or fix memory-hungry code (module 13).

**vCPU accounting:** the Capacity Scheduler's default `DefaultResourceCalculator` schedules on **memory
only**; `DominantResourceCalculator` considers memory **and** CPU. EMR configures the Capacity Scheduler.

## 5. Schedulers

```mermaid
flowchart LR
  subgraph FIFO["FIFO"]
    F1[Job A big] --> F2[Job B waits] --> F3[Job C waits]
  end
  subgraph CAP["Capacity Scheduler"]
    Q1[queue etl 60%] 
    Q2[queue adhoc 30%]
    Q3[queue ml 10%]
  end
  subgraph FAIR["Fair Scheduler"]
    FA[running apps get<br/>equal share over time<br/>+ weights + preemption]
  end
```

| Scheduler | Model | Good for |
|---|---|---|
| FIFO | first come, first served | single-user test clusters |
| **Capacity** (Apache Hadoop default; used by EMR) | hierarchical queues with guaranteed % of cluster; can borrow idle capacity up to `maximum-capacity`; user limits; preemption optional | multi-tenant orgs with budgets per team |
| **Fair** | resources shared so each app/queue converges to its fair share; weights, min shares, preemption | many concurrent interactive jobs |

Capacity Scheduler config sketch (`capacity-scheduler` classification on EMR):

```json
[{"Classification": "capacity-scheduler",
  "Properties": {
    "yarn.scheduler.capacity.root.queues": "etl,adhoc",
    "yarn.scheduler.capacity.root.etl.capacity": "70",
    "yarn.scheduler.capacity.root.etl.maximum-capacity": "100",
    "yarn.scheduler.capacity.root.adhoc.capacity": "30",
    "yarn.scheduler.capacity.root.adhoc.maximum-capacity": "50",
    "yarn.scheduler.capacity.maximum-am-resource-percent": "0.3",
    "yarn.resourcemanager.scheduler.monitor.enable": "true"}}]
```

Submit to a queue: `spark-submit --queue etl ...`.

**Preemption:** if adhoc borrowed etl's idle capacity and etl now needs it, the RM can kill adhoc containers
to restore etl's guarantee. Spark tolerates this (lost tasks rerun), but long tasks lose work.

## 6. YARN analogy check — map it to MapReduce and Spark

| YARN concept | MapReduce | Spark on YARN |
|---|---|---|
| ApplicationMaster | MRAppMaster | Spark AM; in **cluster mode** the **driver runs inside the AM container**; in client mode the driver runs on the client and the AM only requests executors |
| Containers | one per map/reduce task (short-lived) | one per **executor** (long-lived, runs many tasks as threads) |
| Locality request | per split | per partition preferred locations |
| Shuffle service | NM aux service `mapreduce_shuffle` | NM aux service `spark_shuffle` (external shuffle service, needed for dynamic allocation) |

This difference (task = container vs executor = container running many tasks) is a big reason Spark has
lower per-task overhead than MapReduce.

## 7. Operating YARN on EMR

```bash
yarn application -list -appStates RUNNING,ACCEPTED
yarn application -status application_1731391200000_0007
yarn application -kill  application_1731391200000_0007
yarn logs -applicationId application_1731391200000_0007 | less   # aggregated container logs
yarn queue -status etl
yarn node -list -showDetails
yarn top                                                             # live resource use per app
```

- EMR aggregates YARN container logs to S3 under `--log-uri` (`containers/`), so you can read them after the cluster terminates.
- EMR Managed Scaling reads YARN metrics (pending containers, available memory) to add or remove nodes.
- RM HA: EMR clusters with 3 primary nodes run active/standby ResourceManagers.

## 8. Debugging exercises (with solutions)

1. **App stuck in ACCEPTED for 20 minutes.** Check `yarn queue -status <queue>`: used capacity at max? AM
   resource percent reached by many small apps? Pending AM size bigger than `maximum-allocation-mb`?
   Fixes: raise `maximum-am-resource-percent`, use a different queue, enable managed scaling, kill zombie apps.
2. **Executors keep dying with exit code 137 / "exceeding physical memory".** The container limit was exceeded.
   Raise `spark.executor.memoryOverhead` (PySpark UDFs, Arrow, and native libs all use off-heap memory), or
   reduce `spark.executor.cores` so fewer concurrent tasks share the heap.
3. **Cluster 40% idle but jobs wait.** Rounding waste or a memory-only resource calculator (all vCPUs taken
   while memory sits free, or vice versa). Align container sizes to node memory; consider
   `DominantResourceCalculator`.

## Key takeaways

- RM = global allocation (Scheduler + ApplicationsManager); NM = per-node execution; AM = per-app brain.
- Containers are memory + vCPU allocations; requests are rounded up to the minimum allocation.
- Capacity Scheduler (EMR default) uses guaranteed queue shares with elastic borrowing and optional preemption.
- In Spark cluster mode, the driver lives inside the AM container; executors are long-lived containers.
- ACCEPTED-but-not-running = no room for the AM; "killed for exceeding memory" = raise overhead or lower concurrency.

## Interview scenarios

1. *Explain YARN to a MapReduce-only engineer.* — "The JobTracker got split in two: a cluster-wide
   ResourceManager that only hands out memory/CPU containers, and a per-job ApplicationMaster that does
   what the JobTracker did for your job: request containers near your data, launch tasks, retry
   failures. Map/reduce slots are gone; any framework, including Spark, can share the same cluster."
2. *Trace a Spark job submission in cluster mode on YARN.* — Client → RM (app ID) → staging upload → RM
   starts AM container with the driver → driver/AM registers, requests executor containers → NMs launch
   executor JVMs → executors register with the driver → driver schedules tasks → AM unregisters → logs aggregated.
3. *Why might YARN kill a container when the JVM heap is only 60% used?* — the limit applies to total
   process memory (heap + overhead: metaspace, threads, direct buffers, Python workers), not just heap.
