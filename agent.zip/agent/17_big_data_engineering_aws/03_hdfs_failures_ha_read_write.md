# 03 — HDFS Failure Handling, High Availability, and the Read/Write Path

> **Why it matters:** a 1,000-node cluster loses disks and nodes every day. Knowing exactly what HDFS
> does when a DataNode disappears, how the write pipeline survives a failure halfway through a write,
> and how a NameNode outage is prevented is classic senior interview material. It also explains what
> EMR does (and doesn't do) for you.

## In plain words

- **DataNode failure** = one of the photocopy rooms burns down. The librarian notices that room has
  stopped checking in, sees which chapters now have only 2 copies, and orders new copies from the
  survivors.
- **Secondary NameNode** = an assistant who **tidies the librarian's notebook** every hour: merges the
  day's scribbled notes into a clean index. If the librarian quits, the assistant does *not* take over.
- **Standby NameNode** = a **second librarian** who reads every change in a shared journal in real time
  and can take over within seconds.
- **Write pipeline** = a **bucket brigade**: the client hands data to node 1, which passes it to node 2,
  which passes it to node 3; acknowledgements travel back along the chain.

## Architecture at a glance — HDFS High Availability

```mermaid
flowchart TB
  ZK[(ZooKeeper ensemble<br/>3 or 5 nodes<br/>leader lock)]
  subgraph ACT["Active side"]
    ANN[Active NameNode]
    ZK1[ZKFC]
  end
  subgraph STB["Standby side"]
    SNN[Standby NameNode<br/>also does checkpoints]
    ZK2[ZKFC]
  end
  subgraph QJM["Quorum Journal Manager"]
    J1[JournalNode 1]
    J2[JournalNode 2]
    J3[JournalNode 3]
  end
  DNs[DataNodes<br/>heartbeats + block reports<br/>to BOTH NameNodes]
  ZK1 <-->|health + lock| ZK
  ZK2 <-->|health + lock| ZK
  ZK1 --- ANN
  ZK2 --- SNN
  ANN -->|write edits,<br/>needs majority ack| J1 & J2 & J3
  J1 & J2 & J3 -->|tail edits| SNN
  DNs --> ANN
  DNs --> SNN
```

**How to read it:** the active NameNode writes every namespace change to a **majority** of JournalNodes.
The standby continuously reads those edits, so its in-memory namespace is always nearly current. DataNodes
report blocks to **both**, so the standby also knows block locations. A **ZKFC** (ZooKeeper Failover
Controller) next to each NameNode health-checks it and holds a lock in ZooKeeper. If the active dies, its
lock expires, the standby's ZKFC grabs it, **fences** the old active, and promotes the standby.

## 1. How the NameNode persists state: fsimage + edit log

```
 Startup:  load fsimage (snapshot)  ──►  replay edits since snapshot  ──►  namespace in RAM
                                                                           + wait for block reports
 Runtime:  every mutation (create, rename, delete) ──► append to edit log (fsync) ──► update RAM
```

- Block **locations** are **not** persisted; they're rebuilt from DataNode block reports at startup.
- If the edit log grows for weeks without a checkpoint, a restart replays millions of edits → restart takes
  hours. Checkpointing exists to prevent that.
- **Safe mode:** at startup the NN is read-only until enough blocks are reported
  (`dfs.namenode.safemode.threshold-pct` = 0.999). `hdfs dfsadmin -safemode get|leave`.

## 2. Secondary NameNode — the checkpoint helper

```mermaid
sequenceDiagram
  participant NN as NameNode
  participant SNN as Secondary NameNode
  SNN->>NN: every 1h or 1M txns: please roll edits
  NN->>NN: start new edits file (edits_new)
  SNN->>NN: GET fsimage + old edits (HTTP)
  SNN->>SNN: load fsimage, replay edits → new fsimage.ckpt
  SNN->>NN: PUT new fsimage
  NN->>NN: replace fsimage, edits_new becomes edits
```

Triggers: `dfs.namenode.checkpoint.period` = 3600 s **or** `dfs.namenode.checkpoint.txns` = 1,000,000.

| Myth | Reality |
|---|---|
| "Secondary NN is a backup NameNode" | No. It cannot serve clients. It only merges fsimage + edits. |
| "If the NN dies, we lose nothing" | Without HA, you lose changes since the last checkpoint if NN metadata disks die; you can recover from the SNN's checkpoint manually (`-importCheckpoint`) with data loss and downtime. |

In an **HA** setup there is no Secondary NameNode — the **Standby** performs checkpoints.

## 3. DataNode failure — temporary vs permanent

### Detection timeline

DN sends heartbeat every `dfs.heartbeat.interval` = 3 s. NN marks DN **dead** after:

$$
2 \times \text{recheck-interval} + 10 \times \text{heartbeat} = 2 \times 300\,\text{s} + 10 \times 3\,\text{s} = 630\,\text{s} \approx 10.5\ \text{min}
$$

**Read it as:** HDFS deliberately waits ~10 minutes before declaring a node dead, so a reboot or a brief
network blip doesn't trigger terabytes of unnecessary re-replication.

(After ~30 s without heartbeats, the node is considered **stale** — readers and writers avoid it, but no
re-replication starts yet.)

### Temporary failure (node returns within ~10 min)

1. Heartbeats stop → after ~30 s the node is marked stale; clients skip it for reads/writes.
2. Node comes back, sends heartbeat + block report.
3. NN reconciles: blocks are fine, nothing re-replicated. Writes that were in flight recovered via the
   pipeline recovery (section 6).

### Permanent failure (node gone > 10.5 min)

```mermaid
flowchart LR
  A[Heartbeats stop] --> B[~30 s: marked stale]
  B --> C[10.5 min: marked DEAD]
  C --> D[NN scans block map:<br/>blocks on dead node now<br/>under-replicated, e.g. 2 of 3]
  D --> E[Priority queue:<br/>blocks with 1 replica first]
  E --> F[NN tells a surviving DN<br/>in heartbeat reply:<br/>copy block to DN-x]
  F --> G[Back to RF 3,<br/>respecting rack policy]
  G --> H{Old node returns later?}
  H -->|yes| I[Now OVER-replicated →<br/>NN deletes extra replicas]
```

**Re-replication math:** dead node held 10 TB. 100 surviving nodes each copy in parallel; throttled by
`dfs.namenode.replication.max-streams` and bandwidth. At an effective 2 GB/s aggregate:
\(10{,}000\,\text{GB} / 2\,\text{GB/s} = 5{,}000\,\text{s} \approx 1.4\ \text{h}\) of reduced redundancy.
That's why RF 3 (tolerates 2 losses during that window), not 2.

### Planned removal = decommissioning

Add host to `dfs.hosts.exclude`, run `hdfs dfsadmin -refreshNodes`. NN re-replicates the node's blocks
**first**, then marks it decommissioned → zero redundancy loss. EMR does this when you scale in core nodes.

### Disk failure (not the whole node)

`dfs.datanode.failed.volumes.tolerated` (default 0 → DN shuts down on any disk failure; set to 1–2 on
nodes with 12 disks). Lost blocks on that disk are re-replicated.

### Data corruption

Every 512 bytes have a CRC32C checksum (`dfs.bytes-per-checksum`). Clients verify on read; DataNodes run a
**block scanner** periodically. Corrupt replica → reported → NN re-replicates from a good copy, deletes the bad one.

## 4. NameNode HA in depth

### Why HA was needed

In Hadoop 1, the NN was a **single point of failure**: crash or maintenance = whole cluster down, and
restart = load fsimage + replay edits + wait for block reports (could take 30–60+ min on large clusters).

### Components

| Component | Role |
|---|---|
| Active NN | serves all client requests |
| Standby NN(s) | applies edits from JournalNodes, receives block reports, checkpoints; Hadoop 3 allows multiple standbys |
| JournalNodes (≥3, odd) | store the edit log; a write succeeds when a **majority** acknowledges (3 JNs tolerate 1 failure, 5 tolerate 2) |
| ZooKeeper | holds the ephemeral "active" lock |
| ZKFC | health monitor + leader election + triggers fencing |

### Split-brain and fencing

**Split-brain** = two NameNodes both think they're active and both write edits → corrupted namespace.

Defenses:
1. **QJM epochs:** each new active gets a higher epoch number; JournalNodes reject writes from an older epoch.
   So even if the old active is still alive, its edits are refused. This is the main protection.
2. **Fencing methods** (`dfs.ha.fencing.methods`): `sshfence` (kill the process), or a `shell` script
   (e.g. cut power, revoke network) for nodes that are unreachable.

### Failover sequence

```mermaid
sequenceDiagram
  participant A as Active NN + ZKFC-A
  participant ZK as ZooKeeper
  participant S as Standby NN + ZKFC-S
  participant J as JournalNodes
  A--xZK: NN unhealthy / process dies → session expires
  ZK->>S: lock released (watch fires)
  S->>ZK: acquire lock
  S->>A: fence old active (sshfence / shell)
  S->>J: new epoch, finish reading all edits
  S->>S: transition to ACTIVE
  Note over S: clients retry via ConfiguredFailoverProxyProvider<br/>(logical nameservice hdfs://mycluster)
```

Clients use a **logical nameservice** (`hdfs://mycluster`) listing both NNs; on failover they retry the
other NN transparently. Typical failover: tens of seconds.

### Federation (different problem)

HA = availability of one namespace. **Federation** = scaling the namespace: multiple independent NNs each
own a part of the tree (`/user`, `/data`), sharing the same DataNodes. Used when one NN's heap can't hold
all metadata.

### On AWS EMR

- EMR supports **multiple primary nodes** (3 primaries) for HA: NameNode HA, YARN ResourceManager HA, and
  ZooKeeper. Launch with `--instance-groups InstanceGroupType=MASTER,InstanceCount=3,...`.
- Without it, a primary node failure terminates the cluster. For transient clusters reading from S3 this is
  often acceptable: rerun the job.
- With S3 as the store, the "NameNode" concern for your **durable** data disappears: S3 has no single
  metadata server you manage.

## 5. Write path — step by step

```mermaid
sequenceDiagram
  participant C as Client (DFSOutputStream)
  participant NN as NameNode
  participant D1 as DN1 (rack A)
  participant D2 as DN2 (rack B)
  participant D3 as DN3 (rack B)
  C->>NN: create(/data/f.csv)
  NN->>NN: check perms and that file does not exist, add to namespace, grant lease
  NN-->>C: OK
  C->>NN: addBlock()
  NN-->>C: block id + pipeline [DN1, DN2, DN3] (rack-aware)
  C->>D1: setup pipeline
  D1->>D2: setup
  D2->>D3: setup
  loop for each 64 KB packet
    C->>D1: packet (data + checksums)
    D1->>D2: forward
    D2->>D3: forward
    D3-->>D2: ack
    D2-->>D1: ack
    D1-->>C: ack → remove from ack queue
  end
  C->>NN: block full (128 MB) → addBlock() for next block ...
  C->>NN: complete(file)
  NN-->>C: file closed (after min replicas reported)
```

Key internals:

| Detail | Value / meaning |
|---|---|
| Packet size | 64 KB (`dfs.client-write-packet-size`) |
| Chunk + checksum | 512-byte chunks, 4-byte CRC each |
| Data queue / ack queue | client keeps sent packets in the ack queue until all 3 DNs ack — required for recovery |
| Lease | only one writer per file; NN grants a lease that the client renews |
| Success | write returns when `dfs.namenode.replication.min` (default 1) replicas are complete; the NN re-replicates the rest asynchronously |
| Visibility | data becomes visible to readers on block completion or `hflush()` |

### Pipeline failure during write

1. DN2 dies mid-block → client stops sending, moves all packets in the **ack queue back to the front of the data queue** (so nothing is lost).
2. Good DNs (DN1, DN3) get a new **generation stamp** for the block, so the partial replica on DN2 is
   recognizable as stale if it comes back.
3. Pipeline rebuilt with DN1 → DN3 (optionally a replacement node added:
   `dfs.client.block.write.replace-datanode-on-failure.policy`).
4. Write continues; NN notices the block is under-replicated and fixes it later.

## 6. Read path — step by step

```mermaid
sequenceDiagram
  participant C as Client (DFSInputStream)
  participant NN as NameNode
  participant DA as Closest DN for block 1
  participant DB as Closest DN for block 2
  C->>NN: open(/data/f.csv)
  NN-->>C: block list, each with DNs sorted by distance to client
  C->>DA: read block 1 (verify checksums)
  DA-->>C: bytes
  C->>DB: read block 2
  DB-->>C: bytes
  Note over C,DB: on checksum error or dead DN → report to NN,<br/>try next replica in the list
```

**Network distance** = hops in the topology tree: same node 0, same rack 2, different rack 4, different
data center 6. **Short-circuit local reads** (`dfs.client.read.shortcircuit`) let a client on the same
host read the block file directly, bypassing the DataNode TCP stack.

## 7. Diagnosing exercise (with solution)

> *`hdfs fsck /` reports 1,200 under-replicated blocks and 4 missing blocks after a rack switch reboot.
> Ten minutes later, under-replicated drops to 0, but 4 blocks are still missing.*

- Under-replicated blocks recovered by themselves → the rack came back within the dead-node interval;
  block reports restored the counts.
- **Missing** = no live replica anywhere. Likely those files had RF 1 (e.g. temp data written with
  `-D dfs.replication=1`), or all replicas sat on one rack due to a broken topology script.
- Actions: `hdfs fsck / -list-corruptfileblocks`, identify files, restore from source/S3; check
  `hdfs dfsadmin -printTopology` to confirm racks are mapped; enforce RF ≥ 2 for anything not reproducible.

## 8. Explaining a live NameNode outage (stakeholder version)

"The server that knows where every file chunk lives went down. Our data is intact on the storage
machines, but nobody can find it until the index is back. We run a second index server that stays in
sync, so a switchover happens automatically within about a minute. This time the switchover failed
because ZooKeeper had lost quorum, so we promoted the standby manually. Action items: monitor ZooKeeper
quorum health, and run a failover drill every quarter."

## Key takeaways

- NN state = fsimage + edit log on disk; block locations come only from DataNode block reports.
- Secondary NN only checkpoints; Standby NN (HA) is a hot spare with QJM + ZKFC + fencing.
- A DataNode is declared dead after ~10.5 min (stale after ~30 s); re-replication follows priority order.
- Write = 64 KB packets through a rack-aware pipeline with an ack queue; failures rebuild the pipeline with a new generation stamp.
- Read = NN returns replicas sorted by distance; the client reads directly from the closest one, with checksum verification.
- EMR: 3 primary nodes give NN/RM HA, but the cluster is single-AZ — S3 remains the durable store.

## Interview scenarios

1. *Difference between Secondary and Standby NameNode?* — Secondary only merges fsimage + edits (and is
   absent in HA). Standby keeps a live namespace via JournalNodes, receives block reports, and takes over
   on failover; it also performs checkpoints.
2. *Why does the client write through a pipeline instead of to 3 nodes in parallel?* — the client's NIC
   would carry 3× the data. With a pipeline the client sends each byte once, and every node uses both
   incoming and outgoing bandwidth.
3. *Why must JournalNodes be odd and ≥3?* — writes need a majority; 3 tolerate 1 failure and 4 also
   tolerate only 1, so even counts add cost without extra tolerance.
4. *A DataNode rebooted for a kernel patch and returned in 4 minutes. Was data re-replicated?* — No.
   It was stale, not dead (dead = 10.5 min). Writes in flight did pipeline recovery.
5. *How does HDFS prevent split-brain?* — QJM epoch numbers reject the old active's writes; ZKFC fencing kills
   or isolates it; ZooKeeper's ephemeral lock ensures a single elected active.
