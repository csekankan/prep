# 18 — Docker for Data Engineers (+ Amazon ECR)

> **Why it matters:** "works on my machine" is worse in data engineering: Spark, Java, Python, native
> libraries, and connector JARs all have to match across laptop, CI, Airflow workers, and the cluster.
> Containers pin all of that into one artifact. Airflow (Astro, MWAA local runner), Kafka dev stacks, EMR
> on EKS, EMR Serverless custom images, and Glue local development all use Docker. This module skips
> `docker run hello-world` and covers how containers work and the patterns data teams use.

## In plain words

A **virtual machine** is a whole separate house: its own foundation, plumbing, and electricity (a full
guest OS). A **container** is an apartment in one building: it shares the building's foundation (the host
kernel) but has its own locked door, rooms, and meter. Apartments are much cheaper and faster to set up.
An **image** is the apartment's blueprint plus furniture list; a **container** is a running apartment built
from it.

## Architecture at a glance

```mermaid
flowchart TB
  subgraph VM["Virtual machines"]
    direction TB
    HW1[Hardware] --> HV[Hypervisor]
    HV --> G1[Guest OS kernel 1<br/>+ libs + app A]
    HV --> G2[Guest OS kernel 2<br/>+ libs + app B]
  end
  subgraph CT["Containers"]
    direction TB
    HW2[Hardware] --> OS[Host OS kernel<br/>namespaces + cgroups]
    OS --> RT[container runtime<br/>containerd / runc]
    RT --> C1[container A<br/>libs + app]
    RT --> C2[container B<br/>libs + app]
  end
```

**How to read it:** VMs virtualize hardware, so each one boots a kernel (GBs, minutes). Containers virtualize
the OS: they're ordinary Linux processes isolated by kernel features, starting in milliseconds and sized in MBs.

## 1. What a container really is

| Kernel feature | Provides |
|---|---|
| **Namespaces** (pid, net, mnt, uts, ipc, user) | isolation: own process tree, network stack, filesystem view, hostname |
| **cgroups** | resource limits: CPU shares/quotas, memory limit (OOM kill → exit code 137, same as YARN kills) |
| **Union filesystem** (overlayfs) | image layers stacked read-only + one thin writable layer per container |

On macOS/Windows, Docker Desktop runs a small Linux VM, and containers run inside it.

### Images vs containers

| | Image | Container |
|---|---|---|
| What | immutable, layered template (filesystem + metadata: entrypoint, env) | a running (or stopped) instance of an image + writable layer |
| Identity | `repo:tag` and content digest `sha256:...` | container ID/name |
| Storage | shared read-only layers | writable layer, lost on `docker rm` unless volumes are used |
| Analogy | class | object |

### Why Docker beats a VM (for our use cases)

| | Docker | VM |
|---|---|---|
| Startup | ms–seconds | minutes |
| Size | 50 MB–2 GB | 10+ GB |
| Density | dozens–hundreds per host | a handful |
| Reproducibility | Dockerfile in git → identical artifact everywhere | golden AMIs, slower to build |
| Isolation | process-level (shared kernel) | stronger (separate kernel) |

VMs still win for strong multi-tenant isolation or a different kernel/OS. That's why AWS runs containers on
Firecracker microVMs for Lambda/Fargate.

## 2. Layers and build cache — writing good Dockerfiles

Each instruction creates a layer. If a layer's inputs are unchanged, Docker reuses it from cache. **Order
from least to most frequently changing.**

```dockerfile
# Dockerfile — a PySpark/ETL job image
FROM python:3.11-slim AS base

# 1. OS packages (rarely change)
RUN apt-get update && apt-get install -y --no-install-recommends openjdk-17-jre-headless \
    && rm -rf /var/lib/apt/lists/*
ENV JAVA_HOME=/usr/lib/jvm/java-17-openjdk-arm64

# 2. Python deps (change sometimes): copy only the lock file first, for caching
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# 3. App code (changes often)
COPY src/ ./src/

# 4. Run as non-root
RUN useradd -m etl && chown -R etl /app
USER etl
ENTRYPOINT ["python", "-m", "src.main"]
```

`JAVA_HOME` above assumes an arm64 (Graviton/Apple Silicon) build. On amd64 it's `java-17-openjdk-amd64`.

**Multi-stage builds** compile in a fat image and copy only artifacts into a slim runtime image (e.g. build
wheels or a Scala JAR, then copy it). `.dockerignore` keeps `data/`, `.git`, `.venv` out of the build context.

## 3. Essential commands (beyond the basics)

```bash
docker build -t etl:1.4.0 .
docker run --rm -it -v "$PWD/data:/data" -e ENV=dev --memory 4g --cpus 2 etl:1.4.0 --date 2025-03-01
docker exec -it <container> bash          # shell into a running container
docker logs -f <container>
docker stats                              # live CPU/mem per container
docker image history etl:1.4.0            # layer sizes → find bloat
docker inspect <container> | jq '.[0].State'   # exit code, OOMKilled flag
docker system df && docker system prune   # disk cleanup
docker buildx build --platform linux/arm64,linux/amd64 -t repo/etl:1.4.0 --push .   # multi-arch
```

## 4. Docker Compose: a local data platform in one file

```yaml
# docker-compose.yml — Kafka (KRaft) + Postgres + PySpark notebook
services:
  kafka:
    image: apache/kafka:3.8.0
    ports: ["29092:29092"]
    environment:
      KAFKA_NODE_ID: 1
      KAFKA_PROCESS_ROLES: broker,controller
      KAFKA_LISTENERS: PLAINTEXT://0.0.0.0:9092,CONTROLLER://0.0.0.0:9093,EXTERNAL://0.0.0.0:29092
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:9092,EXTERNAL://localhost:29092
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: CONTROLLER:PLAINTEXT,PLAINTEXT:PLAINTEXT,EXTERNAL:PLAINTEXT
      KAFKA_CONTROLLER_LISTENER_NAMES: CONTROLLER
      KAFKA_CONTROLLER_QUORUM_VOTERS: 1@kafka:9093
      KAFKA_INTER_BROKER_LISTENER_NAME: PLAINTEXT
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
      KAFKA_TRANSACTION_STATE_LOG_REPLICATION_FACTOR: 1
      KAFKA_TRANSACTION_STATE_LOG_MIN_ISR: 1

  postgres:
    image: postgres:16
    environment:
      POSTGRES_USER: de
      POSTGRES_PASSWORD: de
      POSTGRES_DB: warehouse
    ports: ["5432:5432"]
    volumes: ["pgdata:/var/lib/postgresql/data"]
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U de"]
      interval: 5s
      retries: 10

  spark:
    image: quay.io/jupyter/pyspark-notebook:latest
    ports: ["8888:8888", "4040:4040"]
    volumes: ["./notebooks:/home/jovyan/work", "./data:/home/jovyan/data"]
    depends_on:
      postgres:
        condition: service_healthy
      kafka:
        condition: service_started

volumes:
  pgdata:
```

```bash
docker compose up -d
docker compose ps
docker compose logs -f kafka
docker compose exec kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server kafka:9092 --create --topic orders --partitions 3
docker compose down            # keep volumes;  `down -v` deletes them
```

Key ideas: services find each other by **service name** on the compose network (`kafka:9092` inside,
`localhost:29092` from your laptop — that's why Kafka needs two advertised listeners). **Named volumes**
persist data across restarts. **Health checks + `depends_on: condition`** order startup.

## 5. Push to Amazon ECR (replaces Docker Hub)

```bash
REGION=ap-south-1; ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REPO=$ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com/bigdata/etl

aws ecr create-repository --repository-name bigdata/etl \
  --image-scanning-configuration scanOnPush=true --image-tag-mutability IMMUTABLE
aws ecr get-login-password --region $REGION | docker login --username AWS --password-stdin ${REPO%%/*}
docker buildx build --platform linux/arm64 -t $REPO:1.4.0 --push .
aws ecr describe-images --repository-name bigdata/etl
```

Production practices: **immutable tags** (never overwrite `1.4.0`), scan on push (or Amazon Inspector),
lifecycle policies to expire untagged images, pull through **VPC endpoints**, and reference images by digest
in deployments.

## 6. Where data teams use containers on AWS

| Use | How |
|---|---|
| **EMR Serverless custom image** | `FROM public.ecr.aws/emr-serverless/spark/emr-7.5.0:latest`, add Python libs/JARs, push to ECR, set `--image-configuration` on the application |
| **EMR on EKS** | custom images derived from the EMR on EKS base images; Spark driver/executors run as pods |
| **MWAA / Airflow** | local runner image to test DAGs; KubernetesPodOperator / ECS operator run tasks in your image |
| **AWS Batch / ECS Fargate** | containerized Python ETL jobs without managing servers |
| **Glue local development** | AWS publishes Glue images (`public.ecr.aws/glue/aws-glue-libs`) to run Glue jobs locally |
| **CI** | build image once → run unit tests and data tests inside it → push → deploy the same digest |

```dockerfile
# EMR Serverless custom image
FROM public.ecr.aws/emr-serverless/spark/emr-7.5.0:latest
USER root
RUN pip3 install --no-cache-dir great-expectations==1.* pyarrow
USER hadoop:hadoop
```

(The ECR repository policy must allow `emr-serverless.amazonaws.com` to pull: `ecr:BatchGetImage`,
`ecr:GetDownloadUrlForLayer`, `ecr:DescribeImages`.)

## Key takeaways

- Containers = namespaces (isolation) + cgroups (limits) + layered filesystem, sharing the host kernel.
- Image = immutable layered template; container = running instance + writable layer.
- Order Dockerfile layers by change frequency; copy dependency files before code; use slim/multi-stage images; run as non-root.
- Compose gives a reproducible local data stack; services talk by service name; volumes persist state.
- On AWS: push to ECR (immutable tags, scanning) and use images on EMR Serverless, EMR on EKS, ECS/Batch, and Airflow.

## Interview scenarios

1. *Explaining why Docker beats a VM for our ETL jobs:* "Each job needs specific Java, Python, and library
   versions. A container image bundles exactly those, starts in seconds, and runs the same on a laptop, in CI,
   and on AWS. VMs take minutes to boot, are 10× bigger, and drift over time."
2. *A container is killed with exit code 137.* — out-of-memory kill by cgroups (`OOMKilled: true` in `docker
   inspect`). Raise the memory limit or reduce usage. Same root cause as a YARN container kill.
3. *Every code change triggers a 10-minute `pip install` in CI.* — dependencies are installed after `COPY . .`, so any
   change invalidates the cache. Copy `requirements.txt` first, install, then copy the code.
4. *Kafka in compose works from other containers but not from your laptop (or vice versa).* — advertised listeners.
   Advertise `kafka:9092` for the internal network and `localhost:29092` for the host.
