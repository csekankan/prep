# 25 — PySpark Deep Dive: Architecture, Code Patterns, Mini Project

> **Why it matters:** Spark is written in Scala and runs on the JVM. PySpark is a Python front end to it.
> Knowing exactly **where your Python code runs** (driver only? executors too?), **when data crosses the
> Python ↔ JVM boundary**, and what that costs explains why one PySpark job runs as fast as Scala and
> another is 10× slower. Read this after module 13. Modules 08–15 cover general Spark; this one is PySpark-specific.

## In plain words

PySpark is a **Python remote control for a JVM engine**. When you write `df.groupBy("city").count()`, Python
doesn't process any rows. It sends instructions to the JVM, and the JVM does all the work. Python only gets
involved with the actual data when **you** force it: a Python UDF, `rdd.map(lambda ...)`, or `toPandas()`.
Every time that happens, rows have to be packed, shipped to a Python process, and unpacked again.

## 1. Architecture at a glance — classic PySpark

```mermaid
flowchart TB
  subgraph DRIVER["Driver machine"]
    PY["Python process<br/>your script, pyspark API<br/>(DataFrame = thin wrapper)"]
    JVMD["Driver JVM<br/>SparkSession, Catalyst,<br/>DAGScheduler, TaskScheduler"]
    PY <-->|"Py4J gateway<br/>(method calls over a local socket)"| JVMD
  end
  subgraph EX1["Executor (YARN container / pod)"]
    JVME["Executor JVM<br/>task threads, Tungsten rows,<br/>shuffle, cache"]
    PW["Python worker processes<br/>(pyspark.daemon forks)<br/>ONLY for Python UDFs / RDD lambdas"]
    JVME <-->|"local socket:<br/>pickle rows or Arrow batches"| PW
  end
  subgraph EX2["Executor"]
    JVME2[Executor JVM]
  end
  JVMD -->|serialized tasks| JVME & JVME2
  JVME <-->|shuffle| JVME2
```

**How to read it:**

1. **Driver side:** your Python script calls PySpark APIs, and each call becomes a **Py4J** call into the driver
   JVM. A DataFrame in Python is just a handle to a JVM object. The plan is built, optimized, and scheduled entirely in the JVM.
2. **Executor side:** for pure DataFrame/SQL code, executors are **only JVMs**, so there's no Python at all. Speed is equal to Scala.
3. **Python workers** start on executors only when a task needs Python: Python UDFs, pandas UDFs,
   `rdd.map(lambda)`, `foreachPartition` with Python functions. Rows then stream between the JVM and Python over a local socket.

## 2. Where does each line of my code run?

| Code | Runs in | Data crosses into Python? |
|---|---|---|
| `spark.read.parquet(...)`, `select`, `filter`, `join`, `groupBy().agg`, `F.*` functions, SQL | executor JVMs | **no** |
| `df.collect()`, `df.toPandas()`, `df.take(5)` | executors compute, results sent to **driver Python** | yes, to the driver only (memory risk) |
| `@F.udf` Python UDF | executor Python workers | yes, row-by-row pickle |
| `@pandas_udf`, `applyInPandas`, `mapInPandas` | executor Python workers | yes, Arrow columnar batches (much cheaper) |
| `df.rdd.map(lambda ...)` | executor Python workers | yes, everything is pickled, and the optimizer is bypassed |
| plain Python outside Spark calls (`for`, `requests.get`) | driver Python only | n/a |

**Rule:** keep the data in the JVM. Use built-ins first, a pandas UDF if you must, a plain UDF last, and RDD lambdas almost never.

## 3. The cost of crossing the boundary

```mermaid
flowchart LR
  subgraph JVM["Executor JVM"]
    R[Tungsten binary rows]
  end
  subgraph PYW["Python worker"]
    F[your function]
  end
  R -->|"1. convert to Java objects<br/>2. pickle / Arrow-encode<br/>3. socket write"| F
  F -->|"4. unpickle / decode<br/>5. run Python<br/>6. encode result back"| R
```

| Path | Serialization | Typical relative cost |
|---|---|---|
| Built-in functions | none | 1× |
| pandas UDF (Arrow) | columnar batches (`spark.sql.execution.arrow.maxRecordsPerBatch` = 10,000) | ~1.5–3× |
| Arrow-optimized Python UDF (`@udf(useArrow=True)`, Spark 3.5+) | Arrow batches, row-wise function | ~2–4× |
| Classic Python UDF | pickle per row, with batching | ~3–10× |
| RDD lambdas | pickle everything, no Catalyst | worst |

Python UDFs are also **opaque to Catalyst**: no predicate pushdown through them, no constant folding, no
code generation. A filter on a UDF result can't be pushed into the Parquet reader.

### Memory: PySpark adds a third consumer

```
 YARN container = executor heap (spark.executor.memory)
                + memoryOverhead (JVM off-heap, Arrow buffers, AND Python worker processes)
                + spark.executor.pyspark.memory (optional explicit cap for Python workers)
```

Python workers live **outside the JVM heap**. Heavy pandas UDFs → "container killed for exceeding memory"
even when the heap looks fine. Fix with a bigger `memoryOverhead` or `spark.executor.pyspark.memory`,
smaller Arrow batches, or fewer cores per executor (one Python worker per concurrently running task).

## 4. Execution flow of a PySpark job (cluster mode on YARN / EMR)

```mermaid
sequenceDiagram
  participant SUB as spark-submit job.py
  participant AM as YARN AM container
  participant DJ as Driver JVM (in AM)
  participant DP as Driver Python
  participant EJ as Executor JVMs
  participant EP as Executor Python workers
  SUB->>AM: launch app (job.py shipped to staging)
  AM->>DJ: start driver JVM (PythonRunner)
  DJ->>DP: start python job.py with Py4J gateway
  DP->>DJ: build DataFrame plan via Py4J calls
  DP->>DJ: action, e.g. write()
  DJ->>DJ: Catalyst optimize, split into stages
  DJ->>EJ: launch tasks
  EJ->>EP: only if plan contains Python UDFs
  EP-->>EJ: UDF results
  EJ-->>DJ: task status
  DJ-->>DP: action returns
```

## 5. Spark Connect — the modern client/server architecture (Spark 3.4+)

```mermaid
flowchart LR
  subgraph CLIENT["Thin client (laptop, app, notebook)"]
    PC["pyspark client<br/>(pip install pyspark[connect])<br/>no JVM needed"]
  end
  subgraph SERVER["Spark cluster"]
    SCS["Spark Connect server<br/>gRPC :15002<br/>(inside the driver)"]
    DRV[Driver: Catalyst + scheduler]
    EXE[Executors]
  end
  PC -->|"unresolved logical plan<br/>(protobuf over gRPC)"| SCS --> DRV --> EXE
  SCS -->|results as Arrow batches| PC
```

| | Classic PySpark | Spark Connect |
|---|---|---|
| Client needs a JVM | yes (Py4J driver) | no: gRPC only |
| Driver lives in | your Python process's JVM | the cluster |
| Client crash | kills the application | session survives on server; client reconnects |
| API | DataFrame + RDD + SparkContext | DataFrame/SQL only (**no RDD, no SparkContext**) |
| Use | batch jobs, legacy code | notebooks/IDEs against remote clusters, multi-tenant apps (Databricks Connect and serverless use this model) |

```python
from pyspark.sql import SparkSession
spark = SparkSession.builder.remote("sc://spark-connect.internal:15002").getOrCreate()
spark.range(10).selectExpr("sum(id)").show()      # plan runs remotely; result arrives as Arrow
```

## 6. Code patterns (short, one idea each)

### Session and config

```python
from pyspark.sql import SparkSession, functions as F, Window
spark = (SparkSession.builder.appName("demo")
         .config("spark.sql.session.timeZone", "UTC")
         .config("spark.sql.execution.arrow.pyspark.enabled", "true")
         .getOrCreate())
```

### Read with a schema (no inference job)

```python
orders = spark.read.schema("order_id STRING, cust STRING, amount DECIMAL(10,2), ts TIMESTAMP") \
                   .option("header", True).csv("s3://bucket/raw/orders/")
```

### Transform with built-ins only

```python
clean = (orders.dropDuplicates(["order_id"])
               .where(F.col("amount") > 0)
               .withColumn("dt", F.to_date("ts")))
```

### Join with a broadcast dimension

```python
enriched = clean.join(F.broadcast(spark.table("dim.customers")), "cust", "left")
```

### Window: top order per customer

```python
w = Window.partitionBy("cust").orderBy(F.desc("amount"))
top = clean.withColumn("rn", F.row_number().over(w)).where("rn = 1")
```

### Built-in vs UDF vs pandas UDF (same logic)

```python
from pyspark.sql.functions import udf, pandas_udf
import pandas as pd

fast = clean.withColumn("tax", F.col("amount") * 0.18)                    # 1. built-in: stays in JVM

@udf("double")
def tax_udf(a): return float(a) * 0.18 if a is not None else None         # 3. row-by-row pickle

@pandas_udf("double")
def tax_pudf(a: pd.Series) -> pd.Series: return a.astype(float) * 0.18    # 2. Arrow batches
```

### Iterator pandas UDF: expensive setup once per partition (e.g. load a model)

```python
from typing import Iterator

@pandas_udf("double")
def score(batches: Iterator[pd.Series]) -> Iterator[pd.Series]:
    model = load_model()                       # once per task, not per batch or row
    for amounts in batches:
        yield pd.Series(model.predict(amounts.to_frame()))
```

### Grouped map: arbitrary pandas logic per group

```python
def zscore(pdf: pd.DataFrame) -> pd.DataFrame:
    a = pdf["amount"].astype(float)
    return pdf.assign(z=(a - a.mean()) / (a.std() or 1.0))

scored = clean.groupBy("cust").applyInPandas(
    zscore, schema="order_id string, cust string, amount decimal(10,2), ts timestamp, dt date, z double")
```

Every group is shipped to one Python worker as a single pandas DataFrame, so a huge group (skew) can blow memory.

### Write partitioned, idempotent

```python
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
clean.repartition("dt").write.mode("overwrite").partitionBy("dt").parquet("s3://bucket/silver/orders/")
```

### Inspect the plan (where's the Python?)

```python
scored.explain()     # look for BatchEvalPython (classic UDF), ArrowEvalPython (pandas UDF),
                     # FlatMapGroupsInPandas (applyInPandas): each is a JVM↔Python boundary
```

### Unit test with a local session

```python
import pytest
@pytest.fixture(scope="session")
def spark():
    return SparkSession.builder.master("local[2]").appName("tests").getOrCreate()

def test_dedupe(spark):
    df = spark.createDataFrame([("o1", 1), ("o1", 1), ("o2", 2)], "order_id string, v int")
    assert df.dropDuplicates(["order_id"]).count() == 2
```

## 7. Mini project — clickstream sessionization & funnel on EMR Serverless

**Goal:** from raw click events, build user sessions (a new session after 30 minutes of inactivity) and a
daily funnel (view → add_to_cart → purchase). No external dataset needed: the job generates its own events
with `spark.range`, so you can run it anywhere.

### Architecture

```mermaid
flowchart LR
  GEN["Generate events<br/>spark.range → 5M clicks"] --> RAW[(S3 bronze/clicks/<br/>partitioned by dt)]
  RAW --> SESS["Sessionize<br/>lag() + 30-min gap<br/>+ running sum = session_id"]
  SESS --> S1[(S3 silver/sessions/)]
  SESS --> FUN["Funnel per day<br/>conditional aggregation"]
  FUN --> G1[(S3 gold/funnel_daily/)]
  G1 --> ATH[Athena / QuickSight]
  subgraph RUN["Runs on"]
    EMRS["EMR Serverless application<br/>or local[*] for testing"]
  end
```

### Sessionization logic (the concept)

```
 user u1 events ordered by ts:   09:00  09:10  09:25  10:30  10:35
 gap from previous (min):          -     10     15     65      5
 new_session = gap > 30 ?          1      0      0      1      0
 running sum  = session number:    1      1      1      2      2   → session_id = u1-1, u1-2
```

Window per user ordered by time → `lag` gives the previous timestamp → flag gaps → **running sum of flags**
gives a session number. Everything stays in the JVM (no UDFs). The only shuffle is partitioning by `user_id` for the window.

### Code

```python
# clickstream_job.py — spark-submit clickstream_job.py <base_s3_path> [n_events]
import sys
from pyspark.sql import SparkSession, functions as F, Window

base, n = sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 5_000_000
spark = (SparkSession.builder.appName("clickstream-sessions")
         .config("spark.sql.session.timeZone", "UTC")
         .config("spark.sql.sources.partitionOverwriteMode", "dynamic").getOrCreate())

# 1) Generate synthetic events (bronze)
events = (spark.range(n)
  .withColumn("user_id", (F.rand(1) * 50_000).cast("int"))
  .withColumn("ts", (F.lit(1735689600) + F.rand(2) * 7 * 86400).cast("timestamp"))  # 7 days from 2025-01-01
  .withColumn("event", F.expr("""CASE WHEN rand(3) < 0.70 THEN 'view'
                                      WHEN rand(3) < 0.93 THEN 'add_to_cart' ELSE 'purchase' END"""))
  .withColumn("dt", F.to_date("ts")).drop("id"))
events.repartition("dt").write.mode("overwrite").partitionBy("dt").parquet(f"{base}/bronze/clicks/")

# 2) Sessionize (silver)
clicks = spark.read.parquet(f"{base}/bronze/clicks/")
w = Window.partitionBy("user_id").orderBy("ts")
sessions = (clicks
  .withColumn("prev_ts", F.lag("ts").over(w))
  .withColumn("gap_min", (F.col("ts").cast("long") - F.col("prev_ts").cast("long")) / 60)
  .withColumn("new_session", F.when(F.col("prev_ts").isNull() | (F.col("gap_min") > 30), 1).otherwise(0))
  .withColumn("session_no", F.sum("new_session").over(w.rowsBetween(Window.unboundedPreceding, 0)))
  .withColumn("session_id", F.concat_ws("-", "user_id", "session_no")))

session_summary = sessions.groupBy("session_id", "user_id").agg(
    F.min("ts").alias("start_ts"), F.max("ts").alias("end_ts"), F.count("*").alias("events"),
    F.max(F.col("event") == "add_to_cart").alias("carted"),
    F.max(F.col("event") == "purchase").alias("purchased")
).withColumn("dt", F.to_date("start_ts"))
session_summary.repartition("dt").write.mode("overwrite").partitionBy("dt").parquet(f"{base}/silver/sessions/")

# 3) Daily funnel (gold)
funnel = (spark.read.parquet(f"{base}/silver/sessions/").groupBy("dt").agg(
    F.count("*").alias("sessions"),
    F.sum(F.col("carted").cast("int")).alias("cart_sessions"),
    F.sum(F.col("purchased").cast("int")).alias("purchase_sessions"))
  .withColumn("cart_rate", F.round(F.col("cart_sessions") / F.col("sessions"), 4))
  .withColumn("conversion", F.round(F.col("purchase_sessions") / F.col("sessions"), 4)))
funnel.coalesce(1).write.mode("overwrite").parquet(f"{base}/gold/funnel_daily/")
funnel.orderBy("dt").show()
spark.stop()
```

### Run it

```bash
# local test (pip install pyspark; needs Java 17)
spark-submit --master "local[4]" clickstream_job.py /tmp/clicks 200000

# EMR Serverless
aws s3 cp clickstream_job.py s3://$BUCKET/code/
aws emr-serverless start-job-run --application-id $APP_ID --execution-role-arn $ROLE_ARN \
  --job-driver '{"sparkSubmit":{"entryPoint":"s3://'$BUCKET'/code/clickstream_job.py",
                 "entryPointArguments":["s3://'$BUCKET'/clickstream","5000000"]}}'
```

### What to observe (ties the concepts together)

| Check | Where | Expected |
|---|---|---|
| No Python on executors | `explain()` has no `*EvalPython` nodes | pure JVM speed |
| One shuffle for sessionization | SQL tab: `Exchange hashpartitioning(user_id)` before `Window` | window needs all of a user's events together |
| Partition pruning in gold reads | `PartitionFilters` when querying one `dt` | only that day is read |
| Skew risk | stage task-time summary | bot users with millions of events → one slow window task; filter bots first |
| Rewrite with a Python UDF for gap logic | compare stage time | noticeably slower: proves the boundary cost |

## Key takeaways

- PySpark = Python API → Py4J → driver JVM. DataFrame/SQL work runs entirely in executor JVMs.
- Python workers on executors appear only for UDFs, pandas UDFs, and RDD lambdas, and data crosses via pickle or Arrow.
- Prefer built-ins > pandas/Arrow UDFs > classic UDFs > RDD lambdas. UDFs are also opaque to the optimizer.
- Python workers consume memoryOverhead (or `pyspark.memory`), not the heap, which is a common source of YARN kills.
- Spark Connect separates a thin Python client (gRPC, no JVM) from the driver on the cluster; DataFrame API only.
- `explain()` shows boundaries: `BatchEvalPython`, `ArrowEvalPython`, `FlatMapGroupsInPandas`.

## Interview scenarios

1. *Is PySpark slower than Scala Spark?* — for DataFrame/SQL code, no: the same JVM plan runs. It's slower only
   when Python UDFs or RDD lambdas force data into Python workers.
2. *Where does `df.filter(F.col("x") > 5)` execute?* — in executor JVMs, as generated code. Python only sent the plan via Py4J.
3. *A pandas UDF job gets YARN memory kills but heap usage is low.* — Python workers and Arrow buffers live in
   overhead memory. Raise `memoryOverhead`/`pyspark.memory`, lower `arrow.maxRecordsPerBatch`, or use fewer cores per executor.
4. *What changes with Spark Connect?* — the client sends unresolved plans over gRPC and gets Arrow results; no local
   JVM; driver failures are isolated from the client; RDD/SparkContext APIs aren't available.
5. *How do you sessionize clickstream data without a UDF?* — window by user ordered by time, `lag` for the previous
   timestamp, flag gaps over the threshold, running `sum` of flags = session number.
