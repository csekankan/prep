# Syllabus Coverage Matrix

Every lecture and exercise from the original 34-section syllabus, mapped to where this course covers it.

**Status values:**
- **Covered**: same topic, explained in depth.
- **AWS**: the GCP/Azure/Confluent/Docker Hub/Astro Cloud version is replaced with the AWS equivalent.
- **Skipped (basic)**: basic SQL/Python, excluded by request. Only the advanced, big-data-relevant parts are kept (module 07).
- **Skipped (platform)**: Udemy navigation or resource-download lectures with no technical content.

Module references use the file number, e.g. `04 §7` = [04_aws_emr_cluster_lab.md](04_aws_emr_cluster_lab.md), section 7.

## Summary

| Syllabus block | Result | Modules |
|---|---|---|
| Course intro | covered (Udemy navigation skipped) | README, 01 |
| MySQL basics, DML, constraints | skipped (basic) | — |
| Python fundamentals + SQLite | basics skipped; lambdas, map/filter/reduce, iterators, generators, decorators, pandas kept in depth | 07, 25 |
| Big data intro | all covered | 01 |
| Hadoop, HDFS, failures, HA, read/write | all covered | 02, 03 |
| GCP cluster, Linux + HDFS commands | all replaced with EMR | 04 |
| MapReduce, YARN | all covered | 05, 06 |
| Higher-order functions | all covered | 07 |
| Spark intro, RDDs, DataFrames, SQL/tables, caching, architecture | all covered | 08–13, 25 |
| Spark projects | all covered (Dataproc → S3/EMR/Athena) | 15 |
| Hive | all covered (+ Athena) | 16 |
| Kafka | all covered (Confluent → MSK, + Kinesis) | 17 |
| Docker | all covered (Docker Hub → ECR) | 18 |
| Airflow + ETL project | all covered (Astro Cloud → MWAA) | 19, 20 |
| Databricks | all covered (Databricks on AWS + Delta) | 21 |
| Azure intro + Azure end-to-end project | all replaced with AWS (resource-download lecture skipped) | 22, 23 |

## 1. Course intro

| Lecture | Status | Where |
|---|---|---|
| Course overview, what a big data engineer does & the roadmap | Covered | README roadmap; `01 §8` |
| How to complete the course and Udemy platform overview | Skipped (platform) | — |

## 2. MySQL (sections: basic operations, DML & alter, constraints)

| Lecture / exercise | Status | Where |
|---|---|---|
| Create/drop database and table; exercises | Skipped (basic) | — |
| NULL, UPDATE, DELETE; ALTER TABLE; data manipulation practice; modify Employees table | Skipped (basic) | — |
| Constraints: PK, FK, UNIQUE, NOT NULL, DEFAULT, INDEX, candidate keys; more MySQL videos; constrained schema design | Skipped (basic) | relational modeling for analytics is in `01 §6` (star schema, SCD) and `22 §5` (Redshift dist/sort keys) |
| SQL section intro; basic-to-intermediate MySQL tutorials | Skipped (basic) | — |

## 3. Python fundamentals and Python with databases

| Lecture / exercise | Status | Where |
|---|---|---|
| Getting started, Anaconda/VS Code, syntax, variables, data types, operators, conditionals, loops | Skipped (basic) | — |
| Lists, sets, tuples, dictionaries, functions, function examples | Skipped (basic) | — |
| Lambda functions | Covered | `07 §1` (lambdas: when to use them) |
| Map function | Covered | `07 §1` |
| Filter function | Covered | `07 §1` |
| Modules/packages, standard library | Covered (advanced part) | `07 §7` packaging Python dependencies for a cluster |
| File operations, file paths | Skipped (basic) | large-file streaming covered in `07 §3` |
| Exception handling, custom exceptions | Skipped (basic) | retry decorator `07 §4` |
| OOP, inheritance, polymorphism, encapsulation, abstraction, magic methods, operator overloading | Skipped (basic) | closures/`self` serialization traps in `07 §2` |
| Iterators | Covered | `07 §3` |
| Generators | Covered | `07 §3` (`mapPartitions` contract) |
| Decorators | Covered | `07 §4` |
| NumPy | Skipped (basic) | — |
| pandas DataFrame & Series; data manipulation; data source reading | Covered (advanced part) | `07 §6` pandas vs PySpark; `25 §6` pandas UDFs |
| Exercises: student records processor; mentoring a beginner's OOP bug | Skipped (basic) | — |
| Python with SQLite; product inventory manager (SQLite) | Skipped (basic) | Python ↔ DB loading in `23 §3` (RDS via SQLAlchemy) and `20 §2` (PostgresHook) |

## 4. Introduction to big data

| Lecture / exercise | Status | Where |
|---|---|---|
| Section intro; what is big data, a practical example | Covered | `01 §1` |
| 5 V's of big data | Covered | `01 §2` |
| Big data and distributed systems | Covered | `01 §3` |
| Designing a good big data system | Covered | `01 §4` |
| On-premise infra vs cloud solutions | Covered | `01 §5` |
| Database vs data warehouse vs data lake | Covered | `01 §6` (+ lakehouse) |
| ETL vs ELT | Covered | `01 §7` |
| What a data engineer does & where big data fits | Covered | `01 §8` |
| Exercise: map big data fundamentals to a real business scenario | Covered | `01 §9` |
| Exercise: explain big data fundamentals to a non-technical stakeholder | Covered | `01 §9`; `24 §6` |

## 5. Hadoop

| Lecture / exercise | Status | Where |
|---|---|---|
| Section intro; introduction to Hadoop | Covered | `02 §1` |
| Properties of Hadoop | Covered | `02 §1` |
| Hadoop ecosystem: main components; components | Covered | `02 §2` (+ AWS equivalents) |
| Quiz | Covered | `02` interview scenarios |
| Exercise: map an e-commerce company's needs to Hadoop components | Covered | `02` interview scenario 5 |
| Exercise: explain Hadoop's core components to a new team member | Covered | `02` interview scenario 4; `24 §6` |

## 6. HDFS

| Lecture / exercise | Status | Where |
|---|---|---|
| Intro to HDFS and common terminology | Covered | `02 §3` |
| Why HDFS | Covered | `02 §4` |
| HDFS architecture | Covered | `02` architecture diagram |
| Blocks in HDFS | Covered | `02 §5` |
| Replication factor | Covered | `02 §6` (+ erasure coding) |
| Rack awareness | Covered | `02 §7` |
| Node failure | Covered | `03 §3` |
| Read before starting GCP & Dataproc — 2026 setup guide | AWS | `04 §1–2` |
| Create GCP account | AWS | `04 §2` (AWS account, IAM Identity Center, budget) |
| Exercise: HDFS architecture, blocks & fault tolerance | Covered | `02` interview scenarios |
| Exercise: HDFS block calculations & fault tolerance design | Covered | `02 §5` block + NameNode memory math; `03 §3` re-replication math |
| Exercise: cracking the HDFS interview round | Covered | `02`, `03` interview scenarios; `24 §5` |
| DataNode failure — temporary | Covered | `03 §3` |
| DataNode failure — permanent | Covered | `03 §3` |
| Secondary NameNode | Covered | `03 §2` |
| Standby NameNode | Covered | `03 §4` |
| Hadoop HA architecture | Covered | `03` architecture + `03 §4` (QJM, ZKFC, fencing) |
| Data write in HDFS | Covered | `03 §5` |
| Read request in HDFS | Covered | `03 §6` |
| Exercise: HDFS failure handling & high availability | Covered | `03` interview scenarios |
| Exercise: diagnosing HDFS failures & tracing the write/read flow | Covered | `03 §7` |
| Exercise: explaining a live NameNode outage | Covered | `03 §8` |

## 7. Hadoop cluster (GCP → AWS EMR), Linux and HDFS commands

| Lecture / exercise | Status | Where |
|---|---|---|
| GCP Hadoop cluster creation | AWS | `04 §3–4` EMR cluster |
| Exploring our Hadoop cluster | AWS | `04 §5` |
| GCP cluster best practices | AWS | `04 §10` EMR best practices |
| Linux commands 1 & 2 | Covered | `04 §6` |
| HDFS commands | Covered | `04 §7` |
| Hadoop outro | Covered | `02`/`03` key takeaways |
| Exercise: GCP cluster & command-line essentials | AWS | `04 §4–7` (+ lab exercise in `04 §7`) |
| Exercise: cluster setup & HDFS command practice | AWS | `04 §7` lab exercise |
| Exercise: reviewing a new hire's first cluster setup | AWS | `04` interview scenario 3 |

## 8. MapReduce

| Lecture / exercise | Status | Where |
|---|---|---|
| MapReduce intro | Covered | `05` architecture |
| Intro to distributed processing | Covered | `05 §1` |
| MapReduce introduction | Covered | `05 §1–2` |
| MapReduce & cluster | Covered | `05 §3–4` (locality, speculation, fault tolerance); `06 §6` |
| MR practical part 1; MR example part 2 | Covered | `05 §5` (Hadoop Streaming on EMR) |
| MR practical with 1 reducer | Covered | `05 §2.6`, `05 §5` experiments |
| MR with 2 reducers practical | Covered | `05 §5` |
| Combiner in MR | Covered | `05 §2.5` (with shuffle-size math) |
| MapReduce with 0 reducers | Covered | `05 §2.6`, `05 §5` |
| MR on a big log file | Covered | `05 §5` log-file analytics |
| Input split in MR | Covered | `05 §2.1` |
| MapReduce outro | Covered | `05 §6` limitations |
| Exercise: MapReduce fundamentals & execution | Covered | `05` interview scenarios |
| Exercise: designing a MapReduce job — reducers, combiners, input splits | Covered | `05` interview scenario 4 |
| Exercise: debugging a slow MapReduce job | Covered | `05` interview scenarios 1 & 5 |

## 9. YARN

| Lecture / exercise | Status | Where |
|---|---|---|
| YARN section intro; YARN introduction | Covered | `06 §1` |
| Components of YARN | Covered | `06 §2` |
| YARN analogy | Covered | `06` in plain words; `06 §6` |
| YARN process step by step | Covered | `06 §3` |
| Exercise: YARN architecture & components | Covered | `06` interview scenarios |
| Exercise: tracing the YARN job execution flow | Covered | `06 §3`; interview scenario 2 |
| Final exercise: explaining YARN to a MapReduce-only engineer | Covered | `06` interview scenario 1 |

## 10. Higher-order functions (pre-Spark)

| Lecture / exercise | Status | Where |
|---|---|---|
| Higher-order functions | Covered | `07 §1` |
| Lambda functions | Covered | `07 §1` |
| Map, filter and reduce | Covered | `07 §1` (+ associativity rule) |
| Exercise: higher-order functions, lambda, map & filter | Covered | `07` interview scenarios |

## 11. Spark introduction

| Lecture / exercise | Status | Where |
|---|---|---|
| Spark section intro; Spark introduction | Covered | `08` architecture |
| Spark common questions | Covered | `08 §2` |
| Limitations of MR | Covered | `05 §6`; `08 §1` |
| What is Spark and its features | Covered | `08 §1` (core features table) |
| Spark ecosystem | Covered | `08 §3` |
| Executing code in Spark | Covered | `08 §5`; `25 §4` |
| Word count program in Spark | Covered | `08 §5` (RDD + DataFrame) |
| Ways to run Spark | Covered | `08 §4`; `13 §6` |
| Transformation vs action | Covered | `08 §6` |
| Why is Spark lazy | Covered | `08 §7` |
| Exercise: Apache Spark fundamentals | Covered | `08` interview scenarios |
| Exercise: transformations, actions & execution behavior | Covered | `08` interview scenarios 1–2 |
| Exercise: explaining why Spark beats MapReduce | Covered | `08 §8` |

## 12. RDDs, partitioning, DataFrames intro

| Lecture / exercise | Status | Where |
|---|---|---|
| What is a Spark RDD | Covered | `09 §1` |
| How Spark reads the data | Covered | `09 §2` |
| Spark read data and partitioning | Covered | `09 §2` (with partition-count math) |
| Data generation + project steps | Covered | `09 §3` |
| Spark RDD operations parts 1 & 2 | Covered | `09 §4` |
| Transformation — narrow vs wide | Covered | `08 §6`; `09 §5` |
| Jobs, stages and tasks in the Spark UI | Covered | `09 §6`; `13 §7` |
| GroupByKey vs ReduceByKey parts 1 & 2 | Covered | `09 §7` |
| Increasing or decreasing the number of partitions | Covered | `09 §8` |
| Repartition vs coalesce | Covered | `09 §8` (coalesce trap) |
| Higher-level APIs — DataFrame | Covered | `09 §9`; `10` |
| Higher-level APIs — Spark tables | Covered | `09 §9`; `11` |
| Exercise: RDDs, partitioning & DataFrames | Covered | `09` interview scenarios |
| Exercise: RDD transformations, partitioning & DataFrames — applied questions | Covered | `09` interview scenario 4 |
| Exercise: fixing a slow groupByKey job | Covered | `09` interview scenario 1 |

## 13. Spark DataFrames

| Lecture / exercise | Status | Where |
|---|---|---|
| Spark DataFrame intro; DataFrames in Spark | Covered | `10` architecture (Catalyst + Tungsten) |
| DataFrame — reading from HDFS | Covered | `10 §1` (HDFS and S3 paths) |
| Spark read — transformation or action | Covered | `10 §2` |
| Schema enforcement in Spark | Covered | `10 §3` |
| Read modes in Spark | Covered | `10 §4` |
| Write in Spark | Covered | `10 §5` |
| Spark operations | Covered | `10 §6` |
| Handling data types in PySpark | Covered | `10 §7` |
| Handling date type | Covered | `10 §8` |
| Exercise: Spark DataFrames — read, schema & write | Covered | `10` interview scenarios |
| Exercise: read modes, schema enforcement & write behavior | Covered | `10` interview scenarios 1–4 |
| Exercise: debugging a silent data-ingestion failure | Covered | `10 §9` |

## 14. Spark SQL and tables

| Lecture / exercise | Status | Where |
|---|---|---|
| Spark SQL intro; Spark tables | Covered | `11` architecture; `11 §1` |
| Spark table — temporary | Covered | `11 §1` |
| Spark table — global temporary | Covered | `11 §1` |
| Spark tables — persistent table | Covered | `11 §1–3` (+ Glue Data Catalog) |
| Spark SQL | Covered | `11 §4` |
| Spark — managed vs external table | Covered | `11 §2` |
| Spark creating DataFrame | Covered | `11 §4` (creating DataFrames) |
| Exercise: Spark tables & Spark SQL | Covered | `11` interview scenarios |
| Exercise: choosing the right Spark table type | Covered | `11 §5` |
| Exercise: explaining why a table disappeared | Covered | `11 §6` |

## 15. Spark caching

| Lecture / exercise | Status | Where |
|---|---|---|
| Spark caching intro; introduction to persist and caching | Covered | `12` architecture (unified memory) |
| Difference between persist and caching | Covered | `12 §1` |
| Common questions about caching | Covered | `12 §2` |
| RDD caching — small file | Covered | `12 §4` experiments table |
| RDD caching — big file | Covered | `12 §4` |
| Caching DF in Spark | Covered | `12 §4` |
| Caching DF — large file parts 1 & 2 | Covered | `12 §4` |
| Spark table caching | Covered | `12 §5` |
| Exercise: Spark caching & persistence | Covered | `12` interview scenarios |
| Exercise: when and how to cache — applied scenarios | Covered | `12 §3`; interview scenarios |
| Exercise: should we cache this dataset? | Covered | `12 §7` |

## 16. Spark architecture and deployment

| Lecture / exercise | Status | Where |
|---|---|---|
| Spark architecture intro; run mode | Covered | `13 §2` |
| Spark's distributed nature and in-memory computation | Covered | `13 §1` |
| Spark architecture and components | Covered | `13` architecture + `13 §1`; PySpark specifics `25 §1` |
| Spark on a standalone cluster | Covered | `13 §2` |
| YARN revision — components; step-by-step process | Covered | `06 §2–3` |
| YARN on Spark architecture + UI | Covered | `13 §3`, `13 §7` |
| Difference between standalone and YARN | Covered | `13 §2` |
| Deployment modes in Spark | Covered | `13 §4` |
| Exercise: Spark architecture & deployment modes | Covered | `13` interview scenarios |
| Exercise: choosing Spark's cluster manager & deployment mode | Covered | `13` interview scenario 2 |
| Exercise: picking the right deployment mode | Covered | `13 §4`; interview scenario 4 |

## 17. Spark projects (Dataproc → EMR / S3 / Athena)

| Lecture | Status | Where |
|---|---|---|
| Spark projects intro | Covered | `15` architecture |
| Read data | Covered | `15 §0` warm-up |
| Process customer data | Covered | `15 §0` |
| Actionable insight from customer and order dataset | Covered | `15 §0` (4 insights) |
| Anatomy of the project — real e-commerce dataset | Covered | `15 §1` (ER diagram + gotchas) |
| Exploration and understanding of data | Covered | `15 §3` |
| Data ingestion into Dataproc cluster | AWS | `15 §2` (S3 + Glue databases) |
| Data exploration 1 & 2 | Covered | `15 §3` |
| Module 2 — data cleaning and transformation (intro + full lecture) | Covered | `15 §4` |
| Module 3 — data integration and aggregation | Covered | `15 §5` |
| Data integration — joining all datasets | Covered | `15 §5` (aggregate to grain, then join) |
| Optimized joins, aggregation and window functions | Covered | `15 §5`, `15 §7` |
| Advanced data aggregations | Covered | `15 §5` (`cube`, `lag`-based MoM growth, repeat-purchase gap) |
| Advanced enrichment | Covered | `15 §5` advanced enrichment (haversine distance, RFM) |
| Module 4 — Spark configuration optimization | Covered | `15 §7`; `13 §5`; `14 §6` |
| Join optimization strategies | Covered | `14 §1–2`; `15 §7` |
| Data serving layer | AWS | `15 §8` (Glue Catalog + Athena + QuickSight) |

## 18. Hive

| Lecture / exercise | Status | Where |
|---|---|---|
| Hive intro; introduction to Hive | Covered | `16 §1` |
| How Hive makes big data processing easier | Covered | `16 §1` |
| Common questions/misconceptions about Hive | Covered | `16 §2` |
| Hive practical — connecting via terminal and Beeline | Covered | `16 §5` (on EMR) |
| Hive practical 2 — creating and querying a table | Covered | `16 §5` |
| Accessing metadata in Hive (both versions) | Covered | `16 §4` (Hive + Glue CLI) |
| Hive architecture & components | Covered | `16` architecture |
| Hive query flow | Covered | `16 §3` |
| Derby DB in Hive | Covered | `16 §4` |
| Exercise: Hive architecture, metastore & query flow | Covered | `16` interview scenarios |
| Exercise: tracing a Hive query from submission to result | Covered | `16` interview scenario 1 |
| Exercise: why are Hive queries so slow to fail? | Covered | `16 §3` |
| (added) Partitioning & bucketing; Athena as serverless Hive | AWS | `16 §6–7` |

## 19. Kafka (Confluent → Amazon MSK)

| Lecture / exercise | Status | Where |
|---|---|---|
| Kafka intro; introduction to Apache Kafka | Covered | `17` architecture |
| Why Kafka and its use cases | Covered | `17 §1` |
| Kafka architecture | Covered | `17 §2` |
| Ways to run Kafka | Covered | `17 §5` |
| Creating a Confluent Kafka cluster | AWS | `17 §6` MSK Serverless (free local option: `18 §4` compose) |
| Producing messages to a Kafka cluster | Covered | `17 §3`, `17 §6` |
| Kafka producers send multiple messages | Covered | `17 §6` producer |
| Callback, poll and flush | Covered | `17 §3` |
| Consuming messages from Kafka | Covered | `17 §4`, `17 §6` consumer |
| Confluent Kafka on CLI | AWS | `17 §6` Kafka CLI with IAM |
| Exercise: Kafka architecture, producers & consumers | Covered | `17` interview scenarios |
| Exercise: producer, consumer & architecture — applied scenarios | Covered | `17` interview scenarios 1–4 |
| Exercise: diagnosing missing Kafka messages | Covered | `17 §8` |
| (added) Kinesis Data Streams vs MSK | AWS | `17 §7` |

## 20. Docker (Docker Hub → ECR)

| Lecture / exercise | Status | Where |
|---|---|---|
| Docker and Airflow intro; introduction to the Docker series | Covered | `18` architecture |
| What are Docker and containers | Covered | `18 §1` |
| Docker images vs containers | Covered | `18 §1` |
| Docker vs virtual machines | Covered | `18` architecture; `18 §1` |
| Docker installation | Covered | `18 §1` installation |
| Creating a Docker image | Covered | `18 §2` |
| Docker basic commands | Covered | `18 §3` |
| Push Docker image to Docker Hub | AWS | `18 §5` (Amazon ECR) |
| Docker Compose | Covered | `18 §4` |
| Exercise: Docker fundamentals — images, containers & Compose | Covered | `18` interview scenarios |
| Exercise: Docker image, container & Compose — applied command practice | Covered | `18 §3–4` |
| Exercise: explaining why Docker beats a virtual machine | Covered | `18 §1`; interview scenario 1 |

## 21. Apache Airflow

| Lecture / exercise | Status | Where |
|---|---|---|
| Introduction to Apache Airflow | Covered | `19` architecture |
| Key components of Apache Airflow | Covered | `19` architecture; `19 §2` |
| Why Airflow for big data and MLOps | Covered | `19 §1` |
| Setting up Airflow with Astro | Covered | `19 §3` |
| Building your first DAG | Covered | `19 §4` |
| Designing a mathematical calculation DAG | Covered | `19 §4` |
| Getting started with the TaskFlow API | Covered | `19 §4` |
| Exercise: Airflow fundamentals & DAGs | Covered | `19` interview scenarios |
| Exercise: designing an Airflow DAG — components & TaskFlow | Covered | `19` interview scenario 2 |
| Exercise: why isn't my DAG running? | Covered | `19 §7` |
| (added) Amazon MWAA | AWS | `19 §6` |

## 22. Airflow ETL project (Astro Cloud → MWAA)

| Lecture / exercise | Status | Where |
|---|---|---|
| Read before starting — Airflow 3 & Astro update guide | Covered | `19 §1` Airflow 2 → 3 changes |
| Introduction to the ETL pipeline | Covered | `20` architecture |
| ETL problem statement and project structure | Covered | `20 §1` |
| Defining the ETL DAG with implementation steps | Covered | `20 §1–2` |
| Step 1 — Postgres setup and create-table task | Covered | `20 §2` |
| Step 2 — NASA API integration with the extract pipeline | Covered | `20 §2` |
| Step 3 — transformation and load pipeline | Covered | `20 §2` |
| Final implementation with Airflow connection setup | Covered | `20 §3` (local), `20 §4.2` (Secrets Manager) |
| Deployment in Astro Cloud and AWS | AWS | `20 §4` (MWAA + RDS) |
| Exercise: Airflow ETL pipeline — Postgres, API & deployment | Covered | `20` interview scenarios |
| Exercise: designing the ETL flow — dependencies & failure handling | Covered | `20 §5` |
| Exercise: fixing a failing load step | Covered | `20 §6` |

## 23. Databricks (on AWS)

| Lecture / exercise | Status | Where |
|---|---|---|
| Updated Databricks note; Databricks intro | Covered | `21 §2` (Free Edition replaced Community Edition) |
| What is Databricks | Covered | `21 §1` |
| Why Databricks | Covered | `21 §1`, `21 §8` |
| Create Databricks Community account | AWS | `21 §2` (Free Edition / AWS Marketplace) |
| Databricks UI walkthrough | Covered | `21 §3` |
| Understanding Databricks architecture | AWS | `21` architecture (control plane vs compute plane in your AWS account) |
| Databricks File System | Covered | `21 §4` (DBFS, volumes, Unity Catalog) |
| Exercise: Databricks fundamentals & architecture | Covered | `21` interview scenarios |
| Exercise: architecture & file system — applied questions | Covered | `21` interview scenarios 1–4 |
| Exercise: explaining where our data actually lives | Covered | `21 §4` |
| Read data in Databricks | Covered | `21 §7` → `15 §0` |
| Process data on Databricks — customer data | Covered | `21 §7` → `15 §0` |
| Processing customers with orders — actionable insights | Covered | `21 §7` |
| (added) Delta Lake internals, medallion on Delta | Covered | `21 §5–6` |

## 24. Azure intro → AWS data services

| Lecture / exercise | Status | Where |
|---|---|---|
| Azure intro | AWS | `22` architecture |
| Creating an Azure account | AWS | `04 §2` |
| Azure cloud overview | AWS | `22 §1–7` |
| Exercise: Azure account setup & service overview | AWS | `22` interview scenarios |
| Exercise: should we learn Azure too? | Covered | `22 §8` (AWS/Azure/GCP mapping) |

## 25. Azure end-to-end project → AWS capstone

| Lecture | Status | Where |
|---|---|---|
| Complete project resources | Skipped (platform) | — |
| Pre-requisite | AWS | `23 §2` |
| Project architecture | AWS | `23` architecture + `23 §1` mapping |
| Creating Azure account; Azure cloud overview | AWS | `04 §2`; `22` |
| Dataset overview: Olist | Covered | `15 §1` |
| SQL DB & data ingestion | AWS | `23 §3` (RDS MySQL) |
| Resource & resource group | AWS | `23 §1–2` (tags, IaC stack) |
| Azure Data Factory | AWS | `23 §5`; `22 §3, §6` (Glue + Step Functions) |
| ADLS Gen2 storage account | AWS | `23 §2`; `22 §2` (S3) |
| Medallion architecture overview | Covered | `01` architecture; `21 §6` |
| Ingestion with ADF | AWS | `23 §5.1` |
| Real-time ingestion with ADF | AWS | `23 §5.2` (JDBC) + DMS CDC note |
| Parameterized ingestion with ADF | AWS | `23 §5.3` (Step Functions Map over config) |
| Azure Databricks account creation | AWS | `21 §2` |
| Azure Databricks overview | AWS | `21 §1` |
| Azure Databricks UI overview | AWS | `21 §3` |
| Creating compute and notebook | AWS | `21 §3` |
| MongoDB ingestion to Databricks | AWS | `23 §4`, `23 §6` |
| Azure Databricks workflow overview | AWS | `21 §3` Databricks Workflows |
| ADLS Gen2 data lake to Databricks connection | AWS | `21 §4`, `23 §6` (UC storage credential + external location) |
| Accessing ADLS Gen2 data | AWS | `23 §6` |
| Quick revision | Covered | `23` key takeaways |
| Data enrichment; accessing data; read data in Databricks | Covered | `23 §6` |
| Spark transformation | Covered | `23 §6`; `08 §6` |
| MongoDB data for enrichment | Covered | `23 §6` |
| Data cleaning | Covered | `23 §6` |
| Extracting insights from data | Covered | `23 §6`; `15 §9` |
| Spark — transformation vs action | Covered | `08 §6` |
| Joining data | Covered | `23 §6` (grain-aware joins) |
| Enriching data via MongoDB | Covered | `23 §6` |
| Visualizing data in Databricks | Covered | `21 §3` |
| Exporting data to the silver layer | Covered | `23 §6` |
| Azure Synapse overview and account creation | AWS | `23 §7` (Athena workgroup, Redshift Serverless) |
| Synapse UI overview | AWS | `16 §7`; `23 §7` |
| Synapse to lake access | AWS | `23 §7` (Glue Catalog, Spectrum IAM role) |
| SQL pool — dedicated vs serverless | AWS | `23 §7`; `22 §5` (Redshift vs Athena) |
| Access lake data | AWS | `23 §6–7` |
| Create gold view and schema | AWS | `23 §7` (Athena views) |
| Azure Synapse workflow | AWS | `23 §5.3` (Step Functions + EventBridge) |
| CETAS understanding | AWS | `23 §7` (Athena CTAS, Iceberg MERGE) |
| Create external serving table in gold | AWS | `23 §7` |
| Serving layer completed | Covered | `23 §7` |
| Visualization flow | AWS | `23 §8` (QuickSight) |
| Thank you / congratulations | Covered | `24` cheat sheet |

## Additions beyond the syllabus

| Topic | Where |
|---|---|
| Spark optimization deep dive (joins, AQE, skew, small files, layout) | `14` |
| PySpark internals (Py4J, Python workers, Arrow, Spark Connect) + mini project | `25` |
| Glue, Lake Formation, Redshift internals, Step Functions | `22` |
| System design (clickstream, CDC, SCD2, exactly-once, cost) | `24 §4` |
