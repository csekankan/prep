# 07 — Python for Distributed Processing (the parts that matter for Spark)

> **Why it matters:** basic Python is assumed. This module covers only what changes when your code runs
> on 200 machines instead of one: higher-order functions (the Spark API *is* higher-order functions),
> closures and how they get serialized and shipped to executors, generators and lazy iteration (how
> `mapPartitions` streams data), and the cost of crossing the JVM ↔ Python boundary.

## In plain words

When you call `rdd.map(f)`, you don't run `f`. You **mail** `f` to 200 workers. Whatever `f`
references, such as a dictionary, a database connection, or `self`, gets packed into the envelope too.
If the envelope is huge, or contains something that can't be mailed (an open socket), the job is slow
or crashes.

## Architecture at a glance — how a Python function reaches an executor

```mermaid
flowchart LR
  subgraph DRIVER["Driver (your script)"]
    F["def parse(line): uses LOOKUP"] --> CP[cloudpickle:<br/>function bytecode +<br/>captured variables]
  end
  CP -->|serialized task<br/>per partition| E1
  CP --> E2
  subgraph E1["Executor JVM — node 1"]
    T1[Task] <-->|pipe / Arrow batches| PW1[Python worker process<br/>unpickles f, runs it]
  end
  subgraph E2["Executor JVM — node 2"]
    T2[Task] <--> PW2[Python worker]
  end
```

**How to read it:** PySpark pickles your function **plus everything it closes over** and sends it with each
task. Executors are JVMs; to run your Python they start Python worker processes and stream rows through a
pipe. Each crossing serializes data, which is why built-in DataFrame functions (which stay in the JVM) beat
Python UDFs.

## 1. Higher-order functions: the vocabulary of distributed APIs

A higher-order function takes a function as an argument or returns one.

| Python | Spark RDD | Spark DataFrame | Meaning |
|---|---|---|---|
| `map(f, xs)` | `rdd.map(f)` | `select(expr)` / `withColumn` | 1 → 1 |
| list comprehension with nested loop | `rdd.flatMap(f)` | `explode()` | 1 → 0..n |
| `filter(p, xs)` | `rdd.filter(p)` | `where(cond)` | keep where true |
| `functools.reduce(f, xs)` | `rdd.reduce(f)` / `reduceByKey(f)` | `agg(sum(...))` | fold many → one |
| `sorted(xs, key=k)` | `sortBy(k)` | `orderBy` | sort |
| `itertools.groupby` | `groupByKey` | `groupBy().agg()` | group |

```python
from functools import reduce

orders = [("A", 120.0), ("B", 30.5), ("A", 80.0), ("C", 15.0), ("B", 9.5)]

big = filter(lambda o: o[1] >= 20, orders)        # lazy iterator in Python 3
with_tax = map(lambda o: (o[0], o[1] * 1.18), big)
total = reduce(lambda acc, o: acc + o[1], with_tax, 0.0)
print(round(total, 2))  # 271.99
```

### Why `reduce` functions must be associative (and ideally commutative)

On a cluster, `reduce` runs **per partition first**, then merges partial results in **arbitrary order**:

```
 partition 1: [1,2,3] → f(f(1,2),3) = 6 ┐
 partition 2: [4,5]   → f(4,5)      = 9 ├─► f(6, 9) or f(9, 6) → 15
```

`lambda a, b: a + b` ✅. `lambda a, b: a - b` ❌: results change with partitioning. `lambda a, b: (a + b) / 2` ❌.
This is the same rule as MapReduce combiners (module 05).

### Lambdas: when to use them

Fine for one-liners. Use named functions for anything non-trivial: they're testable, show up by name in stack
traces, and can be unit-tested without Spark.

## 2. Closures, serialization, and the "Task not serializable" family

### What gets captured

```python
TAX = {"IN": 0.18, "US": 0.07}           # module-level

def add_tax(row):
    country, amount = row
    return country, amount * (1 + TAX[country])   # TAX is captured and shipped

rdd.map(add_tax)
```

`cloudpickle` serializes `add_tax` together with `TAX`. A small dict is fine. A 2 GB dict is shipped with
**every task**: 2,000 tasks × 2 GB is a disaster.

**Fix: broadcast variables.** Ship once per executor, cached, read-only:

```python
tax_b = spark.sparkContext.broadcast(TAX)
rdd.map(lambda r: (r[0], r[1] * (1 + tax_b.value[r[0]])))
```

### Classic traps

| Trap | What happens | Fix |
|---|---|---|
| Method referencing `self.something` | the whole object (maybe holding a SparkContext, connections, big data) is pickled | copy the needed field into a local variable first |
| Capturing a DB connection / file handle / lock | can't be pickled → `PicklingError` | create it **inside** `mapPartitions` (once per partition) |
| Using `SparkContext`/`SparkSession` inside a transformation | not allowed on executors | do driver-side work on the driver only |
| Mutating a global inside `map` | each executor mutates **its own copy**; the driver never sees it | return values, or use **accumulators** for counters |
| Late binding in loops: `[lambda x: x + i for i in range(3)]` | all lambdas use the final `i` | default argument `lambda x, i=i: x + i` |

### Accumulators (write-only counters back to the driver)

```python
bad_rows = spark.sparkContext.accumulator(0)

def parse(line):
    parts = line.split(",")
    if len(parts) != 5:
        bad_rows.add(1)
        return []
    return [parts]

parsed = rdd.flatMap(parse)
parsed.count()
print(bad_rows.value)
```

Caveat: updates inside **transformations** can be applied more than once if a task is retried or a stage is
recomputed. Only updates inside **actions** (`foreach`) are guaranteed exactly-once. Use them for monitoring, not business logic.

## 3. Iterators and generators: lazy, constant-memory processing

A generator yields one item at a time, so memory stays constant regardless of input size. That's exactly the
contract of `mapPartitions`: Spark hands you an **iterator** over a partition, and you return an iterator.

```python
def read_large_csv(path):
    with open(path) as f:
        next(f)                      # skip header
        for line in f:               # file objects are lazy iterators
            yield line.rstrip("\n").split(",")

def only_paid(rows):
    return (r for r in rows if r[3] == "paid")      # generator expression, still lazy

for row in only_paid(read_large_csv("orders.csv")):  # constant memory for a 50 GB file
    ...
```

### `map` vs `mapPartitions` — per-record vs per-partition setup

```python
def enrich_partition(rows):
    import requests                                  # imported on the executor
    session = requests.Session()                     # ONE connection pool per partition
    for r in rows:
        r["geo"] = session.get(f"https://geo.internal/{r['ip']}", timeout=2).json()
        yield r                                      # stream; never build a giant list
    session.close()

rdd.mapPartitions(enrich_partition)
```

| | `map(f)` | `mapPartitions(f)` |
|---|---|---|
| Called | once per record | once per partition, receiving an iterator |
| Use for | stateless per-row logic | expensive setup (connections, model loading), batching calls |
| Memory risk | low | high if you do `list(rows)`; stay lazy with `yield` |

DataFrame equivalent: `mapInPandas` / `applyInPandas` (Arrow batches, vectorized).

## 4. Decorators you'll actually see in data code

```python
import functools, time, logging

def retry(times=3, backoff=2.0, exceptions=(Exception,)):
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            for attempt in range(1, times + 1):
                try:
                    return fn(*args, **kwargs)
                except exceptions as e:
                    if attempt == times:
                        raise
                    logging.warning("retry %s/%s for %s: %s", attempt, times, fn.__name__, e)
                    time.sleep(backoff ** attempt)
        return wrapper
    return deco

@retry(times=5, exceptions=(ConnectionError, TimeoutError))
def fetch_page(url): ...
```

You'll meet decorators everywhere: `@dag` / `@task` in Airflow TaskFlow (module 19), `@pandas_udf` and
`@udf` in PySpark, `@functools.lru_cache` for memoizing lookups on the driver.

## 5. Python UDF cost model — why built-ins win

```mermaid
flowchart LR
  subgraph JVM["Executor JVM (Tungsten binary rows)"]
    R[rows]
  end
  subgraph PY["Python worker"]
    U[your UDF]
  end
  R -->|serialize: pickle row-by-row<br/>or Arrow batches| U
  U -->|serialize results back| R
```

| Approach | Data crosses JVM↔Python? | Optimizer can see inside? | Relative speed |
|---|---|---|---|
| Built-in functions (`F.upper`, `F.when`, `F.regexp_extract`) | no | yes (Catalyst) | fastest |
| Spark SQL expressions | no | yes | fastest |
| `pandas_udf` (Arrow, vectorized) | yes, in batches | no | good |
| Plain `@udf` (row-at-a-time pickle) | yes, per row | no | slowest (often 2–10× slower) |

```python
from pyspark.sql import functions as F
from pyspark.sql.functions import pandas_udf
import pandas as pd

# Bad: row-at-a-time Python UDF
@F.udf("double")
def with_tax_udf(amount):
    return amount * 1.18 if amount is not None else None

# Better: vectorized
@pandas_udf("double")
def with_tax_vec(amount: pd.Series) -> pd.Series:
    return amount * 1.18

# Best: no UDF at all
df = df.withColumn("amount_tax", F.col("amount") * F.lit(1.18))
```

## 6. pandas vs PySpark — when to switch

| | pandas | PySpark DataFrame |
|---|---|---|
| Execution | eager, single process | lazy, distributed, optimized plan |
| Data size | fits in RAM (rule: ≤ ~1/5 of RAM because of copies) | TB–PB |
| Index | yes | no row order guarantee, no index |
| Mutability | in-place ops | immutable; each op returns a new DataFrame |
| Bridge | `spark.createDataFrame(pdf)` | `df.toPandas()` (collects everything to the driver — dangerous on big data) |
| API compatibility | | `pyspark.pandas` (pandas API on Spark) |

Enable Arrow for fast conversion: `spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "true")`.

## 7. Packaging Python dependencies for a cluster

Executors need the same libraries as the driver.

| Platform | How |
|---|---|
| EMR on EC2 | bootstrap action `pip install`; or `--archives venv.tar.gz#environment` with `venv-pack` |
| EMR Serverless | packed venv in S3: `--conf spark.archives=s3://.../venv.tar.gz#environment --conf spark.emr-serverless.driverEnv.PYSPARK_PYTHON=./environment/bin/python ...` |
| Glue | `--additional-python-modules pandas==2.2.3,pyarrow` job parameter |
| Your own code | zip your package and pass `--py-files s3://.../src.zip` |

## Key takeaways

- Spark transformations are higher-order functions; reduce functions must be associative (and commutative).
- Closures are pickled and shipped per task. Broadcast big lookups, and create connections inside `mapPartitions`.
- Executors can't mutate driver state. Use return values; use accumulators only for monitoring.
- Generators and iterators give constant-memory streaming, which is the `mapPartitions` contract.
- Prefer built-in functions > `pandas_udf` > plain UDF, because every JVM↔Python crossing costs serialization.

## Interview scenarios

1. *A PySpark job fails with `PicklingError: Could not serialize object: TypeError: cannot pickle '_thread.lock'`.*
   — a transformation captured an object holding a lock (DB client, logger handler, SparkSession). Create the
   client inside `mapPartitions`, or reference only plain data.
2. *Why is this counter always 0 on the driver: `count = 0; rdd.foreach(lambda x: increment())`?* — each
   executor increments its own deserialized copy. Use an accumulator or `rdd.count()`.
3. *A 500 MB lookup dict is used in `map`; the job is slow and the driver's network is saturated.* — the dict
   is serialized into every task. Broadcast it, or turn it into a DataFrame and join (broadcast join).
4. *Python UDF parsing dates is slow.* — replace with `F.to_date(col, "dd/MM/yyyy")` (runs in the JVM,
   visible to Catalyst), or a `pandas_udf` if no built-in exists.
