# 02 — Hadoop Ecosystem & HDFS Architecture

> **Why it matters:** Hadoop is where the core ideas of big data came from: split files into blocks,
> replicate them, move the computation to where the data is, and assume that hardware will fail.
> Spark, S3-based lakes, and even Kafka's log design borrow from it. EMR still ships HDFS, and
> interviewers still ask you to draw it.

## In plain words

HDFS is a **giant shared hard drive built out of many cheap computers**.

- A big file is cut into fixed-size **blocks** (like tearing a 1,000-page book into 128-page chapters).
- Each chapter is **photocopied 3 times** and the copies go to different computers, and to more than
  one rack, so a dead computer or a dead rack switch doesn't lose anything.
- One **librarian** (the NameNode) keeps the index card: "Book X = chapters 1–8; chapter 3 lives on
  machines 7, 12, 40." The librarian never holds the chapters. Reading them happens directly between
  the reader and the machines.

## Architecture at a glance

```mermaid
flowchart TB
  C[HDFS Client<br/>hdfs dfs / Spark / MR]
  subgraph MASTER["Master"]
    NN["NameNode<br/>namespace + block map<br/>(all in RAM)"]
    FS[(fsimage +<br/>edit log on disk)]
    NN --- FS
  end
  subgraph R1["Rack 1"]
    DN1[DataNode 1<br/>B1 B3]
    DN2[DataNode 2<br/>B2 B1]
  end
  subgraph R2["Rack 2"]
    DN3[DataNode 3<br/>B1 B2]
    DN4[DataNode 4<br/>B3 B2]
  end
  subgraph R3["Rack 3"]
    DN5[DataNode 5<br/>B3]
  end
  C -->|1. metadata: where are blocks?| NN
  NN -->|2. block locations| C
  C ==>|3. read/write bytes directly| DN1
  C ==> DN3
  DN1 -.heartbeat 3s +<br/>block report.-> NN
  DN2 -.-> NN
  DN3 -.-> NN
  DN4 -.-> NN
  DN5 -.-> NN
```

**How to read it:** the client only talks to the NameNode for **metadata**. Data bytes always flow
directly between the client and DataNodes (thick arrows), which is why one NameNode can serve thousands
of nodes. DataNodes send a heartbeat to prove they are alive, and a block report listing the blocks they
hold.

## 1. Hadoop: origins and properties

Google published **GFS (2003)** and **MapReduce (2004)** papers; Doug Cutting and Mike Cafarella
implemented them as **Hadoop** (Yahoo!, 2006). Hadoop 2 (2013) added **YARN**; Hadoop 3 (2017) added
erasure coding, multiple standby NameNodes, and more.

| Property | What it means | Mechanism |
|---|---|---|
| **Distributed** | storage & compute across many nodes | HDFS blocks + YARN containers |
| **Scalable** | add nodes → more capacity/throughput | shared-nothing DataNodes |
| **Fault tolerant** | node loss is normal | replication, re-replication, task retries |
| **Commodity hardware** | no expensive SAN | failure handled in software |
| **Data locality** | move code to data | scheduler prefers node-local, then rack-local tasks |
| **Write-once, read-many** | files are append-only/immutable | simplifies consistency |
| **High throughput, not low latency** | batch scans | large blocks, streaming reads |

## 2. The ecosystem

```mermaid
flowchart TB
  subgraph ACCESS["Access / query"]
    HIVE[Hive<br/>SQL → jobs]
    PIG[Pig<br/>dataflow scripts, legacy]
    SPARK[Spark<br/>in-memory engine]
    PRESTO[Presto / Trino<br/>interactive SQL]
    HBASE[HBase<br/>NoSQL on HDFS]
  end
  subgraph PROC["Processing"]
    MR[MapReduce]
    TEZ[Tez<br/>DAG engine for Hive]
  end
  YARN[YARN<br/>resource management]
  HDFS[HDFS<br/>storage]
  subgraph ING["Ingest"]
    SQOOP[Sqoop<br/>RDBMS ↔ HDFS, retired]
    FLUME[Flume<br/>log ingest, legacy]
    KAFKA[Kafka]
  end
  subgraph COORD["Coordination / ops"]
    ZK[ZooKeeper]
    OOZIE[Oozie<br/>workflow, legacy]
    RANGER[Ranger<br/>security]
  end
  ACCESS --> PROC --> YARN --> HDFS
  SPARK --> YARN
  ING --> HDFS
  COORD -.-> YARN
```

| Component | Role | Modern AWS equivalent / status |
|---|---|---|
| HDFS | distributed file system | **S3** (primary), HDFS on EMR core nodes (scratch / hot data) |
| YARN | cluster resource manager | YARN on EMR; Kubernetes (EMR on EKS); serverless (EMR Serverless, Glue) |
| MapReduce | batch engine | mostly replaced by Spark |
| Hive | SQL on files, metastore | Hive on EMR; **Glue Data Catalog** replaces metastore; **Athena** for serverless SQL |
| HBase | wide-column NoSQL | HBase on EMR (S3 storage mode), **DynamoDB** |
| Sqoop | DB import/export | retired (Apache Attic 2021) → **AWS DMS**, Glue JDBC, Spark JDBC |
| Flume | log ingestion | **Kinesis Data Firehose** (Amazon Data Firehose), Kafka/MSK |
| Oozie | workflows | **MWAA (Airflow)**, Step Functions |
| ZooKeeper | coordination, leader election | still used by HDFS HA, HBase; Kafka moved to KRaft |
| Ranger | authorization | **Lake Formation**, IAM; Ranger on EMR also supported |

## 3. HDFS terminology

| Term | Meaning |
|---|---|
| **NameNode (NN)** | master; holds namespace (directory tree, permissions) and block → DataNode map **in memory** |
| **DataNode (DN)** | worker; stores blocks as local files on Linux file system (`blk_1073741825` + `.meta` checksum file) |
| **Block** | unit of storage; default **128 MB** (Hadoop 2+, was 64 MB in Hadoop 1) |
| **Replication factor (RF)** | copies per block; default **3** |
| **fsimage** | checkpoint of the namespace on disk |
| **Edit log** | journal of every namespace change since the last fsimage |
| **Heartbeat** | DN → NN every **3 s** ("I'm alive, here's my capacity"); NN replies with commands (replicate, delete) |
| **Block report** | DN → NN list of all blocks it holds (full report every 6 h by default + incremental reports) |
| **Secondary NameNode** | checkpoint helper (module 03) — **not** a backup |
| **Standby NameNode** | hot standby for HA (module 03) |
| **Rack** | group of nodes on one top-of-rack switch |

## 4. Why HDFS? (vs a normal file server / NAS)

- One NAS has one network pipe and one set of disks → throughput ceiling. HDFS aggregates the disks
  and NICs of every node.
- Computation can run **on the node holding the block** (data locality), so reads hit local disk, not network.
- Replication across nodes and racks is done in software, so commodity disks are fine.
- **Not good for:** low-latency random reads, many small files, in-place updates (no random writes),
  POSIX semantics.

## 5. Blocks — the core design decision

### Why so large (128 MB vs 4 KB in a local FS)?

1. **Seek time amortization.** HDD seek ≈ 10 ms, transfer ≈ 100–200 MB/s. To keep seek ≤ 1% of
   time, you need a transfer of ≥ 1 s ≈ 100+ MB. Hence ~128 MB.
2. **NameNode memory.** Every block is a metadata object in NN RAM. Bigger blocks → fewer objects.
3. **Task granularity.** One block ≈ one map task / Spark partition; 128 MB is a good unit of parallel work.

A file smaller than a block uses **only its real size on disk** (a 1 MB file uses 1 MB, not 128 MB) —
but it still costs a full metadata entry in NN memory.

### Block calculation (you will be asked this)

File = 1 GB = 1024 MB, block = 128 MB, RF = 3:

- Blocks: \(\lceil 1024 / 128 \rceil = 8\)
- Block replicas stored: \(8 \times 3 = 24\)
- Raw disk used: \(1024 \times 3 = 3072\) MB = **3 GB**

File = 500 MB → \(\lceil 500/128 \rceil = 4\) blocks: three of 128 MB, one of 116 MB. Disk = 1500 MB.

### NameNode memory math — why small files kill HDFS

Rule of thumb: **~150 bytes of NN heap per namespace object** (file, directory, or block).

| Scenario | Objects | NN heap ≈ |
|---|---|---|
| 1 file of 10 GB (80 blocks) | 1 file + 80 blocks = 81 | 12 KB |
| 10 GB as 100,000 files of 100 KB | 100,000 files + 100,000 blocks = 200,000 | 30 MB |
| 100 M small files | ~200 M objects | ~30 GB heap → GC pauses, slow restarts |

Common sizing: **~1 GB of heap per 1 million blocks**. Small files also create one map task each
(huge scheduling overhead). Fixes: compact into larger files (Spark `coalesce`, Hive `CONCATENATE`),
SequenceFiles / HAR archives, or Parquet with sensible file sizes (128 MB–1 GB).

## 6. Replication factor

- Default 3, set per file: `hdfs dfs -setrep -w 2 /data/logs`.
- Read throughput: more replicas → more nodes can serve the block in parallel; hot files can use RF higher than 3.
- Storage overhead = RF × data. 1 PB of data at RF 3 → 3 PB raw.

### Erasure coding (Hadoop 3)

Instead of 3 full copies, use Reed–Solomon **RS(6,3)**: 6 data cells + 3 parity cells.

| | 3× replication | RS(6,3) erasure coding |
|---|---|---|
| Storage overhead | 200% (3.0×) | 50% (1.5×) |
| Failures tolerated | 2 | 3 |
| Cost | cheap CPU, local reads | CPU for encoding, network on reads/reconstruction, no data locality |
| Use for | hot data | cold/archive data |

S3 internally uses erasure coding across multiple AZs — one reason it's cheaper than 3× EBS.

## 7. Rack awareness

Without it, all 3 replicas could land in one rack; a top-of-rack switch failure would make the block unavailable.

**Default placement policy (RF = 3):**

```
  Rack A                Rack B
 ┌────────┐           ┌────────┐
 │ DN1 ●1 │ (writer's │ DN4 ●2 │  replica 2: a node on a DIFFERENT rack
 │ DN2    │  node, or │ DN5 ●3 │  replica 3: a different node on the SAME rack as replica 2
 │ DN3    │  random)  │ DN6    │
 └────────┘           └────────┘
```

1. Replica 1 → the writer's node (if the client runs on a DataNode), else a random node that isn't too busy.
2. Replica 2 → a node on a **different rack**.
3. Replica 3 → a **different node on the same rack as replica 2**.
4. More replicas → random, max 2 per rack where possible.

**Why this split?** It survives a full rack failure (a copy always exists on another rack), but only
**one** cross-rack transfer is needed during the write pipeline (rack A → rack B), saving inter-rack
bandwidth, which is scarcer than intra-rack bandwidth.

Rack awareness is configured with a topology script (`net.topology.script.file.name`) that maps
IP → `/dc1/rack7`.

**On AWS:** the analogy for a rack is an **Availability Zone**. EMR clusters run in a **single AZ** (one
subnet), so HDFS on EMR does **not** protect against an AZ outage. That's another reason durable data lives
in S3 (multi-AZ by design) and HDFS on EMR is treated as scratch space.

## 8. HDFS on EMR vs S3 (EMRFS)

```mermaid
flowchart LR
  subgraph EMR["EMR cluster (one AZ)"]
    P[Primary node<br/>NameNode, RM]
    C1[Core node<br/>DataNode + NodeManager]
    C2[Core node<br/>DataNode + NodeManager]
    T1[Task node<br/>NodeManager only]
  end
  S3[(Amazon S3<br/>multi-AZ, 11 nines)]
  C1 <-->|EMRFS s3://| S3
  C2 <--> S3
  T1 <--> S3
  C1 <-->|hdfs://| C2
```

| | HDFS on EMR | S3 via EMRFS |
|---|---|---|
| Lifetime | dies with the cluster | independent of compute |
| Durability | replication within one AZ | 99.999999999% across ≥3 AZs |
| Latency | low, local disk | higher per request, high aggregate throughput |
| Rename | atomic metadata op | copy + delete (slow for directories) → use S3-optimized committers |
| Consistency | strong | strong read-after-write (since Dec 2020; EMRFS "consistent view" no longer needed) |
| Cost | EBS/instance storage, paid while cluster runs | ~\$0.023/GB-month standard, tiering available |
| Use for | shuffle spill, intermediate/iterative data, HBase | source of truth, inputs and outputs |

**EMR default replication:** `dfs.replication` = 1 for clusters with < 4 core nodes, 2 for 4–9 core
nodes, 3 for 10+ core nodes. A 3-node lab cluster therefore has **no** HDFS redundancy by default.

## Failure modes & production notes

- **Small files** — the #1 HDFS problem; monitor `files / blocks` ratio and average file size.
- **NameNode heap** — size heap for the number of blocks; GC pauses look like cluster-wide hangs.
- **Disk imbalance** — new nodes are empty; run `hdfs balancer -threshold 10`.
- **Under-replicated blocks** after node loss — watch `hdfs fsck / | grep -i under` and NN metrics.
- On EMR: never store the only copy of important data in HDFS; scale-in of **core** nodes must
  decommission DataNodes gracefully (EMR does this, but it's slow with lots of data).

## Key takeaways

- HDFS = NameNode (metadata in RAM) + DataNodes (blocks on disk); bytes never go through the NameNode.
- 128 MB blocks amortize seek time, shrink NN metadata, and define task granularity.
- RF 3 with rack-aware placement survives node and rack loss with one cross-rack hop.
- Small files exhaust NameNode memory (~150 bytes/object) and create too many tasks.
- On AWS, S3 is the durable store; HDFS on EMR is scratch space inside a single AZ.

## Interview scenarios

1. *A 1.5 GB file, block 128 MB, RF 3: blocks, replicas, raw storage?* — 12 blocks (11 × 128 + 1 × 92 MB),
   36 replicas, 4.5 GB raw.
2. *A team wrote 50 M JSON files of 20 KB each. What breaks?* — NN heap (~100 M objects ≈ 15 GB), job
   startup (50 M splits/tasks), listing time. Compact to Parquet files of 256 MB–1 GB.
3. *Why not 1 GB blocks then?* — fewer, larger tasks → less parallelism and worse load balance; longer
   recovery when a node fails; more wasted work on task retry.
4. *Explaining HDFS to a new team member (e-commerce):* "Order history is split into 128 MB chunks with
   3 copies on different machines and racks. A master keeps the map of where chunks live. Our Spark jobs
   run on the machines that already hold the chunks, so we read from local disks instead of the network."
5. *Map e-commerce needs to Hadoop components:* raw logs → HDFS/S3; nightly batch aggregation → Spark on
   YARN (MapReduce historically); SQL for analysts → Hive/Athena; product lookup by key at low latency →
   HBase/DynamoDB; DB import → Sqoop then, DMS now; scheduling → Oozie then, Airflow now.
