# 16 — Apache Hive & Amazon Athena: SQL on the Data Lake

> **Why it matters:** Hive introduced the two ideas that every lake still runs on: **SQL over files** and the
> **metastore** (a table catalog that maps names to S3/HDFS locations, schemas, and partitions). On AWS, the
> Hive metastore became the **Glue Data Catalog**, and the "run SQL over S3 without a cluster" role went to
> **Athena** (Trino). Understanding Hive's architecture explains how both work.

## In plain words

Your data is millions of files in folders. Hive is a **translator plus a card catalog**. The catalog says
"the table `orders` = these folders, with these columns, split by date". The translator turns your SQL into
distributed jobs (MapReduce, Tez, or Spark) that read those files. Athena is the same idea **as a
service**: you bring SQL, AWS brings the computers for exactly as long as the query runs, and you pay per byte scanned.

## Architecture at a glance — Hive

```mermaid
flowchart TB
  subgraph CLIENTS["Clients"]
    BL[Beeline CLI]
    JDBC[JDBC / ODBC<br/>BI tools]
    HUE[Hue / notebooks]
  end
  subgraph HS2["HiveServer2"]
    SESS[Session manager<br/>auth, concurrency]
    subgraph DRV["Driver"]
      CMP[Compiler<br/>parse → semantic analysis<br/>→ logical plan]
      OPT[Optimizer<br/>Calcite CBO:<br/>predicate pushdown,<br/>partition pruning,<br/>join reorder]
      EXE[Executor<br/>submits DAG]
    end
  end
  subgraph MS["Metastore"]
    MSS[Metastore service<br/>Thrift :9083]
    MDB[(RDBMS: MySQL / Postgres /<br/>Derby for dev only<br/>or AWS Glue Data Catalog)]
  end
  ENG[Execution engine:<br/>Tez default / MapReduce legacy / Spark]
  YARN[YARN]
  STORE[(HDFS / S3<br/>ORC, Parquet, text)]
  CLIENTS --> SESS --> CMP
  CMP <-->|table schema,<br/>partitions, location| MSS --- MDB
  CMP --> OPT --> EXE --> ENG --> YARN --> STORE
```

**How to read it:** clients connect to HiveServer2. The Driver compiles the SQL, asking the Metastore what
`orders` means (columns, SerDe, S3 location, partitions). The optimizer prunes partitions and reorders joins.
The executor submits a Tez DAG to YARN, which reads the files. Hive itself stores **no data**: only metadata,
plus the files you point it at.

## 1. Introduction & how Hive makes big data easier

- 2008, Facebook: analysts knew SQL, not Java MapReduce. Hive compiled **HiveQL** into MapReduce jobs.
- **Schema-on-read:** the table definition is applied when reading; files can be loaded first.
- Hive 2/3: Tez execution, LLAP (in-memory daemons for low-latency), ACID transactional tables (ORC),
  cost-based optimizer (Calcite), vectorization.

| Without Hive | With Hive |
|---|---|
| 200 lines of Java MapReduce for a join + group by | `SELECT ... JOIN ... GROUP BY` |
| Every team re-defines file schemas | central metastore: one definition, many engines |
| Manual directory scanning for dates | partition pruning from `WHERE dt = ...` |

## 2. Common questions and misconceptions

| Misconception | Reality |
|---|---|
| "Hive is a database" | It's a SQL engine + metastore over files. No storage engine, no indexes (removed in Hive 3). |
| "Hive is for transactions / OLTP" | No. Batch analytics. ACID tables exist for ETL upserts, not app traffic. |
| "Hive is real-time" | Seconds to minutes of latency (LLAP helps); use Trino/Athena/Redshift for interactive work. |
| "Hive still uses MapReduce" | Tez is the default engine since Hive 2; MR is deprecated. |
| "Dropping a table is always safe" | Managed tables delete data; external tables don't (same as Spark, module 11). |
| "Hive's metastore is only for Hive" | Spark, Presto/Trino, Impala, Athena (via Glue) all use it. |

## 3. Hive query flow step by step

```mermaid
sequenceDiagram
  participant U as Beeline
  participant H as HiveServer2 / Driver
  participant M as Metastore (Glue)
  participant Y as YARN + Tez
  participant S as S3 / HDFS
  U->>H: 1. executeStatement(SQL)
  H->>H: 2. parse → AST
  H->>M: 3. getTable, getPartitions(filter)
  M-->>H: 4. schema, SerDe, locations of matching partitions
  H->>H: 5. semantic analysis + CBO → physical plan (Tez DAG)
  H->>Y: 6. submit DAG (Tez AM, containers reused across vertices)
  Y->>S: 7. read files of pruned partitions (ORC/Parquet with predicate pushdown)
  Y-->>H: 8. status / results written to temp dir
  H-->>U: 9. fetch results
```

### Why Hive queries are "slow to fail"

Steps 2–5 catch syntax errors, missing tables/columns, and type mismatches **in seconds**. But a whole class of
errors only appears **after step 6**, once containers start and real data is read:

- a SerDe that can't parse some rows, or a corrupt file deep in a partition;
- division by zero or a cast error under strict settings;
- a container out of memory on a skewed join key;
- S3 permission denied on one partition prefix.

Each of those costs YARN scheduling time, Tez AM startup, and container launch before failing. Then retries
(`tez.am.task.max.failed.attempts`) repeat it. Mitigations: run `EXPLAIN` first, test with `LIMIT`/a single
partition, validate data on ingest, and use Tez session reuse or LLAP for faster startup.

## 4. The metastore and Derby

| Mode | Metastore DB | Concurrency | Use |
|---|---|---|---|
| Embedded | **Derby** in-process, `metastore_db/` in the working dir | **one session at a time** (file lock) | local dev only |
| Local | MySQL/Postgres; metastore code inside HS2 | many | single HS2 |
| Remote | standalone metastore service (Thrift 9083) + MySQL/Postgres | many | production; shared by Spark/Trino |
| **AWS Glue Data Catalog** | serverless, Hive-compatible | many | EMR, Glue, Athena, Redshift Spectrum |

Classic Derby error when a second session starts: `Another instance of Derby may have already booted the
database`. Also, Derby lives on one machine's disk, so on EMR it disappears with the cluster.

**On EMR:** use the Glue Data Catalog (classification `hive-site`, module 04), or an external RDS/Aurora MySQL
metastore (`javax.jdo.option.ConnectionURL` pointing to RDS) when you need full Hive metastore features.

### Accessing metadata

```sql
SHOW DATABASES;  SHOW TABLES IN sales;
DESCRIBE FORMATTED sales.orders;        -- location, table type, SerDe, input format, partition cols
SHOW PARTITIONS sales.orders;
SHOW CREATE TABLE sales.orders;
```

```bash
aws glue get-table --database-name sales --name orders --query 'Table.StorageDescriptor.Location'
aws glue get-partitions --database-name sales --table-name orders --max-items 5
```

With a MySQL-backed metastore, the raw tables are `DBS`, `TBLS`, `SDS` (storage descriptors), `PARTITIONS`,
`COLUMNS_V2`. Joining them shows every table's location, which is handy for audits.

## 5. Hands-on on EMR

```bash
# on the primary node
beeline -u jdbc:hive2://localhost:10000/default -n hadoop
```

```sql
CREATE DATABASE IF NOT EXISTS sales LOCATION 's3://bigdata-course-123/warehouse/sales.db/';

CREATE EXTERNAL TABLE sales.orders_raw (
  order_id STRING, customer_id INT, city STRING, status STRING,
  amount DECIMAL(12,2), order_date STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION 's3://bigdata-course-123/raw/orders/'
TBLPROPERTIES ('skip.header.line.count'='1');

-- Partitioned, columnar target
CREATE EXTERNAL TABLE sales.orders (
  order_id STRING, customer_id INT, city STRING, status STRING, amount DECIMAL(12,2))
PARTITIONED BY (order_date DATE)
STORED AS ORC
LOCATION 's3://bigdata-course-123/silver/orders_orc/'
TBLPROPERTIES ('orc.compress'='ZSTD');

SET hive.exec.dynamic.partition.mode=nonstrict;
INSERT OVERWRITE TABLE sales.orders PARTITION (order_date)
SELECT order_id, customer_id, city, status, amount, CAST(order_date AS DATE)
FROM sales.orders_raw;

EXPLAIN SELECT city, sum(amount) FROM sales.orders
WHERE order_date = DATE '2025-03-01' GROUP BY city;
```

## 6. Partitioning and bucketing in Hive

| | Partitioning | Bucketing |
|---|---|---|
| Physical layout | sub-directory per value (`order_date=2025-03-01/`) | fixed N files per partition by `hash(col) mod N` |
| Helps | partition pruning on filters | joins/sampling on the bucket key (bucket map join, SMB join) |
| Cardinality | low–medium | high (user_id) |
| Danger | too many partitions → small files + metastore load | N fixed; changing it needs a rewrite |

```sql
CREATE TABLE sales.orders_bucketed (order_id STRING, customer_id INT, amount DECIMAL(12,2))
PARTITIONED BY (order_date DATE)
CLUSTERED BY (customer_id) SORTED BY (customer_id) INTO 32 BUCKETS
STORED AS ORC;
```

Static vs dynamic partition insert: static names the value (`PARTITION (order_date='2025-03-01')`); dynamic
derives it from the last select columns (needs `nonstrict` when no static part is given;
`hive.exec.max.dynamic.partitions` guards against accidental explosions).

## 7. Amazon Athena — serverless "Hive" on AWS

```mermaid
flowchart LR
  U[Analyst / QuickSight /<br/>JDBC / boto3] --> WG[Athena workgroup<br/>limits, result location,<br/>engine version]
  WG --> ENG[Trino-based engine<br/>serverless workers]
  ENG <-->|table metadata| CAT[(Glue Data Catalog)]
  ENG -->|read| S3[(S3 data:<br/>Parquet / ORC / JSON / CSV<br/>Iceberg tables)]
  ENG -->|results CSV +<br/>metadata| RES[(S3 results bucket)]
  ENG -.federated connectors<br/>Lambda.-> OTHER[(DynamoDB, RDS,<br/>Redshift, ...)]
  LF[Lake Formation<br/>column/row permissions] -.-> ENG
```

| | Hive on EMR | Athena |
|---|---|---|
| Infra | cluster you run | none |
| Engine | Tez on YARN | Trino (engine v3) |
| Pricing | instance-hours | **\$5 per TB scanned** (10 MB minimum per query), or provisioned capacity |
| Latency | seconds–minutes (container startup) | typically seconds |
| Catalog | Hive metastore / Glue | Glue |
| Writes | INSERT, ACID tables | CTAS, INSERT INTO, UNLOAD; full DML/MERGE on **Iceberg** tables |
| Best for | heavy ETL on existing Hive code | ad-hoc analytics, BI over the lake, light ELT |

### Cost math (why layout matters in Athena)

Query: last 7 days of revenue from a 3 TB table (2 years of data).

| Layout | Bytes scanned | Cost |
|---|---|---|
| CSV, not partitioned | 3 TB | \$15.00 |
| Parquet (≈ 8× smaller), not partitioned, 2 of 20 columns | 3 TB / 8 × 2/20 ≈ 37.5 GB | \$0.18 |
| Parquet, partitioned by day, 7 of 730 days | 37.5 GB × 7/730 ≈ 0.36 GB | \$0.0018 |

That's a 8,000× difference from layout alone.

### Athena features to know

```sql
-- CTAS: convert raw CSV to partitioned Parquet in one statement (ELT inside Athena)
CREATE TABLE sales.orders_parquet
WITH (format = 'PARQUET', write_compression = 'ZSTD',
      external_location = 's3://bigdata-course-123/silver/orders_parquet/',
      partitioned_by = ARRAY['order_date'])
AS SELECT order_id, customer_id, city, status, amount, CAST(order_date AS DATE) AS order_date
FROM sales.orders_raw;

-- Partition projection: no MSCK/crawlers; partitions computed from the query
CREATE EXTERNAL TABLE logs.events (user_id string, event string, ts timestamp)
PARTITIONED BY (dt string)
STORED AS PARQUET
LOCATION 's3://bigdata-course-123/raw/events/'
TBLPROPERTIES (
  'projection.enabled'='true',
  'projection.dt.type'='date',
  'projection.dt.format'='yyyy-MM-dd',
  'projection.dt.range'='2024-01-01,NOW',
  'storage.location.template'='s3://bigdata-course-123/raw/events/dt=${dt}/');

-- Iceberg table with MERGE (upserts on the lake)
CREATE TABLE sales.customers_iceberg (customer_id int, city string, updated_at timestamp)
LOCATION 's3://bigdata-course-123/iceberg/customers/'
TBLPROPERTIES ('table_type'='ICEBERG');

MERGE INTO sales.customers_iceberg t
USING sales.customers_updates s ON t.customer_id = s.customer_id
WHEN MATCHED THEN UPDATE SET city = s.city, updated_at = s.updated_at
WHEN NOT MATCHED THEN INSERT VALUES (s.customer_id, s.city, s.updated_at);
```

```python
import boto3, time
athena = boto3.client("athena")
qid = athena.start_query_execution(
    QueryString="SELECT city, sum(amount) FROM sales.orders_parquet WHERE order_date = DATE '2025-03-01' GROUP BY city",
    WorkGroup="olist")["QueryExecutionId"]
while (state := athena.get_query_execution(QueryExecutionId=qid)
                 ["QueryExecution"]["Status"]["State"]) in ("QUEUED", "RUNNING"):
    time.sleep(1)
stats = athena.get_query_execution(QueryExecutionId=qid)["QueryExecution"]["Statistics"]
print(state, stats["DataScannedInBytes"])
```

Workgroup guardrails: per-query bytes-scanned cutoff, enforced result location with encryption, separate
workgroups per team for cost attribution.

## Key takeaways

- Hive = HiveServer2 + Driver (compile, optimize, execute) + Metastore + an engine (Tez) over files.
- The metastore is the lasting legacy; on AWS it's the Glue Data Catalog, shared by EMR, Glue, Athena, and Spectrum.
- Derby = single-session dev metastore on local disk; production uses RDS/MySQL or Glue.
- Compile errors are fast; data/runtime errors surface only after containers start, so Hive is slow to fail.
- Athena = serverless Trino over S3, priced per TB scanned. Parquet + partitions + projection cut cost by orders of magnitude.

## Interview scenarios

1. *Trace a Hive query from submission to result.* — Beeline → HS2 session → parse → metastore lookup
   (schema, partitions) → semantic analysis + CBO → Tez DAG → YARN containers read pruned files → results to
   temp dir → fetched by the client.
2. *Two analysts get "Another instance of Derby may have already booted the database".* — embedded Derby
   allows one session. Move to a remote metastore (RDS) or the Glue Data Catalog.
3. *An Athena query costs \$40 each run.* — it scans raw CSV or unpartitioned data. CTAS to partitioned Parquet,
   select only needed columns, filter on partition columns, add a workgroup scan limit.
4. *New S3 partitions aren't visible in Athena.* — partitions aren't in the catalog. Use partition projection
   (best), `MSCK REPAIR TABLE`, `ALTER TABLE ADD PARTITION`, or a Glue crawler. Or use Iceberg tables.
