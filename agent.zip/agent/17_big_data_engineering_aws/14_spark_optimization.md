# 14 — Spark Optimization: Joins, Skew, AQE, Small Files, Layout, Config

> **Why it matters:** a well-tuned Spark job on AWS can cost 5–10× less than a naive one. Nearly all
> big wins come from five places: **read less** (layout, pruning), **shuffle less** (join strategy,
> pre-aggregation), **balance the work** (skew), **right-size partitions and files**, and **right-size
> compute**. This module gives you a diagnose → fix playbook.

## In plain words

You're moving house:
- **Read less** = only pack the rooms you're moving (column pruning, partition pruning).
- **Shuffle less** = don't send every box to a central warehouse to sort it. If one box is tiny (a small
  table), photocopy it for every truck (broadcast join).
- **Skew** = one truck gets the piano and the whole fleet waits for it. Split the piano's load (salting).
- **Small files** = 10,000 envelopes instead of 10 boxes: the handling overhead dominates.

## Architecture at a glance — the optimization map

```mermaid
flowchart LR
  subgraph READ["1. Read less"]
    R1[Parquet/ORC columnar]
    R2[partition pruning]
    R3[predicate pushdown<br/>row-group min/max]
    R4[dynamic partition pruning]
  end
  subgraph SHUF["2. Shuffle less"]
    S1[broadcast small tables]
    S2[pre-aggregate before join]
    S3[bucketing / co-partitioning]
  end
  subgraph BAL["3. Balance"]
    B1[AQE skew join]
    B2[salting hot keys]
    B3[isolate nulls]
  end
  subgraph SIZE["4. Right-size"]
    Z1[shuffle partitions / AQE coalesce]
    Z2[output files 128 MB–1 GB]
    Z3[executor sizing]
  end
  subgraph AWS["5. AWS layer"]
    A1[S3-optimized committer]
    A2[Spot + Graviton]
    A3[EMR runtime for Spark]
  end
  READ --> SHUF --> BAL --> SIZE --> AWS
```

**How to read it:** work left to right. Fixing the read layer usually helps more than any config flag, and
config tuning comes after the plan itself is right.

## 1. Join strategies (how Spark physically joins)

| Strategy | How | Shuffle? | When chosen | Notes |
|---|---|---|---|---|
| **Broadcast Hash Join (BHJ)** | small side collected to driver, broadcast to every executor, hashed in memory; big side streams through | **no shuffle of the big side** | small side < `spark.sql.autoBroadcastJoinThreshold` (10 MB default, based on estimated size) or `broadcast()` hint | fastest; broadcast must fit in executor memory and driver memory; not for full outer joins with the broadcast side being the preserved one |
| **Shuffle Hash Join (SHJ)** | both sides shuffled by key; build hash table of the smaller side per partition | yes | one side much smaller per partition; `spark.sql.join.preferSortMergeJoin=false` or AQE converts | avoids sort, but the hash table must fit in memory |
| **Sort-Merge Join (SMJ)** | both sides shuffled by key, sorted, merged | yes (+ sort) | default for large–large equi-joins | scales to any size (spills); the robust default |
| **Broadcast Nested Loop** | broadcast one side; compare every pair | no | non-equi joins (`a.ts BETWEEN b.start AND b.end`) with a small side | O(n×m): dangerous |
| **Cartesian** | every pair | yes | cross joins | almost always a bug |

```mermaid
flowchart TB
  subgraph BHJ["Broadcast hash join"]
    D[(dim 50 MB)] -->|collect + broadcast once<br/>per executor| E1[exec 1: hash dim]
    D --> E2[exec 2: hash dim]
    F1[fact partitions 1..n] --> E1
    F2[fact partitions n..m] --> E2
  end
  subgraph SMJ["Sort-merge join"]
    A[(orders 2 TB)] -->|shuffle by key| P[partition k:<br/>sort both sides,<br/>merge]
    B[(payments 1 TB)] -->|shuffle by key| P
  end
```

```python
from pyspark.sql.functions import broadcast
out = orders.join(broadcast(cities), "city_id")              # force BHJ
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 100 * 1024 * 1024)  # 100 MB
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)   # disable auto-broadcast
```

**Join optimization checklist:**
1. Filter and select columns **before** joining (shrinks both sides; may make one side broadcastable).
2. Pre-aggregate the many side if you only need aggregates (`groupBy(customer).agg(...)` then join).
3. Check join keys have the **same type** (string vs int → implicit casts that block optimizations).
4. Look for exploding joins (duplicate keys on both sides): count rows before/after.
5. Big-to-big joins that repeat every day on the same key → **bucket** both tables (or use Delta/Iceberg
   with clustering) so the shuffle is avoided.

## 2. Adaptive Query Execution (AQE) — on by default since Spark 3.2

AQE re-optimizes at **stage boundaries** using real shuffle statistics:

| Feature | Config | What it does |
|---|---|---|
| Coalesce shuffle partitions | `spark.sql.adaptive.coalescePartitions.enabled` | merges small post-shuffle partitions toward `spark.sql.adaptive.advisoryPartitionSizeInBytes` (64 MB default) |
| Switch join strategy | (automatic) | if a side turns out small at runtime, SMJ → BHJ (`spark.sql.adaptive.autoBroadcastJoinThreshold`) |
| Skew join | `spark.sql.adaptive.skewJoin.enabled` | splits a partition that is > `skewedPartitionFactor` (5) × median **and** > `skewedPartitionThresholdInBytes` (256 MB) into sub-partitions, replicating the matching side |
| Local shuffle reader | automatic | after converting to BHJ, reads shuffle files locally |

Practical setup: set `spark.sql.shuffle.partitions` **high** (e.g. 2,000 for big jobs) and let AQE coalesce
down. You get parallelism when data is big and no tiny tasks when it's small.

## 3. Data skew — diagnosis and fixes

**Symptoms:** stage summary shows max task duration ≫ median (e.g. 15 min vs 8 s); one task with 40 GB shuffle
read while the rest have 200 MB; executors idle while 1–2 tasks run; spill on few tasks; OOM on one executor.

**Find the hot keys:**

```python
(orders.groupBy("customer_id").count()
       .orderBy(F.desc("count")).show(10))      # often: null, -1, "unknown", a bot, a mega-seller
```

**Fixes, in order of preference:**

1. **Filter junk keys** (nulls, `-1`) that don't need joining; handle them separately and `union` back.
2. **Broadcast** the other side if it fits: no shuffle, so no skew.
3. **AQE skew join**: on by default; check the SQL plan for `skew=true`. Tune thresholds if your skewed
   partitions are below 256 MB but still slow.
4. **Salting** for aggregations, or joins AQE can't fix:

```python
from pyspark.sql import functions as F
N = 16   # salt buckets

# Aggregation salting: two-phase aggregate
partial = (orders.withColumn("salt", (F.rand() * N).cast("int"))
                 .groupBy("seller_id", "salt").agg(F.sum("amount").alias("s")))
final = partial.groupBy("seller_id").agg(F.sum("s").alias("revenue"))

# Join salting: explode the small side N times, salt the big side randomly
sellers_salted = sellers.withColumn("salt", F.explode(F.array([F.lit(i) for i in range(N)])))
orders_salted = orders.withColumn("salt", (F.rand() * N).cast("int"))
joined = orders_salted.join(sellers_salted, ["seller_id", "salt"]).drop("salt")
```

Cost of join salting: the small side grows N×. Salt only hot keys (`when(col.isin(hot_keys), rand) else 0`) to keep it cheap.

Speculative execution (`spark.speculation=true`) helps with **slow nodes**, never with skew.

## 4. The small-files problem (in S3 / lakes)

**Why it hurts:** each file = at least one S3 GET + open cost + task scheduling + Parquet footer read;
listing millions of objects is slow; Athena/Glue planning slows down; S3 request costs.

| Cause | Fix |
|---|---|
| Streaming micro-batches writing every minute | compaction job (hourly/daily) rewriting to 256 MB–1 GB files; Delta `OPTIMIZE`, Iceberg `rewrite_data_files` |
| `partitionBy` with many tasks × values | `repartition(partition_cols)` before writing |
| Over-partitioning (by hour × country × device) | coarser partitions; target ≥ 128 MB per partition |
| Too many shuffle partitions at write | AQE coalesce, `coalesce(n)` at the end |
| Input side: thousands of tiny files | `spark.sql.files.maxPartitionBytes` packs them; `s3-dist-cp --groupBy` to merge |

Target output file size math: daily partition of 12 GB compressed → 12 GB / 512 MB ≈ **24 files**:
`df.repartition(24).write...` (or `maxRecordsPerFile` derived from average row size).

## 5. Storage layout: read less

| Technique | Effect | Example |
|---|---|---|
| Columnar (Parquet + Snappy/ZSTD) | read only needed columns; 5–10× compression vs CSV | CSV 1 TB → Parquet ~150 GB |
| Partition pruning | skip whole directories | `WHERE dt = '2025-03-01'` reads 1/365 |
| Predicate pushdown | skip row groups via min/max stats | sort by `customer_id` within files → tight ranges |
| **Dynamic partition pruning** (Spark 3) | filter on a dimension prunes fact partitions at runtime | `fact JOIN dim ON fact.dt = dim.dt WHERE dim.is_holiday` |
| Bucketing | pre-shuffled by key on disk | daily joins on `customer_id` |
| Z-order / liquid clustering (Delta), sort order (Iceberg) | multi-column data skipping | filters on `city` and `category` |

**Check pruning in the plan:** `PartitionFilters: [isnotnull(dt), (dt = 2025-03-01)]` and `PushedFilters:
[IsNotNull(amount), GreaterThan(amount,1000)]` in `explain("formatted")`. If they're missing (e.g. you wrapped the
column in a UDF or cast), pruning didn't happen.

## 6. Config cheat sheet (start here, then measure)

| Config | Default | Typical change | Why |
|---|---|---|---|
| `spark.sql.adaptive.enabled` | true (3.2+) | keep | runtime re-planning |
| `spark.sql.shuffle.partitions` | 200 | higher for big data + AQE | parallelism |
| `spark.sql.adaptive.advisoryPartitionSizeInBytes` | 64 MB | 128–256 MB | fewer, bigger tasks |
| `spark.sql.autoBroadcastJoinThreshold` | 10 MB | 50–200 MB if memory allows | more broadcast joins |
| `spark.sql.files.maxPartitionBytes` | 128 MB | 256 MB for huge scans | fewer read tasks |
| `spark.serializer` | Java | `KryoSerializer` (RDD-heavy Scala/Java code) | faster, smaller |
| `spark.sql.parquet.compression.codec` | snappy | zstd | smaller files |
| `spark.executor.memoryOverhead` | 10% | 15–25% for PySpark/Arrow | avoid YARN kills |
| `spark.dynamicAllocation.*` | on (EMR) | bound min/max | elasticity |
| `spark.speculation` | false | true for straggler-prone clusters (not with non-idempotent sinks) | slow nodes |

## 7. AWS-specific optimizations

1. **EMR runtime for Apache Spark:** EMR's Spark build includes performance optimizations
   (AWS publishes benchmarks of several times faster than OSS Spark 3.x on TPC-DS). It's on automatically.
2. **EMRFS S3-optimized committer** (default for Parquet on EMR): avoids slow S3 rename-based commits. On
   OSS Spark with S3A, use the **magic committer**.
3. **Graviton** (`m7g`/`r7g`/`c7g`): better price-performance.
4. **Spot for task nodes / executors**, plus `MEMORY_AND_DISK_2` for cached data and graceful decommission
   (Spark 3.1+ migrates shuffle/cache blocks off nodes about to be reclaimed; EMR handles Spot interruption notices).
5. **S3 request rates:** ~3,500 PUT and 5,500 GET requests per second **per prefix**. Very high-throughput
   writers spread across prefixes (partitions naturally do this); a `SlowDown` (503) error means you're throttled.
6. **Instance store (NVMe) for shuffle-heavy jobs** (`r6gd`, `m6gd`): shuffle spill to local NVMe is much faster than EBS gp3.

## 8. Diagnose → fix playbook

| Symptom in Spark UI | Likely cause | Fix |
|---|---|---|
| One/few tasks much slower; huge shuffle read on them | skew | AQE skew, salting, broadcast, isolate nulls |
| Many tasks of a few ms; thousands of tasks | too many partitions / small files | AQE coalesce, compact inputs, fewer shuffle partitions |
| Huge "Spill (disk)" | partitions too big for task memory | more shuffle partitions, more memory/overhead, fewer cores per executor |
| High GC time | memory pressure, big executors, caching too much | smaller executors, unpersist, avoid UDF object churn |
| Stage reads full table though query filters a date | no pruning | partition column type/format, avoid functions on partition columns |
| SortMergeJoin with one small side | stats missing / threshold low | `broadcast()` hint, `ANALYZE TABLE`, raise threshold |
| Executors lost / FetchFailed | Spot loss, OOM kill (137), disk full | On-Demand core, overhead, larger disks, decommissioning |
| Long time before the first task starts | listing millions of files / partitions | compaction, table format (Delta/Iceberg), Glue partition indexes |

## Key takeaways

- BHJ when one side is small (no big-side shuffle); SMJ is the robust default for big–big; avoid nested-loop and cartesian.
- AQE coalesces partitions, switches to broadcast at runtime, and splits skewed partitions. Set shuffle partitions high and let it coalesce.
- Skew: filter junk keys → broadcast → AQE → salting. Speculation doesn't fix skew.
- Read less with Parquet + partition pruning + pushdown + DPP; target 128 MB–1 GB files.
- AWS: EMR runtime, S3-optimized committer, Graviton, Spot with decommissioning, NVMe for shuffle.

## Interview scenarios

1. *A join of 2 TB orders with a 30 MB country table takes 40 min with SortMergeJoin.* — the planner's size
   estimate was over 10 MB, or stats were missing. Use `broadcast(countries)`; the big side no longer shuffles.
2. *Daily job: 199 tasks finish in 1 min, 1 task takes 45 min on `GROUP BY seller_id`.* — a mega-seller is the hot key.
   Use two-phase salted aggregation (AQE skew handling applies to joins, not aggregations).
3. *Athena queries on our Spark output are slow and expensive.* — likely CSV/JSON or tiny files, no partitioning,
   or partitions on a high-cardinality column. Rewrite as partitioned Parquet with 256 MB+ files and sort on
   common filter columns.
4. *What does AQE do that the static optimizer can't?* — it uses actual runtime statistics after each shuffle,
   rather than estimates, to change partition counts, join strategies, and skew handling.
