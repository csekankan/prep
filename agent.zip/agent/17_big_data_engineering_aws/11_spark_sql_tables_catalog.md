# 11 — Spark SQL, Table Types, and the AWS Glue Data Catalog

> **Why it matters:** "Where did my table go?" is one of the most common Spark questions. The answer
> depends on whether it was a temp view, a global temp view, a managed table, or an external table, and
> on which **metastore** the cluster used. On AWS, the Glue Data Catalog is the shared metastore that lets
> EMR, Glue, Athena, Redshift Spectrum, and Databricks see the same tables.

## In plain words

- **Temp view** = a sticky note on *your* screen. Gone when you log out (session ends).
- **Global temp view** = a note on the office whiteboard. Every colleague (session) in this office (Spark
  application) can see it until the office closes.
- **Persistent table** = an entry in the company's official filing index (metastore).
  - **Managed**: the company owns both the index card *and* the files; shredding the card shreds the files.
  - **External**: the index card points to files someone else owns; shredding the card leaves the files alone.

## Architecture at a glance

```mermaid
flowchart TB
  subgraph APP["Spark application (one driver)"]
    S1[SparkSession 1<br/>temp views: v_orders]
    S2[SparkSession 2<br/>temp views: ...]
    GT[global_temp database<br/>shared by sessions]
  end
  CAT[(Metastore =<br/>AWS Glue Data Catalog<br/>databases, tables, schemas,<br/>partitions, S3 locations)]
  subgraph S3["Amazon S3"]
    MW[warehouse path<br/>managed table data]
    EXT[your own prefixes<br/>external table data]
  end
  ATH[Athena]
  RSS[Redshift Spectrum]
  GLUE[Glue ETL]
  S1 --> GT
  S2 --> GT
  APP -->|persistent tables| CAT
  CAT -.location.-> MW
  CAT -.location.-> EXT
  ATH --> CAT
  RSS --> CAT
  GLUE --> CAT
```

**How to read it:** temp and global temp views live **only in the driver's memory**. Persistent tables are
rows in the metastore that point to S3 locations. With the Glue Data Catalog as the metastore, a table created
by Spark on a transient EMR cluster stays queryable from Athena after the cluster is gone.

## 1. Table types compared

| | Temp view | Global temp view | Managed table | External table |
|---|---|---|---|---|
| Created by | `createOrReplaceTempView` | `createOrReplaceGlobalTempView` | `saveAsTable` / `CREATE TABLE` (no LOCATION) | `CREATE TABLE ... LOCATION 's3://...'` / `option("path", ...)` |
| Stored | driver memory (a named plan) | driver memory, `global_temp` db | metastore + data under warehouse dir | metastore + data at your path |
| Visible to | that SparkSession | all sessions in the same application | anyone using the metastore | anyone using the metastore |
| Lifetime | session | application | until dropped | until dropped (data stays even after) |
| `DROP` deletes data? | n/a | n/a | **yes** | **no**, metadata only |
| Holds data? | no, just a query plan | no | yes | yes |

```python
orders.createOrReplaceTempView("v_orders")
spark.sql("SELECT count(*) FROM v_orders").show()

orders.createOrReplaceGlobalTempView("g_orders")
spark.newSession().sql("SELECT count(*) FROM global_temp.g_orders").show()   # works
spark.newSession().sql("SELECT count(*) FROM v_orders")                       # AnalysisException
```

A temp view is **not** cached data. It's an alias for a plan. Every query re-executes the plan unless you cache it (module 12).

## 2. Managed vs external tables

```sql
CREATE DATABASE IF NOT EXISTS sales
  LOCATION 's3://bigdata-course-123/warehouse/sales.db/';

-- Managed: Spark controls location and lifecycle
CREATE TABLE sales.orders_managed USING PARQUET
AS SELECT * FROM v_orders;

-- External: you control location; data survives DROP
CREATE TABLE sales.orders_ext (
  order_id STRING, customer_id INT, city STRING, status STRING,
  amount DECIMAL(12,2), order_date DATE)
USING PARQUET
PARTITIONED BY (order_date)
LOCATION 's3://bigdata-course-123/silver/orders/';

MSCK REPAIR TABLE sales.orders_ext;       -- discover existing partition directories
-- or: ALTER TABLE sales.orders_ext ADD PARTITION (order_date='2025-03-01');
```

PySpark equivalents:

```python
df.write.mode("overwrite").saveAsTable("sales.orders_managed")
df.write.mode("overwrite").option("path", f"s3://{BUCKET}/silver/orders/") \
  .partitionBy("order_date").saveAsTable("sales.orders_ext")      # external because path is given
```

### Choosing

| Choose external when | Choose managed when |
|---|---|
| data is shared with other engines/teams | a scratch or derived table owned by one pipeline |
| data must survive accidental DROP | you want DROP to clean up storage |
| raw/bronze and silver lake layers | (Delta/Iceberg/Unity Catalog: managed tables gain automatic optimization features, module 21) |

**Partition metadata trap:** files written directly to S3 under an external table's location aren't
visible until partitions are registered (`MSCK REPAIR`, `ALTER TABLE ADD PARTITION`, a Glue crawler,
or **Athena partition projection**). Table formats like Delta/Iceberg remove this problem.

## 3. The metastore: from Derby to the Glue Data Catalog

| Metastore option | Where metadata lives | Survives cluster termination? | Shared? |
|---|---|---|---|
| Embedded **Derby** (Spark/Hive default) | `metastore_db/` folder on the driver's disk | no | no, single session |
| Hive Metastore on EMR primary (local MySQL) | primary node | no | only within the cluster |
| External Hive Metastore on **RDS/Aurora MySQL** | RDS | yes | yes (Hive/Spark clusters) |
| **AWS Glue Data Catalog** | managed, serverless | yes | yes: EMR, Glue, Athena, Redshift Spectrum, Lake Formation, Databricks (via Unity Catalog federation / Glue integration) |

Enable on EMR (module 04 `configs.json`) with `spark-hive-site` and `hive-site`
`hive.metastore.client.factory.class = com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory`.
In Glue jobs, pass `--enable-glue-datacatalog`.

```python
spark = (SparkSession.builder.appName("catalog-demo")
         .enableHiveSupport()           # use the configured metastore (Glue on EMR)
         .getOrCreate())
spark.sql("SHOW DATABASES").show()
spark.catalog.listTables("sales")
```

Glue Catalog limits to know: names are lowercase; partitions are listed through API calls (millions of partitions
→ slow planning; use **partition indexes** or projection); permissions via IAM + Lake Formation.

## 4. Spark SQL in practice

Everything you can do with DataFrames you can do in SQL, compiled by the same Catalyst optimizer. Use
whichever is clearer. Spark-specific SQL worth knowing:

```sql
-- Read files directly without a table
SELECT * FROM parquet.`s3://bigdata-course-123/silver/orders/` LIMIT 10;

-- Hints
SELECT /*+ BROADCAST(c) */ o.*, c.segment
FROM sales.orders_ext o JOIN sales.customers c ON o.customer_id = c.customer_id;
SELECT /*+ REPARTITION(64, city) */ * FROM sales.orders_ext;

-- Insert overwrite one partition (idempotent daily load)
SET spark.sql.sources.partitionOverwriteMode=dynamic;
INSERT OVERWRITE TABLE sales.orders_ext PARTITION (order_date)
SELECT order_id, customer_id, city, status, amount, order_date FROM v_orders_today;

-- Metadata
DESCRIBE EXTENDED sales.orders_ext;     -- Type: EXTERNAL / MANAGED, Location, Provider
SHOW PARTITIONS sales.orders_ext;
ANALYZE TABLE sales.orders_ext COMPUTE STATISTICS FOR COLUMNS customer_id, amount;   -- helps the CBO
```

### Creating DataFrames (beyond reading files)

```python
from datetime import date
from decimal import Decimal
rows = [("o1", 10, "Pune", "delivered", Decimal("120.00"), date(2025, 3, 1))]
df1 = spark.createDataFrame(rows, schema=ORDERS_SCHEMA_NO_CORRUPT)
df2 = spark.range(0, 1_000_000).withColumn("bucket", F.col("id") % 10)    # synthetic data
df3 = spark.createDataFrame(pandas_df)                                     # Arrow-accelerated
df4 = spark.table("sales.orders_ext")
df5 = spark.sql("SELECT * FROM sales.orders_ext WHERE order_date >= '2025-03-01'")
```

## 5. Choosing the right table type (exercise with solution)

| Scenario | Choice | Why |
|---|---|---|
| Intermediate result reused by 3 queries in one notebook | temp view (+ `cache`) | session-scoped, no storage |
| Two concurrent sessions in a Spark Thrift server/app need a shared lookup | global temp view | application-scoped |
| Raw clickstream landed by Firehose, queried by Athena and Spark | **external** table (Glue Catalog) | files owned by the ingestion process; DROP must not delete them |
| Nightly aggregate owned solely by one job | managed (or a Delta/Iceberg managed table) | lifecycle tied to the table |
| Table must be queryable after the EMR cluster terminates | any persistent table **in the Glue Catalog** | Derby/local metastore die with the cluster |

## 6. "Why did my table disappear?" (stakeholder explanation)

"Our job registered the results as a *temporary view*: a named query that only exists while that Spark
session runs. When the job finished, the name vanished. The underlying files were never written. Separately,
last month's table disappeared because the cluster used its built-in local catalog, which is deleted with
the cluster. We've switched to the shared AWS Glue Data Catalog and now write real external tables to S3,
so tables outlive the jobs and clusters that create them."

## Key takeaways

- Temp view = session; global temp view = application (`global_temp.`); neither stores data.
- Managed: DROP deletes data. External: DROP keeps data. Use external for shared lake layers.
- Derby/local metastores die with the cluster; use the Glue Data Catalog (or RDS-backed Hive metastore) on AWS.
- External tables need partition registration (MSCK, crawler, projection) unless you use Delta/Iceberg.
- SQL and DataFrames compile to the same plan; hints and `ANALYZE TABLE` influence it.

## Interview scenarios

1. *A colleague dropped `sales.orders` and 3 years of data vanished. Prevention?* — it was managed. Make shared
   tables external, enable S3 versioning, restrict `DROP` via Lake Formation/IAM, and use Delta/Iceberg time
   travel with retention.
2. *Athena can't see new data that Spark wrote to an external table's S3 path.* — partitions aren't registered.
   Run `MSCK REPAIR`/`ADD PARTITION`, a crawler, or configure partition projection.
3. *Global temp view vs temp view in one sentence?* — temp views belong to a SparkSession; global temp views
   belong to the Spark application and are accessed via `global_temp`.
