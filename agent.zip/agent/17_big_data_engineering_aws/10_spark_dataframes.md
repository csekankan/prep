# 10 — Spark DataFrames: Read, Schema, Modes, Write, Types, Dates, Catalyst

> **Why it matters:** 95% of production Spark code is DataFrames. The silent killers in data pipelines
> are schema inference surprises, permissive reads that turn bad rows into nulls without telling
> anyone, write modes that wipe a table, and timezone bugs in dates. This module goes through each of them
> and shows what Catalyst does with your code.

## In plain words

A DataFrame is a **distributed table with a declared schema**: a recipe for producing rows, not the
rows themselves. Because Spark knows the column names and types, it can rewrite your recipe into a
faster one (Catalyst) and store rows in a compact binary format (Tungsten), instead of millions of
Python/Java objects.

## Architecture at a glance — Catalyst + Tungsten

```mermaid
flowchart LR
  Q[DataFrame code / SQL] --> UL[Unresolved<br/>logical plan]
  UL -->|Analyzer +<br/>Catalog: resolve<br/>columns, types| AL[Analyzed<br/>logical plan]
  AL -->|Optimizer rules:<br/>predicate pushdown,<br/>column pruning,<br/>constant folding,<br/>join reorder| OL[Optimized<br/>logical plan]
  OL -->|Planner:<br/>choose join strategy,<br/>scan type| PP[Physical plans]
  PP -->|cost model| SP[Selected<br/>physical plan]
  SP -->|Tungsten:<br/>whole-stage codegen,<br/>binary rows,<br/>off-heap memory| RDD[RDD of<br/>InternalRow]
  SP -.AQE re-optimizes<br/>at runtime using<br/>shuffle stats.-> SP
```

**How to read it:** your code becomes a logical plan. The analyzer resolves names against the catalog;
a missing column fails here, before any job runs. The optimizer applies rule-based rewrites; the planner
picks physical operators (e.g. broadcast vs sort-merge join). Tungsten generates compact JVM bytecode for
entire stages. **AQE** (Adaptive Query Execution) re-plans between stages using real statistics.

See it yourself:

```python
df.explain(mode="formatted")     # or "extended" to see all four plans
```

## 1. Reading from S3 (and HDFS)

```python
from pyspark.sql import SparkSession
spark = (SparkSession.builder.appName("orders-ingest")
         .config("spark.sql.session.timeZone", "UTC")
         .getOrCreate())

orders = (spark.read
    .format("csv")
    .option("header", True)
    .option("inferSchema", False)       # do NOT infer in production
    .schema(ORDERS_SCHEMA)              # explicit schema (section 3)
    .option("mode", "PERMISSIVE")
    .option("columnNameOfCorruptRecord", "_corrupt_record")
    .load("s3://bigdata-course-123/raw/orders/"))   # EMR: s3://  (EMRFS); OSS Spark: s3a://
```

| Path scheme | Where | Notes |
|---|---|---|
| `s3://` | EMR (EMRFS), Glue | recommended on EMR |
| `s3a://` | open-source Hadoop S3A (local Spark, EKS) | needs `hadoop-aws` jar + credentials provider |
| `hdfs:///path` | cluster HDFS | |
| `file:///path` | local disk of **every** executor | only works if the file exists on all nodes |

Options worth knowing: `recursiveFileLookup`, `pathGlobFilter="*.csv"`, `modifiedAfter`, `multiLine`
(JSON/CSV with embedded newlines — makes files non-splittable), `sep`, `quote`, `escape`, `nullValue`,
`dateFormat`, `timestampFormat`.

## 2. Is `spark.read` a transformation or an action?

It's **lazy in principle**, but some reads trigger jobs immediately:

| Read | Triggers a job at read time? | Why |
|---|---|---|
| Parquet / ORC / Delta | small metadata ops only | schema is in the file footer / log |
| CSV with `header=True`, no schema | **yes**, a small job | reads the first line to get column names |
| CSV/JSON with `inferSchema=True` | **yes**, a full pass over the data (or a `samplingRatio`) | to infer types |
| Any format with an explicit `.schema(...)` | **no** | nothing to discover |

**Lesson:** on 2 TB of CSV, `inferSchema=True` reads the data **twice** (once to infer, once to process).
Always supply a schema.

## 3. Schema enforcement

```python
from pyspark.sql.types import (StructType, StructField, StringType, IntegerType,
                               DecimalType, DateType)

ORDERS_SCHEMA = StructType([
    StructField("order_id",    StringType(),        nullable=False),
    StructField("customer_id", IntegerType(),       True),
    StructField("city",        StringType(),        True),
    StructField("status",      StringType(),        True),
    StructField("amount",      DecimalType(12, 2),  True),
    StructField("order_date",  DateType(),          True),
    StructField("_corrupt_record", StringType(),    True),   # captures bad lines in PERMISSIVE mode
])
# DDL string alternative:
# "order_id STRING, customer_id INT, city STRING, status STRING, amount DECIMAL(12,2), order_date DATE"
```

Why explicit schemas:
1. **Performance:** no inference pass.
2. **Correctness:** inference may read `00123` as int 123 (zip codes, IDs), or pick string if one row is dirty.
3. **Contracts:** a changed source shows up as corrupt records or a failure instead of a silently different schema.

Note: `nullable=False` on file sources is **not enforced** on read (Spark treats file-source columns as
nullable). Enforce with explicit checks or table constraints (Delta `NOT NULL` / `CHECK`).

## 4. Read modes — and the silent-failure trap

| Mode | Bad row behavior | Use when |
|---|---|---|
| `PERMISSIVE` (default) | unparseable fields → `null`; whole raw line in `_corrupt_record` if that column is in the schema | ingest + quarantine pattern |
| `DROPMALFORMED` | row silently dropped | almost never: data loss with no trace |
| `FAILFAST` | throws on the first bad row | strict contracts, small trusted feeds |

**Quarantine pattern (production standard):**

```python
raw = spark.read.schema(ORDERS_SCHEMA).option("header", True) \
        .option("mode", "PERMISSIVE").csv(src).cache()   # cache: required to query _corrupt_record alone

bad  = raw.where("_corrupt_record IS NOT NULL")
good = raw.where("_corrupt_record IS NULL").drop("_corrupt_record")

bad_count, total = bad.count(), raw.count()
bad.write.mode("append").json(f"s3://{BUCKET}/quarantine/orders/dt={run_date}/")
if total and bad_count / total > 0.01:
    raise ValueError(f"{bad_count}/{total} corrupt rows > 1% threshold — failing the run")
good.write.mode("overwrite").parquet(f"s3://{BUCKET}/silver/orders/dt={run_date}/")
```

(Since Spark 2.3, a query that references **only** the internal corrupt-record column is disallowed on raw
CSV/JSON. Cache or persist first, as above.)

## 5. Writing data

```python
(df.write
   .mode("overwrite")                       # see table below
   .partitionBy("order_date")               # directory per value: order_date=2025-03-01/
   .option("compression", "snappy")         # Parquet default; zstd = smaller files
   .parquet(f"s3://{BUCKET}/silver/orders/"))
```

| Save mode | If target exists |
|---|---|
| `errorifexists` / `error` (default) | throw |
| `append` | add files (re-running duplicates data!) |
| `overwrite` | replace the target. With `partitionBy`, **static** mode (default) wipes **all** partitions |
| `ignore` | do nothing |

**Dynamic partition overwrite**: rewrite only the partitions present in the DataFrame, which makes
daily reruns idempotent:

```python
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
daily_df.write.mode("overwrite").partitionBy("order_date").parquet(path)
```

### Output layout decisions

| Technique | What it does | Guideline |
|---|---|---|
| `partitionBy(col)` | directories per value, enabling **partition pruning** | low cardinality (date, region); aim for ≥ 128 MB per partition; never partition by user_id |
| `bucketBy(n, col)` + `saveAsTable` | hash files into n buckets; joins/aggregations on that key can skip the shuffle | needs a metastore table; Spark-specific bucketing |
| `maxRecordsPerFile` | cap file size | prevents 10 GB files |
| `repartition(col)` before `partitionBy(col)` | one file per partition directory instead of (tasks × partitions) files | standard small-file prevention |

**File count math:** 200 tasks writing `partitionBy("order_date")` with 365 dates present in each task →
up to 200 × 365 = **73,000 files**. `df.repartition("order_date").write.partitionBy("order_date")` → 365 files.

### File formats

| Format | Layout | Splittable | Schema | Best for |
|---|---|---|---|---|
| CSV | row, text | yes (uncompressed) | none | interchange only |
| JSON | row, text | yes (line-delimited) | weak | raw events |
| Avro | row, binary | yes | embedded, evolution | Kafka, row-wise writes |
| **Parquet** | **columnar**, row groups (~128 MB) with min/max stats | yes | embedded | analytics default |
| ORC | columnar, stripes | yes | embedded | Hive ecosystems |
| Delta / Iceberg / Hudi | Parquet + transaction log | yes | managed + evolution | lakehouse tables (module 21) |

## 6. Core DataFrame operations (the idioms, not the basics)

```python
from pyspark.sql import functions as F, Window

df = (orders
  .withColumn("city", F.initcap(F.trim("city")))
  .withColumn("is_big", F.when(F.col("amount") >= 1000, True).otherwise(False))
  .withColumn("amount", F.coalesce("amount", F.lit(0)))
  .dropDuplicates(["order_id"])                         # dedupe on business key
  .na.fill({"status": "unknown"}))

# window: latest order per customer and running revenue
w_latest = Window.partitionBy("customer_id").orderBy(F.col("order_date").desc())
w_running = (Window.partitionBy("customer_id").orderBy("order_date")
                   .rowsBetween(Window.unboundedPreceding, Window.currentRow))
df = (df.withColumn("rn", F.row_number().over(w_latest))
        .withColumn("running_rev", F.sum("amount").over(w_running)))
latest = df.where("rn = 1")

# conditional aggregation
summary = df.groupBy("city").agg(
    F.count("*").alias("orders"),
    F.sum(F.when(F.col("status") == "cancelled", 1).otherwise(0)).alias("cancelled"),
    F.round(F.avg("amount"), 2).alias("aov"),
    F.approx_count_distinct("customer_id").alias("customers_approx"))
```

| Anti-pattern | Better |
|---|---|
| Loop of `withColumn` × 200 columns | one `select([...])` (each `withColumn` adds a projection; big plans slow analysis) |
| `df.collect()` to process in Python | push logic into Spark functions |
| `count()` to check emptiness | `df.isEmpty()` (Spark 3.3+) or `df.limit(1).count()` |
| Python UDF for string/date logic | built-ins (`regexp_extract`, `to_date`, `date_trunc`) |

## 7. Handling data types

| Type | Gotcha |
|---|---|
| `DoubleType` for money | floating-point error: `0.1 + 0.2 = 0.30000000000000004`. Use `DecimalType(p, s)` |
| `DecimalType` overflow | precision is capped at 38; with ANSI off, overflow returns null |
| Casting bad strings | `cast("int")` returns **null** silently (ANSI off). With `spark.sql.ansi.enabled=true` it throws (ANSI is the default in Spark 4.0) |
| `IntegerType` IDs | 2.1 B max; use `LongType` for growing IDs |
| `StringType` numbers | sorting `"10" < "9"`; compare after casting |
| Complex types | `ArrayType`, `MapType`, `StructType`: use `explode`, `posexplode`, `col("a.b")`, `transform()`, `filter()` higher-order functions |

```python
df = df.withColumn("amount_num", F.col("amount_str").cast("decimal(12,2)"))
bad_casts = df.where(F.col("amount_str").isNotNull() & F.col("amount_num").isNull())   # detect silent nulls
```

## 8. Handling dates and timestamps

```python
df = (df
  .withColumn("order_date", F.to_date("order_date_str", "dd/MM/yyyy"))
  .withColumn("order_ts",   F.to_timestamp("order_ts_str", "yyyy-MM-dd HH:mm:ss"))
  .withColumn("order_ts_utc", F.to_utc_timestamp("order_ts", "Asia/Kolkata"))
  .withColumn("year",  F.year("order_date"))
  .withColumn("month_start", F.trunc("order_date", "month"))
  .withColumn("dow", F.dayofweek("order_date"))                    # 1 = Sunday
  .withColumn("days_to_deliver", F.datediff("delivered_date", "order_date"))
  .withColumn("hour_bucket", F.date_trunc("hour", "order_ts")))
```

Rules that prevent real bugs:
1. Set `spark.sql.session.timeZone=UTC` on every job; convert to local time only for presentation.
2. `TimestampType` is an instant (stored as UTC micros, displayed in session TZ). `TimestampNTZType` (3.4+) is wall-clock without a timezone.
3. Pattern letters: `MM` = month, `mm` = minute; `yyyy` vs `YYYY` (week-based year → wrong dates around New Year).
4. Unparseable dates → null (non-ANSI). Count nulls after parsing.
5. Partition columns: `dt=2025-03-01` strings sort correctly; derive them from the UTC date.

## 9. Debugging a silent data-ingestion failure (scenario with solution)

> *Daily revenue dropped 18% overnight. No job failed. Source volume is normal.*

1. Compare row counts: raw lines vs rows written. Equal → rows weren't dropped; values changed.
2. Null profile per column: `df.select([F.sum(F.col(c).isNull().cast("int")).alias(c) for c in df.columns])`
   → `amount` is 18% null today, ~0% yesterday.
3. Inspect raw rows where `amount` is null → the source started sending `1.234,56` (European format) for one region.
4. Root cause: `PERMISSIVE` + cast to decimal → null, with no alert.
5. Fix: parse with `regexp_replace` for that format; add a **data quality gate** (null-rate thresholds,
   row-count deltas, Glue Data Quality / Great Expectations) that fails the run; route corrupt rows to quarantine.

## Key takeaways

- Catalyst: analyze → optimize (pushdown, pruning) → physical planning → codegen; AQE re-optimizes at runtime.
- Explicit schemas avoid inference jobs and type surprises; `inferSchema` reads data twice.
- PERMISSIVE + `_corrupt_record` + quarantine + thresholds; never `DROPMALFORMED` silently.
- Use dynamic partition overwrite for idempotent reruns; `repartition(col)` before `partitionBy(col)` to avoid file explosions.
- Decimal for money, UTC session timezone, verify casts and date parses (they fail to null silently).

## Interview scenarios

1. *Why does `spark.read.csv(path, inferSchema=True)` launch a job before any action?* — inference needs to
   scan data to decide types; header detection also reads the file.
2. *A rerun of yesterday's job doubled the data.* — `append` mode is not idempotent. Use dynamic partition
   overwrite, `MERGE` (Delta/Iceberg), or delete-then-write of that partition.
3. *Which read mode would you use for a partner feed with an SLA?* — PERMISSIVE with corrupt-record capture,
   quarantine, and an error-rate threshold. FAILFAST if any bad row must block downstream.
4. *Your write produced 120,000 small files.* — tasks × partition values. `repartition` on the partition
   column (or a target count) before writing; set `maxRecordsPerFile`; compact later.
