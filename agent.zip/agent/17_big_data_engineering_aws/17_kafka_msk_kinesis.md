# 17 — Apache Kafka, Amazon MSK & Kinesis Data Streams

> **Why it matters:** batch pipelines answer "what happened yesterday". Streaming answers "what is
> happening now": fraud checks, live inventory, CDC replication, clickstream. Kafka is the backbone of
> most streaming architectures. On AWS you run it as **Amazon MSK**, or use the AWS-native alternative,
> **Kinesis Data Streams**. Knowing partitions, replication, offsets, and delivery semantics lets you
> design pipelines that don't lose or duplicate data.

## In plain words

Kafka is a **set of append-only notebooks** (topics), each split into **pages written in parallel**
(partitions), photocopied to several shelves (replicas). Writers (producers) append lines at the end.
Readers (consumers) keep a **bookmark** (offset) of how far they've read. Reading doesn't erase anything,
so many independent teams can read the same notebook at their own pace, and anyone can rewind.

## Architecture at a glance

```mermaid
flowchart LR
  subgraph PROD["Producers"]
    P1[orders-service]
    P2[clickstream SDK]
    P3[Debezium CDC]
  end
  subgraph CLUSTER["Kafka cluster (MSK, brokers across 3 AZs)"]
    subgraph B1["Broker 1 (AZ a)"]
      T0L[orders-p0 LEADER]
      T1F[orders-p1 follower]
    end
    subgraph B2["Broker 2 (AZ b)"]
      T1L[orders-p1 LEADER]
      T2F[orders-p2 follower]
    end
    subgraph B3["Broker 3 (AZ c)"]
      T2L[orders-p2 LEADER]
      T0F[orders-p0 follower]
    end
    CTRL[KRaft controller quorum<br/>metadata, leader election]
  end
  subgraph CG1["Consumer group: fraud-svc"]
    C1[consumer 1: p0, p1]
    C2[consumer 2: p2]
  end
  subgraph CG2["Consumer group: lake-sink"]
    S1[Spark / Firehose / Connect<br/>→ S3]
  end
  PROD -->|write to partition leaders| CLUSTER
  T0L -.replicate.-> T0F
  T1L -.-> T1F
  T2L -.-> T2F
  CLUSTER --> CG1
  CLUSTER --> CG2
```

**How to read it:** a topic's partitions are spread over brokers. Each partition has one **leader**
(serving reads and writes) and followers in other AZs. Producers write to leaders. Each **consumer group** gets
every message once, with partitions divided among the group's members. Different groups read independently.

## 1. Why Kafka (use cases)

| Problem without Kafka | Kafka's answer |
|---|---|
| N producers × M consumers = N×M point-to-point integrations | one durable log in the middle: N + M connections |
| Consumer down = data lost | messages retained (hours to forever); consumer resumes from its offset |
| Spiky traffic overwhelms downstream | Kafka buffers; consumers read at their own speed (backpressure) |
| Need replay after a bug | reset offsets and reprocess |
| Ordering of events per entity | ordering guaranteed **within a partition** (key = entity id) |

Use cases: event-driven microservices, CDC (Debezium → Kafka → lake), log/metrics aggregation, clickstream,
stream processing (Kafka Streams, Flink, Spark Structured Streaming), feeding ML features in real time.

## 2. Architecture deep dive

### Topics, partitions, segments, offsets

```
 topic "orders", partition 0  (a log on disk, split into segment files)
 ┌─────────────────────────────────────────────────────────────┐
 │ 0 │ 1 │ 2 │ 3 │ 4 │ 5 │ 6 │ 7 │ 8 │ 9 │ 10 │ 11 │ ...  ← new writes append here
 └─────────────────────────────────────────────────────────────┘
   ▲ log start (older segments deleted by retention)     ▲ fraud-svc committed offset = 8
                                                          ▲ lake-sink committed offset = 3 (lagging)
```

- **Offset** = position within a partition (monotonically increasing). Ordering exists only per partition.
- **Segments**: each partition is a series of files (1 GB default `segment.bytes`) with offset and time
  indexes. Retention deletes whole old segments.
- **Retention**: by time (`retention.ms`, default 7 days) and/or size; or **log compaction**
  (`cleanup.policy=compact`) keeps only the latest value per key (changelogs, CDC state).
- **Why it's fast:** sequential disk appends, OS page cache, zero-copy `sendfile` to consumers, batching and compression.

### Partitioning: choosing the key

`partition = murmur2(key) mod num_partitions`. A null key uses the **sticky partitioner** (fills a batch
for one partition, then switches) for better batching.

| Key choice | Effect |
|---|---|
| `order_id` | even spread; ordering per order |
| `customer_id` | all of a customer's events ordered; hot customers → hot partitions |
| `country` | few distinct values → massive skew |
| null | best spread, no ordering |

**Partition count sizing:** target throughput / per-partition throughput. If one consumer handles 10 MB/s and
you need 200 MB/s → ≥ 20 partitions (round up for growth: 30–60). Consumers in a group ≤ partitions; extra
consumers sit idle. Increasing partitions later **changes key → partition mapping**, which breaks per-key
ordering for existing keys.

### Replication, ISR, and durability

- **Replication factor** (RF) = 3 in production (across 3 AZs on MSK).
- **ISR** (in-sync replicas) = replicas caught up within `replica.lag.time.max.ms` (30 s).
- **`acks`** on the producer: `0` (fire and forget), `1` (leader wrote it), `all` (all ISR wrote it; default since Kafka 3.0).
- **`min.insync.replicas`** on the topic/broker: with `acks=all`, the write fails if ISR < this.

$$
\text{RF}=3,\ \text{min.insync.replicas}=2,\ \text{acks=all} \Rightarrow \text{tolerates 1 broker loss with no data loss and no write outage}
$$

**Read it as:** each write lands on at least 2 brokers before it's acknowledged; if one broker dies, the other
copy becomes leader; with only one replica left, writes are rejected rather than risking loss.

- `unclean.leader.election.enable=false` (default): never elect an out-of-sync replica, so data isn't silently lost.

### Controller: ZooKeeper → KRaft

Kafka historically stored metadata in ZooKeeper. **KRaft** (Kafka Raft) moves it into a quorum of Kafka
controller nodes; **Kafka 4.0 removed ZooKeeper entirely**. MSK supports KRaft-mode clusters for newer Kafka versions.

## 3. Producer internals

```mermaid
flowchart LR
  APP[produce key,value] --> SER[serializer<br/>JSON/Avro/Protobuf]
  SER --> PART[partitioner]
  PART --> ACC[record accumulator<br/>batch per partition<br/>batch.size, linger.ms]
  ACC --> SENDER[sender thread<br/>compress batch<br/>max.in.flight]
  SENDER --> BRK[partition leader]
  BRK -->|ack per acks setting| SENDER
  SENDER -->|delivery callback<br/>served by poll / flush| APP
```

| Setting | Meaning | Production value |
|---|---|---|
| `acks` | durability | `all` |
| `enable.idempotence` | broker dedupes retries using producer id + sequence numbers (exactly-once per partition per session) | `true` (default in modern clients) |
| `linger.ms` | wait to fill batches | 5–50 ms for throughput |
| `batch.size` | max batch bytes per partition | 64–256 KB for high throughput |
| `compression.type` | lz4 / zstd / snappy | `lz4` or `zstd` |
| `retries`, `delivery.timeout.ms` | retry window | defaults are fine with idempotence |

### Callback, poll, and flush (confluent-kafka / librdkafka)

- `produce()` is **asynchronous**: it enqueues to a local buffer and returns immediately.
- Delivery reports (success/failure callbacks) run only when you call **`poll()`** (or `flush()`).
- **`flush()`** blocks until all queued messages are delivered or fail. Without it, a script that exits
  **loses whatever is still in the buffer**.

## 4. Consumer internals

| Concept | Detail |
|---|---|
| Consumer group | members share partitions; each partition → exactly one member of the group |
| Group coordinator | broker that manages membership and stores offsets in the internal topic `__consumer_offsets` |
| Poll loop | `poll()` fetches batches; you must call it at least every `max.poll.interval.ms` (5 min default) or you get kicked out of the group |
| Heartbeats | background thread; `session.timeout.ms` (45 s default) → dead member detection |
| Rebalance | on join/leave/crash/new partitions. **Eager** (stop-the-world) vs **cooperative-sticky** (incremental, only moved partitions pause). New **KIP-848** consumer protocol (Kafka 4.0) moves assignment to the broker |
| `auto.offset.reset` | where a group with **no committed offset** starts: `latest` (default) or `earliest` |
| Commit | auto (`enable.auto.commit=true`, every 5 s) or manual after processing |
| Lag | log end offset − committed offset: the key health metric |

### Delivery semantics

| Semantics | How | Risk |
|---|---|---|
| At most once | commit **before** processing | crash after commit → message lost |
| **At least once** (typical) | process, **then** commit | crash before commit → reprocessed → make processing **idempotent** (upserts, dedupe keys) |
| Exactly once | idempotent producer + **transactions** (`read_committed` consumers) for Kafka→Kafka; for Kafka→external sinks, idempotent/transactional writes (e.g. Spark checkpoint + Delta/Iceberg) | complexity |

## 5. Ways to run Kafka

| Option | Ops burden | Notes |
|---|---|---|
| Local Docker (KRaft single node) | you | development (module 18 compose file) |
| Self-managed on EC2 / EKS (Strimzi) | high | full control |
| **Amazon MSK Provisioned** | brokers managed by AWS; you choose broker type/count, storage, configs | standard or **Express** brokers (faster scaling, less storage management) |
| **Amazon MSK Serverless** | none: pay per throughput/partition/hour | IAM auth only; quotas per cluster |
| Confluent Cloud (original course) | none | available in AWS Marketplace |
| Kinesis Data Streams | none | AWS-native API, not Kafka protocol |

## 6. Hands-on: MSK Serverless + Python producer/consumer with IAM

### Create the cluster

```bash
aws kafka create-cluster-v2 --cluster-name bigdata-msk \
  --serverless '{"VpcConfigs":[{"SubnetIds":["subnet-a","subnet-b","subnet-c"],
                                "SecurityGroupIds":["sg-xxxx"]}],
                 "ClientAuthentication":{"Sasl":{"Iam":{"Enabled":true}}}}'
CLUSTER_ARN=$(aws kafka list-clusters-v2 --cluster-name-filter bigdata-msk \
  --query 'ClusterInfoList[0].ClusterArn' --output text)
aws kafka get-bootstrap-brokers --cluster-arn $CLUSTER_ARN   # ...:9098 (SASL/IAM)
```

MSK lives inside your VPC. Run clients from an EC2 instance / Cloud9 replacement / container in the same VPC
(security group allows 9098). The client's IAM role needs `kafka-cluster:Connect`, `DescribeTopic`,
`CreateTopic`, `WriteData`, `ReadData`, `AlterGroup`, `DescribeGroup` on the cluster/topic/group ARNs.

### Kafka CLI with IAM

```bash
# client.properties (plus aws-msk-iam-auth jar on the classpath)
security.protocol=SASL_SSL
sasl.mechanism=AWS_MSK_IAM
sasl.jaas.config=software.amazon.msk.auth.iam.IAMLoginModule required;
sasl.client.callback.handler.class=software.amazon.msk.auth.iam.IAMClientCallbackHandler
```

```bash
kafka-topics.sh --bootstrap-server $BOOTSTRAP --command-config client.properties \
  --create --topic orders --partitions 6
kafka-console-producer.sh --bootstrap-server $BOOTSTRAP --producer.config client.properties \
  --topic orders --property parse.key=true --property key.separator=:
kafka-console-consumer.sh --bootstrap-server $BOOTSTRAP --consumer.config client.properties \
  --topic orders --group cli-test --from-beginning --property print.key=true --property print.partition=true
kafka-consumer-groups.sh --bootstrap-server $BOOTSTRAP --command-config client.properties \
  --describe --group fraud-svc        # per-partition CURRENT-OFFSET, LOG-END-OFFSET, LAG
```

### Python producer (multiple messages, callbacks, poll, flush)

```python
# pip install confluent-kafka aws-msk-iam-sasl-signer-python
import json, os, random, time, uuid
from confluent_kafka import Producer
from aws_msk_iam_sasl_signer import MSKAuthTokenProvider

REGION, BOOTSTRAP = os.environ["AWS_REGION"], os.environ["BOOTSTRAP"]

def oauth_cb(_config):
    token, expiry_ms = MSKAuthTokenProvider.generate_auth_token(REGION)
    return token, expiry_ms / 1000

producer = Producer({
    "bootstrap.servers": BOOTSTRAP,
    "security.protocol": "SASL_SSL",
    "sasl.mechanisms": "OAUTHBEARER",
    "oauth_cb": oauth_cb,
    "acks": "all",
    "enable.idempotence": True,
    "linger.ms": 20,
    "compression.type": "lz4",
})

def on_delivery(err, msg):
    if err:
        print(f"FAILED key={msg.key()}: {err}")         # alert / dead-letter in real systems
    else:
        print(f"ok {msg.topic()}[{msg.partition()}]@{msg.offset()}")

for i in range(1000):
    order = {"order_id": str(uuid.uuid4()), "customer_id": random.randint(1, 500),
             "amount": round(random.uniform(10, 900), 2), "ts": time.time()}
    producer.produce("orders", key=str(order["customer_id"]), value=json.dumps(order),
                     on_delivery=on_delivery)
    producer.poll(0)          # serve delivery callbacks; non-blocking
producer.flush(30)            # block until everything is delivered (or 30 s)
```

### Python consumer (at-least-once with manual commits)

```python
from confluent_kafka import Consumer, KafkaException

consumer = Consumer({
    "bootstrap.servers": BOOTSTRAP, "security.protocol": "SASL_SSL",
    "sasl.mechanisms": "OAUTHBEARER", "oauth_cb": oauth_cb,
    "group.id": "fraud-svc",
    "auto.offset.reset": "earliest",
    "enable.auto.commit": False,
    "partition.assignment.strategy": "cooperative-sticky",
})
consumer.subscribe(["orders"])
try:
    while True:
        msg = consumer.poll(1.0)
        if msg is None:
            continue
        if msg.error():
            raise KafkaException(msg.error())
        order = json.loads(msg.value())
        if order["amount"] > 800:
            print("review:", order["order_id"])     # idempotent side effect (upsert by order_id)
        consumer.commit(message=msg, asynchronous=False)   # commit AFTER processing
finally:
    consumer.close()           # leaves the group cleanly → fast rebalance
```

(Commit per message is simple but slow; in production, commit every N messages or every few seconds.)

### Streaming MSK → S3 with Spark Structured Streaming (lake sink)

```python
from pyspark.sql import functions as F
schema = "order_id STRING, customer_id INT, amount DOUBLE, ts DOUBLE"
stream = (spark.readStream.format("kafka")
  .option("kafka.bootstrap.servers", BOOTSTRAP)
  .option("subscribe", "orders")
  .option("startingOffsets", "earliest")
  .option("kafka.security.protocol", "SASL_SSL")
  .option("kafka.sasl.mechanism", "AWS_MSK_IAM")
  .option("kafka.sasl.jaas.config", "software.amazon.msk.auth.iam.IAMLoginModule required;")
  .option("kafka.sasl.client.callback.handler.class",
          "software.amazon.msk.auth.iam.IAMClientCallbackHandler")
  .load()
  .select(F.from_json(F.col("value").cast("string"), schema).alias("o"), "timestamp")
  .select("o.*", F.to_date("timestamp").alias("dt")))

(stream.writeStream.format("parquet")
   .option("path", f"s3://{BUCKET}/bronze/orders_stream/")
   .option("checkpointLocation", f"s3://{BUCKET}/checkpoints/orders_stream/")  # offsets → exactly-once file sink
   .partitionBy("dt").trigger(processingTime="1 minute").start())
```

No-code alternatives: **MSK Connect** (Kafka Connect S3 sink), **Amazon Data Firehose** with MSK as source.

## 7. Kinesis Data Streams vs MSK

| | Kinesis Data Streams | Amazon MSK |
|---|---|---|
| API | AWS SDK / KCL (not Kafka) | Kafka protocol: the whole Kafka ecosystem works |
| Unit of scale | **shard**: 1 MB/s or 1,000 records/s write, 2 MB/s read | partition (throughput depends on brokers) |
| Capacity modes | provisioned shards or **on-demand** | provisioned brokers or serverless |
| Retention | 24 h default, up to 365 days | configurable, unlimited with tiered storage |
| Ordering | per shard (partition key) | per partition (key) |
| Consumers | shared 2 MB/s/shard, or **enhanced fan-out** 2 MB/s per consumer per shard | as many groups as brokers can serve |
| Integrations | Lambda, Firehose, Managed Service for Apache Flink, native IAM | Kafka Connect, Debezium, Flink, Spark, Lambda, Firehose |
| Pick when | AWS-native, small team, minimal ops, Lambda-centric | existing Kafka skills/tools, CDC with Debezium, very high throughput, portability |

**Shard math:** 5,000 events/s × 2 KB = 10 MB/s write → \(\max(10/1, 5000/1000) = 10\) shards (provisioned), or on-demand.

## 8. Diagnosing missing Kafka messages (scenario with solution)

> *The producer team says 1,000,000 events were sent; the S3 sink has 962,000.*

Walk the pipeline and check each hypothesis:

| Hypothesis | Check | Fix |
|---|---|---|
| Producer exited before delivering | producer logs: delivery callback failures? script calls `flush()`? | always `flush()`; alert on callback errors |
| `acks=1` + leader crash | broker logs for leader change during the window | `acks=all`, `min.insync.replicas=2` |
| New consumer group started with `auto.offset.reset=latest` | group's first committed offsets vs topic start | `earliest` for new sinks; or reset offsets |
| Auto-commit before processing + crash | consumer crashed during the window? | manual commit after processing |
| Retention deleted unconsumed data | consumer lag exceeded retention? | larger retention, lag alerts |
| Deserialization errors silently skipped | sink error counters / DLQ | dead-letter topic + metrics |
| Wrong counting: duplicates on one side | dedupe by `order_id` before comparing | idempotent sink |

Tools: `kafka-consumer-groups --describe` (lag), `kafka-get-offsets` / `GetOffsetShell` (end offsets per
partition), and the CloudWatch MSK metrics `MaxOffsetLag`, `SumOffsetLag`, `UnderReplicatedPartitions`.

## Key takeaways

- Topic → partitions (ordering unit, parallelism unit) → replicated across AZs; consumers track offsets.
- Durability recipe: RF 3, `min.insync.replicas=2`, `acks=all`, idempotent producer, no unclean leader election.
- `produce()` is async: `poll()` serves callbacks and `flush()` guarantees delivery before exit.
- At-least-once (process then commit) + idempotent sinks is the practical default; exactly-once needs transactions or transactional sinks.
- On AWS: MSK (Kafka API, ecosystem) vs Kinesis (AWS-native, shards, minimal ops).

## Interview scenarios

1. *Why can't I add more consumers to speed up my group beyond 12 instances?* — the topic has 12 partitions; each
   partition goes to one consumer in a group. Add partitions (mind key ordering) or speed up processing per consumer.
2. *Guarantee no message loss when one broker fails.* — RF 3, `min.insync.replicas=2`, `acks=all`, idempotence on,
   unclean election off, consumer commits after processing.
3. *The consumer keeps rebalancing every few minutes.* — processing a batch takes longer than `max.poll.interval.ms`.
   Lower `max.poll.records`, speed up processing, raise the interval, use cooperative-sticky assignment and static membership.
4. *MSK or Kinesis for a Debezium CDC pipeline from Aurora?* — MSK (with MSK Connect), because Debezium is a
   Kafka Connect connector. For pure AWS-native without Kafka, consider DMS → Kinesis.
