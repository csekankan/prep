# 21 — Databricks on AWS & Delta Lake

> **Why it matters:** Databricks is the most common commercial Spark platform, and it runs **inside your
> AWS account** (compute and data), while Databricks operates the control plane. The original course uses
> Azure Databricks; everything here is the AWS deployment. Its core technology, **Delta Lake**, is what
> turns an S3 data lake into a **lakehouse** with ACID transactions, upserts, and time travel. The same
> concepts apply to Apache Iceberg (Athena, Glue, EMR, S3 Tables).

## In plain words

Databricks is a **managed Spark workshop**. The front office (notebooks, job scheduler, permissions,
catalog) is run by Databricks. The machines and the warehouse (EC2 instances and S3 buckets) are in your
AWS account, so your data never has to leave it. Delta Lake adds a **ledger** next to your Parquet files:
every change is a numbered entry, so readers always see a consistent version, writers don't corrupt each
other, and you can open the ledger at any past page (time travel).

## Architecture at a glance — Databricks on AWS

```mermaid
flowchart TB
  U[Users / CI / Airflow]
  subgraph DBACC["Databricks AWS account — CONTROL PLANE"]
    WEB[Web app, notebooks,<br/>REST API]
    JOBS[Jobs / Lakeflow<br/>orchestration]
    CM[Cluster manager]
    UC[Unity Catalog service<br/>metastore, permissions,<br/>lineage, audit]
    SERV["Serverless compute plane<br/>(SQL warehouses, serverless<br/>jobs/notebooks)"]
  end
  subgraph CUST["YOUR AWS account — CLASSIC COMPUTE PLANE + DATA"]
    subgraph VPC["Workspace VPC (Databricks-managed or customer-managed)"]
      DRV[Driver EC2]
      WK[Worker EC2 x N]
    end
    ROOT[(Workspace root S3 bucket<br/>DBFS root, system data)]
    MS[(UC managed storage S3)]
    EXT[(Your data buckets:<br/>bronze / silver / gold)]
    XROLE[Cross-account IAM role<br/>lets Databricks launch EC2]
    SCRED[Storage credential IAM role<br/>lets UC access S3 paths]
  end
  U --> WEB
  CM -->|assume XROLE| VPC
  DRV & WK -->|read/write via UC<br/>short-lived credentials| EXT
  DRV & WK --> MS
  UC -.governs.-> MS & EXT
  SERV -.network connectivity +<br/>UC credentials.-> EXT
  WEB --> JOBS --> CM
```

**How to read it:** with **classic compute**, Databricks assumes a cross-account IAM role to launch EC2 in your
VPC; data stays in your S3 buckets. With **serverless compute**, the machines run in Databricks' AWS account
but still access your data through Unity Catalog's credentials. **Unity Catalog** governs every table,
volume, and external location with SQL `GRANT`s and records lineage and audit logs.

## 1. What and why

| Feature | Value over plain EMR/Spark |
|---|---|
| Managed Spark runtime + **Photon** (C++ vectorized engine) | faster SQL/DataFrame workloads without tuning |
| Collaborative notebooks, repos (Git folders) | team development |
| **Jobs / Lakeflow Jobs** | built-in orchestration with retries, task DAGs |
| **Lakeflow Declarative Pipelines** (formerly Delta Live Tables) | declarative ETL with data quality expectations |
| **Auto Loader** (`cloudFiles`) | incremental, exactly-once file ingestion from S3 with schema inference/evolution |
| **Unity Catalog** | central governance: `catalog.schema.table`, grants, lineage, audit, row/column security |
| SQL warehouses | BI-grade SQL endpoints (serverless) |
| Delta Lake | ACID tables on S3 |

When **not** to choose it: small/simple pipelines (Glue or EMR Serverless is cheaper), strict "AWS-native only"
policies, or if you're already on Redshift + Athena with no Spark needs.

## 2. Getting an account

- **Databricks Free Edition** (replaced Community Edition in 2025): free, serverless-only, good for learning notebooks and SQL.
- **Databricks on AWS trial / pay-as-you-go**: subscribe via **AWS Marketplace** (billing consolidated on your AWS bill).
  Workspace creation uses a CloudFormation **Quickstart** that creates the cross-account role, root bucket, and VPC.
- Production: **customer-managed VPC**, **PrivateLink** (front-end and back-end), customer-managed KMS keys.

## 3. UI walkthrough (what each area is for)

| Area | Use |
|---|---|
| Workspace | notebooks, files, Git folders |
| Catalog | browse Unity Catalog catalogs/schemas/tables/volumes, permissions, lineage |
| Compute | all-purpose clusters (interactive), job clusters (per run), SQL warehouses, policies |
| Jobs & Pipelines | scheduled workflows, declarative pipelines |
| SQL Editor / Dashboards | SQL analytics and visualization |
| Data ingestion | upload files, connectors |

**Cluster types:** **all-purpose** (interactive, shared, more expensive DBU rate) vs **job clusters** (created per
run, terminated after: cheaper, isolated). Production jobs run on job clusters or serverless. Cost = **DBUs**
(Databricks) + **EC2** (AWS) for classic compute; serverless bundles both.

### Creating compute and a notebook

Key cluster settings and why they matter:

| Setting | Choice | Why |
|---|---|---|
| Databricks Runtime | latest **LTS** (e.g. 15.4 LTS) | stable Spark + Delta versions with long support |
| Access mode | **Dedicated** (single user) or **Standard** (shared) | both work with Unity Catalog; Standard isolates users on shared clusters |
| Node type | general purpose (`m`), or `d` variants (local NVMe) for shuffle-heavy jobs | cost vs performance |
| Autoscaling | min–max workers | elasticity |
| Auto-termination | 20–60 min idle | the #1 cost control for all-purpose clusters |
| AWS attributes | `SPOT_WITH_FALLBACK`, `first_on_demand: 1` | driver On-Demand, workers on Spot |
| Photon | on for SQL/DataFrame-heavy work | vectorized engine, higher DBU rate |

```json
{
  "cluster_name": "olist-dev",
  "spark_version": "15.4.x-scala2.12",
  "node_type_id": "m5d.xlarge",
  "autoscale": {"min_workers": 1, "max_workers": 4},
  "autotermination_minutes": 30,
  "data_security_mode": "SINGLE_USER",
  "aws_attributes": {"availability": "SPOT_WITH_FALLBACK", "first_on_demand": 1},
  "custom_tags": {"project": "olist"}
}
```

```bash
databricks clusters create --json @cluster.json      # Databricks CLI (or UI: Compute → Create compute)
```

Notebook essentials: attach to compute or serverless; magic commands `%python`, `%sql`, `%md`, `%sh`, `%run
./other_notebook`; `dbutils.fs` (files), `dbutils.secrets` (secret scopes), `dbutils.widgets` (parameters for jobs).

### Visualizing data in Databricks

```python
df = spark.table("olist.gold.category_monthly")
display(df)        # interactive table → "+" → Visualization: bar/line/area/pie/map/heatmap, with group-by and aggregation in the UI
```

- In a notebook, `display()` renders tables and charts. Add several visualizations per cell output.
- In the **SQL editor**, query results become visualizations, which you can pin to **AI/BI dashboards** (scheduled
  refresh, sharing, filters).
- For company-wide BI on AWS, point **QuickSight** at a Databricks SQL warehouse (or at Athena over the same S3 data).

### Databricks Workflows (Lakeflow Jobs)

```mermaid
flowchart LR
  TRG["Trigger:<br/>schedule (cron) /<br/>file arrival /<br/>table update / continuous"] --> J
  subgraph J["Job: olist_daily"]
    T1[ingest_bronze<br/>notebook] --> T2[silver_transform<br/>Python script]
    T2 --> T3[gold_build<br/>SQL task]
    T2 --> T4[dq_checks<br/>notebook]
    T3 & T4 --> T5[refresh_dashboard]
  end
  J --> NOTIF[email / Slack /<br/>webhook on failure]
  JC[(job cluster:<br/>created per run,<br/>terminated after)] -.runs.- J
```

| Concept | Detail |
|---|---|
| Tasks | notebook, Python script, wheel, JAR, SQL, dbt, declarative pipeline, "run job" (nesting), if/else, for-each |
| Dependencies | DAG of tasks; run-if conditions (all succeeded, at least one failed, ...) |
| Compute | **job clusters** (cheaper DBU rate, isolated, per run) or serverless; avoid all-purpose clusters for production |
| Parameters | job/task parameters → notebook widgets; dynamic values like `{{job.start_time.iso_date}}` |
| Reliability | per-task retries and timeouts; **repair run** reruns only failed tasks and their dependents |
| Deploy as code | **Databricks Asset Bundles** (`databricks bundle deploy`) keep jobs, clusters, and code in git |
| Orchestrated from outside | MWAA `DatabricksRunNowOperator` / `DatabricksSubmitRunOperator`, or Step Functions calling the Jobs API |

```bash
databricks jobs create --json @olist_daily_job.json
databricks jobs run-now <job_id>
```

## 4. Where data actually lives: DBFS, volumes, Unity Catalog

| Storage concept | What it is | Status |
|---|---|---|
| **DBFS** (`dbfs:/`) | a filesystem abstraction over object storage. `dbfs:/` root maps to the workspace root S3 bucket | DBFS root and **mounts** (`/mnt/...`) are legacy; don't store production data there |
| **Unity Catalog managed tables** | data in UC managed storage (S3) chosen by metastore/catalog/schema | recommended default |
| **External tables** | data at your S3 path, registered via an **external location** | for shared/existing data |
| **Volumes** (`/Volumes/<catalog>/<schema>/<volume>/`) | governed storage for non-tabular files (CSV drops, images, JARs) | replaces mounts |
| Storage credential + external location | IAM role + S3 prefix that UC is allowed to use | how UC gets S3 access |

```sql
-- One-time (admin): let Unity Catalog use an IAM role for a bucket prefix
CREATE STORAGE CREDENTIAL lake_role WITH (AWS_IAM_ROLE = 'arn:aws:iam::123456789012:role/uc-lake-access');
CREATE EXTERNAL LOCATION lake_bronze URL 's3://bigdata-course-123/bronze/' WITH (STORAGE CREDENTIAL lake_role);

CREATE CATALOG IF NOT EXISTS olist;
CREATE SCHEMA IF NOT EXISTS olist.bronze;
CREATE VOLUME IF NOT EXISTS olist.bronze.landing;          -- files land here
GRANT READ VOLUME ON VOLUME olist.bronze.landing TO `data-engineers`;
GRANT SELECT ON SCHEMA olist.bronze TO `analysts`;
```

```python
dbutils.fs.ls("/Volumes/olist/bronze/landing/")
df = spark.read.csv("/Volumes/olist/bronze/landing/olist_orders_dataset.csv", header=True)
df2 = spark.read.parquet("s3://bigdata-course-123/bronze/olist/")   # works if an external location covers it
```

**Explaining where our data actually lives (stakeholder version):** "All our tables are files in our own
S3 buckets, in our AWS account and region, encrypted with our keys. Databricks runs the compute and keeps the
catalog of table names and permissions, but it doesn't hold a copy of the data. If we stopped using Databricks
tomorrow, the Delta files would still be readable by EMR, Glue, or Athena."

## 5. Delta Lake internals

```mermaid
flowchart TB
  subgraph TBL["s3://.../silver/orders/  (a Delta table)"]
    subgraph LOG["_delta_log/"]
      J0[00000.json<br/>add file A, B<br/>schema, protocol]
      J1[00001.json<br/>add C]
      J2[00002.json<br/>remove B, add B' — UPDATE]
      CK[00010.checkpoint.parquet<br/>full snapshot of state]
    end
    F1[part-A.parquet]
    F2[part-B.parquet — tombstoned]
    F3[part-C.parquet]
    F4[part-B2.parquet]
  end
  R[Reader] -->|1. latest checkpoint +<br/>later JSON commits| LOG
  R -->|2. read only files<br/>in current snapshot| F1 & F3 & F4
  W[Writer] -->|write new Parquet files,<br/>then atomically create<br/>next commit JSON| LOG
```

| Concept | How it works |
|---|---|
| **Transaction log** | ordered JSON commits of actions (`add`, `remove`, `metaData`, `protocol`, `commitInfo`); periodic Parquet **checkpoints** summarize state |
| **Atomicity** | a commit becomes visible only when its log file is created atomically ("put-if-absent"). Half-written Parquet files are invisible |
| **Isolation** | **optimistic concurrency**: writers read version N, write files, try to commit N+1. On conflict (same files touched), retry or fail with `ConcurrentModificationException` |
| **Snapshot reads** | readers see a consistent version, never partial writes |
| **Schema enforcement** | writes with mismatched columns/types fail unless `mergeSchema`/`autoMerge` is set (**schema evolution**) |
| **Time travel** | `VERSION AS OF 12` / `TIMESTAMP AS OF '2025-03-01'`, limited by log retention and VACUUM |
| **Deletion vectors** | mark deleted rows without rewriting files (faster DELETE/UPDATE/MERGE) |
| **Change Data Feed** | row-level change stream (`table_changes`) for downstream incremental processing |

S3 commit safety: S3 has no atomic put-if-absent rename for all clients historically, so multi-cluster writers need a
coordination mechanism. Databricks handles this with its commit service. Open-source Delta on EMR uses a
**DynamoDB-based LogStore** for multi-writer safety (S3 conditional writes are now an option too).

### Delta operations you must know

```sql
-- Create (managed UC table)
CREATE TABLE olist.silver.orders (order_id STRING, customer_id STRING, order_status STRING,
  order_ts TIMESTAMP, amount DECIMAL(12,2), purchase_date DATE)
CLUSTER BY (purchase_date);                     -- liquid clustering (replaces partitioning + ZORDER for new tables)

-- Upsert late-arriving / changed rows
MERGE INTO olist.silver.orders t
USING updates s ON t.order_id = s.order_id
WHEN MATCHED AND s.order_ts > t.order_ts THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;

-- History and time travel
DESCRIBE HISTORY olist.silver.orders;
SELECT count(*) FROM olist.silver.orders VERSION AS OF 3;
RESTORE TABLE olist.silver.orders TO VERSION AS OF 3;     -- undo a bad write

-- Maintenance
OPTIMIZE olist.silver.orders;                              -- compact small files (bin-packing)
OPTIMIZE olist.silver.legacy_orders ZORDER BY (customer_id);  -- multi-dimensional clustering (non-liquid tables)
VACUUM olist.silver.orders RETAIN 168 HOURS;               -- delete unreferenced files older than 7 days (default)
```

| Maintenance | Why | Danger |
|---|---|---|
| `OPTIMIZE` | streaming/small writes → small files | cost of rewriting; schedule it (or **predictive optimization** on UC managed tables) |
| `ZORDER` / liquid clustering | data skipping on several filter columns | ZORDER rewrites entire partitions; liquid is incremental |
| `VACUUM` | storage cost: old files remain after updates | retaining < 7 days can break time travel and long-running readers |

## 6. Medallion architecture on Delta

```mermaid
flowchart LR
  SRC[S3 landing / volume<br/>CSV, JSON] -->|Auto Loader<br/>incremental| BR[Bronze Delta<br/>raw + _ingest_ts<br/>+ _source_file]
  BR -->|clean, dedupe,<br/>types, MERGE| SI[Silver Delta<br/>conformed entities]
  SI -->|join + aggregate| GO[Gold Delta<br/>business marts]
  GO --> SQLW[SQL warehouse /<br/>dashboards]
  GO --> ATH[Athena / Redshift<br/>via UC or Glue federation]
```

```python
# Bronze: Auto Loader — incremental, exactly-once, schema tracking
(spark.readStream.format("cloudFiles")
   .option("cloudFiles.format", "csv")
   .option("header", True)
   .option("cloudFiles.schemaLocation", "/Volumes/olist/bronze/landing/_schemas/orders")
   .load("/Volumes/olist/bronze/landing/orders/")
   .withColumn("_ingest_ts", F.current_timestamp())
   .withColumn("_source_file", F.col("_metadata.file_path"))
   .writeStream
   .option("checkpointLocation", "/Volumes/olist/bronze/landing/_checkpoints/orders")
   .trigger(availableNow=True)                 # process everything new, then stop (batch-style)
   .toTable("olist.bronze.orders"))
```

## 7. Processing data on Databricks: customer + orders insights

The course's Databricks lectures repeat the warm-up exercise: **read data → process customer data → customers
with orders, actionable insights**. Run module 15 §0 as-is in a notebook, reading from a volume path such as
`/Volumes/olist/bronze/landing/customers.csv` instead of S3, and use `display()` on each insight DataFrame to
chart it. The full Olist code from module 15 also runs unchanged, with table names swapped to Unity Catalog
(`olist.silver.orders`). Example insight query in a SQL warehouse:

```sql
WITH cust AS (
  SELECT c.customer_unique_id, c.customer_state, o.order_id, o.purchase_date, o.amount,
         row_number() OVER (PARTITION BY c.customer_unique_id ORDER BY o.purchase_date) AS seq
  FROM olist.silver.orders o JOIN olist.silver.customers c USING (customer_id)
  WHERE o.order_status = 'delivered')
SELECT customer_state,
       count(DISTINCT customer_unique_id)                                AS customers,
       round(avg(CASE WHEN seq = 2 THEN 1.0 ELSE 0 END) * 100, 2)        AS pct_orders_that_are_repeat,
       round(sum(amount) / count(DISTINCT customer_unique_id), 2)        AS revenue_per_customer
FROM cust GROUP BY customer_state ORDER BY customers DESC;
```

## 8. Databricks vs EMR vs Glue on AWS

| | Databricks on AWS | EMR (EC2/Serverless) | Glue ETL |
|---|---|---|---|
| Engine | Databricks Runtime + Photon | EMR runtime for Spark (+ Hive, Trino, Flink, HBase) | Glue Spark runtime |
| Table format | Delta first-class (Iceberg via UniForm) | Delta, Iceberg, Hudi (OSS) | Iceberg, Delta, Hudi |
| Governance | Unity Catalog | Glue Catalog + Lake Formation | Glue Catalog + Lake Formation |
| Notebooks/collab | best | EMR Studio / SageMaker Unified Studio | Glue Studio notebooks |
| Pricing | DBU + EC2 (or serverless) | EC2 + EMR fee (or vCPU/GB-s) | DPU-hours |
| Choose when | lakehouse platform, many teams, ML + BI on one stack | cost-sensitive, open-source stack, custom frameworks | AWS-native ETL with catalog integration, small–medium jobs |

**Open table formats on AWS:** Iceberg is AWS's most-integrated format (Athena DML, Glue, EMR, Redshift,
**Amazon S3 Tables** with managed compaction). Delta works on EMR/Glue via open-source `delta-spark`, and
Databricks **UniForm** can expose Delta tables with Iceberg metadata so Iceberg readers can query them.

## Key takeaways

- Control plane (Databricks account) vs compute plane (classic = EC2 in your VPC; serverless = Databricks account) vs data (your S3).
- Unity Catalog governs tables, volumes, and external locations via storage credentials (IAM roles). DBFS root and mounts are legacy.
- Delta = Parquet + `_delta_log`: atomic commits, optimistic concurrency, snapshot isolation, schema enforcement, time travel.
- MERGE for upserts, OPTIMIZE (and liquid clustering) for layout, VACUUM for storage, with retention ≥ 7 days.
- On AWS, choose among Databricks, EMR, and Glue by platform needs, team skills, and cost.

## Interview scenarios

1. *Two jobs write to the same Delta table at once. What happens?* — optimistic concurrency. Both write files;
   the first commit wins; the second checks for conflicts. Appends to different partitions usually succeed;
   overlapping updates fail with a concurrent modification error and must retry.
2. *An analyst ran `DELETE FROM orders` without a WHERE.* — `DESCRIBE HISTORY`, then `RESTORE TABLE ... TO VERSION
   AS OF <before>`. Works if VACUUM hasn't removed the old files.
3. *Why not just Parquet on S3?* — no atomic multi-file commits (readers see partial writes), no upserts/deletes
   without rewriting partitions manually, no schema enforcement, no time travel, and slow listing for big tables.
4. *Where does a Databricks-on-AWS job's data physically go?* — EC2 instances in the customer VPC (classic) read
   and write the customer's S3 buckets. Only metadata and orchestration live in the Databricks control plane.
