# 23 — Capstone: Olist Medallion Lakehouse on AWS (replaces the Azure project)

> **Why it matters:** this is the industry-style end-to-end project from the original course, rebuilt
> service by service on AWS. Three heterogeneous sources (HTTP files, a relational DB, MongoDB) are
> ingested with parameterized, orchestrated pipelines into an S3 medallion lake, transformed and
> enriched with Spark (Databricks on AWS, or Glue for a pure-AWS path), served through Athena (serverless)
> and Redshift (warehouse), and visualized in QuickSight.

## In plain words

Olist's data is scattered: most tables are CSV files on a web server, payments live in a MySQL database,
and the product-category translation lives in MongoDB. You build a **conveyor belt**: copy everything
as-is into the bronze shelf, clean and combine it on the silver shelf, publish business-ready views on the
gold shelf, and put a dashboard on top. Each step is a reusable machine with settings (parameters), started
automatically in the right order.

## Architecture at a glance

```mermaid
flowchart LR
  subgraph SRC["Sources"]
    HTTP["GitHub raw CSVs<br/>(orders, customers, items,<br/>products, sellers, reviews, geo)"]
    MYSQL[("RDS MySQL<br/>order_payments")]
    MONGO[("MongoDB Atlas on AWS<br/>or DocumentDB<br/>category translation")]
  end
  subgraph ING["Ingestion — replaces Azure Data Factory"]
    SFN[Step Functions<br/>Map over sources.json]
    GPY[Glue Python shell job<br/>http_to_s3 parameterized]
    GJDBC[Glue Spark job<br/>jdbc_to_s3 via Glue connection]
    EB[EventBridge Scheduler<br/>daily trigger]
  end
  subgraph LAKE["S3 lake — replaces ADLS Gen2"]
    BR[bronze/olist/]
    SI[silver/olist/]
    GO[gold/olist/]
  end
  subgraph TRANS["Transform — replaces Azure Databricks"]
    DBX["Databricks on AWS job<br/>(Option A)"]
    GSP["Glue Spark job<br/>(Option B, pure AWS)"]
  end
  subgraph SERVE["Serving — replaces Synapse"]
    ATH["Athena<br/>views + CTAS = CETAS<br/>(serverless SQL pool)"]
    RS["Redshift Serverless<br/>Spectrum + local tables<br/>(dedicated SQL pool)"]
  end
  CAT[(Glue Data Catalog<br/>+ Lake Formation)]
  QS[QuickSight dashboard<br/>replaces Power BI]
  EB --> SFN
  SFN --> GPY
  SFN --> GJDBC
  HTTP --> GPY --> BR
  MYSQL --> GJDBC --> BR
  BR --> DBX & GSP
  MONGO --> DBX & GSP
  DBX & GSP --> SI
  SI --> ATH --> GO
  CAT --- ATH
  CAT --- RS
  GO --> RS
  ATH --> QS
  RS --> QS
```

**How to read it:** EventBridge starts a Step Functions state machine each day. A **Map** state loops over a
config file of HTTP sources and runs one parameterized Glue job per file, in parallel. A JDBC Glue job copies
MySQL payments. Spark (Databricks or Glue) cleans, joins, and enriches the bronze data with MongoDB
categories, and writes silver Parquet. Athena builds gold views and CTAS tables (the CETAS equivalent);
Redshift Serverless serves high-concurrency dashboards. QuickSight visualizes.

## 1. Azure lecture → AWS implementation map

| Azure lecture | AWS implementation in this module |
|---|---|
| Creating Azure account / Azure overview | AWS account, IAM Identity Center, budget (module 04), region choice |
| Resource & resource group | **tags** `project=olist` + one CloudFormation/Terraform stack; optional separate account |
| SQL DB & data ingestion | **RDS for MySQL** with `order_payments` loaded |
| ADLS Gen2 storage account | **S3** bucket with bronze/silver/gold prefixes, versioning, SSE-KMS |
| Azure Data Factory | **Glue jobs** (copy/ingest) + **Step Functions** (pipeline/ForEach) + **EventBridge** (trigger) |
| Ingestion with ADF (HTTP) | `http_to_s3` Glue Python shell job |
| "Real-time" ingestion with ADF (SQL → lake) | `jdbc_to_s3` Glue Spark job with a Glue JDBC connection |
| Parameterized ingestion with ADF (ForEach + parameters) | Step Functions **Map** over `sources.json`, passing job arguments |
| Azure Databricks account / UI / compute | **Databricks on AWS** workspace (or Glue Spark for pure AWS) |
| ADLS Gen2 → Databricks connection | Unity Catalog **storage credential (IAM role) + external location** |
| MongoDB ingestion / enrichment | **MongoDB Atlas on AWS** (or **DocumentDB**) via `pymongo` / Glue MongoDB connection |
| Cleaning, joins, enrichment, visualization, export to silver | Spark notebook/job → `s3://.../silver/olist/` Parquet |
| Synapse overview / UI / lake access | **Athena** workgroup + Glue Catalog; **Redshift Serverless** with IAM role |
| SQL pool dedicated vs serverless | **Redshift** (provisioned/serverless warehouse) vs **Athena** (pay per TB scanned) |
| Gold schema + views | Athena `olist_gold` database + views |
| CETAS | **Athena CTAS** (`external_location`) or Redshift `UNLOAD` + external table |
| External serving table in gold | Glue Catalog external tables on `gold/` |
| Visualization (Power BI) | **QuickSight** on Athena/Redshift |
| Workflow | Step Functions state machine + EventBridge Scheduler (or MWAA, module 19) |

## 2. Prerequisites and setup

```bash
export AWS_PROFILE=bigdata REGION=ap-south-1
export ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
export BUCKET=olist-lake-$ACCOUNT_ID

aws s3 mb s3://$BUCKET --region $REGION
aws s3api put-bucket-versioning --bucket $BUCKET --versioning-configuration Status=Enabled
aws s3api put-bucket-tagging --bucket $BUCKET --tagging 'TagSet=[{Key=project,Value=olist}]'
for db in olist_bronze olist_silver olist_gold; do aws glue create-database --database-input Name=$db; done
```

Host the 7 HTTP-source CSVs in a GitHub repo (as the original course did), e.g.
`https://raw.githubusercontent.com/<you>/olist-data/main/olist_orders_dataset.csv`.

IAM roles to create (least privilege):

| Role | Trusted by | Permissions |
|---|---|---|
| `olist-glue-role` | glue.amazonaws.com | read/write `s3://$BUCKET/*`, Glue Catalog on `olist_*`, read Secrets Manager `olist/*`, VPC ENIs (for the JDBC connection), CloudWatch Logs |
| `olist-sfn-role` | states.amazonaws.com | `glue:StartJobRun/GetJobRun/BatchStopJobRun`, `s3:GetObject` on the config, SNS publish |
| `olist-uc-role` | Databricks UC (external ID trust) | read/write `s3://$BUCKET/*` |
| `olist-redshift-role` | redshift.amazonaws.com | read `s3://$BUCKET/gold/*`, Glue Catalog read |

## 3. Source 1: RDS MySQL with order payments

```bash
aws rds create-db-instance --db-instance-identifier olist-mysql \
  --engine mysql --engine-version 8.0 --db-instance-class db.t4g.micro --allocated-storage 20 \
  --master-username admin --manage-master-user-password --db-name olist \
  --no-publicly-accessible --vpc-security-group-ids sg-olist-db --db-subnet-group-name olist-private \
  --tags Key=project,Value=olist
```

Load the CSV from your laptop through an SSM port-forward via a small bastion EC2 instance (no public DB):

```bash
aws ssm start-session --target i-bastion \
  --document-name AWS-StartPortForwardingSessionToRemoteHost \
  --parameters '{"host":["olist-mysql.xxxx.ap-south-1.rds.amazonaws.com"],"portNumber":["3306"],"localPortNumber":["3306"]}'
```

```python
# load_payments.py — pip install pandas sqlalchemy pymysql
import pandas as pd
from sqlalchemy import create_engine, text

engine = create_engine("mysql+pymysql://admin:<password>@127.0.0.1:3306/olist")
with engine.begin() as con:
    con.execute(text("""
      CREATE TABLE IF NOT EXISTS order_payments (
        order_id VARCHAR(32), payment_sequential INT, payment_type VARCHAR(20),
        payment_installments INT, payment_value DECIMAL(10,2),
        PRIMARY KEY (order_id, payment_sequential))"""))
df = pd.read_csv("olist/olist_order_payments_dataset.csv")
df.to_sql("order_payments", engine, if_exists="append", index=False, chunksize=5000, method="multi")
```

Store DB credentials for Glue in Secrets Manager (`olist/mysql`) and create a **Glue JDBC connection** in the
same VPC/subnet with a security group that the DB security group allows on 3306. The Glue job subnets need an
**S3 gateway endpoint** (and a Secrets Manager interface endpoint or NAT).

```bash
aws glue create-connection --connection-input '{
  "Name": "olist-mysql", "ConnectionType": "JDBC",
  "ConnectionProperties": {
    "JDBC_CONNECTION_URL": "jdbc:mysql://olist-mysql.xxxx.ap-south-1.rds.amazonaws.com:3306/olist",
    "SECRET_ID": "olist/mysql"},
  "PhysicalConnectionRequirements": {"SubnetId": "subnet-priv-a",
    "SecurityGroupIdList": ["sg-glue"], "AvailabilityZone": "ap-south-1a"}}'
```

## 4. Source 2: MongoDB (category translation)

Create a free **MongoDB Atlas cluster on AWS** in the same region (or an **Amazon DocumentDB** cluster in your
VPC). Load the translation CSV:

```python
# load_mongo.py — pip install pymongo pandas
import pandas as pd
from pymongo import MongoClient

client = MongoClient("mongodb+srv://<user>:<pass>@<cluster>.mongodb.net/")
coll = client["olist"]["product_categories"]
coll.delete_many({})
coll.insert_many(pd.read_csv("olist/product_category_name_translation.csv").to_dict("records"))
coll.create_index("product_category_name", unique=True)
print(coll.count_documents({}))
```

Atlas network access: allow the NAT gateway's Elastic IP (Glue/Databricks egress) or use PrivateLink. Store the
URI in Secrets Manager `olist/mongo` (for Databricks: a secret scope backed by your vault, or UC service credentials).

## 5. Ingestion layer (replaces ADF)

### 5.1 Parameterized HTTP → S3 job (Glue Python shell)

```python
# glue/http_to_s3.py — Glue Python shell job; args: --source_url --target_key --bucket
import sys, urllib.request, hashlib, datetime
import boto3
from awsglue.utils import getResolvedOptions

args = getResolvedOptions(sys.argv, ["source_url", "target_key", "bucket"])
ingest_date = datetime.date.today().isoformat()
key = f"bronze/olist/{args['target_key']}/ingest_date={ingest_date}/{args['target_key']}.csv"

with urllib.request.urlopen(args["source_url"], timeout=60) as resp:
    if resp.status != 200:
        raise RuntimeError(f"HTTP {resp.status} for {args['source_url']}")
    body = resp.read()

if len(body) < 100:
    raise RuntimeError(f"Suspiciously small file ({len(body)} bytes) from {args['source_url']}")

boto3.client("s3").put_object(Bucket=args["bucket"], Key=key, Body=body,
    Metadata={"source_url": args["source_url"], "sha256": hashlib.sha256(body).hexdigest()})
print(f"wrote s3://{args['bucket']}/{key} ({len(body)} bytes)")
```

```bash
aws s3 cp glue/http_to_s3.py s3://$BUCKET/code/glue/
aws glue create-job --name olist-http-to-s3 --role olist-glue-role \
  --command Name=pythonshell,PythonVersion=3.9,ScriptLocation=s3://$BUCKET/code/glue/http_to_s3.py \
  --max-capacity 0.0625 --default-arguments '{"--bucket":"'$BUCKET'"}' --tags project=olist
```

### 5.2 JDBC → S3 job (Glue Spark, the "SQL DB ingestion")

```python
# glue/jdbc_to_s3.py — args: --table --bucket
import sys, datetime
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext

args = getResolvedOptions(sys.argv, ["JOB_NAME", "table", "bucket"])
glue = GlueContext(SparkContext.getOrCreate()); job = Job(glue); job.init(args["JOB_NAME"], args)

dyf = glue.create_dynamic_frame.from_options(
    connection_type="mysql",
    connection_options={"useConnectionProperties": "true", "connectionName": "olist-mysql",
                        "dbtable": args["table"], "hashfield": "payment_sequential",
                        "hashpartitions": "4"})          # parallel JDBC reads
ingest_date = datetime.date.today().isoformat()
(dyf.toDF().write.mode("overwrite")
    .parquet(f"s3://{args['bucket']}/bronze/olist/{args['table']}/ingest_date={ingest_date}/"))
job.commit()
```

```bash
aws glue create-job --name olist-jdbc-to-s3 --role olist-glue-role --glue-version 5.0 \
  --worker-type G.1X --number-of-workers 2 --connections Connections=olist-mysql \
  --command Name=glueetl,ScriptLocation=s3://$BUCKET/code/glue/jdbc_to_s3.py,PythonVersion=3 \
  --default-arguments '{"--bucket":"'$BUCKET'","--table":"order_payments"}' --tags project=olist
```

For true **CDC** (continuous changes instead of daily snapshots), use **DMS** from RDS MySQL (binlog) to S3
Parquet, and MERGE into silver.

### 5.3 Parameterized pipeline: Step Functions Map over a config file

Config file `s3://$BUCKET/config/sources.json` (adding a source = adding one line):

```json
{"sources": [
  {"url": "https://raw.githubusercontent.com/<you>/olist-data/main/olist_orders_dataset.csv",        "target": "orders"},
  {"url": "https://raw.githubusercontent.com/<you>/olist-data/main/olist_customers_dataset.csv",     "target": "customers"},
  {"url": "https://raw.githubusercontent.com/<you>/olist-data/main/olist_order_items_dataset.csv",   "target": "order_items"},
  {"url": "https://raw.githubusercontent.com/<you>/olist-data/main/olist_products_dataset.csv",      "target": "products"},
  {"url": "https://raw.githubusercontent.com/<you>/olist-data/main/olist_sellers_dataset.csv",       "target": "sellers"},
  {"url": "https://raw.githubusercontent.com/<you>/olist-data/main/olist_order_reviews_dataset.csv", "target": "reviews"},
  {"url": "https://raw.githubusercontent.com/<you>/olist-data/main/olist_geolocation_dataset.csv",   "target": "geolocation"}
]}
```

```json
{
  "Comment": "Olist daily ingestion + transform",
  "StartAt": "LoadConfig",
  "States": {
    "LoadConfig": {
      "Type": "Task",
      "Resource": "arn:aws:states:::aws-sdk:s3:getObject",
      "Parameters": {"Bucket": "olist-lake-123456789012", "Key": "config/sources.json"},
      "ResultSelector": {"config.$": "States.StringToJson($.Body)"},
      "Next": "Ingest"
    },
    "Ingest": {
      "Type": "Parallel",
      "Branches": [
        {"StartAt": "HttpSources", "States": {
          "HttpSources": {
            "Type": "Map", "ItemsPath": "$.config.sources", "MaxConcurrency": 4,
            "ItemProcessor": {"ProcessorConfig": {"Mode": "INLINE"}, "StartAt": "HttpToS3", "States": {
              "HttpToS3": {
                "Type": "Task", "Resource": "arn:aws:states:::glue:startJobRun.sync",
                "Parameters": {"JobName": "olist-http-to-s3",
                               "Arguments": {"--source_url.$": "$.url", "--target_key.$": "$.target"}},
                "Retry": [{"ErrorEquals": ["States.ALL"], "IntervalSeconds": 30, "MaxAttempts": 2, "BackoffRate": 2}],
                "End": true}}},
            "End": true}}},
        {"StartAt": "MySqlPayments", "States": {
          "MySqlPayments": {
            "Type": "Task", "Resource": "arn:aws:states:::glue:startJobRun.sync",
            "Parameters": {"JobName": "olist-jdbc-to-s3", "Arguments": {"--table": "order_payments"}},
            "Retry": [{"ErrorEquals": ["States.ALL"], "IntervalSeconds": 60, "MaxAttempts": 2, "BackoffRate": 2}],
            "End": true}}}
      ],
      "Catch": [{"ErrorEquals": ["States.ALL"], "Next": "NotifyFailure"}],
      "Next": "TransformSilver"
    },
    "TransformSilver": {
      "Type": "Task", "Resource": "arn:aws:states:::glue:startJobRun.sync",
      "Parameters": {"JobName": "olist-silver"},
      "Catch": [{"ErrorEquals": ["States.ALL"], "Next": "NotifyFailure"}],
      "Next": "BuildGold"
    },
    "BuildGold": {
      "Type": "Task", "Resource": "arn:aws:states:::athena:startQueryExecution.sync",
      "Parameters": {"QueryString": "MERGE INTO olist_gold.seller_performance t USING (SELECT seller_id, seller_state, count(DISTINCT order_id) AS orders, sum(price) AS revenue, avg(review_score) AS avg_review, avg(CASE WHEN delay_days > 0 THEN 1.0 ELSE 0 END) AS late_rate FROM olist_silver.order_items_enriched WHERE order_status = 'delivered' GROUP BY seller_id, seller_state) s ON t.seller_id = s.seller_id WHEN MATCHED THEN UPDATE SET seller_state = s.seller_state, orders = s.orders, revenue = s.revenue, avg_review = s.avg_review, late_rate = s.late_rate WHEN NOT MATCHED THEN INSERT (seller_id, seller_state, orders, revenue, avg_review, late_rate) VALUES (s.seller_id, s.seller_state, s.orders, s.revenue, s.avg_review, s.late_rate)",
                     "WorkGroup": "olist"},
      "Catch": [{"ErrorEquals": ["States.ALL"], "Next": "NotifyFailure"}],
      "End": true
    },
    "NotifyFailure": {
      "Type": "Task", "Resource": "arn:aws:states:::sns:publish",
      "Parameters": {"TopicArn": "arn:aws:sns:ap-south-1:123456789012:olist-alerts",
                     "Message.$": "States.JsonToString($)"},
      "Next": "Fail"
    },
    "Fail": {"Type": "Fail"}
  }
}
```

`BuildGold` refreshes the gold Iceberg table created in section 7 with an idempotent `MERGE`. Schedule the
state machine daily:

```bash
aws scheduler create-schedule --name olist-daily --schedule-expression "cron(0 2 * * ? *)" \
  --schedule-expression-timezone "Asia/Kolkata" --flexible-time-window Mode=OFF \
  --target '{"Arn":"arn:aws:states:ap-south-1:'$ACCOUNT_ID':stateMachine:olist-pipeline",
             "RoleArn":"arn:aws:iam::'$ACCOUNT_ID':role/olist-scheduler-role"}'
```

**Option A (Databricks transform):** replace `TransformSilver` with a Databricks job triggered by a
**file-arrival trigger** on `bronze/olist/`, or orchestrate the whole flow from MWAA with
`DatabricksRunNowOperator` (module 19). **Option B (pure AWS):** keep `olist-silver` as a Glue Spark job running
the code in section 6.

## 6. Transformation & enrichment: bronze → silver (Spark)

The same code runs as a Databricks notebook/job or a Glue 5.0 Spark job. On Databricks, the S3 path is
governed by a Unity Catalog external location backed by `olist-uc-role`:

```sql
-- Databricks (admin, one-time): the "ADLS Gen2 → Databricks connection" equivalent
CREATE STORAGE CREDENTIAL olist_cred WITH (AWS_IAM_ROLE = 'arn:aws:iam::123456789012:role/olist-uc-role');
CREATE EXTERNAL LOCATION olist_lake URL 's3://olist-lake-123456789012/' WITH (STORAGE CREDENTIAL olist_cred);
```

```python
# silver_transform.py
from pyspark.sql import SparkSession, functions as F, Window
import pandas as pd
from pymongo import MongoClient

spark = SparkSession.builder.appName("olist-silver").getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")
BUCKET = "olist-lake-123456789012"
B, S = f"s3://{BUCKET}/bronze/olist", f"s3://{BUCKET}/silver/olist"

def latest_csv(name):
    """Read the most recent ingest_date partition of a bronze CSV source."""
    df = spark.read.option("header", True).option("multiLine", True).option("escape", '"').csv(f"{B}/{name}/")
    latest = df.agg(F.max("ingest_date")).first()[0]
    return df.where(F.col("ingest_date") == latest).drop("ingest_date")

orders    = latest_csv("orders")
customers = latest_csv("customers")
items     = latest_csv("order_items")
products  = latest_csv("products")
sellers   = latest_csv("sellers")
reviews   = latest_csv("reviews")
payments  = spark.read.parquet(f"{B}/order_payments/")
payments  = payments.where(F.col("ingest_date") == payments.agg(F.max("ingest_date")).first()[0])

# --- cleaning ---
orders = (orders.dropDuplicates(["order_id"])
  .withColumn("order_purchase_timestamp", F.to_timestamp("order_purchase_timestamp"))
  .withColumn("order_delivered_customer_date", F.to_timestamp("order_delivered_customer_date"))
  .withColumn("order_estimated_delivery_date", F.to_timestamp("order_estimated_delivery_date"))
  .withColumn("purchase_date", F.to_date("order_purchase_timestamp"))
  .withColumn("purchase_month", F.date_format("order_purchase_timestamp", "yyyy-MM"))
  .withColumn("delivery_days", F.datediff("order_delivered_customer_date", "order_purchase_timestamp"))
  .withColumn("delay_days", F.datediff("order_delivered_customer_date", "order_estimated_delivery_date"))
  .na.drop(subset=["order_id", "customer_id", "order_purchase_timestamp"]))
items = (items.withColumn("price", F.col("price").cast("decimal(10,2)"))
              .withColumn("freight_value", F.col("freight_value").cast("decimal(10,2)")))
payments = payments.withColumn("payment_value", F.col("payment_value").cast("decimal(10,2)"))
products = (products.withColumnRenamed("product_name_lenght", "product_name_length")
                    .withColumnRenamed("product_description_lenght", "product_description_length"))

# --- enrichment from MongoDB (small reference data → driver → broadcast) ---
def mongo_uri():
    if "dbutils" in globals():                                   # Databricks secret scope
        return dbutils.secrets.get("olist", "mongo_uri")
    import json, boto3                                           # Glue: Secrets Manager
    secret = boto3.client("secretsmanager").get_secret_value(SecretId="olist/mongo")
    return json.loads(secret["SecretString"])["uri"]

cats_pd = pd.DataFrame(list(MongoClient(mongo_uri())["olist"]["product_categories"].find({}, {"_id": 0})))
cats = spark.createDataFrame(cats_pd)
products = (products.join(F.broadcast(cats), "product_category_name", "left")
  .withColumn("category", F.coalesce("product_category_name_english", "product_category_name", F.lit("unknown"))))

# --- join at the right grain ---
pay_order = payments.groupBy("order_id").agg(
    F.sum("payment_value").alias("paid_value"),
    F.max("payment_installments").alias("max_installments"),
    F.concat_ws(",", F.collect_set("payment_type")).alias("payment_types"))
review_order = reviews.withColumn("review_score", F.col("review_score").cast("int")) \
                      .groupBy("order_id").agg(F.avg("review_score").alias("review_score"))

order_items_enriched = (items
  .join(F.broadcast(products.select("product_id", "category", "product_weight_g")), "product_id", "left")
  .join(F.broadcast(sellers), "seller_id", "left")
  .join(orders.select("order_id", "order_status", "purchase_date", "purchase_month",
                      "customer_id", "delivery_days", "delay_days"), "order_id")
  .join(customers.select("customer_id", "customer_unique_id", "customer_state"), "customer_id", "left")
  .join(pay_order, "order_id", "left")
  .join(review_order, "order_id", "left"))

# --- quick insight checks (the "extracting insights" lectures) ---
order_items_enriched.groupBy("category").agg(F.sum("price").alias("rev")).orderBy(F.desc("rev")).show(10)

# --- export to silver (Parquet so Athena/Redshift Spectrum can read it directly) ---
(order_items_enriched.repartition("purchase_month")
   .write.mode("overwrite").partitionBy("purchase_month")
   .parquet(f"{S}/order_items_enriched/"))
for df, name in [(orders, "orders"), (customers, "customers"), (products, "products"), (sellers, "sellers")]:
    df.write.mode("overwrite").parquet(f"{S}/{name}/")
```

Register silver in the Glue Catalog (Athena DDL, a crawler, or `saveAsTable` with the Glue metastore). With
Athena:

```sql
CREATE EXTERNAL TABLE olist_silver.order_items_enriched (
  order_id string, customer_id string, seller_id string, product_id string, order_item_id string,
  shipping_limit_date string, price decimal(10,2), freight_value decimal(10,2),
  category string, product_weight_g string, seller_zip_code_prefix string, seller_city string,
  seller_state string, order_status string, purchase_date date, delivery_days int, delay_days int,
  customer_unique_id string, customer_state string, paid_value decimal(12,2), max_installments int,
  payment_types string, review_score double)
PARTITIONED BY (purchase_month string)
STORED AS PARQUET
LOCATION 's3://olist-lake-123456789012/silver/olist/order_items_enriched/'
TBLPROPERTIES ('projection.enabled'='true', 'projection.purchase_month.type'='date',
  'projection.purchase_month.format'='yyyy-MM', 'projection.purchase_month.range'='2016-01,2018-12',
  'projection.purchase_month.interval'='1', 'projection.purchase_month.interval.unit'='MONTHS');
```

The column order must match the Parquet schema by **name** (Athena reads Parquet by name by default), so a
mismatched order is harmless but names must match exactly.

## 7. Serving layer (replaces Synapse)

### Serverless SQL pool → Athena

```sql
-- Gold views (logical layer, always fresh, no storage)
CREATE OR REPLACE VIEW olist_gold.v_category_monthly AS
SELECT category, purchase_month, sum(price) AS revenue, count(DISTINCT order_id) AS orders
FROM olist_silver.order_items_enriched
WHERE order_status = 'delivered'
GROUP BY category, purchase_month;

CREATE OR REPLACE VIEW olist_gold.v_state_delivery AS
SELECT customer_state, purchase_month,
       avg(delivery_days) AS avg_delivery_days,
       avg(CASE WHEN delay_days > 0 THEN 1.0 ELSE 0 END) AS late_rate,
       avg(review_score) AS avg_review
FROM olist_silver.order_items_enriched
WHERE order_status = 'delivered'
GROUP BY customer_state, purchase_month;

-- CETAS equivalent: materialize gold as Parquet files + external table in one statement
CREATE TABLE olist_gold.category_monthly
WITH (format = 'PARQUET', write_compression = 'SNAPPY',
      external_location = 's3://olist-lake-123456789012/gold/olist/category_monthly/')
AS SELECT * FROM olist_gold.v_category_monthly;

-- Refreshable gold: an Iceberg table (created once), then MERGEd by the pipeline every day
CREATE TABLE olist_gold.seller_performance
WITH (table_type = 'ICEBERG', is_external = false, format = 'PARQUET',
      location = 's3://olist-lake-123456789012/gold/olist/seller_performance/')
AS
SELECT seller_id, seller_state,
       count(DISTINCT order_id) AS orders,
       sum(price)               AS revenue,
       avg(review_score)        AS avg_review,
       avg(CASE WHEN delay_days > 0 THEN 1.0 ELSE 0 END) AS late_rate
FROM olist_silver.order_items_enriched
WHERE order_status = 'delivered'
GROUP BY seller_id, seller_state;
```

A plain Parquet CTAS fails if `external_location` already contains data, so it suits one-off snapshots
(or a dated prefix per run). For tables refreshed daily, use **Iceberg** with `MERGE` (as `BuildGold` does),
which also gives time travel and safe concurrent reads during the refresh.

**Views vs CTAS tables:**

| | View | CTAS table (CETAS) |
|---|---|---|
| Storage | none | Parquet in gold/ |
| Freshness | always current | as of the last refresh |
| Query cost | re-scans silver each time | scans small gold files |
| Use | light logic, low traffic | heavy aggregations behind dashboards |

### Dedicated SQL pool → Redshift Serverless

```bash
aws redshift-serverless create-namespace --namespace-name olist \
  --iam-roles arn:aws:iam::$ACCOUNT_ID:role/olist-redshift-role --default-iam-role-arn arn:aws:iam::$ACCOUNT_ID:role/olist-redshift-role
aws redshift-serverless create-workgroup --workgroup-name olist --namespace-name olist --base-capacity 8
```

```sql
-- Query the lake via Spectrum (no copy)
CREATE EXTERNAL SCHEMA lake_gold FROM DATA CATALOG DATABASE 'olist_gold' IAM_ROLE default;
CREATE EXTERNAL SCHEMA lake_silver FROM DATA CATALOG DATABASE 'olist_silver' IAM_ROLE default;

-- Load hot gold data locally for fast, concurrent dashboards
CREATE TABLE public.seller_performance DISTSTYLE AUTO SORTKEY AUTO AS
SELECT * FROM lake_gold.seller_performance;

-- Or materialized views over Spectrum, refreshed after each pipeline run
CREATE MATERIALIZED VIEW public.mv_state_month AS
SELECT customer_state, purchase_month, count(*) AS items, sum(price) AS revenue
FROM lake_silver.order_items_enriched GROUP BY 1, 2;
REFRESH MATERIALIZED VIEW public.mv_state_month;
```

**Dedicated vs serverless (Synapse) → Redshift vs Athena decision:** Athena is enough for this dataset and a handful
of analysts. Use Redshift when dozens of dashboard users need sub-second responses, complex joins run constantly,
or you need workload management and SLAs.

## 8. Visualization: QuickSight

1. Sign up for QuickSight (Standard/Enterprise), allow access to Athena and the `olist-lake-*` bucket (or
   the Redshift workgroup).
2. Dataset → Athena → workgroup `olist` → `olist_gold.v_category_monthly`, `v_state_delivery`,
   `seller_performance`. Import into **SPICE** (in-memory) for speed, and schedule a refresh after the pipeline.
3. Visuals: revenue trend by month (line), top 10 categories (bar), late-rate by state (filled map / heatmap),
   review score vs delay (scatter), seller leaderboard (table with conditional formatting).

## 9. Production hardening checklist

| Area | Action |
|---|---|
| IaC | the whole stack in CloudFormation/CDK/Terraform; tags `project=olist`, `env=dev` |
| Security | private subnets, VPC endpoints, SSE-KMS, Secrets Manager, Lake Formation grants on `olist_*`, no public DB |
| Idempotency | dated bronze prefixes; silver/gold overwrite per partition or MERGE (Iceberg/Delta) |
| Data quality | Glue Data Quality rules on silver; fail the state machine on rule failure |
| Observability | Step Functions execution history, Glue job metrics, CloudWatch alarms on failures and duration, SNS alerts |
| Cost | Glue Flex for non-urgent jobs, Python shell (0.0625 DPU) for HTTP copies, Athena workgroup scan limits, Redshift Serverless max RPU, S3 lifecycle on bronze |
| Lineage | Unity Catalog lineage (Databricks) or Amazon DataZone / SageMaker Catalog for business catalog and lineage |

## 10. Cost estimate (dev, one run per day)

Rough order of magnitude for this dataset size (~120 MB raw). Check current regional prices:

| Component | Driver | ≈ Cost |
|---|---|---|
| RDS MySQL db.t4g.micro | hourly | low tens of \$/month if left running |
| Glue Python shell × 7 | 0.0625 DPU × ~1 min each | cents per run |
| Glue Spark JDBC + silver | 2–4 G.1X workers × few minutes | well under \$1 per run |
| Athena | MBs scanned | fractions of a cent |
| Redshift Serverless | RPU-seconds while querying | a few \$ per hour of active use; zero when idle |
| NAT gateway | hourly + per-GB | ~\$1+/day: delete after labs |
| MongoDB Atlas free tier / DocumentDB | — | free / hourly |

## Teardown

```bash
aws scheduler delete-schedule --name olist-daily
aws stepfunctions delete-state-machine --state-machine-arn arn:aws:states:$REGION:$ACCOUNT_ID:stateMachine:olist-pipeline
for j in olist-http-to-s3 olist-jdbc-to-s3 olist-silver; do aws glue delete-job --job-name $j; done
aws glue delete-connection --connection-name olist-mysql
aws rds delete-db-instance --db-instance-identifier olist-mysql --skip-final-snapshot
aws redshift-serverless delete-workgroup --workgroup-name olist
aws redshift-serverless delete-namespace --namespace-name olist
for db in olist_bronze olist_silver olist_gold; do aws glue delete-database --name $db; done
# empty and delete the bucket (versioned: delete versions too, or use the console "Empty" action)
# delete NAT gateway, bastion EC2, Databricks workspace/cluster, Atlas cluster, QuickSight subscription
```

## Key takeaways

- ADF maps to Glue jobs (copy/transform) + Step Functions (pipeline, ForEach = Map, `.sync` waits) + EventBridge (triggers).
- ADLS Gen2 maps to S3 + Glue Catalog + Lake Formation; Databricks connects via UC storage credentials (IAM roles).
- Synapse serverless maps to Athena (views, CTAS = CETAS); Synapse dedicated maps to Redshift (Serverless) + Spectrum.
- Join at the right grain, broadcast small reference data (MongoDB), export silver as Parquet with partitions.
- Everything parameterized, idempotent, tagged, monitored, and torn down after the lab.

## Interview scenarios

1. *Walk me through your capstone architecture.* — three sources → Step Functions (Map over config for HTTP,
   Glue JDBC for MySQL) → S3 bronze by ingest date → Spark (Databricks/Glue) cleans, enriches with MongoDB,
   writes partitioned silver Parquet → Athena views + CTAS gold → Redshift Serverless for dashboards → QuickSight;
   daily via EventBridge; alerts via SNS.
2. *How did you make ingestion parameterized?* — one generic Glue job with `--source_url/--target_key` arguments;
   a JSON config listing sources; a Step Functions Map state iterating it with bounded concurrency and retries.
   Adding a source = one config line.
3. *Why Parquet in silver instead of Delta?* — simplest interoperability with Athena/Spectrum for this project. In
   production I'd use Iceberg (best AWS-native support) or Delta with UniForm, for MERGE and time travel.
4. *What breaks if the MySQL table gets updates after ingestion?* — daily snapshots catch them next run, but
   intra-day changes and deletes are missed. Use DMS CDC to S3 and MERGE into an Iceberg/Delta silver table.
