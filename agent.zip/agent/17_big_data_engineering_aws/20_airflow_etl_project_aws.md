# 20 — Airflow ETL Project: NASA API → RDS Postgres on MWAA

> **Why it matters:** this is the original course's Airflow ETL project (Astro + Postgres + NASA API),
> rebuilt for AWS. It's small enough to finish in an afternoon, but it covers every production concern:
> connections and secrets, extract/transform/load as separate idempotent tasks, retries, a failing load
> step and how to fix it, local development, and deployment to MWAA with a private RDS database.

## In plain words

Every day, ask NASA's "Astronomy Picture of the Day" (APOD) API for today's picture details (title,
explanation, image URL, date). Clean the response, and save one row per day into a Postgres table. If you
run the same day twice, you still get exactly one row for that day.

## Architecture at a glance

```mermaid
flowchart LR
  subgraph LOCAL["Local dev (Astro CLI / MWAA local runner)"]
    LDAG[DAG code] --> LPG[(Postgres container)]
  end
  subgraph AWS["AWS"]
    GIT[git main branch] -->|CI: aws s3 sync| S3[(MWAA bucket<br/>dags/, requirements.txt)]
    subgraph VPC["VPC — private subnets"]
      MWAA[MWAA environment<br/>workers]
      RDS[(RDS PostgreSQL<br/>apod table)]
      NAT[NAT gateway]
    end
    SM[Secrets Manager<br/>airflow/connections/nasa_api<br/>airflow/connections/postgres_apod]
    S3 --> MWAA
    MWAA -->|5432, SG-to-SG rule| RDS
    MWAA -->|HTTPS| NAT --> NASA[api.nasa.gov<br/>APOD API]
    SM -.connections.-> MWAA
  end
```

**How to read it:** the same DAG runs locally against a Postgres container and on MWAA against RDS. On MWAA,
workers live in your private subnets. They reach RDS through a security-group rule and the public NASA API
through a NAT gateway. Credentials come from Secrets Manager, never from code.

## 1. Problem statement and project structure

| Step | Task | Type |
|---|---|---|
| 0 | `create_table` — ensure `apod` table exists | SQL (idempotent DDL) |
| 1 | `extract_apod` — GET `https://api.nasa.gov/planetary/apod?api_key=...&date={{ ds }}` | HTTP |
| 2 | `transform_apod` — select fields, validate, normalize | Python (TaskFlow) |
| 3 | `load_apod` — upsert into Postgres | Python + PostgresHook |

```
airflow-apod/
├── dags/
│   └── apod_etl.py
├── tests/
│   └── test_dag_integrity.py
├── requirements.txt          # provider packages
├── Dockerfile                # Astro runtime (local)
└── .github/workflows/deploy.yml
```

`requirements.txt`:

```
apache-airflow-providers-http
apache-airflow-providers-postgres
apache-airflow-providers-common-sql
apache-airflow-providers-amazon
```

(Pin versions that match your Airflow version's **constraints file**. MWAA validates them against its constraints.)

## 2. The DAG

```python
# dags/apod_etl.py
from datetime import datetime, timedelta
from airflow.sdk import dag, task
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from airflow.providers.http.operators.http import HttpOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook

PG_CONN = "postgres_apod"

@dag(
    dag_id="apod_etl",
    start_date=datetime(2025, 1, 1),
    schedule="@daily",
    catchup=False,
    max_active_runs=1,
    default_args={"retries": 3, "retry_delay": timedelta(minutes=2),
                  "retry_exponential_backoff": True, "execution_timeout": timedelta(minutes=10)},
    tags=["etl", "course"],
)
def apod_etl():
    create_table = SQLExecuteQueryOperator(
        task_id="create_table",
        conn_id=PG_CONN,
        sql="""
        CREATE TABLE IF NOT EXISTS apod (
            apod_date    DATE PRIMARY KEY,
            title        TEXT NOT NULL,
            explanation  TEXT,
            url          TEXT,
            media_type   TEXT,
            loaded_at    TIMESTAMPTZ DEFAULT now()
        );""",
    )

    extract_apod = HttpOperator(
        task_id="extract_apod",
        http_conn_id="nasa_api",                      # host: https://api.nasa.gov
        endpoint="planetary/apod",
        method="GET",
        data={"api_key": "{{ conn.nasa_api.extra_dejson.api_key }}", "date": "{{ ds }}"},
        response_check=lambda r: r.status_code == 200,
        response_filter=lambda r: r.json(),           # pushed to XCom (small JSON)
        log_response=False,
    )

    @task
    def transform_apod(resp: dict) -> dict:
        required = ("date", "title")
        missing = [k for k in required if not resp.get(k)]
        if missing:
            raise ValueError(f"APOD response missing {missing}: {resp}")
        return {
            "apod_date": resp["date"],
            "title": resp["title"].strip(),
            "explanation": (resp.get("explanation") or "").strip(),
            "url": resp.get("hdurl") or resp.get("url"),
            "media_type": resp.get("media_type", "unknown"),
        }

    @task
    def load_apod(row: dict) -> None:
        hook = PostgresHook(postgres_conn_id=PG_CONN)
        hook.run(
            """
            INSERT INTO apod (apod_date, title, explanation, url, media_type)
            VALUES (%(apod_date)s, %(title)s, %(explanation)s, %(url)s, %(media_type)s)
            ON CONFLICT (apod_date) DO UPDATE SET
              title = EXCLUDED.title, explanation = EXCLUDED.explanation,
              url = EXCLUDED.url, media_type = EXCLUDED.media_type, loaded_at = now();
            """,
            parameters=row,
        )

    row = transform_apod(extract_apod.output)
    create_table >> extract_apod
    load_apod(row)

apod_etl()
```

Design notes:

| Choice | Why |
|---|---|
| `date={{ ds }}` | each run fetches **its own** logical date, so backfills produce historical days correctly |
| `ON CONFLICT ... DO UPDATE` | rerunning a day is **idempotent** (exactly one row per date) |
| Separate extract/transform/load | retry only the failed step; inspect XCom between steps |
| `response_check` + validation in transform | fail loudly on bad responses instead of loading garbage |
| `execution_timeout` + exponential retries | API hiccups self-heal; hung requests don't block the worker forever |
| `max_active_runs=1` | gentle on the API (DEMO_KEY rate limits are low; get a free key) |

## 3. Local development with Astro (Airflow 3)

```bash
astro dev init                    # then copy apod_etl.py into dags/ and the provider lines into requirements.txt
astro dev start
# Connections (UI → Admin → Connections, or CLI):
astro dev run connections add nasa_api --conn-type http --conn-host https://api.nasa.gov \
  --conn-extra '{"api_key": "DEMO_KEY"}'
astro dev run connections add postgres_apod --conn-uri 'postgres://postgres:postgres@postgres:5432/postgres'
astro dev run dags test apod_etl 2025-03-01      # run one logical date end to end, in-process
```

The Astro local stack already runs a Postgres container (the metadata DB). Using it as the target is fine for
learning, but use a separate database in anything real.

DAG integrity test (runs in CI):

```python
# tests/test_dag_integrity.py
from airflow.models import DagBag

def test_no_import_errors():
    bag = DagBag(dag_folder="dags", include_examples=False)
    assert not bag.import_errors, bag.import_errors

def test_apod_structure():
    dag = DagBag(dag_folder="dags", include_examples=False).get_dag("apod_etl")
    assert set(dag.task_ids) == {"create_table", "extract_apod", "transform_apod", "load_apod"}
    assert dag.default_args["retries"] >= 1
```

## 4. Deploy on AWS: RDS + Secrets Manager + MWAA

### 4.1 RDS PostgreSQL (private)

```bash
aws rds create-db-instance --db-instance-identifier apod-pg \
  --engine postgres --db-instance-class db.t4g.micro --allocated-storage 20 \
  --master-username apod_admin --manage-master-user-password \
  --db-name apod --no-publicly-accessible \
  --vpc-security-group-ids sg-rds --db-subnet-group-name private-subnets \
  --backup-retention-period 1
aws rds wait db-instance-available --db-instance-identifier apod-pg
```

Security group rule: **inbound 5432 on `sg-rds` from `sg-mwaa`** (SG-to-SG, no CIDRs).

### 4.2 Connections in Secrets Manager

```bash
aws secretsmanager create-secret --name airflow/connections/nasa_api \
  --secret-string '{"conn_type":"http","host":"https://api.nasa.gov","extra":{"api_key":"<your-key>"}}'
aws secretsmanager create-secret --name airflow/connections/postgres_apod \
  --secret-string 'postgres://apod_etl:<password>@apod-pg.xxxx.ap-south-1.rds.amazonaws.com:5432/apod'
```

Create a dedicated DB user `apod_etl` with rights only on the `apod` table (least privilege). The MWAA
execution role needs `secretsmanager:GetSecretValue` on `airflow/connections/*` and `airflow/variables/*`.
The JSON secret format needs a recent Amazon provider; the URI format works everywhere.

### 4.3 Deploy

```bash
aws s3 cp requirements.txt s3://$MWAA_BUCKET/requirements.txt
aws s3 sync dags/ s3://$MWAA_BUCKET/dags/ --delete
aws mwaa update-environment --name bigdata-mwaa \
  --requirements-s3-path requirements.txt \
  --requirements-s3-object-version $(aws s3api head-object --bucket $MWAA_BUCKET --key requirements.txt --query VersionId --output text)
```

(The MWAA bucket must have versioning enabled.) Unpause `apod_etl` in the UI and trigger a run.

CI/CD (GitHub Actions sketch): on push to `main` → `pytest tests/` → OIDC-assume a deploy role →
`aws s3 sync dags/ s3://$MWAA_BUCKET/dags/`.

## 5. Designing the flow: dependencies and failure handling

```mermaid
flowchart LR
  CT[create_table] --> EX[extract_apod<br/>retries 3, backoff]
  EX --> TR[transform_apod<br/>validate]
  TR --> LD[load_apod<br/>upsert]
  EX -. fail after retries .-> ALERT[on_failure_callback<br/>→ SNS / Slack]
  TR -. invalid payload .-> ALERT
  LD -. fail .-> ALERT
```

| Failure | What happens | Desired behavior |
|---|---|---|
| NASA returns 429/5xx | `response_check` fails → retry with backoff | self-heals; alert only after the final retry |
| NASA returns 200 with missing fields | transform raises → no load | bad data never reaches the table |
| DB unreachable (SG, credentials) | load fails → retries → alert | fix infra, then **clear** only `load_apod` (XCom from transform is reused) |
| Rerun of a successful day | upsert overwrites the same row | no duplicates |
| A week of missed days | backfill 7 logical dates | each run fetches its own date |

Add an alert callback:

```python
def notify_failure(context):
    import boto3
    ti = context["ti"]
    boto3.client("sns").publish(
        TopicArn="arn:aws:sns:ap-south-1:123456789012:data-alerts",
        Subject=f"Airflow failure: {ti.dag_id}.{ti.task_id}",
        Message=f"Run {context['run_id']} try {ti.try_number}: {context.get('exception')}")
# default_args={"on_failure_callback": notify_failure, ...}
```

## 6. Fixing a failing load step (scenario with solution)

> *`load_apod` started failing with `duplicate key value violates unique constraint "apod_pkey"` after a
> teammate "simplified" the SQL to a plain `INSERT`. It fails every time the DAG is rerun or backfilled.*

- **Root cause:** a plain INSERT isn't idempotent. Any retry or rerun of an already-loaded date hits the primary key.
- **Wrong fixes:** dropping the primary key (creates duplicates), or catching and ignoring all exceptions (hides real errors).
- **Right fix:** restore `INSERT ... ON CONFLICT (apod_date) DO UPDATE` (or DO NOTHING if updates aren't wanted).
  Add a unit/integration test that runs load twice and asserts 1 row. In code review, require idempotency for every load task.

Second variant: `psycopg2.OperationalError: connection timed out` on MWAA but not locally → network. The RDS
security group lacks inbound from the MWAA security group, or RDS sits in subnets without a route from
MWAA's subnets. Verify with a test task that resolves the host and opens a socket to port 5432.

## Teardown

```bash
aws mwaa delete-environment --name bigdata-mwaa
aws rds delete-db-instance --db-instance-identifier apod-pg --skip-final-snapshot
aws secretsmanager delete-secret --secret-id airflow/connections/nasa_api --force-delete-without-recovery
aws secretsmanager delete-secret --secret-id airflow/connections/postgres_apod --force-delete-without-recovery
# NAT gateways bill hourly: delete the one you created for the lab
```

## Key takeaways

- One task per E/T/L step; pass small JSON via XCom; keep the run's logical date (`ds`) in every external call.
- Idempotent loads (`ON CONFLICT`) make retries, reruns, and backfills safe.
- Locally: Astro CLI + `dags test`. On AWS: MWAA + RDS in private subnets + Secrets Manager connections.
- Network design for MWAA: private subnets, SG-to-SG rules to data stores, NAT or endpoints for outbound access.
- Alert after final retries, not on every transient failure.

## Interview scenarios

1. *How do you make an API → DB pipeline safe to rerun?* — parameterize by logical date, upsert on a natural key,
   overwrite partitions rather than append, keep raw responses in S3 for replay.
2. *Your DAG works locally but times out on MWAA when calling an external API.* — MWAA workers are in private
   subnets. They need a NAT gateway (or a proxy) for internet egress.
3. *Where should the NASA API key live?* — Secrets Manager (via the MWAA secrets backend), referenced as a connection
   extra. Never in DAG code, Variables in plain text, or git.
