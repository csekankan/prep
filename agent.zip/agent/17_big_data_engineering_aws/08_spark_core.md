# 08 — Apache Spark Core: Why It Beat MapReduce, Transformations vs Actions, Laziness

> **Why it matters:** Spark is the default engine for big data on EMR, Glue, and Databricks. Every
> performance problem you'll debug comes down to how Spark turns your code into a DAG of stages and
> tasks. This module builds that mental model.

## In plain words

MapReduce is a chef who, after every step of a recipe, puts the half-finished dish **back in the
freezer** (HDFS) and takes it out again for the next step. Spark keeps it **on the counter** (memory)
and reads the **whole recipe first** (lazy evaluation), so it can combine steps ("chop and fry in one
go") and skip steps whose results nobody eats.

## Architecture at a glance

```mermaid
flowchart TB
  subgraph API["APIs you write"]
    SQL[Spark SQL]
    DF[DataFrame / Dataset]
    PY[PySpark / Scala / Java / R]
  end
  subgraph LIBS["Libraries"]
    SS[Structured Streaming]
    ML[MLlib]
    GX[GraphX / GraphFrames]
  end
  CAT[Catalyst optimizer<br/>+ Tungsten execution]
  CORE[Spark Core<br/>RDDs, DAG scheduler, task scheduler,<br/>memory mgmt, shuffle, fault tolerance]
  subgraph CM["Cluster managers"]
    STA[Standalone]
    YARN[YARN — EMR]
    K8S[Kubernetes — EMR on EKS]
    LOC[local mode]
  end
  subgraph ST["Storage"]
    S3[(S3)]
    HDFS[(HDFS)]
    JDBC[(JDBC / Kafka /<br/>Delta / Iceberg)]
  end
  API --> CAT
  LIBS --> CAT
  CAT --> CORE --> CM
  CORE <--> ST
```

**How to read it:** you write SQL/DataFrame code. Catalyst optimizes it into a physical plan. Spark Core
runs that plan as tasks on executors provided by a cluster manager, reading from and writing to storage.
Spark is a **compute engine only**: it has no storage of its own.

## 1. Limitations of MapReduce → what Spark changed

| MapReduce | Spark |
|---|---|
| Disk between every job (HDFS write ×3 replicas, read back) | in-memory between stages where possible; shuffle files on local disk |
| Only map + reduce; multi-step = chain of jobs | arbitrary DAG of 80+ operators in one application |
| New JVM per task | long-lived executors; tasks are threads |
| Batch only | batch, SQL, streaming, ML, graph in one engine |
| Verbose Java | concise Python/Scala/SQL |
| No global optimization | Catalyst optimizes the whole query |

**Iterative example — logistic regression, 10 iterations over 100 GB:**
- MR: 10 jobs × (read 100 GB + write results) ≈ 10 full disk scans.
- Spark: read once, `cache()`, then 10 passes from memory. That's how Spark reached 10–100× speedups.

### What is Spark, and its core features

Apache Spark is a **unified, distributed, in-memory compute engine** for large-scale data processing. It was
created at UC Berkeley AMPLab in 2009 and became an Apache top-level project in 2014.

| Feature | What it means | Mechanism |
|---|---|---|
| **In-memory computation** | intermediate data stays in RAM within and across stages when possible | pipelined operators, `cache/persist`, Tungsten binary format |
| **Lazy evaluation** | nothing runs until an action; the whole plan is optimized first | lineage DAG + Catalyst (section 7) |
| **Fault tolerance** | lost partitions are recomputed, not restored from replicas | RDD lineage; shuffle files kept for reuse |
| **Distributed & parallel** | data split into partitions, processed by many tasks at once | DAG scheduler → stages → tasks |
| **Unified engine** | batch, SQL, streaming, ML, graph on one API and runtime | Spark SQL, Structured Streaming, MLlib, GraphX |
| **Polyglot** | Python, Scala, Java, R, SQL | all compile to the same JVM plan (module 25) |
| **Optimizer** | rewrites queries (pushdown, pruning, join selection) and adapts at runtime | Catalyst + AQE |
| **Runs anywhere** | local, Standalone, YARN, Kubernetes, serverless | pluggable cluster managers |
| **Reads anything** | S3, HDFS, JDBC, Kafka, Parquet/ORC/JSON/CSV/Avro, Delta/Iceberg/Hudi | data source API |

## 2. Common questions about Spark (and correct answers)

| Question | Answer |
|---|---|
| Is Spark a replacement for Hadoop? | It replaces **MapReduce**. It still often uses YARN (resource manager) and HDFS/S3 (storage). |
| Does Spark need everything to fit in memory? | No. It spills to disk during shuffles/aggregations and processes partitions as streams. Memory makes it faster, not possible. |
| Is Spark always faster than MR? | For multi-stage and iterative jobs, yes. For a single huge sort, the gap is smaller (both are disk/network bound). |
| Is Spark a database? | No. No storage, no indexes (Delta/Iceberg add table features on top). |
| Is Spark real-time? | Structured Streaming is micro-batch (~100 ms–seconds latency); Flink is better for millisecond event-at-a-time. |

## 3. Spark ecosystem

| Component | Use | AWS service where you'll run it |
|---|---|---|
| Spark SQL / DataFrames | ETL, analytics | EMR, Glue, Databricks, EMR Serverless; **Athena for Apache Spark** notebooks |
| Structured Streaming | streams from Kafka/MSK/Kinesis to S3/Delta | EMR, Glue streaming jobs, Databricks |
| MLlib | distributed ML (feature pipelines, ALS, GBT) | EMR, SageMaker Processing with Spark |
| GraphX (Scala) / GraphFrames | graph algorithms | EMR |
| pandas API on Spark | pandas syntax at scale | anywhere |

## 4. Ways to run Spark

| Mode | Where the driver and executors run | Use |
|---|---|---|
| `local[*]` | one JVM, threads = cores | dev, unit tests |
| Standalone | Spark's own master/workers | simple dedicated clusters |
| YARN (EMR) | executors in YARN containers | Hadoop clusters |
| Kubernetes (EMR on EKS) | executors in pods | K8s shops |
| Serverless (EMR Serverless, Glue) | managed | no cluster ops |
| Interactive | `pyspark` shell, notebooks (EMR Studio, Databricks, SageMaker Unified Studio) | exploration |

```bash
# local
pip install pyspark==3.5.*
pyspark --master "local[4]"

# EMR primary node
spark-submit --master yarn --deploy-mode cluster \
  --num-executors 4 --executor-cores 4 --executor-memory 8g \
  s3://$BUCKET/code/wordcount.py s3://$BUCKET/raw/books/ s3://$BUCKET/curated/wc/
```

## 5. Executing code in Spark: word count end to end

```python
# wordcount.py
import sys
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("wordcount").getOrCreate()
sc = spark.sparkContext
src, dst = sys.argv[1], sys.argv[2]

counts = (sc.textFile(src)                              # RDD[str], 1 partition per split
            .flatMap(lambda line: line.lower().split())  # narrow
            .map(lambda w: (w, 1))                       # narrow
            .reduceByKey(lambda a, b: a + b)             # WIDE → shuffle (with map-side combine)
            .sortBy(lambda kv: -kv[1]))                  # WIDE → shuffle (range partitioning)

counts.saveAsTextFile(dst)                               # ACTION → triggers the job
spark.stop()
```

DataFrame version (what you'd write in practice):

```python
from pyspark.sql import functions as F
(spark.read.text(src)
   .select(F.explode(F.split(F.lower("value"), r"\s+")).alias("word"))
   .where(F.col("word") != "")
   .groupBy("word").count()
   .orderBy(F.desc("count"))
   .write.mode("overwrite").parquet(dst))
```

## 6. Transformations vs actions

| | Transformations | Actions |
|---|---|---|
| Returns | a new RDD/DataFrame (a plan) | a value to the driver, or writes to storage |
| Runs anything? | **no** — just records lineage | **yes** — triggers a job |
| Examples | `map`, `filter`, `flatMap`, `select`, `where`, `join`, `groupBy`, `union`, `distinct`, `repartition` | `count`, `collect`, `take`, `first`, `show`, `reduce`, `foreach`, `write.*`, `saveAsTextFile` |

**Narrow vs wide transformations** (deeper in module 09):

```
 NARROW (no shuffle)                      WIDE (shuffle)
 parent partitions → child partitions     every child partition may need data
 1-to-1 or many-to-1 by position          from every parent partition
 P1 → P1'                                 P1 ─┬─► P1'
 P2 → P2'                                 P2 ─┼─► P2'
 P3 → P3'                                 P3 ─┴─► P3'
 map, filter, flatMap, union, coalesce    groupByKey, reduceByKey, join*, distinct, repartition, orderBy
                                          (*unless co-partitioned or broadcast)
```

## 7. Why is Spark lazy?

```mermaid
flowchart LR
  A["read orders<br/>(transformation)"] --> B["filter status='delivered'"] --> C["select id, amount"] --> D["groupBy day sum"] --> E{{"write parquet<br/>(ACTION)"}}
  E -->|now Spark builds the DAG,<br/>optimizes, splits into stages| RUN[Job runs]
```

Laziness lets Spark see the **whole pipeline** before running anything:

1. **Pipelining:** `read → filter → select` fuse into one pass per partition (one stage), with no intermediate materialization.
2. **Predicate pushdown:** the filter moves into the Parquet reader, which skips row groups using min/max stats.
3. **Column pruning:** only `id, amount, status, day` are read from Parquet.
4. **Avoid wasted work:** `df.limit(10).show()` reads only enough partitions.
5. **Fault tolerance via lineage:** the recipe (not the data) is remembered, so a lost partition is recomputed from its parents.

**Consequence:** errors show up at the action, not at the line that caused them. A typo'd column fails at
analysis time (DataFrames check eagerly), but bad data such as a division by zero fails during execution.

### Jobs, stages, tasks (preview)

- **Job** = one action.
- **Stage** = a set of pipelined narrow transformations; **stage boundaries are shuffles**.
- **Task** = one stage applied to one partition; tasks = parallel units scheduled on executor cores.

Word count above → 1 job (`saveAsTextFile`), with `sortBy` triggering an extra sampling job; stages:
`[textFile → flatMap → map → map-side combine]` | shuffle | `[reduceByKey final → sample/range-partition]`
| shuffle | `[sort → write]`.

## 8. Spark vs MapReduce — explaining it to a manager

"MapReduce writes every intermediate result to the distributed disk and reads it back for the next step.
Spark plans the whole job first, keeps intermediate data in memory, and only writes to disk when data must
move between machines. For our 12-step nightly pipeline that means 1 read and a couple of shuffles instead of
12 full disk round trips. It went from 4 hours to 25 minutes, and we can now run the same code for SQL,
streaming, and ML."

## Key takeaways

- Spark replaces MapReduce, not Hadoop storage/YARN; it's a compute engine with no storage.
- Transformations build a lineage DAG; actions trigger jobs.
- Laziness enables pipelining, predicate pushdown, column pruning, and lineage-based recovery.
- Stage boundary = shuffle = wide transformation; task = one partition of one stage.
- Run Spark on AWS via EMR (EC2/EKS/Serverless), Glue, Databricks, or Athena Spark notebooks.

## Interview scenarios

1. *`df = spark.read.parquet(p).filter(...)` returns instantly on 5 TB. Did it read the data?* — No. Only
   metadata (Parquet footers/schema) was touched. Work happens at the first action.
2. *How many jobs does this code run: `df.count(); df.show(); df.write.parquet(p)`?* — at least 3 (one per
   action), and without caching each recomputes from the source.
3. *Why doesn't Spark lose data if an executor dies mid-job?* — lineage. The lost partitions are recomputed
   from their parent partitions (and shuffle outputs are re-fetched or regenerated).
4. *Why Spark beats MapReduce (one sentence)?* — in-memory pipelining across a whole optimized DAG instead of
   disk-materialized, map-and-reduce-only jobs.
