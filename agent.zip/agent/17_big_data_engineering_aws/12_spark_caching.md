# 12 — Spark Caching & Persistence

> **Why it matters:** caching is the most misused Spark feature. Done right, it turns a 5-action
> notebook from 5 full S3 scans into 1. Done wrong, it evicts execution memory, causes spills and GC
> storms, and makes jobs slower. You need the memory model to decide.

## In plain words

Without caching, every time you ask a question about a dataset, Spark **re-cooks the whole recipe
from raw ingredients** (re-reads S3 and redoes every transformation). Caching = putting the cooked dish
in the fridge after the first time. Fridge space (executor memory) is shared with the stove (execution:
joins, aggregations). Fill the fridge with dishes nobody eats again and there's no room to cook.

## Architecture at a glance — executor memory (unified memory manager)

```mermaid
flowchart TB
  subgraph CONT["YARN container = executor heap + overhead"]
    subgraph HEAP["JVM heap: spark.executor.memory (e.g. 8 GB)"]
      RES["Reserved: 300 MB"]
      subgraph UNI["Unified memory = (heap − 300 MB) × spark.memory.fraction 0.6"]
        STO["Storage<br/>cached blocks, broadcasts<br/>(soft boundary: storageFraction 0.5)"]
        EXE["Execution<br/>shuffle, join, sort, agg buffers"]
      end
      USR["User memory = (heap − 300 MB) × 0.4<br/>your objects, UDF data, metadata"]
    end
    OVH["memoryOverhead: max(384 MB, 10%)<br/>off-heap, native, Python workers"]
  end
  EXE <-->|borrow / evict| STO
```

**How to read it:** storage and execution share one pool. Execution can **evict** cached blocks (down to
the protected `storageFraction` region) when it needs memory. Storage can borrow free execution memory but
can't evict execution. So caching never directly fails a job, but it can push execution into spilling to disk.

**Worked numbers** for `spark.executor.memory=8g`:

- Usable: \(8192 - 300 = 7892\) MB
- Unified: \(7892 \times 0.6 \approx 4735\) MB (storage protected ≈ 2368 MB)
- User memory: \(7892 \times 0.4 \approx 3157\) MB
- Overhead: \(\max(384, 0.10 \times 8192) \approx 819\) MB → YARN container ≈ 9 GB

Ten executors therefore cache roughly 23–47 GB of **deserialized** data in total. Deserialized Java
objects can be 2–5× larger than the Parquet on disk, so a 20 GB Parquet dataset might not fit.

## 1. cache() vs persist()

| | `cache()` | `persist(level)` |
|---|---|---|
| RDD default | `MEMORY_ONLY` | any level |
| DataFrame/Dataset default | `MEMORY_AND_DISK` (Spark 3.x; stored in a compact columnar format) | any level |
| Laziness | lazy: materialized by the first action | lazy |
| Remove | `unpersist()` | `unpersist()` |

`cache()` is simply `persist()` with the default level.

### Storage levels

| Level | Where | Serialized? | If it doesn't fit | When |
|---|---|---|---|---|
| `MEMORY_ONLY` | heap | no (RDD) | partitions not cached; recomputed on use | small, hot, cheap to recompute |
| `MEMORY_AND_DISK` | heap, spill to local disk | DF: columnar compressed | written to disk | default for DataFrames; expensive lineage |
| `MEMORY_ONLY_SER` (Scala/Java) | heap | yes | recomputed | less memory, more CPU |
| `DISK_ONLY` | local disk | yes | | huge but expensive to recompute |
| `*_2` (e.g. `MEMORY_AND_DISK_2`) | two executors | | | fast recovery on executor loss (Spot!) |
| `OFF_HEAP` | off-heap memory | yes | | requires `spark.memory.offHeap.enabled` |

In PySpark, RDD data is always pickled (serialized) on the JVM side, so the `_SER` distinction is a Scala/Java concern.

## 2. Common questions about caching

| Question | Answer |
|---|---|
| Does `df.cache()` cache immediately? | No. The next action materializes it, and only for the partitions that action computes (`take(5)` may cache only 1 partition). Use `count()` to fully materialize. |
| Is a temp view cached? | No. Use `spark.catalog.cacheTable("v")` or `CACHE TABLE v`. |
| Is `CACHE TABLE` lazy? | **No, eager by default** in SQL. `CACHE LAZY TABLE t` is lazy. |
| Does caching survive the application? | No. It's executor memory/disk. For reuse across jobs, write Parquet/Delta. |
| What if an executor holding cached blocks dies? | Those partitions are recomputed from lineage on next use (or read from the replica with `_2`). |
| Does Spark cache automatically? | Shuffle outputs are kept and reused ("skipped stages"), but datasets aren't cached unless you ask. |
| `df2 = df.filter(...)` after `df.cache()`: is df2 cached? | It *uses* df's cache as its source, but df2's own result isn't cached. |

## 3. When caching helps vs hurts

```mermaid
flowchart TD
  A[Is the DataFrame used by ≥ 2 actions<br/>or in an iterative loop?] -->|no| N1[Don't cache]
  A -->|yes| B[Is recomputing it expensive?<br/>S3 scan of large data, joins, UDFs]
  B -->|no: e.g. read a small Parquet + filter| N2[Probably don't cache]
  B -->|yes| C[Does it fit comfortably in<br/>storage memory across executors?]
  C -->|yes| Y1[cache / MEMORY_AND_DISK<br/>materialize with count,<br/>unpersist when done]
  C -->|no| D[Is it reused many times?]
  D -->|yes| Y2[persist DISK_ONLY<br/>or write to Parquet checkpoint]
  D -->|no| N3[Don't cache]
```

Good uses: iterative ML; an expensive cleaned/joined dataset feeding several aggregations; a dimension table
reused in many joins (broadcasting is often better); interactive exploration.

Bad uses: caching a raw read used once; caching before a filter (cache the **filtered/projected** result);
caching everything "just in case"; forgetting `unpersist` in long-running jobs and notebooks.

## 4. Hands-on: measure it

```python
import time
from pyspark import StorageLevel
from pyspark.sql import functions as F

src = spark.read.parquet(f"s3://{BUCKET}/silver/orders/")
enriched = (src.where("status = 'delivered'")
               .join(spark.read.parquet(f"s3://{BUCKET}/silver/customers/"), "customer_id")
               .select("order_id", "customer_id", "city", "segment", "amount", "order_date"))

def timed(label, fn):
    t = time.time(); fn(); print(f"{label}: {time.time() - t:.1f}s")

timed("no cache, action 1", lambda: enriched.groupBy("city").sum("amount").collect())
timed("no cache, action 2", lambda: enriched.groupBy("segment").count().collect())

enriched.persist(StorageLevel.MEMORY_AND_DISK)
timed("materialize", enriched.count)
timed("cached, action 1", lambda: enriched.groupBy("city").sum("amount").collect())
timed("cached, action 2", lambda: enriched.groupBy("segment").count().collect())

enriched.unpersist()
```

What to check in the Spark UI:
- **Storage tab:** "Fraction Cached" (100%?), size in memory vs on disk.
- **SQL tab:** the plan now begins with `InMemoryTableScan` instead of `FileScan parquet`.
- **Stages:** cached runs show no S3 input bytes.

Experiments the original course does on small vs big files, and what you'll observe:

| Experiment | Typical observation |
|---|---|
| Small file (100 MB) RDD cache | little gain: S3 read is fast, and caching adds overhead on the first action |
| Big file (20+ GB) RDD `MEMORY_ONLY` | partial cache ("Fraction cached 60%"); uncached partitions recomputed each time |
| Big DF `MEMORY_AND_DISK` | 100% cached, part on disk; still faster than an S3 re-read plus re-join |
| `CACHE TABLE` in SQL | eager job immediately; subsequent SQL hits `InMemoryTableScan` |

## 5. Table caching in SQL

```sql
CACHE TABLE hot_orders AS
SELECT * FROM sales.orders_ext WHERE order_date >= date_sub(current_date(), 7);  -- eager

CACHE LAZY TABLE sales.customers;     -- lazy
UNCACHE TABLE hot_orders;
CLEAR CACHE;
```

```python
spark.catalog.cacheTable("sales.customers")
spark.catalog.isCached("sales.customers")
spark.catalog.clearCache()
```

## 6. Caching vs checkpointing vs writing to storage

| | `cache/persist` | `checkpoint()` | write Parquet/Delta |
|---|---|---|---|
| Lineage kept | yes | **truncated** | n/a (new source) |
| Survives application | no | reliable checkpoint dir persists (HDFS/S3) but is meant for the app | yes |
| Use | reuse within a job | very long lineages (iterative loops) that make plans huge or recovery expensive | reuse across jobs, auditability |

`df.localCheckpoint()` truncates lineage using executor storage (fast, not fault tolerant).

## 7. Should we cache this dataset? (scenario with solution)

> *A notebook reads 800 GB of clickstream, filters to one country (40 GB), joins with a 2 GB user table,
> then runs 6 different aggregations. 10 executors × 16 GB.*

- Total unified memory ≈ 10 × (16,384 − 300) MB × 0.6 ≈ 94 GB; protected storage ≈ 47 GB.
- The filtered + joined result in memory: maybe 40–80 GB deserialized (columnar cache compresses well).
- Recompute cost per action: an 800 GB S3 scan plus a join. Very expensive.
- **Decision:** persist the **joined, column-pruned** result with `MEMORY_AND_DISK` (select only the needed
  columns first), materialize with `count()`, run the 6 aggregations, `unpersist()`. Broadcast the user table
  if it's under ~1 GB after projection. If the data is reused by tomorrow's jobs too, write it as Parquet instead.

## Key takeaways

- Unified memory = (heap − 300 MB) × 0.6, shared by storage and execution; execution can evict cache.
- RDD `cache()` = MEMORY_ONLY; DataFrame `cache()` = MEMORY_AND_DISK; both lazy. `CACHE TABLE` is eager.
- Cache only data that's reused, expensive to recompute, and filtered/projected first; then unpersist.
- Use `_2` levels on Spot-heavy clusters; checkpoint to cut very long lineage; write to storage to reuse across jobs.

## Interview scenarios

1. *After adding `cache()`, the job got slower.* — the cached data competed with execution memory, causing
   spills/GC, or it was used only once (extra materialization cost). Remove it, or cache a smaller projected dataset.
2. *You called `df.cache(); df.show()` and the Storage tab shows 1 of 200 partitions cached.* — `show()`
   computes only the partitions it needs. Use `count()` to materialize fully.
3. *Difference between persist and checkpoint?* — persist keeps lineage and stores data for reuse;
   checkpoint saves to reliable storage and **truncates** lineage.
