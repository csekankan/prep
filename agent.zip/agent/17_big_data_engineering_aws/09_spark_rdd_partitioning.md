# 09 — RDDs, Partitioning, Narrow vs Wide, Jobs/Stages/Tasks

> **Why it matters:** partitions are Spark's unit of parallelism, memory, and failure. Too few means idle
> cores and out-of-memory errors. Too many means scheduler overhead and tiny files. Shuffles are where 80%
> of job time goes. Being able to read the Spark UI and say "this stage has 3 tasks because of coalesce"
> is the core practical skill of a Spark engineer.

## In plain words

A **partition** is a stack of papers handed to one worker. A **task** is "one worker processes one
stack". A **narrow** step is "each worker processes their own stack" (highlight, filter). A **wide**
step is "everyone regroups papers by customer name", so papers must be passed between desks across the
room: the **shuffle**.

## Architecture at a glance — from code to tasks

```mermaid
flowchart TB
  CODE["Your code:<br/>read → filter → map → reduceByKey → join → write"]
  CODE --> DAGS[DAGScheduler:<br/>cut the lineage at shuffle boundaries]
  DAGS --> S1["Stage 1 (ShuffleMapStage)<br/>read → filter → map → map-side combine<br/>200 tasks = 200 input partitions"]
  DAGS --> S2["Stage 2 (ShuffleMapStage)<br/>read customers<br/>40 tasks"]
  S1 -->|shuffle write / read| S3["Stage 3 (ResultStage)<br/>reduce + join + write<br/>N tasks = shuffle partitions"]
  S2 -->|shuffle| S3
  S3 --> TS[TaskScheduler:<br/>assign tasks to executor cores,<br/>prefer data locality]
  TS --> EX1[Executor 1: 4 cores → 4 tasks at a time]
  TS --> EX2[Executor 2: 4 cores → 4 tasks at a time]
```

**How to read it:** one action = one job. The DAG scheduler walks the lineage backward from the action
and starts a new stage at every shuffle dependency. Each stage runs one task per partition. Tasks run
in **waves** across the total executor cores.

## 1. What is an RDD?

**Resilient Distributed Dataset** = an immutable, partitioned collection with lineage. Five properties
define every RDD internally:

| Property | Meaning |
|---|---|
| list of **partitions** | how the data is split |
| **compute** function per partition | how to produce a partition from its parents |
| list of **dependencies** | parent RDDs (narrow or shuffle) |
| optional **partitioner** | for key-value RDDs: hash or range |
| optional **preferred locations** | e.g. HDFS block hosts, for data locality |

**Resilient** = a lost partition is recomputed from lineage. **Distributed** = partitions live on many
executors. **Immutable** = transformations create new RDDs.

When to use RDDs today: rarely. Use them for unstructured, low-level control (custom partitioning,
non-tabular data). Otherwise DataFrames: Catalyst optimizes them and Tungsten stores them compactly. Under
the hood, DataFrames still execute as RDDs of internal binary rows.

## 2. How Spark reads data and decides the number of partitions

### RDD API (`sc.textFile`)

Uses the Hadoop InputFormat: **one partition per input split** (≈ per HDFS block, or per chunk for S3
based on the filesystem's reported block size). `minPartitions` can raise it. A non-splittable `.gz` file = 1 partition.

### DataFrame API (`spark.read.parquet/csv/json`)

Spark packs files into partitions using:

$$
\text{maxSplitBytes} = \min\Big(\text{maxPartitionBytes},\ \max\big(\text{openCostInBytes},\ \tfrac{\text{totalBytes}}{\text{defaultParallelism}}\big)\Big)
$$

with `spark.sql.files.maxPartitionBytes` = 128 MB, `spark.sql.files.openCostInBytes` = 4 MB (each file
counts as at least 4 MB when packing), and `defaultParallelism` = total executor cores.

**Worked examples** (cluster with 16 cores):

| Input | Calculation | Partitions |
|---|---|---|
| 1 file, 10 GB splittable | 10 GB/16 = 640 MB → capped at 128 MB | 10,240 / 128 = **80** |
| 1,000 files × 1 MB | each counts 1 + 4 MB; total ≈ 5 GB / 16 = 312 MB → 128 MB; pack ~25 files per partition | ≈ **40** |
| 200 MB total | 200/16 = 12.5 MB → max(4, 12.5) = 12.5 MB | ≈ **16** (one per core: good for small data) |
| 1 × 5 GB `.csv.gz` | not splittable | **1** (one core does all the work!) |

### `sc.parallelize(data)` / shuffles

- `parallelize` → `spark.default.parallelism` (= total cores on YARN).
- RDD shuffles (`reduceByKey`) default to `spark.default.parallelism` or the parent's partition count.
- DataFrame shuffles → `spark.sql.shuffle.partitions` = **200**, then **AQE** coalesces small ones at runtime (module 14).

## 3. Data generation + project steps (hands-on dataset)

Generate a synthetic orders dataset to experiment with partitioning and shuffles:

```python
# gen_orders.py — writes N CSV files of fake orders
import csv, random, datetime, sys, os

n_files, rows_per_file, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
os.makedirs(out, exist_ok=True)
cities = ["Mumbai", "Delhi", "Bengaluru", "Pune", "Chennai", "Kolkata"]
statuses = ["delivered"] * 8 + ["cancelled", "returned"]
start = datetime.date(2025, 1, 1)

for f in range(n_files):
    with open(f"{out}/orders_{f:04d}.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["order_id", "customer_id", "city", "status", "amount", "order_date"])
        for i in range(rows_per_file):
            cust = int(random.paretovariate(1.2)) % 100_000       # skewed: a few heavy customers
            w.writerow([f"{f}-{i}", cust, random.choice(cities), random.choice(statuses),
                        round(random.uniform(50, 5000), 2),
                        start + datetime.timedelta(days=random.randint(0, 364))])
```

```bash
python gen_orders.py 20 500000 ./orders        # ~20 × 30 MB
aws s3 sync ./orders s3://$BUCKET/raw/orders/
```

Project steps: (1) read and inspect partitions, (2) per-city revenue with `reduceByKey` vs `groupByKey`,
(3) inspect jobs/stages/tasks in the UI, (4) tune partitions with `repartition` / `coalesce`, (5) redo it with DataFrames.

## 4. RDD operations you should know

```python
sc = spark.sparkContext
lines = sc.textFile(f"s3://{BUCKET}/raw/orders/")
print(lines.getNumPartitions())

header = lines.first()
rows = (lines.filter(lambda l: l != header)
             .map(lambda l: l.split(","))
             .filter(lambda r: r[3] == "delivered"))

pairs = rows.map(lambda r: (r[2], float(r[4])))             # (city, amount)
revenue = pairs.reduceByKey(lambda a, b: a + b)             # wide, with map-side combine
avg = (pairs.aggregateByKey((0.0, 0),                       # (sum, count) per key
                            lambda acc, v: (acc[0] + v, acc[1] + 1),       # within partition
                            lambda a, b: (a[0] + b[0], a[1] + b[1]))       # across partitions
            .mapValues(lambda s: s[0] / s[1]))
top5 = revenue.takeOrdered(5, key=lambda kv: -kv[1])        # action, no full sort

print(rows.glom().map(len).collect()[:10])                  # rows per partition → spot skew
```

| Category | Operations |
|---|---|
| Narrow | `map`, `flatMap`, `filter`, `mapPartitions`, `mapValues`, `union`, `sample`, `coalesce` (no shuffle) |
| Wide | `groupByKey`, `reduceByKey`, `aggregateByKey`, `combineByKey`, `sortByKey`, `distinct`, `join`, `cogroup`, `repartition`, `partitionBy` |
| Actions | `collect`, `count`, `take`, `takeOrdered`, `first`, `reduce`, `fold`, `aggregate`, `countByKey`, `foreach`, `saveAsTextFile` |

`mapValues` keeps the parent's partitioner (`map` drops it), so a following `reduceByKey`/`join` on the same
keys can avoid a shuffle.

## 5. Narrow vs wide in depth — and what a shuffle physically does

```mermaid
flowchart LR
  subgraph MAPSIDE["Stage N: shuffle write"]
    T1[task 1] --> F1[(local shuffle file<br/>+ index, sorted by<br/>target partition)]
    T2[task 2] --> F2[(shuffle file)]
  end
  subgraph REDSIDE["Stage N+1: shuffle read"]
    R1[task for partition 0] 
    R2[task for partition 1]
  end
  F1 -->|block 0| R1
  F2 -->|block 0| R1
  F1 -->|block 1| R2
  F2 -->|block 1| R2
```

Shuffle cost = **serialize + write to local disk + network transfer + deserialize + (sort/aggregate)**. With
M map tasks and R reduce partitions, there are M × R blocks. Shuffle files are kept, so a retried
downstream stage can re-read them without recomputing upstream (one reason shuffle stages show up as
"skipped" in the UI).

## 6. Jobs, stages, and tasks in the Spark UI

| UI tab | What to read |
|---|---|
| **Jobs** | one row per action; duration; number of stages; "skipped" stages = reused shuffle output |
| **Stages** | tasks count, **shuffle read/write**, input size, **spill (memory/disk)**, and the task duration summary (min / median / max) |
| **Stage detail → Summary metrics** | if max ≫ median (e.g. 9 min vs 10 s) → **skew** |
| **Storage** | cached RDDs/DataFrames, fraction in memory |
| **Executors** | GC time (> 10% of task time = memory pressure), failed tasks, shuffle totals |
| **SQL / DataFrame** | the physical plan as a graph: scans, exchanges (shuffles), join types, AQE changes |
| **Environment** | effective configs (verify your `--conf` actually applied) |

On EMR: Spark History Server at port 18080, or the persistent application UI in the console. On EMR
Serverless / Glue: the Spark UI link in the console (Glue needs event logs enabled).

**Waves:** 1,000 tasks on 10 executors × 4 cores = 40 slots → 25 waves. If each task takes 30 s, the stage
takes ≈ 12.5 min. Going to 80 slots halves it, as long as the tasks don't get I/O-bound.

## 7. groupByKey vs reduceByKey

```mermaid
flowchart TB
  subgraph G["groupByKey — ship every value"]
    GA["P1: (Pune,10)(Pune,20)(Delhi,5)"] -->|3 records| GS[shuffle]
    GB["P2: (Pune,30)(Delhi,7)"] -->|2 records| GS
    GS --> GR["Pune: [10,20,30] → sum<br/>Delhi: [5,7] → sum"]
  end
  subgraph R["reduceByKey — combine first"]
    RA["P1: (Pune,10)(Pune,20)(Delhi,5)"] --> RC1["combine: (Pune,30)(Delhi,5)"] -->|2 records| RS[shuffle]
    RB["P2: (Pune,30)(Delhi,7)"] --> RC2["(Pune,30)(Delhi,7)"] -->|2 records| RS
    RS --> RR["Pune: 60, Delhi: 12"]
  end
```

**Worked numbers:** 10 M delivered orders, 6 cities, 80 partitions.
- `groupByKey`: shuffles **10 M** records; one reducer per city gets millions of values held in memory as a
  list (OOM risk, and only 6 non-empty partitions → 6 busy tasks).
- `reduceByKey`: each partition emits ≤ 6 records → **480** records shuffled.

```python
# bad
pairs.groupByKey().mapValues(sum)
# good
pairs.reduceByKey(lambda a, b: a + b)
```

Use `groupByKey` only when you truly need **all** values together and they can't be combined (e.g. building
a per-user session list, with a bounded list size). DataFrame `groupBy().agg()` automatically does partial
(map-side) aggregation: the plan shows `HashAggregate(partial) → Exchange → HashAggregate(final)`.

## 8. Changing the number of partitions: repartition vs coalesce

| | `repartition(n)` / `repartition(n, col)` | `coalesce(n)` |
|---|---|---|
| Shuffle | **yes**, full | **no** (narrow): merges existing partitions on the same executor |
| Direction | increase or decrease | decrease only (unless `shuffle=True` on RDDs) |
| Output balance | even (round-robin) or by hash of column | can be uneven (merges neighbors) |
| Cost | network + disk | cheap |
| Use | fix skewed/too few partitions, co-locate by key before writes/joins | reduce the number of output files after a filter |

**The coalesce trap:** coalesce is narrow, so it's pipelined into the **upstream** stage.
`df.filter(...).coalesce(1).write...` runs the **entire** filter stage with **1 task**, not just the
write. If upstream work is heavy, use `repartition(1)` (shuffle, so upstream stays parallel), or better,
don't write a single file.

```python
df = spark.read.csv(f"s3://{BUCKET}/raw/orders/", header=True)
print(df.rdd.getNumPartitions())            # e.g. 20

df.repartition(64).rdd.getNumPartitions()   # 64, full shuffle
df.repartition("city").write.partitionBy("city").parquet(out)  # one file per city partition dir
df.coalesce(4).write.parquet(out2)          # 4 files, no shuffle
```

### How many partitions should I have?

- Target **100–200 MB per partition** in memory (shuffle partitions), and **2–4 tasks per core** for balance.
- Output files: **128 MB–1 GB** each.
- Example: 300 GB shuffle → 300,000 MB / 200 MB ≈ **1,500** shuffle partitions (not 200). Or turn on AQE with
  `advisoryPartitionSizeInBytes` and a high initial number, and let Spark coalesce.

## 9. Higher-level APIs — DataFrames and Spark tables (bridge to module 10)

```python
from pyspark.sql import functions as F
orders = (spark.read.option("header", True).option("inferSchema", True)
              .csv(f"s3://{BUCKET}/raw/orders/"))
(orders.where("status = 'delivered'")
       .groupBy("city").agg(F.sum("amount").alias("revenue"))
       .orderBy(F.desc("revenue")).show())

orders.createOrReplaceTempView("orders")
spark.sql("SELECT city, sum(amount) revenue FROM orders WHERE status='delivered' GROUP BY city").show()
```

Same result as the RDD version, but Catalyst prunes columns, pushes down filters, and uses partial aggregation for you.

## Key takeaways

- RDD = partitions + compute function + dependencies + optional partitioner + preferred locations.
- Partition count comes from input splits (`maxPartitionBytes` = 128 MB, `openCostInBytes` = 4 MB) or shuffle settings (200 by default for SQL).
- Stage boundaries are shuffles; tasks = partitions; stage time ≈ waves × task time; max ≫ median task time means skew.
- `reduceByKey`/`aggregateByKey` combine map-side; `groupByKey` ships every value.
- `repartition` = shuffle and balanced; `coalesce` = no shuffle, but it collapses upstream parallelism.

## Interview scenarios

1. *Fixing a slow `groupByKey` job:* the UI shows shuffle write of 400 GB and a few tasks spilling 50 GB.
   Replace with `reduceByKey`/`aggregateByKey` (or DataFrame `groupBy().agg`), check key skew, and raise
   shuffle partitions if partitions are > 1 GB.
2. *Why does my job read a 20 GB file with one task?* — it's a single gzip file (not splittable). Re-compress
   as splittable (or repartition right after reading, accepting one slow read), and fix it at the source:
   write Parquet/Snappy.
3. *`coalesce(1)` made a 10-minute job take 2 hours. Why?* — coalesce is narrow and merged into the upstream
   stage, so everything ran in one task. Use `repartition(1)`, or write multiple files.
4. *How many tasks and stages: read 40 partitions → filter → `groupBy(city).agg` (shuffle partitions 200, AQE off) → write?*
   — 2 stages: 40 tasks (scan + partial agg) and 200 tasks (final agg + write). With AQE on, the second stage
   might be coalesced to a handful of tasks.
