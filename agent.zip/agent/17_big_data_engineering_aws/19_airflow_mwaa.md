# 19 — Apache Airflow & Amazon MWAA

> **Why it matters:** a data platform is dozens of dependent jobs: ingest → validate → transform →
> aggregate → publish, each with retries, schedules, backfills, and alerts. Cron can't express
> dependencies or retries, and it can't tell you what failed. Airflow is the standard orchestrator.
> On AWS it's **Amazon MWAA** (Managed Workflows for Apache Airflow), which replaces Astro Cloud /
> Cloud Composer in the original course.

## In plain words

Airflow is a **project manager with a Gantt chart that executes itself**. You write the plan as Python
(a DAG: tasks and arrows between them). Every day the manager checks the calendar, creates that day's run,
starts each task when its prerequisites are done, retries failures, and shows a colored grid of what
succeeded or failed. The manager doesn't do the heavy lifting: tasks *tell* Spark/EMR/Athena/Glue to do the
work and wait for the result.

## Architecture at a glance — Airflow 3

```mermaid
flowchart TB
  DEV[DAG files in git → deployed to<br/>dags folder / S3 bucket on MWAA]
  subgraph CP["Airflow control plane"]
    DP[DAG processor<br/>parses DAG files →<br/>serialized DAGs in DB]
    SCH[Scheduler<br/>creates DAG runs,<br/>decides ready tasks,<br/>hands them to the executor]
    API[API server<br/>UI + REST API +<br/>Task Execution API]
    TRG[Triggerer<br/>async waits for<br/>deferrable tasks]
    DB[(Metadata DB<br/>Postgres: runs, task<br/>states, XComs, connections)]
  end
  EXE[Executor<br/>Local / Celery / Kubernetes / ECS]
  subgraph WK["Workers"]
    W1[task process<br/>Task SDK]
    W2[task process]
  end
  EXT[(External systems:<br/>EMR, Glue, Athena,<br/>Redshift, S3, APIs)]
  DEV --> DP --> DB
  SCH <--> DB
  API <--> DB
  TRG <--> DB
  SCH --> EXE --> W1 & W2
  W1 & W2 <-->|state, XCom, connections<br/>via Task Execution API| API
  W1 & W2 -->|submit + poll| EXT
```

**How to read it:** the DAG processor parses your Python files into serialized DAGs. The scheduler creates runs
and queues ready tasks to the executor, which runs them on workers. In **Airflow 3**, workers no longer talk to
the metadata DB directly. They go through the API server's Task Execution API (better security and isolation).
The **triggerer** handles deferred tasks (e.g. "wait for this EMR job") asynchronously, so they don't occupy worker slots.

## 1. Why Airflow for big data and MLOps

| Need | Airflow feature |
|---|---|
| Dependencies across systems | DAGs; 1,000+ provider operators (AWS, Databricks, Snowflake, dbt, Kafka...) |
| Retries, timeouts, alerting | per-task `retries`, `retry_delay`, `execution_timeout`, `on_failure_callback` |
| Reprocessing history | backfills over logical dates; idempotent tasks keyed by `ds` |
| Data-driven triggers | **Assets** (formerly Datasets): run DAG B when DAG A updates `s3://.../orders` |
| Visibility | grid/graph views, logs per try, run history |
| Code-defined, reviewable | DAGs are Python in git → CI tests |
| MLOps | feature → train → evaluate → register → deploy pipelines with gates |

What Airflow is **not**: a data-processing engine (don't move GBs through tasks or XCom), or a streaming system.

### Airflow 2 → Airflow 3: what changed (read before following older tutorials)

Airflow 3.0 (April 2025) changed the architecture and some APIs. Older videos and blog posts use Airflow 2 syntax.

| Area | Airflow 2 | Airflow 3 |
|---|---|---|
| UI / API process | `webserver` (Flask) | **`api-server`** (FastAPI) serving the new React UI, REST API, and Task Execution API |
| DAG parsing | inside the scheduler (optional standalone) | **separate `dag-processor`**, mandatory |
| Task ↔ metadata DB | tasks query the DB directly | tasks talk to the API server through the **Task SDK** (no direct DB access from workers) |
| DAG authoring imports | `from airflow import DAG`, `from airflow.decorators import dag, task` | **`from airflow.sdk import DAG, dag, task`** |
| Core operators | `airflow.operators.bash/python` | moved to the **standard provider**: `airflow.providers.standard.operators.*` |
| Data-aware scheduling | Datasets | renamed **Assets** (`from airflow.sdk import Asset`) |
| `catchup` default | True | **False** |
| `execution_date` | context variable | removed: use **`logical_date`** / `data_interval_start` |
| `schedule_interval` | deprecated alias | removed: use **`schedule`** |
| SubDAGs, SLAs | available | **removed** (use task groups; deadline alerts replace SLAs in later 3.x) |
| `SimpleHttpOperator` | http provider | renamed **`HttpOperator`** |
| Backfills | CLI-only, run by the CLI process | managed by the **scheduler**, launched from UI/API/CLI |
| DAG versioning | latest code only | runs remember the DAG version they started with |

Astro Runtime images and the `astro dev` CLI default to Airflow 3. On MWAA, pick the Airflow version when you
create the environment, and write DAGs for that version.

## 2. Key components and concepts

| Concept | Meaning |
|---|---|
| **DAG** | directed acyclic graph of tasks + schedule + defaults |
| **Task / Operator** | a unit of work; operators are templates (`BashOperator`, `EmrServerlessStartJobOperator`) |
| **Sensor** | waits for a condition (`S3KeySensor`); prefer `deferrable=True` |
| **Hook** | Python client for a system using a Connection (`S3Hook`, `PostgresHook`) |
| **Connection** | credentials + endpoint by id (`aws_default`, `postgres_dwh`), stored in DB or a secrets backend |
| **Variable** | global key/value config |
| **XCom** | small messages between tasks (IDs, paths, counts, never datasets) |
| **TaskFlow API** | `@task` decorated functions; return values become XComs automatically |
| **Logical date** (`ds`) | the date the run *represents*. A daily run for 2025-03-01 executes after that interval ends |
| **Data interval** | `[data_interval_start, data_interval_end)`, the window this run processes |
| **Catchup** | create runs for past intervals since `start_date` (default **False** in Airflow 3) |
| **Backfill** | explicitly run a historical date range (scheduler-managed in Airflow 3: UI/CLI/API) |
| **Trigger rules** | `all_success` (default), `all_done`, `one_failed`, `none_failed_min_one_success`... |
| **Pools / max_active_runs / max_active_tasks** | concurrency control (protect databases and APIs) |
| **Dynamic task mapping** | `.expand()` to create N task instances at runtime (one per file/table) |

### Scheduling semantics (the #1 confusion)

```
 schedule="@daily", start_date=2025-03-01
 Run with logical date 2025-03-01 covers [2025-03-01 00:00, 2025-03-02 00:00)
 and STARTS at 2025-03-02 00:00 — after the data for the 1st is complete.
```

## 3. Setting up Airflow locally with the Astro CLI

```bash
brew install astro                 # or curl -sSL install.astronomer.io | sudo bash
mkdir airflow-course && cd airflow-course
astro dev init                     # dags/, include/, plugins/, requirements.txt, Dockerfile (Astro Runtime = Airflow 3)
astro dev start                    # docker compose: api-server, scheduler, dag-processor, triggerer, postgres
# UI → http://localhost:8080
astro dev run dags list
astro dev pytest                   # DAG import tests
```

Alternatives: the official `docker-compose.yaml` from the Airflow docs, `pip install apache-airflow` +
`airflow standalone`, or the **MWAA local runner** (`aws-mwaa-docker-images`) to mirror MWAA exactly.

## 4. Your first DAGs

### Classic operators

```python
# dags/hello_classic.py
from datetime import datetime, timedelta
from airflow.sdk import DAG
from airflow.providers.standard.operators.bash import BashOperator
from airflow.providers.standard.operators.python import PythonOperator

def greet(name: str, **context):
    print(f"Hello {name}, processing {context['ds']}")

with DAG(
    dag_id="hello_classic",
    start_date=datetime(2025, 1, 1),
    schedule="@daily",
    catchup=False,
    default_args={"retries": 2, "retry_delay": timedelta(minutes=5)},
    tags=["course"],
) as dag:
    start = BashOperator(task_id="start", bash_command="echo run for {{ ds }}")
    hello = PythonOperator(task_id="hello", python_callable=greet, op_kwargs={"name": "data team"})
    done = BashOperator(task_id="done", bash_command="echo done")
    start >> hello >> done
```

### Mathematical calculation DAG with XCom (classic style)

```python
# dags/math_classic.py — start=10 → +5 → ×2 → −3 → square
from datetime import datetime
from airflow.sdk import DAG
from airflow.providers.standard.operators.python import PythonOperator

def start_number(ti):
    ti.xcom_push(key="value", value=10)

def make_step(fn, upstream):
    def _step(ti):
        v = ti.xcom_pull(task_ids=upstream, key="value")
        ti.xcom_push(key="value", value=fn(v))
        print(f"{upstream}: {v} -> {fn(v)}")
    return _step

with DAG("math_classic", start_date=datetime(2025, 1, 1), schedule=None, catchup=False) as dag:
    t0 = PythonOperator(task_id="start", python_callable=start_number)
    t1 = PythonOperator(task_id="add_5", python_callable=make_step(lambda v: v + 5, "start"))
    t2 = PythonOperator(task_id="mul_2", python_callable=make_step(lambda v: v * 2, "add_5"))
    t3 = PythonOperator(task_id="sub_3", python_callable=make_step(lambda v: v - 3, "mul_2"))
    t4 = PythonOperator(task_id="square", python_callable=make_step(lambda v: v ** 2, "sub_3"))
    t0 >> t1 >> t2 >> t3 >> t4        # ((10+5)*2-3)^2 = 729
```

### The same with the TaskFlow API

```python
# dags/math_taskflow.py
from datetime import datetime
from airflow.sdk import dag, task

@dag(start_date=datetime(2025, 1, 1), schedule=None, catchup=False, tags=["course"])
def math_taskflow():
    @task
    def start() -> int: return 10
    @task
    def add(v: int, n: int) -> int: return v + n
    @task
    def mul(v: int, n: int) -> int: return v * n
    @task
    def square(v: int) -> int:
        print(f"result={v ** 2}")
        return v ** 2

    square(add(mul(add(start(), 5), 2), -3))   # dependencies inferred from data flow

math_taskflow()
```

TaskFlow removes the explicit `xcom_push/pull` and `>>` boilerplate. Return values are XComs, and passing
them as arguments creates the dependency.

## 5. Designing production DAGs — rules

1. **Idempotent tasks:** rerunning a task for `ds` gives the same result (overwrite the `dt={{ ds }}` partition, MERGE, never blind append).
2. **Atomic tasks:** one task = one logical step that fully succeeds or fails.
3. **Airflow orchestrates, engines compute:** submit Spark to EMR Serverless, SQL to Athena/Redshift. Don't process data inside the worker.
4. **Small XComs only:** S3 paths, job IDs, row counts. The default XCom backend stores values in the metadata DB.
5. **No heavy top-level code:** DAG files are parsed every ~30 s; no API calls or DB queries at import time.
6. **Deferrable operators/sensors** for long waits (`deferrable=True`), so waiting doesn't occupy worker slots.
7. **Use the data interval**, not `datetime.now()`: `{{ data_interval_start }}`, `{{ ds }}`.
8. **Secrets in a secrets backend** (AWS Secrets Manager on MWAA), never in code.
9. **Tests in CI:** DAG import test (no import errors, no cycles), unit tests for callables.

## 6. Amazon MWAA

```mermaid
flowchart LR
  GIT[git repo] -->|CI: aws s3 sync| S3[(S3 bucket<br/>dags/<br/>requirements.txt<br/>plugins.zip<br/>startup.sh)]
  subgraph MWAA["MWAA environment (AWS-managed account)"]
    WEB[Web server / API server]
    SCHED[Schedulers x2+]
    WRK[Celery workers<br/>auto-scale min..max]
    MDB[(Metadata DB<br/>managed)]
    Q[[SQS queue]]
  end
  S3 --> MWAA
  SCHED --> Q --> WRK
  WRK -->|ENIs in YOUR<br/>private subnets| VPC[Your VPC:<br/>RDS, EMR, MSK, Redshift]
  WRK --> AWS[AWS APIs: EMR Serverless,<br/>Glue, Athena, S3]
  MWAA --> CW[CloudWatch Logs + metrics]
  SM[Secrets Manager<br/>connections + variables] -.-> WRK
```

| Aspect | Detail |
|---|---|
| Deploy code | upload to the S3 `dags/` prefix (synced to workers within ~a minute); `requirements.txt` and `plugins.zip` changes trigger an environment update |
| Networking | needs a VPC with **2 private subnets** (NAT or VPC endpoints for AWS APIs); UI access public or private |
| Sizing | environment class (`mw1.micro` … `mw1.2xlarge`) sets scheduler/worker capacity; `min/max workers` for Celery autoscaling |
| Identity | **execution role** = permissions your tasks get (EMR, Glue, Athena, S3, Secrets Manager) |
| Secrets | `secrets.backend = airflow.providers.amazon.aws.secrets.secrets_manager.SecretsManagerBackend` |
| Versions | multiple Airflow 2.x and 3.x versions offered; check `aws mwaa` / console for current ones |
| Cost | billed per environment-hour by class + extra workers/schedulers + metadata storage: a running dev environment costs money even when idle; delete after labs |

```bash
aws s3 sync dags/ s3://$MWAA_BUCKET/dags/
aws mwaa create-environment --name bigdata-mwaa \
  --airflow-version <supported-version> \
  --source-bucket-arn arn:aws:s3:::$MWAA_BUCKET --dag-s3-path dags \
  --requirements-s3-path requirements.txt \
  --execution-role-arn arn:aws:iam::$ACCOUNT_ID:role/mwaa-exec \
  --network-configuration SubnetIds=subnet-priv-a,subnet-priv-b,SecurityGroupIds=sg-mwaa \
  --environment-class mw1.small --max-workers 5 \
  --webserver-access-mode PUBLIC_ONLY \
  --airflow-configuration-options '{"secrets.backend":"airflow.providers.amazon.aws.secrets.secrets_manager.SecretsManagerBackend","secrets.backend_kwargs":"{\"connections_prefix\":\"airflow/connections\",\"variables_prefix\":\"airflow/variables\"}"}'
aws mwaa create-web-login-token --name bigdata-mwaa      # or open the UI from the console
```

### Orchestrating the module 15 Spark project on MWAA

```python
# dags/olist_pipeline.py
from datetime import datetime, timedelta
from airflow.sdk import dag, task
from airflow.providers.amazon.aws.operators.emr import EmrServerlessStartJobOperator
from airflow.providers.amazon.aws.operators.athena import AthenaOperator
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor

BUCKET, APP_ID = "bigdata-course-123", "00abc123xyz"
ROLE = "arn:aws:iam::123456789012:role/EMRServerlessJobRole"

def spark_job(name):
    return EmrServerlessStartJobOperator(
        task_id=name, application_id=APP_ID, execution_role_arn=ROLE,
        job_driver={"sparkSubmit": {
            "entryPoint": f"s3://{BUCKET}/code/olist/{name}.py",
            "entryPointArguments": [BUCKET, "{{ ds }}"]}},
        configuration_overrides={"monitoringConfiguration": {
            "s3MonitoringConfiguration": {"logUri": f"s3://{BUCKET}/emr-serverless-logs/"}}},
        deferrable=True)

@dag(start_date=datetime(2025, 1, 1), schedule="0 2 * * *", catchup=False, max_active_runs=1,
     default_args={"retries": 2, "retry_delay": timedelta(minutes=10)}, tags=["olist"])
def olist_pipeline():
    landed = S3KeySensor(task_id="wait_for_raw", bucket_name=BUCKET,
                         bucket_key="bronze/olist/{{ ds }}/_SUCCESS",
                         deferrable=True, timeout=6 * 3600)
    silver = spark_job("01_bronze_to_silver")
    gold = spark_job("02_silver_to_gold")
    check = AthenaOperator(task_id="dq_check", database="olist_gold", workgroup="olist",
        query="SELECT count(*) FROM fact_orders WHERE purchase_month = '{{ macros.ds_format(ds, '%Y-%m-%d', '%Y-%m') }}'",
        output_location=f"s3://{BUCKET}/athena-results/")

    @task
    def notify(**context):
        print(f"olist pipeline done for {context['ds']}")   # Slack/SNS in real life

    landed >> silver >> gold >> check >> notify()

olist_pipeline()
```

## 7. "Why isn't my DAG running?" — checklist

| Symptom | Cause | Fix |
|---|---|---|
| DAG not in UI | import error (see "DAG import errors" banner / DAG processor logs), file not in `dags/`, `.airflowignore`, duplicate `dag_id` | fix error; `airflow dags list-import-errors` |
| In UI, never runs | **paused** (new DAGs are paused by default: `dags_are_paused_at_creation`) | unpause |
| Unpaused, no runs | `start_date` in the future, or the first interval hasn't **ended** yet | understand data intervals; trigger manually |
| `schedule=None` | only manual/asset-triggered runs | set a schedule |
| Runs stuck in queued | executor/workers down, pool full, `max_active_runs`/`max_active_tasks` hit, MWAA at max workers | check pools, concurrency, worker health |
| Tasks "up_for_retry" forever | retries with long delay | inspect logs per attempt |
| Downstream skipped | upstream failed/skipped with `all_success` trigger rule | adjust trigger rule |
| Waiting on previous day | `depends_on_past=True` and yesterday failed | fix or clear yesterday |
| Wrong time | schedule in UTC; DAG timezone not set | use `pendulum` timezone-aware `start_date` |

## Key takeaways

- Airflow 3: DAG processor + scheduler + API server (incl. Task Execution API) + triggerer + executor/workers + metadata DB.
- A run's logical date marks the *start* of its data interval; it executes after the interval ends.
- TaskFlow (`@dag`, `@task`) makes XCom and dependencies implicit; keep XComs tiny.
- Production rules: idempotent, atomic, orchestrate-don't-compute, deferrable waits, secrets backend, CI tests.
- MWAA = managed Airflow: DAGs from S3, workers in your VPC, execution role for AWS access, Secrets Manager integration.

## Interview scenarios

1. *Why isn't my DAG running?* — walk the checklist: import errors → paused → start_date/interval → schedule →
   concurrency/pools → executor health.
2. *Design an Airflow DAG for a daily pipeline with failure handling.* — sensor (deferrable) for input → Spark on EMR
   Serverless (deferrable, retries with backoff, `execution_timeout`) → data quality task that fails on thresholds →
   publish → notify; `on_failure_callback` to SNS/Slack; idempotent writes keyed by `ds`; `max_active_runs=1` if days must be ordered.
3. *Someone passes a 300 MB DataFrame via XCom.* — XComs live in the metadata DB. Write to S3 and pass the path
   (or configure an object-storage XCom backend).
4. *Catchup vs backfill?* — catchup automatically creates missed runs since `start_date` when the DAG is enabled; a
   backfill is an explicit request to run a historical range.
