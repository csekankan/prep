# 05 — MapReduce Deep Dive

> **Why it matters:** MapReduce is the original programming model for distributed batch processing.
> Spark's "stages separated by shuffles" is MapReduce generalized. If you understand
> map → spill → shuffle → sort → reduce, you understand why `groupByKey` is slow, why combiners help,
> why skew hurts, and what a Spark stage boundary really is.

## In plain words

Counting the votes in a national election:

1. **Map:** every polling booth counts its own ballots locally and writes `(candidate, count)` slips.
2. **Combine:** each booth adds up its own slips first ("Alice: 412") instead of sending 412 slips saying "Alice: 1".
3. **Shuffle:** all slips for Alice go to counting center A, all slips for Bob go to center B (a partitioner decides who goes where).
4. **Sort/group:** each center sorts slips by candidate.
5. **Reduce:** each center adds the numbers and announces the final total.

The booths work in parallel. The expensive part is shipping slips between cities (the network shuffle).

## Architecture at a glance

```mermaid
flowchart LR
  subgraph IN["Input on HDFS / S3"]
    B1[Split 1<br/>~block 1]
    B2[Split 2]
    B3[Split 3]
  end
  subgraph MAP["Map phase (one task per split)"]
    M1[Mapper 1<br/>+ combiner]
    M2[Mapper 2<br/>+ combiner]
    M3[Mapper 3<br/>+ combiner]
  end
  subgraph SH["Shuffle: partition, sort, spill, merge, fetch over network"]
    P0((partition 0))
    P1((partition 1))
  end
  subgraph RED["Reduce phase (R tasks)"]
    R0[Reducer 0]
    R1[Reducer 1]
  end
  OUT[(Output<br/>part-r-00000<br/>part-r-00001)]
  B1 --> M1
  B2 --> M2
  B3 --> M3
  M1 --> P0 & P1
  M2 --> P0 & P1
  M3 --> P0 & P1
  P0 --> R0
  P1 --> R1
  R0 --> OUT
  R1 --> OUT
```

**How to read it:** one mapper per input split, ideally running on the node holding that block. Every
mapper's output is split into R partitions (one per reducer). Every reducer pulls its partition from
**every** mapper (an M × R all-to-all transfer). That network step is the shuffle.

## 1. Intro to distributed processing

Two ways to process 10 TB:

| | Move data to code | Move code to data |
|---|---|---|
| How | central server pulls everything over the network | ship a small program (KBs) to every node holding blocks |
| Bottleneck | central NIC: 10 TB / 10 Gbps ≈ 2.2 h just to transfer | each node reads local disks in parallel |
| Used by | traditional ETL servers | MapReduce, Spark on HDFS |

MapReduce's contract: you write **two pure functions** and the framework handles partitioning,
scheduling, locality, retries, and the shuffle.

$$
\text{map}: (k_1, v_1) \rightarrow \text{list}(k_2, v_2) \qquad
\text{reduce}: (k_2, \text{list}(v_2)) \rightarrow \text{list}(k_3, v_3)
$$

**Read it as:** map turns each input record into zero or more key-value pairs; the framework groups all
values by key; reduce turns each key and its list of values into output records.

## 2. The phases in detail

### 2.1 Input format and input splits

- **InputFormat** decides how to cut input into **splits** and how to turn a split into records
  (`TextInputFormat`: key = byte offset, value = line).
- **Split** = logical chunk of work; **block** = physical chunk of storage. By default split size = block size:

$$
\text{splitSize} = \max(\text{minSize}, \min(\text{maxSize}, \text{blockSize}))
$$

- **Records crossing block boundaries:** a line can start in block 1 and end in block 2. The reader for
  split 1 reads past its end to finish the line; the reader for split 2 skips the partial first line.
  This is why splits are logical.
- **Non-splittable compression:** a 10 GB `.gz` file = **1 split = 1 mapper** (gzip can't be read from the
  middle). Use bzip2 (splittable, slow), or better: splittable container formats (Parquet, ORC, Avro,
  SequenceFile) with Snappy/ZSTD inside.

**Number of mappers = number of splits.** 10 GB uncompressed at 128 MB → 80 mappers.

### 2.2 Map and the spill

```
 mapper emits (k,v) ─► partition = hash(k) mod R ─► in-memory circular buffer (100 MB)
                                                         │ at 80% full
                                                         ▼
                                     sort by (partition, key) ─► [combiner] ─► spill file on local disk
                                                         │ map finishes
                                                         ▼
                                     merge all spill files into ONE sorted, partitioned file + index
```

| Setting | Default | Meaning |
|---|---|---|
| `mapreduce.task.io.sort.mb` | 100 MB | buffer size |
| `mapreduce.map.sort.spill.percent` | 0.80 | spill threshold |
| `mapreduce.task.io.sort.factor` | 10 | streams merged at once |
| `mapreduce.map.output.compress` | false | compress map output (turn on: Snappy/LZ4 — shuffle is network-bound) |

Map output goes to **local disk**, not HDFS, because it's temporary and replication would be wasted work.

### 2.3 Shuffle and sort (reduce side)

1. Reducer's fetcher threads pull its partition from every completed mapper over HTTP
   (`mapreduce.reduce.shuffle.parallelcopies`, default 5).
2. Fetched segments are merged in memory/disk (merge sort).
3. Reducer receives keys **in sorted order** with an iterator over all values for each key.

Reducers can start fetching when 5% of maps finish (`mapreduce.job.reduce.slowstart.completedmaps` = 0.05),
but `reduce()` can't run until **all** maps are done: any map could still emit a value for any key.

### 2.4 Partitioner

Default: `HashPartitioner` → `(key.hashCode() & Integer.MAX_VALUE) % numReducers`. Custom partitioners
are useful for:
- **Total order sort** (range partitioning using sampled boundaries, so output files are globally sorted).
- Routing (e.g., all events for a country to one file).

### 2.5 Combiner — the "mini reducer"

Runs on map output (after sort, during spill/merge) to shrink data before the shuffle.

**Rule:** only valid if the operation is **associative and commutative** and the combiner's input/output
types match the map output types. The framework may run it 0, 1, or many times.

| Operation | Combiner OK? | Why |
|---|---|---|
| sum, count, max, min | ✅ | \( \text{sum}(\text{sum}(a,b), c) = \text{sum}(a,b,c) \) |
| average | ❌ directly | avg of averages ≠ overall average. ✅ if you emit `(sum, count)` pairs and divide in the reducer |
| median, distinct count (exact) | ❌ | needs all values |

**Worked example — impact of a combiner:** word count over 10 GB of text, ~1.5 B words, 50 k distinct
words, 80 mappers.

- Without combiner: shuffle ~1.5 B `(word, 1)` pairs ≈ 1.5 B × ~12 bytes ≈ **18 GB** over the network.
- With combiner: each mapper emits at most ~50 k pairs → 80 × 50 k = 4 M pairs ≈ **48 MB**.

That's a ~375× smaller shuffle. Spark's `reduceByKey` does exactly this automatically (module 09).

### 2.6 Number of reducers

- Default 1 (`mapreduce.job.reduces`) → a single bottleneck and one output file.
- Classic guidance: `0.95 × (nodes × max containers per node)` so all reducers run in one wave, or `1.75 ×`
  for two waves with better load balancing.
- Practical: aim for **reducer input ≈ 1–2 GB each** (or 128 MB–1 GB output files).

| Reducers | Effect |
|---|---|
| 0 | **map-only job**: no shuffle, no sort; mapper output written straight to HDFS (`part-m-xxxxx`). Use for filtering, format conversion, row-level parsing |
| 1 | global aggregation or total ordering; slow if data is big |
| many | parallel reduce; output = one file per reducer |

## 3. Data locality and speculative execution

Scheduler preference: **node-local** (block on same node) → **rack-local** → **off-rack**.

**Speculative execution:** if a task runs much slower than its peers (a "straggler" caused by a bad disk
or noisy neighbor), launch a duplicate on another node; the first to finish wins, the other is killed.
It helps with hardware stragglers but **not with data skew**: a duplicate of a skewed task is just as slow.

## 4. Fault tolerance

| Failure | Handling |
|---|---|
| Map task fails | retried up to `mapreduce.map.maxattempts` = 4 on another node |
| Reduce task fails | retried; re-fetches map outputs |
| Node dies after its maps finished | maps **re-run**, because their output lived on that node's local disk |
| ApplicationMaster fails | YARN restarts it (`mapreduce.am.max-attempts` = 2); can recover completed tasks |
| Whole job fails | rerun; output dir must not exist (prevents accidental overwrite) |

## 5. Practical: word count with Hadoop Streaming (Python) on EMR

Hadoop Streaming lets any executable act as mapper/reducer via stdin/stdout. Lines are `key\tvalue`, and
the reducer receives them **sorted by key**.

```python
# mapper.py
import sys, re

for line in sys.stdin:
    for word in re.findall(r"[a-z']+", line.lower()):
        print(f"{word}\t1")
```

```python
# reducer.py — input arrives grouped and sorted by key
import sys

current, total = None, 0
for line in sys.stdin:
    word, count = line.rstrip("\n").split("\t", 1)
    if word != current:
        if current is not None:
            print(f"{current}\t{total}")
        current, total = word, 0
    total += int(count)
if current is not None:
    print(f"{current}\t{total}")
```

Test locally with a Unix pipe that simulates map → shuffle/sort → reduce:

```bash
cat book.txt | python3 mapper.py | sort -k1,1 | python3 reducer.py | sort -k2,2nr | head
```

Run on the EMR cluster (module 04):

```bash
aws s3 cp mapper.py s3://$BUCKET/code/ && aws s3 cp reducer.py s3://$BUCKET/code/
aws emr add-steps --cluster-id $CLUSTER_ID --steps '[{
  "Type":"STREAMING","Name":"wordcount-2-reducers","ActionOnFailure":"CONTINUE",
  "Args":["-files","s3://'$BUCKET'/code/mapper.py,s3://'$BUCKET'/code/reducer.py",
          "-D","mapreduce.job.reduces=2",
          "-mapper","python3 mapper.py",
          "-combiner","python3 reducer.py",
          "-reducer","python3 reducer.py",
          "-input","s3://'$BUCKET'/raw/books/",
          "-output","s3://'$BUCKET'/curated/wordcount/run1/"]}]'
```

The reducer doubles as the combiner here because summing is associative and its input/output formats match.

Experiments to run and observe in the YARN UI / job counters:

| Experiment | What to observe |
|---|---|
| `mapreduce.job.reduces=1` | one `part-00000`; reduce phase is a single long task |
| `=2` | two output files; words split by hash |
| `=0` (drop `-reducer`) | `part-m-*` files containing raw `(word,1)` per mapper, unsorted across files |
| with / without `-combiner` | counters: `Map output records` vs `Combine output records`, `Reduce shuffle bytes` |
| big log file, `.gz` vs uncompressed | `.gz` → 1 mapper; uncompressed → N mappers |

### Log-file analytics example (status codes per hour)

```python
# mapper_logs.py — Apache combined log → key "2026-11-12T09|404", value 1
import sys, re
pat = re.compile(r'\[(\d{2})/(\w{3})/(\d{4}):(\d{2}):\d{2}:\d{2}[^\]]*\] "[^"]*" (\d{3})')
for line in sys.stdin:
    m = pat.search(line)
    if m:
        d, mon, y, h, status = m.groups()
        print(f"{y}-{mon}-{d}T{h}|{status}\t1")
```

Same reducer. Malformed lines are skipped. In production, also emit a counter so you know how many lines were dropped:
`sys.stderr.write("reporter:counter:logs,malformed,1\n")`.

## 6. Limitations of MapReduce (why Spark won)

| Limitation | Consequence |
|---|---|
| Every job writes output to HDFS (replicated) and the next job reads it back | iterative algorithms (ML, graph) do 10–100 full disk round trips |
| Only map and reduce | joins, multi-step pipelines need chains of jobs + glue code |
| JVM startup per task | high latency even for small jobs |
| Batch only | no interactive queries, no streaming |
| Verbose Java API | low productivity |

Spark keeps intermediate data in memory and plans a whole DAG of stages, so it's typically 10–100× faster for
iterative work (module 08).

## Key takeaways

- Splits (logical) ≈ blocks (physical); #mappers = #splits; gzip files aren't splittable.
- Map output is partitioned by `hash(key) mod R`, sorted, spilled to local disk, then pulled by every reducer.
- Combiners shrink the shuffle massively but must be associative and commutative.
- 0 reducers = map-only job with no shuffle; reducer count controls parallelism and output file count.
- Speculative execution fixes slow hardware, not data skew.

## Interview scenarios

1. *A MapReduce job is slow: 799 reducers finish in 2 min, 1 takes 90 min. Cause and fix?* — key skew
   (one hot key such as `null` or a popular product). Add a combiner, salt the hot key
   (`key#rand(0..N)`, aggregate twice), filter/handle nulls separately, or use a custom partitioner.
2. *Why can't reduce start before all maps finish?* — any mapper may still produce values for any key, and
   reduce needs the full list per key. Shuffle copy can start early (slowstart); `reduce()` can't.
3. *Can you use a combiner to compute an average?* — not directly. Emit `(sum, count)` from map/combiner and
   compute `sum/count` in the reducer.
4. *Design: 2 TB of logs, compute daily unique users per country.* — map emits `(country|date, user)`;
   exact distinct needs grouping by key in the reducer (a combiner can dedupe locally with a set per key);
   partition on `country|date`; for approximate counts use HyperLogLog sketches, which are combinable.
5. *Debugging a slow job:* check counters (spilled records ≫ map output records → raise `io.sort.mb`),
   shuffle bytes (add combiner/compression), task time distribution (skew vs stragglers), number of maps
   (small files or a single gz).
