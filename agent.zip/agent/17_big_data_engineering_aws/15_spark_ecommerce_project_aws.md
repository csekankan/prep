# 15 — Spark E-commerce Project on AWS (S3 + EMR + Glue Catalog + Athena)

> **Why it matters:** this is the original course's Dataproc project rebuilt on AWS. You take a real
> e-commerce dataset (Olist, ~100k orders, 9 tables) through ingestion → exploration → cleaning →
> integration → window-function analytics → optimization → a serving layer that analysts query with
> SQL. The patterns are the same ones you'd use at 1,000× the scale.

## In plain words

Raw CSVs land in an S3 "inbox". A Spark job on EMR cleans them into tidy Parquet tables, joins them
into a single "order fact" view of the business, computes the metrics the business asked for
(revenue, delivery delays, customer lifetime value, seller rankings), and publishes small, fast
summary tables. Analysts query those with Athena like a database, without ever touching Spark.

## Architecture at a glance

```mermaid
flowchart LR
  K[Kaggle Olist<br/>9 CSV files] -->|aws s3 sync| BR
  subgraph S3["Amazon S3 lake"]
    BR[bronze/olist/<br/>raw CSV]
    SI[silver/olist/<br/>clean Parquet<br/>typed, deduped]
    GO[gold/olist/<br/>facts + aggregates<br/>partitioned Parquet]
  end
  subgraph EMR["EMR cluster (transient) or EMR Serverless"]
    J1[01_bronze_to_silver.py<br/>schema, clean, quality]
    J2[02_silver_to_gold.py<br/>join, window, aggregate]
  end
  CAT[(Glue Data Catalog<br/>olist_silver, olist_gold)]
  ATH[Athena<br/>workgroup with<br/>bytes-scanned limit]
  QS[QuickSight dashboard]
  BR --> J1 --> SI --> J2 --> GO
  J1 -.register tables.-> CAT
  J2 -.register tables.-> CAT
  GO --> ATH --> QS
  CAT --- ATH
```

**How to read it:** two Spark jobs, two layer transitions. Every table is registered in the Glue Data
Catalog, so Athena sees it right away. Compute is transient: the cluster exists only while the jobs run.

## 0. Warm-up project: customers + orders → actionable insights

Before the 9-table Olist project, the original course runs a small two-table exercise: **read data, process
customer data, then join customers with orders for insights**. The same three steps reappear in the Databricks
section, so this code runs unchanged on EMR, Glue, or Databricks.

```mermaid
flowchart LR
  C[(customers.csv<br/>id, name, city,<br/>signup_date)] --> R1[read with schema]
  O[(orders.csv<br/>order_id, customer_id,<br/>amount, status, order_date)] --> R2[read with schema]
  R1 --> P1[process customers:<br/>clean, dedupe,<br/>tenure, city counts]
  R2 --> P2[process orders:<br/>delivered only]
  P1 & P2 --> J[join on customer_id]
  J --> I1[top customers by spend]
  J --> I2[revenue + AOV per city]
  J --> I3[inactive customers<br/>no order in 90 days]
  J --> I4[monthly revenue trend]
```

```python
from pyspark.sql import functions as F, Window

customers = (spark.read.option("header", True)
    .schema("customer_id INT, name STRING, city STRING, signup_date DATE")
    .csv(f"s3://{BUCKET}/raw/warmup/customers.csv"))
orders = (spark.read.option("header", True)
    .schema("order_id STRING, customer_id INT, amount DECIMAL(10,2), status STRING, order_date DATE")
    .csv(f"s3://{BUCKET}/raw/warmup/orders.csv"))

# 1) Process customer data
customers = (customers.dropDuplicates(["customer_id"])
    .withColumn("city", F.initcap(F.trim("city")))
    .withColumn("tenure_days", F.datediff(F.current_date(), "signup_date")))
customers.groupBy("city").count().orderBy(F.desc("count")).show(5)

# 2) Customers + orders → insights
delivered = orders.where(F.lower("status") == "delivered")
cust_orders = customers.join(delivered, "customer_id", "left")

spend = cust_orders.groupBy("customer_id", "name", "city").agg(
    F.count("order_id").alias("orders"), F.coalesce(F.sum("amount"), F.lit(0)).alias("spend"),
    F.max("order_date").alias("last_order"))

top10 = spend.orderBy(F.desc("spend")).limit(10)                                    # insight 1
city_kpis = cust_orders.groupBy("city").agg(F.sum("amount").alias("revenue"),
    F.round(F.avg("amount"), 2).alias("aov"))                                         # insight 2
inactive = spend.where(F.col("last_order").isNull() |
                       (F.datediff(F.current_date(), "last_order") > 90))             # insight 3
monthly = (delivered.groupBy(F.date_trunc("month", "order_date").alias("month"))
    .agg(F.sum("amount").alias("revenue")).orderBy("month"))                          # insight 4
```

| Insight | Business action |
|---|---|
| Top 10 customers by spend | VIP program, account managers |
| Revenue and average order value (AOV) per city | where to focus marketing and logistics |
| Inactive for 90+ days (or never ordered) | win-back campaign |
| Monthly revenue trend | seasonality, forecasting |

Why `left` join: customers with no delivered orders must stay in the result, or they'd vanish from
"inactive customers", which is the most actionable list.

## 1. Anatomy of the dataset

```mermaid
erDiagram
  CUSTOMERS ||--o{ ORDERS : places
  ORDERS ||--|{ ORDER_ITEMS : contains
  ORDERS ||--o{ PAYMENTS : "paid by"
  ORDERS ||--o{ REVIEWS : "reviewed in"
  PRODUCTS ||--o{ ORDER_ITEMS : "sold as"
  SELLERS ||--o{ ORDER_ITEMS : fulfills
  CATEGORY_TRANSLATION ||--o{ PRODUCTS : names
  GEOLOCATION }o--o{ CUSTOMERS : "zip prefix"
  CUSTOMERS {
    string customer_id PK
    string customer_unique_id
    string customer_zip_code_prefix
    string customer_city
    string customer_state
  }
  ORDERS {
    string order_id PK
    string customer_id FK
    string order_status
    timestamp order_purchase_timestamp
    timestamp order_delivered_customer_date
    timestamp order_estimated_delivery_date
  }
  ORDER_ITEMS {
    string order_id FK
    int order_item_id
    string product_id FK
    string seller_id FK
    double price
    double freight_value
  }
  PAYMENTS {
    string order_id FK
    int payment_sequential
    string payment_type
    int payment_installments
    double payment_value
  }
```

Gotchas found during exploration (these drive the cleaning rules):

| Table | Gotcha |
|---|---|
| customers | `customer_id` is per-order; the real person is `customer_unique_id` (use it for CLV) |
| orders | delivered timestamps null for non-delivered statuses; a few delivered orders missing delivery dates |
| order_items | one row per item; an order with 3 items has 3 rows (aggregate before joining payments) |
| payments | multiple rows per order (vouchers + card); `payment_value` must be summed per order |
| reviews | duplicate `review_id`s; free-text with embedded newlines (needs `multiLine`) |
| products | misspelled columns (`product_name_lenght`); null categories |
| geolocation | ~1M rows, many per zip prefix: dedupe or aggregate to one lat/lng per prefix |

## 2. Data ingestion into S3 (replaces "ingestion into Dataproc")

```bash
pip install kaggle        # API token in ~/.kaggle/kaggle.json
kaggle datasets download -d olistbr/brazilian-ecommerce -p ./olist --unzip
aws s3 sync ./olist s3://$BUCKET/bronze/olist/ --exclude "*" --include "*.csv"
aws s3 ls s3://$BUCKET/bronze/olist/ --human-readable
aws glue create-database --database-input Name=olist_silver
aws glue create-database --database-input Name=olist_gold
```

## 3. Data exploration (run in an EMR Studio / Jupyter notebook)

```python
from pyspark.sql import functions as F
B = f"s3://{BUCKET}/bronze/olist"
orders = spark.read.csv(f"{B}/olist_orders_dataset.csv", header=True, inferSchema=True)  # OK for exploration only

orders.printSchema()
orders.groupBy("order_status").count().orderBy(F.desc("count")).show()
orders.select([F.sum(F.col(c).isNull().cast("int")).alias(c) for c in orders.columns]).show(vertical=True)
orders.select(F.min("order_purchase_timestamp"), F.max("order_purchase_timestamp")).show()
orders.groupBy(F.date_trunc("month", "order_purchase_timestamp").alias("m")).count().orderBy("m").show(30)

items = spark.read.csv(f"{B}/olist_order_items_dataset.csv", header=True, inferSchema=True)
items.groupBy("order_id").count().groupBy("count").count().orderBy("count").show()   # items-per-order distribution
items.describe("price", "freight_value").show()
```

Write down: row counts per table, key uniqueness (`count()` vs `distinct().count()` on PKs), null rates,
date ranges, value distributions. That profile becomes your data quality rules.

## 4. Module 2 — Cleaning & transformation (bronze → silver)

```python
# jobs/01_bronze_to_silver.py
import sys
from pyspark.sql import SparkSession, functions as F, Window

BUCKET = sys.argv[1]
B, S = f"s3://{BUCKET}/bronze/olist", f"s3://{BUCKET}/silver/olist"
spark = (SparkSession.builder.appName("olist-bronze-to-silver")
         .config("spark.sql.session.timeZone", "UTC")
         .enableHiveSupport().getOrCreate())

def read(name, schema, **opts):
    return (spark.read.option("header", True).option("mode", "PERMISSIVE")
                 .options(**opts).schema(schema).csv(f"{B}/{name}.csv"))

orders = read("olist_orders_dataset",
    "order_id STRING, customer_id STRING, order_status STRING, order_purchase_timestamp TIMESTAMP, "
    "order_approved_at TIMESTAMP, order_delivered_carrier_date TIMESTAMP, "
    "order_delivered_customer_date TIMESTAMP, order_estimated_delivery_date TIMESTAMP")
customers = read("olist_customers_dataset",
    "customer_id STRING, customer_unique_id STRING, customer_zip_code_prefix STRING, "
    "customer_city STRING, customer_state STRING")
items = read("olist_order_items_dataset",
    "order_id STRING, order_item_id INT, product_id STRING, seller_id STRING, "
    "shipping_limit_date TIMESTAMP, price DECIMAL(10,2), freight_value DECIMAL(10,2)")
payments = read("olist_order_payments_dataset",
    "order_id STRING, payment_sequential INT, payment_type STRING, "
    "payment_installments INT, payment_value DECIMAL(10,2)")
reviews = read("olist_order_reviews_dataset",
    "review_id STRING, order_id STRING, review_score INT, review_comment_title STRING, "
    "review_comment_message STRING, review_creation_date TIMESTAMP, review_answer_timestamp TIMESTAMP",
    multiLine=True, escape='"')
products = read("olist_products_dataset",
    "product_id STRING, product_category_name STRING, product_name_lenght INT, "
    "product_description_lenght INT, product_photos_qty INT, product_weight_g INT, "
    "product_length_cm INT, product_height_cm INT, product_width_cm INT")
sellers = read("olist_sellers_dataset",
    "seller_id STRING, seller_zip_code_prefix STRING, seller_city STRING, seller_state STRING")
translation = read("product_category_name_translation",
    "product_category_name STRING, product_category_name_english STRING")

# --- cleaning rules from exploration ---
orders_c = (orders.dropDuplicates(["order_id"])
    .withColumn("order_status", F.lower(F.trim("order_status")))
    .withColumn("purchase_date", F.to_date("order_purchase_timestamp"))
    .withColumn("delivery_days",
        F.datediff("order_delivered_customer_date", "order_purchase_timestamp"))
    .withColumn("delay_days",
        F.datediff("order_delivered_customer_date", "order_estimated_delivery_date"))
    .withColumn("is_late", F.col("delay_days") > 0)
    .withColumn("dq_missing_delivery",
        (F.col("order_status") == "delivered") & F.col("order_delivered_customer_date").isNull()))

customers_c = (customers.dropDuplicates(["customer_id"])
    .withColumn("customer_city", F.initcap(F.trim("customer_city")))
    .withColumn("customer_state", F.upper("customer_state")))

products_c = (products
    .withColumnRenamed("product_name_lenght", "product_name_length")
    .withColumnRenamed("product_description_lenght", "product_description_length")
    .join(F.broadcast(translation), "product_category_name", "left")
    .withColumn("category", F.coalesce("product_category_name_english",
                                       "product_category_name", F.lit("unknown")))
    .withColumn("volume_cm3", F.col("product_length_cm") * F.col("product_height_cm") * F.col("product_width_cm")))

w_latest_review = Window.partitionBy("review_id").orderBy(F.col("review_answer_timestamp").desc())
reviews_c = (reviews.where(F.col("review_score").between(1, 5))
    .withColumn("rn", F.row_number().over(w_latest_review)).where("rn = 1").drop("rn"))

# --- quality gate: fail loudly instead of silently ---
def assert_unique(df, key, name):
    dupes = df.groupBy(key).count().where("count > 1").limit(1).count()
    if dupes:
        raise ValueError(f"{name}: duplicate {key}")
assert_unique(orders_c, "order_id", "orders")
null_ts = orders_c.where("order_purchase_timestamp IS NULL").count()
if null_ts > 0:
    raise ValueError(f"orders: {null_ts} rows with unparseable purchase timestamp")

def write(df, name, partition=None):
    if partition:
        df = df.repartition(partition)             # one file per partition directory
    w = df.write.mode("overwrite").format("parquet").option("path", f"{S}/{name}")
    if partition:
        w = w.partitionBy(partition)
    w.saveAsTable(f"olist_silver.{name}")          # external table in the Glue Data Catalog

write(orders_c.withColumn("purchase_month", F.date_format("purchase_date", "yyyy-MM")),
      "orders", partition="purchase_month")
for df, name in [(customers_c, "customers"), (items, "order_items"), (payments, "payments"),
                 (reviews_c, "reviews"), (products_c, "products"), (sellers, "sellers")]:
    write(df, name)
spark.stop()
```

## 5. Module 3 — Integration, window functions, advanced aggregation (silver → gold)

```python
# jobs/02_silver_to_gold.py
import sys
from pyspark.sql import SparkSession, functions as F, Window

BUCKET = sys.argv[1]
G = f"s3://{BUCKET}/gold/olist"
spark = (SparkSession.builder.appName("olist-silver-to-gold")
         .config("spark.sql.session.timeZone", "UTC")
         .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
         .enableHiveSupport().getOrCreate())
t = lambda n: spark.table(f"olist_silver.{n}")

# 1) Aggregate the "many" sides to ORDER grain BEFORE joining (avoids row explosion)
items_per_order = (t("order_items").groupBy("order_id").agg(
    F.count("*").alias("n_items"),
    F.sum("price").alias("items_value"),
    F.sum("freight_value").alias("freight_value"),
    F.countDistinct("seller_id").alias("n_sellers")))
pay_per_order = (t("payments").groupBy("order_id").agg(
    F.sum("payment_value").alias("paid_value"),
    F.max("payment_installments").alias("max_installments"),
    F.collect_set("payment_type").alias("payment_types")))
review_per_order = t("reviews").groupBy("order_id").agg(F.avg("review_score").alias("review_score"))

# 2) Order fact: one row per order
fact_orders = (t("orders")
    .join(t("customers"), "customer_id", "left")
    .join(items_per_order, "order_id", "left")
    .join(pay_per_order, "order_id", "left")
    .join(review_per_order, "order_id", "left")
    .withColumn("order_value", F.col("items_value") + F.col("freight_value")))

# 3) Item fact: one row per item, enriched with product + seller (small dims → broadcast)
fact_items = (t("order_items")
    .join(F.broadcast(t("products").select("product_id", "category", "product_weight_g")), "product_id", "left")
    .join(F.broadcast(t("sellers")), "seller_id", "left")
    .join(t("orders").select("order_id", "order_status", "purchase_date", "purchase_month"), "order_id"))

# 4) Window functions
w_cust = Window.partitionBy("customer_unique_id").orderBy("order_purchase_timestamp")
customer_orders = (fact_orders.where("order_status = 'delivered'")
    .withColumn("order_seq", F.row_number().over(w_cust))
    .withColumn("prev_order_ts", F.lag("order_purchase_timestamp").over(w_cust))
    .withColumn("days_since_prev", F.datediff("order_purchase_timestamp", "prev_order_ts"))
    .withColumn("cum_spend", F.sum("order_value").over(
        w_cust.rowsBetween(Window.unboundedPreceding, Window.currentRow))))

customer_360 = customer_orders.groupBy("customer_unique_id", "customer_state").agg(
    F.count("*").alias("orders"),
    F.sum("order_value").alias("lifetime_value"),
    F.min("purchase_date").alias("first_order"),
    F.max("purchase_date").alias("last_order"),
    F.avg("days_since_prev").alias("avg_days_between_orders"),
    F.avg("review_score").alias("avg_review"))
customer_360 = customer_360.withColumn("segment",
    F.when(F.col("orders") >= 3, "loyal").when(F.col("orders") == 2, "returning").otherwise("one_time"))

# Seller ranking within each state by revenue, with share of state revenue
seller_rev = (fact_items.where("order_status = 'delivered'")
    .groupBy("seller_state", "seller_id").agg(F.sum("price").alias("revenue"),
                                              F.countDistinct("order_id").alias("orders")))
w_state = Window.partitionBy("seller_state")
seller_rank = (seller_rev
    .withColumn("rank_in_state", F.dense_rank().over(w_state.orderBy(F.desc("revenue"))))
    .withColumn("share_of_state", F.round(F.col("revenue") / F.sum("revenue").over(w_state), 4)))

# Monthly category revenue with month-over-month growth
cat_month = (fact_items.where("order_status = 'delivered'")
    .groupBy("category", "purchase_month").agg(F.sum("price").alias("revenue")))
w_cat = Window.partitionBy("category").orderBy("purchase_month")
cat_month = (cat_month.withColumn("prev", F.lag("revenue").over(w_cat))
    .withColumn("mom_growth", F.round((F.col("revenue") - F.col("prev")) / F.col("prev"), 4)))

# 5) Advanced aggregation: multi-level totals in one pass
delivery_kpis = (fact_orders.where("order_status = 'delivered'")
    .cube("customer_state", "purchase_month").agg(
        F.count("*").alias("orders"),
        F.round(F.avg("delivery_days"), 2).alias("avg_delivery_days"),
        F.round(F.avg(F.col("is_late").cast("int")), 4).alias("late_rate"),
        F.expr("percentile_approx(delivery_days, 0.9)").alias("p90_delivery_days")))

# 6) Serve: partitioned Parquet + Glue Catalog tables
def publish(df, name, partition=None, files=None):
    if files:
        df = df.repartition(files, partition) if partition else df.repartition(files)
    w = df.write.mode("overwrite").format("parquet").option("path", f"{G}/{name}")
    if partition:
        w = w.partitionBy(partition)
    w.saveAsTable(f"olist_gold.{name}")

publish(fact_orders, "fact_orders", partition="purchase_month", files=24)
publish(fact_items, "fact_items", partition="purchase_month", files=24)
publish(customer_360, "customer_360", files=4)
publish(seller_rank, "seller_rank", files=1)
publish(cat_month, "category_monthly", files=1)
publish(delivery_kpis, "delivery_kpis", files=1)
spark.stop()
```

### Advanced enrichment

Two enrichments that turn raw joins into business signal: **seller-to-customer distance** (does distance
explain late deliveries?) and **RFM segmentation** (who are the best customers?).

```mermaid
flowchart LR
  GEO[(geolocation<br/>~1M rows, many per zip)] -->|"avg lat/lng per zip prefix<br/>(dedupe → ~19k rows)"| ZIP[zip_centroids]
  ZIP -->|broadcast join on<br/>customer zip| C[customers + lat/lng]
  ZIP -->|broadcast join on<br/>seller zip| S[sellers + lat/lng]
  C & S --> FI[fact_items] -->|haversine| DIST[distance_km per item]
  DIST --> CORR[distance bucket vs<br/>late rate, delivery days]
```

**Haversine** gives the great-circle distance between two lat/lng points:

$$
d = 2R \cdot \arcsin\sqrt{\sin^2\tfrac{\Delta\varphi}{2} + \cos\varphi_1 \cos\varphi_2 \sin^2\tfrac{\Delta\lambda}{2}}, \quad R = 6371\ \text{km}
$$

**Read it as:** convert both points to radians, measure how far apart they are in latitude and longitude, and
turn that angle on the sphere into kilometres. It's built from Spark functions, so no UDF is needed.

```python
B = f"s3://{BUCKET}/bronze/olist"
geo = spark.read.csv(f"{B}/olist_geolocation_dataset.csv", header=True, inferSchema=True)
zip_centroids = geo.groupBy(F.col("geolocation_zip_code_prefix").cast("string").alias("zip")).agg(
    F.avg("geolocation_lat").alias("lat"), F.avg("geolocation_lng").alias("lng"))

def haversine_km(lat1, lng1, lat2, lng2):
    dlat, dlng = F.radians(lat2 - lat1), F.radians(lng2 - lng1)
    a = F.sin(dlat / 2) ** 2 + F.cos(F.radians(lat1)) * F.cos(F.radians(lat2)) * F.sin(dlng / 2) ** 2
    return F.lit(2 * 6371.0) * F.asin(F.sqrt(a))

cz = zip_centroids.select(F.col("zip").alias("customer_zip_code_prefix"), F.col("lat").alias("c_lat"), F.col("lng").alias("c_lng"))
sz = zip_centroids.select(F.col("zip").alias("seller_zip_code_prefix"), F.col("lat").alias("s_lat"), F.col("lng").alias("s_lng"))

items_dist = (fact_items
    .join(t("orders").select("order_id", "customer_id", "delivery_days", "is_late"), "order_id")
    .join(t("customers").select("customer_id", "customer_zip_code_prefix"), "customer_id")
    .join(F.broadcast(cz), "customer_zip_code_prefix", "left")
    .join(F.broadcast(sz), "seller_zip_code_prefix", "left")
    .withColumn("distance_km", haversine_km("s_lat", "s_lng", "c_lat", "c_lng"))
    .withColumn("distance_bucket", F.when(F.col("distance_km") < 100, "<100 km")
                .when(F.col("distance_km") < 500, "100-500 km")
                .when(F.col("distance_km") < 1500, "500-1500 km").otherwise(">1500 km")))

items_dist.groupBy("distance_bucket").agg(
    F.round(F.avg("delivery_days"), 1).alias("avg_delivery_days"),
    F.round(F.avg(F.col("is_late").cast("int")), 3).alias("late_rate")).orderBy("avg_delivery_days").show()
```

**RFM segmentation** with `ntile` windows (Recency, Frequency, Monetary scored 1–5):

```python
ref_date = customer_360.agg(F.max("last_order")).first()[0]
rfm = (customer_360
    .withColumn("recency_days", F.datediff(F.lit(ref_date), "last_order"))
    .withColumn("R", F.ntile(5).over(Window.orderBy(F.desc("recency_days"))))   # most recent → 5
    .withColumn("F", F.ntile(5).over(Window.orderBy("orders")))
    .withColumn("M", F.ntile(5).over(Window.orderBy("lifetime_value")))
    .withColumn("rfm_segment", F.when((F.col("R") >= 4) & (F.col("M") >= 4), "champions")
                .when(F.col("R") <= 2, "at_risk").otherwise("regular")))
```

`Window.orderBy` without `partitionBy` moves **all rows to one partition**. That's fine for ~100k customers, but at
scale compute quantiles with `approx_quantile` and bucket with `when` instead.

More ideas: flag negative review keywords and join them to late deliveries; build a cohort retention matrix
(first-purchase month × months since first purchase).

## 6. Run it on AWS

```bash
aws s3 cp jobs/ s3://$BUCKET/code/olist/ --recursive

# Transient EMR: create → run 2 steps → terminate
aws emr create-cluster --name olist-batch --release-label emr-7.5.0 \
  --applications Name=Spark --use-default-roles \
  --instance-groups InstanceGroupType=MASTER,InstanceCount=1,InstanceType=m7g.xlarge \
                    InstanceGroupType=CORE,InstanceCount=2,InstanceType=m7g.xlarge \
  --configurations file://configs.json --log-uri s3://$BUCKET/emr-logs/ \
  --steps "Type=Spark,Name=bronze_to_silver,ActionOnFailure=TERMINATE_CLUSTER,Args=[--deploy-mode,cluster,s3://$BUCKET/code/olist/01_bronze_to_silver.py,$BUCKET]" \
          "Type=Spark,Name=silver_to_gold,ActionOnFailure=TERMINATE_CLUSTER,Args=[--deploy-mode,cluster,s3://$BUCKET/code/olist/02_silver_to_gold.py,$BUCKET]" \
  --auto-terminate
```

EMR Serverless alternative: submit each script with `start-job-run` (module 04). Add
`--conf spark.hadoop.hive.metastore.client.factory.class=com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory`
so the jobs use the Glue Data Catalog.

## 7. Module 4 — Spark configuration & join optimization for this project

| Decision | Reason |
|---|---|
| Explicit schemas | avoid inference jobs; catch format changes |
| Aggregate items/payments to order grain **before** joining | prevents fan-out (3 items × 2 payments = 6 rows per order and doubled revenue) |
| `broadcast()` products, sellers, translation | all are a few MB; the big side never shuffles |
| Partition gold facts by `purchase_month` | dashboards filter by month → Athena prunes |
| `repartition(n, partition_col)` before write | one or a few files per partition |
| `partitionOverwriteMode=dynamic` | reruns for a month don't wipe others |
| AQE on (default) | coalesces 200 shuffle partitions down to a handful for this small dataset |
| Customer windows partitioned by `customer_unique_id` | high cardinality → well-distributed window partitions |

At 100k orders this runs in minutes on 2 nodes. At 1B orders the same code holds up. You would then raise
shuffle partitions, check skew (mega-sellers in `seller_rev`), and switch facts to Delta/Iceberg for MERGE-based
incremental loads.

## 8. Data serving layer with Athena

```bash
aws athena create-work-group --name olist \
  --configuration "ResultConfiguration={OutputLocation=s3://$BUCKET/athena-results/},BytesScannedCutoffPerQuery=10737418240,EnforceWorkGroupConfiguration=true"
```

```sql
-- Athena (Trino engine); tables already exist via the Glue Catalog
SELECT customer_state, purchase_month, avg_delivery_days, late_rate
FROM olist_gold.delivery_kpis
WHERE customer_state IS NOT NULL AND purchase_month IS NOT NULL
ORDER BY late_rate DESC LIMIT 20;

SELECT category, purchase_month, revenue, mom_growth
FROM olist_gold.category_monthly
WHERE purchase_month BETWEEN '2018-01' AND '2018-08'
ORDER BY revenue DESC;

-- partition pruning: scans one month only
SELECT count(*), sum(order_value) FROM olist_gold.fact_orders WHERE purchase_month = '2018-05';
```

Connect **QuickSight** to Athena (dataset → Athena → `olist_gold`) and build: monthly revenue trend,
late-delivery heatmap by state, top sellers per state, customer segment split.

## 9. Actionable insights the project should produce

| Question | Table | Typical finding on Olist |
|---|---|---|
| Where are deliveries late? | `delivery_kpis` | northern/northeastern states have much longer delivery times and higher late rates |
| Do late deliveries hurt reviews? | `fact_orders` (`is_late` vs `review_score`) | late orders average markedly lower review scores |
| Is there repeat business? | `customer_360` | the vast majority are one-time customers → retention opportunity |
| Which categories grow? | `category_monthly` | health/beauty, bed/bath, and similar categories lead revenue |

## Teardown

```bash
aws emr list-clusters --active
aws s3 rm s3://$BUCKET/athena-results/ --recursive
# keep bronze/silver/gold if you continue to module 16; otherwise:
# aws s3 rm s3://$BUCKET/ --recursive && aws glue delete-database --name olist_silver && aws glue delete-database --name olist_gold
```

## Key takeaways

- Profile first; the profile becomes the cleaning and quality rules.
- Aggregate many-to-one tables to the join grain before joining to avoid fan-out double counting.
- Broadcast small dimensions; partition facts by the most common filter (month/day).
- Register every layer in the Glue Catalog so Athena/QuickSight can serve it without a running cluster.
- Transient EMR (or EMR Serverless) + S3 + Athena gives near-zero idle cost.

## Interview scenarios

1. *Revenue in the gold table is ~1.4× the payments total. Why?* — joining items and payments at different grains
   duplicated rows. Aggregate each to order grain first, then join.
2. *How would you make this pipeline incremental at 1B orders?* — partition by date, process only new
   partitions (Airflow passes `ds`), use Delta/Iceberg `MERGE` for late-arriving updates (order status changes),
   and recompute only affected aggregates.
3. *Why Athena instead of keeping the EMR cluster up for analysts?* — Athena is serverless and pay-per-scan;
   with partitioned Parquet a typical dashboard query scans MBs and costs fractions of a cent, with no idle cluster.
