# Big Data Engineering on AWS — Hadoop → Spark → Kafka → Airflow → Lakehouse

> A deep-dive course for engineers who already know basic SQL and Python.
> Every module goes: **why it exists → plain-words analogy → architecture diagram → internals →
> numbers you can calculate → AWS implementation → failure modes → interview scenarios.**
>
> Every GCP (Dataproc, GCS) and Azure (ADF, ADLS Gen2, Synapse) part of the original syllabus is
> **replaced with its AWS equivalent**. Basic SQL / basic Python lectures are intentionally skipped.

## Roadmap

```mermaid
flowchart LR
  subgraph A["PART A — Foundations"]
    M01[01 Big data, DW vs lake,<br/>ETL vs ELT]
  end
  subgraph B["PART B — Hadoop on AWS EMR"]
    M02[02 Hadoop + HDFS] --> M03[03 HDFS failures, HA,<br/>read/write path]
    M03 --> M04[04 AWS + EMR cluster lab]
    M04 --> M05[05 MapReduce]
    M05 --> M06[06 YARN]
  end
  subgraph C["PART C — Spark"]
    M07[07 Python for distributed<br/>processing] --> M08[08 Spark core]
    M08 --> M09[09 RDDs + partitioning]
    M09 --> M10[10 DataFrames]
    M10 --> M11[11 Spark SQL + tables<br/>+ Glue Catalog]
    M11 --> M12[12 Caching]
    M12 --> M13[13 Architecture +<br/>deployment]
    M13 --> M14[14 Optimization]
    M14 --> M15[15 E-commerce project<br/>on EMR]
  end
  subgraph D["PART D — Ecosystem"]
    M16[16 Hive + Athena] --> M17[17 Kafka, MSK, Kinesis]
    M17 --> M18[18 Docker + ECR]
    M18 --> M19[19 Airflow + MWAA]
    M19 --> M20[20 Airflow ETL project]
  end
  subgraph E["PART E — Lakehouse on AWS"]
    M21[21 Databricks on AWS<br/>+ Delta Lake] --> M22[22 AWS data services:<br/>Glue, Lake Formation,<br/>Athena, Redshift]
    M22 --> M23[23 Capstone: Olist<br/>medallion on AWS]
    M23 --> M24[24 Cheat sheet +<br/>interview scenarios]
  end
  A --> B --> C --> D --> E
```

| # | Module | You will be able to |
|---|---|---|
| 01 | [Big data foundations](01_big_data_foundations.md) | explain the 5 V's, distributed-system trade-offs (CAP, scale-up vs out), DB vs DW vs lake vs lakehouse, ETL vs ELT, and the data engineer's job |
| 02 | [Hadoop ecosystem & HDFS architecture](02_hadoop_hdfs_architecture.md) | draw HDFS, calculate blocks/replicas/NameNode memory, explain rack awareness and why HDFS hates small files |
| 03 | [HDFS failures, HA, read & write path](03_hdfs_failures_ha_read_write.md) | trace a write pipeline packet by packet, handle temporary vs permanent DataNode loss, compare Secondary vs Standby NameNode, design QJM + ZKFC HA |
| 04 | [AWS foundations & EMR cluster lab](04_aws_emr_cluster_lab.md) | set up IAM/VPC/S3 safely, launch EMR (replaces Dataproc), pick primary/core/task nodes, use Spot + autoscaling, EMR Serverless, Linux + HDFS commands |
| 05 | [MapReduce deep dive](05_mapreduce.md) | explain map → spill → shuffle → sort → reduce, size mappers/reducers, use combiners/partitioners, run Hadoop Streaming on EMR |
| 06 | [YARN](06_yarn.md) | trace an application through RM → AM → containers, compare FIFO/Capacity/Fair schedulers, tune container memory on EMR |
| 07 | [Python for distributed processing](07_python_for_distributed_processing.md) | connect higher-order functions, closures, generators and serialization to how Spark ships code |
| 08 | [Spark core](08_spark_core.md) | explain why Spark beats MR, the ecosystem, transformations vs actions, laziness, the DAG |
| 09 | [RDDs, partitioning, jobs/stages/tasks](09_spark_rdd_partitioning.md) | calculate partitions, spot narrow vs wide, read the Spark UI, pick reduceByKey over groupByKey, repartition vs coalesce |
| 10 | [Spark DataFrames](10_spark_dataframes.md) | read from S3 with explicit schemas, use read/write modes, handle types/dates, understand Catalyst + Tungsten |
| 11 | [Spark SQL, tables & the Glue Data Catalog](11_spark_sql_tables_catalog.md) | choose temp vs global temp vs persistent, managed vs external, use Glue Catalog as the metastore |
| 12 | [Caching & persistence](12_spark_caching.md) | understand storage levels and the unified memory model, decide when caching helps or hurts |
| 13 | [Spark architecture & deployment](13_spark_architecture_deployment.md) | size executors with real math, compare standalone/YARN/K8s, client vs cluster mode, EMR vs EMR Serverless vs Glue |
| 14 | [Spark optimization](14_spark_optimization.md) | pick join strategies, fix skew with salting/AQE, solve small files, choose Parquet/partitioning |
| 15 | [Spark e-commerce project on AWS](15_spark_ecommerce_project_aws.md) | build ingestion → cleaning → integration → window aggregations → serving with S3 + EMR + Athena |
| 16 | [Hive & Athena](16_hive_athena.md) | draw Hive architecture and query flow, replace Derby with Glue/RDS metastore, partition/bucket, use Athena as serverless SQL |
| 17 | [Kafka, Amazon MSK & Kinesis](17_kafka_msk_kinesis.md) | explain partitions/ISR/offsets/consumer groups, delivery semantics, produce/consume against MSK with IAM, choose MSK vs Kinesis |
| 18 | [Docker for data engineers + ECR](18_docker_for_data_engineers.md) | understand layers and images vs containers, run a local data stack with Compose, push to ECR |
| 19 | [Apache Airflow & Amazon MWAA](19_airflow_mwaa.md) | draw Airflow 3 architecture, write DAGs + TaskFlow, design idempotent/backfillable pipelines, deploy to MWAA |
| 20 | [Airflow ETL project: API → RDS Postgres on MWAA](20_airflow_etl_project_aws.md) | build and deploy an extract/transform/load DAG with connections, retries, and failure handling |
| 21 | [Databricks on AWS & Delta Lake](21_databricks_on_aws_delta.md) | explain control vs compute plane in your AWS account, Unity Catalog, Delta transaction log, OPTIMIZE/VACUUM/time travel |
| 22 | [AWS data services deep dive](22_aws_data_services.md) | use Glue (catalog, crawlers, ETL), Lake Formation, Athena, Redshift (MPP, dist/sort keys, Spectrum, Serverless), Step Functions |
| 23 | [Capstone: Olist medallion lakehouse on AWS](23_capstone_olist_aws.md) | rebuild the Azure project on AWS: RDS + HTTP + MongoDB → Glue/Step Functions → S3 bronze/silver/gold → Databricks/Glue → Athena/Redshift → QuickSight |
| 24 | [Cheat sheet & interview scenarios](24_cheatsheet_interview.md) | answer the common big-data system-design and debugging questions |
| 25 | [PySpark deep dive: architecture, code patterns, mini project](25_pyspark_deep_dive.md) | explain Py4J, Python workers, Arrow, and Spark Connect; know where each line runs; write short idiomatic PySpark; build a sessionization + funnel project (read after 13) |

**Syllabus coverage:** [COVERAGE.md](COVERAGE.md) maps every original lecture and exercise to the module section
that covers it (or marks it as an AWS replacement, or as skipped basic SQL/Python).

## Azure / GCP → AWS translation table (used throughout)

| Original syllabus | AWS equivalent in this course | Notes |
|---|---|---|
| GCP account | AWS account + IAM Identity Center user + budget alarm | never use the root user day-to-day |
| GCP **Dataproc** (Hadoop/Spark cluster) | **Amazon EMR** (on EC2), EMR Serverless, EMR on EKS | module 04 |
| GCS bucket | **Amazon S3** | EMR reads `s3://` via EMRFS |
| Hive Metastore on Dataproc | **AWS Glue Data Catalog** (or RDS-backed Hive metastore) | module 11, 16 |
| BigQuery | **Athena** (serverless) / **Redshift** (warehouse) | module 16, 22 |
| Pub/Sub, Confluent Cloud | **Amazon MSK** (managed Kafka), **Kinesis Data Streams** | module 17 |
| Docker Hub | **Amazon ECR** | module 18 |
| Cloud Composer / Astro Cloud | **Amazon MWAA** (managed Airflow) | module 19, 20 |
| Azure **Data Factory** (ingestion + orchestration) | **AWS Glue** jobs (ingest/transform) + **Step Functions** or MWAA (orchestration) | module 22, 23 |
| Azure **ADLS Gen2** | **S3** + Glue Data Catalog + **Lake Formation** (permissions) | |
| Azure SQL Database | **Amazon RDS for MySQL** / Aurora | |
| MongoDB (Atlas on Azure) | **MongoDB Atlas on AWS** or **Amazon DocumentDB** | |
| Azure **Databricks** | **Databricks on AWS** (or EMR / Glue for a pure-AWS stack) | module 21 |
| Synapse **serverless** SQL pool | **Athena** (or Redshift Spectrum) | pay per TB scanned |
| Synapse **dedicated** SQL pool | **Redshift** provisioned (RA3) / Redshift Serverless | |
| Synapse **CETAS** | **Athena CTAS** / Redshift `UNLOAD` + external table | module 23 |
| Resource group | **tags** + CloudFormation/Terraform stack (+ separate accounts per env) | |
| Azure Key Vault | **AWS Secrets Manager** / SSM Parameter Store | |
| Power BI | **Amazon QuickSight** | |

## How every module is structured

| Block | Purpose |
|---|---|
| **Why it matters** | the engineering problem this topic solves |
| **In plain words** | an everyday analogy before the internals |
| **Architecture at a glance** + **How to read it** | a diagram of the moving parts and the flow |
| **Deep dive** | internals, defaults, and calculations with real numbers |
| **On AWS** | how the same thing is done with AWS services, with CLI / code |
| **Failure modes & production notes** | how it breaks at scale and what to do |
| **Key takeaways** + **Interview scenarios** | what to remember, and how it gets asked (with answers) |

## Cost safety (read once)

AWS bills by the second for most things in this course. Before every lab:

1. Create a **budget alarm** (module 04) — e.g. alert at \$10 and \$25.
2. Prefer **transient** EMR clusters (`--auto-terminate`) or **EMR Serverless** (stops when idle).
3. Use **Spot** for task nodes, Graviton (`m7g`, `r7g`) instance types where possible.
4. Every lab ends with a **teardown** block. Run it.
5. MSK, Redshift provisioned, MWAA, and NAT Gateways bill per hour even when idle — delete them after labs.

## Prerequisites

- Comfortable with SQL (joins, group by, window functions) and Python (functions, classes, pandas).
- AWS CLI v2 installed and configured (`aws configure sso` recommended).
- Optional local tools: Docker, Java 17, `pip install pyspark==3.5.* boto3 confluent-kafka`.
