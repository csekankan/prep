# 22 — AWS Data Services Deep Dive: S3, Glue, Lake Formation, Redshift, Step Functions, DMS

> **Why it matters:** this module replaces the original "Azure intro / Azure cloud overview" lectures.
> Before the capstone, you need a working model of the AWS services that make up a data platform: how
> S3 behaves at scale, what Glue actually is (four products under one name), how Lake Formation permissions
> layer on IAM, how Redshift's MPP architecture decides performance, and when to orchestrate with Step
> Functions vs MWAA.

## In plain words

- **S3** = the warehouse floor where every box (file) lives.
- **Glue Data Catalog** = the inventory system: what's in which aisle, and in what format.
- **Glue ETL** = forklift crews (serverless Spark) that move and repackage boxes.
- **Lake Formation** = the security desk that decides who may open which boxes, down to columns and rows.
- **Athena** = walk-in shoppers who query boxes directly. **Redshift** = a showroom where curated goods are
  pre-arranged for very fast, high-concurrency browsing.
- **Step Functions / MWAA** = the shift supervisors who sequence the crews.
- **DMS / Kinesis / MSK** = the delivery trucks bringing goods in.

## Architecture at a glance — AWS-native lakehouse reference

```mermaid
flowchart LR
  subgraph SRC["Sources"]
    RDS[(RDS / Aurora)]
    SAAS[SaaS / HTTP]
    EVT[Events]
    DDB[(DynamoDB)]
  end
  subgraph ING["Ingest"]
    DMS[DMS<br/>full load + CDC]
    ZETL[Zero-ETL<br/>Aurora/RDS/DynamoDB → Redshift]
    GLI[Glue jobs /<br/>AppFlow / Lambda]
    FH[Data Firehose]
    KDS[Kinesis / MSK]
  end
  subgraph LAKE["S3 lake (Iceberg / Delta / Parquet)"]
    B[bronze] --> S[silver] --> G[gold]
  end
  subgraph GOV["Catalog & governance"]
    GDC[(Glue Data Catalog)]
    LF[Lake Formation<br/>grants, LF-tags,<br/>row/column filters]
    DQ[Glue Data Quality]
  end
  subgraph PROC["Process"]
    GLUE[Glue ETL Spark]
    EMR[EMR / EMR Serverless]
  end
  subgraph SERVE["Serve"]
    ATH[Athena]
    RS[Redshift<br/>+ Spectrum]
    QS[QuickSight]
    SM[SageMaker]
  end
  ORCH[Step Functions / MWAA<br/>+ EventBridge schedules]
  RDS --> DMS --> B
  RDS --> ZETL --> RS
  SAAS --> GLI --> B
  EVT --> KDS --> FH --> B
  DDB --> ZETL
  B & S --> PROC --> S & G
  GDC --- LAKE
  LF -.enforces.-> ATH & RS & GLUE & EMR
  G --> ATH --> QS
  G --> RS --> QS
  S --> SM
  ORCH -.-> ING & PROC
```

**How to read it:** S3 is the single storage layer. The Glue Data Catalog is the single metadata layer.
Lake Formation enforces permissions for every engine that reads through the catalog. Processing engines are
interchangeable, and serving splits by need: Athena for ad-hoc and pay-per-query, Redshift for
high-concurrency, low-latency BI.

## 1. AWS foundations you need for data work

| Concept | What matters for data engineering |
|---|---|
| **Region / AZ** | data residency = region choice; EMR/MSK/RDS placement across AZs; cross-region transfer costs money |
| **Shared responsibility** | AWS secures the infrastructure; you secure IAM, encryption, network, data classification |
| **Multi-account** (Organizations) | separate dev/stage/prod and a central "data lake" account; Lake Formation cross-account sharing |
| **IAM** | roles (not users) for services; policy evaluation: explicit **Deny** > Allow > implicit deny; resource policies (bucket policies) + identity policies + SCPs + permission boundaries all apply |
| **KMS** | SSE-KMS on buckets, Redshift, MSK, Glue; the key policy must allow the service roles |
| **VPC endpoints** | Gateway (S3, DynamoDB: free) and Interface (Glue, Athena, STS, Secrets Manager) keep traffic private and avoid NAT charges |
| **Cost** | tag everything; Cost Explorer by tag; budgets; S3 storage classes; Spot; serverless where usage is spiky |

## 2. Amazon S3 for data lakes — the deep parts

| Topic | Detail |
|---|---|
| Consistency | strong read-after-write for PUT/DELETE and LIST (since Dec 2020) |
| Performance | ≥ 3,500 PUT/COPY/POST/DELETE and 5,500 GET/HEAD requests per second **per prefix**; scales with more prefixes; 503 `SlowDown` = throttling |
| Large objects | multipart upload (required > 5 GB, recommended > 100 MB); byte-range GETs for parallel reads |
| Storage classes | Standard → Intelligent-Tiering (unknown access patterns) → Standard-IA → Glacier Instant/Flexible/Deep Archive; lifecycle rules move/expire by prefix/tag/age |
| Protection | versioning, Object Lock (WORM, compliance), replication (CRR/SRR), MFA delete |
| Encryption | SSE-S3 by default; SSE-KMS for key control and audit (enable **S3 Bucket Keys** to cut KMS request costs) |
| Events | S3 Event Notifications / EventBridge → Lambda / SQS / Step Functions (event-driven ingestion) |
| Listing | LIST returns 1,000 keys per call. Listing 10 M files takes minutes, which is why table formats keep file lists in metadata |
| **S3 Tables** | table buckets with managed Apache Iceberg tables (automatic compaction, snapshot management), queryable by Athena/EMR/Glue/Redshift |

Lake layout convention:

```
s3://acme-lake-prod/
  bronze/<source>/<table>/ingest_date=YYYY-MM-DD/      raw, immutable, as received
  silver/<domain>/<table>/                             cleaned, Iceberg/Delta/Parquet
  gold/<mart>/<table>/                                 aggregated, BI-ready
  _quarantine/<table>/dt=.../                          rejected rows
```

## 3. AWS Glue — four products under one name

```mermaid
flowchart TB
  subgraph GLUE["AWS Glue"]
    CAT[Data Catalog<br/>databases, tables,<br/>partitions, schemas]
    CRW[Crawlers + classifiers<br/>infer schema & partitions]
    ETL[ETL jobs<br/>Spark / Python shell / Ray*<br/>Glue Studio visual]
    DQ[Data Quality<br/>DQDL rules]
    WF[Workflows + triggers]
    CON[Connections<br/>JDBC, MongoDB, Kafka, SaaS]
  end
  CRW -->|creates/updates| CAT
  ETL <--> CAT
  DQ --> CAT
  WF --> CRW & ETL
  CON --> ETL
```

### 3.1 Data Catalog and crawlers

- Hive-compatible metastore (databases, tables, partitions, column stats), serverless, shared by all engines.
- **Crawlers** sample data in S3/JDBC/DynamoDB, infer schemas with classifiers, and add tables and partitions.
  Good for discovery. For production tables, prefer **explicit DDL / table formats / partition projection**:
  crawlers can mis-infer types or split one table into many when files differ.
- **Partition indexes** speed up planning on tables with many partitions.

### 3.2 Glue ETL jobs

| Concept | Detail |
|---|---|
| Versions | Glue 4.0 (Spark 3.3), **Glue 5.0** (Spark 3.5, Python 3.11) |
| Workers | G.1X (4 vCPU, 16 GB = 1 DPU), G.2X (2 DPU), G.4X, G.8X; G.025X for streaming; **Flex** execution class for non-urgent jobs at lower cost |
| Pricing | per DPU-hour, billed per second (1-minute minimum on Glue 2.0+) |
| DynamicFrame | Glue's schema-flexible frame: handles inconsistent types via `ChoiceType` (`resolveChoice`); convert with `toDF()` / `fromDF()` |
| **Job bookmarks** | track processed S3 files / JDBC keys between runs → incremental processing; needs `transformation_ctx` on sources and `job.commit()` |
| Connectors | JDBC (RDS, Redshift), MongoDB/DocumentDB, Kafka/MSK, Kinesis, SaaS via Glue connectors |
| Local dev | Glue Docker image, interactive sessions in notebooks |

```python
# glue_job_orders.py — incremental CSV → Parquet with bookmarks and DQ
import sys
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from awsglue.transforms import ApplyMapping
from pyspark.context import SparkContext

args = getResolvedOptions(sys.argv, ["JOB_NAME", "src", "dst"])
glue = GlueContext(SparkContext.getOrCreate())
spark = glue.spark_session
job = Job(glue); job.init(args["JOB_NAME"], args)

raw = glue.create_dynamic_frame.from_options(
    connection_type="s3", format="csv",
    connection_options={"paths": [args["src"]], "recurse": True},
    format_options={"withHeader": True},
    transformation_ctx="raw_orders")                     # bookmark key: only NEW files are read

typed = ApplyMapping.apply(frame=raw, mappings=[
    ("order_id", "string", "order_id", "string"),
    ("customer_id", "string", "customer_id", "string"),
    ("order_status", "string", "order_status", "string"),
    ("order_purchase_timestamp", "string", "order_ts", "timestamp")],
    transformation_ctx="typed")

df = typed.toDF().withColumnRenamed("order_status", "status")
df = df.withColumn("dt", df.order_ts.cast("date"))
(df.write.mode("append").partitionBy("dt").parquet(args["dst"]))   # bookmarks make append safe per file

job.commit()                                            # persist bookmark state
```

```bash
aws glue create-job --name orders-incremental --role GlueJobRole --glue-version 5.0 \
  --worker-type G.1X --number-of-workers 4 \
  --command Name=glueetl,ScriptLocation=s3://$BUCKET/code/glue_job_orders.py,PythonVersion=3 \
  --default-arguments '{"--job-bookmark-option":"job-bookmark-enable","--enable-glue-datacatalog":"true",
    "--src":"s3://'$BUCKET'/bronze/orders/","--dst":"s3://'$BUCKET'/silver/orders/"}'
aws glue start-job-run --job-name orders-incremental
```

### 3.3 Glue Data Quality (DQDL)

```
Rules = [
  RowCount > 1000,
  IsComplete "order_id",
  IsUnique "order_id",
  ColumnValues "status" in ["delivered","shipped","canceled","invoiced","processing","unavailable","approved","created"],
  Completeness "customer_id" > 0.99,
  ColumnValues "amount" between 0 and 100000
]
```

Use it inside a Glue job (`EvaluateDataQuality` transform) to fail the run or route bad rows, or as a ruleset
attached to a catalog table.

## 4. AWS Lake Formation — permissions for the lake

**Problem:** IAM + bucket policies work at the S3 object/prefix level, and they're coarse. Analysts need
**table, column, row, and cell** permissions that apply the same way in Athena, Redshift Spectrum, EMR, and Glue.

| Feature | Detail |
|---|---|
| Registered locations | S3 paths Lake Formation manages; engines get **temporary credentials** vended by LF |
| Grants | `SELECT`, `INSERT`, `ALTER`, `DROP`, `DESCRIBE` on databases/tables/columns, to IAM principals, IAM Identity Center users/groups, or other accounts |
| **LF-Tags** (tag-based access control) | tag resources (`domain=sales`, `pii=true`), grant on tag expressions. Scales far better than per-table grants |
| **Data filters** | row-level (`country = 'IN'`) and column-level / cell-level security |
| Cross-account sharing | share catalog resources with consumer accounts (via AWS RAM) without copying data |
| Hybrid mode | adopt LF gradually while existing IAM-based access keeps working |

```bash
aws lakeformation create-lf-tag --tag-key pii --tag-values true false
aws lakeformation add-lf-tags-to-resource \
  --resource '{"TableWithColumns":{"DatabaseName":"olist_silver","Name":"customers","ColumnNames":["customer_zip_code_prefix"]}}' \
  --lf-tags TagKey=pii,TagValues=true
aws lakeformation grant-permissions \
  --principal DataLakePrincipalIdentifier=arn:aws:iam::123456789012:role/analyst \
  --permissions SELECT \
  --resource '{"LFTagPolicy":{"ResourceType":"TABLE","Expression":[{"TagKey":"pii","TagValues":["false"]}]}}'
```

## 5. Amazon Redshift — MPP warehouse deep dive

```mermaid
flowchart TB
  C[BI / SQL clients<br/>JDBC, Data API] --> L[Leader node<br/>parse, plan, compile,<br/>coordinate, final aggregation]
  L --> N1[Compute node 1<br/>slices 1..k]
  L --> N2[Compute node 2<br/>slices 1..k]
  L --> N3[Compute node N]
  N1 & N2 & N3 <--> RMS[(Redshift Managed Storage<br/>S3-backed, local SSD cache — RA3)]
  N1 & N2 & N3 -.Spectrum layer.-> S3L[(S3 lake via<br/>Glue Catalog)]
```

| Concept | Detail |
|---|---|
| **MPP** | data is distributed across compute nodes and their **slices**; each slice processes its portion in parallel |
| **RA3 nodes** | compute separated from **managed storage** (S3-backed with SSD cache): scale compute independently |
| **Redshift Serverless** | capacity in **RPUs**, auto-scales, billed per RPU-second while queries run; base capacity configurable |
| Columnar + compression | column encodings (AZ64, ZSTD, LZO); **zone maps** (min/max per 1 MB block) skip blocks |
| **Distribution style** | how rows are placed on slices: `AUTO` (default), `EVEN` (round-robin), `KEY` (hash of a column: co-locates join keys), `ALL` (full copy on every node: small dimensions) |
| **Sort keys** | order on disk; makes zone maps effective for range filters (e.g. date); `AUTO` available |
| Workload management | automatic WLM, query priorities, **concurrency scaling** (burst clusters for spikes), short query acceleration |
| Loading | `COPY` from S3 in parallel (split input into a multiple of the number of slices, 1 MB–1 GB compressed files); **zero-ETL** from Aurora/RDS/DynamoDB; streaming ingestion from Kinesis/MSK |
| Unloading | `UNLOAD ('select ...') TO 's3://...' FORMAT PARQUET PARTITION BY (...)` |
| **Spectrum** | query S3 tables (Glue Catalog) from Redshift via external schemas; join lake + warehouse data |
| Other | materialized views (auto refresh), data sharing across clusters/accounts, Redshift ML |

**Why distribution matters (worked example):** joining `fact_orders` (2 B rows) to `dim_customer` (50 M rows) on
`customer_id`:
- Both `DISTSTYLE KEY (customer_id)` → matching rows sit on the same slice → **no data movement**
  (`DS_DIST_NONE` in EXPLAIN).
- Fact distributed EVEN, dim KEY on another column → Redshift redistributes or broadcasts 50 M rows on every
  query (`DS_BCAST_INNER` / `DS_DIST_BOTH`) → slow.
- A small dim (e.g. 200 countries) → `DISTSTYLE ALL`.

```sql
CREATE TABLE gold.fact_orders (
  order_id VARCHAR(32), customer_id VARCHAR(32), purchase_date DATE,
  order_value DECIMAL(12,2), customer_state CHAR(2))
DISTSTYLE KEY DISTKEY (customer_id)
SORTKEY (purchase_date);

COPY gold.fact_orders FROM 's3://bigdata-course-123/gold/olist/fact_orders/'
IAM_ROLE 'arn:aws:iam::123456789012:role/RedshiftS3Read' FORMAT AS PARQUET;

-- Spectrum: query the lake directly
CREATE EXTERNAL SCHEMA lake FROM DATA CATALOG DATABASE 'olist_gold'
IAM_ROLE 'arn:aws:iam::123456789012:role/RedshiftSpectrum';
SELECT customer_state, sum(order_value) FROM lake.fact_orders
WHERE purchase_month = '2018-05' GROUP BY 1;
```

### Athena vs Redshift vs Redshift Spectrum

| | Athena | Redshift (provisioned / serverless) | Spectrum |
|---|---|---|---|
| Data location | S3 | Redshift managed storage | S3 |
| Pricing | per TB scanned | per node-hour / per RPU-second | per TB scanned (+ cluster) |
| Latency/concurrency | seconds; moderate concurrency | sub-second to seconds; high concurrency with caching/scaling | seconds |
| Best for | ad-hoc exploration, infrequent queries, ELT with CTAS | dashboards with many users, complex joins, SLAs | joining warehouse tables with cold lake data |

## 6. Orchestration: Step Functions vs MWAA

```mermaid
stateDiagram-v2
  [*] --> ListSources
  ListSources --> IngestEach
  state IngestEach {
    [*] --> RunGlueIngest
    RunGlueIngest --> [*]
  }
  IngestEach --> TransformSilver: all sources done
  TransformSilver --> DataQuality
  DataQuality --> PublishGold: pass
  DataQuality --> NotifyFailure: fail
  PublishGold --> [*]
  NotifyFailure --> [*]
```

```json
{
  "Comment": "Parametrized ingestion: one Glue run per source, then transform",
  "StartAt": "IngestEach",
  "States": {
    "IngestEach": {
      "Type": "Map",
      "ItemsPath": "$.sources",
      "MaxConcurrency": 5,
      "ItemProcessor": {
        "ProcessorConfig": {"Mode": "INLINE"},
        "StartAt": "RunGlueIngest",
        "States": {
          "RunGlueIngest": {
            "Type": "Task",
            "Resource": "arn:aws:states:::glue:startJobRun.sync",
            "Parameters": {
              "JobName": "olist-ingest",
              "Arguments": {"--source_url.$": "$.url", "--target_path.$": "$.target"}
            },
            "Retry": [{"ErrorEquals": ["States.ALL"], "MaxAttempts": 2, "BackoffRate": 2, "IntervalSeconds": 30}],
            "End": true
          }
        }
      },
      "Next": "TransformSilver"
    },
    "TransformSilver": {
      "Type": "Task",
      "Resource": "arn:aws:states:::glue:startJobRun.sync",
      "Parameters": {"JobName": "olist-silver"},
      "End": true
    }
  }
}
```

`.sync` makes Step Functions wait for the Glue job to finish (no polling code). The Map state replaces ADF's
**ForEach + parameterized pipeline** pattern.

| | Step Functions | MWAA (Airflow) |
|---|---|---|
| Model | JSON/YAML state machines (ASL), visual designer | Python DAGs |
| Cost | per state transition (Standard) / per request-duration (Express); zero idle | per environment-hour (idle costs) |
| Integrations | 200+ AWS services natively, `.sync` patterns | 1,000+ operators, including non-AWS (Databricks, dbt, Snowflake) |
| Scheduling/backfill | EventBridge Scheduler; no native backfill concept | rich scheduling, catchup, backfills, data intervals |
| Choose when | AWS-only, event-driven, serverless, small teams | many pipelines, cross-platform, Python-heavy teams, backfills |

## 7. Ingestion services cheat sheet

| Service | Use |
|---|---|
| **DMS** | database migration + **CDC** (binlog/WAL) from MySQL/Postgres/Oracle/SQL Server to S3 (Parquet), Redshift, Kinesis, MSK |
| **Zero-ETL integrations** | Aurora MySQL/Postgres, RDS MySQL, DynamoDB → Redshift (or to SageMaker Lakehouse), near real-time, no pipelines |
| **AppFlow** | SaaS (Salesforce, ServiceNow...) → S3/Redshift |
| **Data Firehose** | streams (Kinesis, MSK, direct PUT) → S3/Redshift/OpenSearch with buffering, format conversion to Parquet, dynamic partitioning |
| **Glue jobs** | JDBC/HTTP/MongoDB pulls with custom logic |
| **DataSync / Transfer Family** | on-prem file shares / SFTP → S3 |

## 8. "Should we learn Azure too?" (and GCP)

Concepts transfer almost one-to-one; only names and IAM models differ. Learn one cloud deeply, then map:

| Concept | AWS | Azure | GCP |
|---|---|---|---|
| Object storage | S3 | ADLS Gen2 / Blob | GCS |
| Managed Spark/Hadoop | EMR | HDInsight / Synapse Spark | Dataproc |
| Serverless ETL | Glue | Data Factory (data flows) | Dataflow / Dataproc Serverless |
| Orchestration | Step Functions / MWAA | Data Factory pipelines | Cloud Composer / Workflows |
| Catalog / governance | Glue Catalog + Lake Formation | Purview / Unity Catalog | Dataplex / BigLake |
| Serverless SQL on lake | Athena | Synapse serverless SQL | BigQuery external tables |
| Warehouse | Redshift | Synapse dedicated / Fabric Warehouse | BigQuery |
| Streaming | Kinesis / MSK | Event Hubs | Pub/Sub |
| BI | QuickSight | Power BI | Looker |

## Key takeaways

- S3: strong consistency, per-prefix request limits, lifecycle/storage classes, versioning; table formats beat LIST at scale.
- Glue = Catalog + crawlers + serverless Spark ETL (DynamicFrames, bookmarks) + Data Quality.
- Lake Formation adds table/column/row permissions with LF-Tags and vends temporary credentials to all engines.
- Redshift performance = distribution style + sort keys + MPP slices; Spectrum and Athena query S3 directly.
- Step Functions (serverless, AWS-native, Map + `.sync`) vs MWAA (Python, cross-platform, backfills).

## Interview scenarios

1. *Glue crawler created 300 tables for one dataset.* — files in the prefix had inconsistent schemas or folder
   structures. Fix the layout, configure crawler grouping (`TableGroupingPolicy: CombineCompatibleSchemas`),
   or define the table explicitly with DDL.
2. *Analysts in India must only see Indian customers, and nobody except finance sees emails.* — Lake Formation
   data filters (row filter `country='IN'`, column exclusion for email) and LF-Tags `pii=true` granted to finance only.
3. *A Redshift join between two big tables is slow; EXPLAIN shows DS_BCAST_INNER.* — the inner table is broadcast
   every query. Distribute both on the join key (KEY), or use ALL for small dimensions; check sort keys for filters.
4. *Step Functions or MWAA for a 5-step AWS-only nightly pipeline in a small team?* — Step Functions: no idle cost,
   native `.sync` integrations, simple. MWAA when there are many DAGs, non-AWS systems, or backfill needs.
