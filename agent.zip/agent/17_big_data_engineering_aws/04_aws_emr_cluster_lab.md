# 04 — AWS Foundations & Amazon EMR Cluster Lab (replaces GCP + Dataproc)

> **Why it matters:** the original course builds a Hadoop cluster on GCP Dataproc. On AWS the
> equivalent is **Amazon EMR**. EMR gives you HDFS, YARN, Spark, and Hive on EC2 in about 10 minutes,
> with S3 as durable storage. This module sets up a safe AWS account, launches a cluster the
> production way (transient, Spot, autoscaling, logs in S3), and drills the Linux and HDFS commands
> you'll use on it.

## In plain words

- **AWS account** = your own building. **IAM** = the badge system that decides who can open which door.
- **VPC/subnet** = the floors and rooms inside the building; your cluster lives in one room (one AZ).
- **S3** = an infinitely large, very durable warehouse across town. Your cluster comes and goes; the warehouse stays.
- **EMR** = a rental company that sets up a fully furnished Hadoop/Spark office (primary + workers) in
  minutes, then removes it when you leave, so you stop paying.

## Architecture at a glance — the lab environment

```mermaid
flowchart TB
  YOU[You: laptop<br/>AWS CLI via SSO]
  subgraph ACC["AWS account (region ap-south-1 or us-east-1)"]
    IAM[IAM Identity Center user<br/>+ EMR service role<br/>+ EMR EC2 instance profile]
    BUD[AWS Budgets alarm]
    subgraph VPC["VPC"]
      subgraph SUB["Subnet in ONE AZ"]
        P["Primary node<br/>NameNode, ResourceManager,<br/>HiveServer2, Spark History"]
        C1["Core node x2<br/>DataNode + NodeManager"]
        T1["Task nodes on Spot<br/>NodeManager only<br/>(autoscaled)"]
      end
      VPCE[S3 Gateway<br/>VPC endpoint]
    end
    S3[(S3 buckets<br/>data / code / logs)]
    CW[CloudWatch metrics]
  end
  YOU -->|aws emr create-cluster| ACC
  YOU -->|SSM Session Manager<br/>or SSH| P
  P --- C1 --- T1
  C1 & T1 -->|EMRFS via endpoint,<br/>no NAT cost| VPCE --> S3
  P -->|logs every 5 min| S3
  ACC --> CW
```

**How to read it:** you never use the root user; you log in through IAM Identity Center. The cluster
lives in one subnet. Core nodes hold HDFS and run tasks; task nodes run tasks only, so they're safe to put on
Spot and scale freely. An **S3 gateway endpoint** gives the cluster free, private access to S3, with no NAT
Gateway data charges. Logs land in S3, so you can debug even after the cluster terminates.

## 1. Dataproc → EMR concept mapping

| GCP Dataproc | Amazon EMR | Notes |
|---|---|---|
| Master node | **Primary node** (formerly "master") | 1 or 3 (HA) |
| Primary workers | **Core nodes** | run DataNode + NodeManager; scaling in is slow (HDFS decommission) |
| Secondary / preemptible workers | **Task nodes** on **Spot** | compute only, no HDFS → safe to lose |
| Image version (2.2-debian12) | **Release label** (`emr-7.x`) | pins Hadoop/Spark/Hive versions |
| Initialization actions | **Bootstrap actions** | scripts run on every node before apps start |
| Cluster properties | **Configurations** JSON (classifications) | `spark-defaults`, `yarn-site`, `hdfs-site`... |
| Jobs API | **Steps** API | `aws emr add-steps` |
| Component Gateway | EMR Studio / persistent application UIs / SSH tunnel | |
| Dataproc Serverless | **EMR Serverless** | no cluster, pay per vCPU-second / GB-second |
| GCS connector `gs://` | **EMRFS** `s3://` | |
| Autoscaling policy | **EMR Managed Scaling** | |
| Scheduled deletion (idle TTL) | **Auto-termination policy** (idle timeout) | |

## 2. Account setup — the safe way (one-time)

### 2.1 Lock down root and create a working identity

1. Sign up, enable **MFA on root**, then stop using root.
2. Enable **IAM Identity Center**, create a user, assign `AdministratorAccess` for the lab account
   (in companies: narrower permission sets).
3. On your laptop:

```bash
aws configure sso            # pick the account + permission set; profile name: bigdata
export AWS_PROFILE=bigdata
aws sts get-caller-identity  # verify: you are NOT root
```

### 2.2 Budget alarm (do this before launching anything)

```bash
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
aws budgets create-budget --account-id "$ACCOUNT_ID" \
  --budget '{"BudgetName":"bigdata-course","BudgetLimit":{"Amount":"25","Unit":"USD"},
             "TimeUnit":"MONTHLY","BudgetType":"COST"}' \
  --notifications-with-subscribers '[
    {"Notification":{"NotificationType":"ACTUAL","ComparisonOperator":"GREATER_THAN",
                     "Threshold":40,"ThresholdType":"PERCENTAGE"},
     "Subscribers":[{"SubscriptionType":"EMAIL","Address":"you@example.com"}]},
    {"Notification":{"NotificationType":"FORECASTED","ComparisonOperator":"GREATER_THAN",
                     "Threshold":100,"ThresholdType":"PERCENTAGE"},
     "Subscribers":[{"SubscriptionType":"EMAIL","Address":"you@example.com"}]}]'
```

### 2.3 S3 buckets and layout

```bash
export REGION=ap-south-1
export BUCKET=bigdata-course-$ACCOUNT_ID       # globally unique
aws s3 mb s3://$BUCKET --region $REGION
aws s3api put-public-access-block --bucket $BUCKET \
  --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
# default encryption is SSE-S3 on all new buckets; use SSE-KMS for sensitive data
```

```
s3://bigdata-course-<acct>/
├── raw/          # bronze: source files as received
├── curated/      # silver/gold outputs
├── code/         # .py scripts, jars, bootstrap actions
├── emr-logs/     # cluster + step logs
└── tmp/
```

Add a lifecycle rule to expire `tmp/` and `emr-logs/` after 14 days.

### 2.4 IAM roles EMR needs

| Role | Assumed by | Purpose |
|---|---|---|
| `EMR_DefaultRole` (service role) | EMR service | create EC2 instances, security groups, etc. |
| `EMR_EC2_DefaultRole` (instance profile) | every cluster node | the identity your Spark code uses to read/write S3, Glue Catalog |
| `EMR_AutoScaling_DefaultRole` | Application Auto Scaling | only for custom autoscaling (managed scaling doesn't need it) |

```bash
aws emr create-default-roles
# Optional: allow Session Manager instead of SSH keys
aws iam attach-role-policy --role-name EMR_EC2_DefaultRole \
  --policy-arn arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore
```

**Production note:** the default EC2 role is broad (S3 full access). In real projects, create a custom
instance profile limited to specific bucket prefixes and Glue databases, or use **EMR runtime roles**
(per-job IAM roles) with Lake Formation.

### 2.5 Networking

Use the default VPC for learning. For production: private subnets, **S3 gateway endpoint** (free), interface
endpoints for Glue/STS/CloudWatch/SSM if there's no NAT, security groups managed by EMR.

## 3. EMR node types and sizing

```mermaid
flowchart LR
  subgraph PRIMARY["Primary (1 or 3)"]
    NN[NameNode] --- RM[ResourceManager] --- HS2[HiveServer2] --- SHS[Spark History Server]
  end
  subgraph CORE["Core (≥1)"]
    DN[DataNode] --- NM1[NodeManager]
  end
  subgraph TASK["Task (0..n)"]
    NM2[NodeManager]
  end
  PRIMARY --> CORE
  PRIMARY --> TASK
```

| Node type | Runs | Purchase option | Scaling |
|---|---|---|---|
| Primary | master daemons | On-Demand (losing it kills the cluster unless 3 primaries) | fixed |
| Core | HDFS + YARN | On-Demand (or Spot only for throwaway clusters) | scale out fast, scale in slow |
| Task | YARN only | **Spot** (60–90% cheaper) | scale freely |

**Instance groups vs instance fleets:** groups = one instance type per group. **Fleets** = up to 5 types
(30 with allocation strategy) per node type plus Spot/On-Demand targets. That diversifies against Spot
capacity shortages. Prefer **fleets** with the `price-capacity-optimized` Spot allocation strategy in production.

**Sizing rule of thumb for learning:** 1 × `m7g.xlarge` primary + 2 × `m7g.xlarge` core (4 vCPU, 16 GB
each). Use `m5.xlarge` if your region lacks Graviton. Cost ≈ a few dollars per hour including the EMR
surcharge; terminate after each session.

## 4. Launch the cluster (CLI = reproducible)

```bash
SUBNET_ID=$(aws ec2 describe-subnets --filters Name=default-for-az,Values=true \
  --query 'Subnets[0].SubnetId' --output text)
aws emr list-release-labels --query 'ReleaseLabels[0:5]'   # pick the latest emr-7.x

cat > configs.json <<'EOF'
[
  {"Classification": "spark-defaults",
   "Properties": {"spark.sql.adaptive.enabled": "true",
                  "spark.dynamicAllocation.enabled": "true"}},
  {"Classification": "spark-hive-site",
   "Properties": {"hive.metastore.client.factory.class":
     "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory"}},
  {"Classification": "hive-site",
   "Properties": {"hive.metastore.client.factory.class":
     "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory"}}
]
EOF

CLUSTER_ID=$(aws emr create-cluster \
  --name "bigdata-lab" \
  --release-label emr-7.5.0 \
  --applications Name=Hadoop Name=Spark Name=Hive Name=Livy \
  --instance-groups \
     InstanceGroupType=MASTER,InstanceCount=1,InstanceType=m7g.xlarge \
     InstanceGroupType=CORE,InstanceCount=2,InstanceType=m7g.xlarge \
  --ec2-attributes SubnetId=$SUBNET_ID \
  --use-default-roles \
  --configurations file://configs.json \
  --log-uri s3://$BUCKET/emr-logs/ \
  --auto-termination-policy IdleTimeout=3600 \
  --managed-scaling-policy 'ComputeLimits={UnitType=Instances,MinimumCapacityUnits=3,MaximumCapacityUnits=8,MaximumOnDemandCapacityUnits=3,MaximumCoreCapacityUnits=3}' \
  --tags project=bigdata-course owner=$USER \
  --query ClusterId --output text)

aws emr wait cluster-running --cluster-id $CLUSTER_ID
aws emr describe-cluster --cluster-id $CLUSTER_ID \
  --query 'Cluster.{state:Status.State,dns:MasterPublicDnsName}'
```

What each flag buys you:

| Flag | Why |
|---|---|
| `--release-label` | reproducible versions (emr-7.x ships Spark 3.5, Hadoop 3.3/3.4, Hive 3.1) |
| Glue catalog classification | Hive and Spark tables are stored in the **Glue Data Catalog**, so they outlive the cluster and Athena can see them |
| `--log-uri` | step/container logs persist in S3 after termination |
| `--auto-termination-policy` | kills idle clusters — the most important cost control |
| `--managed-scaling-policy` | EMR adds/removes nodes based on YARN metrics; extra capacity beyond `MaximumOnDemandCapacityUnits` uses Spot task nodes where configured |
| `--tags` | cost allocation (replaces Azure resource groups) |

### Connect

```bash
# Option A: Session Manager (no open port 22)
PRIMARY_ID=$(aws emr list-instances --cluster-id $CLUSTER_ID --instance-group-types MASTER \
  --query 'Instances[0].Ec2InstanceId' --output text)
aws ssm start-session --target $PRIMARY_ID
sudo su - hadoop

# Option B: SSH (requires --ec2-attributes KeyName=... and port 22 open to your IP)
aws emr ssh --cluster-id $CLUSTER_ID --key-pair-file ~/.ssh/emr.pem
```

Web UIs: YARN RM `:8088`, Spark History `:18080`, NameNode `:9870`, HDFS DataNode `:9864`. Reach them via
SSM port forwarding (`AWS-StartPortForwardingSession`), an SSH tunnel, or the **persistent application UIs**
from the EMR console, which work even after termination.

## 5. Exploring the cluster

```bash
yarn node -list -all                 # NodeManagers and their state
hdfs dfsadmin -report                # capacity, live/dead DataNodes
hdfs getconf -confKey dfs.blocksize  # 134217728 = 128 MB
hdfs getconf -confKey dfs.replication
cat /etc/hadoop/conf/yarn-site.xml | grep -A1 'yarn.nodemanager.resource.memory-mb'
ls /usr/lib/spark /usr/lib/hadoop /usr/lib/hive
sudo systemctl status hadoop-hdfs-namenode     # services are systemd units
spark-submit --version
```

## 6. Linux commands that matter for data engineers

Basic `cd`/`ls` are assumed. These are the ones you'll actually use when debugging clusters and data:

| Task | Command |
|---|---|
| Disk usage by directory | `du -sh /mnt/* \| sort -h` |
| Free disk / memory | `df -h`, `free -g` |
| Peek at big files without loading them | `head -n 5 f.csv`, `tail -f app.log`, `less +F app.log` |
| Count lines / records | `wc -l f.csv` |
| Top values in a column | `cut -d',' -f3 f.csv \| sort \| uniq -c \| sort -rn \| head` |
| Filter + aggregate | `awk -F',' '$5>100 {s+=$5} END {print s}' f.csv` |
| Search logs recursively | `grep -rn "OutOfMemoryError" /var/log/hadoop-yarn/` |
| Find big / old files | `find /mnt -size +1G -mtime +7 -print` |
| Batch operations | `find . -name '*.gz' \| xargs -P 8 -n 1 gunzip` |
| Compressed files | `zcat f.gz \| head`, `tar -czf out.tgz dir/` |
| Processes / JVMs | `ps aux --sort=-%mem \| head`, `jps -l`, `top -o %MEM` |
| Ports in use | `ss -tlnp \| grep 8088` |
| Long-running jobs that survive disconnect | `tmux new -s job` or `nohup cmd > out.log 2>&1 &` |
| Permissions | `chmod 640 f`, `chown hadoop:hadoop f` |
| Copy between machines | `scp`, `rsync -avP src/ host:dst/` |
| Environment | `env \| grep -i spark`, `export PYSPARK_PYTHON=python3` |

## 7. HDFS commands

```bash
# Navigation and metadata
hdfs dfs -ls -h /user/hadoop
hdfs dfs -ls -R /data | head
hdfs dfs -du -s -h /data/*          # logical size (multiply by RF for raw)
hdfs dfs -count -q -h /data         # dirs, files, bytes, quotas — spot small-file problems
hdfs dfs -stat "%r %o %b %n" /data/orders.csv   # replication, block size, bytes, name

# Moving data in/out
hdfs dfs -mkdir -p /data/raw
hdfs dfs -put -f orders.csv /data/raw/
hdfs dfs -get /data/out/part-00000 .
hdfs dfs -getmerge /data/out/ merged.csv
hdfs dfs -cat /data/raw/orders.csv | head
hdfs dfs -tail /data/raw/orders.csv
hdfs dfs -mv /data/raw/a /data/archive/
hdfs dfs -rm -r -skipTrash /data/tmp   # -skipTrash frees space immediately

# Replication, permissions, health
hdfs dfs -setrep -w 2 /data/raw/orders.csv
hdfs dfs -chmod -R 750 /data/secure
hdfs fsck /data/raw/orders.csv -files -blocks -locations   # see each block and which DNs hold it
hdfs fsck / | tail -20                                       # under-replicated / missing / corrupt
hdfs dfsadmin -safemode get
hdfs balancer -threshold 10

# HDFS <-> S3 (bulk copy as a MapReduce job)
hadoop distcp hdfs:///data/raw s3://$BUCKET/raw/
s3-dist-cp --src s3://$BUCKET/raw/ --dest hdfs:///data/raw --groupBy '.*(orders).*' --targetSize 256
```

**Lab exercise:** upload a 1 GB file (`fallocate -l 1G big.bin` locally, or a real dataset), then run `hdfs
fsck ... -files -blocks -locations`. Verify 8 blocks. On a 2-core-node cluster, verify replication = 1 (EMR
default for < 4 core nodes). Set it to 2 with `-setrep -w 2` and check the locations again.

## 8. Running work: Steps

```bash
aws s3 cp wordcount.py s3://$BUCKET/code/
aws emr add-steps --cluster-id $CLUSTER_ID --steps \
  'Type=Spark,Name=wordcount,ActionOnFailure=CONTINUE,Args=[--deploy-mode,cluster,s3://'$BUCKET'/code/wordcount.py,s3://'$BUCKET'/raw/,s3://'$BUCKET'/curated/wc/]'
aws emr list-steps --cluster-id $CLUSTER_ID --query 'Steps[0].Status'
```

Transient pattern (production batch): `create-cluster ... --steps file://steps.json --auto-terminate`. The
cluster boots, runs the steps, and shuts down. Airflow's `EmrCreateJobFlowOperator` +
`EmrAddStepsOperator` + `EmrJobFlowSensor` automate this (module 19).

## 9. EMR deployment options — which one when

| Option | You manage | Best for |
|---|---|---|
| **EMR on EC2** | cluster size, instance types, configs | full control, HDFS/HBase, long-running shared clusters, custom tuning |
| **EMR Serverless** | nothing but the job | spiky batch Spark/Hive jobs, no idle cost, simple ops |
| **EMR on EKS** | Kubernetes cluster | organizations standardized on K8s, mixing Spark with other workloads |
| **AWS Glue** (module 22) | nothing; DPUs | ETL with catalog integration, crawlers, bookmarks |

```bash
APP_ID=$(aws emr-serverless create-application --name lab --type SPARK \
  --release-label emr-7.5.0 --query applicationId --output text)
aws emr-serverless start-job-run --application-id $APP_ID \
  --execution-role-arn arn:aws:iam::$ACCOUNT_ID:role/EMRServerlessJobRole \
  --job-driver '{"sparkSubmit":{"entryPoint":"s3://'$BUCKET'/code/wordcount.py",
     "entryPointArguments":["s3://'$BUCKET'/raw/","s3://'$BUCKET'/curated/wc/"],
     "sparkSubmitParameters":"--conf spark.executor.cores=4 --conf spark.executor.memory=8g"}}'
```

## 10. EMR best practices (replaces "GCP cluster best practices")

1. **S3 is the source of truth**; HDFS only for intermediate data. Clusters are cattle.
2. **Transient clusters per pipeline** or EMR Serverless, not one giant forever-cluster.
3. **Auto-termination** always on for interactive clusters.
4. **Spot for task nodes** via instance fleets with 5+ instance types; On-Demand for primary/core.
5. **Graviton** instances: typically ~20–30% better price-performance.
6. **Glue Data Catalog** as metastore so tables survive cluster deletion.
7. **Logs to S3**, metrics to CloudWatch; enable persistent application UIs.
8. **Least-privilege** instance profile / runtime roles; SSE-KMS; private subnets + endpoints.
9. **Bootstrap actions** for OS packages only; ship Python dependencies as a packed venv/zip.
10. **Tag everything** for cost allocation.

## Teardown (always)

```bash
aws emr terminate-clusters --cluster-ids $CLUSTER_ID
aws emr wait cluster-terminated --cluster-id $CLUSTER_ID
aws emr-serverless delete-application --application-id $APP_ID   # if created
aws emr list-clusters --active   # should be empty
```

## Key takeaways

- EMR = Dataproc on AWS: primary/core/task nodes, release labels, bootstrap actions, steps.
- Core nodes hold HDFS (On-Demand); task nodes are compute-only (Spot, autoscaled).
- Use Glue Data Catalog as metastore and S3 as storage, so clusters can be transient.
- Always enable auto-termination, budgets, and logs to S3.
- EMR Serverless removes cluster management entirely for batch jobs.

## Interview scenarios

1. *Your EMR cluster lost 30% of its nodes and jobs failed with missing HDFS blocks. What went wrong in
   the design?* — Core nodes were on Spot, and the data/intermediate output lived only in HDFS. Put core on
   On-Demand, use Spot only for task nodes, write outputs to S3, use instance fleets for Spot diversity.
2. *A cluster costs \$9k/month but runs jobs 3 hours/day. Fix?* — transient clusters per run (or EMR
   Serverless), auto-termination, Spot task nodes, Graviton. Should drop cost by roughly 80%+.
3. *Reviewing a new hire's first cluster setup:* flags to check — root user used? public S3 bucket? port 22
   open to 0.0.0.0/0? no auto-termination? logs not in S3? metastore local (tables lost on termination)?
   all nodes On-Demand at max size? no tags?
4. *Why does HDFS on a 3-node EMR cluster have replication 1?* — EMR sets `dfs.replication` from the core node
   count (<4 → 1) because the cluster is assumed transient with data in S3.
