# 01 — Big Data Foundations: What, Why, and Where It Lives

> **Why it matters:** every tool in this course (HDFS, Spark, Kafka, Redshift, Delta) is an answer to
> one question — *what do you do when data no longer fits on, or can't be processed fast enough by,
> one machine?* If you understand the forces (volume, velocity, failure, cost), you can predict how
> each tool is designed before you read its docs.

## In plain words

Imagine a library that receives **one truck of books per second**.

- One librarian (one server) can't even unload them, let alone catalog them. You hire **many
  librarians** and split the work — that's **distributed processing**.
- You store books across **many rooms** with **copies in different rooms** so a fire doesn't lose
  anything — that's **distributed, replicated storage** (HDFS, S3).
- Some books arrive as tidy, catalogued boxes (structured tables), some as loose photos and letters
  (unstructured). A **warehouse** only accepts tidy boxes; a **lake** accepts everything and sorts later.
- **ETL** = clean and sort books *before* shelving. **ELT** = shelve them as-is, clean later using the
  library's own staff (the warehouse/lake compute).

## Architecture at a glance — a modern AWS data platform

```mermaid
flowchart LR
  subgraph SRC["Sources"]
    OLTP[("OLTP DBs<br/>RDS MySQL/Postgres")]
    APP[App events<br/>clickstream]
    SAAS[SaaS / HTTP APIs]
    FILES[Files / logs]
  end
  subgraph ING["Ingestion"]
    DMS[AWS DMS<br/>CDC]
    MSK[MSK / Kinesis<br/>streaming]
    GLUEI[Glue jobs /<br/>Lambda / AppFlow]
  end
  subgraph LAKE["S3 data lake — medallion"]
    BR[Bronze<br/>raw, immutable]
    SI[Silver<br/>cleaned, conformed]
    GO[Gold<br/>business aggregates]
  end
  subgraph PROC["Processing"]
    EMR[EMR / EMR Serverless<br/>Spark]
    GLUE[Glue ETL<br/>Spark]
    DBX[Databricks on AWS]
  end
  CAT[(Glue Data Catalog<br/>+ Lake Formation)]
  subgraph SERVE["Serving"]
    ATH[Athena]
    RS[Redshift]
    QS[QuickSight / BI]
    ML[SageMaker / ML]
  end
  ORCH[MWAA Airflow /<br/>Step Functions]

  OLTP --> DMS --> BR
  APP --> MSK --> BR
  SAAS --> GLUEI --> BR
  FILES --> BR
  BR --> PROC --> SI --> PROC --> GO
  CAT -.metadata.- LAKE
  GO --> ATH --> QS
  GO --> RS --> QS
  SI --> ML
  ORCH -.schedules.- ING
  ORCH -.schedules.- PROC
```

**How to read it:** data flows left to right. Sources are copied into **bronze** untouched (so you can
always replay). Spark engines (EMR, Glue, Databricks) refine bronze → silver → gold. The **Glue Data
Catalog** stores table definitions so every engine sees the same tables. Athena/Redshift serve SQL to
BI and analysts. Airflow or Step Functions orchestrate the whole thing on a schedule.

## 1. What is "big data", concretely?

Big data is **not** a size threshold. It's the point where the *single-machine approach breaks*:

| Signal | Example |
|---|---|
| Doesn't fit in RAM | 500 GB of orders; pandas on a 64 GB laptop dies |
| Doesn't fit on one disk | 200 TB of clickstream |
| Too slow on one machine | 2 TB scan at ~200 MB/s from one disk ≈ **2.8 hours**; split across 100 disks ≈ **1.7 minutes** |
| Arrives too fast | 1 M events/second; one process can't even deserialize them |
| Must survive failure | a server dies every day in a 1,000-node fleet |

**Worked example — why parallelism is forced on you.** One HDD reads ~150–200 MB/s; one NVMe SSD maybe
2–3 GB/s. Scanning 10 TB:

- 1 HDD @ 200 MB/s: \(10{,}000{,}000 / 200 = 50{,}000\) s ≈ **14 hours**
- 100 nodes × 4 disks @ 200 MB/s = 80 GB/s → \(10{,}000 / 80 = 125\) s ≈ **2 minutes**

The disk throughput wall, not CPU, is what created Hadoop.

## 2. The 5 V's (and what each forces on the architecture)

| V | Meaning | Architectural consequence |
|---|---|---|
| **Volume** | TB → PB | horizontal storage (HDFS, S3), columnar formats (Parquet), partitioning |
| **Velocity** | speed of arrival | streaming (Kafka/MSK, Kinesis), micro-batches, backpressure |
| **Variety** | structured, semi (JSON), unstructured (images, logs) | schema-on-read, data lakes, flexible formats |
| **Veracity** | quality/trustworthiness | data quality checks (Glue Data Quality, Great Expectations), lineage, quarantine tables |
| **Value** | business usefulness | gold layer, SLAs, cost controls — big data with no consumer is just a bill |

Interviewers sometimes add **Variability** (meaning/shape changes over time → schema evolution) and
**Visualization**.

## 3. Big data and distributed systems

### Scale up vs scale out

```
 SCALE UP (vertical)                SCALE OUT (horizontal)
 ┌──────────────┐                   ┌────┐ ┌────┐ ┌────┐ ┌────┐
 │  1 huge box  │                   │node│ │node│ │node│ │node│ ...
 │ 448 vCPU,24TB│                   └────┘ └────┘ └────┘ └────┘
 └──────────────┘                     cheap commodity, add more
 + simple, no network               + near-linear capacity, survives failures
 - price grows super-linearly       - network, coordination, partial failure
 - hard ceiling, single point        - you need a framework (Hadoop/Spark)
   of failure
```

### Fundamental problems every distributed data system must solve

| Problem | How big-data systems answer it |
|---|---|
| **Partitioning** — how to split data | HDFS blocks, Kafka partitions, Spark partitions, S3 prefixes, hash/range keys |
| **Replication** — survive node loss | HDFS 3× replicas, Kafka ISR, S3 (11 nines durability, multi-AZ) |
| **Data locality** — moving data is expensive | ship code to data (MapReduce, Spark on HDFS) |
| **Coordination** — who is the leader | NameNode, YARN RM, Kafka controller (KRaft), ZooKeeper |
| **Partial failure** — some nodes slow/dead | retries, speculative execution, lineage recomputation (Spark), idempotent writes |
| **Consistency** | S3 is strongly read-after-write consistent (since Dec 2020); Kafka offers per-partition ordering |

### CAP and PACELC in one paragraph

During a network **P**artition, a system must choose **C**onsistency (refuse some requests) or
**A**vailability (answer, maybe stale). PACELC adds: **E**lse, even when healthy, you trade **L**atency
vs **C**onsistency. HDFS NameNode chooses C (no split-brain — fencing). Kafka with `acks=all` +
`min.insync.replicas=2` chooses C for writes. DynamoDB eventually consistent reads choose A/L.

### Network cost numbers worth memorizing

| Operation | Approx latency |
|---|---|
| Main memory reference | 100 ns |
| Read 1 MB sequentially from memory | ~3–10 µs |
| Read 1 MB from NVMe SSD | ~50–100 µs |
| Round trip within same AZ | ~0.1–0.5 ms |
| Read 1 MB from HDD | ~2–5 ms |
| Cross-region round trip | 60–150 ms |

**Read it as:** a shuffle (sending data over the network to other nodes) is 10–100× more expensive than
reading locally. Most Spark tuning (module 14) is "shuffle less".

## 4. Designing a good big data system — the checklist

1. **Scalable**: adding nodes adds throughput roughly linearly (no single bottleneck).
2. **Fault tolerant**: assume nodes, disks, AZs fail; design for replay (immutable raw layer).
3. **Idempotent**: re-running a job for the same date gives the same result (overwrite partitions, not append blindly).
4. **Decoupled storage & compute**: S3 + transient compute beats HDFS-bound clusters on cost.
5. **Schema managed**: catalog, contracts, evolution rules.
6. **Observable**: row counts, freshness, data quality metrics, lineage, cost per pipeline.
7. **Secure & governed**: encryption (SSE-KMS), least-privilege IAM, Lake Formation, PII masking.
8. **Cost-aware**: columnar formats, partition pruning, Spot, lifecycle rules to Glacier.

## 5. On-premise vs cloud

| Dimension | On-prem Hadoop | AWS cloud |
|---|---|---|
| Capacity | buy for peak; 3–6 month procurement | elastic, minutes |
| Cost model | CapEx + staff; cheap at constant 24/7 high use | OpEx; cheap for bursty workloads, expensive if left running |
| Storage/compute | coupled (HDFS on the same nodes) | decoupled (S3 + EMR/Glue/Athena) |
| Ops | you patch, upgrade, replace disks | managed services |
| Data gravity / sovereignty | full control | regions, KMS, PrivateLink; must design for it |

**Rule of thumb:** steady-state, fully utilized clusters can be cheaper on-prem; spiky, exploratory,
or fast-growing workloads win in the cloud. Most companies run **ephemeral compute on S3**.

## 6. Database vs Data Warehouse vs Data Lake vs Lakehouse

```mermaid
flowchart TB
  subgraph DB["Database (OLTP)"]
    D1[Row-oriented<br/>small fast txns<br/>normalized 3NF]
  end
  subgraph DW["Data Warehouse (OLAP)"]
    W1[Columnar, MPP<br/>schema-on-write<br/>star schema]
  end
  subgraph DL["Data Lake"]
    L1[Files on object storage<br/>any format<br/>schema-on-read]
  end
  subgraph LH["Lakehouse"]
    H1[Files on S3 + table format<br/>Delta / Iceberg / Hudi<br/>ACID + time travel]
  end
  DB -->|ETL/ELT| DW
  DB -->|raw copy| DL
  DL -->|add transactions<br/>+ metadata layer| LH
```

| | Database (OLTP) | Data warehouse (OLAP) | Data lake | Lakehouse |
|---|---|---|---|---|
| Purpose | run the app | analytics/BI | store everything cheaply, ML | lake cost + warehouse reliability |
| Workload | many small reads/writes by key | few huge scans + aggregates | batch processing, exploration | both |
| Storage layout | row-oriented (B-tree) | columnar, compressed | files (Parquet, JSON, CSV, images) | Parquet + transaction log |
| Schema | on write, strict | on write, modeled (star/snowflake) | on read | on write with evolution |
| ACID | yes | yes | no (files) | yes |
| AWS | RDS, Aurora, DynamoDB | Redshift | S3 + Glue Catalog + Athena | S3 + Iceberg/Delta + Glue/Athena/EMR/Databricks |

### Why columnar storage wins analytics

Table: 1 billion rows × 100 columns × 8 bytes = 800 GB. Query: `SELECT avg(price) FROM sales WHERE year=2025`.

- **Row store** reads every row → ~800 GB.
- **Column store** reads only `price` and `year` → 2 × 8 GB = 16 GB, then compression (often 5–10×) → ~2–3 GB.
- With **partitioning** by year (10 years), it reads 1/10 → ~0.3 GB.

That 2,000× reduction is the whole reason Parquet + partitioning + Athena work.

### Star schema (warehouse modeling) in 30 seconds

```
              dim_customer
                   │
 dim_product ── fact_sales ── dim_date
                   │
               dim_store
```

Facts = measurable events (one row per order line). Dimensions = descriptive context. Slowly Changing
Dimensions **Type 1** overwrite, **Type 2** add a new row with `valid_from/valid_to/is_current`.

## 7. ETL vs ELT

```mermaid
flowchart LR
  subgraph ETL["ETL (classic)"]
    S1[Source] --> T1[Transform server<br/>Informatica / Glue / Spark] --> L1[(Warehouse)]
  end
  subgraph ELT["ELT (modern)"]
    S2[Source] --> L2[(Lake / Warehouse<br/>raw tables)] --> T2[Transform inside<br/>SQL: dbt on Redshift/Athena<br/>or Spark on lake]
  end
```

| | ETL | ELT |
|---|---|---|
| Where transform runs | separate engine before load | inside target (warehouse/lakehouse) |
| Raw data kept? | often not | yes — replay anytime |
| Best when | strict compliance (mask PII before landing), limited target compute | cheap storage, elastic compute (Redshift, Athena, Spark) |
| Tools on AWS | Glue ETL, EMR Spark → Redshift | land in S3/Redshift → dbt / Redshift SQL / Athena CTAS |

Modern pipelines are usually **EtLT**: light cleanup (PII hashing, format conversion) at ingest, heavy
modeling later.

## 8. What does a (big) data engineer actually do?

```mermaid
flowchart LR
  P[Producers<br/>apps, DBs, devices] --> DE[Data engineer builds:<br/>ingestion, storage layout,<br/>transforms, orchestration,<br/>quality, governance, cost]
  DE --> DA[Data analysts<br/>SQL / BI]
  DE --> DS[Data scientists<br/>features, training]
  DE --> APPS[Data products<br/>APIs, reverse ETL]
```

Daily work: build and fix pipelines; model tables; tune slow Spark jobs; set SLAs and alerting; handle
schema changes; control cloud spend; enforce access control. Where big data fits: when volume/velocity
exceed single-machine tools, the engineer moves from pandas/cron to Spark/Kafka/Airflow on distributed
infrastructure.

## 9. Real business scenario mapping (exercise with solution)

> *An e-commerce company: 50 M orders/year in MySQL, 2 B clickstream events/day, product images,
> and a requirement for hourly dashboards and daily ML recommendations.*

| Need | Design on AWS | V addressed |
|---|---|---|
| Copy orders without hurting MySQL | DMS CDC → S3 bronze (Parquet) | Volume |
| 2 B events/day ≈ 23 k/s avg, peaks 100 k/s | MSK or Kinesis → Firehose/Spark Structured Streaming → S3 | Velocity |
| Images + JSON + tables | S3 lake, catalog only the structured parts | Variety |
| Bad events (nulls, bots) | Glue Data Quality rules, quarantine prefix | Veracity |
| Hourly dashboards | gold tables partitioned by `dt/hour`, Athena + QuickSight | Value |
| ML recommendations | silver features → SageMaker | Value |

**Explaining to a non-technical stakeholder:** "We keep an untouched copy of everything (so mistakes are
fixable), clean it in stages, and only pay for computers while they're working. Dashboards read a small
pre-summarized version, which is why they're fast and cheap."

## Key takeaways

- Big data = when single-machine storage, throughput, or reliability breaks. Disk throughput forced parallelism.
- Distributed systems must solve partitioning, replication, locality, coordination, and partial failure.
- Columnar + compression + partitioning can cut scanned bytes by 1,000× — the basis of lake analytics.
- Lakehouse = S3 files + a table format (Delta/Iceberg) giving ACID, schema evolution, time travel.
- Modern AWS pattern: decouple storage (S3) from transient compute (EMR/Glue/Athena), keep raw data immutable.

## Interview scenarios

1. *Your team wants to put 300 GB of daily logs into RDS Postgres for analytics. Response?* — OLTP is
   row-oriented and single-node; analytic scans will be slow and expensive. Land in S3 as partitioned
   Parquet, catalog in Glue, query with Athena; move curated aggregates to Redshift if concurrency/latency demand it.
2. *ETL or ELT for a healthcare feed with PII?* — EtLT: tokenize/hash PII during ingest (so raw PII never
   lands broadly), then ELT for modeling. Encrypt with KMS, restrict via Lake Formation.
3. *Why do we keep a bronze layer if silver is "correct"?* — replay after bugs, schema changes, new
   business logic, audits. Storage is cheap; re-extracting from sources may be impossible.
4. *Is S3 a data lake?* — S3 is storage. A lake also needs a catalog (Glue), access control (Lake
   Formation/IAM), formats/layout conventions, and processing engines.
