# 24 — Cheat Sheet & Interview Scenarios

> One page of numbers and defaults to memorize, a decision guide for AWS services, and worked answers to
> the system-design and debugging questions that come up in big-data engineering interviews.

## 1. Numbers & defaults

| Area | Default / number |
|---|---|
| HDFS block size | 128 MB |
| HDFS replication | 3 (EMR: 1 if < 4 core nodes, 2 if 4–9, 3 if ≥ 10) |
| NameNode memory | ~150 bytes per file/block/dir object; ~1 GB heap per 1 M blocks |
| DataNode heartbeat / dead after | 3 s / ~10.5 min (stale after 30 s) |
| Full block report interval | 6 h |
| Secondary NN checkpoint | every 1 h or 1 M transactions |
| Write packet / checksum chunk | 64 KB / 512 bytes |
| MR sort buffer / spill threshold | 100 MB / 80% |
| MR default reducers | 1 |
| Spark SQL shuffle partitions | 200 |
| Spark `maxPartitionBytes` / `openCostInBytes` | 128 MB / 4 MB |
| Broadcast join threshold | 10 MB |
| AQE | on (3.2+); advisory partition 64 MB; skew = > 5× median and > 256 MB |
| Spark memory | reserved 300 MB; unified = 60% of rest; storage fraction 0.5; overhead max(384 MB, 10%) |
| RDD `cache()` / DF `cache()` | MEMORY_ONLY / MEMORY_AND_DISK |
| Executor cores sweet spot | ~5 |
| Kafka retention | 7 days; segment 1 GB |
| Kafka durability recipe | RF 3, `min.insync.replicas=2`, `acks=all`, idempotence on |
| Kafka consumer | `max.poll.interval.ms` 5 min, `session.timeout.ms` 45 s, `auto.offset.reset=latest` |
| Kinesis shard | 1 MB/s or 1,000 rec/s in, 2 MB/s out; 24 h default retention (up to 365 d) |
| S3 request rate | 3,500 writes / 5,500 reads per second per prefix |
| Athena price | \$5 per TB scanned (10 MB minimum per query) |
| Glue DPU | 4 vCPU + 16 GB (G.1X = 1 DPU) |
| Delta VACUUM retention | 7 days |
| Target file size in lakes | 128 MB–1 GB |
| Airflow 3 catchup default | False |

## 2. AWS service decision guide

```mermaid
flowchart TD
  Q1{Batch or streaming?} -->|streaming| S1{Kafka ecosystem<br/>needed? Debezium,<br/>Connect, portability}
  S1 -->|yes| MSK[MSK / MSK Serverless]
  S1 -->|no| KDS[Kinesis Data Streams<br/>+ Firehose / Lambda / Flink]
  Q1 -->|batch| B1{Spark needed?}
  B1 -->|no, SQL on S3| ATH[Athena CTAS / views]
  B1 -->|no, warehouse modeling| RS[Redshift + dbt]
  B1 -->|yes| B2{Ops appetite}
  B2 -->|none, catalog-centric ETL| GLUE[Glue ETL]
  B2 -->|none, plain Spark jobs| EMRS[EMR Serverless]
  B2 -->|full control / HDFS / HBase / long-running| EMR[EMR on EC2]
  B2 -->|platform: notebooks, ML, governance| DBX[Databricks on AWS]
  Q2{Orchestration} -->|AWS-only, event-driven, serverless| SFN[Step Functions + EventBridge]
  Q2 -->|many DAGs, cross-platform, backfills| MWAA[MWAA]
  Q3{Serving} -->|ad hoc, infrequent| ATH2[Athena]
  Q3 -->|high-concurrency BI, SLAs| RS2[Redshift Serverless/RA3]
```

## 3. Debugging playbook (symptom → cause → fix)

| Symptom | Likely cause | Fix |
|---|---|---|
| One Spark task runs 50× longer than the median | key skew | AQE skew join, salting, broadcast, isolate nulls |
| Job reads a big file with 1 task | gzip / non-splittable | splittable format; repartition after read |
| 100k tiny output files | tasks × partition values | `repartition(partition_cols)` before `partitionBy`; compaction |
| Container killed, exit 137 / "exceeding physical memory" | overhead too small, PySpark/Arrow memory | raise `memoryOverhead`, fewer cores per executor |
| Driver OOM | `collect`, `toPandas`, big broadcast, millions of files | remove collect, cap broadcast, compact files, more driver memory |
| YARN app stuck in ACCEPTED | queue full / AM limit | queue capacity, `maximum-am-resource-percent`, scaling |
| Athena query expensive | CSV / unpartitioned / `SELECT *` | Parquet + partitions + projection + select columns |
| New S3 data invisible in Athena | partitions not registered | partition projection, MSCK, crawler, Iceberg |
| Table vanished after cluster termination | local Derby/Hive metastore or temp view | Glue Data Catalog, external tables |
| Rerun doubled the data | `append` writes | dynamic partition overwrite, MERGE, upserts |
| Kafka messages "missing" | `latest` offset reset, no `flush()`, `acks=1`, commit before processing, retention | see module 17 table |
| Consumer group rebalancing constantly | processing > `max.poll.interval.ms` | smaller batches, faster processing, cooperative-sticky, static membership |
| Airflow DAG not running | paused, import error, start_date/interval, pools | module 19 checklist |
| Glue job reprocesses old files | bookmarks off or missing `transformation_ctx` / `job.commit()` | enable bookmarks correctly |
| Redshift join slow, `DS_BCAST_INNER` | bad distribution | DISTKEY on join key or DISTSTYLE ALL for small dims |

## 4. System-design scenarios (with model answers)

### 4.1 Clickstream analytics: 2 B events/day, dashboards within 5 minutes

```mermaid
flowchart LR
  SDK[Web/mobile SDK] --> API[API GW / ALB collector] --> K[MSK or Kinesis<br/>partition by session_id]
  K --> SS[Spark Structured Streaming / Flink<br/>dedupe by event_id, watermark 10 min]
  SS --> B[(Iceberg bronze<br/>partition by event_hour)]
  B --> AGG[5-min aggregates job] --> G[(Iceberg gold)]
  G --> RS[Redshift / Athena] --> QS[QuickSight]
  K --> FH[Firehose → S3 raw archive]
  CMP[Hourly compaction +<br/>snapshot expiry] -.-> B
```

Key points: ~23 k events/s average, size partitions for peak (e.g. 100 k/s × 1 KB = 100 MB/s → Kinesis 100+
shards or MSK with ~50–100 partitions). Idempotent processing via `event_id` dedupe within a watermark.
Checkpoints in S3 for exactly-once file sinks. Compaction for small files. A raw archive for replay. Late
data handled with watermarks plus a daily correction batch.

### 4.2 CDC from Aurora MySQL into a lakehouse

DMS (or Debezium on MSK Connect) reads the binlog → S3 bronze change records (`op`, `ts`, row) → Spark job
MERGEs into Iceberg/Delta silver ordered by commit timestamp (dedupe the latest change per key within a batch;
deletes → `WHEN MATCHED AND op='D' THEN DELETE`) → gold aggregates. Alternative for warehouse-only needs:
**zero-ETL** Aurora → Redshift.

### 4.3 Slowly Changing Dimension Type 2 in Spark + Delta

```sql
MERGE INTO silver.dim_customer t
USING (
  -- rows to close: changed customers (match on key)  +  rows to insert: new versions (NULL merge key)
  SELECT s.customer_id AS merge_key, s.* FROM staging_customers s
  UNION ALL
  SELECT NULL AS merge_key, s.* FROM staging_customers s
  JOIN silver.dim_customer d ON s.customer_id = d.customer_id AND d.is_current
  WHERE s.city <> d.city OR s.segment <> d.segment
) u
ON t.customer_id = u.merge_key AND t.is_current
WHEN MATCHED AND (t.city <> u.city OR t.segment <> u.segment) THEN
  UPDATE SET is_current = false, valid_to = u.updated_at
WHEN NOT MATCHED THEN
  INSERT (customer_id, city, segment, valid_from, valid_to, is_current)
  VALUES (u.customer_id, u.city, u.segment, u.updated_at, NULL, true);
```

**Read it as:** each changed customer appears twice in the source. The keyed copy closes the current row;
the NULL-keyed copy never matches, so it inserts the new current version. Brand-new customers insert once
through the keyed copy.

### 4.4 Cut a \$60k/month EMR bill

1. Measure: cost by cluster/tag and utilization (YARN memory used vs available).
2. Long-running idle clusters → transient clusters per pipeline / EMR Serverless; auto-termination.
3. Spot task nodes via instance fleets (5+ types); Graviton.
4. Right-size executors (~5 cores), AQE, fix skew and small files (fewer task-hours).
5. Storage: CSV/JSON → Parquet/ZSTD, partition pruning (less I/O = less runtime); S3 lifecycle for old raw data.
6. Move ad-hoc SQL to Athena; schedule heavy jobs off-peak.

### 4.5 Late-arriving data in daily partitions

Partition by **event date**, but process by **arrival window**. Each run reprocesses affected event-date
partitions (dynamic partition overwrite or MERGE), tracked by a manifest of which dates received new data.
Streaming: watermarks bound state, and a daily batch fixes stragglers beyond the watermark.

### 4.6 Exactly-once from Kafka to S3

Spark Structured Streaming with a checkpoint directory (offsets + commit log) + an idempotent/transactional
sink (file sink with a metadata log, Delta/Iceberg commits). On restart, Spark replays from the last committed
offsets, and the sink ignores already-committed batches. For external DBs: upserts keyed by a business ID.

## 5. Rapid-fire concept questions

| Question | One-line answer |
|---|---|
| Block vs split? | block = physical storage unit; split = logical unit of work for one mapper/partition |
| Secondary vs Standby NN? | checkpoint helper vs hot failover replica (QJM + ZKFC) |
| Why rack awareness? | survive rack loss with only one cross-rack write hop |
| Combiner rule? | operation must be associative and commutative |
| YARN RM vs AM? | cluster-wide allocation vs per-application task negotiation |
| Narrow vs wide? | no shuffle (partition-local) vs shuffle (cross-partition dependency) |
| Why is Spark lazy? | whole-plan optimization, pipelining, pruning, lineage recovery |
| reduceByKey vs groupByKey? | map-side combine vs shipping all values |
| repartition vs coalesce? | shuffle and balanced vs no shuffle and may collapse upstream parallelism |
| cache vs persist vs checkpoint? | default level vs chosen level vs saved with lineage truncated |
| Client vs cluster deploy mode? | driver on submitter vs driver in YARN AM |
| BHJ vs SMJ? | broadcast the small side (no big shuffle) vs shuffle + sort both sides |
| Managed vs external table? | DROP deletes data vs DROP keeps data |
| Temp vs global temp view? | session scope vs application scope (`global_temp`) |
| Parquet vs Avro? | columnar for analytics vs row-based for streaming/writes and schema evolution |
| Partitioning vs bucketing? | directory per value (pruning) vs N hashed files (join/shuffle avoidance) |
| Kafka ordering guarantee? | per partition only |
| At-least-once recipe? | process then commit, idempotent sink |
| Delta ACID mechanism? | atomic log commits + optimistic concurrency + snapshot reads |
| Athena vs Redshift? | serverless pay-per-scan lake SQL vs provisioned/serverless MPP warehouse |
| Glue job bookmarks? | state of processed inputs for incremental runs |
| Lake Formation vs IAM? | table/column/row grants with vended credentials vs coarse S3/API permissions |
| ETL vs ELT? | transform before loading vs load raw and transform inside the target |
| Lake vs lakehouse? | files with schema-on-read vs files + table format with ACID and governance |

## 6. Behavioral / stakeholder prompts (from the course exercises)

| Prompt | Structure of a strong answer |
|---|---|
| Explain big data to a non-technical stakeholder | the problem (too big/fast for one machine) → the idea (split, copy, parallelize) → the business outcome (fresh dashboards, lower cost) |
| Explain Hadoop's components to a new teammate | storage (HDFS/S3) → resources (YARN) → engines (MR/Spark) → SQL (Hive/Athena) → ingest/orchestrate |
| Cracking the HDFS round | draw the architecture, then do block math, then explain the write pipeline and failure handling |
| Debugging a slow MapReduce / Spark job | evidence first: counters/UI → classify (skew, spill, small files, shuffle) → targeted fix → measure |
| Should we cache this dataset? | reuse count × recompute cost vs memory pressure → decision + unpersist |
| Picking the right deployment mode | interactive → client; production → cluster or serverless |
| Live NameNode / pipeline outage | impact → mitigation → root cause → prevention (monitoring, drills) |
| Why isn't my DAG running? | checklist: import errors → paused → dates → concurrency → infra |
| Fixing a failing load step | reproduce → root cause (non-idempotent insert, network) → fix + test + guardrail |
| Explaining where our data lives (Databricks) | our S3, our account, our keys; Databricks = compute + catalog |

## Key takeaways

- Memorize the defaults table. Interviewers use them to check hands-on experience.
- For every symptom, name the evidence you'd look at (Spark UI stage metrics, YARN logs, consumer lag) before proposing a fix.
- System designs should cover ingestion, storage layout, processing semantics (idempotency, exactly-once), serving, orchestration, governance, cost, and failure handling.
