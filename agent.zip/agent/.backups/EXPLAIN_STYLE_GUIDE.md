# Style guide: make every concept understandable to a newcomer

The reader is a motivated engineer who is NEW to this topic. Today many files read like notes for
someone who already knows the subject: bullet fragments, arrow chains (`A → B → C`), undefined
acronyms, and claims with no example. Your job is to rewrite them so the reader never has to look
anything up elsewhere.

The reference style is folder `16_ai_infra_zero_to_hero` (read one section, e.g.
`16_ai_infra_zero_to_hero/part03_mlops_cicd_cost/s12_cost_optimization.md`, before you start).

## Rules

1. **Define every term at first use, in plain words.** Acronyms (SSE, HITL, TP, NVLink, QoS, DRA, SM,
   RRF, MMR, KV cache, p95, OOM, IAM, VPC, ...), library names (tenacity, Langfuse, Karpenter ...), and
   jargon ("jitter", "recency", "reask", "fan-out", "lineage", "spill"). One short clause is enough:
   "**jitter** (a small random delay added so that many clients don't retry at the same instant)".
2. **Every concept gets "why" + "what" + a concrete example.** Prefer a real-feeling scenario with
   numbers ("a support bot gets 2,000 questions a day ...") or a tiny input → output illustration.
   An analogy from everyday life is welcome when it genuinely helps; don't force one per bullet.
3. **Turn fragments into complete sentences.** A bullet like
   `- Compaction — summarize long histories; offload tool outputs` becomes 2–4 sentences explaining
   what it is, why you'd do it, and an example. Keep bullets/tables where they help scanning, but each
   cell/bullet must be understandable on its own. Put longer explanations in prose under the table.
4. **No arrow chains or shorthand in prose.** `prompt → RAG → tools` becomes "start with a prompt;
   if that isn't enough, add retrieval (RAG); only then add tools". Arrows inside diagrams are fine.
5. **Explain diagrams.** After every diagram (Mermaid or ASCII), add a "**How to read it:**" paragraph
   if missing, and define any term in the diagram labels that the prose hasn't explained yet
   (a "**Terms in this diagram:**" list works well, as in folder 16). Explain terms BEFORE or right
   after the diagram, never only in a later section.
6. **Explain formulas and numbers.** After a formula, say in words what each symbol means and work one
   small numeric example. After a back-of-envelope number, show where it came from.
7. **Easy language.** Short sentences, active voice, everyday words. Avoid "trivially", "simply",
   "obviously", "just". Don't assume prior knowledge from later chapters; if you reference another
   file, still give a one-line explanation here.
8. **Keep everything that's correct.** Do not delete technical content, code, commands, tables,
   interview questions, links, or headings. Expand; don't shorten. Fix factual errors only if you are
   sure, and keep the original structure/heading order so cross-links still work.
9. **Code stays as is.** Never change executable code behavior. In `.py` files you may only expand the
   module docstring and comments (concept explanations live in the top docstring). The file must still
   pass `python3 -m py_compile <file>`. In `.md` files you may add short comments to code blocks.
10. **Match the file's voice and formatting** (heading style, `> **Why it matters:**` callouts, etc.).
    No emojis. Don't add meta text like "this section was expanded".
11. **Mermaid safety:** if you touch a Mermaid diagram, quote labels containing special characters
    (`()`, `:`, `/`, `<`, `>`), and use `<br/>` for line breaks. Prefer not editing diagrams at all.

## Example transformation

Before:
```
| Rate limits / 5xx | Retry with exponential backoff + jitter (tenacity) |
```

After:
```
| Rate limits or server errors (HTTP 429 / 5xx) | Retry with exponential backoff and jitter |
```
followed by prose:

> **Retry with exponential backoff and jitter.** LLM providers limit how many requests you can send
> per minute; past the limit they answer **HTTP 429** ("too many requests"), and when they are
> overloaded they answer **5xx** server errors. Both are usually temporary, so the fix is to wait and
> try again. **Exponential backoff** means each wait doubles (1 s, 2 s, 4 s, 8 s), giving the provider
> time to recover. **Jitter** adds a small random amount to each wait, so that 500 clients that failed
> at the same moment don't all retry at the same moment and cause a new spike.
> Example: your batch job hits a 429 at 10:00:00; it retries after 1.3 s, then 2.1 s, then 4.4 s,
> and succeeds on the third try. The Python library **tenacity** gives you this with one decorator.
