"""
Retriever with a relevance threshold.

Returning nothing is better than returning irrelevant chunks: irrelevant context invites the
model to stitch together a plausible but wrong answer. The threshold is tuned on the eval set
(watch contextual precision vs. recall as you move it).
"""

from functools import lru_cache

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings

from apps.support_copilot.config import get_settings


@lru_cache
def _store() -> Chroma:
    s = get_settings()
    return Chroma(
        collection_name=s.collection,
        embedding_function=OpenAIEmbeddings(model=s.embedding_model),
        persist_directory=s.chroma_path,
        collection_metadata={"hnsw:space": "cosine"},
    )


def search(query: str) -> list[Document]:
    s = get_settings()
    # relevance scores are normalized to [0, 1] (1 = most similar).
    hits = _store().similarity_search_with_relevance_scores(query, k=s.retrieval_k)
    return [doc for doc, score in hits if score >= s.min_relevance]


def format_docs(docs: list[Document]) -> str:
    return "\n\n".join(f"[{d.metadata['source']}] {d.page_content}" for d in docs)
