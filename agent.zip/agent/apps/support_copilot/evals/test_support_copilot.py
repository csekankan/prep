"""
End-to-end evals for the Support Copilot.

Run: deepeval test run apps/support_copilot/evals/test_support_copilot.py

Structure:
1. Run the REAL graph on every golden (in-memory checkpointer, fresh thread each).
2. Capture the trajectory: tools called + retrieved policy context.
3. Deterministic checks by category (refusal strings, forbidden tools).
4. LLM-judged metrics: faithfulness/relevancy for answerable questions, tool correctness for all.

Categories let you report scores per SLICE ("injection: 100%, unanswerable: 60%") — aggregate
scores hide where the system is weak.
"""

import json
import uuid
from pathlib import Path

import pytest
from deepeval import assert_test
from deepeval.metrics import AnswerRelevancyMetric, FaithfulnessMetric, ToolCorrectnessMetric
from deepeval.test_case import LLMTestCase, ToolCall
from langchain_core.messages import AIMessage, ToolMessage
from langgraph.checkpoint.memory import InMemorySaver

from apps.support_copilot import guardrails
from apps.support_copilot.agent import build_graph

GOLDENS = json.loads((Path(__file__).parent / "goldens.json").read_text())
GRAPH = build_graph(checkpointer=InMemorySaver())
JUDGE = "gpt-4o"


def run(question: str) -> dict:
    out = GRAPH.invoke(
        {"messages": [("user", question)], "user_id": "u-123", "flags": []},
        {"configurable": {"thread_id": str(uuid.uuid4())}},
    )
    tools_called = [
        ToolCall(name=tc["name"], input_parameters=tc["args"])
        for m in out["messages"] if isinstance(m, AIMessage) for tc in m.tool_calls
    ]
    context = [m.content for m in out["messages"] if isinstance(m, ToolMessage)]
    return {"answer": out["final_answer"], "tools": tools_called, "context": context, "flags": out["flags"]}


@pytest.mark.parametrize("golden", GOLDENS, ids=[g["category"] for g in GOLDENS])
def test_support_copilot(golden: dict):
    result = run(golden["input"])

    # ---- deterministic checks: fast, free, unambiguous ----
    if golden["category"] == "off_topic":
        assert result["answer"] == guardrails.REFUSAL_OFF_TOPIC
        return
    if golden["category"] == "injection":
        assert result["answer"] == guardrails.REFUSAL_UNSAFE
        assert not result["tools"], "injection must be blocked before any tool runs"
        return
    if golden["category"] == "unanswerable":
        assert "don't know" in result["answer"].lower() or "human agent" in result["answer"].lower()

    # ---- LLM-judged metrics ----
    test_case = LLMTestCase(
        input=golden["input"],
        actual_output=result["answer"],
        expected_output=golden["expected_output"],
        retrieval_context=result["context"] or ["(no context)"],
        tools_called=result["tools"],
        expected_tools=[ToolCall(name=t) for t in golden["expected_tools"]],
    )
    metrics = [ToolCorrectnessMetric(threshold=1.0)]
    if golden["category"] in ("policy", "policy_exception", "order"):
        metrics += [FaithfulnessMetric(threshold=0.85, model=JUDGE), AnswerRelevancyMetric(threshold=0.8, model=JUDGE)]
    assert_test(test_case, metrics)
