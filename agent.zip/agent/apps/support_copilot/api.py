"""
FastAPI service.

Run: uvicorn apps.support_copilot.api:app --reload

Production concepts on display:
- LIFESPAN: build expensive objects (graph, DB connections) once at startup, not per request.
- thread_id = conversation id → LangGraph checkpointer restores history automatically.
- user_id comes from AUTH (stubbed as a header here), never from the request body the model sees.
- BackgroundTasks: memory writes happen after the response is sent (latency off the hot path).
- run_id returned to the client so feedback can be attached to the exact trace.
- Privacy endpoints: list and delete a user's memories.
"""

import os
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import BackgroundTasks, FastAPI, Header, HTTPException
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.checkpoint.sqlite import SqliteSaver
from prometheus_client import make_asgi_app
from pydantic import BaseModel, Field

from apps.support_copilot import memory
from apps.support_copilot.agent import build_graph
from apps.support_copilot.config import get_settings
from apps.support_copilot.metrics import FEEDBACK, GUARDRAIL_BLOCKS, INFLIGHT, LATENCY, RELEASE, REQUESTS, TOKENS


@asynccontextmanager
async def lifespan(app: FastAPI):
    # SQLite works for a single instance. With several replicas (Kubernetes), every pod must see
    # the same conversation state → Postgres checkpointer, selected by CHECKPOINT_PG_URL.
    if pg_url := os.environ.get("CHECKPOINT_PG_URL"):
        from langgraph.checkpoint.postgres import PostgresSaver

        saver_cm = PostgresSaver.from_conn_string(pg_url)
    else:
        saver_cm = SqliteSaver.from_conn_string(get_settings().checkpoint_db)
    with saver_cm as saver:
        saver.setup()  # creates checkpoint tables if missing (idempotent)
        app.state.graph = build_graph(checkpointer=saver)
        yield


app = FastAPI(title="ShopCo Support Copilot", lifespan=lifespan)
app.mount("/metrics", make_asgi_app())  # scraped by Prometheus (ServiceMonitor in 11_kubernetes)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    thread_id: str | None = None


class ChatResponse(BaseModel):
    answer: str
    thread_id: str
    run_id: str
    flags: list[str]


class Feedback(BaseModel):
    run_id: str
    thumbs_up: bool
    comment: str = ""


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest, background: BackgroundTasks, x_user_id: str = Header(...)):
    thread_id = req.thread_id or str(uuid.uuid4())
    run_id = uuid.uuid4()
    s = get_settings()
    config = {
        "configurable": {"thread_id": f"{x_user_id}:{thread_id}"},  # scope threads per user
        "run_id": run_id,                                            # becomes the LangSmith trace id
        "recursion_limit": 2 * s.max_agent_steps + 6,
        "metadata": {"user_id": x_user_id, "prompt_version": s.prompt_version},
        "tags": ["support-copilot"],
    }
    config["tags"].append(f"release:{RELEASE}")  # lets online evals score canary vs stable separately
    start = time.perf_counter()
    try:
        with INFLIGHT.track_inprogress():
            out = app.state.graph.invoke(
                {"messages": [("user", req.message)], "user_id": x_user_id, "flags": []}, config
            )
    except Exception:
        REQUESTS.labels(RELEASE, "500").inc()
        raise HTTPException(status_code=500, detail="Something went wrong. Please try again.")
    finally:
        LATENCY.labels(RELEASE).observe(time.perf_counter() - start)

    REQUESTS.labels(RELEASE, "200").inc()
    _record_usage(out["messages"])
    for flag in out["flags"]:
        if flag in ("injection:regex", "injection:llm", "off_topic", "ungrounded", "too_long"):
            GUARDRAIL_BLOCKS.labels(RELEASE, flag).inc()
    if not out["blocked"]:
        background.add_task(memory.remember, x_user_id, req.message, out["final_answer"])
    return ChatResponse(answer=out["final_answer"], thread_id=thread_id, run_id=str(run_id), flags=out["flags"])


def _record_usage(messages) -> None:
    """Count tokens for THIS turn only (the checkpointed thread contains earlier turns too)."""
    turn = []
    for m in reversed(messages):
        if isinstance(m, HumanMessage):
            break
        turn.append(m)
    for m in turn:
        if isinstance(m, AIMessage) and m.usage_metadata:
            TOKENS.labels(RELEASE, "input").inc(m.usage_metadata.get("input_tokens", 0))
            TOKENS.labels(RELEASE, "output").inc(m.usage_metadata.get("output_tokens", 0))


@app.post("/feedback")
def feedback(fb: Feedback):
    from langsmith import Client

    FEEDBACK.labels(RELEASE, "up" if fb.thumbs_up else "down").inc()
    Client().create_feedback(run_id=fb.run_id, key="user_rating", score=int(fb.thumbs_up), comment=fb.comment)
    return {"ok": True}


@app.get("/memories")
def get_memories(x_user_id: str = Header(...)):
    return memory.list_memories(x_user_id)


@app.delete("/memories")
def delete_memories(x_user_id: str = Header(...)):
    memory.forget_user(x_user_id)
    return {"deleted": True}


@app.get("/health")
def health():
    """Liveness probe: is the process alive? Must NOT call dependencies — if the LLM provider is
    down, restarting pods won't fix it and would only cause a restart storm."""
    return {"status": "ok"}


@app.get("/ready")
def ready():
    """Readiness probe: can this pod serve traffic? Kubernetes removes unready pods from the
    Service, so a pod still loading (or that lost its checkpoint DB) gets no requests."""
    if getattr(app.state, "graph", None) is None:
        raise HTTPException(status_code=503, detail="not ready")
    return {"status": "ready", "release": RELEASE}
