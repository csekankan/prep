# Refund Policy

Customers may request a full refund within 30 days of delivery. Items must be unused and in
original packaging. Refunds are issued to the original payment method within 5–7 business days
after the returned item is received.

## Exceptions

Digital goods and gift cards are non-refundable. Personalized items can only be refunded if they
arrive damaged.

# Shipping Policy

Standard shipping takes 3–5 business days and is free on orders above $50. Express shipping
takes 1–2 business days and costs $15. Orders placed after 2 PM ship the next business day.

# Warranty

Electronics carry a 1-year limited warranty covering manufacturing defects. Accidental damage
is not covered. Warranty claims require the original order ID.
