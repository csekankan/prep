"""
Long-term user memory via Mem0 (concepts: 05_memory/02_mem0_memory.py).

Design choices:
- READ in the hot path (fast vector search), WRITE in the background (LLM extraction is slow).
- Failures are non-fatal: if memory is down, the copilot still answers — memory is an
  enhancement, not a dependency. Wrap every call.
- Custom fact-extraction prompt keeps Mem0 from storing irrelevant or sensitive details.
"""

import logging
from functools import lru_cache

from mem0 import Memory

log = logging.getLogger(__name__)

FACT_EXTRACTION_PROMPT = """Extract durable facts useful for future ShopCo support conversations:
preferred name, language, preferred contact channel, recurring products, past issues and their resolution.
Do NOT extract payment details, addresses, phone numbers, emails, or anything sensitive.
Return JSON: {"facts": ["..."]}"""


@lru_cache
def _memory() -> Memory:
    return Memory.from_config(
        {
            "llm": {"provider": "openai", "config": {"model": "gpt-4o-mini", "temperature": 0}},
            "embedder": {"provider": "openai", "config": {"model": "text-embedding-3-small"}},
            "vector_store": {"provider": "chroma", "config": {"collection_name": "support_mem", "path": "./.mem0_support"}},
            "custom_fact_extraction_prompt": FACT_EXTRACTION_PROMPT,
        }
    )


def recall(user_id: str, query: str, limit: int = 5) -> list[str]:
    try:
        return [m["memory"] for m in _memory().search(query=query, user_id=user_id, limit=limit).get("results", [])]
    except Exception:  # noqa: BLE001
        log.exception("memory recall failed; continuing without memories")
        return []


def remember(user_id: str, user_msg: str, assistant_msg: str) -> None:
    try:
        _memory().add(
            [{"role": "user", "content": user_msg}, {"role": "assistant", "content": assistant_msg}],
            user_id=user_id,
        )
    except Exception:  # noqa: BLE001
        log.exception("memory write failed")


def list_memories(user_id: str) -> list[dict]:
    return _memory().get_all(user_id=user_id).get("results", [])


def forget_user(user_id: str) -> None:
    _memory().delete_all(user_id=user_id)
