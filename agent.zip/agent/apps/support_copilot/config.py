"""
Typed configuration.

Why pydantic-settings: config is validated at STARTUP (fail fast on a missing key) instead of
at the first request. Model names, thresholds, and limits live here so they can change per
environment (dev/staging/prod) without code changes — and so evals can sweep them.
"""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    chat_model: str = "openai:gpt-4o-mini"
    fallback_model: str = "openai:gpt-4o"
    guard_model: str = "openai:gpt-4o-mini"
    embedding_model: str = "text-embedding-3-small"

    chroma_path: str = "./.chroma_support"
    collection: str = "shopco_policies"
    retrieval_k: int = 4
    min_relevance: float = 0.3   # below this, treat as "no relevant docs" (tune on evals)

    max_agent_steps: int = 6
    llm_timeout_s: int = 20
    prompt_version: str = "support-v1"

    checkpoint_db: str = "./.checkpoints_support.sqlite"


@lru_cache
def get_settings() -> Settings:
    return Settings()
