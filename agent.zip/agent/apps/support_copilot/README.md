# App 1 — ShopCo Support Copilot

Single tool-calling agent + RAG + long-term memory (Mem0) + layered guardrails + DeepEval,
served via FastAPI. This README walks the app through the **AI engineering lifecycle**.

## 1. Define

- **User**: ShopCo customers asking about orders, shipping, refunds, warranty.
- **Job**: get correct, policy-grounded answers in seconds instead of waiting for a human.
- **Out of scope**: anything not about ShopCo → polite refusal. Refunds → human approval.
- **Success metrics (launch bar)**:

| Metric | Target | Measured by |
|---|---|---|
| Faithfulness | ≥ 0.85 | DeepEval `FaithfulnessMetric` |
| Answer relevancy | ≥ 0.80 | DeepEval `AnswerRelevancyMetric` |
| Correct refusal on out-of-scope | ≥ 95% | G-Eval + exact string check |
| Tool correctness | ≥ 90% | `ToolCorrectnessMetric` |
| p95 latency | < 5 s | traces |
| Cost per conversation | < $0.01 | token metrics |

- **Autonomy level**: single agent (level 2). Multi-agent not justified: one domain, few tools.

## 2. Data

- `data/*.md` policy docs → `ingest.py` chunks by heading, embeds, stores in Chroma with metadata.
- `evals/goldens.json` — seed eval set incl. out-of-scope and injection cases.

## 3. Prototype → architecture

```
POST /chat
  │
  ▼
input_guard ──(blocked)──────────────────────────────────────────► respond
  │ allowed (PII redacted)
  ▼
load_memories (Mem0 search, user-scoped)
  │
  ▼
agent ◄────────► tools: search_policies (RAG), get_order_status    (bounded loop)
  │
  ▼
output_guard (PII, groundedness vs retrieved context)
  │
  ▼
respond  ──► background: save_memories (Mem0 add)
```

## 4. Evaluate — `evals/test_support_copilot.py` (`deepeval test run ...`)
## 5. Harden — `guardrails.py`, bounded loops, retries, fallbacks in `config.py`/`agent.py`
## 6. Deploy — `api.py` (`uvicorn apps.support_copilot.api:app`), SQLite checkpointer (→ Postgres in prod)
## 7. Observe — LangSmith env vars; `/feedback` endpoint links thumbs up/down to the trace
## 8. Improve — negative-feedback traces → new goldens → re-run evals → ship

## Files

| File | Role |
|---|---|
| `config.py` | typed settings from env (models, thresholds, paths) |
| `prompts.py` | versioned prompts |
| `ingest.py` | indexing pipeline |
| `retrieval.py` | retriever with relevance threshold |
| `guardrails.py` | input/output rails |
| `memory.py` | Mem0 wrapper |
| `agent.py` | LangGraph graph |
| `api.py` | FastAPI service |
| `evals/` | goldens + DeepEval tests |
