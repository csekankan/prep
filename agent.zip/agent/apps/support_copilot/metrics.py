"""
Prometheus metrics exposed at /metrics.

These feed three consumers:
  1. Grafana dashboards (humans)
  2. Alertmanager rules (10_llmops_pipeline/alerts/prometheus-rules.yaml)
  3. Argo Rollouts canary analysis (11_kubernetes/k8s/rollout-canary.yaml) — the `release` label
     lets the analysis compare canary pods against stable pods.

Keep label cardinality LOW: never put user_id, question text, or thread_id in labels
(each unique value creates a new time series and can take down Prometheus).
"""

import os

from prometheus_client import Counter, Gauge, Histogram

RELEASE = os.environ.get("RELEASE_VERSION", "dev")   # injected by the Deployment from the release manifest

REQUESTS = Counter("copilot_requests_total", "Chat requests", ["release", "status"])
LATENCY = Histogram(
    "copilot_request_latency_seconds", "End-to-end chat latency", ["release"],
    buckets=(0.5, 1, 2, 3, 4, 6, 8, 12, 20),
)
TOKENS = Counter("copilot_tokens_total", "LLM tokens used", ["release", "direction"])
GUARDRAIL_BLOCKS = Counter("copilot_guardrail_blocks_total", "Guardrail blocks", ["release", "reason"])
FEEDBACK = Counter("copilot_feedback_total", "User feedback", ["release", "rating"])
# Autoscaling signal (HPA via Prometheus Adapter): LLM apps saturate on concurrent requests, not CPU.
# multiprocess_mode matters if you run several uvicorn workers with PROMETHEUS_MULTIPROC_DIR set.
INFLIGHT = Gauge("copilot_inflight_requests", "Requests currently being processed", multiprocess_mode="livesum")
