"""
INDEXING PIPELINE (offline): load → split by structure → embed → store with metadata.

Run: python -m apps.support_copilot.ingest

Production notes:
- Make ingestion IDEMPOTENT: deterministic chunk IDs (hash of source+content) so re-running
  upserts instead of duplicating.
- Re-index on doc change (CI hook, webhook from CMS, or nightly job).
- Store `updated_at` and `access_level` metadata so retrieval can filter stale/forbidden docs.
- Changing the embedding model requires RE-EMBEDDING everything — vectors from different
  models are not comparable. Version your collections (e.g. `policies_te3small_v2`).
"""

import hashlib
from pathlib import Path

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import MarkdownHeaderTextSplitter, RecursiveCharacterTextSplitter

from apps.support_copilot.config import get_settings

DATA_DIR = Path(__file__).parent / "data"


def load_and_split() -> list[Document]:
    # Two-stage split: first by markdown headers (keeps semantic sections together and records
    # the section title as metadata), then by size for any section that's still too long.
    header_splitter = MarkdownHeaderTextSplitter(headers_to_split_on=[("#", "section"), ("##", "subsection")])
    size_splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=100)

    chunks: list[Document] = []
    for path in sorted(DATA_DIR.glob("*.md")):
        for section in header_splitter.split_text(path.read_text()):
            section.metadata["source"] = path.name
            for piece in size_splitter.split_documents([section]):
                # Contextual header: prepend the section title to the chunk text. Cheap trick that
                # noticeably improves retrieval for chunks like "They take 1–2 days" (what does?).
                title = " > ".join(v for k, v in piece.metadata.items() if k in ("section", "subsection"))
                piece.page_content = f"{title}\n{piece.page_content}"
                chunks.append(piece)
    return chunks


def chunk_id(doc: Document) -> str:
    return hashlib.sha256(f"{doc.metadata['source']}|{doc.page_content}".encode()).hexdigest()[:32]


def main() -> None:
    s = get_settings()
    chunks = load_and_split()
    store = Chroma(
        collection_name=s.collection,
        embedding_function=OpenAIEmbeddings(model=s.embedding_model),
        persist_directory=s.chroma_path,
        collection_metadata={"hnsw:space": "cosine"},
    )
    store.add_documents(chunks, ids=[chunk_id(c) for c in chunks])
    print(f"Indexed {len(chunks)} chunks into '{s.collection}'.")


if __name__ == "__main__":
    main()
