"""
The Support Copilot graph.

    START → input_guard ─(blocked)──────────────────────────────► END
                 │
                 ▼
            load_memory → agent ⇄ tools   (bounded ReAct loop)
                            │
                            ▼
                       output_guard → END

Concepts on display:
- Guardrails as GRAPH NODES: they're visible in traces, testable, and can't be skipped by the LLM.
- InjectedState: the tool receives `user_id` from graph state, NOT from the model. The model
  can't ask for someone else's order by hallucinating/being tricked into a different user_id.
- Message replacement: returning a message with the same `id` makes `add_messages` REPLACE it
  (used to store the PII-redacted version of the user's message).
- Per-turn context: `policy_context` is rebuilt each turn from this turn's tool results and fed
  to the groundedness check.
"""

from typing import Annotated, TypedDict

from langchain.chat_models import init_chat_model
from langchain_core.messages import AIMessage, AnyMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.tools import tool
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import InjectedState, ToolNode

from apps.support_copilot import guardrails, memory, retrieval
from apps.support_copilot.config import get_settings
from apps.support_copilot.prompts import system_prompt

# ------------------------------------------------------------------ tools
FAKE_ORDERS = {
    ("u-123", "ORD-1001"): "shipped, arriving 2026-11-14 via BlueDart",
    ("u-123", "ORD-1002"): "delivered on 2026-10-20",
}


@tool
def search_policies(query: str) -> str:
    """Search ShopCo policy documents (refunds, shipping, warranty). Use for ANY policy question.
    Pass a focused search query, e.g. 'refund window for electronics'."""
    docs = retrieval.search(query)
    return retrieval.format_docs(docs) if docs else "NO_RELEVANT_POLICY_FOUND"


@tool
def get_order_status(order_id: str, user_id: Annotated[str, InjectedState("user_id")]) -> str:
    """Get the status of one of the current customer's orders. order_id looks like ORD-1001."""
    # Authorization by construction: lookup is keyed on the authenticated user's id.
    status = FAKE_ORDERS.get((user_id, order_id.upper()))
    return f"{order_id}: {status}" if status else f"No order {order_id} found for this customer."


TOOLS = [search_policies, get_order_status]


# ------------------------------------------------------------------ state
class SupportState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    user_id: str
    memories: list[str]
    steps: int
    blocked: bool
    flags: list[str]
    final_answer: str


# ------------------------------------------------------------------ helpers
def _current_turn(messages: list[AnyMessage]) -> list[AnyMessage]:
    """Messages since the latest human message (the checkpointer keeps the whole thread)."""
    for i in range(len(messages) - 1, -1, -1):
        if isinstance(messages[i], HumanMessage):
            return messages[i:]
    return messages


def _llm():
    s = get_settings()
    primary = init_chat_model(s.chat_model, temperature=0, timeout=s.llm_timeout_s, max_retries=2)
    fallback = init_chat_model(s.fallback_model, temperature=0, timeout=s.llm_timeout_s)
    # bind_tools must be applied to each model BEFORE adding fallbacks.
    return primary.bind_tools(TOOLS).with_fallbacks([fallback.bind_tools(TOOLS)])


# ------------------------------------------------------------------ nodes
def input_guard(state: SupportState) -> dict:
    last = state["messages"][-1]
    verdict = guardrails.check_input(last.content)
    update = {"flags": verdict.flags, "steps": 0, "blocked": not verdict.allowed, "final_answer": ""}
    if not verdict.allowed:
        update["final_answer"] = verdict.text
        update["messages"] = [AIMessage(verdict.text)]
    elif verdict.text != last.content:
        # Same id → replaces the raw message: PII never reaches the LLM or the checkpoint store.
        update["messages"] = [HumanMessage(verdict.text, id=last.id)]
    return update


def load_memory(state: SupportState) -> dict:
    return {"memories": memory.recall(state["user_id"], state["messages"][-1].content)}


def agent(state: SupportState) -> dict:
    s = get_settings()
    msgs = [SystemMessage(system_prompt(s.prompt_version, state["memories"])), *state["messages"]]
    return {"messages": [_llm().invoke(msgs)], "steps": state["steps"] + 1}


def route_agent(state: SupportState) -> str:
    last = state["messages"][-1]
    if getattr(last, "tool_calls", None) and state["steps"] < get_settings().max_agent_steps:
        return "tools"
    return "output_guard"


def output_guard(state: SupportState) -> dict:
    turn = _current_turn(state["messages"])
    last = turn[-1]
    # If we stopped because of the step cap, the last message may be an unanswered tool call.
    answer = last.content if isinstance(last, AIMessage) and not last.tool_calls else ""
    if not answer:
        answer = "Sorry, I couldn't complete that. Let me connect you with a human agent."
    policy_context = "\n".join(
        m.content for m in turn
        if isinstance(m, ToolMessage) and m.name == "search_policies" and m.content != "NO_RELEVANT_POLICY_FOUND"
    )
    verdict = guardrails.check_output(answer, policy_context)
    update = {"final_answer": verdict.text, "flags": state["flags"] + verdict.flags}
    if verdict.text != answer and isinstance(last, AIMessage):
        update["messages"] = [AIMessage(verdict.text, id=last.id)]
    return update


# ------------------------------------------------------------------ graph
def build_graph(checkpointer=None):
    g = StateGraph(SupportState)
    g.add_node("input_guard", input_guard)
    g.add_node("load_memory", load_memory)
    g.add_node("agent", agent)
    g.add_node("tools", ToolNode(TOOLS))
    g.add_node("output_guard", output_guard)

    g.add_edge(START, "input_guard")
    g.add_conditional_edges("input_guard", lambda s: END if s["blocked"] else "load_memory", ["load_memory", END])
    g.add_edge("load_memory", "agent")
    g.add_conditional_edges("agent", route_agent, ["tools", "output_guard"])
    g.add_edge("tools", "agent")
    g.add_edge("output_guard", END)
    return g.compile(checkpointer=checkpointer)
