"""
CLI runner demonstrating durable execution + human-in-the-loop.

    python -m apps.research_team.run "vector databases for startups"

Flow:
  1. graph.stream(...) runs until the human_review interrupt; state is saved in SQLite.
  2. We show the draft and ask the human.
  3. graph.stream(Command(resume=answer), same thread_id) continues exactly where it paused.
If the process crashes between 1 and 3, rerunning with the same thread_id resumes from the checkpoint.
"""

import sys

from dotenv import load_dotenv
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.types import Command

from apps.research_team.graph import build_graph

load_dotenv()


def main(topic: str) -> None:
    with SqliteSaver.from_conn_string("./.checkpoints_research.sqlite") as saver:
        graph = build_graph(saver)
        config = {
            "configurable": {"thread_id": f"brief:{topic}"},
            "recursion_limit": 40,  # global hard stop across all agents
            "tags": ["research-team"],
            "metadata": {"topic": topic},
        }

        inputs = {"topic": topic, "findings": [], "turns": 0, "revisions": 0, "critique": None, "human_notes": ""}
        while True:
            # stream_mode="updates" yields {node_name: update} — a live activity feed of the team.
            for event in graph.stream(inputs, config, stream_mode="updates"):
                for node, update in event.items():
                    if node == "__interrupt__":
                        continue
                    print(f"▶ {node}: {', '.join(update.keys()) if update else ''}")

            state = graph.get_state(config)
            if not state.next:  # nothing left to run → finished
                print("\nPublished:", state.values.get("published"))
                print(state.values["draft"])
                return

            # Paused at an interrupt: show its payload and collect the decision.
            payload = state.tasks[0].interrupts[0].value
            print("\n" + "=" * 60 + f"\nDRAFT (critic score {payload['critic_score']}):\n{payload['draft']}\n" + "=" * 60)
            approve = input("Approve? [y/N] ").strip().lower() == "y"
            notes = "" if approve else input("Notes for the writer: ")
            inputs = Command(resume={"approve": approve, "notes": notes})


if __name__ == "__main__":
    main(" ".join(sys.argv[1:]) or "vector databases for startups")
