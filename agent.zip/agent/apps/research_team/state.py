"""
Shared state for the research team.

Design principle: state holds ARTIFACTS (findings, analysis, draft, critique), not raw chat
transcripts. Agents communicate through well-defined fields — like a team sharing documents
instead of forwarding each other every email. That keeps each agent's context small and makes
every intermediate result inspectable in checkpoints and traces.
"""

import operator
from typing import Annotated, Literal, TypedDict

from pydantic import BaseModel, Field


class Critique(BaseModel):
    score: int = Field(ge=1, le=10)
    issues: list[str] = Field(description="Concrete, fixable problems. Empty if none.")


class Route(BaseModel):
    reasoning: str = Field(description="One sentence: why this worker, why now.")
    next: Literal["researcher", "analyst", "writer"]
    instruction: str = Field(description="Specific task for the chosen worker.")


class ResearchState(TypedDict):
    topic: str
    # operator.add → each researcher run APPENDS findings; parallel/sequential runs never overwrite.
    findings: Annotated[list[str], operator.add]
    analysis: str
    draft: str
    critique: Critique | None
    human_notes: str
    revisions: int
    turns: int
    next: str
    instruction: str
    published: bool
