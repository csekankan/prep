"""
The research team graph.

Two kinds of control flow coexist here — knowing when to use which is a core skill:
  1. LLM-DECIDED routing (supervisor): flexible, for open-ended phases (how much research is enough?).
  2. CODE-DECIDED routing (critic threshold, revision cap, human decision): deterministic, for
     anything that must be predictable, auditable, or bounded.
Rule: let the LLM choose WHAT to do; let code enforce LIMITS and POLICIES.
"""

from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt

from apps.research_team import agents
from apps.research_team.state import ResearchState

MAX_SUPERVISOR_TURNS = 6
MAX_REVISIONS = 2
PASS_SCORE = 8


# ------------------------------------------------------------------ research phase (supervisor-led)
def supervisor(state: ResearchState) -> dict:
    turns = state.get("turns", 0) + 1
    # Budget guard: if the team is dithering, force progress to writing.
    if turns > MAX_SUPERVISOR_TURNS:
        return {"next": "writer" if state.get("analysis") else "analyst", "instruction": "Proceed with what you have.", "turns": turns}
    route = agents.supervisor_llm.invoke(
        agents.SUPERVISOR_PROMPT.format(
            topic=state["topic"], n_findings=len(state.get("findings", [])), has_analysis=bool(state.get("analysis"))
        )
    )
    # Guard against invalid transitions the LLM might choose (writer with no analysis).
    nxt = route.next
    if nxt == "writer" and not state.get("analysis"):
        nxt = "analyst" if state.get("findings") else "researcher"
    return {"next": nxt, "instruction": route.instruction, "turns": turns}


def researcher(state: ResearchState) -> dict:
    result = agents.researcher_agent.invoke(
        {"messages": [("user", f"Topic: {state['topic']}\nTask: {state['instruction']}")]}
    )
    # Context isolation: only the final findings leave the sub-agent; raw search pages stay inside.
    return {"findings": [result["messages"][-1].content]}


def analyst(state: ResearchState) -> dict:
    msg = agents.analyst_llm.invoke(
        agents.ANALYST_PROMPT.format(topic=state["topic"], findings="\n\n".join(state["findings"]))
    )
    return {"analysis": msg.content}


# ------------------------------------------------------------------ writing phase (code-led loop)
def writer(state: ResearchState) -> dict:
    feedback_parts = []
    if state.get("critique") and state["critique"].issues:
        feedback_parts.append("Editor feedback to address:\n- " + "\n- ".join(state["critique"].issues))
    if state.get("human_notes"):
        feedback_parts.append(f"Human reviewer notes (highest priority): {state['human_notes']}")
    draft = agents.writer_llm.invoke(
        agents.WRITER_PROMPT.format(topic=state["topic"], analysis=state["analysis"], feedback="\n".join(feedback_parts))
    )
    return {"draft": draft.content, "revisions": state.get("revisions", 0) + 1}


def critic(state: ResearchState) -> dict:
    return {"critique": agents.critic_llm.invoke(agents.CRITIC_PROMPT.format(topic=state["topic"], draft=state["draft"]))}


def route_after_critic(state: ResearchState) -> str:
    if state["critique"].score < PASS_SCORE and state["revisions"] <= MAX_REVISIONS:
        return "writer"
    return "human_review"


# ------------------------------------------------------------------ human-in-the-loop
def human_review(state: ResearchState) -> dict:
    """`interrupt(payload)` PAUSES the graph and persists state via the checkpointer. The payload
    is surfaced to the caller (e.g. shown in a review UI). The run can be resumed minutes or days
    later — even from a different process — with `Command(resume=<human's answer>)`, and
    `interrupt` then RETURNS that answer here.

    Note: on resume, the node re-runs from its start, so keep code before interrupt() side-effect free."""
    decision = interrupt(
        {"draft": state["draft"], "critic_score": state["critique"].score, "question": "Approve? {'approve': bool, 'notes': str}"}
    )
    if decision.get("approve"):
        return {"human_notes": ""}
    return {"human_notes": decision.get("notes", "Please improve."), "revisions": 0, "critique": None}


def route_after_human(state: ResearchState) -> str:
    return "writer" if state.get("human_notes") else "publish"


def publish(state: ResearchState) -> dict:
    # Real system: write to CMS/Notion/S3. Idempotent by topic+version so a resumed run can't double-publish.
    return {"published": True}


# ------------------------------------------------------------------ assemble
def build_graph(checkpointer):
    g = StateGraph(ResearchState)
    for name, fn in [
        ("supervisor", supervisor), ("researcher", researcher), ("analyst", analyst),
        ("writer", writer), ("critic", critic), ("human_review", human_review), ("publish", publish),
    ]:
        g.add_node(name, fn)

    g.add_edge(START, "supervisor")
    g.add_conditional_edges("supervisor", lambda s: s["next"], ["researcher", "analyst", "writer"])
    g.add_edge("researcher", "supervisor")
    g.add_edge("analyst", "supervisor")
    g.add_edge("writer", "critic")
    g.add_conditional_edges("critic", route_after_critic, ["writer", "human_review"])
    g.add_conditional_edges("human_review", route_after_human, ["writer", "publish"])
    g.add_edge("publish", END)
    # A checkpointer is REQUIRED for interrupt() — paused state has to live somewhere.
    return g.compile(checkpointer=checkpointer)
