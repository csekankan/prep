# App 2 — Research Team (multi-agent LangGraph)

Produces a short, sourced research brief on a topic using a team of specialized agents with a
bounded critique loop and a **human approval gate** before publishing.

## 1. Define

- **User**: an analyst who needs a 1-page brief ("State of vector databases for startups").
- **Why multi-agent (justification, not fashion)**:
  - Research floods the context with search results → isolate it in a researcher sub-agent.
  - Writing quality benefits from a separate critic with a strict rubric.
  - Publishing is irreversible-ish → human-in-the-loop.
- **Success metrics**: brief covers ≥ 90% of rubric points (G-Eval), every claim has a source,
  ≤ 2 revision rounds on average, cost < $0.25/brief, < 2 min wall-clock.

## 2. Architecture

```
            ┌───────────────── supervisor (router, structured output) ─────────────────┐
            │                         ▲               ▲                                 │
            ▼                         │               │                                 ▼
       researcher ───────────────────┘          analyst                            writer
  (tool agent: web_search)              (synthesizes findings)                        │
                                                                                       ▼
                                                                                     critic
                                                                        score < 8 & revisions < 2 ──► writer
                                                                                       │ else
                                                                                       ▼
                                                                         human_review (interrupt)
                                                                        approve ──► publish ──► END
                                                                        reject + notes ──► writer
```

## Concepts demonstrated

| Concept | Where |
|---|---|
| Supervisor routing with `Literal` structured output | `graph.py::supervisor` |
| Sub-agent as a node (context isolation) | `agents.py::researcher_agent` |
| Reducers for accumulating findings | `state.py` (`operator.add`) |
| Bounded reflection loop | `graph.py::route_after_critic` |
| Human-in-the-loop with `interrupt()` / `Command(resume=...)` | `graph.py::human_review`, `run.py` |
| Durable checkpointing (resume after crash or after human replies hours later) | `run.py` (SqliteSaver) |
| Global budgets (`turns`, `recursion_limit`) | `graph.py`, `run.py` |

## 3–8. Lifecycle

- **Evaluate**: G-Eval rubric on final brief + check every paragraph cites a source; trajectory
  check that researcher ran before writer; track revisions and cost per run.
- **Harden**: researcher's web content is untrusted → it only returns *findings text* to the
  shared state; no agent that reads the web has a publishing tool (breaks the "lethal trifecta").
- **Deploy**: run as a background job (queue) — not a request/response API; notify when awaiting review.
- **Observe**: each node is a span named after the agent; tag runs with the topic.
- **Improve**: human reviewer notes are logged → mined for new rubric points and critic prompt fixes.

Run: `python -m apps.research_team.run "vector databases for startups"`
