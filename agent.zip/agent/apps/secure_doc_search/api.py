"""
FastAPI service with Bearer-token auth.

Run (dev users, no Entra needed):
    AUTH_MODE=dev uvicorn apps.secure_doc_search.api:app --reload
    curl -X POST localhost:8000/search -H "Authorization: Bearer dev-external-pune" \
         -H "Content-Type: application/json" -d '{"question": "Yield strength and price of S355?"}'

Identity comes ONLY from the validated token (a FastAPI dependency) — never from the body.
"""

from fastapi import Depends, FastAPI, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

from apps.secure_doc_search.auth import AuthError, authenticate
from apps.secure_doc_search.graph import ask
from apps.secure_doc_search.policy import AccessContext, resolve

app = FastAPI(title="Secure Document Search")
bearer = HTTPBearer()


def current_access(creds: HTTPAuthorizationCredentials = Depends(bearer)) -> AccessContext:
    try:
        return resolve(authenticate(creds.credentials))
    except AuthError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


class SearchRequest(BaseModel):
    question: str = Field(min_length=3, max_length=2000)


@app.post("/search")
def search(req: SearchRequest, ctx: AccessContext = Depends(current_access)):
    if not ctx.entitlements:
        raise HTTPException(status_code=403, detail="You have no document access. Request access via the IT portal.")
    return ask(ctx, req.question)


@app.get("/me/access")
def my_access(ctx: AccessContext = Depends(current_access)):
    """Transparency endpoint: lets users (and support staff) see why they can or can't see things."""
    return {"user": ctx.username, "groups": ctx.matched_groups, "entitlements": sorted(ctx.entitlements),
            "sites": sorted(ctx.sites), "employment": ctx.employment}
