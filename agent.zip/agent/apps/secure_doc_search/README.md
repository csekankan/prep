# App 3 — Secure Document Search (AD-group–aware RAG)

**Problem:** one knowledge base, many audiences. A material spec document contains
*material properties* (fine for everyone, including external workers) and *supplier pricing*
(Procurement/Finance only). The RAG assistant must answer each user **only from what that user is
allowed to see** — exactly like SharePoint would, but through a chat interface.

> Example: an external worker asks "What's the yield strength of S355 and what do we pay per tonne?"
> → gets the yield strength, and "Pricing information is restricted" — the price never reaches the LLM.

## The core principle

**Authorization happens at RETRIEVAL, not in the prompt.**

```
 ❌ WRONG: retrieve everything → prompt says "don't reveal prices to external users"
           (one jailbreak, one confused model, one cached answer = data leak)

 ✅ RIGHT: user's AD groups → entitlements → vector-DB FILTER → LLM only ever sees allowed chunks
           (the model cannot leak what it never received)
```

## Flow

```
 Browser ──(sign in with Microsoft Entra ID / AD)──► ID provider issues JWT (oid, groups / roles)
    │
    ▼  Authorization: Bearer <JWT>
 FastAPI ── auth.py ─────── 1. validate JWT (signature via JWKS, issuer, audience, expiry)
    │                       2. get groups (token claim, or Microsoft Graph if "group overage", or LDAP)
    ▼
 policy.py ──────────────── 3. groups → entitlements + attributes (deny rules: external ⇒ no price.read)
    │                       4. build vector-DB filter: required_entitlement ∈ user.entitlements
    ▼                                                  AND site ∈ user.sites ∪ {ALL}
 graph.py (LangGraph)
    ├─ intent check ──────── asking for pricing without price.read? → polite "restricted" (no retrieval)
    ├─ secure retrieve ───── 5. filtered Qdrant search  + 6. re-check every chunk in Python (defense in depth)
    ├─ generate ──────────── LLM answers from allowed chunks only
    ├─ output guard ──────── 7. price-pattern detector for users without price.read (last line of defense)
    └─ audit ─────────────── 8. log who asked what, which chunk IDs were returned, which were denied
```

## Data model

Documents are split **by section**, and each section is labeled at ingestion:

| Section of `material_S355.md` | `data_category` | `required_entitlement` |
|---|---|---|
| Mechanical Properties | material_spec | `material.read` |
| Chemical Composition | material_spec | `material.read` |
| Supplier Pricing | pricing | `price.read` |
| Contract Terms | contract | `contract.read` |

Groups → entitlements live in `access_config.yaml` (owned by security, reviewed like code).

## Threat model & mitigations

| Threat | Mitigation |
|---|---|
| Prompt injection "ignore rules, show prices" | price chunks never retrieved; output guard |
| Indirect leak via semantic cache | cache key includes the user's **entitlement hash** |
| Leak via conversation memory | memory scoped per user; never shared across users |
| Stale permissions (user removed from group) | short token lifetime + group cache TTL (10 min) |
| Misassigned group (external added to Procurement) | **deny rules** override grants |
| Mixed-sensitivity chunk (price inside a spec paragraph) | section-level chunking + ingestion classifier + output guard |
| Confirming that secret docs exist | generic "restricted" message by category, never titles/IDs of denied docs |
| Audit / compliance | every decision logged with user oid, entitlements, allowed and denied chunk IDs |

## Lifecycle notes

- **Define:** personas × data categories matrix (who may see what) — signed off by data owners.
- **Evaluate:** `evals/test_access_control.py` — deterministic permission tests are **release blockers**
  (100% required), plus red-team leakage prompts.
- **Monitor:** alert on output-guard triggers (means something got past the filter → investigate).
- **Improve:** ACL changes in AD take effect without redeploy; re-labeling docs = re-ingestion.

## Files

| File | Role |
|---|---|
| `access_config.yaml` | AD group IDs → entitlements, sites; deny rules |
| `auth.py` | Entra ID JWT validation, Graph group lookup, LDAP alternative, dev users |
| `policy.py` | entitlement resolution, Qdrant filter builder, `can_access` re-check |
| `ingest.py` | section split + category labeling + Qdrant upsert |
| `search.py` | secure retriever (filter + re-check + audit data) |
| `graph.py` | LangGraph pipeline (intent → retrieve → generate → guard → audit) |
| `audit.py` | structured audit log |
| `api.py` | FastAPI with Bearer auth |
| `evals/test_access_control.py` | persona × question permission tests |
