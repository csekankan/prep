"""
AUTHORIZATION POLICY: AD groups → entitlements → retrieval filter
==================================================================

CONCEPT DEEP DIVE
-----------------
RBAC vs ABAC:
  RBAC (role-based)       group/role → permission.            "Procurement can read prices."
  ABAC (attribute-based)  rules over user + resource attributes. "External users may read material
                          specs only for sites they are assigned to."
Real systems combine them: entitlements from groups (RBAC) + attribute conditions like site and
employment type (ABAC).

Evaluation order (the classic, safe one):
  1. DEFAULT DENY        no recognized groups → no entitlements
  2. GRANTS              union of entitlements from all the user's groups
  3. DENY RULES          remove entitlements based on attributes — deny ALWAYS wins
  4. RESOURCE CHECK      chunk.required_entitlement ∈ user.entitlements AND chunk.site ∈ user.sites ∪ {ALL}

The SAME policy is enforced twice:
  - as a vector-DB FILTER (fast, efficient — forbidden chunks are never even scored), and
  - as a Python RE-CHECK on every returned chunk (defense in depth against filter bugs,
    a mis-configured index, or someone calling the store without the filter).

Larger orgs externalize this into a policy engine (OPA/Rego, AWS Cedar / Verified Permissions,
Cerbos, OpenFGA for relationship-based access). The interface stays the same:
`decide(user, resource) → allow/deny`, plus `filter_for(user)` for search.
"""

import hashlib
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

import yaml
from qdrant_client import models

from apps.secure_doc_search.auth import Identity

CONFIG_PATH = Path(__file__).parent / "access_config.yaml"


@dataclass(frozen=True)
class AccessContext:
    """Everything downstream code needs to know about the user's permissions. Immutable."""

    user_id: str
    username: str
    entitlements: frozenset[str]
    sites: frozenset[str]
    employment: str
    matched_groups: tuple[str, ...] = field(default=())

    @property
    def fingerprint(self) -> str:
        """Hash of the permission set. Use it in CACHE KEYS: two users with identical permissions
        may share cached answers; users with different permissions must never share one."""
        raw = "|".join(sorted(self.entitlements)) + "#" + "|".join(sorted(self.sites))
        return hashlib.sha256(raw.encode()).hexdigest()[:16]


@lru_cache
def load_policy() -> dict:
    return yaml.safe_load(CONFIG_PATH.read_text())


def resolve(identity: Identity) -> AccessContext:
    policy = load_policy()
    entitlements: set[str] = set()
    sites: set[str] = set()
    employment = "internal"
    matched = []

    for gid in identity.group_ids:
        group = policy["groups"].get(gid)
        if not group:
            continue  # unknown groups grant nothing
        matched.append(group["name"])
        entitlements.update(group.get("entitlements", []))
        attrs = group.get("attributes", {})
        sites.update(attrs.get("sites", []))
        if attrs.get("employment") == "external":
            employment = "external"   # "external" is sticky: any external group marks the user external

    for rule in policy.get("deny_rules", []):
        if rule["when"].get("employment") == employment:
            entitlements -= set(rule["remove_entitlements"])

    return AccessContext(
        user_id=identity.user_id,
        username=identity.username,
        entitlements=frozenset(entitlements),
        sites=frozenset(sites),
        employment=employment,
        matched_groups=tuple(matched),
    )


def retrieval_filter(ctx: AccessContext) -> models.Filter:
    """Qdrant filter applied INSIDE the vector search. If the user has no entitlements, the filter
    matches nothing (MatchAny with a sentinel) — default deny, not 'no filter'."""
    allowed_entitlements = list(ctx.entitlements) or ["__none__"]
    allowed_sites = [*ctx.sites, "ALL"]
    return models.Filter(
        must=[
            models.FieldCondition(key="required_entitlement", match=models.MatchAny(any=allowed_entitlements)),
            models.FieldCondition(key="site", match=models.MatchAny(any=allowed_sites)),
        ]
    )
    # pgvector equivalent (04_rag/04_pgvector_server.py):
    #   WHERE required_entitlement = ANY(%(ents)s) AND site = ANY(%(sites)s)


def can_access(ctx: AccessContext, chunk_payload: dict) -> bool:
    """Per-chunk re-check. Missing labels → DENY (an unlabeled chunk is treated as secret)."""
    required = chunk_payload.get("required_entitlement")
    site = chunk_payload.get("site")
    if not required or not site:
        return False
    return required in ctx.entitlements and (site == "ALL" or site in ctx.sites)


def category_allowed(ctx: AccessContext, category: str) -> bool:
    return load_policy()["categories"].get(category) in ctx.entitlements


def restricted_message(category: str) -> str:
    return load_policy()["restricted_messages"].get(category, "You don't have access to that information.")
