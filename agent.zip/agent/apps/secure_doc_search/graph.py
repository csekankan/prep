"""
SECURE RAG PIPELINE (LangGraph)
================================

    START → intent ──(asks for restricted category only)──► restricted ──► audit → END
              │
              ▼
           retrieve (filtered + re-checked) ──(nothing allowed)──► no_access ──► audit → END
              │
              ▼
           generate → output_guard → audit → END

Design notes:
- The AccessContext is put in state ONCE by the API from the validated token. No node accepts
  identity from the user's message — "I am in procurement" in the chat changes nothing.
- INTENT step is UX, not security: it lets us say "pricing is restricted" instead of a vague
  "not found" when an external worker asks for prices. Security comes from the retrieval filter.
- A mixed question ("yield strength AND price?") is still answered for the allowed part, with a
  note about the restricted part.
- OUTPUT GUARD is the last net: if a price pattern appears in an answer to a user without
  price.read, something upstream is wrong → block the answer and flag it in the audit log.
"""

import re
import uuid
from typing import Literal, TypedDict

from langchain.chat_models import init_chat_model
from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel, Field

from apps.secure_doc_search import audit
from apps.secure_doc_search.policy import AccessContext, category_allowed, restricted_message
from apps.secure_doc_search.search import secure_search

llm = init_chat_model("openai:gpt-4o-mini", temperature=0)
PRICE_PATTERN = re.compile(r"(EUR|USD|INR|€|\$|₹)\s?\d|\d\s?(EUR|USD|INR)|per\s+(tonne|ton|kg)", re.IGNORECASE)


class Intent(BaseModel):
    categories: list[Literal["material_spec", "pricing", "contract"]] = Field(
        description="All information categories the question asks about."
    )


class State(TypedDict):
    ctx: AccessContext
    request_id: str
    question: str
    restricted_notes: list[str]
    chunks: list[dict]
    denied_ids: list[str]
    answer: str
    decision: str
    guard_triggered: bool


def intent(state: State) -> dict:
    asked = llm.with_structured_output(Intent).invoke(
        f"Which categories does this question ask about? material_spec = properties/composition/specs; "
        f"pricing = prices/costs/discounts; contract = terms/payment/penalties.\nQuestion: {state['question']}"
    ).categories
    notes = [restricted_message(c) for c in asked if not category_allowed(state["ctx"], c)]
    only_restricted = bool(asked) and all(not category_allowed(state["ctx"], c) for c in asked)
    return {"restricted_notes": notes, "decision": "restricted_category" if only_restricted else ""}


def route_intent(state: State) -> str:
    return "restricted" if state["decision"] == "restricted_category" else "retrieve"


def restricted(state: State) -> dict:
    return {"answer": " ".join(state["restricted_notes"]), "chunks": [], "denied_ids": []}


def retrieve(state: State) -> dict:
    res = secure_search(state["ctx"], state["question"])
    return {"chunks": res.chunks, "denied_ids": res.denied_ids}


def route_retrieve(state: State) -> str:
    return "generate" if state["chunks"] else "no_access"


def no_access(state: State) -> dict:
    # Same message whether the doc doesn't exist or exists but is forbidden → no existence leak.
    note = " ".join(state["restricted_notes"])
    return {"answer": f"I couldn't find information you have access to. {note}".strip(), "decision": "no_access"}


def generate(state: State) -> dict:
    context = "\n\n".join(f"[{c['source']} › {c['section']}]\n{c['content']}" for c in state["chunks"])
    answer = llm.invoke(
        "Answer using ONLY the context. Cite as [source › section]. "
        "If the context doesn't cover part of the question, say that part isn't available.\n"
        f"<context>\n{context}\n</context>\nQuestion: {state['question']}"
    ).content
    if state["restricted_notes"]:
        answer += "\n\nNote: " + " ".join(state["restricted_notes"])
    return {"answer": answer, "decision": "answered"}


def output_guard(state: State) -> dict:
    if "price.read" not in state["ctx"].entitlements and PRICE_PATTERN.search(state["answer"]):
        return {
            "answer": "Sorry, I can't share that information. " + restricted_message("pricing"),
            "decision": "guard_blocked",
            "guard_triggered": True,
        }
    return {"guard_triggered": False}


def write_audit(state: State) -> dict:
    audit.record(
        state["ctx"], request_id=state["request_id"], query=state["question"], decision=state["decision"],
        returned=state.get("chunks", []), denied_ids=state.get("denied_ids", []),
        output_guard_triggered=state.get("guard_triggered", False),
    )
    return {}


builder = StateGraph(State)
for name, fn in [("intent", intent), ("restricted", restricted), ("retrieve", retrieve), ("no_access", no_access),
                 ("generate", generate), ("output_guard", output_guard), ("audit", write_audit)]:
    builder.add_node(name, fn)
builder.add_edge(START, "intent")
builder.add_conditional_edges("intent", route_intent, ["restricted", "retrieve"])
builder.add_conditional_edges("retrieve", route_retrieve, ["generate", "no_access"])
builder.add_edge("generate", "output_guard")
for n in ("restricted", "no_access", "output_guard"):
    builder.add_edge(n, "audit")
builder.add_edge("audit", END)
graph = builder.compile()


def ask(ctx: AccessContext, question: str) -> dict:
    out = graph.invoke({"ctx": ctx, "request_id": str(uuid.uuid4()), "question": question,
                        "restricted_notes": [], "guard_triggered": False, "decision": ""})
    return {"answer": out["answer"], "decision": out["decision"],
            "sources": sorted({f"{c['source']} › {c['section']}" for c in out.get("chunks", [])})}
