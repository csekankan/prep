"""
AUTHENTICATION + GROUP LOOKUP (who is this user, and which AD groups are they in?)
==================================================================================

CONCEPT DEEP DIVE
-----------------
AuthN vs AuthZ:
  AUTHENTICATION  = proving identity       → the identity provider (Entra ID / AD FS / Okta) does this
  AUTHORIZATION   = deciding what's allowed → OUR code does this (policy.py), using groups as input

Three ways to get a user's groups, from most to least common in modern setups:

1. MICROSOFT ENTRA ID (Azure AD) — OIDC/OAuth2 tokens
   - The SPA/web app signs the user in and gets an ACCESS TOKEN (a JWT) for our API.
   - Configure the app registration to emit the `groups` claim (security groups) — or better,
     map groups to APP ROLES so the token carries a short `roles` claim.
   - GROUP OVERAGE: if a user is in > 200 groups, the token has NO groups list; instead
     `_claim_names: {"groups": ...}` signals "ask Microsoft Graph". We then call
     Graph `getMemberGroups` (returns TRANSITIVE membership, i.e. nested groups too).

2. ON-PREM ACTIVE DIRECTORY via LDAP(S)
   - Query the domain controller for the user's groups, including NESTED groups with the
     special matching rule 1.2.840.113556.1.4.1941 (LDAP_MATCHING_RULE_IN_CHAIN).
   - Usually behind AD FS / Entra Connect in web apps; direct LDAP is common for internal tools.

3. DEV MODE — fake users for local testing and evals (never enabled in prod).

JWT validation checklist (all mandatory — skipping any one is a vulnerability):
  ✔ signature with the provider's public keys (JWKS), ✔ algorithm pinned (RS256),
  ✔ issuer = our tenant, ✔ audience = our API, ✔ not expired.

CACHING & REVOCATION: Graph/LDAP lookups are slow (50–300 ms), so cache groups per user with a
short TTL (e.g. 10 min). Trade-off: removing someone from a group takes up to TTL + token lifetime
to take effect. For high-risk data, shorten both or use continuous access evaluation.
"""

import os
import time
from dataclasses import dataclass, field

import httpx
import jwt
from jwt import PyJWKClient

TENANT_ID = os.environ.get("ENTRA_TENANT_ID", "00000000-0000-0000-0000-000000000000")
API_AUDIENCE = os.environ.get("ENTRA_API_AUDIENCE", "api://secure-doc-search")
CLIENT_ID = os.environ.get("ENTRA_CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("ENTRA_CLIENT_SECRET", "")   # from a secret manager in prod
AUTH_MODE = os.environ.get("AUTH_MODE", "entra")            # entra | ldap | dev

ISSUER = f"https://login.microsoftonline.com/{TENANT_ID}/v2.0"
JWKS_URL = f"https://login.microsoftonline.com/{TENANT_ID}/discovery/v2.0/keys"
GROUP_CACHE_TTL_S = 600


@dataclass
class Identity:
    user_id: str                 # Entra `oid` — stable, unique; never use email as the key
    username: str
    group_ids: list[str] = field(default_factory=list)


class AuthError(Exception):
    pass


# ================================================================ 1. Entra ID
_jwks = PyJWKClient(JWKS_URL, cache_keys=True)   # fetches + caches the provider's signing keys
_group_cache: dict[str, tuple[float, list[str]]] = {}


def validate_entra_token(token: str) -> Identity:
    try:
        signing_key = _jwks.get_signing_key_from_jwt(token)
        claims = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],          # pin the algorithm (prevents "alg: none" / HS256 tricks)
            audience=API_AUDIENCE,
            issuer=ISSUER,
            options={"require": ["exp", "iat", "oid"]},
        )
    except jwt.PyJWTError as exc:
        raise AuthError(f"invalid token: {exc}") from exc

    user_id = claims["oid"]
    if "groups" in claims:
        groups = claims["groups"]
    elif "groups" in claims.get("_claim_names", {}):
        groups = _graph_member_groups(user_id)     # overage → ask Graph
    else:
        groups = []                                 # default deny downstream
    return Identity(user_id=user_id, username=claims.get("preferred_username", ""), group_ids=groups)


def _graph_app_token() -> str:
    """App-only token (client credentials) for Microsoft Graph. Needs the
    GroupMember.Read.All (or Directory.Read.All) application permission with admin consent."""
    import msal

    app = msal.ConfidentialClientApplication(
        CLIENT_ID, authority=f"https://login.microsoftonline.com/{TENANT_ID}", client_credential=CLIENT_SECRET
    )
    result = app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])
    if "access_token" not in result:
        raise AuthError(f"graph token failed: {result.get('error_description')}")
    return result["access_token"]


def _graph_member_groups(user_id: str) -> list[str]:
    cached = _group_cache.get(user_id)
    if cached and time.time() - cached[0] < GROUP_CACHE_TTL_S:
        return cached[1]
    resp = httpx.post(
        f"https://graph.microsoft.com/v1.0/users/{user_id}/getMemberGroups",
        headers={"Authorization": f"Bearer {_graph_app_token()}"},
        json={"securityEnabledOnly": True},   # transitive: includes nested group membership
        timeout=10,
    )
    resp.raise_for_status()
    groups = resp.json()["value"]
    _group_cache[user_id] = (time.time(), groups)
    return groups


# ================================================================ 2. On-prem AD via LDAP
def ldap_groups(username: str) -> Identity:
    """Look up a user's groups (incl. nested) directly from a domain controller over LDAPS."""
    from ldap3 import SUBTREE, Connection, Server

    server = Server(os.environ["LDAP_URL"], use_ssl=True)   # ldaps://dc01.corp.example.com
    conn = Connection(server, user=os.environ["LDAP_BIND_DN"], password=os.environ["LDAP_BIND_PASSWORD"], auto_bind=True)
    base = os.environ["LDAP_BASE_DN"]                         # DC=corp,DC=example,DC=com

    conn.search(base, f"(&(objectClass=user)(sAMAccountName={_ldap_escape(username)}))", SUBTREE,
                attributes=["distinguishedName", "objectGUID"])
    if not conn.entries:
        raise AuthError("user not found")
    user = conn.entries[0]
    user_dn = user.distinguishedName.value

    # 1.2.840.113556.1.4.1941 = walk the membership chain → nested groups included.
    conn.search(base, f"(&(objectClass=group)(member:1.2.840.113556.1.4.1941:={_ldap_escape(user_dn)}))",
                SUBTREE, attributes=["objectGUID", "cn"])
    return Identity(
        user_id=str(user.objectGUID.value),
        username=username,
        group_ids=[str(g.objectGUID.value) for g in conn.entries],
    )


def _ldap_escape(value: str) -> str:
    """Prevent LDAP injection (e.g. a username like '*)(cn=*')."""
    from ldap3.utils.conv import escape_filter_chars

    return escape_filter_chars(value)


# ================================================================ 3. dev users (local + evals)
DEV_USERS = {
    "dev-external-pune": Identity("u-ext-1", "ravi.contractor@vendor.com",
                                  ["6f1c2a10-0000-4000-8000-000000000002", "6f1c2a10-0000-4000-8000-000000000010"]),
    "dev-procurement": Identity("u-proc-1", "anna.buyer@corp.com",
                                ["6f1c2a10-0000-4000-8000-000000000001", "6f1c2a10-0000-4000-8000-000000000003",
                                 "6f1c2a10-0000-4000-8000-000000000011"]),
    # Misassignment case: external worker wrongly added to SG-Procurement → deny rule must still block prices.
    "dev-external-misassigned": Identity("u-ext-2", "temp@vendor.com",
                                         ["6f1c2a10-0000-4000-8000-000000000002", "6f1c2a10-0000-4000-8000-000000000003"]),
    "dev-nobody": Identity("u-none", "unknown@corp.com", []),
}


def authenticate(bearer_token: str) -> Identity:
    if AUTH_MODE == "dev":
        if bearer_token not in DEV_USERS:
            raise AuthError("unknown dev user")
        return DEV_USERS[bearer_token]
    return validate_entra_token(bearer_token)
