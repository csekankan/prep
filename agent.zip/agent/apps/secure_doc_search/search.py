"""
SECURE RETRIEVER: filter in the database, re-check in code, report what was denied.

The retriever is the ONLY way the rest of the app can reach documents — there is no
"unfiltered search" function to call by mistake. Requiring an AccessContext argument makes
forgetting authorization a type error rather than a data leak.
"""

import os
from dataclasses import dataclass

from langchain_openai import OpenAIEmbeddings
from qdrant_client import QdrantClient

from apps.secure_doc_search.ingest import COLLECTION
from apps.secure_doc_search.policy import AccessContext, can_access, retrieval_filter

client = QdrantClient(url=os.environ.get("QDRANT_URL", "http://localhost:6333"),
                      api_key=os.environ.get("QDRANT_API_KEY"), timeout=10)
embedder = OpenAIEmbeddings(model="text-embedding-3-small")


@dataclass
class SecureResult:
    chunks: list[dict]
    denied_ids: list[str]        # for the audit log only — never shown to the user


def secure_search(ctx: AccessContext, query: str, k: int = 5) -> SecureResult:
    result = client.query_points(
        COLLECTION,
        query=embedder.embed_query(query),
        query_filter=retrieval_filter(ctx),   # enforcement point #1: inside the vector search
        limit=k,
        with_payload=True,
        score_threshold=0.25,
    )
    allowed, denied = [], []
    for p in result.points:
        # Enforcement point #2: if this ever triggers, the filter is broken → alert security.
        if can_access(ctx, p.payload):
            allowed.append({"id": str(p.id), "score": p.score, **p.payload})
        else:
            denied.append(str(p.id))
    return SecureResult(chunks=allowed, denied_ids=denied)
