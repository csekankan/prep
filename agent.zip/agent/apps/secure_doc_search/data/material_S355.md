---
site: ALL
owner: materials-engineering
---

# Mechanical Properties

Structural steel grade S355J2 (EN 10025-2). Minimum yield strength 355 MPa for thickness up to
16 mm. Tensile strength 470–630 MPa. Minimum elongation 22%. Impact energy 27 J at -20 °C.

# Chemical Composition

Carbon max 0.20%, Manganese max 1.60%, Silicon max 0.55%, Phosphorus max 0.025%,
Sulfur max 0.025%. Carbon equivalent (CEV) max 0.45% for thickness up to 30 mm.

# Supplier Pricing

Current negotiated price with SteelCo GmbH: EUR 742 per tonne (FCA Hamburg), valid until
2026-12-31. Volume discount 3% above 500 tonnes per quarter. Previous quarter: EUR 768 per tonne.

# Contract Terms

Framework agreement FA-2025-118 with SteelCo GmbH. Payment terms 60 days net.
Penalty for late delivery: 0.5% per week, capped at 5%. Termination with 90 days notice.
