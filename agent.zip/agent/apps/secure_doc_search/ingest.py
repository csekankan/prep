"""
INGESTION WITH SECURITY LABELS
===============================

CONCEPT DEEP DIVE
-----------------
Permission-aware RAG is only as good as its LABELS. Every chunk must carry, at minimum:
  required_entitlement  which entitlement is needed to read it
  site                  ABAC scope (or "ALL")
  data_category         human-meaningful class (material_spec / pricing / contract)
  source, section       for citations and audits

Where labels come from (in order of preference):
  1. SOURCE-SYSTEM ACLs — e.g. SharePoint/Confluence permissions synced at ingestion
     (the doc's allowed groups become chunk metadata). Keeps one source of truth.
  2. DOCUMENT METADATA — front matter / document properties set by the owner (`site: ALL` here).
  3. SECTION CLASSIFICATION — map headings to categories, with an LLM classifier for unknown headings.
     Needed because ONE document often mixes sensitivity levels (spec + pricing in the same file).

Granularity matters: chunk by SECTION so a pricing paragraph never shares a chunk with material
data. If a chunk is mixed, label it with the MOST restrictive category.

Fail closed: if classification is uncertain, label as the most restrictive category and send the
section to a human for review.
"""

import hashlib
import re
from pathlib import Path
from typing import Literal

import yaml
from langchain.chat_models import init_chat_model
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import MarkdownHeaderTextSplitter
from pydantic import BaseModel
from qdrant_client import QdrantClient, models

from apps.secure_doc_search.policy import load_policy

DATA_DIR = Path(__file__).parent / "data"
COLLECTION = "secure_docs_v1"
RESTRICTIVENESS = ["material_spec", "contract", "pricing"]  # later = more restrictive

HEADING_RULES = {
    r"pric|cost|rate card|discount|tariff": "pricing",
    r"contract|terms|agreement|penalt|payment": "contract",
    r"propert|composition|specification|dimension|tolerance|standard": "material_spec",
}


class SectionLabel(BaseModel):
    category: Literal["material_spec", "pricing", "contract"]
    confident: bool


_classifier = init_chat_model("openai:gpt-4o-mini", temperature=0).with_structured_output(SectionLabel)


def classify_section(heading: str, text: str) -> str:
    rule_hits = [cat for pattern, cat in HEADING_RULES.items() if re.search(pattern, heading, re.I)]
    # Content check catches prices hidden in "innocent" sections (e.g. a cost line inside specs).
    if re.search(r"(EUR|USD|INR|€|\$|₹)\s?\d|per\s+tonne|per\s+kg", text, re.I):
        rule_hits.append("pricing")
    if rule_hits:
        return max(rule_hits, key=RESTRICTIVENESS.index)
    label = _classifier.invoke(f"Classify this document section.\nHeading: {heading}\nText: {text[:1500]}")
    return label.category if label.confident else "pricing"   # fail closed


def split_with_front_matter(path: Path) -> tuple[dict, list]:
    raw = path.read_text()
    meta = {}
    if raw.startswith("---"):
        _, fm, raw = raw.split("---", 2)
        meta = yaml.safe_load(fm)
    sections = MarkdownHeaderTextSplitter([("#", "section")]).split_text(raw)
    return meta, sections


def build_points(path: Path, embedder) -> list[models.PointStruct]:
    categories = load_policy()["categories"]
    meta, sections = split_with_front_matter(path)
    texts, payloads = [], []
    for s in sections:
        heading = s.metadata.get("section", "")
        category = classify_section(heading, s.page_content)
        texts.append(f"{path.stem} > {heading}\n{s.page_content}")
        payloads.append({
            "content": s.page_content,
            "source": path.name,
            "section": heading,
            "data_category": category,
            "required_entitlement": categories[category],
            "site": meta.get("site", "ALL"),
            "owner": meta.get("owner", "unknown"),
        })
    vectors = embedder.embed_documents(texts)
    return [
        models.PointStruct(
            id=hashlib.md5(f"{p['source']}|{p['section']}".encode()).hexdigest(),  # 32 hex chars = valid UUID
            vector=v,
            payload=p,
        )
        for v, p in zip(vectors, payloads)
    ]


def main(client: QdrantClient) -> None:
    embedder = OpenAIEmbeddings(model="text-embedding-3-small")
    if not client.collection_exists(COLLECTION):
        client.create_collection(COLLECTION, vectors_config=models.VectorParams(size=1536, distance=models.Distance.COSINE))
        # Index every field used in security filters — filters must be fast AND exact.
        for key in ("required_entitlement", "site", "data_category", "source"):
            client.create_payload_index(COLLECTION, key, field_schema=models.PayloadSchemaType.KEYWORD)
    for path in DATA_DIR.glob("*.md"):
        points = build_points(path, embedder)
        client.upsert(COLLECTION, points=points, wait=True)
        print(path.name, [(p.payload["section"], p.payload["data_category"]) for p in points])
