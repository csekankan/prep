"""
AUDIT LOG — who asked what, and what data they were (and weren't) given.

Required for regulated data and invaluable for incident response ("did any external user ever
receive a pricing chunk?" must be answerable with one query).

Rules:
- Structured JSON, one event per request, shipped to an append-only store (CloudWatch Logs with
  retention lock, S3 Object Lock, SIEM like Splunk/Sentinel).
- Log chunk IDs and categories, NOT chunk contents (the audit log must not become a leak itself).
- Log the user's resolved entitlements AT THE TIME of the request (groups change later).
"""

import json
import logging
import time

from apps.secure_doc_search.policy import AccessContext

audit_logger = logging.getLogger("audit")


def record(ctx: AccessContext, *, request_id: str, query: str, decision: str,
           returned: list[dict], denied_ids: list[str], output_guard_triggered: bool) -> None:
    audit_logger.info(json.dumps({
        "ts": time.time(),
        "type": "doc_search",
        "request_id": request_id,
        "user_id": ctx.user_id,
        "username": ctx.username,
        "employment": ctx.employment,
        "groups": list(ctx.matched_groups),
        "entitlements": sorted(ctx.entitlements),
        "sites": sorted(ctx.sites),
        "query_chars": len(query),          # store the query itself only if your policy allows it
        "decision": decision,                # answered | restricted_category | no_access | guard_blocked
        "returned_chunks": [{"id": c["id"], "category": c["data_category"], "source": c["source"]} for c in returned],
        "filter_violations": denied_ids,     # non-empty = filter bug → page security
        "output_guard_triggered": output_guard_triggered,
    }))
