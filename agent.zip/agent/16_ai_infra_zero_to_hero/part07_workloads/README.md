# Part VII — Workload-Specific Infrastructure (Sections 24–30, lectures 162–210)

How infrastructure changes with the workload: data pipelines, generative AI (RAG, LLM serving, fine-tuning),
computer vision, NLP, multimodal, and reinforcement learning.

| § | Section | You will be able to | Exercise |
|---|---|---|---|
| 24 | [Data Pipelines for AI at Scale](s24_data_pipelines.md) | Build idempotent ELT and Airflow DAGs, run Kafka durably, serve point-in-time-correct features, and window streams with watermarks | [`s24_stream_windows.py`](../exercises/s24_stream_windows.py) |
| 25 | [Generative AI Infrastructure Foundations](s25_genai_foundations.md) | Size weights and KV cache, choose vector indexes, build permission-aware RAG with evals, cache safely, and serve LLMs behind a gateway | [`s25_permission_rag.py`](../exercises/s25_permission_rag.py) |
| 26 | [Advanced Generative AI Infrastructure](s26_genai_advanced.md) | Choose ZeRO stages and 3D parallelism, use Flash Attention, plan multi-node runs, compute LoRA/QLoRA exactly, and budget with 6·N·D | [`s26_lora_params.py`](../exercises/s26_lora_params.py) |
| 27 | [Computer Vision Infrastructure at Scale](s27_computer_vision.md) | Do the video bytes math, keep CV training fed, pick models by latency, and serve multi-stream video with DeepStream at the edge | — |
| 28 | [NLP Infrastructure at Scale](s28_nlp_infrastructure.md) | Version tokenizers, serve encoders and embeddings, cut latency by controlling length, and run multilingual models per language | — |
| 29 | [Multimodal AI Infrastructure](s29_multimodal.md) | Build image-text pipelines, train and serve CLIP, budget voice turns, index video segments, and bound multimodal requests | — |
| 30 | [Reinforcement Learning Infrastructure](s30_reinforcement_learning.md) | Balance actors and learners, scale simulators, design LLM RL fine-tuning, and serve policies safely with OPE | — |

```mermaid
flowchart LR
  P6["Part VI: edge<br/>and mobile"] --> S24["§24 Data pipelines<br/>batch, streaming, features"]
  S24 --> S25["§25 GenAI foundations<br/>LLM serving, RAG"]
  S25 --> S26["§26 Advanced GenAI<br/>ZeRO, Megatron, LoRA"]
  S24 --> S27["§27 Vision"]
  S24 --> S28["§28 NLP"]
  S27 --> S29["§29 Multimodal"]
  S28 --> S29
  S25 --> S29
  S26 --> S30["§30 Reinforcement learning<br/>incl. LLM RL"]
  S29 --> NEXT["Part VIII: scale,<br/>MLOps, optimization"]
  S30 --> NEXT
```

**How to read it:** Section 24's data pipelines feed every workload. Generative AI comes next (serving and
RAG in Section 25, training and fine-tuning in Section 26). Vision and NLP each have their own
infrastructure patterns, and they combine in multimodal systems. Reinforcement learning reuses the LLM
training and serving stack for RL fine-tuning. Part VIII then scales training and MLOps to enterprise size.
