# Section 30 — Reinforcement Learning Infrastructure

> Lectures 204–210 • Assessment: quiz
> **After this section you can:** explain the actor-learner structure of RL workloads and where their
> bottlenecks are, choose and scale simulators (Gymnasium, MuJoCo, Isaac Lab), design distributed RL
> training (IMPALA, Ape-X, RLlib) and RL fine-tuning of LLMs, serve RL policies safely in real time, scale
> robot learning from simulation and fleets, run online learning agents (bandits) with logged propensities and
> guardrails, and train and serve a policy with Ray RLlib.
>
> Go deeper: [13 / Lab 31 — Ray and KubeRay architecture](../../13_sovereign_ai_infra_course/03_distributed_training/lab31_ray_kuberay_architecture.md),
> [Lab 32 — Ray Core jobs](../../13_sovereign_ai_infra_course/03_distributed_training/lab32_ray_core_jobs.md),
> [Lab 38 — Volcano gang scheduling](../../13_sovereign_ai_infra_course/03_distributed_training/lab38_volcano_gang_scheduling.md),
> [Lab 08 — Local vLLM sandbox](../../13_sovereign_ai_infra_course/01_foundations_local_sandbox/lab08_local_vllm_sandbox.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 204 | Basics of RL workloads | Actors generate experience, learners update the policy. The data comes from the model itself |
| 205 | Simulation environments (Gym, Isaac) | Simulator throughput is the budget. GPU-parallel physics runs thousands of environments per GPU |
| 206 | Distributed RL training infrastructures | Scale actors on CPUs, learners on GPUs, and manage policy lag (IMPALA, Ape-X, RLlib) |
| 207 | Real-time serving of RL agents | Tiny models with hard deadlines, safety layers, logged action probabilities, and off-policy evaluation |
| 208 | Scaling RL for robotics | Sim-to-real with domain randomization, fleet data, and on-robot inference at control rates |
| 209 | Infrastructure for online learning agents | Bandits and continual learners need propensity logging, exploration budgets, and rollback |
| 210 | Lab: train an RL agent with Ray RLlib | PPO on CartPole, scaling env runners, checkpointing, and serving the policy |

```mermaid
flowchart LR
  subgraph ACT["Actors (many, CPU or GPU sim)"]
    ENV["Environment or simulator"] <--> POL["Policy copy<br/>version k"]
  end
  POL --> EXP["Experience<br/>obs, action, reward, logprob"]
  EXP --> BUF[("Buffer<br/>on-policy batch or replay")]
  BUF --> LRN["Learner<br/>GPU, PPO, IMPALA, SAC"]
  LRN --> W["New weights k+1"]
  W -->|"broadcast"| POL
  LRN --> CK[("Checkpoints + metrics<br/>return, steps/s, policy lag")]
  CK --> SERVE["Deployed policy<br/>safety layer + logging"]
  SERVE -->|"logged interactions"| BUF
```

**How to read it:** RL training is a loop. Many actors run the current policy in environments and record
experience. A learner on GPUs uses that experience to improve the policy and broadcasts new weights back to
the actors. Unlike supervised learning, the training data is produced by the model being trained, so actor
throughput, weight freshness, and data flow are the infrastructure problems.

**Terms in this diagram.**
- **Actors**: worker processes that let the policy act in environments and record what happens.
- **Environment or simulator**: the world the agent acts in, such as a game, a physics simulation, or a real system.
  Each step, it takes an action and returns a new observation and a reward.
- **Policy, version k**: the model that chooses actions from observations. Each actor holds a copy of the version
  it last received.
- **Experience: obs, action, reward, logprob**: what the agent saw (**observation**), what it did, the **reward**
  score it received, and the **log probability** the policy gave that action, which many algorithms need.
- **On-policy batch or replay**: some algorithms use only freshly collected data, and others keep a **replay buffer**
  of past data (Lecture 204).
- **Learner, PPO, IMPALA, SAC**: the GPU process that updates the policy. **PPO** (Proximal Policy Optimization),
  **IMPALA** (a scalable actor-learner architecture), and **SAC** (Soft Actor-Critic) are common algorithms.
- **Broadcast**: sending the new weights to every actor.
- **Return, steps/s, policy lag**: **return** is the total reward per episode, the main measure of how well the agent
  does. **Steps/s** is environment steps per second. **Policy lag** is how many versions behind the actors' policy is.
- **Safety layer**: rules around a deployed policy that block dangerous actions (Lecture 207).

---

## Lecture 204 — Basics of reinforcement learning workloads

**Why it matters.** RL powers game agents, robotics, recommendation and ads optimization, chip and data center
control, and, most commonly today, the fine-tuning of LLMs with human or verifiable rewards (RLHF, GRPO). Its
compute profile is unlike supervised training: experience generation often costs more than gradient
updates.

**In plain words.** Learning to ride a bike by trying: each attempt (an episode) produces experience,
and you adjust after seeing what worked. The faster you can attempt, the faster you learn, so most of the
infrastructure is about generating attempts quickly and feeding them to the "brain" that adjusts.

**Architecture: on-policy vs off-policy data flow.**

```mermaid
flowchart LR
  subgraph ON["On-policy (PPO, GRPO)"]
    A1["Collect a fresh batch<br/>with current policy"] --> U1["Several gradient epochs<br/>on that batch"]
    U1 --> D1["Discard batch"]
    D1 --> A1
  end
  subgraph OFF["Off-policy (DQN, SAC)"]
    A2["Actors add transitions continuously"] --> RB[("Replay buffer<br/>millions of transitions")]
    RB --> U2["Learner samples minibatches<br/>reuses old data"]
    U2 --> A2
  end
```

**How to read it:** on-policy methods collect a batch with the current policy, learn from it, and throw it
away, which is simple and stable but needs lots of fresh experience. Off-policy methods keep a large replay buffer
and reuse old experience many times, which is more sample-efficient but needs buffer memory and careful
handling of stale data.

In the diagram, **GRPO** (Group Relative Policy Optimization) is a PPO variant widely used to train LLMs with
rewards. **DQN** (Deep Q-Network) is the classic off-policy method that learned to play Atari games. A **gradient
epoch** is one full pass of updates over the batch. A **transition** is one step of experience: observation, action,
reward, next observation. A **minibatch** is a small random sample drawn from the buffer for one update. **Sample-
efficient** means it needs fewer environment steps to learn.

**Core ideas.**
- **Vocabulary.** Environment, observation, action, reward, episode, policy (π), value function, return.
- **Algorithms by infrastructure profile.**
  - PPO: on-policy, the default for many tasks and for LLM RLHF.
  - GRPO: on-policy without a value model, using group-relative rewards. It's popular for reasoning LLMs.
  - DQN and SAC: off-policy, with replay.
  - IMPALA: off-policy-corrected actor-learner.
- **Cost split.** Simulation and rollouts (CPU-heavy for classic environments, GPU-heavy for LLM generation) vs
  learner updates (GPU). The ratio decides the hardware mix.
- **Metrics.** Environment steps per second, sample efficiency (return vs steps), policy lag (how many versions
  old the acting policy is), learner utilization, and episode return mean and variance across seeds.
- **Reproducibility.** RL is high-variance. Run several seeds, and fix seeds and simulator versions.

**Example: the misplaced GPUs.** A team ran PPO on a CPU-based physics simulator with 8 GPUs and 16 CPU
cores per node. The learner took 0.3 s per update, but collecting the batch took 14 s. The GPUs were idle
97% of the time. Re-provisioning to 1 GPU and 96 CPU cores per job (and running 6× more parallel environments)
cut wall-clock time by 5× at lower cost.

**Senior / FAANG best practice.** Profile the loop before buying hardware: measure environment steps/s,
rollout time, and learner time, and size actors vs learners from the ratio. Report results across several
seeds, track policy lag, and version simulators and reward functions like code.

---

## Lecture 205 — Simulation environments for RL (Gym, Isaac)

**Why it matters.** Most RL learns in simulation, because real-world trials are slow, expensive, or
dangerous. The simulator's speed caps how fast you can learn, and its realism caps how well the policy
transfers. Choosing and scaling simulators is a core RL infrastructure decision.

**In plain words.** Pilots train in flight simulators before flying real planes. A faster simulator
means more practice hours per day. A more realistic one means the practice counts for more in a real cockpit.

**Architecture: CPU-vectorized vs GPU-parallel simulation.**

```mermaid
flowchart LR
  subgraph CPUV["CPU vectorized (Gymnasium, MuJoCo)"]
    W1["Worker process 1<br/>N envs"] --> OBS1["obs batch"]
    W2["Worker process M<br/>N envs"] --> OBS1
    OBS1 --> PI1["Policy on GPU or CPU"]
    PI1 --> W1
    PI1 --> W2
  end
  subgraph GPUP["GPU parallel (Isaac Lab, MJX, Brax)"]
    SIM["Thousands of envs<br/>as tensors on one GPU"] <--> PI2["Policy on the same GPU<br/>no host copies"]
  end
```

**How to read it:** classic simulators step environments on CPU cores, so you scale by adding worker
processes and cores, and observations move to the policy each step. GPU-parallel simulators keep thousands
of environments as tensors on the GPU next to the policy, so stepping and inference happen without leaving
the device, often 100–1,000× more steps per second per machine.

In the diagram, **envs** is short for environments. **Vectorized** means one process steps N copies of the environment together and returns their
observations as one batch. **Gymnasium** is the standard Python API for RL environments (the successor of OpenAI
Gym). **MuJoCo** is a fast physics engine for robots and bodies. **Isaac Lab** is NVIDIA's GPU robotics simulation
framework, and **MJX** (MuJoCo on JAX) and **Brax** are GPU and TPU physics engines from Google. **No host copies**
means data never travels between CPU memory and GPU memory.

**Core ideas.**
- **Gymnasium** (the maintained successor of OpenAI Gym) is the standard API: `reset()` returns
  `(obs, info)`, and `step(action)` returns `(obs, reward, terminated, truncated, info)`. Vector environments step many
  copies at once.
- **Physics.** MuJoCo (open source, the standard for control), MJX (MuJoCo on JAX for GPUs and TPUs), Brax,
  PyBullet, and NVIDIA Isaac Sim with Isaac Lab (GPU physics, rendering, robot assets; successor to Isaac Gym).
- **GPU-parallel results.** Legged-robot locomotion policies train in minutes with ~4,000 parallel
  environments on a single GPU, which once took days on CPU clusters.
- **Rendering** (camera observations) is much more expensive than physics state. Use low resolution, tiled
  rendering, or state-based training with vision distillation later.
- **Custom environments.** Wrap business simulators (inventory, data center cooling, ad auctions) behind the
  Gymnasium API, and validate them against historical data before trusting the results.

```python
import gymnasium as gym
envs = gym.make_vec("CartPole-v1", num_envs=16, vectorization_mode="async")      # 16 envs in subprocesses
obs, info = envs.reset(seed=0)
for _ in range(1000):
    obs, reward, terminated, truncated, info = envs.step(envs.action_space.sample())  # autoreset per env
envs.close()
```

**Example: from cluster to GPU.** A warehouse-robot team trained grasping on a CPU simulator cluster with 2,000
cores, at ~40,000 steps/s. Porting the environment to Isaac Lab on 8 GPUs, with 4,096 environments per GPU and
state observations, reached ~1.5 M steps/s. Experiments that took 2 days finished in about an hour, and
the team could sweep reward designs 20× faster.

**Senior / FAANG best practice.** Treat the simulator as production code: version it, test it, and
validate it against real data. Choose GPU-parallel simulation when physics allows, start from state-based
observations, and track steps/s per dollar. Pin simulator and physics settings with every result, since tiny
changes alter policies.

---

## Lecture 206 — Distributed RL training infrastructures

**Why it matters.** Hard RL problems need billions of environment steps. Distributed architectures scale
experience generation across hundreds of actors while keeping learners busy and policies fresh, and their
design decides throughput, stability, and cost.

**In plain words.** Many scouts explore the territory and send reports to one strategist, who updates the
map and sends it back. Scouts using an old map make worse reports, so the system must keep maps fresh, or
correct for the old ones.

**Architecture: an IMPALA-style actor-learner system.**

```mermaid
flowchart LR
  subgraph ACTORS["Actors: hundreds of CPU workers"]
    A1["Actor 1<br/>policy v(k-2)"]
    A2["Actor 2<br/>policy v(k-1)"]
    AN["Actor N<br/>policy v(k)"]
  end
  A1 -->|"trajectories"| Q[("Trajectory queue")]
  A2 --> Q
  AN --> Q
  Q --> L["Learner GPUs<br/>V-trace off-policy correction"]
  L --> PS["Parameter server or broadcast"]
  PS -->|"latest weights"| A1
  PS --> A2
  PS --> AN
  MON["Metrics: steps/s, queue depth,<br/>policy lag, learner util"] -.-> L
```

**How to read it:** actors run independently, each with a slightly stale copy of the policy, and push
trajectories into a queue. The learner consumes batches as fast as it can, and corrects for actors' stale
policies with V-trace. Fresh weights are broadcast back regularly. Queue depth and policy lag show whether
actors or the learner are the bottleneck.

In the diagram, `v(k-2)` means policy version k minus 2, two updates older than the newest. A **trajectory** is a
sequence of consecutive steps from one actor. **V-trace** is IMPALA's **off-policy correction**: it re-weights each
step by how likely the *current* policy would have been to take that action, so learning from slightly old data
stays correct. A **parameter server** is a service holding the latest weights that actors fetch from. **Queue
depth** growing means the learner is too slow. Near zero means actors are too slow. **Learner util** is how busy the
learner GPUs are.

**Core ideas.**
- **Architectures.**
  - **IMPALA:** decoupled actors with V-trace correction, for high throughput.
  - **Ape-X / R2D2:** distributed prioritized replay.
  - **SEED RL:** central GPU inference for all actors, with only environment stepping on actors.
  - **Synchronous PPO:** gather, then update. It's simpler, but waits for the slowest actor.
- **Frameworks.** Ray RLlib (EnvRunners for sampling, Learners for updates, and scaling on Ray and KubeRay),
  Sample Factory (single-machine throughput), TorchRL, CleanRL (single-file references), and for LLM RL,
  TRL, OpenRLHF, and verl.
- **RL for LLMs** has the same structure. Rollouts are LLM generation (vLLM or SGLang), rewards come from reward
  models or verifiers (unit tests, math checkers in sandboxes), and the learner is a sharded LLM trainer. Weight sync
  from trainer to generator (GBs per step) and long-tail generation lengths are the key infrastructure issues.
- **Scheduling.** Gang-schedule learners (Lab 38 in course 13), autoscale actors elastically, and use
  spot or preemptible capacity for stateless actors.

**Example: finding the bottleneck.** An IMPALA run's learner utilization sat at 35% and the trajectory queue
was always empty, so the actors were the bottleneck. Doubling actors from 256 to 512 raised learner utilization
to 80%. Going to 1,024 filled the queue, raised policy lag from ~2 to ~9 versions, and made learning curves
noisier. They settled at 640 actors, which is the point where the queue stays non-empty with lag ≤ 3.

**Senior / FAANG best practice.** Instrument queue depth, policy lag, steps/s, and learner utilization,
scale actors until the learner is busy and lag stays bounded, put stateless actors on cheap preemptible
capacity, and gang-schedule learners. For LLM RL, plan weight-sync bandwidth and generation length
tails explicitly.

---

## Lecture 207 — Real-time serving of RL agents

**Why it matters.** Deployed RL policies make decisions under deadlines: a bid in 10 ms, a robot command
every 20 ms, a cooling setpoint every minute. Because they act, mistakes have direct consequences, and the
decisions they make shape the data you'll learn from next.

**In plain words.** A self-driving student driver needs an instructor with a brake pedal. The policy
decides, a safety layer can override it, and every decision is written down with how confident it was, so
the next lesson can learn from it.

**Architecture: a policy serving stack.**

```mermaid
flowchart LR
  REQ["State or observation<br/>from app or robot"] --> FEAT["Featurize<br/>same code as training"]
  FEAT --> POL["Policy inference<br/>small model, under 1-5 ms"]
  POL --> SAFE["Safety layer<br/>action masks, limits,<br/>fallback controller"]
  SAFE --> ACT["Action"]
  POL --> LOG["Log: state, action,<br/>action probability, version"]
  ACT --> ENVR["Real world"]
  ENVR -->|"reward, delayed"| LOG
  LOG --> OPE["Off-policy evaluation<br/>of candidate policies"]
  OPE --> GATE["Release gate"]
  GATE --> POL
```

**How to read it:** observations are featurized with the exact training code, the policy proposes an
action, and a safety layer enforces hard constraints or falls back to a known-safe controller. Every decision
is logged with the action probability and policy version. Rewards arrive later, and the logs let you
evaluate new candidate policies offline before any of them touch production.

In the diagram, to **featurize** is to turn raw state into the model's input numbers. **Action masks** remove actions
that aren't allowed in the current state. **Limits** clamp values, for example maximum speed or price change. A
**fallback controller** is a simple, proven rule-based controller used when the policy's output is unsafe or missing.
**Reward, delayed** means the outcome (a purchase, a task completed) is only known later. **Off-policy evaluation**
(OPE) estimates how a new policy *would* have performed using the logged decisions and their probabilities, without
deploying it. The **release gate** blocks candidates that don't beat the current policy safely.

**Core ideas.**
- **Latency.** Policies are often small MLPs or transformers, so they run in-process (ONNX Runtime, TorchScript) or on
  the device for robots. Design for p99.9 under the deadline, and handle a timeout with a safe default action.
- **Safety layers.** Action masking (invalid actions impossible), clipping to physical or business limits, rate
  limits on changes, and rule-based fallbacks when inputs are out of distribution.
- **Logging propensities.** Store the probability of the chosen action. It's required for off-policy evaluation
  (inverse propensity scoring, doubly robust estimators) and for training the next policy correctly.
- **Off-policy evaluation (OPE).** Estimate a new policy's value from logged data before deploying it, then shadow
  it, then canary with bounded exposure.
- **Determinism.** Use greedy or low-temperature actions for safety-critical decisions, and controlled
  exploration elsewhere (Lecture 209).

**Example: the bidding agent.** An ad-bidding RL policy had a 10 ms deadline. It ran in-process as an INT8
ONNX MLP (~0.2 ms), behind clipping to campaign budget pacing limits, with a rule-based bidder as fallback when
features were missing. A new policy showed +6% value in doubly robust OPE on logged data. In a 5% canary, it
showed +4.8%, inside the OPE confidence interval, so it ramped to 100% with an automatic rollback on spend anomalies.

**Senior / FAANG best practice.** Serve policies with hard latency budgets and safe defaults, put a
deterministic safety layer between the policy and the world, log state, action, propensity, and version for
every decision, and gate releases on off-policy evaluation, shadow, and canary. Never deploy an RL policy
straight from training curves.

---

## Lecture 208 — Scaling RL for robotics

**Why it matters.** Robots must learn in simulation (fast, safe) but act in the real world (noisy, varied),
and real-world data is expensive. Robotics infrastructure combines massive simulation, fleet data
collection, large policy models, and on-robot inference at control rates.

**In plain words.** Practice a dance in a mirror-lined studio (simulation), then perform on stages with
different floors and lights (reality). Practicing on many varied studio floors makes the real stage
less surprising (domain randomization).

**Architecture: a robot learning flywheel.**

```mermaid
flowchart LR
  SIMR["GPU simulation<br/>domain randomization"] --> TRN["Training cluster<br/>RL + imitation"]
  FLEET["Robot fleet<br/>teleop + autonomous runs"] --> LOGS[("Episode logs<br/>MCAP, video, actions")]
  LOGS --> CUR["Curation + labeling<br/>failures, interventions"]
  CUR --> TRN
  TRN --> EVALS["Eval: sim suites +<br/>real test cells"]
  EVALS --> REG["Policy registry"]
  REG -->|"staged OTA"| EDGE["On-robot inference<br/>Jetson Orin, 10-50 Hz policy,<br/>1 kHz low-level control"]
  EDGE --> FLEET
```

**How to read it:** policies are trained on a mix of randomized simulation and real fleet data. Every
real episode, especially failures and human interventions, is logged, curated, and fed back. Candidates
are evaluated in simulation suites and on physical test cells before staged rollout. On the robot, a
learned policy runs at 10–50 Hz on an embedded GPU, above a classical low-level controller running at ~1 kHz.

**Terms in this diagram.**
- **Domain randomization**: randomly varying the simulator's physics, lighting, textures, and delays during training,
  so the policy works on real robots, whose details never exactly match the simulation.
- **Imitation**: imitation learning trains a policy to copy demonstrations by humans.
- **Teleop**: teleoperation, where a human remotely controls the robot, producing demonstrations and recovering from
  failures.
- **Episode logs, MCAP**: an **episode** is one complete attempt at a task. **MCAP** is an open file format for
  recording timestamped robot sensor data, used with ROS 2 (Robot Operating System).
- **Interventions**: moments when a human took over because the robot was failing, which are especially valuable
  training data.
- **Sim suites, real test cells**: fixed sets of simulated test scenarios, and physical test stations with real robots.
- **Policy registry**: the versioned store of approved policies, like a model registry (Section 9).
- **Staged OTA**: an over-the-air update rolled out to a few robots first, then more (Section 21).
- **10-50 Hz policy, 1 kHz low-level control**: the learned policy decides 10 to 50 times per second. A classical
  controller turns its decisions into motor commands 1,000 times per second, keeping motion smooth and safe.

**Core ideas.**
- **Sim-to-real.**
  - Domain randomization: mass, friction, latency, lighting, and textures.
  - System identification to calibrate the simulator.
  - Real-data fine-tuning.
- **Robot foundation models.** Vision-language-action models (RT-1 used ~130 k episodes from 13 robots over 17
  months; RT-2, OpenVLA at 7 B params, π0) learn from many tasks and embodiments. They need LLM-scale training
  infrastructure and efficient on-robot inference (quantization, action chunking).
- **Data.** Logs are large (multiple cameras + proprioception at high rate). Use MCAP or rosbag2, sync clocks, and
  index by task, outcome, and intervention.
- **Edge.** Inference must meet the control period every time. Use a real-time OS or priorities, local fallbacks,
  and safety controllers independent of the learned policy (Section 44).
- **Evaluation** is the bottleneck. Real-world trials are slow, so combine large simulation suites with
  standardized physical test cells and statistically meaningful trial counts.

**Example: the friction gap.** A quadruped policy walked perfectly in simulation and slipped on polished
warehouse floors. Randomizing friction (0.3–1.2), adding actuator latency (5–25 ms), and adding sensor noise in
training, then fine-tuning on 6 hours of real logs, raised real-world success on the test course from 54% to
93%. Sim success dipped slightly, which is the expected trade-off.

**Senior / FAANG best practice.** Build the flywheel: randomized GPU simulation, fleet data with
intervention logging, curated retraining, and evaluation in simulation suites plus physical test cells. Run
policies on the robot with hard real-time guarantees and an independent safety controller, and roll out in
stages with fast rollback.

---

## Lecture 209 — Infrastructure for online learning agents

**Why it matters.** Recommendation, ads, pricing, and notification systems often learn continuously from
live feedback with contextual bandits or RL. This lets them adapt quickly, but also lets them drift,
self-reinforce bias, or be gamed, unless the infrastructure enforces exploration budgets, logging, and
rollback.

**In plain words.** A shopkeeper who always shows the best-selling items never learns whether new items
would sell better. Trying new things a little (exploration) helps, but you have to remember what you tried
and why, limit the risk, and be able to undo a bad change quickly.

**Architecture: a contextual bandit loop.**

```mermaid
flowchart LR
  CTX["Request context<br/>user, item features"] --> FS["Feature store<br/>online features"]
  FS --> POLB["Bandit policy<br/>Thompson or epsilon-greedy"]
  POLB --> CHOOSE["Choose arm + propensity"]
  CHOOSE --> USER["User"]
  USER -->|"click, purchase<br/>delayed reward"| JOIN["Join reward to decision<br/>by decision_id, within window"]
  CHOOSE --> DLOG[("Decision log<br/>context, arm, p, version")]
  DLOG --> JOIN
  JOIN --> UPD["Incremental update<br/>minutes to hours"]
  UPD --> VAL{"Guardrail checks<br/>OPE, metrics, drift"}
  VAL -->|"pass"| POLB
  VAL -->|"fail"| RB["Roll back to last good model"]
```

**How to read it:** each request is scored with fresh features, and the policy picks an arm while
recording the probability of choosing it. Rewards arrive later, and are joined to the logged decision by id
within a time window. The model updates incrementally, but each update passes guardrail checks before
going live, with automatic rollback to the last good version.

**Terms in this diagram.**
- **Bandit policy**: a **contextual bandit** is the one-step version of RL. It picks one option per request and learns
  from the immediate reward, used for recommendations, ranking, and pricing.
- **Thompson or epsilon-greedy**: two ways to balance trying options (**exploration**) and using the best known one
  (**exploitation**). **Thompson sampling** picks each option with the probability that it's the best, given the
  uncertainty. **Epsilon-greedy** picks the best option most of the time, and a random one with small probability ε.
- **Arm, propensity**: an **arm** is one of the options, from the "multi-armed bandit" slot-machine analogy. The
  **propensity** `p` is the probability the policy chose that arm. It's required for unbiased offline evaluation.
- **decision_id, within window**: every decision gets a unique ID, and rewards are matched to it if they arrive
  within, say, 24 hours.
- **Incremental update**: the model is updated with the new data every few minutes or hours, without retraining from
  scratch.
- **Guardrail checks: OPE, metrics, drift**: off-policy evaluation, business metric limits, and input drift checks
  (Section 17) must pass before the update goes live.

**Core ideas.**
- **Exploration** must be bounded (for example ≤ 5% of traffic or a confidence-based method like Thompson sampling)
  and excluded from sensitive decisions.
- **Delayed and missing rewards.** Use attribution windows (for example 24 hours for a purchase), join
  logic that's correct under late events (Section 24), and a definition of "no reward".
- **Propensity logging** enables unbiased evaluation and learning from logged data.
- **Feedback loops.** The model shapes its own training data (popularity bias, filter bubbles). Keep
  exploration, monitor coverage and diversity, and periodically retrain from randomized data.
- **Update cadence.** Online updates every few minutes, warm-started daily retrains, versioned snapshots,
  and the ability to freeze learning during incidents or anomalies (bots, outages).
- **Safety.** Constraint-aware objectives (no clickbait, fairness constraints), and reward definitions reviewed
  like product requirements, since agents optimize exactly what you measure.

**Example: the bot burst.** A news-recommendation bandit updated every 10 minutes. A scraper bot clicked
thousands of times on one category overnight, and the policy shifted heavily toward it, so real-user
engagement fell 12% by morning. Fixes: bot filtering before reward joins, a guardrail that blocks updates when
reward distribution shifts by more than a threshold, a cap on per-update weight change, and automatic rollback
when real-user engagement drops.

**Senior / FAANG best practice.** Log every decision with context, propensity, and model version, join rewards
correctly under delay, bound exploration, guard every online update with checks and automatic rollback, filter
adversarial and bot traffic before learning, and keep a frozen, known-good fallback model.

---

## Lecture 210 — Lab: train an RL agent with Ray RLlib

**Goal:** train PPO on CartPole-v1 with Ray RLlib, measure how sampling throughput scales with the number of env
runners, checkpoint and restore the policy, and serve it for single-observation inference with latency
measured.

**What you're building.**

```mermaid
flowchart LR
  CFG["PPOConfig<br/>CartPole-v1"] --> ER["EnvRunners x N<br/>CPU sampling"]
  ER --> LR["Learner<br/>PPO update"]
  LR --> ER
  LR --> CK[("checkpoint/")]
  CK --> SRV["serve.py<br/>restore + forward_inference"]
  SRV --> LAT["latency and episode return"]
```

**In plain words.** You train an agent to balance a pole on a cart, see how adding parallel workers
speeds up experience collection, then load the trained "brain" and use it like a deployed service.

**How to read the diagram:** `PPOConfig` is Ray RLlib's configuration object for the PPO algorithm, here set to the
**CartPole-v1** environment (balance a pole on a moving cart). RLlib starts N **EnvRunners**, the actor processes that
sample experience on CPUs. The **learner** runs the PPO update and sends new weights back to them. Training saves
the policy to `checkpoint/`. `serve.py` restores it and calls `forward_inference`, the RLlib module method that
computes actions without training-only extras. It reports per-call latency and the **episode return** (CartPole's
maximum is 500).

### Step 1 — Install and train

```bash
pip install "ray[rllib]>=2.40" "gymnasium>=1.0" torch
```

```python
# train.py
import os, sys, time
from ray.rllib.algorithms.ppo import PPOConfig
runners = int(sys.argv[1]) if len(sys.argv) > 1 else 2
config = (PPOConfig()
          .environment("CartPole-v1")
          .env_runners(num_env_runners=runners, num_envs_per_env_runner=4)
          .training(lr=3e-4, train_batch_size_per_learner=4000, minibatch_size=256, num_epochs=10, gamma=0.99)
          .debugging(seed=0))
algo = config.build_algo()            # Ray < 2.43: config.build()
t0 = time.time()
for i in range(60):
    r = algo.train()
    ret = r["env_runners"]["episode_return_mean"]
    steps = r.get("num_env_steps_sampled_lifetime") or r["env_runners"].get("num_env_steps_sampled_lifetime", 0)
    print(f"iter {i:2d} return {ret:6.1f} steps {steps:7d} steps/s {steps / (time.time() - t0):7.0f}")
    if ret >= 475:
        break
print("checkpoint:", algo.save_to_path(os.path.abspath("checkpoint")))
algo.stop()
```

```bash
python train.py 1     # then 2, 4, 8: compare steps/s and wall-clock time to return >= 475
```

(Result key names have changed across Ray versions. If one is missing, print `r.keys()` and use the
equivalent, for example `env_runners/episode_return_mean`.)

### Step 2 — Restore and serve the policy

```python
# serve.py: load the trained module and act on single observations, like a policy server
import os, time
import gymnasium as gym, numpy as np, torch
from ray.rllib.core.rl_module import RLModule
module = RLModule.from_checkpoint(os.path.abspath("checkpoint/learner_group/learner/rl_module/default_policy"))
env = gym.make("CartPole-v1")
returns, lat = [], []
for ep in range(20):
    obs, _ = env.reset(seed=100 + ep); done, total = False, 0.0
    while not done:
        t = time.perf_counter()
        with torch.no_grad():
            out = module.forward_inference({"obs": torch.from_numpy(obs).float().unsqueeze(0)})
        action = int(out["action_dist_inputs"].argmax(-1))          # greedy action for deployment
        lat.append((time.perf_counter() - t) * 1e3)
        obs, r, term, trunc, _ = env.step(action); total += r; done = term or trunc
    returns.append(total)
lat.sort()
print(f"mean return {np.mean(returns):.1f} over 20 episodes, inference p50 {lat[len(lat)//2]:.3f} ms p99 {lat[int(len(lat)*.99)]:.3f} ms")
```

### Step 3 — Observe the actor-learner balance

```bash
ray start --head --dashboard-host 0.0.0.0 &>/dev/null; python train.py 8
# Ray dashboard on :8265: watch EnvRunner CPU and learner time per iteration
```

**Expected results:**
- PPO reaches a mean return ≥ 475 (CartPole's maximum is 500) in roughly 10–30 iterations, which is a few minutes on a
  laptop CPU.
- Sampling steps/s grows nearly linearly from 1 to 4 env runners. Beyond your physical core count, it flattens, and
  the learner update becomes a larger share of each iteration.
- The restored greedy policy scores ~500 on most of the 20 evaluation episodes. Per-step inference p50 is ~0.1–0.5
  ms on CPU, far inside any real-time deadline. Batching or ONNX export helps only at high request rates.
- The checkpoint directory contains the RL module (weights) separately from the learner and optimizer state, so
  you can deploy just the policy.

---

## FAANG deep-dive notes

**How big tech does it.** The largest RL workloads today are LLM post-training (RLHF and RL with verifiable rewards),
built from sharded LLM trainers, high-throughput generation engines for rollouts, reward models and sandboxed
verifiers, and fast weight synchronization. Classic RL runs on actor-learner platforms (often Ray-based) with
GPU-parallel simulators. Production decision systems (ads, recommendations, data center control) use bandits
or RL with propensity logging, off-policy evaluation gates, safety layers, and automatic rollback. Robotics
teams run sim-and-fleet flywheels with large evaluation suites.

**Staff review questions.**
- What fraction of wall time is rollout vs learning, and is the hardware mix matched to it?
- What are the policy lag and the weight-sync cost per step?
- How is a new policy evaluated before it touches real users or robots (OPE, shadow, canary)?
- What does the safety layer guarantee independently of the learned policy?
- How are rewards defined, reviewed, and protected against hacking or adversarial traffic?

**Interview question.** "Design the infrastructure for RL fine-tuning of a 7B LLM on math and code tasks with
verifiable rewards."

**Typical system-design prompt:** *Run GRPO-style RL on a 7B model: 512 prompts per step, 8 samples per prompt, up
to 4,000 generated tokens per sample (average 1,000), rewards from unit tests and math checkers, 500 steps, on
16 H100s.*

**1. Clarify first:** Is the trainer colocated with generation or disaggregated? Is a reference model needed for the KL
penalty? What are the verifier costs (sandboxed code execution time)? What's the sequence length limit, and what
policy lag is acceptable? What are the checkpoint and eval cadence?

**2. Back-of-envelope sizing:**
- Rollout tokens per step: 512 × 8 × 1,000 = 4.1 M generated tokens. At ~10,000 tokens/s per H100 in
  throughput mode for 7B, 8 GPUs take ~50 s per step, before the long tail.
- Training on those tokens: 6 × 7e9 × 4.1e6 ≈ 1.7e17 FLOPs. At ~400 TFLOP/s per GPU on 8 GPUs, that's ~55 s.
  Reference-model log-probs add ~2 × N × D ≈ 5.7e16 FLOPs, ~18 s.
- Verifiers: 4,096 samples × ~1 s of sandboxed execution each ÷ 256 CPU workers ≈ 16 s, overlapped with other
  work.
- Weight sync: 7B BF16 = 14 GB per step, a few seconds over NVLink or InfiniBand.
- A step is ~2 minutes, so 500 steps ≈ 17 hours, if the long tail of generation is controlled.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Placement | Colocated (same GPUs alternate) | Disaggregated pools | Colocate at small scale. Disaggregate when generation and training can overlap |
| Synchrony | Synchronous on-policy | Asynchronous with bounded lag | Async raises utilization. Bound lag (1–2 steps) and correct if needed |
| Long tail | Wait for all samples | Cap length / partial rollouts / over-sample | Cap max tokens and over-sample, then drop stragglers |
| Rewards | Learned reward model | Verifiers (tests, checkers) | Verifiers where possible. They're harder to hack |
| Simulator (classic RL) | CPU vectorized | GPU-parallel | GPU-parallel when physics supports it |

**4. Follow-up questions with crisp answers:**
- *Why is generation the bottleneck in LLM RL?* It's sequential decode for thousands of samples per step, with a
  long tail of lengths, while training on the same tokens is a parallel pass.
- *How do you sync weights quickly?* NCCL broadcast from trainer ranks to generator ranks (or the same GPUs when
  colocated), in BF16, with matching tensor-parallel layouts to avoid resharding.
- *How do you detect reward hacking?* Hold-out evals that the reward doesn't touch, monitoring of
  response length and format drift, sampled human review, and adversarial tests of verifiers.
- *Why log action probabilities in production RL?* For unbiased off-policy evaluation of new policies and correct
  learning from logged data.

**Debug this (common onsite question):** "In our GRPO run, GPU utilization averages 30%, and step time is
4× the estimate."
1. Break a step down into stages. Generation takes 75% of the step, and most of that is waiting for the last few
   samples.
2. Look at the length histogram: the median sample is 900 tokens, but ~1% hit the 16,000 max (looping
   outputs), and the whole synchronous batch waits for them.
3. The trainer GPUs are idle during generation, and the generator GPUs are idle during training.
4. Fix: cap max tokens at 4,000 with a length penalty, over-sample by 10% and drop the slowest, overlap the
   next step's generation with training (async with lag 1), and track the length distribution as a metric.

The lesson: in synchronous RL, the slowest rollout sets the pace. Control the tail of rollout cost (lengths,
episode durations, slow environments) and overlap phases.

**5. What separates senior from staff answers:** a senior engineer configures RLlib or an LLM RL framework, scales
actors, and tunes the algorithm. A staff engineer profiles the rollout/learn split to size hardware, designs
placement and synchrony with bounded lag, controls long tails, builds safe deployment (safety layers,
propensity logging, OPE, canaries), and treats reward definitions and simulators as versioned, reviewed
artifacts.

**Red flags:**
- GPUs bought for a CPU-bound simulator.
- No policy-lag or steps/s metrics.
- Deploying from training curves without OPE, shadow, or canary.
- No safety layer or fallback.
- Online updates without guardrails or rollback.
- Rewards not reviewed, or no hold-out evals for reward hacking.

---

## Quiz

<details><summary>1. What are the two halves of an RL training system?</summary>
Actors, which run the policy in environments to generate experience, and learners, which update the policy from that
experience on GPUs. New weights are sent back to the actors.
</details>

<details><summary>2. How do on-policy and off-policy methods differ in infrastructure needs?</summary>
On-policy (PPO, GRPO) needs fresh batches from the current policy, so throughput of rollouts dominates and data is
discarded. Off-policy (DQN, SAC) reuses experience from a replay buffer, which needs memory and handling of stale data.
</details>

<details><summary>3. Why are GPU-parallel simulators so much faster?</summary>
Thousands of environments run as tensors on one GPU next to the policy, so stepping and inference happen on the device
with no CPU process overhead or host copies.
</details>

<details><summary>4. What is policy lag, and why does it matter?</summary>
How many versions old the acting policy is compared with the learner. High lag makes the data off-policy, which needs
corrections like V-trace and can destabilize learning.
</details>

<details><summary>5. Why must deployed RL policies log action probabilities?</summary>
Off-policy evaluation and learning from logged data need the propensity of each chosen action, to correct for
the logging policy's choices.
</details>

<details><summary>6. What does a safety layer do in RL serving?</summary>
It enforces hard constraints independently of the learned policy: action masking, clipping to limits, rate limits,
and fallback to a known-safe controller when inputs are abnormal or the deadline is missed.
</details>

<details><summary>7. Name three techniques for sim-to-real transfer.</summary>
Domain randomization (physics, latency, visuals), system identification to calibrate the simulator, and fine-tuning
on real-world data, with evaluation on physical test cells.
</details>

<details><summary>8. What makes generation the bottleneck in RL fine-tuning of LLMs?</summary>
Rollouts require sequential decoding for thousands of samples per step, with a long tail of output lengths, so
synchronous steps wait for the slowest samples while training GPUs sit idle.
</details>

## Failure modes
- Hardware mismatched to the workload, such as GPUs idling behind CPU-bound simulators.
- Unmeasured policy lag, so off-policy data destabilizes training.
- Results from a single seed reported as conclusions.
- Simulators and reward functions changed without versioning.
- RL policies deployed without a safety layer, OPE, shadow, or canary.
- No propensity logging, so new policies can't be evaluated from logs.
- Online learners updated by bot or adversarial traffic without guardrails.
- Long-tail rollouts stalling synchronous steps.
- Reward hacking that goes unnoticed without hold-out evals.

## Checklist
- [ ] You can draw the actor-learner loop and say which part is the bottleneck for a given workload
- [ ] You can use the Gymnasium API and vector environments, and know when to use GPU-parallel simulators
- [ ] You can explain IMPALA, Ape-X, and RLlib, and tune actors vs learners with lag metrics
- [ ] You can design RL fine-tuning infrastructure for an LLM, including weight sync and long-tail control
- [ ] You can serve a policy with a deadline, safety layer, and propensity logging
- [ ] You can describe a robotics sim-and-fleet flywheel and on-robot inference constraints
- [ ] You can design an online bandit loop with bounded exploration, guardrails, and rollback
- [ ] You trained PPO with RLlib, scaled env runners, and served the restored policy
