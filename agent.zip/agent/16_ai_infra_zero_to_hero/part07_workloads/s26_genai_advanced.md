# Section 26 — Advanced Generative AI Infrastructure

> Lectures 176–182 • Assessments: quiz, [Calculate LoRA trainable parameters](#assessment--calculate-lora-trainable-parameters) • Exercise: [`s26_lora_params.py`](../exercises/s26_lora_params.py)
> **After this section you can:** choose a ZeRO stage and offload settings for a model, explain Megatron's
> tensor, pipeline, and sequence parallelism, use Flash Attention, activation checkpointing, and FP8 to cut
> memory, plan multi-node LLM training (network, scheduling, failures), decide between full fine-tuning,
> LoRA, and QLoRA with exact parameter and memory math, estimate training cost from 6·N·D, and fine-tune a
> small LLM with PEFT.
>
> Go deeper: [13 / Lab 34 — PyTorch FSDP](../../13_sovereign_ai_infra_course/03_distributed_training/lab34_pytorch_fsdp.md),
> [Lab 40 — Megatron-LM](../../13_sovereign_ai_infra_course/03_distributed_training/lab40_megatron_lm.md),
> [Lab 36 — NCCL optimization](../../13_sovereign_ai_infra_course/03_distributed_training/lab36_nccl_optimization.md),
> [Lab 45 — Multi-LoRA serving](../../13_sovereign_ai_infra_course/04_serving_inference/lab45_multi_lora_serving.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 176 | DeepSpeed and ZeRO optimization for LLMs | Shard optimizer states, gradients, and parameters across GPUs: per-GPU memory falls from 16 bytes/param toward 16/N |
| 177 | Megatron-LM for large model training | Tensor parallel inside a node, pipeline parallel across nodes, data parallel outermost (3D parallelism) |
| 178 | Flash Attention and memory optimizations | IO-aware attention avoids the N² matrix in HBM. Add checkpointing, BF16/FP8, and fused kernels |
| 179 | Multi-node distributed training for LLMs | 400 Gb/s per GPU fabrics, gang scheduling, and failure-tolerant checkpoints. Hardware fails daily at scale |
| 180 | Fine-tuning vs parameter-efficient tuning | LoRA trains ~0.1–1% of parameters. QLoRA fits a 70B fine-tune on one 80 GB GPU |
| 181 | Cost challenges of generative AI training | Compute ≈ 6·N·D FLOPs. MFU, goodput, and data quality decide the bill |
| 182 | Lab: fine-tune a small LLM with PEFT | LoRA on a 0.5B model with TRL, evaluate, then serve the adapter with vLLM |

```mermaid
flowchart LR
  NEED["Training need"] --> Q1{"New knowledge<br/>or behavior?"}
  Q1 -->|"facts that change"| RAG["RAG (Section 25)<br/>no training"]
  Q1 -->|"style, format, domain task"| PEFT["LoRA or QLoRA<br/>1 GPU to 1 node"]
  Q1 -->|"big domain shift,<br/>continued pretraining"| FULL["Full fine-tune<br/>ZeRO-3 or FSDP"]
  Q1 -->|"new foundation model"| PRE["Pretraining<br/>3D parallel, thousands of GPUs"]
  FULL --> MEM["Memory tools<br/>Flash Attention, checkpointing, BF16/FP8"]
  PRE --> MEM
  PRE --> NET["Multi-node fabric<br/>IB or RoCE, NCCL"]
  PRE --> FT["Fault tolerance<br/>frequent checkpoints, auto-restart"]
  PEFT --> SERVE["Serve adapters<br/>multi-LoRA"]
```

**How to read it:** start from the need. Changing facts are a retrieval problem, not a training one. Most
product fine-tuning is parameter-efficient and fits on one GPU or one node. Full fine-tuning and
pretraining need sharding (ZeRO, FSDP, Megatron), memory optimizations, a fast multi-node network, and fault
tolerance. Each step to the right costs one to three orders of magnitude more.

**Terms in this diagram.**
- **RAG**: retrieval-augmented generation, which looks facts up at question time instead of training them in.
- **LoRA or QLoRA**: **LoRA** trains small add-on matrices while the original weights stay frozen (Lecture 180).
  **QLoRA** does the same on top of a base model quantized to 4 bits, so even bigger models fit on one GPU.
- **Continued pretraining**: further training on a large amount of domain text (for example medical papers), using
  the same next-token objective as the original pretraining.
- **Full fine-tune, ZeRO-3 or FSDP**: updating all weights. That needs memory for weights, gradients, and optimizer
  state, so it's sharded across GPUs with DeepSpeed **ZeRO-3** or PyTorch **FSDP** (fully sharded data parallel)
  (Lecture 176).
- **Pretraining, 3D parallel**: training a model from scratch, using data, tensor, and pipeline parallelism together
  (Lecture 177).
- **Flash Attention, checkpointing, BF16/FP8**: memory-saving attention (Lecture 178). **Activation checkpointing**
  recomputes intermediate values in the backward pass instead of storing them. **BF16/FP8** are 16-bit and 8-bit
  number formats.
- **IB or RoCE, NCCL**: InfiniBand or RDMA over Converged Ethernet networks (Section 13), and **NCCL**, NVIDIA's
  library for GPU collective communication (Section 8).
- **Multi-LoRA**: serving many adapters on one shared base model (Section 15).

---

## Lecture 176 — DeepSpeed and ZeRO optimization for LLMs

**Why it matters.** Plain data parallelism keeps a full copy of the weights, gradients, and optimizer
states on every GPU. For mixed-precision Adam that's ~16 bytes per parameter, so a 7.5B model needs 120 GB per
GPU before activations. ZeRO removes this redundancy, which is how models larger than one GPU's memory
train at all with data parallelism.

**In plain words.** Eight people each carrying a full copy of a heavy encyclopedia is wasteful. ZeRO
gives each person one volume, and when someone needs a page from another volume, it's passed over just in
time and handed back.

**Architecture: what each ZeRO stage shards.**

```mermaid
flowchart LR
  subgraph DP["Plain DDP: every GPU holds everything"]
    A1["params 2B + grads 2B<br/>+ optimizer 12B = 16 B/param"]
  end
  subgraph Z1["ZeRO-1"]
    B1["shard optimizer states<br/>4 + 12/N B/param"]
  end
  subgraph Z2["ZeRO-2"]
    C1["also shard gradients<br/>2 + 14/N B/param"]
  end
  subgraph Z3["ZeRO-3 (like FSDP)"]
    D1["also shard parameters<br/>16/N B/param, gather per layer"]
  end
  DP --> Z1 --> Z2 --> Z3
  Z3 --> OFF["ZeRO-Offload / Infinity<br/>optimizer or params to CPU or NVMe"]
```

**How to read it:** each stage shards one more kind of state across the N data-parallel GPUs. ZeRO-1 and 2
keep communication close to plain data parallelism. ZeRO-3 also shards the weights, so it must all-gather each
layer's parameters before using them, which costs ~1.5× the communication but makes memory per GPU fall
almost linearly with N. Offload moves state to CPU RAM or NVMe when GPU memory is the last constraint.

**Terms in this diagram.**
- **Plain DDP**: PyTorch distributed data parallel, where every GPU holds a full copy of everything (Section 8).
- **params 2B + grads 2B + optimizer 12B = 16 B/param**: here "B" means *bytes per parameter*, not billions. With
  mixed-precision Adam, each parameter needs 2 bytes for its BF16 weight, 2 bytes for its gradient, and 12 bytes of
  **optimizer state** (an FP32 master copy of the weight plus Adam's two FP32 running averages, 4 bytes each).
  So a 7-billion-parameter model needs about 112 GB before activations.
- **Shard**: split into N pieces, one per GPU, instead of every GPU holding a full copy. `12/N` means each GPU keeps
  only its share of the 12 bytes.
- **ZeRO-1, 2, 3**: the three stages of DeepSpeed's Zero Redundancy Optimizer, sharding optimizer state, then also
  gradients, then also parameters.
- **Gather per layer**: under ZeRO-3, GPUs exchange their shards to rebuild each layer's full weights just before
  using it (an **all-gather**), then drop them.
- **ZeRO-Offload / Infinity**: move optimizer state or parameters to CPU memory (**Offload**) or also NVMe SSDs
  (**Infinity**), trading speed for fitting larger models.

**Core ideas.**
- **Numbers from the ZeRO paper** (7.5B params, N = 64): DDP 120 GB per GPU, ZeRO-1 31.4 GB, ZeRO-2 16.6 GB,
  ZeRO-3 1.9 GB.
- **Choosing a stage.** Use ZeRO-1/2 when the parameters fit (cheaper communication). Use ZeRO-3 when they
  don't. Use offload only when you must, because PCIe makes steps much slower.
- **FSDP** is PyTorch's native equivalent of ZeRO-3 (Section 32 compares them in depth). FSDP2 shards per
  parameter with DTensor.
- **Communication.** ZeRO-3 issues all-gathers in the forward and backward passes and reduce-scatters
  for gradients. Overlap them with compute (prefetching), and keep the per-GPU micro-batch large enough to
  hide them.

```json
{
  "bf16": {"enabled": true},
  "zero_optimization": {
    "stage": 3,
    "overlap_comm": true,
    "contiguous_gradients": true,
    "reduce_bucket_size": 5e8,
    "stage3_prefetch_bucket_size": 5e8,
    "stage3_param_persistence_threshold": 1e6,
    "stage3_gather_16bit_weights_on_model_save": true
  },
  "gradient_accumulation_steps": 8,
  "train_micro_batch_size_per_gpu": 2,
  "gradient_clipping": 1.0
}
```

**Example: fitting a 13B full fine-tune on one node.** At 16 bytes/param, 13B needs 208 GB of state, which
can't fit one 80 GB GPU. On 8 × A100 80 GB, ZeRO-2 needs 2 + 14/8 = 3.75 B/param = 49 GB per GPU, leaving
~30 GB for activations at sequence length 4k with activation checkpointing. ZeRO-3 would need 26 GB per GPU
but ran 18% slower because of the extra all-gathers. The team chose ZeRO-2.

**Senior / FAANG best practice.** Pick the lowest ZeRO stage that fits, because extra sharding costs
communication. Compute bytes per parameter per GPU before launching, overlap communication with compute,
and save consolidated or sharded checkpoints deliberately. Benchmark stages on the real cluster, since the
best choice depends on interconnect bandwidth.

---

## Lecture 177 — Megatron-LM for large model training

**Why it matters.** Beyond ~10–20B parameters, sharding states isn't enough: single layers and activations
get too large, and data parallelism alone hits batch-size limits. Megatron-LM's tensor and pipeline
parallelism, combined with data parallelism, is how the largest models train.

**In plain words.** To build a skyscraper fast, you split each floor's work across a crew working side by
side (tensor parallelism), assign different floors to different crews in an assembly line (pipeline
parallelism), and build several identical towers at once (data parallelism).

**Architecture: 3D parallelism on 64 GPUs (TP 8 × PP 2 × DP 4).**

```mermaid
flowchart LR
  subgraph R1["Data-parallel replica 1 (16 GPUs)"]
    subgraph S1["Pipeline stage 1: layers 1-40, node A"]
      T1["TP group: 8 GPUs over NVLink<br/>each holds 1/8 of every matrix"]
    end
    subgraph S2["Pipeline stage 2: layers 41-80, node B"]
      T2["TP group: 8 GPUs over NVLink"]
    end
    T1 -->|"activations, point to point"| T2
  end
  R1 -.->|"gradient all-reduce or reduce-scatter<br/>across 4 replicas"| R2["Replicas 2, 3, 4<br/>same layout"]
```

**How to read it:** inside a node, eight GPUs split every weight matrix (tensor parallelism), which needs
all-reduces inside each layer, so it stays on NVLink. Layers are split into stages across nodes (pipeline
parallelism), and only activations at stage boundaries cross the slower network. The whole layout is
replicated four times for data parallelism, with gradients synchronized between replicas.

In the diagram, a **TP group** (tensor-parallel group) is the 8 GPUs that together hold one layer, each with 1/8 of
every weight matrix. **NVLink** is the very fast GPU-to-GPU connection inside one server. A **pipeline stage** is a
consecutive block of layers on one node. **Point to point** means stage 1 sends its output activations directly to
stage 2, rather than to all GPUs. A **data-parallel replica** is one complete copy of the model, here spanning 16
GPUs. The 4 replicas each train on different data, then combine gradients with an **all-reduce**, or with a
**reduce-scatter** when the optimizer state is sharded (Section 8). In total that's 4 × 16 = 64 GPUs.

**Core ideas.**
- **Tensor parallelism (TP).** Column-parallel then row-parallel linear layers split the MLP and attention
  heads, with two all-reduces per layer in the forward pass. Keep TP ≤ GPUs per node (8).
- **Pipeline parallelism (PP).** The 1F1B schedule with micro-batches has a bubble of ~(p − 1) / m of the
  step, for p stages and m micro-batches. The interleaved schedule (virtual stages) shrinks it further.
  Use m ≥ 4p.
- **Sequence and context parallelism** split activations along the sequence dimension, for long context.
- **Expert parallelism** places mixture-of-experts experts on different GPUs, using all-to-all
  communication.
- **Megatron-Core** is the library form, used by NeMo and others. DeepSpeed can combine with it
  (Megatron-DeepSpeed). PyTorch-native alternatives are TorchTitan and FSDP2 + DTensor TP.
- **MFU** (model FLOPs utilization) measures success: achieved 6·N·tokens/s over peak FLOPs. A
  well-tuned dense model on H100s gets ~40–55%.

```bash
# Megatron-LM style launch sketch (per node, 8 GPUs; 8 nodes total)
torchrun --nnodes 8 --nproc-per-node 8 --rdzv-backend c10d --rdzv-endpoint $MASTER:29500 pretrain_gpt.py \
  --tensor-model-parallel-size 8 --pipeline-model-parallel-size 2 --num-layers-per-virtual-pipeline-stage 10 \
  --sequence-parallel --use-flash-attn --bf16 --num-layers 80 --hidden-size 8192 --num-attention-heads 64 \
  --group-query-attention --num-query-groups 8 --seq-length 8192 --micro-batch-size 1 --global-batch-size 512
```

**Example: the pipeline bubble.** A 4-stage pipeline with 8 micro-batches per step had a bubble of
3/8 ≈ 37%, and MFU was 31%. Raising to 32 micro-batches (bubble ~9%) with the interleaved schedule lifted
MFU to 44%. The global batch didn't change, because micro-batch size was reduced and accumulation increased.

**Senior / FAANG best practice.** Map parallelism to topology: TP inside NVLink domains, PP across
nodes, DP (sharded) outermost. Keep enough micro-batches to shrink the bubble, measure MFU per configuration,
and tune the layout with short profiling runs before committing a large cluster.

---

## Lecture 178 — Flash Attention and memory optimizations

**Why it matters.** Standard attention writes an N × N score matrix to GPU memory for every head. At
8k tokens that's 128 MB per head per layer in BF16, which limits context length and wastes bandwidth.
Flash Attention, activation checkpointing, and low precision are what make long-context LLM training
practical.

**In plain words.** Instead of writing every intermediate result on a big whiteboard across the room and
walking back and forth (slow memory), you work on small cards at your desk (fast on-chip memory), finish
each piece, and only write the final answer to the whiteboard.

**Architecture: standard vs Flash Attention data flow.**

```mermaid
flowchart LR
  subgraph STD["Standard attention"]
    QK["Q times K^T"] --> S[("N x N scores in HBM")]
    S --> SM["softmax"] --> P[("N x N probs in HBM")]
    P --> PV["times V"]
  end
  subgraph FA["Flash Attention"]
    TILE["Load Q, K, V tiles<br/>into on-chip SRAM"] --> ON["Scores, online softmax,<br/>and times V per tile"]
    ON --> OUT["Write only the output<br/>N x d to HBM"]
  end
```

**How to read it:** standard attention makes several round trips through slow HBM with an N × N matrix.
Flash Attention streams tiles through fast on-chip memory, computes softmax incrementally, and never stores
the full matrix. In the backward pass it recomputes tiles instead of saving them. The result is exact, uses
O(N) memory, and is faster because it's limited by compute instead of memory traffic.

**Terms in this diagram.**
- **Q, K, V, K^T**: attention's **query**, **key**, and **value** matrices, one row per token. `K^T` is K transposed
  (rows and columns swapped), so `Q × K^T` gives every token's score against every other token.
- **N x N scores, N x d**: N is the sequence length and d is the size of each head's vectors. At N = 32,000 tokens,
  an N × N matrix has a billion entries per head, which is why storing it is the problem.
- **HBM**: the GPU's main high-bandwidth memory, large but much slower than on-chip memory.
- **Softmax, probs**: softmax turns each row of scores into probabilities that sum to 1.
- **Tiles, on-chip SRAM**: small blocks of Q, K, and V that fit in each streaming multiprocessor's tiny, very fast
  on-chip memory (shared memory, about 200 KB).
- **Online softmax**: computing softmax block by block, keeping a running maximum and sum and rescaling as new tiles
  arrive, so the full row is never needed at once.

**Core ideas.**
- **Flash Attention 2** improved parallelism and work partitioning. **Flash Attention 3** targets Hopper
  (asynchronous copies, FP8) and reaches ~75% of H100 peak in FP16. PyTorch's
  `scaled_dot_product_attention` dispatches to fused kernels automatically.
- **Activation checkpointing** stores only some activations and recomputes the rest in backward. Full
  checkpointing costs ~30–40% more compute for a large memory cut. Selective checkpointing (only attention)
  is cheaper.
- **Precision.** BF16 is the default for training. FP8 (Transformer Engine on H100/B200) adds ~1.3–1.5× speed
  with per-tensor scaling, and needs validation of loss curves.
- **Other tools.** Fused kernels (RMSNorm, rotary, cross-entropy, for example Liger kernels), 8-bit or paged
  optimizers, CPU offload, gradient accumulation, and sequence packing (no padding waste).

```python
import torch, torch.nn.functional as F
q = k = v = torch.randn(1, 32, 8192, 128, device="cuda", dtype=torch.bfloat16)
out = F.scaled_dot_product_attention(q, k, v, is_causal=True)     # Flash/efficient kernel, no 8k x 8k matrix
# Hugging Face: model = AutoModelForCausalLM.from_pretrained(..., attn_implementation="flash_attention_2")
# model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
```

**Example: from 2k to 16k context.** A team fine-tuning a 7B model ran out of memory at 4k tokens with eager
attention. Enabling Flash Attention 2 removed the 32 heads × 8k × 8k score matrices, enabling activation
checkpointing cut stored activations by ~5×, and sequence packing removed 35% padding. They trained at 16k
context on the same 8 GPUs, with step time 1.3× longer per token, a fair trade for 4× context.

**Senior / FAANG best practice.** Always use fused attention, apply selective checkpointing before full
checkpointing, train in BF16 (FP8 after validating convergence on a pilot run), pack sequences, and profile
memory with the PyTorch memory snapshot tools instead of guessing.

---

## Lecture 179 — Multi-node distributed training for LLMs

**Why it matters.** Training beyond one node turns the network, the scheduler, and failure handling into
first-order problems. At thousands of GPUs, something breaks every few hours, and a fabric misconfiguration
can halve throughput silently.

**In plain words.** A rowing team only goes as fast as its slowest rower, and everyone has to row in
sync. More rowers means more chances that someone drops an oar, so you need quick swaps and a way to
resume from the last checkpoint without rowing back to the start.

**Architecture: a multi-node training cluster.**

```mermaid
flowchart LR
  SCHED["Scheduler<br/>Slurm or Kubernetes + Kueue/Volcano<br/>gang scheduling"] --> N1["Node 1<br/>8 GPUs, NVLink/NVSwitch"]
  SCHED --> N2["Node 2"]
  SCHED --> NN["Node N"]
  N1 <-->|"8 x 400 Gb/s rails<br/>GPUDirect RDMA"| FAB["Rail-optimized fabric<br/>InfiniBand or RoCE"]
  N2 <--> FAB
  NN <--> FAB
  N1 --> CKPT[("Parallel file system<br/>or object storage<br/>async sharded checkpoints")]
  MON["Health checks<br/>DCGM, NCCL tests, ECC, links"] -.-> SCHED
  MON -.-> N1
```

**How to read it:** the scheduler starts all ranks together (gang scheduling) or none. Each node has
fast NVLink inside and one 400 Gb/s network adapter per GPU (a "rail"), so collective communication across
nodes uses GPUDirect RDMA without the CPU. Checkpoints go to fast shared storage. Health monitoring removes
bad nodes before and during jobs.

**Terms in this diagram.**
- **Slurm or Kubernetes + Kueue/Volcano**: **Slurm** is the traditional HPC job scheduler. On Kubernetes, **Kueue**
  and **Volcano** add job queues and batch scheduling (Section 11).
- **Gang scheduling**: all of a job's pods start at the same time or none do, because a distributed job with one
  missing rank just waits forever while holding GPUs.
- **Ranks**: the individual processes of a distributed job, typically one per GPU (Section 8).
- **NVLink/NVSwitch**: **NVSwitch** connects all 8 GPUs in a server through NVLink at full speed.
- **8 x 400 Gb/s rails, GPUDirect RDMA**: one 400-gigabit network card per GPU. Each "rail" connects the same-numbered
  GPU across all nodes. **GPUDirect RDMA** lets the network card read GPU memory directly (Section 13).
- **Rail-optimized fabric, InfiniBand or RoCE**: a network designed so traffic between same-rail GPUs needs only one
  switch hop.
- **Parallel file system**: shared storage such as Lustre, GPFS, or WEKA that many nodes read and write at high
  speed at once (Section 6).
- **Async sharded checkpoints**: each GPU saves its own shard in the background while training continues (Section 31).
- **DCGM, NCCL tests, ECC, links**: GPU diagnostics, `nccl-tests` bandwidth benchmarks, memory error counters, and
  network link health (Sections 8 and 16).

**Core ideas.**
- **Fabric.** Use 400 Gb/s per GPU (8 per node) on InfiniBand NDR or RoCEv2 with lossless or
  congestion-controlled Ethernet, a rail-optimized topology, and NCCL tuned for it (Lab 35 and Lab 36 in
  course 13). Validate with `nccl-tests` all-reduce bus bandwidth before every big job.
- **Scheduling.** Use gang scheduling, topology-aware placement (same leaf switch), and hot spares.
- **Failures are normal.** Meta reported 466 job interruptions during a 54-day Llama 3 405B pretraining run on
  16k H100s, 419 unexpected and ~78% caused by hardware (GPUs, HBM, and so on). They still achieved
  >90% effective training time through automation.
- **Resilience.** Use frequent asynchronous sharded checkpoints (Section 32), automatic restart with node
  exclusion, pre-job burn-in tests, straggler detection, and the NCCL watchdog and timeouts tuned to fail fast.
- **Goodput** = useful training time ÷ wall-clock time. Track it with MFU.

```bash
# fabric validation before a big run: all-reduce bus bandwidth across 2 nodes x 8 GPUs
mpirun -np 16 -H node1:8,node2:8 -x NCCL_DEBUG=WARN -x NCCL_IB_HCA=mlx5 \
  ./build/all_reduce_perf -b 1G -e 8G -f 2 -g 1
# expect ~350-400+ GB/s bus bandwidth on 8x400G NDR per node; far less means a misconfigured rail or PFC/ECN
```

**Example: the half-speed cluster.** A new 32-node cluster trained at 55% of the expected tokens/s.
`nccl-tests` showed 180 GB/s bus bandwidth instead of ~380. One rail per node was cabled to the wrong leaf
switch, forcing cross-spine traffic, and `NCCL_IB_HCA` excluded two adapters. Fixing the cabling and the
environment restored full speed. That's 45% of the cluster's cost recovered without new hardware.

**Senior / FAANG best practice.** Validate the fabric and every node (burn-in, NCCL tests, DCGM
diagnostics) before training, schedule gangs topology-aware with spares, checkpoint asynchronously and
often enough that the expected loss per failure is minutes, automate restart and node exclusion, and
report goodput and MFU daily.

---

## Lecture 180 — Fine-tuning vs parameter-efficient tuning

**Why it matters.** Most companies don't pretrain models. They adapt open or licensed models. The
choice between full fine-tuning, LoRA, QLoRA, or no training at all (prompting or RAG) changes cost by 10–100×,
and changes how you serve: one merged model, or many adapters on a shared base.

**In plain words.** Full fine-tuning rewrites the whole textbook. LoRA adds a thin booklet of corrections
that's clipped to the original. QLoRA does the same while reading from a compressed copy of the textbook to
save desk space. You can keep many booklets for different classes and swap them on one shared textbook.

**Architecture: a LoRA-adapted linear layer and multi-adapter serving.**

```mermaid
flowchart LR
  X["input x<br/>d_in"] --> W["Frozen W<br/>d_out x d_in"]
  X --> A["A: r x d_in<br/>trainable"]
  A --> B["B: d_out x r<br/>trainable, starts at 0"]
  W --> SUM(("+"))
  B -->|"scale alpha/r"| SUM
  SUM --> Y["output"]
  subgraph SERVE["Serving"]
    BASE["One base model in GPU memory"] --> L1["adapter: support, 84 MB"]
    BASE --> L2["adapter: legal, 84 MB"]
    BASE --> L3["adapter: sales, 84 MB"]
  end
```

**How to read it:** the original weight stays frozen. A small low-rank path (A then B) learns the change,
which adds r × (d_in + d_out) trainable parameters per adapted matrix. B starts at zero, so training starts
from the base model's behavior. At serving time, many adapters can share one base model and be selected per
request.

In the diagram, `d_in` and `d_out` are the input and output sizes of one weight matrix W, for example 4,096 each.
**Frozen** means W isn't updated. **r** is the LoRA **rank**, a small number such as 8 or 16. A is `r × d_in` and B is
`d_out × r`, so their product `B × A` has W's shape but far fewer parameters: 16 × (4,096 + 4,096) = 131,072 instead of
16.8 million. **Low-rank** means the change is limited to r independent directions. **alpha/r** is a scaling factor:
`alpha` is a setting (often 2 × r), and dividing by r keeps the update size stable when you change r. The **84 MB**
adapters show how small each team's customization is compared with the base model.

**Core ideas.**

| Method | Trainable | Memory (8B, before activations) | Use when |
|---|---|---|---|
| Prompting + RAG | 0 | Serving only | Knowledge changes, few examples needed |
| LoRA | ~0.1–1% (42 M for 8B, r = 16, all linear) | ~17 GB | Task, format, or style adaptation |
| QLoRA (4-bit NF4 base) | Same as LoRA | ~5 GB | Limited GPUs, large models (70B on one 80 GB GPU) |
| Full fine-tune | 100% | ~128 GB, needs ZeRO/FSDP | Large domain shift, continued pretraining |

- **Targets.** Adapting all linear layers (q, k, v, o, gate, up, down) usually beats attention-only at the
  same parameter count. Rank 8–64 is typical, with alpha ≈ r to 2r.
- **GQA matters.** k and v projections are narrower (1,024 outputs for Llama 3 8B), so their adapters are
  smaller.
- **QLoRA** uses NF4 quantization of the frozen base, double quantization, and paged optimizers. The original
  paper fine-tuned a 65B model on a single 48 GB GPU.
- **Serving.** Merge the adapter into the weights for one model, or serve many adapters on a shared base
  (vLLM `--enable-lora`, S-LoRA, Lab 45 in course 13).
- **Data beats method.** A few thousand clean, representative examples matter more than LoRA vs full.

**Example: the cheaper path.** A support team planned a full fine-tune of a 70B model: ~1.1 TB of training
state, ~64 GPUs, and a week. A QLoRA run on 8 GPUs (each one could hold the 42 GB quantized base) took 9 hours
and matched the planned full fine-tune's evals within a point. They served it as one 414 MB adapter on the
shared 70B pool.

**Senior / FAANG best practice.** Exhaust prompting and RAG first, then LoRA or QLoRA with a clean eval set,
and reserve full fine-tuning for measured gaps. Version adapters like models (base model hash, data
version, eval results), serve them on shared bases, and compute parameters and memory before you request
GPUs.

---

## Lecture 181 — Cost challenges of generative AI training

**Why it matters.** Training compute is predictable from model size and tokens, and it's huge: tens of
millions of dollars for frontier models, and thousands to hundreds of thousands even for fine-tunes and
small pretraining runs. Most overspend comes from low utilization, failed runs, and poorly planned experiments,
not from the final run.

**In plain words.** The fuel for a trip is distance × consumption. Training compute is model size ×
tokens × a constant. You can't negotiate with the physics, but you can drive efficiently (MFU), avoid detours
(failed runs), and pick the right car (model size).

**Architecture: where training money goes.**

```mermaid
flowchart LR
  BUD["Training budget"] --> EXP["Experiments and ablations<br/>often 2-5x the final run"]
  BUD --> FIN["Final run<br/>6 x N x D FLOPs"]
  FIN --> MFU["divided by MFU x peak<br/>= GPU-hours"]
  MFU --> WASTE["plus failures and restarts<br/>1 - goodput"]
  BUD --> DATA["Data: collection, cleaning,<br/>dedupe, labeling"]
  BUD --> EVALS["Evals and red-teaming"]
  BUD --> IDLE["Idle reserved capacity"]
```

**How to read it:** the final run's compute is set by 6·N·D, and its GPU-hours by how efficiently you use
the hardware (MFU) and how much is lost to failures (goodput). Around it, experiments, data work, evals,
and idle reserved capacity often cost as much as the final run or more.

**Terms in this diagram.**
- **Ablations**: experiments that remove or change one thing at a time, to learn what matters.
- **6 x N x D FLOPs**: the standard estimate of training compute. N is the number of parameters, D is the number of
  training tokens, and 6 covers the forward pass (2) plus the backward pass (4) per parameter per token. **FLOPs**
  are floating-point operations.
- **MFU x peak**: **MFU** (model FLOPs utilization) is the fraction of the GPU's **peak** advertised speed you
  actually achieve, typically 35–55% for large training. Dividing the required FLOPs by (MFU × peak FLOPs per second
  per GPU) gives GPU-seconds, and so GPU-hours.
- **Goodput**: the fraction of paid GPU time that produced useful training progress. **1 − goodput** is time lost to
  crashes, restarts, and recomputing steps since the last checkpoint (Section 31).
- **Red-teaming**: deliberately attacking the model to find unsafe behavior before release (Section 18).
- **Idle reserved capacity**: GPUs you committed to pay for but didn't keep busy.

**Core ideas.**
- **Compute ≈ 6 × N × D FLOPs** (forward plus backward, N params, D tokens). Llama 3.1 405B: 6 × 405e9 ×
  15.6e12 ≈ 3.8e25 FLOPs. At ~400 TFLOP/s effective per H100 (~40% MFU), that's ~26 M GPU-hours. Meta reported
  ~30.8 M H100 hours, which includes real-world overhead.
- **GPU-hours → dollars.** At $2–4 per H100-hour, that's tens of millions of dollars. A 1B-parameter model on
  100 B tokens is 6e20 FLOPs ≈ 420 H100-hours ≈ $1–2k.
- **Chinchilla** found ~20 tokens per parameter compute-optimal for training. Modern models train far past
  that (Llama 3 8B used ~15 T tokens, ~1,900 per param), because smaller models are cheaper to *serve*.
- **Levers.**
  - Raise MFU (Sections 31 and 32).
  - Raise goodput (checkpoints, burn-in).
  - Spend less on experiments with small-scale ablations and scaling laws.
  - Dedupe and filter data, since better data means fewer tokens.
  - Use spot or preemptible capacity for fine-tunes, and reserved capacity for long pretraining.
  - Right-size: fine-tune instead of pretraining, and PEFT instead of a full fine-tune.

```bash
python3 -c "N,D=8e9,1e12; f=6*N*D; h=f/(0.4*989e12)/3600; print(f'{f:.2e} FLOPs, {h:,.0f} H100-hours, ~${h*2.5:,.0f} at \$2.5/h')"
# -> 4.80e+22 FLOPs, 33,704 H100-hours, ~$84,260 at $2.5/h
```

**Example: the run that cost twice.** A 7B continued-pretraining run on 200 B tokens was budgeted at ~6,000
H100-hours (40% MFU). It took 13,500. MFU was 28% (no Flash Attention, small micro-batches), and two
multi-day failures resumed from day-old checkpoints. Fixes for the next run were fused attention and
larger micro-batches (MFU 43%), hourly asynchronous checkpoints, and a burn-in that removed three flaky nodes.
It came in under budget.

**Senior / FAANG best practice.** Budget every run from 6·N·D with an explicit MFU and goodput assumption,
track actual vs planned daily, gate large runs on small-scale ablations, and make data quality and
checkpoint frequency part of the cost plan. Report cost per run and per eval point gained to leadership.

---

## Lecture 182 — Lab: fine-tune a small LLM with PEFT

**Goal:** LoRA-fine-tune Qwen2.5-0.5B-Instruct on a small instruction dataset with Hugging Face TRL and
PEFT, verify the trainable parameter count against the formula, compare before and after on held-out
prompts, and serve the adapter with vLLM.

**What you're building.**

```mermaid
flowchart LR
  DATA["train.jsonl<br/>instruction, response"] --> SFT["TRL SFTTrainer<br/>+ LoRA r=16 all-linear"]
  BASE["Qwen2.5-0.5B-Instruct<br/>frozen"] --> SFT
  SFT --> AD["adapter/<br/>~18 MB"]
  AD --> EV["eval.py<br/>held-out prompts, loss"]
  AD --> VLLM["vLLM --enable-lora<br/>base + adapter"]
  CALC["s26_lora_params.py"] -.->|"predicts 8,798,208"| SFT
```

**In plain words.** You teach a small model a new response style with a ~18 MB adapter, prove you predicted
its size correctly, and serve it next to the unchanged base model.

**How to read the diagram:** `train.jsonl` holds one JSON object per line, each with an instruction and the desired
response. **TRL** (Hugging Face's Transformer Reinforcement Learning library) provides `SFTTrainer` for **supervised
fine-tuning**, meaning learning from example answers. LoRA is applied with rank `r=16` to `all-linear` layers, that
is, every linear (matrix) layer. The base model, **Qwen2.5-0.5B-Instruct**, a 0.5-billion-parameter open
chat model, stays frozen. Training writes only the adapter folder, about 18 MB. `eval.py` checks it on **held-out**
prompts not used in training, and reports the **loss** (how wrong the model's predictions are, lower is better).
`vllm --enable-lora` serves the base model and loads the adapter on top. `s26_lora_params.py` computes the expected
number of trainable parameters, 8,798,208, which must match what training reports.

### Step 1 — Environment and data

```bash
pip install "transformers>=4.45" "trl>=0.12" "peft>=0.13" datasets accelerate
python - <<'EOF'
from datasets import load_dataset
ds = load_dataset("databricks/databricks-dolly-15k", split="train").filter(lambda r: r["category"] == "summarization")
ds = ds.map(lambda r: {"messages": [
    {"role": "user", "content": f"Summarize the following text:\n{r['context']}"},
    {"role": "assistant", "content": r["response"]}]}, remove_columns=ds.column_names)
ds.train_test_split(test_size=0.05, seed=0).save_to_disk("data")
EOF
```

### Step 2 — Predict, then train

```bash
python3 exercises/s26_lora_params.py --hidden 896 --layers 24 --heads 14 --kv-heads 2 --inter 4864 \
  --vocab 151936 --tied --r 16 --targets q,k,v,o,gate,up,down          # predicts 8,798,208 trainable
```

```python
# train.py
from datasets import load_from_disk
from peft import LoraConfig
from trl import SFTConfig, SFTTrainer
ds = load_from_disk("data")
peft_cfg = LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, task_type="CAUSAL_LM",
                      target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"])
args = SFTConfig(output_dir="out", num_train_epochs=2, per_device_train_batch_size=8, gradient_accumulation_steps=2,
                 learning_rate=2e-4, lr_scheduler_type="cosine", warmup_ratio=0.03, bf16=True, logging_steps=10,
                 eval_strategy="epoch", save_strategy="epoch", max_length=1024, packing=True, report_to="none")
trainer = SFTTrainer(model="Qwen/Qwen2.5-0.5B-Instruct", args=args, train_dataset=ds["train"],
                     eval_dataset=ds["test"], peft_config=peft_cfg)
trainer.model.print_trainable_parameters()
print("eval loss before:", trainer.evaluate()["eval_loss"])     # B starts at 0, so this is the base model
trainer.train()
print("eval loss after: ", trainer.evaluate()["eval_loss"])
trainer.save_model("adapter")
```

```bash
python train.py
ls -lh adapter/adapter_model.safetensors
```

(On older TRL versions, `max_length` is called `max_seq_length`.)

### Step 3 — Compare before and after

```python
# eval.py: same held-out prompts, base vs base+adapter, compared with the reference summaries
import statistics
from datasets import load_from_disk
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer
tok = AutoTokenizer.from_pretrained("Qwen/Qwen2.5-0.5B-Instruct")
base = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2.5-0.5B-Instruct", torch_dtype="auto", device_map="auto")
tuned = PeftModel.from_pretrained(AutoModelForCausalLM.from_pretrained(
    "Qwen/Qwen2.5-0.5B-Instruct", torch_dtype="auto", device_map="auto"), "adapter")
def gen(m, msgs):
    ids = tok.apply_chat_template(msgs[:1], add_generation_prompt=True, return_tensors="pt").to(m.device)
    return tok.decode(m.generate(ids, max_new_tokens=200, do_sample=False)[0][ids.shape[1]:], skip_special_tokens=True)
words = {"reference": [], "base": [], "tuned": []}
for row in load_from_disk("data")["test"].select(range(20)):
    words["reference"].append(len(row["messages"][1]["content"].split()))
    words["base"].append(len(gen(base, row["messages"]).split()))
    words["tuned"].append(len(gen(tuned, row["messages"]).split()))
print({k: statistics.median(v) for k, v in words.items()})        # median answer length in words
# also read 5 pairs side by side: is the tuned summary faithful, not just shorter?
```

### Step 4 — Serve the adapter with vLLM

```bash
vllm serve Qwen/Qwen2.5-0.5B-Instruct --enable-lora --lora-modules summarizer=./adapter --max-lora-rank 16
curl -s localhost:8000/v1/chat/completions -H 'content-type: application/json' -d \
  '{"model":"summarizer","messages":[{"role":"user","content":"Summarize the following text:\n..."}]}'
# "model":"Qwen/Qwen2.5-0.5B-Instruct" still serves the unchanged base from the same GPU
```

**Expected results:**
- `print_trainable_parameters()` prints `trainable params: 8,798,208 || all params: 502,830,976 ||
  trainable%: 1.7497`. The trainable count matches the exercise exactly. The total differs from the
  exercise by 27,648, which is Qwen's q/k/v bias parameters.
- The adapter file is ~18 MB. Training takes a few minutes on one 24 GB GPU (the summarization subset is ~1,200
  examples), with peak memory of ~6–10 GB.
- Eval loss falls clearly after the first epoch, then flattens. If it rises in epoch 2 while training loss
  keeps falling, you're overfitting, so keep the epoch-1 checkpoint.
- The base instruct model writes much longer summaries than the references. The tuned model's median length
  moves close to the reference median. Read several pairs side by side to confirm the shorter summaries
  are still faithful.
- vLLM serves both `summarizer` and the base model from one process. Adding more adapters costs MBs, not GBs.

---

## Assessment — Calculate LoRA trainable parameters

**Scenario:** your team must choose a LoRA configuration and GPU plan for three models, and justify it to
the platform team with exact numbers, not estimates.

**Task:** from the model shapes, compute LoRA trainable parameters per layer and in total (with GQA), the
adapter size, and the memory for full fine-tuning, LoRA, and QLoRA. Reproduce Hugging Face PEFT's printed
numbers.

```bash
python3 exercises/s26_lora_params.py
python3 exercises/s26_lora_params.py --model llama3-70b --r 16 --targets q,k,v,o,gate,up,down
```

**Formula:** for each adapted matrix W with shape (d_out × d_in), LoRA adds r × (d_in + d_out). Llama 3 8B
per layer, r = 16: q and o are 16 × (4,096 + 4,096) = 131,072. k and v are 16 × (4,096 + 1,024) = 81,920
(GQA: 8 KV heads × 128). gate, up, and down are 16 × (4,096 + 14,336) = 294,912. Multiply by 32 layers.

**Expected output:**

| Model, config | Trainable | All params (as PEFT prints) | Trainable % | Adapter (BF16) |
|---|---|---|---|---|
| Llama 2 7B, r = 8, q,v | 4,194,304 | 6,742,609,920 | 0.0622% | 8.4 MB |
| Llama 3 8B, r = 16, q,k,v,o | 13,631,488 | 8,043,892,736 | 0.1695% | 27.3 MB |
| Llama 3 8B, r = 16, all linear | 41,943,040 | 8,072,204,288 | 0.5196% | 83.9 MB |
| Llama 3 70B, r = 16, all linear | 207,093,760 | 70,760,800,256 | 0.2927% | 414 MB |

| Memory before activations | Llama 3 8B | Llama 3 70B |
|---|---|---|
| Full fine-tune (16 B/param) | 128.5 GB | 1,129 GB |
| LoRA (BF16 base) | 16.7 GB | 144.4 GB |
| QLoRA (NF4 base) | 5.1 GB | 42.1 GB (fits one 80 GB GPU) |

**What a strong answer explains:** trainable parameters grow linearly with rank and with the widths of the
targeted matrices. GQA makes k/v adapters smaller. Memory is dominated by the frozen base, not the
adapter, so QLoRA's 4-bit base is what makes large models fit. Activations, which depend on sequence
length and batch, come on top and are controlled with Flash Attention and checkpointing. Small adapters make
multi-adapter serving cheap: 100 adapters for 8B total ~8.4 GB.

---

## FAANG deep-dive notes

**How big tech does it.** Foundation-model teams run 3D/4D parallel training (TP, PP, DP with sharding,
and context or expert parallelism) on tens of thousands of GPUs with dedicated fabrics, automated
health checks, and checkpointing designed for frequent failures. Success is measured by MFU and goodput.
Product teams mostly adapt shared foundation models with PEFT on a central fine-tuning platform that
tracks base model versions, data versions, and eval results, and serves adapters on shared bases. Every
large run is preceded by small ablations, and budgets are planned from 6·N·D.

**Staff review questions.**
- Why this parallelism layout for this topology, and what MFU did the pilot achieve?
- What is the expected loss per failure, and how was checkpoint frequency chosen?
- Why fine-tune at all (vs RAG or prompting), and why this method?
- What eval proves the fine-tune is better, and on which slices?
- What's the cost estimate (6·N·D, MFU, goodput), and how is it tracked during the run?

**Interview question.** "Plan the training of a 70B model on 2 T tokens with 512 H100s."

**Typical system-design prompt:** *Plan continued pretraining of a 70B dense model on 2 T domain tokens,
with 512 H100 80 GB GPUs (64 nodes, 8 × 400 Gb/s each), in under 30 days.*

**1. Clarify first:** What sequence length? What are the data readiness and dedupe status? Is the 30-day
deadline for training only, or including evals? What's the checkpoint storage throughput? Are spares
available? What are the target MFU and failure history of this cluster?

**2. Back-of-envelope sizing:**
- Compute: 6 × 70e9 × 2e12 = 8.4e23 FLOPs. At 40% MFU (~400 TFLOP/s per GPU) × 512 GPUs = 2.0e17 FLOP/s,
  that's 4.2e6 s ≈ 49 days. **That misses the deadline.**
- Options: raise MFU to ~50% (≈ 39 days, still too long), cut tokens to ~1.2 T, get ~850 GPUs, or use FP8
  (~1.3×, ≈ 30 days at 50% MFU). Present these trade-offs explicitly.
- Memory: 70B × 16 B = 1.12 TB of state. Sharded over DP with TP 8 × PP 2, it fits with activation
  checkpointing at 8k sequence length.
- Checkpoints: weights + optimizer ≈ 1.1 TB. At 50 GB/s aggregate write, that's ~22 s asynchronous, so
  checkpoint every 30–60 minutes.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Sharding | ZeRO-1/2 + TP/PP | ZeRO-3/FSDP | Lowest sharding that fits. Add TP/PP when layers or activations are too big |
| TP size | 4 | 8 | Stay inside the NVLink domain. Larger TP means smaller per-GPU matmuls |
| Precision | BF16 | FP8 | FP8 after a convergence pilot. It's the biggest single speed lever on H100 |
| Checkpoint interval | Every few hours | Every 30–60 min async | Minimize expected lost work given failure rate and write cost |
| Method | Full continued pretraining | LoRA on domain data | Full for large domain shifts. Test LoRA first on a slice |

**4. Follow-up questions with crisp answers:**
- *Why is TP kept inside a node?* It all-reduces activations inside every layer, which needs NVLink
  bandwidth (~900 GB/s on H100), not ~50 GB/s per network adapter.
- *How do you choose checkpoint frequency?* Minimize expected loss: interval ≈ √(2 × checkpoint cost × mean
  time between failures). With asynchronous checkpoints, the cost is small, so checkpoint often.
- *Loss spikes at step 40k. What do you do?* Roll back to an earlier checkpoint, skip or inspect the data
  batch, lower the learning rate or tighten clipping, and check for bad nodes (silent data corruption).
- *Why did MFU drop when scaling from 256 to 512 GPUs?* Larger DP all-reduces, smaller per-GPU batch, a
  pipeline bubble, or cross-spine traffic. Profile communication vs compute.

**Debug this (common onsite question):** "A 256-GPU run's tokens/s dropped 30% overnight. No errors, and
loss is normal."
1. Per-rank step timings: all ranks wait on the same 8 GPUs at every all-reduce. It's a straggler.
2. DCGM on that node: one GPU is throttling at 87 °C, with clocks down 35%, after a fan failure.
3. NCCL bus bandwidth on that node's rails is normal, so it's not the network.
4. Fix: cordon the node, restart from the last checkpoint with a spare, and add alerts for per-rank step-time
   skew and GPU thermal throttling.

The lesson: synchronous training runs at the speed of the slowest GPU. Monitor per-rank skew and hardware
health, and keep spares to swap quickly.

**5. What separates senior from staff answers:** a senior engineer configures ZeRO, Megatron, Flash Attention,
and LoRA correctly and computes memory. A staff engineer starts from the business need (RAG vs PEFT vs full
training), does the 6·N·D math to expose infeasible deadlines early, plans for failures as a certainty, maps
parallelism to the physical topology, and runs a cost-tracked program of ablations before committing the
cluster.

**Red flags:**
- No 6·N·D estimate before requesting GPUs.
- TP across nodes.
- Checkpoints every few hours, or only synchronous ones.
- No fabric validation before a big run.
- Full fine-tuning where LoRA or RAG would do.
- No held-out eval for fine-tunes.

---

## Quiz

<details><summary>1. What does each ZeRO stage shard?</summary>
Stage 1 shards optimizer states, stage 2 also shards gradients, and stage 3 also shards parameters (gathered per layer when needed).
Memory per GPU falls toward 16/N bytes per parameter at stage 3.
</details>

<details><summary>2. Why is tensor parallelism kept inside a node?</summary>
It needs all-reduces inside every layer, in the forward and backward passes, which requires NVLink-class bandwidth. Across
nodes, the network is ~10–20× slower.
</details>

<details><summary>3. What is the pipeline bubble, and how do you shrink it?</summary>
It's idle time while the pipeline fills and drains, ~(p − 1)/m of a step. Use more micro-batches (m ≥ 4p) and
interleaved schedules.
</details>

<details><summary>4. How does Flash Attention save memory without approximation?</summary>
It processes Q, K, and V in tiles in on-chip SRAM, with an online softmax, never writing the N × N score matrix to
HBM, and recomputes tiles in the backward pass. Memory is O(N), and the results are exact.
</details>

<details><summary>5. Compute LoRA parameters for one 4096 × 4096 matrix at r = 16.</summary>
16 × (4,096 + 4,096) = 131,072 parameters, about 0.8% of the matrix's 16.8 M.
</details>

<details><summary>6. Why does QLoRA fit much larger models than LoRA?</summary>
The frozen base model is stored in 4-bit NF4 (~0.5 bytes/param) instead of BF16 (2 bytes/param), and the base
dominates memory. Adapters stay small and train in higher precision.
</details>

<details><summary>7. Estimate the compute for training a 7B model on 1 T tokens.</summary>
6 × 7e9 × 1e12 = 4.2e22 FLOPs. At ~400 TFLOP/s effective per H100, that's ~29,000 GPU-hours.
</details>

<details><summary>8. Why are failures a design input for large training runs?</summary>
With thousands of GPUs, hardware fails every few hours. (Meta saw 419 unexpected interruptions in 54 days on 16k
GPUs.) Checkpoint frequency, automatic restart, spares, and health checks determine goodput.
</details>

## Failure modes
- Choosing ZeRO-3 or offload when a lower stage fits, which slows every step.
- Tensor parallelism across nodes, or a pipeline with too few micro-batches.
- Eager attention at long context, running out of memory or wasting bandwidth.
- No fabric validation, so a miscabled rail halves throughput silently.
- Infrequent or synchronous checkpoints that lose hours per failure.
- Straggler GPUs (thermal, ECC) slowing the whole synchronous job.
- Full fine-tuning when RAG or LoRA would meet the need.
- Fine-tunes shipped without held-out evals, or overfit to format.
- Training budgets without a 6·N·D estimate or MFU and goodput assumptions.

## Checklist
- [ ] You can compute per-GPU memory for each ZeRO stage
- [ ] You can design a TP × PP × DP layout for a cluster topology and explain the bubble
- [ ] You use fused attention, checkpointing, BF16 or FP8, and sequence packing
- [ ] You validate fabrics with `nccl-tests` and plan checkpoints for failures
- [ ] You ran `s26_lora_params.py` and can derive LoRA parameter counts by hand, including GQA
- [ ] You can choose between RAG, LoRA, QLoRA, and full fine-tuning with numbers
- [ ] You can estimate training compute and cost from 6·N·D, MFU, and goodput
- [ ] You fine-tuned a small LLM with PEFT, evaluated it, and served the adapter with vLLM
