# Section 28 — NLP Infrastructure at Scale

> Lectures 190–196 • Assessment: quiz
> **After this section you can:** treat tokenizers as part of the model contract, explain encoder, decoder,
> and encoder-decoder infrastructure needs, plan large transformer training data and runs, serve embedding
> models for both bulk indexing and low-latency queries, cut NLP inference latency with distillation,
> quantization, compilation, and length-aware batching, deploy multilingual models with per-language cost and
> quality in view, and ship a BERT classifier with FastAPI and ONNX Runtime.
>
> Go deeper: [13 / Lab 41 — Triton multi-framework](../../13_sovereign_ai_infra_course/04_serving_inference/lab41_triton_multi_framework.md),
> [Lab 46 — Semantic routing](../../13_sovereign_ai_infra_course/04_serving_inference/lab46_semantic_routing.md),
> [Lab 29 — HPA on custom metrics](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab29_hpa_custom_metrics.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 190 | NLP workloads: tokenization, embeddings, transformers | Text becomes tokens, then vectors. Tokenizer and model are one versioned unit, and cost scales with tokens |
| 191 | Training large transformer models | Pre-tokenize into packed shards, warm up and decay the learning rate, clip gradients, and watch for loss spikes |
| 192 | Infrastructure for BERT and GPT | Encoders: short, batchable, one pass. Decoders: long, sequential, KV cache. Different serving stacks |
| 193 | Efficient serving of embedding models | Two paths: bulk throughput for indexing, low-latency for queries, with versioned vectors |
| 194 | Latency reduction in NLP inference | Distill, quantize, compile, and above all control sequence length and padding |
| 195 | Deploying multilingual models at scale | Some languages need 2–4× more tokens per word. Evaluate, size, and budget per language |
| 196 | Lab: deploy a BERT model with FastAPI | PyTorch baseline to ONNX INT8 with micro-batching, load-tested with latency percentiles |

```mermaid
flowchart LR
  TXT["Raw text<br/>many languages"] --> NORM["Normalize<br/>Unicode NFC, cleanup"]
  NORM --> TOK["Tokenizer<br/>versioned with the model"]
  TOK --> ENC["Encoder model<br/>BERT-class"]
  TOK --> DECM["Decoder model<br/>GPT-class"]
  ENC --> CLS["Classify, tag, rank"]
  ENC --> EMB["Embeddings<br/>search, RAG, dedupe"]
  DECM --> GEN["Generate<br/>chat, summarize"]
  EMB --> VDB[("Vector index")]
  CLS --> APPS["Moderation, routing,<br/>intent, NER"]
```

**How to read it:** all NLP workloads start with normalization and tokenization, and the tokenizer must
match the model exactly. Encoders (BERT-class) turn text into labels or embeddings in a single pass, and are
the workhorses of classification and search. Decoders (GPT-class) generate text token by token and need the
LLM serving stack from Section 25.

**Terms in this diagram.**
- **Unicode NFC, cleanup**: the same visible character can be stored as different byte sequences (for example "é" as
  one code point, or as "e" plus an accent mark). **NFC** (Normalization Form C) converts text to one standard
  form, so identical text gets identical tokens. Cleanup removes control characters and broken markup.
- **Tokenizer, versioned with the model**: the tokenizer files ship with the model and must never be swapped
  independently (Lecture 190).
- **Encoder model, BERT-class**: models such as **BERT** that read the whole text at once and output a
  representation of it.
- **Decoder model, GPT-class**: models such as **GPT** that predict the next token, one at a time, to generate text.
- **Classify, tag, rank**: assign a label to text, label each word (**tagging**), or order results by relevance.
- **Embeddings: search, RAG, dedupe**: vectors that capture meaning, used for semantic search, retrieval-augmented
  generation, and finding near-duplicate texts.
- **Moderation, routing, intent, NER**: detecting harmful content, sending requests to the right handler,
  recognizing what the user wants (**intent**), and **named entity recognition**, which finds names, places, and
  dates in text.

---

## Lecture 190 — NLP workloads: tokenization, embeddings, transformers

**Why it matters.** Every NLP cost and latency number is driven by tokens: how many there are, how they're
batched, and how attention scales with them. Tokenizers are also a silent source of production bugs when
the serving tokenizer differs from the training tokenizer.

**In plain words.** A tokenizer chops text into pieces from a fixed dictionary, like LEGO bricks. The
model only understands bricks from its own dictionary. Use a different dictionary at serving time and
the model reads nonsense without any error.

**Architecture: from text to model output.**

```mermaid
flowchart LR
  T["Text: tokenization matters"] --> PT["Pre-tokenize<br/>split on spaces, punctuation"]
  PT --> SUB["Subword model<br/>BPE, WordPiece, or Unigram"]
  SUB --> IDS["Pieces to ids<br/>token, ##ization, matters"]
  IDS --> EMBL["Embedding lookup<br/>vocab x hidden"]
  EMBL --> TR["Transformer layers<br/>attention cost grows with n squared"]
  TR --> HEAD["Task head<br/>classify, embed, or next token"]
```

**How to read it:** text is split into words, then into subword pieces from a fixed vocabulary, which
become integer ids. Each id looks up a vector, and transformer layers mix information across positions,
with attention cost growing with the square of the sequence length. The last layer feeds a task-specific
head.

In the diagram, **pre-tokenize** is the first rough split into words and punctuation. A **subword model** then breaks
rare words into common pieces. **BPE** (byte-pair encoding, used by GPT models) repeatedly merges the most frequent
pairs of symbols. **WordPiece** (used by BERT) is similar. **Unigram** (used by SentencePiece in T5 and others)
starts with many pieces and removes the least useful. In `##ization`, the `##` is WordPiece's marker meaning "this
piece continues the previous word". Each piece maps to an integer **id**. The **embedding lookup** is a table with
one row per vocabulary entry (**vocab**) and one column per **hidden** dimension, for example 30,000 × 768 for BERT
base. **n squared** means doubling the sequence length makes attention four times as expensive. The **task head** is
the final small layer that produces the answer for a specific task.

**Core ideas.**
- **Subword algorithms.** WordPiece (BERT, vocab 30,522), byte-level BPE (GPT-2 50,257, Llama 3 128,256), and
  Unigram/SentencePiece (T5, XLM-R). Byte-level BPE never fails on unknown characters.
- **Fertility** (tokens per word) is ~1.3 for English with modern tokenizers, and often 2–4× higher for
  under-represented scripts. Cost, latency, and context capacity follow token counts (Lecture 195).
- **The tokenizer is part of the model.** Ship `tokenizer.json`, special tokens, and the chat template with the
  weights, version them together, and test that serving produces identical ids to training.
- **Embeddings.** Static token embeddings feed contextual layers. Sentence embeddings come from pooling
  (mean or the CLS token) and usually L2 normalization.
- **Model families.** Encoder-only (BERT, RoBERTa, DeBERTa) for understanding, decoder-only (GPT, Llama) for
  generation, and encoder-decoder (T5, BART, NLLB) for translation and summarization.
- **Performance.** Fast tokenizers (the Rust `tokenizers` library) handle hundreds of thousands of short texts
  per second per core. Slow pure-Python tokenizers can become the CPU bottleneck in front of a GPU.

```python
from transformers import AutoTokenizer
tok = AutoTokenizer.from_pretrained("bert-base-uncased")
print(tok.tokenize("Tokenization matters!"))    # ['token', '##ization', 'matters', '!']
print(tok("Tokenization matters!")["input_ids"])  # [101, ..., 102] with [CLS] and [SEP] added
```

**Example: the tokenizer drift.** A moderation model retrained with a newer tokenizer version that changed
the normalization of accented characters. Serving still loaded the old tokenizer from a shared base image.
No error was raised, but French and Spanish recall dropped 9 points, because the ids no longer matched training.
The fix: package the tokenizer inside the model artifact, and add a CI test that checks token ids on a fixed
multilingual sample against the training run.

**Senior / FAANG best practice.** Version and ship the tokenizer with the model, test serving ids against
training ids in CI, use fast tokenizers, measure fertility per language, and budget compute in tokens, not
requests or characters.

---

## Lecture 191 — Training large transformer models

**Why it matters.** Transformer training at scale is mostly a data and stability problem. Tokenizing on the
fly wastes CPU, padding wastes GPU, and unstable learning-rate settings waste whole runs. The parallelism
machinery (Sections 26, 31, and 32) only pays off when these basics are right.

**In plain words.** Before a marathon, you prepare the route, pace yourself at the start, and have a
plan for when you stumble. For training, that means preparing tokenized data ahead of time, warming up the
learning rate, and having checkpoints and spike handling ready.

**Architecture: a transformer training data and run pipeline.**

```mermaid
flowchart LR
  RAW["Raw corpus<br/>web, code, docs"] --> CLEAN["Filter + dedupe<br/>quality, PII, near-dup"]
  CLEAN --> TOKZ["Tokenize once<br/>parallel CPU job"]
  TOKZ --> PACK["Pack to fixed length<br/>e.g. 4,096 tokens, no padding"]
  PACK --> SHARD[("Token shards<br/>binary, memory-mapped")]
  SHARD --> LOAD["Streaming loader<br/>deterministic, resumable"]
  LOAD --> TRAIN["Training<br/>BF16, warmup + cosine,<br/>grad clipping"]
  TRAIN --> MON["Loss, grad norm,<br/>throughput, MFU"]
  MON -->|"spike"| RB["Roll back to checkpoint,<br/>skip batch, lower LR"]
  TRAIN --> CK[("Checkpoints")]
```

**How to read it:** data is filtered, deduplicated, and tokenized once into packed, fixed-length binary
shards, so training reads ready-made token arrays with no padding. The loader is deterministic and
resumable, so a restart continues from the exact sample. Training uses standard stability measures, and
spikes in loss or gradient norm trigger a rollback rather than hoping it recovers.

**Terms in this diagram.**
- **Corpus**: the whole body of training text.
- **Filter + dedupe: quality, PII, near-dup**: drop low-quality pages, remove personal information, and remove
  **near-duplicates** (documents that are almost identical, found with techniques such as MinHash).
- **Pack to fixed length, no padding**: concatenate many documents, separated by an end-of-text token, and cut the
  stream into equal 4,096-token rows, so no compute is wasted on **padding** (filler tokens).
- **Token shards, binary, memory-mapped**: token ids stored as raw integers in large files that the loader
  **memory-maps** (the OS maps the file into memory and reads pages only as needed).
- **Deterministic, resumable**: the same seed gives the same sample order, and the loader can restart from a saved
  position.
- **BF16, warmup + cosine, grad clipping**: **BF16** is 16-bit training precision. The learning rate **warms up**
  from near zero, then decays along a **cosine** curve. **Gradient clipping** caps the gradient's size each step to
  prevent explosions.
- **Grad norm, MFU**: the **gradient norm** is the overall size of the gradient, and a sudden jump signals
  instability. **MFU** is model FLOPs utilization, the share of the GPU's peak speed you achieve (Section 26).
- **Roll back, skip batch, lower LR**: return to the last good checkpoint, skip the data that triggered the spike,
  and continue with a lower **learning rate** (LR).

**Core ideas.**
- **Pre-tokenize and pack.** Concatenate documents with separator tokens and cut into fixed-length sequences.
  Use attention masks or document boundaries if cross-document attention matters.
- **Deduplication.** Exact and near-duplicate removal (MinHash) improves quality and reduces memorization.
- **Objectives.** Masked language modeling (BERT-style encoders) or next-token prediction (GPT-style).
  Encoders are often trained with shorter sequences (128–512).
- **Stability.**
  - Use BF16, learning-rate warmup then cosine or linear decay, and gradient clipping (1.0).
  - Use AdamW with tuned beta2 (0.95 for large models) and z-loss or QK-norm in some architectures.
  - Monitor gradient norm.
- **Scale references.** BERT-base has 110 M parameters and BERT-large 340 M. DistilBERT keeps ~97% of BERT's
  language understanding with 40% fewer parameters and 60% faster inference.
- **Resumability.** Save the data loader state (shard and offset) with the model checkpoint, or a restart repeats or skips data.

**Example: the padding tax.** A team pretrained a 350M encoder on documents padded to 512 tokens. The
average document had 180 tokens, so 65% of compute went to padding. Packing sequences to 512 with document
masks cut tokens processed per useful token from 2.8 to 1.0, and the same budget trained on 2.8× more real
text.

**Senior / FAANG best practice.** Invest in the data pipeline first: filter, dedupe, tokenize once, pack, and
make the loader deterministic and resumable. Use standard stability settings, track gradient norm and loss
spikes with automated rollback, and run short ablations before long runs.

---

## Lecture 192 — Infrastructure for BERT and GPT

**Why it matters.** BERT-style encoders and GPT-style decoders are both transformers, but their serving
profiles are opposite. Treating a classifier like an LLM wastes GPUs, and treating an LLM like a classifier
gives terrible latency.

**In plain words.** An encoder is a speed reader that reads a short note once and gives a verdict. A
decoder is a storyteller that writes one word at a time and must remember everything it has said so far.
One needs a fast assembly line, the other needs a big notebook (the KV cache).

**Architecture: encoder vs decoder serving.**

```mermaid
flowchart LR
  subgraph ENC["Encoder (BERT-class)"]
    E1["Request: 20-200 tokens"] --> E2["Dynamic batch<br/>ms-level wait"]
    E2 --> E3["One forward pass<br/>ONNX Runtime, TensorRT"]
    E3 --> E4["Label or vector<br/>in 2-20 ms"]
  end
  subgraph DEC["Decoder (GPT-class)"]
    D1["Request: 500-8,000 tokens"] --> D2["Continuous batching"]
    D2 --> D3["Prefill + many decode steps<br/>KV cache per sequence"]
    D3 --> D4["Token stream<br/>over seconds"]
  end
```

**How to read it:** encoder requests are short and finish in a single forward pass, so they batch easily and
can even run on CPUs after optimization. Decoder requests are long, run many steps, hold KV cache memory
for their whole life, and need continuous batching on GPUs (Section 25).

In the diagram, **dynamic batching** waits a few milliseconds to group requests that arrive together, then runs them
as one batch. A **forward pass** is one run of the model from input to output. **ONNX Runtime** and **TensorRT** are
optimized inference runtimes (Section 15). **Continuous batching** lets new requests join, and finished ones leave,
the running batch at every decode step, instead of waiting for the whole batch to finish. **Prefill** processes the
prompt, **decode** generates each new token, and the **KV cache** stores past attention state for each sequence.

**Core ideas.**

| | Encoder (BERT, RoBERTa, DeBERTa) | Decoder (GPT, Llama) |
|---|---|---|
| Work per request | One pass over ≤ 512 tokens | Prefill + one step per output token |
| Latency | 2–20 ms | Hundreds of ms to seconds (streamed) |
| Memory driver | Activations at batch × length | Weights + KV cache per sequence |
| Batching | Dynamic batching (Triton, TorchServe) | Continuous batching (vLLM, TensorRT-LLM) |
| Hardware | CPU (INT8) or small GPU | GPU, often multi-GPU |
| Typical uses | Classification, NER, ranking, embeddings | Chat, summarization, generation, tool use |

- **Encoders are cheap.** A distilled INT8 encoder can serve thousands of requests per second per CPU node,
  and a T4 with TensorRT can serve many thousands of short sequences per second.
- **Many "LLM" tasks are encoder tasks.** Routing, moderation, intent detection, and reranking often run
  10–100× cheaper on a fine-tuned encoder than by prompting a decoder.
- **Shared platform.** One gateway can front both, but keep separate pools and autoscaling signals: queue
  latency and RPS for encoders, queue depth and KV usage for decoders.

**Example: routing with the right model.** A help-desk product sent every ticket to a 70B LLM to classify
intent (12 classes) before answering. Classification was ~40% of LLM tokens. A fine-tuned DeBERTa-v3-base
classifier matched the LLM's accuracy (93.8% vs 94.1%) at ~4 ms on a shared GPU, and cut the LLM bill by a third.

**Senior / FAANG best practice.** Use the right architecture for the task. Push classification, extraction,
ranking, and routing to fine-tuned encoders, keep decoders for generation, and run them in separate pools with
different autoscaling signals. Re-check periodically, as small models improve quickly.

---

## Lecture 193 — Efficient serving of embedding models

**Why it matters.** Embeddings power search, RAG, recommendations, deduplication, and clustering. An
embedding service has two very different workloads, bulk indexing of millions of documents and
millisecond query embedding, and it must keep vectors consistent across model versions.

**In plain words.** Embedding a library's whole catalog is a night shift in a factory: maximum throughput,
latency doesn't matter. Embedding a visitor's question is a front-desk job: one at a time, instantly. Use
the same recipe for both, or the catalog and the questions won't match.

**Architecture: online and bulk embedding paths.**

```mermaid
flowchart LR
  subgraph ONLINE["Online: query embedding"]
    Q["Queries<br/>10-50 tokens"] --> GWQ["Gateway"]
    GWQ --> SRVQ["Embedding server<br/>TEI or Triton,<br/>max batch delay 2-5 ms"]
    SRVQ --> CQ[("Cache<br/>hash of model+text")]
  end
  subgraph BULK["Bulk: document embedding"]
    DOCS["Docs to (re)index"] --> QUEUE["Work queue<br/>Kafka or batch job"]
    QUEUE --> SRVB["GPU workers<br/>large batches,<br/>length-sorted"]
    SRVB --> VDB[("Vector DB<br/>collection per model version")]
  end
  SRVQ --> VDB
  REG["Model registry<br/>embedding model v3"] -.-> SRVQ
  REG -.-> SRVB
```

**How to read it:** queries go through a low-latency server with a tiny batching window and a cache.
Documents are embedded by GPU workers pulling from a queue in large, length-sorted batches. Both use the
same registered model version, and each version writes to its own collection, because vectors from
different models can't be compared.

In the diagram, **TEI** (Text Embeddings Inference) is Hugging Face's dedicated embedding server. **Triton** is
NVIDIA's general inference server (Section 15). **Max batch delay 2-5 ms** is how long the server waits to fill a
batch. The **cache key** is a hash of "model+text" (the model version plus the text), so a model upgrade never
returns stale vectors. The **model registry** records which embedding model version is current (Section 9). To **(re)index** means embedding documents for the first time, or again with a new model. **Length-sorted**
batches group texts of similar length, so little compute is wasted on padding. A **collection** is one named index in
the vector database.

**Core ideas.**
- **Servers.** Hugging Face Text Embeddings Inference (TEI), Triton with ONNX or TensorRT, and vLLM (which supports
  embedding models). All provide dynamic batching.
- **Throughput tricks.** Sort by length within a batch window (less padding), use FP16 or INT8, fused attention,
  and truncation to what the model was trained on (often 512).
- **Dimensions and storage.** 384 (small), 768 (base), and 1,024+ (large). Matryoshka-trained models let you
  truncate dimensions (for example 1,024 → 256) with small quality loss. INT8 or binary vector quantization
  cuts index memory 4–32×.
- **Versioning.** A model change means re-embedding the corpus. Build the new collection in parallel, dual-write,
  backfill, evaluate retrieval, switch reads, then delete the old one.
- **Asymmetric models** need prefixes (for example "query: " vs "passage: " for E5). Missing prefixes
  quietly cut retrieval quality.
- **Caching.** Cache by hash of (model version, normalized text). Many queries and chunks repeat.

```bash
docker run --gpus all -p 8080:80 ghcr.io/huggingface/text-embeddings-inference:1.5 \
  --model-id BAAI/bge-small-en-v1.5 --max-batch-tokens 16384 --max-client-batch-size 64
curl -s localhost:8080/embed -H 'content-type: application/json' -d '{"inputs":["What is the GPU quota?"]}' | head -c 120
```

**Example: the 10-day re-index.** Re-embedding 300 M chunks with a new model was estimated at 10 days on
16 GPUs. Profiling showed batches padded to 512 tokens while the median chunk was 140 tokens. Length-sorted
batching with `max-batch-tokens` limits, plus FP16, raised throughput 3.1×. The job finished in 3.5 days, with
dual collections so search served the old model until the switch.

**Senior / FAANG best practice.** Separate online and bulk paths that share a registered model version, use
length-aware batching, version vector collections by model with dual-write migrations, cache by model and text
hash, and evaluate retrieval quality (recall@k on a labeled set) before switching versions.

---

## Lecture 194 — Latency reduction in NLP inference

**Why it matters.** Many NLP models sit in the critical path: search ranking, moderation before posting, intent
routing, and autocomplete. A few milliseconds matter, and the tail (p99) is often dominated by a few long
inputs.

**In plain words.** To speed up a checkout line, you can hire a faster cashier (a smaller model), use a
barcode scanner (compiled kernels), or put customers with a single item in an express lane (length
bucketing). The express lane is often the cheapest win.

**Architecture: where latency comes from and the lever for each.**

```mermaid
flowchart LR
  REQ["Request"] --> TOKN["Tokenize<br/>lever: fast tokenizer"]
  TOKN --> WAIT["Batch wait<br/>lever: max delay 1-5 ms"]
  WAIT --> PAD["Padding to longest<br/>lever: length buckets, truncation"]
  PAD --> FWD["Forward pass<br/>levers: distill, INT8, ONNX/TensorRT, fusion"]
  FWD --> POST["Postprocess<br/>lever: keep it on device"]
  POST --> NET["Network<br/>lever: gRPC, keep-alive"]
```

**How to read it:** each stage of a request has its own latency lever. The forward pass gets the most
attention, but padding (one 512-token input in a batch of short ones) and batch wait time often dominate p99,
so they're tuned first.

**Terms in this diagram.**
- **Fast tokenizer**: Hugging Face's Rust-based tokenizers, which are many times faster than pure-Python ones.
- **Padding to longest**: in a batch, every input is filled with padding tokens up to the longest one's length, and
  the model computes all of them.
- **Length buckets, truncation**: **buckets** group requests of similar length into separate batches. **Truncation**
  cuts inputs at a maximum length, such as 256 tokens, when the tail rarely matters.
- **Distill, INT8, fusion**: use a smaller student model (such as DistilBERT), 8-bit weights, and operator fusion
  (several operations merged into one GPU kernel) (Section 22).
- **Postprocess, keep it on device**: turn raw outputs into the answer. Do softmax and top-k selection on the GPU, and copy only the small final result to the CPU.
- **gRPC, keep-alive**: a binary protocol with lower overhead than JSON over HTTP (Section 14), and **keep-alive**
  connections that are reused instead of re-opened for every request.
- **p99**: the latency within which 99% of requests finish.

**Core ideas.**
- **Control length.** Truncate to the shortest length that keeps accuracy (often 128 for classification). Use
  length buckets or a separate queue for long inputs, and dynamic padding to the batch's longest, not the model maximum.
- **Smaller models.** Distillation (DistilBERT, MiniLM) and pruning heads or layers. Pick the smallest model
  that passes evals.
- **Quantization.** INT8 dynamic quantization on CPU (ONNX Runtime) gives ~2–3× speedup, and FP16 or INT8 on GPU
  with TensorRT. Validate accuracy per slice.
- **Compilation.** ONNX Runtime graph optimizations (attention and LayerNorm fusion), TensorRT, and
  `torch.compile`.
- **Runtime settings.** CPU threads per model instance (`intra_op_num_threads`), several instances rather than one
  with many threads, warm models, and pinned versions.
- **Cascade and cache.** A cheap model or rules first, the expensive model only when uncertain, and a cache for
  repeated inputs.

```python
# ONNX Runtime CPU session tuned for low latency (one instance per 2-4 cores)
import onnxruntime as ort
so = ort.SessionOptions()
so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
so.intra_op_num_threads = 2
so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
sess = ort.InferenceSession("model-int8.onnx", so, providers=["CPUExecutionProvider"])
```

**Example: fixing the tail.** A comment-moderation classifier had p50 of 12 ms and p99 of 310 ms. Batches mixed
20-token comments with occasional 512-token pastes, so every batch with a long input padded to 512. The fix:
truncate to 256 (accuracy unchanged on the eval set), add separate short and long queues, and switch to an
INT8 ONNX model. p50 fell to 6 ms and p99 to 28 ms, on the same hardware.

**Senior / FAANG best practice.** Profile the full request path. Fix length and padding first, then batch
wait, then the model (distill, quantize, compile), and validate accuracy per slice at every step. Set p99 SLOs
per input-length band, and load-test with production length distributions, not fixed-length samples.

---

## Lecture 195 — Deploying multilingual models at scale

**Why it matters.** Global products serve dozens of languages. Tokenizer fertility, model quality, and
regulation all vary by language and region, so one global average metric hides languages that are worse
and more expensive.

**In plain words.** Translating a menu into 30 languages isn't one job. Some languages need twice as many
words for the same dish, some translators are better than others, and some countries require the
menu to be printed locally. Check each language, not just the average.

**Architecture: a multilingual serving setup.**

```mermaid
flowchart LR
  IN["Request"] --> LID["Language ID<br/>fastText or CLD3, under 1 ms"]
  LID --> ROUTE{"Route"}
  ROUTE -->|"high-traffic languages"| SPEC["Specialized models<br/>en, es, ja ..."]
  ROUTE -->|"long tail"| MULTI["Multilingual model<br/>XLM-R, mE5, bge-m3"]
  SPEC --> OUT["Result"]
  MULTI --> OUT
  OUT --> MET["Metrics per language<br/>accuracy, tokens, latency, cost"]
  REG["Regional deployments<br/>EU, US, APAC"] -.-> SPEC
  REG -.-> MULTI
```

**How to read it:** a tiny language-ID model routes each request. High-traffic languages may justify
specialized models for quality and cost, while one multilingual model covers the long tail. Everything
is measured per language, and models are deployed per region where data residency requires it.

In the diagram, **fastText** (from Meta) and **CLD3** (Compact Language Detector 3, from Google) are tiny models that
identify the language of a text in under a millisecond. `en, es, ja` are language codes for English, Spanish, and
Japanese. The **long tail** is the many languages that each have little traffic. **XLM-R**, **mE5**, and **bge-m3**
are widely used multilingual encoder and embedding models. **Tokens** are tracked per language because some scripts
need many more tokens for the same meaning, which raises cost and latency. **EU** is the European Union, and
**APAC** means Asia-Pacific. **Data
residency** laws require some users' data to be processed inside their own region.

**Core ideas.**
- **Models.** mBERT (104 languages), XLM-RoBERTa (100 languages, base ~270 M / large ~550 M),
  multilingual-E5, bge-m3 (100+ languages, long inputs), LaBSE for sentence alignment, NLLB-200 for translation,
  and multilingual LLMs.
- **Fertility and cost.** If Thai or Hindi uses 2–3× the tokens of English for the same content, those users pay
  more in latency and cost, and get less effective context. Measure tokens per character or word per
  language, and size capacity by language mix.
- **Evaluation.** Use per-language test sets (not machine-translated English only), and watch for the "curse of
  multilinguality", where adding languages to a fixed-size model reduces per-language quality.
- **Text handling.** Unicode normalization (NFC/NFKC), script and direction (RTL), segmentation for languages
  without spaces, and code-switching.
- **Regional deployment** for latency and residency (Sections 20 and 42), with the same model artifacts and
  per-region monitoring.

**Example: the hidden language gap.** A support classifier reported 92% accuracy globally. Per-language
evaluation showed English 95%, Spanish 93%, Vietnamese 78%, and Tagalog 71%. The long-tail languages also
averaged 2.4× more tokens per ticket. The team added native-labeled data for the 6 weakest languages,
switched to a larger multilingual encoder only for them (routed by language ID), and set per-language accuracy
gates in CI.

**Senior / FAANG best practice.** Measure quality, tokens, latency, and cost per language, gate releases on
per-language thresholds, route by language between specialized and multilingual models, normalize text
consistently, and deploy regionally where residency or latency requires it.

---

## Lecture 196 — Lab: deploy a BERT model with FastAPI

**Goal:** serve a DistilBERT sentiment classifier with FastAPI, first in PyTorch, then as an INT8 ONNX model
with micro-batching. Load-test both with realistic text lengths and compare p50/p99 latency, throughput, and
accuracy on SST-2.

**What you're building.**

```mermaid
flowchart LR
  LOAD["load.py<br/>concurrent clients,<br/>real length mix"] --> API["FastAPI /classify"]
  API --> MB["Micro-batcher<br/>max 32, max wait 3 ms"]
  MB --> V1["v1: PyTorch FP32"]
  MB --> V2["v2: ONNX Runtime INT8"]
  API --> HC["/healthz, /readyz"]
  V2 --> ACC["eval: SST-2 validation accuracy"]
```

**In plain words.** You put a real NLP model behind an HTTP API, make it about 3× faster without new
hardware, and prove with measurements that accuracy held.

**How to read the diagram:** `load.py` simulates many concurrent clients, sending texts with a realistic mix of
lengths. The FastAPI `/classify` endpoint passes requests to a **micro-batcher**, which groups up to 32 requests or
waits at most 3 ms, whichever comes first. Version v1 runs the model in plain PyTorch at FP32. Version v2 runs the same
model exported to ONNX Runtime with INT8 quantization. `/healthz` and `/readyz` are the liveness and readiness
endpoints (Section 14). The evaluation runs v2 on the **SST-2** validation set (Stanford Sentiment Treebank, a
standard positive or negative sentiment dataset), to confirm the faster model is still accurate.

### Step 1 — Baseline service

```bash
pip install "transformers>=4.45" torch fastapi uvicorn "optimum[onnxruntime]" datasets httpx
```

```python
# app.py: MODE=torch or MODE=onnx
import asyncio, os, time
import numpy as np
from fastapi import FastAPI
from transformers import AutoTokenizer
MODEL = "distilbert-base-uncased-finetuned-sst-2-english"
MODE = os.getenv("MODE", "torch")
tok = AutoTokenizer.from_pretrained(MODEL)
if MODE == "torch":
    import torch
    from transformers import AutoModelForSequenceClassification
    torch.set_num_threads(4)
    model = AutoModelForSequenceClassification.from_pretrained(MODEL).eval()
    def infer(texts):
        enc = tok(texts, padding=True, truncation=True, max_length=128, return_tensors="pt")
        with torch.inference_mode():
            return model(**enc).logits.numpy()
else:
    from optimum.onnxruntime import ORTModelForSequenceClassification
    model = ORTModelForSequenceClassification.from_pretrained("onnx-int8", file_name="model_quantized.onnx")
    def infer(texts):
        enc = tok(texts, padding=True, truncation=True, max_length=128, return_tensors="np")
        return model(**enc).logits

app, queue = FastAPI(), asyncio.Queue()
MAX_BATCH, MAX_WAIT = 32, 0.003

async def batcher():
    while True:
        items = [await queue.get()]
        deadline = time.perf_counter() + MAX_WAIT
        while len(items) < MAX_BATCH and (left := deadline - time.perf_counter()) > 0:
            try:
                items.append(await asyncio.wait_for(queue.get(), left))
            except asyncio.TimeoutError:
                break
        logits = await asyncio.to_thread(infer, [t for t, _ in items])
        for (_, fut), row in zip(items, logits):
            fut.set_result(row)

@app.on_event("startup")
async def start():
    infer(["warm up"]); asyncio.create_task(batcher())

@app.get("/healthz")
def healthz(): return {"ok": True}

@app.get("/readyz")
def readyz(): return {"ready": True, "mode": MODE}

@app.post("/classify")
async def classify(body: dict):
    fut = asyncio.get_running_loop().create_future()
    await queue.put((body["text"], fut))
    row = await fut
    p = np.exp(row - row.max()); p /= p.sum()
    return {"label": ["NEGATIVE", "POSITIVE"][int(p.argmax())], "score": float(p.max()), "mode": MODE}
```

### Step 2 — Export and quantize to ONNX INT8

```bash
optimum-cli export onnx --model distilbert-base-uncased-finetuned-sst-2-english onnx-fp32/
optimum-cli onnxruntime quantize --onnx_model onnx-fp32/ --avx512 -o onnx-int8/   # use --avx2 or --arm64 to match your CPU
```

### Step 3 — Load test both modes

```python
# load.py: 32 concurrent clients, SST-2 validation sentences (real length mix), 2,000 requests
import asyncio, statistics, sys, time
import httpx
from datasets import load_dataset
texts = load_dataset("glue", "sst2", split="validation")["sentence"]
async def main(n=2000, conc=32):
    lat = []
    async with httpx.AsyncClient(base_url="http://localhost:8000", timeout=10) as c:
        sem = asyncio.Semaphore(conc)
        async def one(i):
            async with sem:
                t = time.perf_counter(); await c.post("/classify", json={"text": texts[i % len(texts)]})
                lat.append((time.perf_counter() - t) * 1000)
        t0 = time.perf_counter(); await asyncio.gather(*(one(i) for i in range(n))); dt = time.perf_counter() - t0
    lat.sort()
    print(f"rps={n / dt:.0f} p50={lat[n // 2]:.1f}ms p99={lat[int(n * .99)]:.1f}ms")
asyncio.run(main())
```

```bash
MODE=torch uvicorn app:app --port 8000 & sleep 20; python load.py; kill %1
MODE=onnx  uvicorn app:app --port 8000 & sleep 20; python load.py; kill %1
```

### Step 4 — Check accuracy did not regress

```python
# eval.py: SST-2 validation accuracy for the INT8 model (872 sentences)
from datasets import load_dataset
from optimum.onnxruntime import ORTModelForSequenceClassification
from transformers import AutoTokenizer
ds = load_dataset("glue", "sst2", split="validation")
tok = AutoTokenizer.from_pretrained("distilbert-base-uncased-finetuned-sst-2-english")
m = ORTModelForSequenceClassification.from_pretrained("onnx-int8", file_name="model_quantized.onnx")
correct = 0
for i in range(0, len(ds), 64):
    b = ds[i:i + 64]
    pred = m(**tok(b["sentence"], padding=True, truncation=True, max_length=128, return_tensors="np")).logits.argmax(-1)
    correct += int((pred == b["label"]).sum())
print(f"accuracy {correct / len(ds):.4f}")
```

**Expected results** (8-core x86 CPU, rough):

| Mode | Throughput | p50 | p99 | SST-2 accuracy |
|---|---|---|---|---|
| PyTorch FP32 + micro-batching | ~150–300 req/s | ~80–150 ms | ~200–300 ms | 0.911 (model card 91.3%) |
| ONNX Runtime INT8 + micro-batching | ~500–900 req/s | ~30–50 ms | ~60–100 ms | ~0.90–0.91 |

- Micro-batching raises throughput substantially compared with batch-1 requests at the same concurrency. With
  `MAX_BATCH = 1`, p99 climbs sharply under 32 concurrent clients.
- INT8 typically gives a 2–3× speedup on CPU with ≤ 1 point accuracy change. Always confirm with `eval.py`.
- Latency at this concurrency is mostly queueing. Lower concurrency gives single-digit-ms p50 for the INT8
  model.

---

## FAANG deep-dive notes

**How big tech does it.** Large NLP platforms run fleets of small, fine-tuned encoders for classification,
ranking, moderation, and embeddings. These are distilled, quantized, and compiled, served with dynamic
batching, and often on CPUs. Generation is a separate GPU platform. Tokenizers ship inside model artifacts,
with CI checks on token ids. Embedding services have separate bulk and online paths, with versioned
collections. Quality, latency, and cost are tracked per language and region, with per-language release gates.

**Staff review questions.**
- What's the input length distribution, and how does it drive p99 and cost?
- Could a smaller encoder do this instead of an LLM? What's the eval evidence?
- How are tokenizer and model versioned together, and how is that tested?
- What's the re-embedding plan when the embedding model changes?
- What are accuracy and tokens per language, and which languages are below the gate?

**Interview question.** "Design a toxicity classification service for comments in 30 languages."

**Typical system-design prompt:** *Design a toxicity classifier for user comments in 30 languages: 100,000
requests/s at peak, p99 < 50 ms, with per-language recall targets, running in three regions.*

**1. Clarify first:** What are the comment lengths (median and p99 in tokens)? Which languages carry most of the
traffic? Are there recall and precision targets per language and per category? Is it blocking (synchronous) or
asynchronous review? Are there human appeal and labeling loops? Are there residency constraints?

**2. Back-of-envelope sizing:**
- Median 40 tokens, p99 400 tokens. Truncate to 256 after confirming recall holds.
- A distilled multilingual encoder (~100–150 M params) on GPU with TensorRT FP16 handles roughly 3,000–6,000
  short sequences/s per T4-class GPU. 100,000/s ÷ ~4,000 ≈ 25 GPUs, ×1.5 for headroom and long inputs ≈ ~40
  across regions.
- The CPU alternative: INT8 at ~200–400 sequences/s per core needs ~300–500 cores. Compare cost per million
  requests on both.
- Tokenization: a fast tokenizer at ~100,000+ short texts/s per core needs ~1–2 cores per GPU, which is fine.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Model | One multilingual encoder | Per-language specialists | Multilingual first. Specialists for top languages if they beat it on evals and cost |
| Hardware | CPU INT8 | GPU TensorRT | Compare cost per million requests at the p99 target |
| Long inputs | Truncate | Chunk + aggregate | Truncate if recall holds. Chunk for long-form content |
| Batching | Single queue | Length-bucketed queues | Buckets when the length distribution is wide |
| Cascade | One model | Fast model + LLM on uncertain | Cascade when a small fraction is ambiguous |

**4. Follow-up questions with crisp answers:**
- *How do you hit p99 with long inputs?* Truncate, use length buckets or a separate queue for long inputs, use
  dynamic padding, and set per-length SLOs.
- *How do you know Vietnamese recall is OK?* A native-labeled test set per language, per-language gates in CI,
  and production sampling with human review.
- *How do you update the model safely?* Shadow it on live traffic, compare per-language metrics, canary by region,
  and roll back automatically on recall drop.
- *Why not just prompt an LLM?* At 100,000/s, that's orders of magnitude more cost and latency. Use an LLM only
  for ambiguous cases or for labeling.

**Debug this (common onsite question):** "p50 latency is 9 ms, but p99 is 700 ms, and GPU utilization is
only 35%."
1. Break p99 latency into stages. Queue wait and the forward pass are both high for the slow requests.
2. Log sequence lengths per batch: slow batches contain one input at 512 tokens, and all 32 inputs are padded to 512.
3. The tokenizer was set to `padding="max_length"` in one code path, so even short batches pad to the maximum.
4. Fix: dynamic padding, truncation to 256, short and long queues, and a dashboard of p99 by length band.

The lesson: in NLP serving, latency is a function of sequence length. Control lengths and padding before
buying hardware.

**5. What separates senior from staff answers:** a senior engineer optimizes the model (distill,
quantize, compile) and tunes batching. A staff engineer chooses the right model class for each task (encoder vs
LLM), sizes by tokens and length distribution, versions tokenizers with models, plans re-embedding migrations,
and makes per-language quality and cost first-class, with gates and routing.

**Red flags:**
- Padding to the model maximum.
- Tokenizer loaded separately from the model.
- One global accuracy number for 30 languages.
- Prompting an LLM for high-QPS classification.
- Re-embedding in place without dual collections.
- Load tests with fixed-length inputs.

---

## Quiz

<details><summary>1. Why must the tokenizer be versioned with the model?</summary>
The model learned embeddings for specific token ids. A different tokenizer or normalization produces different
ids, and the model silently degrades without any error.
</details>

<details><summary>2. What is tokenizer fertility, and why does it matter for infrastructure?</summary>
The number of tokens per word or character. Higher fertility (common for under-represented languages) means more
compute, latency, and cost per request, and less effective context.
</details>

<details><summary>3. Why pre-tokenize and pack sequences for training?</summary>
It avoids on-the-fly CPU tokenization and eliminates padding waste. Every training token is real data, and
loading is a fast read of memory-mapped arrays.
</details>

<details><summary>4. How do encoder and decoder serving differ?</summary>
Encoders take one forward pass over short inputs, with dynamic batching, ms latency, and can run on CPU. Decoders
take prefill plus many decode steps, hold a KV cache per sequence, use continuous batching on GPUs, and stream output.
</details>

<details><summary>5. Why separate bulk and online embedding paths?</summary>
Bulk indexing needs maximum throughput (large, length-sorted batches). Online queries need low latency (tiny batch
windows). Both must use the same model version so vectors are comparable.
</details>

<details><summary>6. What is the safe way to change an embedding model?</summary>
Build a new collection with the new model, dual-write, backfill, evaluate retrieval on a labeled set, switch reads,
then retire the old collection. Never mix vectors from different models.
</details>

<details><summary>7. Name four ways to cut NLP inference latency.</summary>
Truncation and dynamic padding with length buckets, distillation to a smaller model, INT8 or FP16 quantization,
compilation (ONNX Runtime or TensorRT fusions), tuned batching windows, and caching.
</details>

<details><summary>8. Why evaluate multilingual models per language?</summary>
Global averages hide weak languages. Quality and token costs vary widely by language, so per-language test sets and
gates are needed to find and fix gaps.
</details>

## Failure modes
- Tokenizer and model versions drifting apart between training and serving.
- Padding to the model maximum, or mixing long and short inputs in one batch.
- Compute budgeted by requests instead of tokens.
- LLMs used for high-volume classification that an encoder could do.
- Embedding model changed without re-embedding, mixing incompatible vectors.
- Missing query/passage prefixes for asymmetric embedding models.
- Data loader state not checkpointed, so restarts repeat or skip data.
- Multilingual quality reported only as a global average.
- Load tests with fixed-length synthetic inputs.

## Checklist
- [ ] You can explain BPE, WordPiece, and Unigram tokenization, and measure fertility per language
- [ ] Your tokenizer ships with the model, and CI checks token ids
- [ ] You can design a pre-tokenized, packed, resumable training data pipeline
- [ ] You know when to use an encoder instead of an LLM, and how their serving differs
- [ ] You can run an embedding server and plan a versioned re-embedding migration
- [ ] You can cut NLP latency with length control, distillation, INT8, and compilation
- [ ] You evaluate and budget multilingual models per language
- [ ] You deployed DistilBERT with FastAPI, ONNX INT8, and micro-batching, and load-tested it
