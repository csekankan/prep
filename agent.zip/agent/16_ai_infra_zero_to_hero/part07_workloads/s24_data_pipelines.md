# Section 24 — Data Pipelines for AI at Scale

> Lectures 162–168 • Assessments: quiz, [Aggregate streaming events into time windows](#assessment--aggregate-streaming-events-into-time-windows) • Exercise: [`s24_stream_windows.py`](../exercises/s24_stream_windows.py)
> **After this section you can:** choose between ETL and ELT, build idempotent Airflow DAGs for training data,
> run Kafka with the right durability settings, serve point-in-time-correct features from a feature store,
> process streams with event-time windows and watermarks, monitor data quality with contracts and gates, and
> build a streaming feature pipeline from Kafka to an online store.
>
> Go deeper: [13 / Lab 63 — Kafka real-time RAG](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab63_kafka_realtime_rag.md),
> [Lab 64 — Pydantic edge validation](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab64_pydantic_edge_validation.md),
> [Lab 60 — Redis for AI](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab60_redis_for_ai.md),
> [Lab 66 — Data provenance hashing](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab66_data_provenance_hashing.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 162 | Introduction to ETL and ELT pipelines | Land raw data first (ELT), transform in the warehouse or lakehouse, and keep every step idempotent and partitioned |
| 163 | Apache Airflow for AI workflows | Airflow orchestrates, it doesn't compute: small idempotent tasks, partitioned by date, with heavy work in pods |
| 164 | Streaming data with Apache Kafka | A durable, partitioned log. Ordering is per partition, durability comes from `acks=all` + `min.insync.replicas=2` |
| 165 | Feature stores for ML (Feast, Tecton) | One definition, two stores: offline for point-in-time-correct training, online for millisecond serving |
| 166 | Real-time preprocessing at scale | Stateful stream processing on event time, with watermarks, checkpoints, and exactly-once sinks |
| 167 | Data quality monitoring for AI systems | Contracts and checks on schema, volume, freshness, and distribution, which block bad data before training |
| 168 | Lab: build a streaming pipeline with Kafka | Producer to Kafka to a windowed feature job to Redis, with lag, late data, and replay tested |

```mermaid
flowchart LR
  subgraph SRC["Sources"]
    APP["App events"]
    DB["OLTP databases<br/>via CDC"]
    FILES["Files and partners"]
  end
  subgraph STREAM["Streaming path"]
    K["Kafka topics"] --> SP["Stream processor<br/>Flink or Spark"]
  end
  subgraph BATCH["Batch path"]
    RAW["Raw zone<br/>object storage"] --> XF["Transform<br/>Spark, dbt, SQL"]
    XF --> CUR["Curated tables<br/>Iceberg or Delta"]
  end
  APP --> K
  DB --> K
  K --> RAW
  FILES --> RAW
  SP --> ON["Online store<br/>Redis or DynamoDB"]
  CUR --> OFF["Offline store<br/>training sets"]
  SP --> CUR
  OFF --> TRAIN["Training"]
  ON --> SERVE["Model serving"]
  AF["Airflow<br/>orchestration"] -.-> XF
  AF -.-> TRAIN
  DQ["Data quality checks"] -.-> CUR
  DQ -.-> SP
```

**How to read it:** events and database changes flow into Kafka, which feeds two paths. The streaming
path computes fresh features into a low-latency online store for serving. The batch path lands everything
in object storage, transforms it into curated tables, and builds training sets. Airflow schedules the batch
work and the training. Data quality checks guard both paths, so bad data is stopped before a model learns
from it.

**Terms in this diagram.**
- **OLTP databases via CDC**: **OLTP** (online transaction processing) databases are the app's live databases, such as
  Postgres or MySQL, serving orders and accounts. **CDC** (change data capture) streams every insert, update, and
  delete from the database's log into Kafka, for example with Debezium, without querying the database.
- **Kafka topics**: named, durable event streams (Lecture 164).
- **Stream processor, Flink or Spark**: a program that handles events continuously as they arrive. **Apache Flink**
  and **Spark Structured Streaming** are the main engines (Lecture 166).
- **Raw zone, object storage**: the landing area in S3, GCS, or similar, where data is stored unchanged
  (Lecture 162).
- **Transform: Spark, dbt, SQL**: **dbt** (data build tool) manages SQL transformations as versioned, tested code.
- **Curated tables, Iceberg or Delta**: cleaned, documented tables in an open table format (**Apache Iceberg** or
  **Delta Lake**) that adds versions and safe updates on top of files (Section 6).
- **Online store, Redis or DynamoDB**: a key-value database serving the latest feature values in milliseconds.
- **Offline store, training sets**: the historical feature values used to build training data (Lecture 165).
- **Airflow orchestration**: Apache Airflow runs scheduled tasks in the right order and retries failures
  (Lecture 163).

---

## Lecture 162 — Introduction to ETL and ELT pipelines

**Why it matters.** Models are only as good as the data pipelines feeding them. Most production ML
incidents are data incidents, such as a broken join, a silently empty partition, a unit change, or a
duplicated day, rather than model bugs. Pipeline design determines whether you can reproduce, backfill,
and debug training data.

**In plain words.** ETL is cooking before you put food in the fridge: you extract, transform, then load
only the finished dish. ELT puts the raw groceries in the fridge first, then cooks whatever recipe you
need later. With cheap storage and powerful warehouses, ELT usually wins, because you can always cook a
new recipe from the raw ingredients.

**Architecture: the medallion (raw, cleaned, curated) layout.**

```mermaid
flowchart LR
  S["Sources<br/>APIs, DBs, events"] -->|"extract + load as-is"| BR["Bronze (raw)<br/>append-only, partitioned by date"]
  BR -->|"clean, dedupe, type, PII mask"| SI["Silver (cleaned)<br/>conformed tables"]
  SI -->|"join, aggregate, label"| GO["Gold (curated)<br/>features, training sets"]
  GO --> ML["Training and evaluation"]
  GO --> BI["Analytics"]
  BR -.->|"replay any day"| SI
```

**How to read it:** raw data is stored unchanged and forever (or for its retention period). Each later
layer is derived and can be rebuilt from the layer before it. When a transformation bug is found, you fix
the code and recompute silver and gold from bronze.

In the diagram, **bronze, silver, gold** are the layers of the **medallion architecture**, ordered from raw to most
refined. **Append-only** means records are only added, never changed. **Dedupe** removes duplicate records. **Type**
means converting text fields into proper types such as dates and numbers. **PII mask** hides or hashes personal data
such as emails. **Conformed** tables use the same IDs, names, and units everywhere, so they can be joined. **Label**
means attaching the training target, for example "did this user churn?". **BI** (business intelligence) is reporting
and dashboards. **Replay any day** means re-running the transformation on any past date's bronze data.

**Core ideas.**

| | ETL | ELT |
|---|---|---|
| Where it transforms | A separate engine before loading | Inside the warehouse or lakehouse (SQL, dbt, Spark) |
| Raw data kept? | Often not | Yes, in the raw (bronze) zone |
| Change a transformation | Re-extract from sources | Recompute from raw |
| Best for | Strict PII removal before storage, legacy systems | Most modern analytics and ML |

- **Idempotent and partitioned.** Each run processes one partition (for example `dt=2026-11-12`) and
  *overwrites* that partition. Running it twice gives the same result. Appending on retry creates duplicates.
- **Table formats.** Apache Iceberg, Delta Lake, and Apache Hudi add ACID transactions, schema evolution,
  and time travel on top of Parquet in object storage. Time travel means you can rebuild "the training set as
  of model v12".
- **Change data capture (CDC).** Debezium reads database write-ahead logs into Kafka, so you get every
  change without hammering production with `SELECT *`.
- **Lineage.** Record which inputs and code version produced each table (OpenLineage, a data catalog). You'll
  need it for audits (Section 18) and for debugging.

**Example: the double-counted day.** A daily job appended yesterday's transactions to the training table.
One night it failed halfway and the retry appended again, so 40% of rows were duplicated. The fraud model
retrained on it learned that duplicated merchants were "normal" and its precision dropped. The fix was
a partition overwrite (`INSERT OVERWRITE ... PARTITION (dt)`) plus a uniqueness check on `txn_id`. The
pattern is the same one as the idempotent ingest exercise in Section 6.

**Senior / FAANG best practice.** Keep raw data immutable and partitioned, make every job a pure function
of (input partitions, code version) that overwrites its output partition, use an open table format with
time travel, and record lineage. Then any training set can be reproduced and any bug fixed with a
backfill.

---

## Lecture 163 — Apache Airflow for AI workflows

**Why it matters.** Training data builds, retraining, evaluation, and batch inference are multi-step
workflows with dependencies, retries, and schedules. Airflow is the most widely used orchestrator for
them, and misusing it, for example by doing heavy compute inside the scheduler's workers, is a classic
source of outages.

**In plain words.** Airflow is a conductor. It doesn't play the instruments. It tells each musician
(Spark, a GPU pod, a SQL warehouse) when to start, waits for them to finish, and restarts them if they
stumble.

**Architecture: Airflow components.**

```mermaid
flowchart LR
  DAGS["DAG files in Git<br/>synced to Airflow"] --> SCH["Scheduler<br/>decides what runs"]
  SCH --> MDB[("Metadata DB<br/>Postgres")]
  SCH --> EX["Executor<br/>Kubernetes or Celery"]
  EX --> P1["Pod: extract"]
  EX --> P2["Pod: Spark job"]
  EX --> P3["Pod: GPU training"]
  WEB["Web UI / API server"] --> MDB
  P2 --> S3["Object storage"]
  P3 --> REG["Model registry"]
```

**How to read it:** DAG files describe tasks and their dependencies. The scheduler stores state in a
metadata database and hands ready tasks to an executor, which, with Kubernetes, launches one pod per task.
Heavy work runs in those pods or in external systems such as Spark. Airflow tracks only the state.

In the diagram, a **DAG** (directed acyclic graph) is a workflow: tasks connected by arrows showing which must finish
first, with no loops. DAG files are Python code. The **scheduler** checks each DAG's timetable and dependencies and
decides which tasks are ready. The **metadata DB**, usually **Postgres**, records every run and task state. The
**executor** decides *how* tasks run. The **Kubernetes** executor starts a pod per task, and the **Celery** executor
sends tasks to a pool of long-running worker machines through a message queue. The **web UI / API server** shows run
history and lets you trigger or retry tasks. The training pod saves its result to the **model registry**, the
versioned catalog of trained models (Section 9).

**Core ideas.**
- **DAG.** Tasks and dependencies, with a schedule. Each run has a *logical date* (the data interval it
  processes). Use it for partitioning, not `now()`, so backfills reproduce history.
- **Operators.** `KubernetesPodOperator` runs any container. Others include Spark, SQL, and sensors. The
  TaskFlow API (`@task`) makes Python tasks simple.
- **Data-aware scheduling.** Assets (called Datasets before Airflow 3) let a DAG run when an upstream table
  is updated, instead of guessing with a cron time.
- **Pools and priority.** Limit concurrency against scarce resources (for example a `gpu` pool with 8 slots).
- **XCom** passes small metadata (paths, metrics) between tasks, never datasets.
- **Alternatives.** Kubeflow Pipelines (Section 33), Argo Workflows, Dagster (asset-centric), Prefect, and
  managed services such as Cloud Composer and MWAA.

```python
# dags/train_fraud.py: daily build, validate, train, and gate (Airflow 2.x/3.x TaskFlow)
from datetime import datetime, timedelta
from airflow.decorators import dag, task
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator

@dag(schedule="0 3 * * *", start_date=datetime(2026, 1, 1), catchup=False, max_active_runs=1,
     default_args={"retries": 2, "retry_delay": timedelta(minutes=10)}, tags=["ml", "fraud"])
def train_fraud():
    build = KubernetesPodOperator(
        task_id="build_features", image="registry.local/feature-build:1.8.2",
        arguments=["--date", "{{ ds }}", "--mode", "overwrite"],        # idempotent per partition
        container_resources={"requests": {"cpu": "4", "memory": "16Gi"}})
    validate = KubernetesPodOperator(
        task_id="validate_data", image="registry.local/dq:0.9.0",
        arguments=["--table", "gold.fraud_features", "--partition", "{{ ds }}"])
    train = KubernetesPodOperator(
        task_id="train", image="registry.local/train:2.3.0", pool="gpu",
        arguments=["--train-end", "{{ ds }}"],
        container_resources={"limits": {"nvidia.com/gpu": "1"}})

    @task
    def gate(run_id: str = "{{ run_id }}"):
        ...  # compare candidate vs production metrics, register only if better (Section 10)

    build >> validate >> train >> gate()

train_fraud()
```

**Example: the scheduler that fell over.** A team loaded a 6 GB CSV with pandas inside a `PythonOperator`
on Celery workers shared by 300 DAGs. Workers ran out of memory, tasks were killed, and retries piled up,
so every team's DAGs were delayed for hours. Moving the job into a `KubernetesPodOperator` with its own
resource requests isolated it, and the shared workers went back to only orchestrating.

**Senior / FAANG best practice.** Treat the orchestrator as a control plane. Keep tasks small,
idempotent, and parameterized by the logical date, run compute in isolated containers, use pools for scarce
resources, test DAGs in CI (import tests and a dry run), and alert on SLA misses and data freshness, not
only task failures.

---

## Lecture 164 — Streaming data with Apache Kafka

**Why it matters.** Fresh features (clicks in the last 5 minutes, transactions in the last hour), real-time
RAG updates, and logs for monitoring all move through a streaming backbone. Kafka is the standard one, and
its settings decide whether you lose data, reorder it, or duplicate it.

**In plain words.** Kafka is a set of append-only notebooks. Producers write lines at the end. Each
reader keeps a bookmark (offset) and reads at its own pace, so slow readers don't slow writers, and a reader
can go back and reread from an earlier bookmark.

**Architecture: topics, partitions, replicas, and consumer groups.**

```mermaid
flowchart LR
  PR["Producers<br/>key = user_id"] --> T
  subgraph T["Topic clicks: 6 partitions, replication factor 3"]
    P0["Partition 0<br/>leader broker 1"]
    P1["Partition 1<br/>leader broker 2"]
    P2["Partition 2 ... 5"]
  end
  P0 -.->|"replicate"| F0["Followers on<br/>brokers 2 and 3"]
  T --> CG1["Consumer group: features<br/>3 consumers, 2 partitions each"]
  T --> CG2["Consumer group: archiver<br/>writes to object storage"]
  CTRL["KRaft controllers<br/>cluster metadata"] -.-> T
```

**How to read it:** a topic is split into partitions spread across brokers. Each partition has a leader
and follower replicas. Records with the same key go to the same partition, so they stay in order.
Each consumer group gets every record, and within a group each partition is read by exactly one consumer,
so the number of partitions caps a group's parallelism.

**Terms in this diagram.**
- **Producers, key = user_id**: programs that write records. The **key** decides the partition (by hashing it), so
  all of one user's events land in one partition, in order.
- **Partition**: one ordered, append-only log. A topic is split into several so many machines can share the work.
- **Replication factor 3**: each partition is stored on 3 brokers, so it survives losing 2 of them.
- **Broker**: one Kafka server.
- **Leader, followers**: the **leader** replica handles all reads and writes for a partition. **Followers** copy it,
  and one takes over if the leader fails.
- **Consumer group**: a set of consumers sharing one job. Kafka splits the partitions among them and tracks the
  group's position, its **offset**, in each partition.
- **Archiver**: a consumer that copies every record to object storage for long-term keeping.
- **KRaft controllers**: Kafka's built-in metadata quorum (Kafka Raft), which tracks brokers, topics, and leaders. It
  replaced the older ZooKeeper dependency.

**Core ideas.**
- **Ordering** is guaranteed only within a partition. Key by the entity whose order matters (user, account).
- **Durability.** Use `replication.factor=3`, `min.insync.replicas=2`, and producer `acks=all`. A write is
  acknowledged only when two replicas have it, so one broker failure loses nothing.
- **Delivery semantics.** At-least-once is the default (commit offsets after processing, so you might see
  duplicates on retry). The idempotent producer (the default since Kafka 3.0) removes duplicates caused by
  producer retries. Exactly-once read-process-write uses transactions (`isolation.level=read_committed`).
- **Retention** is time- or size-based. Log compaction keeps the latest value per key, which is good for
  changelogs. Tiered storage moves old segments to object storage.
- **Schemas.** Use a schema registry (Avro or Protobuf) with compatibility rules, so producers can't break
  consumers (Section 14's contract idea, applied to events).
- **Consumer lag** (latest offset minus committed offset) is the key health metric.
- **KRaft** replaced ZooKeeper for metadata. Kafka 4.0 removed ZooKeeper entirely.

```properties
# producer: durable and ordered per key
acks=all
enable.idempotence=true
compression.type=zstd
linger.ms=10
batch.size=131072
# topic
replication.factor=3
min.insync.replicas=2
retention.ms=604800000      # 7 days
```

**Example: the hot partition.** Events were keyed by `country`. One country produced 60% of traffic, so one
partition, and the one consumer reading it, did most of the work, and lag on it grew to 40 minutes while the
others sat idle. Re-keying by `user_id` spread the load, and the consumer for ordering by user still worked.
Partition count was raised from 12 to 48 ahead of the next peak.

**Senior / FAANG best practice.** Choose keys for both ordering and even spread, size partitions for the
peak consumer parallelism you'll need (they're hard to reduce later), and run `acks=all` with
`min.insync.replicas=2` and RF 3. Enforce schemas through a registry, alert on consumer lag in time (not only
offsets), and design consumers to be idempotent, because duplicates will happen.

---

## Lecture 165 — Feature stores for ML (Feast, Tecton)

**Why it matters.** Two of the most expensive ML bugs are *training-serving skew* (features computed one
way for training and another way in production) and *label leakage* (training on feature values that
weren't known at prediction time). Feature stores exist to prevent both, and to let teams reuse features.

**In plain words.** A feature store is a shared pantry with one recipe card per ingredient. The
same recipe is used to prepare large batches for training and single portions for serving. It also
records when each portion was made, so training only uses what existed at that moment.

**Architecture: offline and online stores.**

```mermaid
flowchart LR
  DEF["Feature definitions in Git<br/>entity, source, TTL"] --> REG["Registry"]
  SRC["Batch sources<br/>warehouse tables"] --> OFF[("Offline store<br/>BigQuery, Snowflake, Parquet")]
  STR["Streaming source<br/>Kafka"] --> PUSH["Stream job<br/>push features"]
  OFF -->|"materialize latest values"| ON[("Online store<br/>Redis, DynamoDB")]
  PUSH --> ON
  PUSH --> OFF
  OFF -->|"point-in-time join"| TRAIN["Training set"]
  ON -->|"get_online_features, p99 under 10 ms"| SERVE["Model server"]
  REG -.-> TRAIN
  REG -.-> SERVE
```

**How to read it:** feature definitions live in Git and are registered once. Historical values sit in
the offline store and are joined to training labels *as of* each label's timestamp. The latest values are
materialized (or pushed from a stream) into the online store, where the model server reads them in
milliseconds. Both paths use the same definitions.

**Terms in this diagram.**
- **Entity, source, TTL**: an **entity** is the thing features describe, such as a user or product, identified by a
  key. The **source** is the table or stream the values come from. The **TTL** (time to live) is how old a value may
  be before it's considered missing.
- **Registry**: the catalog of all feature definitions, shared by training and serving.
- **BigQuery, Snowflake, Parquet**: two cloud data warehouses, and the columnar file format, all usable as the offline
  store.
- **Push features**: a stream job writes fresh values directly into the online store as events happen.
- **Materialize**: a scheduled job copies the latest value per entity from the offline store to the online store.
- **Point-in-time join**: for each training label, it fetches each feature's value *as it was at that label's
  timestamp*, never a later one. That prevents **leakage** of future information into training.
- **get_online_features, p99 under 10 ms**: the Feast call the model server uses, which should return within 10 ms
  for 99% of requests.

**Core ideas.**
- **Point-in-time correctness.** For a label at time *t*, use the latest feature value with timestamp ≤ *t*
  (and within its TTL). An ordinary join on the current value leaks the future.
- **Entities and TTLs.** Features are keyed by entities (user, merchant). A TTL stops stale values from
  being served as if fresh.
- **Feast** is open source and you run it on your own stores. **Tecton** is a managed platform with
  streaming transformations. Cloud options include SageMaker Feature Store, Vertex AI Feature Store, and
  Databricks Feature Store.
- **Freshness** is a feature property: a 1-hour batch feature and a 30-second streaming feature need
  different pipelines. Monitor feature freshness and null rates in serving.

```python
# features.py (Feast)
from datetime import timedelta
from feast import Entity, FeatureView, Field, FileSource
from feast.types import Float32, Int64

user = Entity(name="user", join_keys=["user_id"])
txn_stats = FeatureView(
    name="user_txn_stats", entities=[user], ttl=timedelta(days=2),
    schema=[Field(name="txn_count_1h", dtype=Int64), Field(name="amount_sum_1h", dtype=Float32)],
    source=FileSource(path="s3://features/user_txn_stats/", timestamp_field="event_ts"))

# training: point-in-time join against labels (entity_df has user_id, event_timestamp, label)
#   store.get_historical_features(entity_df=labels, features=["user_txn_stats:txn_count_1h"]).to_df()
# serving: latest values
#   store.get_online_features(features=["user_txn_stats:txn_count_1h"], entity_rows=[{"user_id": 42}])
```

**Example: the model that was too good offline.** A churn model scored 0.94 AUC offline and 0.71 in
production. The training set had joined each user's *current* `support_tickets_30d`, which included tickets
filed after they churned. A point-in-time join brought offline AUC to 0.78, which matched production, and
the team then improved it honestly.

**Senior / FAANG best practice.** Define each feature once, compute it with the same code for training
and serving, build training sets only with point-in-time joins, attach TTLs and owners, and monitor
online freshness and skew (compare logged serving features with offline recomputation). Log the features
used at prediction time, which is the most reliable source for the next training set.

---

## Lecture 166 — Real-time data preprocessing at scale

**Why it matters.** Fraud, ads, recommendations, and real-time RAG need features computed within
seconds. Doing this correctly means handling out-of-order events, duplicates, failures, and replays,
which is harder than it looks and is where most streaming bugs live.

**In plain words.** Counting cars per minute from reports that arrive late and sometimes twice is
tricky. You count each car in the minute it *passed* (event time), wait a little for stragglers
(the watermark), accept a few latecomers as corrections (allowed lateness), and keep the rest in a separate
"too late" pile.

**Architecture: a stateful stream job with checkpoints.**

```mermaid
flowchart LR
  K["Kafka source<br/>offsets"] --> WM["Assign event time<br/>and watermarks"]
  WM --> DD["Dedupe by event_id<br/>keyed state with TTL"]
  DD --> KEY["keyBy user_id"]
  KEY --> WIN["Window aggregate<br/>count, sum per minute"]
  WIN --> SINK["Exactly-once sink<br/>upsert or 2-phase commit"]
  WIN -->|"too late"| DLQ["Side output<br/>late events topic"]
  ST[("State backend<br/>RocksDB")] -.-> DD
  ST -.-> WIN
  CK["Periodic checkpoint<br/>state + offsets to S3"] -.-> ST
```

**How to read it:** the job reads from Kafka, stamps each event with its event time, drops duplicates,
groups by key, and aggregates into windows held in local state. Checkpoints periodically save both the
state and the Kafka offsets together. After a crash, the job restores both and continues with no loss and no
double counting. Events that are too late go to a side output for inspection.

**Terms in this diagram.**
- **Offsets**: each record's position number in its Kafka partition. Saving offsets records how far the job has read.
- **Event time, watermarks**: **event time** is when the event actually happened, as opposed to when it arrived. A
  **watermark** is the job's running estimate that "all events up to time T have arrived", which lets it close
  windows despite late arrivals.
- **Dedupe by event_id, keyed state with TTL**: each event's unique ID is remembered for a while (the **TTL**, for
  example 1 hour), and repeats are dropped. **Keyed state** is memory kept separately per key.
- **keyBy user_id**: routes all of one user's events to the same worker, so that worker's state is complete.
- **Window aggregate**: totals over a time window, here per minute per user.
- **Exactly-once sink, upsert or 2-phase commit**: the **sink** is where results are written. **Exactly-once** means
  each result takes effect once, even after a crash. Either an **upsert** (insert or overwrite by key, so a repeat
  is harmless) or a **two-phase commit** (results become visible only when the checkpoint completes) achieves it.
- **Side output, late events topic**: a second output stream for events that arrived after their window closed.
- **State backend, RocksDB**: where state lives. **RocksDB** is an embedded on-disk key-value store that lets state
  grow larger than memory.
- **Checkpoint**: a consistent snapshot of all state plus offsets, saved to durable storage such as S3 (Lecture 166).

**Core ideas.**
- **Event time vs processing time.** Aggregate by when it happened. In the exercise, processing-time windows
  disagree with the true event-time counts on 15 of 30 windows.
- **Watermarks** declare "no events older than *T* are expected". A window fires when the watermark passes
  its end. Bounded out-of-orderness (for example 10 s) trades latency for completeness.
- **Allowed lateness** keeps a fired window's state a bit longer, so late events emit updates. The sink must
  handle updates (upsert by window key).
- **Windows.** Tumbling (fixed, non-overlapping), sliding or hopping (overlapping), and session (gap-based,
  per user).
- **Exactly-once** = replayable source + consistent checkpoints + idempotent or transactional sink.
- **Engines.** Apache Flink (the strongest for stateful event-time work), Spark Structured Streaming
  (micro-batch, good if you're already on Spark), Kafka Streams (a library inside your service), and Apache
  Beam on Dataflow.
- **Backpressure.** When sinks slow down, the job slows down its reads and lag grows. Alert on lag, and scale
  by partitions.

**Example: the lateness trade-off.** In the exercise, with 400 events, ~3% delayed 60–150 s, and 4% duplicated:

| Watermark delay | Allowed lateness | Late updates | Dropped to side output | Max windows in state |
|---|---|---|---|---|
| 0 s | 0 s | 0 | 21 | 4 |
| 10 s | 30 s | 2 | 10 | 6 |
| 30 s | 120 s | 11 | 0 | 12 |

More tolerance means fewer lost events but later and more frequent outputs and more state. Choose using the
measured lateness distribution and the business cost of a missed event.

**Senior / FAANG best practice.** Use event time with explicit watermarks, set lateness from the measured
delay distribution, send late data to a side output with a metric and an alert, dedupe on event ids with TTL
state, and make sinks idempotent upserts. Test recovery by killing the job mid-stream and comparing its
output with a batch recomputation, which is exactly what the assessment exercise does.

---

## Lecture 167 — Data quality monitoring for AI systems

**Why it matters.** Bad data doesn't crash pipelines. It quietly trains worse models and serves wrong
predictions. Schema changes, missing partitions, null spikes, unit changes, and duplicate loads are routine,
so you need automated checks that block bad data before it is used.

**In plain words.** A quality inspector at the factory door checks every delivery: is it the right part,
the right amount, on time, and within tolerance? A bad batch is sent back before it reaches the assembly
line.

**Architecture: quality gates in the pipeline.**

```mermaid
flowchart LR
  PROD["Producer team"] -->|"data contract<br/>schema, SLAs, owner"| IN["Incoming partition"]
  IN --> CH{"Checks<br/>schema, volume,<br/>freshness, nulls,<br/>uniqueness, distribution"}
  CH -->|"pass"| PUB["Publish partition<br/>mark ready"]
  CH -->|"fail, blocking"| Q["Quarantine<br/>alert owner"]
  CH -->|"warn"| PUB
  PUB --> TR["Training and features"]
  MET["Check results over time"] --> DASH["Dashboards and anomaly detection"]
  CH --> MET
```

**How to read it:** each new partition is checked against the contract before it's published. Blocking
failures quarantine the data and alert the producer who owns it. Warnings let it through but get
recorded. Downstream jobs read only partitions marked ready, and check results are tracked over time to
spot gradual degradation.

In the diagram, a **data contract** is a written, versioned agreement between the team producing data and the teams
using it. It covers the **schema** (fields and types), **SLAs** (service level agreements, such as "delivered by
06:00 daily"), and an **owner** to contact. An **incoming partition** is one new batch of data, typically one day. The
checks cover **volume** (row count in the expected range), **freshness** (recent enough), **nulls** (missing values),
**uniqueness** (no duplicate keys), and **distribution** (values look like usual). **Quarantine** holds failed data
aside, so nothing downstream reads it. **Anomaly detection** flags check results that differ from their history.

**Core ideas.**

| Check | Example rule | Catches |
|---|---|---|
| Schema | Columns and types match the contract | Renamed or retyped fields |
| Volume | Row count within ±30% of the trailing 7-day median | Empty or partial loads |
| Freshness | Max `event_ts` within 2 hours | Stalled upstream jobs |
| Completeness | `amount` null rate < 0.5% | Broken extraction |
| Uniqueness | `txn_id` unique | Duplicate loads |
| Validity | `0 <= amount < 1e6`, `currency in ISO list` | Unit or encoding changes |
| Distribution | PSI vs reference < 0.2 (Section 17) | Silent shifts |

- **Tools.** Great Expectations, Soda, Deequ (Spark), dbt tests, Pandera or Pydantic for in-code
  validation, and data observability platforms such as Monte Carlo.
- **Data contracts** make producers accountable: a schema, semantics, SLAs, and an owner, with
  breaking changes reviewed like API changes.
- **Write-audit-publish.** Write to a staging branch or table, audit it, and publish atomically (Iceberg
  branches and tags make this easy).

```python
# checks/fraud_features.py: a minimal blocking gate (pandas), run before publish
def check(df, history_counts):
    errs = []
    if set(df.columns) != {"user_id", "event_ts", "txn_count_1h", "amount_sum_1h"}: errs.append("schema")
    med = sorted(history_counts)[len(history_counts) // 2]
    if not 0.7 * med <= len(df) <= 1.3 * med: errs.append(f"volume {len(df)} vs median {med}")
    if df["amount_sum_1h"].isna().mean() > 0.005: errs.append("nulls in amount_sum_1h")
    if df.duplicated(["user_id", "event_ts"]).any(): errs.append("duplicate keys")
    if (df["amount_sum_1h"] < 0).any(): errs.append("negative amounts")
    return errs   # non-empty = quarantine and page the owning team
```

**Example: cents vs dollars.** A payments team switched `amount` from dollars to cents. Schema checks passed
because the type was still a number. The validity check `amount < 1e6` failed on 0.3% of rows, and the
distribution check showed a PSI of 4.1. The partition was quarantined before nightly retraining, which would
otherwise have shipped a fraud model that saw every customer as a big spender.

**Senior / FAANG best practice.** Put contracts on every critical upstream, run blocking checks before
publishing (write-audit-publish), track check results over time, route alerts to the producing team, and
define "ready" explicitly so downstream jobs never read partial data. Treat a data incident like a
production incident, with a postmortem.

---

## Lecture 168 — Lab: build a streaming pipeline with Kafka

**Goal:** run Kafka locally, produce click events with realistic out-of-order and duplicate delivery,
compute per-user 1-minute event-time features with a watermark, write them idempotently to Redis as an
online store, and verify lag, late-data handling, and replay.

**What you're building.**

```mermaid
flowchart LR
  GEN["producer.py<br/>clicks, delays, duplicates"] --> K["Kafka topic clicks<br/>6 partitions, key user_id"]
  K --> CON["features.py consumer group<br/>dedupe, windows, watermark"]
  CON --> R[("Redis<br/>user feature hashes")]
  CON --> LATE["Kafka topic clicks-late"]
  R --> API["Read features<br/>redis-cli HGETALL"]
  MON["kafka-consumer-groups<br/>lag"] -.-> CON
```

**In plain words.** You build a miniature version of a real-time feature pipeline: events go in one side,
fresh per-user features come out in Redis, and you can watch lag, late events, and recovery.

**How to read the diagram:** `producer.py` generates click events, including deliberate delays and duplicates, into
the `clicks` topic, which has 6 partitions keyed by `user_id`. `features.py` is a consumer group that drops
duplicates, counts clicks per user per time window, and uses a watermark to decide when a window is complete. It
writes each user's features into a Redis **hash** (a small key-to-fields map per user) and sends too-late events to
the `clicks-late` topic. You read features with `redis-cli HGETALL`, which prints every field of a hash. The
`kafka-consumer-groups` tool shows **lag**: how many records each partition has that the group hasn't read yet.

### Step 1 — Start Kafka (KRaft) and Redis

```yaml
# docker-compose.yml
services:
  kafka:
    image: apache/kafka:3.9.0
    ports: ["9092:9092"]
    environment:
      KAFKA_NODE_ID: 1
      KAFKA_PROCESS_ROLES: broker,controller
      KAFKA_LISTENERS: PLAINTEXT://:9092,CONTROLLER://:9093
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://localhost:9092
      KAFKA_CONTROLLER_LISTENER_NAMES: CONTROLLER
      KAFKA_CONTROLLER_QUORUM_VOTERS: 1@localhost:9093
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
      KAFKA_NUM_PARTITIONS: 6
  redis:
    image: redis:7.4
    ports: ["6379:6379"]
```

```bash
docker compose up -d
docker compose exec kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 \
  --create --topic clicks --partitions 6 --replication-factor 1
docker compose exec kafka /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 \
  --create --topic clicks-late --partitions 1 --replication-factor 1
pip install confluent-kafka redis
```

(Single broker, so RF 1. In production use RF 3 with `min.insync.replicas=2`.)

### Step 2 — Produce events with delays and duplicates

```python
# producer.py
import json, random, time, uuid
from confluent_kafka import Producer
p = Producer({"bootstrap.servers": "localhost:9092", "acks": "all", "enable.idempotence": True,
              "linger.ms": 10, "compression.type": "zstd"})
rng, users = random.Random(1), [f"u{i}" for i in range(50)]
for i in range(20_000):
    now = time.time()
    r = rng.random()
    delay = rng.uniform(0, 3) if r < 0.9 else rng.uniform(5, 25) if r < 0.98 else rng.uniform(90, 180)
    e = {"event_id": str(uuid.uuid4()), "user_id": rng.choice(users), "ts": now - delay,
         "page": rng.choice(["home", "search", "item", "cart"])}
    p.produce("clicks", key=e["user_id"], value=json.dumps(e))
    if rng.random() < 0.03:                                    # at-least-once upstream: resend
        p.produce("clicks", key=e["user_id"], value=json.dumps(e))
    p.poll(0)
    time.sleep(0.005)
p.flush()
```

### Step 3 — The windowed feature consumer

```python
# features.py: event-time 1-minute windows, 10 s watermark, 30 s lateness, idempotent Redis upserts
import json, time, redis
from confluent_kafka import Consumer, Producer
W, OOO, LATE = 60, 10, 30
c = Consumer({"bootstrap.servers": "localhost:9092", "group.id": "features", "enable.auto.commit": False,
              "auto.offset.reset": "earliest"})
c.subscribe(["clicks"])
late_out = Producer({"bootstrap.servers": "localhost:9092"})
r = redis.Redis()
state, max_ts, n = {}, 0.0, 0
while True:
    msg = c.poll(1.0)
    if msg is None or msg.error():
        continue
    e = json.loads(msg.value())
    if not r.set(f"seen:{e['event_id']}", 1, nx=True, ex=3600):   # dedupe, TTL 1 h
        c.commit(msg, asynchronous=True); continue
    start = int(e["ts"] // W * W)
    if start + W + LATE <= max_ts - OOO:
        late_out.produce("clicks-late", value=msg.value()); c.commit(msg, asynchronous=True); continue
    key = (e["user_id"], start)
    state[key] = state.get(key, 0) + 1
    max_ts = max(max_ts, e["ts"])
    wm = max_ts - OOO
    for (u, s), cnt in list(state.items()):
        if s + W <= wm:                                          # window closed: upsert, idempotent
            r.hset(f"feat:{u}", mapping={"clicks_1m": cnt, "window_start": s})
            r.expire(f"feat:{u}", 900)
        if s + W + LATE <= wm:
            del state[(u, s)]
    n += 1
    if n % 500 == 0:
        c.commit(asynchronous=False)                             # commit after state is written
        print(f"processed={n} watermark_lag_s={time.time() - wm:.1f} open_windows={len(state)}")
```

Run it in one terminal, then the producer in another:

```bash
python features.py
python producer.py
```

This consumer keeps window state in memory, so a crash loses open windows (the Redis upserts make the
replay safe). A production job uses Flink or Kafka Streams state with checkpoints. Then compare with the
reference logic:

```bash
python3 exercises/s24_stream_windows.py        # the same semantics, verified against a batch recompute
```

### Step 4 — Observe lag, late data, and replay

```bash
# consumer lag per partition
docker compose exec kafka /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 \
  --describe --group features
# late events
docker compose exec kafka /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 \
  --topic clicks-late --from-beginning --timeout-ms 5000 | wc -l
# features
docker compose exec redis redis-cli HGETALL feat:u7
# replay: stop the consumer, reset offsets, restart; results must be identical (dedupe + upsert)
docker compose exec kafka /opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server localhost:9092 \
  --group features --reset-offsets --to-earliest --topic clicks --execute
```

**Expected results:**
- Lag stays near zero while the consumer keeps up. Stop the consumer for 60 s and lag grows to roughly
  12,000 messages (about 200 per second), then drains within seconds after restart.
- About 2% of events (those delayed 90–180 s) land in `clicks-late`, and about 3% are dropped as duplicates.
- `HGETALL feat:u7` shows `clicks_1m` and a `window_start` about 70–80 s behind real time (one window plus
  the 10 s watermark).
- Replaying from the earliest offset produces the same Redis values: duplicates are skipped and upserts
  overwrite with the same counts. To replay as if fresh, first clear the `seen:*` keys.

---

## Assessment — Aggregate streaming events into time windows

**Scenario:** a click stream of 400 events over 10 minutes from 3 users arrives out of order: 88%
within 4 s, 9% delayed 5–30 s, and 3% delayed 60–150 s. About 4% of events are delivered twice. Product
needs per-user 1-minute counts and sums that match a batch recomputation, as early as possible.

**Task:** implement event-time tumbling windows with a watermark (10 s out-of-orderness), allowed lateness
(30 s), deduplication, and a side output for events that are too late. Show that the result equals the
batch ground truth on accepted events, that every event is accounted for, and that state stays bounded.
Then compare processing-time windows, sliding windows, and session windows.

```bash
python3 exercises/s24_stream_windows.py
python3 exercises/s24_stream_windows.py --ooo 30 --lateness 120    # the trade-off
```

**Expected output:**

| Result | Value |
|---|---|
| Received / unique / duplicates | 417 / 400 / 17 |
| Final window emissions | 30 (3 users × 10 minutes) |
| Late updates (within lateness) | 2 |
| Side output (too late) | 10 |
| Max windows in state | 6 (bounded) |
| Streaming equals batch on accepted events | Yes |
| Processing-time windows wrong | 15 of 30 windows |
| Sliding 60 s / 30 s windows | 60, each event in 2 windows |
| Clickstream sessions (gap 30 s) | u1 = 3, u2 = 5, u3 = 2, matching the generated bursts |

**What a strong answer explains:** event time makes results correct and replayable. The watermark trades
latency for completeness, and allowed lateness trades state and update traffic for fewer dropped events
(with 30 s / 120 s nothing is dropped, but state doubles and updates rise to 11). Sinks must be upserts keyed
by window, because late updates rewrite results. Duplicates are expected with at-least-once delivery, so
dedupe by event id with TTL state. Too-late events are counted and kept, never silently discarded.

---

## FAANG deep-dive notes

**How big tech does it.** Large companies run a central event backbone (Kafka or an internal equivalent)
with schema registries and data contracts, a lakehouse of open table formats with time travel, and
orchestrators that schedule thousands of idempotent, partitioned jobs. Real-time features are computed
by Flink-style stateful jobs on event time and pushed to online stores, and the same definitions feed
point-in-time-correct training sets. Features used at serving time are logged and become the next training
data, which removes skew. Data quality gates block publication, and data incidents get postmortems.

**Staff review questions.**
- Can you rebuild the training set for any past model exactly? How?
- Which features are streaming vs batch, and what freshness does each actually need?
- What happens to late events, duplicates, and a 2-hour upstream outage?
- How do you prove the online and offline feature values match?
- Which checks block publication, and who gets paged when they fail?

**Interview question.** "Design the real-time feature pipeline for a payments fraud model that scores each
transaction within 100 ms."

**Typical system-design prompt:** *Design a pipeline that computes per-card features (transaction count
and amount over 1 minute, 1 hour, and 24 hours, distinct merchants over 24 hours) for 20,000 transactions
per second at peak, serves them at p99 < 10 ms, and produces leakage-free training sets.*

**1. Clarify first:** How fresh must each feature be (1-minute features need streaming, 24-hour ones may not)?
What is the late-arrival distribution? Is the score computed before or after the transaction is written?
Which regions and what retention apply? What are the accuracy needs for distinct counts (exact or
approximate)?

**2. Back-of-envelope sizing:**
- 20,000 events/s × ~500 bytes = 10 MB/s in. With RF 3, that's ~30 MB/s of broker writes. Retained for a
  year, raw events are ~315 TB (~950 TB with RF 3), so keep 7 days on brokers and tier the rest to object storage.
- Partitions: at ~5,000 events/s per consumer, that's ≥ 4 consumers. Use 48 partitions for headroom and
  future growth.
- Online store: 50 M cards × 6 features × ~16 bytes ≈ 5 GB, plus overhead, so a small Redis cluster with
  replicas. Reads are 20,000/s at p99 < 10 ms, easy for Redis.
- Stream state: 24-hour windows for 50 M cards. Use sliding windows with pre-aggregated buckets (24 × 1-hour
  buckets per card) and HyperLogLog for distinct merchants, roughly tens of GB in RocksDB, checkpointed.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Feature path | Batch materialization | Streaming job | Streaming only where freshness changes model value |
| Time semantics | Processing time | Event time + watermark | Event time for anything used in training |
| Delivery | At-least-once + idempotent sink | Transactional exactly-once | Idempotent upserts first; transactions when sinks can't be idempotent |
| Distinct counts | Exact sets | HyperLogLog | HLL at scale; ~1% error is fine for features |
| Training data | Recompute features offline | Log served features | Log served features to remove skew; recompute for new features |
| Late events | Drop silently | Side output + lateness | Never silent; size lateness from the measured delay distribution |

**4. Follow-up questions with crisp answers:**
- *How do you prevent leakage?* Point-in-time joins on event timestamps, with features computed strictly
  from events before the prediction time, ideally by logging the served features.
- *How do you backfill a new streaming feature?* Run the same logic in batch over historical events (or
  replay Kafka or tiered storage), with the same windowing code, then validate against a short period of live
  streaming output.
- *The stream job is down for 2 hours. What do serving features look like?* Stale. TTLs mark them so,
  the model falls back to batch features or a rule, and on recovery the job catches up from offsets.
  Alert on feature freshness, not just job health.
- *Why not compute features at request time from the database?* Aggregating 24 hours of history per request
  costs too much latency and load. Precompute incrementally.

**Debug this (common onsite question):** "The fraud model's online precision dropped from 82% to 64%
overnight, and offline evaluation on yesterday's data still shows 81%."
1. Compare logged online features with offline recomputation for the same transactions. `txn_count_1h`
   online is ~40% lower.
2. Check the stream job: consumer lag on 8 of 48 partitions is 90 minutes. A deploy changed the key to
   `merchant_id`, which created hot partitions.
3. Features served from the lagging partitions were stale, and their TTL (24 hours) was too long to flag
   them.
4. Fix: revert the key to `card_id`, add a feature-freshness SLO (age < 2 minutes) with fallback, shorten
   TTLs on fast features, and add an online-offline skew check to alerting.

The lesson: models fail through their data. Monitor feature freshness and online-offline skew as
first-class SLOs, not just job uptime.

**5. What separates senior from staff answers:** a senior engineer builds a correct Kafka plus Flink plus
Redis pipeline with event time and idempotent sinks. A staff engineer decides which features need streaming
at all, guarantees reproducibility (immutable raw data, time travel, lineage), eliminates skew by logging
served features, defines freshness and quality SLOs with owners, and plans backfills, replays, and
regional failure up front.

**Red flags:**
- Processing-time windows for features used in training.
- Appending on retry, or no idempotency.
- Training sets built from current feature values (no point-in-time join).
- Late events dropped silently.
- Heavy compute inside Airflow workers.
- No consumer lag or freshness alerting.

---

## Quiz

<details><summary>1. Why is ELT usually preferred over ETL for ML?</summary>
Raw data is kept, so any transformation can be recomputed or changed later (backfills, new features,
bug fixes) without re-extracting from sources. Warehouses and lakehouses make transformation inside the
store cheap and scalable.
</details>

<details><summary>2. What makes a batch job idempotent?</summary>
It processes a defined input partition, such as a logical date, and overwrites its output partition, so
running it twice gives the same result. It never appends on retry or depends on `now()`.
</details>

<details><summary>3. Why should Airflow tasks run heavy work in pods or external systems?</summary>
Airflow is a control plane. Heavy work on shared workers starves other DAGs and the scheduler. Pods give
isolation, their own resources (including GPUs), and reproducible images.
</details>

<details><summary>4. What Kafka settings make a write survive one broker failure?</summary>
Replication factor 3, `min.insync.replicas=2`, and producer `acks=all`, ideally with the idempotent
producer enabled.
</details>

<details><summary>5. What does a point-in-time join do, and why does it matter?</summary>
For each training label at time t, it uses the latest feature value with timestamp ≤ t (within the TTL).
It prevents leakage of future information, which otherwise inflates offline metrics.
</details>

<details><summary>6. What is a watermark in stream processing?</summary>
A statement that no events older than a given event time are expected. Windows fire when the watermark
passes their end. The out-of-orderness delay trades latency for completeness.
</details>

<details><summary>7. How do you get exactly-once results with an at-least-once source?</summary>
Use a replayable source, checkpoints that save state and offsets consistently, dedupe by event id, and an
idempotent (upsert) or transactional sink.
</details>

<details><summary>8. Name five data quality checks you'd block a training partition on.</summary>
Schema matches the contract, volume within range of history, freshness, null-rate limits, key uniqueness,
value validity ranges, and distribution shift (PSI) against a reference.
</details>

## Failure modes
- Appending on retry, which duplicates whole days of training data.
- Training on current feature values instead of point-in-time values, which leaks the future.
- Hot partitions from skewed keys, with lag growing on a few partitions only.
- `acks=1` or `min.insync.replicas=1`, losing data on broker failure.
- Processing-time windows that change when replayed.
- Late events dropped silently, and no side output metric.
- Unbounded dedupe or window state, which grows until the job runs out of memory.
- Heavy compute inside Airflow workers, starving the scheduler.
- Data quality checks that only warn, so bad partitions still reach training.
- Stale online features served without TTLs or freshness alerts.

## Checklist
- [ ] You can explain ETL vs ELT and the bronze, silver, and gold layers
- [ ] Your batch jobs overwrite partitions keyed by the logical date
- [ ] You can write an Airflow DAG that runs work in pods, with pools and retries
- [ ] You know Kafka's durability settings, ordering guarantees, and how to read consumer lag
- [ ] You can define a feature in Feast and build a point-in-time-correct training set
- [ ] You ran `s24_stream_windows.py` and can explain watermarks, lateness, and dedupe
- [ ] You have blocking data quality checks with owners and contracts
- [ ] You built the Kafka to Redis feature pipeline and tested lag, late data, and replay
