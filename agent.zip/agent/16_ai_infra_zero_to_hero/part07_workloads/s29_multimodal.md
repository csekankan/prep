# Section 29 — Multimodal AI Infrastructure

> Lectures 197–203 • Assessment: quiz
> **After this section you can:** explain how multimodal models combine encoders and language models,
> build text-image data pipelines (filtering, dedupe, shards), train and serve CLIP-style models (including
> the large-batch contrastive loss), run speech-to-text and voice pipelines with real-time-factor and latency
> budgets, design video and text search with timestamps, handle the serving challenges of mixed inputs
> (pixels to tokens, encoder caching, payloads), and deploy CLIP for text-to-image search.
>
> Go deeper: [13 / Lab 61 — Vector DB topologies](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab61_vector_db_topologies.md),
> [Lab 62 — Milvus multi-node](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab62_milvus_multinode.md),
> [Lab 41 — Triton multi-framework](../../13_sovereign_ai_infra_course/04_serving_inference/lab41_triton_multi_framework.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 197 | What is multimodal AI? | Modality encoders map pixels, audio, and text into a shared space, or into tokens an LLM can read |
| 198 | Handling text + image pipelines | Filter, dedupe, and caption pairs, store them in shards, and keep preprocessing identical everywhere |
| 199 | Training and serving CLIP models | The contrastive loss wants huge batches. Serving precomputes image vectors and embeds text at query time |
| 200 | Infrastructure for speech + text models | 16 kHz audio, VAD chunking, real-time factor, and a voice turn budget under ~1 s |
| 201 | Deploying video + text search systems | Sample frames, transcribe, OCR, and index segments with timestamps, then search hybrid |
| 202 | Challenges of multimodal model serving | Image resolution sets token count. Cache encoder outputs and bound pixels and payloads |
| 203 | Lab: deploy CLIP for image search | OpenCLIP + FAISS + FastAPI over ~13k images, with precision@10 and latency measured |

```mermaid
flowchart LR
  IMG["Images"] --> VE["Vision encoder<br/>ViT"]
  AUD["Audio"] --> AE["Audio encoder<br/>Whisper-style"]
  TXT["Text"] --> TE["Text encoder or tokenizer"]
  VE --> SHARED["Shared embedding space<br/>CLIP-style search"]
  TE --> SHARED
  VE --> PROJ["Projector<br/>vision features to tokens"]
  AE --> PROJ
  PROJ --> LLM["Language model<br/>VLM or speech LLM"]
  TE --> LLM
  SHARED --> SEARCH["Search, dedupe, tagging"]
  LLM --> GENR["Answers, captions,<br/>transcripts, actions"]
```

**How to read it:** each modality has its own encoder. In one pattern (CLIP), image and text encoders map
into a shared vector space, which powers search and tagging. In the other pattern (vision-language and speech
LLMs), encoder outputs are projected into "soft tokens" and fed to a language model alongside text, which
powers question answering, captioning, and agents. Infrastructure must serve both encoders and the LLM.

**Terms in this diagram.**
- **Modality**: a type of data, such as text, images, audio, or video.
- **Vision encoder, ViT**: a model that turns an image into vectors. A **ViT** (Vision Transformer) cuts the image into
  small square patches and treats each patch like a token.
- **Audio encoder, Whisper-style**: a model that turns audio into vectors, like the encoder half of OpenAI's
  **Whisper** speech recognition model.
- **Shared embedding space, CLIP-style**: image and text vectors are trained so that a photo of a dog and the words "a
  dog" land close together. **CLIP** (Contrastive Language–Image Pretraining) is OpenAI's model that introduced this
  (Lecture 199).
- **Projector**: a small network that converts encoder outputs into vectors the language model accepts as if they
  were word tokens, called **soft tokens**.
- **VLM, speech LLM**: a **vision-language model** reads images plus text. A **speech LLM** reads audio plus text.
- **Tagging**: automatically attaching labels such as "beach" or "car" to media.

---

## Lecture 197 — What is multimodal AI?

**Why it matters.** Products increasingly take photos, screenshots, voice, and video as input. Each
modality brings its own data formats, preprocessing, encoder compute, and failure modes, and the combined
system is only as fast and reliable as its slowest piece.

**In plain words.** A multimodal model is a team with an eye, an ear, and a voice that share one
notebook. The eye and ear translate what they sense into notes the brain can read, and the brain writes the
answer.

**Architecture: the main multimodal model patterns.**

```mermaid
flowchart LR
  subgraph DUAL["Dual encoder (CLIP, SigLIP)"]
    I1["Image"] --> IE["Image encoder"] --> V1["vector"]
    T1["Text"] --> TEN["Text encoder"] --> V2["vector"]
    V1 --> SIM["cosine similarity"]
    V2 --> SIM
  end
  subgraph FUSE["Encoder + LLM (LLaVA, Qwen-VL)"]
    I2["Image"] --> VIT["ViT"] --> PJ["Projector"]
    PJ --> TOK["~576+ image tokens"]
    Q["Question tokens"] --> DEC["LLM decoder"]
    TOK --> DEC
    DEC --> ANS["Answer"]
  end
```

**How to read it:** dual encoders embed each modality separately and compare vectors. They're cheap at query
time because one side (for example images) is precomputed. Fused models turn an image into hundreds or
thousands of tokens that the LLM processes like text. They're more capable, but every image costs LLM
prefill compute and KV memory.

In the diagram, **SigLIP** is Google's improved CLIP-style model, which uses a sigmoid loss. **Cosine similarity**
measures the angle between two vectors: 1 means the same direction (same meaning), and 0 means unrelated. **LLaVA**
and **Qwen-VL** are open vision-language models. **~576+ image tokens** is the number of soft tokens one image becomes
(a 336-pixel image cut into 24 × 24 patches gives 576), and high-resolution modes use more. **Prefill** is the LLM's
pass over all input tokens, and the **KV memory** is the cache it keeps for them (Section 25).

**Core ideas.**
- **Dual encoders** (CLIP, SigLIP, CLAP for audio) power retrieval, zero-shot classification, dedupe, and
  moderation.
- **Vision-language models** (LLaVA, Qwen2-VL, Llama 3.2 Vision, GPT-4o-class) answer questions about images.
  LLaVA-1.5 turns a 336 px image into 576 tokens (a 24 × 24 patch grid with ViT-L/14). High-resolution tiling
  multiplies that.
- **Speech models.** ASR (Whisper), TTS, and speech-native LLMs. **Video models** combine frame sampling with
  vision encoders, often plus audio transcripts.
- **Infra consequences.** Heterogeneous compute (encoders + decoder), large inputs (MBs per image or video),
  preprocessing (decode, resize, resample) that is often CPU-bound, and new safety surfaces (prompt injection
  in images, harmful media).

**Example: the screenshot that cost a page of text.** A support assistant let users attach screenshots. A
1440p screenshot tiled at high resolution became ~2,300 image tokens, more than the whole text conversation.
TTFT doubled for image requests, and KV memory per request tripled. The team capped images at 1024 px on the
long side (~1,000 tokens), which kept OCR quality on the eval set, and moved image encoding to a separate GPU pool.

**Senior / FAANG best practice.** Pick the pattern by product need: dual encoders for search and tagging,
fused models for reasoning over media. Convert every modality into a token or compute budget, measure each
stage separately (preprocess, encode, prefill, decode), and treat media inputs as untrusted.

---

## Lecture 198 — Handling text + image pipelines

**Why it matters.** Multimodal models are trained on billions of image-text pairs, and their quality
depends heavily on filtering. In production, mismatched preprocessing between training and serving (resize,
crop, color order, normalization) silently degrades results, just as tokenizer drift does for text.

**In plain words.** Building a picture dictionary means collecting pictures with captions, throwing away
the wrong or junk pairs, removing duplicates, and making sure everyone who uses the dictionary crops and
colors pictures the same way.

**Architecture: an image-text data pipeline.**

```mermaid
flowchart LR
  SRC["Sources<br/>web alt-text, catalogs,<br/>licensed sets"] --> DL["Download<br/>img2dataset, parallel"]
  DL --> F1["Filters<br/>size, aspect, NSFW,<br/>language, CLIP score"]
  F1 --> DD["Dedupe<br/>perceptual hash,<br/>embedding near-dup"]
  DD --> CAP["Recaption<br/>VLM synthetic captions,<br/>optional"]
  CAP --> SH[("WebDataset shards<br/>jpg + txt + json")]
  SH --> TRAIN["Training loaders"]
  PREP["One preprocessing spec<br/>resize, crop, mean/std"] -.-> TRAIN
  PREP -.-> SERVE["Serving"]
```

**How to read it:** pairs are downloaded in parallel, then filtered by quality (size, safety, language, and
image-text similarity), deduplicated, and optionally recaptioned by a model. They're written as shards with the
image, caption, and metadata together. A single preprocessing specification is shared by training and serving.

**Terms in this diagram.**
- **Web alt-text, catalogs, licensed sets**: **alt-text** is the description web pages attach to images for
  accessibility, a free source of captions. **Catalogs** are product images with descriptions. **Licensed sets** are
  datasets bought with usage rights.
- **img2dataset**: an open-source tool that downloads and resizes millions of images in parallel from a list of URLs.
- **Size, aspect, NSFW, language, CLIP score**: filters that drop images that are too small or oddly shaped
  (**aspect** ratio), unsafe content (**NSFW**, "not safe for work"), captions in unwanted languages, and pairs whose
  **CLIP score** (image-text similarity) shows the caption doesn't match the picture.
- **Perceptual hash, embedding near-dup**: a **perceptual hash** is a short fingerprint that stays the same when an
  image is resized or re-compressed. Comparing embeddings also catches near-duplicates that look slightly different.
- **Recaption, VLM synthetic captions**: a vision-language model writes new, more detailed captions to replace noisy
  web text.
- **WebDataset shards, jpg + txt + json**: `.tar` files where each sample's image, caption, and metadata are stored
  side by side under the same name (Section 27).
- **Resize, crop, mean/std**: the exact image preparation: resize, center **crop**, and normalize each color channel
  with a fixed **mean** and **standard deviation**. Any mismatch between training and serving silently hurts accuracy.

**Core ideas.**
- **Scale.** LAION-5B has ~5.85 B pairs, and many models train on hundreds of millions to billions. The tool
  `img2dataset` downloads and resizes at thousands of images per second per node.
- **Filtering.** A CLIP-similarity threshold between image and caption removes mismatched pairs. Safety, PII
  (faces, documents), and licensing filters are legal requirements, not options. Track provenance (Lab 66 in course 13).
- **Dedupe.** Perceptual hashes (pHash) for exact and near-exact copies, and embedding similarity for semantic
  duplicates. This also helps with test-set contamination.
- **Synthetic captions.** Recaptioning with a VLM improves detail, and is now common.
- **Preprocessing is part of the model.** Resize mode, crop, RGB vs BGR, and normalization mean/std (CLIP's
  values differ from ImageNet's) must match. Ship the processor config with the model, as you ship a tokenizer.

```bash
pip install img2dataset
img2dataset --url_list pairs.parquet --input_format parquet --url_col url --caption_col caption \
  --output_format webdataset --output_folder shards/ --image_size 256 --resize_mode keep_ratio \
  --processes_count 16 --thread_count 64 --enable_wandb False
```

**Example: the BGR bug.** An image-moderation service moved preprocessing from PIL (RGB) to OpenCV (BGR) for
speed. No error was raised. Recall on violent content dropped from 91% to 78%, because colors were
swapped. A golden-image test, which embeds 50 fixed images and requires cosine similarity ≥ 0.999 to the reference
embeddings, now runs in CI for every preprocessing change.

**Senior / FAANG best practice.** Filter and dedupe aggressively with recorded provenance and licenses,
store pairs in shards with metadata, ship a single versioned preprocessing spec with the model, and protect it
with golden-input embedding tests, as you would a tokenizer.

---

## Lecture 199 — Training and serving CLIP models

**Why it matters.** CLIP-style models are the backbone of image search, zero-shot classification, content
moderation, and the vision encoders inside many VLMs. Training them has an unusual infrastructure need
(very large global batches for the contrastive loss), and serving them well depends on precomputing the
expensive side.

**In plain words.** CLIP learns by matching games: in a pile of photos and captions, find which caption
belongs to which photo. The bigger the pile, the harder and more useful the game, so training wants huge piles
(batches) spread across many GPUs.

**Architecture: the distributed contrastive loss.**

```mermaid
flowchart LR
  subgraph G1["GPU 1 (local batch b)"]
    I1["images"] --> IE1["image encoder"] --> ZI1["b image vectors"]
    T1["captions"] --> TE1["text encoder"] --> ZT1["b text vectors"]
  end
  subgraph GN["GPU N"]
    IN["images"] --> IEN["image encoder"] --> ZIN["b image vectors"]
    TN["captions"] --> TEN["text encoder"] --> ZTN["b text vectors"]
  end
  ZT1 --> AG["all-gather text and image vectors<br/>global batch B = N x b"]
  ZTN --> AG
  ZI1 --> AG
  ZIN --> AG
  AG --> LOSS["Local b x B similarity block<br/>InfoNCE: match the diagonal"]
```

**How to read it:** each GPU encodes its local batch, then all GPUs all-gather the embeddings, so every
image is contrasted against every caption in the global batch. Each GPU computes only its local rows of the
similarity matrix (b × B instead of B × B), which keeps memory manageable while the loss still sees all
negatives.

In the diagram, **b** is the batch on one GPU and **B = N × b** is the **global batch** across N GPUs. **All-gather**
gives every GPU a copy of every GPU's vectors (Section 8). The **similarity block** is a table of scores: each row
is one of this GPU's images, and each column is one caption from the whole global batch. **InfoNCE** is the
contrastive loss. It treats each row as a classification problem whose right answer is the image's own caption, so
the correct pairs lie on the **diagonal** and should score highest. All other captions are **negatives**, and more
negatives (a bigger global batch) teach finer distinctions, which is why CLIP training uses batches of tens of
thousands.

**Core ideas.**
- **Scale references.** OpenAI CLIP used 400 M pairs with a 32,768 batch. Zero-shot ImageNet: ViT-B/32 63.2%,
  ViT-L/14 75.3%. OpenCLIP ViT-H/14 on LAION-2B reached 78.0%.
- **Memory tricks.** Local-loss computation (rows for local samples only), gradient checkpointing, mixed
  precision, and gradient caching to simulate bigger batches.
- **SigLIP** replaces softmax over the batch with a pairwise sigmoid loss. It needs less communication, works well
  at smaller batches, and is popular as the vision tower in VLMs.
- **Serving.**
  - Image embeddings are precomputed offline (the costly ViT pass, ~100s–1,000s images/s per GPU).
  - Only the text tower runs per query (a few ms).
  - Vectors are normalized and indexed (Section 25).
  - Zero-shot classification encodes the class prompts once ("a photo of a {label}").
- **Fine-tuning.** Domain fine-tunes (products, medical) on in-domain pairs often add large gains, and
  LoRA works for CLIP towers too.

```python
import open_clip, torch
model, _, preprocess = open_clip.create_model_and_transforms("ViT-B-32", pretrained="laion2b_s34b_b79k")
tok = open_clip.get_tokenizer("ViT-B-32")
with torch.no_grad():
    t = model.encode_text(tok(["a photo of a dog", "a photo of a cat"]))
    t = t / t.norm(dim=-1, keepdim=True)                    # cosine via dot product on normalized vectors
```

**Example: the cheap query path.** A marketplace with 400 M product photos ran the image tower once per
photo (~3 days on 32 GPUs for the backfill, plus ~1 GPU for new uploads). Queries ran only the text tower,
at ~4 ms on a shared GPU with batching. Search cost per query was dominated by the vector index, not the
model, and a domain fine-tune on 20 M product-title pairs raised click-through on search by 11%.

**Senior / FAANG best practice.** For training, use local-loss all-gather, large global batches (or SigLIP), and
filtered, deduped data. For serving, precompute the expensive tower, version vectors with the model, fine-tune
on in-domain pairs, and evaluate retrieval on labeled queries before switching models.

---

## Lecture 200 — Infrastructure for speech + text models

**Why it matters.** Voice interfaces, call-center analytics, meeting transcription, and voice agents
depend on speech models. Their infrastructure is shaped by audio formats, chunking, streaming, and tight
conversational latency budgets that text systems don't have.

**In plain words.** A live interpreter must listen, understand, think of a reply, and speak, all within
about a second, or the conversation feels broken. Transcribing a recorded lecture can take its time. The
two need very different setups.

**Architecture: a voice agent turn.**

```mermaid
flowchart LR
  MIC["User audio<br/>WebRTC, 20 ms frames"] --> VAD["VAD + endpointing<br/>detect end of speech"]
  VAD --> ASR["Streaming ASR<br/>partial + final text"]
  ASR --> LLM["LLM<br/>stream tokens"]
  LLM --> TTS["Streaming TTS<br/>first audio chunk"]
  TTS --> SPK["User hears reply"]
  BUDGET["Turn budget ~800 ms:<br/>endpoint 200, ASR 100,<br/>LLM TTFT 300, TTS 150"] -.-> LLM
  subgraph BATCH["Batch transcription"]
    FILES["Recorded audio"] --> RS["Resample 16 kHz mono"]
    RS --> CH["VAD chunks under 30 s"]
    CH --> WH["Whisper batched<br/>GPU, faster-whisper"]
    WH --> DIA["Diarization + timestamps"]
  end
```

**How to read it:** in the live path, audio streams in small frames, voice activity detection decides when
the user has finished, streaming ASR produces text, the LLM streams a reply, and streaming TTS starts speaking
before the whole reply exists. Each stage gets a slice of a ~1 s turn budget. The batch path resamples
recordings, chunks them, transcribes in large GPU batches, and adds speaker labels and timestamps.

**Terms in this diagram.**
- **WebRTC, 20 ms frames**: **WebRTC** is the browser standard for real-time audio and video. Audio arrives in tiny
  20-millisecond pieces.
- **VAD + endpointing**: **VAD** (voice activity detection) tells speech from silence. **Endpointing** decides the
  user has finished their turn, typically after a few hundred milliseconds of silence.
- **Streaming ASR, partial + final**: **ASR** (automatic speech recognition) turns speech into text. Streaming ASR emits
  **partial** guesses while the user talks, then a **final** transcript.
- **Streaming TTS**: **TTS** (text to speech) starts producing audio from the first words of the reply, without
  waiting for the whole text.
- **Turn budget ~800 ms**: the target delay from the user stopping to hearing a reply, split across stages: 200 ms
  endpointing, 100 ms ASR, 300 ms LLM time to first token (TTFT), and 150 ms TTS. Around a second still feels natural.
- **Resample 16 kHz mono**: convert recordings to 16,000 samples per second and a single channel, the input format
  Whisper expects.
- **VAD chunks under 30 s**: Whisper processes 30-second windows, so recordings are cut at silences into shorter
  pieces.
- **faster-whisper**: an optimized reimplementation of Whisper on the CTranslate2 engine, several times faster.
- **Diarization**: labeling *who* spoke when ("speaker 1", "speaker 2").

**Core ideas.**
- **Audio math.** 16 kHz mono 16-bit PCM = 32 KB/s ≈ 115 MB per hour. Compressed (Opus), it's ~10–30× smaller.
- **Whisper** works on 30 s windows (large-v3 is ~1.55 B params, and the turbo variant is ~809 M). Optimized runtimes
  (faster-whisper with CTranslate2, or TensorRT-LLM) are several times faster than the reference, and INT8 helps on CPU.
- **Real-time factor (RTF)** = processing time ÷ audio duration. Batch GPU transcription reaches RTF ≪ 0.01
  (100+ hours of audio per GPU-hour). Streaming needs consistently low latency, not just a low average.
- **Voice agents.** Endpointing (how long silence lasts before "done") is the hidden latency knob. Stream every
  stage, colocate ASR, LLM, and TTS in one region, and use WebRTC for transport.
- **Diarization** (who spoke when, for example pyannote), word timestamps, and PII redaction in transcripts
  (Section 18) are usually required in enterprise use.

```python
from faster_whisper import WhisperModel
m = WhisperModel("large-v3", device="cuda", compute_type="float16")
segments, info = m.transcribe("call.wav", vad_filter=True, beam_size=1)
for s in segments:
    print(f"[{s.start:6.1f}-{s.end:6.1f}] {s.text}")
```

**Example: shaving the voice turn.** A voice agent felt slow at ~1.9 s per turn. Measurements showed
endpointing waited 700 ms of silence, ASR ran in another region (+120 ms), the LLM's first token took 600 ms on
a large model, and TTS waited for the full sentence. Fixes: 300 ms endpointing with a semantic end-of-turn
check, colocated services, a smaller fine-tuned model for most turns, and TTS starting on the first clause.
The turn dropped to ~750 ms.

**Senior / FAANG best practice.** Separate streaming and batch speech infrastructure. Give each stage of a voice
turn a latency budget and measure it, stream everything, colocate the pipeline, tune endpointing, and track
word error rate per language, accent, and channel (phone vs app), with PII redaction in transcripts.

---

## Lecture 201 — Deploying video + text search systems

**Why it matters.** "Find the moment where the presenter shows the revenue chart" or "every clip with a red
car at night" requires indexing what's seen, said, and written in video, and returning timestamps. This
combines CV, speech, OCR, and vector search at large data volumes.

**In plain words.** Indexing a video library is writing a detailed table of contents for every film:
what appears on screen, what people say, and what text is shown, with the minute and second of each, so a
search jumps straight to the right moment.

**Architecture: video indexing and search.**

```mermaid
flowchart LR
  VID["Video files"] --> SHOT["Shot or scene detection<br/>or 1 fps sampling"]
  SHOT --> KF["Keyframes"]
  KF --> CLIPE["CLIP image embeddings"]
  KF --> OCR["OCR text on screen"]
  VID --> AUDIO["Audio track"]
  AUDIO --> ASRV["ASR transcript<br/>word timestamps"]
  CLIPE --> SEG["Segment records<br/>video_id, start, end,<br/>vectors, transcript, OCR"]
  OCR --> SEG
  ASRV --> SEG
  SEG --> IDX[("Hybrid index<br/>vectors + BM25 + filters")]
  QRY["Text query"] --> QE["CLIP text embedding<br/>+ keyword query"]
  QE --> IDX
  IDX --> RES["Ranked segments<br/>with timestamps + thumbnails"]
```

**How to read it:** each video is split into shots (or sampled at a fixed rate). Keyframes are embedded with CLIP
and run through OCR, and the audio is transcribed with timestamps. These are merged into segment records
indexed for both vector and keyword search. A query searches visuals and words together and returns segments
with start and end times.

In the diagram, **shot detection** finds the cuts between camera shots, and **scene detection** groups shots into
scenes. **1 fps sampling** is the simple alternative of taking one frame per second. **Keyframes** are the frames
chosen to represent each segment. **OCR** (optical character recognition) reads text shown on screen, such as slides
or signs. **Word timestamps** record when each spoken word starts and ends. A **segment record** is one searchable
row per piece of video. The **hybrid index** combines vector search, **BM25** keyword ranking, and **filters** such as
date or channel (Section 25). **Thumbnails** are small preview images of each segment.

**Core ideas.**
- **Sampling.** 1 fps is simple, and shot detection (PySceneDetect) gives fewer, more meaningful segments.
  Sampling rate is the main cost knob.
- **Storage math.** 1 M hours at 1 fps = 3.6 B frames. At 512 dims FP16 that's ~3.7 TB of vectors. At one keyframe
  per ~5 s shot, it's ~720 M vectors (~740 GB), and INT8 or PQ shrinks that further.
- **Hybrid ranking.** Fuse visual similarity, transcript BM25, and OCR matches, then rerank with a
  cross-encoder or VLM for the top results.
- **Processing.** GPU decode (NVDEC), batched CLIP, batched ASR, and orchestration as a DAG per video
  (Section 24), idempotent per video and segment.
- **Video LLMs** can summarize or answer questions over retrieved segments, which is RAG over video.

**Example: the lecture archive.** A university indexed 80,000 hours of lectures. At 1 fps, it would have
288 M frames. Shot detection plus a frame every 10 s inside long static shots gave 31 M keyframes. Combining
slide OCR with transcripts let "gradient descent derivation" queries land within ±15 s of the right moment for
84% of labeled queries, vs 52% with transcripts alone.

**Senior / FAANG best practice.** Index segments, not whole videos, with timestamps. Combine visual, spoken, and
on-screen text signals with hybrid ranking, choose the sampling rate from the cost math and labeled query
evaluation, and run indexing as an idempotent per-video pipeline with GPU decode and batched models.

---

## Lecture 202 — Challenges of multimodal model serving

**Why it matters.** Multimodal requests vary enormously in size and cost: a text-only question vs ten
high-resolution images vs a minute of video. Without explicit limits, encoder caching, and separate scaling, a
few heavy requests wreck latency for everyone.

**In plain words.** A restaurant that serves both coffee and banquet orders needs a separate kitchen station
for banquets, a limit on how large an order can be, and pre-made ingredients for popular dishes. Otherwise
one banquet blocks every coffee.

**Architecture: a multimodal serving stack.**

```mermaid
flowchart LR
  REQ["Request<br/>text + media URLs"] --> GW["Gateway<br/>size, pixel, duration limits,<br/>media safety scan"]
  GW --> FETCH["Media fetch + decode<br/>CPU pool, resize to max pixels"]
  FETCH --> CACHE{"Encoder cache<br/>hash of media + processor version"}
  CACHE -->|"hit"| TOKS["Image or audio tokens"]
  CACHE -->|"miss"| ENC["Encoder pool<br/>ViT or audio encoder, GPU"]
  ENC --> TOKS
  TOKS --> LLMS["LLM pool<br/>prefill + decode"]
  LLMS --> OUT["Response"]
  ENC --> MET["Metrics per modality:<br/>tokens, encode ms, TTFT"]
  LLMS --> MET
```

**How to read it:** the gateway enforces limits on bytes, pixels, and duration, and scans media for safety.
Media is fetched and decoded on CPU workers and resized to a maximum. Encoder outputs are cached by content
hash, so repeated images cost nothing. Encoders and the LLM run in separately scaled pools, with metrics per
modality.

In the diagram, **media URLs** are links to images or audio that the server must download. **Pixel** and **duration
limits** cap image size and audio or video length, because cost grows with both. A **media safety scan** checks
uploads for illegal or harmful content. The **CPU pool** decodes files, since this work doesn't need a GPU. The
cache key combines a hash of the media bytes with the **processor version** (the exact preprocessing code), so a
preprocessing change never reuses old outputs. A **pool** is a group of replicas that scales independently.
**Encode ms** is time spent in the encoder, and **TTFT** is the LLM's time to first token.

**Core ideas.**
- **Pixels → tokens → cost.** Image token count grows with resolution (patches) and tiling. Set `max_pixels`
  or the number of tiles per model, and validate accuracy at that cap.
- **Encoder caching.** Users resend the same image across turns. Cache embeddings or soft tokens by
  (content hash, processor and model version).
- **Disaggregation.** Run vision encoders in their own pool (encode → prefill → decode), so encoder spikes don't
  starve LLM decode. Engines such as vLLM support multimodal inputs, and some deployments split the encoder out.
- **Payloads.** Upload to object storage, pass URLs, and fetch server-side with timeouts and size limits. Don't
  send megabytes of base64 through the gateway. Strip EXIF metadata (location).
- **Batching.** Mixed requests make batching harder. Bucket by modality and size, and set per-class SLOs (text-only
  vs with images).
- **Safety.** Text inside images can carry prompt injections. Scan media (CSAM hashes, NSFW), and apply the same
  output guardrails as text.

**Example: the photo-album request.** A user sent 40 photos in one request to a VLM endpoint. Each
became ~1,000 tokens, for a 40,000-token prefill that held a GPU for 6 seconds, and p99 TTFT for everyone else
on that replica spiked. Limits of at most 8 images per request and 1024 px on the long side, plus a separate
encoder pool and a per-request token budget at the gateway, kept p99 TTFT for text requests under 700 ms.

**Senior / FAANG best practice.** Convert every media input into a token budget enforced at the gateway,
resize to validated maximums, cache encoder outputs by content hash, scale encoder and LLM pools separately,
pass media by reference, and apply safety scanning and injection defenses to media as well as text.

---

## Lecture 203 — Lab: deploy CLIP for image search

**Goal:** embed ~13,000 images with OpenCLIP, index them in FAISS, serve text-to-image and image-to-image
search with FastAPI, and measure embedding throughput, query latency, and precision@10 on labeled text queries.

**What you're building.**

```mermaid
flowchart LR
  DS["Imagenette 160 px<br/>~13k images, 10 classes"] --> EMBI["embed_images.py<br/>ViT-B-32 image tower, batched"]
  EMBI --> FA[("FAISS IndexFlatIP<br/>normalized vectors")]
  Q["GET /search?q=a+church"] --> API["FastAPI"]
  API --> TT["Text tower"]
  TT --> FA
  FA --> TOP["Top-k image paths + scores"]
  EV["eval.py<br/>precision at 10 per class"] --> API
```

**In plain words.** You build a small "Google Images" for a photo folder: type words, get matching pictures,
and measure how often the top results are right.

**How to read the diagram:** **Imagenette** is a free 10-class subset of ImageNet, here the version with images
resized to 160 pixels, about 13,000 images. `embed_images.py` runs CLIP's **ViT-B-32** image **tower** (the image
encoder half of the model, using a base-size ViT with 32-pixel patches) over all images in batches. The vectors are
**normalized** to length 1 and stored in a **FAISS** `IndexFlatIP`, an exact index that ranks by **inner product**,
which for normalized vectors equals cosine similarity. A request such as `GET /search?q=a+church` (`+` is a space in a
URL) is embedded by the **text tower** and searched. The API returns the **top-k** image paths with scores. `eval.py`
measures **precision at 10**, the share of the 10 results that belong to the queried class, for each class.

### Step 1 — Data and dependencies

```bash
pip install open_clip_torch faiss-cpu fastapi uvicorn pillow
curl -L -O https://s3.amazonaws.com/fast-ai-imageclas/imagenette2-160.tgz && tar xzf imagenette2-160.tgz
```

### Step 2 — Embed and index the images

```python
# embed_images.py
import glob, json, time
import faiss, numpy as np, open_clip, torch
from PIL import Image
dev = "cuda" if torch.cuda.is_available() else "cpu"
model, _, preprocess = open_clip.create_model_and_transforms("ViT-B-32", pretrained="laion2b_s34b_b79k", device=dev)
model.eval()
paths = sorted(glob.glob("imagenette2-160/*/*/*.JPEG"))
vecs, t0 = [], time.time()
with torch.no_grad(), torch.autocast(dev, enabled=dev == "cuda"):
    for i in range(0, len(paths), 256):
        batch = torch.stack([preprocess(Image.open(p).convert("RGB")) for p in paths[i:i + 256]]).to(dev)
        v = model.encode_image(batch).float()
        vecs.append(torch.nn.functional.normalize(v, dim=-1).cpu().numpy())
X = np.concatenate(vecs).astype("float32")
print(f"{len(paths)} images in {time.time() - t0:.0f}s ({len(paths) / (time.time() - t0):.0f} img/s)")
index = faiss.IndexFlatIP(X.shape[1]); index.add(X)
faiss.write_index(index, "images.faiss"); json.dump(paths, open("paths.json", "w"))
```

### Step 3 — The search API

```python
# app.py
import json, time
import faiss, open_clip, torch
from fastapi import FastAPI, UploadFile
from PIL import Image
model, _, preprocess = open_clip.create_model_and_transforms("ViT-B-32", pretrained="laion2b_s34b_b79k")
tok = open_clip.get_tokenizer("ViT-B-32"); model.eval()
index, paths = faiss.read_index("images.faiss"), json.load(open("paths.json"))
app = FastAPI()

def search(v, k):
    v = torch.nn.functional.normalize(v.float(), dim=-1).numpy()
    scores, ids = index.search(v, k)
    return [{"path": paths[i], "score": round(float(s), 4)} for s, i in zip(scores[0], ids[0])]

@app.get("/search")
def text_search(q: str, k: int = 10):
    t = time.perf_counter()
    with torch.no_grad():
        res = search(model.encode_text(tok([q])), k)
    return {"query": q, "ms": round((time.perf_counter() - t) * 1000, 1), "results": res}

@app.post("/similar")
async def image_search(file: UploadFile, k: int = 10):
    img = Image.open(file.file).convert("RGB")
    img.thumbnail((1024, 1024))                     # bound pixels before preprocessing
    with torch.no_grad():
        return {"results": search(model.encode_image(preprocess(img).unsqueeze(0)), k)}
```

```bash
python embed_images.py
uvicorn app:app --port 8000 &
curl -s "localhost:8000/search?q=a+photo+of+a+church&k=5"
curl -s -F file=@imagenette2-160/val/n03028079/$(ls imagenette2-160/val/n03028079 | head -1) localhost:8000/similar
```

### Step 4 — Evaluate precision@10

```python
# eval.py: one query per class, a result is correct if its folder (class id) matches
import json, urllib.parse, urllib.request
CLASSES = {"n01440764": "tench fish", "n02102040": "English springer dog", "n02979186": "cassette player",
           "n03000684": "chainsaw", "n03028079": "church", "n03394916": "French horn",
           "n03417042": "garbage truck", "n03425413": "gas pump", "n03445777": "golf ball", "n03888605": "parachute"}
total = 0
for wnid, name in CLASSES.items():
    url = "http://localhost:8000/search?" + urllib.parse.urlencode({"q": f"a photo of a {name}", "k": 10})
    r = json.load(urllib.request.urlopen(url))
    p = sum(wnid in x["path"] for x in r["results"]) / 10
    total += p; print(f"{name:22s} P@10={p:.1f}  {r['ms']} ms")
print(f"mean P@10 = {total / len(CLASSES):.2f}")
```

**Expected results:**
- Embedding throughput is roughly 800–2,500 img/s on a single modern GPU (often limited by JPEG decode in
  the Python loop), and ~30–100 img/s on a laptop CPU.
- Text query latency is ~5–15 ms on GPU or ~20–60 ms on CPU, almost all of it the text tower. FAISS flat search over
  13k vectors is well under 1 ms.
- Mean P@10 is high (typically ≥ 0.9) on these distinct classes. Prompts matter: try "church" vs "a photo of a
  church".
- Image-to-image search returns visually and semantically similar images from the same class. At 10 M+ images,
  switch FAISS to HNSW or IVF-PQ, or move to a vector database (Section 25).

---

## FAANG deep-dive notes

**How big tech does it.** Photo, product, and video search at large companies runs on dual-encoder
embeddings precomputed for billions of items, with sharded ANN indexes, hybrid ranking with text signals, and
reranking. Vision-language and speech models run on GPU platforms with separate encoder and decoder pools,
token budgets per request, and encoder caches. Data pipelines filter, dedupe, and recaption billions of pairs
with provenance tracking, and preprocessing specs ship with models, guarded by golden-input tests.

**Staff review questions.**
- What does each modality cost in tokens or compute, and what are the limits per request?
- Which side of retrieval is precomputed, and how are vectors versioned with the model?
- How is preprocessing kept identical across training, indexing, and serving?
- What's the latency budget per stage for voice turns, and what is measured?
- How are media inputs checked for safety, privacy (EXIF, faces), and prompt injection?

**Interview question.** "Design text and image search for a photo-sharing app."

**Typical system-design prompt:** *Design search over 10 B user photos supporting text queries and
"find similar" image queries at 20,000 QPS, with p99 < 200 ms, 100 M new photos per day, and only photos the
user is allowed to see.*

**1. Clarify first:** What are the privacy scopes (own photos, friends, public)? What freshness is needed for new
uploads? Is quality measured by clicks or labeled relevance? Are there multilingual queries? Are there
regional storage constraints?

**2. Back-of-envelope sizing:**
- Vectors: 10 B × 512 dims. FP16 = 10 TB, INT8 = 5 TB, PQ at 64 bytes = 640 GB. Use IVF-PQ with rescoring on
  sharded nodes.
- Backfill: 10 B images ÷ ~2,000 img/s per GPU = 5 M GPU-seconds ≈ 1,400 GPU-hours. Decode and resize CPUs
  are needed too.
- New uploads: 100 M/day ≈ 1,160 img/s, which is ~1 GPU (×2 for headroom) plus decode workers.
- Queries: 20,000 QPS of text-tower inference with batching at ~3,000–5,000 queries/s per GPU ≈ 5–8 GPUs.
  The ANN fan-out across shards dominates latency.
- Privacy filtering: per-user scope filters inside the ANN search, or a per-user or per-scope partition for
  private photos (Section 25).

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Model | Off-the-shelf CLIP | Domain fine-tuned | Fine-tune on in-domain pairs when labeled evals show a gap |
| Index | HNSW in RAM | IVF-PQ + rescoring | IVF-PQ at billions of vectors, HNSW below ~100 M per shard |
| Privacy | Post-filter | Filter in search / partition | Filter in search. Partition private photos by owner |
| Freshness | Batch reindex nightly | Streaming upserts | Stream new uploads. Batch for model migrations |
| Ranking | Vector only | Hybrid + rerank | Hybrid with captions and OCR, then rerank the top 100 |

**4. Follow-up questions with crisp answers:**
- *How do you migrate to a new CLIP model?* Re-embed into a new index in parallel (~1,400 GPU-hours), dual-serve,
  compare relevance on labeled queries and online A/B, then switch and retire the old index.
- *How does a deleted photo disappear from search?* A delete event triggers a tombstone in the index immediately,
  then physical removal at compaction. Measure the delete SLA.
- *Why precompute image embeddings rather than text?* Images are the corpus (encoded once, queried
  many times). Text is the query, and its tower is cheap.
- *How do you handle multilingual queries?* Use a multilingual text tower aligned to the same image space, or
  translate queries, with evaluation per language.

**Debug this (common onsite question):** "After moving image preprocessing to a new microservice, search
relevance dropped ~15%, but there were no errors, and latency is better."
1. Embed 50 golden images through the old and new paths. Cosine similarity is 0.86–0.93 instead of ≥ 0.999.
2. Compare preprocessing step by step: the new service uses ImageNet mean/std instead of CLIP's, and
   center-crops after resizing the short side to 256 instead of 224.
3. New uploads were embedded with the new path, so the index now mixes two incompatible preprocessing
   versions.
4. Fix: restore CLIP's processor config from the model artifact, re-embed affected items, and add the golden-image
   test to CI for any preprocessing change.

The lesson: preprocessing is part of the model. Version it with the model, test it with golden inputs, and
never mix vectors from different pipelines in one index.

**5. What separates senior from staff answers:** a senior engineer builds a working CLIP + ANN search with
batching and good latency. A staff engineer sizes the corpus, backfill, and migrations, enforces privacy inside
retrieval, treats preprocessing and vectors as versioned contracts, budgets tokens and compute per modality,
and defines relevance evaluation (labeled queries plus online metrics) that gates every model change.

**Red flags:**
- Mixing vectors from different models or preprocessing in one index.
- No pixel, size, or duration limits on media inputs.
- Encoding the corpus at query time.
- Post-filtering private photos.
- Voice pipelines without per-stage latency budgets.
- Media passed as base64 through every hop.

---

## Quiz

<details><summary>1. What are the two main multimodal model patterns?</summary>
Dual encoders that map modalities into a shared vector space (CLIP, SigLIP) for search and zero-shot tasks, and
encoder + LLM models that turn media into tokens for a language model (VLMs, speech LLMs) for reasoning and
generation.
</details>

<details><summary>2. Why does image resolution matter for VLM serving cost?</summary>
Image token count grows with the number of patches and tiles, so higher resolution means more prefill compute and KV
memory per request. Cap pixels or tiles at a validated maximum.
</details>

<details><summary>3. Why does CLIP training want very large batches, and how is memory kept manageable?</summary>
Every other pair in the batch is a negative, so more negatives give a stronger contrastive signal. Embeddings are
all-gathered, and each GPU computes only its local rows of the similarity matrix. SigLIP's sigmoid loss reduces
the dependence on batch size.
</details>

<details><summary>4. In CLIP search, which tower is run per query, and why?</summary>
The text tower, because it's small and fast. Image embeddings for the corpus are precomputed once offline and indexed.
</details>

<details><summary>5. What is the real-time factor in speech processing?</summary>
Processing time divided by audio duration. RTF < 1 means faster than real time. Batch GPU transcription can
reach RTF ≪ 0.01.
</details>

<details><summary>6. What dominates voice-agent turn latency, and how do you reduce it?</summary>
Endpointing wait, ASR, LLM time to first token, and TTS start. Reduce it by tuning endpointing, streaming every
stage, colocating services, using smaller models for most turns, and starting TTS on the first clause.
</details>

<details><summary>7. How should video be indexed for text search?</summary>
As timestamped segments, built from shot detection or sampled keyframes, with CLIP embeddings, OCR, and ASR
transcripts in a hybrid vector + keyword index, returning start and end times.
</details>

<details><summary>8. Why is preprocessing part of the model contract?</summary>
Resize, crop, color order, and normalization change the embeddings. Mismatches silently degrade quality, so ship
the processor config with the model and test it with golden inputs.
</details>

## Failure modes
- Training-serving preprocessing mismatch (RGB vs BGR, wrong mean/std, different crop).
- Vectors from different models or pipelines mixed in one index.
- Unbounded image resolution or media count per request, which blows up tokens and TTFT.
- Encoder and LLM in one pool, so media spikes starve decode.
- No encoder cache for repeated media.
- Media sent as base64 through every service, and EXIF location data kept.
- Voice pipelines in different regions, or with conservative endpointing.
- Video indexed without timestamps, or at a sampling rate chosen without cost math.
- Image-text data without filtering, dedupe, licensing, or provenance.

## Checklist
- [ ] You can explain dual-encoder vs encoder + LLM architectures and their costs
- [ ] You can build a filtered, deduped image-text shard pipeline
- [ ] You ship preprocessing with the model and test it with golden images
- [ ] You can explain the distributed contrastive loss and CLIP serving with precomputed image vectors
- [ ] You can design batch and streaming speech pipelines and budget a voice turn
- [ ] You can design segment-level video search with visual, spoken, and OCR signals
- [ ] You enforce pixel, token, and payload limits and cache encoder outputs
- [ ] You deployed CLIP image search and measured throughput, latency, and P@10
