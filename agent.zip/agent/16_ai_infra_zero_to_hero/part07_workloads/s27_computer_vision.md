# Section 27 — Computer Vision Infrastructure at Scale

> Lectures 183–189 • Assessment: quiz
> **After this section you can:** size image and video data (storage, bandwidth, decode), build CV training
> pipelines that keep GPUs fed (sharded datasets, GPU decode), choose CV models by measured latency rather
> than FLOPs, serve real-time video inference with batching across streams and deliberate frame dropping,
> build DeepStream pipelines, split work between edge and cloud, and deploy a multi-stream real-time
> detector.
>
> Go deeper: [13 / Lab 41 — Triton multi-framework](../../13_sovereign_ai_infra_course/04_serving_inference/lab41_triton_multi_framework.md),
> [Lab 33 — Distributed data loading](../../13_sovereign_ai_infra_course/03_distributed_training/lab33_distributed_data_loading.md),
> [Lab 43 — TensorRT engines](../../13_sovereign_ai_infra_course/04_serving_inference/lab43_tensorrt_llm_engines.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 183 | Image and video data challenges | A decoded 1080p frame is 6.2 MB. Video is a decode and bandwidth problem before it's a model problem |
| 184 | Training pipelines for CV models | Sharded datasets + GPU decode and augmentation keep GPUs busy. The data loader is usually the bottleneck |
| 185 | EfficientNet and model scaling trade-offs | Compound scaling is efficient in FLOPs, but latency on real hardware is what you ship |
| 186 | Serving real-time video inference | Decode on GPU, batch across streams, infer every Nth frame plus tracking, and drop stale frames |
| 187 | DeepStream SDK for video analytics | GStreamer pipelines with zero-copy GPU buffers: decode, mux, infer, track, publish |
| 188 | Edge-to-cloud video processing | Analyze at the edge, send events and clips, and retrain in the cloud on hard examples |
| 189 | Lab: deploy real-time object detection | 4 RTSP streams, a TensorRT YOLO detector, cross-stream batching, and frame-age metrics |

```mermaid
flowchart LR
  CAM["Cameras<br/>RTSP H.264/H.265"] --> DEC["GPU decode<br/>NVDEC"]
  DEC --> PRE["Resize + normalize<br/>on GPU"]
  PRE --> BATCH["Batch across streams"]
  BATCH --> INF["Detector<br/>TensorRT FP16/INT8"]
  INF --> TRK["Tracker<br/>IDs across frames"]
  TRK --> EVT["Events + metadata<br/>Kafka"]
  EVT --> APP["Apps, alerts, dashboards"]
  TRK --> CLIP["Clips on event<br/>object storage"]
  CLIP --> LAB["Hard examples to labeling"]
  LAB --> TRAIN["Training pipeline<br/>sharded data, GPU aug"]
  TRAIN --> REG["Model registry"]
  REG -->|"OTA or rollout"| INF
```

**How to read it:** video comes in compressed, is decoded on the GPU, preprocessed, and batched across
streams for the detector. A tracker turns per-frame detections into objects with IDs, and only events,
metadata, and short clips leave the pipeline. Interesting or wrong cases flow back to labeling and
training, and new models roll out to the inference fleet through the registry.

**Terms in this diagram.**
- **RTSP H.264/H.265**: cameras stream video over **RTSP** (Real-Time Streaming Protocol), compressed with the
  **H.264** or newer, roughly twice as efficient, **H.265** codec.
- **GPU decode, NVDEC**: the dedicated video decoder on NVIDIA GPUs, which turns compressed video into frames without
  using the compute cores (Section 21).
- **Batch across streams**: frames from many cameras are stacked into one model call to keep the GPU efficient.
- **Detector, TensorRT FP16/INT8**: an object detection model compiled with TensorRT at 16-bit or 8-bit precision
  (Section 22).
- **Tracker, IDs across frames**: links each frame's boxes into objects with a stable ID, so "person 17" is the same
  person over time.
- **Events + metadata, Kafka**: small records such as "person entered zone A at 10:02:13", published to a Kafka
  topic (Section 24).
- **Clips on event**: a few seconds of video around an event, saved for review.
- **Hard examples**: cases the model got wrong or was unsure about, which teach it the most.
- **Sharded data, GPU aug**: training data stored as many large files (Lecture 184), and **augmentation** (random
  crops, flips, and color changes) done on the GPU.
- **OTA or rollout**: an over-the-air update to edge devices, or a gradual rollout to servers.

---

## Lecture 183 — Image and video data challenges in AI infra

**Why it matters.** Vision data is large, both compressed and especially decoded. Pipelines that treat images like
rows in a table run out of bandwidth, CPU, or money long before the model becomes the bottleneck.

**In plain words.** A video file is a vacuum-packed suitcase. It's small in the trunk, but once you
unpack it (decode), it fills a room. Every frame you process has to be unpacked first, so where and how you
unpack decides how many suitcases you can handle.

**Architecture: bytes at each stage for one 1080p camera.**

```mermaid
flowchart LR
  C["Camera 1080p30<br/>H.264 ~4 Mbps"] -->|"0.5 MB/s"| NET["Network + storage<br/>~43 GB per day"]
  NET --> D["Decode"]
  D -->|"6.2 MB per frame<br/>187 MB/s"| RAW["Raw RGB frames<br/>in memory"]
  RAW --> R["Resize to 640x640<br/>1.2 MB per frame"]
  R --> M["Model input tensor"]
```

**How to read it:** compressed video is cheap to move and store, about 0.5 MB/s per camera. Decoding
multiplies data ~370×, to 187 MB/s of raw frames per camera. That's why decode must happen close to the
model (ideally on the GPU, with frames staying in GPU memory) and why frames are resized immediately.

In the diagram, **1080p30** means 1920 × 1080 pixels at 30 frames per second. **4 Mbps** is 4 megabits per second,
which is 0.5 megabytes per second, or about 43 GB per day. A raw **RGB** frame stores red, green, and blue bytes for
every pixel: 1920 × 1080 × 3 = 6.2 MB, and 30 of them per second is 187 MB/s. Resizing to **640x640**, a typical
detector input size, cuts each frame to 1.2 MB. The **model input tensor** is that frame as an array of numbers.

**Core ideas.**
- **Image datasets.** ImageNet-1k is ~1.28 M images (~150 GB). Production datasets reach hundreds of millions.
  Millions of small files on object storage are slow (per-request overhead), so pack them into shards
  (WebDataset tar, TFRecord, MDS) of ~100 MB–1 GB.
- **Video.** Store compressed. Index by camera and time. Extract frames only when needed (keyframes, sampled
  frames, event windows). 100 cameras × 43 GB/day ≈ 4.3 TB per day, so retention policies dominate cost.
- **Decode.** CPU decode of 1080p H.264 takes roughly one core per few streams in real time. GPUs have
  dedicated decoders (NVDEC) that handle dozens of 1080p30 streams without using CUDA cores.
- **Labels.** Boxes, masks, and tracks are expensive. Use model-assisted labeling and active learning to label
  what the model gets wrong.
- **Privacy.** Faces and license plates are personal data in many jurisdictions. Blur at the edge,
  minimize retention, and control access (Section 18).

**Example: the training job that waited.** A team trained a detector on 40 M JPEGs stored as individual
objects in S3. GPU utilization was 22%, and the data loader spent most of its time on per-object request
latency. Repacking into 512 MB WebDataset shards and streaming them sequentially took utilization to 85% and
cut epoch time by 3.5×, with no change to the model.

**Senior / FAANG best practice.** Do the bytes math at every stage (compressed, decoded, resized) before
choosing hardware. Store media compressed in sharded, sequentially readable formats, decode on the GPU near
the model, set retention by value, and design privacy (blurring, access, retention) into ingest.

---

## Lecture 184 — Training pipelines for CV models

**Why it matters.** Vision models are often limited by input throughput. Eight modern GPUs can train a
ResNet-50 on tens of thousands of images per second, far more than CPU JPEG decode and augmentation can
supply. A balanced pipeline can halve training time and cost.

**In plain words.** A fast oven is useless if the prep cooks can't chop vegetables quickly enough. You
either hire more prep cooks (CPU workers), buy a vegetable chopper (GPU decode), or pre-chop ahead of time
(preprocessed shards).

**Architecture: a CV training input pipeline.**

```mermaid
flowchart LR
  S3[("Object storage<br/>tar shards")] --> STREAM["Streaming reader<br/>shuffle buffer"]
  STREAM --> DEC{"Decode where?"}
  DEC -->|"CPU workers"| CPU["PIL or OpenCV<br/>~100-300 img/s per core"]
  DEC -->|"GPU"| DALI["DALI / nvJPEG<br/>thousands of img/s"]
  CPU --> AUG["Augment<br/>crop, flip, color"]
  DALI --> GAUG["GPU augment"]
  AUG --> PIN["Pinned memory<br/>prefetch"]
  GAUG --> GPU["GPU training step<br/>AMP, channels_last"]
  PIN --> GPU
  GPU --> MET["Metrics: img/s,<br/>data-wait time, GPU util"]
```

**How to read it:** shards stream from object storage through a shuffle buffer. Decoding and augmentation
happen either on CPU workers (simple, but often the bottleneck) or on the GPU with DALI and nvJPEG. Batches
are prefetched in pinned memory so the GPU never waits. The key health metric is how long each step waits for
data.

**Terms in this diagram.**
- **Tar shards**: thousands of images packed into each `.tar` file of a few hundred MB (the WebDataset format), because
  reading millions of tiny files from object storage is very slow (Section 6).
- **Streaming reader, shuffle buffer**: shards are read sequentially, and a **shuffle buffer** holds a few thousand
  samples and outputs them in random order, so training doesn't see images in storage order.
- **PIL or OpenCV**: the two common Python image libraries for decoding JPEGs on the CPU.
- **DALI / nvJPEG**: NVIDIA's **DALI** (Data Loading Library) runs decoding and augmentation on the GPU, and
  **nvJPEG** is its GPU JPEG decoder.
- **Augment: crop, flip, color**: random changes to each training image, so the model generalizes better.
- **Pinned memory, prefetch**: **pinned** (page-locked) host memory can be copied to the GPU faster and asynchronously.
  **Prefetch** prepares the next batches while the current one trains.
- **AMP, channels_last**: **AMP** (automatic mixed precision) runs most math in FP16 or BF16. **channels_last** stores
  images as height, width, channels in memory, which tensor cores process faster for convolutions.
- **img/s, data-wait time**: images processed per second, and the time each training step spends waiting for input.

**Core ideas.**
- **Measure first.** Time a training step with synthetic data (no loader). If real data is much slower, the
  pipeline is the bottleneck.
- **CPU path.** Use enough DataLoader workers (often 4–8 per GPU), `pin_memory=True`, `persistent_workers=True`,
  and prefetching. Use Pillow-SIMD or OpenCV, and decode at reduced size when the format allows it.
- **GPU path.** NVIDIA DALI decodes JPEG with nvJPEG (with hardware JPEG decoders on A100/H100) and augments on
  the GPU. torchvision v2 transforms can also run on GPU tensors.
- **Training speedups.**
  - Mixed precision (AMP) and the `channels_last` memory format.
  - Progressive resizing: small images early, full size late.
  - Pretrained backbones, so fine-tuning beats training from scratch.
- **Distributed.** Use DDP with a sharded data split per rank, and set seeds and epochs so every rank sees different
  shards. Scaling to many GPUs often needs a larger batch with learning-rate warmup (LARS or LAMB for very large batches).

```python
# DALI pipeline: read WebDataset-style tar shards, decode on GPU, random-resized crop, normalize
from nvidia.dali import pipeline_def, fn, types
@pipeline_def(batch_size=256, num_threads=8, device_id=0)
def train_pipe(paths, index_paths):
    jpegs, labels = fn.readers.webdataset(paths=paths, index_paths=index_paths, ext=["jpg", "cls"],
                                          random_shuffle=True, initial_fill=4096, name="Reader")
    imgs = fn.decoders.image_random_crop(jpegs, device="mixed", output_type=types.RGB)
    imgs = fn.resize(imgs, resize_x=224, resize_y=224)
    imgs = fn.crop_mirror_normalize(imgs, dtype=types.FLOAT16, output_layout="CHW",
                                    mean=[0.485 * 255, 0.456 * 255, 0.406 * 255],
                                    std=[0.229 * 255, 0.224 * 255, 0.225 * 255], mirror=fn.random.coin_flip())
    return imgs, labels
```

**Example: CPU-bound on 8 GPUs.** ResNet-50 training on 8 × A100 reached 9,000 img/s with 64 CPU cores
doing decode and augmentation, all at 100%. With synthetic data, the GPUs could do ~22,000 img/s. Moving decode and
augmentation to DALI reached ~19,000 img/s, so epoch time fell from 2.4 to 1.1 minutes on ImageNet-1k. The
same CPUs were then free for the data-loading reader threads.

**Senior / FAANG best practice.** Benchmark synthetic vs real input on every new pipeline, keep data-wait
time near zero, store shards for sequential reads, move decode and augmentation to GPUs when CPUs saturate,
and record images/s and data-wait time on the training dashboard next to loss.

---

## Lecture 185 — EfficientNet and model scaling trade-offs

**Why it matters.** Choosing a CV model is choosing a point on an accuracy-latency-cost curve. Papers report
FLOPs and parameters, but production cares about latency and throughput on specific hardware, and those
can disagree sharply.

**In plain words.** Fuel efficiency in a brochure isn't the same as fuel efficiency in city traffic.
EfficientNet does very little arithmetic per image, but some of its operations move a lot of data relative
to the math, and on GPUs moving data is often what's slow.

**Architecture: compound scaling and how it maps to hardware.**

```mermaid
flowchart LR
  B0["EfficientNet-B0<br/>5.3 M params, 0.39 GFLOPs<br/>77.1% top-1"] --> CS{"Compound scaling<br/>depth x 1.2, width x 1.1,<br/>resolution x 1.15 per step"}
  CS --> B4["B4<br/>19 M, 4.2 GFLOPs, 82.9%"]
  CS --> B7["B7<br/>66 M, 37 GFLOPs, 84.3%"]
  B4 --> HW{"Measured on target hardware"}
  B7 --> HW
  R50["ResNet-50<br/>25.6 M, 4.1 GFLOPs, ~76-80%"] --> HW
  HW --> GPUL["GPU: dense convs fast,<br/>depthwise convs memory-bound"]
  HW --> EDGE["Mobile NPU or CPU:<br/>depthwise convs efficient"]
```

**How to read it:** EfficientNet scales depth, width, and input resolution together from a small base,
which gives excellent accuracy per FLOP. On GPUs, its depthwise convolutions and squeeze-excitation layers are
memory-bound, so a ResNet-50 with similar FLOPs can be faster than B4, while on mobile hardware the
reverse often holds. Always measure on the target.

In the diagram, **M params** is millions of parameters. **GFLOPs** is billions of floating-point operations per image.
**Top-1** is ImageNet accuracy, the share of images whose first guess is correct. **Compound scaling** grows all three
dimensions by fixed factors at each step: **depth** (number of layers) × 1.2, **width** (channels per layer) × 1.1,
and input **resolution** × 1.15. **Dense convs** are ordinary convolutions, with lots of math per byte of data, which
GPUs love. **Depthwise convs** filter each channel separately, so they do little math per byte, and on GPUs they're
**memory-bound**, limited by memory speed rather than compute. A mobile **NPU** (neural processing unit) is designed
for such layers, so they're efficient there (Section 23).

**Core ideas.**
- **Compound scaling.** For one compute step: depth α = 1.2, width β = 1.1, and resolution γ = 1.15, with α·β²·γ² ≈ 2,
  so each step roughly doubles FLOPs. Larger resolution is expensive for memory and latency.
- **FLOPs ≠ latency.** Arithmetic intensity, kernel support (TensorRT fusions), memory bandwidth, and batch
  size decide real speed. EfficientNetV2 replaced early depthwise blocks with fused convolutions for this reason,
  and it trains much faster.
- **Other families.** ResNet (simple, fast on GPUs), ConvNeXt (modern CNN), ViT and Swin (scale well with
  data, and attention costs grow with resolution), YOLO families for real-time detection (n, s, m, l, x sizes), and
  MobileNet and EfficientNet-Lite for edge devices.
- **Choose by budget.** Fix a latency or cost budget per image on the target hardware, then pick the most
  accurate model that fits, then optimize it (FP16/INT8, Section 22).

**Example: picking the classifier.** For a 5 ms per-image budget at batch 8 on a T4 with TensorRT FP16, the
team measured three models.
- **EfficientNet-B4 at 380 px:** 82.9% top-1, but 11.8 ms. Too slow, because the high resolution and depthwise layers cost latency.
- **ResNet-50 at 224 px:** ~80% top-1 with modern training, at 2.1 ms.
- **EfficientNetV2-S at 384 px:** 83.9% top-1, at 4.6 ms.

They chose V2-S, and the FLOPs ranking would have pointed them at the wrong model.

**Senior / FAANG best practice.** Maintain a model zoo benchmarked on every target (GPU type, edge
device) with the production runtime and batch sizes. Choose by accuracy at a latency or cost budget, treat
input resolution as a first-class knob, and re-benchmark when the runtime or hardware changes.

---

## Lecture 186 — Serving real-time video inference

**Why it matters.** Real-time video means a hard per-frame budget (33 ms at 30 fps), many concurrent
streams, and a fixed GPU fleet. Systems that queue every frame fall behind and stay behind, while
well-designed ones keep latency flat and serve many streams per GPU.

**In plain words.** A news ticker should show the latest news, not every headline from an hour ago.
If you can't keep up, skip old frames and work on the newest one, and use a tracker to fill in the frames
you skipped.

**Architecture: a multi-stream inference service.**

```mermaid
flowchart LR
  S1["Stream 1"] --> D1["NVDEC decode"]
  S2["Stream 2"] --> D2["NVDEC decode"]
  SN["Stream N"] --> DN["NVDEC decode"]
  D1 --> LQ["Latest-frame slot per stream<br/>older frames dropped"]
  D2 --> LQ
  DN --> LQ
  LQ --> SCHED["Batcher<br/>every 33 ms or max batch"]
  SCHED --> TRT["TensorRT detector<br/>batch N, FP16"]
  TRT --> NMS["NMS on GPU"]
  NMS --> TRK["Per-stream tracker"]
  TRK --> OUT["Events, metrics:<br/>frame age, fps, drops"]
```

**How to read it:** each stream decodes on the GPU into a one-slot buffer that always holds the newest
frame, so stale frames are overwritten, not queued. A batcher collects the current frame from every stream on
a fixed tick, runs the detector on the batch, and hands detections to per-stream trackers. The key
metric is frame age (now minus capture time), not queue length.

In the diagram, the **latest-frame slot** is a buffer holding exactly one frame per stream. New frames replace old
ones, so the detector always sees the present. **Every 33 ms or max batch** means the batcher runs once per frame
interval at 30 fps, or sooner if it has a full batch. **Batch N** means one frame from each of the N streams. **NMS**
(non-maximum suppression) removes duplicate overlapping boxes, and doing it on the GPU avoids copying all raw
boxes to the CPU. **Frame age** is how old a frame is when its result comes out. **Drops** counts frames overwritten
before being processed.

**Core ideas.**
- **Budget.** Decode, preprocess, inference, postprocessing, and tracking must fit the frame interval at your
  processing rate. At 30 fps that's 33 ms, but many applications only need 5–10 inferences per second.
- **Infer every Nth frame + track.** Running the detector at 10 fps and a tracker (ByteTrack, NvDCF) at
  30 fps saves ~3× compute with little quality loss for most motion.
- **Batch across streams.** One batch-16 call is far cheaper than 16 batch-1 calls. Triton's dynamic batcher
  or a fixed-tick batcher does this.
- **Drop, don't queue.** Use leaky or latest-only buffers. If inference falls behind, drop frames and
  report it, never let queues grow.
- **Keep frames on the GPU.** NVDEC → CUDA preprocessing → TensorRT with zero copies. CPU round trips of
  6 MB frames kill throughput.
- **Capacity unit = streams per GPU** at a target processing fps, measured end to end.

**Example: 16 streams on one GPU.** A retailer's detector ran per-stream batch-1 inference with CPU decode.
One T4 handled 5 streams before frame age climbed. With NVDEC decode, GPU preprocessing, batch-16 TensorRT
FP16 inference at 10 fps per stream, and a tracker filling the gaps, the same T4 handled 16 streams with
p99 frame age of 140 ms, and the fleet needed 3× fewer GPUs.

**Senior / FAANG best practice.** Design for bounded latency. Use latest-frame buffers and explicit drop
metrics, batch across streams on a fixed tick, decode and preprocess on the GPU, and pair a lower detection rate
with tracking. Plan capacity in streams per GPU, measured end to end, with frame age as the SLO.

---

## Lecture 187 — DeepStream SDK for video analytics

**Why it matters.** Hand-building decode, batching, inference, and tracking for hundreds of streams is a
lot of hard engineering. NVIDIA DeepStream packages these as GStreamer plugins that keep frames in GPU
memory end to end, and it's the standard way to run high-density video analytics on NVIDIA hardware,
from Jetson to data-center GPUs.

**In plain words.** DeepStream is a set of LEGO bricks for video plumbing: a decoder brick, a batching
brick, a model brick, a tracker brick, and a messaging brick. You snap them together in a config file, and
the video never leaves the GPU between bricks.

**Architecture: a DeepStream pipeline.**

```mermaid
flowchart LR
  SRC["uridecodebin<br/>RTSP x N"] --> DEC["nvv4l2decoder<br/>NVDEC"]
  DEC --> MUX["nvstreammux<br/>batch N frames"]
  MUX --> PGIE["nvinfer primary<br/>detector, TensorRT"]
  PGIE --> TRK["nvtracker<br/>NvDCF or IOU"]
  TRK --> SGIE["nvinfer secondary<br/>classifier on crops"]
  SGIE --> CONV["nvmsgconv<br/>metadata to JSON"]
  CONV --> BROKER["nvmsgbroker<br/>Kafka or MQTT"]
  SGIE --> OSD["nvdsosd<br/>draw boxes, optional"]
```

**How to read it:** sources decode on NVDEC, `nvstreammux` forms one batch from all streams, the primary
detector runs as a TensorRT engine, the tracker assigns IDs, and an optional secondary model classifies the
detected objects (for example, vehicle type). Metadata is converted to JSON and published to Kafka. On-screen
drawing is optional and is usually disabled in production to save GPU time.

**Terms in this diagram.** Each box is a **GStreamer element**, a plug-in stage in a media pipeline (Section 21).
- **uridecodebin**: GStreamer's generic source, which opens a URI such as `rtsp://...` and picks the right decoder.
- **nvv4l2decoder**: NVIDIA's hardware decoder element, which uses NVDEC through the Linux V4L2 video interface.
- **nvstreammux**: the stream muxer, which combines frames from N sources into one batch.
- **nvinfer primary (PGIE)**: the **primary GPU inference engine**, which runs the main detector on full frames.
- **nvtracker, NvDCF or IOU**: the tracker element. **NvDCF** is NVIDIA's accurate correlation-filter tracker, and
  **IOU** is a fast tracker that matches overlapping boxes.
- **nvinfer secondary (SGIE)**: a **secondary** engine that runs a classifier on each detected object's **crop** (the
  cut-out box).
- **nvmsgconv, nvmsgbroker**: convert metadata into JSON messages, then send them to a broker such as Kafka or MQTT.
- **nvdsosd**: the on-screen display element, which draws boxes and labels onto the video.

**Core ideas.**
- **Configuration.** Pipelines are defined by config files or the Python bindings (`pyds`). `nvinfer` takes
  an ONNX model and builds or caches a TensorRT engine (FP16/INT8).
- **Batching.** `nvstreammux` `batch-size` should equal the number of sources. Set `batched-push-timeout` to bound
  latency when a stream is slow.
- **Intervals.** `interval=2` on the primary detector infers every third frame, and the tracker fills the gaps.
- **Metadata.** `NvDsBatchMeta`, frame meta, and object meta are attached to buffers. Probes in Python
  read them to build events.
- **Deployment.** Containers from NGC for x86 and Jetson, monitoring with Prometheus metrics, and
  Graph Composer and DeepStream Service Maker for building pipelines.

```ini
# deepstream_app config excerpt: 8 streams, detector every 3rd frame, tracker, Kafka output
[streammux]
batch-size=8
width=1920
height=1080
batched-push-timeout=40000
live-source=1

[primary-gie]
enable=1
# the nvinfer file sets onnx-file, network-mode=2 (FP16), and batch-size=8
config-file=config_infer_primary_yolo.txt
interval=2

[tracker]
enable=1
ll-lib-file=/opt/nvidia/deepstream/deepstream/lib/libnvds_nvmultiobjecttracker.so
ll-config-file=config_tracker_NvDCF_perf.yml

[sink1]
# type 6 = message converter + broker
type=6
msg-broker-proto-lib=/opt/nvidia/deepstream/deepstream/lib/libnvds_kafka_proto.so
msg-broker-conn-str=kafka;9092;video-events
```

**Example: from Python glue to DeepStream.** A city traffic project ran OpenCV decode + PyTorch per
stream and needed one GPU per 4 cameras. Rebuilding it as a DeepStream pipeline (NVDEC, mux batch 16,
INT8 detector at interval 2, NvDCF tracker) ran 16 cameras per GPU at 30 fps output with full tracking. The
CPU, previously saturated, was mostly idle.

**Senior / FAANG best practice.** Use DeepStream (or an equivalent zero-copy GPU pipeline) for dense
video analytics instead of Python frame loops. Version pipeline configs and engines with the model,
benchmark streams per GPU per model, disable on-screen display in production, and export pipeline
metrics (fps per source, latency, drops) to your monitoring stack.

---

## Lecture 188 — Edge-to-cloud video processing

**Why it matters.** Sending every camera's video to the cloud is expensive in bandwidth and cloud
compute, adds latency, and raises privacy risk. Processing at the edge and sending only events and clips
changes the economics, but brings fleet management, updates, and offline operation into scope.

**In plain words.** A security guard watching the cameras in each building calls headquarters only when
something happens, instead of shipping every tape to headquarters to be watched there.

**Architecture: edge analysis, cloud learning.**

```mermaid
flowchart LR
  subgraph SITE["Each site"]
    CAMS["Cameras"] --> EDGE["Edge box<br/>Jetson Orin or small GPU server<br/>DeepStream"]
    EDGE --> BUF[("Local ring buffer<br/>24-72 h video")]
  end
  EDGE -->|"events + metadata<br/>~kbps"| BUS["Cloud event bus"]
  EDGE -->|"clips on event<br/>or on request"| OBJ[("Object storage")]
  BUS --> APPS["Dashboards, alerts, analytics"]
  OBJ --> AL["Active learning<br/>hard and uncertain cases"]
  AL --> TRN["Cloud training"]
  TRN --> REG["Registry + fleet manager"]
  REG -->|"staged OTA rollout"| EDGE
  BUS -->|"heavy model verification<br/>on selected events"| VER["Cloud model"]
```

**How to read it:** edge boxes run the real-time pipeline on site and keep a rolling local video buffer.
Only events, metadata, and selected clips go to the cloud. The cloud aggregates, verifies some events with
heavier models, and mines hard examples for retraining. New models roll back out to the fleet in stages.

In the diagram, a **local ring buffer** is storage that keeps the last 24 to 72 hours of video and overwrites the
oldest automatically, so footage around any event can still be fetched. **~kbps** means a few kilobits per second per
site, compared with megabits for video. The **cloud event bus** is a managed message stream such as Kafka.
**Clips on request** means an operator can ask a site to upload a specific time range. **Active learning** selects
the examples the model is least sure about for humans to label first. A **staged OTA rollout** updates a small group
of sites, checks their metrics, then continues to more. **Heavy model verification** reruns selected events through a
larger, more accurate model in the cloud to confirm or reject them.

**Core ideas.**
- **Bandwidth math.** 1,000 cameras × 4 Mbps = 4 Gbps of continuous uplink. Metadata is ~1–10 kbps per camera,
  and clips are on demand, a reduction of 100–1,000×.
- **Placement.** Use the edge for latency, bandwidth, privacy, and offline operation, and the cloud for heavy models,
  cross-site analytics, training, and long-term storage. Many systems use cascades: the edge detects, and the cloud
  verifies.
- **Fleet operations.** Device identity and certificates, staged OTA updates with rollback (Section 21),
  health telemetry, remote logs, and version skew tracking.
- **Offline.** Buffer events locally when the uplink fails, and send them on reconnect with idempotent ids.
- **Privacy by design.** Blur faces and plates at the edge, send only metadata by default, and minimize retention.

**Example: the bandwidth bill.** A logistics company streamed 2,400 warehouse cameras to the cloud for
analysis: ~10 Gbps of uplink, plus cloud GPUs decoding everything. Moving detection to one edge server per
warehouse (8–16 cameras each) cut uplink to ~40 Mbps of events plus clips. Monthly network and cloud GPU
costs dropped ~85%, and alert latency improved from ~4 s to under 1 s.

**Senior / FAANG best practice.** Analyze where the pixels are, send the minimum (events, metadata, and
clips on demand), and use the cloud for learning and verification. Treat the edge fleet like production
servers, with identity, staged rollouts, rollback, and telemetry, and close the loop with active learning on
hard examples.

---

## Lecture 189 — Lab: deploy real-time object detection

**Goal:** serve a YOLO detector as a TensorRT FP16 engine to 4 simulated RTSP cameras with cross-stream
batching and latest-frame buffers, publish detections as JSON events, and measure FPS, frame age, and drops
as you scale from 1 to 8 streams.

**What you're building.**

```mermaid
flowchart LR
  MP4["sample.mp4 looped"] --> FF["ffmpeg x 4<br/>publish RTSP"]
  FF --> MTX["MediaMTX<br/>RTSP server"]
  MTX --> RD["reader thread per stream<br/>latest-frame slot"]
  RD --> BT["batcher tick 100 ms<br/>batch of 4"]
  BT --> ENG["YOLO11n TensorRT FP16"]
  ENG --> EV["events.jsonl<br/>+ fps, frame age, drops"]
```

**In plain words.** You build a miniature video analytics service: simulated cameras, one GPU detector shared by
all streams, and the metrics that show whether it's keeping up.

**How to read the diagram:** four `ffmpeg` processes (the standard command-line video tool) loop `sample.mp4` and
publish it as RTSP streams to **MediaMTX**, a small open-source RTSP server, so you get four simulated cameras. Your
app runs one reader thread per stream that keeps only the latest frame. Every 100 ms, the batcher collects one
frame per stream into a batch of 4 and runs **YOLO11n**, the nano version of Ultralytics' YOLO11 detector, as a
TensorRT FP16 engine. Results are appended to `events.jsonl` (one JSON object per line), together with fps, frame age,
and dropped-frame counts.

### Step 1 — Simulated cameras

```bash
docker run -d --name mediamtx -p 8554:8554 bluenviron/mediamtx:latest
curl -L -o sample.mp4 https://github.com/intel-iot-devkit/sample-videos/raw/master/people-detection.mp4
for i in 1 2 3 4; do
  ffmpeg -loglevel error -re -stream_loop -1 -i sample.mp4 -c copy -f rtsp rtsp://localhost:8554/cam$i &
done
```

### Step 2 — Export the detector to TensorRT

```bash
pip install ultralytics opencv-python
yolo export model=yolo11n.pt format=engine half=True batch=8 imgsz=640 dynamic=True   # builds yolo11n.engine
# no NVIDIA GPU: format=onnx and use the .onnx file below (CPU; expect ~10x lower throughput)
```

### Step 3 — The multi-stream detector

```python
# detector.py: latest-frame buffers, batch across streams on a fixed tick, JSON events, metrics
import json, sys, threading, time
import cv2
from ultralytics import YOLO

URLS = [f"rtsp://localhost:8554/cam{i}" for i in range(1, int(sys.argv[1]) + 1)]
TICK = 0.1                                         # 10 inferences per second per stream
slots = {u: None for u in URLS}                    # latest (capture_time, frame) only
drops = {u: 0 for u in URLS}
lock = threading.Lock()

def reader(url):
    cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
    while True:
        ok, frame = cap.read()
        if not ok:
            time.sleep(0.5); cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG); continue
        with lock:
            if slots[url] is not None:
                drops[url] += 1                    # overwritten before being processed: deliberate drop
            slots[url] = (time.time(), frame)

for u in URLS:
    threading.Thread(target=reader, args=(u,), daemon=True).start()

model = YOLO("yolo11n.engine", task="detect")
ages, n, t0 = [], 0, time.time()
with open("events.jsonl", "a") as out:
    while True:
        start = time.time()
        with lock:
            batch = [(u, slots[u]) for u in URLS if slots[u] is not None]
            for u, _ in batch:
                slots[u] = None
        if batch:
            results = model.predict([f for _, (_, f) in batch], imgsz=640, half=True, verbose=False, classes=[0])
            now = time.time()
            for (u, (ts, _)), r in zip(batch, results):
                ages.append(now - ts)
                out.write(json.dumps({"stream": u[-4:], "ts": ts, "persons": len(r.boxes),
                                      "infer_ms": round(r.speed["inference"], 1)}) + "\n")
            n += len(batch)
        if time.time() - t0 >= 10:
            ages.sort()
            print(f"streams={len(URLS)} processed_fps={n / (time.time() - t0):.1f} "
                  f"frame_age_p50={ages[len(ages) // 2] * 1000:.0f}ms p99={ages[int(len(ages) * .99)] * 1000:.0f}ms "
                  f"drops={sum(drops.values())}")
            ages, n, t0 = [], 0, time.time()
        time.sleep(max(0.0, TICK - (time.time() - start)))
```

### Step 4 — Scale and observe

```bash
python detector.py 1        # then 4, then 8 (start 4 more ffmpeg publishers for cam5..cam8)
nvidia-smi dmon -s u -d 2   # GPU utilization while it runs
tail -3 events.jsonl
```

Then set `TICK = 0.0` (process as fast as possible), and watch which resource saturates first.

**Expected results:**
- At 10 inferences/s per stream, `processed_fps` is ~10 × streams, and frame age p50 is ~60–120 ms. Drops are
  high by design (~20 of every 30 decoded frames), and frame age stays flat as you add streams.
- TensorRT FP16 YOLO11n inference is a few ms per batch of 4–8 on a T4/RTX-class GPU, so the GPU is mostly idle.
- With `TICK = 0.0` and 8 streams, CPU decode with OpenCV (one 1080p decode per thread) usually saturates
  before the GPU. That's the measured reason to move decode to NVDEC (DeepStream or PyNvVideoCodec).
- If you replace the latest-frame slot with an unbounded queue, frame age climbs steadily as soon as
  inference can't keep up. Try it once to see why real-time systems drop frames.

---

## FAANG deep-dive notes

**How big tech does it.** Large video platforms (content moderation, retail analytics, autonomous
fleets, smart cities) run zero-copy GPU pipelines with hardware decode, cross-stream batching, and tracking,
plan capacity in streams per accelerator, and push analysis to the edge wherever bandwidth or privacy
demands it. Training pipelines read sharded datasets with GPU decode, and active learning sends uncertain
and wrong predictions back to labeling. Model choice is driven by benchmarked latency on each target device.

**Staff review questions.**
- What's the bytes math (compressed, decoded, resized) per stream and for the fleet?
- What's the capacity unit, streams per GPU at what fps, measured end to end?
- What happens when inference falls behind, and what metric shows it?
- Where is decode, and do frames ever cross PCIe to the CPU?
- What leaves the edge, and how are privacy and retention handled?

**Interview question.** "Design a video analytics system for 5,000 retail cameras that counts people and
detects queues."

**Typical system-design prompt:** *Design people counting and queue detection for 500 stores with 10 cameras each
(1080p, 15 fps, H.264 ~2 Mbps), with alerts within 2 s, 30 days of event history, and clips kept only for
incidents.*

**1. Clarify first:** What inference rate is needed (people counting works at 2–5 fps)? What's the store uplink
bandwidth? Are there privacy rules (faces)? What happens when a store is offline? Are there existing on-site
servers?

**2. Back-of-envelope sizing:**
- Cloud-only: 5,000 × 2 Mbps = 10 Gbps of uplink, and decode for 5,000 streams. At ~70 1080p15 streams per
  NVDEC-equipped data-center GPU, that's ~70 GPUs for decode alone. Expensive.
- Inference: 5,000 × 5 fps = 25,000 images/s. A small INT8 detector does ~1,000 images/s per T4-class GPU, so ~25 GPUs.
  **Decode, not inference, is the bigger cost.**
- Edge: 10 cameras per store on one Jetson Orin NX-class box (decode 10 × 1080p15, detect at 5 fps), at ~$1k
  per store. Uplink is ~10 kbps of events per camera, plus clips on incidents.
- Storage: raw per-detection events at ~1 KB × 5 fps × 5,000 cameras = 25 MB/s ≈ 65 TB/month, which is too much. Aggregate
  at the edge to per-second counts per zone (~100 bytes per camera per second ≈ 1.3 TB/month), and keep raw events only briefly.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Where to analyze | Cloud | Edge | Edge when uplink, privacy, or latency matter. Cloud for verification and training |
| Detection rate | Every frame | 2–5 fps + tracking | The lowest rate that meets accuracy, with tracking for continuity |
| Decode | CPU | NVDEC | Hardware decode for more than a few streams per box |
| Overload behavior | Queue frames | Drop to latest | Drop and measure frame age. Never queue unbounded |
| Model | Larger, more accurate | Smaller + cloud verify | Small at the edge, with cascade verification for alerts that matter |

**4. Follow-up questions with crisp answers:**
- *How do you roll out a new model to 500 stores?* Staged OTA (1%, 10%, 100%), per-store health and accuracy
  checks against a sample of labeled clips, and automatic rollback.
- *How do you know accuracy holds in each store?* Periodically sample clips for human labeling, track per-store
  count error, and watch for drift (lighting, camera moved).
- *A store's uplink is down for 6 hours. What happens?* The edge keeps working, buffers events locally, and
  sends them on reconnect with idempotent ids. Dashboards show the store as delayed, not as zero people.
- *Why not run inference on every frame?* It costs 3–6× more compute for little gain, since tracking
  interpolates motion between detections.

**Debug this (common onsite question):** "Alerts are getting slower over the day. In the morning, latency is
under 1 s, and by evening it's over a minute, and the service restarts nightly fix it."
1. Measure frame age (now − capture timestamp) per stream, not just inference time. Frame age grows linearly
   during busy hours.
2. Inspect the pipeline: decoded frames go into an unbounded `queue.Queue` per stream. When the store gets
   busy, the tracker slows (more objects), and processing falls below the arrival rate.
3. Memory also grows by ~6 MB per queued frame, which is why the nightly restart "fixes" it.
4. Fix: latest-frame buffers (leaky queue size 1), drop metrics, a frame-age SLO and alert, and capacity
   testing at peak object counts.

The lesson: in real-time systems, a growing queue is a bug, not a buffer. Bound queues, drop deliberately,
and use frame age as the latency SLO.

**5. What separates senior from staff answers:** a senior engineer builds a fast GPU pipeline with batching
and tracking. A staff engineer starts from the bytes and decode math, finds that decode and bandwidth (not
inference) dominate, places work across edge and cloud accordingly, defines frame age and per-site accuracy
SLOs, and designs the fleet rollout and active-learning loop.

**Red flags:**
- CPU decode for dozens of streams.
- Unbounded frame queues.
- Model choice by FLOPs or parameter count.
- Raw video streamed to the cloud by default.
- Millions of small image files read individually during training.
- No privacy handling for faces and plates.

---

## Quiz

<details><summary>1. How large is a decoded 1080p RGB frame, and why does it matter?</summary>
1920 × 1080 × 3 bytes ≈ 6.2 MB. At 30 fps that's 187 MB/s per stream, so decode must happen near the model
(ideally on the GPU) and frames must be resized immediately.
</details>

<details><summary>2. Why pack image datasets into shards?</summary>
Millions of small objects pay per-request latency on object storage. 100 MB–1 GB shards (WebDataset, TFRecord)
are read sequentially at high throughput and shuffle well with a buffer.
</details>

<details><summary>3. How do you tell whether CV training is input-bound?</summary>
Compare throughput with synthetic data vs real data, and measure data-wait time per step. A large gap or a
high wait means the pipeline (decode, augmentation, I/O) is the bottleneck.
</details>

<details><summary>4. Why can EfficientNet be slower than ResNet-50 on a GPU despite fewer FLOPs?</summary>
Depthwise convolutions and squeeze-excitation layers have low arithmetic intensity, so they're
memory-bound on GPUs. Higher input resolution adds cost too. Latency depends on hardware and kernels, not FLOPs alone.
</details>

<details><summary>5. What is a latest-frame buffer, and why use it?</summary>
A one-slot buffer per stream that always holds the newest frame, so older frames are overwritten and
dropped. It keeps latency bounded when inference can't keep up, instead of letting queues grow.
</details>

<details><summary>6. What does nvstreammux do in DeepStream?</summary>
It forms a batch from frames of multiple sources (with a timeout for slow sources), so the inference
plugin runs one batched TensorRT call for all streams.
</details>

<details><summary>7. Why pair a lower detection rate with a tracker?</summary>
Detecting every 3rd frame cuts compute ~3×, and the tracker keeps object IDs and positions on the frames
in between, with little loss of quality for typical motion.
</details>

<details><summary>8. Give three reasons to process video at the edge.</summary>
Uplink bandwidth and cost (events instead of raw video), latency for local actions, privacy (pixels stay on
site), and continued operation when the network is down.
</details>

## Failure modes
- Training data stored as millions of small files, starving GPUs.
- CPU decode and augmentation saturated while GPUs idle.
- Models chosen by FLOPs, then missing latency targets on real hardware.
- Unbounded frame queues that make latency grow over the day.
- Per-stream batch-1 inference with frames copied through the CPU.
- On-screen drawing left enabled in production pipelines.
- Raw video streamed to the cloud by default.
- Edge fleets without staged rollouts, rollback, or telemetry.
- Faces and plates stored and shared without blurring or retention limits.

## Checklist
- [ ] You can do the bytes math for compressed, decoded, and resized frames
- [ ] Your training data is sharded, and you measured synthetic vs real input throughput
- [ ] You can move decode and augmentation to the GPU with DALI
- [ ] You choose CV models by measured latency at a budget on the target hardware
- [ ] You use latest-frame buffers, cross-stream batching, and tracking in real-time services
- [ ] You can read and modify a DeepStream pipeline config
- [ ] You can split a video system between edge and cloud with bandwidth math
- [ ] You ran the multi-stream detector lab and measured fps, frame age, and drops
