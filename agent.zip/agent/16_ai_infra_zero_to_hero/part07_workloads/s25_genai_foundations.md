# Section 25 — Generative AI Infrastructure Foundations

> Lectures 169–175 • Assessments: quiz, [Present a production RAG infrastructure design](#assessment--present-a-production-rag-infrastructure-design),
> [Build permission-aware RAG retrieval](#assessment--build-permission-aware-rag-retrieval) • Exercise: [`s25_permission_rag.py`](../exercises/s25_permission_rag.py)
> **After this section you can:** explain why LLMs stress infrastructure differently (prefill vs decode,
> memory bandwidth, KV cache), size weights, KV cache, and storage for a model, choose and tune a vector
> database, build a RAG pipeline with permission-aware retrieval and evaluation, design safe caches (prefix,
> response, semantic), and serve LLMs in production with vLLM or TensorRT-LLM behind a gateway.
>
> Go deeper: [13 / Lab 08 — Local vLLM sandbox](../../13_sovereign_ai_infra_course/01_foundations_local_sandbox/lab08_local_vllm_sandbox.md),
> [Lab 47 — KV cache optimization](../../13_sovereign_ai_infra_course/04_serving_inference/lab47_kv_cache_optimization.md),
> [Lab 61 — Vector DB topologies](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab61_vector_db_topologies.md),
> [Lab 60 — Redis for AI](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab60_redis_for_ai.md),
> [Lab 79 — Rate limiting and token throttling](../../13_sovereign_ai_infra_course/06_agentic_mcp/lab79_rate_limiting_token_throttling.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 169 | Infrastructure challenges of LLMs | Prefill is compute-bound, decode is memory-bandwidth-bound, and the KV cache decides how many users fit |
| 170 | Memory and storage needs of LLMs | Weights = params × bytes. KV cache = 2 × layers × KV heads × head dim × bytes, per token |
| 171 | Vector databases: FAISS, Pinecone, Weaviate | Pick an index (HNSW, IVF-PQ) for your recall, latency, and memory budget, and filter inside the search |
| 172 | RAG pipelines | Ingest with ACLs, retrieve hybrid, rerank, ground with citations, and evaluate retrieval and answers separately |
| 173 | Caching strategies for LLMs | Prefix caching is free speed. Response and semantic caches need keys that include model, prompt, and permissions |
| 174 | Serving LLMs in production | vLLM or TensorRT-LLM with continuous batching, behind a gateway, autoscaled on queue depth and TTFT |
| 175 | Lab: deploy a simple RAG pipeline | Qdrant + embeddings + vLLM + FastAPI, with permission filters, citations, and a small eval set |

```mermaid
flowchart LR
  subgraph ING["Ingestion (offline)"]
    SRC["Docs, wikis, tickets<br/>with ACLs"] --> PARSE["Parse + chunk"]
    PARSE --> EMB["Embedding model<br/>GPU batch"]
    EMB --> VDB[("Vector DB<br/>vectors + ACL metadata")]
  end
  subgraph QRY["Query path (online)"]
    U["User + identity"] --> GW["LLM gateway<br/>auth, quotas, routing"]
    GW --> RET["Retrieve<br/>ACL pre-filter, hybrid"]
    RET --> RR["Rerank"]
    RR --> PR["Prompt assembly<br/>budget + citations"]
    PR --> LLM["LLM server<br/>vLLM or TensorRT-LLM"]
    LLM --> GW
  end
  VDB --> RET
  CACHE[("Caches<br/>prefix, response, embedding")] -.-> GW
  CACHE -.-> LLM
  EVAL["Evals<br/>offline suites + online sampling"] -.-> RET
  EVAL -.-> LLM
```

**How to read it:** offline, documents are parsed, chunked, embedded on GPUs, and indexed together with
their access-control metadata. Online, a request passes a gateway (identity, quotas, model routing),
retrieves only chunks the user may read, reranks them, assembles a prompt within a token budget, and
generates on a GPU serving engine. Caches cut cost and latency at several layers. Evaluations watch
retrieval quality and answer quality continuously.

**Terms in this diagram.**
- **ACLs**: access control lists, which record who may read each document. They're copied onto every chunk so search
  results respect them.
- **Parse + chunk**: extract plain text from PDFs, internal wikis, web pages, and support tickets, then split it into passages of a few
  hundred tokens each (Lecture 172).
- **Embedding model, GPU batch**: a model that turns each chunk into a vector of numbers capturing its meaning, run on
  GPUs in large batches.
- **Vector DB**: a database that finds the stored vectors closest to a query vector (Lecture 171).
- **LLM gateway: auth, quotas, routing**: the single entry point that checks identity, enforces token limits per
  user or team, and chooses the model (Lecture 174).
- **ACL pre-filter, hybrid**: the search only considers chunks the user may read. **Hybrid** search combines vector
  similarity with keyword search.
- **Rerank**: a more accurate but slower model re-scores the top candidates.
- **Prompt assembly: budget + citations**: the selected chunks are placed into the prompt within a **token budget**,
  and labeled so the answer can **cite** its sources.
- **vLLM or TensorRT-LLM**: the two most common high-throughput LLM serving engines (Lecture 174).
- **Prefix, response, embedding caches**: reuse of work at three levels (Lecture 173).
- **Evals, offline suites + online sampling**: automated quality tests on a fixed question set before release, and
  grading a sample of live answers.

---

## Lecture 169 — Infrastructure challenges of large language models

**Why it matters.** LLMs break assumptions from classic model serving. Requests run for seconds, not
milliseconds. Output is generated token by token. Memory, not compute, is often the bottleneck, and one
model can need several GPUs. Designs that ignore this waste most of an expensive GPU fleet.

**In plain words.** Answering a question has two phases. First the model reads the whole prompt at once,
like skimming a page (prefill: lots of math, done in parallel). Then it writes the answer one word at a
time, re-reading its notes for each word (decode: little math per word, but every word needs all the
weights moved from memory). Different phases, different bottlenecks.

**Architecture: where time and memory go in one request.**

```mermaid
flowchart LR
  REQ["Request<br/>2,000 prompt tokens"] --> Q["Queue<br/>waiting for a batch slot"]
  Q --> PF["Prefill<br/>all prompt tokens in parallel<br/>compute-bound"]
  PF --> KV[("KV cache<br/>grows per token")]
  PF --> D1["Decode step 1<br/>first token = TTFT"]
  D1 --> DN["Decode steps 2..N<br/>one token each<br/>memory-bandwidth-bound"]
  KV <--> DN
  DN --> OUT["Streamed tokens<br/>TPOT per token"]
```

**How to read it:** time to first token (TTFT) is queueing plus prefill. After that, each output token
costs one decode step, which reads all weights and the growing KV cache from GPU memory. The KV cache
lives as long as the request, so long prompts and long answers hold GPU memory for many seconds.

**Terms in this diagram.**
- **Prompt tokens**: the input text split into tokens (word pieces, about 0.75 English words each).
- **Batch slot**: the serving engine runs many requests together, and a request waits until there's room for it.
- **Prefill, compute-bound**: the first phase processes all prompt tokens at once. It's **compute-bound**, limited by
  the GPU's arithmetic speed.
- **KV cache**: for every token processed, each attention layer stores a **key** and a **value** vector, so later
  tokens don't recompute them. It grows by one entry per token.
- **Decode, memory-bandwidth-bound**: the second phase generates one token per step. Each step must read every
  weight from GPU memory to produce a single token, so speed is limited by **memory bandwidth** (bytes per second),
  not arithmetic.
- **TTFT, TPOT**: **TTFT** (time to first token) is the wait before the answer starts. **TPOT** (time per output
  token) is the gap between later tokens, which sets the streaming speed.

**Core ideas.**
- **Metrics.** TTFT, time per output token (TPOT, also called inter-token latency), end-to-end latency,
  throughput in tokens per second, and *goodput* (throughput that meets the latency SLO).
- **Prefill vs decode.** Prefill costs ~2 × params FLOPs per prompt token and saturates compute. Decode at
  small batch is limited by memory bandwidth: an upper bound is bandwidth ÷ bytes read per step. For an 8B
  model in FP16 (16 GB) on an H100 (~3.35 TB/s), that's at most ~200 tokens/s for one sequence. Batching
  many sequences reuses each weight read, which is why continuous batching matters.
- **The KV cache** decides concurrency. Free GPU memory after weights ÷ KV bytes per sequence = max
  concurrent sequences.
- **Model size.** 70B+ models need tensor parallelism across GPUs (fast NVLink within a node).
- **Cost** is per token, and varies 10–100× with model choice, so routing to the smallest adequate model is
  the biggest lever.
- **Quality and safety** need evals, guardrails, and audit logs, which are infrastructure too.

**Example: the GPU that was "busy" but slow.** A team served a 13B model with batch size 1 per request.
GPU utilization showed 95%, yet throughput was 40 tokens/s per GPU. Decode was reading 26 GB of weights per
token for a single sequence. Switching to vLLM with continuous batching served 60 concurrent sequences at
~25 tokens/s each, which is ~1,500 tokens/s per GPU, a 37× gain on the same hardware.

**Senior / FAANG best practice.** Track TTFT and TPOT separately with SLOs, measure goodput rather than raw
throughput, size concurrency from KV cache memory, batch continuously, and route each request to the smallest
model that passes your evals. Treat the GPU memory budget (weights + KV + activations) as the primary
capacity number.

---

## Lecture 170 — Memory and storage needs of LLMs

**Why it matters.** Whether a model fits on one GPU, how many users it serves, how fast it cold-starts, and
what a checkpoint costs to store are all simple arithmetic. Engineers who can't do this math pick the
wrong GPUs.

**In plain words.** A GPU's memory is a desk. The model's weights take up most of it permanently. Each
conversation needs its own notepad (the KV cache) that grows with every word. The number of notepads that
fit on the rest of the desk is the number of users you can serve at once.

**Architecture: an 80 GB GPU serving an 8B model.**

```mermaid
flowchart LR
  subgraph GPU["H100 80 GB"]
    W["Weights FP16<br/>16 GB"]
    ACT["Activations + runtime<br/>~4 GB"]
    KVP["KV cache pool<br/>~52 GB at 0.9 utilization"]
  end
  KVP --> S["128 KB per token<br/>8k context = 1 GiB per sequence"]
  S --> C["~48 concurrent 8k sequences<br/>or ~190 at 2k"]
  DISK[("Model files<br/>safetensors on NVMe")] -->|"load 16 GB at ~2-5 GB/s"| W
  OBJ[("Object storage<br/>model registry")] -->|"pre-pull to node cache"| DISK
```

**How to read it:** the weights take a fixed slice. The serving engine reserves most of what's left as
a KV cache pool, which it hands out in blocks. Dividing the pool by per-sequence KV size gives concurrency.
Model files are pulled from object storage to fast local disk before the pod starts, so cold starts are
seconds, not minutes.

In the diagram, the numbers are for an 8-billion-parameter model: 8 billion × 2 bytes in **FP16** = 16 GB of weights.
**Activations + runtime** is temporary working memory plus the CUDA libraries. **0.9 utilization** is vLLM's
`gpu_memory_utilization` setting, which lets the engine use 90% of the 80 GB. **128 KB per token** is the KV cache size
per token for this model. At an **8k context** (8,192 tokens), that's 1 GiB per sequence, so about 48 sequences fit
at once, or about 190 if each uses only 2k tokens. **Safetensors** is a safe, fast file format for weights, which can
be memory-mapped straight from disk. **NVMe** is fast local SSD. To **pre-pull to node cache** means copying files
onto the node before the pod needs them.

**Core ideas.**
- **Weights:** params × bytes per param. FP16/BF16 = 2, FP8/INT8 = 1, INT4 ≈ 0.5 (plus small scales).
  So 8B FP16 = 16 GB, 70B FP16 = 140 GB, 70B FP8 = 70 GB, and 70B INT4 ≈ 35–40 GB.
- **KV cache per token** = 2 (K and V) × layers × KV heads × head dim × bytes.
  - Llama 3 8B (32 layers, 8 KV heads with GQA, head dim 128, FP16): 2 × 32 × 8 × 128 × 2 = 128 KB per token.
  - Llama 3 70B (80 layers, 8 KV heads, 128): 320 KB per token, so 8k tokens ≈ 2.5 GiB per sequence.
  - Grouped-query attention (GQA) is why modern models are 4–8× smaller in KV than older multi-head designs.
    An FP8 KV cache halves it again.
- **Training memory** is ~16 bytes per param for mixed-precision Adam before activations (Section 7), which is
  why training needs far more GPUs than serving.
- **Storage.** Checkpoints with optimizer state are ~6–8× the weights. Use safetensors, versioned in a
  registry. For fast cold starts, pre-pull to node-local NVMe, use a shared read-through cache, or stream
  weights directly into GPU memory with a model streamer.

```bash
# quick KV math in the shell: tokens of context you can hold in 52 GB for Llama 3 8B FP16
python3 -c "kv=2*32*8*128*2; print(kv//1024,'KB/token', int(52e9/kv),'tokens total')"
# -> 128 KB/token 396728 tokens total  (e.g. ~48 sequences of 8k, or ~190 of 2k)
```

**Example: the 70B that "fit".** A team put Llama 3 70B FP8 (70 GB) on one 80 GB H100. It loaded, but
only ~6 GB remained for the KV cache, about 2 sequences at 8k context, so latency collapsed under load.
Moving to 2 × H100 with tensor parallelism gave ~68 GB of KV pool (~26 sequences of 8k), and per-token latency
also dropped because each GPU read half the weights. An FP8 KV cache doubled concurrency again.

**Senior / FAANG best practice.** Do the weights and KV arithmetic before picking hardware, budget at
least as much memory for KV as for weights for interactive workloads, use GQA models plus FP8 weights and KV
where evals allow, and engineer cold starts: pre-pulled weights, readiness probes that wait for warmup,
and a model cache per node.

---

## Lecture 171 — Vector databases: FAISS, Pinecone, Weaviate

**Why it matters.** Retrieval quality and latency in RAG come from the vector index. Recall, memory, filter
behavior, and update speed vary widely by index type and product, and a wrong choice either misses relevant
documents or costs 10× more memory than needed.

**In plain words.** Finding the most similar vectors among 100 million is like finding the closest houses
on a map without measuring the distance to every house. HNSW builds a network of shortcuts between
neighbors. IVF sorts houses into neighborhoods and only searches the nearest few. PQ shrinks each address
to a short code so many more fit in memory.

**Architecture: index choices and where they live.**

```mermaid
flowchart LR
  Q["Query vector"] --> F{"Metadata filter<br/>tenant, ACL, date"}
  F --> IDX{"Index type"}
  IDX --> FLAT["Flat<br/>exact, O(N)"]
  IDX --> HNSW["HNSW graph<br/>high recall, RAM heavy"]
  IDX --> IVF["IVF + PQ<br/>compressed, tunable nprobe"]
  IDX --> DISK["Disk-based ANN<br/>DiskANN-style, SSD"]
  HNSW --> TOPK["Top-k candidates"]
  IVF --> TOPK
  FLAT --> TOPK
  DISK --> TOPK
  TOPK --> RR["Rerank with full vectors<br/>or a cross-encoder"]
```

**How to read it:** metadata filters narrow the search first. The index then finds approximate
neighbors: Flat is exact but slow at scale, HNSW gives high recall with lots of RAM, IVF-PQ compresses
heavily with tunable recall, and disk-based indexes trade some latency for much lower memory. A rerank step
fixes ordering errors from approximation.

**Terms in this diagram.**
- **Metadata filter: tenant, ACL, date**: restrict results by customer (**tenant**), by permission (**ACL**), or by
  date, before or during the vector search.
- **Flat, exact, O(N)**: compares the query with every stored vector. **O(N)** means the time grows in proportion to
  the number of vectors, which is fine for thousands but too slow for billions.
- **HNSW graph, high recall, RAM heavy**: **HNSW** (hierarchical navigable small world) links each vector to its
  near neighbors in a layered graph and walks it toward the query. **Recall** is the share of the true nearest
  neighbors it finds. The graph and the full vectors must sit in RAM.
- **IVF + PQ, tunable nprobe**: **IVF** (inverted file index) groups vectors into clusters and searches only the
  closest few. **nprobe** is how many clusters to search, so more means better recall but slower. **PQ** (product
  quantization) compresses each vector into a few bytes.
- **Disk-based ANN, DiskANN-style, SSD**: **ANN** means approximate nearest neighbor. **DiskANN** keeps the graph on
  SSD and only a compressed copy in RAM.
- **Top-k candidates**: the `k` best matches, for example 50.
- **Cross-encoder**: a model that reads the query and a document *together* and scores their relevance. It's more
  accurate than comparing separate vectors, but too slow to run on everything.

**Core ideas.**

| Option | What it is | Strengths | Watch out for |
|---|---|---|---|
| FAISS | A library (Meta) | Fastest building blocks, GPU indexes, full control | No server, replication, or filtering service. You build those |
| Pinecone | Managed, serverless | No operations, scales storage and queries separately | Data residency, cost at high QPS, vendor lock-in |
| Weaviate | Open-source DB | Hybrid search (BM25 + vectors), multi-tenancy, modules | You operate it (or use the managed cloud) |
| Others | Milvus, Qdrant, pgvector, OpenSearch, Redis | Milvus scales out, Qdrant has strong filtering, pgvector fits existing Postgres | Varies by product |

- **Memory math.** 10 M vectors × 1,024 dims × 4 bytes = 41 GB raw. HNSW adds the graph (M = 16 means ~32
  neighbor ids per vector, roughly 128–256 bytes). INT8 quantization makes the vectors 10 GB. PQ at 64 bytes
  makes them 0.64 GB, with a rerank on full vectors to recover recall.
- **Tuning.** HNSW `M` and `ef_construction` set build quality, and `ef_search` trades latency for recall.
  IVF uses `nlist` and `nprobe`. Always measure recall@k against exact search on a sample.
- **Filtering.** Filter inside the search (pre-filter). Post-filtering top-k results returns too few, as the
  exercise shows. Very selective filters may need per-tenant indexes or partitions.
- **Hybrid search.** Combining BM25 keyword and dense scores (for example with reciprocal rank fusion)
  fixes misses on names, codes, and rare terms.
- **Operations.** Replicas for QPS, shards for size, snapshots and backups (Lab 68 in course 13), and
  re-embedding plans when the embedding model changes (old and new vectors aren't comparable).

**Example: recall vs cost.** A 50 M-chunk index on HNSW FP32 needed ~250 GB of RAM across replicas. The team
measured recall@10 against exact search at 0.97. Switching to INT8 vectors with a rescoring pass kept recall
at 0.96 and cut memory to ~70 GB, from six large memory nodes to two.

**Senior / FAANG best practice.** Choose the index from measured recall@k, p99 latency, and memory on your
own data, not benchmarks. Filter in the search and partition by tenant where needed. Use hybrid retrieval
and reranking, version embeddings with the index (re-embed with dual indexes and a cutover), and back up
the index like a database.

---

## Lecture 172 — RAG (retrieval-augmented generation) pipelines

**Why it matters.** RAG grounds LLM answers in your own, current documents without retraining, and it's
the most common enterprise GenAI architecture. Most RAG failures are retrieval and data failures, such as
bad chunking, missed documents, stale indexes, or permission leaks, rather than model failures.

**In plain words.** RAG is an open-book exam. Before answering, the model gets the few pages most likely
to contain the answer, and it must cite them. If you hand it the wrong pages, or pages the student isn't
allowed to see, the answer will be wrong or a leak, however smart the student is.

**Architecture: ingestion and query paths with evaluation.**

```mermaid
flowchart LR
  subgraph IN["Ingestion"]
    CDC["Source changes<br/>CDC or webhooks"] --> PAR["Parse<br/>PDF, HTML, tables"]
    PAR --> CH["Chunk<br/>300-800 tokens, overlap"]
    CH --> META["Attach metadata<br/>tenant, ACL, source, version"]
    META --> EM["Embed"]
    EM --> IX[("Index<br/>vectors + BM25")]
  end
  subgraph QP["Query"]
    QU["Question + user identity"] --> RW["Rewrite or expand<br/>optional"]
    RW --> HY["Hybrid retrieve<br/>ACL pre-filter"]
    HY --> RK["Cross-encoder rerank<br/>top 50 to top 5"]
    RK --> GEN["Generate with citations<br/>or say insufficient"]
  end
  IX --> HY
  GEN --> LOG["Log question, chunks,<br/>answer, feedback"]
  LOG --> EV["Evals<br/>retrieval recall, faithfulness"]
```

**How to read it:** ingestion keeps the index current through change events, and stores permission and
version metadata with every chunk. Queries retrieve broadly with hybrid search under an ACL filter, rerank to
a few chunks, and generate an answer that cites them, or refuse when the context doesn't support an
answer. Everything is logged so retrieval and generation can be evaluated separately.

In the diagram, **CDC or webhooks** are the ways sources announce changes: change data capture from a database
(Section 24), or a **webhook**, an HTTP call the source system makes to you when something changes. A chunk
**overlap** repeats a few sentences between neighboring chunks, so an idea split across a boundary isn't lost.
**BM25** is the classic keyword-ranking formula used by search engines. Storing it next to vectors enables hybrid
search. **Rewrite or expand** means rephrasing the question, or adding synonyms, to improve retrieval. **Say
insufficient** means the model answers "I don't have enough information" instead of guessing. **Faithfulness**
measures whether every claim in the answer is supported by the retrieved chunks.

**Core ideas.**
- **Chunking.** Use structure-aware splitting (headings, tables) of ~300–800 tokens with some overlap, and
  keep titles and section paths as context. Bad chunking causes most retrieval misses.
- **Permission-aware retrieval.** Chunks inherit document ACLs. Groups are tenant-scoped, user groups are
  resolved at query time (so revocation is immediate), documents without an ACL are denied, and the filter
  runs inside the search. In the assessment exercise, naive retrieval leaked 30 forbidden chunks across 12
  queries, and post-filtering safely returned nothing for Alice's salary question while pre-filtering
  returned three allowed chunks.
- **Grounding.** Instruct the model to answer only from context, cite chunk ids, and say "insufficient
  context" otherwise. Add a relevance threshold so weak matches aren't treated as evidence.
- **Freshness.** Stream document changes (Kafka, Lab 63 in course 13) to re-embed and upsert within minutes,
  and delete promptly. A deleted document that's still retrievable is a compliance incident.
- **Evaluation.** Measure retrieval (recall@k and MRR on a labeled set of question-to-source pairs) separately
  from generation (faithfulness to context, answer relevance, citation accuracy). LLM-as-judge scoring
  scales this, but calibrate the judge against human labels on a sample and re-check it when the judge model
  changes. RAGAS-style metrics, `mlflow.evaluate`, and tracing tools help. Gate releases on a fixed golden set
  and sample production traffic weekly.

**Example: the confident wrong answer.** An HR assistant told employees the parental leave was 12 weeks.
The policy had changed to 20 weeks a month earlier, but the old PDF remained in the index next to the new
one, and both chunks were retrieved. Fixes: index document versions with a `superseded` flag
filtered at query time, prefer the newest effective date in reranking, and add a freshness eval with
questions on recently changed policies.

**Senior / FAANG best practice.** Treat RAG as a search system plus a generator. Invest in parsing,
chunking, hybrid retrieval, and reranking first, enforce permissions in retrieval (never in the prompt),
keep the index fresh and deletions immediate, and evaluate retrieval and generation separately with a golden
set in CI and production sampling.

---

## Lecture 173 — Caching strategies for LLMs

**Why it matters.** LLM calls are slow and expensive, and many requests repeat work: the same system
prompt, the same documents, the same questions. Caching can cut cost and latency by 2–10×, and a careless
cache can serve wrong or unauthorized answers.

**In plain words.** A chef who makes the same sauce base every morning saves time on every dish (prefix
cache). Keeping finished dishes for repeat orders is faster still (response cache), but you must not hand
someone's custom order, or their private meal, to the next customer who asks for something similar
(semantic cache risk).

**Architecture: cache layers.**

```mermaid
flowchart LR
  R["Request"] --> RC{"Response cache<br/>exact key"}
  RC -->|"hit"| OUT["Answer"]
  RC -->|"miss"| SC{"Semantic cache<br/>similar question,<br/>same permissions"}
  SC -->|"hit above threshold"| OUT
  SC -->|"miss"| EC["Embedding cache<br/>query and chunk vectors"]
  EC --> RET["Retrieval"]
  RET --> PC["Prefix cache in the engine<br/>reuse KV of shared prefix"]
  PC --> LLM["Generate"]
  LLM --> OUT
  LLM --> RC
```

**How to read it:** the cheapest check comes first. An exact response cache hit returns immediately. A
semantic cache can return an answer to a sufficiently similar question, but only within the same permission
scope. Otherwise the request proceeds with cached embeddings, and inside the serving engine the KV cache for
a shared prompt prefix is reused, so prefill only processes the new tokens.

In the diagram, an **exact key** is built from the full normalized request and the model version, so only identical
requests match. **Similar question, same permissions** means the semantic cache compares question embeddings, and
only returns answers created for users with the same access rights. Otherwise it could leak another user's private
information. **Above threshold** means the similarity score passes a tuned cut-off, such as 0.95. A **shared prefix**
is the identical beginning of many prompts, such as the system instructions.

**Core ideas.**

| Cache | Saves | Key must include | Risk |
|---|---|---|---|
| Prefix (KV) cache | Prefill compute and TTFT | Exact token prefix (automatic in vLLM, SGLang, provider APIs) | None for correctness. Order prompts static-first to get hits |
| Exact response cache | The whole call | Model + version, system prompt version, params, user scope, normalized input | Stale answers after document or model changes |
| Semantic cache | The whole call for paraphrases | Embedding similarity + model + prompt version + ACL fingerprint | Wrong answers for "similar but different" questions, and permission leaks |
| Embedding cache | Embedding calls | Embedding model version + text hash | Mixing model versions |
| Retrieval cache | Vector DB calls | Query + filters + index version | Stale results |

- **Prompt layout for prefix hits.** Put the system prompt, tool definitions, and shared documents first, and
  user-specific content last. One timestamp at the top of the prompt destroys the hit rate.
- **Invalidation.** Use TTLs plus explicit invalidation on document updates, index rebuilds, and model or
  prompt changes (include their versions in the key, so old entries simply stop matching).
- **Semantic thresholds.** Tune the similarity threshold on labeled pairs. "How do I reset my password?" vs
  "How do I reset someone else's password?" are close in embedding space and need different answers.
- **Where.** Redis is the usual cache store, with vector search for semantic caching (Lab 60 in course 13).

**Example: the cache that leaked salaries.** In the exercise, Bob (HR) asks about salary bands first. With a
cache keyed only by the normalized question, Alice (engineering) gets Bob's cached answer, built from HR-only
chunks. Keying by (question, ACL fingerprint) gives Alice her own, correctly limited answer. The same bug in
a semantic cache is worse, because paraphrases also hit.

**Senior / FAANG best practice.** Get prefix caching right first, since it's free and safe. Add response and
semantic caches only with keys that include model version, prompt version, and the user's permission scope,
measure hit rate *and* correctness on labeled samples, and invalidate on document, index, model, and prompt
changes.

---

## Lecture 174 — Serving LLMs in production

**Why it matters.** Production LLM serving combines a high-throughput engine, a gateway for identity,
quotas, routing, and safety, autoscaling on the right signals, and evals and observability. Get any of these
wrong and you pay for idle GPUs, or users see timeouts.

**In plain words.** The serving engine is the kitchen, packing as many orders into each oven cycle as fit
(continuous batching). The gateway is the front desk: it checks who you are, how much you may order,
which kitchen to send you to, and keeps the receipts.

**Architecture: a production LLM platform.**

```mermaid
flowchart LR
  APP["Apps and agents"] --> GW["LLM gateway<br/>auth, token quotas, routing,<br/>PII redaction, audit log"]
  GW -->|"simple tasks"| SM["Small model pool<br/>8B, vLLM"]
  GW -->|"hard tasks"| LG["Large model pool<br/>70B TP=2, TensorRT-LLM or vLLM"]
  GW -->|"fallback"| EXT["External API<br/>if policy allows"]
  SM --> MET["Metrics: TTFT, TPOT, queue,<br/>KV cache usage, tokens"]
  LG --> MET
  MET --> AS["Autoscaler<br/>KEDA or HPA on queue depth"]
  AS --> SM
  AS --> LG
  GW --> GR["Guardrails<br/>input and output checks"]
  GW --> EV["Eval sampling<br/>quality dashboards"]
```

**How to read it:** all traffic goes through the gateway, which enforces identity and token budgets,
routes each request to the smallest adequate model pool, and logs everything for audit and evaluation.
Engines expose LLM-specific metrics, and the autoscaler uses queue depth and KV usage, not CPU, to add or
remove replicas.

**Terms in this diagram.**
- **Agents**: programs where an LLM plans and calls tools in several steps (Section 26).
- **Token quotas**: limits on how many tokens each user or team may consume per minute or month.
- **PII redaction, audit log**: personal data is removed or masked from prompts before they reach models or logs, and
  every request is recorded for security reviews (Section 18).
- **8B, 70B TP=2**: model sizes of 8 and 70 billion parameters. **TP=2** means **tensor parallelism** across 2 GPUs:
  each layer's matrices are split between them because the model doesn't fit on one (Section 8).
- **External API, if policy allows**: a hosted model from another company, used only for data classes permitted to
  leave your systems.
- **KV cache usage**: the fraction of the KV cache pool in use. Near 100%, new requests must wait.
- **KEDA or HPA on queue depth**: Kubernetes autoscalers driven by how many requests are waiting (Section 14).
- **Guardrails**: checks for prompt injection, unsafe content, and data leaks on the way in and out (Section 18).
- **Eval sampling**: grading a sample of live answers, with humans or a judge model, for quality dashboards.

**Core ideas.**
- **Engines.**
  - **vLLM**: PagedAttention (KV in blocks, near-zero fragmentation), continuous batching, prefix
    caching, multi-LoRA, an OpenAI-compatible API, and broad hardware support.
  - **TensorRT-LLM**: compiled engines with in-flight batching, paged KV cache, and FP8/INT4 kernels. It's often
    the fastest on NVIDIA hardware, at the cost of build steps (Lab 43 in course 13).
  - **SGLang**: strong prefix reuse (RadixAttention) and structured output.
  - Triton Inference Server or NVIDIA Dynamo can host and orchestrate these engines.
- **Scheduling features.** Chunked prefill (long prompts don't stall decodes), speculative decoding (a
  small draft model proposes tokens, Lab 48), and prefill/decode disaggregation onto separate GPU pools at
  large scale.
- **Autoscaling** on queue depth, running and waiting requests, KV cache utilization, or TTFT. GPU
  utilization is misleading, and CPU is meaningless here. Keep warm minimum replicas, since cold starts take minutes.
- **Gateway duties.** Authentication, per-team token rate limits and budgets (Lab 79), routing and fallback,
  retries with backoff for overload responses, PII redaction, guardrails, and full request and response
  audit logs with retention rules (Section 18). Agents also need egress allow-lists for the tools they call.
- **Evals as release gates.** Before a model, prompt, or engine change ships, run the golden-set eval
  (task accuracy, faithfulness, safety, format), then canary with online quality sampling (Section 10).

```bash
# vLLM: an 8B model with prefix caching and chunked prefill (OpenAI-compatible API on :8000)
vllm serve meta-llama/Llama-3.1-8B-Instruct --max-model-len 8192 --gpu-memory-utilization 0.90 \
  --enable-prefix-caching --enable-chunked-prefill --max-num-seqs 128
curl -s localhost:8000/metrics | grep -E "vllm:(num_requests_waiting|kv_cache_usage_perc|gpu_cache_usage_perc|time_to_first_token)"
# (newer vLLM versions report kv_cache_usage_perc, older ones gpu_cache_usage_perc)
```

**Example: autoscaling on the wrong signal.** An HPA scaled a vLLM deployment at 70% GPU utilization.
Utilization sat at 95–99% whether 10 or 120 requests were running, so the HPA added replicas at low load and
never told them apart from overload. Switching to KEDA on `vllm:num_requests_waiting` (scale out above 5
waiting per replica) kept TTFT p95 under 800 ms through peaks, with 30% fewer GPU-hours at night.

**Senior / FAANG best practice.** Run a continuous-batching engine with prefix caching behind a gateway
that owns identity, budgets, routing, and audit. Autoscale on queue and KV signals with warm minimums, route
by task to the smallest model that passes evals, and gate every model, prompt, and engine change on an
eval suite plus a canary.

---

## Lecture 175 — Lab: deploy a simple RAG pipeline

**Goal:** deploy a working RAG service: Qdrant as the vector store, a small embedding model, a vLLM (or
Ollama on CPU) generator, and a FastAPI `/ask` endpoint that filters by the caller's groups, cites sources,
refuses when evidence is weak, and passes a small evaluation set.

**What you're building.**

```mermaid
flowchart LR
  DOCS["docs/*.md<br/>with groups in front matter"] --> ING["ingest.py<br/>chunk, embed, upsert"]
  ING --> QD[("Qdrant<br/>vectors + payload groups")]
  USER["curl with X-User-Groups"] --> API["app.py FastAPI /ask"]
  API --> EMB["bge-small embeddings"]
  API --> QD
  API --> LLM["vLLM or Ollama<br/>OpenAI-compatible"]
  LLM --> API
  EVAL["eval.py<br/>10 golden questions"] --> API
```

**In plain words.** You build the smallest real RAG system: load documents with permissions, ask
questions as different users, and check with a tiny test set that answers are grounded and permissions hold.

**How to read the diagram:** each Markdown file in `docs/` lists which user groups may read it in its **front
matter**, the YAML block at the top of the file. `ingest.py` chunks the files, embeds them, and **upserts** them
(inserts, or replaces if already present) into **Qdrant**, an open-source vector database, which stores the groups
in each point's **payload** (its metadata). You call `/ask` with `curl`, passing your groups in the `X-User-Groups`
header to simulate different users. `app.py` embeds the question with **bge-small**, a small open embedding model,
searches Qdrant filtered to your groups, and asks the LLM. **vLLM** or **Ollama** (an easy local LLM runner) serves
the model through an **OpenAI-compatible** API, the same request format as OpenAI's. `eval.py` runs 10 **golden
questions**, each with a known correct answer and source.

### Step 1 — Start Qdrant and a model server

```bash
docker run -d --name qdrant -p 6333:6333 qdrant/qdrant:v1.12.4
# GPU: an OpenAI-compatible vLLM server
docker run -d --gpus all -p 8000:8000 vllm/vllm-openai:latest --model Qwen/Qwen2.5-1.5B-Instruct --max-model-len 8192
# CPU alternative: ollama serve & ollama pull qwen2.5:1.5b   (OpenAI-compatible API on :11434/v1)
pip install qdrant-client sentence-transformers fastapi uvicorn openai pyyaml
```

### Step 2 — Ingest documents with ACL metadata

```python
# ingest.py: each docs/*.md starts with front matter like:  ---\ngroups: [eng, all]\n---
import glob, re, uuid, yaml
from qdrant_client import QdrantClient, models
from sentence_transformers import SentenceTransformer
emb = SentenceTransformer("BAAI/bge-small-en-v1.5")              # 384 dims
qc = QdrantClient("localhost", port=6333)
if qc.collection_exists("kb"):
    qc.delete_collection("kb")
qc.create_collection("kb", vectors_config=models.VectorParams(size=384, distance=models.Distance.COSINE))
qc.create_payload_index("kb", "groups", models.PayloadSchemaType.KEYWORD)
points = []
for path in glob.glob("docs/*.md"):
    _, fm, body = open(path).read().split("---", 2)
    groups = yaml.safe_load(fm).get("groups") or []                 # no groups = nobody (deny by default)
    paras = [p.strip() for p in re.split(r"\n\s*\n", body) if p.strip()]
    for i, text in enumerate(paras):
        points.append(models.PointStruct(id=str(uuid.uuid5(uuid.NAMESPACE_URL, f"{path}#{i}")),
            vector=emb.encode(text, normalize_embeddings=True).tolist(),
            payload={"text": text, "source": f"{path}#{i}", "groups": [f"acme/{g}" for g in groups]}))
qc.upsert("kb", points)
print(f"indexed {len(points)} chunks")
```

### Step 3 — The `/ask` endpoint with a permission pre-filter

```python
# app.py
from fastapi import FastAPI, Header
from openai import OpenAI
from qdrant_client import QdrantClient, models
from sentence_transformers import SentenceTransformer
app, qc = FastAPI(), QdrantClient("localhost", port=6333)
emb = SentenceTransformer("BAAI/bge-small-en-v1.5")
llm = OpenAI(base_url="http://localhost:8000/v1", api_key="local")
MIN_SCORE = 0.55

@app.post("/ask")
def ask(q: dict, x_user_groups: str = Header(...)):      # in production: groups come from a verified token
    groups = [f"acme/{g.strip()}" for g in x_user_groups.split(",")]
    hits = qc.query_points("kb", query=emb.encode(q["question"], normalize_embeddings=True).tolist(), limit=5,
        query_filter=models.Filter(must=[models.FieldCondition(key="groups", match=models.MatchAny(any=groups))]),
    ).points
    hits = [h for h in hits if h.score >= MIN_SCORE]
    if not hits:
        return {"answer": "I don't have enough information you can access to answer that.", "sources": []}
    ctx = "\n".join(f"[{h.payload['source']}] {h.payload['text']}" for h in hits)
    r = llm.chat.completions.create(model="Qwen/Qwen2.5-1.5B-Instruct", temperature=0, max_tokens=300,
        messages=[{"role": "system", "content": "Answer only from the context and cite sources in [brackets]. "
                   "If the context does not answer the question, say so."},
                  {"role": "user", "content": f"Context:\n{ctx}\n\nQuestion: {q['question']}"}])
    return {"answer": r.choices[0].message.content, "sources": [h.payload["source"] for h in hits]}
```

```bash
uvicorn app:app --port 9000 &
curl -s localhost:9000/ask -H 'X-User-Groups: eng,all' -d '{"question":"What is the GPU quota?"}' -H 'content-type: application/json'
curl -s localhost:9000/ask -H 'X-User-Groups: eng,all' -d '{"question":"What are the salary bands?"}' -H 'content-type: application/json'
python3 exercises/s25_permission_rag.py        # the same rules, with leaks and cache pitfalls shown
```

### Step 4 — Evaluate

```python
# eval.py: golden set of (question, groups, expected source or None for "should refuse")
import json, urllib.request
GOLD = [("What is the GPU quota?", "eng,all", "docs/gpu.md"),
        ("What are the salary bands?", "eng,all", None),            # eng must not see HR content
        ("What are the salary bands?", "hr,all", "docs/salary.md"),
        ("When is the office closed?", "all", "docs/holidays.md")]   # extend to 10+
ok = 0
for q, g, src in GOLD:
    req = urllib.request.Request("http://localhost:9000/ask", json.dumps({"question": q}).encode(),
                                 {"content-type": "application/json", "X-User-Groups": g})
    r = json.load(urllib.request.urlopen(req))
    hit = (src is None and not r["sources"]) or (src and any(s.startswith(src) for s in r["sources"]))
    ok += bool(hit); print("PASS" if hit else "FAIL", q, g, r["sources"][:2])
print(f"retrieval/permission accuracy {ok}/{len(GOLD)}")
```

**Expected results:**
- Ingestion indexes every paragraph with group payloads. A document without `groups` is never returned.
- An engineering user asking about salary bands gets the refusal message and no HR sources. An HR user gets a
  cited answer.
- Answers cite `[docs/...#n]` sources that appear in `sources`. With the 1.5B model, roughly 80–90% of
  answers stay faithful on simple questions. Upgrading to a 7–8B model usually removes most remaining
  hallucinated details.
- `eval.py` passes all permission cases. Any retrieval failures point to chunking or the `MIN_SCORE`
  threshold. Tune it on the golden set, not by feel.
- TTFT on a GPU is roughly 100–300 ms for these short prompts. On CPU with Ollama, expect a few seconds.

---

## Assessment — Present a production RAG infrastructure design

**Scenario:** design the internal knowledge assistant for a 20,000-employee company in the EU. It covers
5 M documents (Confluence, SharePoint, tickets) with existing permissions, at a peak of 50 questions per second.
Targets are p95 TTFT < 1.5 s and answers with citations. Data must stay in the EU, permissions must never
leak, and the GPU budget is limited.

**Task:** prepare a 10-minute presentation (6–8 slides) and defend it in 10 minutes of questions.

**Suggested slide outline:**
1. Requirements and SLOs: users, QPS, latency, freshness (document changes visible within 15 minutes),
   residency, and "zero permission leaks".
2. Reference architecture (ingestion and query paths, as in the section diagram), with components named.
3. Sizing (show your math, as below).
4. Permission model: ACL sync from sources, tenant- and group-scoped metadata, query-time resolution,
   deny-by-default, permission-aware caches, deletion SLAs.
5. Quality: chunking, hybrid retrieval, reranking, refusal behavior, golden set, LLM-as-judge with human
   calibration, online feedback.
6. Operations: autoscaling signals, SLOs and alerts, model and prompt release process, DR, and cost.
7. Risks and roadmap.

**Back-of-envelope sizing to present:**
- Chunks: 5 M docs × ~8 chunks = 40 M chunks. With 1,024-dim FP32 vectors that's ~164 GB, or ~41 GB with
  INT8. Use 3 shards × 2 replicas on memory-optimized nodes, plus BM25.
- Initial embedding: 40 M × ~500 tokens = 20 B tokens. At ~30,000 tokens/s per mid-range GPU for a base-size
  embedding model, that's ~185 GPU-hours, about a day on 8 GPUs. Daily churn (~1%) is ~2 GPU-hours.
- Generation: 50 QPS × ~4,000 prompt tokens = 200,000 prefill tokens/s. With an 8B model (~16 GFLOP per token),
  that's 3.2 PFLOP/s, ~8 H100s at ~40% of peak for prefill. Decode is 50 × 300 output tokens = 15,000 tokens/s,
  with ~500 concurrent streams. Plan ~12–16 H100s at peak with headroom, autoscaled down off-peak.
  A 70B model would need ~9× the compute, so justify it with evals or route only hard questions to it.
- KV cache: 500 streams × ~4,300 tokens × 128 KB ≈ 280 GB across the pool, which fits in the free memory of
  16 GPUs. Prefix caching of the system prompt reduces prefill slightly. Response caching helps FAQs.

**Rubric:**

| Criterion | Strong | Weak |
|---|---|---|
| Requirements | Quantified SLOs, freshness, residency, leak target | "Fast and accurate" |
| Permissions | ACL metadata, query-time groups, pre-filter, permission-aware caches, deletion SLA | Filtering in the prompt or after retrieval |
| Sizing | Vector memory, embedding hours, prefill and decode compute, KV memory | GPU count guessed |
| Quality | Golden set, retrieval and generation metrics separate, calibrated judge, refusal | "We'll use the best model" |
| Operations | Queue-based autoscaling, warm pools, eval-gated releases, DR, cost per answer | Static fleet, no evals |
| Trade-offs | Model size vs cost, managed vs self-hosted vector DB under EU residency | One option, no alternatives |

**Questions the panel will ask:** How does a permission change in SharePoint reach the index, and how fast?
What happens when a document is deleted? Why this model size? What is your cost per answer? How do you know
answers are faithful? What happens if the vector DB is down?

---

## Assessment — Build permission-aware RAG retrieval

**Scenario:** a two-tenant corpus (acme, globex) of 12 documents and 24 chunks, with group ACLs. There are
four users: Alice (acme eng), Bob (acme hr), Dave (acme eng + finance), and Carol (globex eng). One legacy
document has no ACL.

**Task:** implement retrieval that never returns a chunk the user may not read, without losing recall.
Then show tenant scoping, deny-by-default, immediate revocation, a permission-aware cache, and a
token-budgeted prompt with citations.

```bash
python3 exercises/s25_permission_rag.py
python3 exercises/s25_permission_rag.py --user alice --query "salary bands for engineers" --mode naive
```

**Expected output:**

| Check | Result |
|---|---|
| Naive retrieval (no ACL) | Leaks 30 forbidden chunks across 4 users × 3 queries |
| Post-filter (top-k, then drop) | Safe, but 12 user/query pairs get fewer results. Alice's salary query returns nothing |
| Pre-filter (inside the search) | Safe, full top-3 where enough authorized chunks exist |
| Bare group names | Carol (globex) receives `acme-all-1`, `acme-all-2`. Tenant-scoped ACLs fix it |
| Deny by default | `acme-legacy` (no ACL) is never returned |
| Revocation | Dave loses `acme-fin-1` on the next query after leaving finance |
| Query-only cache key | Leaks Bob's HR chunks to Alice. Keying by (query, ACL fingerprint) fixes it |
| Prompt | 32 of 40 tokens used, citing only authorized chunks |

**What a strong answer explains:** permissions must be enforced in retrieval, because anything in the
prompt can end up in the answer, and instructions to the model are not a security control. Post-filtering is
safe but starves the model of context. Group names need tenant scope. Groups are resolved at query time
from the identity provider so revocation is immediate, while document ACL changes must be synced to index
metadata quickly, with a measured SLA. Every cache above retrieval must include the permission scope in its
key. Alice's salary question should end in "insufficient context", which needs a relevance threshold, not
an answer improvised from weakly related chunks.

---

## FAANG deep-dive notes

**How big tech does it.** Large companies run a central LLM platform: a gateway that handles identity,
quotas, routing, safety, and audit, pools of continuous-batching engines on GPUs (often with
disaggregated prefill and decode at the largest scale), and an evaluation service that gates every model
and prompt change. RAG is built on the company's search infrastructure, with document-level permissions
enforced in retrieval, hybrid ranking, and freshness pipelines. Cost is tracked per token per team, and
routing to the smallest adequate model is the main cost lever.

**Staff review questions.**
- What are the TTFT and TPOT SLOs, and what signal does the autoscaler use?
- How many concurrent sequences fit per GPU, and how did you compute that?
- How are permissions enforced in retrieval and in every cache?
- What is the golden set, and which metrics gate a model or prompt change?
- What is the cost per 1,000 answers, and what is the routing plan to reduce it?

**Interview question.** "Design an LLM inference platform shared by 15 internal products."

**Typical system-design prompt:** *Design a multi-tenant LLM platform for 15 products: chat (latency
sensitive), RAG (long prompts), and batch summarization (throughput). Peak is 300 requests/s, prompts average
3,000 tokens and outputs 250. You have 64 H100s and must control cost per team.*

**1. Clarify first:** What are the SLOs per class (TTFT for chat, completion time for batch)? Which models are
needed, and can most traffic use a small one? What are the data and residency rules (can anything go to
external APIs)? How are teams billed? What are the peak-to-average ratio and time zones?

**2. Back-of-envelope sizing:**
- Prefill: 300 × 3,000 = 900,000 tokens/s. With an 8B model, 900,000 × 16 GFLOP = 14.4 PFLOP/s, about 36 H100s at
  ~400 TFLOP/s effective. That's too many, so route by need, cut prompt length (reranking to fewer chunks), and
  use prefix caching for shared system prompts and documents.
- Decode: 300 × 250 = 75,000 output tokens/s. At ~2,500–4,000 tokens/s per H100 for 8B with large batches, that's
  ~20–30 GPUs.
- So 64 H100s are tight for all traffic on 8B. Batch summarization moves off-peak (it's ~30% of tokens),
  and chat and RAG share the online pool.
- KV: 300 requests/s × ~8 s average duration = 2,400 concurrent sequences × 3,250 tokens × 128 KB ≈ 1 TB.
  That fits in the ~60 GB free per GPU on ~17 GPUs, so it's OK if spread across the pool.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Engine | vLLM | TensorRT-LLM | vLLM for flexibility and speed of iteration. TensorRT-LLM when peak per-GPU throughput justifies the build pipeline |
| Pools | One shared pool | Per-class pools | Separate latency-critical from batch, or use priorities with preemption |
| Prefill/decode | Co-located | Disaggregated | Disaggregate at large scale with long prompts. Co-locate below that |
| Model choice | One large model | Router + small/large | Route: most traffic to small, hard cases to large, decided by evals |
| Autoscaling signal | GPU utilization | Queue depth, KV usage, TTFT | Queue and KV signals, with warm minimum replicas |
| Tenancy | Shared quotas | Per-team token budgets | Per-team budgets and priorities, enforced at the gateway |

**4. Follow-up questions with crisp answers:**
- *Why is GPU utilization a bad scaling signal for LLMs?* It saturates near 100% at modest load and doesn't
  reflect queueing or latency. Queue depth and KV usage do.
- *How do you protect chat latency from batch jobs?* Use separate pools or priority scheduling, token budgets per
  class, chunked prefill, and run batch work off-peak through a queue.
- *How do you roll out a new model?* Run the offline eval suite on golden sets, shadow traffic for latency and cost,
  canary 5% with online quality sampling and guardrail metrics, then ramp, with the old model warm for
  rollback.
- *A team's costs tripled. Where do you look?* Tokens per request (prompt growth, RAG k), cache hit rates, model
  routing changes, and retries.

**Debug this (common onsite question):** "After a release, chat TTFT p99 jumped from 600 ms to 6 s. GPU
utilization and error rates look normal."
1. Check engine metrics: `num_requests_waiting` rose 10×, and prefix-cache hit rate fell from 85% to 4%.
2. Diff the release: the system prompt now starts with the current timestamp and user name, which breaks
   the shared prefix. RAG `top_k` also went from 5 to 20.
3. Prefill tokens per request rose ~4×, without the cache. Queueing dominates TTFT.
4. Fix: move dynamic fields to the end of the prompt, restore `top_k` 5 with a reranker, enable chunked
   prefill, and add TTFT and prefix-hit-rate alerts to the release canary.

The lesson: prompt changes are infrastructure changes. They alter compute per request and cache behavior,
so they need the same canary and metrics as code.

**5. What separates senior from staff answers:** a senior engineer deploys vLLM well, sizes GPUs from the
KV math, and builds a correct RAG pipeline. A staff engineer designs the platform: gateway-enforced
identity, budgets, and audit, routing by evals to minimize cost per answer, permission-safe retrieval and
caches, eval-gated releases for models *and* prompts, and capacity plans that separate prefill, decode, and
traffic classes.

**Red flags:**
- Scaling LLM servers on CPU or GPU utilization.
- Permissions enforced by prompt instructions or after retrieval.
- Caches keyed without model version, prompt version, and permission scope.
- One giant model for every request.
- No golden-set eval before model or prompt changes.
- Weights pulled from object storage on every cold start.

---

## Quiz

<details><summary>1. Why is LLM decode usually memory-bandwidth-bound?</summary>
Each decode step generates one token per sequence but must read all model weights (and the KV cache) from
GPU memory. With few sequences, there's little compute per byte read. Batching many sequences raises the
compute per weight read.
</details>

<details><summary>2. Compute the KV cache per token for a model with 32 layers, 8 KV heads, head dim 128, FP16.</summary>
2 × 32 × 8 × 128 × 2 bytes = 131,072 bytes = 128 KB per token. An 8k context is 1 GiB per sequence.
</details>

<details><summary>3. What are TTFT and TPOT, and what drives each?</summary>
Time to first token is driven by queueing and prefill (prompt length, compute). Time per output token is
driven by decode (memory bandwidth, batch size, model size).
</details>

<details><summary>4. HNSW vs IVF-PQ: when would you choose each?</summary>
HNSW gives high recall and low latency when the vectors fit in RAM. IVF-PQ compresses vectors heavily for very large
collections or tight memory, with tunable recall (nprobe) and a rerank on full vectors.
</details>

<details><summary>5. Why must ACL filtering happen inside the vector search, not after it?</summary>
Post-filtering top-k results can leave few or no results (lost recall). Filtering inside the search returns the
best k chunks the user may read. Doing it in the prompt isn't a security control at all.
</details>

<details><summary>6. What must a semantic cache key include in a multi-user RAG system?</summary>
Model version, system prompt version, generation parameters, and the user's permission scope (ACL fingerprint),
plus a tuned similarity threshold, with invalidation on document and index changes.
</details>

<details><summary>7. How do you get high prefix-cache hit rates?</summary>
Put static content (system prompt, tool definitions, shared documents) first and dynamic content (user data,
timestamps, the question) last, keep it byte-identical across requests, and enable prefix caching in the engine.
</details>

<details><summary>8. What should an LLM autoscaler use as its signal?</summary>
Queue depth (waiting requests), running sequences or KV cache utilization, and TTFT against the SLO, with warm
minimum replicas because cold starts are slow. GPU utilization and CPU aren't useful signals.
</details>

## Failure modes
- Choosing GPUs from weight size only, leaving no room for the KV cache.
- Batch-size-1 serving that wastes most of the GPU.
- Permission filtering in the prompt or after retrieval, or group names without tenant scope.
- Caches keyed only by the question, leaking answers across users or serving stale answers.
- Dynamic content at the start of prompts, destroying prefix-cache hits.
- Stale or superseded documents still retrievable, and deletions not propagated.
- Changing the embedding model without re-embedding the index.
- Autoscaling on GPU utilization, with no warm pool.
- Releasing model or prompt changes without golden-set evals.
- LLM-as-judge scores trusted without calibration against human labels.

## Checklist
- [ ] You can explain prefill vs decode and the TTFT/TPOT metrics
- [ ] You can compute weights, KV per token, and concurrency for a model on a GPU
- [ ] You can choose a vector index and measure recall@k against exact search
- [ ] You built a RAG pipeline with chunking, hybrid retrieval, reranking, citations, and refusal
- [ ] You ran `s25_permission_rag.py` and can explain pre-filtering, tenant scoping, revocation, and cache keys
- [ ] You know which caches are safe and how to key and invalidate them
- [ ] You can serve an LLM with vLLM, read its metrics, and autoscale on queue depth
- [ ] You can present a sized, permission-safe production RAG design with evals and costs
