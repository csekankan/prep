# Section 20 — Multi-Cloud AI Infrastructure

> Lectures 134–140 • Assessment: quiz
> **After this section you can:** decide when multi-cloud is worth its cost, manage Kubernetes fleets across
> clouds, replicate models and data between providers, use price and capacity differences between clouds,
> design cross-region disaster recovery with clear RTO and RPO, run hybrid on-prem plus cloud AI, and serve one
> model from AWS and GCP behind a health-checked global endpoint.
>
> Go deeper: [13 / Lab 91 — Multi-cluster federation](../../13_sovereign_ai_infra_course/07_sovereign_deployment/lab91_multi_cluster_federation.md),
> [Lab 97 — Global traffic and border routing](../../13_sovereign_ai_infra_course/07_sovereign_deployment/lab97_global_traffic_border_routing.md),
> [Lab 68 — Velero vector DR](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab68_velero_vector_dr.md),
> [Lab 94 — Air-gapped architecture](../../13_sovereign_ai_infra_course/07_sovereign_deployment/lab94_air_gapped_architecture.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 134 | Why enterprises go multi-cloud | GPU capacity, regulation, negotiation, and acquisitions. Rarely "avoid lock-in" alone |
| 135 | Kubernetes federation across clouds | One control model for many clusters: GitOps fleets, multi-cluster services, global scheduling |
| 136 | Data replication across cloud providers | Replicate artifacts cheaply. Avoid replicating big data live, because egress dominates |
| 137 | Cost arbitrage in multi-cloud AI | Place portable workloads (training, batch) where GPUs are cheapest or available |
| 138 | Disaster recovery across regions | Choose RTO and RPO per service, then backup, pilot light, warm standby, or active-active |
| 139 | Hybrid on-prem + cloud AI setups | Owned GPUs for steady load and sensitive data, cloud for bursts |
| 140 | Lab: serve a model across AWS + GCP | The same image on two clouds, a health-checked global endpoint, and failover |

```mermaid
flowchart TB
  GIT[("Git: one source of truth<br/>manifests, policies, model versions")] --> ARGO["GitOps fleet manager<br/>Argo CD / Flux / Fleet"]
  ARGO --> AWS["AWS: EKS<br/>inference, region eu-west-1"]
  ARGO --> GCP["GCP: GKE<br/>inference + TPU training"]
  ARGO --> ONP["On-prem: GPU cluster<br/>sensitive training"]
  REG[("Model registry + artifacts<br/>replicated per cloud")] --> AWS & GCP & ONP
  GLB["Global DNS / LB<br/>health checks, geo, weights"] --> AWS & GCP
  ID["Federated identity<br/>OIDC, workload identity federation"] -.-> AWS & GCP & ONP
  OBS["One observability + cost view"] -.-> AWS & GCP & ONP
```

**How to read it:** in a well-run multi-cloud setup, Git is the single source of truth, and a GitOps
fleet manager applies the same manifests and policies to clusters in every environment. Model artifacts
are replicated to each cloud, so serving never crosses providers at runtime. A global load balancer
steers users between clouds, while federated identity and a shared observability and cost view keep
operations unified.

**Terms in this diagram.**
- **Manifests, policies**: Kubernetes YAML files describing what should run, and the rules every cluster must
  follow.
- **GitOps fleet manager: Argo CD / Flux / Fleet**: **GitOps** means clusters pull their desired state from Git and
  correct any difference automatically. A **fleet manager** does this for many clusters at once. **Argo CD** and
  **Flux** are the main open-source tools, and Rancher **Fleet** is another (Lecture 135, and Section 10).
- **EKS, GKE**: the managed Kubernetes services of AWS and Google Cloud. `eu-west-1` is an AWS region in Ireland.
- **TPU**: Google's own AI accelerator chip, available only in GCP.
- **On-prem**: on-premises, meaning hardware in your own data center.
- **Global DNS / LB: health checks, geo, weights**: it routes users by health, by **geo** (sending them to the
  nearest location), and by **weights** (fixed percentages per cloud).
- **Federated identity, workload identity federation**: one identity system trusted by every cloud, so a workload
  in one cloud can use a short-lived token to access another cloud without stored keys. **OIDC** (OpenID Connect)
  is the standard token format that makes this trust possible (Section 18).

---

## Lecture 134 — Why enterprises go multi-cloud

**Why it matters.** Multi-cloud roughly doubles the platform work: two sets of IAM, networking, quotas,
tooling, and skills. It's worth it only for specific reasons, and AI has made some of those reasons more
common, especially GPU availability.

**In plain words.** Shopping at two supermarkets costs extra time. People do it because one has
something the other doesn't, one is much cheaper for some items, or the nearest one sometimes runs out.
Not because they're worried about becoming "locked in" to one.

**Architecture: the common multi-cloud shapes.**

```mermaid
flowchart LR
  subgraph S1["(1) Workload split: most common"]
    A1["AWS: apps + inference"] --- G1["GCP: TPU training,<br/>BigQuery analytics"]
  end
  subgraph S2["(2) Capacity overflow"]
    A2["Primary cloud GPUs"] -->|"burst when full"| N2["GPU cloud / second provider"]
  end
  subgraph S3["(3) Redundant serving"]
    A3["Cloud A serving"] <-->|"failover"| B3["Cloud B serving"]
  end
  subgraph S4["(4) Sovereign / regulatory"]
    A4["Global cloud"] --- L4["Local or sovereign cloud<br/>for regulated data"]
  end
```

**How to read it:** most organizations use pattern (1): different workloads in different clouds, each in
its best place. AI adds (2): overflow to another provider when GPUs run out. Pattern (3), the same
service running redundantly in two clouds, is the most expensive and the rarest. Pattern (4) comes from
regulation and data sovereignty (Section 42).

In the diagram, **BigQuery** is Google Cloud's serverless analytics warehouse. To **burst** means sending extra work
elsewhere only while your main capacity is full. A **GPU cloud** is a specialist provider such as CoreWeave or
Lambda that mainly rents GPUs. **Sovereign** cloud means data and operations stay under one country's legal
control, operated by local staff, and **regulated data** is data a law restricts, such as health records.

**Core ideas.**

| Reason | Strength | Example |
|---|---|---|
| GPU / accelerator access | Strong for AI | H100 capacity in one cloud, TPUs only on GCP, GPU clouds (CoreWeave, Lambda) for training |
| Best-of-breed services | Strong | BigQuery for analytics, Azure OpenAI for specific models |
| Regulation / sovereignty | Strong where it applies | Data must stay in-country or with a sovereign provider |
| Mergers and acquisitions | Practical reality | The acquired company runs on another cloud |
| Negotiating leverage | Moderate | A credible ability to move workloads improves pricing |
| Resilience against a provider failure | Weaker than expected | Multi-region in one cloud covers most failures more cheaply |
| "Avoid lock-in" alone | Weak | Portability has a real cost. Lock into managed services where they pay back |

- **Costs of multi-cloud:** duplicated platform engineering, inconsistent IAM and networking, cross-cloud
  egress ($0.08–0.12/GB on the internet), lowest-common-denominator designs, and split commitment
  discounts.
- **Portability layers that work:** containers, Kubernetes, Terraform/OpenTofu, OCI images, open model
  formats (safetensors, ONNX), open table formats (Iceberg, Delta), and OpenTelemetry.

**Example: multi-cloud for GPUs, not ideology.** A company ran everything on AWS, but couldn't get
H100 capacity for a 3-month training project. It ran training on a GPU cloud with reserved capacity
(about 40% cheaper per GPU-hour), copied the final checkpoints (~1.2 TB) back once, and kept serving on AWS.
The one-time egress was ~$110. Building a full second serving stack would have cost months of platform
work for little benefit.

**Senior / FAANG best practice.** Write down *why* each workload is on each cloud, and decide multi-cloud
per workload, not as a blanket strategy. Standardize the portable layers (Kubernetes, GitOps, Terraform,
OCI, OTel, identity federation), and accept cloud-specific managed services where they clearly pay back.
Most big tech companies run on their own infrastructure plus targeted use of others, and treat portability
as a capability, not a default.

---

## Lecture 135 — Kubernetes federation across clouds

**Why it matters.** Once you have clusters in several clouds and regions, managing each one by hand
leads to drift, inconsistent security, and slow rollouts. Fleet management gives you one way to deploy,
govern, and observe them all.

**In plain words.** A restaurant chain doesn't let each branch invent its own recipes and safety rules.
Head office sends the same recipe book and rules to every branch, and checks that they're followed.

**Architecture: GitOps fleet management.**

```mermaid
flowchart TB
  GIT[("Git repo<br/>base + overlays per cloud/region")] --> HUB["Hub: Argo CD ApplicationSets<br/>or Flux, Rancher Fleet, GKE Fleet / Azure Arc"]
  HUB -->|"cluster generator:<br/>labels cloud=aws, env=prod"| C1["EKS eu-west-1"]
  HUB --> C2["GKE europe-west4"]
  HUB --> C3["On-prem cluster"]
  POL["Policy: Kyverno / Gatekeeper<br/>same rules everywhere"] --> C1 & C2 & C3
  MCS["Multi-cluster service discovery:<br/>Cilium ClusterMesh / Istio / Submariner"] -.-> C1 & C2
  SCHED["Multi-cluster scheduling:<br/>Karmada / Kueue MultiKueue"] -.-> C1 & C2 & C3
```

**How to read it:** the hub watches Git and applies the right configuration to each cluster, using labels
to pick per-cloud overlays (storage classes, node selectors, IAM annotations). The same admission policies run
everywhere. Optional layers add cross-cluster service discovery (a pod in one cluster calls a service in
another) and multi-cluster job scheduling, which sends work to whichever cluster has free GPUs.

**Terms in this diagram.**
- **Base + overlays**: a **base** is the shared configuration. An **overlay** patches only what differs per cloud or
  region. This is the pattern of **Kustomize**, a tool built into `kubectl` (`kubectl apply -k`) that merges an
  overlay's patches onto the base YAML.
- **Hub**: the central management cluster that pushes configuration to all the others.
- **ApplicationSets, cluster generator**: an Argo CD **ApplicationSet** creates one application per matching cluster.
  Its **cluster generator** selects clusters by labels such as `cloud=aws, env=prod`.
- **GKE Fleet / Azure Arc**: Google's and Microsoft's services for managing many clusters, including ones running
  outside their cloud.
- **Kyverno / Gatekeeper**: admission policy engines that reject Kubernetes objects breaking the rules. Gatekeeper is
  built on OPA (Section 18).
- **Cilium ClusterMesh / Istio / Submariner**: tools that connect pod networks across clusters, so a service name in
  one cluster can be reached from another.
- **Karmada / Kueue MultiKueue**: **Karmada** spreads workloads across clusters. **Kueue** is the Kubernetes job
  queue for batch and GPU jobs (Section 11), and its **MultiKueue** mode dispatches queued jobs to worker clusters.
- **Storage classes, node selectors, IAM annotations**: the settings that differ per cloud: which disk type to use,
  which node labels to match, and which cloud identity each service account maps to.

**Core ideas.**

```yaml
# Argo CD ApplicationSet: deploy the model service to every prod cluster labeled for inference
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata: { name: llm-api }
spec:
  generators:
  - clusters: { selector: { matchLabels: { env: prod, role: inference } } }
  template:
    metadata: { name: "llm-api-{{name}}" }
    spec:
      project: default
      source:
        repoURL: https://git.example.com/platform/deploy.git
        targetRevision: main
        path: "apps/llm-api/overlays/{{metadata.labels.cloud}}"
      destination: { server: "{{server}}", namespace: llm }
      syncPolicy: { automated: { prune: true, selfHeal: true } }
```

| Need | Tools | Note |
|---|---|---|
| Deploy everywhere consistently | Argo CD ApplicationSets, Flux, Rancher Fleet | GitOps is the standard. "KubeFed" (v2) is archived |
| Govern consistently | Kyverno, OPA Gatekeeper, cloud fleet policy | The same baseline in every cluster |
| Cross-cluster networking | Cilium ClusterMesh, Istio multi-cluster, Submariner, GKE MCS | Use sparingly: cross-cloud calls add latency and egress |
| Place jobs across clusters | Karmada, Kueue MultiKueue, Armada | Good for batch and training queues |
| Fleet visibility | Central Prometheus/Thanos, OTel, cost tools | Labels: cloud, region, cluster |

- **Overlay what differs, share what doesn't:** storage classes, GPU node labels, load-balancer
  annotations, and workload identity annotations differ per cloud. App manifests and policies don't.
- **Avoid synchronous cross-cloud dependencies** in the request path. Each cloud's stack should serve
  independently.

**Example: drift found by GitOps.** A company moved 14 clusters across AWS and GCP to Argo CD. On the first
sync, Argo reported 230 resources that differed from Git: manual hotfixes, old NetworkPolicies, and two
clusters missing the pod-security baseline. After cleanup, `selfHeal: true` kept them identical, and a
security fix now reached all clusters in under 10 minutes instead of a week of tickets.

**Senior / FAANG best practice.** Treat clusters as cattle: created from code, enrolled in the fleet
automatically, and configured only through Git. Keep request paths cloud-local, and use multi-cluster
scheduling for batch and training, where cross-cloud latency doesn't matter. Measure configuration drift
as a fleet health metric.

---

## Lecture 136 — Data replication across cloud providers

**Why it matters.** Models need data and artifacts close to where they run. Moving data between clouds is
slow and expensive (egress), and replicating it live is complex. Decide carefully what to replicate, how,
and how often.

**In plain words.** Moving house between cities, you carry the important boxes (model files) with you, but
you don't ship the whole library back and forth every day. You borrow from the local library (local copies)
instead.

**Architecture: what to replicate and how.**

```mermaid
flowchart LR
  subgraph AWS["AWS (primary data)"]
    LAKE[("Data lake: S3 + Iceberg<br/>100s of TB")]
    REGA[("Model registry + artifacts")]
  end
  subgraph GCP["GCP"]
    REGB[("Artifact replica: GCS")]
    VECB[("Vector index built locally")]
    TR["Training job reading<br/>a curated subset"]
  end
  REGA -->|"on promotion: model files,<br/>GBs, event-driven"| REGB
  LAKE -->|"curated training snapshot,<br/>scheduled, compressed, deduplicated"| TR
  LAKE -.->|"avoid: live replication of raw data"| GCP
  SRC["Source documents"] --> VECB
```

**How to read it:** small, high-value artifacts (model files, configs, container images) are replicated
automatically whenever they change, so each cloud can serve independently. Large datasets stay in their home
cloud. Only curated, deduplicated snapshots move when a job elsewhere needs them. Derived data, like vector
indexes, is often cheaper to *rebuild* locally from the source than to copy.

In the diagram, **Iceberg** (Apache Iceberg) is a table format on top of object storage that adds versions, schemas,
and snapshots (Section 6). An **artifact replica** is a copy of the model files in the other cloud's storage, here
GCS (Google Cloud Storage). **On promotion** means when a model is approved for production in the registry.
**Event-driven** means the copy is triggered by that event, not by a schedule. A **curated** subset is selected and
cleaned for one job. **Deduplicated** means duplicate records are removed before sending, to cut egress fees (the
charge clouds make for data leaving them). **Live replication of raw data** copies everything continuously, which
is very expensive at hundreds of terabytes.

**Core ideas.**

| Data | Size | Approach | Tools |
|---|---|---|---|
| Container images | GBs | Mirror to each cloud's registry | Registry replication, `crane copy`, Harbor |
| Model artifacts | GBs to TBs | Copy on promotion, verify checksums | Storage Transfer Service, DataSync, `rclone`, `s5cmd` |
| Training datasets | TBs to PBs | Curated snapshots, scheduled | Iceberg/Delta snapshots, transfer services, physical transfer appliances for PB scale |
| Operational DBs | GBs | Database-native replication or CDC | Debezium + Kafka, cross-cloud managed replicas |
| Vector indexes | GBs to TBs | Rebuild from source, or snapshot + restore | Re-embed pipelines, DB-native backups |

- **Egress math:** 100 TB across clouds at ~$0.05–0.09/GB is ~$5,000–9,000 per copy. Do it once, not
  daily. Private interconnects (Direct Connect, Cloud Interconnect, Equinix) cut the per-GB price at
  committed cost.
- **Consistency:** artifacts are immutable and versioned (copy-then-switch). Replicating mutable data
  across clouds needs a clear owner (one writer) and lag monitoring.
- **Verify integrity:** checksums (SHA-256) and manifests for every replicated model, compared before
  serving (Section 10).
- **Residency:** some data may not leave a region or country. Replication rules must enforce data classes.

**Example: rebuild, don't copy.** A team replicated a 3 TB vector index from AWS to GCP nightly, at ~$250 a
night in egress, and it was often stale. Instead, they replicated only new and changed *source* documents
(~5 GB a day) and re-embedded them locally in GCP, at ~$0.45 a day in egress plus ~$20 of GPU time. The GCP
index became fresher (hourly updates) and ~10× cheaper to keep in sync.

**Senior / FAANG best practice.** Classify data by size, mutability, and sensitivity, and pick a
replication method per class. Make artifacts immutable and content-addressed, so replication is a safe,
idempotent copy. Keep each cloud's serving path independent of cross-cloud reads. Track replication lag and
egress cost as first-class metrics.

---

## Lecture 137 — Cost arbitrage in multi-cloud AI

**Why it matters.** GPU prices vary a lot between providers, regions, and purchase options, often 2–3×
for similar hardware. Portable workloads (training and batch inference) can save large amounts by running
where capacity is cheapest, as long as egress and engineering costs don't erase the savings.

**In plain words.** Filling up your car where fuel is cheapest makes sense if the cheap station is on your
way, not if you drive an hour to save two dollars.

**Architecture: a cost-aware placement decision.**

```mermaid
flowchart LR
  JOB["Job: 2,000 H100-hours<br/>reads 40 TB, writes 1 TB"] --> EST["Estimate per provider:<br/>compute + storage + egress<br/>+ queue time + engineering"]
  EST --> P1["Cloud A on-demand<br/>$4.0/GPU-h"]
  EST --> P2["Cloud A reserved / spot"]
  EST --> P3["GPU cloud B<br/>$2.4/GPU-h, data must move"]
  P1 & P2 & P3 --> PICK{"Lowest total cost<br/>meeting deadline + compliance"}
  PICK --> RUN["Run + record actual cost"]
```

**How to read it:** for each portable job, estimate the *total* cost per option: compute, plus storage,
plus moving data in and results out, plus how long you'd wait for capacity, plus any engineering effort.
Then pick the cheapest that meets the deadline and compliance rules, and record the actual cost to improve
the next estimate.

In the diagram, **H100-hours** are hours of one NVIDIA H100 GPU, so 2,000 could be 250 GPUs for 8 hours. **Egress**
is the provider's fee for data leaving its network, often $0.05–0.09 per GB, so 40 TB can cost thousands of dollars
by itself. **Queue time** is how long you'd wait for the GPUs to become free. **On-demand** is the full list price
with no commitment. **Reserved** is a discount for committing to one or three years, and **spot** is spare capacity
at a deep discount that can be reclaimed (Section 12). **$/GPU-h** is price per GPU per hour. **Cost arbitrage**
means moving work to wherever the total is cheapest.

**Core ideas.**

**Worked comparison (illustrative prices):** 2,000 H100 GPU-hours, input 40 TB, output 1 TB.

| Option | Compute | Data movement | Total |
|---|---|---|---|
| Cloud A on-demand ($4.00/GPU-h) | $8,000 | $0 (data already there) | **$8,000** |
| Cloud A spot (~$2.20/GPU-h, +15% rework from interruptions) | $5,060 | $0 | **$5,060** |
| GPU cloud B ($2.40/GPU-h) | $4,800 | 40 TB out of A at ~$0.05/GB ≈ $2,000. 1 TB back ≈ $0 (ingress free) | **$6,800** |

Here, spot in the home cloud wins. If the job were *repeated* on the same data monthly, copying it to B
once would make B cheaper from the second run. If the data were only 2 TB, B would win immediately.

| Workload | Arbitrage potential | Why |
|---|---|---|
| Large training runs | High | Long, portable, capacity-hungry. Data moves once |
| Batch inference / embeddings | High | Stateless, interruptible, portable |
| Fine-tuning | Medium | Small data, but needs the eval pipeline nearby |
| Online inference | Low | Latency, data locality, and operations complexity |
| Data-heavy ETL | Low | Egress dominates |

- **Hidden costs:** queue time (capacity not available when promised), extra platform work per
  provider, security reviews, and committed-spend discounts you'll miss in your primary cloud.
- **Capacity often matters more than price.** Being able to get 512 GPUs *next week* can be worth more
  than a 20% discount.

**Example: a quarterly placement review.** An ML org ran a quarterly review of its large portable workloads.
Monthly embedding refreshes moved to a GPU cloud with the source corpus replicated once (saving ~45%), the
main pretraining stayed in the primary cloud under a commitment discount, and online inference stayed
put. Net savings were ~28% of GPU spend, with one extra provider to operate, an explicit, tracked trade-off.

**Senior / FAANG best practice.** Make arbitrage a decision with numbers, per workload: total cost
including data movement, capacity lead time, and operating cost. Keep training and batch pipelines portable
(containers, object-storage interfaces, checkpoints in open formats), so you *can* move them. Don't make
online serving portable without a strong reason. Revisit placement when prices or commitments change.

---

## Lecture 138 — Disaster recovery across regions

**Why it matters.** Regions do fail, through outages, natural disasters, and botched global changes. So do
accounts (compromise, accidental deletion). DR planning decides how long you'll be down (RTO) and how much
data you'll lose (RPO), before it happens.

**In plain words.** RTO is how long until the shop reopens after a fire. RPO is how many of the day's
receipts you lose. A spare shop already stocked across town (warm standby) reopens fast. A box of
backup receipts in a safe (backups) loses little data, but reopening takes longer.

**Architecture: DR strategies by cost and speed.**

```mermaid
flowchart LR
  BR["Backup and restore<br/>RTO hours-days, RPO hours<br/>$"] --> PL["Pilot light<br/>core data replicated,<br/>compute off<br/>RTO 1-4 h, $$"]
  PL --> WS["Warm standby<br/>scaled-down full stack<br/>RTO minutes, $$$"]
  WS --> AA["Active-active<br/>both serve traffic<br/>RTO ~0, RPO ~0 to seconds, $$$$"]
```

**How to read it:** strategies range from cheap and slow (restore everything from backups) to expensive and
instant (two regions serving at once). Pilot light keeps data replicated with compute off, and warm
standby runs a small copy that can scale up. Pick per service, based on what downtime and data loss cost the
business.

In the diagram, **RTO** (recovery time objective) is how long the service may be down after a disaster. **RPO**
(recovery point objective) is how much recent data you may lose, measured in time. An RPO of 1 hour means up to the
last hour of changes. The dollar signs show relative cost, from one ($) for the cheapest to four ($$$$) for the most
expensive. **Pilot light** is named after the small flame in a gas heater: the essentials stay lit, so the rest can
start quickly. In **active-active**, both regions serve live traffic all the time.

**Core ideas.**

| AI component | What DR needs | Typical approach |
|---|---|---|
| Model artifacts and images | Available in the DR region | Replicated on promotion (immutable, small) |
| Serving infrastructure | Re-creatable | Terraform + GitOps. Clusters re-creatable in under an hour |
| GPU capacity | **The hardest part** | Reservations in the DR region, a degraded mode with a smaller model, or an external-provider fallback |
| Vector indexes | Restorable | Snapshots + replicated source, or a rebuild (know how long it takes) |
| Feature store / databases | Low RPO | Cross-region replicas, point-in-time recovery |
| Training checkpoints | Not lost | Cross-region replicated bucket for the latest N checkpoints |
| Secrets, keys, identity | Usable in DR | Multi-region keys and secret replication, break-glass accounts |

- **Account-level disasters:** keep backups in a separate account with write-once storage (Object Lock),
  so a compromised or deleted primary account can't destroy them.
- **Test restores:** schedule DR drills, measure the actual RTO and RPO, and fix the gaps. A backup you
  haven't restored is a hope, not a backup.
- **Runbooks:** who declares DR, the exact steps, DNS changes, and how to fail back afterwards.

**Example: the 9-hour index rebuild.** A DR drill failed over a RAG assistant to its standby region.
Compute came up in 20 minutes, but the vector index had no snapshot, and rebuilding it from 40 million
documents took 9 hours on the available GPUs, so the real RTO was 9 hours, not the documented 1 hour. The
team added daily index snapshots replicated to the DR region (restore: 35 minutes) and re-ran the drill.

**Senior / FAANG best practice.** Set RTO and RPO per service with the business, choose the cheapest
strategy that meets them, and prove them with regular drills. Include GPU capacity and derived data
(indexes, caches) in the plan, because they're what usually breaks it. Big tech runs region-evacuation
exercises, and keeps immutable, cross-account backups for the "everything is compromised" scenario.

---

## Lecture 139 — Hybrid on-prem + cloud AI setups

**Why it matters.** Many organizations own GPUs, or are buying them, because steady AI workloads are
cheaper on owned hardware at high utilization, and sensitive data may need to stay on-prem. The cloud adds
burst capacity and managed services. Making the two work as one platform is a common senior task.

**In plain words.** Owning a car is cheaper if you drive every day. Renting is better for a road trip in a
bigger car. Many families own one car and rent when they need more.

**Architecture: a hybrid AI platform.**

```mermaid
flowchart LR
  subgraph ONP["On-prem data center"]
    GPU1["Owned GPU cluster<br/>steady training + inference<br/>~70-85% utilization"]
    DATA1[("Sensitive data<br/>stays here")]
  end
  subgraph CLOUD["Cloud"]
    BURST["Burst GPU pool<br/>spot / on-demand"]
    MS["Managed services:<br/>registry, CI, observability"]
  end
  ONP <-->|"Direct Connect / Interconnect<br/>10-100 Gb/s, private"| CLOUD
  Q["Unified job queue<br/>Kueue MultiKueue / Slurm + cloud bursting"] --> GPU1
  Q -->|"when on-prem is full<br/>and data class allows"| BURST
  ID["One identity (SSO, OIDC)"] -.-> ONP & CLOUD
  GIT[("GitOps: same manifests")] -.-> ONP & CLOUD
```

**How to read it:** owned GPUs run the steady base load at high utilization, and sensitive data never
leaves the building. A unified queue sends jobs on-prem first, and bursts to cloud GPUs when on-prem is full,
but only for jobs whose data class allows it. A private network link connects the two, and the same
identity, GitOps, and observability make it one platform for users.

In the diagram, **Direct Connect** (AWS) and **Interconnect** (GCP) are dedicated private fiber links from your data
center to the cloud, at 10 to 100 gigabits per second, instead of the public internet. **Slurm** is the job scheduler
traditionally used on HPC (high-performance computing) and GPU clusters, and **cloud bursting** adds cloud nodes to
it temporarily. A **data class** is a label like "public", "internal", or "restricted" that decides where data may be
processed. **SSO** (single sign-on) means one login for every system. **Managed services** are tools the cloud runs
for you.

**Core ideas.**

| Factor | On-prem | Cloud |
|---|---|---|
| Cost at high, steady utilization | Lower (often 40–60% over 3–4 years at >70% utilization) | Higher |
| Cost at low or bursty utilization | Higher (idle capital) | Lower |
| Time to capacity | Months (procurement, power, cooling) | Minutes to weeks |
| Data control | Full | Shared responsibility |
| Operations burden | High: hardware, power, networking, repairs | Low |
| Hardware refresh | Your problem (3–5 year cycles) | Provider's problem |

**Break-even, roughly:** an 8× H100 server costs ~$300,000 plus ~$60,000 a year to run (power, space,
support), ~$540,000 over 4 years. The cloud on-demand equivalent at ~$4/GPU-hour is ~$280,000 a year. At 80%
utilization (~$225,000 a year, ~$900,000 over 4 years), owning saves ~40%. At 30% utilization, the cloud is
cheaper. These numbers are illustrative, so use your own quotes.

- **Data gravity:** put compute where the big or sensitive data is. Burst only workloads whose data can
  move, or that use data already in the cloud.
- **Same software stack:** Kubernetes with the GPU Operator on both sides, the same images, the same
  registry (mirrored), and the same scheduler policies.
- **Power and cooling** are now the main constraint for on-prem GPUs: 10–15 kW per 8-GPU server, 40–130 kW per
  rack for the newest systems. Many data centers can't host them without liquid cooling (Section 46).

**Example: base on-prem, burst to cloud.** A bank bought 256 H100s for steady model training on customer
data, at 78% average utilization. Quarter-end risk recomputations needed 3× capacity for 10 days.
Anonymized feature sets were allowed in the cloud, so those jobs burst to cloud spot GPUs through
MultiKueue. Total cost was ~35% below all-cloud, and quarter-end deadlines no longer slipped.

**Senior / FAANG best practice.** Decide on-prem vs cloud from utilization forecasts, data classification,
and time-to-capacity, and revisit it yearly. Run one platform (identity, GitOps, scheduler, observability)
across both, with data-class-aware placement enforced by policy, not by convention. Plan power, cooling, and
networking for GPUs years ahead.

---

## Lecture 140 — Lab: serve a model across AWS + GCP

**Goal:** run the same model container on AWS and GCP, put a health-checked global endpoint in front, and
show that traffic fails over when one cloud's deployment goes down. A fully local version simulates both
clouds with two kind clusters and a health-checking proxy, if you don't have cloud accounts.

**What you're building.**

```mermaid
flowchart LR
  U((Client)) --> GLB["Global endpoint<br/>Route 53 failover / Cloudflare LB<br/>(local: NGINX with health checks)"]
  GLB -->|"primary"| AWS["AWS: App Runner or EKS<br/>model:1.0 from ECR"]
  GLB -->|"secondary"| GCP["GCP: Cloud Run or GKE<br/>model:1.0 from Artifact Registry"]
  IMG[("Same image digest<br/>pushed to both registries")] --> AWS & GCP
```

**In plain words.** You build a model service that doesn't depend on any one cloud, and prove it keeps
answering when one cloud's copy disappears.

**How to read the diagram:** clients call one global endpoint. **Route 53** (AWS DNS) failover records, or a
**Cloudflare** load balancer, send traffic to the primary and switch to the secondary when health checks fail. With no
cloud accounts, a local NGINX with health checks plays this role. **App Runner** (AWS) and **Cloud Run** (GCP) are
serverless container services that run an image without managing a cluster, and EKS and GKE are the Kubernetes
options. **ECR** and **Artifact Registry** are each cloud's container registry. The **image digest** is the
`sha256:` content hash of the image, so pushing the same digest to both registries guarantees both clouds run
byte-for-byte identical code.

### Step 1 — Push the same image to both registries

```bash
IMG=classifier:1.0       # from Section 14, or any small model API
AWS_REPO=$ACCOUNT.dkr.ecr.eu-west-1.amazonaws.com/classifier
GCP_REPO=europe-west4-docker.pkg.dev/$PROJECT/models/classifier
aws ecr get-login-password | docker login --username AWS --password-stdin ${AWS_REPO%%/*}
gcloud auth configure-docker europe-west4-docker.pkg.dev
docker tag $IMG $AWS_REPO:1.0 && docker push $AWS_REPO:1.0
crane copy $AWS_REPO:1.0 $GCP_REPO:1.0                  # copies by digest, so both clouds run identical bits
crane digest $AWS_REPO:1.0; crane digest $GCP_REPO:1.0  # must match
```

### Step 2 — Deploy on each cloud

```bash
# GCP: Cloud Run
gcloud run deploy classifier --image $GCP_REPO:1.0 --region europe-west4 --port 8000 \
  --cpu 2 --memory 2Gi --min-instances 1 --allow-unauthenticated
# AWS: App Runner (or EKS with the Section 14 manifests)
aws apprunner create-service --service-name classifier --source-configuration "{
  \"ImageRepository\": {\"ImageIdentifier\": \"$AWS_REPO:1.0\", \"ImageRepositoryType\": \"ECR\",
  \"ImageConfiguration\": {\"Port\": \"8000\"}}, \"AuthenticationConfiguration\": {\"AccessRoleArn\": \"$APPRUNNER_ECR_ROLE\"}}" \
  --instance-configuration Cpu=2048,Memory=4096 \
  --health-check-configuration Protocol=HTTP,Path=/readyz
```

### Step 3 — A health-checked global endpoint

With Route 53: create two health checks (`/readyz` on each URL) and a failover record pair, with
PRIMARY pointing to App Runner and SECONDARY to Cloud Run, a 30-second TTL, and each record tied to its health check.
Cloudflare Load Balancing or another global DNS provider works the same way.

**Local version (no cloud accounts):**

```bash
kind create cluster --name cloud-a && kind create cluster --name cloud-b
for c in cloud-a cloud-b; do
  kind load docker-image classifier:1.0 --name $c
  kubectl --context kind-$c create deployment model --image=classifier:1.0 --port 8000
  kubectl --context kind-$c expose deployment model --type NodePort --port 8000
done
# point an NGINX upstream at both NodePorts, primary first, with "backup" on the secondary
```

```nginx
upstream global_model {
  server 172.18.0.2:30080 max_fails=2 fail_timeout=10s;    # cloud-a node IP:NodePort
  server 172.18.0.3:30080 backup;                           # cloud-b
}
server { listen 8088; location / { proxy_pass http://global_model; proxy_next_upstream error timeout http_502 http_503; } }
```

### Step 4 — Fail one cloud and watch traffic move

```bash
while true; do curl -s -o /dev/null -w "%{http_code} %{remote_ip}\n" https://model.example.com/readyz; sleep 2; done
# in another terminal: take the primary down
aws apprunner pause-service --service-arn $APPRUNNER_ARN
# local: kubectl --context kind-cloud-a scale deployment model --replicas 0
# restore afterwards
aws apprunner resume-service --service-arn $APPRUNNER_ARN
```

**Expected results:**
- Both registries report the **same image digest**.
- Both cloud URLs return 200 on `/readyz` and the same prediction for the same image.
- **Failover:** after pausing the primary, the health check fails within ~30–90 seconds, and DNS answers point to
  Cloud Run. The client loop shows a short burst of errors, bounded by the health-check interval plus the TTL,
  then 200s from the secondary.
- **Local version:** NGINX switches to the backup within one or two requests, because passive health checks
  react faster than DNS.
- **Teardown:** delete both services and the DNS records to stop charges.

---

## FAANG deep-dive notes

**How big tech does it.** Most big tech companies run primarily on their own global infrastructure, and
use other clouds for specific capabilities or capacity. Enterprises typically run a primary cloud, plus
specific workloads elsewhere, plus on-prem GPUs for steady load. What they share is a portable operating
layer: containers, GitOps fleets, policy as code, federated identity, OpenTelemetry, and immutable
artifacts replicated by digest. Serving paths stay cloud-local. DR is defined per service with RTO and RPO,
and proven with drills. Placement of training and batch work is a recurring cost and capacity decision.

**Staff review questions.**
- Why is this workload on this cloud, and what would it cost to move it?
- What's the RTO and RPO for this service, and when was it last proven in a drill?
- Where does data cross cloud boundaries, and what does that cost each month?
- What's our GPU capacity plan in the DR region?

**Interview question.** "Should we go multi-cloud for our AI platform?"

**Typical system-design prompt:** *Your company serves an LLM assistant from one AWS region. Leadership
asks for "multi-cloud resilience" after a regional outage, and the ML team can't get enough GPUs for
training. Design the strategy.*

**1. Clarify first:** What was the actual impact of the outage, and what are the RTO/RPO targets? Would
multi-region in AWS meet them? Which data classes can move? What GPU capacity is needed, for how long?
What platform team capacity do we have?

**2. Back-of-envelope sizing:**
- Serving: 120 GPUs in one region. A warm standby in a second AWS region at 30% (36 GPUs) plus
  external-provider overflow for peak meets an RTO of ~15 minutes, at ~30% extra serving cost.
- Second-cloud active-active serving: another full platform stack (people, IAM, networking, observability),
  roughly 2–4 engineers ongoing, plus duplicated GPU capacity.
- Training: 512 GPUs × 2 months = ~740,000 GPU-hours. A GPU cloud at a $1.50/hour discount saves ~$1.1M.
  Moving 80 TB of data once costs ~$4,000–7,000.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Resilience | Multi-cloud active-active | Multi-region in one cloud + provider fallback | Multi-region first. Multi-cloud only if single-provider risk is unacceptable |
| Training capacity | Wait for the primary cloud | Use a GPU cloud | Move portable training where capacity exists, data moves once |
| Portability | Abstract everything | Portable core + accept managed services | A portable core (K8s, GitOps, OCI, Terraform), managed services where they pay |
| Data | Replicate everything | Replicate artifacts, snapshot curated data | Move small, immutable things often, and big things rarely |
| DR strategy | Active-active everywhere | Per-service RTO/RPO tiers | Tier services, and fund what each tier needs |

**4. Follow-up questions with crisp answers:**
- *Doesn't multi-region in one cloud still leave provider risk?* Yes, but most outages are regional or
  change-related. A provider-wide outage is rare. Cover it with an external LLM fallback and immutable
  cross-account backups, rather than a full second stack.
- *How do you keep two clouds' deployments identical?* Same image digest, the same GitOps source with
  per-cloud overlays only for infrastructure differences, the same policies, and drift detection.
- *What's the hardest part of DR for AI?* GPU capacity in the DR location, and rebuilding derived data
  (indexes, caches) fast enough.

**Debug this (common onsite question):** "After moving batch inference to a second cloud to save money, the monthly bill went up."
1. Break down the bill: compute fell 35%, but there's a new $38,000 line for egress from the primary cloud.
2. Trace the data flow: each nightly batch job reads features *live* from the primary cloud's warehouse
   (6 TB a night), instead of from a replicated snapshot.
3. Results are written back daily, which is small. So the read path is the problem.
4. Fix: replicate the feature snapshot once a week with daily incremental files (~200 GB a day), or keep
   batch jobs in the primary cloud on spot. Recompute the business case including egress.

The lesson: in multi-cloud, data movement often dominates the cost. Price the data flows before moving
compute, and keep jobs next to their data.

**5. What separates senior from staff answers:** a senior engineer can deploy and fail over across clouds,
and replicate artifacts correctly. A staff engineer questions whether multi-cloud is needed, chooses per
workload with numbers (cost, capacity, egress, people), designs a portable operating layer without forcing
lowest-common-denominator services, defines DR tiers with tested RTO and RPO, and includes GPU capacity
and derived data in every plan.

**Red flags:**
- "Multi-cloud to avoid lock-in" with no workload-level reason.
- Synchronous cross-cloud calls in the request path.
- Replicating raw data live across providers.
- DR plans without GPU capacity or index restore times.
- Images rebuilt separately per cloud instead of copied by digest.

---

## Quiz

<details><summary>1. Give two strong and one weak reason for multi-cloud AI.</summary>
Strong: access to GPUs or accelerators (TPUs, GPU clouds), regulatory or sovereignty requirements, or
best-of-breed services. Weak: "avoid lock-in" on its own, without a workload-level justification.
</details>

<details><summary>2. How do you deploy the same app to clusters in several clouds consistently?</summary>
GitOps fleet management, for example Argo CD ApplicationSets with a cluster generator. Shared base manifests
with per-cloud overlays, and the same admission policies everywhere.
</details>

<details><summary>3. Why rebuild a vector index locally rather than copying it across clouds?</summary>
Copying the full index repeatedly costs a lot of egress and is often stale. Replicating only changed source
documents and re-embedding locally is cheaper and fresher.
</details>

<details><summary>4. When does moving a training job to a cheaper GPU cloud not pay off?</summary>
When moving the data costs more than the compute savings (large datasets, frequent re-reads), when
capacity isn't really available when needed, or when the extra platform work outweighs the discount.
</details>

<details><summary>5. Define RTO and RPO.</summary>
RTO (recovery time objective) is the maximum acceptable downtime. RPO (recovery point objective) is the
maximum acceptable data loss, measured in time.
</details>

<details><summary>6. What makes DR for AI services harder than for typical web services?</summary>
Scarce GPU capacity in the DR location, large model artifacts, and derived data (vector indexes, caches)
that can take hours to rebuild.
</details>

<details><summary>7. When are owned on-prem GPUs cheaper than the cloud?</summary>
At high, steady utilization (roughly above 60–70%) over the hardware's 3–5 year life, and when power,
cooling, and operations skills are available. Bursty or low-utilization workloads favor the cloud.
</details>

<details><summary>8. Why copy container images by digest rather than rebuilding them in each cloud?</summary>
Copying by digest guarantees identical bits everywhere, keeping signatures, SBOMs, and test results
valid. Rebuilding can produce different images.
</details>

## Failure modes
- Multi-cloud adopted as a blanket strategy, doubling platform work without workload-level benefit.
- Cross-cloud synchronous calls adding latency and making both clouds a dependency.
- Egress costs from live cross-cloud data reads erasing compute savings.
- DR plans that ignore GPU capacity and index rebuild time, and DR never drilled.
- Configuration drift between clusters in different clouds.
- Data residency rules broken by careless replication.
- On-prem GPUs bought without utilization forecasts, power, or cooling plans.

## Checklist
- [ ] Each workload has a written reason for its cloud placement
- [ ] All clusters are managed by GitOps with shared policies and per-cloud overlays
- [ ] Artifacts replicate by digest on promotion. Big data moves as curated snapshots only
- [ ] Portable training and batch jobs are placed by total cost, including egress and capacity
- [ ] Every service has RTO and RPO targets, a DR strategy, and a recent drill result
- [ ] Hybrid placement is enforced by data class, with one identity and observability layer
- [ ] You served one image from two clouds (or two kind clusters) and watched failover happen
