# Section 16 — Observability in AI Infrastructure

> Lectures 106–112 • Assessments: quiz, **Evaluate Sustained Infrastructure Alerts** ([solution](../exercises/s16_alert_eval.py))
> **After this section you can:** explain what to monitor in AI systems and why, collect GPU telemetry with
> DCGM, scrape and query metrics with Prometheus, build useful Grafana dashboards, trace AI requests end to
> end with OpenTelemetry, write alerts that page only for real problems, and monitor a GPU cluster.
>
> Go deeper: [13 / Lab 27 — DCGM telemetry](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab27_dcgm_telemetry.md),
> [Lab 29 — HPA on custom metrics](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab29_hpa_custom_metrics.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 106 | Why monitoring AI systems matters | AI fails silently: healthy servers with wrong answers. Monitor infra, service, and model |
| 107 | GPU monitoring with DCGM | Utilization lies. Watch SM activity, memory, temperature, power, and XID errors |
| 108 | Metrics collection with Prometheus | Pull-based time series with labels, PromQL, recording rules, and cardinality discipline |
| 109 | Visualization dashboards with Grafana | Dashboards that answer questions: golden signals first, drill-down next |
| 110 | Tracing AI requests with OpenTelemetry | Follow one request through gateway, retrieval, model, and tools, with tokens and cost |
| 111 | Building alerts for AI system failures | Page on symptoms and SLO burn, use `for` and inhibition, and attach runbooks |
| 112 | Lab: monitor a GPU cluster with Prometheus | DCGM exporter, Prometheus, Grafana, and alert rules on Kubernetes |

```mermaid
flowchart LR
  subgraph SRC["Signals"]
    DCGM["DCGM exporter<br/>GPU metrics"]
    NODE["node-exporter, kube-state-metrics"]
    APP["Model servers<br/>/metrics: latency, tokens, queue"]
    OTEL["OpenTelemetry SDK<br/>traces + logs"]
  end
  DCGM & NODE & APP -->|scrape| PROM[(Prometheus<br/>+ long-term store)]
  OTEL --> COL["OTel Collector"] --> TR[(Trace store<br/>Tempo / Jaeger)]
  COL --> LOGS[(Logs<br/>Loki / ELK)]
  PROM --> GRAF["Grafana dashboards"]
  TR & LOGS --> GRAF
  PROM --> AM["Alertmanager<br/>group, inhibit, route"]
  AM --> PAGE["On-call: page + runbook"]
  AM --> TICKET["Ticket queue"]
```

**How to read it:** exporters expose GPU, node, Kubernetes, and application metrics, and Prometheus
scrapes them. Applications also emit traces and logs through OpenTelemetry to a collector. Grafana
shows all three signals together. Prometheus evaluates alert rules and sends them to Alertmanager, which
groups and suppresses related alerts, then routes urgent ones to a page and the rest to a ticket.

**Terms in this diagram.**
- **Exporter**: a small program that reads numbers from a system and publishes them on a `/metrics` web page in
  Prometheus format. The **DCGM exporter** does this for NVIDIA GPUs (Lecture 107).
- **node-exporter, kube-state-metrics**: **node-exporter** publishes machine metrics such as CPU, memory, disk, and
  network. **kube-state-metrics** publishes the state of Kubernetes objects, for example how many pods are pending
  or restarting.
- **Scrape**: Prometheus *pulls* each `/metrics` page on a fixed interval (Lecture 108).
- **Long-term store**: a system that keeps metrics for months, since Prometheus itself keeps only days.
- **OpenTelemetry SDK, OTel Collector**: **OpenTelemetry** (OTel) is the open standard for emitting traces, metrics,
  and logs. The **SDK** is the library inside your code, and the **Collector** is a service that receives, filters,
  and forwards that data (Lecture 110).
- **Tempo / Jaeger, Loki / ELK**: storage backends. **Tempo** and **Jaeger** store traces. **Loki** and **ELK**
  (Elasticsearch, Logstash, Kibana) store and search logs.
- **Alertmanager: group, inhibit, route**: it **groups** related alerts into one notification, **inhibits**
  (mutes) alerts explained by a bigger one, and **routes** each alert to the right team and channel (Lecture 111).
- **Page, runbook**: a **page** is an urgent phone notification to the on-call engineer. A **runbook** is the
  written step-by-step guide for handling that alert.

---

## Lecture 106 — Why monitoring AI systems matters

**Why it matters.** Ordinary services usually fail loudly with errors and timeouts. AI systems also fail
*quietly*: every server is green while predictions get worse, a GPU throttles, or an LLM starts answering
from stale data. Without the right signals, users find these problems before you do.

**In plain words.** A car's dashboard shows speed, fuel, and engine temperature. An AI system also needs
a gauge for "is the driver still reading the map correctly". The engine can run perfectly while the car
drives somewhere wrong.

**Architecture: three layers of AI monitoring.**

```mermaid
flowchart TB
  subgraph L3["Model layer: is it right?"]
    Q["Prediction quality, drift,<br/>LLM eval scores, hallucination rate"]
  end
  subgraph L2["Service layer: is it fast and available?"]
    S["Golden signals: latency, traffic,<br/>errors, saturation<br/>LLM: TTFT, tokens/s, queue"]
  end
  subgraph L1["Infrastructure layer: is the hardware healthy?"]
    I["GPU util, memory, temperature, XID,<br/>node, network, storage"]
  end
  L1 --> L2 --> L3
  SLO["SLOs + error budgets"] -.-> L2 & L3
```

**How to read it:** infrastructure health supports service health, which supports model quality.
Problems flow upward. A failing GPU raises latency, and stale features lower quality. Each layer needs
its own signals, and SLOs tie the service and model layers to what users experience.

**Terms in this diagram.**
- **Drift, LLM eval scores, hallucination rate**: **drift** is when live inputs or outputs stop looking like the
  training data (Section 17). **Eval scores** come from automatically grading a sample of LLM answers. The
  **hallucination rate** is the share of answers containing made-up facts.
- **Golden signals**: latency, traffic, errors, and saturation (how full a resource is), from Google's SRE practice.
- **TTFT, tokens/s, queue**: **TTFT** (time to first token) is how long a user waits before the answer starts
  appearing. **Tokens per second** is how fast it streams. **Queue** is how many requests are waiting for a GPU.
- **GPU util, XID**: **GPU utilization** is how busy the GPU is. An **XID** is an error code the NVIDIA driver logs
  when the GPU faults, for example XID 79, "GPU has fallen off the bus" (Lecture 107).
- **SLOs + error budgets**: an **SLO** (service level objective) is a target such as "99.9% of requests under 2
  seconds". The **error budget** is the failure allowed by that target (here 0.1%). When it's spent, the team slows
  down releases.

**Core ideas.**

| Layer | Key signals | Example failure it catches |
|---|---|---|
| Infrastructure | GPU utilization, memory, temperature, power, XID errors, ECC, NVLink, node and disk | GPU falls off the bus, thermal throttling |
| Service | Request rate, p50/p95/p99 latency, error rate, queue depth. LLM: time to first token, tokens per second | Batching misconfigured, cold starts |
| Model | Prediction distribution, drift (Section 17), accuracy on labeled samples, LLM eval scores | Feature pipeline broke, model degraded |
| Business | Conversions, cost per request, user feedback | A "healthy" model hurting revenue |

- **Metrics, logs, and traces** answer different questions: *how much and how often* (metrics), *what
  exactly happened* (logs), and *where the time went in this request* (traces).
- **SLOs** (for example, "99.9% of requests under 500 ms over 30 days") turn monitoring into decisions. The
  error budget tells you when to slow releases and fix reliability.

**Example: green dashboards, bad answers.** A recommendation service showed 99.99% availability and a
stable p99 for a week while click-through fell 18%. An upstream job had started writing null values for
a key feature, and the model silently used the default. A monitor on the model layer (feature null rate
plus prediction-distribution drift) would have caught it in an hour.

**Senior / FAANG best practice.** Define SLOs on user-visible symptoms for every AI service, monitor all
three layers, and connect them: dashboards link from a latency spike to the GPU and node metrics behind
it. Big tech treats model-quality monitoring as part of the production readiness review. A model without
quality monitors doesn't launch.

---

## Lecture 107 — GPU monitoring with DCGM

**Why it matters.** GPUs are the most expensive, and among the most failure-prone, parts of an AI
cluster. `nvidia-smi` "utilization" only says whether *any* kernel was running, not whether the GPU was
working hard. DCGM gives the real picture and catches hardware faults early.

**In plain words.** "GPU utilization 100%" is like saying a shop was "open" all day. It doesn't tell you
whether one customer or a thousand came in. DCGM counts the customers (how busy the compute units
really are), checks the fridge temperature, and logs every breakdown.

**Architecture: GPU telemetry on Kubernetes.**

```mermaid
flowchart LR
  subgraph NODE["GPU node"]
    GPU["GPUs"] --> DRV["NVIDIA driver + NVML"]
    DRV --> HE["DCGM host engine"]
    HE --> EXP["dcgm-exporter :9400<br/>(DaemonSet via GPU Operator)"]
    KUBE["kubelet pod-resources API"] --> EXP
  end
  EXP -->|"metrics labeled with<br/>gpu, UUID, pod, namespace"| PROM[(Prometheus)]
  PROM --> D["Dashboards: per job, per team"]
  PROM --> A["Alerts: XID, ECC, temperature, idle GPUs"]
```

**How to read it:** DCGM reads detailed counters from the driver. `dcgm-exporter` publishes them to
Prometheus, and asks the kubelet which pod owns each GPU, so every metric carries pod and namespace
labels. That makes it possible to see GPU efficiency per job and per team, and to alert on hardware
problems.

In the diagram, **NVML** (NVIDIA Management Library) is the driver's interface for reading GPU state. **DCGM**
(Data Center GPU Manager) builds on it, and its **host engine** is the background service that collects counters.
Port **9400** is where `dcgm-exporter` serves them. It runs as a **DaemonSet** (one pod per GPU node), installed by
the NVIDIA **GPU Operator** (Section 11, Lecture 71). The kubelet's **pod-resources API** tells it which pod holds
which GPU. **UUID** is each GPU's unique hardware ID. **ECC** (error-correcting code) errors are memory bit-flips
the GPU detected. Too many uncorrectable ones mean the GPU must be drained and replaced. **Idle GPUs** are allocated
to a pod but doing no work, which is pure waste.

**Core ideas.**

| Metric (DCGM field) | What it tells you | Watch for |
|---|---|---|
| `DCGM_FI_DEV_GPU_UTIL` | Fraction of time any kernel ran | Misleading on its own |
| `DCGM_FI_PROF_SM_ACTIVE` / `SM_OCCUPANCY` | How much of the compute units are busy | Low values mean underfed GPUs (data loading, small batches) |
| `DCGM_FI_PROF_PIPE_TENSOR_ACTIVE` | Tensor-core usage | Near zero means you're not using bf16/fp16 math |
| `DCGM_FI_DEV_FB_USED` / `FB_FREE` | GPU memory | Near-full memory risks OOM. Low memory with low activity means the GPU is oversized |
| `DCGM_FI_DEV_GPU_TEMP`, `POWER_USAGE` | Thermal and power state | Above ~85 °C sustained, or hitting the power cap, leads to throttling |
| `DCGM_FI_DEV_CLOCK_THROTTLE_REASONS` | Why clocks dropped | Thermal or power throttling |
| `DCGM_FI_DEV_XID_ERRORS` | Driver-reported faults | XID 79 (fell off the bus), 48/63/64 (ECC), 94/95 (contained/uncontained memory errors) |
| `DCGM_FI_PROF_NVLINK_TX/RX_BYTES`, `PCIE_TX/RX` | Interconnect traffic | Communication bottlenecks |

- **Active health checks:** `dcgmi diag -r 1` (quick) to `-r 3` (long) before putting a node into
  service, or after a fault.
- Fleet-level questions: what's the average SM activity per team? How many GPU-hours were allocated
  but idle? Both feed the cost work in Section 12.

**Example: "100% utilized", 20% busy.** A training job showed `GPU_UTIL` at 100%, but `SM_ACTIVE` was 0.22
and `PIPE_TENSOR_ACTIVE` was 0.03. It was running fp32 with batch size 8. Moving to bf16 autocast and
batch size 64 raised SM activity to 0.71, tensor activity to 0.45, and throughput 3.4×, all visible on
the same dashboard.

**Senior / FAANG best practice.** Run DCGM everywhere through the GPU Operator, label metrics with pod,
job, and team, and build an automatic hardware-health loop: XID or ECC errors and failed diagnostics
cordon and drain the node, open a ticket, and run diagnostics after repair. Report SM activity (not
`GPU_UTIL`) as the efficiency number in capacity reviews.

---

## Lecture 108 — Metrics collection with Prometheus

**Why it matters.** Prometheus is the default metrics system in Kubernetes and the AI ecosystem: model
servers (vLLM, Triton), DCGM, and Kubernetes itself all speak its format. Using it well (labels,
queries, and cardinality) decides whether your monitoring is fast and cheap or slow and expensive.

**In plain words.** Prometheus is a clerk who walks around every 15–30 seconds, reads every meter in the
building, and writes the numbers in a big ledger with tags ("floor 3, GPU 2"). Later you can ask the
ledger questions like "average temperature on floor 3 over the last hour".

**Architecture: Prometheus in a Kubernetes cluster.**

```mermaid
flowchart LR
  SD["Kubernetes service discovery<br/>ServiceMonitor / PodMonitor"] --> P["Prometheus<br/>scrape every 30 s"]
  T1["/metrics model server"] --> P
  T2["/metrics dcgm-exporter"] --> P
  T3["/metrics kube-state-metrics"] --> P
  P --> TSDB[(Local TSDB<br/>~15 days)]
  P --> RR["Recording rules<br/>precompute heavy queries"]
  P --> AR["Alert rules"] --> AM[Alertmanager]
  P -->|remote_write| LT[(Long-term: Thanos,<br/>Mimir, managed Prometheus)]
```

**How to read it:** Prometheus finds targets through Kubernetes service discovery (the Prometheus
Operator uses ServiceMonitors), pulls their `/metrics` pages on an interval, and stores samples in its local
time-series database. Recording rules precompute expensive queries, and alert rules feed Alertmanager.
Remote write sends data to a long-term, scalable store for retention and global queries.

In the diagram, **service discovery** means Prometheus asks the Kubernetes API which pods and services exist, so
new replicas are scraped automatically. A **ServiceMonitor** or **PodMonitor** is a small Kubernetes object that
tells the Prometheus Operator which services or pods to scrape, and on which port. The **TSDB** (time-series
database) is Prometheus's own on-disk storage, typically kept about 15 days. `remote_write` streams every sample to
another system. **Thanos** and **Mimir** are open-source systems that store Prometheus data cheaply in object
storage for months and query across clusters. Managed Prometheus services from cloud providers do the same.

**Core ideas.**

| Metric type | Use | Example |
|---|---|---|
| Counter | Only goes up. Query with `rate()` | `requests_total`, `generated_tokens_total` |
| Gauge | Goes up and down | `gpu_temp`, `queue_depth`, `kv_cache_usage` |
| Histogram | Bucketed distribution. Query percentiles | `request_duration_seconds_bucket` |

```promql
# p99 latency per model over 5 minutes
histogram_quantile(0.99, sum by (le, model) (rate(request_duration_seconds_bucket[5m])))
# error ratio
sum(rate(requests_total{code=~"5.."}[5m])) / sum(rate(requests_total[5m]))
# tokens per second per model (vLLM)
sum by (model_name) (rate(vllm:generation_tokens_total[1m]))
# GPUs allocated but nearly idle for 1 hour
avg_over_time(DCGM_FI_PROF_SM_ACTIVE[1h]) < 0.05
```

- **Cardinality** is the number of unique label combinations, and it's what makes Prometheus slow and
  expensive. Never put user IDs, request IDs, or prompts in labels. Use logs and traces for those.
- **Recording rules** (`job:request_latency:p99_5m`) keep dashboards and alerts fast, and give consistent
  definitions across teams.

**Example: the label that took Prometheus down.** A team added a `prompt_hash` label to an LLM latency
histogram "for debugging". With 12 buckets × 3 models × ~2 million unique prompts per day, the series
count exploded, and Prometheus ran out of memory within hours. They removed the label, kept per-request detail
in traces, and added a CI check that fails when a new metric would add more than 10,000 series.

**Senior / FAANG best practice.** Publish a metrics standard: naming, required labels (service, model,
version, team), banned high-cardinality labels, and standard histograms. Precompute SLO metrics with recording
rules. Use a horizontally scalable backend (Thanos, Mimir, or managed Prometheus) for retention and
global views. Monitor the monitoring itself (scrape failures, rule evaluation time, series count).

---

## Lecture 109 — Visualization dashboards with Grafana

**Why it matters.** During an incident, the dashboard is where people decide what to do. A wall of 60
panels hides the answer, while a well-designed dashboard leads from "users are hurting" to "this GPU on
this node" in two clicks.

**In plain words.** A good dashboard works like a hospital chart: vital signs at the top (is the patient
OK?), then details by organ system, with each number labeled and a normal range shown.

**Architecture: a dashboard hierarchy for an AI platform.**

```mermaid
flowchart TB
  OV["Overview: all AI services<br/>SLO status, error budget left"] -->|"click service"| SVC["Service dashboard: llm-api<br/>RED: rate, errors, duration<br/>TTFT, tokens/s, queue"]
  SVC -->|"click replica or node"| INF["Infrastructure: node + GPU<br/>SM active, memory, temp, XID"]
  SVC -->|"click a slow request"| TR["Trace view: one request<br/>spans with timings"]
  SVC --> MOD["Model quality: drift,<br/>eval scores, feedback"]
  COST["Cost: GPU-hours by team,<br/>idle GPUs"] -.-> OV
```

**How to read it:** the overview shows every service's SLO status. Clicking a service opens its golden
signals and model-specific metrics. From there you drill into the replicas' nodes and GPUs, open the
traces of slow requests, or check model quality. Every level answers one question, and links to the next.

In the diagram, **error budget left** is how much of the allowed failure remains this period. **RED** stands for
rate (requests per second), errors, and duration (latency), the standard trio for any request-serving service.
**SM active** is the fraction of time the GPU's streaming multiprocessors (its compute cores) are working, which
is a truer busyness measure than plain GPU utilization (Section 7). **Temp** is temperature. **Spans** are the
timed steps of one request (Lecture 110). **Feedback** is users' thumbs-up and thumbs-down or corrections.
**GPU-hours by team** is GPU time multiplied by hours, charged to each team (Section 12).

**Core ideas.**
- **Top row = user experience:** request rate, error ratio, p99 latency against the SLO line. For LLMs,
  add time to first token and inter-token latency.
- **Use template variables** (`$cluster`, `$namespace`, `$model`) so one dashboard serves every service.
- **Show thresholds and units** on every panel. Compare with "the same time last week" for context.
- **Annotate deployments** and incidents on the time axis. Most regressions line up with a change.
- **Dashboards as code:** JSON in Git (Grafana provisioning, Grafonnet, or the Terraform provider), reviewed
  like code, not hand-edited in production.

| Panel | Query idea | Why it's there |
|---|---|---|
| SLO burn | Error ratio ÷ (1 − SLO) | One number for "how fast are we spending the budget" |
| Latency heatmap | Histogram buckets over time | Shows bimodal latency that averages hide |
| Queue depth vs replicas | Queue gauge plus replica count | Shows whether autoscaling keeps up |
| GPU SM active by pod | `DCGM_FI_PROF_SM_ACTIVE` | Efficiency and stuck jobs |

**Example: one panel that ended an argument.** Users reported "random slowness". The average-latency
panel looked flat. A latency heatmap showed two bands, ~200 ms and ~4 s. Splitting by replica showed that
the 4 s band came from two pods on nodes with thermal throttling. The heatmap and drill-down found in five
minutes what averages had hidden for a week.

**Senior / FAANG best practice.** Standardize dashboards per service type (generated from templates), put
the SLO at the top, link every alert to the dashboard panel and the runbook that explain it, and delete
dashboards nobody opens. Review dashboards after every incident: did they show the problem quickly?

---

## Lecture 110 — Tracing AI requests with OpenTelemetry

**Why it matters.** Modern AI requests cross many services: gateway, authentication, retrieval, a
reranker, the LLM, tool calls, and safety filters. Metrics say *that* it's slow. Traces show *where*,
for one specific request.

**In plain words.** A trace is a parcel's tracking history: picked up 9:02, sorted 9:40, on the truck
10:15, delivered 14:30. You can see exactly which step was slow for *that* parcel.

**Architecture: one RAG request as a trace.**

```mermaid
flowchart LR
  subgraph TRACE["trace_id 4bf9..., total 2.8 s"]
    G["gateway 2.8 s"] --> AU["auth 12 ms"]
    G --> RAG["rag.answer 2.7 s"]
    RAG --> EMB["embed query 25 ms"]
    RAG --> VEC["vector search 60 ms"]
    RAG --> RR["rerank 140 ms"]
    RAG --> LLM["llm.generate 2.4 s<br/>TTFT 380 ms, 512 tokens,<br/>model=llama-3-70b, cost $0.004"]
    RAG --> SAFE["safety filter 35 ms"]
  end
  TRACE --> COL["OTel Collector<br/>tail sampling: keep errors + slow"] --> STORE[(Tempo / Jaeger / vendor)]
```

**How to read it:** the trace is a tree of **spans**, one per operation, each with a duration and
attributes. Context propagates in HTTP headers (`traceparent`), so every service adds its spans to the
same trace. Here, the LLM span dominates. Its attributes (model, tokens, time to first token, cost) explain
why. The collector keeps all slow or failed traces and a sample of the rest.

**Terms in this diagram.**
- **trace_id**: the unique ID shared by every span of one request, here starting `4bf9...`.
- **gateway, auth**: the front door service, and the authentication check it runs.
- **rag.answer**: the RAG (retrieval-augmented generation) step, which finds relevant documents and asks the LLM to
  answer using them (Section 25).
- **Embed query, vector search, rerank**: turn the question into an embedding vector, find the nearest document
  vectors in a vector database, then re-score the top hits with a more accurate model.
- **llm.generate**: the LLM call. Its attributes record TTFT (time to first token), the number of tokens, the model
  name, and the cost.
- **Safety filter**: a check that blocks harmful or policy-breaking output before it reaches the user (Section 18).
- **Tail sampling**: the collector waits until a trace is complete, then decides whether to keep it, so it can keep
  every error and slow trace while discarding most normal ones. **Head sampling**, by contrast, decides randomly at
  the start, before knowing whether the request will be interesting.

**Core ideas.**

```python
from opentelemetry import trace
tracer = trace.get_tracer("rag-service")

def answer(q):
    with tracer.start_as_current_span("rag.answer") as span:
        with tracer.start_as_current_span("vector.search") as s:
            docs = search(q); s.set_attribute("rag.docs_returned", len(docs))
        with tracer.start_as_current_span("llm.generate") as s:
            out = llm(q, docs)
            s.set_attribute("gen_ai.request.model", "llama-3-70b")
            s.set_attribute("gen_ai.usage.input_tokens", out.prompt_tokens)
            s.set_attribute("gen_ai.usage.output_tokens", out.completion_tokens)
        return out.text
```

- Use **auto-instrumentation** for HTTP, gRPC, databases, and LLM SDKs, and add manual spans around
  business steps.
- Follow the OpenTelemetry **GenAI semantic conventions** (`gen_ai.*` attributes), so tools understand
  tokens, models, and costs.
- **Sampling:** keep 100% of errors and slow requests (tail-based sampling in the collector), and a few
  percent of normal ones.
- **Privacy:** don't record prompts and completions by default. If needed for debugging, redact them,
  restrict access, and set short retention.
- Link traces to metrics (exemplars) and logs (inject `trace_id` into log lines).

**Example: the slow step wasn't the LLM.** A chatbot's p99 was 9 s, and the team was about to buy more GPUs.
Traces of slow requests showed the LLM span was a steady ~2 s, but a "fetch user profile" span took 6 s
when a downstream CRM API retried three times. A 300 ms timeout with a cached fallback cut p99 to 2.6 s,
with no new GPUs.

**Senior / FAANG best practice.** Make trace context propagation mandatory in every service template,
including async queues and agent tool calls. Use tail sampling to keep what matters at affordable cost.
Track tokens and cost per span, so you can attribute LLM spend to features and customers. Big tech links
every alert and dashboard panel to example traces, so engineers jump from symptom to cause.

---

## Lecture 111 — Building alerts for AI system failures

**Why it matters.** Too few alerts and users find outages first. Too many, and on-call engineers start
ignoring pages, until they miss the real one. Good alerting is a design skill: page on what hurts users,
wait long enough to know it's real, and point straight at a fix.

**In plain words.** A smoke alarm that goes off every time you make toast gets its batteries removed.
Good alerts go off for real fires, give you a moment to confirm it isn't toast, and come with an
evacuation plan.

**Architecture: from rule to page.**

```mermaid
flowchart LR
  R["Alert rule<br/>expr + for + labels + runbook"] --> ST{"State"}
  ST -->|"expr true"| PEND["pending"]
  PEND -->|"true for 'for' duration"| FIRE["firing"]
  PEND -->|"false"| INACT["inactive"]
  FIRE -->|"false for keep_firing_for"| RES["resolved"]
  FIRE --> AM["Alertmanager"]
  AM --> GRP["group by service, cluster"]
  GRP --> INH["inhibit: NodeDown silences<br/>GPU alerts on that node"]
  INH --> ROUTE{"severity"}
  ROUTE -->|critical| PAGER["Page on-call"]
  ROUTE -->|warning| TKT["Ticket / chat"]
```

**How to read it:** a rule's expression must stay true for the `for` duration before the alert fires,
which filters out brief spikes. Once firing, `keep_firing_for` stops a brief dip from resolving and
re-paging. Alertmanager groups related alerts, inhibits symptoms of a known cause (a node down explains
its missing GPU metrics), and routes by severity: critical pages a human, warning opens a ticket.

In the diagram, an alert rule has four parts. `expr` is the PromQL query that's true when something is wrong. `for`
is how long it must stay true. **Labels** such as `severity` and `team` decide routing. The **runbook** link tells
the responder what to do. The states are **inactive** (fine), **pending** (condition true, but not yet for long
enough), **firing** (sent to Alertmanager), and **resolved** (cleared). **NodeDown** is an example alert that fires
when a whole node stops responding.

**Core ideas.**

```yaml
groups:
- name: ai-serving
  rules:
  - alert: LLMApiErrorBudgetBurnFast
    expr: |
      (sum(rate(requests_total{service="llm-api",code=~"5.."}[1h])) / sum(rate(requests_total{service="llm-api"}[1h]))) > 14.4 * 0.001
      and
      (sum(rate(requests_total{service="llm-api",code=~"5.."}[5m])) / sum(rate(requests_total{service="llm-api"}[5m]))) > 14.4 * 0.001
    for: 2m
    labels: { severity: critical, team: inference }
    annotations:
      summary: "llm-api is burning its 99.9% error budget 14x too fast"
      runbook_url: https://runbooks.example.com/llm-api/errors
  - alert: GpuXidError
    expr: increase(DCGM_FI_DEV_XID_ERRORS[5m]) > 0
    labels: { severity: warning }
    annotations: { runbook_url: https://runbooks.example.com/gpu/xid }
  - alert: GpuOverheating
    expr: DCGM_FI_DEV_GPU_TEMP > 85
    for: 5m
    keep_firing_for: 2m
    labels: { severity: warning }
```

| Principle | Meaning |
|---|---|
| Page on symptoms | Users see errors or latency (SLO burn). Causes (CPU high) go to tickets or dashboards |
| Multi-window burn rate | Page when both a long (1 h) and a short (5 m) window burn fast: fast detection, few false pages |
| `for` duration | Ignore spikes shorter than the duration you'd act on |
| `keep_firing_for` | Hysteresis: one incident becomes one page, not a flapping series |
| Inhibition and grouping | One page for one cause |
| Every page has a runbook | And every page is actionable, or it's deleted or downgraded |

- **AI-specific alerts:** GPU XID and ECC errors (drain the node), KV-cache saturation and queue growth
  (scale out), model-quality drift (ticket, Section 17), token spend anomalies (Section 12), and
  "no predictions logged" (a broken pipeline).
- A burn rate of 14.4 over 1 hour spends 2% of a 30-day budget in that hour. The common pairs are 14.4×
  (1 h / 5 m) for pages and 6× (6 h / 30 m) for urgent tickets.

**Example: from 140 pages a week to 9.** An ML platform paged on GPU utilization below 20%, any XID, any pod
restart, and p95 above 300 ms for one minute. On-call got ~140 pages a week, and most were ignored. The
team replaced them with SLO burn-rate pages per service, moved hardware faults to automatic
cordon-and-ticket, and added `for` and inhibition. Pages fell to 9 a week, each with a runbook, and the
mean time to acknowledge went from 22 minutes to 4.

**Senior / FAANG best practice.** Alerting is SLO-driven: pages come from error-budget burn on
user-facing SLOs, and everything else is a ticket or a dashboard. Review alert quality monthly (pages per
shift, actionable rate, false positives), and treat a page without action as a bug to fix. Test alert
rules in CI with unit tests (`promtool test rules`) against synthetic series, which is exactly what the
assessment does.

---

## Lecture 112 — Lab: monitor a GPU cluster with Prometheus

**Goal:** install the kube-prometheus-stack and DCGM exporter, scrape GPU and model-server metrics, build
a Grafana dashboard, add alert rules, and verify the rules fire with `promtool` unit tests.

**What you're building.**

```mermaid
flowchart LR
  subgraph K8S["Kubernetes cluster with GPU nodes"]
    DCGM["dcgm-exporter DaemonSet"] --> PROM["Prometheus (kube-prometheus-stack)"]
    VLLM["vLLM or Triton /metrics"] --> PROM
    PROM --> AM["Alertmanager"]
    PROM --> GRAF["Grafana"]
  end
  RULES["gpu-rules.yaml<br/>PrometheusRule"] --> PROM
  TEST["promtool test rules<br/>synthetic series"] -.validates.-> RULES
```

**In plain words.** You set up the standard open-source monitoring stack used on most GPU clusters,
then prove your alerts work before a real incident does it for you.

**How to read the diagram:** `kube-prometheus-stack` is a Helm chart that installs Prometheus, Alertmanager,
Grafana, node-exporter, and kube-state-metrics in one step. The `dcgm-exporter` DaemonSet adds GPU metrics, and
**vLLM** or **Triton** (popular LLM and model inference servers) add serving metrics. Your alert rules live in
`gpu-rules.yaml` as a **PrometheusRule**, the Kubernetes object the Prometheus Operator loads rules from. `promtool
test rules` is Prometheus's built-in unit tester. It feeds **synthetic series** (made-up metric values over time)
into your rules and checks that the expected alerts fire, with no cluster needed.

### Step 1 — Install the monitoring stack and the DCGM exporter

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add gpu-helm-charts https://nvidia.github.io/dcgm-exporter/helm-charts
helm install kps prometheus-community/kube-prometheus-stack -n monitoring --create-namespace \
  --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false
helm install dcgm gpu-helm-charts/dcgm-exporter -n monitoring --set serviceMonitor.enabled=true
# (if you use the NVIDIA GPU Operator, dcgm-exporter is already installed: enable its ServiceMonitor)
kubectl -n monitoring port-forward svc/kps-kube-prometheus-stack-prometheus 9090 &
```

No GPU? Run the lab with the exporter's sample metrics or with `nvidia-smi`-free node-exporter
metrics, and use the `promtool` tests in Step 4, which need no hardware.

### Step 2 — Query GPU metrics

```promql
DCGM_FI_DEV_GPU_TEMP
avg by (Hostname) (DCGM_FI_PROF_SM_ACTIVE)
sum by (namespace, pod) (DCGM_FI_DEV_FB_USED) / 1024            # GiB used per pod
```

### Step 3 — Add alert rules

```yaml
# gpu-rules.yaml
apiVersion: monitoring.coreos.com/v1
kind: PrometheusRule
metadata: { name: gpu-rules, namespace: monitoring, labels: { release: kps } }
spec:
  groups:
  - name: gpu
    rules:
    - alert: GpuOverheating
      expr: DCGM_FI_DEV_GPU_TEMP > 85
      for: 5m
      keep_firing_for: 2m
      labels: { severity: warning }
      annotations: { summary: "GPU {{ $labels.gpu }} on {{ $labels.Hostname }} above 85C for 5m" }
    - alert: GpuIdleAllocated
      expr: avg_over_time(DCGM_FI_PROF_SM_ACTIVE[1h]) < 0.05 and on(pod) DCGM_FI_DEV_FB_USED > 0
      for: 30m
      labels: { severity: ticket }
```

```bash
kubectl apply -f gpu-rules.yaml
```

### Step 4 — Unit-test the rules with promtool

```yaml
# gpu-rules-test.yaml   (rules extracted to a plain rules file: gpu.rules.yaml)
rule_files: [gpu.rules.yaml]
evaluation_interval: 30s
tests:
- interval: 30s
  input_series:
  - series: 'DCGM_FI_DEV_GPU_TEMP{gpu="0",Hostname="a"}'
    values: '70x9 88 88 70x40'          # 1-minute spike: must NOT fire
  - series: 'DCGM_FI_DEV_GPU_TEMP{gpu="3",Hostname="a"}'
    values: '72x19 90x30 72x20'         # 15 minutes hot: must fire
  alert_rule_test:
  - eval_time: 16m
    alertname: GpuOverheating
    exp_alerts:
    - exp_labels: { severity: warning, gpu: "3", Hostname: a }
```

```bash
promtool test rules gpu-rules-test.yaml
```

Then import Grafana dashboard **12239** (NVIDIA DCGM exporter) and add a panel for SM activity by pod.

**Expected results:**
- Prometheus shows the `dcgm-exporter` targets as UP, and GPU metrics have `pod` and `namespace` labels when
  GPUs are allocated to pods.
- `promtool test rules` prints `SUCCESS`: the 1-minute spike on gpu 0 doesn't fire, and gpu 3 fires at
  16 minutes.
- The Grafana dashboard shows temperature, memory, and SM activity per GPU. Under load, SM activity
  rises well above idle.

---

## Assessment — Evaluate sustained infrastructure alerts

**Scenario:** 70 minutes of 30-second samples from a GPU cluster and an LLM API:
- GPU 0 on node `a` has three 1-minute temperature spikes to 88 °C.
- GPU 3 on node `a` runs at 90 °C from minute 10 to minute 25.
- The `llm-api` error ratio is 4% from minute 30 to 50, with one 30-second dip to 1.5% at minute 40.
- Node `b` goes down at minute 60, and its GPU metrics disappear.

**Task:** for both the naive rules (no `for`) and the sustained rules (`for`, `keep_firing_for`,
inhibition), decide which alerts fire and resolve, and when. Then justify the tuned design.

```bash
python3 exercises/s16_alert_eval.py --timeline
```

**Expected output:**

| Alert | Naive rules | Sustained rules |
|---|---|---|
| GpuHot gpu0 (transient spikes) | 3 pages (minutes 5, 20, 33) | None: never true for 5 minutes |
| GpuHot gpu3 (sustained) | Page at 10 | Page at 15.0, resolved at 26.5 |
| ErrorRateHigh llm-api | 2 pages (30, 40.5) | 1 page at 35.0, resolved at 51.5 (the dip is absorbed by `keep_firing_for: 2m`) |
| NodeDown node b | Page at 60 | Page at 61.0 |
| GpuMetricsAbsent node b | Page at 60 | Inhibited by NodeDown |
| **Total** | **8 pages** | **3 pages, 62% fewer**, and every real incident still pages |

**What a strong answer explains:** `for` trades detection delay for precision (5 minutes is fine for
temperature, while SLO burn alerts use multi-window rates instead). `keep_firing_for` prevents one
incident from paging twice. Inhibition makes the on-call see the cause (node down) rather than ten
symptoms. Rules like these should be unit-tested with `promtool` in CI.

---

## FAANG deep-dive notes

**How big tech does it.** Observability is a platform: standard client libraries emit metrics, traces,
and logs with consistent labels. Prometheus-compatible systems (or internal equivalents like Monarch)
store metrics at a global scale, and tracing is sampled end to end. Every service has SLOs, and paging comes
from burn-rate alerts on those SLOs. GPU fleets run continuous health checks with automatic
cordon-and-repair. AI services add model-quality monitors, token and cost telemetry, and eval-score
dashboards to the standard set.

**Staff review questions.**
- What are this service's SLOs, and which alerts page on them?
- Which GPU efficiency number do we report, and how do hardware faults get handled automatically?
- What's our highest-cardinality metric, and what stops a new label from exploding it?
- How many pages per on-call shift, and what share are actionable?

**Interview question.** "Design monitoring and alerting for a 2,000-GPU inference fleet serving 30 models."

**Typical system-design prompt:** *Design observability for an LLM platform: 2,000 GPUs, 30 models, 50,000
requests per second. On-call is drowning in pages, and two outages were reported by customers first.*

**1. Clarify first:** What are the user-facing SLOs (availability, TTFT, tokens per second)? What paged in the
last month, and what was actionable? Which signals exist today? What's the retention requirement and budget?
Are there privacy constraints on prompts?

**2. Back-of-envelope sizing:**
- DCGM: 2,000 GPUs × ~40 metrics = 80,000 series. Node and Kubernetes metrics: ~250 nodes × ~1,500 = ~375,000.
- Services: 30 models × ~200 pods × ~300 series (histograms dominate) ≈ 1.8 million series. Total
  ~2–3 million active series, which is a horizontally scaled Prometheus-compatible store (Mimir, Thanos, or managed).
- Traces: 50,000 requests/s × ~10 spans = 500,000 spans/s. Keep 100% of errors and slow requests plus 1% of
  the rest, ~10,000 spans/s stored.
- Pages: aim for at most 2 actionable pages per shift.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| What pages | Cause metrics (CPU, GPU util) | Symptom / SLO burn | Page on symptoms. Causes go to tickets and dashboards |
| Detection speed | Short `for`, single window | Multi-window burn rate | Multi-window: fast for big burns, quiet for blips |
| Trace sampling | Head sampling 1% | Tail sampling (keep errors and slow) | Tail sampling for debugging value per dollar |
| GPU faults | Page a human | Auto-cordon + ticket | Automate. Hardware faults are routine at scale |
| Prompt logging | Full prompts | Redacted, sampled, access-controlled | Privacy by default |

**4. Follow-up questions with crisp answers:**
- *Why not page on GPU utilization?* It isn't a user symptom, and it's misleading. Low utilization goes to a
  cost ticket, and latency problems show up in SLO burn.
- *How do you know alerts work?* Unit tests with synthetic series in CI (`promtool`), game days that inject
  faults, and monthly page reviews.
- *How do you catch quality regressions that aren't errors?* Model-layer monitors: prediction-distribution
  drift, eval scores on sampled traffic, and user feedback rates (Section 17).

**Debug this (common onsite question):** "Customers report slow answers, but no alert fired and the latency dashboard looks fine."
1. The dashboard shows **average** latency for the whole service. The heatmap shows a second band at 6 s.
2. Split by model: only the 70B model is slow. Its traffic is small, so the service-wide average hides it.
3. Traces of slow requests: TTFT is high, and queue wait dominates. The queue depth for that model has grown for an hour.
4. Metrics: KV-cache usage is at 100%, and the autoscaler scales on CPU, which looks idle.
5. Fix: per-model SLOs and burn-rate alerts, autoscaling on queue depth or KV-cache usage, and p99 panels per model.

The lesson: averages and service-wide aggregates hide the users who are hurting. Define SLOs per
model and per user-visible journey, and alert on their burn.

**5. What separates senior from staff answers:** a senior engineer instruments services, builds
dashboards, and writes reasonable alerts. A staff engineer defines SLOs with product owners, builds alerting
on error-budget burn with tested rules, controls cardinality and sampling as cost decisions, automates
hardware-fault handling, extends monitoring to model quality, and measures the on-call experience as a
system metric.

**Red flags:**
- Paging on GPU utilization or CPU.
- Alerts without a `for` duration or a runbook.
- Average latency as the main panel.
- User IDs or prompts as metric labels.
- No model-quality monitors.
- Alert rules never tested.

---

## Quiz

<details><summary>1. Why is nvidia-smi "GPU utilization" a poor efficiency metric?</summary>
It only measures the fraction of time any kernel was running, not how much of the GPU's compute was
used. SM activity and tensor-pipe activity from DCGM show real efficiency.
</details>

<details><summary>2. Name two GPU XID errors that should drain a node.</summary>
XID 79 (GPU fell off the bus), and the memory errors (XID 48 double-bit ECC, 63/64 row remapping events, 94/95
contained and uncontained errors). Repeated or uncontained errors call for cordon, drain, and diagnostics.
</details>

<details><summary>3. What is metric cardinality, and how do you control it?</summary>
It's the number of unique label combinations (time series). Keep unbounded values (user IDs, request IDs,
prompts) out of labels, use logs and traces for them, and check series counts in CI.
</details>

<details><summary>4. What does a trace show that metrics can't?</summary>
Where the time went in one specific request, across services. Each span has a duration and attributes, such
as tokens, model, and retries, so you can find the slow step for that request.
</details>

<details><summary>5. What do `for` and `keep_firing_for` do in a Prometheus alert?</summary>
`for` requires the condition to hold for a duration before firing, which filters spikes. `keep_firing_for`
keeps an alert firing through brief dips, so one incident doesn't resolve and page again.
</details>

<details><summary>6. Why page on SLO burn rate instead of individual causes?</summary>
Burn rate measures user impact directly and catches every cause. Cause-based pages are noisy and miss
unknown causes.
</details>

<details><summary>7. What does Alertmanager inhibition do? Give an AI example.</summary>
A firing alert suppresses related ones. NodeDown on node b silences GpuMetricsAbsent and GPU alerts for
that node, so on-call sees the cause instead of many symptoms.
</details>

<details><summary>8. How do you make sure alert rules actually work?</summary>
Unit-test them with synthetic series (`promtool test rules`) in CI, run game days that inject faults, and
review page quality regularly.
</details>

## Failure modes
- Monitoring only infrastructure: healthy servers serving wrong answers.
- `GPU_UTIL` taken as efficiency, hiding underfed GPUs.
- High-cardinality labels crashing or bankrupting the metrics backend.
- Averages and service-wide aggregates hiding the users who are hurting.
- Pages on causes, no `for`, no runbook, leading to alert fatigue and ignored pages.
- Traces missing across async hops or tool calls, and prompts stored without redaction.
- Alert rules never tested, failing silently when needed.

## Checklist
- [ ] Every AI service has SLOs and monitors at the infrastructure, service, and model layers
- [ ] DCGM runs on every GPU node, with pod labels and automatic hardware-fault handling
- [ ] You can write PromQL for p99, error ratio, tokens per second, and idle GPUs
- [ ] Dashboards start with the SLO and drill down to GPUs and traces
- [ ] Requests are traced end to end with GenAI attributes and tail sampling
- [ ] Pages come from burn-rate alerts with `for`, inhibition, and runbooks, tested in CI
- [ ] You ran `s16_alert_eval.py`, and can explain every page the naive and tuned rules send
