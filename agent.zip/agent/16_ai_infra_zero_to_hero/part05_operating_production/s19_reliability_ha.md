# Section 19 — Reliability and High Availability

> Lectures 127–133 • Assessments: quiz, **Coordinate a Production AI Service Outage**
> **After this section you can:** explain why AI systems fail in production, build fault-tolerant inference
> (timeouts, retries, circuit breakers, fallbacks), design redundancy and failover for AI APIs, do
> availability math, design highly available GPU clusters, let Kubernetes heal common failures, run chaos
> experiments safely, and lead an incident response for an AI outage.
>
> Go deeper: [13 / Lab 50 — Blue-green models](../../13_sovereign_ai_infra_course/04_serving_inference/lab50_blue_green_models.md),
> [Lab 67 — MinIO HA](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab67_minio_ha.md),
> [Lab 69 — Active-active replication](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab69_active_active_replication.md),
> [Lab 98 — Hardware lifecycle](../../13_sovereign_ai_infra_course/07_sovereign_deployment/lab98_hardware_lifecycle.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 127 | Why AI systems fail in production | Changes, capacity, dependencies, and hardware. GPUs fail often at scale |
| 128 | Fault tolerance in AI inference | Timeouts, retries with jitter, circuit breakers, load shedding, and graceful degradation |
| 129 | Redundancy and failover for AI APIs | N+1 across zones, multi-region and multi-provider failover, and availability math |
| 130 | Designing high-availability AI clusters | HA control planes, zone spread, scarce GPU capacity, and cells to limit blast radius |
| 131 | Auto-healing infrastructure with Kubernetes | Probes, controllers, node health checks, and safe automatic remediation |
| 132 | Chaos engineering for AI systems | Prove resilience with controlled experiments and game days |
| 133 | Lab: build an HA AI inference cluster | Multi-zone replicas, PDBs, fallbacks, and chaos while under load |

```mermaid
flowchart TB
  U((Users)) --> GLB["Global LB / DNS<br/>health-based failover"]
  GLB --> R1["Region A (active)"]
  GLB --> R2["Region B (active or warm)"]
  subgraph R1
    GW1["Gateway: timeouts, retries,<br/>circuit breakers, shedding"] --> Z1["Zone 1 replicas"] & Z2["Zone 2 replicas"] & Z3["Zone 3 replicas"]
    GW1 -.->|"degraded mode"| FB1["Fallback: smaller model,<br/>cache, or external provider"]
  end
  HEAL["Auto-healing: probes, node health,<br/>drain + replace"] -.-> Z1 & Z2 & Z3
  CHAOS["Chaos experiments + game days"] -.->|"verify"| R1
  IC["Incident response:<br/>IC, comms, runbooks, postmortems"] -.-> GLB
```

**How to read it:** reliability comes in layers. A global load balancer fails over between regions.
Inside a region, replicas spread across zones, and the gateway protects them with timeouts, retries,
circuit breakers, and load shedding, switching to a fallback when needed. Auto-healing replaces failed
pods and nodes. Chaos experiments prove all of this works, and when it doesn't, incident response takes
over.

**Terms in this diagram.**
- **Global LB / DNS, health-based failover**: a load balancer or DNS service in front of all regions. When health
  checks show a region failing, it stops sending users there.
- **Region, zone**: a **region** is a geographic area of a cloud, such as `us-east-1`. A **zone** (availability
  zone) is one of several separate data centers inside a region, with its own power and network (Section 3).
- **Active or warm**: an **active** region serves traffic all the time. A **warm** one runs at reduced size, ready
  to scale up and take over.
- **Timeouts, retries, circuit breakers, shedding**: give up on slow calls, try again carefully, stop calling a
  failing dependency, and reject extra load early (all in Lecture 128).
- **Degraded mode, fallback**: a reduced but still useful service, such as a smaller model, a cached answer, or
  another provider's API.
- **Probes, drain + replace**: health checks, and moving pods off a bad node before replacing it (Lecture 131).
- **Chaos experiments + game days**: deliberately injecting failures to test recovery. A **game day** is a planned
  session where the team practices this together (Lecture 132).
- **IC, comms, runbooks, postmortems**: the **IC** (incident commander) coordinates the response. **Comms** keeps
  stakeholders and users updated. **Runbooks** are step-by-step guides. A **postmortem** is the blameless write-up
  afterwards that fixes root causes.

---

## Lecture 127 — Why AI systems fail in production

**Why it matters.** You can't design for reliability without knowing what actually breaks. AI systems
share the classic causes (bad changes, overload, dependencies) and add their own: scarce, failure-prone
GPUs, huge artifacts, and model behavior that can fail without errors.

**In plain words.** Most car breakdowns aren't mysterious. They come from skipped maintenance, overloading,
a bad part, or a mechanic's mistake. AI outages are the same: mostly predictable categories that you can
plan for.

**Architecture: the main failure sources.**

```mermaid
flowchart LR
  subgraph CAUSES["What breaks"]
    CH["Changes: deploys, config,<br/>model versions (most outages)"]
    CAP["Capacity: traffic spikes,<br/>GPU shortage, cold starts"]
    DEP["Dependencies: vector DB,<br/>feature store, LLM provider, DNS"]
    HW["Hardware: GPU XID, HBM ECC,<br/>NVLink, NICs, nodes"]
    DATA["Data: bad features,<br/>corrupt index, drift"]
  end
  CH & CAP & DEP & HW & DATA --> SYM["Symptoms: errors, latency,<br/>wrong answers, cost spikes"]
  SYM --> USERS((Users))
```

**How to read it:** five families of causes produce the symptoms users notice. In most organizations,
*changes* cause the majority of outages, which is why progressive rollouts matter so much (Section 10).
At GPU scale, hardware joins them as a constant background rate of failure, and data problems can produce
wrong answers with no errors at all.

In the diagram, **cold starts** are the minutes a new replica needs to download and load a large model before it can
serve. **Dependencies** are other services yours needs, such as the vector database, feature store, an external
LLM provider, or DNS (name lookup). Under **hardware**: a **GPU XID** is a driver error code, **HBM ECC** errors are
memory faults detected in the GPU's high-bandwidth memory, **NVLink** is the fast GPU-to-GPU link inside a server,
and **NICs** are network cards (Sections 7 and 16). A **corrupt index** is a damaged search index, for example in a
vector database, which returns wrong results without errors. **Drift** is live data slowly moving away from the
training data (Section 17).

**Core ideas.**

| Cause | AI-specific form | Primary defense |
|---|---|---|
| Changes | New model version, new serving image, changed prompt, CUDA or driver upgrade | Canary + automatic rollback, change freezes at peak times |
| Capacity | Viral launch, long prompts, GPU quota, minutes-long cold starts | Headroom, load shedding, warm pools, capacity reservations |
| Dependencies | Vector DB slow, feature store down, external LLM API rate-limited | Timeouts, circuit breakers, fallbacks, caching |
| Hardware | GPU falls off the bus, ECC errors, NIC flaps | Health checks, auto-drain, N+1 capacity, checkpointing for training |
| Data | Null features, corrupted index, stale embeddings | Validation, versioned indexes, quick rollback of data |

- **Hardware at scale is a rate, not an event.** Meta reported 419 unexpected interruptions during a
  54-day, 16,384-GPU Llama 3 training run (about one every 3 hours), with GPU and HBM faults the largest
  share. Design for failure as a normal condition.
- **Silent failures:** a model that returns plausible but wrong output, or a RAG index serving stale data,
  passes health checks. Quality monitors (Sections 16–17) are reliability tools.

**Example: the outage that was a config change.** An LLM API went down for 47 minutes. The cause wasn't
the model or GPUs. A config change lowered the maximum model length on the serving engine, so requests
with long contexts started failing validation, retries tripled the load, and the healthy replicas
overloaded. A canary with an error-rate gate would have caught it within minutes on 5% of traffic.

**Senior / FAANG best practice.** Classify every incident by cause family, and track the distribution over
time. It tells you where to invest (usually change safety first). Treat configuration, prompts, and model
versions as changes subject to the same rollout gates as code. Budget for hardware failure explicitly in
capacity plans (N+1 or N+2).

---

## Lecture 128 — Fault tolerance in AI inference

**Why it matters.** Every dependency will be slow or down sometimes. Fault tolerance decides whether that
becomes a brief degradation or a cascading outage where retries and queues take down everything.

**In plain words.** A good restaurant doesn't stop serving when the espresso machine breaks. It offers
filter coffee (fallback), stops taking more orders than the kitchen can handle (load shedding), and doesn't
keep pressing the broken machine's button (circuit breaker).

**Architecture: resilience patterns around a model call.**

```mermaid
flowchart LR
  REQ((Request)) --> ADM{"Admission:<br/>queue full?"}
  ADM -->|"yes: 429 / 503"| SHED["Shed load early,<br/>with Retry-After"]
  ADM -->|no| CB{"Circuit breaker<br/>for the dependency"}
  CB -->|"open: failing"| FB["Fallback:<br/>smaller model, cache,<br/>other provider, default"]
  CB -->|closed| CALL["Call with deadline<br/>e.g. 2 s"]
  CALL -->|"timeout or 5xx"| RETRY{"Retry budget left?<br/>idempotent?"}
  RETRY -->|"yes: backoff + jitter"| CALL
  RETRY -->|no| FB
  CALL -->|ok| OUT((Response))
  FB --> OUT
```

**How to read it:** admission control rejects work early when queues are full, which is cheaper than
timing out later. A circuit breaker stops calls to a dependency that's failing and goes straight to a
fallback. Calls carry deadlines. Failed calls are retried only if they're idempotent and a retry budget
remains, with exponential backoff and jitter. When everything fails, the fallback gives a degraded but
useful answer.

**Terms in this diagram.**
- **Admission**: the decision at the door whether to accept a request at all.
- **429 / 503, Retry-After**: HTTP **429** means "too many requests" from this client, and **503** means "service
  unavailable" right now. The `Retry-After` header tells the client how many seconds to wait before trying again.
- **Circuit breaker, open, closed**: named after an electrical breaker. **Closed** means calls flow normally. After
  too many failures it **opens**, and calls go straight to the fallback without waiting. After a cool-down, it lets
  a few test calls through (half-open) and closes again if they succeed.
- **Deadline**: the total time the caller allows, here 2 seconds, passed along so downstream services stop work
  that no one will wait for.
- **5xx**: any HTTP server-error status, such as 500, 502, 503, or 504.
- **Retry budget**: a cap on retries, for example at most 10% extra requests, so retries can't multiply load during
  an outage.
- **Idempotent**: safe to repeat. Doing it twice has the same effect as once, like a prediction, unlike charging a
  card.
- **Backoff + jitter**: **exponential backoff** waits longer after each failure (100 ms, 200 ms, 400 ms...).
  **Jitter** adds randomness so thousands of clients don't retry at the same instant.

**Core ideas.**

| Pattern | Rule | AI note |
|---|---|---|
| Timeouts / deadlines | Every call has one. Propagate deadlines downstream | LLM streaming: separate time-to-first-token and total timeouts |
| Retries | Only for idempotent, transient errors. Exponential backoff + jitter. Cap retries (budget ~10% of traffic) | Don't retry long generations blindly. Doubling GPU load during overload causes collapse |
| Circuit breaker | Open after N failures or a high error rate, probe periodically (half-open) | Per model and per provider |
| Bulkheads | Separate pools and queues per tenant or feature | Free tier can't starve paid traffic |
| Load shedding | Reject early (429/503) when the queue exceeds what the SLO allows | Shed by priority: batch and free tier first |
| Graceful degradation | Smaller model, cached answer, fewer RAG documents, disable non-critical features | Have a documented "degraded mode" per feature |
| Hedged requests | Send a second request if the first is slow (p95), use the first reply | Expensive on GPUs, so use only for cheap, critical calls |

```python
import random, time
def call_with_retry(fn, attempts=3, base=0.2, cap=2.0, deadline_s=5.0):
    start = time.monotonic()
    for i in range(attempts):
        try:
            return fn(timeout=max(0.1, deadline_s - (time.monotonic() - start)))
        except (TimeoutError, ConnectionError):
            if i == attempts - 1 or time.monotonic() - start > deadline_s:
                raise
            time.sleep(random.uniform(0, min(cap, base * 2 ** i)))   # full jitter
```

**Example: the retry storm.** A vector DB slowed down from 20 ms to 900 ms. The RAG service retried 3
times with no jitter or budget, and each user retry added three more. Load on the vector DB rose 9×, and it
fell over completely. The fixes: a 150 ms timeout, one retry with jitter, a 10% retry budget, a circuit
breaker, and a fallback that answers without retrieval, with a disclaimer. The next slowdown caused a
4% quality dip instead of an outage.

**Senior / FAANG best practice.** Standardize these patterns in the service mesh or client libraries, so
teams can't forget them. Give every feature a documented degraded mode, and test it (Lecture 132). Prefer
shedding load early to queueing it: a fast 503 that the client retries elsewhere is better than a 30-second
timeout.

---

## Lecture 129 — Redundancy and failover for AI APIs

**Why it matters.** Any single thing can fail: a pod, a node, a zone, a region, a provider. Redundancy at
the right levels, with failover that actually works, is what turns those failures into non-events.

**In plain words.** A hospital has backup generators, two power lines from different substations, and an
agreement with the hospital across town. Each backup covers a different, bigger kind of failure.

**Architecture: redundancy levels for an LLM API.**

```mermaid
flowchart TB
  C((Clients)) --> DNS["Global DNS / anycast LB<br/>health checks every 10 s"]
  DNS --> A["Region A: active<br/>3 zones, N+1 replicas per zone"]
  DNS --> B["Region B: active<br/>3 zones, N+1 replicas per zone"]
  A & B --> GWY["LLM gateway"]
  GWY -->|"primary"| SELF["Self-hosted model"]
  GWY -->|"overflow or failover"| EXT["External provider (different vendor)"]
  A <-->|"replicated: model artifacts,<br/>config, vector index"| B
```

**How to read it:** clients reach the nearest healthy region through a global load balancer that health-checks
each region. Each region spreads replicas over three zones, with one extra replica's worth of capacity per
zone. A gateway can send traffic to an external provider if self-hosted capacity fails or overflows. Model
artifacts, configuration, and indexes are replicated, so either region can serve alone.

In the diagram, **anycast** means many locations announce the same IP address, and the internet routes each user to
the nearest one. **N+1 replicas** means one more replica than the load needs, so losing one doesn't overload the
rest. The **LLM gateway** is a proxy that chooses between model backends. **Overflow or failover** means sending
traffic to the external provider either when local capacity is full or when it's down. Using a **different vendor**
avoids sharing that provider's outages. **Replicated** artifacts are copied to both regions ahead of time.

**Core ideas.**

**Availability math.**
- In series (all components needed): A = A₁ × A₂ × … For example, gateway 99.99% × model 99.9% × vector DB 99.9% =
  **99.79%**.
- In parallel (any one is enough): A = 1 − (1 − A₁)(1 − A₂). For example, two regions at 99.9% =
  **99.9999%**, *if* failures are independent and failover works.
- **Downtime budget per 30 days:** 99.9% = 43.2 minutes. 99.95% = 21.6 minutes. 99.99% = 4.3 minutes.

| Pattern | Recovery time | Cost | Use when |
|---|---|---|---|
| N+1 replicas across zones | Seconds (load balancer) | +1 replica per zone | Always for production |
| Active-passive region (warm standby) | Minutes (scale up and switch DNS) | Low to medium | Most internal AI services |
| Active-active regions | Seconds | ~2× capacity, or 1.5× with shared headroom | User-facing, tight SLOs |
| Multi-provider LLM | Seconds (gateway switch) | Pay per use when failing over | Apps that depend on external LLM APIs |

- **GPU capacity is the hard part.** A standby region is useless if it can't get GPUs during the failover,
  so reserve capacity, or plan degraded capacity (smaller model, shed free tier).
- **Failover must be tested.** An untested failover path usually fails when you need it: stale config,
  expired certificates, missing model artifacts.
- **Multi-provider failover** needs prompt and output compatibility tests, because models behave
  differently. Keep evals for the fallback model (Section 25).

**Example: the zone that went dark.** A cloud zone lost power for 2 hours. Service A ran 6 replicas, all in
one zone because of an affinity rule left over from a GPU-quota workaround, and was down for the full
2 hours. Service B ran 3 replicas per zone across 3 zones with topology spread constraints, lost a third of
its capacity, shed free-tier traffic for 12 minutes while autoscaling replaced capacity, and met its SLO.

**Senior / FAANG best practice.** Set the redundancy level from the SLO and the cost of downtime, write
down which failures each level covers (pod, node, zone, region, provider), and test each failover
regularly, with real traffic in game days. Make sure failures really are independent: separate zones,
dependencies, and config pipelines. A shared global config push can take down every region at once.

---

## Lecture 130 — Designing high-availability AI clusters

**Why it matters.** The cluster is the foundation every model service stands on. A cluster with a single
control-plane node, GPUs in one zone, or one shared failure domain for everything turns small faults into
platform-wide outages.

**In plain words.** Don't build a city with one bridge. Build several, in different places, and divide
the city into districts that can keep working if one gets cut off.

**Architecture: an HA GPU cluster with cells.**

```mermaid
flowchart TB
  subgraph CP["Control plane (managed or 3+ nodes across zones)"]
    E1["etcd 1 (zone a)"] & E2["etcd 2 (zone b)"] & E3["etcd 3 (zone c)"]
  end
  subgraph CELL1["Cell 1: tenants A-M"]
    G1["GPU pool zone a"] & G2["GPU pool zone b"]
  end
  subgraph CELL2["Cell 2: tenants N-Z"]
    G3["GPU pool zone b"] & G4["GPU pool zone c"]
  end
  CP --> CELL1 & CELL2
  ROUTER["Cell router"] --> CELL1 & CELL2
  STORE[(Model artifacts replicated<br/>per zone, local NVMe cache)] -.-> G1 & G2 & G3 & G4
```

**How to read it:** the control plane runs across three zones (managed services like EKS, GKE, and AKS do this
for you), so losing a zone doesn't lose the cluster. Workloads are split into **cells**, independent slices that
each serve a subset of tenants, so a bad deploy or overload in one cell doesn't affect others. GPU pools span
zones, and model artifacts are cached near the GPUs, so recovery doesn't wait on a single storage
endpoint.

In the diagram, **etcd** is the database that stores all Kubernetes state (Section 5, entry A2). Three copies in
three zones keep a majority (2 of 3) alive if a zone fails. **Tenants** are the customers or teams being served.
"Tenants A-M" means those whose names fall in that range are assigned to cell 1, and "N-Z" go to cell 2. The **cell router** sends each
request to its tenant's cell. A **GPU pool** is a group of GPU nodes. **Local NVMe cache** is a copy of model files on
fast SSDs inside each node, so pods start without downloading from remote storage.

**Core ideas.**

| Area | HA design choice |
|---|---|
| Control plane | Managed or 3/5 etcd members across zones. Back up etcd. Upgrade one minor version at a time |
| Node pools | GPU pools in at least 2 zones. Separate system pools for critical add-ons (DNS, CNI, ingress) |
| Spread | `topologySpreadConstraints` by zone, `PodDisruptionBudget`, anti-affinity for replicas |
| Capacity | Reservations or committed capacity for baseline GPUs in each zone. Headroom for N+1 |
| Artifacts | Model weights in regional object storage plus a node-local cache. Images pre-pulled |
| Blast radius | Cells or multiple clusters, staged rollouts per cell, per-tenant quotas |
| Dependencies | DNS (CoreDNS scaled, NodeLocal DNSCache), registries mirrored, no single NFS server for weights |

- **Upgrades are a top outage cause.** Upgrade one cell or cluster at a time, surge GPU nodes (create new
  nodes before draining old ones), and test the new driver and CUDA versions on a canary pool.
- **Training clusters** need different HA: jobs restart from checkpoints, spare nodes are kept hot, and
  scheduler and storage availability matter more than pod replicas (Section 8).

**Example: one NFS server for 400 GPUs.** All inference pods loaded weights from a single NFS server at
startup. When it stalled, every restarting pod hung, autoscaling couldn't add capacity, and a minor node
failure became a 90-minute outage. Moving weights to object storage with a per-node NVMe cache (and
pre-warming on new nodes) removed the shared dependency. Cold start also fell from 6 minutes to 70 seconds.

**Senior / FAANG best practice.** Big tech limits blast radius structurally: cells, staged deployments
per cell and region, and independent control planes. A typical rule is that no single change, failure, or
tenant can affect more than one cell at a time. Inventory every shared dependency of the cluster (DNS,
registry, storage, identity, config), and give each one its own HA design and test.

---

## Lecture 131 — Auto-healing infrastructure with Kubernetes

**Why it matters.** At scale, failures happen too often for humans to fix each one. Kubernetes already heals
crashed pods. With the right health signals, it can also heal sick nodes and GPUs, but automation can also
make outages worse if it's not rate-limited.

**In plain words.** The building has sensors that notice a broken light and call maintenance automatically.
But if every sensor suddenly reports a problem at once, the building shouldn't evacuate everyone. That
probably means the sensors are broken.

**Architecture: the healing loops.**

```mermaid
flowchart TB
  subgraph POD["Pod level"]
    PR["liveness / readiness probes"] --> KL["kubelet restarts container,<br/>Service removes unready pod"]
    RS["Deployment / ReplicaSet"] --> RE["recreate missing pods"]
  end
  subgraph NODE["Node level"]
    NPD["node-problem-detector +<br/>DCGM health (XID, ECC)"] --> COND["Node condition / taint"]
    COND --> NHC["Remediation controller<br/>(NHC, cloud auto-repair)"]
    NHC -->|"rate-limited:<br/>max 10% of nodes"| DRAIN["cordon, drain, reboot or replace"]
  end
  subgraph CAP["Capacity level"]
    CA["Cluster autoscaler / Karpenter"] --> NEW["provision replacement nodes"]
  end
  DRAIN --> CA
```

**How to read it:** pod-level loops restart failed containers and recreate missing pods. Node-level loops
turn hardware and OS problems (detected by node-problem-detector and DCGM) into node conditions and taints.
A remediation controller then drains and repairs or replaces the node, with a limit on how many nodes it may
touch at once. The autoscaler provisions replacement capacity.

**Terms in this diagram.**
- **Kubelet**: the agent on each node that starts containers and runs probes (Section 5, entry A6).
- **ReplicaSet**: the object under a Deployment that keeps the requested number of pod copies running.
- **node-problem-detector**: a DaemonSet that watches kernel logs and system health, and reports problems as node
  conditions.
- **DCGM health (XID, ECC)**: NVIDIA's GPU health checks for driver error codes and memory errors (Section 16).
- **Node condition / taint**: a **condition** is a status flag on the node, such as `GPUUnhealthy=True`. A **taint**
  stops new pods from being scheduled there (Section 5, entry G3).
- **Remediation controller (NHC, cloud auto-repair)**: software that acts on bad conditions. **NHC** (Node Health
  Check operator) is an open-source one, and GKE and EKS have built-in node auto-repair.
- **Rate-limited, max 10% of nodes**: it may only repair a few nodes at a time, so a false alarm can't take down the
  whole cluster.
- **Cordon, drain**: **cordon** marks a node unschedulable. **Drain** evicts its pods safely, respecting
  PodDisruptionBudgets.
- **Cluster autoscaler / Karpenter**: tools that add and remove nodes. **Karpenter** picks the instance types
  itself and launches them quickly (Section 12).

**Core ideas.**

| Failure | Detection | Automatic action |
|---|---|---|
| Container crash or hang | Liveness probe | Restart container (with backoff) |
| Pod not ready (model loading, dependency) | Readiness probe | Remove from Service endpoints |
| Node unreachable | Node controller (NotReady) | Evict pods after a timeout, autoscaler replaces the node |
| GPU XID 79, double-bit ECC | DCGM exporter / health checks | Taint `nvidia.com/gpu=unhealthy:NoSchedule`, drain, reboot or replace |
| Disk or memory pressure | Kubelet conditions | Evict pods, alert |
| Kernel or OS issues | node-problem-detector | Condition, then remediation |

- **Rate-limit remediation:** never let automation drain more than a small share of nodes at once, and stop
  automation if many nodes fail together. That usually means a bad rollout or a monitoring bug, not
  hardware.
- **PodDisruptionBudgets** stop drains from taking too many replicas at once. Size them, so drains can
  still make progress.
- **Training jobs:** healing means restarting the job from its last checkpoint on healthy nodes (elastic
  training, Kubeflow restart policies), and automatically excluding bad nodes.

**Example: the healer that caused an outage.** A new DCGM exporter version reported a false XID on
every node after an upgrade. The remediation controller drained 60% of the GPU fleet within 15 minutes,
which caused a major outage. Adding a "max 10% unhealthy, otherwise pause and page" limit, and canarying monitoring
changes like any other change, made the next false positive a single page with no impact.

**Senior / FAANG best practice.** Automate the repetitive repairs (most GPU and node faults should never
need a human), but give every automated remediation a rate limit, a global circuit breaker, an audit trail,
and a dashboard. At big-tech scale, repair systems handle thousands of hardware events a day, and the
safety limits matter as much as the automation.

---

## Lecture 132 — Chaos engineering for AI systems

**Why it matters.** Redundancy, fallbacks, and auto-healing you haven't tested are assumptions. Chaos
engineering turns them into evidence, by causing small, controlled failures on purpose before real ones
happen at 3 a.m.

**In plain words.** A fire drill. You don't wait for a real fire to find out the exit is blocked. You
practice, with everyone watching, at a time you choose.

**Architecture: a chaos experiment loop.**

```mermaid
flowchart LR
  H["Hypothesis:<br/>'losing one zone keeps<br/>p99 under 2 s and errors under 0.5%'"] --> SS["Measure steady state<br/>(SLO metrics)"]
  SS --> INJ["Inject fault, small blast radius:<br/>Chaos Mesh / Litmus / AWS FIS"]
  INJ --> OBS["Observe SLO metrics,<br/>auto-abort if breached"]
  OBS --> RES{"Hypothesis held?"}
  RES -->|yes| WIDEN["Widen scope next time"]
  RES -->|no| FIX["Fix + add a regression experiment"]
  FIX --> H
```

**How to read it:** start with a hypothesis stated in SLO terms. Measure normal behavior, inject a fault
in a limited scope, and watch the same metrics, with automatic abort conditions. If the system behaved as
expected, widen the scope next time. If not, you've found a weakness cheaply. Fix it, and keep the experiment
as a regression test.

In the diagram, the **steady state** is normal measured behavior, such as p99 latency (the time within which 99% of
requests finish) and error rate. The **blast radius** is how much of the system a fault can affect, so you start
with one pod or a small share of traffic. **Chaos Mesh** and **Litmus** are open-source Kubernetes chaos tools, and
**AWS FIS** (Fault Injection Service) is Amazon's managed one. **Auto-abort if breached** stops the experiment
automatically when the SLO is violated. A **regression experiment** is re-run regularly to make sure the weakness
doesn't come back. The hypothesis **held** if the metrics stayed within the stated limits throughout.

**Core ideas.**

| AI-specific experiment | Validates |
|---|---|
| Kill one inference pod, then one GPU node | Replica count, PDBs, readiness, autoscaling |
| Inject 500 ms latency into the vector DB | Timeouts, circuit breaker, RAG fallback |
| Make the external LLM provider return 429/503 | Gateway failover, quotas, degraded mode |
| Fill the node's local disk (model cache) | Eviction behavior, cache re-download |
| Corrupt or roll back the RAG index version | Index versioning and rollback procedure |
| Drain a whole zone | Topology spread, capacity headroom, GPU availability elsewhere |
| Fail the model registry or artifact store | Can running and new pods still start? |
| Kill a training node mid-run | Checkpoint and restart, bad-node exclusion |

- **Start in staging, then production with tiny blast radius** (one pod, 1% of traffic), with abort
  conditions on SLO metrics and a named owner watching.
- **Game days:** scheduled exercises where teams respond to realistic scenarios using their real runbooks
  and tools. They test people and processes, not just systems.
- **Tools:** Chaos Mesh and LitmusChaos (Kubernetes), AWS Fault Injection Service, Azure Chaos Studio,
  Gremlin, and toxiproxy for dependency faults.

**Example: the fallback that didn't exist.** A chaos experiment made the external LLM provider return 503s
for 5 minutes. The design document promised failover to a self-hosted model. In reality, the fallback's
API key had expired 4 months earlier, and the failover code path had a typo in the model name. Nobody had
noticed because it was never used. Both were fixed, and the experiment now runs weekly in staging.

**Senior / FAANG best practice.** Run chaos continuously for the basics (pod and node loss in production)
and regularly for bigger failures (zone, provider, region) via game days. Require a chaos test for every
documented failover and degraded mode. Big tech practices region evacuation, and some teams practice
"turning off" whole dependencies, because only exercised paths keep working.

---

## Lecture 133 — Lab: build an HA AI inference cluster

**Goal:** run a model API on a three-zone kind cluster with zone spread, a PodDisruptionBudget, probes, and
a fallback. Then kill pods, drain a node, and take out a whole zone while load runs, and measure the error
rate.

**What you're building.**

```mermaid
flowchart LR
  LOAD["hey / k6 load<br/>50 RPS"] --> ING["Service (NodePort / port-forward)"]
  ING --> P1["model pod zone-a"] & P2["model pod zone-b"] & P3["model pod zone-c"]
  P1 & P2 & P3 -.->|"on dependency failure"| FB["fallback response"]
  CHAOS["kubectl delete pod / drain /<br/>cordon a zone"] -.-> P1 & P2 & P3
```

**In plain words.** You build a small cluster that pretends to have three data centers, run a model
service across all of them, then break things on purpose and check that users barely notice.

**How to read the diagram:** `hey` and `k6` are load-testing tools that send a steady 50 requests per second (RPS).
They reach the pods through a Service, exposed with a **NodePort** (a fixed port opened on every node) or with
`kubectl port-forward` (a tunnel from your laptop). One model pod runs in each simulated zone. When a dependency
fails, pods return a **fallback response** instead of an error. The chaos actions are deleting a pod, draining a node,
or cordoning every node of one zone, which simulates losing a whole data center.

### Step 1 — A three-zone cluster

```yaml
# kind-ha.yaml
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
nodes:
- role: control-plane
- role: worker
  labels: { topology.kubernetes.io/zone: zone-a }
- role: worker
  labels: { topology.kubernetes.io/zone: zone-b }
- role: worker
  labels: { topology.kubernetes.io/zone: zone-c }
- role: worker
  labels: { topology.kubernetes.io/zone: zone-a }
```

```bash
kind create cluster --name ha --config kind-ha.yaml
kubectl get nodes -L topology.kubernetes.io/zone
```

### Step 2 — Deploy with spread, PDB, and probes

Use the image classifier from Section 14 (`classifier:1.0`), or any HTTP model server image.

```yaml
# ha-model.yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: model }
spec:
  replicas: 6
  strategy: { rollingUpdate: { maxUnavailable: 0, maxSurge: 1 } }
  selector: { matchLabels: { app: model } }
  template:
    metadata: { labels: { app: model } }
    spec:
      topologySpreadConstraints:
      - { maxSkew: 1, topologyKey: topology.kubernetes.io/zone, whenUnsatisfiable: DoNotSchedule, labelSelector: { matchLabels: { app: model } } }
      terminationGracePeriodSeconds: 30
      containers:
      - name: model
        image: classifier:1.0
        ports: [{ containerPort: 8000 }]
        readinessProbe: { httpGet: { path: /readyz, port: 8000 }, periodSeconds: 3 }
        livenessProbe:  { httpGet: { path: /healthz, port: 8000 }, periodSeconds: 10 }
        startupProbe:   { httpGet: { path: /readyz, port: 8000 }, periodSeconds: 5, failureThreshold: 36 }
        lifecycle: { preStop: { exec: { command: ["sleep", "5"] } } }
---
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata: { name: model }
spec: { minAvailable: 4, selector: { matchLabels: { app: model } } }
---
apiVersion: v1
kind: Service
metadata: { name: model }
spec: { selector: { app: model }, ports: [{ port: 80, targetPort: 8000 }] }
```

```bash
kind load docker-image classifier:1.0 --name ha
kubectl apply -f ha-model.yaml && kubectl rollout status deploy/model
kubectl get pods -o wide -L topology.kubernetes.io/zone       # 2 per zone
kubectl port-forward svc/model 8080:80 &
```

### Step 3 — Run load while breaking things

```bash
# terminal 1: steady load for 5 minutes, recording status codes
hey -z 5m -q 10 -c 5 -m POST -T "multipart/form-data; boundary=X" -D body.bin http://localhost:8080/v1/classify > load.txt &
# terminal 2: chaos, one experiment at a time, wait 60 s between them
kubectl delete pod -l app=model --wait=false $(kubectl get pod -l app=model -o name | head -1 | cut -d/ -f2)
kubectl drain ha-worker --ignore-daemonsets --delete-emptydir-data       # respects the PDB
kubectl uncordon ha-worker
for n in $(kubectl get nodes -l topology.kubernetes.io/zone=zone-a -o name); do kubectl drain ${n#node/} --ignore-daemonsets --delete-emptydir-data; done   # lose a zone
```

`port-forward` pins to one pod and doesn't fail over, so for a realistic measurement run the load from a
pod inside the cluster: `kubectl run load --image=williamyeh/hey --restart=Never -- -z 5m -q 10 -c 5 http://model/healthz`.

### Step 4 — Read the results and restore

```bash
grep -A 10 "Status code distribution" load.txt
kubectl get pods -o wide -L topology.kubernetes.io/zone
for n in $(kubectl get nodes -l topology.kubernetes.io/zone=zone-a -o name); do kubectl uncordon ${n#node/}; done
```

**Expected results:**
- **Pod deletion:** zero or near-zero errors. The Service stops routing to the terminating pod, and a
  replacement becomes ready.
- **Node drain:** the PDB keeps at least 4 pods available, and the drain waits if it would go below that.
- **Zone loss:** pods in zone-a become Pending, because `DoNotSchedule` with `maxSkew: 1` can't place them while
  zone-a has no schedulable nodes. The 4 remaining pods serve all traffic, with a short latency bump and
  few or no errors. Discuss whether `ScheduleAnyway` is better for your SLO.
- The status code distribution shows over 99.5% 200s across all experiments.

---

## Assessment — Coordinate a production AI service outage

**Scenario (live exercise, about 45 minutes):** you're the incident commander. At 14:02 a burn-rate
alert fires: the customer-facing LLM chat API has a 38% error rate, and p99 time to first token is 22 s. In the
last two hours, a new vLLM image was rolled out to 50% of replicas, and the GPU node pool in zone b started a
driver upgrade. Social media complaints are rising, and a large enterprise customer is asking support
for an ETA.

**Deliverable:** run the incident, then write the postmortem. A model answer:

| Phase | What the IC does (model answer) |
|---|---|
| Declare (14:04) | Declare SEV-1 (customer-facing, over 25% errors). Open the incident channel and bridge. Assign roles: **IC** (coordinates, decides), **ops lead** (hands-on mitigation), **comms lead** (status page, support, customer liaison), **scribe** (timeline). Page the vLLM owner and the GPU platform on-call |
| Assess (14:04–14:10) | Ask: what changed? (two changes). What's the user impact? (38% errors, all regions or one? Only zone b plus new-image pods?). Ops checks error rate split by image version and by zone |
| Mitigate first (14:10) | **Stop all changes:** pause the driver upgrade, freeze the rollout. **Roll back the vLLM image** to the previous version, the fastest and most reversible action, even before root cause is known. Shed the free tier to protect paid traffic |
| Communicate (14:12, then every 30 min) | Status page: "We are investigating elevated errors on chat. Mitigation in progress. Next update 14:45." Support gets the same text. The customer liaison briefs the enterprise customer directly. Don't speculate on cause |
| Verify (14:25) | The error rate is still 14%, now only on zone-b nodes. Cordon zone b and shift capacity to the other zones. The error rate falls to 0.3% by 14:38 |
| Stabilize (14:38–15:30) | Monitor for 30 minutes. Keep the change freeze. Downgrade to SEV-2 once the SLO has recovered. Final status update. Collect logs and keep evidence for root cause |
| Close (15:30) | Hand-off notes, postmortem owner assigned, due in 5 business days |

**Postmortem (blameless), model findings:**
- **Root causes (two, interacting):** (1) the new vLLM image changed a default (`max_num_seqs`), so
  KV-cache preemption under load produced 500s. (2) The driver upgrade in zone b left nodes with a CUDA
  driver/runtime mismatch, so pods crash-looped there, shrinking capacity just as (1) hit.
- **Detection:** the burn-rate alert fired 6 minutes after impact began. The canary for the image ran only on
  5% of traffic for 10 minutes at low load, so it didn't exercise high concurrency.
- **Contributing factors:** two risky changes overlapping in one window. No change calendar or lock.
  The driver canary pool didn't run the production image.
- **Actions:** a change lock (one infrastructure and one application change at a time per cell). Canary
  gates include a load test at peak concurrency. Pin serving-engine defaults explicitly in config. The
  driver upgrade pipeline runs the production serving image on canary nodes. Add a runbook for "split error
  rate by version and zone". Practice the rollback in the next game day.
- **Metrics:** time to detect 6 minutes, time to mitigate 36 minutes, error budget consumed ~70% of the month.

**What reviewers look for:** clear roles in the first minutes, **mitigation before root cause** (roll back,
stop changes), regular and honest communication, evidence-driven narrowing (split by version and zone), and a
blameless postmortem with systemic actions, owners, and dates.

---

## FAANG deep-dive notes

**How big tech does it.** Reliability is managed through SLOs and error budgets: when a service spends its
budget, feature launches pause until reliability work restores it. Services run N+1 or N+2 across zones,
critical ones active-active across regions, in cells that limit blast radius. Every change is
progressive and automatically rolled back on SLO regression. Hardware failures are handled by automated
repair pipelines with safety limits. Incident response follows a standard command structure (IC, ops,
comms, scribe), and blameless postmortems are reviewed in weekly operations meetings.

**Staff review questions.**
- What's the SLO, how much budget is left this month, and what happens when it runs out?
- What's the blast radius of a bad deploy, a bad config push, a zone loss, a region loss?
- When did we last test each failover and degraded mode?
- Which automated remediations exist, and what limits stop them from making things worse?

**Interview question.** "Design an LLM inference service with 99.95% availability across two regions."

**Typical system-design prompt:** *Design a 99.95%-available LLM chat API: 5,000 requests per second at
peak, two regions, self-hosted 70B model with an external provider as backup, GPU capacity constrained.*

**1. Clarify first:** Is availability measured per request or per minute? Does degraded quality (a
smaller model) count as available? Is there a data-residency constraint on failover? What's the budget for
duplicate GPU capacity? What are the external provider's quota limits?

**2. Back-of-envelope sizing:**
- Error budget: 0.05% of 30 days = 21.6 minutes per month, or 0.05% of requests (~6.5 million of 13 billion
  per month).
- Capacity: ~30 RPS per 70B replica (2× H100, continuous batching) means ~170 replicas at peak.
  Active-active, each region must carry ~100% when the other fails: 170 per region is costly. Common
  compromise: ~110 per region (65% each, 30% headroom), plus failover overflow to the external provider and
  shedding the free tier.
- Serial availability: gateway 99.99% × region stack 99.95% × vector DB 99.95% ≈ 99.89% in a single
  region, below target. Two independent regions give 1 − (0.0011)² ≈ 99.9999%, so multi-region is required.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Region strategy | Active-passive | Active-active | Active-active for tight SLOs, if capacity and data replication allow |
| Spare GPU capacity | Full duplicate | Partial + provider overflow + shedding | Partial plus documented degraded modes. Full duplicates are rarely affordable |
| Retries | Client and server retries | One layer, with a budget | One retry layer, budgeted, with jitter |
| Remediation | Human-driven | Automated with limits | Automate, with rate limits and global breakers |
| Fallback model | Same model elsewhere | Smaller or external model | Both, with evals proving the fallback is acceptable |

**4. Follow-up questions with crisp answers:**
- *Why roll back before finding the root cause?* Rollback is fast, reversible, and usually fixes
  change-induced outages. Diagnosis can continue once users are safe.
- *How do you stop retries from causing an outage?* One retry layer, exponential backoff with jitter,
  retry budgets (~10%), circuit breakers, and early load shedding.
- *Why are cells useful?* They limit blast radius: a bad change, a poisonous request, or an overloaded tenant
  affects one cell, not everyone.

**Debug this (common onsite question):** "Every night at 02:00, the inference service's error rate spikes to 8% for about 10 minutes."
1. Correlate with schedules: a batch embedding job starts at 02:00 on the same GPU pool (shared quota).
2. Check capacity: the batch pods preempt nothing, but the autoscaler scales inference down at night
   (low traffic), so the cluster is full and burst capacity is gone.
3. Check the failure: inference replicas that restart (routine node rotations at 02:00) can't be scheduled
   again, so the remaining pods overload, return 503s, and clients retry.
4. Fix: a PriorityClass for inference above batch, a minimum replica floor, batch moved to its own
   pool or queue (Kueue), and node rotations moved away from batch start times.

The lesson: recurring incidents are scheduling and capacity interactions. Correlate with every
scheduled job and automation, and make priorities explicit.

**5. What separates senior from staff answers:** a senior engineer applies the patterns: replicas across zones,
probes, timeouts, retries, failover. A staff engineer starts from the SLO and the error budget, does the
availability math, designs blast-radius limits (cells, staged changes), plans scarce GPU capacity and
degraded modes honestly, puts safety limits on automation, and builds the practice (chaos, game days,
incident command, postmortems) that keeps it all true over time.

**Red flags:**
- No timeouts.
- Unbounded retries.
- Replicas in one zone.
- A failover never tested.
- Auto-remediation without rate limits.
- Two risky changes at once.
- Root cause hunted while users are still down.
- Postmortems that blame a person.

---

## Quiz

<details><summary>1. What is the most common cause of production outages, and the main defense against it?</summary>
Changes: deploys, config, and model versions. Defend with progressive rollouts (canary) and automatic
rollback on SLO regression.
</details>

<details><summary>2. Why must retries use backoff, jitter, and a budget?</summary>
Without them, retries multiply load on a struggling dependency (a retry storm) and turn a slowdown into an
outage. Jitter spreads retries out, and a budget caps the extra load.
</details>

<details><summary>3. Three services in series have 99.99%, 99.9%, and 99.9% availability. What's the total?</summary>
0.9999 × 0.999 × 0.999 ≈ 99.79%.
</details>

<details><summary>4. How much downtime does 99.95% allow per 30 days?</summary>
0.05% × 43,200 minutes = 21.6 minutes.
</details>

<details><summary>5. What do topology spread constraints and PodDisruptionBudgets each protect against?</summary>
Spread constraints keep replicas across zones and nodes (protection against zone and node loss). PDBs
limit how many replicas voluntary disruptions, such as drains and upgrades, can remove at once.
</details>

<details><summary>6. Why should automated node remediation be rate-limited?</summary>
A monitoring bug or bad rollout can make many nodes look unhealthy at once. Without limits, automation
drains the fleet and causes an outage itself.
</details>

<details><summary>7. What are the steps of a chaos experiment?</summary>
State a hypothesis in SLO terms, measure steady state, inject a fault with a small blast radius and abort
conditions, observe, then fix the weaknesses found or widen the scope.
</details>

<details><summary>8. In an outage, what does the incident commander do first?</summary>
Declare severity, assign roles (ops, comms, scribe), establish communication, stop ongoing changes, and drive
mitigation (often a rollback) before root-cause analysis.
</details>

## Failure modes
- Untested failover paths that fail when needed (expired keys, missing artifacts).
- Retry storms from multiple retry layers without jitter or budgets.
- Replicas or GPU capacity concentrated in one zone.
- Shared dependencies (NFS, config push, DNS) that defeat redundancy.
- Auto-remediation draining large parts of the fleet on false signals.
- Overlapping risky changes, and canaries that don't exercise peak load.
- Hunting the root cause before mitigating, and postmortems without systemic actions.

## Checklist
- [ ] Every service has an SLO, an error budget, and a policy for when it runs out
- [ ] Calls have deadlines, budgeted retries with jitter, circuit breakers, and a documented degraded mode
- [ ] Replicas spread across zones, with PDBs, N+1 capacity, and tested regional or provider failover
- [ ] Cluster shared dependencies are inventoried and each has an HA design
- [ ] Node and GPU faults heal automatically, with rate limits and a global breaker
- [ ] Chaos experiments cover each failover, and game days run regularly
- [ ] You can run an incident as IC and write a blameless postmortem
- [ ] You ran the HA lab and measured errors during pod, node, and zone failures
