# Part V — Operating AI in Production (Sections 16–20, lectures 106–140)

How to see what's happening, catch quiet failures, keep systems secure and compliant, stay up through
failures, and run across regions and clouds.

| § | Section | You will be able to | Exercise |
|---|---|---|---|
| 16 | [Observability in AI Infrastructure](s16_observability.md) | Monitor GPUs with DCGM, query Prometheus, build drill-down dashboards, trace AI requests, and write alerts that page only for real problems | [`s16_alert_eval.py`](../exercises/s16_alert_eval.py) |
| 17 | [Model and Data Drift](s17_drift.md) | Tell drift types apart, detect drift with Evidently and PSI, monitor in real time, use human review, mitigate, and lead a drift incident review | [`s17_psi_drift.py`](../exercises/s17_psi_drift.py) |
| 18 | [AI Security and Compliance](s18_security_compliance.md) | Threat-model AI systems, design least-privilege IAM, manage secrets and keys, defend models, and map GDPR, HIPAA, and SOC 2 to controls | [`s18_iam_policy_check.py`](../exercises/s18_iam_policy_check.py) |
| 19 | [Reliability and High Availability](s19_reliability_ha.md) | Build fault-tolerant inference, do availability math, design HA GPU clusters, auto-heal safely, run chaos experiments, and lead an outage | — |
| 20 | [Multi-Cloud AI Infrastructure](s20_multi_cloud.md) | Decide when multi-cloud pays off, run GitOps fleets, replicate data wisely, use cost and capacity differences, design DR, and run hybrid | — |

```mermaid
flowchart LR
  P4["Part IV: networking<br/>and serving"] --> S16["§16 See it<br/>metrics, traces, alerts"]
  S16 --> S17["§17 Catch quiet failures<br/>drift, human review"]
  S17 --> S18["§18 Protect it<br/>IAM, secrets, compliance"]
  S18 --> S19["§19 Keep it up<br/>HA, healing, chaos, incidents"]
  S19 --> S20["§20 Run it anywhere<br/>multi-region, multi-cloud, hybrid"]
  S20 --> NEXT["Part VI: edge<br/>and mobile AI"]
```

**How to read it:** Part V is about day-two operations. Section 16 makes the system visible, and Section 17
extends that visibility to model quality. Section 18 secures it and proves compliance. Section 19 keeps it
available when things break, and Section 20 extends availability and capacity across regions, clouds, and
your own data centers.
