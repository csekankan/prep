# Section 17 — Model and Data Drift

> Lectures 113–119 • Assessments: quiz, **Lead a Model Drift Incident Review**, **Detect Population Drift with PSI** ([solution](../exercises/s17_psi_drift.py))
> **After this section you can:** tell data drift from concept drift, explain how drift hurts models and
> the business, detect drift with Evidently and PSI, run drift monitoring in batch and streaming pipelines,
> put humans in the loop where labels are slow, choose between retraining, rebalancing, and rollback, and
> lead a drift incident review.
>
> Go deeper: [13 / Lab 63 — Kafka real-time RAG](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab63_kafka_realtime_rag.md),
> [Lab 66 — Data provenance hashing](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab66_data_provenance_hashing.md),
> [Lab 44 — MLflow model registry](../../13_sovereign_ai_infra_course/04_serving_inference/lab44_mlflow_model_registry.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 113 | What is concept drift vs data drift? | Inputs change (data drift), or the input-to-answer relationship changes (concept drift) |
| 114 | Why drift destroys AI performance | Models assume the future looks like the training data. Drift breaks that silently |
| 115 | Tools for drift detection (Evidently) | Reports and test suites for feature, prediction, and target drift |
| 116 | Real-time drift monitoring pipelines | Log predictions, compare windows to a reference, alert with sensible thresholds |
| 117 | Human-in-the-loop drift evaluation | Labels arrive late or never. Sample, review, and feed back |
| 118 | Mitigation strategies: retraining and rebalancing | Fix the pipeline, roll back, retrain, reweight, or change the model |
| 119 | Lab: build a drift detection pipeline | Evidently plus a scheduled job, a metrics push, and an alert |

```mermaid
flowchart LR
  TRAIN[(Training data<br/>= reference)] --> MODEL["Model in production"]
  REQ((Live traffic)) --> MODEL
  MODEL --> LOG[("Prediction log<br/>features, prediction, model version")]
  LOG --> DET["Drift detection<br/>PSI, KS, Evidently<br/>per feature, prediction, target"]
  LABELS["Delayed labels +<br/>human review"] --> PERF["Performance monitoring"]
  LOG --> PERF
  DET --> TRIAGE{"Triage"}
  PERF --> TRIAGE
  TRIAGE -->|"pipeline bug"| FIX["Fix data, backfill"]
  TRIAGE -->|"real-world change"| RETRAIN["Retrain / reweight / new features"]
  TRIAGE -->|"severe"| RB["Roll back or fall back"]
  RETRAIN --> MODEL
```

**How to read it:** the training data is the reference. Live predictions and their inputs are logged,
and drift detection compares recent windows with the reference per feature and for the predictions.
When labels arrive, from the business or from human review, performance is measured directly. Triage
decides the response: fix a broken pipeline, retrain for a real change, or roll back if users are being
hurt now.

**Terms in this diagram.**
- **Reference**: the "known good" dataset that live data is compared against, usually the training data.
- **Prediction log**: a record of every request's input features, the model's output, and the model version that
  produced it.
- **PSI, KS, Evidently**: **PSI** (population stability index) measures how much a feature's distribution has
  shifted. Under 0.1 is stable, and over 0.25 is a large shift (see the PSI assessment near the end of this section). The **KS** test
  (Kolmogorov–Smirnov) measures the largest gap between two cumulative distributions of a numeric feature.
  **Evidently** is an open-source library that computes these and draws reports (Lecture 115).
- **Per feature, prediction, target**: drift is checked separately on each input, on the model's outputs, and on
  the true outcomes once known.
- **Delayed labels**: true outcomes that arrive later, for example whether a transaction turned out to be fraud,
  which can take weeks.
- **Triage**: quickly deciding how serious a problem is and which response it needs.
- **Backfill**: recomputing the affected days of data correctly after fixing a bug.
- **Reweight**: giving recent or under-represented examples more weight in training (Lecture 118).
- **Roll back or fall back**: return to the previous model version, or to a simple safe rule.

---

## Lecture 113 — What is concept drift vs data drift?

**Why it matters.** "The model got worse" has different causes and different fixes. Naming the type of
drift correctly is the first step of every drift investigation.

**In plain words.** An umbrella shop's sales model learned "rain means umbrella sales". *Data drift*: the
shop moves to a rainier city. Inputs change, but the rule still holds. *Concept drift*: everyone starts
buying raincoats instead. It's just as rainy, but the rule itself changed.

**Architecture: where each drift type lives.**

```mermaid
flowchart LR
  X["Inputs X<br/>features"] -->|"model learned P(y given X)"| Y["Target y<br/>label"]
  DD["Data drift / covariate shift:<br/>P(X) changes"] -.-> X
  PD["Prior / label drift:<br/>P(y) changes"] -.-> Y
  CD["Concept drift:<br/>P(y given X) changes"] -.-> Y
  UP["Upstream changes:<br/>schema, units, nulls, bugs"] -.->|"looks like data drift"| X
```

**How to read it:** a model learns the relationship from inputs to target. *Data drift* changes the
distribution of inputs. *Prior drift* changes how often each outcome happens. *Concept drift* changes the
relationship itself, so the same inputs now mean a different answer. Upstream bugs (a unit change, new
nulls) look like data drift but are really data-quality incidents.

In the diagram, **P(X)** means "how often each kind of input appears", **P(y)** means "how often each outcome
happens", and **P(y given X)** means "the chance of each outcome for a given input", which is what the model
learned. **Covariate shift** is the statistics name for data drift (inputs are also called covariates). **Prior**
drift refers to P(y), the base rate before seeing inputs. **Upstream** means the systems that produce the data
before it reaches the model. A **schema** change renames, adds, or retypes fields. **Nulls** are missing values.

**Core ideas.**

| Type | What changes | Example | Detectable without labels? |
|---|---|---|---|
| Data drift (covariate shift) | P(X) | New market launched, users older, more mobile traffic | Yes: compare feature distributions |
| Prior (label) drift | P(y) | Fraud rate doubles during holidays | Partly: the prediction distribution shifts |
| Concept drift | P(y given X) | Fraudsters change tactics. "Cheap" means something different after inflation | Mostly no: needs labels or proxies |
| Data-quality issue | The pipeline, not the world | Currency in cents instead of dollars, nulls become zeros | Yes: schema and distribution checks |

- **Speed of change:** sudden (a launch, a bug), gradual (inflation), seasonal (holidays), or recurring.
  Each needs a different detection window.
- **Not all drift matters.** A feature the model barely uses can drift a lot with no impact, so weight drift
  by feature importance.

**Example: one shift, two diagnoses.** A loan model's "income" feature shifted up 22% in one quarter.
Investigation found two causes: real wage growth (data drift, where the model under-scored good applicants),
and a new partner sending *monthly* instead of *annual* income for 3% of rows (a data-quality bug,
where incomes looked 12× too small). The bug was fixed at the source, and the real shift went into the next
retraining.

**Senior / FAANG best practice.** Classify every drift alert before acting: data-quality bug, data drift,
prior drift, or concept drift. The fixes are different, and retraining on buggy data bakes the bug in.
Mature teams run data contracts and validation (Section 6) upstream, so most "drift" alerts never reach
the model team.

---

## Lecture 114 — Why drift destroys AI performance

**Why it matters.** Drift is the main reason production models decay. It's silent, because the service
stays up, and it's expensive, because bad predictions cost money long before anyone notices.

**In plain words.** A map is accurate the day it's printed. Every new road and closed bridge makes it a
little more wrong, and the driver doesn't know until they're lost.

**Architecture: how drift turns into business loss.**

```mermaid
flowchart LR
  W["World changes"] --> F["Feature distributions move<br/>outside training range"]
  F --> E["Model extrapolates:<br/>confident and wrong"]
  E --> C["Calibration breaks:<br/>scores no longer match rates"]
  C --> D["Decisions use fixed thresholds<br/>approve, block, rank"]
  D --> B["Business loss:<br/>fraud missed, good users blocked,<br/>bad recommendations"]
  B -.->|"weeks later"| L["Labels reveal it"]
```

**How to read it:** when inputs move outside what the model saw in training, it extrapolates, often
confidently and wrongly. Its scores stop matching real probabilities (calibration), but business rules
still use fixed thresholds, so decisions go wrong. The labels that would reveal the damage often arrive
weeks later.

In the diagram, **extrapolates** means the model guesses for inputs beyond the range it was trained on, where it
has no evidence. **Calibration** means a score of 0.8 really corresponds to an 80% rate. After drift, a "0.8" might
really be 50%. A **fixed threshold** is a cut-off such as "block if score over 0.7", which silently changes meaning
when calibration breaks.

**Core ideas.**
- **Extrapolation:** tree models clamp at the edges of the training range, and linear or neural models can
  extrapolate wildly. Neither is right outside the data.
- **Calibration drift:** a score of 0.8 used to mean an 80% fraud rate, and now means 55%. Threshold-based
  decisions silently change meaning.
- **Feedback loops:** a model's own decisions change future data. Blocked transactions never get labels, and
  recommended items get more clicks. That hides drift and biases retraining.
- **Label delay** (fraud chargebacks ~30–90 days, churn ~months) means drift detection on inputs and
  predictions is the *early warning*. Performance metrics come later.

| Domain | Typical drift driver | Typical label delay |
|---|---|---|
| Fraud | Adversaries adapt | 30–90 days (chargebacks) |
| Recommendations | Catalog and trends | Minutes to hours (clicks) |
| Credit | Economy, policy | Months to years |
| Demand forecasting | Seasons, promotions, shocks | Days |
| LLM apps | New topics, products, prompt styles | Often no labels. Use evals and feedback |

**Example: COVID-era demand.** In March 2020, many retail demand models trained on years of stable data
predicted normal sales of toilet paper and flour while demand jumped several-fold. Teams with drift
monitoring and quick manual-override paths adapted within days. Teams without them kept ordering from
models that were wrong for weeks.

**Senior / FAANG best practice.** Assume every model decays. Set expected retraining cadences from
historical decay curves (backtest: train on month M, test on months M+1, M+2, ...), monitor inputs and
predictions for early warning, keep holdout or exploration traffic to collect unbiased labels despite
feedback loops, and have a fallback (a rules baseline or the previous model) for sudden shifts.

---

## Lecture 115 — Tools for drift detection (Evidently)

**Why it matters.** Writing statistical tests for every feature by hand is slow and error-prone. Tools
like Evidently run the right test per column type, produce readable reports, and plug into pipelines
as pass/fail checks.

**In plain words.** Evidently is a health check-up for your data. You hand it last month's "normal"
sample and this week's sample, and it gives you a report: which measurements changed, by how much, and
whether to worry.

**Architecture: Evidently in a monitoring workflow.**

```mermaid
flowchart LR
  REF[(Reference: training<br/>or a stable past window)] --> EV["Evidently Report / TestSuite<br/>DataDriftPreset, DataSummaryPreset"]
  CUR[(Current window<br/>from prediction log)] --> EV
  EV --> HTML["HTML report<br/>for humans"]
  EV --> JSON["JSON / dict<br/>drift share, per-column scores"]
  JSON --> GATE{"Tests pass?"}
  GATE -->|no| ALERT["Alert / block pipeline"]
  JSON --> PROM["Metrics to Prometheus /<br/>Evidently UI"]
```

**How to read it:** Evidently compares a reference dataset with a current one. Reports give humans a
visual explanation, and the same results as JSON feed automation: tests that fail a pipeline, and
metrics pushed to dashboards and alerts.

In the diagram, a **stable past window** is a recent period known to be healthy, used as the reference instead of
training data when seasonality matters. The **current window** is the latest slice of the prediction log, for
example yesterday. An Evidently **Report** describes the data, and a **TestSuite** adds pass or fail conditions.
**DataDriftPreset** runs a drift test on every column, and **DataSummaryPreset** adds basic statistics such as
missing values and ranges. **Drift share** is the fraction of columns flagged as drifted. The HTML report is a
web page you open in a browser. Metrics go to **Prometheus**, the metrics system from Section 16, or to the
**Evidently UI**, Evidently's optional dashboard service.

**Core ideas.**

```python
import pandas as pd
from evidently import Report
from evidently.presets import DataDriftPreset, DataSummaryPreset

ref = pd.read_parquet("reference.parquet")
cur = pd.read_parquet("last_7_days.parquet")
report = Report([DataDriftPreset(), DataSummaryPreset()])
result = report.run(reference_data=ref, current_data=cur)
result.save_html("drift_report.html")
summary = result.dict()          # per-column drift scores, share of drifted columns
```

The API changed in Evidently 0.7 (`from evidently import Report`). Older tutorials use
`evidently.report` and `evidently.metric_preset`, so pin the version.

| Test | Column type | Good for | Caveat |
|---|---|---|---|
| Kolmogorov–Smirnov | Numeric | Small samples | With large samples, almost everything is "significant" |
| Chi-squared | Categorical | Small samples | Same large-sample issue |
| PSI | Both (binned) | Industry standard in credit and risk. Interpretable thresholds | Depends on binning and sample size |
| Wasserstein distance | Numeric | Large samples. Magnitude of shift | Units depend on the feature (normalize) |
| Jensen–Shannon distance | Both | Large samples, bounded 0–1 | Less intuitive |

- Evidently chooses tests automatically by column type and sample size (statistical tests for small
  samples, distance metrics for large ones). You can override them per column.
- **Alternatives:** NannyML (estimates performance without labels), WhyLabs/whylogs (profiles at scale),
  Alibi Detect (multivariate and embedding drift), and built-in cloud monitors (SageMaker Model Monitor,
  Vertex AI Model Monitoring).
- **Embeddings and text:** use drift on embedding distributions (a domain classifier, or distances to
  centroids) rather than per-dimension tests.

**Example: the test that always failed.** A team used KS tests with p < 0.05 on 2 million rows per day.
Every feature "drifted" every day, so the alert was muted within a week. Switching to Wasserstein
distance for numeric features and PSI with fixed thresholds, plus requiring a drifted share of important
features above 30%, produced ~2 meaningful alerts a month.

**Senior / FAANG best practice.** Choose tests by sample size (effect-size metrics for large data), set
thresholds from historical backtests (how much did these metrics move in normal weeks?), weight by feature
importance, and version reference datasets with the model. Big platforms compute data profiles
continuously and cheaply (whylogs-style sketches), and run detailed reports only on demand.

---

## Lecture 116 — Real-time drift monitoring pipelines

**Why it matters.** Drift detection is only useful if it runs automatically on fresh data, with the right
windows, and alerts the right people. This lecture builds the pipeline around the statistics.

**In plain words.** A smoke detector that only gets checked once a month is useless. Drift monitoring
must sample the air continuously, and sound the alarm when it changes.

**Architecture: batch and streaming drift monitoring.**

```mermaid
flowchart LR
  SVC["Model service"] -->|"async log: features, prediction,<br/>model_version, request_id"| BUS[["Kafka topic<br/>predictions"]]
  BUS --> STREAM["Stream job: Flink / Spark<br/>5-min windows: counts, nulls,<br/>sketches, PSI vs reference"]
  BUS --> LAKE[(Lake / warehouse<br/>partitioned by day)]
  LAKE --> BATCH["Daily batch: Evidently report<br/>per feature, slice, model version"]
  STREAM --> PROM[(Metrics)]
  BATCH --> PROM
  PROM --> AL["Alerts: data quality = page,<br/>drift = ticket"]
  LABELS[(Labels as they arrive)] --> LAKE
  REFS[(Versioned reference<br/>per model version)] --> STREAM & BATCH
```

**How to read it:** the model service logs each prediction asynchronously to a stream, so logging never
slows requests. A streaming job computes cheap statistics over short windows (null rates, counts,
quick drift scores) for fast detection of breakages. A daily batch job computes full reports per feature,
slice, and model version against that version's reference. Data-quality failures page, and gradual drift
opens a ticket.

**Terms in this diagram.**
- **Async log**: the service hands the log record to a background sender and replies to the user without waiting.
- **Kafka topic**: Apache Kafka is a durable message stream. A **topic** is a named stream that many consumers can
  read independently (Section 24).
- **Flink / Spark, 5-min windows**: stream processing engines that compute results over each 5-minute slice of
  events.
- **Sketches**: compact approximate summaries, such as quantile sketches, that estimate a distribution in a few
  kilobytes instead of storing every value.
- **Partitioned by day**: data is stored in one folder per date, so a job reads only the days it needs.
- **Slice**: a subgroup of traffic, such as one country or device type, where drift may hide (Section 10).
- **Versioned reference per model version**: each model version is compared with the data it was trained on, not
  with another version's data.
- **Page vs ticket**: a broken pipeline needs a human now (page). Slow drift can wait for working hours (ticket).

**Core ideas.**

| Window | Detects | Method |
|---|---|---|
| 5–15 minutes (streaming) | Breakages: nulls, schema, units, traffic mix | Null rate, min/max, cardinality, PSI on sketches |
| Daily (batch) | Gradual drift | Evidently or PSI per feature and slice |
| Weekly to monthly | Performance decay once labels arrive | Accuracy, AUC, calibration per slice |

- **Log what the model actually saw:** the computed features at inference time, not raw inputs you plan to
  recompute later (recomputing hides skew).
- **Reference = the training data of the deployed model version.** Change the reference when the model
  changes.
- **Slice:** drift often hides in one country, device, or partner. Monitor key slices, not only the global
  distribution.
- **Sampling:** at high QPS, log 1–10% of requests for drift (with a full log for audits if regulated).
- **Thresholds and noise:** small windows need higher thresholds. The assessment shows how PSI rises
  from sampling noise alone.

**Example: catching a breakage in 10 minutes.** A partner API deployed a change that returned
`country=""` for 40% of requests. The streaming job's null-rate check for `country` went from 0.2% to
41% in the first 5-minute window and paged the data on-call. The team routed that partner's traffic to a
fallback model within 25 minutes. The daily batch report would have caught it the next morning, after
~1.2 million bad predictions.

**Senior / FAANG best practice.** Build drift monitoring into the serving platform, so every model gets
prediction logging, profiles, and default monitors at launch, with per-model thresholds tuned later.
Keep two paths: fast data-quality checks that page, and slower statistical drift that opens tickets. Store
profiles per model version, so comparisons survive model updates.

---

## Lecture 117 — Human-in-the-loop drift evaluation

**Why it matters.** For many models, labels arrive late, are expensive, or never arrive (LLM answers,
content moderation, medical triage). Humans fill the gap: they review samples, label edge cases, and judge
whether a drift is actually a problem.

**In plain words.** Metal detectors at an airport flag bags automatically, but a trained officer opens a
sample of flagged and unflagged bags. The officer's findings tell you whether the detector still works,
and teach it new threats.

**Architecture: a human review loop.**

```mermaid
flowchart LR
  PRED[(Predictions)] --> SAMP["Sampler:<br/>random + low confidence +<br/>drifted slices + disagreements"]
  SAMP --> Q["Review queue<br/>Label Studio / Argilla / vendor"]
  Q --> H["Reviewers: guidelines,<br/>gold questions, 2 reviewers on 10%"]
  H --> LAB[(Labeled sample)]
  LAB --> MET["Estimated accuracy per slice,<br/>with confidence intervals"]
  LAB --> TRAIN["Retraining data"]
  MET --> DEC{"Drift harmful?"}
  DEC -->|yes| ACT["Mitigate (Lecture 118)"]
  DEC -->|no| OK["Accept, update reference"]
```

**How to read it:** the sampler sends reviewers a mix of random predictions (for unbiased accuracy
estimates) and targeted ones (low confidence, drifted slices, cases where two models disagree). Reviewers
follow guidelines, and gold questions and double reviews measure their quality. Labels give accuracy
estimates per slice, feed retraining, and decide whether a detected drift actually harms the product.

In the diagram, **low confidence** cases are those where the model's top score was near the threshold.
**Disagreements** are cases where two models, for example the champion and a challenger, gave different answers.
**Label Studio** and **Argilla** are open-source labeling tools, and a **vendor** is a paid labeling company.
**Guidelines** are the written rules for labeling. **Gold questions** are items with known correct answers mixed in
secretly to measure each reviewer's accuracy. Having **2 reviewers on 10%** measures how often humans agree. A
**confidence interval** gives the range the true accuracy probably lies in, given the sample size.

**Core ideas.**
- **Random sample** for unbiased performance estimates, plus **targeted samples** for finding failure modes
  (active learning). Keep them separate, or estimates are biased.
- **Sample size:** 400 random labels give accuracy ±~5 percentage points (95% CI at p ≈ 0.5). For
  ±2 points, ~2,400 are needed. Budget per slice you care about.
- **Label quality:** written guidelines, gold questions with known answers, inter-annotator agreement
  (Cohen's kappa), and an adjudication step.
- **LLM-as-judge** can scale review for generative outputs, but must be calibrated against humans on a
  regular sample (Section 25).
- **Feedback signals:** thumbs up or down, edits, escalations to human agents. Noisy but abundant, they
  track trends.

**Example: drift that didn't matter, and drift that did.** A support-ticket classifier showed high PSI
on text length after a new mobile app launched (shorter tickets). Reviewing 500 random tickets showed
accuracy unchanged (91% vs 92%), so they accepted it and updated the reference. A month later, a new product
line caused moderate drift in vocabulary. Review showed accuracy on those tickets was 61%, so they collected
2,000 targeted labels and retrained.

**Senior / FAANG best practice.** Keep a standing labeling budget per production model (a fixed number of
random labels per week), with quality controls, so performance is always measured, not just inferred.
Route drifted slices to review automatically. Big tech runs large internal and vendor rating programs
with detailed guidelines, because human judgment is the ground truth for search, ads, and LLM quality.

---

## Lecture 118 — Mitigation strategies: retraining and rebalancing

**Why it matters.** Detecting drift is half the job. The response must match the cause: retraining on a
broken pipeline makes things worse, and rolling back doesn't help when the world has changed for good.

**In plain words.** If a car pulls to one side, you first check whether it's a flat tire (fix the
pipeline) or the road being slanted (adapt). Then you choose: pull over (roll back), adjust the steering
(recalibrate), or get a better car (retrain or redesign).

**Architecture: the mitigation decision tree.**

```mermaid
flowchart TB
  A["Drift confirmed"] --> B{"Data-quality bug?"}
  B -->|yes| C["Fix at source, backfill features,<br/>quarantine bad training data"]
  B -->|no| D{"Users harmed now?"}
  D -->|yes| E["Fall back: previous model,<br/>rules, or conservative threshold"]
  D -->|no| F{"Enough new labels?"}
  E --> F
  F -->|yes| G["Retrain on recent window,<br/>validate on newest slice, canary"]
  F -->|no| H["Recalibrate scores / adjust thresholds,<br/>reweight training data,<br/>collect labels"]
  G --> I["Update reference + monitors"]
  H --> I
```

**How to read it:** first rule out (or fix) data-quality bugs, and never retrain on bad data. If users are
being harmed, switch to a safe fallback while you work. With enough fresh labels, retrain and release
through the normal gates (Section 10). Without them, recalibrate or reweight, and collect labels. Then
update the reference data and monitors for the new model.

In the diagram, to **quarantine** bad training data means to mark it so no future training job uses it. A
**conservative threshold** is a cut-off moved toward the safe side, for example sending more cases to human review.
**Validate on newest slice** means test the retrained model on the most recent labeled data, which is what it will
face next. **Canary** is releasing it to a small share of traffic first (Section 10). **Recalibrate** means refit
the mapping from raw scores to probabilities on recent data, without retraining the whole model.

**Core ideas.**

| Strategy | When | How |
|---|---|---|
| Fix pipeline + backfill | Data-quality incident | Repair the source, recompute features, exclude affected rows from training |
| Roll back / fall back | Sudden harm, new model bad | Registry alias to the previous version, rules baseline, safer threshold |
| Recalibrate | Rankings still good, probabilities off | Refit Platt or isotonic calibration on recent labeled data, move thresholds |
| Retrain (same design) | Gradual drift, labels available | Sliding or expanding window, more weight on recent data |
| Reweight / rebalance | Covariate or prior shift | Importance weights (new/old density ratio), class rebalancing to the new prior |
| Scheduled retraining | Predictable decay | Cadence from backtested decay curves (daily for ads, monthly for churn) |
| Redesign | Concept drift that breaks the features | New features or data sources, online learning for fast-changing domains |

- **Retraining is a release.** It goes through the same pipeline: data validation, evaluation against the
  champion on the *newest* data and on slices, then canary.
- **Watch for feedback loops** when retraining on the model's own decisions. Add exploration or holdout
  traffic.
- **LLM apps:** "retraining" is usually refreshing the RAG index, updating prompts and few-shot examples, or
  fine-tuning adapters. Evals gate every change.

**Example: a measured response.** A fraud model's precision fell from 0.82 to 0.64 over three weeks
while a new attack pattern grew. The team (1) lowered the auto-block threshold and sent borderline cases to
manual review the same day, (2) collected 3,000 reviewed labels in a week, (3) retrained with a new
velocity feature and 3× weight on the last 30 days, and (4) canaried for 48 hours. Precision recovered to
0.80, and they moved retraining from monthly to weekly.

**Senior / FAANG best practice.** Write the drift playbook *before* the incident: owners, fallback options,
who can change thresholds, and the retraining path. Automate scheduled retraining with the same gates as any
release, and measure model staleness (age of training data) as an operational metric. Big tech often runs
continuous training for fast-moving models (ads, feeds), with automatic validation and rollback.

---

## Lecture 119 — Lab: build a drift detection pipeline

**Goal:** build a daily drift job with Evidently, publish drift metrics to Prometheus, alert on
data-quality breakages and significant drift, and produce an HTML report for humans.

**What you're building.**

```mermaid
flowchart LR
  GEN["simulate.py<br/>reference + 3 daily batches:<br/>stable, drifted, broken"] --> DATA[(data/*.parquet)]
  DATA --> JOB["drift_job.py<br/>Evidently + PSI"]
  JOB --> HTML["reports/day_N.html"]
  JOB --> PGW["Pushgateway :9091"]
  PGW --> PROM["Prometheus"] --> RULE["Alert: drift_share > 0.3<br/>or null_rate > 0.05"]
```

**In plain words.** You build a small version of what production teams run every night, and watch it
catch both a real drift and a broken pipeline.

**How to read the diagram:** `simulate.py` creates a reference dataset and three daily batches: one **stable**
(like the reference), one **drifted** (real-world change), and one **broken** (a simulated pipeline bug with many
nulls). They're saved as **Parquet**, a compressed column-based file format. `drift_job.py` runs Evidently and
computes PSI, writes an HTML report per day, and sends the numbers to the Prometheus **Pushgateway** on port 9091.
A Pushgateway holds metrics pushed by short-lived batch jobs, which finish before Prometheus could scrape them.
The alert fires when more than 30% of columns drift (`drift_share > 0.3`) or more than 5% of values are missing
(`null_rate > 0.05`).

### Step 1 — Simulate reference data and three days of traffic

```python
# simulate.py
import numpy as np, pandas as pd, pathlib
rng = np.random.default_rng(0); pathlib.Path("data").mkdir(exist_ok=True)
def batch(n, income_mult=1.0, mobile=0.55, null_rate=0.02):
    df = pd.DataFrame({
        "age": rng.normal(41, 12, n),
        "income": rng.lognormal(10.8, 0.5, n) * income_mult,
        "device": rng.choice(["mobile", "desktop", "tablet"], n, p=[mobile, 0.93 - mobile, 0.07]),
        "txn_amount": rng.exponential(60, n)})
    df.loc[rng.random(n) < null_rate, "txn_amount"] = np.nan
    return df
batch(20000).to_parquet("data/reference.parquet")
batch(5000).to_parquet("data/day_1.parquet")                                  # stable
batch(5000, income_mult=1.22, mobile=0.78).to_parquet("data/day_2.parquet")    # real drift
batch(5000, null_rate=0.31).to_parquet("data/day_3.parquet")                  # pipeline bug
```

### Step 2 — The drift job

```python
# drift_job.py   (pip install evidently==0.7.* pandas pyarrow prometheus-client)
import sys, pandas as pd
from evidently import Report
from evidently.presets import DataDriftPreset
from prometheus_client import CollectorRegistry, Gauge, push_to_gateway

day = sys.argv[1]
ref, cur = pd.read_parquet("data/reference.parquet"), pd.read_parquet(f"data/{day}.parquet")
result = Report([DataDriftPreset(method="psi", threshold=0.1)]).run(reference_data=ref, current_data=cur)
result.save_html(f"reports/{day}.html")

metrics = {m["metric_id"]: m["value"] for m in result.dict()["metrics"]}
share = next(v["share"] for k, v in metrics.items() if k.startswith("DriftedColumnsCount"))
null_rate = cur["txn_amount"].isna().mean()

reg = CollectorRegistry()
Gauge("drift_share", "share of drifted columns", ["model"], registry=reg).labels("risk-v3").set(share)
Gauge("feature_null_rate", "null rate", ["model", "feature"], registry=reg).labels("risk-v3", "txn_amount").set(null_rate)
push_to_gateway("localhost:9091", job="drift_job", registry=reg)
print(f"{day}: drift_share={share:.2f} txn_amount_null_rate={null_rate:.1%}")
```

The structure of `result.dict()` differs between Evidently versions. Print it once and adjust the
lookup. That's also a good reason to pin the version.

### Step 3 — Run it, then wire up alerts

```bash
mkdir -p reports && python simulate.py
docker run -d -p 9091:9091 prom/pushgateway
for d in day_1 day_2 day_3; do python drift_job.py $d; done
python3 exercises/s17_psi_drift.py        # cross-check PSI values with the standard-library implementation
```

```yaml
- alert: FeatureNullRateHigh          # data quality: page
  expr: feature_null_rate > 0.05
  labels: { severity: critical }
- alert: ModelInputDrift              # drift: ticket
  expr: drift_share > 0.3
  for: 1h
  labels: { severity: ticket }
```

Schedule `drift_job.py` daily (cron, Airflow, or a Kubernetes CronJob) once it works.

**Expected results:**
- **day_1:** drift share near 0, and null rate ~2%. No alerts.
- **day_2:** `income` and `device` drift (PSI above 0.1), so drift share is ~0.5 and the drift ticket
  fires. The HTML report shows the shifted histograms.
- **day_3:** the `txn_amount` null rate is ~31%, so the critical data-quality alert fires, even though
  the other features are stable.
- The PSI values roughly match `s17_psi_drift.py` (income ~0.15, device ~0.4).

---

## Assessment — Detect population drift with PSI

**Task:** given a reference window (training data) and a current window (last 7 days), compute PSI for
each feature and the prediction score, classify each one (stable, moderate, or major), find which bin
drives the change, and handle sample size correctly.

```bash
python3 exercises/s17_psi_drift.py
python3 exercises/s17_psi_drift.py --ref ref.csv --cur cur.csv    # your own data
```

**Expected output:**

| Feature | What changed | PSI | Verdict | Top contributor |
|---|---|---|---|---|
| age | Nothing | 0.000 | Stable | — |
| income | 22% upward shift | 0.155 | Moderate | Top income bin |
| device | Mobile 55% → 78%, new `smart_tv` | 0.400 | **Major** | desktop share fell |
| txn_amount | Missing 2% → 31% (pipeline bug) | 0.892 | **Major** | Missing-values bin |
| score (model output) | Shifted up | 0.224 | Moderate | Lowest score bin |

The sample-size part: a same-distribution window of only 150 rows gives PSI 0.097, close to the alert
line, from noise alone. Its 99th-percentile noise floor is 0.157, against ~0.001 at 20,000 rows, so small
windows need a higher threshold. All 8 checks print PASS.

**What a strong answer explains:**
- PSI = Σ (a − e)·ln(a/e) over bins. Bins come from reference quantiles, missing values get their own
  bin, and empty bins are floored to avoid log(0).
- **txn_amount is a data-quality incident**, not drift. Page data on-call, fix the source, and don't
  retrain on it.
- **device** includes a category the model never saw, so check how the model encodes unknowns.
- A 12% shift in income would score only ~0.05 (stable). PSI measures distribution overlap, not business
  impact, so pair it with feature importance and performance.

---

## Assessment — Lead a model drift incident review

**Scenario:** a credit-risk model's approval rate jumped from 38% to 52% over four days. Defaults on new
loans won't be known for months. The PSI report above was produced on day 4. Lead the blameless review.

**Deliverable:** a one-page incident review that covers:

| Section | What to write (model answer in brief) |
|---|---|
| Summary | Approval rate +14 points over 4 days. Cause: ~31% of `txn_amount` values arrived null after a partner's payload change, imputed as 0, which looks like low spending, and so low risk. ~18,000 applications were affected |
| Impact | Estimated extra approvals: ~2,500. Expected excess loss estimated from historical default rates for those score bands. Applications from other partners were unaffected |
| Detection | The daily PSI job flagged `txn_amount` MAJOR on day 4. **Gap:** no streaming null-rate check, so it took 4 days instead of 10 minutes |
| Timeline | Partner deploy (day 0, 14:05), approvals rise (day 0), PSI ticket (day 4, 06:00), triage confirms the bug (day 4, 09:30), fallback threshold for that partner (10:15), partner fix (day 5) |
| Root cause and contributing factors | No data contract with the partner. Imputation silently turned missing into 0. The alert was a ticket, not a page. No approval-rate monitor |
| What went well | The PSI report pointed at the missing bin immediately. The registry allowed a quick per-partner threshold change |
| Actions (owner, date) | (1) Data contract and schema validation at ingest. (2) Streaming null-rate page (>5%). (3) Missing values flagged as missing, not zero, and the model retrained with a missing indicator. (4) Approval-rate guardrail alert. (5) Manual review of the ~2,500 extra approvals. (6) Exclude affected rows from the next training run |
| Decision on the model | **Do not retrain** to "fix" this: it's a data bug. Monitor income and device drift separately (real moderate drift), and schedule their review |

**What reviewers look for:** blameless framing (systems, not people), separating the data-quality incident
from the real drift in the same report, quantified impact, a concrete detection gap with a fix, and
owners and dates on every action.

---

## FAANG deep-dive notes

**How big tech does it.** Every production model has prediction logging, versioned reference profiles,
continuous data-quality checks (streaming), and daily drift reports per slice, built into the serving
platform. Labels flow back automatically where possible, and human rating programs measure quality where
they don't. Retraining is scheduled from decay curves and gated like any release. Fast-moving domains (ads,
feeds) train continuously. Drift incidents get blameless reviews, and the action items usually land
upstream, in data contracts.

**Staff review questions.**
- What's the label delay for this model, and what early-warning signals cover the gap?
- Which alerts page (data quality) and which open tickets (drift), and how were thresholds set?
- How quickly can we fall back, and who decides?
- How do we keep feedback loops from biasing retraining data?

**Interview question.** "How would you know your fraud model is getting worse before the chargebacks arrive?"

**Typical system-design prompt:** *Design drift monitoring for 150 production models across a bank:
fraud (real time), credit (batch), and marketing (daily). Some labels arrive in minutes, some in 90 days.
Regulators require evidence of ongoing monitoring.*

**1. Clarify first:** Which models are high-risk (regulated)? What are the label delays per model? What
logging exists today? Who owns response for each model? What's the retention requirement for audit?

**2. Back-of-envelope sizing:**
- Fraud: 5,000 transactions per second × 200 features. Streaming profiles over 5-minute windows mean
  ~200 features × 288 windows per day, cheap with sketches.
- Logging at 10%: 5,000 × 0.1 × 86,400 × 2 KB ≈ 86 GB per day for drift analysis. Full logs for
  audit go to cold storage.
- Daily reports: 150 models × ~50 features × ~10 slices ≈ 75,000 PSI computations, minutes on one
  Spark job.
- Human review: 400 random labels per week per high-risk model (±5 points accuracy) × 30 high-risk models =
  12,000 labels per week.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Detection test | p-value tests (KS, chi²) | Effect sizes (PSI, Wasserstein) | Effect sizes at large n, with backtested thresholds |
| Window | Short (minutes) | Long (days) | Short for breakages (page), long for drift (ticket) |
| Response | Auto-retrain on drift | Human triage first | Triage first. Auto-retrain only with strong gates and on clean data |
| Labels | Wait for real labels | Human review + proxies | Both: a review budget for now, real labels for confirmation |
| Ownership | Central ML platform | Model team | Platform provides monitors, model teams own thresholds and response |

**4. Follow-up questions with crisp answers:**
- *Why not just retrain automatically when drift is detected?* The drift may be a data bug (retraining
  bakes it in), or harmless. Retraining is a release, and needs triage and gates.
- *How do you detect concept drift without labels?* You mostly can't directly. Use proxies (prediction
  distribution, confidence, user behavior), human review samples, and models that estimate performance
  (NannyML-style), then confirm with labels.
- *Why is PSI noisy on small windows?* Sampling error alone moves bin proportions. Use larger windows, or
  thresholds above the bootstrap noise floor.

**Debug this (common onsite question):** "Drift alerts fire for 40 features every morning, and the team has started ignoring them."
1. Check the tests: KS p-values on 2 million rows, where tiny, harmless shifts are "significant".
2. Check the reference: training data from 18 months ago. Seasonal patterns differ from today.
3. Check the importance: 30 of the 40 features have near-zero importance in the model.
4. Fix: effect-size metrics with thresholds backtested on normal weeks, a rolling recent reference plus the
   training reference, importance-weighted drift scores, one aggregated alert per model, and data-quality
   checks separated out to page on their own.

The lesson: a drift monitor is a product for the on-call team. If it cries wolf, it's worse than none.
Calibrate it on history, and make every alert actionable.

**5. What separates senior from staff answers:** a senior engineer computes drift correctly, builds the
monitoring pipeline, and retrains through gates. A staff engineer designs monitoring as a platform default,
separates data-quality incidents from drift, sets thresholds from backtests and business impact, funds
human review where labels lag, writes playbooks with fallbacks, and pushes fixes upstream into data
contracts.

**Red flags:**
- Retraining on drifted data without checking for bugs.
- p-value tests on millions of rows.
- No prediction logging.
- A reference dataset that doesn't match the deployed model version.
- Drift alerts that page for every feature.
- No fallback plan.

---

## Quiz

<details><summary>1. Define data drift and concept drift, with one example each.</summary>
Data drift: the input distribution P(X) changes, for example more mobile users. Concept drift: the
relationship P(y given X) changes, for example fraudsters change tactics, so the same features now mean
different risk.
</details>

<details><summary>2. Why is drift detection on inputs important even when labels exist?</summary>
Labels often arrive weeks or months late. Input and prediction drift give early warning, before
performance metrics can show the damage.
</details>

<details><summary>3. Why do KS tests on very large samples cause alert fatigue?</summary>
With millions of rows, tiny, harmless differences become statistically significant, so everything
"drifts". Use effect-size measures (PSI, Wasserstein) with backtested thresholds.
</details>

<details><summary>4. Write the PSI formula and the usual thresholds.</summary>
PSI = Σ (actual% − expected%) · ln(actual% / expected%) over bins. Below 0.10 is stable, 0.10–0.25 is moderate,
and above 0.25 is a major shift.
</details>

<details><summary>5. A feature's null rate jumps from 2% to 31% overnight. Is that drift? What do you do?</summary>
It's almost certainly a data-quality incident, not real-world drift. Page data on-call, find and fix the
source, fall back if predictions are harmed, and exclude the bad rows from training.
</details>

<details><summary>6. Why sample both randomly and in a targeted way for human review?</summary>
Random samples give unbiased performance estimates. Targeted samples (low confidence, drifted slices) find
failures efficiently. Mixing them in one estimate biases the result.
</details>

<details><summary>7. When would you recalibrate instead of retrain?</summary>
When the model still ranks cases well but its probabilities no longer match reality (for example after
prior drift). Refitting the calibration or moving thresholds is faster and lower risk than a full retrain.
</details>

<details><summary>8. What must every drift incident review include?</summary>
Quantified impact, a timeline, the detection gap, the root cause and contributing factors (blameless),
whether it was a data bug or real drift, and actions with owners and dates.
</details>

## Failure modes
- Treating pipeline bugs as drift, and retraining on corrupted data.
- p-value tests on huge samples: constant alerts that get muted.
- References that don't match the deployed model version, or are stale.
- Monitoring only global distributions while one slice breaks.
- No early warning for long label delays, and no fallback path.
- Feedback loops biasing retraining data (only approved or recommended items get labels).
- Auto-retraining without gates, shipping a worse model automatically.

## Checklist
- [ ] You can classify a drift alert as a data-quality issue, data drift, prior drift, or concept drift
- [ ] Every model logs features and predictions, with a versioned reference
- [ ] Fast data-quality checks page, and statistical drift opens tickets, with backtested thresholds
- [ ] You can compute PSI by hand, and know its noise floor at your window size
- [ ] High-risk models have a standing human-review budget with quality controls
- [ ] A drift playbook exists: fallback, recalibration, retraining path, owners
- [ ] You ran the drift pipeline lab and `s17_psi_drift.py`, and wrote the drift incident review
