# Section 5 — Kubernetes Fundamentals

> Lectures 29–35 • Assessment: quiz
> **After this section you can:** explain what Kubernetes does for AI workloads, describe pods, nodes and
> clusters, deploy a model with a Deployment and a Service, configure it with ConfigMaps, Secrets and
> volumes, autoscale inference with the Horizontal Pod Autoscaler, package it all as a Helm chart, and
> run it on Minikube. The [Kubernetes component and resource reference](#kubernetes-component-and-resource-reference)
> after the lab then covers every control-plane and node component and every major resource (workloads,
> networking, storage, tenancy, autoscaling, security, and operators), each with an analogy, a diagram, YAML, its
> AI use, and its pitfalls.
>
> Go deeper: [`11_kubernetes/`](../../11_kubernetes/00_K8S_DEPLOYMENT.md) (canary, GitOps, CI) and
> [13 / Lab 4 — Bootstrapping K3s](../../13_sovereign_ai_infra_course/01_foundations_local_sandbox/lab04_bootstrapping_k3s.md).
> GPU scheduling comes in Section 11.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 29 | What is Kubernetes and why AI needs it | You declare what you want ("3 copies of my model"); Kubernetes keeps it true |
| 30 | Pods, nodes, and clusters | A pod is the smallest unit; nodes are machines; the control plane is the brain |
| 31 | Deployments and Services | Deployments keep N pods running and roll out updates; Services give them one stable address |
| 32 | ConfigMaps, Secrets, and volumes | Keep config, credentials, and data outside the image |
| 33 | Horizontal Pod Autoscaling for inference | Add replicas when load rises, remove them when it falls |
| 34 | Helm charts | One templated package per app, with different values per environment |
| 35 | Lab: deploy a model on Minikube | The Section 4 classifier, running with probes, a Service, and autoscaling |

```mermaid
flowchart TB
  DEV[You: kubectl apply -f model.yaml] --> API
  subgraph CP["Control plane (the brain)"]
    API[API server] --> ETCD[(etcd:<br/>desired state)]
    API --> SCHED[Scheduler:<br/>which node?]
    API --> CM[Controllers:<br/>keep desired = actual]
  end
  subgraph N1["Worker node 1"]
    K1[kubelet] --> P1[pod: model-api]
    K1 --> P2[pod: model-api]
  end
  subgraph N2["Worker node 2 (GPU)"]
    K2[kubelet] --> P3[pod: model-api]
  end
  SCHED -.assigns pods.-> K1 & K2
  SVC[Service: model-api<br/>one stable IP / DNS name] --> P1 & P2 & P3
  USERS2((Users)) --> ING[Ingress / LoadBalancer] --> SVC
```

**How to read it:** you hand the API server a description of what you want. It's stored in etcd. The
scheduler picks a node for each pod, and the kubelet on that node starts the containers. Controllers keep
checking that reality matches your description. Users never talk to pods directly: they go through a
Service, which spreads traffic across whichever pods are healthy right now.

---

## Lecture 29 — What is Kubernetes and why AI needs it

**Why it matters.** Docker runs containers on *one* machine. Production AI needs dozens of machines,
replicas that restart when they crash, rolling updates without downtime, autoscaling with traffic, and
fair sharing of expensive GPUs between teams. Kubernetes (K8s) is the standard way to do all of that.

**In plain words.** Kubernetes is an orchestra conductor. You give it the score: "three violins, one
cello, keep playing". If a violinist faints, the conductor brings in a substitute without stopping the
music. You never tell individual musicians what to do.

**Architecture: the reconciliation loop.**

```mermaid
flowchart LR
  WANT["Desired state<br/>replicas: 3"] --> CMP{"Compare"}
  HAVE["Actual state<br/>2 pods running<br/>(1 crashed)"] --> CMP
  CMP -->|"difference: 1 missing"| ACT["Act: create 1 pod"]
  ACT --> HAVE
  CMP -->|"no difference"| WAIT["Wait, check again"]
  WAIT --> CMP
```

**How to read it:** Kubernetes never runs a one-off script like "start 3 pods". It keeps comparing what
you asked for with what exists, and closes the gap. This loop is why it heals itself.

**Core ideas.**

| AI need | What Kubernetes provides |
|---|---|
| Keep the model API up | Restarts crashed containers; replaces pods on failed nodes |
| Ship new model versions safely | Rolling updates and instant rollback |
| Handle traffic spikes | Horizontal Pod Autoscaler; Cluster Autoscaler / Karpenter adds nodes |
| Share GPUs between teams | Resource requests and limits, quotas, namespaces (Sections 11 and 40) |
| Run training jobs | `Job`, `CronJob`, and operators like Kubeflow's PyTorchJob (Section 11) |
| Same platform on any cloud or on-prem | EKS, GKE, AKS, or self-hosted all speak the same API |

**Example.** At 2 a.m. a GPU node's hardware fails. Without Kubernetes, the on-call engineer is paged,
logs in, starts the model on another machine, and updates the load balancer: 40 minutes of downtime.
With Kubernetes, the node is marked `NotReady`, its pods are recreated on healthy nodes, and the Service
stops sending them traffic. Users see a few slow requests, and the engineer reads about it in the morning.

**Senior note.** Kubernetes is not free: it adds operational complexity. For one model on one VM, a
container with `systemd` or a managed endpoint may be the better choice. Kubernetes pays off when you
have many services, many machines, or many teams.

---

## Lecture 30 — Pods, nodes, and clusters explained

**In plain words.** A *cluster* is the whole company. *Nodes* are the office buildings (machines). A
*pod* is a desk where one small team sits: one or more containers that always sit together, share the same
phone extension (IP address), and share a filing cabinet (volumes). The *control plane* is head office,
deciding who sits where.

**Architecture: inside a node and a pod.**

```mermaid
flowchart TB
  subgraph NODE["Node (a VM or physical server with GPUs)"]
    KUBELET[kubelet: talks to the control plane]
    KPROXY[kube-proxy: routes Service traffic]
    RUNTIME[containerd]
    subgraph POD["Pod: model-api-7d9f (IP 10.244.1.17)"]
      C1[container: model server :8000]
      C2["sidecar container: log shipper<br/>(optional)"]
      V[(shared volume:<br/>/models)]
      C1 --- V
      C2 --- V
    end
    KUBELET --> RUNTIME --> POD
  end
```

**How to read it:** the kubelet receives instructions and asks containerd to start the pod's containers.
Containers in a pod share one IP address and can share volumes, so a sidecar can read the main app's logs
or files. Pods are disposable: if one dies, a *new* pod with a new name and IP replaces it.

**Core objects and commands.**

| Object | What it is |
|---|---|
| Cluster | Control plane + worker nodes |
| Node | One machine. `kubectl get nodes` |
| Namespace | A folder for objects, used to separate teams or environments |
| Pod | One or more containers scheduled together on one node |

```bash
kubectl get nodes -o wide                    # machines, their status and IPs
kubectl get pods -n ml -o wide               # pods in namespace "ml", and which node they're on
kubectl describe pod <name> -n ml            # events: why is it Pending / CrashLoopBackOff?
kubectl logs <pod> -n ml -f                  # container output
kubectl exec -it <pod> -n ml -- bash         # shell inside the container
kubectl top pods -n ml                       # CPU and memory (needs metrics-server)
```

**Pod status cheat sheet.**

| Status | Usually means | First command |
|---|---|---|
| `Pending` | No node has enough free CPU, memory, or GPU | `kubectl describe pod` → Events |
| `ImagePullBackOff` | Wrong image name or tag, or no registry credentials | `kubectl describe pod` |
| `CrashLoopBackOff` | The container starts and exits repeatedly | `kubectl logs <pod> --previous` |
| `OOMKilled` | Exceeded its memory limit (often during model loading) | `kubectl describe pod` → Last State |
| `Running` but `0/1 READY` | The readiness probe is failing (model still loading?) | `kubectl describe pod` → probe events |

**Example.** A model pod sits in `Pending` forever. `kubectl describe pod` shows
`0/3 nodes are available: 3 Insufficient memory`. The pod requested 64 Gi of memory, and each node has
32 Gi. The fix is to lower the request to what the model actually needs (measured with `kubectl top`), or
add a bigger node pool.

**Senior / FAANG best practice.** Every production container sets requests, and memory limits equal to
requests for model servers, so the scheduler's view matches reality. Every Deployment has a
PodDisruptionBudget, and replicas are spread across zones with `topologySpreadConstraints`. Model servers
use a `startupProbe` sized to the real model-load time, so Kubernetes doesn't kill a pod while it is
still loading weights.

---

## Lecture 31 — Deployments and Services for AI apps

**Why it matters.** You almost never create pods directly. A **Deployment** keeps the right number of
identical pods running and replaces them gradually when you ship a new version. A **Service** gives those
ever-changing pods one stable address.

**In plain words.** A Deployment is a staffing agency's contract: "always keep 3 trained cashiers at the
store". If one quits, the agency sends another. A Service is the store's phone number: customers always
call the same number, and it rings whichever cashier is free.

**Architecture: a rolling update from v1 to v2.**

```mermaid
flowchart LR
  subgraph DEP["Deployment: model-api (replicas: 3)"]
    RS1["ReplicaSet v1<br/>image: classifier:1.0"]
    RS2["ReplicaSet v2<br/>image: classifier:1.1"]
  end
  RS1 --> A1[pod v1] & A2[pod v1]
  RS2 --> B1[pod v2 ✔ ready] & B2[pod v2 ⏳ starting]
  SVC2["Service: model-api<br/>selector: app=model-api"] -->|only ready pods| A1 & A2 & B1
```

**How to read it:** during an update the Deployment creates a new ReplicaSet for v2 and scales it up
while scaling v1 down. The Service selects pods by label, and sends traffic only to pods whose readiness
probe passes, so a v2 pod that's still loading its model gets no requests.

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: model-api
  namespace: ml
spec:
  replicas: 3
  selector:
    matchLabels: { app: model-api }
  strategy:
    rollingUpdate: { maxUnavailable: 0, maxSurge: 1 }    # never drop below 3 ready pods
  template:
    metadata:
      labels: { app: model-api }
    spec:
      containers:
        - name: api
          image: registry.example.com/classifier:1.0
          ports: [{ containerPort: 8000 }]
          resources:
            requests: { cpu: "1", memory: 2Gi }
            limits:   { memory: 3Gi }
          readinessProbe:                   # "may I receive traffic?"
            httpGet: { path: /healthz, port: 8000 }
            periodSeconds: 5
          livenessProbe:                    # "am I stuck and should be restarted?"
            httpGet: { path: /healthz, port: 8000 }
            periodSeconds: 10
            failureThreshold: 3
          startupProbe:                     # "give me up to 5 minutes to load the model"
            httpGet: { path: /healthz, port: 8000 }
            periodSeconds: 10
            failureThreshold: 30
---
apiVersion: v1
kind: Service
metadata:
  name: model-api
  namespace: ml
spec:
  selector: { app: model-api }
  ports: [{ port: 80, targetPort: 8000 }]
  type: ClusterIP            # internal only; expose with an Ingress or type: LoadBalancer
```

```bash
kubectl apply -f model-api.yaml
kubectl rollout status deploy/model-api -n ml
kubectl set image deploy/model-api api=registry.example.com/classifier:1.1 -n ml   # ship v1.1
kubectl rollout undo deploy/model-api -n ml                                          # roll back
```

| Service type | Reachable from | Use for |
|---|---|---|
| `ClusterIP` | Inside the cluster (`model-api.ml.svc.cluster.local`) | Internal model APIs |
| `NodePort` | Each node's IP on a high port | Local testing |
| `LoadBalancer` | A cloud load balancer with a public or private IP | Simple external exposure |
| Ingress / Gateway API | One entry point routing by host and path | Many APIs behind one domain, TLS |

**Example.** A team had no readiness probe. During every rollout, new pods got traffic while their 6 GB
model was still loading, and about 2% of requests failed for a minute. Adding a readiness probe on
`/healthz` (which returns "ok" only once the model is loaded) made rollouts invisible to users.

**Senior note.** Set `startupProbe` generously for big models. A liveness probe that fires during a
3-minute model load restarts the pod forever, which shows up as `CrashLoopBackOff` even though nothing is
actually broken.

---

## Lecture 32 — ConfigMaps, Secrets, and volumes

**Why it matters.** The same image should run in dev, staging, and production. What changes between them
(config, credentials, data) must live *outside* the image.

**In plain words.** The image is a new phone fresh from the factory. A ConfigMap is your settings, a Secret
is your passwords (kept in a safer place), and a volume is your photo storage, which survives even if
you replace the phone.

**Architecture: what gets injected into a pod.**

```mermaid
flowchart LR
  CMAP["ConfigMap: model-config<br/>MODEL_NAME, BATCH_SIZE,<br/>LOG_LEVEL"] -->|env vars| POD2
  SEC["Secret: model-secrets<br/>HF_TOKEN, DB_PASSWORD"] -->|"env var or file<br/>/var/run/secrets/..."| POD2
  PVC["PersistentVolumeClaim:<br/>model-weights (50 Gi)"] -->|"mounted at /models"| POD2
  PV[(PersistentVolume:<br/>EBS / PD / NFS)] --- PVC
  SC["StorageClass:<br/>gp3, standard-rwo"] -.creates.-> PV
  POD2[pod: model-api]
```

**How to read it:** config and secrets arrive as environment variables or files. Storage is *claimed*
with a PersistentVolumeClaim (PVC): the pod asks for "50 Gi", and the StorageClass creates a real disk
(a PersistentVolume) in the cloud to satisfy it.

**Terms in this diagram.**
- **Env vars** (environment variables): named text values the operating system hands to a program at
  start, like `MODEL_NAME=resnet18`. The app reads them with `os.environ["MODEL_NAME"]`.
- **MODEL_NAME, BATCH_SIZE, LOG_LEVEL**: example settings: which model to load, how many requests to
  process together on the GPU, and how detailed the logs should be (`info`, `debug`).
- **HF_TOKEN, DB_PASSWORD**: example secrets. `HF_TOKEN` is a Hugging Face access token, needed to
  download gated models such as Llama. `DB_PASSWORD` is a database password.
- **/var/run/secrets/...**: a folder inside the container where Kubernetes can place secrets as files,
  which is safer than environment variables because they don't show up in process listings or crash
  reports.
- **50 Gi**: 50 gibibytes, about 53.7 GB. Kubernetes uses binary units: `Gi` means 1024³ bytes.
- **EBS / PD / NFS**: the real storage behind the volume. EBS (Elastic Block Store) is an AWS network
  disk, PD (Persistent Disk) is the Google Cloud equivalent, and NFS (Network File System) is a shared
  folder served over the network that many pods can mount at once.
- **gp3, standard-rwo**: names of StorageClasses. `gp3` is AWS's general-purpose SSD disk type, and
  `standard-rwo` is GKE's default class (RWO means ReadWriteOnce, one node at a time).

```yaml
apiVersion: v1
kind: ConfigMap
metadata: { name: model-config, namespace: ml }
data:
  MODEL_NAME: resnet18
  BATCH_SIZE: "8"
  LOG_LEVEL: info
---
apiVersion: v1
kind: Secret
metadata: { name: model-secrets, namespace: ml }
type: Opaque
stringData:
  HF_TOKEN: replace-me            # in real clusters, create this from a secrets manager, not a file in git
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata: { name: model-weights, namespace: ml }
spec:
  accessModes: [ReadWriteOnce]    # ReadOnlyMany / ReadWriteMany need a storage class that supports them
  resources: { requests: { storage: 50Gi } }
```

Used inside the Deployment's pod template:

```yaml
      containers:
        - name: api
          envFrom:
            - configMapRef: { name: model-config }
          env:
            - name: HF_TOKEN
              valueFrom: { secretKeyRef: { name: model-secrets, key: HF_TOKEN } }
          volumeMounts:
            - { name: weights, mountPath: /models, readOnly: true }
      volumes:
        - name: weights
          persistentVolumeClaim: { claimName: model-weights }
```

| Thing | Use | Watch out |
|---|---|---|
| ConfigMap | Non-sensitive settings | Pods don't restart automatically when it changes (Helm can add a checksum annotation to trigger it) |
| Secret | Tokens, passwords, keys | Only **base64-encoded**, not encrypted, unless you enable encryption at rest; restrict with RBAC; prefer External Secrets / CSI driver with a cloud secrets manager |
| `emptyDir` | Scratch space for the pod's lifetime | Deleted with the pod |
| PVC | Data that must outlive pods | `ReadWriteOnce` disks attach to one node at a time |

**Example.** A team stored their Hugging Face token in a ConfigMap. Every developer with read access to
the namespace could see it in plain text with `kubectl get cm -o yaml`. Moving it to a Secret with RBAC
restricted to the service account (and later to External Secrets backed by AWS Secrets Manager) closed
the gap. Section 18 covers secrets management in depth.

**Senior / FAANG best practice.** Secrets never live in Git, images, or ConfigMaps. Pods fetch them at
runtime from a central secrets manager, using workload identity (IRSA on AWS, Workload Identity on GCP),
so there are no long-lived keys to leak. Config changes roll out like code: a checksum annotation
restarts pods in waves, never all at once.

---

## Lecture 33 — Horizontal Pod Autoscaling for AI inference

**Why it matters.** Inference traffic is uneven: quiet at night, spiky during sales or launches. Running
enough replicas for the peak all the time wastes money; running for the average drops requests at peak.

**In plain words.** A supermarket opens more checkout lanes when the queues get long and closes them when
it's quiet. The HPA is the manager watching the queues.

**Architecture: the HPA control loop.**

```mermaid
flowchart LR
  PODS3[model-api pods] -->|CPU / memory| MS[metrics-server]
  PODS3 -->|"/metrics: requests in flight,<br/>queue depth, GPU util"| PROM[Prometheus]
  PROM --> ADP[Prometheus Adapter /<br/>KEDA]
  MS --> HPA
  ADP --> HPA["HPA (every 15 s):<br/>desired = ceil(current × metric ÷ target)"]
  HPA -->|"scale replicas<br/>(min 2, max 10)"| DEP3[Deployment]
  DEP3 --> PODS3
  DEP3 -.pods Pending: no room.-> CA["Cluster Autoscaler /<br/>Karpenter adds a node"]
```

**How to read it:** the HPA reads metrics, computes how many replicas would bring the metric back to its
target, and updates the Deployment. If new pods can't fit on existing nodes, a node autoscaler adds
machines. For GPU inference, CPU is often the wrong signal, so custom metrics come from Prometheus.

**The formula.** `desired = ceil(current_replicas × current_metric / target_metric)`.
With 3 replicas at 90% CPU and a 60% target: `ceil(3 × 90 / 60) = ceil(4.5) = 5` replicas.

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata: { name: model-api, namespace: ml }
spec:
  scaleTargetRef: { apiVersion: apps/v1, kind: Deployment, name: model-api }
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target: { type: Utilization, averageUtilization: 60 }   # % of the CPU *request*
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 0          # react to spikes immediately
    scaleDown:
      stabilizationWindowSeconds: 300        # wait 5 min of low load before removing pods
      policies: [{ type: Pods, value: 1, periodSeconds: 60 }]
```

| Signal | Good for | Problem |
|---|---|---|
| CPU utilization | CPU-served models | Says little about GPU-bound inference |
| Requests in flight / per second per pod | Most model APIs | Needs custom metrics (Prometheus Adapter or KEDA) |
| Queue depth / pending requests | Batched or async inference, LLM servers | Needs the server to expose it |
| GPU utilization (DCGM) | GPU-bound models | Can stay near 100% with batching even when latency is fine |

**Example.** An LLM API scaled on CPU and never scaled up: the CPU sat at 20% while the GPU was saturated
and p95 latency climbed to 9 seconds. Switching the HPA to "requests waiting in the server queue, target 4
per pod" (exported by vLLM) scaled it from 2 to 6 replicas during peak, and p95 returned under 2 seconds.
[13 / Lab 29](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab29_hpa_custom_metrics.md)
builds this end to end.

**Senior note.** GPU pods take minutes to become ready (node provisioning, image pull, model load). Keep
`minReplicas` high enough to absorb the first part of a spike, scale up early, and scale down slowly.

---

## Lecture 34 — Helm charts for simplified AI deployments

**Why it matters.** A real model service is 6–10 YAML files (Deployment, Service, ConfigMap, HPA, Ingress,
ServiceAccount…), repeated for dev, staging, and production with small differences. Copy-pasting them
leads to drift and mistakes.

**In plain words.** Helm is a form letter. The chart is the template ("Dear `{{ name }}`, your model
`{{ image }}` will run with `{{ replicas }}` replicas"), and each environment fills in its own values file.

**Architecture: how Helm renders a release.**

```mermaid
flowchart LR
  subgraph CHART["Chart: model-api/"]
    T["templates/<br/>deployment.yaml, service.yaml,<br/>hpa.yaml, configmap.yaml"]
    DV["values.yaml (defaults)"]
  end
  EV["values-prod.yaml<br/>replicas: 4, image tag: 1.1,<br/>gpu: true"] --> R
  T --> R["helm upgrade --install<br/>(render templates + values)"]
  DV --> R
  R --> K8S["Kubernetes objects<br/>= release 'model-api-prod', revision 7"]
  K8S -.helm rollback model-api-prod 6.-> PREV[previous revision]
```

**How to read it:** templates plus default values plus environment-specific values produce plain
Kubernetes YAML. Helm records each install or upgrade as a numbered *revision*, so a rollback restores
the whole set of objects, not just the image.

```text
model-api/
├── Chart.yaml           # name, version
├── values.yaml          # defaults
└── templates/
    ├── deployment.yaml
    ├── service.yaml
    └── hpa.yaml
```

```yaml
# values.yaml
image:
  repository: registry.example.com/classifier
  tag: "1.0"
replicas: 2
resources:
  requests: { cpu: "1", memory: 2Gi }
autoscaling: { enabled: true, minReplicas: 2, maxReplicas: 10, targetCPU: 60 }
```

```yaml
# templates/deployment.yaml (excerpt)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Release.Name }}
spec:
  {{- if not .Values.autoscaling.enabled }}
  replicas: {{ .Values.replicas }}          # when the HPA is on, it owns the replica count
  {{- end }}
  selector:
    matchLabels: { app: {{ .Release.Name }} }
  template:
    metadata:
      labels: { app: {{ .Release.Name }} }
    spec:
      containers:
        - name: api
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
          resources: {{- toYaml .Values.resources | nindent 12 }}
```

```bash
helm create model-api                                     # scaffold a chart
helm template model-api ./model-api -f values-prod.yaml   # preview the rendered YAML
helm upgrade --install model-api-prod ./model-api -n ml -f values-prod.yaml --set image.tag=1.1
helm history model-api-prod -n ml
helm rollback model-api-prod 6 -n ml
```

**Example.** Staging and production YAML had drifted apart over a year: production had no memory limit,
which nobody noticed until a memory leak took down a node. With one chart and two small values files,
the only differences between environments are the ones written in `values-prod.yaml`, and they're
reviewed in pull requests.

**Senior note.** Don't set `replicas` in the Deployment when an HPA manages it, or every `helm upgrade`
resets the replica count and fights the autoscaler. The template above handles this.

---

## Lecture 35 — Lab: deploy a model on Minikube

**Goal:** run the Section 4 classifier on a local Kubernetes cluster with a Deployment, Service, probes,
ConfigMap, and HPA, then watch it self-heal and autoscale.

**In plain words.** Minikube is a model railway: a real Kubernetes cluster, shrunk to fit inside your
laptop. Everything you do here (deploy, break things, watch them heal, add load) works the same way on a
100-node cloud cluster.

**What you're building.**

```mermaid
flowchart TB
  YOU2[Your laptop: curl] -->|minikube service / port-forward| SVC4
  subgraph MK["Minikube cluster (1 node)"]
    subgraph NS2["namespace: ml"]
      SVC4[Service: classifier :80] --> PA[pod] & PB[pod]
      DEP4["Deployment: classifier<br/>image classifier:1.0"] --> PA & PB
      HPA4["HPA: 2–5 replicas<br/>CPU target 60%"] --> DEP4
      CM4[ConfigMap: classifier-config] -.-> PA & PB
    end
    MS4[metrics-server addon] --> HPA4
  end
```

**How to read it:** the same image from Section 4 runs as two pods behind one Service. The HPA watches CPU
through metrics-server and adds pods under load.

**Step 1 — start the cluster and load the image.**

```bash
minikube start --cpus=4 --memory=8g
minikube addons enable metrics-server
minikube image load classifier:1.0          # copies your local image into the cluster (no registry needed)
kubectl create namespace ml
```

**Step 2 — apply the manifests.** Save as `classifier.yaml`:

```yaml
apiVersion: v1
kind: ConfigMap
metadata: { name: classifier-config, namespace: ml }
data: { LOG_LEVEL: info }
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: classifier, namespace: ml }
spec:
  selector: { matchLabels: { app: classifier } }
  template:
    metadata: { labels: { app: classifier } }
    spec:
      containers:
        - name: api
          image: classifier:1.0
          imagePullPolicy: Never              # use the image loaded into minikube
          ports: [{ containerPort: 8000 }]
          envFrom: [{ configMapRef: { name: classifier-config } }]
          resources:
            requests: { cpu: 500m, memory: 1Gi }
            limits: { memory: 2Gi }
          startupProbe:  { httpGet: { path: /healthz, port: 8000 }, periodSeconds: 5, failureThreshold: 60 }
          readinessProbe: { httpGet: { path: /healthz, port: 8000 }, periodSeconds: 5 }
          livenessProbe:  { httpGet: { path: /healthz, port: 8000 }, periodSeconds: 10 }
---
apiVersion: v1
kind: Service
metadata: { name: classifier, namespace: ml }
spec:
  selector: { app: classifier }
  ports: [{ port: 80, targetPort: 8000 }]
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata: { name: classifier, namespace: ml }
spec:
  scaleTargetRef: { apiVersion: apps/v1, kind: Deployment, name: classifier }
  minReplicas: 2
  maxReplicas: 5
  metrics:
    - type: Resource
      resource: { name: cpu, target: { type: Utilization, averageUtilization: 60 } }
```

```bash
kubectl apply -f classifier.yaml
kubectl get pods -n ml -w                   # wait for 2/2 pods READY 1/1
```

The model downloads its weights on first start. In the cluster, there's no `torch-cache` volume, so each
new pod downloads again. Adding a PVC for `/cache` is a good extension exercise.

**Step 3 — call it.**

```bash
kubectl port-forward -n ml svc/classifier 8080:80 &
curl -s -F "file=@dog.jpg" localhost:8080/predict
```

**Step 4 — watch it self-heal.**

```bash
kubectl delete pod -n ml -l app=classifier --wait=false   # delete all pods at once
kubectl get pods -n ml -w                                 # new pods appear immediately
```

**Step 5 — watch it autoscale.**

```bash
kubectl get hpa -n ml -w &
for i in $(seq 4); do
  ( while true; do curl -s -o /dev/null -F "file=@dog.jpg" localhost:8080/predict; done ) &
done
# After 1–2 minutes REPLICAS rises above 2. Stop the load (and the port-forward) with: kill $(jobs -p)
# About 5 minutes later it scales back down to 2 (the scale-down stabilization window).
```

**Step 6 — clean up.** `minikube delete`.

**Expected results:** pods recreated within seconds of deletion; the HPA scales from 2 towards 5 under
load and back to 2 afterwards; no failed requests during a `kubectl rollout restart deploy/classifier -n ml`.

---

## Kubernetes component and resource reference

Lectures 29–35 teach the core path: Pod, Deployment, Service, config, autoscaling, and Helm. This reference
covers **every major Kubernetes component and resource**, one entry each, in nine groups. Each entry gives
what it is, an analogy, a diagram, YAML or commands, how AI workloads use it, and the pitfalls senior engineers
watch for.

| Group | Entries |
|---|---|
| A. Control plane | kube-apiserver, etcd, kube-scheduler, kube-controller-manager, cloud-controller-manager |
| B. Node and add-ons | kubelet, container runtime (containerd), kube-proxy, CNI plugin, CoreDNS, CSI drivers, device plugins and DRA |
| C. Workloads | Pod, ReplicaSet, Deployment, StatefulSet, DaemonSet, Job, CronJob |
| D. Networking | Service (ClusterIP, NodePort, LoadBalancer, ExternalName, Headless), EndpointSlice, Ingress, Gateway API, NetworkPolicy |
| E. Config and storage | ConfigMap, Secret, volumes (emptyDir, hostPath, projected), PersistentVolume, PersistentVolumeClaim, StorageClass |
| F. Scheduling and tenancy | Namespace, ResourceQuota, LimitRange, PriorityClass, taints and tolerations, affinity and topology spread, PodDisruptionBudget |
| G. Autoscaling | HPA, VPA, Cluster Autoscaler and Karpenter, KEDA |
| H. Security | ServiceAccount, RBAC, Pod Security Admission, admission policies and webhooks |
| I. Extensibility | CustomResourceDefinitions and operators |

**The whole map.**

```mermaid
flowchart LR
  subgraph CPL["Control plane"]
    APIS["kube-apiserver"] --> ETC[("etcd")]
    SCH["kube-scheduler"] --> APIS
    KCM["kube-controller-manager"] --> APIS
    CCM["cloud-controller-manager"] --> APIS
  end
  subgraph NODEX["Each worker node"]
    KL["kubelet"] --> CRI["containerd"]
    KP["kube-proxy"]
    CNI["CNI plugin"]
    CSI["CSI node driver"]
    DP["Device plugin<br/>nvidia.com/gpu"]
    CRI --> PODX["Pods"]
  end
  KL --> APIS
  KP --> APIS
  DNS["CoreDNS<br/>add-on pods"] --> APIS
  CCM --> CLOUD["Cloud APIs<br/>load balancers, nodes, routes"]
  USER["kubectl, CI, GitOps"] --> APIS
```

**How to read it:** every component talks only to the API server, and only the API server talks to etcd.
Controllers and the scheduler watch the API server for changes and write their decisions back. On each node,
the kubelet runs pods through containerd, while kube-proxy, the CNI plugin, CSI drivers, and device plugins
provide networking, storage, and hardware. CoreDNS runs as ordinary pods.

**What happens when you run `kubectl apply -f deployment.yaml`.**

```mermaid
sequenceDiagram
  participant U as kubectl
  participant A as kube-apiserver
  participant E as etcd
  participant C as controller-manager
  participant S as scheduler
  participant K as kubelet (node 2)
  participant R as containerd
  U->>A: POST Deployment (authn, authz, admission)
  A->>E: store Deployment
  C->>A: watch sees new Deployment, create ReplicaSet
  C->>A: ReplicaSet controller creates 3 Pods (nodeName empty)
  S->>A: watch sees unscheduled Pods, filter + score nodes
  S->>A: bind Pod to node 2
  K->>A: watch sees Pod bound to my node
  K->>R: pull image, create containers
  K->>A: report status Running, Ready after probes pass
```

**How to read it:** nothing is called directly. Each component reacts to objects it watches and writes the next
fact back to the API server. The Deployment controller creates a ReplicaSet, the ReplicaSet controller creates
Pods, the scheduler assigns them to nodes, and the kubelet on each node makes them real. This chain of
independent controllers is why Kubernetes heals itself, and why `kubectl describe` Events tell you exactly
which step got stuck.

In the diagram, `POST` is the HTTP method for "create", and kubectl sends the YAML as a create request. Authn,
authz, and admission are the API server's three gates (who are you, may you do this, is this object allowed),
explained in entry A1. "nodeName empty" means the new pod's `spec.nodeName` field, the node it should run on,
isn't filled in yet. Filling it in is exactly the scheduler's job, called **binding**. The **filter + score**
steps are how the scheduler picks the node (entry A3). **Probes** are the health checks from Lecture 31.

---

### A. Control plane

#### A1. kube-apiserver

**What it is.** The front door of the cluster and the only way to read or change its state. It's a REST API that
authenticates every request, authorizes it (RBAC), runs admission control, validates the object, and stores it in
etcd. Every other component, including `kubectl`, controllers, kubelets, and operators, works by reading and
watching it.

**In plain words.** The reception desk of a government office. Every form goes through it, gets checked
for ID and permission, gets stamped, and is filed. Nobody walks into the archive (etcd) directly.

```mermaid
flowchart LR
  REQ["Request<br/>kubectl apply"] --> AUTHN["Authentication<br/>certs, OIDC, tokens"]
  AUTHN --> AUTHZ["Authorization<br/>RBAC"]
  AUTHZ --> MUT["Mutating admission<br/>defaults, sidecar injection"]
  MUT --> VAL["Schema validation"]
  VAL --> VADM["Validating admission<br/>policies, quotas"]
  VADM --> ETCDA[("etcd")]
  ETCDA --> WATCH["Watch streams<br/>to controllers, kubelets"]
```

**How to read it:** every request passes the same checkpoints in order. **Authentication** (often shortened
to authn) answers "who are you?" using client certificates, OIDC tokens from your company login, or
ServiceAccount tokens. **Authorization** (authz) answers "may you do this?", usually with RBAC (entry H2).
**Mutating admission** may change the object, for example filling in defaults or injecting a sidecar
container. **Schema validation** checks the object is well-formed. **Validating admission** applies policies
and quotas. Only then is it saved in etcd. **Watch streams** are long-lived connections over which the API
server pushes every change to the components that subscribed, so they react within milliseconds instead of
polling.

```bash
kubectl get --raw /readyz?verbose               # API server health checks
kubectl api-resources                           # every resource type the API serves (including CRDs)
kubectl auth can-i create deployments -n ml     # what RBAC allows the current user
```

**AI use.** Operators for training (PyTorchJob, RayCluster) and serving (KServe) are API clients. Large
batch systems that create thousands of pods put real load on the API server.

**Pitfalls and senior practice.**
- Clients that `list` everything in a loop instead of using watches and informers overload it. Use client
  libraries with informers and rate limits.
- Run 3+ API server replicas behind a load balancer (managed services do this). Enable audit logging for
  security (Section 18).
- API Priority and Fairness protects it from noisy clients. Check `apiserver_flowcontrol_*` metrics when
  requests get throttled.

#### A2. etcd

**What it is.** A strongly consistent, distributed key-value store (Raft consensus) that holds all cluster
state: every object you create. Only the API server reads and writes it.

**In plain words.** The archive vault with three or five clerks who must agree before anything is filed. As
long as a majority is present, the archive works. Lose the majority and nothing new can be filed.

```mermaid
flowchart LR
  APIE["kube-apiserver"] --> L["etcd leader"]
  L -->|"replicate log"| F1["etcd follower"]
  L -->|"replicate log"| F2["etcd follower"]
  L --> Q{"Majority ack?<br/>2 of 3"}
  Q -->|"yes"| OK["Write committed"]
  SNAP["etcdctl snapshot save<br/>scheduled backups"] -.-> L
```

**How to read it:** etcd members elect one **leader**. Every write goes to the leader, which copies it to the
**followers** (the other members) as entries in a replicated log. The write is **committed**, meaning final and
safe, only when a majority (2 of 3, or 3 of 5) has stored it. That majority rule is called **quorum**, and it's
the core of the **Raft** consensus algorithm etcd uses. If the leader dies, the followers elect a new one in
about a second. `etcdctl` is etcd's command-line tool, and `snapshot save` writes a backup of the whole
database to a file.

```bash
ETCDCTL_API=3 etcdctl --endpoints=https://127.0.0.1:2379 --cacert=ca.crt --cert=etcd.crt --key=etcd.key \
  snapshot save /backup/etcd-$(date +%F).db
etcdctl endpoint status --write-out=table     # leader, DB size, raft index
```

**AI use.** You never put data in etcd directly, but AI platforms stress it indirectly. Thousands of Jobs, pods,
and large CRDs (for example big ConfigMaps of model metadata) grow its database.

**Pitfalls and senior practice.**
- Run an odd number of members (3 or 5) on fast SSDs, spread across zones. Quorum is ⌊n/2⌋ + 1.
- Objects are limited to ~1.5 MiB each, and the database to a few GB (the default quota is 2 GB, and ~8 GB is the
  practical maximum). Don't store big blobs in ConfigMaps or CRDs, and clean up finished Jobs
  (`ttlSecondsAfterFinished`).
- Back it up and test restores. Encrypt Secrets at rest (entry E2). On managed clusters (EKS, GKE, AKS), the
  provider runs etcd, but object limits still apply.

#### A3. kube-scheduler

**What it is.** The component that decides which node each new pod runs on. For every unscheduled pod, it
filters out nodes that can't fit it (resources, taints, affinity, volumes), scores the rest, and binds the pod
to the best node.

**In plain words.** A wedding planner seating guests: first remove tables that are full or wrong (filter),
then pick the best remaining table by preferences (score), then write the name on the seating card (bind).

```mermaid
flowchart LR
  PEND["Unscheduled pod<br/>needs 1 GPU, 32 Gi"] --> FIL["Filter<br/>resources fit, taints,<br/>node affinity, volume zone"]
  FIL --> CANDS["Feasible nodes"]
  CANDS --> SCORE["Score<br/>spread, bin-packing,<br/>affinity preferences"]
  SCORE --> BIND["Bind pod to best node"]
  FIL -->|"none fit"| EVT["Event: 0/12 nodes available,<br/>Insufficient nvidia.com/gpu"]
  EVT --> PREEMPT["Preempt lower-priority pods?<br/>or wait for autoscaler"]
```

**How to read it:** a pod asking for 1 GPU and 32 Gi of memory first goes through the **filter** step, which
removes nodes without enough free resources, nodes with a **taint** the pod doesn't tolerate (entry F5), nodes
excluded by **node affinity** rules (entry F6), and nodes in the wrong zone for the pod's disk. The remaining
**feasible nodes** are **scored**: for example "spread replicas apart" or "pack pods tightly" (**bin-packing**,
filling nodes fully so whole nodes stay free). **Bind** writes the chosen node into the pod's `spec.nodeName`
field. If no node passes the filter, the scheduler records an Event explaining why. It may then **preempt**
(evict) lower-priority pods (entry F4), or the pod waits until a node autoscaler adds a machine (entry G3).

```bash
kubectl get pods -A --field-selector=status.phase=Pending
kubectl describe pod <pod> | sed -n '/Events/,$p'     # the scheduler explains exactly why
```

**AI use.** GPU placement: requests for `nvidia.com/gpu`, taints on GPU nodes, topology (keeping a training job's
pods on the same rack), and bin-packing to reduce fragmentation.

**Pitfalls and senior practice.**
- The default scheduler places pods one at a time. Distributed training needs **gang scheduling** (all or
  nothing), from Kueue, Volcano, or the coscheduling plugin (Section 11).
- GPU fragmentation (one free GPU on each of eight nodes, but no node with 8 free) blocks big jobs. Use
  bin-packing scoring (`MostAllocated`) for GPU pools.
- The scheduler only knows requests, not real usage. Wrong requests mean wrong placement.

#### A4. kube-controller-manager

**What it is.** One process that runs dozens of built-in controllers, each a reconciliation loop for one kind of
object: Deployment, ReplicaSet, StatefulSet, DaemonSet, Job, CronJob, Node lifecycle, EndpointSlice, Namespace,
ServiceAccount, garbage collector, and more. Replicas use leader election, so only one is active.

**In plain words.** A building's maintenance crew, where each member has one job: one checks the lights, one
the elevators, one the doors. Each walks the same loop forever: look, compare with the plan, fix the difference.

```mermaid
flowchart LR
  subgraph KCMX["kube-controller-manager (leader)"]
    DC["Deployment controller"]
    RSC["ReplicaSet controller"]
    NC["Node lifecycle controller"]
    JC["Job controller"]
    EC["EndpointSlice controller"]
    GC["Garbage collector"]
  end
  DC --> APIC["kube-apiserver"]
  RSC --> APIC
  NC --> APIC
  JC --> APIC
  EC --> APIC
  GC --> APIC
```

**How to read it:** each box is a separate loop inside one program, and each talks only to the API server.
The **Deployment controller** creates ReplicaSets for each version, and the **ReplicaSet controller** keeps the
pod count right. The **node lifecycle controller** notices dead nodes. The **Job controller** runs pods to
completion. The **EndpointSlice controller** keeps the list of ready pods behind each Service. The **garbage
collector** deletes objects whose owner was deleted. The program runs several copies for safety, but only the
**leader** (chosen through a lock object called a Lease) acts. The others wait to take over.

**Key behaviors to know.**
- **Node failure.** When a node stops heartbeating, the node lifecycle controller marks it `NotReady` (after ~40 s)
  and taints it. Pods tolerate that taint for 300 s by default, then they're evicted and replaced elsewhere.
  For latency-critical serving, shorten `tolerationSeconds` on the not-ready and unreachable taints.
- **Garbage collection.** Owner references link Deployment → ReplicaSet → Pod. Deleting the owner deletes the
  children (cascading delete).

```yaml
# serving pods: move off a dead node after 30 s instead of the default 300 s
tolerations:
  - { key: node.kubernetes.io/not-ready, operator: Exists, effect: NoExecute, tolerationSeconds: 30 }
  - { key: node.kubernetes.io/unreachable, operator: Exists, effect: NoExecute, tolerationSeconds: 30 }
```

**AI use.** Every Deployment, Job, and rollout depends on these controllers. The node lifecycle timing decides how
long a model API runs degraded after a GPU node dies.

**Pitfalls and senior practice.** Know the default timings and tune them per workload. Training pods should
*not* be evicted quickly on a short network blip, while serving pods should move quickly.

#### A5. cloud-controller-manager

**What it is.** The bridge between Kubernetes and a cloud provider's APIs. It initializes nodes with cloud
metadata (zone, instance type), removes nodes whose VMs are deleted, sets up routes, and creates cloud load
balancers for `type: LoadBalancer` Services.

**In plain words.** The building's liaison with the city: it orders new street addresses (load balancers) and
tells the city when a building is demolished (node removed).

```mermaid
flowchart LR
  SVCL["Service type LoadBalancer"] --> CCMX["cloud-controller-manager"]
  CCMX --> LB["Cloud load balancer<br/>NLB, GCP LB, Azure LB"]
  NODEC["New VM joins"] --> CCMX
  CCMX -->|"labels: zone, instance-type"| NODEL["Node object"]
  VMGONE["VM deleted in cloud"] --> CCMX
  CCMX -->|"delete Node"| NODEL
```

**How to read it:** when you create a Service of type LoadBalancer, the cloud-controller-manager calls the
cloud's API to create a real load balancer: an **NLB** (Network Load Balancer) on AWS, or the Google or Azure
equivalent. When a new VM joins, it labels the Node object with the VM's zone and instance type. When a VM is
deleted in the cloud console, it deletes the matching Node object, so Kubernetes stops waiting for it.

**AI use.** Node labels it sets (`topology.kubernetes.io/zone`, `node.kubernetes.io/instance-type`) drive
zone spreading and GPU-type targeting (for example selecting `p5.48xlarge` nodes).

**Pitfalls and senior practice.** Load balancer settings come from cloud-specific Service annotations
(internal vs public, cross-zone, idle timeouts). Long LLM streaming responses need idle timeouts above the
longest generation time.

---

### B. Node agents and cluster add-ons

#### B1. kubelet

**What it is.** The agent on every node. It watches the API server for pods bound to its node, asks the
container runtime to start them, mounts volumes, runs probes, enforces resource limits through cgroups, reports
node and pod status, and evicts pods when the node runs low on memory or disk.

**In plain words.** The floor manager of one factory floor. Head office (the API server) sends work orders.
The floor manager gets the machines running, checks them regularly, and reports back.

```mermaid
flowchart LR
  APIK["kube-apiserver"] -->|"pods bound to this node"| KLX["kubelet"]
  KLX -->|"CRI gRPC"| CRX["containerd"]
  KLX -->|"mount volumes"| CSIX["CSI node driver"]
  KLX -->|"allocate GPUs"| DPX["device plugin"]
  KLX -->|"probes"| PODK["Pod containers"]
  KLX -->|"status + Lease heartbeat"| APIK
  KLX -->|"memory or disk pressure"| EVICT["Evict pods<br/>BestEffort first"]
```

**How to read it:** the kubelet receives the list of pods assigned to its node. It talks to containerd over
**CRI** (the Container Runtime Interface, a gRPC API, entry B2), asks the CSI driver to mount disks (entry B6),
and asks the device plugin for GPUs (entry B7). It runs the probes, then reports status back. Every 10 seconds
it renews a **Lease** object, a heartbeat that tells the control plane the node is alive. Under **memory or
disk pressure** (the node running out), it **evicts** (stops and removes) pods, starting with **BestEffort**
pods, which have no resource requests (QoS classes are in entry C1).

```bash
kubectl describe node <node>      # Conditions (MemoryPressure, DiskPressure), Capacity vs Allocatable
journalctl -u kubelet -f          # on the node itself
```

**AI use.** Pulling a 15 GB inference image is done by the kubelet through containerd, and slow pulls show up as
`ContainerCreating`. GPU allocation goes through the kubelet's device plugin manager.

**Pitfalls and senior practice.**
- **Allocatable is less than capacity.** The kubelet reserves CPU and memory for the system (`kube-reserved`,
  `system-reserved`). Size pods against Allocatable.
- **Eviction order** follows QoS class: BestEffort, then Burstable pods over their request, then Guaranteed.
  Give serving pods requests equal to limits for memory.
- Image garbage collection kicks in at disk thresholds. Huge model images on small disks cause constant
  re-pulls. Use larger node disks or image pre-pulling.

#### B2. Container runtime (containerd, CRI)

**What it is.** The software that actually pulls images and runs containers. The kubelet talks to it through the
Container Runtime Interface (CRI). containerd and CRI-O are the common runtimes. Docker Engine support
(dockershim) was removed in Kubernetes 1.24, though images built with Docker still run fine.

**In plain words.** The machine operator. The floor manager says "run this", and the operator loads the
right part (image) and starts the machine (runc).

```mermaid
flowchart LR
  KLR["kubelet"] -->|"CRI: RunPodSandbox, CreateContainer"| CD["containerd"]
  CD --> REG["Registry<br/>pull layers"]
  CD --> SNAPR["Snapshotter<br/>unpack layers"]
  CD --> RUNC["runc<br/>namespaces, cgroups"]
  RUNC --> CTR["Container process"]
  CD -.->|"GPU hook"| NCT["NVIDIA Container Toolkit"]
```

**How to read it:** the kubelet calls CRI functions such as `RunPodSandbox` (create the pod's shared network
and environment, the "sandbox") and `CreateContainer` (create each container inside it). containerd pulls the
image **layers** (the stacked filesystem pieces of an image) from the registry. The **snapshotter** unpacks the
layers into a filesystem on disk. **runc** is the small low-level tool that actually starts the process inside
Linux **namespaces** (isolated views of processes, network, and files) and **cgroups** (kernel limits on CPU
and memory). For GPU pods, the NVIDIA Container Toolkit's hook adds the GPU device files and driver libraries
to the container.

```bash
crictl ps              # containers on the node (like docker ps)
crictl images          # cached images and sizes
crictl pull <image>    # test registry access from the node
```

**AI use.** The NVIDIA Container Toolkit hooks into containerd so containers see GPUs. Lazy-loading
snapshotters (for example stargz or SOCI) can start large AI images before all layers are downloaded.

**Pitfalls and senior practice.** Pin images by digest. Mirror registries inside the region to avoid pull rate
limits. Pre-pull large inference images on new nodes (for example with a DaemonSet) to cut cold starts.

#### B3. kube-proxy

**What it is.** A per-node agent that implements Services. It watches Services and EndpointSlices and programs
the node's packet rules (iptables by default, or IPVS, or nftables in newer releases) so that traffic to a
Service's virtual IP gets load-balanced to a ready backend pod.

**In plain words.** A switchboard operator on every floor: calls to the "sales department" number are routed
to whichever salesperson is currently at their desk.

```mermaid
flowchart LR
  CLIENT["Client pod"] -->|"10.96.0.20:80"| RULES["Node packet rules<br/>iptables, IPVS, nftables"]
  KPX["kube-proxy"] -->|"programs"| RULES
  APIP["kube-apiserver"] -->|"Services, EndpointSlices"| KPX
  RULES -->|"random pick"| B1["Pod A 10.244.1.5"]
  RULES --> B2["Pod B 10.244.2.9"]
```

**How to read it:** a client sends a request to the Service's **virtual IP** (`10.96.0.20`), an address no
machine actually owns. kube-proxy has written packet rules into the Linux kernel with **iptables**, **IPVS**,
or **nftables** (three kernel features for filtering and redirecting network packets). The rules rewrite the
destination to one ready pod, picked at random, so the client never needs to know pod addresses.

**AI use.** Every ClusterIP call between microservices (gateway to embedding service, for example) goes
through these rules.

**Pitfalls and senior practice.**
- It balances **connections**, not requests. gRPC and HTTP/2 clients keep one long-lived connection, so all
  requests stick to one pod. Use an L7 proxy or mesh (Envoy, see lab 49) or client-side balancing over a
  Headless Service.
- Cilium and other eBPF CNIs can replace kube-proxy entirely for better performance at large scale.

#### B4. CNI plugin

**What it is.** The Container Network Interface plugin gives every pod its own IP and connects pods across nodes
so every pod can reach every other pod without NAT (the Kubernetes network model). Examples: Calico, Cilium,
Flannel, the AWS VPC CNI, and Azure CNI. The CNI plugin also enforces NetworkPolicy, if it supports it.

**In plain words.** The building's internal phone wiring: every desk gets an extension, and any extension can
dial any other.

```mermaid
flowchart LR
  subgraph N1["Node 1 (10.244.1.0/24)"]
    PA["Pod A 10.244.1.5"]
  end
  subgraph N2["Node 2 (10.244.2.0/24)"]
    PB["Pod B 10.244.2.9"]
  end
  PA -->|"overlay or routed<br/>VXLAN, BGP, VPC IPs"| PB
  CNIX["CNI plugin<br/>Cilium, Calico, VPC CNI"] -.->|"assign IPs, routes, policy"| PA
  CNIX -.-> PB
```

**How to read it:** each node owns a range of pod addresses (`10.244.1.0/24` means the 256 addresses
10.244.1.0 to 10.244.1.255). The CNI plugin gives each new pod one address and sets up routes so pod A can
reach pod B on another node. It does this in one of three ways. An **overlay** such as **VXLAN** wraps pod
packets inside normal node-to-node packets, like an envelope inside an envelope. A **routed** network uses
**BGP** (the routing protocol of the internet) to tell the physical network where each pod range lives.
**VPC IPs** give pods real addresses from the cloud network itself, as the AWS VPC CNI does.

**AI use.** Multi-node training needs more than pod networking. High-bandwidth RDMA (InfiniBand or RoCE) is
added as secondary interfaces with Multus and the SR-IOV or NVIDIA Network Operator (Section 13).

**Pitfalls and senior practice.**
- **IP exhaustion.** VPC-native CNIs give each pod a real VPC IP. Big clusters run out of subnet space, so plan
  CIDRs early.
- Flannel does **not** enforce NetworkPolicy. Your policies silently do nothing. Pick Calico or Cilium if you
  need isolation.

#### B5. CoreDNS

**What it is.** The cluster DNS server, running as a Deployment in `kube-system`. It resolves Service names like
`embedder.ml.svc.cluster.local` to ClusterIPs (or pod IPs for Headless Services).

**In plain words.** The company phone directory: you ask for "embedder in the ml department" and get its
number.

```mermaid
flowchart LR
  APPD["App calls http://embedder"] --> RES["/etc/resolv.conf<br/>search ml.svc.cluster.local"]
  RES --> CDNS["CoreDNS pods"]
  CDNS -->|"watch Services"| APID["kube-apiserver"]
  CDNS -->|"A record 10.96.0.20"| APPD
  CDNS -->|"external names"| UP["Upstream DNS"]
```

**How to read it:** the app asks for the short name `embedder`. The container's `/etc/resolv.conf` file
(the DNS settings Kubernetes writes into every container) lists **search domains**, so the name is tried as
`embedder.ml.svc.cluster.local`. CoreDNS knows every Service, because it watches the API server, and replies
with an **A record** (the DNS answer that maps a name to an IPv4 address). Names outside the cluster, like
`huggingface.co`, are forwarded to the **upstream DNS** server of the VPC or data center.

```bash
kubectl run -it --rm dnsdbg --image=busybox:1.36 --restart=Never -- nslookup embedder.ml.svc.cluster.local
```

**AI use.** Every service-to-service call in a RAG pipeline (gateway, embedder, vector DB, LLM) starts with a DNS
lookup.

**Pitfalls and senior practice.**
- The default `ndots:5` means a name like `api.openai.com` is first tried against every cluster search domain,
  so one call becomes several DNS queries. Use fully qualified names with a trailing dot, or lower `ndots` in
  `dnsConfig`.
- At high request rates, run **NodeLocal DNSCache** and scale CoreDNS. DNS timeouts look like random 5-second
  latency spikes.

#### B6. CSI drivers

**What it is.** Container Storage Interface drivers let Kubernetes create, attach, mount, resize, and snapshot
volumes from any storage system: cloud disks (EBS, Persistent Disk), shared filesystems (EFS, Filestore,
FSx for Lustre), or on-prem storage (Ceph). There's a controller part (create and attach) and a node part
(mount on the node).

**In plain words.** A universal adapter so any brand of storage locker plugs into the same building.

```mermaid
flowchart LR
  PVCB["PVC: 500 Gi, class fast-ssd"] --> CTRLB["CSI controller<br/>CreateVolume, Attach"]
  CTRLB --> STOR["Storage backend<br/>EBS, PD, Lustre, Ceph"]
  KLB["kubelet"] --> NODEB["CSI node plugin<br/>NodeStage, NodePublish"]
  NODEB -->|"mount"| PODB["Pod /data"]
```

**How to read it:** a PVC asks for 500 Gi of class `fast-ssd`. The CSI **controller** part calls the storage
system's API: `CreateVolume` makes the disk, and `Attach` connects it to the right machine. On that machine,
the CSI **node** part runs `NodeStage` (format the disk and mount it once on the node) and `NodePublish` (make
it visible inside this pod's container at `/data`). These names come from the CSI specification, so every
storage vendor implements the same steps.

**AI use.** Training checkpoints on fast block or parallel filesystems. Shared read-only model weights on a
ReadOnlyMany or ReadWriteMany filesystem. The Secrets Store CSI driver mounts secrets from Vault or a cloud
key store.

**Pitfalls and senior practice.** Block disks are zonal. A pod rescheduled to another zone can't attach its disk,
so use `WaitForFirstConsumer` binding (entry E6). Throughput limits per disk often bottleneck data loading
before the GPU does.

#### B7. Device plugins and Dynamic Resource Allocation (DRA)

**What it is.** A device plugin (usually a DaemonSet) advertises special hardware to the kubelet as an
extended resource, like `nvidia.com/gpu: 8`, and wires the device into containers that request it. The NVIDIA
GPU Operator installs the driver, container toolkit, device plugin, DCGM exporter, and MIG manager.
**Dynamic Resource Allocation** (DRA, GA in Kubernetes 1.34) is the newer, richer model: devices are described
with attributes (memory, model, MIG profile) and claimed with `ResourceClaim` objects, instead of plain counts.

**In plain words.** The device plugin is the equipment room clerk who tells head office "this floor has 8
GPUs" and hands one to each worker who signed for it.

```mermaid
flowchart LR
  GPUOP["NVIDIA GPU Operator"] --> DRV["Driver + toolkit"]
  GPUOP --> DPN["Device plugin DaemonSet"]
  GPUOP --> DCGM["DCGM exporter<br/>GPU metrics"]
  DPN -->|"register nvidia.com/gpu: 8"| KLG["kubelet"]
  KLG -->|"capacity"| NODEG["Node status"]
  PODG["Pod limits nvidia.com/gpu: 1"] --> SCHG["scheduler"]
  SCHG --> KLG
  KLG -->|"inject /dev/nvidia3"| CG["Container"]
```

**How to read it:** the GPU Operator installs everything a GPU node needs. The **driver** is the kernel
software that talks to the GPU. The **toolkit** lets containers use it. **DCGM** (NVIDIA Data Center GPU
Manager) reports GPU health and usage as metrics. The device plugin tells the kubelet "this node has 8
`nvidia.com/gpu`", and that number appears in the node's capacity. When the scheduler places a pod that asks
for one GPU, the kubelet gives the container one specific device file, such as `/dev/nvidia3` (the fourth
GPU, counting from 0), so the container sees only that GPU.

```yaml
resources:
  limits:
    nvidia.com/gpu: 1     # extended resources go in limits; request defaults to the same value
```

**AI use.** This is how every GPU workload in this course gets a GPU. Small inference workloads can share one
GPU in two ways (Sections 7 and 11). **MIG** (Multi-Instance GPU, on A100, H100, and newer) splits one GPU in
hardware into isolated slices with their own memory, requested as for example `nvidia.com/mig-1g.10gb` (one
compute slice, 10 GB). **Time-slicing** lets several pods take turns on the whole GPU, with no memory isolation.

**Pitfalls and senior practice.**
- GPUs are counted in whole units. `0.5` is invalid, so share them with MIG, time-slicing, or MPS (Multi-Process
  Service, which lets several processes run on one GPU at the same time).
- A pod that doesn't request a GPU but runs on a GPU node can still see GPUs if the image sets
  `NVIDIA_VISIBLE_DEVICES=all`. Taint GPU nodes, and make the device plugin the only path to GPUs.
- Alert on DCGM **XID errors** (numbered error codes the NVIDIA driver logs when a GPU faults, for example
  XID 79, "GPU has fallen off the bus") and on nodes whose allocatable GPU count drops (a failed GPU).

---

### C. Workloads

```mermaid
flowchart TB
  DEPC["Deployment<br/>stateless, rolling updates"] --> RSX["ReplicaSet<br/>keeps N copies"]
  RSX --> PODC["Pods"]
  STS["StatefulSet<br/>stable names + disks"] --> PODC
  DS["DaemonSet<br/>one per node"] --> PODC
  CJ["CronJob<br/>on a schedule"] --> JOBC["Job<br/>run to completion"]
  JOBC --> PODC
```

**How to read it:** every workload controller ends in Pods. Pick the controller by the question "how should
these pods live?" Forever and interchangeable means a Deployment. Forever with identity and disk means a
StatefulSet. One per node means a DaemonSet. Until done means a Job, and on a schedule means a CronJob.

#### C1. Pod

**What it is.** The smallest deployable unit: one or more containers that share a network namespace (one IP,
talk over `localhost`) and volumes, and are always scheduled together on one node. Pods are disposable. They're
replaced, never repaired.

**In plain words.** A shared apartment: roommates (containers) share one address, the kitchen (volumes), and
the same lease (lifecycle).

```mermaid
flowchart LR
  subgraph PODP["Pod: one IP 10.244.1.5"]
    INIT["init container<br/>download model weights"] -->|"then"| MAIN["main container<br/>model server :8000"]
    SIDE["native sidecar<br/>log shipper or proxy"]
    VOLP[("shared emptyDir /models")]
  end
  INIT --> VOLP
  MAIN --> VOLP
```

**How to read it:** everything inside the box shares one IP address. The **init container** runs first and must
finish successfully before the main container starts. Here it downloads model weights. The **main container**
is the model server, listening on port 8000. A **native sidecar** is a helper container (log shipper, proxy)
that starts before the main container and keeps running beside it for the pod's whole life. The **shared
emptyDir** is a scratch folder both containers mount, which is how the downloaded weights reach the server.

```yaml
apiVersion: v1
kind: Pod
metadata: { name: llm, labels: { app: llm } }
spec:
  terminationGracePeriodSeconds: 60            # let in-flight generations finish
  initContainers:
    - name: fetch-weights
      image: amazon/aws-cli:2.17.0
      command: ["aws", "s3", "sync", "s3://models/llama3-8b/", "/models/"]
      volumeMounts: [{ name: models, mountPath: /models }]
    - name: log-shipper                        # native sidecar: starts first, stops last
      image: fluent/fluent-bit:3.1
      restartPolicy: Always
  containers:
    - name: server
      image: vllm/vllm-openai:v0.6.3
      args: ["--model", "/models"]
      resources:
        requests: { cpu: "4", memory: 32Gi, nvidia.com/gpu: 1 }
        limits:   { memory: 32Gi, nvidia.com/gpu: 1 }
      lifecycle:
        preStop: { exec: { command: ["sleep", "10"] } }   # wait for endpoints to update before shutdown
      volumeMounts: [{ name: models, mountPath: /models }]
  volumes:
    - { name: models, emptyDir: { sizeLimit: 40Gi } }
```

**QoS classes** decide eviction order. They're computed from requests and limits:

| QoS class | Rule | Use for |
|---|---|---|
| Guaranteed | Every container has requests equal to limits for CPU and memory | Latency-critical serving |
| Burstable | Some requests set, not all equal to limits | Most services |
| BestEffort | No requests or limits | Never in production |

**AI use.** Init containers fetch weights, native sidecars (init containers with `restartPolicy: Always`) run log
shippers or auth proxies, and the main container serves the model.

**Pitfalls and senior practice.**
- Never create bare Pods in production. Nothing recreates them if the node dies. Use a controller.
- On shutdown, a pod is removed from endpoints at the same time it gets SIGTERM. A short `preStop` sleep
  avoids dropped requests, and the grace period must exceed your longest request.

#### C2. ReplicaSet

**What it is.** A controller that keeps exactly N pods matching a label selector running. If one dies, it creates
another. If there are too many, it deletes extras. You almost never create one yourself, because Deployments
create and manage ReplicaSets for you.

**In plain words.** A shift supervisor whose only rule is "there must always be 3 cashiers on the floor."

```mermaid
flowchart LR
  RSR["ReplicaSet<br/>replicas: 3, selector app=api"] --> CNT{"Pods with app=api?"}
  CNT -->|"2 found"| CREATE["Create 1 pod"]
  CNT -->|"4 found"| DELETE["Delete 1 pod"]
  CNT -->|"3 found"| NOOP["Do nothing"]
```

**How to read it:** the ReplicaSet's **selector** (`app=api`) is a label query. It counts pods carrying that
label, compares the count with `replicas: 3`, and creates or deletes pods to close the gap. That's the whole job.

```bash
kubectl get rs -l app=api                 # one ReplicaSet per Deployment revision
kubectl get pod <pod> -o jsonpath='{.metadata.ownerReferences[0].name}'
```

**Pitfalls and senior practice.** The selector matches any pod with those labels, including pods you created by
hand, which it will "adopt" or delete. Keep labels unique per app. Old ReplicaSets (scaled to 0) are kept for
rollback, limited by `revisionHistoryLimit` (default 10).

#### C3. Deployment

**What it is.** The standard controller for stateless apps. It manages ReplicaSets to do rolling updates and
rollbacks. Covered in depth in Lecture 31.

**In plain words.** A shift manager who replaces the whole team gradually, a few people at a time, so the store
never closes.

```mermaid
flowchart LR
  DEPD["Deployment v2 applied"] --> NEWRS["New ReplicaSet v2<br/>scale up by maxSurge"]
  DEPD --> OLDRS["Old ReplicaSet v1<br/>scale down by maxUnavailable"]
  NEWRS --> READY{"New pods Ready?"}
  READY -->|"yes"| NEXT["Continue rollout"]
  READY -->|"no, past progressDeadlineSeconds"| STUCK["Progressing=False<br/>rollout stuck"]
```

**How to read it:** applying v2 creates a new ReplicaSet. It grows by up to **maxSurge** extra pods above the
desired count, while the old ReplicaSet shrinks by at most **maxUnavailable** pods below it. Each time new pods
become Ready, the next batch is swapped. If no progress happens within **progressDeadlineSeconds** (default 600
seconds), the Deployment sets its `Progressing` condition to `False`. Kubernetes doesn't roll back by itself:
your CI or rollout tool must see that condition and act.

```yaml
spec:
  replicas: 4
  strategy:
    type: RollingUpdate            # or Recreate: kill all, then start all (needed when 2 versions cannot coexist)
    rollingUpdate: { maxSurge: 1, maxUnavailable: 0 }   # GPU-safe: never drop below 4 serving pods
  progressDeadlineSeconds: 900     # big models load slowly; default is 600
  minReadySeconds: 30              # pod must stay Ready 30 s before it counts
```

**AI use.** Stateless model servers, embedding services, API gateways, and feature-serving APIs.

**Pitfalls and senior practice.** With GPUs, `maxSurge: 1` needs one spare GPU during rollouts. If none is free,
the rollout stalls, so either keep headroom or use `maxSurge: 0, maxUnavailable: 1` and accept reduced
capacity. Use `kubectl rollout undo` for fast rollback, and canaries for risky model changes (Section 10).

#### C4. StatefulSet

**What it is.** A controller for pods that need a **stable identity** (`qdrant-0`, `qdrant-1`), **stable storage**
(each pod keeps its own PVC across restarts through `volumeClaimTemplates`), and **ordered** startup, update, and
shutdown. It requires a Headless Service for per-pod DNS names. Section 11 Lecture 72 goes deeper.

**In plain words.** Assigned seats with personal lockers. When `qdrant-1` comes back, it sits in the same seat
and opens the same locker.

```mermaid
flowchart LR
  STSS["StatefulSet qdrant<br/>replicas: 3"] --> P0["qdrant-0"]
  STSS --> P1["qdrant-1"]
  STSS --> P2["qdrant-2"]
  P0 --- V0[("PVC data-qdrant-0")]
  P1 --- V1[("PVC data-qdrant-1")]
  P2 --- V2[("PVC data-qdrant-2")]
  HS["Headless Service<br/>qdrant-1.qdrant.ml.svc"] -.-> P1
```

**How to read it:** the StatefulSet creates pods with fixed numbered names, `qdrant-0` to `qdrant-2`. Each gets
its own PVC (`data-qdrant-1` always belongs to `qdrant-1`), so after a restart the pod reattaches to the same data.
The **Headless Service** (entry D1) gives each pod its own DNS name, `qdrant-1.qdrant.ml.svc`, read as "pod
qdrant-1, of Service qdrant, in namespace ml". Cluster members use these names to find each other. Qdrant is an
open-source vector database (Section 25).

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata: { name: qdrant, namespace: ml }
spec:
  serviceName: qdrant                 # the Headless Service that gives per-pod DNS
  replicas: 3
  podManagementPolicy: Parallel       # start all at once; OrderedReady (default) waits for each pod
  selector: { matchLabels: { app: qdrant } }
  template:
    metadata: { labels: { app: qdrant } }
    spec:
      containers:
        - name: qdrant
          image: qdrant/qdrant:v1.12.4
          ports: [{ containerPort: 6333 }, { containerPort: 6335 }]
          volumeMounts: [{ name: data, mountPath: /qdrant/storage }]
  volumeClaimTemplates:
    - metadata: { name: data }
      spec:
        accessModes: [ReadWriteOnce]
        storageClassName: fast-ssd
        resources: { requests: { storage: 200Gi } }
```

**AI use.** Vector databases (Qdrant, Milvus), Redis, Kafka, Elasticsearch, and other stateful systems in AI
pipelines.

**Pitfalls and senior practice.**
- Deleting a StatefulSet does **not** delete its PVCs by default. That's intentional, to protect data. Set
  `persistentVolumeClaimRetentionPolicy` if you want cleanup.
- Replicas don't replicate data by themselves. The database must do replication. For production, often prefer a
  managed database or the vendor's operator.
- A pod stuck on a dead node blocks its replacement, because two `qdrant-1` pods must never run at once.

#### C5. DaemonSet

**What it is.** A controller that runs exactly one pod on every node (or on every node matching a selector). New
nodes get one automatically.

**In plain words.** A smoke detector in every room, including rooms added later.

```mermaid
flowchart LR
  DSD["DaemonSet dcgm-exporter<br/>nodeSelector: gpu=true"] --> G1["GPU node 1<br/>exporter pod"]
  DSD --> G2["GPU node 2<br/>exporter pod"]
  DSD --> G3["New GPU node<br/>exporter pod auto-added"]
  DSD -.->|"skipped"| CPU["CPU node"]
```

**How to read it:** the DaemonSet's `nodeSelector` limits it to nodes labeled as GPU nodes, so every GPU node
gets exactly one **dcgm-exporter** pod, a small service that publishes GPU metrics for Prometheus (Section 16). A
new GPU node gets its pod automatically, and CPU-only nodes are skipped.

```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata: { name: dcgm-exporter, namespace: gpu-operator }
spec:
  selector: { matchLabels: { app: dcgm-exporter } }
  updateStrategy: { type: RollingUpdate, rollingUpdate: { maxUnavailable: 1 } }
  template:
    metadata: { labels: { app: dcgm-exporter } }
    spec:
      nodeSelector: { nvidia.com/gpu.present: "true" }
      tolerations: [{ key: nvidia.com/gpu, operator: Exists, effect: NoSchedule }]   # GPU nodes are tainted
      priorityClassName: system-node-critical
      containers:
        - name: exporter
          image: nvcr.io/nvidia/k8s/dcgm-exporter:3.3.8-3.6.0-ubuntu22.04
          ports: [{ containerPort: 9400, name: metrics }]
```

**AI use.** GPU device plugins, DCGM GPU metrics exporters, log and metric agents, NodeLocal DNSCache, image
pre-pullers for large inference images, and CNI and CSI node plugins.

**Pitfalls and senior practice.** Forgetting the GPU taint toleration means the DaemonSet silently skips GPU nodes,
which is a classic reason GPU metrics are missing. DaemonSet pods use resources on *every* node, so keep them
small. Give critical agents a high PriorityClass so they're never evicted.

#### C6. Job

**What it is.** A controller that runs pods **to completion**. It retries failures up to `backoffLimit` and
records success when `completions` pods succeed. `parallelism` controls how many run at once. **Indexed Jobs**
give each pod a stable index (`JOB_COMPLETION_INDEX`), which is ideal for sharding work.

**In plain words.** A batch of envelopes to stuff: hire up to 10 temps at once, the work is done after 100
envelopes, and give up after 6 failed attempts.

```mermaid
flowchart LR
  JOBJ["Job embed-corpus<br/>completions: 100, parallelism: 10"] --> W["10 pods at a time<br/>index 0 to 99"]
  W -->|"success"| DONE["100 succeeded<br/>Complete"]
  W -->|"fail"| RETRY{"Retries under backoffLimit?"}
  RETRY -->|"yes"| W
  RETRY -->|"no"| FAILJ["Job Failed"]
```

**How to read it:** the Job needs 100 successful pods (**completions**) and runs at most 10 at a time
(**parallelism**). With an Indexed Job, each pod gets a number from 0 to 99 and processes that shard of the
corpus. A failed pod is retried until the failure count reaches **backoffLimit**, with a growing wait between
attempts, and then the whole Job is marked Failed.

```yaml
apiVersion: batch/v1
kind: Job
metadata: { name: embed-corpus, namespace: ml }
spec:
  completionMode: Indexed            # each pod gets JOB_COMPLETION_INDEX 0..99 = one shard of the corpus
  completions: 100
  parallelism: 10
  backoffLimit: 6
  activeDeadlineSeconds: 14400       # hard stop after 4 h
  ttlSecondsAfterFinished: 86400     # auto-delete a day later (protects etcd)
  podFailurePolicy:
    rules:
      - action: FailJob              # a code bug: don't burn retries
        onExitCodes: { containerName: embed, operator: In, values: [42] }
      - action: Ignore               # node drain or preemption: don't count as a failure
        onPodConditions: [{ type: DisruptionTarget }]
  template:
    spec:
      restartPolicy: Never
      containers:
        - name: embed
          image: registry.example.com/embed-batch:1.4.0
          command: ["python", "embed.py", "--shard", "$(JOB_COMPLETION_INDEX)", "--num-shards", "100"]
          resources: { limits: { nvidia.com/gpu: 1 } }
```

**AI use.** Batch embedding, offline batch inference, evaluation runs, data preprocessing, and single-node
fine-tuning. Multi-node training uses JobSet or the Kubeflow training operator built on top of Jobs (Section 11).

**Pitfalls and senior practice.** Make each shard **idempotent**, because retries and preemption re-run shards.
Without `ttlSecondsAfterFinished`, thousands of finished Jobs pile up in etcd.

#### C7. CronJob

**What it is.** A controller that creates a Job on a cron schedule.

**In plain words.** An alarm clock that hires the envelope-stuffing crew every night at 2 a.m.

```mermaid
flowchart LR
  CRON["CronJob nightly-eval<br/>0 2 * * *"] -->|"at 02:00"| J1["Job nightly-eval-28901"]
  CRON --> POL{"Previous run still going?"}
  POL -->|"concurrencyPolicy Forbid"| SKIP["Skip this run"]
  J1 --> PODJ["Pods run to completion"]
```

**How to read it:** `0 2 * * *` is cron syntax, with five fields: minute (0), hour (2), day of month, month, and
day of week (`*` means "any"). So it runs every day at 02:00. At that time, the CronJob creates a Job with a
unique name. If last night's run is still going, `concurrencyPolicy: Forbid` skips tonight's run instead of
starting a second copy.

```yaml
apiVersion: batch/v1
kind: CronJob
metadata: { name: nightly-eval, namespace: ml }
spec:
  schedule: "0 2 * * *"
  timeZone: "Etc/UTC"
  concurrencyPolicy: Forbid           # never overlap two eval runs
  startingDeadlineSeconds: 3600       # if the controller was down, still start within 1 h
  successfulJobsHistoryLimit: 3
  failedJobsHistoryLimit: 5
  jobTemplate:
    spec:
      backoffLimit: 2
      template:
        spec:
          restartPolicy: Never
          containers:
            - name: eval
              image: registry.example.com/eval-harness:2.1.0
              args: ["--model", "prod", "--suite", "regression"]
```

**AI use.** Nightly evaluation, drift checks (Section 17), index rebuilds, feature backfills, and data cleanup.

**Pitfalls and senior practice.** Set `concurrencyPolicy: Forbid` for anything that writes shared state. Alert on
"last successful run" age, not just on failures, because a CronJob that silently stops being scheduled produces no
failure. For multi-step pipelines with dependencies, use a workflow engine (Argo Workflows, Airflow) instead.

---

### D. Networking

```mermaid
flowchart LR
  NET["Internet"] --> GW["Gateway API or Ingress<br/>L7: host, path, TLS"]
  NET --> LBS["Service type LoadBalancer<br/>L4"]
  GW --> CIP["Service ClusterIP"]
  LBS --> CIP
  CIP --> ES["EndpointSlices<br/>ready pod IPs"]
  ES --> PODN["Pods"]
  NP["NetworkPolicy<br/>who may talk to whom"] -.->|"enforced by CNI"| PODN
```

**How to read it:** traffic from outside enters through an L7 Gateway or Ingress (host and path routing, TLS) or
an L4 LoadBalancer Service. Inside the cluster, a Service gives a stable name and virtual IP, EndpointSlices list
the ready pods behind it, and NetworkPolicy decides which pods may talk to which.

#### D1. Service: the five kinds

**What it is.** A stable name and virtual IP in front of a changing set of pods, chosen by label selector. Pods
come and go, but the Service's address doesn't change. Lecture 31 introduced it. Here are all five kinds.

**In plain words.** A company switchboard number. Employees change desks and leave, but customers always call the
same number.

```mermaid
flowchart TB
  subgraph KINDS["Service kinds"]
    C1S["ClusterIP<br/>virtual IP inside cluster"]
    C2S["NodePort<br/>ClusterIP + port 30000-32767 on every node"]
    C3S["LoadBalancer<br/>NodePort + cloud LB"]
    C4S["ExternalName<br/>DNS CNAME to outside name"]
    C5S["Headless clusterIP None<br/>DNS returns pod IPs"]
  end
  C3S --> C2S --> C1S
```

**How to read it:** ClusterIP, NodePort, and LoadBalancer build on each other: a LoadBalancer Service also gets a
NodePort and a ClusterIP. ExternalName and Headless are different: neither has a virtual IP, and both work purely
through DNS. A **NodePort** opens the same port (from the range 30000–32767) on every node's own IP address. An
ExternalName Service answers DNS lookups with a **CNAME** record, a DNS alias that says "this name is really that
other name". A Headless Service (`clusterIP: None`) answers with the IP addresses of all its ready pods, so the
client chooses which pod to call.

```yaml
# 1. ClusterIP (default): internal callers use http://embedder.ml
apiVersion: v1
kind: Service
metadata: { name: embedder, namespace: ml }
spec:
  selector: { app: embedder }
  ports: [{ name: http, port: 80, targetPort: 8000 }]
---
# 2. LoadBalancer: public or internal cloud LB; Local keeps the client IP and skips the extra node hop
apiVersion: v1
kind: Service
metadata:
  name: llm-public
  annotations: { service.beta.kubernetes.io/aws-load-balancer-type: "nlb" }
spec:
  type: LoadBalancer
  externalTrafficPolicy: Local
  selector: { app: llm }
  ports: [{ port: 443, targetPort: 8443 }]
---
# 3. ExternalName: in-cluster name for an outside dependency (swap to an in-cluster DB later with no code change)
apiVersion: v1
kind: Service
metadata: { name: feature-db, namespace: ml }
spec:
  type: ExternalName
  externalName: features.abc123.us-east-1.rds.amazonaws.com
---
# 4. Headless: DNS returns every pod IP, for StatefulSets and client-side gRPC load balancing
apiVersion: v1
kind: Service
metadata: { name: qdrant, namespace: ml }
spec:
  clusterIP: None
  selector: { app: qdrant }
  ports: [{ name: grpc, port: 6334 }]
```

| Kind | Reachable from | Typical AI use | Watch out for |
|---|---|---|---|
| ClusterIP | Inside cluster | Embedder, reranker, vector DB, internal LLM | Connection-level balancing only |
| NodePort | Node IPs | Labs, bare metal behind your own LB | Exposes every node, odd port range |
| LoadBalancer | Outside (one cloud LB each) | One public model API | One LB per Service costs money, use a Gateway for many |
| ExternalName | Inside, resolves to outside DNS | Managed DB or SaaS API alias | No proxying, TLS name mismatch possible |
| Headless | Inside, per-pod DNS | StatefulSets, gRPC client-side LB, NCCL rendezvous | No virtual IP, clients must handle pod changes |

**Pitfalls and senior practice.**
- **gRPC and HTTP/2 imbalance.** One long-lived connection pins to one pod through ClusterIP. Use an L7 proxy,
  mesh, or Gateway, or a Headless Service plus client-side round robin.
- `sessionAffinity: ClientIP` gives crude stickiness. For KV-cache or prefix-aware routing to LLM replicas, use
  the Gateway API Inference Extension (entry D4) instead.
- `internalTrafficPolicy: Local` keeps traffic on the same node, which is useful for node-local caches.

#### D2. EndpointSlice

**What it is.** The list of actual pod IPs and ports behind a Service, split into slices of up to 100 endpoints
each. The EndpointSlice controller maintains them from the Service selector and pod readiness. kube-proxy, CoreDNS,
and ingress controllers read them.

**In plain words.** The switchboard's live list of who is at their desk right now, split into pages so updating
one name doesn't reprint the whole book.

```mermaid
flowchart LR
  SVCE["Service embedder<br/>selector app=embedder"] --> ESC["EndpointSlice controller"]
  PODS["Pods with app=embedder"] -->|"readiness"| ESC
  ESC --> SL1["Slice 1: up to 100 endpoints<br/>ready, serving, terminating"]
  SL1 --> CONSUMERS["kube-proxy, CoreDNS,<br/>ingress and gateway controllers"]
```

**How to read it:** the controller combines the Service's selector with each pod's readiness and writes slices.
Each endpoint carries three conditions. **ready** means it should get new traffic. **serving** means it can still
answer requests. **terminating** means it's shutting down, so it gets no new traffic but may finish in-flight
requests. Everything that routes traffic reads these slices.

```bash
kubectl get endpointslices -n ml -l kubernetes.io/service-name=embedder -o wide
```

**AI use.** When a model server's readiness probe fails (for example while weights load), it's removed from the
slice and gets no traffic. That's how slow model loading stays invisible to users.

**Pitfalls and senior practice.** "Service has no endpoints" almost always means the selector labels don't match
the pod labels, or no pod is Ready. Check this first when a Service returns connection refused.

#### D3. Ingress

**What it is.** An L7 HTTP routing object: host and path rules plus TLS, sending traffic to Services. It does
nothing by itself. An **Ingress controller** (a reverse proxy such as NGINX, Traefik, HAProxy, or a cloud load
balancer controller) implements it. The API is stable but frozen, and new features go into the Gateway API.

**In plain words.** The building lobby directory: "Floor 3 for /chat, floor 5 for /embed", with the receptionist
(controller) actually walking you there.

```mermaid
flowchart LR
  USERI["https://ai.example.com"] --> ICTRL["Ingress controller pods<br/>reads Ingress objects"]
  ICTRL -->|"/v1/chat"| SCHAT["Service llm"]
  ICTRL -->|"/v1/embed"| SEMB["Service embedder"]
  TLSI["Secret ai-tls<br/>certificate"] -.-> ICTRL
```

**How to read it:** the Ingress controller is an ordinary set of pods running a reverse proxy (a server that
receives requests and forwards them to the right backend). It reads Ingress objects and routes
`https://ai.example.com/v1/chat` to the `llm` Service and `/v1/embed` to the `embedder` Service. **TLS** is the
encryption behind `https`. The certificate and private key that prove the site's identity are stored in the
Secret `ai-tls`, usually created and renewed automatically by cert-manager.

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata: { name: ai-api, namespace: ml }
spec:
  ingressClassName: traefik          # which controller implements this Ingress
  tls: [{ hosts: [ai.example.com], secretName: ai-tls }]
  rules:
    - host: ai.example.com
      http:
        paths:
          - { path: /v1/chat,  pathType: Prefix, backend: { service: { name: llm,      port: { number: 80 } } } }
          - { path: /v1/embed, pathType: Prefix, backend: { service: { name: embedder, port: { number: 80 } } } }
```

**AI use.** A single public entry point for several model APIs.

**Pitfalls and senior practice.**
- Timeouts, body size, and streaming behavior are set through **controller-specific annotations**, so they aren't
  portable. LLM streaming needs long read timeouts and response buffering turned off.
- The community ingress-nginx controller was retired (best-effort maintenance ended in March 2026). Plan new
  platforms on the Gateway API, and migrate existing ingress-nginx installs.

#### D4. Gateway API

**What it is.** The successor to Ingress: a family of role-oriented resources. Platform teams own a
`GatewayClass` (which implementation) and a `Gateway` (listeners, ports, TLS). App teams attach routes
(`HTTPRoute`, `GRPCRoute`) from their own namespaces. It supports weighted traffic splitting, header matching,
and request mirroring in the core API. The **Gateway API Inference Extension** adds `InferencePool`, which routes
LLM requests to the replica with the best KV-cache and queue state.

**In plain words.** Ingress is one shared lobby directory that everyone edits. The Gateway API gives the building
owner the front doors, and gives each tenant their own signs pointing to their floor.

```mermaid
flowchart LR
  GC["GatewayClass<br/>owned by infra provider"] --> GWD["Gateway public-gw<br/>owned by platform team"]
  GWD --> HR1["HTTPRoute chat<br/>owned by app team ml"]
  GWD --> GR1["GRPCRoute embed"]
  HR1 -->|"weight 90"| V1["Service llm-v1"]
  HR1 -->|"weight 10"| V2["Service llm-v2 canary"]
  HR2["HTTPRoute with InferencePool backend"] --> IP["InferencePool<br/>KV-cache aware picker"]
  GWD --> HR2
```

**How to read it:** three owners, three layers. The infrastructure provider supplies a **GatewayClass**, which
names the implementation (Envoy Gateway, Istio, a cloud load balancer). The platform team creates a **Gateway**,
the actual entry point with its ports, hostnames, and certificates. App teams write **routes** in their own
namespaces. An **HTTPRoute** matches HTTP requests by path or header. A **GRPCRoute** matches gRPC calls by
service and method (gRPC is a fast binary RPC protocol over HTTP/2, common for embedding and model APIs).
**Weights** split traffic: 90% to v1 and 10% to the canary v2. An **InferencePool** is a group of LLM server pods
plus an endpoint picker that sends each request to the replica with free KV cache and a short queue (the
**KV cache** is GPU memory holding the attention state of requests in progress, Section 25).

```yaml
apiVersion: gateway.networking.k8s.io/v1
kind: Gateway
metadata: { name: public-gw, namespace: gateway-system }
spec:
  gatewayClassName: envoy-gateway
  listeners:
    - name: https
      protocol: HTTPS
      port: 443
      hostname: ai.example.com
      tls: { certificateRefs: [{ name: ai-tls }] }
      allowedRoutes: { namespaces: { from: Selector, selector: { matchLabels: { gateway-access: "true" } } } }
---
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata: { name: chat, namespace: ml }
spec:
  parentRefs: [{ name: public-gw, namespace: gateway-system }]
  hostnames: [ai.example.com]
  rules:
    - matches: [{ path: { type: PathPrefix, value: /v1/chat } }]
      timeouts: { request: 300s }           # long LLM generations
      backendRefs:
        - { name: llm-v1, port: 80, weight: 90 }
        - { name: llm-v2, port: 80, weight: 10 }   # 10% canary of the new model
```

**AI use.** Canary rollouts of new models by weight, routing by header (`x-model: llama3-70b`), gRPC routes for
embedding services, and model-aware load balancing with the Inference Extension.

**Pitfalls and senior practice.** Features beyond the core API vary by implementation (Envoy Gateway, Istio,
Cilium, cloud gateways), so check the conformance level of the one you pick. Restrict which namespaces may attach
routes (`allowedRoutes`), or any team can claim any path on the public gateway.

#### D5. NetworkPolicy

**What it is.** A firewall rule for pods, selected by labels. By default all pods can talk to all pods. Once a
pod is selected by any policy for a direction (ingress or egress), only traffic explicitly allowed for that
direction gets through. The CNI plugin enforces it.

**In plain words.** Office key cards. By default every door is open. A policy says "only the finance team's
cards open the finance room."

```mermaid
flowchart LR
  GWN["gateway pods"] -->|"allowed :8000"| LLMN["llm pods"]
  RAGN["rag-api pods"] -->|"allowed :6334"| QD["qdrant pods"]
  OTHER["any other pod"] -.->|"denied"| QD
  LLMN -.->|"egress denied<br/>except DNS"| INET["Internet"]
```

**How to read it:** **ingress** here means traffic coming *into* a pod, and **egress** means traffic going *out*
of it. These aren't the Ingress object from entry D3. Only gateway pods may reach the LLM pods on port 8000, and
only rag-api pods may reach Qdrant on port 6334. Every other pod is denied. The LLM pods may not call the internet
at all, except for DNS lookups, which every pod needs to resolve Service names.

```yaml
# 1. Default deny all ingress and egress in the namespace
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: { name: default-deny, namespace: ml }
spec:
  podSelector: {}
  policyTypes: [Ingress, Egress]
---
# 2. Only rag-api may reach qdrant
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: { name: qdrant-from-rag, namespace: ml }
spec:
  podSelector: { matchLabels: { app: qdrant } }
  policyTypes: [Ingress]
  ingress:
    - from: [{ podSelector: { matchLabels: { app: rag-api } } }]
      ports: [{ port: 6334, protocol: TCP }]
---
# 3. Allow DNS egress for everyone (otherwise default-deny breaks all name lookups)
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: { name: allow-dns, namespace: ml }
spec:
  podSelector: {}
  policyTypes: [Egress]
  egress:
    - to: [{ namespaceSelector: { matchLabels: { kubernetes.io/metadata.name: kube-system } }, podSelector: { matchLabels: { k8s-app: kube-dns } } }]
      ports: [{ port: 53, protocol: UDP }, { port: 53, protocol: TCP }]
```

**AI use.** Isolate tenants' vector databases, block model servers and agents from calling the internet
(data exfiltration and prompt-injection defense), and allow only the gateway to reach GPU pods.

**Pitfalls and senior practice.**
- Default deny without a DNS rule breaks everything. Always add the DNS egress rule.
- Policies are additive allow-lists: there's no "deny" rule in the core API. For FQDN egress rules (allow only
  `api.openai.com`) or L7 rules, use Cilium or Calico extensions, or an egress gateway.
- Test policies with a debug pod (`kubectl run ... -- nc -zv qdrant 6334`), because a CNI that doesn't support
  them ignores them silently.

---

### E. Configuration and storage

#### E1. ConfigMap

**What it is.** Non-secret configuration as key-value pairs or whole files, consumed as environment variables or
mounted as files. Limited to 1 MiB. Lecture 32 introduced it.

**In plain words.** The settings sheet pinned next to the machine, separate from the machine itself, so the same
machine (image) runs in dev and prod with different sheets.

```mermaid
flowchart LR
  CM["ConfigMap llm-config"] -->|"envFrom"| ENV["Env vars<br/>read once at start"]
  CM -->|"volume mount"| FILES["Files /etc/llm<br/>updated in place after ~1 min"]
  ENV --> APPC["Container"]
  FILES --> APPC
```

**How to read it:** there are two ways in. `envFrom` turns every key into an environment variable, read once when
the container starts, so a later change has no effect until the pod restarts. A **volume mount** turns every key
into a file under `/etc/llm`. The kubelet refreshes those files about a minute after the ConfigMap changes, but
the app only notices if it re-reads them.

```yaml
apiVersion: v1
kind: ConfigMap
metadata: { name: llm-config-v3, namespace: ml }
immutable: true                   # cannot change, protects against accidental edits and reduces API load
data:
  MAX_MODEL_LEN: "8192"
  GPU_MEMORY_UTILIZATION: "0.90"
  prompts.yaml: |
    system: "You are a helpful assistant. Answer only from the provided context."
```

**AI use.** Serving flags (context length, batch size), prompt templates, feature flags, and routing tables.

**Pitfalls and senior practice.** Changing a ConfigMap does **not** restart pods, and env vars never update. Use
versioned, immutable names (`llm-config-v3`) referenced from the Deployment, or a checksum annotation (Helm, Lecture
34), so a config change triggers a rollout you can roll back.

#### E2. Secret

**What it is.** Like a ConfigMap but for sensitive data: API keys, tokens, TLS certificates, and registry
credentials. Values are only **base64-encoded**, not encrypted, unless encryption at rest is enabled for etcd.
Types include `Opaque`, `kubernetes.io/tls`, and `kubernetes.io/dockerconfigjson`.

**In plain words.** A locked drawer, but the default lock is cardboard. Real protection means encryption at rest,
access controls (RBAC), and ideally keeping the real key in an external safe.

```mermaid
flowchart LR
  VAULT["External store<br/>Vault, AWS Secrets Manager"] --> ESO["External Secrets Operator<br/>or Secrets Store CSI"]
  ESO --> SEC["Secret hf-token"]
  SEC -->|"encrypted at rest<br/>KMS provider"| ETCDS[("etcd")]
  SEC -->|"mounted file, not env"| PODSE["Pod"]
  RBACS["RBAC: only this ServiceAccount<br/>may get secrets"] -.-> SEC
```

**How to read it:** the real secret lives in an external store such as **HashiCorp Vault** or **AWS Secrets
Manager** (dedicated, audited secret vaults). The **External Secrets Operator** copies it into a Kubernetes Secret
and keeps it updated. The **Secrets Store CSI driver** mounts it straight into the pod as a file. In etcd, the
Secret is encrypted with a key from a **KMS** (the cloud's key management service), so a stolen etcd backup is
useless. RBAC limits who may read it.

```yaml
apiVersion: v1
kind: Secret
metadata: { name: hf-token, namespace: ml }
type: Opaque
stringData:                       # plain text here, stored base64; never commit real values to git
  HF_TOKEN: "replace-me"
---
# consume as a file (safer than env: not visible in `kubectl describe` output or crash dumps)
volumes:
  - name: hf
    secret: { secretName: hf-token, defaultMode: 0400 }
```

**AI use.** Hugging Face tokens for gated models, provider API keys for LLM gateways, vector DB credentials, and
image pull secrets for private model images.

**Pitfalls and senior practice.**
- Anyone who can `get secrets` in a namespace, or create a pod there, can read them. Keep RBAC tight.
- Enable etcd encryption with a KMS provider. Sync from Vault or a cloud secret manager instead of committing
  Secrets to git. Use Sealed Secrets or SOPS if they must live in git.
- Prefer workload identity (entry H1) over long-lived cloud keys stored in Secrets.

#### E3. Volumes: emptyDir, hostPath, projected, and image

**What it is.** Storage attached to a pod's lifetime or to the node:
- `emptyDir` is scratch space that lives as long as the pod. Use `medium: Memory` for a RAM-backed tmpfs.
- `hostPath` mounts a node directory. It's dangerous: it breaks isolation and ties a pod to one node.
- `projected` combines Secrets, ConfigMaps, the downward API, and ServiceAccount tokens into one directory.
- `image` volumes (beta in recent releases) mount the contents of an OCI image read-only, which is a way to
  ship model weights as an artifact.

**In plain words.** `emptyDir` is the desk you clear when you leave. `hostPath` is drilling into the building's
wall, which works but makes a mess for the next tenant.

```mermaid
flowchart LR
  PODV["Training pod"] --> SHM["emptyDir medium Memory<br/>mounted at /dev/shm"]
  PODV --> SCR["emptyDir on local NVMe<br/>dataset cache"]
  PODV --> PROJ["projected<br/>token + config + labels"]
  PODV --> IMGV["image volume<br/>model weights OCI artifact"]
  SHM --> DL["PyTorch DataLoader<br/>workers share tensors"]
```

**How to read it:** `/dev/shm` is Linux **shared memory**, a RAM-backed folder that processes use to exchange
data quickly. PyTorch's **DataLoader** starts several worker processes to load batches, and they hand finished
batches (tensors) to the training process through `/dev/shm`. Mounting an emptyDir with `medium: Memory` there
makes it large enough. The **local NVMe** emptyDir is fast scratch space on the node's own SSD. The **projected**
volume combines several sources into one folder. The **image volume** mounts model weights shipped as an **OCI
artifact** (a file package stored in a container registry, just like an image).

```yaml
# The classic AI fix: containers get only 64 MB of /dev/shm by default,
# so PyTorch DataLoader workers crash with "bus error" or shared memory errors.
volumes:
  - name: dshm
    emptyDir: { medium: Memory, sizeLimit: 16Gi }   # counts against the pod's memory limit
  - name: scratch
    emptyDir: { sizeLimit: 200Gi }
containers:
  - name: train
    volumeMounts:
      - { name: dshm, mountPath: /dev/shm }
      - { name: scratch, mountPath: /scratch }
```

**AI use.** `/dev/shm` for DataLoaders and NCCL, local NVMe scratch for dataset caches and weight downloads, and
shared weights between an init container and the server.

**Pitfalls and senior practice.** Memory-backed `emptyDir` counts toward the memory limit, so an oversized cache
gets the pod OOM-killed. Ban `hostPath` in tenant namespaces with Pod Security Admission (entry H3).

#### E4. PersistentVolume (PV)

**What it is.** A piece of real storage in the cluster (a cloud disk, an NFS export, a Lustre filesystem), either
created by an admin or dynamically provisioned by a CSI driver. It's a cluster-wide object with a capacity,
access modes, and a reclaim policy.

**In plain words.** A physical storage unit in the warehouse, with its size and rules written on the door.

```mermaid
flowchart LR
  PVA["PersistentVolume pv-ckpt<br/>2 Ti, ReadWriteMany<br/>reclaim Retain"] --> BACK["FSx for Lustre<br/>or Filestore, EFS"]
  PVCA["PVC ckpt-shared"] -->|"bound 1 to 1"| PVA
```

**How to read it:** the PV `pv-ckpt` describes 2 TiB of shared storage that many nodes can read and write
(`ReadWriteMany`). The backend here is a shared file system: **FSx for Lustre** (AWS's managed version of Lustre,
a very fast parallel file system used in HPC), Google **Filestore**, or Amazon **EFS**. **Reclaim Retain** means
the data is kept when the claim is deleted. A PVC binds to exactly one PV, and that PV then belongs to that claim
only.

| Access mode | Meaning | AI example |
|---|---|---|
| ReadWriteOnce (RWO) | Read-write from one node | Vector DB replica disk |
| ReadOnlyMany (ROX) | Read-only from many nodes | Shared model weights |
| ReadWriteMany (RWX) | Read-write from many nodes | Shared checkpoint directory for multi-node training |
| ReadWriteOncePod (RWOP) | Read-write from exactly one pod | Single-writer databases |

```yaml
apiVersion: v1
kind: PersistentVolume
metadata: { name: pv-ckpt }
spec:
  capacity: { storage: 2Ti }
  accessModes: [ReadWriteMany]
  persistentVolumeReclaimPolicy: Retain     # keep data if the claim is deleted
  storageClassName: ""                      # static PV, not dynamically provisioned
  nfs: { server: 10.0.5.10, path: /exports/checkpoints }
```

**Pitfalls and senior practice.** `Delete` reclaim (the default for dynamic provisioning) destroys data when the
PVC is deleted. Use `Retain` for anything you can't regenerate, like checkpoints and labeled data.

#### E5. PersistentVolumeClaim (PVC)

**What it is.** A pod's request for storage: "I need 200 Gi, ReadWriteOnce, class fast-ssd." Kubernetes binds
it to a matching PV, or provisions a new one through the StorageClass. Pods reference the PVC, never the PV.

**In plain words.** A rental application for a storage unit. You say what size you need, and the warehouse
hands you a key.

```mermaid
flowchart LR
  PODPV["Pod"] -->|"claimName"| PVCX["PVC 200 Gi fast-ssd"]
  PVCX -->|"dynamic provisioning"| SCX["StorageClass fast-ssd"]
  SCX -->|"CSI CreateVolume"| PVX["New PV + cloud disk"]
  PVCX -->|"Bound"| PVX
```

**How to read it:** the pod refers to the claim by name (`claimName` in the pod's volume list). If no existing PV
matches, **dynamic provisioning** takes over: the StorageClass tells its CSI driver to `CreateVolume`, a new PV
object is created for the new disk, and the claim's status becomes `Bound`.

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata: { name: model-cache, namespace: ml }
spec:
  accessModes: [ReadWriteOnce]
  storageClassName: fast-ssd
  resources: { requests: { storage: 200Gi } }
```

```bash
kubectl get pvc -n ml                         # Pending means no PV matched or provisioning failed
kubectl describe pvc model-cache -n ml        # Events explain why
```

**Pitfalls and senior practice.** A PVC stuck `Pending` usually means a wrong StorageClass name, an unsupported
access mode (block disks can't do RWX), or `WaitForFirstConsumer` waiting for a pod (which is expected). Expand
volumes by editing `resources.requests.storage` if the class allows it. You can't shrink them.

#### E6. StorageClass

**What it is.** A template for dynamic provisioning: which CSI driver, which disk type and parameters, the
reclaim policy, whether volumes can expand, and **when** to bind.

**In plain words.** The warehouse's menu of unit types: "standard", "fast SSD", "shared". Customers order from
the menu instead of building units.

```mermaid
flowchart LR
  SCY["StorageClass fast-ssd<br/>WaitForFirstConsumer"] --> WAIT["PVC waits"]
  POD1["Pod scheduled to zone us-east-1b"] --> WAIT
  WAIT --> PROV["Provision disk in us-east-1b<br/>same zone as the pod"]
```

**How to read it:** with `volumeBindingMode: WaitForFirstConsumer`, creating the PVC doesn't create a disk yet. The
claim waits until a pod using it is scheduled. The scheduler picks a node, here in **zone** `us-east-1b` (an
availability zone, one data center within an AWS region). Only then is the disk created, in that same zone,
because cloud block disks can only attach to machines in their own zone.

```yaml
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata: { name: fast-ssd }
provisioner: ebs.csi.aws.com
parameters: { type: gp3, iops: "16000", throughput: "1000" }
reclaimPolicy: Delete
allowVolumeExpansion: true
volumeBindingMode: WaitForFirstConsumer   # create the disk where the pod lands, not in a random zone
```

**AI use.** Separate classes for fast checkpoint scratch, cheap bulk storage, and shared filesystems for weights.

**Pitfalls and senior practice.** With `Immediate` binding, the disk may be created in a zone where no GPU node
exists, so the pod stays Pending forever. Use `WaitForFirstConsumer` for zonal storage. Mark exactly one class as
the default, and use **VolumeSnapshots** (`VolumeSnapshotClass`) for fast backups of vector DB disks.

---

### F. Scheduling, placement, and tenancy

#### F1. Namespace

**What it is.** A virtual partition of the cluster. Names are unique within a namespace, and RBAC, quotas,
LimitRanges, NetworkPolicies, and Pod Security levels all apply per namespace. Nodes, PVs, StorageClasses, and
ClusterRoles are cluster-wide and don't belong to any namespace.

**In plain words.** Floors of an office building. Each team gets a floor with its own key cards, budget, and
rules, but they share the building's elevators and power.

```mermaid
flowchart TB
  subgraph NS1["namespace team-search"]
    Q1["ResourceQuota 16 GPUs"]
    R1["RoleBinding search-devs"]
    N1["NetworkPolicy default-deny"]
  end
  subgraph NS2["namespace team-ads"]
    Q2["ResourceQuota 8 GPUs"]
    R2["RoleBinding ads-devs"]
  end
  CW["Cluster-wide: Nodes, PVs,<br/>StorageClasses, ClusterRoles"]
```

**How to read it:** each team namespace carries its own rules. A **ResourceQuota** caps its total GPUs (entry F2),
a **RoleBinding** says who may work in it (entry H2), and a **NetworkPolicy** isolates its traffic (entry D5). The
box at the bottom lists objects that don't belong to any namespace and are shared by every team.

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: team-search
  labels:
    pod-security.kubernetes.io/enforce: restricted    # entry H3
    gateway-access: "true"                            # entry D4: may attach routes to the public gateway
```

**Pitfalls and senior practice.** Namespaces are a *soft* boundary: pods share kernels and nodes. For hostile
tenants, add dedicated node pools, sandboxed runtimes (gVisor, Kata), or separate clusters (Section 18).

#### F2. ResourceQuota

**What it is.** A per-namespace cap on total resources (CPU, memory, GPUs, storage) and object counts (pods,
Services, LoadBalancers, PVCs). Requests that would exceed it are rejected at admission.

**In plain words.** A team's budget. When it's spent, new purchase orders are refused.

```mermaid
flowchart LR
  NEWP["New pod requests 4 GPUs"] --> ADM{"Quota check<br/>used 14 of 16 GPUs"}
  ADM -->|"14 + 4 over 16"| REJ["Rejected:<br/>exceeded quota"]
  ADM -->|"fits"| ACC["Admitted"]
```

**How to read it:** the namespace already uses 14 of its 16 GPUs. A new pod asking for 4 would bring the total to
18, so the API server rejects it at **admission**, before it's even stored. The pod is never created, so it never
shows up as Pending. The error appears on the Deployment's or Job's events instead.

```yaml
apiVersion: v1
kind: ResourceQuota
metadata: { name: team-search-quota, namespace: team-search }
spec:
  hard:
    requests.nvidia.com/gpu: "16"
    requests.cpu: "256"
    requests.memory: 2Ti
    limits.memory: 2Ti
    persistentvolumeclaims: "50"
    requests.storage: 20Ti
    services.loadbalancers: "2"
    count/jobs.batch: "200"
```

**AI use.** GPU budgets per team (this is the multi-tenant GPU platform in the FAANG notes below).

**Pitfalls and senior practice.** Once a quota covers CPU or memory, every pod must set those requests, or it's
rejected. Pair quotas with a LimitRange that supplies defaults. Quotas are hard caps and waste idle GPUs, so for
borrowing and fair sharing across teams, use Kueue's ClusterQueues and cohorts (Section 11).

#### F3. LimitRange

**What it is.** Per-namespace defaults and min/max bounds for individual containers or pods. It injects default
requests and limits into pods that don't set them, and rejects pods outside the bounds.

**In plain words.** The house rules for each order: "if you don't say, you get a medium; nobody orders more than
an extra-large."

```mermaid
flowchart LR
  PODL["Pod with no requests"] --> LR["LimitRange<br/>default 500m CPU, 1 Gi"]
  LR --> MUTD["Pod admitted with defaults"]
  BIG["Pod asking 512 Gi"] --> LR
  LR -->|"over max 256 Gi"| REJL["Rejected"]
```

**How to read it:** a pod that sets no requests is given the defaults (`500m` CPU means half a CPU core, since
`m` is a thousandth of a core). A pod asking for more than the maximum is rejected outright.

```yaml
apiVersion: v1
kind: LimitRange
metadata: { name: defaults, namespace: team-search }
spec:
  limits:
    - type: Container
      defaultRequest: { cpu: 500m, memory: 1Gi }
      default:        { cpu: "2",  memory: 4Gi }      # default limits
      max:            { cpu: "64", memory: 256Gi }
```

**Pitfalls and senior practice.** Defaults that are too small silently throttle or OOM-kill workloads that forgot
to set requests. Make the defaults visible to teams, and alert on pods running at their default limits.

#### F4. PriorityClass and preemption

**What it is.** A cluster-wide priority number. When the cluster is full, the scheduler can **preempt** (evict)
lower-priority pods to make room for higher-priority ones. Built-in classes `system-cluster-critical` and
`system-node-critical` protect core components.

**In plain words.** Boarding groups on a full flight. First class gets a seat even if a standby passenger has to
get off.

```mermaid
flowchart LR
  HP["Pending: online serving<br/>priority 100000"] --> FULL{"Cluster full?"}
  FULL -->|"yes"| PRE["Preempt batch pods<br/>priority 1000"]
  PRE --> RUNHP["Serving pod scheduled"]
  PRE --> REQ["Batch pods requeued<br/>resume from checkpoint"]
```

**How to read it:** a serving pod with priority 100000 can't fit. The scheduler finds batch pods with priority
1000 whose removal makes room, evicts them, and places the serving pod. The evicted batch pods are **requeued**
(recreated by their Job and wait their turn again), and if the training code saved **checkpoints** (snapshots of
model weights and optimizer state), they continue from the last one instead of starting over.

```yaml
apiVersion: scheduling.k8s.io/v1
kind: PriorityClass
metadata: { name: online-serving }
value: 100000
preemptionPolicy: PreemptLowerPriority
description: "User-facing inference. May preempt batch and research jobs."
---
apiVersion: scheduling.k8s.io/v1
kind: PriorityClass
metadata: { name: batch-preemptible }
value: 1000
preemptionPolicy: Never         # never evicts others, waits instead
```

**AI use.** Serving beats training, and production training beats research notebooks. Batch jobs fill idle GPUs
and get preempted when serving needs to scale.

**Pitfalls and senior practice.** Preempted jobs lose work unless they checkpoint often (Section 31). Without a
quota, anyone can use the highest class, so restrict who can use which PriorityClass with ResourceQuota
`scopeSelector` or admission policy.

#### F5. Taints and tolerations

**What it is.** A **taint** on a node repels pods. Only pods with a matching **toleration** may be scheduled
there. Effects: `NoSchedule` (don't place new pods), `PreferNoSchedule` (avoid if possible), and `NoExecute`
(also evict running pods).

**In plain words.** A "staff only" sign on a door. Only people with the matching badge go in. The badge lets you
in, but doesn't send you there (that's affinity, entry F6).

```mermaid
flowchart LR
  GN["GPU node<br/>taint nvidia.com/gpu NoSchedule"]
  WEB["Web pod, no toleration"] -.->|"repelled"| GN
  TRAIN["Training pod<br/>tolerates nvidia.com/gpu"] -->|"allowed"| GN
```

**How to read it:** the GPU node carries the taint `nvidia.com/gpu` with the effect `NoSchedule`. The web pod has no
matching toleration, so the scheduler is **repelled** (it won't place the pod there). The training pod declares
it tolerates that taint, so it's allowed on the node.

```bash
kubectl taint nodes gpu-node-1 nvidia.com/gpu=present:NoSchedule
```

```yaml
tolerations:
  - { key: nvidia.com/gpu, operator: Exists, effect: NoSchedule }
```

**AI use.** Keep CPU workloads off expensive GPU nodes. Managed GPU node pools on EKS, GKE, and AKS often add this
taint automatically.

**Pitfalls and senior practice.** A toleration only *allows* placement. Combine it with a node selector or
affinity so GPU pods actually *go to* GPU nodes. Remember DaemonSets need the toleration too (entry C5).

#### F6. Node affinity, pod affinity, and topology spread

**What it is.** Rules that attract pods to places:
- `nodeSelector` and **node affinity** pick nodes by label: GPU type, zone, spot vs on-demand.
- **Pod affinity** and **anti-affinity** place pods near or away from other pods.
- **topologySpreadConstraints** spread replicas evenly across zones or nodes.

Each comes in a hard form ("required") and a soft form ("preferred").

**In plain words.** Seating preferences: "seat me by a window" (node affinity), "next to my team" (pod
affinity), "don't put both pilots on the same plane" (anti-affinity and spread).

```mermaid
flowchart TB
  subgraph ZA["zone a"]
    A1["llm replica 1"]
    A2["llm replica 3"]
  end
  subgraph ZB["zone b"]
    B1["llm replica 2"]
    B2["llm replica 4"]
  end
  RULE["topologySpread maxSkew 1 by zone<br/>node affinity: H100 only"] -.-> ZA
  RULE -.-> ZB
```

**How to read it:** node affinity restricts the pods to H100 GPU nodes. The topology spread rule with **maxSkew 1**
says the replica count in any two zones may differ by at most 1, so four replicas land two per zone. If one zone
fails, half the capacity survives.

```yaml
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - { key: nvidia.com/gpu.product, operator: In, values: [NVIDIA-H100-80GB-HBM3] }
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 50
        preference: { matchExpressions: [{ key: karpenter.sh/capacity-type, operator: In, values: [on-demand] }] }
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: topology.kubernetes.io/zone
    whenUnsatisfiable: DoNotSchedule
    labelSelector: { matchLabels: { app: llm } }
```

**AI use.** Pin training to a GPU type, spread serving replicas across zones for availability, and co-locate
training workers in one placement group for network bandwidth.

**Pitfalls and senior practice.** Hard rules can make pods unschedulable when capacity is short. Use
`preferred` unless the rule is truly required. GPU node labels (`nvidia.com/gpu.product`) come from GPU Feature
Discovery, which the GPU Operator installs.

#### F7. PodDisruptionBudget (PDB)

**What it is.** A limit on how many pods of an app may be down at once during **voluntary** disruptions: node
drains, cluster upgrades, and autoscaler scale-downs. The eviction API respects it. It does not protect against
crashes or node failures.

**In plain words.** "At least 3 cashiers must stay on the floor during the fire drill."

```mermaid
flowchart LR
  DRAIN["kubectl drain node-7<br/>or autoscaler scale-down"] --> EV["Eviction API"]
  EV --> CHECK{"PDB llm<br/>minAvailable 3"}
  CHECK -->|"4 ready, evict 1"| OKE["Allowed"]
  CHECK -->|"3 ready"| BLOCK["Blocked, retry later"]
```

**How to read it:** `kubectl drain` empties a node before maintenance, and the autoscaler does the same before
removing a node. Both ask the **Eviction API** to remove pods one by one. With 4 ready pods and `minAvailable: 3`,
evicting one is allowed. With only 3 ready, the eviction is refused, and the drain keeps retrying until a
replacement pod is Ready elsewhere.

```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata: { name: llm, namespace: ml }
spec:
  minAvailable: 3                 # or maxUnavailable: 1
  selector: { matchLabels: { app: llm } }
```

**AI use.** Keep model serving capacity during node upgrades. Protect a vector DB StatefulSet's quorum.

**Pitfalls and senior practice.** A PDB with `minAvailable` equal to replicas (or `maxUnavailable: 0`) blocks
every drain forever, which stalls cluster upgrades. A single-replica app with a PDB can't be drained either.
Long-running training jobs usually need checkpointing and a drain window, not a PDB.

---

### G. Autoscaling

```mermaid
flowchart LR
  LOAD["Traffic or queue grows"] --> HPAX["HPA or KEDA<br/>adds pods"]
  HPAX --> PENDG["Pods Pending<br/>no room"]
  PENDG --> NODEAS["Cluster Autoscaler or Karpenter<br/>adds nodes"]
  VPAX["VPA<br/>right-sizes requests"] -.-> HPAX
```

**How to read it:** pod autoscalers (HPA, KEDA) change *how many* pods. VPA changes *how big* each pod is. Node
autoscalers (Cluster Autoscaler, Karpenter) add machines when pods can't fit. They work as a chain, and GPU node
startup plus model loading is usually the slowest link.

#### G1. HorizontalPodAutoscaler (HPA)

Covered in depth in Lecture 33. In short, it scales replicas as
`desired = ceil(current × currentMetric / target)`, using CPU, memory, or custom metrics. For LLM serving, scale on
queue depth or KV-cache usage (for example vLLM's `num_requests_waiting`), not CPU.

#### G2. VerticalPodAutoscaler (VPA)

**What it is.** An add-on that watches real usage and recommends, or applies, better CPU and memory
requests. Modes: `Off` (recommend only), `Initial` (set at pod creation), `Recreate` (evict and recreate pods with
new values), and in-place resizing in newer versions.

**In plain words.** A tailor who watches how you actually move and adjusts the suit size, instead of you guessing
once and never changing it.

```mermaid
flowchart LR
  MET["metrics-server usage history"] --> REC["VPA recommender"]
  REC --> VPAO["VPA object<br/>target 3.2 CPU, 11 Gi"]
  VPAO -->|"mode Off"| HUMAN["Engineers read recommendations"]
  VPAO -->|"mode Recreate"| UPD["Updater evicts pod,<br/>admission sets new requests"]
```

**How to read it:** VPA has three parts. The **recommender** reads usage history from **metrics-server** (the
cluster add-on that collects CPU and memory usage from every kubelet) and computes target requests. In `Off` mode,
engineers just read the recommendation. In `Recreate` mode, the **updater** evicts pods whose requests are far off,
and VPA's **admission** webhook writes the new requests into the replacement pod as it's created.

```yaml
apiVersion: autoscaling.k8s.io/v1
kind: VerticalPodAutoscaler
metadata: { name: feature-api, namespace: ml }
spec:
  targetRef: { apiVersion: apps/v1, kind: Deployment, name: feature-api }
  updatePolicy: { updateMode: "Off" }          # start with recommendations only
  resourcePolicy:
    containerPolicies:
      - containerName: "*"
        minAllowed: { cpu: 250m, memory: 512Mi }
        maxAllowed: { cpu: "8", memory: 32Gi }
```

**AI use.** Right-size CPU-side services (tokenizers, feature APIs, preprocessing) and find over-requested memory,
which is a common cost win (Section 12).

**Pitfalls and senior practice.** Don't let VPA and HPA both act on the same CPU or memory metric, because they
fight. VPA doesn't manage GPUs. Evicting pods to resize them disrupts serving, so use `Off` mode or in-place resize
for critical paths.

#### G3. Cluster Autoscaler and Karpenter

**What it is.** Node autoscalers. **Cluster Autoscaler** grows and shrinks predefined node groups when pods are
Pending or nodes are underused. **Karpenter** (AWS and Azure) skips node groups: it reads pending pods'
requirements and launches the cheapest right-sized instance directly, and it **consolidates** by replacing
underused nodes.

**In plain words.** Cluster Autoscaler orders more of the same tables you already have. Karpenter looks at the
guests waiting and orders exactly the table size they need.

```mermaid
flowchart LR
  PEN["Pending pod<br/>needs 8 H100"] --> KARP["Karpenter"]
  KARP --> NPOOL["NodePool gpu<br/>allowed types, spot or on-demand"]
  NPOOL --> EC2["Launch p5.48xlarge"]
  EC2 --> JOIN["Node joins,<br/>pod scheduled"]
  KARP --> CONS["Consolidation<br/>remove idle nodes"]
```

**How to read it:** a pod needing 8 H100 GPUs is Pending. Karpenter checks the **NodePool**, its rule book listing
the allowed instance types and whether **spot** (spare cloud capacity, up to ~70% cheaper but reclaimable with two
minutes' notice) or **on-demand** (normal price, never reclaimed) may be used. It launches a `p5.48xlarge` (the
AWS instance type with 8 H100 GPUs), the node joins, and the pod is scheduled. **Consolidation** later removes or
replaces nodes that are empty or underused, to cut cost.

```yaml
apiVersion: karpenter.sh/v1
kind: NodePool
metadata: { name: gpu }
spec:
  template:
    spec:
      nodeClassRef: { group: karpenter.k8s.aws, kind: EC2NodeClass, name: gpu }
      requirements:
        - { key: karpenter.k8s.aws/instance-family, operator: In, values: [p5, g6e] }
        - { key: karpenter.sh/capacity-type, operator: In, values: [on-demand, spot] }
      taints: [{ key: nvidia.com/gpu, value: present, effect: NoSchedule }]
  limits: { nvidia.com/gpu: 64 }              # hard spending cap for the pool
  disruption:
    consolidationPolicy: WhenEmpty           # never move running GPU jobs to save money
    consolidateAfter: 10m
```

**AI use.** Bring GPU nodes up only when jobs are queued, and scale to zero GPU nodes overnight.

**Pitfalls and senior practice.**
- GPU node startup plus driver setup plus image pull plus model load can take 5–15 minutes. Keep a warm
  minimum for serving, or use over-provisioning placeholder pods with negative priority.
- Aggressive consolidation evicts long training jobs. Use `WhenEmpty` for GPU pools, or the
  `karpenter.sh/do-not-disrupt` annotation on pods.
- Always set limits on the pool, or a bug that creates pods can launch a fortune in GPUs.

#### G4. KEDA (event-driven autoscaling)

**What it is.** An add-on that scales workloads on event sources such as queue length, Kafka lag, Prometheus
queries, and cron schedules, including **scale to zero**. It creates and drives an HPA under the hood.

**In plain words.** A manager who watches the line outside the door, not how tired the staff look, and sends
everyone home when the line is empty.

```mermaid
flowchart LR
  Q["Queue: 4,000 pending<br/>embedding requests"] --> KEDAX["KEDA ScaledObject"]
  KEDAX --> HPAK["HPA it manages"]
  HPAK --> WORK["Workers 0 to 50"]
  EMPTY["Queue empty 5 min"] --> KEDAX
  KEDAX -->|"scale to 0"| WORK
```

**How to read it:** you describe the scaling rule in a **ScaledObject**, KEDA's custom resource (entry I1), which
names the workload, the event source (here, the queue depth), and the replica bounds. KEDA creates and feeds an
HPA, so 4,000 queued requests become up to 50 workers. When the queue has been empty for the cooldown period,
KEDA scales the workers to zero, which a plain HPA can't do.

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata: { name: embed-workers, namespace: ml }
spec:
  scaleTargetRef: { name: embed-workers }
  minReplicaCount: 0
  maxReplicaCount: 50
  cooldownPeriod: 300
  triggers:
    - type: prometheus
      metadata:
        serverAddress: http://prometheus.monitoring:9090
        query: sum(embed_queue_depth)
        threshold: "100"            # about 100 queued items per worker
```

**AI use.** Batch embedding and async inference workers that idle most of the day, and GPU workloads that should
release nodes when idle.

**Pitfalls and senior practice.** Scaling from zero means the first request waits for a cold start, so use it
only for async work or with a warm floor for user-facing APIs. Keep the trigger query cheap, because KEDA polls it
every 30 seconds by default.

---

### H. Security and access control

```mermaid
flowchart LR
  WHO["Who: user or ServiceAccount"] --> AUTHZH["RBAC: may they do this?"]
  AUTHZH --> ADMH["Admission: is this object allowed?<br/>Pod Security, policies, webhooks"]
  ADMH --> RUNH["Runtime: securityContext<br/>non-root, no privilege"]
  RUNH --> NETH["Network: NetworkPolicy"]
```

**How to read it:** security in Kubernetes is layered. Identity and RBAC (role-based access control) decide who
can call the API. Admission decides what objects are acceptable. A **webhook** is an HTTPS service of yours that
the API server calls to check or change an object before saving it. The **securityContext** is the part of a pod
spec that limits what a running container can do, for example running as a normal user instead of root (the
all-powerful Linux admin user) and dropping extra privileges. NetworkPolicy (entry D5) limits who it can talk to.
Section 18 and Section 11 Lecture 76 go deeper.

#### H1. ServiceAccount

**What it is.** An identity for pods (as opposed to humans). Each pod runs as one ServiceAccount and gets a
short-lived, automatically rotated token for the API server. With **workload identity** (EKS Pod Identity or
IRSA, GKE Workload Identity, Azure Workload Identity), a ServiceAccount maps to a cloud IAM role (a set of cloud
permissions), so pods get cloud access without stored keys.

**In plain words.** An employee badge issued to a robot. It says who the robot is, and the security desk (RBAC and
cloud IAM) decides which doors that badge opens.

```mermaid
flowchart LR
  PODH["Pod: trainer"] -->|"runs as"| SA["ServiceAccount trainer"]
  SA -->|"RoleBinding"| ROLEH["Role: read ConfigMaps"]
  SA -->|"workload identity"| IAM["Cloud IAM role<br/>read s3://datasets only"]
  SA -->|"projected token<br/>expires, rotated"| APIH["kube-apiserver"]
```

**How to read it:** the pod runs as the `trainer` ServiceAccount. A RoleBinding (entry H2) gives that identity
Kubernetes permissions. Workload identity links it to a cloud IAM role that may only read the datasets bucket. A
**projected token** is a short-lived credential file that Kubernetes writes into the pod and replaces before it
expires, so a stolen token stops working quickly.

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: trainer
  namespace: ml
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::111122223333:role/ml-trainer-s3-read   # IRSA example
automountServiceAccountToken: false     # most app pods never call the Kubernetes API
```

**AI use.** Training pods read datasets and write checkpoints to object storage with a scoped IAM role. Agent pods
get an identity with only the tools they need.

**Pitfalls and senior practice.** Every namespace has a `default` ServiceAccount, so never grant it permissions.
Create one ServiceAccount per workload, and turn off token automount unless the app needs the Kubernetes API.

#### H2. RBAC: Role, ClusterRole, RoleBinding, ClusterRoleBinding

**What it is.** Role-based access control. A **Role** (namespaced) or **ClusterRole** (cluster-wide) lists allowed
verbs (`get`, `list`, `create`, `delete`, and so on) on resources. A **RoleBinding** grants a Role or ClusterRole to
users, groups, or ServiceAccounts in one namespace. A **ClusterRoleBinding** grants it across the whole cluster.
Permissions only add up: there are no deny rules.

**In plain words.** A Role is a job description ("may read reports"). A binding is the HR record saying "Priya has
this job, on this floor."

```mermaid
flowchart LR
  ROLEX["Role ml-dev in ml<br/>get, list, create Jobs<br/>get logs"] --> RBX["RoleBinding<br/>namespace ml"]
  GRP["Group ml-engineers"] --> RBX
  CR["ClusterRole view"] --> RB2["RoleBinding in team-ads"]
  SAX["ServiceAccount ci"] --> RB2
```

**How to read it:** on the left, the `ml-dev` Role is granted to the `ml-engineers` group, only inside namespace
`ml`. On the right, the built-in `view` ClusterRole (read-only access to most objects) is granted to the `ci`
ServiceAccount, but only in `team-ads`, because a RoleBinding limits even a ClusterRole to one namespace.

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata: { name: ml-dev, namespace: ml }
rules:
  - apiGroups: ["batch"]
    resources: ["jobs"]
    verbs: ["get", "list", "watch", "create", "delete"]
  - apiGroups: [""]
    resources: ["pods", "pods/log"]
    verbs: ["get", "list", "watch"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata: { name: ml-dev-binding, namespace: ml }
subjects: [{ kind: Group, name: ml-engineers, apiGroup: rbac.authorization.k8s.io }]
roleRef: { kind: Role, name: ml-dev, apiGroup: rbac.authorization.k8s.io }
```

```bash
kubectl auth can-i create jobs -n ml --as=priya@example.com
kubectl auth can-i --list -n ml --as=system:serviceaccount:ml:trainer
```

**AI use.** Researchers can submit training Jobs in their team namespace but can't read other teams' Secrets.
Operators (KubeRay, KServe) get exactly the ClusterRoles they need.

**Pitfalls and senior practice.**
- `create pods` in a namespace effectively grants access to every Secret and ServiceAccount there, because the pod
  can mount them. Treat it as a powerful permission.
- Avoid wildcards (`*`) and `cluster-admin` bindings. Review the `escalate`, `bind`, and `impersonate` verbs,
  which let someone grant themselves more power.
- Bind to groups from your identity provider (single sign-on through OIDC), not to individual users.

#### H3. Pod Security Admission and securityContext

**What it is.** **Pod Security Admission** is a built-in admission controller that enforces one of three Pod
Security Standards per namespace, set by a label: `privileged` (anything goes), `baseline` (blocks known
escalations like hostPath and privileged containers), and `restricted` (also requires non-root, dropped Linux
capabilities, and a seccomp profile). The **securityContext** in each pod is where you meet those rules.

**In plain words.** Building codes per floor. The lab floor allows special equipment, but office floors must follow
the strict fire code, and inspectors refuse anything that doesn't comply.

```mermaid
flowchart LR
  NSL["Namespace label<br/>enforce: restricted"] --> PSA["Pod Security Admission"]
  PODX2["Pod runs as root,<br/>privileged: true"] --> PSA
  PSA -->|"violates restricted"| DENY["Rejected with reason"]
  GOOD["Pod non-root, drop ALL,<br/>seccomp RuntimeDefault"] --> PSA
  PSA --> ALLOW["Admitted"]
```

**How to read it:** the namespace label sets the level. A **privileged** container has almost full control of the
node, so it's rejected. The accepted pod runs as a non-root user, drops **ALL Linux capabilities** (special kernel
powers such as changing network settings), and uses the **seccomp RuntimeDefault** profile, a filter that blocks
dangerous system calls the app never needs.

```yaml
# pod spec that passes the "restricted" level
securityContext:
  runAsNonRoot: true
  runAsUser: 10001
  fsGroup: 10001
  seccompProfile: { type: RuntimeDefault }
containers:
  - name: server
    securityContext:
      allowPrivilegeEscalation: false
      readOnlyRootFilesystem: true
      capabilities: { drop: ["ALL"] }
```

**AI use.** Model servers and agent sandboxes run as `restricted`. System namespaces for GPU drivers and CNI need
`privileged`, so keep those namespaces locked down to platform admins.

**Pitfalls and senior practice.** Many AI images run as root by default and write into their own filesystem
(caches in `/root/.cache`). Fix the image (Section 4) and mount writable `emptyDir` paths, rather than lowering the
namespace level. Roll out with `warn` and `audit` labels first, then `enforce`.

#### H4. Admission policies and webhooks

**What it is.** Custom rules that run when objects are created or updated:
- **ValidatingAdmissionPolicy** (built in, GA since 1.30) uses CEL (Common Expression Language, a small,
  safe expression language) to accept or reject objects without running any webhook server.
- **Mutating** and **validating admission webhooks** call your HTTPS service to change or check objects.
- Policy engines such as Kyverno and OPA Gatekeeper package these patterns with ready-made rule libraries.

**In plain words.** Custom inspectors added to the reception desk: "every package must have a return address"
(validate), or "stamp every package with the department code" (mutate).

```mermaid
flowchart LR
  OBJ["New Deployment"] --> MW["Mutating webhooks<br/>add labels, inject sidecar"]
  MW --> VAP["ValidatingAdmissionPolicy<br/>CEL rules"]
  VAP --> VW["Validating webhooks<br/>Kyverno, Gatekeeper"]
  VW -->|"all pass"| STORE[("Stored in etcd")]
  VAP -->|"fail"| REJH["Rejected with message"]
```

**How to read it:** changes happen first (a mutating webhook may add labels or **inject a sidecar**, meaning it
adds an extra helper container such as a proxy to the pod). Then the checks run: built-in CEL policies, then any
validating webhooks such as Kyverno or Gatekeeper. Only an object that passes everything is stored.

```yaml
apiVersion: admissionregistration.k8s.io/v1
kind: ValidatingAdmissionPolicy
metadata: { name: gpu-pods-need-team-label }
spec:
  failurePolicy: Fail
  matchConstraints:
    resourceRules:
      - { apiGroups: [""], apiVersions: ["v1"], operations: ["CREATE"], resources: ["pods"] }
  validations:
    - expression: >-
        !object.spec.containers.exists(c, has(c.resources.limits) && 'nvidia.com/gpu' in c.resources.limits)
        || (has(object.metadata.labels) && 'team' in object.metadata.labels)
      message: "Pods that request GPUs must carry a 'team' label for cost attribution."
---
apiVersion: admissionregistration.k8s.io/v1
kind: ValidatingAdmissionPolicyBinding
metadata: { name: gpu-pods-need-team-label }
spec:
  policyName: gpu-pods-need-team-label
  validationActions: [Deny]
```

**AI use.** Require cost labels on GPU pods, allow images only from the approved registry, require resource
limits, and block `:latest` tags on model servers.

**Pitfalls and senior practice.** A webhook with `failurePolicy: Fail` that goes down blocks every matching create,
which can include the pods needed to fix it. Prefer CEL policies for simple rules, exclude `kube-system`, keep
webhooks highly available, and set short timeouts.

---

### I. Extensibility

#### I1. CustomResourceDefinitions (CRDs) and operators

**What it is.** A **CRD** adds a new resource type to the API (for example `RayCluster` or `InferenceService`),
with its own schema, so you can `kubectl apply` it like any built-in object. An **operator** is a custom
controller that watches those resources and reconciles the real world toward them, the same loop as Lecture 29,
encoding a human operator's expertise in code. Section 11 Lecture 73 goes deeper.

**In plain words.** Kubernetes ships with forms for common requests. A CRD adds a new form ("Ray cluster
request"). The operator is the specialist who knows how to fulfil it.

```mermaid
flowchart LR
  CRDX["CRD rayclusters.ray.io<br/>new API type"] --> APII["kube-apiserver"]
  USERX["kubectl apply RayCluster"] --> APII
  OPX["KubeRay operator<br/>watch and reconcile"] --> APII
  OPX --> HEAD["Head pod + Service"]
  OPX --> WORKERS["Worker pods<br/>autoscaled"]
  OPX -->|"status: ready"| APII
```

**How to read it:** installing the CRD teaches the API server a new type. When you apply a `RayCluster`, the
**KubeRay operator** (the controller for Ray, a Python framework for distributed computing) sees it and creates the
real pieces: a **head pod** that coordinates the cluster, a Service to reach it, and **worker pods** that do the
compute and are added or removed with load. It then writes the cluster's status back.

```yaml
apiVersion: ray.io/v1
kind: RayCluster
metadata: { name: batch-infer, namespace: ml }
spec:
  headGroupSpec:
    rayStartParams: { dashboard-host: "0.0.0.0" }
    template:
      spec:
        containers: [{ name: ray-head, image: rayproject/ray:2.40.0-py311, resources: { limits: { cpu: "4", memory: 16Gi } } }]
  workerGroupSpecs:
    - groupName: gpu
      replicas: 2
      minReplicas: 0
      maxReplicas: 8
      rayStartParams: {}
      template:
        spec:
          containers: [{ name: ray-worker, image: rayproject/ray:2.40.0-py311-gpu, resources: { limits: { nvidia.com/gpu: 1, memory: 32Gi } } }]
```

**The AI operator landscape:**

| Operator or CRD | What it manages |
|---|---|
| NVIDIA GPU Operator (`ClusterPolicy`) | Drivers, device plugin, DCGM, MIG |
| KubeRay (`RayCluster`, `RayJob`, `RayService`) | Ray clusters for training, tuning, batch inference |
| Kubeflow Trainer (`TrainJob`, earlier `PyTorchJob`) | Multi-node distributed training |
| JobSet | Groups of Jobs for multi-role distributed workloads |
| Kueue (`ClusterQueue`, `LocalQueue`) | Job queueing, quotas, fair sharing, gang admission |
| KServe (`InferenceService`) | Model serving with autoscaling and canaries |
| Gateway API Inference Extension (`InferencePool`) | Model-aware LLM request routing |
| cert-manager, External Secrets | Certificates and secrets from external stores |

**Pitfalls and senior practice.**
- Every operator is privileged code running in your cluster. Pin versions, review its RBAC, and watch its resource
  use.
- CRD upgrades can change schemas (`v1alpha1` to `v1`). Test them in staging, and back up custom resources before
  upgrading.
- Don't write an operator when a Helm chart or Job does the job. Operators pay off for stateful,
  day-2 operations: failover, upgrades, scaling.

---

## FAANG deep-dive notes

**How big tech does it.** Kubernetes is run as a product by a platform team. Separate node pools per
GPU type are tainted, so only GPU workloads land on them. Each team gets a namespace with resource
quotas, and a queueing layer (Kueue, Volcano, or an internal scheduler) shares GPUs fairly. Inference
autoscales on request-level metrics (queue depth, tokens per second), not CPU. Policy engines (Gatekeeper,
Kyverno) enforce requests, limits, probes, and signed images at admission. Clusters are disposable and
rebuilt from Git (GitOps).

**Staff review questions.**
- What is GPU allocation compared with real GPU utilization, by team? Where is the waste?
- What scales inference pods, and how long does a new replica take to become ready?
- What happens to serving during a node upgrade or a zone outage?
- How does one team's runaway job get stopped from starving everyone else?

**Interview question.** "Design a shared Kubernetes platform for many ML teams on a fixed GPU budget."

**Typical system-design prompt:** *Design a multi-tenant Kubernetes platform for 15 ML teams sharing
200 GPUs across online inference, batch inference, and training jobs.*

**1. Clarify first:** What is the split between latency-critical serving and batch work? Which GPU
types are in use? Are there hard isolation needs (regulated data)? How long do jobs run? Who decides
priority when GPUs run out?

**2. Back-of-envelope sizing:**
- 200 GPUs ÷ 8 per node = 25 GPU nodes, plus a CPU pool for system and API pods.
- Reserve ~40% (80 GPUs) as guaranteed quota for serving. Share the rest through a queue with
  borrowing and preemption.
- Startup: image pull (~1–2 min) plus weight load (~1–3 min) means 2–5 minutes to add a replica, so
  autoscaling must start early or keep warm headroom.
- A 7B fp16 model is 14 GB, so a 24 GB GPU fits one replica. Smaller models can share an A100 or H100
  using MIG slices (Section 7).

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Tenancy | One shared cluster | A cluster per team | Shared, with namespaces and quotas. Separate clusters only for hard isolation or compliance |
| Inference autoscaling | HPA on CPU | Custom metrics (queue depth, in-flight requests) | Custom metrics: CPU says little about a GPU server |
| QoS | Burstable | Guaranteed (requests = limits) | Guaranteed for model servers, so they are evicted last |
| GPU sharing | Whole GPUs | MIG or time-slicing | Whole GPUs for big models. MIG for many small, steady ones |

**4. Follow-up questions with crisp answers:**
- *How do you keep CPU pods off GPU nodes?* Taint the GPU nodes. Only pods with a matching toleration
  that also request `nvidia.com/gpu` land there.
- *Why use a startupProbe?* Model loading can take minutes. Without it, the liveness probe kills the
  pod before it finishes loading.
- *How do you survive node upgrades?* Set PodDisruptionBudgets, spread replicas across zones, and drain
  nodes one at a time.

**Debug this (common onsite question):** "New inference pods are stuck in `Pending` with
`Insufficient nvidia.com/gpu`, but the new node pool has 16 free GPUs."
1. `kubectl describe node <new-node>`: the node's allocatable resources show no `nvidia.com/gpu` at
   all.
2. Check the NVIDIA device plugin (or GPU Operator) DaemonSet: it isn't running on the new pool,
   because its toleration doesn't match the pool's new taint.
3. Fix the DaemonSet toleration. The plugin starts, and the node advertises 8 GPUs.
4. Prevent it: a post-provisioning check that fails if a GPU node doesn't advertise GPUs within
   5 minutes.

The lesson: Kubernetes only knows about GPUs that a device plugin advertises. "Free GPUs" on the
machine aren't free to the scheduler.

**5. What separates senior from staff answers:** a senior engineer writes correct manifests with probes,
requests, and an HPA. A staff engineer designs the tenancy model: quotas and fair-share queues,
admission policies, autoscaling on the right signals, zone-failure behavior, and a chargeback report
that shows each team its allocated and used GPU hours.

**Red flags:**
- No requests or limits on GPU pods.
- Autoscaling GPU inference on CPU utilization.
- No PodDisruptionBudget, so node upgrades take serving down.
- GPU nodes without taints, filled with CPU pods.
- One team able to claim every GPU in the cluster.

---

## Quiz

<details><summary>1. What is the difference between a Pod, a Deployment, and a Service?</summary>
A Pod runs one or more containers together. A Deployment keeps a desired number of identical pods running
and handles rolling updates and rollbacks. A Service gives those pods one stable name and IP, and
load-balances across the ready ones.
</details>

<details><summary>2. What's the difference between readiness, liveness, and startup probes?</summary>
Readiness: should this pod receive traffic now? Liveness: is it stuck and should it be restarted? Startup:
give a slow-starting app (like one loading a big model) time before liveness checks begin.
</details>

<details><summary>3. An HPA has 4 replicas at 75% CPU with a 50% target. How many replicas will it want?</summary>
ceil(4 × 75 / 50) = ceil(6) = 6 replicas (capped by <code>maxReplicas</code>).
</details>

<details><summary>4. Are Kubernetes Secrets encrypted?</summary>
Not by default. They're base64-encoded, which anyone can decode. Enable encryption at rest in etcd, restrict
access with RBAC, and ideally sync them from an external secrets manager.
</details>

<details><summary>5. Why is CPU often a poor autoscaling signal for GPU inference?</summary>
The bottleneck is the GPU, so CPU can stay low while requests queue up. Scale on requests in flight, queue
depth, or latency, exported as custom metrics.
</details>

<details><summary>6. A pod is <code>Pending</code>. What do you check?</summary>
<code>kubectl describe pod</code> and read Events. Usually no node has enough of the requested CPU, memory, or
GPU, or a node selector / taint prevents scheduling. Lower the requests, fix the scheduling constraints, or
add nodes.
</details>

<details><summary>7. Why shouldn't a Helm chart set <code>replicas</code> when an HPA is enabled?</summary>
Every <code>helm upgrade</code> would reset the replica count to the fixed value, fighting the HPA and
possibly scaling down during peak traffic.
</details>

<details><summary>8. Your GPU metrics dashboard shows no data for the newest GPU nodes. The dcgm-exporter DaemonSet exists. What's the most likely cause?</summary>
The GPU nodes are tainted (for example <code>nvidia.com/gpu:NoSchedule</code>) and the DaemonSet has no matching
toleration, so its pods are never scheduled there. Add the toleration (reference entries C5 and F5).
</details>

<details><summary>9. Which workload controller fits each job: a vector database with 3 replicas, a nightly evaluation, a log agent on every node, and sharded batch embedding of 10 million documents?</summary>
StatefulSet (stable names and one disk per replica), CronJob, DaemonSet, and an Indexed Job with
<code>parallelism</code> and <code>ttlSecondsAfterFinished</code>. Each shard must be idempotent because retries re-run it.
</details>

<details><summary>10. A gRPC embedding service behind a ClusterIP Service shows one pod at 100% and the others idle. Why, and how do you fix it?</summary>
kube-proxy balances connections, not requests, and a gRPC client keeps one long-lived HTTP/2 connection, so all
its requests go to one pod. Use an L7 proxy, mesh, or Gateway (GRPCRoute), or a Headless Service with
client-side round-robin (reference entries B3 and D1).
</details>

<details><summary>11. A PVC for a training pod's disk stays Pending, and when it binds, the pod can't start because the disk is in another zone. What setting prevents this?</summary>
<code>volumeBindingMode: WaitForFirstConsumer</code> on the StorageClass, so the disk is created in the zone where
the scheduler places the pod (reference entry E6).
</details>

<details><summary>12. PyTorch DataLoader workers crash with "bus error" inside a pod but work on a laptop. What's the fix?</summary>
Containers get only 64 MB of <code>/dev/shm</code> by default. Mount an <code>emptyDir</code> with
<code>medium: Memory</code> and a size limit at <code>/dev/shm</code>, and remember it counts against the memory
limit (reference entry E3).
</details>

## Failure modes
- No readiness probe, so traffic reaches pods that are still loading the model.
- A liveness probe that's too aggressive for model load time, causing endless restarts (`CrashLoopBackOff`).
- No resource requests, so the scheduler overpacks nodes and pods get OOMKilled or throttled.
- Secrets committed to git as plain YAML.
- Autoscaling on the wrong metric, or `minReplicas: 1`, so a single pod failure is an outage.
- A DaemonSet (device plugin, GPU exporter, log agent) without the GPU taint toleration, silently missing GPU
  nodes.
- A default-deny NetworkPolicy without a DNS egress rule, breaking every name lookup. Or NetworkPolicies on a CNI
  that doesn't enforce them, so the isolation is imaginary.
- A PodDisruptionBudget with `maxUnavailable: 0`, which blocks every node drain and stalls cluster upgrades.
- An admission webhook with `failurePolicy: Fail` that goes down and blocks all pod creation.
- Finished Jobs never cleaned up (`ttlSecondsAfterFinished` missing), bloating etcd.
- Zonal disks with `Immediate` binding, created in a zone with no GPU nodes.
- Node autoscaler consolidation evicting long training runs that don't checkpoint.

## Checklist
- [ ] You can explain the control plane, nodes, pods, and the reconciliation loop
- [ ] Your model Deployment has requests, limits, and startup/readiness/liveness probes
- [ ] Config comes from a ConfigMap and credentials from a Secret, not from the image
- [ ] The HPA scales your model between 2 and N replicas under load
- [ ] The same Helm chart deploys to two environments with different values files
- [ ] You deleted pods on Minikube and watched them come back
- [ ] You can name every control-plane and node component and say what breaks when it fails
- [ ] You can choose the right workload controller (Deployment, StatefulSet, DaemonSet, Job, CronJob) for an AI job
- [ ] You can explain all five Service kinds, Ingress vs Gateway API, and write a default-deny NetworkPolicy
- [ ] You can set up namespace tenancy: ResourceQuota, LimitRange, PriorityClass, RBAC, and Pod Security
- [ ] You know which autoscaler (HPA, VPA, KEDA, Cluster Autoscaler or Karpenter) solves which problem
