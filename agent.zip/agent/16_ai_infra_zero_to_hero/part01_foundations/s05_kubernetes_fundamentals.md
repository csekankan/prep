# Section 5 — Kubernetes Fundamentals

> Lectures 29–35 • Assessment: quiz
> **After this section you can:** explain what Kubernetes does for AI workloads, describe pods, nodes and
> clusters, deploy a model with a Deployment and a Service, configure it with ConfigMaps, Secrets and
> volumes, autoscale inference with the Horizontal Pod Autoscaler, package it all as a Helm chart, and
> run it on Minikube.
>
> Go deeper: [`11_kubernetes/`](../../11_kubernetes/00_K8S_DEPLOYMENT.md) (canary, GitOps, CI) and
> [13 / Lab 4 — Bootstrapping K3s](../../13_sovereign_ai_infra_course/01_foundations_local_sandbox/lab04_bootstrapping_k3s.md).
> GPU scheduling comes in Section 11.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 29 | What is Kubernetes and why AI needs it | You declare what you want ("3 copies of my model"); Kubernetes keeps it true |
| 30 | Pods, nodes, and clusters | A pod is the smallest unit; nodes are machines; the control plane is the brain |
| 31 | Deployments and Services | Deployments keep N pods running and roll out updates; Services give them one stable address |
| 32 | ConfigMaps, Secrets, and volumes | Keep config, credentials, and data outside the image |
| 33 | Horizontal Pod Autoscaling for inference | Add replicas when load rises, remove them when it falls |
| 34 | Helm charts | One templated package per app, with different values per environment |
| 35 | Lab: deploy a model on Minikube | The Section 4 classifier, running with probes, a Service, and autoscaling |

```mermaid
flowchart TB
  DEV[You: kubectl apply -f model.yaml] --> API
  subgraph CP["Control plane (the brain)"]
    API[API server] --> ETCD[(etcd:<br/>desired state)]
    API --> SCHED[Scheduler:<br/>which node?]
    API --> CM[Controllers:<br/>keep desired = actual]
  end
  subgraph N1["Worker node 1"]
    K1[kubelet] --> P1[pod: model-api]
    K1 --> P2[pod: model-api]
  end
  subgraph N2["Worker node 2 (GPU)"]
    K2[kubelet] --> P3[pod: model-api]
  end
  SCHED -.assigns pods.-> K1 & K2
  SVC[Service: model-api<br/>one stable IP / DNS name] --> P1 & P2 & P3
  USERS2((Users)) --> ING[Ingress / LoadBalancer] --> SVC
```

**How to read it:** you hand the API server a description of what you want. It's stored in etcd. The
scheduler picks a node for each pod, and the kubelet on that node starts the containers. Controllers keep
checking that reality matches your description. Users never talk to pods directly: they go through a
Service, which spreads traffic across whichever pods are healthy right now.

---

## Lecture 29 — What is Kubernetes and why AI needs it

**Why it matters.** Docker runs containers on *one* machine. Production AI needs dozens of machines,
replicas that restart when they crash, rolling updates without downtime, autoscaling with traffic, and
fair sharing of expensive GPUs between teams. Kubernetes (K8s) is the standard way to do all of that.

**In plain words.** Kubernetes is an orchestra conductor. You give it the score: "three violins, one
cello, keep playing". If a violinist faints, the conductor brings in a substitute without stopping the
music. You never tell individual musicians what to do.

**Architecture: the reconciliation loop.**

```mermaid
flowchart LR
  WANT["Desired state<br/>replicas: 3"] --> CMP{"Compare"}
  HAVE["Actual state<br/>2 pods running<br/>(1 crashed)"] --> CMP
  CMP -->|"difference: 1 missing"| ACT["Act: create 1 pod"]
  ACT --> HAVE
  CMP -->|"no difference"| WAIT["Wait, check again"]
  WAIT --> CMP
```

**How to read it:** Kubernetes never runs a one-off script like "start 3 pods". It keeps comparing what
you asked for with what exists, and closes the gap. This loop is why it heals itself.

**Core ideas.**

| AI need | What Kubernetes provides |
|---|---|
| Keep the model API up | Restarts crashed containers; replaces pods on failed nodes |
| Ship new model versions safely | Rolling updates and instant rollback |
| Handle traffic spikes | Horizontal Pod Autoscaler; Cluster Autoscaler / Karpenter adds nodes |
| Share GPUs between teams | Resource requests and limits, quotas, namespaces (Sections 11 and 40) |
| Run training jobs | `Job`, `CronJob`, and operators like Kubeflow's PyTorchJob (Section 11) |
| Same platform on any cloud or on-prem | EKS, GKE, AKS, or self-hosted all speak the same API |

**Example.** At 2 a.m. a GPU node's hardware fails. Without Kubernetes, the on-call engineer is paged,
logs in, starts the model on another machine, and updates the load balancer: 40 minutes of downtime.
With Kubernetes, the node is marked `NotReady`, its pods are recreated on healthy nodes, and the Service
stops sending them traffic. Users see a few slow requests, and the engineer reads about it in the morning.

**Senior note.** Kubernetes is not free: it adds operational complexity. For one model on one VM, a
container with `systemd` or a managed endpoint may be the better choice. Kubernetes pays off when you
have many services, many machines, or many teams.

---

## Lecture 30 — Pods, nodes, and clusters explained

**In plain words.** A *cluster* is the whole company. *Nodes* are the office buildings (machines). A
*pod* is a desk where one small team sits: one or more containers that always sit together, share the same
phone extension (IP address), and share a filing cabinet (volumes). The *control plane* is head office,
deciding who sits where.

**Architecture: inside a node and a pod.**

```mermaid
flowchart TB
  subgraph NODE["Node (a VM or physical server with GPUs)"]
    KUBELET[kubelet: talks to the control plane]
    KPROXY[kube-proxy: routes Service traffic]
    RUNTIME[containerd]
    subgraph POD["Pod: model-api-7d9f (IP 10.244.1.17)"]
      C1[container: model server :8000]
      C2["sidecar container: log shipper<br/>(optional)"]
      V[(shared volume:<br/>/models)]
      C1 --- V
      C2 --- V
    end
    KUBELET --> RUNTIME --> POD
  end
```

**How to read it:** the kubelet receives instructions and asks containerd to start the pod's containers.
Containers in a pod share one IP address and can share volumes, so a sidecar can read the main app's logs
or files. Pods are disposable: if one dies, a *new* pod with a new name and IP replaces it.

**Core objects and commands.**

| Object | What it is |
|---|---|
| Cluster | Control plane + worker nodes |
| Node | One machine. `kubectl get nodes` |
| Namespace | A folder for objects, used to separate teams or environments |
| Pod | One or more containers scheduled together on one node |

```bash
kubectl get nodes -o wide                    # machines, their status and IPs
kubectl get pods -n ml -o wide               # pods in namespace "ml", and which node they're on
kubectl describe pod <name> -n ml            # events: why is it Pending / CrashLoopBackOff?
kubectl logs <pod> -n ml -f                  # container output
kubectl exec -it <pod> -n ml -- bash         # shell inside the container
kubectl top pods -n ml                       # CPU and memory (needs metrics-server)
```

**Pod status cheat sheet.**

| Status | Usually means | First command |
|---|---|---|
| `Pending` | No node has enough free CPU, memory, or GPU | `kubectl describe pod` → Events |
| `ImagePullBackOff` | Wrong image name or tag, or no registry credentials | `kubectl describe pod` |
| `CrashLoopBackOff` | The container starts and exits repeatedly | `kubectl logs <pod> --previous` |
| `OOMKilled` | Exceeded its memory limit (often during model loading) | `kubectl describe pod` → Last State |
| `Running` but `0/1 READY` | The readiness probe is failing (model still loading?) | `kubectl describe pod` → probe events |

**Example.** A model pod sits in `Pending` forever. `kubectl describe pod` shows
`0/3 nodes are available: 3 Insufficient memory`. The pod requested 64 Gi of memory, and each node has
32 Gi. The fix is to lower the request to what the model actually needs (measured with `kubectl top`), or
add a bigger node pool.

---

## Lecture 31 — Deployments and Services for AI apps

**Why it matters.** You almost never create pods directly. A **Deployment** keeps the right number of
identical pods running and replaces them gradually when you ship a new version. A **Service** gives those
ever-changing pods one stable address.

**In plain words.** A Deployment is a staffing agency's contract: "always keep 3 trained cashiers at the
store". If one quits, the agency sends another. A Service is the store's phone number: customers always
call the same number, and it rings whichever cashier is free.

**Architecture: a rolling update from v1 to v2.**

```mermaid
flowchart LR
  subgraph DEP["Deployment: model-api (replicas: 3)"]
    RS1["ReplicaSet v1<br/>image: classifier:1.0"]
    RS2["ReplicaSet v2<br/>image: classifier:1.1"]
  end
  RS1 --> A1[pod v1] & A2[pod v1]
  RS2 --> B1[pod v2 ✔ ready] & B2[pod v2 ⏳ starting]
  SVC2["Service: model-api<br/>selector: app=model-api"] -->|only ready pods| A1 & A2 & B1
```

**How to read it:** during an update the Deployment creates a new ReplicaSet for v2 and scales it up
while scaling v1 down. The Service selects pods by label, and sends traffic only to pods whose readiness
probe passes, so a v2 pod that's still loading its model gets no requests.

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: model-api
  namespace: ml
spec:
  replicas: 3
  selector:
    matchLabels: { app: model-api }
  strategy:
    rollingUpdate: { maxUnavailable: 0, maxSurge: 1 }    # never drop below 3 ready pods
  template:
    metadata:
      labels: { app: model-api }
    spec:
      containers:
        - name: api
          image: registry.example.com/classifier:1.0
          ports: [{ containerPort: 8000 }]
          resources:
            requests: { cpu: "1", memory: 2Gi }
            limits:   { memory: 3Gi }
          readinessProbe:                   # "may I receive traffic?"
            httpGet: { path: /healthz, port: 8000 }
            periodSeconds: 5
          livenessProbe:                    # "am I stuck and should be restarted?"
            httpGet: { path: /healthz, port: 8000 }
            periodSeconds: 10
            failureThreshold: 3
          startupProbe:                     # "give me up to 5 minutes to load the model"
            httpGet: { path: /healthz, port: 8000 }
            periodSeconds: 10
            failureThreshold: 30
---
apiVersion: v1
kind: Service
metadata:
  name: model-api
  namespace: ml
spec:
  selector: { app: model-api }
  ports: [{ port: 80, targetPort: 8000 }]
  type: ClusterIP            # internal only; expose with an Ingress or type: LoadBalancer
```

```bash
kubectl apply -f model-api.yaml
kubectl rollout status deploy/model-api -n ml
kubectl set image deploy/model-api api=registry.example.com/classifier:1.1 -n ml   # ship v1.1
kubectl rollout undo deploy/model-api -n ml                                          # roll back
```

| Service type | Reachable from | Use for |
|---|---|---|
| `ClusterIP` | Inside the cluster (`model-api.ml.svc.cluster.local`) | Internal model APIs |
| `NodePort` | Each node's IP on a high port | Local testing |
| `LoadBalancer` | A cloud load balancer with a public or private IP | Simple external exposure |
| Ingress / Gateway API | One entry point routing by host and path | Many APIs behind one domain, TLS |

**Example.** A team had no readiness probe. During every rollout, new pods got traffic while their 6 GB
model was still loading, and about 2% of requests failed for a minute. Adding a readiness probe on
`/healthz` (which returns "ok" only once the model is loaded) made rollouts invisible to users.

**Senior note.** Set `startupProbe` generously for big models. A liveness probe that fires during a
3-minute model load restarts the pod forever, which shows up as `CrashLoopBackOff` even though nothing is
actually broken.

---

## Lecture 32 — ConfigMaps, Secrets, and volumes

**Why it matters.** The same image should run in dev, staging, and production. What changes between them
(config, credentials, data) must live *outside* the image.

**In plain words.** The image is a new phone fresh from the factory. A ConfigMap is your settings, a Secret
is your passwords (kept in a safer place), and a volume is your photo storage, which survives even if
you replace the phone.

**Architecture: what gets injected into a pod.**

```mermaid
flowchart LR
  CMAP["ConfigMap: model-config<br/>MODEL_NAME, BATCH_SIZE,<br/>LOG_LEVEL"] -->|env vars| POD2
  SEC["Secret: model-secrets<br/>HF_TOKEN, DB_PASSWORD"] -->|"env var or file<br/>/var/run/secrets/..."| POD2
  PVC["PersistentVolumeClaim:<br/>model-weights (50 Gi)"] -->|"mounted at /models"| POD2
  PV[(PersistentVolume:<br/>EBS / PD / NFS)] --- PVC
  SC["StorageClass:<br/>gp3, standard-rwo"] -.creates.-> PV
  POD2[pod: model-api]
```

**How to read it:** config and secrets arrive as environment variables or files. Storage is *claimed*
with a PersistentVolumeClaim (PVC): the pod asks for "50 Gi", and the StorageClass creates a real disk
(a PersistentVolume) in the cloud to satisfy it.

```yaml
apiVersion: v1
kind: ConfigMap
metadata: { name: model-config, namespace: ml }
data:
  MODEL_NAME: resnet18
  BATCH_SIZE: "8"
  LOG_LEVEL: info
---
apiVersion: v1
kind: Secret
metadata: { name: model-secrets, namespace: ml }
type: Opaque
stringData:
  HF_TOKEN: replace-me            # in real clusters, create this from a secrets manager, not a file in git
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata: { name: model-weights, namespace: ml }
spec:
  accessModes: [ReadWriteOnce]    # ReadOnlyMany / ReadWriteMany need a storage class that supports them
  resources: { requests: { storage: 50Gi } }
```

Used inside the Deployment's pod template:

```yaml
      containers:
        - name: api
          envFrom:
            - configMapRef: { name: model-config }
          env:
            - name: HF_TOKEN
              valueFrom: { secretKeyRef: { name: model-secrets, key: HF_TOKEN } }
          volumeMounts:
            - { name: weights, mountPath: /models, readOnly: true }
      volumes:
        - name: weights
          persistentVolumeClaim: { claimName: model-weights }
```

| Thing | Use | Watch out |
|---|---|---|
| ConfigMap | Non-sensitive settings | Pods don't restart automatically when it changes (Helm can add a checksum annotation to trigger it) |
| Secret | Tokens, passwords, keys | Only **base64-encoded**, not encrypted, unless you enable encryption at rest; restrict with RBAC; prefer External Secrets / CSI driver with a cloud secrets manager |
| `emptyDir` | Scratch space for the pod's lifetime | Deleted with the pod |
| PVC | Data that must outlive pods | `ReadWriteOnce` disks attach to one node at a time |

**Example.** A team stored their Hugging Face token in a ConfigMap. Every developer with read access to
the namespace could see it in plain text with `kubectl get cm -o yaml`. Moving it to a Secret with RBAC
restricted to the service account (and later to External Secrets backed by AWS Secrets Manager) closed
the gap. Section 18 covers secrets management in depth.

---

## Lecture 33 — Horizontal Pod Autoscaling for AI inference

**Why it matters.** Inference traffic is uneven: quiet at night, spiky during sales or launches. Running
enough replicas for the peak all the time wastes money; running for the average drops requests at peak.

**In plain words.** A supermarket opens more checkout lanes when the queues get long and closes them when
it's quiet. The HPA is the manager watching the queues.

**Architecture: the HPA control loop.**

```mermaid
flowchart LR
  PODS3[model-api pods] -->|CPU / memory| MS[metrics-server]
  PODS3 -->|"/metrics: requests in flight,<br/>queue depth, GPU util"| PROM[Prometheus]
  PROM --> ADP[Prometheus Adapter /<br/>KEDA]
  MS --> HPA
  ADP --> HPA["HPA (every 15 s):<br/>desired = ceil(current × metric ÷ target)"]
  HPA -->|"scale replicas<br/>(min 2, max 10)"| DEP3[Deployment]
  DEP3 --> PODS3
  DEP3 -.pods Pending: no room.-> CA["Cluster Autoscaler /<br/>Karpenter adds a node"]
```

**How to read it:** the HPA reads metrics, computes how many replicas would bring the metric back to its
target, and updates the Deployment. If new pods can't fit on existing nodes, a node autoscaler adds
machines. For GPU inference, CPU is often the wrong signal, so custom metrics come from Prometheus.

**The formula.** `desired = ceil(current_replicas × current_metric / target_metric)`.
With 3 replicas at 90% CPU and a 60% target: `ceil(3 × 90 / 60) = ceil(4.5) = 5` replicas.

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata: { name: model-api, namespace: ml }
spec:
  scaleTargetRef: { apiVersion: apps/v1, kind: Deployment, name: model-api }
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target: { type: Utilization, averageUtilization: 60 }   # % of the CPU *request*
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 0          # react to spikes immediately
    scaleDown:
      stabilizationWindowSeconds: 300        # wait 5 min of low load before removing pods
      policies: [{ type: Pods, value: 1, periodSeconds: 60 }]
```

| Signal | Good for | Problem |
|---|---|---|
| CPU utilization | CPU-served models | Says little about GPU-bound inference |
| Requests in flight / per second per pod | Most model APIs | Needs custom metrics (Prometheus Adapter or KEDA) |
| Queue depth / pending requests | Batched or async inference, LLM servers | Needs the server to expose it |
| GPU utilization (DCGM) | GPU-bound models | Can stay near 100% with batching even when latency is fine |

**Example.** An LLM API scaled on CPU and never scaled up: the CPU sat at 20% while the GPU was saturated
and p95 latency climbed to 9 seconds. Switching the HPA to "requests waiting in the server queue, target 4
per pod" (exported by vLLM) scaled it from 2 to 6 replicas during peak, and p95 returned under 2 seconds.
[13 / Lab 29](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab29_hpa_custom_metrics.md)
builds this end to end.

**Senior note.** GPU pods take minutes to become ready (node provisioning, image pull, model load). Keep
`minReplicas` high enough to absorb the first part of a spike, scale up early, and scale down slowly.

---

## Lecture 34 — Helm charts for simplified AI deployments

**Why it matters.** A real model service is 6–10 YAML files (Deployment, Service, ConfigMap, HPA, Ingress,
ServiceAccount…), repeated for dev, staging, and production with small differences. Copy-pasting them
leads to drift and mistakes.

**In plain words.** Helm is a form letter. The chart is the template ("Dear `{{ name }}`, your model
`{{ image }}` will run with `{{ replicas }}` replicas"), and each environment fills in its own values file.

**Architecture: how Helm renders a release.**

```mermaid
flowchart LR
  subgraph CHART["Chart: model-api/"]
    T["templates/<br/>deployment.yaml, service.yaml,<br/>hpa.yaml, configmap.yaml"]
    DV["values.yaml (defaults)"]
  end
  EV["values-prod.yaml<br/>replicas: 4, image tag: 1.1,<br/>gpu: true"] --> R
  T --> R["helm upgrade --install<br/>(render templates + values)"]
  DV --> R
  R --> K8S["Kubernetes objects<br/>= release 'model-api-prod', revision 7"]
  K8S -.helm rollback model-api-prod 6.-> PREV[previous revision]
```

**How to read it:** templates plus default values plus environment-specific values produce plain
Kubernetes YAML. Helm records each install or upgrade as a numbered *revision*, so a rollback restores
the whole set of objects, not just the image.

```text
model-api/
├── Chart.yaml           # name, version
├── values.yaml          # defaults
└── templates/
    ├── deployment.yaml
    ├── service.yaml
    └── hpa.yaml
```

```yaml
# values.yaml
image:
  repository: registry.example.com/classifier
  tag: "1.0"
replicas: 2
resources:
  requests: { cpu: "1", memory: 2Gi }
autoscaling: { enabled: true, minReplicas: 2, maxReplicas: 10, targetCPU: 60 }
```

```yaml
# templates/deployment.yaml (excerpt)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Release.Name }}
spec:
  {{- if not .Values.autoscaling.enabled }}
  replicas: {{ .Values.replicas }}          # when the HPA is on, it owns the replica count
  {{- end }}
  selector:
    matchLabels: { app: {{ .Release.Name }} }
  template:
    metadata:
      labels: { app: {{ .Release.Name }} }
    spec:
      containers:
        - name: api
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
          resources: {{- toYaml .Values.resources | nindent 12 }}
```

```bash
helm create model-api                                     # scaffold a chart
helm template model-api ./model-api -f values-prod.yaml   # preview the rendered YAML
helm upgrade --install model-api-prod ./model-api -n ml -f values-prod.yaml --set image.tag=1.1
helm history model-api-prod -n ml
helm rollback model-api-prod 6 -n ml
```

**Example.** Staging and production YAML had drifted apart over a year: production had no memory limit,
which nobody noticed until a memory leak took down a node. With one chart and two small values files,
the only differences between environments are the ones written in `values-prod.yaml`, and they're
reviewed in pull requests.

**Senior note.** Don't set `replicas` in the Deployment when an HPA manages it, or every `helm upgrade`
resets the replica count and fights the autoscaler. The template above handles this.

---

## Lecture 35 — Lab: deploy a model on Minikube

**Goal:** run the Section 4 classifier on a local Kubernetes cluster with a Deployment, Service, probes,
ConfigMap, and HPA, then watch it self-heal and autoscale.

**What you're building.**

```mermaid
flowchart TB
  YOU2[Your laptop: curl] -->|minikube service / port-forward| SVC4
  subgraph MK["Minikube cluster (1 node)"]
    subgraph NS2["namespace: ml"]
      SVC4[Service: classifier :80] --> PA[pod] & PB[pod]
      DEP4["Deployment: classifier<br/>image classifier:1.0"] --> PA & PB
      HPA4["HPA: 2–5 replicas<br/>CPU target 60%"] --> DEP4
      CM4[ConfigMap: classifier-config] -.-> PA & PB
    end
    MS4[metrics-server addon] --> HPA4
  end
```

**How to read it:** the same image from Section 4 runs as two pods behind one Service. The HPA watches CPU
through metrics-server and adds pods under load.

**Step 1 — start the cluster and load the image.**

```bash
minikube start --cpus=4 --memory=8g
minikube addons enable metrics-server
minikube image load classifier:1.0          # copies your local image into the cluster (no registry needed)
kubectl create namespace ml
```

**Step 2 — apply the manifests.** Save as `classifier.yaml`:

```yaml
apiVersion: v1
kind: ConfigMap
metadata: { name: classifier-config, namespace: ml }
data: { LOG_LEVEL: info }
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: classifier, namespace: ml }
spec:
  selector: { matchLabels: { app: classifier } }
  template:
    metadata: { labels: { app: classifier } }
    spec:
      containers:
        - name: api
          image: classifier:1.0
          imagePullPolicy: Never              # use the image loaded into minikube
          ports: [{ containerPort: 8000 }]
          envFrom: [{ configMapRef: { name: classifier-config } }]
          resources:
            requests: { cpu: 500m, memory: 1Gi }
            limits: { memory: 2Gi }
          startupProbe:  { httpGet: { path: /healthz, port: 8000 }, periodSeconds: 5, failureThreshold: 60 }
          readinessProbe: { httpGet: { path: /healthz, port: 8000 }, periodSeconds: 5 }
          livenessProbe:  { httpGet: { path: /healthz, port: 8000 }, periodSeconds: 10 }
---
apiVersion: v1
kind: Service
metadata: { name: classifier, namespace: ml }
spec:
  selector: { app: classifier }
  ports: [{ port: 80, targetPort: 8000 }]
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata: { name: classifier, namespace: ml }
spec:
  scaleTargetRef: { apiVersion: apps/v1, kind: Deployment, name: classifier }
  minReplicas: 2
  maxReplicas: 5
  metrics:
    - type: Resource
      resource: { name: cpu, target: { type: Utilization, averageUtilization: 60 } }
```

```bash
kubectl apply -f classifier.yaml
kubectl get pods -n ml -w                   # wait for 2/2 pods READY 1/1
```

The model downloads its weights on first start. In the cluster, there's no `torch-cache` volume, so each
new pod downloads again. Adding a PVC for `/cache` is a good extension exercise.

**Step 3 — call it.**

```bash
kubectl port-forward -n ml svc/classifier 8080:80 &
curl -s -F "file=@dog.jpg" localhost:8080/predict
```

**Step 4 — watch it self-heal.**

```bash
kubectl delete pod -n ml -l app=classifier --wait=false   # delete all pods at once
kubectl get pods -n ml -w                                 # new pods appear immediately
```

**Step 5 — watch it autoscale.**

```bash
kubectl get hpa -n ml -w &
for i in $(seq 4); do
  ( while true; do curl -s -o /dev/null -F "file=@dog.jpg" localhost:8080/predict; done ) &
done
# After 1–2 minutes REPLICAS rises above 2. Stop the load (and the port-forward) with: kill $(jobs -p)
# About 5 minutes later it scales back down to 2 (the scale-down stabilization window).
```

**Step 6 — clean up.** `minikube delete`.

**Expected results:** pods recreated within seconds of deletion; the HPA scales from 2 towards 5 under
load and back to 2 afterwards; no failed requests during a `kubectl rollout restart deploy/classifier -n ml`.

---

## Quiz

<details><summary>1. What is the difference between a Pod, a Deployment, and a Service?</summary>
A Pod runs one or more containers together. A Deployment keeps a desired number of identical pods running
and handles rolling updates and rollbacks. A Service gives those pods one stable name and IP, and
load-balances across the ready ones.
</details>

<details><summary>2. What's the difference between readiness, liveness, and startup probes?</summary>
Readiness: should this pod receive traffic now? Liveness: is it stuck and should it be restarted? Startup:
give a slow-starting app (like one loading a big model) time before liveness checks begin.
</details>

<details><summary>3. An HPA has 4 replicas at 75% CPU with a 50% target. How many replicas will it want?</summary>
ceil(4 × 75 / 50) = ceil(6) = 6 replicas (capped by <code>maxReplicas</code>).
</details>

<details><summary>4. Are Kubernetes Secrets encrypted?</summary>
Not by default. They're base64-encoded, which anyone can decode. Enable encryption at rest in etcd, restrict
access with RBAC, and ideally sync them from an external secrets manager.
</details>

<details><summary>5. Why is CPU often a poor autoscaling signal for GPU inference?</summary>
The bottleneck is the GPU, so CPU can stay low while requests queue up. Scale on requests in flight, queue
depth, or latency, exported as custom metrics.
</details>

<details><summary>6. A pod is <code>Pending</code>. What do you check?</summary>
<code>kubectl describe pod</code> and read Events. Usually no node has enough of the requested CPU, memory, or
GPU, or a node selector / taint prevents scheduling. Lower the requests, fix the scheduling constraints, or
add nodes.
</details>

<details><summary>7. Why shouldn't a Helm chart set <code>replicas</code> when an HPA is enabled?</summary>
Every <code>helm upgrade</code> would reset the replica count to the fixed value, fighting the HPA and
possibly scaling down during peak traffic.
</details>

## Failure modes
- No readiness probe, so traffic reaches pods that are still loading the model.
- A liveness probe that's too aggressive for model load time, causing endless restarts (`CrashLoopBackOff`).
- No resource requests, so the scheduler overpacks nodes and pods get OOMKilled or throttled.
- Secrets committed to git as plain YAML.
- Autoscaling on the wrong metric, or `minReplicas: 1`, so a single pod failure is an outage.

## Checklist
- [ ] You can explain the control plane, nodes, pods, and the reconciliation loop
- [ ] Your model Deployment has requests, limits, and startup/readiness/liveness probes
- [ ] Config comes from a ConfigMap and credentials from a Secret, not from the image
- [ ] The HPA scales your model between 2 and N replicas under load
- [ ] The same Helm chart deploys to two environments with different values files
- [ ] You deleted pods on Minikube and watched them come back
