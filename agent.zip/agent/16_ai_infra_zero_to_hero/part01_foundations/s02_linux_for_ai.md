# Section 2 — Linux Foundations for AI Engineers

> Lectures 8–14 • Assessments: build a Linux system health script, quiz
> **After this section you can:** move around a Linux box confidently, fix permission and disk problems,
> install packages without breaking the system Python, find and kill runaway processes, automate
> chores with bash, and set up an Ubuntu machine for AI work.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 8 | Why Linux dominates AI infrastructure | GPU drivers, containers, and Kubernetes are all Linux-native |
| 9 | Navigating the shell | Pipes and small tools beat clicking: `ls`, `cd`, `grep`, `find`, `|` |
| 10 | Filesystems, directories, permissions | Know where things live (`/data`, `/dev/nvidia0`) and who can touch them |
| 11 | Package managers | `apt`/`yum` for the OS, `pip`/`uv` inside a virtual environment for Python |
| 12 | Process management and monitoring | `ps`, `top`, `htop`, `nvidia-smi`, `kill`, `systemd`, `nohup`/`tmux` |
| 13 | Scripting for automation | Bash with `set -euo pipefail`, loops, functions, cron |
| 14 | Lab: set up Ubuntu for AI development | Drivers, CUDA check, Python env, Docker, a GPU smoke test |

```mermaid
flowchart LR
  SH[Shell basics] --> FS[Files + permissions]
  FS --> PKG[Packages + envs]
  PKG --> PROC[Processes + monitoring]
  PROC --> SCRIPT[Automation scripts]
  SCRIPT --> LAB[AI-ready Ubuntu box]
  SCRIPT --> EX[Exercise: health script]
```

**How to read it:** each skill builds on the one before. You learn the **shell** (the text window where you type
commands), then files and permissions, then installing **packages** (ready-made software) and **envs** (Python
virtual environments, one per project). After that come processes and monitoring, then scripts that automate it
all. The lab ends with an "AI-ready" Ubuntu machine, meaning it has the GPU driver, a working PyTorch with CUDA,
and Docker that can see the GPU. The exercise is a health-check script for a GPU server.

---

## Lecture 8 — Why Linux dominates AI infrastructure

**Why it matters.** Almost every GPU server, cloud VM, container, and Kubernetes node you will touch
runs Linux. On-call debugging happens over SSH with no GUI.

**In plain words.** Linux is the common language of the AI world. GPU drivers, containers, and
Kubernetes all "speak" it natively. Using anything else means hiring a translator, which makes things
slower and adds more ways for them to break.

**Architecture: the Linux stack on a GPU server.**

```mermaid
flowchart TB
  subgraph USER["User space"]
    PY[python train.py<br/>PyTorch + CUDA libs] --> LIBC[libcuda.so,<br/>libnccl.so]
    DOCKER[containerd / Docker] --> CT[containers]
    TOOLS[nvidia-smi, htop, bash]
  end
  subgraph KERNEL["Linux kernel"]
    DRV[NVIDIA kernel driver] --> DEV["/dev/nvidia0, /dev/nvidia1 ..."]
    NS[namespaces + cgroups]
    FSK[filesystems: ext4, xfs, NFS]
    NETK[network stack + RDMA]
  end
  HW[(GPUs • NVMe disks • NICs)]
  LIBC --> DEV
  CT --> NS
  DRV --> HW
  FSK --> HW
  NETK --> HW
```

**How to read it:** your Python program never touches the GPU directly. It calls CUDA libraries, which
talk to the kernel driver through device files like `/dev/nvidia0`. The driver talks to the hardware.
Containers are just processes that the kernel fences in with namespaces and cgroups.

**Terms in this diagram.**
- **User space** and **kernel**: the kernel is the core of the operating system, with full control of the
  hardware. User space is where ordinary programs run, and they must ask the kernel for anything hardware-related.
- **libcuda.so, libnccl.so**: shared libraries (`.so` files, the Linux version of Windows `.dll` files).
  `libcuda` is the CUDA driver library that sends work to the GPU. `libnccl` is NCCL, NVIDIA's library for
  fast GPU-to-GPU communication during multi-GPU training.
- **containerd / Docker**: the programs that start and manage containers (Section 4).
- **nvidia-smi, htop, bash**: `nvidia-smi` shows GPU usage, memory, and temperature. `htop` is an interactive
  CPU and memory monitor. `bash` is the shell you type commands into.
- **/dev/nvidia0**: a **device file**, a special file through which programs talk to a piece of hardware,
  here the first GPU.
- **Namespaces + cgroups**: kernel features behind containers. **Namespaces** give a process its own private
  view of processes, network, and files. **cgroups** (control groups) limit how much CPU and memory it may use.
- **ext4, xfs, NFS**: ext4 and xfs are the common Linux disk filesystems. NFS (Network File System) lets many
  machines share one folder over the network.
- **Network stack + RDMA**: the kernel code that sends and receives network packets. **RDMA** (remote direct
  memory access) lets one machine read another's memory directly, skipping the CPU, which multi-node training
  uses for speed (Section 13).
- **NVMe disks, NICs**: NVMe is the fast SSD interface. A **NIC** (network interface card) is the network
  adapter.

**Example.** When `nvidia-smi` says "No devices were found", the fault is somewhere along that chain:
the driver isn't loaded (`lsmod | grep nvidia`), the device files are missing (`ls /dev/nvidia*`), or
the hardware isn't visible at all (`lspci | grep -i nvidia`). Knowing the chain tells you what to check
and in what order.

**Core ideas.**
- **Drivers and runtimes:** NVIDIA's data-center drivers, CUDA, NCCL, and InfiniBand stacks target
  Linux first.
- **Containers are Linux features:** namespaces and cgroups are Linux kernel features. Docker on a
  Mac runs a hidden Linux VM.
- **Everything is a file:** GPUs appear as `/dev/nvidia0`, process stats under `/proc`, and resource
  limits under `/sys/fs/cgroup`. Tools only need to read files.
- **Free and scriptable:** no license per node across 10,000 servers, and everything can be automated.

| Distribution | Where you'll see it |
|---|---|
| Ubuntu LTS (22.04, 24.04) | Most common for AI. Default on cloud deep learning images |
| RHEL / Rocky / Amazon Linux | Enterprises and AWS defaults. Uses `dnf`/`yum` |
| Debian slim, Alpine, distroless | Container base images (Alpine's musl libc often breaks Python wheels) |

**Senior / FAANG best practice.** Large fleets run **one** distribution and **one** LTS version per
hardware generation, built as an immutable "golden image" by a pipeline. Nobody hand-edits a node.
If a node drifts, it is replaced, not repaired. Mixing distributions across a GPU fleet multiplies the
driver, kernel, and library combinations you have to test.

---

## Lecture 9 — Navigating the Linux shell: bash basics

**In plain words.** The shell is a conversation: you type a command, it answers with text. Pipes let
you feed one answer into the next command, like an assembly line.

```bash
pwd                                   # where am I?
ls -lah /data                         # list, long format, human sizes, include hidden files
cd ~/projects && cd -                 # go somewhere, then jump back
cat config.yaml | less                # page through a file
tail -f train.log                     # follow a growing log, Ctrl-C to stop
grep -n "loss" train.log | tail -5    # last 5 lines mentioning loss, with line numbers
find /data -name "*.parquet" -size +1G          # big parquet files
du -sh /data/* | sort -h | tail       # which directories are biggest?
history | grep docker                 # what did I run last time?
```

**Architecture: a pipeline is an assembly line.**

```mermaid
flowchart LR
  F[(train.log<br/>2 million lines)] --> G["grep 'CUDA error'<br/>keep matching lines"]
  G --> A["awk '{print $5}'<br/>keep column 5: GPU id"]
  A --> S["sort"]
  S --> U["uniq -c<br/>count each GPU id"]
  U --> R["sort -rn | head<br/>worst GPU first"]
```

**How to read it:** each box is a small program that does one job and passes its text output to the next
box. No program needs to know about the others.

**Example.** "Which GPU threw the most CUDA errors last night?" is one line:

```bash
grep "CUDA error" train.log | awk '{print $5}' | sort | uniq -c | sort -rn | head
#   412 gpu3
#     2 gpu0
```

Now you know `gpu3` is probably faulty and should be drained before the next run.

**Five ideas that make you fast.**

| Idea | Example | Meaning |
|---|---|---|
| Pipe `\|` | `ps aux \| grep python` | Output of one becomes input of the next |
| Redirect `>`, `>>`, `2>&1` | `python train.py > run.log 2>&1` | Send stdout and stderr to a file |
| Variables | `export CUDA_VISIBLE_DEVICES=0,1` | Environment variables configure tools |
| Exit codes | `cmd && echo ok \|\| echo failed` | 0 means success. Scripts depend on this |
| Globs | `rm checkpoints/epoch_0[0-4].pt` | Patterns expand to file names |

**Senior note.** Learn `grep`, `awk '{print $2}'`, `sort | uniq -c`, and `xargs`. Together they answer
most "what's going on in these logs?" questions in seconds.

---

## Lecture 10 — Filesystems, directories, and permissions

**In plain words.** The filesystem is one big tree of folders that starts at `/`. Extra disks get
"plugged into" a branch of the tree (mounted), for example a 2 TB NVMe at `/data`. Permissions are door
locks: each file says who owns it, which group shares it, and what everyone else may do.

**Architecture: one tree, several disks.**

```mermaid
flowchart TB
  ROOT["/ (root disk, 100 GB)"] --> HOME["/home/alice<br/>code, notebooks"]
  ROOT --> ETC["/etc<br/>configuration"]
  ROOT --> VAR["/var<br/>logs, Docker images"]
  ROOT --> DEVN["/dev<br/>nvidia0, nvme1n1"]
  ROOT --> DATA["/data ← mounted NVMe (2 TB, fast,<br/>wiped if the VM stops)"]
  ROOT --> SHARED["/mnt/shared ← mounted NFS / EFS<br/>(shared by all nodes, slower)"]
  ROOT --> S3["(not mounted) s3://bucket<br/>durable, read via API or s3fs"]
```

**How to read it:** to your program everything looks like one tree, but the branches sit on different
disks with very different speed, size, and durability. Choosing *which* branch to write to is a design
decision.

**Terms in this diagram.**
- **/ (root)**: the top of the Linux directory tree. Every other path hangs below it.
- **/dev/nvme1n1**: the device file for a second NVMe SSD (disk 1, namespace 1). Disks appear in `/dev` before
  they're mounted.
- **Mounted**: attached to a folder, so a disk's contents appear at that path (for example `/data`).
- **Mounted NVMe, wiped if the VM stops**: many GPU VMs include very fast **instance-store** NVMe disks that
  belong to the physical host, so their data is lost when the VM stops or moves.
- **NFS / EFS**: NFS is the standard network-shared filesystem. **EFS** (Elastic File System) is AWS's managed
  NFS. All nodes see the same files, but each read travels over the network, so it's slower.
- **s3://bucket, s3fs**: **S3** is AWS object storage, durable and almost unlimited, read through an HTTP API
  rather than as a disk. **s3fs** is a tool that makes a bucket look like a folder, slowly (Sections 3 and 6).

**Example.** A team kept checkpoints in `/data` on instance-store NVMe because it was fast. A spot VM
was reclaimed, and three days of training disappeared with it. The fix: write checkpoints to `/data`
for speed, then copy each one to S3 in the background.

**Where things live.**

| Path | What's there | AI relevance |
|---|---|---|
| `/home/<user>` | Your files | Code, notebooks |
| `/etc` | System configuration | `/etc/docker/daemon.json`, `/etc/fstab` |
| `/var/log` | System logs | Driver errors in `syslog`/`kern.log` |
| `/dev` | Devices | `/dev/nvidia0`, `/dev/nvme0n1` |
| `/proc`, `/sys` | Kernel's live view | `/proc/meminfo`, cgroup limits |
| `/tmp` | Temporary, often small or RAM-backed | Don't put datasets here |
| `/mnt`, `/data` (convention) | Mounted disks | Datasets, checkpoints |

**Permissions.** Each file has an owner, a group, and read/write/execute bits for *user, group, others*.

```bash
ls -l train.sh            # -rwxr-x--- 1 alice mlteam ... train.sh
chmod 750 train.sh        # rwx for owner, r-x for group, nothing for others
chown alice:mlteam /data/shared
sudo usermod -aG docker alice   # let alice use Docker without sudo (log out and in again)
```

Read `750` as three digits, each the sum of read=4, write=2, execute=1: owner 7=rwx, group 5=r-x, others 0.

**Disks.** Datasets and checkpoints fill disks fast.

```bash
df -h                     # free space per filesystem
lsblk                     # which disks exist, which are mounted
sudo mkfs.ext4 /dev/nvme1n1 && sudo mkdir -p /data && sudo mount /dev/nvme1n1 /data
```

Cloud "instance store" NVMe disks are fast but **wiped when the VM stops**. Use them as a cache, never for
the only copy of a checkpoint.

**Senior note.** A full disk is one of the most common reasons a training job crashes at 3 a.m. Both the
root disk (Docker images, logs) and the data disk need monitoring. The exercise script below checks them.

---

## Lecture 11 — Package managers: apt, yum, pip

**In plain words.** The OS package manager installs system software for everyone. `pip` installs Python
libraries. Mixing them up is how people break their machines.

Think of the OS as a shared kitchen. `apt` stocks the shared pantry that everyone (including the OS
itself) relies on. A virtual environment is your own labelled box in the fridge: you can put anything in
it, and throwing it away doesn't break anyone else's dinner.

**Architecture: what goes where.**

```mermaid
flowchart TB
  subgraph SYS["System (managed by apt / dnf, needs sudo)"]
    DRV2[NVIDIA driver] --- GIT[git, curl, htop] --- SYSPY["/usr/bin/python3<br/>(used by OS tools, don't touch)"]
  end
  subgraph P1["Project A: ~/proj-a/.venv"]
    T1["torch 2.4.1 (cu124)"] --- TR1[transformers 4.44]
  end
  subgraph P2["Project B: ~/proj-b/.venv"]
    T2["torch 2.1.2 (cu121)"] --- TF2[old research code]
  end
  SYS --> P1
  SYS --> P2
```

**How to read it:** the system layer is shared and changes rarely. Each project gets its own isolated
Python environment on top of it, so Project A and Project B can need different PyTorch versions without
fighting each other.

**Terms in this diagram.**
- **apt / dnf, sudo**: `apt` (Ubuntu, Debian) and `dnf` (Red Hat, Fedora) are the system package managers that
  install software for the whole machine. `sudo` runs a command as the administrator (root).
- **/usr/bin/python3**: the system Python that the operating system's own tools depend on. Changing its packages
  can break the OS.
- **.venv**: a Python **virtual environment**, a private folder with its own Python packages for one project.
- **torch 2.4.1 (cu124)**: the PyTorch version, built for CUDA 12.4. The `cuXXX` suffix must match what the
  NVIDIA driver supports.
- **transformers**: Hugging Face's library for loading and running pretrained models.

**Example.** A data scientist ran `sudo pip install --upgrade numpy` to fix a notebook. It replaced the
numpy that Ubuntu's own tools used, and `apt` itself started crashing. With a venv, the same upgrade would
have touched only that project.

| Tool | Scope | Example |
|---|---|---|
| `apt` (Ubuntu/Debian) | System packages | `sudo apt update && sudo apt install -y build-essential git htop` |
| `dnf`/`yum` (RHEL family) | System packages | `sudo dnf install -y git htop` |
| `pip` / `uv` | Python packages, **inside a virtual environment** | `uv pip install torch` |
| `conda` / `mamba` | Python plus native libraries (CUDA toolkits) | `mamba create -n ai python=3.11` |

**Rules that prevent pain.**
1. **Never `sudo pip install`.** It overwrites packages the OS depends on. Ubuntu 23.04+ blocks it by default (PEP 668).
2. **One virtual environment per project:** `python3 -m venv .venv && source .venv/bin/activate`.
3. **Pin versions** in `requirements.txt` or a lock file. `torch==2.4.1` is reproducible; `torch` is not.
4. **Match PyTorch to CUDA:** use the right index URL, e.g. `pip install torch --index-url https://download.pytorch.org/whl/cu124`.
5. **Hold the GPU driver** so an unattended upgrade doesn't change it under a running cluster: `sudo apt-mark hold nvidia-driver-550`.

**Senior / FAANG best practice.** Treat the driver, CUDA, cuDNN, NCCL, and framework versions as one
**tested bundle** with a single version name (for example "gpu-stack-2026.10"). Upgrades roll out as a
new image: first to a canary pool, then in waves, with automatic rollback if job failure rates rise.
Mirror packages internally (an apt or PyPI proxy), so builds don't break when a public mirror changes
or goes down.

---

## Lecture 12 — Process management and monitoring

**Why it matters.** "The GPU is busy but nothing is training" and "the box is out of memory" are both
process problems.

**In plain words.** Every running program is a *process* with an ID number (PID), like a ticket number
at a counter. Monitoring tools show which tickets are using the most resources. Signals are how you ask
a process to stop: politely (SIGTERM, "please finish and leave") or forcefully (SIGKILL, "security
escorts you out").

**Architecture: the life of a training process.**

```mermaid
stateDiagram-v2
  [*] --> Running: python train.py (PID 4242)
  Running --> Sleeping: waiting for disk / network / GPU
  Sleeping --> Running: data arrived
  Running --> Stopping: SIGTERM (kill 4242)
  Stopping --> [*]: saves checkpoint, exits 0
  Running --> Killed: SIGKILL (kill -9) or kernel OOM killer
  Killed --> [*]: no cleanup, exit 137
  Running --> Zombie: exited, parent hasn't collected it yet
  Zombie --> [*]: parent calls wait()
```

**How to read it:** a healthy process moves between *running* and *sleeping* (waiting for something).
It ends either cleanly after SIGTERM or abruptly after SIGKILL. Exit code 137 means 128 + 9, i.e. it was
killed by signal 9, which is the classic sign of an out-of-memory kill.

**Terms in this diagram.**
- **PID**: process ID, the number the kernel gives each running program (here 4242).
- **Signal**: a short message the kernel delivers to a process. **SIGTERM** (signal 15, what `kill` sends) politely
  asks it to stop, so it can save a checkpoint first. **SIGKILL** (signal 9, `kill -9`) ends it immediately, with
  no chance to clean up.
- **Kernel OOM killer**: when the machine runs out of memory (OOM), the kernel picks a large process and sends it
  SIGKILL to save the system.
- **Exit 0, exit 137**: the **exit code** a process returns. 0 means success. Codes above 128 mean "killed by
  signal (code − 128)", so 137 is signal 9.
- **Zombie, wait()**: a finished process whose parent hasn't yet read its exit code with the `wait()` system
  call. It uses no CPU, but it holds a slot in the process table until collected.

**Example.** `nvidia-smi` shows a GPU at 100% memory but 0% utilization, and nobody is training. The
process table at the bottom of `nvidia-smi` shows PID 9131. `ps -fp 9131` reveals a Jupyter kernel from a
notebook someone forgot to close. `kill 9131` frees 40 GB of GPU memory.

```bash
ps aux --sort=-%mem | head          # top memory users
top / htop                          # live view: CPU, memory, load
nvidia-smi                          # GPU usage, memory, and which PIDs hold the GPU
watch -n 1 nvidia-smi               # refresh every second
kill <pid>                          # polite: SIGTERM, lets the process clean up
kill -9 <pid>                       # forceful: SIGKILL, no cleanup. Last resort
free -h                             # memory and swap
uptime                              # load average for 1, 5, 15 minutes
dmesg -T | grep -i -E "oom|xid"     # OOM kills and NVIDIA Xid (GPU hardware/driver) errors
```

**Keeping jobs alive after you disconnect.**

| Method | Use when |
|---|---|
| `nohup python train.py > train.log 2>&1 &` | Quick one-off |
| `tmux new -s train` (detach with Ctrl-b d, return with `tmux attach -t train`) | Interactive work you want to come back to |
| `systemd` service | Something that should restart on failure and start on boot (an inference server, an exporter) |

A minimal systemd unit for a model server:

```ini
# /etc/systemd/system/model-api.service
[Unit]
Description=Model API
After=network-online.target

[Service]
User=ml
WorkingDirectory=/opt/model-api
ExecStart=/opt/model-api/.venv/bin/uvicorn app:app --host 0.0.0.0 --port 8000
Restart=on-failure
Environment=CUDA_VISIBLE_DEVICES=0

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload && sudo systemctl enable --now model-api
journalctl -u model-api -f          # its logs
```

**Senior note.** *Load average* is the number of processes running or waiting. A load of 32 on a 32-core
box means fully busy. On a GPU box, low CPU with low GPU utilization usually means the data loader is
waiting on disk or network.

---

## Lecture 13 — Scripting for automation in AI workflows

**Why it matters.** Anything you do twice by hand (downloading data, launching runs, cleaning old
checkpoints) should be a script. Scripts are also the first step towards CI/CD.

**In plain words.** A script is a written recipe for the computer. You write the steps once, and the
computer repeats them exactly, at 3 a.m., on 100 machines, without getting tired or skipping a step.

**Architecture: a nightly automation flow.**

```mermaid
flowchart LR
  CRON["cron: 02:00 every night"] --> PULL[download new data<br/>from S3]
  PULL --> CHECK{row count and<br/>checksum OK?}
  CHECK -->|no| ALERT[send alert, exit 1]
  CHECK -->|yes| TRAIN[launch training]
  TRAIN --> PRUNE[delete old checkpoints,<br/>keep newest 3]
  PRUNE --> LOG[(append to<br/>/var/log/nightly.log)]
```

**How to read it:** cron starts the script on a schedule. The script checks its inputs before doing
expensive work, stops with a non-zero exit code when something is wrong, and cleans up after itself.
**cron** is the Linux scheduler that runs commands at set times. A **checksum** is a short fingerprint of a
file (for example its SHA-256 hash), and if it doesn't match the published one, the download is corrupt or
incomplete.

**Example.** Without the "row count OK?" step, a half-finished upload trained a model on 40% of the
data, and it was deployed. One `if` in the script would have stopped it.

**The safe-bash header.** Put this at the top of every script:

```bash
#!/usr/bin/env bash
set -euo pipefail     # -e: stop on error, -u: error on unset variables, -o pipefail: a failure anywhere in a pipe counts
IFS=$'\n\t'
```

**A realistic example: keep only the 3 newest checkpoints.**

```bash
#!/usr/bin/env bash
set -euo pipefail
CKPT_DIR="${1:?usage: $0 <checkpoint-dir> [keep]}"
KEEP="${2:-3}"

ls -1t "$CKPT_DIR"/*.pt 2>/dev/null | tail -n +"$((KEEP + 1))" | while read -r f; do
  echo "removing $f"
  rm -- "$f"
done
```

**Scheduling with cron.**

```bash
crontab -e
# minute hour day month weekday  command
0 * * * *  /opt/scripts/prune_ckpts.sh /data/ckpts 3 >> /var/log/prune.log 2>&1
*/5 * * * * /opt/scripts/system_health.sh --quiet || /opt/scripts/alert.sh
```

**When to stop using bash.** Once a script needs data structures, retries with backoff, API calls, or
more than ~100 lines, switch to Python. Bash is glue, not an application language.

**Senior / FAANG best practice.** Every production script starts with `set -euo pipefail`. It passes
`shellcheck` in CI, is idempotent (safe to run twice), and emits machine-readable output (exit codes,
JSON lines) so monitoring can act on it. Node health checks like the one in this lab usually run as a
DaemonSet or node agent that **cordons** a bad node automatically, instead of emailing a human.

---

## Lecture 14 — Lab: set up Ubuntu for AI development

**Goal:** a fresh Ubuntu 22.04/24.04 machine (a GPU VM from Section 1, or a local box) that is ready for
the rest of the course.

**What you're building.**

```mermaid
flowchart TB
  subgraph HOST["Ubuntu host"]
    DRV3["NVIDIA driver (e.g. 550)<br/>step 2"]
    VENV["~/venvs/ai: PyTorch cu124<br/>step 3"]
    DKR["Docker + NVIDIA Container Toolkit<br/>step 4"]
    DKR --> CTR["container: nvidia/cuda image<br/>sees the GPU via the toolkit"]
  end
  VENV --> DRV3
  CTR --> DRV3
  DRV3 --> G[(GPU)]
```

**How to read it:** the driver is installed once on the host. Both your Python environment and your
containers reuse it, which is why containers don't ship a driver of their own.

**In plain words.** You're setting up a workshop: install the power supply (driver), your personal
toolbox (Python env), and a way to bring in pre-packed toolkits from others (Docker), all plugged into
the same power supply.

```bash
# 1. Base tools
sudo apt update && sudo apt -y upgrade
sudo apt install -y build-essential git curl wget htop tmux jq unzip python3-venv

# 2. NVIDIA driver (skip if your image already has one; nvidia-smi will tell you)
ubuntu-drivers devices                       # shows the recommended driver
sudo ubuntu-drivers install                  # installs it
sudo reboot
nvidia-smi                                   # must show your GPU

# 3. Python environment
python3 -m venv ~/venvs/ai && source ~/venvs/ai/bin/activate
pip install --upgrade pip
pip install torch --index-url https://download.pytorch.org/whl/cu124
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"

# 4. Docker and GPU support in containers
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker "$USER"              # log out and back in
# Install the NVIDIA Container Toolkit following NVIDIA's docs for your distro, then:
sudo nvidia-ctk runtime configure --runtime=docker && sudo systemctl restart docker
docker run --rm --gpus all nvidia/cuda:12.4.1-base-ubuntu22.04 nvidia-smi
```

**Expected:** `nvidia-smi` works on the host **and** inside a container, and PyTorch prints `True`.
Note the three versions involved: the **driver** (host), the **CUDA runtime** (inside PyTorch or the
container image), and **PyTorch** itself. The driver must be at least as new as the CUDA runtime needs.

---

## Assessment — Build a Linux system health script

**Task:** write a script an on-call engineer can run on any AI node to answer "is this box healthy?".
It must check:
1. CPU load relative to the number of cores
2. Memory available
3. Disk usage on every mounted filesystem
4. GPU presence, utilization, memory, and temperature (if a GPU exists)
5. Recent OOM kills or NVIDIA Xid errors (if readable)

It must exit `0` when healthy, `1` on warnings, and `2` on critical problems, so cron or a monitoring agent
can act on it.

**How the script works.**

```mermaid
flowchart LR
  START[run script] --> CPU[CPU load per core]
  CPU --> MEM[memory available]
  MEM --> DSK[disk % per mount]
  DSK --> GPUC["GPU via nvidia-smi<br/>(SKIP if none)"]
  GPUC --> KER["kernel log: OOM / Xid<br/>(Linux only)"]
  KER --> EXIT{"worst result"}
  EXIT -->|all OK| E0[exit 0]
  EXIT -->|any WARN| E1[exit 1]
  EXIT -->|any CRIT| E2[exit 2]
```

Each check reports `OK`, `WARN`, `CRIT`, or `SKIP`. The script remembers the worst result and uses it as
the exit code. A check that can't run on this machine (no GPU, no `/proc`) is skipped instead of failing.

**Example output** from a GPU node with one hot GPU:

```text
OK    cpu      load1=6.10 cores=32 per_core=0.19
OK    memory   available=61%
OK    disk     / used=48%
WARN  disk     /data used=86%
WARN  gpu      gpu0 NVIDIA H100 80GB HBM3 util=97% mem=95% temp=84C
OK    gpu      gpu1 NVIDIA H100 80GB HBM3 util=12% mem=1% temp=41C
OK    kernel   no OOM kills or Xid errors
RESULT: warning
```

**Solution:** [`../exercises/s02_system_health.sh`](../exercises/s02_system_health.sh). It works on Linux
and degrades gracefully on macOS (no `/proc`, no GPU). Thresholds are environment variables, so you can
tune them without editing the script.

```bash
bash exercises/s02_system_health.sh
DISK_WARN=70 DISK_CRIT=85 bash exercises/s02_system_health.sh
bash exercises/s02_system_health.sh --quiet; echo "exit code: $?"
```

---

## FAANG deep-dive notes

**How big tech does it.** GPU nodes are cattle, not pets. A pipeline (Packer, image-builder, or an
internal equivalent) builds an immutable OS image that contains the kernel, a pinned NVIDIA driver,
the container runtime, and monitoring agents. Nodes boot from that image and are never patched by hand.
A node agent runs health checks (DCGM diagnostics, Xid errors in the kernel log, ECC counters) and
cordons and drains a bad node automatically. Driver upgrades roll out as new images in canary waves.

**Staff review questions.**
- How long does it take to replace every node in the fleet, and what breaks while that happens?
- What happens to running training jobs during a driver upgrade?
- How do you detect a silently degraded GPU (throttling, ECC errors) before a job fails?
- Who can SSH into production nodes, and is every session audited?

**Interview question.** "You run 2,000 GPU nodes. How do you roll out a new NVIDIA driver?"

**Typical system-design prompt:** *Design how the OS image and GPU software stack for a 2,000-node GPU fleet
are built, tested, rolled out, and kept consistent, without breaking running training jobs.*

**1. Clarify first:** Which GPU generations are in the fleet? Is it Kubernetes or Slurm? How long do jobs
run, and how often do they checkpoint? Are there compliance baselines (CIS hardening)? What maintenance
windows are allowed?

**2. Back-of-envelope sizing:**
- Canary: 5% = 100 nodes, soaked for 24 hours under real jobs.
- Waves: 10% (200 nodes) per wave. If draining waits for the next checkpoint (~1 hour) plus reboot and
  checks (~30 minutes), each wave takes ~2 hours. 10 waves ≈ 20 hours.
- Total: about 2–3 days per fleet-wide driver upgrade. Plan for 4–6 upgrades a year.
- Image: ~8–15 GB. Pre-stage it to each zone, so 200 nodes don't pull it from one place at once.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Node config | Golden immutable image | Configure at boot (Ansible, cloud-init) | Golden image for speed and consistency. Boot-time config only for small, fast-changing settings |
| Driver install | Baked into the host image | NVIDIA GPU Operator container | Operator when you want Kubernetes to own it. Baked in for the fastest boot and the fewest moving parts |
| OS updates | Unattended upgrades on | Off, with image rebuilds | Off on GPU nodes. Rebuild and roll out the image instead |
| Distribution | Ubuntu LTS | RHEL family | Pick the one your drivers and vendor support best, then never mix them |

**4. Follow-up questions with crisp answers:**
- *Why hold the driver package?* An automatic update changes the user-space libraries while the old
  kernel module is still loaded, and every GPU call fails until a reboot.
- *How do you catch a bad GPU?* Read Xid errors from `dmesg`, check ECC counters, and run periodic
  DCGM diagnostics (level 1 on each boot, deeper levels during maintenance).
- *Why not Alpine for GPU images?* Its musl libc is incompatible with most prebuilt CUDA and Python
  wheels, which expect glibc.

**Debug this (common onsite question):** "Overnight, 300 nodes started failing jobs with `Failed to initialize
NVML: Driver/library version mismatch`."
1. Compare the loaded kernel module version (`cat /proc/driver/nvidia/version`) with the installed
   package version (`dpkg -l | grep nvidia`). They differ.
2. Check `/var/log/apt/history.log`: unattended-upgrades installed a new driver package last night.
3. Mitigate: cordon the affected nodes and reboot them in waves, so the new module loads, or downgrade
   the package.
4. Prevent: `apt-mark hold` the driver, turn off unattended upgrades on GPU nodes, and ship drivers only
   through new images.

The lesson: on GPU nodes the kernel module and user-space libraries must always match. Any change path
that bypasses the image pipeline will eventually break the fleet.

**5. What separates senior from staff answers:** a senior engineer knows how to install and pin a driver.
A staff engineer designs the whole rollout system: a canary with automatic rollback, drains that respect
checkpoints, fleet-wide health signals, the time to replace the fleet as a tracked metric, and a clear
owner for every layer of the stack.

**Red flags:**
- SSH-ing into nodes to "fix" them by hand.
- Unattended upgrades turned on for GPU drivers.
- No canary wave, or rolling out to the whole fleet at once.
- No automated node health checks or auto-cordon.
- Shared root credentials, or SSH sessions with no audit trail.

---

## Quiz

<details><summary>1. What does <code>set -euo pipefail</code> do?</summary>
<code>-e</code> stops the script when a command fails, <code>-u</code> treats unset variables as errors, and
<code>pipefail</code> makes a pipeline fail if any command in it fails, not just the last one.
</details>

<details><summary>2. Why should you never run <code>sudo pip install</code>?</summary>
It installs into the system Python, and can overwrite packages that OS tools depend on. Use a virtual
environment per project instead.
</details>

<details><summary>3. <code>chmod 640 secrets.env</code>: who can do what?</summary>
The owner can read and write (6). The group can read (4). Others have no access (0).
</details>

<details><summary>4. A training job died overnight with no Python traceback. Where do you look?</summary>
<code>dmesg -T | grep -i oom</code> or <code>journalctl -k</code> for an out-of-memory kill, <code>df -h</code>
for a full disk, and <code>dmesg</code> for NVIDIA Xid errors. A SIGKILL leaves no traceback.
</details>

<details><summary>5. What's the difference between <code>kill</code> and <code>kill -9</code>?</summary>
<code>kill</code> sends SIGTERM, which a process can catch to save state and exit cleanly. <code>kill -9</code>
sends SIGKILL, which can't be caught, so there's no cleanup.
</details>

<details><summary>6. Your data disk is an instance-store NVMe. Is it safe for checkpoints?</summary>
Only as a fast local cache. Instance-store data is lost when the VM stops or is replaced. Copy checkpoints
to object storage (S3/GCS) or a persistent volume.
</details>

<details><summary>7. GPU utilization is 15% and CPU is mostly idle during training. What's the likely cause?</summary>
The input pipeline is waiting on I/O: slow disk or network reads, too few data loader workers, or small
files. Section 6 covers fixes.
</details>

## Failure modes
- Driver auto-upgraded by `unattended-upgrades`, so `nvidia-smi` fails after the next reboot. Hold the driver package.
- Root disk fills up with Docker images and logs (`docker system df`, `journalctl --vacuum-size=1G`).
- A long job runs in a plain SSH session and dies when the laptop sleeps. Use `tmux` or systemd.
- Scripts without `set -euo pipefail` keep going after a failed download and train on half a dataset.

## Checklist
- [ ] You can find the biggest directories on a disk and the biggest memory user on a box in under a minute
- [ ] Every project has its own virtual environment with pinned versions
- [ ] Your Ubuntu box runs `nvidia-smi` on the host and inside a container
- [ ] Your health script exits non-zero when a disk passes the threshold
