# Section 1 — AI Infrastructure Fundamentals

> Lectures 1–7 • Assessment: quiz
> **After this section you can:** explain what AI infrastructure is, choose between CPU, GPU and TPU
> for a workload, tell training from inference by its resource profile, name the layers of an AI
> platform, and launch your first GPU VM.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 1 | What is AI infrastructure? | Everything a model needs besides the math: compute, data, network, software, and the people who run them |
| 2 | CPUs vs GPUs vs TPUs | Few smart cores vs. thousands of simple ones vs. a matrix-multiply engine |
| 3 | Training vs inference | Training is a big batch job you run rarely. Inference is a latency-sensitive service that runs forever |
| 4 | Infrastructure layers | Hardware → platform → MLOps → applications. Each layer hides the one below |
| 5 | Case studies: ChatGPT, DALL·E | Frontier AI is a supercomputer for training plus a global fleet for serving |
| 6 | Industry landscape | Hyperscalers, GPU clouds, and chip vendors, and where lock-in comes from |
| 7 | Lab: spin up your first AI VM | Launch a GPU instance, verify the driver, run a matrix multiply, shut it down |

```mermaid
flowchart TB
  subgraph APP[Applications]
    A1[Chat app] --- A2[Recommender] --- A3[Fraud API]
  end
  subgraph OPS[MLOps layer]
    O1[Experiment tracking] --- O2[CI/CD + registry] --- O3[Monitoring + drift]
  end
  subgraph PLAT[Platform layer]
    P1[Containers] --- P2[Kubernetes] --- P3[Serving: FastAPI, Triton]
  end
  subgraph HW[Hardware layer]
    H1[CPU / GPU / TPU] --- H2[Storage] --- H3[Network]
  end
  APP --> OPS --> PLAT --> HW
```

**How to read it:** every request from an application eventually becomes work on hardware.
Each layer exists so that the layer above doesn't need to know the details of the layer below.
The rest of this course walks this stack from the bottom up.

**Terms in this diagram.** Every box gets its own section later. In short:
- **Recommender**: a model that picks items for each user (videos, products). **Fraud API**: a service that
  scores each payment for fraud risk in milliseconds.
- **Experiment tracking**: recording every training run's settings and results so it can be compared and
  reproduced (Section 9).
- **CI/CD + registry**: CI/CD (continuous integration and delivery) automatically tests and ships each change.
  The **model registry** is the catalog of trained model versions, with which one is in production (Section 10).
- **Monitoring + drift**: watching the live system's health, and detecting **drift**, when real-world data
  changes so the model gets less accurate (Sections 16 and 17).
- **Containers**: a packaged app with all its libraries, so it runs the same everywhere (Section 4).
- **Kubernetes**: the system that runs containers across many machines, restarts them when they fail, and
  scales them (Section 5).
- **Serving: FastAPI, Triton**: **serving** means running a model behind an API so apps can send it
  requests. **FastAPI** is a popular Python web framework for simple model APIs. **Triton** (NVIDIA Triton
  Inference Server) is a high-performance server for many models at once (Sections 14 and 15).
- **CPU / GPU / TPU**: the processors. A **GPU** does thousands of math operations in parallel, which is what
  neural networks need. A **TPU** is Google's custom AI chip (Lecture 6, Section 7).
- **Storage** and **Network**: where data and models live (Section 6), and the links between users,
  servers, and GPUs (Section 13).

---

## Lecture 1 — What is AI infrastructure? The engine behind AI

**Why it matters.** A model file on its own does nothing. To train it you need thousands of GPU-hours,
terabytes of data delivered fast enough to keep the GPUs busy, and a way to recover when a node dies
on day 9 of a 14-day run. To serve it you need an API, autoscaling, monitoring, and security. That
surrounding system is AI infrastructure, and it is usually where most of the cost and most of the
outages are.

**In plain words.** If the model is a car engine, AI infrastructure is the factory that builds it, the
fuel supply, the roads, the traffic lights, and the mechanics.

**Architecture: the four pillars around one model.**

```mermaid
flowchart LR
  DATA[(Storage<br/>datasets, checkpoints,<br/>model weights)] -->|fast reads| COMPUTE[Compute<br/>GPUs train + serve<br/>the model]
  COMPUTE -->|save checkpoints| DATA
  USERS[Users / apps] -->|requests| NET[Network<br/>load balancer, API,<br/>GPU-to-GPU links]
  NET --> COMPUTE
  SW[Software<br/>drivers, PyTorch, Docker,<br/>Kubernetes, MLOps] -.runs everything.- COMPUTE
  SW -.-> NET
  SW -.-> DATA
```

**How to read it:** storage feeds the GPUs, and the GPUs write their progress back to storage. Users reach
the model through the network. Software sits around all three and makes them work together.

**Terms in this diagram.**
- **Datasets**: the training examples (text, images, transactions), often terabytes.
- **Checkpoints**: snapshots of a model saved during training, so a crash costs minutes of work instead of days.
- **Model weights**: the learned numbers inside a trained model. "The model file" is mostly its weights.
- **Load balancer**: a server that spreads incoming requests across several copies of the model.
- **GPU-to-GPU links**: very fast connections between GPUs (NVLink inside a server, InfiniBand between
  servers) that let many GPUs train one model together (Sections 7 and 13).
- **Drivers**: the low-level software that lets the operating system use the GPU. **PyTorch**: the most
  popular Python library for building and training neural networks. **Docker**: the standard tool for
  building and running containers. **Kubernetes** and **MLOps** are explained in the diagram above.

**Example.** A bank builds a fraud model. The *model* is a 50 MB file. The *infrastructure* is everything
else: a data lake with 3 years of transactions (storage), 4 GPUs for training every night (compute), an
API answering 2,000 card swipes a second in under 50 ms (network and serving), and dashboards that page
someone when the fraud-catch rate drops (monitoring). The model took one week to build. The
infrastructure took six months.

**Core ideas.**
- AI infrastructure has four resource pillars: **compute** (CPU, GPU, TPU), **storage** (object, block,
  file), **network** (inside the cluster and to users), and **software** (drivers, frameworks,
  orchestration, MLOps tooling).
- It differs from classic web infrastructure in three ways:

| | Web service | AI system |
|---|---|---|
| Expensive resource | CPU and RAM, cheap per unit | GPUs, often $2–$10 per GPU-hour each |
| Data | Small requests, a database | Terabytes of training data, gigabytes of model weights |
| Correctness | Deterministic: tests pass or fail | Statistical: quality can drift silently while the service looks healthy |
| Failure blast radius | One request | A multi-day training run, or every prediction made since drift started |

**Senior note.** The goal of AI infrastructure is **GPU utilization at acceptable risk**. An idle GPU
costs the same as a busy one. Most of the techniques in this course exist to keep expensive
accelerators busy (data pipelines, batching, scheduling) or to stop them from doing the wrong thing
(monitoring, drift detection, security).

---

## Lecture 2 — CPUs vs GPUs vs TPUs: computing power for AI

**Why it matters.** Picking the wrong processor is the most expensive mistake in AI infrastructure. A
CPU-only training job can take 50× longer. A GPU serving a tiny model can cost 10× more than it needs to.

**In plain words.** A CPU is a few expert chefs who can cook anything. A GPU is a thousand line cooks
who can each only chop, but all at the same time. A TPU is a machine built only to chop, very fast.

**Architecture: how the same work is split up.**

```mermaid
flowchart TB
  JOB["Multiply two 4096×4096 matrices<br/>= ~69 billion multiply-adds"]
  JOB --> CPU
  JOB --> GPU
  JOB --> TPU
  subgraph CPU["CPU: 16 big cores"]
    C1[core 1] --- C2[core 2] --- C3[... core 16]
  end
  subgraph GPU["GPU: thousands of small cores + Tensor Cores"]
    G1[SM 1] --- G2[SM 2] --- G3[... SM 132]
  end
  subgraph TPU["TPU: systolic array"]
    T1["128×128 grid of multipliers<br/>data flows through like a wave"]
  end
  CPU --> R1["~1 second"]
  GPU --> R2["~5 milliseconds"]
  TPU --> R3["~5 milliseconds"]
```

**How to read it:** the same job is split many ways. The CPU gives each core a large share, so it
finishes late. The GPU spreads it across ~132 streaming multiprocessors (SMs), each with many cores. The
TPU pushes the numbers through a fixed grid of multipliers. Timings are rough, for illustration.

**Terms in this diagram.**
- **Multiply-adds**: the basic step of matrix math, multiplying two numbers and adding the result to a running
  total. Neural networks are mostly billions of these.
- **SM (streaming multiprocessor)**: the GPU's building block. Each SM holds many small cores and shares a fast
  local memory. An H100 has 132 SMs.
- **Tensor Cores**: special units inside each SM that multiply small blocks of matrices in one step, many times
  faster than ordinary cores. They're why GPUs dominate AI (Section 7).
- **Systolic array**: a grid of multipliers where numbers flow from cell to cell like a wave, each cell
  multiplying and passing its result on. It's very efficient for matrix math, but good at little else.

**Example.** Grading 10,000 multiple-choice exam papers. One professor (a CPU core) is brilliant but
grades one paper at a time. A hall of 1,000 students each grading 10 papers (a GPU) finishes far sooner,
even though each student is slower than the professor. If the job were "write a thesis", the professor
would win, because that work can't be split up. That's why CPUs still run the control logic, data
preprocessing, and the web server around your model.

**Core ideas.** Neural networks are mostly **matrix multiplications**, which are millions of
independent multiply-adds. That work is "embarrassingly parallel", so processors with many simple
cores win.

| | CPU | GPU | TPU |
|---|---|---|---|
| Cores | 8–128 complex cores | Thousands of simple cores plus Tensor Cores | Systolic arrays (matrix units) |
| Good at | Branching logic, preprocessing, small models, orchestration | Training and inference of most deep learning models | Large-scale training and inference on Google Cloud |
| Memory | System RAM, large but slow (~100 GB/s) | HBM, small but fast (2–8 TB/s) | HBM |
| Software | Everything | CUDA ecosystem (PyTorch, TensorFlow, JAX) | JAX, TensorFlow, PyTorch/XLA |
| Where | Everywhere | Every cloud, on-prem | Google Cloud only |

- **Memory bandwidth often matters more than FLOPs.** For LLM inference, each generated token reads
  every weight once, so speed is limited by how fast memory can deliver the weights, not by compute.
- Other accelerators exist: AWS **Trainium/Inferentia**, AMD **Instinct MI300X**, and NPUs in phones and
  laptops. Section 46 covers chip trends.

**Rule of thumb.**

| Workload | Pick |
|---|---|
| Classical ML (XGBoost, scikit-learn), feature engineering | CPU |
| Small model inference (< 100M params) at modest traffic | CPU, or a small GPU (T4, L4) if latency matters |
| Training any deep network | GPU (or TPU if you're on Google Cloud and use JAX) |
| LLM inference | GPU with enough HBM to hold the weights plus the KV cache |

**Senior note.** Ask "what is the bottleneck: compute, memory capacity, or memory bandwidth?" before
asking "which chip?". See [`14_math_for_ml_dl_llm/09_ml_systems_math.md`](../../14_math_for_ml_dl_llm/09_ml_systems_math.md)
for how to work this out on paper.

---

## Lecture 3 — Training vs inference: two faces of AI workloads

**Why it matters.** Training and inference need almost opposite infrastructure. Teams that reuse their
training cluster for serving (or the reverse) overpay or miss latency targets.

**In plain words.** Training is writing the textbook: slow, expensive, done once. Inference is answering
questions with the textbook: fast, cheap per question, done millions of times.

**Architecture: two very different shapes.**

```mermaid
flowchart LR
  subgraph TRAIN["Training: a batch job (hours to weeks, then stops)"]
    D[(Dataset<br/>TBs in object storage)] --> L[Data loader]
    L --> F[Forward pass]
    F --> LOSS[Loss]
    LOSS --> B[Backward pass<br/>gradients]
    B --> SYNC[Sync gradients<br/>across GPUs]
    SYNC --> OPT[Optimizer<br/>updates weights]
    OPT -->|next batch| F
    OPT -->|every N steps| CK[(Checkpoint)]
  end
  CK -->|final model| REG[(Model registry)]
  subgraph SERVE["Inference: a service (runs 24/7)"]
    U[User request] --> API[API + batching]
    API --> FW[Forward pass only]
    FW --> RESP[Response in ms]
  end
  REG -->|deploy| FW
```

**How to read it:** training loops over the data again and again, and the GPUs must talk to each other
every step (*sync gradients*). It ends by producing a model file. Inference loads that file and runs only
the forward pass, once per request, as quickly as possible.

**Terms in this diagram.**
- **Data loader**: the code that reads examples from storage, groups them into **batches** (for example 256
  examples), and feeds them to the GPU.
- **Forward pass**: running inputs through the model to get predictions. **Loss**: one number measuring how
  wrong the predictions were.
- **Backward pass, gradients**: working backwards through the model to compute, for every weight, which
  direction to nudge it to reduce the loss. Those nudge directions are the **gradients**.
- **Sync gradients across GPUs**: when several GPUs each train on different batches, they average their
  gradients every step so all copies of the model stay identical (Section 8).
- **Optimizer**: the algorithm (for example Adam) that applies the gradients to update the weights.
- **Model registry**: the catalog where finished model versions are stored and promoted (Sections 9 and 10).
- **Batching** (inference): grouping several users' requests into one GPU call, which is much more efficient
  than one call per request.

| | Training | Inference |
|---|---|---|
| Goal | Throughput: finish the run sooner | Latency (p95/p99) and cost per request |
| Shape | Batch job: hours to weeks, then stops | Long-running service, 24/7 |
| Math | Forward + backward pass + optimizer update | Forward pass only |
| Memory per parameter | ~16 bytes (weights, gradients, Adam states, mixed precision) | ~2 bytes (fp16) or less when quantized |
| Scale-out | Many GPUs working on **one** job, tightly coupled, needs fast interconnect | Many replicas working **independently**, loosely coupled |
| Failure impact | Lose hours of progress unless you checkpoint | Users see errors right away |
| Cost driver | GPU-hours × number of runs | Traffic × time × replicas left running |

**Worked example.** A team fine-tunes a 7B model.
- Training: 7B × 16 bytes ≈ 112 GB of model state, so it doesn't fit on one 80 GB GPU. They need 2+ GPUs
  with sharding (Section 8), for about 6 hours.
- Inference: 7B × 2 bytes ≈ 14 GB of weights. That fits on a single 24 GB GPU (L4 or A10G) with room
  for the KV cache.

So training rents 8 GPUs for an afternoon, while serving runs on one cheaper GPU for months. Over a
year, **serving usually costs more than training**.

**Senior note.** Plan for inference from day one. The most common surprise in AI budgets is the serving
bill, not the training bill.

---

## Lecture 4 — AI infrastructure layers: hardware, software, ops

**Why it matters.** When something breaks, you need to know which layer to look at. "The model is slow"
can be a hardware problem (thermal throttling), a platform problem (CPU limits on the pod), or an ops
problem (a bad model version was deployed).

**In plain words.** A restaurant. The building and kitchen equipment are the hardware. The gas and
electricity are the system software. The head chef assigning cooks to stations is orchestration. The
recipes are the ML frameworks. Inventory, menu changes, and health inspections are MLOps. The diner
only sees the plate: the application.

**The layers, bottom to top.**

| Layer | Contains | Example tools | Owned by |
|---|---|---|---|
| 1. Hardware | Accelerators, CPUs, storage, network fabric | NVIDIA H100, NVMe, InfiniBand | Cloud provider or data-center team |
| 2. System software | OS, drivers, runtimes | Ubuntu, NVIDIA driver, CUDA, containerd | Platform team |
| 3. Orchestration | Scheduling, scaling, isolation | Kubernetes, Slurm, Ray | Platform team |
| 4. ML frameworks | Training and serving libraries | PyTorch, TensorFlow, vLLM, Triton | ML engineers |
| 5. MLOps | The model lifecycle | MLflow, Kubeflow, CI/CD, feature store | MLOps team |
| 6. Observability and security | Cross-cutting at every layer | Prometheus, Grafana, IAM, Vault | SRE and security |
| 7. Applications | What users touch | Chatbots, search, fraud APIs | Product teams |

**Example: debugging "the chatbot got slow" layer by layer.**

```mermaid
flowchart TB
  S["Symptom: p95 latency 400 ms → 2 s"] --> L7{"(7) App: did the prompt<br/>or traffic change?"}
  L7 -->|no| L5{"(5) MLOps: was a new<br/>model version deployed?"}
  L5 -->|no| L4{"(4) Framework: is batching<br/>still on? Did vLLM upgrade?"}
  L4 -->|no| L3{"(3) Orchestration: are pods<br/>CPU-throttled or pending?"}
  L3 -->|no| L2{"(2) System: driver errors<br/>in dmesg?"}
  L2 -->|no| L1["(1) Hardware: GPU at 88°C<br/>and throttling its clocks ✔"]
```

**How to read it:** start at the top, where changes happen most often, and work down. In this example
every upper layer was fine. The real cause was a failed cooling fan that made the GPU slow itself down
to avoid overheating. Section 16 shows how GPU temperature dashboards catch this before users notice.

**Terms in this diagram.**
- **p95 latency**: the response time that 95% of requests beat. It shows what slow users experience, which an
  average hides.
- **Batching, vLLM**: batching groups requests into one GPU call. **vLLM** is a popular open-source server for
  large language models that does this automatically.
- **Pods CPU-throttled or pending**: a **pod** is a running container in Kubernetes (Section 5). **Throttled**
  means it hit its CPU limit, so the kernel pauses it in short bursts. **Pending** means it's waiting because
  no machine has room for it.
- **dmesg**: a Linux command that prints the kernel's log, where GPU driver errors (NVIDIA "Xid" errors)
  appear (Section 2).
- **Throttling its clocks**: a hot GPU lowers its clock speed, so it does less work per second, to protect
  itself.

**Senior note.** A version mismatch between layers 2 and 4 (driver ↔ CUDA ↔ PyTorch) is the most common
"it worked yesterday" failure. Pin versions in every layer, and change them one at a time.

---

## Lecture 5 — Case studies: the infrastructure behind ChatGPT and DALL·E

These are simplified from public information. Section 45 goes deeper.

**In plain words.** Building ChatGPT is like building a car factory and a nationwide taxi service.
The factory (the training supercomputer) is used to build the car once. The taxi fleet (serving) has to
be in every city, all day, with short wait times, and it costs more to run over time than the factory did.

**ChatGPT.**
- **Training:** a supercomputer built with Microsoft Azure. Tens of thousands of NVIDIA GPUs connected with
  InfiniBand, because distributed training is limited by how fast GPUs can exchange gradients.
- **Serving:** a global fleet of GPU clusters behind load balancers. To make it economical they rely on
  batching many users' requests together, caching, and routing each request to the right model size.
- **Lesson:** the training cluster is about the *interconnect*. The serving fleet is about *utilization
  and latency*.

**DALL·E (image generation).**
- Every request runs dozens of diffusion steps on a GPU, so cost per request is much higher than for text.
- Safety filters run before and after generation, each with its own models and infrastructure.
- **Lesson:** a "single model" product is often a pipeline of several models, and each one needs its own
  scaling and monitoring.

```mermaid
flowchart LR
  U[User] --> LB[Global load balancer]
  LB --> MOD[Moderation model]
  MOD --> ROUTE[Router: which model, which region]
  ROUTE --> B[Batching scheduler]
  B --> G1[GPU replica]
  B --> G2[GPU replica]
  G1 & G2 --> OUT[Output safety filter] --> U
```

**How to read it:** follow one request left to right. Notice that before and after the main model it
also passes through a moderation model and a safety filter.

**Terms in this diagram.**
- **Global load balancer**: one public entry point that sends each user to a healthy data center, usually the
  nearest one.
- **Moderation model**: a small, fast model that checks the incoming prompt for abuse or policy violations
  before the expensive main model sees it.
- **Router**: decides which model version handles the request (for example a small model for easy questions)
  and in which region it runs.
- **Batching scheduler**: collects requests arriving at nearly the same moment and runs them together on a
  GPU, which multiplies throughput (Section 15).
- **GPU replica**: one copy of the model loaded on its own GPUs. Many identical replicas share the traffic.
- **Output safety filter**: checks the generated answer before it's returned, for example for leaked personal
  data or harmful content.

**Example: why serving outgrows training (illustrative numbers).** Say a chat product has 10M daily
users who send 5 messages each, about 500 output tokens per reply.

| Quantity | Calculation | Result |
|---|---|---|
| Requests per day | 10M × 5 | 50M |
| Average requests per second | 50M ÷ 86,400 | ~580 |
| Peak (3× average) | 580 × 3 | ~1,750 |
| Peak output tokens per second | 1,750 × 500 | ~875,000 |
| GPUs at ~10,000 tokens/s each (8B model, batched) | 875,000 ÷ 10,000, plus 30% headroom | ~115 |
| Monthly serving bill at $3 per GPU-hour | 115 × $3 × 730 h | ~$250,000 |

A fine-tune of the same model might use 8 GPUs for a day (about $600). Training happens once.
Serving runs every month, and grows with every new user.

**Senior / FAANG best practice.** Big-tech teams treat training and serving as two separate products with
separate capacity plans. The training cluster is sized by the size of the largest job and how fast the
interconnect is. The serving fleet is sized by peak tokens per second, a latency target, and a headroom
policy. Track **cost per 1,000 requests** from launch day, because that number decides whether the
product is a business.

**Example: why batching decides the serving bill.** Suppose one GPU replica costs $4 per hour and can
generate 30 tokens per second for a single user. Serving users one at a time, it produces about 108,000
tokens per hour, or roughly **$37 per million tokens**. With batching, the same GPU serves 32 users at
once at maybe 25 tokens per second each, about 2.9 million tokens per hour, or roughly **$1.40 per
million tokens**. Same hardware, about 26× cheaper. This is why large serving fleets invest so heavily
in batching schedulers (Sections 15 and 25).

---

## Lecture 6 — Industry landscape: cloud providers and AI chips

**In plain words.** Getting GPUs is like getting a place to live. A hyperscaler is a full-service
apartment complex: gym, security, concierge, higher rent, and a long lease. A GPU cloud is a cheaper
flat with fewer amenities. On-prem means buying a house: expensive up front, but cheapest per month if
you live there for years.

**Architecture: a simple decision path.**

```mermaid
flowchart TB
  Q1{"Must data stay on your own<br/>hardware (law, sovereignty)?"} -->|yes| ONP[On-prem / colocation]
  Q1 -->|no| Q2{"GPUs busy > ~60% of the<br/>time for 2+ years?"}
  Q2 -->|yes| MIX["Reserved capacity or on-prem<br/>for the base load + cloud for bursts"]
  Q2 -->|no| Q3{"Need managed services<br/>(IAM, databases, compliance)<br/>next to the GPUs?"}
  Q3 -->|yes| HYP[Hyperscaler: AWS / GCP / Azure]
  Q3 -->|no| GPC[GPU cloud: CoreWeave, Lambda, ...]
```

**How to read it:** answer the questions top to bottom. Legal constraints come first, then how steadily
you use the GPUs, then whether you need the surrounding managed services.

**Terms in this diagram.**
- **Sovereignty**: rules that data must stay inside a country or under an organization's own control.
- **On-prem / colocation**: on-prem means servers in your own data center. Colocation means your servers in a
  rented space in someone else's data center.
- **Reserved capacity**: committing to rent GPUs for 1 to 3 years in exchange for a big discount (Section 12).
  **Base load + bursts**: the steady minimum you always use, plus short peaks.
- **Managed services, IAM**: managed services are things the cloud runs for you (databases, queues).
  **IAM** (identity and access management) is the cloud's permission system.
- **Hyperscaler: AWS / GCP / Azure**: the three largest clouds: Amazon Web Services, Google Cloud Platform, and
  Microsoft Azure. **GPU cloud**: smaller providers that mainly rent GPUs (CoreWeave, Lambda).

**Example.** A 10-person startup fine-tuning models a few days a month picks a GPU cloud: it's cheapest
per hour and they don't need much else. A hospital network that must keep patient data in-country runs
inference on-prem, and uses a hyperscaler region in the same country for non-sensitive training.

| Category | Players | When to use |
|---|---|---|
| Hyperscalers | AWS, Google Cloud, Microsoft Azure, Oracle | You need managed services, compliance certifications, and the rest of your stack is already there |
| GPU-focused clouds | CoreWeave, Lambda, Crusoe, Together, RunPod | You need cheaper or more available GPUs, and mainly want raw compute |
| Managed AI platforms | SageMaker, Vertex AI, Azure ML, Databricks | You want MLOps handled for you and accept some lock-in |
| On-prem / colocation | NVIDIA DGX/HGX, Dell, Supermicro | Steady high utilization, data sovereignty, or regulatory needs |

| Chip vendor | Products | Notes |
|---|---|---|
| NVIDIA | H100/H200, B200, L4, Jetson | Dominant, mostly because of the CUDA software ecosystem |
| AMD | Instinct MI300X/MI325X | Large HBM. Uses the ROCm software stack |
| Google | TPU v5e/v5p, Trillium | Google Cloud only. Best with JAX |
| AWS | Trainium, Inferentia | AWS only. Uses the Neuron SDK |
| Intel | Gaudi | Price/performance option |

**Senior note.** Lock-in comes mostly from **software, not hardware**: CUDA kernels, managed-service APIs,
and data gravity (it's expensive to move petabytes). Containers, Kubernetes, and open formats (ONNX,
safetensors, Parquet) are your exit doors. Section 20 covers multi-cloud.

---

## Lecture 7 — Lab: spin up your first AI VM

**Goal:** launch a GPU VM, confirm the GPU works, run a matrix multiply on it, and shut it down without a
surprise bill.

**Cost:** an NVIDIA T4 instance costs about $0.35–$0.55 per hour on demand. This lab takes 30 minutes.

**What you're building.**

```mermaid
flowchart LR
  YOU[Your laptop] -->|SSH, port 22,<br/>only from your IP| SG[Security group /<br/>firewall rule]
  SG --> VM
  subgraph VM["GPU VM (g4dn.xlarge or n1-standard-4 + T4)"]
    OS[Ubuntu + NVIDIA driver] --> CUDA[CUDA runtime in PyTorch]
    CUDA --> GPU[(T4 GPU, 16 GB)]
    DISK[(100 GB boot disk)]
  end
  VM -.billing runs while it exists.-> BILL[Billing alert]
```

**How to read it:** you reach the VM only over SSH, and only from your own IP address. Inside the VM the
driver lets PyTorch talk to the GPU. The billing alert is part of the design, not an afterthought.

**Terms in this diagram.**
- **SSH, port 22**: SSH (Secure Shell) is the encrypted remote-login protocol for Linux servers. It listens on
  network port 22.
- **Security group / firewall rule**: the cloud's firewall around a VM. Here it allows only SSH, only from your
  IP address, and blocks everything else.
- **g4dn.xlarge, n1-standard-4 + T4**: VM sizes. `g4dn.xlarge` is the AWS type with 4 vCPUs, 16 GB of RAM, and
  one NVIDIA T4 GPU. On Google Cloud, you attach a T4 to an `n1-standard-4` VM (4 vCPUs, 15 GB). The **T4** is
  a small, cheap inference GPU with 16 GB of memory.
- **Ubuntu + NVIDIA driver**: Ubuntu is the most common Linux distribution for AI servers, and the driver is the
  kernel software that controls the GPU.
- **CUDA runtime in PyTorch**: CUDA is NVIDIA's platform for running code on GPUs. PyTorch ships its own CUDA
  runtime libraries, so you only need a recent enough driver on the VM.
- **Boot disk**: the VM's main disk, holding the operating system and your files.
- **Billing alert**: an email or message from the cloud when spending passes a limit you set.

**In plain words.** You're renting a powerful computer by the hour, checking that its engine starts,
taking it for one quick drive, and returning the keys so the meter stops.

### Step 1 — Launch the instance

AWS (a `g4dn.xlarge` has one T4 GPU). Use a Deep Learning AMI, which has drivers preinstalled:

```bash
aws ec2 run-instances \
  --image-id <deep-learning-ami-id-for-your-region> \
  --instance-type g4dn.xlarge \
  --key-name my-key \
  --security-group-ids <sg-allowing-ssh-from-your-ip-only> \
  --block-device-mappings 'DeviceName=/dev/sda1,Ebs={VolumeSize=100,VolumeType=gp3}' \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=owner,Value=me},{Key=ttl,Value=2h}]'
```

Google Cloud equivalent:

```bash
gcloud compute instances create ai-lab-1 \
  --zone=us-central1-a --machine-type=n1-standard-4 \
  --accelerator=type=nvidia-tesla-t4,count=1 \
  --image-family=common-cu123-debian-11 --image-project=deeplearning-platform-release \
  --maintenance-policy=TERMINATE --boot-disk-size=100GB \
  --metadata=install-nvidia-driver=True
```

GPU VMs need `--maintenance-policy=TERMINATE` on Google Cloud because they can't be live-migrated. A new
account may also need a GPU quota increase first.

### Step 2 — Verify the GPU

```bash
ssh -i my-key.pem ubuntu@<public-ip>
nvidia-smi
```

Expected: one row showing `Tesla T4`, about 15 GB of memory, and a driver and CUDA version in the header.

### Step 3 — Prove the GPU is doing work

```python
import time, torch
print(torch.cuda.is_available(), torch.cuda.get_device_name(0))
for device in ["cpu", "cuda"]:
    a = torch.randn(4096, 4096, device=device)
    b = torch.randn(4096, 4096, device=device)
    torch.matmul(a, b)                       # warm-up
    if device == "cuda": torch.cuda.synchronize()
    t = time.time()
    for _ in range(10): torch.matmul(a, b)
    if device == "cuda": torch.cuda.synchronize()
    print(device, f"{(time.time() - t) / 10 * 1000:.1f} ms per matmul")
```

Expected: the GPU is roughly 10–50× faster than the CPU. `torch.cuda.synchronize()` is needed because
GPU calls are asynchronous. Without it you only time how long it took to *queue* the work.

### Step 4 — Stop paying

```bash
aws ec2 terminate-instances --instance-ids <id>       # or: gcloud compute instances delete ai-lab-1
```

A *stopped* instance still bills for its disk. Set a billing alert before your first GPU lab.

**Expected results:** `nvidia-smi` lists one Tesla T4 with about 15 GB of memory. The Step 3 matrix
multiply is roughly 10–50× faster on `cuda` than on `cpu`. After Step 4, the console lists no running or
stopped instances and no leftover disks. The total cost is under $1.

---

## FAANG deep-dive notes

**How big tech does it.** Hyperscale AI teams split infrastructure into a *training platform*, a few
very large, tightly coupled clusters scheduled as a shared resource, and a *serving platform*, many
loosely coupled replicas spread across regions. A capacity team plans GPUs 6–18 months ahead, because
accelerators are bought, not just rented. Every launch review asks for cost per request, p99 latency,
and the plan for when a region goes down.

**Staff review questions.**
- What limits this workload: compute, memory capacity, memory bandwidth, or the network?
- What does serving cost per 1,000 requests at today's traffic, and at 10×?
- Which layer owns each failure, and who gets paged?
- Where are the version pins (driver, CUDA, framework, model), and how are they upgraded?

**Interview question.** "Your company wants to launch an LLM assistant to 10M users. Walk me through the
infrastructure."

**Typical system-design prompt:** *Design the infrastructure for an LLM-powered feature: fine-tune an
open 8B model on company data, then serve it to 10M daily users with a p95 time-to-first-token under
1 second.*

**1. Clarify first:** How many users at peak, and how many tokens per reply? Is the latency target for
the first token or the whole reply? Must data stay in a region? Is the model fixed, or will it be retrained
every month? What is the budget?

**2. Back-of-envelope sizing:**
- Training state: 8B × 16 bytes ≈ 128 GB, so 2+ 80 GB GPUs with sharding. In practice, one 8-GPU node for a day.
- Serving weights: 8B × 2 bytes = 16 GB in fp16, so one GPU per replica fits the weights plus the KV cache.
- Peak load: ~1,750 requests/s × 500 tokens ≈ 875k tokens/s, so ~115 GPUs with 30% headroom (see Lecture 5).
- Decode speed limit at batch size 1: 3.35 TB/s ÷ 16 GB ≈ 200 tokens/s per sequence on an H100.
  Batching is what turns that into thousands of tokens per second per GPU.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Where to run | Hyperscaler (AWS, GCP, Azure) | GPU cloud or on-prem | Hyperscaler when you need IAM, data, and compliance next to the GPUs. On-prem when utilization stays above ~60% for years |
| Model size | One large model for everything | A router to small and large models | Route: most queries don't need the big model |
| Serving GPU | Fewer large GPUs (H100) | More small GPUs (L4) | Measure cost per 1M tokens at your latency target, not price per hour |
| Training cadence | Retrain often | Fine-tune rarely, use retrieval for freshness | Retrieval for facts that change. Fine-tuning for behavior and format |

**4. Follow-up questions with crisp answers:**
- *Why does serving usually cost more than training?* Training is a one-off bill. Serving is paid every
  hour and grows with traffic.
- *Why is LLM decode memory-bound?* Each new token reads every weight once. Bytes moved per token are large
  compared with the math done, so memory bandwidth sets the speed.
- *What happens when a region fails?* Traffic shifts to other regions, so each region needs spare capacity,
  or you accept slower responses during failover.

**Debug this (common onsite question):** "Our training job shows 30% GPU utilization. Why?"
1. Check whether the GPU is waiting on input: watch CPU usage of the data-loader workers and disk or
   network read throughput.
2. Check the step-time breakdown with a profiler: time in data loading compared with forward and backward.
3. Check communication: in multi-GPU jobs, slow gradient sync looks like idle GPUs.
4. Typical fix: more loader workers, prefetching, caching the dataset on local NVMe, and larger batches.

The lesson: low GPU utilization almost always means the GPU is waiting on something upstream. Find
what it's waiting for before you buy more GPUs.

**5. What separates senior from staff answers:** a senior engineer sizes the GPUs correctly. A staff
engineer also states the cost per request, the procurement lead time, the region-failure plan, how the
system changes at 10× traffic, and what *not* to build (for example, buying an API instead of hosting
a model when traffic is small).

**Red flags:**
- Picking a chip before naming the bottleneck.
- No serving cost estimate, only a training estimate.
- One region, no failover, no headroom.
- No checkpointing for multi-hour training runs.
- "We'll just use the latest versions" with no version pins.

---

## Quiz

<details><summary>1. Why are GPUs faster than CPUs for deep learning?</summary>
Neural networks are dominated by matrix multiplications, which are many independent multiply-adds. GPUs
have thousands of simple cores, Tensor Cores, and very high-bandwidth memory, so they can do that work in
parallel. CPUs have a few complex cores that are optimized for sequential, branching code.
</details>

<details><summary>2. Name two ways training infrastructure differs from inference infrastructure.</summary>
Any two of these: training is a throughput-oriented batch job, while inference is a latency-oriented
service. Training needs ~16 bytes per parameter, inference ~2 or less. Training is tightly coupled across
GPUs and needs a fast interconnect, while inference replicas are independent.
</details>

<details><summary>3. An LLM generates tokens slowly even though GPU compute utilization is low. What is the likely bottleneck?</summary>
Memory bandwidth. At small batch sizes, each token requires reading all the weights from HBM, so the GPU
waits on memory rather than compute. Batching more requests together raises the useful work done per byte
read.
</details>

<details><summary>4. Which layer would you check first if PyTorch says <code>CUDA not available</code> on a GPU VM?</summary>
System software (layer 2): the NVIDIA driver, and whether the installed PyTorch build matches the driver's
CUDA version. Run <code>nvidia-smi</code> first. If it fails, the problem is the driver, not PyTorch.
</details>

<details><summary>5. Why does serving often cost more than training over a year?</summary>
Training runs for a bounded time. Serving runs 24/7 with several replicas for redundancy and peak traffic,
so even cheaper GPUs add up over months.
</details>

<details><summary>6. Where does cloud lock-in mostly come from?</summary>
Software and data: proprietary APIs and managed services, chip-specific kernels (CUDA, Neuron), and the
cost of moving large datasets (data gravity). Hardware is the easy part to replace.
</details>

## Failure modes
- A GPU VM left running over a weekend: $100+ for a T4, thousands of dollars for 8×H100.
- PyTorch installed with the wrong CUDA build, so it silently runs on CPU. Always check `torch.cuda.is_available()`.
- Benchmarking without `torch.cuda.synchronize()`, which reports impossibly fast GPU times.
- Choosing a GPU by FLOPs when the workload is limited by memory capacity or bandwidth.

## Checklist
- [ ] You can explain CPU vs GPU vs TPU in one sentence each
- [ ] You can list three differences between training and inference infrastructure
- [ ] You can name the infrastructure layers and who owns each one
- [ ] You launched a GPU VM, ran `nvidia-smi` and a timed matmul, and terminated it
- [ ] You have a billing alert set up
