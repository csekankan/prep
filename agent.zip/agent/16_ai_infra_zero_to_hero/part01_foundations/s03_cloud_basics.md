# Section 3 — Cloud Infrastructure Basics

> Lectures 15–21 • Assessments: recommend a cloud architecture for AI inference, quiz
> **After this section you can:** explain the cloud building blocks AI workloads use, pick a CPU or GPU
> instance from a workload's numbers, design a safe VPC, choose the right storage type, launch GPU
> instances on AWS and Google Cloud, and compare clouds on cost *per unit of work*, not cost per hour.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 15 | Introduction to cloud for AI workloads | Rent GPUs by the hour, pay for what you use, and design for the bill |
| 16 | Compute instances: CPU vs GPU | Pick by the bottleneck: memory to hold the model, then throughput per dollar |
| 17 | Networking: VPCs, firewalls, load balancers | Private by default; only the load balancer faces the internet |
| 18 | Cloud storage: object, block, file | Object for datasets and models, block for a VM's disk, file for shared folders |
| 19 | Hands-on: AWS EC2 for AI | Deep Learning AMI, `g`/`p` instance families, spot, IAM roles |
| 20 | Hands-on: Google Cloud GPU instances | Attach a GPU to a VM, quotas, `TERMINATE` maintenance policy |
| 21 | Lab: compare cost and performance across clouds | Measure throughput, then compute cost per 1M predictions |

```mermaid
flowchart TB
  INTERNET((Internet)) --> LB[Load balancer<br/>public subnet]
  subgraph VPC["VPC 10.0.0.0/16 (your private network in the cloud)"]
    LB --> GPU1[GPU VM<br/>private subnet]
    LB --> GPU2[GPU VM<br/>private subnet]
    GPU1 & GPU2 --> EBS[(Block disk<br/>per VM)]
    GPU1 & GPU2 --> EFS[(Shared file system)]
    GPU1 & GPU2 --> NAT[NAT gateway<br/>outbound only]
  end
  GPU1 & GPU2 -->|private endpoint| S3[(Object storage<br/>S3 / GCS: data + models)]
  IAM[IAM role] -.grants access.-> GPU1 & GPU2
```

**How to read it:** this is the shape of almost every cloud AI service. Traffic enters through one load
balancer. GPU machines sit in a private network where nobody can reach them directly. Models and data
live in object storage, and IAM decides which machines may read them. The lectures below explain each box.

---

## Lecture 15 — Introduction to cloud for AI workloads

**Why it matters.** A single 8×H100 server costs about $250,000–$400,000 to buy and months to deliver.
The cloud rents you the same machine in minutes, by the hour. That changes how teams experiment, and it
also creates a new risk: a bill that grows as fast as your ambition.

**In plain words.** Owning servers is like owning a car. The cloud is like a taxi or car-rental app: no
up-front cost, available right away, perfect for occasional trips, and expensive if you use it all day,
every day.

**Architecture: the service models.**

```mermaid
flowchart LR
  subgraph IAAS["IaaS: you rent machines"]
    I1[EC2 / Compute Engine VM]
  end
  subgraph CAAS["Containers / Kubernetes"]
    K1[EKS / GKE / AKS]
  end
  subgraph PAAS["Managed ML platform"]
    P1[SageMaker / Vertex AI / Azure ML]
  end
  subgraph SAAS["Model as an API"]
    S1[Bedrock / Vertex Gemini / OpenAI API]
  end
  IAAS -->|more control,<br/>more work| CAAS --> PAAS -->|less control,<br/>less work| SAAS
```

**How to read it:** moving right, the provider takes over more of the work (patching, scaling, serving)
and you give up control and portability. Most teams use several columns at once.

**Core ideas.**
- **Elasticity:** scale from 0 to 64 GPUs for a training run, then back to 0.
- **Pricing models:**

| Model | Discount vs on-demand | Catch | Use for |
|---|---|---|---|
| On-demand | — | Most expensive | Experiments, unpredictable work |
| Spot / preemptible | 60–90% off | Can be taken back with ~30 s–2 min notice | Training with checkpoints, batch inference |
| Reserved / committed use | 30–60% off | You pay for 1–3 years whether you use it or not | Steady inference base load |
| Savings plans | 20–50% off | Commit to a dollar amount per hour | Mixed fleets |

- **Shared responsibility:** the provider secures the data center and hypervisor. *You* secure your
  network rules, IAM, data, and what runs inside your VMs.

**Example.** A team trains a model for 3 days every month on 8 GPUs at $4 per GPU-hour.
On-demand: 8 × 72 h × $4 = **$2,304/month**. On spot at 70% off, with checkpoints so a preemption only
loses ~15 minutes: about **$700/month**. Buying the server would only pay off if it stayed busy most of
the month.

**Senior note.** In the cloud, **architecture is cost**. Every design decision (instance type, region,
where data lives, whether VMs scale to zero) shows up on the bill. Section 12 goes deep on cost.

---

## Lecture 16 — Compute instances: choosing CPU vs GPU

**Why it matters.** Instance choice is the biggest single line on most AI bills, and the "biggest GPU"
is rarely the cheapest way to get the work done.

**In plain words.** Choosing an instance is like choosing a delivery vehicle. A scooter (CPU) is perfect
for small parcels in the city. A van (T4/L4) carries more. A truck (H100) is only worth it if you
actually fill it. A half-empty truck is the most expensive way to deliver a parcel.

**Architecture: a decision path.**

```mermaid
flowchart TB
  START{Workload} -->|classical ML, ETL,<br/>small models| CPUI["CPU instance<br/>(c7i, n2, c3)"]
  START -->|deep learning| MEM{"Model memory<br/>(weights + KV cache /<br/>activations) in GB?"}
  MEM -->|"< 16 GB"| SMALL["T4 16 GB / L4 24 GB<br/>(g4dn, g6, g2)"]
  MEM -->|"16–80 GB"| MID["A10G 24 GB, L40S 48 GB,<br/>A100 / H100 80 GB"]
  MEM -->|"> 80 GB"| MULTI["multi-GPU: 4–8× A100/H100<br/>(p4d, p5, a3) + NVLink"]
  SMALL & MID & MULTI --> COST{"Measure throughput,<br/>pick the lowest<br/>cost per unit of work"}
```

**How to read it:** first ask whether you need a GPU at all. Then let memory decide the *smallest* GPU
that fits. Only then compare a few candidates by cost per unit of work.

**Core ideas: reading instance names.**

| Cloud | Name | Meaning |
|---|---|---|
| AWS | `g4dn.xlarge` | `g` = graphics/inference GPU family, `4` = generation, `dn` = local NVMe + network boost, `xlarge` = size |
| AWS | `p5.48xlarge` | `p` = training-class GPUs (8× H100) |
| Google Cloud | `g2-standard-8` | G2 = L4 GPUs, 8 vCPUs |
| Google Cloud | `a3-highgpu-8g` | A3 = H100, 8 GPUs |
| Azure | `Standard_NC24ads_A100_v4` | NC = compute GPU, A100 |

| GPU | Memory | Typical use | Rough on-demand price per GPU-hour |
|---|---|---|---|
| T4 | 16 GB | Cheap inference, small models | $0.35–0.55 |
| L4 | 24 GB | Efficient inference, video | $0.70–1.00 |
| A10G | 24 GB | Inference, small fine-tunes | $1.00–1.50 |
| L40S | 48 GB | Inference, mid-size fine-tunes | $1.50–2.50 |
| A100 80 GB | 80 GB | Training and large-model inference | $2.50–4.50 |
| H100 80 GB | 80 GB | Large-scale training and LLM serving | $3.00–12.00 (varies widely) |

Prices vary by region, provider, and month. Always check the current pricing page.

**Example.** Serving a 7B LLM in fp16 needs ~14 GB for weights plus ~6 GB for the KV cache = ~20 GB.
That rules out the T4 and fits on an L4 or A10G (24 GB). An H100 would be ~3× faster but ~5× more
expensive per hour, so per token the L4 wins, *unless* the latency target can only be met by the H100.

**Senior note.** Don't forget the CPU and RAM attached to the GPU. A GPU instance with too few vCPUs
can't decode images or tokenize text fast enough, and the GPU sits idle waiting.

---

## Lecture 17 — Networking basics: VPCs, firewalls, load balancers

**Why it matters.** Most cloud security incidents in AI are network mistakes: a Jupyter notebook or
model API exposed to the internet with no authentication, or a training bucket readable by anyone.

**In plain words.** A VPC is a gated office campus. Subnets are buildings: the *public* building has a
reception desk facing the street (the load balancer), and the *private* buildings have no street door at
all. Security groups are the badge readers on each door. A NAT gateway is a mailroom that lets people
inside send letters out, but never lets strangers walk in.

**Architecture: a safe inference network.**

```mermaid
flowchart TB
  USER((Users)) -->|HTTPS 443| ALB
  subgraph VPC["VPC 10.0.0.0/16"]
    subgraph PUB["Public subnets (2 zones)"]
      ALB["Application load balancer<br/>SG: allow 443 from 0.0.0.0/0"]
      NATG[NAT gateway]
    end
    subgraph PRIV["Private subnets (2 zones)"]
      APP1["GPU VM zone a<br/>SG: allow 8000 from ALB SG only"]
      APP2["GPU VM zone b<br/>SG: allow 8000 from ALB SG only"]
    end
    VPCE[VPC endpoint for S3]
  end
  ALB --> APP1 & APP2
  APP1 & APP2 -->|pip, model hub| NATG --> INTERNET((Internet))
  APP1 & APP2 --> VPCE --> S3B[(S3 bucket)]
  ADMIN[Engineer] -->|SSM / IAP, no open SSH port| APP1
```

**How to read it:** users can reach only the load balancer. The GPU VMs accept traffic on port 8000
*only from the load balancer's security group*. They reach the internet outbound through NAT, and reach
S3 through a private endpoint that never leaves the cloud network. Engineers log in through a managed
session tool instead of an open SSH port.

**Core ideas.**

| Concept | AWS | Google Cloud | What it does |
|---|---|---|---|
| Private network | VPC | VPC network | Your isolated IP range |
| Subnet | Subnet (per zone) | Subnet (per region) | A slice of the range |
| Firewall | Security group (stateful, per VM) + NACL | Firewall rules (by tag or service account) | Allow or deny ports and sources |
| Outbound-only internet | NAT gateway | Cloud NAT | Private VMs can download packages |
| Load balancer | ALB (HTTP), NLB (TCP/gRPC) | Cloud Load Balancing | Spreads traffic, health-checks backends |
| Private access to storage | VPC endpoint | Private Google Access | Reach S3/GCS without the internet |

**Example.** A security group for the GPU VMs, written as Terraform:

```hcl
resource "aws_security_group" "model_api" {
  name   = "model-api"
  vpc_id = aws_vpc.main.id
  ingress {
    from_port       = 8000
    to_port         = 8000
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]   # only the load balancer, never 0.0.0.0/0
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
```

**Senior note.** NAT gateways charge per GB processed. A cluster that downloads a 140 GB model from the
internet on every pod start can spend more on NAT than on GPUs. Cache models in S3/GCS and read them
through a VPC endpoint.

---

## Lecture 18 — Cloud storage: object, block, and file systems

**Why it matters.** Storage choice decides how fast GPUs get their data, how much you pay to keep it, and
whether a checkpoint survives a crash.

**In plain words.** *Object storage* is a giant warehouse: unlimited space, cheap, very durable, and you
fetch whole boxes by their label. *Block storage* is the hard drive inside one computer: fast, but only
that computer can use it. *File storage* is a shared network folder: many computers can open the same
files at once, at a higher price.

**Architecture: where each type fits in an AI system.**

```mermaid
flowchart LR
  subgraph OBJ["Object storage (S3, GCS, Azure Blob)"]
    RAW[(raw data)] --- DS[(training datasets<br/>Parquet / WebDataset shards)] --- MODELS[(model artifacts,<br/>checkpoints)]
  end
  subgraph BLK["Block storage (EBS, Persistent Disk)"]
    BOOT[(VM boot disk)] --- SCRATCH[(local cache<br/>for one VM)]
  end
  subgraph FILE["File storage (EFS, Filestore, FSx for Lustre)"]
    SHARED2[(shared folder for<br/>many training nodes)]
  end
  DS -->|stream or prefetch| TRAINING[Training nodes]
  SHARED2 --> TRAINING
  TRAINING -->|checkpoint| MODELS
  MODELS -->|load at startup| SERVING[Inference VMs]
  BOOT --- SERVING
```

**How to read it:** object storage is the source of truth for data and models. Block disks are private
working space for one machine. A shared file system sits next to the training cluster when many nodes
need the same files with normal file paths.

| | Object | Block | File |
|---|---|---|---|
| Examples | S3, GCS, Azure Blob | EBS, Persistent Disk, Azure Disk | EFS, Filestore, FSx for Lustre |
| Access | HTTP API (`GET`/`PUT` whole objects) | Mounted disk, one VM (mostly) | Mounted folder, many VMs |
| Durability | Very high (11 nines) | Replicated in one zone | Regional or zonal |
| Price per GB-month (rough) | $0.02 (less for cold tiers) | $0.08–0.12 | $0.10–0.30 |
| Best for | Datasets, models, checkpoints, logs | OS disks, databases, scratch | Shared training data, home directories |

**Example.** A vision team kept 200 TB of images on EFS so every node could read them: about $60,000 per
month. Moving them to S3 as 1 GB WebDataset shards, streamed during training with a small local NVMe
cache, cost about $4,600 per month, and training got *faster* because large sequential reads beat
millions of small file opens.

**Senior note.** Millions of tiny files are slow on every storage type. Pack them into large shards
(Parquet, TFRecord, WebDataset tar files). Section 6 covers this in depth.

---

## Lecture 19 — Hands-on with AWS EC2 for AI

**In plain words.** EC2 is AWS's computer-rental counter. An AMI is the pre-installed software image you
start from. An IAM role is the ID badge the machine wears, so it can open S3 without anyone typing a
password into it.

**Architecture: what you launch.**

```mermaid
flowchart LR
  AMI["Deep Learning AMI<br/>(Ubuntu + driver + CUDA + PyTorch)"] --> EC2["EC2 g5.xlarge<br/>1× A10G 24 GB"]
  ROLE["IAM instance profile:<br/>read s3://models-bucket only"] --> EC2
  SG2["Security group:<br/>SSH from my IP only"] --> EC2
  EC2 --> EBS2[(gp3 EBS 200 GB)]
  EC2 -->|aws s3 cp, no keys on disk| S3M[(s3://models-bucket)]
```

**How to read it:** the AMI gives you working drivers. The IAM role gives the VM *temporary* credentials
that rotate automatically. The security group limits who can connect.

**Steps.**

```bash
# 1. Find the latest Deep Learning AMI for your region
aws ec2 describe-images --owners amazon \
  --filters "Name=name,Values=Deep Learning OSS Nvidia Driver AMI GPU PyTorch*Ubuntu 22.04*" \
  --query 'sort_by(Images,&CreationDate)[-1].ImageId' --output text

# 2. Launch it with a role instead of access keys (spot shown; drop --instance-market-options for on-demand)
aws ec2 run-instances --image-id <ami> --instance-type g5.xlarge \
  --iam-instance-profile Name=model-reader \
  --instance-market-options 'MarketType=spot' \
  --security-group-ids <sg> --key-name my-key

# 3. On the VM: the role works without any keys
aws s3 ls s3://models-bucket/
nvidia-smi
```

**Example.** A new engineer copied their personal access keys into `~/.aws/credentials` on a shared GPU
VM. Anyone with SSH access could now act as that engineer. With an instance role, there are no long-lived
keys on disk to steal.

**Senior note.** Check your **GPU quota** (Service Quotas → "Running On-Demand G and VT instances") before
a deadline. New accounts often start at zero GPUs.

---

## Lecture 20 — Hands-on with Google Cloud GPU instances

**In plain words.** On Google Cloud you rent a normal VM and "plug in" a GPU card as an option (except on
the newer G2 and A3 families, where the GPU is part of the machine type).

**Architecture.**

```mermaid
flowchart LR
  IMG["Deep Learning VM image<br/>(common-cu123)"] --> VM2["Compute Engine VM<br/>g2-standard-8 + 1× L4"]
  SA["Service account:<br/>roles/storage.objectViewer"] --> VM2
  FW["Firewall rule:<br/>SSH via IAP only"] --> VM2
  POL["maintenance-policy=TERMINATE<br/>(GPU VMs can't live-migrate)"] --> VM2
  VM2 -->|gsutil / gcloud storage| GCS[(gs://models-bucket)]
```

**How to read it:** same pattern as AWS: a ready-made image, an identity (a *service account* instead of
an IAM role), a firewall, and one GPU-specific rule, `TERMINATE`, because Google can't move a running GPU
VM to another host during maintenance.

```bash
gcloud compute instances create l4-box \
  --zone=us-central1-a --machine-type=g2-standard-8 \
  --image-family=common-cu123-ubuntu-2204 --image-project=deeplearning-platform-release \
  --maintenance-policy=TERMINATE --boot-disk-size=200GB \
  --service-account=model-reader@<project>.iam.gserviceaccount.com --scopes=cloud-platform \
  --provisioning-model=SPOT          # remove for on-demand

gcloud compute ssh l4-box --tunnel-through-iap
gcloud compute regions describe us-central1 --format="table(quotas.metric,quotas.limit)" | grep -i gpu
```

| AWS term | Google Cloud term |
|---|---|
| AMI | Image / image family |
| Instance profile (IAM role) | Service account |
| Security group | Firewall rule (by network tag or service account) |
| Spot instance | Spot VM |
| Session Manager | IAP TCP forwarding |

**Example.** A launch fails with `ZONE_RESOURCE_POOL_EXHAUSTED`: the zone has no free L4s right now.
The fix is to retry in another zone of the same region, or use a managed instance group that tries
several zones for you. Popular GPUs are often out of stock in popular zones.

---

## Lecture 21 — Lab: compare cost and performance across clouds

**Goal:** decide which instance to use for an inference service by measuring **cost per 1 million
predictions**, not price per hour.

**In plain words.** A cheaper taxi isn't cheaper if it takes three times as long. Compare the price of
the whole trip, not the price per minute.

**Architecture: the method.**

```mermaid
flowchart LR
  A[Same model,<br/>same container] --> B[Run on candidate<br/>instances]
  B --> C["Measure throughput<br/>(predictions/sec at<br/>your latency target)"]
  C --> D["cost per 1M =<br/>price per hour ÷ (throughput × 3600) × 1,000,000"]
  D --> E[Check latency SLO<br/>and availability]
  E --> F[Pick cheapest that<br/>meets the SLO]
```

**How to read it:** keep everything identical except the hardware, measure throughput *while meeting
your latency target*, then convert to a cost per unit of work.

**Step 1 — measure.** Run the same benchmark on each instance (Section 7 covers benchmarking properly):

```bash
# Inside the model container on each VM; reports throughput and p95 latency
python bench.py --batch-size 8 --duration 120 --p95-target-ms 100
```

**Step 2 — compute and compare** with the exercise script, which comes with sample measurements:

```bash
python3 exercises/s03_cloud_cost_compare.py
python3 exercises/s03_cloud_cost_compare.py --monthly-predictions 500000000 --p95-slo-ms 80
```

**Example result (sample numbers).** The H100 has the highest price per hour but the *lowest* cost per
1M predictions because its throughput is so much higher, *if* you have enough traffic to keep it busy.
At low traffic, a smaller GPU wins because you pay for idle time on the big one. The script prints both
views.

---

## Assessment — Recommend a cloud architecture for AI inference

**Scenario.** An e-commerce company wants product-image tagging (a ResNet-50-sized model) as an API.
Traffic averages 300 requests per second, peaks at 1,200 during sales, and the p95 latency target is
100 ms. Images contain no personal data. The team is already on AWS.

**Your recommendation should cover:** compute, network, storage, scaling, security, and estimated cost.

**Model answer.**

```mermaid
flowchart TB
  CL((Clients)) --> CF[CloudFront + WAF]
  CF --> ALB2[ALB, 2 AZs]
  subgraph VPC2["VPC, private subnets in 2 AZs"]
    ALB2 --> ASG["Auto Scaling group / EKS node group<br/>g6.xlarge (L4), min 2, max 8<br/>scale on GPU util / requests per target"]
    ASG --> CACHE[(ElastiCache:<br/>results for repeat images)]
  end
  ASG -->|VPC endpoint| S3C[(S3: model artifacts,<br/>versioned)]
  ASG --> CW[CloudWatch / Prometheus:<br/>p95, errors, GPU util]
  IAM2[IAM role: read model bucket only] -.-> ASG
```

| Decision | Choice | Why |
|---|---|---|
| Compute | L4 GPUs (`g6.xlarge`), not H100 | The model is small; L4 gives the best cost per prediction and meets 100 ms p95 |
| Capacity | Min 2 (one per zone), autoscale to 8 | Survives a zone failure; one L4 handles roughly 300–500 req/s with dynamic batching on this model, measured in the lab |
| Purchasing | Reserved/savings plan for the 2 base nodes, on-demand for burst | Base load is steady; spot is risky for a latency SLO unless mixed with on-demand |
| Network | Only the ALB is public; VMs in private subnets; S3 via VPC endpoint | Smallest attack surface; no NAT charges for model downloads |
| Storage | Versioned S3 bucket for models; nothing stateful on VMs | VMs are disposable, so autoscaling and replacement are safe |
| Caching | Hash the image bytes and cache results | Sale traffic repeats the same product images |
| Security | WAF, TLS at the ALB, IAM role per service, no SSH (Session Manager) | Least privilege, no long-lived keys |
| Observability | p95 latency, error rate, GPU utilization, queue depth | Scale on what users feel, not only on CPU |

Run `python3 exercises/s03_cloud_cost_compare.py` to reproduce the cost comparison behind the instance
choice.

---

## Quiz

<details><summary>1. Instance A costs $1/hour and does 500 predictions/sec. Instance B costs $4/hour and does 2,500/sec. Which is cheaper per prediction?</summary>
A: $1 ÷ (500 × 3600) × 1M ≈ $0.56 per 1M. B: $4 ÷ (2,500 × 3600) × 1M ≈ $0.44 per 1M. B is cheaper per
prediction, but only if you have enough traffic to keep it busy.
</details>

<details><summary>2. Why should GPU VMs sit in private subnets?</summary>
So they can't be reached directly from the internet. Only the load balancer is public, and the VMs'
firewall allows traffic only from it.
</details>

<details><summary>3. Which storage type for: (a) a 50 TB training dataset, (b) a VM's OS, (c) a folder many training nodes read?</summary>
(a) Object storage, ideally as large shards. (b) Block storage. (c) File storage, such as EFS, Filestore,
or FSx for Lustre for high throughput.
</details>

<details><summary>4. When is spot a good fit, and when is it a bad one?</summary>
Good: training with frequent checkpoints, and batch inference, which can retry. Bad: latency-critical
serving with no on-demand fallback, because capacity can be reclaimed with very short notice.
</details>

<details><summary>5. Why use an IAM role or service account instead of access keys on a VM?</summary>
The credentials are temporary and rotate automatically, and nothing long-lived sits on disk to be stolen
or leaked. Access can also be scoped to exactly the buckets the VM needs.
</details>

<details><summary>6. Why does Google Cloud require <code>--maintenance-policy=TERMINATE</code> for GPU VMs?</summary>
VMs with attached GPUs can't be live-migrated to another host during maintenance, so they have to be
stopped instead.
</details>

## Failure modes
- A model API or Jupyter exposed on `0.0.0.0/0` with no authentication.
- GPU quota of zero discovered on launch day.
- NAT gateway bills exploding because every pod downloads weights from the internet.
- Choosing by price per hour instead of cost per unit of work, or forgetting idle time at low traffic.
- Training data on an expensive shared file system when object storage plus a cache would do.

## Checklist
- [ ] You can draw a VPC with public and private subnets, a load balancer, NAT, and a storage endpoint
- [ ] You can name the right storage type for datasets, OS disks, and shared folders
- [ ] You launched a GPU VM on AWS or Google Cloud with a role or service account, not keys
- [ ] You compared at least two instance types by cost per 1M predictions
