# Section 3 — Cloud Infrastructure Basics

> Lectures 15–21 • Assessments: recommend a cloud architecture for AI inference, quiz
> **After this section you can:** explain the cloud building blocks AI workloads use, pick a CPU or GPU
> instance from a workload's numbers, design a safe VPC, choose the right storage type, launch GPU
> instances on AWS and Google Cloud, and compare clouds on cost *per unit of work*, not cost per hour.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 15 | Introduction to cloud for AI workloads | Rent GPUs by the hour, pay for what you use, and design for the bill |
| 16 | Compute instances: CPU vs GPU | Pick by the bottleneck: memory to hold the model, then throughput per dollar |
| 17 | Networking: VPCs, firewalls, load balancers | Private by default; only the load balancer faces the internet |
| 18 | Cloud storage: object, block, file | Object for datasets and models, block for a VM's disk, file for shared folders |
| 19 | Hands-on: AWS EC2 for AI | Deep Learning AMI, `g`/`p` instance families, spot, IAM roles |
| 20 | Hands-on: Google Cloud GPU instances | Attach a GPU to a VM, quotas, `TERMINATE` maintenance policy |
| 21 | Lab: compare cost and performance across clouds | Measure throughput, then compute cost per 1M predictions |

```mermaid
flowchart TB
  INTERNET((Internet)) --> LB[Load balancer<br/>public subnet]
  subgraph VPC["VPC 10.0.0.0/16 (your private network in the cloud)"]
    LB --> GPU1[GPU VM<br/>private subnet]
    LB --> GPU2[GPU VM<br/>private subnet]
    GPU1 & GPU2 --> EBS[(Block disk<br/>per VM)]
    GPU1 & GPU2 --> EFS[(Shared file system)]
    GPU1 & GPU2 --> NAT[NAT gateway<br/>outbound only]
  end
  GPU1 & GPU2 -->|private endpoint| S3[(Object storage<br/>S3 / GCS: data + models)]
  IAM[IAM role] -.grants access.-> GPU1 & GPU2
```

**How to read it:** this is the shape of almost every cloud AI service. Traffic enters through one load
balancer. GPU machines sit in a private network where nobody can reach them directly. Models and data
live in object storage, and IAM decides which machines may read them. The lectures below explain each box.

**Terms in this diagram** (each is covered in depth in the lecture named):
- **VPC 10.0.0.0/16**: a virtual private cloud, your own isolated network inside the cloud. `10.0.0.0/16` is its
  address range, 65,536 private IP addresses (Lecture 17).
- **Public subnet** and **private subnet**: a subnet is a slice of the VPC's addresses. Machines in a public
  subnet can be reached from the internet. Machines in a private subnet can't, which is where GPU servers belong.
- **Block disk per VM**: a network disk attached to one VM, like its hard drive (EBS on AWS, Lecture 18).
- **Shared file system**: a folder many VMs mount at once (EFS on AWS, Lecture 18).
- **NAT gateway, outbound only**: lets private machines start connections to the internet (to download packages)
  while nothing on the internet can start a connection to them.
- **Private endpoint**: a private door from the VPC to a cloud service such as S3, so that traffic never crosses
  the public internet.
- **S3 / GCS**: object storage on AWS (Simple Storage Service) and Google Cloud (Cloud Storage), the durable home
  of datasets and model files.
- **IAM role**: a named set of cloud permissions a machine can use, such as "read the models bucket", with no
  password stored on the machine (Lecture 19).

---

## Lecture 15 — Introduction to cloud for AI workloads

**Why it matters.** A single 8×H100 server costs about $250,000–$400,000 to buy and months to deliver.
The cloud rents you the same machine in minutes, by the hour. That changes how teams experiment, and it
also creates a new risk: a bill that grows as fast as your ambition.

**In plain words.** Owning servers is like owning a car. The cloud is like a taxi or car-rental app: no
up-front cost, available right away, perfect for occasional trips, and expensive if you use it all day,
every day.

**Architecture: the service models.**

```mermaid
flowchart LR
  subgraph IAAS["IaaS: you rent machines"]
    I1[EC2 / Compute Engine VM]
  end
  subgraph CAAS["Containers / Kubernetes"]
    K1[EKS / GKE / AKS]
  end
  subgraph PAAS["Managed ML platform"]
    P1[SageMaker / Vertex AI / Azure ML]
  end
  subgraph SAAS["Model as an API"]
    S1[Bedrock / Vertex Gemini / OpenAI API]
  end
  IAAS -->|more control,<br/>more work| CAAS --> PAAS -->|less control,<br/>less work| SAAS
```

**How to read it:** moving right, the provider takes over more of the work (patching, scaling, serving)
and you give up control and portability. Most teams use several columns at once.

**Terms in this diagram.**
- **IaaS** (infrastructure as a service): you rent raw VMs and manage everything on them. **EC2** is AWS's VM
  service, and **Compute Engine** is Google's.
- **Containers / Kubernetes**: the cloud runs the Kubernetes control plane for you, and you run containers on it.
  **EKS** (AWS Elastic Kubernetes Service), **GKE** (Google Kubernetes Engine), and **AKS** (Azure Kubernetes
  Service) are the managed versions (Section 5).
- **Managed ML platform** (a kind of PaaS, platform as a service): the cloud runs training jobs and model
  endpoints for you. Examples are **SageMaker** (AWS), **Vertex AI** (Google), and **Azure ML**.
- **Model as an API** (a kind of SaaS, software as a service): you don't run the model at all, you just send
  requests and pay per token. Examples are **Bedrock** (AWS's hosted foundation models), **Gemini** on Vertex AI,
  and the **OpenAI API**.
- **Portability**: how easily you could move to another cloud. It drops as you move right, because managed
  services differ between providers.

**Core ideas.**
- **Elasticity:** scale from 0 to 64 GPUs for a training run, then back to 0.
- **Pricing models:**

| Model | Discount vs on-demand | Catch | Use for |
|---|---|---|---|
| On-demand | — | Most expensive | Experiments, unpredictable work |
| Spot / preemptible | 60–90% off | Can be taken back with ~30 s–2 min notice | Training with checkpoints, batch inference |
| Reserved / committed use | 30–60% off | You pay for 1–3 years whether you use it or not | Steady inference base load |
| Savings plans | 20–50% off | Commit to a dollar amount per hour | Mixed fleets |

- **Shared responsibility:** the provider secures the data center and hypervisor. *You* secure your
  network rules, IAM, data, and what runs inside your VMs.

**Example.** A team trains a model for 3 days every month on 8 GPUs at $4 per GPU-hour.
On-demand: 8 × 72 h × $4 = **$2,304/month**. On spot at 70% off, with checkpoints so a preemption only
loses ~15 minutes: about **$700/month**. Buying the server would only pay off if it stayed busy most of
the month.

**Senior note.** In the cloud, **architecture is cost**. Every design decision (instance type, region,
where data lives, whether VMs scale to zero) shows up on the bill. Section 12 goes deep on cost.

---

## Lecture 16 — Compute instances: choosing CPU vs GPU

**Why it matters.** Instance choice is the biggest single line on most AI bills, and the "biggest GPU"
is rarely the cheapest way to get the work done.

**In plain words.** Choosing an instance is like choosing a delivery vehicle. A scooter (CPU) is perfect
for small parcels in the city. A van (T4/L4) carries more. A truck (H100) is only worth it if you
actually fill it. A half-empty truck is the most expensive way to deliver a parcel.

**Architecture: a decision path.**

```mermaid
flowchart TB
  START{Workload} -->|classical ML, ETL,<br/>small models| CPUI["CPU instance<br/>(c7i, n2, c3)"]
  START -->|deep learning| MEM{"Model memory<br/>(weights + KV cache /<br/>activations) in GB?"}
  MEM -->|"< 16 GB"| SMALL["T4 16 GB / L4 24 GB<br/>(g4dn, g6, g2)"]
  MEM -->|"16–80 GB"| MID["A10G 24 GB, L40S 48 GB,<br/>A100 / H100 80 GB"]
  MEM -->|"> 80 GB"| MULTI["multi-GPU: 4–8× A100/H100<br/>(p4d, p5, a3) + NVLink"]
  SMALL & MID & MULTI --> COST{"Measure throughput,<br/>pick the lowest<br/>cost per unit of work"}
```

**How to read it:** first ask whether you need a GPU at all. Then let memory decide the *smallest* GPU
that fits. Only then compare a few candidates by cost per unit of work.

**Terms in this diagram.**
- **Classical ML, ETL**: classical ML means models like gradient-boosted trees and linear models, which run well
  on CPUs. **ETL** (extract, transform, load) is data-processing work: reading raw data, cleaning it, and writing
  it somewhere useful.
- **c7i, n2, c3**: CPU-only instance families. `c7i` is AWS, and `n2` and `c3` are Google Cloud. Names are
  decoded in the table below.
- **Weights + KV cache / activations**: what must fit in GPU memory. **Weights** are the model's learned numbers.
  The **KV cache** is the memory a language model keeps per request so it doesn't recompute earlier tokens.
  **Activations** are intermediate results saved during training for the backward pass (Section 7).
- **T4, L4, A10G, L40S, A100, H100**: NVIDIA GPU models, roughly from smallest and cheapest to largest. The GB
  number is each GPU's memory. **g4dn, g6, g2, p4d, p5, a3** are the instance families that contain them.
- **Multi-GPU + NVLink**: a model too big for one GPU is split across 4–8 GPUs in one server. **NVLink** is
  NVIDIA's very fast direct link between GPUs, many times faster than the normal PCIe bus, so they can share
  the work efficiently (Section 7).
- **Throughput**: how much work per second, for example predictions per second at your latency target.

**Core ideas: reading instance names.**

| Cloud | Name | Meaning |
|---|---|---|
| AWS | `g4dn.xlarge` | `g` = graphics/inference GPU family, `4` = generation, `dn` = local NVMe + network boost, `xlarge` = size |
| AWS | `p5.48xlarge` | `p` = training-class GPUs (8× H100) |
| Google Cloud | `g2-standard-8` | G2 = L4 GPUs, 8 vCPUs |
| Google Cloud | `a3-highgpu-8g` | A3 = H100, 8 GPUs |
| Azure | `Standard_NC24ads_A100_v4` | NC = compute GPU, A100 |

| GPU | Memory | Typical use | Rough on-demand price per GPU-hour |
|---|---|---|---|
| T4 | 16 GB | Cheap inference, small models | $0.35–0.55 |
| L4 | 24 GB | Efficient inference, video | $0.70–1.00 |
| A10G | 24 GB | Inference, small fine-tunes | $1.00–1.50 |
| L40S | 48 GB | Inference, mid-size fine-tunes | $1.50–2.50 |
| A100 80 GB | 80 GB | Training and large-model inference | $2.50–4.50 |
| H100 80 GB | 80 GB | Large-scale training and LLM serving | $3.00–12.00 (varies widely) |

Prices vary by region, provider, and month. Always check the current pricing page.

**Example.** Serving a 7B LLM in fp16 needs ~14 GB for weights plus ~6 GB for the KV cache = ~20 GB.
That rules out the T4 and fits on an L4 or A10G (24 GB). An H100 would be ~3× faster but ~5× more
expensive per hour, so per token the L4 wins, *unless* the latency target can only be met by the H100.

**Senior note.** Don't forget the CPU and RAM attached to the GPU. A GPU instance with too few vCPUs
can't decode images or tokenize text fast enough, and the GPU sits idle waiting.

---

## Lecture 17 — Networking basics: VPCs, firewalls, load balancers

**Why it matters.** Most cloud security incidents in AI are network mistakes: a Jupyter notebook or
model API exposed to the internet with no authentication, or a training bucket readable by anyone.

**In plain words.** A VPC is a gated office campus. Subnets are buildings: the *public* building has a
reception desk facing the street (the load balancer), and the *private* buildings have no street door at
all. Security groups are the badge readers on each door. A NAT gateway is a mailroom that lets people
inside send letters out, but never lets strangers walk in.

**Architecture: a safe inference network.**

```mermaid
flowchart TB
  USER((Users)) -->|HTTPS 443| ALB
  subgraph VPC["VPC 10.0.0.0/16"]
    subgraph PUB["Public subnets (2 zones)"]
      ALB["Application load balancer<br/>SG: allow 443 from 0.0.0.0/0"]
      NATG[NAT gateway]
    end
    subgraph PRIV["Private subnets (2 zones)"]
      APP1["GPU VM zone a<br/>SG: allow 8000 from ALB SG only"]
      APP2["GPU VM zone b<br/>SG: allow 8000 from ALB SG only"]
    end
    VPCE[VPC endpoint for S3]
  end
  ALB --> APP1 & APP2
  APP1 & APP2 -->|pip, model hub| NATG --> INTERNET((Internet))
  APP1 & APP2 --> VPCE --> S3B[(S3 bucket)]
  ADMIN[Engineer] -->|SSM / IAP, no open SSH port| APP1
```

**How to read it:** users can reach only the load balancer. The GPU VMs accept traffic on port 8000
*only from the load balancer's security group*. They reach the internet outbound through NAT, and reach
S3 through a private endpoint that never leaves the cloud network. Engineers log in through a managed
session tool instead of an open SSH port.

**Terms in this diagram.**
- **HTTPS 443**: encrypted web traffic, which uses network port 443.
- **Application load balancer (ALB)**: AWS's HTTP-aware load balancer. It ends the HTTPS connection and spreads
  requests across healthy servers.
- **SG** (security group): a firewall attached to a resource. `allow 443 from 0.0.0.0/0` means "port 443 from any
  IPv4 address" (`0.0.0.0/0` is the whole internet). `allow 8000 from ALB SG only` means only machines in the load
  balancer's security group may connect, which is safer than listing IP addresses.
- **2 zones**: two availability zones, separate data centers in the same region, so one failing doesn't take the
  service down.
- **pip, model hub**: the GPU VMs reach out through NAT to download Python packages (pip) and model files from
  a hub such as Hugging Face.
- **VPC endpoint for S3**: the private path from the VPC to S3 described above.
- **SSM / IAP**: managed login tools. **SSM** is AWS Systems Manager Session Manager, and **IAP** is Google's
  Identity-Aware Proxy. Both give you a shell on the VM after checking your cloud identity, with no SSH port open
  to the internet.

**Core ideas.**

| Concept | AWS | Google Cloud | What it does |
|---|---|---|---|
| Private network | VPC | VPC network | Your isolated IP range |
| Subnet | Subnet (per zone) | Subnet (per region) | A slice of the range |
| Firewall | Security group (stateful, per VM) + NACL | Firewall rules (by tag or service account) | Allow or deny ports and sources |
| Outbound-only internet | NAT gateway | Cloud NAT | Private VMs can download packages |
| Load balancer | ALB (HTTP), NLB (TCP/gRPC) | Cloud Load Balancing | Spreads traffic, health-checks backends |
| Private access to storage | VPC endpoint | Private Google Access | Reach S3/GCS without the internet |

**Example.** A security group for the GPU VMs, written as Terraform:

```hcl
resource "aws_security_group" "model_api" {
  name   = "model-api"
  vpc_id = aws_vpc.main.id
  ingress {
    from_port       = 8000
    to_port         = 8000
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]   # only the load balancer, never 0.0.0.0/0
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
```

**Senior note.** NAT gateways charge per GB processed. A cluster that downloads a 140 GB model from the
internet on every pod start can spend more on NAT than on GPUs. Cache models in S3/GCS and read them
through a VPC endpoint.

---

## Lecture 18 — Cloud storage: object, block, and file systems

**Why it matters.** Storage choice decides how fast GPUs get their data, how much you pay to keep it, and
whether a checkpoint survives a crash.

**In plain words.** *Object storage* is a giant warehouse: unlimited space, cheap, very durable, and you
fetch whole boxes by their label. *Block storage* is the hard drive inside one computer: fast, but only
that computer can use it. *File storage* is a shared network folder: many computers can open the same
files at once, at a higher price.

**Architecture: where each type fits in an AI system.**

```mermaid
flowchart LR
  subgraph OBJ["Object storage (S3, GCS, Azure Blob)"]
    RAW[(raw data)] --- DS[(training datasets<br/>Parquet / WebDataset shards)] --- MODELS[(model artifacts,<br/>checkpoints)]
  end
  subgraph BLK["Block storage (EBS, Persistent Disk)"]
    BOOT[(VM boot disk)] --- SCRATCH[(local cache<br/>for one VM)]
  end
  subgraph FILE["File storage (EFS, Filestore, FSx for Lustre)"]
    SHARED2[(shared folder for<br/>many training nodes)]
  end
  DS -->|stream or prefetch| TRAINING[Training nodes]
  SHARED2 --> TRAINING
  TRAINING -->|checkpoint| MODELS
  MODELS -->|load at startup| SERVING[Inference VMs]
  BOOT --- SERVING
```

**How to read it:** object storage is the source of truth for data and models. Block disks are private
working space for one machine. A shared file system sits next to the training cluster when many nodes
need the same files with normal file paths.

**Terms in this diagram.**
- **Azure Blob**: Microsoft Azure's object storage, the equivalent of S3 and GCS.
- **Parquet / WebDataset shards**: **Parquet** is a column-based file format for tables that compresses well and
  reads only the columns you ask for. **WebDataset** packs many training samples (images and labels) into large
  `.tar` files. A **shard** is one of many such files, so many workers can read different shards in parallel
  (Section 6).
- **Model artifacts**: the files a training run produces: weights, tokenizer, config, and metrics.
- **EBS, Persistent Disk**: AWS's and Google's network block disks.
- **Filestore, FSx for Lustre**: Google's managed NFS, and AWS's managed **Lustre**, a parallel filesystem from
  supercomputing that serves files to hundreds of nodes at very high speed.
- **Stream or prefetch**: **streaming** reads data from object storage while training runs. **Prefetching**
  downloads the next pieces before they're needed, so the GPU never waits.

| | Object | Block | File |
|---|---|---|---|
| Examples | S3, GCS, Azure Blob | EBS, Persistent Disk, Azure Disk | EFS, Filestore, FSx for Lustre |
| Access | HTTP API (`GET`/`PUT` whole objects) | Mounted disk, one VM (mostly) | Mounted folder, many VMs |
| Durability | Very high (11 nines) | Replicated in one zone | Regional or zonal |
| Price per GB-month (rough) | $0.02 (less for cold tiers) | $0.08–0.12 | $0.10–0.30 |
| Best for | Datasets, models, checkpoints, logs | OS disks, databases, scratch | Shared training data, home directories |

**Example.** A vision team kept 200 TB of images on EFS so every node could read them: about $60,000 per
month. Moving them to S3 as 1 GB WebDataset shards, streamed during training with a small local NVMe
cache, cost about $4,600 per month, and training got *faster* because large sequential reads beat
millions of small file opens.

**Senior note.** Millions of tiny files are slow on every storage type. Pack them into large shards
(Parquet, TFRecord, WebDataset tar files). Section 6 covers this in depth.

---

## Lecture 19 — Hands-on with AWS EC2 for AI

**In plain words.** EC2 is AWS's computer-rental counter. An AMI is the pre-installed software image you
start from. An IAM role is the ID badge the machine wears, so it can open S3 without anyone typing a
password into it.

**Architecture: what you launch.**

```mermaid
flowchart LR
  AMI["Deep Learning AMI<br/>(Ubuntu + driver + CUDA + PyTorch)"] --> EC2["EC2 g5.xlarge<br/>1× A10G 24 GB"]
  ROLE["IAM instance profile:<br/>read s3://models-bucket only"] --> EC2
  SG2["Security group:<br/>SSH from my IP only"] --> EC2
  EC2 --> EBS2[(gp3 EBS 200 GB)]
  EC2 -->|aws s3 cp, no keys on disk| S3M[(s3://models-bucket)]
```

**How to read it:** the AMI gives you working drivers. The IAM role gives the VM *temporary* credentials
that rotate automatically. The security group limits who can connect.

**Terms in this diagram.**
- **Deep Learning AMI**: an AMI (Amazon Machine Image) is a ready-made disk image a VM boots from. This one
  comes with Ubuntu, the NVIDIA driver, **CUDA** (NVIDIA's GPU computing platform), and **PyTorch** installed.
- **EC2 g5.xlarge, 1× A10G 24 GB**: an AWS VM with one NVIDIA A10G GPU that has 24 GB of memory.
- **IAM instance profile**: the way an IAM role is attached to an EC2 VM. Programs on the VM automatically get
  short-lived credentials for that role, here allowed to read only `s3://models-bucket`.
- **gp3 EBS 200 GB**: a 200 GB general-purpose SSD network disk (`gp3` is the disk type).
- **aws s3 cp, no keys on disk**: the AWS command-line copy command. It finds the role's credentials by itself,
  so no access keys are ever saved in files.

**Steps.**

```bash
# 1. Find the latest Deep Learning AMI for your region
aws ec2 describe-images --owners amazon \
  --filters "Name=name,Values=Deep Learning OSS Nvidia Driver AMI GPU PyTorch*Ubuntu 22.04*" \
  --query 'sort_by(Images,&CreationDate)[-1].ImageId' --output text

# 2. Launch it with a role instead of access keys (spot shown; drop --instance-market-options for on-demand)
aws ec2 run-instances --image-id <ami> --instance-type g5.xlarge \
  --iam-instance-profile Name=model-reader \
  --instance-market-options 'MarketType=spot' \
  --security-group-ids <sg> --key-name my-key

# 3. On the VM: the role works without any keys
aws s3 ls s3://models-bucket/
nvidia-smi
```

**Example.** A new engineer copied their personal access keys into `~/.aws/credentials` on a shared GPU
VM. Anyone with SSH access could now act as that engineer. With an instance role, there are no long-lived
keys on disk to steal.

**Senior note.** Check your **GPU quota** (Service Quotas → "Running On-Demand G and VT instances") before
a deadline. New accounts often start at zero GPUs.

---

## Lecture 20 — Hands-on with Google Cloud GPU instances

**In plain words.** On Google Cloud you rent a normal VM and "plug in" a GPU card as an option (except on
the newer G2 and A3 families, where the GPU is part of the machine type).

**Architecture.**

```mermaid
flowchart LR
  IMG["Deep Learning VM image<br/>(common-cu123)"] --> VM2["Compute Engine VM<br/>g2-standard-8 + 1× L4"]
  SA["Service account:<br/>roles/storage.objectViewer"] --> VM2
  FW["Firewall rule:<br/>SSH via IAP only"] --> VM2
  POL["maintenance-policy=TERMINATE<br/>(GPU VMs can't live-migrate)"] --> VM2
  VM2 -->|gsutil / gcloud storage| GCS[(gs://models-bucket)]
```

**How to read it:** same pattern as AWS: a ready-made image, an identity (a *service account* instead of
an IAM role), a firewall, and one GPU-specific rule, `TERMINATE`, because Google can't move a running GPU
VM to another host during maintenance.

**Terms in this diagram.**
- **Deep Learning VM image (common-cu123)**: Google's ready-made image with the driver, CUDA 12.3, and ML
  libraries.
- **g2-standard-8 + 1× L4**: a Google Cloud VM with 8 vCPUs and one NVIDIA L4 GPU (24 GB).
- **Service account, roles/storage.objectViewer**: a **service account** is an identity for a machine rather than
  a person. `roles/storage.objectViewer` is a built-in role that allows reading objects in Cloud Storage, nothing
  more.
- **SSH via IAP only**: SSH connections are allowed only through Google's Identity-Aware Proxy, which checks your
  Google login first, so port 22 isn't open to the internet.
- **Live-migrate**: Google normally moves running VMs to another physical host during maintenance without
  stopping them. GPU VMs can't be moved, so they must be stopped (`TERMINATE`) instead.
- **gsutil / gcloud storage**: Google's command-line tools for copying files to and from buckets. `gcloud
  storage` is the newer, faster one. **gs://** is how Cloud Storage bucket addresses start.

```bash
gcloud compute instances create l4-box \
  --zone=us-central1-a --machine-type=g2-standard-8 \
  --image-family=common-cu123-ubuntu-2204 --image-project=deeplearning-platform-release \
  --maintenance-policy=TERMINATE --boot-disk-size=200GB \
  --service-account=model-reader@<project>.iam.gserviceaccount.com --scopes=cloud-platform \
  --provisioning-model=SPOT          # remove for on-demand

gcloud compute ssh l4-box --tunnel-through-iap
gcloud compute regions describe us-central1 --format="table(quotas.metric,quotas.limit)" | grep -i gpu
```

| AWS term | Google Cloud term |
|---|---|
| AMI | Image / image family |
| Instance profile (IAM role) | Service account |
| Security group | Firewall rule (by network tag or service account) |
| Spot instance | Spot VM |
| Session Manager | IAP TCP forwarding |

**Example.** A launch fails with `ZONE_RESOURCE_POOL_EXHAUSTED`: the zone has no free L4s right now.
The fix is to retry in another zone of the same region, or use a managed instance group that tries
several zones for you. Popular GPUs are often out of stock in popular zones.

**Senior / FAANG best practice.** Don't treat GPUs as always available. Big teams keep **capacity
reservations** for baseline load, with launch templates that list several instance types and zones in
order of preference. They track quota and capacity as first-class dashboards, and they request quota
increases weeks before a launch, not on launch day.

---

## Lecture 21 — Lab: compare cost and performance across clouds

**Goal:** decide which instance to use for an inference service by measuring **cost per 1 million
predictions**, not price per hour.

**In plain words.** A cheaper taxi isn't cheaper if it takes three times as long. Compare the price of
the whole trip, not the price per minute.

**Architecture: the method.**

```mermaid
flowchart LR
  A[Same model,<br/>same container] --> B[Run on candidate<br/>instances]
  B --> C["Measure throughput<br/>(predictions/sec at<br/>your latency target)"]
  C --> D["cost per 1M =<br/>price per hour ÷ (throughput × 3600) × 1,000,000"]
  D --> E[Check latency SLO<br/>and availability]
  E --> F[Pick cheapest that<br/>meets the SLO]
```

**How to read it:** keep everything identical except the hardware, measure throughput *while meeting
your latency target*, then convert to a cost per unit of work. The **latency SLO** (service level objective)
is your written latency promise, for example "95% of requests answered within 200 ms". An instance that's cheap
but breaks the SLO is disqualified.

**Step 1 — measure.** Run the same benchmark on each instance (Section 7 covers benchmarking properly):

```bash
# Inside the model container on each VM; reports throughput and p95 latency
python bench.py --batch-size 8 --duration 120 --p95-target-ms 100
```

**Step 2 — compute and compare** with the exercise script, which comes with sample measurements:

```bash
python3 exercises/s03_cloud_cost_compare.py
python3 exercises/s03_cloud_cost_compare.py --monthly-predictions 500000000 --p95-slo-ms 80
```

**Example result (sample numbers).** The H100 has the highest price per hour but the *lowest* cost per
1M predictions because its throughput is so much higher, *if* you have enough traffic to keep it busy.
At low traffic, a smaller GPU wins because you pay for idle time on the big one. The script prints both
views.

**Expected results:** a table with one row per instance, showing price per hour, measured throughput,
p95 latency, and cost per 1M predictions both at full utilization and at your real traffic. With the
sample data, the H100 wins at full utilization ($0.26 per 1M), but a GCP L4 wins for the real traffic
(3 replicas, about $1,555 a month). You should come away with a one-line recommendation that names the
instance and says when to revisit it.

---

## Assessment — Recommend a cloud architecture for AI inference

**Scenario.** An e-commerce company wants product-image tagging (a ResNet-50-sized model) as an API.
Traffic averages 300 requests per second, peaks at 1,200 during sales, and the p95 latency target is
100 ms. Images contain no personal data. The team is already on AWS.

**Your recommendation should cover:** compute, network, storage, scaling, security, and estimated cost.

**Model answer.**

```mermaid
flowchart TB
  CL((Clients)) --> CF[CloudFront + WAF]
  CF --> ALB2[ALB, 2 AZs]
  subgraph VPC2["VPC, private subnets in 2 AZs"]
    ALB2 --> ASG["Auto Scaling group / EKS node group<br/>g6.xlarge (L4), min 2, max 8<br/>scale on GPU util / requests per target"]
    ASG --> CACHE[(ElastiCache:<br/>results for repeat images)]
  end
  ASG -->|VPC endpoint| S3C[(S3: model artifacts,<br/>versioned)]
  ASG --> CW[CloudWatch / Prometheus:<br/>p95, errors, GPU util]
  IAM2[IAM role: read model bucket only] -.-> ASG
```

**How to read it:** requests enter at the edge, pass a firewall, and reach a load balancer spread over two
zones. Behind it, a group of L4 GPU machines grows and shrinks with load, checks a cache before running the
model, loads models from S3, and reports metrics.

**Terms in this diagram.**
- **CloudFront + WAF**: **CloudFront** is AWS's CDN (content delivery network), a global set of edge servers close
  to users that terminate connections and absorb traffic spikes. **WAF** (web application firewall) blocks
  malicious requests such as floods, bots, and injection attempts before they reach your servers.
- **ALB, 2 AZs**: the application load balancer (Lecture 17), placed in two availability zones (separate data
  centers).
- **Auto Scaling group / EKS node group**: an **Auto Scaling group** is a set of identical EC2 VMs that AWS adds to
  or removes from automatically between a minimum and maximum. An **EKS node group** is the same idea for the
  machines of a Kubernetes cluster.
- **g6.xlarge (L4), min 2, max 8**: one L4 GPU per VM, never fewer than 2 VMs (one per zone), at most 8.
- **Scale on GPU util / requests per target**: add machines when GPU utilization or the number of requests each
  machine handles passes a threshold.
- **ElastiCache**: AWS's managed Redis or Memcached, an in-memory key-value store. Here it remembers results for
  images already seen.
- **S3 versioned**: the bucket keeps every older version of each file, so a bad model upload can be undone.
- **CloudWatch / Prometheus**: **CloudWatch** is AWS's built-in metrics and logs service. **Prometheus** is the
  open-source metrics database (Section 16). Either one tracks p95 latency, errors, and GPU utilization.

| Decision | Choice | Why |
|---|---|---|
| Compute | L4 GPUs (`g6.xlarge`), not H100 | The model is small; L4 gives the best cost per prediction and meets 100 ms p95 |
| Capacity | Min 2 (one per zone), autoscale to 8 | Survives a zone failure; one L4 handles roughly 300–500 req/s with dynamic batching on this model, measured in the lab |
| Purchasing | Reserved/savings plan for the 2 base nodes, on-demand for burst | Base load is steady; spot is risky for a latency SLO unless mixed with on-demand |
| Network | Only the ALB is public; VMs in private subnets; S3 via VPC endpoint | Smallest attack surface; no NAT charges for model downloads |
| Storage | Versioned S3 bucket for models; nothing stateful on VMs | VMs are disposable, so autoscaling and replacement are safe |
| Caching | Hash the image bytes and cache results | Sale traffic repeats the same product images |
| Security | WAF, TLS at the ALB, IAM role per service, no SSH (Session Manager) | Least privilege, no long-lived keys |
| Observability | p95 latency, error rate, GPU utilization, queue depth | Scale on what users feel, not only on CPU |

Run `python3 exercises/s03_cloud_cost_compare.py` to reproduce the cost comparison behind the instance
choice.

---

## FAANG deep-dive notes

**How big tech does it.** Cloud use starts from a **landing zone**: separate accounts or projects per
team and environment, a central network with private connectivity, organization-wide guardrails
(service control policies), and mandatory cost tags. GPU capacity is a managed portfolio: reserved
or committed capacity for steady load, on-demand for spikes, and spot for jobs that can be interrupted.
A FinOps function reviews spend weekly by team and by workload.

**Staff review questions.**
- What is our GPU capacity mix (reserved, on-demand, spot), and is it matched to how steady each workload is?
- Is the data in the same region as the compute? What would a cross-region epoch cost?
- What happens to a training job when a spot instance is reclaimed?
- Can a single engineer's mistake create unlimited spend? Where are the budget alarms?

**Interview question.** "Set up the cloud foundation for a 60-person ML organization."

**Typical system-design prompt:** *Design the cloud setup for a 60-person ML org: account structure,
networking, GPU capacity strategy, and cost controls for development, training, and inference.*

**1. Clarify first:** How many people need GPUs for development, and for how many hours? How many big
training runs per month, and of what size? What are the inference traffic and latency targets? Are
there data-residency rules? Is there an existing cloud commitment or discount?

**2. Back-of-envelope sizing (illustrative prices):**

| Workload | Calculation | Monthly cost |
|---|---|---|
| Dev GPUs: 20 L4s, 10 h/day, 22 days | 20 × $0.80 × 220 h | ~$3,500 |
| Training: 64 H100s for 2 weeks | 64 × $4 × 336 h | ~$86,000 |
| Inference: 16 L4s, always on | 16 × $0.80 × 730 h | ~$9,300 |

Training dominates, so it's where reservations, spot, and utilization matter most. Dev GPUs need
auto-stop more than discounts.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Capacity | On-demand | Reserved or committed | Reserve the steady baseline (~60%+ utilization). On-demand for the rest |
| Fault-tolerant jobs | On-demand | Spot (60–90% cheaper) | Spot only if the job checkpoints often and restarts automatically |
| Accounts | One shared account | Account per team and environment | Separate accounts: clean billing, blast-radius limits, simpler IAM |
| Platform | Managed (SageMaker, Vertex AI) | Do it yourself on Kubernetes | Managed for small teams. Kubernetes once you have a platform team and need portability |

**4. Follow-up questions with crisp answers:**
- *How much warning does a spot reclaim give?* About 2 minutes on AWS, and about 30 seconds on GCP. Checkpoint
  often enough that losing the last interval is acceptable.
- *Why do GPU launches fail with available quota?* Quota is permission to launch. Capacity is whether
  the zone actually has free GPUs. You need both.
- *How do you stop a runaway bill?* Budgets with alerts per account, auto-stop for idle dev instances,
  and limits on the largest instance types.

**Debug this (common onsite question):** "This month's bill jumped $10,000, and training is slower than usual."
1. Group cost by service and usage type: "inter-region data transfer" stands out.
2. Find the job: training runs in `us-east-1` but reads a 50 TB dataset from a bucket in `eu-west-1`.
3. Do the math: 50 TB ≈ 51,200 GB × ~$0.02/GB ≈ $1,000 per epoch. 10 epochs ≈ $10,000, and every read
   crosses the Atlantic, which explains the slowdown.
4. Fix: copy the dataset once to a bucket in the training region, or run training in the data's region.
   Add a policy check that flags cross-region reads.

The lesson: keep data and compute in the same region. Data transfer is a hidden bill and a hidden
latency.

**5. What separates senior from staff answers:** a senior engineer picks good instances and sets alerts.
A staff engineer designs the capacity portfolio, ties every dollar to a team and workload through
tags, plans quota and reservations ahead of launches, and sets guardrails so one mistake can't create
unlimited spend.

**Red flags:**
- Everyone in one account with admin rights.
- No cost tags, so nobody knows who spends what.
- Spot for jobs that don't checkpoint.
- Data in one region, GPUs in another.
- No budget alerts until the invoice arrives.

---

## Quiz

<details><summary>1. Instance A costs $1/hour and does 500 predictions/sec. Instance B costs $4/hour and does 2,500/sec. Which is cheaper per prediction?</summary>
A: $1 ÷ (500 × 3600) × 1M ≈ $0.56 per 1M. B: $4 ÷ (2,500 × 3600) × 1M ≈ $0.44 per 1M. B is cheaper per
prediction, but only if you have enough traffic to keep it busy.
</details>

<details><summary>2. Why should GPU VMs sit in private subnets?</summary>
So they can't be reached directly from the internet. Only the load balancer is public, and the VMs'
firewall allows traffic only from it.
</details>

<details><summary>3. Which storage type for: (a) a 50 TB training dataset, (b) a VM's OS, (c) a folder many training nodes read?</summary>
(a) Object storage, ideally as large shards. (b) Block storage. (c) File storage, such as EFS, Filestore,
or FSx for Lustre for high throughput.
</details>

<details><summary>4. When is spot a good fit, and when is it a bad one?</summary>
Good: training with frequent checkpoints, and batch inference, which can retry. Bad: latency-critical
serving with no on-demand fallback, because capacity can be reclaimed with very short notice.
</details>

<details><summary>5. Why use an IAM role or service account instead of access keys on a VM?</summary>
The credentials are temporary and rotate automatically, and nothing long-lived sits on disk to be stolen
or leaked. Access can also be scoped to exactly the buckets the VM needs.
</details>

<details><summary>6. Why does Google Cloud require <code>--maintenance-policy=TERMINATE</code> for GPU VMs?</summary>
VMs with attached GPUs can't be live-migrated to another host during maintenance, so they have to be
stopped instead.
</details>

## Failure modes
- A model API or Jupyter exposed on `0.0.0.0/0` with no authentication.
- GPU quota of zero discovered on launch day.
- NAT gateway bills exploding because every pod downloads weights from the internet.
- Choosing by price per hour instead of cost per unit of work, or forgetting idle time at low traffic.
- Training data on an expensive shared file system when object storage plus a cache would do.

## Checklist
- [ ] You can draw a VPC with public and private subnets, a load balancer, NAT, and a storage endpoint
- [ ] You can name the right storage type for datasets, OS disks, and shared folders
- [ ] You launched a GPU VM on AWS or Google Cloud with a role or service account, not keys
- [ ] You compared at least two instance types by cost per 1M predictions
