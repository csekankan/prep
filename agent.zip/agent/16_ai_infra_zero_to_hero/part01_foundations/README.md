# Part I — Foundations (Sections 1–5, lectures 1–35)

From "what is AI infrastructure?" to a model running on Kubernetes with autoscaling.

| § | Section | You will be able to | Exercise |
|---|---|---|---|
| 1 | [AI Infrastructure Fundamentals](s01_ai_infra_fundamentals.md) | Pick CPU/GPU/TPU, tell training from inference, name the layers, launch a GPU VM | — |
| 2 | [Linux Foundations for AI Engineers](s02_linux_for_ai.md) | Work in the shell, fix permissions and disks, manage processes, automate with bash | [`s02_system_health.sh`](../exercises/s02_system_health.sh) |
| 3 | [Cloud Infrastructure Basics](s03_cloud_basics.md) | Choose instances, design a VPC, pick storage, compare clouds by cost per unit of work | [`s03_cloud_cost_compare.py`](../exercises/s03_cloud_cost_compare.py) |
| 4 | [Containerization Foundations](s04_containerization.md) | Build lean, secure AI images, use volumes and Compose, audit a Dockerfile | [`s04_dockerfile_audit.py`](../exercises/s04_dockerfile_audit.py) |
| 5 | [Kubernetes Fundamentals](s05_kubernetes_fundamentals.md) | Deploy a model with probes, config, secrets, autoscaling, and Helm | — |

```mermaid
flowchart LR
  S1["§1 What & why<br/>GPU VM"] --> S2["§2 Linux<br/>the OS under everything"]
  S2 --> S3["§3 Cloud<br/>VPC, compute, storage"]
  S3 --> S4["§4 Containers<br/>package the model"]
  S4 --> S5["§5 Kubernetes<br/>run it at scale"]
  S5 --> NEXT["Part II: data, GPUs,<br/>distributed training"]
```

**How to read it:** each section builds on the previous one. The classifier you containerize in Section 4
is the one you deploy on Kubernetes in Section 5, and it's served and optimized again in Sections 14–15.
