# Section 4 — Containerization Foundations

> Lectures 22–28 • Assessments: audit a production Dockerfile, quiz
> **After this section you can:** explain why AI teams containerize everything, build and run images,
> containerize a model API, wire services together with networks, volumes and Compose, write lean and
> secure AI images, and spot the common mistakes in someone else's Dockerfile.
>
> Go deeper: [13 / Lab 2 — Containerization deep dive](../../13_sovereign_ai_infra_course/01_foundations_local_sandbox/lab02_containerization_deep_dive.md)
> covers runtimes, cgroups and supply-chain signing in more depth.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 22 | Why containers are critical for AI | "Works on my machine" becomes "works on every machine": code, libraries, and CUDA runtime travel together |
| 23 | Docker basics: images and containers | An image is a recipe snapshot; a container is a running copy of it |
| 24 | Building a container for an AI app | Dockerfile → `docker build` → `docker run`, with the model loaded once at startup |
| 25 | Networking and volumes | Containers talk over named networks; data that must survive lives in volumes |
| 26 | Docker Compose for multi-service AI | One YAML file starts the API, the cache, and the monitoring together |
| 27 | Best practices: lightweight AI containers | Slim runtime base, multi-stage builds, no weights in the image, non-root |
| 28 | Lab: containerize a PyTorch model | Build, run, test, and measure a real image classifier container |

```mermaid
flowchart LR
  CODE[app.py +<br/>requirements.txt] --> DF[Dockerfile]
  DF -->|docker build| IMG[(Image<br/>in a registry)]
  IMG -->|docker run| C1[Container: laptop]
  IMG -->|docker run| C2[Container: CI]
  IMG -->|kubectl apply| C3[Container: production GPU node]
  VOL[(Volume:<br/>model weights)] -.mounted.-> C1 & C2 & C3
```

**How to read it:** you describe the environment once (the Dockerfile) and build it into an image. The
*same* image then runs on your laptop, in CI, and in production. Large model weights are mounted from
storage instead of being baked in.

**Terms in this diagram.**
- **requirements.txt**: the list of Python packages (with versions) the app needs.
- **Dockerfile**: a text file of build instructions: start from this base image, install these packages, copy
  this code, run this command.
- **Image in a registry**: an **image** is the built, read-only package of the app and everything it needs. A
  **registry** is a server that stores images, such as Docker Hub, GitHub Container Registry, or AWS ECR.
- **docker build / docker run**: build an image from a Dockerfile, and start a container from an image.
- **CI**: continuous integration, the automated system that tests every code change (Section 10).
- **kubectl apply**: the Kubernetes command that tells a cluster to run something (Section 5).
- **Volume**: storage that lives outside the container and is attached (**mounted**) into it, so large or changing
  files such as model weights don't have to be inside the image.

---

## Lecture 22 — Why containers are critical for AI

**Why it matters.** An AI app depends on a fragile stack: a specific Python version, PyTorch built for a
specific CUDA version, system libraries like `libgl` for OpenCV, and the right driver on the host. Without
containers, every new server or teammate means hours of "it works on my machine".

**In plain words.** Shipping containers changed world trade because every port can handle the same
standard box, whatever is inside it. A software container is the same idea: one standard box holding your
code and everything it needs, which any Docker or Kubernetes host can run.

**Architecture: VM vs container.**

```mermaid
flowchart TB
  subgraph VMS["Virtual machines"]
    HW1[Hardware] --> HV[Hypervisor]
    HV --> G1["Guest OS (2 GB) + libs + app A"]
    HV --> G2["Guest OS (2 GB) + libs + app B"]
  end
  subgraph CTRS["Containers"]
    HW2[Hardware] --> OS2[Host Linux kernel + NVIDIA driver]
    OS2 --> RT2[Container runtime]
    RT2 --> CA["libs + app A (MBs to GBs)"]
    RT2 --> CB["libs + app B"]
  end
```

**How to read it:** each VM carries a full operating system. Containers share the host's kernel (and its
GPU driver), so they're smaller, start in seconds, and pack more workloads per machine.

**Terms in this diagram.**
- **Hypervisor**: the software that runs virtual machines, splitting one physical server into several fake
  "computers" (for example KVM, VMware ESXi, or AWS Nitro).
- **Guest OS**: the full operating system installed inside each VM, often 1–2 GB, with its own kernel.
- **Host Linux kernel**: the single kernel of the real machine. All containers on it share this kernel, which is
  why they're light.
- **Container runtime**: the program that creates and runs containers, such as containerd or Docker.
- **Libs**: the libraries an app depends on (Python, PyTorch, CUDA libraries), packed inside each container.

**Core ideas.**

| Problem without containers | How containers solve it |
|---|---|
| PyTorch/CUDA version conflicts between projects | Each image has its own Python, PyTorch, and CUDA runtime |
| "Works on my laptop, fails in prod" | The exact same image runs everywhere |
| Slow, manual server setup | `docker run` starts a ready environment in seconds |
| Hard to scale | Kubernetes starts more copies of the same image (Section 5) |
| Hard to roll back | Re-deploy the previous image tag |

**Example.** A team's model passed every test on the data scientist's laptop and crashed in production
with `libGL.so.1: cannot open shared object file`: OpenCV needed a system library the server didn't
have. With a container, that library is installed in the image, so the laptop and the server run the
same thing.

**Senior note.** Containers share the host kernel, so they're a packaging boundary first and a security
boundary second. Untrusted code (for example agent-generated code) needs stronger isolation such as
gVisor or Kata, covered in [13 / Lab 77](../../13_sovereign_ai_infra_course/06_agentic_mcp/lab77_sandboxing_agent_tools.md).

---

## Lecture 23 — Docker basics: images and containers

**In plain words.** An *image* is like a frozen meal: prepared once, sealed, and identical every time.
A *container* is that meal heated up and on a plate: a running copy of the image. You can heat up many
copies of the same frozen meal at once.

**Architecture: layers.**

```mermaid
flowchart TB
  subgraph IMAGE["Image (read-only layers, shared and cached)"]
    L1["Layer 1: python:3.11-slim (base OS + Python)"]
    L2["Layer 2: pip install -r requirements.txt"]
    L3["Layer 3: COPY app.py"]
    L1 --> L2 --> L3
  end
  IMAGE --> C1W["Container 1: thin writable layer"]
  IMAGE --> C2W["Container 2: thin writable layer"]
```

**How to read it:** an image is a stack of read-only layers, each created by one Dockerfile instruction.
Containers add a small writable layer on top, and that layer is thrown away when the container is removed.
If you change only `app.py`, Docker rebuilds only layer 3 and reuses the cached layers below it.

**The commands you'll use every day.**

```bash
docker pull python:3.11-slim                 # download an image
docker images                                # list local images
docker run --rm -it python:3.11-slim python  # run interactively, delete when it exits
docker run -d --name api -p 8000:8000 my-model:1.0   # run in the background, map a port
docker ps                                    # running containers
docker logs -f api                           # follow its output
docker exec -it api bash                     # open a shell inside it
docker stop api && docker rm api             # stop, then remove
docker build -t my-model:1.0 .               # build an image from ./Dockerfile
docker push registry.example.com/my-model:1.0
docker system df                             # how much disk Docker is using
```

| Term | Meaning |
|---|---|
| Image | Read-only template (layers + metadata) |
| Container | A running (or stopped) instance of an image |
| Tag | A human-friendly, **movable** name: `my-model:1.0`, `latest` |
| Digest | An **immutable** content hash: `my-model@sha256:3f1c…` |
| Registry | Where images are stored: Docker Hub, ECR, GCR/Artifact Registry, Harbor |

**Example.** Two engineers both pulled `pytorch/pytorch:latest` a month apart and got different PyTorch
versions. One model loaded, the other didn't. Pin tags (`pytorch/pytorch:2.4.1-cuda12.4-cudnn9-runtime`)
and deploy by digest in production.

**Senior / FAANG best practice.** Production images come only from an internal registry that mirrors
approved base images. Every image is scanned, signed (for example with cosign), and shipped with an SBOM
(a list of everything inside it). The cluster's admission policy rejects unsigned images and any image
referenced by a mutable tag like `latest`.

---

## Lecture 24 — Building a container for an AI app

**Why it matters.** This is the core skill: turning a working model script into something anyone can run.

**In plain words.** A Dockerfile is a recipe card: start from this base, add these ingredients, copy in
my code, and here's the command to serve it.

**Architecture: what happens on `docker build` and `docker run`.**

```mermaid
sequenceDiagram
  participant Dev as Developer
  participant D as Docker
  participant Reg as Registry
  participant C as Container
  Dev->>D: docker build -t classifier:1.0 .
  D->>Reg: pull base image (if not cached)
  D->>D: run each instruction → one layer each
  Dev->>D: docker run -p 8000:8000 classifier:1.0
  D->>C: start process: uvicorn app:app
  C->>C: load model ONCE into memory (startup)
  Dev->>C: POST /predict (image)
  C-->>Dev: {"label": "golden retriever", "score": 0.93}
```

**How to read it:** the build happens once and produces layers. At run time the container loads the
model once at startup, then answers many requests. Loading the model per request is a classic mistake
that makes every request take seconds.

**Terms in this diagram.**
- **docker build -t classifier:1.0 .**: build the image from the Dockerfile in the current folder (`.`) and give
  it the name `classifier` with tag (version label) `1.0`.
- **Pull base image (if not cached)**: download the starting image named in `FROM` unless it's already on the
  machine.
- **docker run -p 8000:8000**: start a container and **publish** its port 8000 on your machine's port 8000, so
  you can reach it at `localhost:8000`.
- **uvicorn app:app**: **uvicorn** is a fast Python web server. `app:app` means "in the file `app.py`, run the
  object named `app`", which is the FastAPI application.
- **POST /predict**: an HTTP request with the `POST` method (used to send data) to the `/predict` URL path. The
  image goes in the request body.
- **{"label": "golden retriever", "score": 0.93}**: the JSON response: the predicted class (a dog breed, one of
  the 1,000 ImageNet classes the model knows) and the model's confidence from 0 to 1.

**A minimal model API** (`app.py`):

```python
from contextlib import asynccontextmanager
import io
import torch
from fastapi import FastAPI, UploadFile
from PIL import Image
from torchvision.models import resnet18, ResNet18_Weights

state = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    weights = ResNet18_Weights.DEFAULT
    state["model"] = resnet18(weights=weights).eval()
    state["preprocess"] = weights.transforms()
    state["labels"] = weights.meta["categories"]
    yield

app = FastAPI(lifespan=lifespan)

@app.get("/healthz")
def healthz():
    return {"ok": "model" in state}

@app.post("/predict")
async def predict(file: UploadFile):
    img = Image.open(io.BytesIO(await file.read())).convert("RGB")
    with torch.inference_mode():
        probs = state["model"](state["preprocess"](img).unsqueeze(0)).softmax(-1)[0]
    score, idx = probs.max(0)
    return {"label": state["labels"][idx], "score": round(score.item(), 4)}
```

**Its Dockerfile:**

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt     # deps first: cached unless requirements change
COPY app.py .                                           # code last: changes often, rebuilds fast
EXPOSE 8000
CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]
```

`requirements.txt`: `fastapi==0.115.*`, `uvicorn==0.30.*`, `python-multipart==0.0.*`, `pillow==10.*`,
plus `torch` and `torchvision` from the CPU index (see the lab) to keep the image small.

**Example.** Moving `COPY . .` above `pip install` made every one-line code change reinstall all
dependencies: 9-minute builds. Swapping the two lines brought rebuilds down to 15 seconds.

**Senior / FAANG best practice.** Builds run in CI, never on laptops, with a shared remote layer cache
(BuildKit `--cache-to` / `--cache-from`). Platform teams publish a small set of blessed base images
(CPU, CUDA runtime, CUDA devel) that product teams build on. A security fix to a base image then
reaches every service with one rebuild.

---

## Lecture 25 — Networking and volumes in Docker

**In plain words.** A Docker *network* is a private phone line between containers: on it they can call
each other by name (`redis`, `api`). A *volume* is an external hard drive you plug into a container. The
container can be thrown away, but the drive and its data stay.

**Architecture.**

```mermaid
flowchart LR
  USER2((You: localhost:8000)) -->|"-p 8000:8000"| API2
  subgraph NET["Docker network: ai-net"]
    API2[api container] -->|"redis:6379 (by name)"| REDIS[redis container]
  end
  MODELS2[("volume: model-weights<br/>(or bind mount ./models)")] -.mounted at /models.-> API2
  RDATA[(volume: redis-data)] -.-> REDIS
```

**How to read it:** only the API has a port published to your machine. The API finds Redis by its
container name over the private network. Model weights and Redis data live in volumes, so they survive
container restarts and upgrades.

**Terms in this diagram.**
- **localhost:8000**: `localhost` is your own machine's address. Port 8000 on it is forwarded into the API
  container by `-p 8000:8000`.
- **Docker network: ai-net**: a private network that Docker creates. Containers on it can reach each other by
  **name** (`redis`), because Docker runs a small DNS server for the network.
- **redis:6379**: **Redis** is an in-memory key-value database, used here as a fast cache. 6379 is its standard
  port.
- **Volume vs bind mount**: a **volume** is storage managed by Docker (it lives in Docker's own folder). A **bind
  mount** maps a folder from your machine (`./models`) straight into the container.

```bash
docker network create ai-net
docker volume create model-weights
docker run -d --name redis --network ai-net -v redis-data:/data redis:7
# :ro = read-only mount, so the API can't corrupt the weights
docker run -d --name api --network ai-net -p 8000:8000 \
  -v model-weights:/models:ro \
  -e REDIS_URL=redis://redis:6379 my-model:1.0
docker run --rm --gpus all my-model:1.0 nvidia-smi   # GPU access (needs NVIDIA Container Toolkit)
```

| Storage option | What it is | Use for |
|---|---|---|
| Named volume (`-v name:/path`) | Managed by Docker | Databases, caches, downloaded weights |
| Bind mount (`-v ./models:/models`) | A host folder | Development, live code reload |
| tmpfs (`--tmpfs /tmp`) | In memory | Scratch space with a read-only root filesystem |
| Container layer | The writable top layer | Nothing important: it's deleted with the container |

**Example.** A team baked a 14 GB LLM into their image. Every deploy pushed and pulled 14 GB, and new
nodes took 8 minutes to start. They moved the weights to a volume (in Kubernetes: a persistent volume,
filled once from object storage), and the image shrank to 3 GB. The same pattern scales to production in
Section 5.

**Senior / FAANG best practice.** Version code and weights separately. The image holds the code and
libraries. The weights live in a model registry or object storage under an immutable version
(a content hash). The deployment names both, for example `image@sha256:…` plus `model=v42`. Then you can
roll back either one independently, and you can prove exactly what served a given request.

---

## Lecture 26 — Docker Compose for multi-service AI systems

**Why it matters.** Real AI systems are several services: the model API, a cache or vector database, a
worker, and monitoring. Starting each with a long `docker run` command doesn't scale.

**In plain words.** Compose is a band's set list. Instead of telling each musician separately when to
start, you hand everyone one sheet, and `docker compose up` starts the whole band in the right order.

**Architecture: a local AI stack.**

```mermaid
flowchart LR
  U3((Browser)) --> API3["api :8000<br/>FastAPI + model"]
  API3 --> R3[("redis :6379<br/>prediction cache")]
  API3 -->|/metrics| P3["prometheus :9090"]
  P3 --> G3["grafana :3000"]
  W3[worker<br/>batch jobs] --> R3
```

**How to read it:** one Compose file starts five cooperating containers. The browser calls the API. The API caches
predictions in Redis and publishes metrics. A worker processes batch jobs from the same Redis.

**Terms in this diagram.**
- **FastAPI + model**: the Python web app that serves the model (Lecture 24).
- **Prediction cache**: Redis stores recent answers keyed by the input, so repeated requests skip the model.
- **/metrics**: a URL where the app publishes its numbers (request count, latency) in a plain text format.
- **prometheus :9090**: **Prometheus** is an open-source metrics database. It **scrapes** (fetches) `/metrics` from
  each service every few seconds and stores the history. Its web UI is on port 9090 (Section 16).
- **grafana :3000**: **Grafana** is an open-source dashboard tool that draws charts from Prometheus data, on
  port 3000.
- **Worker, batch jobs**: a background process that takes queued jobs (for example "classify these 10,000
  images") from Redis and runs them without a user waiting.
```yaml
# compose.yaml
services:
  api:
    build: .
    ports: ["8000:8000"]
    environment:
      REDIS_URL: redis://redis:6379
    volumes:
      - ./models:/models:ro
    depends_on:
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "python", "-c", "import urllib.request; urllib.request.urlopen('http://localhost:8000/healthz')"]
      interval: 10s
      retries: 5
    # GPU access for this service (remove on machines without a GPU):
    deploy:
      resources:
        reservations:
          devices: [{ driver: nvidia, count: 1, capabilities: [gpu] }]

  redis:
    image: redis:7.2-alpine
    volumes: [redis-data:/data]
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 5s

  prometheus:
    image: prom/prometheus:v2.54.1
    volumes: [./prometheus.yml:/etc/prometheus/prometheus.yml:ro]
    ports: ["9090:9090"]

  grafana:
    image: grafana/grafana:11.2.0
    ports: ["3000:3000"]

volumes:
  redis-data:
```

```bash
docker compose up -d --build      # build and start everything
docker compose ps                 # status and health
docker compose logs -f api
docker compose down               # stop (add -v to delete volumes too)
```

**Example.** Without `condition: service_healthy`, the API started before Redis was ready, failed its
first connection, and crashed on every fresh laptop. The healthcheck makes Compose wait.

**Senior note.** Compose is for development, demos, and single-host deployments. For several machines,
autoscaling, and self-healing, you graduate to Kubernetes (Section 5). The concepts map directly:
service → Deployment, ports → Service, volumes → PersistentVolumeClaim.

---

## Lecture 27 — Best practices: lightweight AI containers

**Why it matters.** AI images bloat easily: 15–20 GB is common. Big images mean slow deploys, slow
autoscaling, bigger attack surface, and higher registry and network costs.

**In plain words.** Pack for a trip with only what you'll use. Take the cooked meal, not the whole
kitchen: build in one stage, then carry only the result into a small final image.

**Architecture: a multi-stage build.**

```mermaid
flowchart LR
  subgraph S1["Stage 1: builder (thrown away)"]
    B1[full Python + compilers] --> B2[pip install into /opt/venv]
  end
  subgraph S2["Stage 2: runtime (shipped)"]
    R1[python:3.11-slim or<br/>CUDA *runtime* base] --> R2[COPY /opt/venv from builder]
    R2 --> R3[COPY app code]
    R3 --> R4[USER 10001, non-root]
  end
  B2 -->|copy only the result| R2
```

**How to read it:** the heavy tools needed to *build* (compilers, headers, pip caches) stay in stage 1,
which is discarded. Only the installed packages and your code reach the final image.

**Terms in this diagram.**
- **Builder stage**: a temporary image with compilers, used only to install packages. A **multi-stage build** lets
  a later stage copy files out of it and throw the rest away.
- **/opt/venv**: a Python virtual environment folder. Installing everything into one folder makes it easy to copy
  into the final stage in one step.
- **python:3.11-slim**: a small official Python base image. **CUDA runtime base**: NVIDIA's images come as
  `devel` (with compilers, several GB) and `runtime` (only the libraries needed to run, much smaller). Ship the
  runtime one.
- **USER 10001, non-root**: the container runs as an unprivileged user with ID 10001, not as root, so a break-in
  has far less power.

**The rules.**

| Rule | Why | How |
|---|---|---|
| Pin base image versions | Reproducible builds, no silent CUDA changes | `nvidia/cuda:12.4.1-runtime-ubuntu22.04`, not `latest` |
| Use `runtime`, not `devel`, CUDA bases | `devel` includes compilers: ~3 GB more | Only use `devel` in a builder stage |
| Multi-stage builds | No compilers or caches in the final image | `FROM ... AS build`, then `COPY --from=build` |
| Keep weights out of the image | Huge layers on every deploy | Mount from a volume or download at startup from object storage |
| `pip install --no-cache-dir` | Saves hundreds of MB | Or use a cache mount: `RUN --mount=type=cache,target=/root/.cache/pip` |
| Order layers by change frequency | Fast rebuilds | System packages → Python deps → code |
| `.dockerignore` | Keeps datasets, `.git`, `.venv` out of the build | `data/`, `*.pt`, `.git`, `.venv`, `__pycache__` |
| Run as non-root | Limits damage if the app is compromised | `RUN useradd -u 10001 app` then `USER 10001` |
| Exec-form `CMD` | The app is PID 1 and receives SIGTERM for graceful shutdown | `CMD ["uvicorn", ...]`, not `CMD uvicorn ...` |
| Add a `HEALTHCHECK` (or Kubernetes probes) | Orchestrators know when the model is loaded | `/healthz` endpoint |
| No secrets in the image | Anyone who pulls it can read them | Pass at runtime via env vars or a secrets manager |
| Scan the image | Known CVEs in base packages | `trivy image my-model:1.0` |

**A production-style Dockerfile for a GPU model API:**

```dockerfile
# syntax=docker/dockerfile:1.7
FROM nvidia/cuda:12.4.1-runtime-ubuntu22.04 AS build
RUN apt-get update && apt-get install -y --no-install-recommends python3.11 python3.11-venv \
 && python3.11 -m venv /opt/venv
ENV PATH=/opt/venv/bin:$PATH
COPY requirements.txt .
RUN --mount=type=cache,target=/root/.cache/pip pip install -r requirements.txt

FROM nvidia/cuda:12.4.1-runtime-ubuntu22.04
RUN apt-get update && apt-get install -y --no-install-recommends python3.11 \
 && rm -rf /var/lib/apt/lists/* \
 && useradd --uid 10001 --create-home app
COPY --from=build /opt/venv /opt/venv
ENV PATH=/opt/venv/bin:$PATH PYTHONUNBUFFERED=1 MODEL_DIR=/models
WORKDIR /app
COPY --chown=app:app app.py .
USER 10001
EXPOSE 8000
HEALTHCHECK --interval=15s --start-period=60s CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/healthz')"
CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]
```

Both stages use the same base and the same `python3.11` from the distro. A venv links to the Python
that created it, so copying a venv between images with different Pythons breaks.

**Example: image size before and after.**

| Change | Size |
|---|---|
| Starting point: `pytorch/pytorch:latest` (devel) + weights baked in + `COPY . .` incl. dataset sample | 21.4 GB |
| Weights mounted from a volume instead | 12.8 GB |
| `.dockerignore` for `data/` and `.git` | 10.1 GB |
| CUDA runtime base instead of devel, multi-stage, `--no-cache-dir` | 5.9 GB |
| CPU-only PyTorch wheel (for a model that serves fine on CPU) | 1.3 GB |

**Senior / FAANG best practice.** Put an image-size budget in CI, for example failing the build if the
image grows more than 10% without approval. At fleet scale, image size is a scale-up latency problem,
not just a storage problem. Teams also use lazy-pulling snapshotters (stargz, SOCI) or peer-to-peer image
distribution (Dragonfly, Spegel), so a 100-node scale-up doesn't overwhelm the registry.

---

## Lecture 28 — Lab: containerize a PyTorch model

**Goal:** package the ResNet-18 classifier from Lecture 24 as a lean image, run it, test it, and measure
its size, startup time, and latency.

**In plain words.** You're putting the model into a sealed lunchbox with everything it needs to eat,
then checking three things: how big the lunchbox is, how long it takes to open, and how fast the model
answers once it's open.

**What you're building.**

```mermaid
flowchart LR
  subgraph HOST3["Your machine"]
    CURL[curl / test script] -->|POST /predict| PORT[localhost:8000]
    subgraph CT3["container: classifier:1.0 (non-root)"]
      UV[uvicorn] --> APP3[FastAPI app]
      APP3 --> M3[ResNet-18 in memory]
    end
    PORT --> UV
    CACHE3[("volume: torch-cache<br/>downloaded weights")] -.-> M3
  end
```

**How to read it:** your test script sends an image with `curl` (a command-line HTTP client) to `localhost:8000`.
Docker forwards it into the container, where uvicorn (the web server) hands it to the FastAPI app, which runs the
**ResNet-18** image classifier (a small, standard 18-layer convolutional network) already loaded in memory. The
pretrained weights download once into the `torch-cache` volume, so restarts don't download them again.

**Step 1 — project files.**

```text
classifier/
├── app.py              # from Lecture 24
├── requirements.txt
├── .dockerignore
└── Dockerfile
```

```text
# requirements.txt
--extra-index-url https://download.pytorch.org/whl/cpu
torch==2.4.1
torchvision==0.19.1
fastapi==0.115.0
uvicorn==0.30.6
python-multipart==0.0.9
pillow==10.4.0
```

```text
# .dockerignore
.git
.venv
__pycache__
data/
*.pt
*.pth
```

```dockerfile
# Dockerfile
FROM python:3.11-slim AS build
RUN python -m venv /opt/venv
ENV PATH=/opt/venv/bin:$PATH
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

FROM python:3.11-slim
RUN useradd --uid 10001 --create-home app
COPY --from=build /opt/venv /opt/venv
ENV PATH=/opt/venv/bin:$PATH PYTHONUNBUFFERED=1 TORCH_HOME=/cache
WORKDIR /app
COPY --chown=app:app app.py .
RUN mkdir /cache && chown app:app /cache
USER 10001
EXPOSE 8000
CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]
```

**Step 2 — build and run.**

```bash
docker build -t classifier:1.0 .
docker images classifier:1.0                       # expect roughly 1–1.5 GB with CPU-only torch
docker run -d --name clf -p 8000:8000 -v torch-cache:/cache classifier:1.0
docker logs -f clf                                 # wait for "Application startup complete"
```

**Step 3 — test.**

```bash
curl -s -o dog.jpg https://upload.wikimedia.org/wikipedia/commons/2/26/YellowLabradorLooking_new.jpg
curl -s -F "file=@dog.jpg" localhost:8000/predict
# {"label":"Labrador retriever","score":0.6...}
curl -s localhost:8000/healthz
```

**Step 4 — measure.**

```bash
time (docker restart clf && until curl -sf localhost:8000/healthz >/dev/null; do sleep 0.5; done)  # cold start
for i in $(seq 20); do curl -s -o /dev/null -w "%{time_total}\n" -F "file=@dog.jpg" localhost:8000/predict; done | sort -n | tail -2
docker stats --no-stream clf                       # memory used by the container
```

Write down: image size, cold-start time, slowest of 20 requests, and memory. Section 14 serves this model
properly, and Section 15 makes it faster.

**Example: a results sheet.** Typical numbers on a 4-core laptop (yours will differ):

| Measurement | CPU-only image | Default `torch` wheel (bundles CUDA libraries) |
|---|---|---|
| Image size | ~1.2 GB | ~6–7 GB |
| Cold start, weights already in the `torch-cache` volume | ~4 s | ~6 s |
| Cold start, first run (downloads ~45 MB of weights) | ~8 s | ~10 s |
| Slowest of 20 requests | ~120 ms | ~120 ms (no GPU used) |
| Container memory | ~450 MB | ~500 MB |

The second column is the trap to notice: installing plain `torch` on Linux pulls the CUDA build, which
adds about 5 GB to the image even when the model never touches a GPU.

**Step 5 (optional) — GPU.** Swap the requirements to the `cu124` index, use the CUDA runtime base from
Lecture 27, move the model and tensors to `"cuda"`, and run with `--gpus all`. Compare latency and image
size with the CPU version.

**Expected results:** the CPU image is roughly 1–2 GB, not 10+ GB. `curl` to `/predict` returns a JSON
prediction, and `/healthz` returns 200. A rebuild after a one-line code change takes seconds,
because the dependency layers are cached. `python3 exercises/s04_dockerfile_audit.py Dockerfile` reports no
high-severity findings.

---

## Assessment — Audit a production Dockerfile

**Task:** review this Dockerfile, which a team wants to ship to production. List every problem, explain
the risk, and propose a fix.

```dockerfile
FROM pytorch/pytorch:latest
COPY . .
RUN pip install -r requirements.txt
RUN apt-get update && apt-get install -y libgl1 curl vim
ENV HF_TOKEN=hf_aBcD1234secret
ENV AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG
ADD https://example.com/model.bin /models/model.bin
EXPOSE 22 8000
CMD python serve.py
```

**How to approach it.**

```mermaid
flowchart LR
  A[Reproducibility:<br/>pinned base? pinned deps?] --> B[Security:<br/>secrets? root? extra ports?]
  B --> C[Size:<br/>devel base? weights? caches?]
  C --> D[Build speed:<br/>layer order? .dockerignore?]
  D --> E[Runtime:<br/>exec-form CMD? healthcheck?]
```

**How to read it:** review a Dockerfile in five passes, each asking specific questions.
- **Reproducibility**: is the base image **pinned** (fixed to an exact version or digest, not `latest`) and are
  the Python packages pinned to exact versions? If not, tomorrow's build may differ from today's.
- **Security**: are secrets (keys, tokens) copied into the image, does it run as root, and does it open ports it
  doesn't need?
- **Size**: does it use a `devel` base with compilers, bake in model weights, or leave pip and apt caches behind?
- **Build speed**: are rarely-changing steps (installing packages) placed before often-changing ones (copying
  code), so the layer cache works? Is there a **.dockerignore** file to keep data, `.git`, and virtual
  environments out of the build?
- **Runtime**: is `CMD` written in **exec form** (`CMD ["uvicorn", "app:app"]`, a JSON list) so the app gets
  shutdown signals directly, rather than through a shell? Is there a **healthcheck** command that tells Docker
  whether the app is really working?

**Solution.** Run the audit tool against the example above (it's built in), or against your own file:

```bash
python3 exercises/s04_dockerfile_audit.py
python3 exercises/s04_dockerfile_audit.py path/to/Dockerfile
```

The tool ([`../exercises/s04_dockerfile_audit.py`](../exercises/s04_dockerfile_audit.py)) reports each
finding with a severity, the line number, the risk, and the fix, and exits non-zero on high-severity
findings so it can run in CI. The full list for the example:

| Severity | Line | Problem | Fix |
|---|---|---|---|
| HIGH | 5–6 | Secrets in `ENV`: visible to anyone who pulls the image (`docker history`) | Inject at runtime from a secrets manager; rotate the leaked keys now |
| HIGH | 1 | `latest` tag: builds change silently (new PyTorch/CUDA) | Pin a version, deploy by digest |
| HIGH | — | No `USER`: the app runs as root | `useradd` and `USER 10001` |
| MEDIUM | 2 | `COPY . .` before dependency install: every code change reinstalls everything, and the whole build context (data, `.git`) is copied | Copy `requirements.txt` first, add `.dockerignore` |
| MEDIUM | 7 | Weights baked in via remote `ADD`: huge layer, not verified | Mount from a volume or download at startup with a checksum |
| MEDIUM | 8 | Port 22 exposed: suggests SSH in a container | Remove; use `docker exec` / `kubectl exec` |
| MEDIUM | 9 | Shell-form `CMD`: `sh` is PID 1 and doesn't forward SIGTERM, so in-flight requests are cut off | `CMD ["python", "serve.py"]` |
| LOW | 3 | `pip install` without `--no-cache-dir` | Add the flag or use a cache mount |
| LOW | 4 | `apt-get install` without `--no-install-recommends` and without cleaning lists; `vim` and `curl` in production | Install only what's needed and `rm -rf /var/lib/apt/lists/*` |
| LOW | — | Single-stage build on a heavy ML base | Multi-stage build with a runtime base |
| LOW | — | No `HEALTHCHECK` | Add one, or define Kubernetes probes |
| LOW | — | No `WORKDIR`: files land in `/` | `WORKDIR /app` |

---

## FAANG deep-dive notes

**How big tech does it.** A central build system turns source into images reproducibly, using a shared
remote cache. Platform teams publish blessed base images (CPU, CUDA runtime, CUDA devel), patch them
weekly, and rebuild dependents automatically. Images are scanned, signed, and stored in internal
registries close to each cluster. Weights are not baked into images. Clusters only admit signed images
referenced by digest. Large fleets add lazy pulling or peer-to-peer distribution so scale-ups stay fast.

**Staff review questions.**
- How long does a fresh node take to go from boot to serving, and how much of that is image pull?
- If a critical CVE lands in the base image today, how many hours until every service is rebuilt and redeployed?
- Can you prove which image digest and which model version served a request last Tuesday?
- What stops someone from deploying an unscanned image from Docker Hub?

**Interview question.** "Your ML images are 10 GB and scale-ups take 8 minutes. What do you do?"

**Typical system-design prompt:** *Design the build-and-ship pipeline for 300 ML services whose images are
5–15 GB, so that builds are reproducible, deploys are safe, and new nodes serve within 2 minutes.*

**1. Clarify first:** How often does each service deploy? How large are the weights compared with the
code? How many nodes join during a typical scale-up? Are there compliance needs (SBOMs, signing)?
Single cloud or multi-cloud?

**2. Back-of-envelope sizing:**
- Pushes: 300 services × 3 deploys/week × 10 GB ≈ 9 TB/week into the registry.
- One pull: 10 GB at ~250 MB/s ≈ 40 s to download, then extraction. Typically 1.5–2 minutes in total.
- Scale-up: 50 nodes pulling at once = 500 GB from the registry in a few minutes. That needs a
  per-zone registry cache or peer-to-peer distribution.
- Moving 8 GB of weights out of the image cuts every pull by ~80%.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Weights | Baked into the image | Mounted from a volume or object storage | Mount anything over ~1 GB. Version it separately |
| Base images | Each team picks its own | A few blessed platform images | Blessed images: one patch fixes everyone |
| Image references | Tags | Digests | Tags for humans, digests for deploys |
| Runtime image | Full OS | Slim or distroless | Slim for most cases. Distroless when you can live without a shell for debugging |

**4. Follow-up questions with crisp answers:**
- *Why do CUDA containers fail on some hosts?* The host driver must be new enough for the CUDA runtime
  inside the image. The image carries CUDA. The host carries the driver.
- *How do you make builds reproducible?* Pin base images by digest, pin packages with a lock file,
  and build in CI with a shared cache.
- *What is an SBOM for?* A list of every package in the image. When a CVE is announced, you can find
  every affected image in minutes.

**Debug this (common onsite question):** "A model container keeps exiting with code 137 right after start."
1. Exit code 137 means the process received SIGKILL, usually from the out-of-memory killer. Confirm it
   with `docker inspect --format '{{.State.OOMKilled}}'` or the pod's `OOMKilled` reason.
2. Compare the memory limit with the model size: a 6 GB model under an 8 GB limit.
3. Find the spike: loading a state dict and then copying it into the model briefly holds two copies
   (~12 GB).
4. Fix: load with memory-mapped `safetensors` or straight onto the target device, and set the limit from
   measured peak usage plus headroom.

The lesson: size memory limits by **peak** usage during loading, not by steady-state usage.

**5. What separates senior from staff answers:** a senior engineer writes a lean, cache-friendly
Dockerfile. A staff engineer designs the supply chain: blessed base images, signing and admission control,
SBOM-driven CVE response, separate versioning for weights, and image distribution that keeps scale-ups
fast at fleet size.

**Red flags:**
- `FROM something:latest` in production.
- Secrets in `ENV` or baked into layers.
- Weights baked into multi-GB images that change daily.
- Images built on laptops and pushed by hand.
- No vulnerability scanning or signing.

---

## Quiz

<details><summary>1. What's the difference between an image and a container?</summary>
An image is a read-only, layered template. A container is a running (or stopped) instance of an image with
its own thin writable layer. Many containers can run from one image.
</details>

<details><summary>2. Why should model weights usually not be baked into the image?</summary>
They make images huge, so every deploy and every new node pulls gigabytes, which slows autoscaling and
costs money. Code changes often and weights change rarely, so keep them separate: code in the image,
weights in a volume or object storage.
</details>

<details><summary>3. Your container ignores <code>docker stop</code> and is killed after 10 seconds. Why?</summary>
Probably a shell-form <code>CMD</code>, so <code>/bin/sh</code> is PID 1 and doesn't forward SIGTERM to the
app. Use exec form (<code>CMD ["python", "serve.py"]</code>) or an init such as <code>tini</code>, and handle
SIGTERM in the app.
</details>

<details><summary>4. How do two containers on the same Docker network find each other?</summary>
By container or service name, through Docker's built-in DNS (for example <code>redis:6379</code>). No IP
addresses are needed.
</details>

<details><summary>5. Why use a multi-stage build?</summary>
Build tools (compilers, headers, caches) stay in the builder stage. The final image contains only runtime
artifacts, so it's smaller and has fewer vulnerabilities.
</details>

<details><summary>6. Why do containers not need their own GPU driver?</summary>
The driver lives in the host kernel, which containers share. The NVIDIA Container Toolkit mounts the GPU
device files and the host's driver libraries into the container at start. The image only needs a
compatible CUDA runtime.
</details>

<details><summary>7. A one-line code change makes the build take 10 minutes. What's the likely cause?</summary>
The code is copied before dependencies are installed, so the code change invalidates the cached
dependency layer. Copy <code>requirements.txt</code>, install, then copy the code.
</details>

## Failure modes
- `latest` tags let a silent PyTorch/CUDA upgrade break the model.
- Secrets in `ENV` or copied files end up readable in every pulled image, forever.
- Containers killed with exit code 137 (OOMKilled) because the memory limit is below the peak during model loading.
- The model loaded per request instead of once at startup, so every request takes seconds.
- Data written to the container layer and lost on restart.

## Checklist
- [ ] You can explain image vs container, tag vs digest, and volume vs bind mount
- [ ] Your model image is multi-stage, pinned, non-root, and has no weights or secrets inside
- [ ] Your Compose stack starts the API only after its dependencies are healthy
- [ ] You measured image size, cold start, and latency for your container
- [ ] The Dockerfile audit tool reports no HIGH findings on your Dockerfile
