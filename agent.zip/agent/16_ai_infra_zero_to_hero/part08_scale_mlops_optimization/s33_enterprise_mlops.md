# Section 33 — Enterprise MLOps Foundations

> Lectures 225–231 • Assessment: quiz
> **After this section you can:** explain what changes when MLOps serves hundreds of models and teams, describe
> Kubeflow's components and multi-user model, run MLflow as a shared, secure, scalable service with registry aliases,
> build the same train-evaluate-register pipeline on SageMaker Pipelines, Vertex AI Pipelines, and Azure ML, choose
> between them, and build and run a Kubeflow pipeline with caching, conditions, GPU steps, and artifact lineage.
>
> Builds on: [Section 9](../part03_mlops_cicd_cost/s09_experiment_tracking.md) (experiment tracking, registry) and
> [Section 10](../part03_mlops_cicd_cost/s10_cicd_for_ai.md) (CI/CD and quality gates).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 225 | What is enterprise MLOps? | A shared platform with paved paths, so hundreds of teams ship models safely without each rebuilding the plumbing |
| 226 | Introduction to Kubeflow | A Kubernetes-native toolkit: Pipelines, Notebooks, Katib, Trainer, KServe, and a model registry, with per-team profiles |
| 227 | Introduction to MLflow at scale | Run tracking as a service: database backend, object store artifacts, auth, aliases, and quotas |
| 228 | SageMaker Pipelines basics | AWS-managed pipelines from Python steps: processing, training, condition, register, with caching |
| 229 | GCP Vertex AI Pipelines | Managed Kubeflow Pipelines: compile with the KFP SDK, run serverless, lineage in Vertex ML Metadata |
| 230 | Azure ML pipelines | Components and pipelines in the v2 SDK or YAML, on compute clusters, with registries shared across workspaces |
| 231 | Lab: build a pipeline in Kubeflow | Preprocess, train, evaluate, and conditionally register, with caching and lineage, on a local cluster |

```mermaid
flowchart LR
  TEAMS["Many product teams"] --> PAVED["Paved path<br/>templates, SDK, CI"]
  PAVED --> ORCH{"Pipeline orchestrator"}
  ORCH --> KFP["Kubeflow Pipelines<br/>self-managed on Kubernetes"]
  ORCH --> SM["SageMaker Pipelines<br/>AWS managed"]
  ORCH --> VX["Vertex AI Pipelines<br/>GCP managed KFP"]
  ORCH --> AML["Azure ML pipelines<br/>Azure managed"]
  KFP & SM & VX & AML --> TRACK["Tracking + registry<br/>MLflow or cloud-native"]
  TRACK --> GATE["Quality and approval gates"]
  GATE --> SERVE["Serving + monitoring"]
  GOV["Identity, quotas, cost, audit"] -.-> ORCH
  GOV -.-> TRACK
```

**How to read it:** an enterprise platform gives many teams one paved path: templates, a shared SDK, and CI
integration. Their pipelines run on one orchestrator, either self-managed Kubeflow or a cloud-managed service.
Every run logs to a shared tracking and registry service, passes quality and approval gates, and deploys to serving
with monitoring. Identity, quotas, cost tracking, and audit apply across all of it.

**Terms in this diagram.**
- **Paved path**: the supported, documented way to do something, such as "train and deploy a model", that's easier
  than building your own. Teams may leave it, but then they own the extra work.
- **Templates, SDK, CI**: starter project templates, a shared Python library wrapping the platform's APIs, and
  continuous integration that builds and tests pipelines automatically (Section 10).
- **Pipeline orchestrator**: the system that runs a pipeline's steps in order, passes data between them, retries
  failures, and records what happened.
- **Kubeflow Pipelines (KFP)**: the open-source pipeline orchestrator in Kubeflow, running on your own Kubernetes
  cluster (Lecture 226).
- **SageMaker, Vertex AI, Azure ML**: the managed machine-learning platforms of AWS, Google Cloud, and Microsoft Azure
  (Lectures 228–230).
- **Tracking + registry**: storage of every run's parameters, metrics, and artifacts, and the catalog of approved
  model versions (Section 9, Lecture 227).
- **Quality and approval gates**: automated checks, such as a minimum accuracy, and human sign-offs that a model must
  pass before deployment (Section 10).
- **Identity, quotas, cost, audit**: who may do what, resource limits per team, spend tracking, and a record of every
  action.

---

## Lecture 225 — What is enterprise MLOps?

**Why it matters.** One team with three models can run notebooks, a cron job, and a spreadsheet of model versions.
A company with 400 models across 60 teams can't: every team would rebuild the same pipelines, nobody could say which
model is in production or what data trained it, and an auditor's question takes weeks. Enterprise MLOps is the
platform that solves this once.

**In plain words.** Small restaurants each have their own kitchen. A restaurant chain builds a central kitchen with
standard recipes, shared suppliers, safety inspections, and one ordering system, so a new branch opens in weeks,
food tastes the same everywhere, and a health inspector can trace every ingredient.

**Architecture: the layers of an enterprise ML platform.**

```mermaid
flowchart TB
  subgraph EXP["Experience layer"]
    NB["Notebooks + IDEs"]
    TPL["Project templates<br/>cookiecutter, repo generator"]
    SDK["Platform SDK + CLI"]
  end
  subgraph CORE["Core services"]
    PIPE["Pipelines + scheduling"]
    FEAT["Feature store"]
    TRK["Tracking + model registry"]
    SRV["Serving + monitoring"]
  end
  subgraph INFRA["Infrastructure"]
    K8S["Kubernetes or managed compute<br/>CPU and GPU pools, Kueue"]
    DATA[("Lake, warehouse,<br/>object storage")]
  end
  subgraph GOVL["Governance (every layer)"]
    IAM["SSO, RBAC, per-team namespaces"]
    LIN["Lineage + audit"]
    COST["Quotas + showback"]
  end
  EXP --> CORE --> INFRA
  GOVL -.-> EXP
  GOVL -.-> CORE
  GOVL -.-> INFRA
```

**How to read it:** data scientists work in the experience layer (notebooks, templates, and an SDK). Those tools
call shared core services for pipelines, features, tracking, and serving. Everything runs on shared infrastructure.
Governance cuts across every layer: who may access what, a record of how every model was built, and who pays for it.

**Terms in this diagram.**
- **Cookiecutter, repo generator**: tools that create a new project from a template, with the folder layout, CI files,
  and pipeline skeleton already in place.
- **Platform SDK + CLI**: a Python library and command-line tool that wrap the platform, so users run
  `platform train` instead of writing Kubernetes YAML.
- **Feature store**: the service that serves the same feature values to training and inference (Section 24).
- **Kueue**: Kubernetes' job queue, which shares GPU pools fairly between teams (Section 11).
- **SSO, RBAC, per-team namespaces**: single sign-on, role-based access control (permissions granted by role), and a
  separate Kubernetes namespace per team (Sections 5 and 18).
- **Lineage**: the recorded chain from data and code to a trained model and its deployment, so you can trace any
  prediction back to its sources.
- **Showback**: reporting each team's spend to them, without necessarily charging them (Section 12).

**Core ideas.**
- **Maturity levels.** Google's MLOps levels are a useful shorthand.
  - **Level 0**: manual, notebook-driven training and hand-off.
  - **Level 1**: automated training pipelines with continuous training on new data.
  - **Level 2**: CI/CD for the pipelines themselves, so pipeline code is tested and deployed like any service.
  - Most enterprises have teams at all three levels at once. The platform's job is to make level 2 the easy path.
- **Platform as a product.**
  - The platform team has users, a roadmap, documentation, an SLO, and adoption metrics.
  - Its key metrics are time from idea to first production model, the share of models on the paved path, and
    incidents caused by platform gaps.
- **Standardize interfaces, not models.** Teams keep their choice of framework, but must use the standard pipeline
  format, tracking API, registry, and deployment contract. That's what makes lineage and governance possible.
- **Build vs buy.**
  - Managed services (SageMaker, Vertex, Azure ML) remove operational work.
  - Self-managed Kubeflow and MLflow give portability, control, and lower cost at large scale, with more people needed
    to run them.
  - Many enterprises mix: open-source tracking and registry, with cloud-managed compute.
- **Multi-tenancy from day one.** Per-team namespaces, quotas, and cost attribution are hard to add later
  (Section 40).

**Example: from 9 weeks to 6 days.** A bank's 40 data science teams each built their own deployment scripts. The
median time from approved model to production was 9 weeks, mostly spent on security reviews of each custom setup.
The platform team shipped a template (pipeline, tests, a standard serving container, and pre-approved IAM roles) and
a shared MLflow registry with an approval workflow. Security reviewed the template once. Teams on the paved path
reached production in a median of 6 days, and the share of models with full lineage went from 20% to 85% in a year.

**Senior / FAANG best practice.** Run the ML platform as a product with named users, SLOs, and adoption metrics.
Standardize the interfaces (pipeline format, tracking API, registry stages, serving contract) and leave frameworks
open. Pre-approve security for the paved path so it's also the fastest path. Build multi-tenancy, quotas, and cost
attribution in from the start, and measure time-to-production as the headline metric.

---

## Lecture 226 — Introduction to Kubeflow

**Why it matters.** Kubeflow is the most widely used open-source ML platform for Kubernetes. Vertex AI Pipelines runs
Kubeflow's pipeline format, and many enterprises run Kubeflow on-premises or in their own cloud accounts for control
and portability. Knowing its parts tells you what an ML platform needs, even if you end up buying one.

**In plain words.** Kubeflow is a toolkit of separate tools that share one workshop: a place to experiment
(notebooks), an assembly line (pipelines), an automatic tuning machine (Katib), a training floor for big jobs
(Trainer), a shop counter (KServe), and a catalog of finished products (model registry). Each team gets its own
locked room in the workshop (a profile).

**Architecture: Kubeflow components.**

```mermaid
flowchart TB
  USER["Data scientist<br/>browser + SDK"] --> GW["Istio gateway + Dex / OIDC<br/>login, per-user identity"]
  GW --> DASH["Central dashboard"]
  DASH --> NBK["Notebooks<br/>Jupyter, VS Code pods"]
  DASH --> KFPC["Pipelines<br/>KFP API, UI, Argo Workflows"]
  DASH --> KAT["Katib<br/>hyperparameter tuning"]
  KFPC --> TRN["Trainer<br/>PyTorchJob, TrainJob"]
  KFPC --> KS["KServe<br/>InferenceService"]
  KFPC --> MR["Model Registry"]
  PROF["Profiles: one namespace per team<br/>RBAC + Istio policies"] -.-> NBK
  PROF -.-> KFPC
  KFPC --> ART[("Artifact store<br/>MinIO or S3, MySQL metadata")]
```

**How to read it:** users log in through an Istio gateway with an identity provider, and reach a central dashboard.
From there they open notebooks, build and run pipelines, launch tuning experiments, train large models, deploy with
KServe, and register models. Each team works inside its own profile, which is a Kubernetes namespace with access
rules. Pipelines store their artifacts in object storage and their run records in a database.

**Terms in this diagram.**
- **Istio gateway + Dex / OIDC**: **Istio** is a service mesh that routes and secures traffic between services
  (Section 13). **Dex** is an identity broker that connects to the company login system through **OIDC** (OpenID
  Connect), so every request carries the user's identity.
- **Central dashboard**: Kubeflow's web portal linking all components.
- **Notebooks**: Jupyter or VS Code environments running as pods in the user's namespace, with requested CPUs or GPUs.
- **KFP API, UI, Argo Workflows**: the Kubeflow Pipelines API server, its web UI, and **Argo Workflows**, the
  Kubernetes workflow engine that actually runs each pipeline step as a pod.
- **Katib**: Kubeflow's hyperparameter tuning and neural architecture search service. It launches many trial runs and
  searches for the best settings.
- **Trainer, PyTorchJob, TrainJob**: the Kubeflow Training Operator and its job types for distributed training
  (Section 11, Lecture 222).
- **KServe, InferenceService**: Kubeflow's model serving system. An **InferenceService** object declares a model to
  serve, with autoscaling and canary rollouts (Section 14).
- **Model Registry**: Kubeflow's catalog of registered models, versions, and their artifact locations.
- **Profiles, RBAC + Istio policies**: a **profile** creates one namespace per team or user, plus Kubernetes RBAC
  rules and Istio authorization policies that block other users.
- **MinIO or S3, MySQL metadata**: **MinIO** is S3-compatible object storage you can run yourself. KFP keeps run
  records in **MySQL** and lineage in its ML metadata store.

**Core ideas.**
- **Kubeflow Pipelines v2 (KFP v2).**
  - Pipelines are Python functions decorated with `@dsl.pipeline`. Steps are **components**, decorated with
    `@dsl.component`, each running in its own container.
  - Pipelines compile to an **IR YAML** file (a portable intermediate representation), which runs on Kubeflow, on
    Vertex AI, or locally.
  - Typed **artifacts** (`Dataset`, `Model`, `Metrics`) are passed between steps through object storage, and their
    lineage is recorded automatically.
- **Caching.** If a step's code, image, and inputs haven't changed, KFP reuses its previous outputs instead of
  re-running it. This saves hours in iterative development. Turn it off for steps that read changing data, such as
  "fetch yesterday's data".
- **Control flow.** `dsl.If` and `dsl.Else` run steps conditionally (for example, register only if accuracy passes),
  `dsl.ParallelFor` fans out, and `dsl.ExitHandler` always runs a cleanup or notification step.
- **Resources per step.** Each task can request CPU, memory, GPUs, node selectors, and tolerations, so a pipeline
  mixes cheap CPU preprocessing with a GPU training step.
- **Operating Kubeflow is real work.** It's a dozen services with upgrades, authentication, storage, and
  multi-tenancy to manage. Many teams install only the parts they need ("standalone KFP" plus KServe) or use a
  managed distribution.

```python
from kfp import dsl

@dsl.component(base_image="python:3.11-slim", packages_to_install=["scikit-learn==1.5.2"])
def train(data: dsl.Input[dsl.Dataset], model: dsl.Output[dsl.Model], c: float = 1.0):
    import pickle, pandas as pd
    from sklearn.linear_model import LogisticRegression
    df = pd.read_csv(data.path)
    clf = LogisticRegression(C=c, max_iter=500).fit(df.drop(columns="y"), df["y"])
    pickle.dump(clf, open(model.path, "wb"))
    model.metadata["framework"] = "sklearn"
```

In the code, `base_image` is the container image the step runs in, and `packages_to_install` adds Python packages
at start-up. `dsl.Input[dsl.Dataset]` declares an input artifact, and KFP downloads it and gives the local file path
as `data.path`. `dsl.Output[dsl.Model]` declares an output artifact. Whatever the step writes to `model.path` is
uploaded to object storage and linked in lineage. `model.metadata` attaches searchable key-value labels.

**Example: caching saves a day a week.** A team's pipeline spent 3 hours on feature engineering before a 40-minute
training step. During model development they changed only the training code, but every run repeated the 3 hours.
With KFP caching on (and the feature step's inputs pinned to a dated snapshot), reruns skipped straight to
training. The team ran 4× more experiments per week on the same budget.

**Senior / FAANG best practice.** Use KFP v2 with typed artifacts, pin every component image by digest, and keep
components small and reusable across pipelines. Turn on caching deliberately, and disable it for steps that read
changing sources. Give each team a profile with quotas. Install only the Kubeflow parts you'll operate, and treat
upgrades as a quarterly project with a staging cluster.

---

## Lecture 227 — Introduction to MLflow at scale

**Why it matters.** MLflow is the most common experiment tracker and model registry. A laptop `mlruns/` folder works
for one person. A company needs a shared server that thousands of runs can write to at once, that stores artifacts
safely, enforces who can change the registry, and stays up. Running MLflow at scale is a small platform project of its
own.

**In plain words.** A lab notebook for one scientist becomes a records office for a whole institute: a proper filing
system (database), a warehouse for large items (object storage), a front desk that checks badges (authentication),
and clear labels on which version is "approved for use" (aliases).

**Architecture: MLflow as a shared service.**

```mermaid
flowchart LR
  CL["Training jobs, notebooks,<br/>pipelines: mlflow client"] --> LB["Load balancer + SSO proxy<br/>OIDC, per-user identity"]
  LB --> TS["MLflow tracking servers<br/>3+ replicas, stateless"]
  TS --> DB[("PostgreSQL<br/>runs, params, metrics, registry")]
  TS -->|"--serve-artifacts proxy"| OBJ[("S3 / GCS / Blob<br/>artifacts, models")]
  CL -.->|"or direct upload<br/>with own credentials"| OBJ
  REG["Model registry<br/>versions, aliases, tags"] --> DB
  CD["CI/CD + serving<br/>load models:/name@champion"] --> TS
```

**How to read it:** clients log runs through a load balancer that enforces single sign-on. Several stateless
tracking servers handle requests and keep everything in a PostgreSQL database. Large artifacts go to object storage,
either proxied through the server or uploaded directly by clients that have their own credentials. The model
registry lives in the same database. Deployment tools load models by name and alias, such as "the champion version
of fraud-detector".

**Terms in this diagram.**
- **mlflow client**: the MLflow Python library inside training code, calling `mlflow.log_param`, `log_metric`, and so
  on.
- **SSO proxy**: a reverse proxy, such as oauth2-proxy, that requires company login before forwarding requests to
  MLflow, and passes along the user's identity.
- **Stateless**: the servers keep nothing on local disk, so you can run several behind a load balancer and replace
  any of them.
- **PostgreSQL**: the relational database that stores runs, parameters, metrics, and registry entries.
- **--serve-artifacts proxy**: a server mode where clients send artifacts to the tracking server, which writes them
  to object storage. Clients then don't need storage credentials.
- **S3 / GCS / Blob**: object storage on AWS, Google Cloud, and Azure.
- **Versions, aliases, tags**: each registered model has numbered **versions**. An **alias** such as `champion` is a
  movable name pointing at one version. **Tags** are free-form labels, such as `validation_status=approved`.
- **models:/name@champion**: the URI format for loading the version a given alias points to.

**Core ideas.**
- **Backend and artifact stores are separate.**
  - Metadata (runs, metrics, registry) goes to a database: PostgreSQL or MySQL, never the default SQLite file for
    shared use.
  - Artifacts (models, plots, data samples) go to object storage.
- **Scale the write path.**
  - Thousands of jobs logging metrics every step can overload the server. Log in batches (`mlflow.log_metrics` with a
    dictionary, or `MlflowClient.log_batch`), log every N steps, and use asynchronous logging
    (`mlflow.config.enable_async_logging()`).
  - Index the database and archive old experiments.
- **Security.**
  - Open-source MLflow has a basic-auth app (`--app-name basic-auth`) with per-experiment and per-model permissions.
    Enterprises usually put it behind an SSO proxy, or use a managed MLflow (Databricks, SageMaker, Azure ML), which
    adds full access control.
  - Never expose an unauthenticated MLflow server: it can read and write your artifact store.
- **Registry aliases replace stages.**
  - MLflow 2.9+ deprecated the fixed "Staging/Production" stages in favor of **aliases** (`@champion`,
    `@challenger`) and tags.
  - Promotion moves an alias, so rollback is moving it back. Serving always loads by alias.
- **Separate environments.** Many companies run one registry per environment (dev, prod) and copy approved models
  between them, or one shared registry with strict permissions on production aliases.

```bash
mlflow server \
  --backend-store-uri postgresql://mlflow:${DB_PASS}@mlflow-db:5432/mlflow \
  --artifacts-destination s3://acme-mlflow-artifacts \
  --serve-artifacts --host 0.0.0.0 --port 5000 --workers 8
```

```python
import mlflow
from mlflow import MlflowClient

mlflow.set_tracking_uri("https://mlflow.internal.acme.com")
mlflow.config.enable_async_logging()
with mlflow.start_run(run_name="fraud-xgb-2026-11-12") as run:
    mlflow.log_params({"max_depth": 6, "eta": 0.1})
    for step in range(0, 1000, 50):
        mlflow.log_metrics({"auc": 0.90 + step / 1e5, "loss": 0.3 - step / 1e4}, step=step)
    info = mlflow.sklearn.log_model(clf, name="model", registered_model_name="fraud-detector")

client = MlflowClient()
client.set_registered_model_alias("fraud-detector", "challenger", info.registered_model_version)
model = mlflow.pyfunc.load_model("models:/fraud-detector@champion")      # what serving loads
```

In the commands, `--workers 8` runs 8 server processes. `${DB_PASS}` comes from a secret, never typed into a file
(Section 18). In the Python code, `enable_async_logging` sends metrics in the background so training never waits on
the server. `log_model` with `registered_model_name` saves the model and creates a new registry version in one call.
`set_registered_model_alias` points `challenger` at that version. Promotion to `champion` happens later, after the
gates pass. `mlflow.pyfunc.load_model` loads any model flavor behind one generic `predict` interface.

**Example: the server that fell over every Monday.** A company's single MLflow server, with a SQLite file on a
shared disk, became unusable every Monday when weekly retraining jobs started. Hundreds of jobs logged every step,
and SQLite locked the whole file on each write. Moving to PostgreSQL, three server replicas behind a load balancer,
batched and asynchronous logging, and logging every 50 steps cut request volume 40× and ended the outages.

**Senior / FAANG best practice.** Run MLflow with PostgreSQL, object storage, multiple stateless replicas, SSO in
front, and backups of both stores. Make batched, asynchronous logging the default in your platform SDK. Use aliases
and tags for promotion, restrict who can move production aliases, and have serving load only by alias. Monitor the
server's latency and error rate like any production service, and set retention for old experiments.

---

## Lecture 228 — SageMaker Pipelines basics

**Why it matters.** On AWS, SageMaker Pipelines is the managed way to automate ML workflows without running an
orchestrator yourself. It integrates with SageMaker training, processing, the model registry, and IAM, so a team can
go from notebook to scheduled, audited pipeline in days.

**In plain words.** Instead of building your own assembly line, you rent AWS's: you describe the stations (prepare,
train, check, register) in Python, and AWS runs them on machines it starts and stops for you, keeping a record of
every run.

**Architecture: a SageMaker training pipeline.**

```mermaid
flowchart LR
  TRIG["EventBridge schedule<br/>or new data in S3"] --> PIPE["SageMaker Pipeline<br/>parameters: data date, instance type"]
  PIPE --> PROC["ProcessingStep<br/>feature prep on ml.m5.4xlarge"]
  PROC --> TRAIN["TrainingStep<br/>ml.g5.2xlarge, spot + checkpoints"]
  TRAIN --> EVAL["ProcessingStep: evaluate<br/>writes evaluation.json"]
  EVAL --> COND{"ConditionStep<br/>AUC at least 0.90?"}
  COND -->|"yes"| REG["ModelStep: register<br/>status PendingManualApproval"]
  COND -->|"no"| FAIL["FailStep<br/>with reason"]
  REG --> APPROVE["Human approves in registry"]
  APPROVE --> DEPLOY["EventBridge rule triggers<br/>deployment pipeline"]
```

**How to read it:** a schedule or a new-data event starts the pipeline with parameters. A processing step prepares
features, a training step trains on a GPU instance (on cheaper spot capacity, with checkpoints), and an evaluation
step writes metrics to a file. A condition step reads that file: if the model passes, it's registered awaiting
approval, and otherwise the pipeline fails with a reason. When a human approves the model, an event starts a separate
deployment pipeline.

**Terms in this diagram.**
- **EventBridge**: AWS's event bus and scheduler. It can start a pipeline on a cron schedule or when a file lands in
  S3.
- **Pipeline parameters**: values supplied per run, such as the data date or the instance type, so one definition
  serves many runs.
- **ProcessingStep**: a SageMaker job that runs a script in a container for data preparation or evaluation.
- **ml.m5.4xlarge, ml.g5.2xlarge**: SageMaker instance types. `m5` is general-purpose CPU, and `g5` has an NVIDIA A10G
  GPU.
- **TrainingStep, spot + checkpoints**: a SageMaker training job. **Managed spot training** uses spare capacity at up to
  ~70–90% off, and checkpoints written to S3 let it resume after interruptions (Section 12).
- **evaluation.json, ConditionStep**: the evaluation script writes its metrics to a JSON file, declared as a
  **property file** so later steps can read values from it. A **ConditionStep** branches on those values.
- **ModelStep: register, PendingManualApproval**: registers a new version in the **SageMaker Model Registry**, inside
  a **model package group**, with approval status "pending manual approval".
- **FailStep**: ends the run as failed with an explicit error message.

**Core ideas.**
- **Steps and data passing.** Steps exchange data through S3 locations. A step's outputs are referenced with
  `step.properties`, which also creates the dependency between steps automatically.
- **Caching.** `CacheConfig(enable_caching=True, expire_after="P30D")` reuses a step's result when its arguments are
  unchanged, for up to 30 days (`P30D` is the ISO 8601 notation for a 30-day period).
- **Pipeline sessions.** With `PipelineSession`, calls such as `estimator.fit()` don't start a job immediately.
  Instead they return step arguments, so the same code defines the pipeline.
- **IAM per pipeline.** The pipeline runs with an execution role. Scope it to the buckets, ECR repositories, and
  registry groups it needs (Section 18).
- **Where it fits.** It's best for AWS-centric teams that use SageMaker training and endpoints. Cross-cloud
  portability is low, and complex control flow is more limited than in Kubeflow or Airflow.

```python
from sagemaker.workflow.pipeline_context import PipelineSession
from sagemaker.workflow.parameters import ParameterString
from sagemaker.workflow.steps import TrainingStep, CacheConfig
from sagemaker.workflow.condition_step import ConditionStep
from sagemaker.workflow.conditions import ConditionGreaterThanOrEqualTo
from sagemaker.workflow.functions import JsonGet
from sagemaker.workflow.fail_step import FailStep
from sagemaker.workflow.model_step import ModelStep
from sagemaker.workflow.pipeline import Pipeline
from sagemaker.estimator import Estimator
from sagemaker.model import Model

sess = PipelineSession()
role = "arn:aws:iam::123456789012:role/sm-pipeline-fraud"
data_date = ParameterString("DataDate", default_value="2026-11-11")
cache = CacheConfig(enable_caching=True, expire_after="P30D")

est = Estimator(image_uri=TRAIN_IMAGE, role=role, instance_type="ml.g5.2xlarge", instance_count=1,
                use_spot_instances=True, max_run=3600, max_wait=7200,
                checkpoint_s3_uri="s3://acme-ml/fraud/checkpoints/", sagemaker_session=sess)
train = TrainingStep("Train", step_args=est.fit({"train": prep.properties.ProcessingOutputConfig
                                                 .Outputs["train"].S3Output.S3Uri}), cache_config=cache)

auc = JsonGet(step_name=evaluate.name, property_file=eval_report, json_path="metrics.auc.value")
model = Model(image_uri=SERVE_IMAGE, model_data=train.properties.ModelArtifacts.S3ModelArtifacts,
              role=role, sagemaker_session=sess)
register = ModelStep("Register", step_args=model.register(
    model_package_group_name="fraud-detector", approval_status="PendingManualApproval",
    content_types=["application/json"], response_types=["application/json"]))
gate = ConditionStep("AucGate", conditions=[ConditionGreaterThanOrEqualTo(left=auc, right=0.90)],
                     if_steps=[register], else_steps=[FailStep("TooWeak", error_message="AUC below 0.90")])

pipe = Pipeline("fraud-train", parameters=[data_date], steps=[prep, train, evaluate, gate], sagemaker_session=sess)
pipe.upsert(role_arn=role)
pipe.start(parameters={"DataDate": "2026-11-12"})
```

In the code, `prep` and `evaluate` are processing steps defined the same way, and `eval_report` is the
`PropertyFile` that the evaluation step declares for `evaluation.json`. `max_wait` must be larger than `max_run` for
spot training, because it includes time spent waiting for capacity. `JsonGet` reads the AUC value from that file at
run time. `upsert` creates or updates the pipeline definition, and `start` launches a run with chosen parameters.

**Example: approval as the audit trail.** An insurer's regulator required evidence of who approved each pricing
model and on what metrics. Their SageMaker pipeline registered every candidate as "PendingManualApproval", with the
evaluation report attached. A model risk reviewer approved it in the registry, and that approval event triggered
deployment. The registry's history became the audit evidence, with no separate spreadsheet.

**Senior / FAANG best practice.** Define pipelines in code reviewed in Git and deployed by CI, not edited in the
console. Use parameters for dates and instance types, caching for expensive stable steps, spot with checkpoints for
training, and a separate least-privilege execution role per pipeline. Gate registration on evaluation metrics, require
human approval for regulated models, and trigger deployment from approval events.

---

## Lecture 229 — GCP Vertex AI Pipelines

**Why it matters.** Vertex AI Pipelines runs Kubeflow Pipelines definitions as a fully managed, serverless service:
you write KFP v2 code, and Google runs it with no cluster to manage. That makes KFP skills portable between your own
Kubernetes and Google Cloud.

**In plain words.** It's Kubeflow's assembly line without owning the factory. You bring the same blueprints, and
Google provides and maintains the building, the machines, and the record-keeping.

**Architecture: a KFP pipeline on Vertex AI.**

```mermaid
flowchart LR
  CODE["pipeline.py<br/>KFP v2 SDK"] -->|"compile"| IR["pipeline.yaml<br/>IR spec"]
  IR --> AR[("Artifact Registry<br/>pipeline templates")]
  AR --> JOB["aiplatform.PipelineJob<br/>service account, pipeline_root gs://"]
  JOB --> RUN["Vertex runs each step<br/>serverless containers, GPUs on demand"]
  RUN --> GCPC["Google Cloud Pipeline Components<br/>BigQuery, CustomJob, Model upload"]
  RUN --> MD[("Vertex ML Metadata<br/>artifacts + lineage")]
  RUN --> VMR["Vertex Model Registry<br/>versions + aliases"]
  SCHED["Scheduler API<br/>cron runs"] --> JOB
```

**How to read it:** you write the pipeline with the KFP v2 SDK and compile it to a YAML spec, optionally storing it
as a versioned template. A `PipelineJob` submits it with a service account and a Cloud Storage location for
intermediate artifacts. Vertex runs each step in its own container, requesting GPUs as needed. Prebuilt Google
components call BigQuery, custom training jobs, and model upload. Every artifact and its lineage is recorded in Vertex
ML Metadata, and models land in the Vertex Model Registry.

**Terms in this diagram.**
- **IR spec**: the compiled pipeline definition in KFP's portable intermediate representation, the same file that
  runs on Kubeflow.
- **Artifact Registry, pipeline templates**: Google's registry for container images and other packages. It can store
  compiled pipelines as versioned templates.
- **aiplatform.PipelineJob**: the Vertex AI Python SDK class that submits a pipeline run.
- **Service account**: the Google Cloud identity the pipeline runs as, which decides what it can access.
- **pipeline_root gs://**: the Cloud Storage folder where steps write their output artifacts.
- **Serverless containers**: Vertex starts a container per step on Google-managed machines and stops it afterwards,
  so you pay only while steps run.
- **Google Cloud Pipeline Components (GCPC)**: prebuilt KFP components for Google services, such as running a BigQuery
  query, launching a `CustomJob` for training, or uploading a model.
- **Vertex ML Metadata**: the managed metadata store that records artifacts, executions, and lineage.
- **Vertex Model Registry**: Google's model registry, with versions and aliases such as `default` or `champion`.
- **Scheduler API**: Vertex's built-in way to run a pipeline on a cron schedule.

**Core ideas.**
- **Same SDK, different backend.**
  - Pipelines compiled with the KFP v2 SDK run on Vertex with little or no change.
  - Differences are in platform features: machine types and accelerators are requested with
    `set_accelerator_type("NVIDIA_L4")` style names, and Google-specific components replace in-cluster services.
- **Heavy training goes to CustomJob.** For distributed or long GPU training, a pipeline step often launches a Vertex
  `CustomJob` (with worker pools, reservations, or spot VMs) instead of running training inside the step container.
- **Lineage for free.** Each artifact links to the run and step that produced it, and the step's inputs, which gives
  "which data trained this model?" answers in the console or via the SDK.
- **Caching** works as in KFP and is enabled per run (`enable_caching=True`) or per task.
- **Networking and security.** Run pipelines with a dedicated service account, VPC Service Controls (a security
  perimeter around Google APIs), and a private network peering when steps need private databases. Use CMEK
  (customer-managed encryption keys) for regulated data.

```python
from kfp import compiler, dsl
from google.cloud import aiplatform

@dsl.pipeline(name="churn-train")
def pipeline(table: str = "acme.analytics.churn_features", min_auc: float = 0.85):
    data = export_bq(table=table)
    trained = train(data=data.outputs["dataset"]).set_accelerator_type("NVIDIA_L4").set_accelerator_limit(1)
    metrics = evaluate(model=trained.outputs["model"], data=data.outputs["dataset"])
    with dsl.If(metrics.outputs["auc"] >= min_auc):
        upload_model(model=trained.outputs["model"])

compiler.Compiler().compile(pipeline, "churn.yaml")
aiplatform.init(project="acme-ml", location="europe-west4")
aiplatform.PipelineJob(display_name="churn-train", template_path="churn.yaml",
                       pipeline_root="gs://acme-ml-pipelines/churn", enable_caching=True,
                       parameter_values={"min_auc": 0.86}).submit(
    service_account="pipelines-churn@acme-ml.iam.gserviceaccount.com")
```

In the code, `export_bq`, `train`, `evaluate`, and `upload_model` are KFP components defined elsewhere (Lecture 231
shows how). `set_accelerator_type("NVIDIA_L4")` requests one NVIDIA L4 GPU for the training step. `dsl.If` runs the
upload only when the AUC output meets the threshold. `submit` starts the run without waiting, while `run` would
wait for it to finish.

**Example: one pipeline, two clouds.** A retailer ran Kubeflow on-premises for stores' data under data-residency
rules, and Vertex AI for online analytics. Because both used KFP v2, the same pipeline package ran in both places.
Only the components that touched storage differed (MinIO on-premises, BigQuery on Google Cloud), chosen by a pipeline
parameter. The team maintained one codebase instead of two.

**Senior / FAANG best practice.** Write pipelines with the KFP v2 SDK to keep them portable, keep platform-specific
calls in a few swappable components, and send heavy training to `CustomJob`. Run every pipeline with its own service
account inside VPC Service Controls. Store compiled templates in Artifact Registry with versions, schedule with the
Scheduler API, and use ML Metadata lineage in audits.

---

## Lecture 230 — Azure ML pipelines

**Why it matters.** Enterprises standardized on Microsoft (Entra ID, Azure DevOps, Microsoft 365) often run ML on
Azure Machine Learning. Its v2 pipelines combine reusable components, managed compute clusters, and registries that
share models and components across workspaces and regions.

**In plain words.** Azure ML organizes work into workspaces, like separate offices, and gives you reusable recipe
cards (components) to combine into a full meal plan (pipeline). A shared central pantry (registry) lets every office
use the same approved recipes and finished dishes.

**Architecture: Azure ML pipeline and registry.**

```mermaid
flowchart TB
  DEV["Developer or CI<br/>az ml CLI v2, Python SDK v2"] --> WS["Workspace: dev"]
  WS --> PJ["Pipeline job<br/>prep, train, evaluate components"]
  PJ --> CC["Compute cluster<br/>Standard_NC24ads_A100_v4, 0 to 8 nodes"]
  PJ --> DSTORE[("Datastore<br/>Blob or ADLS Gen2, data assets")]
  PJ --> MREG["Model registered in workspace"]
  MREG -->|"promote"| REG[("Azure ML registry<br/>shared components, models, environments")]
  REG --> WSP["Workspace: prod<br/>managed online endpoint"]
  ENTRA["Entra ID + managed identity<br/>RBAC per workspace"] -.-> WS
  ENTRA -.-> WSP
```

**How to read it:** developers or CI submit a pipeline job to a development workspace, using the CLI or Python SDK.
Its components run on an autoscaling GPU compute cluster and read data from a datastore. The resulting model is
registered in the workspace, then promoted to a shared registry, from which the production workspace deploys it to a
managed endpoint. Identity and permissions come from Entra ID, with managed identities for jobs.

**Terms in this diagram.**
- **az ml CLI v2, Python SDK v2**: Azure ML's current command-line extension and Python library (`azure-ai-ml`).
- **Workspace**: the top-level Azure ML resource holding jobs, models, data, and compute for one team or environment.
- **Pipeline job, components**: a **component** is a reusable step with declared inputs, outputs, a command, and an
  environment. A **pipeline job** connects components.
- **Compute cluster, Standard_NC24ads_A100_v4, 0 to 8 nodes**: an autoscaling pool of VMs. This VM size has one
  NVIDIA A100 80 GB GPU. Minimum 0 nodes means no cost when idle.
- **Datastore, Blob or ADLS Gen2, data assets**: a **datastore** is a registered connection to storage such as Azure
  **Blob** Storage or **ADLS Gen2** (Azure Data Lake Storage). **Data assets** are named, versioned references to data.
- **Azure ML registry**: a shared store, outside any single workspace, for components, environments, and models, so
  dev, test, and prod workspaces (even in different regions) use identical assets.
- **Managed online endpoint**: Azure ML's hosted real-time serving with autoscaling and traffic splitting (Section
  14).
- **Entra ID + managed identity**: Microsoft's identity service (formerly Azure Active Directory), and identities
  assigned to compute so jobs access storage without stored secrets (Section 18).

**Core ideas.**
- **Components are the unit of reuse.** Define them in YAML or Python, version them, and publish them to a registry
  so all teams use the same approved preprocessing or evaluation step.
- **Environments pin dependencies.** An **environment** is a Docker image plus a Conda or pip spec, versioned like
  code. Curated environments exist for PyTorch and other frameworks.
- **Compute choices.** Compute clusters autoscale for pipeline steps. **Serverless compute** runs jobs without
  creating a cluster. Kubernetes compute attaches your own AKS or Arc-enabled cluster.
- **MLflow is native.** Azure ML workspaces expose an MLflow tracking URI, so standard `mlflow` code logs runs and
  models there (Lecture 227).
- **Promotion across workspaces.** Separate dev and prod workspaces, with a registry in between, is the standard
  enterprise pattern. It gives clean separation of permissions and network isolation for production.

```python
from azure.ai.ml import MLClient, Input, Output, command, dsl
from azure.identity import DefaultAzureCredential

ml = MLClient(DefaultAzureCredential(), subscription_id=SUB, resource_group_name="rg-ml-dev",
              workspace_name="ws-fraud-dev")

train = command(
    name="train_fraud", display_name="Train fraud model",
    inputs={"data": Input(type="uri_folder"), "lr": 0.05},
    outputs={"model": Output(type="mlflow_model")},
    code="./src", command="python train.py --data ${{inputs.data}} --lr ${{inputs.lr}} --out ${{outputs.model}}",
    environment="azureml://registries/azureml/environments/acpt-pytorch-2.2-cuda12.1/labels/latest",
)

@dsl.pipeline(compute="gpu-a100-cluster", description="fraud training")
def fraud_pipeline(raw: Input):
    prepped = prep(raw=raw)
    trained = train(data=prepped.outputs.features)
    return {"model": trained.outputs.model}

job = fraud_pipeline(raw=Input(type="uri_folder", path="azureml:fraud-raw@latest"))
ml.jobs.create_or_update(job, experiment_name="fraud")
```

In the code, `DefaultAzureCredential` picks up your login or the job's managed identity. `command` defines a
component: `${{inputs.data}}` placeholders are replaced with mounted paths at run time, and the `mlflow_model` output
type marks the folder as an MLflow model. The `environment` reference points at a curated PyTorch environment in
Microsoft's public `azureml` registry. `prep` is another component, defined the same way. `azureml:fraud-raw@latest`
refers to the latest version of a registered data asset.

**Example: one approved evaluation component.** A healthcare company found each team computed "sensitivity" slightly
differently, which confused its clinical review board. The platform team published one versioned evaluation
component to the Azure ML registry, with the review board's exact metric definitions and a fairness report. All
pipelines were required to use it, and model reviews became comparable across teams.

**Senior / FAANG best practice.** Separate dev and prod workspaces, and promote models and components through a
registry. Version components and environments, and share approved ones centrally. Use managed identities and
private endpoints rather than keys. Scale compute clusters to zero when idle, and set per-workspace quotas. Log with
MLflow so code stays portable across Azure ML, Databricks, and self-hosted MLflow.

**Choosing between the four.**

| Need | Kubeflow (self-managed) | SageMaker Pipelines | Vertex AI Pipelines | Azure ML pipelines |
|---|---|---|---|---|
| Portability across clouds and on-premises | Highest | Low | Medium (KFP format) | Low |
| Operational work | High | Low | Low | Low |
| Distributed GPU training | Trainer operator, Kueue | SageMaker training jobs | CustomJob | Compute clusters, AKS |
| Pipeline authoring | KFP v2 SDK | SageMaker Python SDK | KFP v2 SDK | SDK v2 or YAML |
| Lineage | ML Metadata | SageMaker lineage, registry | Vertex ML Metadata | Jobs, registry, MLflow |
| Best fit | Multi-cloud, on-prem, platform teams | AWS-first teams | GCP-first teams, KFP users | Microsoft-first enterprises |

---

## Lecture 231 — Lab: build a pipeline in Kubeflow

**Goal:** build a Kubeflow Pipelines v2 pipeline that prepares data, trains a model, evaluates it, and registers it
only if it beats a threshold. Run it on a local Kubernetes cluster, then rerun it to see caching and inspect lineage.

**What you're building:** four components (prepare, train, evaluate, register), a pipeline with a condition, a local
KFP installation on kind, and a client script that uploads and runs the pipeline twice.

```mermaid
flowchart LR
  P["prepare<br/>breast cancer data, split"] --> T["train<br/>logistic regression"]
  P --> E["evaluate<br/>AUC on test split"]
  T --> E
  E --> C{"dsl.If AUC<br/>at least min_auc"}
  C -->|"true"| R["register<br/>write model card"]
  KIND["kind cluster + KFP standalone<br/>UI on localhost:8080"] -.-> P
```

**How to read the diagram:** `prepare` loads scikit-learn's built-in breast cancer dataset and splits it into train
and test sets. `train` fits a **logistic regression** classifier on the training split. `evaluate` computes the
**AUC** (area under the ROC curve, where 1.0 is perfect and 0.5 is random guessing) on the test split. A `dsl.If`
condition runs `register` only when the AUC meets `min_auc`. Everything runs on a **kind** cluster ("Kubernetes in
Docker", a local cluster inside Docker containers) with standalone Kubeflow Pipelines, whose UI is reachable on
`localhost:8080`.

**Prerequisites:** Docker, `kind`, `kubectl`, Python 3.10+, about 8 GB of free RAM, and `pip install "kfp>=2.9,<3"`.

### Step 1 — Install standalone Kubeflow Pipelines on kind

```bash
kind create cluster --name kfp
export PIPELINE_VERSION=2.3.0
kubectl apply -k "github.com/kubeflow/pipelines/manifests/kustomize/cluster-scoped-resources?ref=$PIPELINE_VERSION"
kubectl wait --for condition=established --timeout=60s crd/applications.app.k8s.io
kubectl apply -k "github.com/kubeflow/pipelines/manifests/kustomize/env/platform-agnostic?ref=$PIPELINE_VERSION"
kubectl -n kubeflow wait --for=condition=Available deploy --all --timeout=900s
kubectl -n kubeflow port-forward svc/ml-pipeline-ui 8080:80 &
```

`kubectl apply -k` applies a **Kustomize** folder directly from GitHub. The first one installs cluster-wide
resources, including CRDs (custom resource definitions). `kubectl wait --for condition=established` waits until the
CRD is ready. The `platform-agnostic` environment installs KFP with MinIO and MySQL inside the cluster. The last
command forwards the UI to your laptop.

### Step 2 — Components and pipeline

```python
# pipeline.py
from kfp import dsl, compiler

IMG = "python:3.11-slim"
PKGS = ["scikit-learn==1.5.2", "pandas==2.2.3"]

@dsl.component(base_image=IMG, packages_to_install=PKGS)
def prepare(train_out: dsl.Output[dsl.Dataset], test_out: dsl.Output[dsl.Dataset], seed: int = 7):
    import pandas as pd
    from sklearn.datasets import load_breast_cancer
    from sklearn.model_selection import train_test_split
    X, y = load_breast_cancer(return_X_y=True, as_frame=True)
    df = X.assign(y=y)
    tr, te = train_test_split(df, test_size=0.25, random_state=seed, stratify=df["y"])
    tr.to_csv(train_out.path, index=False); te.to_csv(test_out.path, index=False)
    train_out.metadata["rows"] = len(tr); test_out.metadata["rows"] = len(te)

@dsl.component(base_image=IMG, packages_to_install=PKGS)
def train(data: dsl.Input[dsl.Dataset], model: dsl.Output[dsl.Model], c: float = 1.0):
    import pickle, pandas as pd
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    df = pd.read_csv(data.path)
    clf = make_pipeline(StandardScaler(), LogisticRegression(C=c, max_iter=1000))
    clf.fit(df.drop(columns="y"), df["y"])
    with open(model.path, "wb") as f:
        pickle.dump(clf, f)
    model.metadata.update({"framework": "sklearn", "C": c})

@dsl.component(base_image=IMG, packages_to_install=PKGS)
def evaluate(model: dsl.Input[dsl.Model], data: dsl.Input[dsl.Dataset],
             metrics: dsl.Output[dsl.Metrics]) -> float:
    import pickle, pandas as pd
    from sklearn.metrics import roc_auc_score
    df = pd.read_csv(data.path)
    with open(model.path, "rb") as f:
        clf = pickle.load(f)
    auc = float(roc_auc_score(df["y"], clf.predict_proba(df.drop(columns="y"))[:, 1]))
    metrics.log_metric("auc", auc)
    return auc

@dsl.component(base_image=IMG)
def register(model: dsl.Input[dsl.Model], auc: float, card: dsl.Output[dsl.Artifact]):
    import json
    with open(card.path, "w") as f:
        json.dump({"model_uri": model.uri, "auc": auc, "status": "candidate"}, f, indent=2)
    print("registered", model.uri, "auc", auc)

@dsl.pipeline(name="cancer-train", description="prepare, train, evaluate, conditionally register")
def cancer_pipeline(c: float = 1.0, min_auc: float = 0.97):
    p = prepare()
    t = train(data=p.outputs["train_out"], c=c)
    e = evaluate(model=t.outputs["model"], data=p.outputs["test_out"])
    with dsl.If(e.outputs["Output"] >= min_auc, name="auc-gate"):
        register(model=t.outputs["model"], auc=e.outputs["Output"])

if __name__ == "__main__":
    compiler.Compiler().compile(cancer_pipeline, "cancer_pipeline.yaml")
    print("compiled cancer_pipeline.yaml")
```

In the code, `dsl.Output[dsl.Metrics]` is a special artifact whose `log_metric` values appear in the KFP UI and can
be compared across runs. A component's plain return value (here the AUC float) becomes an output named `"Output"`,
which is why the condition uses `e.outputs["Output"]`. `model.uri` is the artifact's object-storage location. The
`register` step here writes a **model card** (a short JSON record of what was registered and why). In production it
would call the MLflow or Kubeflow Model Registry API instead.

### Step 3 — Compile, upload, and run twice

```python
# run.py
import kfp
client = kfp.Client(host="http://localhost:8080")
exp = client.create_experiment("lab-231")
for c in (1.0, 1.0, 0.01):
    r = client.create_run_from_pipeline_package("cancer_pipeline.yaml", arguments={"c": c},
                                                experiment_id=exp.experiment_id, run_name=f"c={c}")
    print("run", r.run_id, "c =", c, "->", client.wait_for_run_completion(r.run_id, timeout=1800).state)
```

```bash
python3 pipeline.py && python3 run.py
```

`create_run_from_pipeline_package` uploads the compiled YAML and starts a run with arguments. `wait_for_run_completion`
blocks until the run finishes and returns its final state. The second run repeats the first exactly, to show caching.
The third uses strong regularization (`c=0.01`), which may lower the AUC below the gate.

### Step 4 — Inspect

Open `http://localhost:8080`:
- In run 2, the `prepare`, `train`, and `evaluate` steps show a cache icon and finish in seconds.
- In each run, click the `model` artifact to see its URI and metadata, and the lineage view linking it to the
  dataset and the run.
- Compare runs in the experiment view: the AUC metric is shown side by side.
- Change `seed` in `prepare` and rerun: caching no longer applies from `prepare` onward, because its inputs changed.

**Expected results:**
- Run 1 completes with all four steps, and AUC is about 0.99, so `register` runs and writes the model card.
- Run 2 completes in well under a minute, with `prepare`, `train`, and `evaluate` reused from cache.
- Run 3 (`c=0.01`) either registers with a slightly lower AUC or skips `register`, depending on the gate. Raising
  `min_auc` to 0.999 makes the gate skip `register` in every run, and the condition branch shows as not executed.
- Every artifact has a URI in MinIO, and the lineage graph links data → model → metrics → model card.

---

## FAANG deep-dive notes

**How big tech does it.** Large companies run an internal ML platform as a product: Uber's Michelangelo, Meta's
FBLearner Flow, LinkedIn's Pro-ML, Netflix's Metaflow, and Spotify's Hendrix. Each gives teams a paved path from
notebook to production: standard pipelines, a shared feature store, one tracking and registry service, standard
serving, and built-in governance. The platform team measures adoption and time-to-production, and makes the paved
path faster than any custom alternative. Open-source building blocks (Kubeflow, MLflow, Metaflow, Feast, KServe)
or managed clouds provide the parts, and the company's value is in how they're integrated and governed.

**Staff review questions.**
- Who are the platform's users, and what are its adoption and time-to-production metrics?
- Which interfaces are standardized (pipeline format, tracking API, registry, serving contract), and which are left
  open?
- How does a model get from approved run to production, and who can move a production alias?
- Can you answer "which data and code produced the model serving this request?" in minutes?
- What's the operational cost of self-managing (people, upgrades) compared with a managed service?
- How are quotas and costs attributed per team?

**Interview question.** "Design an ML platform for 50 teams and 300 models."

**Typical system-design prompt:** *Design the ML platform for a company with 50 data science teams, 300 production
models (half batch, half real-time), on AWS and an on-premises GPU cluster, with model risk regulation.*

**1. Clarify first:** What do teams use today? Which frameworks? How many training runs per day, and how big? What
does the regulator require (approvals, explainability, retention)? Which data can't leave on-premises? What's the
platform team's size?

**2. Back-of-envelope sizing:**
- Runs: 300 models retrained weekly, plus ~20 experiments per model per week = ~6,300 runs per week, ~900 per day.
  Peak logging at ~10 metrics per second per active run, with 100 concurrent runs = 1,000 writes per second, which
  needs batched or asynchronous logging and a PostgreSQL-backed MLflow with replicas.
- Artifacts: 300 models × 10 versions kept × ~500 MB = 1.5 TB in the registry, plus run artifacts, so plan ~20 TB with
  lifecycle rules.
- Platform team: rule of thumb 1 engineer per 5–10 teams served, so ~6–10 engineers.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Orchestrator | Self-managed Kubeflow | Managed (SageMaker) | Kubeflow when on-prem or multi-cloud is required. Managed otherwise |
| Tracking + registry | Cloud-native | Self-hosted MLflow | MLflow for portability and one registry across environments |
| Promotion | Stages | Aliases + tags + approvals | Aliases. Production alias changes need an approval record |
| Tenancy | Shared namespace | Namespace per team + quotas | Per team from day one |
| Golden path | Optional docs | Templates + pre-approved security | Make the paved path the fastest path |

**4. Follow-up questions with crisp answers:**
- *How do you get teams to adopt the platform?* Make it faster than their own setup: templates, pre-approved
  security, and migration help. Measure adoption, and fix the top blockers.
- *How do you handle on-prem data that can't move?* Run the same KFP pipelines on an on-prem Kubeflow, with a shared
  registry metadata (not data) across sites.
- *How is rollback done?* Move the production alias back to the previous version. Serving reloads by alias.
- *What do you standardize?* Interfaces and governance, not frameworks.

**Debug this (common onsite question):** "Model training pipelines suddenly take 3× longer, across all teams."
1. Check the pipeline step durations: all slowdown is in steps that log to MLflow.
2. Check the MLflow server: database CPU at 100%, and the metrics table has 2 billion rows with no index on the
   commonly queried columns.
3. A new SDK release removed batching, so every step logs individually.
4. Fix: restore batched, asynchronous logging in the SDK, add database indexes, archive old experiments, and add an
   SLO alert on tracking latency.

The lesson: shared platform services are production systems. A client-side change can overload them, so version
the SDK carefully and monitor the service.

**5. What separates senior from staff answers:** a senior engineer builds a good pipeline on one platform. A staff
engineer designs the platform as a product with standard interfaces, governance, and multi-tenancy, chooses build vs
buy per component with operational cost in mind, makes the paved path the fastest path, and measures success by
adoption and time-to-production.

**Red flags:**
- Each team running its own MLflow or orchestration.
- A SQLite-backed shared MLflow.
- Promotion by copying files or editing a spreadsheet.
- Pipelines edited in a console instead of code in Git.
- No per-team namespaces, quotas, or cost attribution.
- No lineage from data to deployed model.

---

## Quiz

<details><summary>1. What's the difference between MLOps maturity levels 0, 1, and 2?</summary>
Level 0 is manual, notebook-driven training and hand-off. Level 1 automates the training pipeline, including
continuous training on new data. Level 2 adds CI/CD for the pipelines themselves, so pipeline code is tested and
deployed automatically.
</details>

<details><summary>2. What does KFP caching do, and when should you disable it?</summary>
It reuses a step's previous outputs when the component, image, and inputs are unchanged. Disable it for steps that read
changing sources, such as "fetch the latest data", whose inputs look the same but whose results differ.
</details>

<details><summary>3. Why should a shared MLflow server use PostgreSQL and object storage, not SQLite and a local folder?</summary>
SQLite locks the whole database on each write, which fails under concurrent jobs, and local folders don't scale or
survive server loss. A database handles concurrent writes, and object storage holds large artifacts durably, so the
servers can be stateless replicas.
</details>

<details><summary>4. Why did MLflow move from stages to aliases?</summary>
Fixed stages (Staging, Production) didn't fit real workflows. Aliases such as @champion and @challenger are flexible
named pointers to versions. Promotion and rollback are just moving an alias, and serving loads by alias.
</details>

<details><summary>5. What does a SageMaker ConditionStep use to decide, and how does it get the value?</summary>
It evaluates conditions on step outputs, typically metrics read with JsonGet from a property file (such as
evaluation.json) written by an evaluation processing step.
</details>

<details><summary>6. Why can the same KFP pipeline run on Kubeflow and Vertex AI?</summary>
Both execute the KFP v2 IR YAML that the SDK compiles. Only platform-specific components and resource names differ.
</details>

<details><summary>7. What is an Azure ML registry for?</summary>
Sharing components, environments, and models across workspaces and regions, so dev, test, and prod use identical
versioned assets, and models are promoted from one workspace to another through it.
</details>

<details><summary>8. What should a platform team standardize, and what should it leave open?</summary>
Standardize interfaces and governance: pipeline format, tracking API, registry and promotion, serving contract,
identity, and quotas. Leave modeling choices, such as framework and algorithm, to the teams.
</details>

## Failure modes
- Every team building its own pipelines, tracking, and deployment, with no shared lineage.
- A shared MLflow on SQLite, or without authentication in front of the artifact store.
- Per-step metric logging from hundreds of jobs overwhelming the tracking database.
- Promotion by copying files, so nobody can say which model is in production.
- Caching enabled on steps that read changing data, so pipelines reuse stale results.
- Pipelines edited in a console instead of code reviewed in Git.
- Self-managing all of Kubeflow without the people to upgrade and secure it.
- No per-team namespaces, quotas, or cost attribution, making noisy neighbors and surprise bills common.
- Regulated models deployed without a recorded approval linked to the evaluation.

## Checklist
- [ ] You can describe the layers of an enterprise ML platform and what each provides
- [ ] You can name Kubeflow's components and explain profiles and multi-tenancy
- [ ] You can run MLflow with a database, object storage, replicas, and SSO, and promote with aliases
- [ ] You can build a SageMaker pipeline with processing, training, condition, and register steps
- [ ] You can compile a KFP v2 pipeline and run it on Vertex AI with a service account
- [ ] You can define Azure ML components and pipelines, and promote through a registry
- [ ] You can choose between Kubeflow, SageMaker, Vertex AI, and Azure ML for a given organization
- [ ] You built and ran a Kubeflow pipeline with caching, a condition, metrics, and lineage
