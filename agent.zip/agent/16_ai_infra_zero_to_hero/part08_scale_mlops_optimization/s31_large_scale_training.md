# Section 31 — Large-Scale Training Foundations

> Lectures 211–217 • Assessment: quiz
> **After this section you can:** define what makes training "large-scale" in numbers, choose between data,
> tensor, pipeline, and sharded parallelism with memory and communication math, compare pipeline schedules
> (GPipe, 1F1B, interleaved, zero-bubble), compute all-reduce cost and overlap it with compute, account for
> MFU and find the bottleneck (compute, memory, network, storage, input, stragglers), design fault tolerance
> for multi-node jobs, and train a transformer across multiple nodes with torchrun.
>
> Go deeper: [13 / Lab 37 — Multi-node gradient descent](../../13_sovereign_ai_infra_course/03_distributed_training/lab37_multinode_gradient_descent.md),
> [Lab 36 — NCCL optimization](../../13_sovereign_ai_infra_course/03_distributed_training/lab36_nccl_optimization.md),
> [Lab 35 — InfiniBand and RoCEv2](../../13_sovereign_ai_infra_course/03_distributed_training/lab35_infiniband_rocev2.md),
> [Lab 39 — Checkpointing to S3](../../13_sovereign_ai_infra_course/03_distributed_training/lab39_checkpointing_s3.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 211 | What is large-scale training? | When one node isn't enough for memory or time. Success is measured in MFU and goodput, not GPU count |
| 212 | Data parallelism vs model parallelism revisited | Choose by what doesn't fit (states, layers, activations) and by which links are fast |
| 213 | Pipeline parallelism in transformers | Bubble ≈ (p−1)/m. 1F1B saves memory, interleaving and zero-bubble schedules cut idle time |
| 214 | Distributed optimizers and gradient sync | Ring all-reduce moves ~2× the gradient bytes per GPU. Bucket, overlap, and shard the optimizer |
| 215 | Infrastructure bottlenecks in training LLMs | MFU = 6·N·tokens/s ÷ peak. Find which of compute, memory, network, input, or stragglers caps it |
| 216 | Fault tolerance in multi-node training | Failures are certain. Checkpoint interval, fast restart, spares, and health checks decide goodput |
| 217 | Lab: train a transformer across multiple nodes | torchrun across 2 nodes (or 2 simulated), DDP then FSDP, with throughput, MFU, and a kill-and-resume test |

```mermaid
flowchart LR
  Q1{"Does the model + optimizer<br/>fit on one GPU?"} -->|"yes"| DDP["Data parallel (DDP)<br/>scale batch across GPUs"]
  Q1 -->|"no"| Q2{"Do single layers<br/>and activations fit?"}
  Q2 -->|"yes"| SH["Sharded DP<br/>ZeRO-3 / FSDP"]
  Q2 -->|"no"| TP["+ Tensor parallel<br/>inside NVLink domain"]
  TP --> Q3{"Still too big or<br/>too many nodes for TP?"}
  Q3 -->|"yes"| PP["+ Pipeline parallel<br/>across nodes"]
  Q3 -->|"no"| RUN["Run + measure MFU"]
  DDP --> RUN
  SH --> RUN
  PP --> CP["+ Context or expert parallel<br/>long sequences, MoE"]
  CP --> RUN
```

**How to read it:** start with the simplest strategy that fits. If the full training state fits on a GPU,
use data parallelism. If not, shard it (ZeRO-3 or FSDP). Add tensor parallelism only when individual layers
or activations are too big, keeping it on NVLink, and add pipeline parallelism across nodes when needed.
Long context and mixture-of-experts add their own dimensions. Every choice is validated by measured MFU.

**Terms in this diagram.**
- **Model + optimizer**: the weights, gradients, and optimizer state together, about 16 bytes per parameter with
  mixed-precision Adam (Section 26).
- **Data parallel (DDP)**: every GPU holds the whole model and trains on different data. Gradients are averaged each
  step (Section 8).
- **Sharded DP, ZeRO-3 / FSDP**: data parallelism where each GPU stores only a 1/N slice of the training state
  (Lecture 212).
- **Activations**: the intermediate outputs of each layer, saved for the backward pass. They grow with batch size and
  sequence length.
- **Tensor parallel, inside NVLink domain**: splitting each weight matrix across GPUs. It communicates inside every
  layer, so it stays within the GPUs connected by fast NVLink, usually one 8-GPU server (Lecture 212).
- **Pipeline parallel**: splitting the layers into stages on different nodes (Lecture 213).
- **Context or expert parallel, MoE**: **context parallelism** splits a very long sequence across GPUs. **Expert
  parallelism** places the different **experts** of a **mixture-of-experts** (MoE) model, which are sub-networks
  that each token uses only a few of, on different GPUs.
- **MFU**: model FLOPs utilization, the share of the GPUs' peak math speed you actually achieve (Section 26).

---

## Lecture 211 — What is large-scale training?

**Why it matters.** "Large-scale" changes the engineering problem. Beyond one node, the network,
scheduler, storage, and failure rate matter as much as the model code, and costs grow fast enough that
small efficiency losses are worth months of engineering.

**In plain words.** Cooking for four is about the recipe. Catering for four thousand is about logistics:
kitchens, delivery routes, staff schedules, and what happens when an oven breaks halfway through.

**Architecture: the large-scale training stack.**

```mermaid
flowchart LR
  CODE["Model + training code<br/>PyTorch, Megatron, JAX"] --> PAR["Parallelism layer<br/>DDP, FSDP, TP, PP"]
  PAR --> COMM["Collectives<br/>NCCL over NVLink + IB/RoCE"]
  COMM --> HW["GPUs, NVSwitch,<br/>rail-optimized fabric"]
  DATA[("Token or sample shards<br/>object storage + cache")] --> LOADER["Deterministic loaders"]
  LOADER --> CODE
  CODE --> CKPT[("Checkpoints<br/>parallel FS or object store")]
  SCHED["Scheduler<br/>Slurm or K8s + Kueue"] --> HW
  OBS["Observability<br/>MFU, step time, per-rank skew,<br/>DCGM health"] -.-> SCHED
  OBS -.-> PAR
```

**How to read it:** training code sits on a parallelism layer that turns it into collective communication
over NVLink and the network fabric. Data flows in through deterministic loaders, and checkpoints flow out to
shared storage. A scheduler places the job on healthy hardware, and observability ties MFU, step time, and
hardware health together.

In the diagram, training code is written in **PyTorch**, **Megatron** (NVIDIA's library for tensor and pipeline
parallel transformer training, Section 26), or **JAX** (Google's numerical library, common on TPUs). The parallelism
layer applies DDP, FSDP, **TP** (tensor parallelism), and **PP** (pipeline parallelism).
**Collectives** are group communication operations such as all-reduce, all-gather, and reduce-scatter. **NCCL**
performs them over **NVLink** inside a server and **IB/RoCE** (InfiniBand or RDMA over Converged Ethernet) between
servers (Section 13). **NVSwitch** connects all GPUs in a server. A **rail-optimized fabric** connects same-numbered
GPUs across servers through one switch. A **parallel FS** is a shared high-speed file system such as Lustre.
**Per-rank skew** is the difference in step time between the fastest and slowest process, which reveals a slow GPU or
link. **DCGM** reports GPU health (Section 16). The scheduler is **Slurm**, or Kubernetes with **Kueue**, its job-queueing
add-on (Section 11).

**Core ideas.**
- **Scale markers.** You need more than one node because of memory (the training state exceeds a node) or time (the
  deadline needs more GPUs). Typical runs span tens to thousands of GPUs, and frontier runs tens of thousands.
- **The two efficiency numbers.**
  - **MFU** (model FLOPs utilization) = 6·N·tokens/s ÷ (GPUs × peak FLOPs).
  - **Goodput** = productive time ÷ wall time.
  - Effective compute = GPUs × peak × MFU × goodput.
- **Scaling efficiency.** Throughput at N GPUs ÷ (N × single-GPU throughput). It falls as communication grows,
  unless you increase work per GPU or overlap communication.
- **Global batch limits.** Data parallelism increases the global batch. Beyond the critical batch size, more
  samples per step stop reducing the number of steps needed, so you need model parallelism to use more GPUs.

**Example: the 1,000-GPU arithmetic.** A team planned 1,024 H100s for a run estimated at 21 days at 45% MFU
and 95% goodput. In the first week, they measured 38% MFU and 86% goodput (frequent restarts from slow
checkpoints). Effective compute was 0.38 × 0.86 ÷ (0.45 × 0.95) = 76% of plan, a 6-day slip. Asynchronous
checkpoints and faster restart raised goodput to 96%, and communication overlap raised MFU to 44%.

**Senior / FAANG best practice.** Plan and report runs in effective compute (MFU × goodput), not GPU count.
Validate scaling efficiency with short runs at increasing scale before committing, keep the global batch
below the critical batch size, and staff the infrastructure (scheduler, storage, fabric, health checks)
as part of the training program.

---

## Lecture 212 — Data parallelism vs model parallelism revisited

**Why it matters.** Section 8 introduced data parallelism, and Section 26 introduced ZeRO and Megatron. At
scale, you combine them, and the right mix depends on memory math and link bandwidth. A wrong mix can
cost 2× throughput on the same hardware.

**In plain words.** You can split homework by giving each student different pages of the same worksheet
(data parallel), or by splitting each hard problem among several students (tensor parallel), or by having
students pass work down an assembly line (pipeline parallel). The best split depends on how big the problems
are and how fast students can talk to each other.

**Architecture: what each strategy splits and communicates.**

```mermaid
flowchart LR
  subgraph DPX["Data parallel"]
    D1["Full model per GPU<br/>different data"] --> D2["All-reduce gradients<br/>once per step"]
  end
  subgraph FSX["Sharded DP (FSDP/ZeRO-3)"]
    F1["1/N of states per GPU"] --> F2["All-gather params per layer,<br/>reduce-scatter grads"]
  end
  subgraph TPX["Tensor parallel"]
    T1["1/t of each matrix"] --> T2["All-reduce activations<br/>2x per layer, forward + backward"]
  end
  subgraph PPX["Pipeline parallel"]
    P1["1/p of the layers"] --> P2["Point-to-point activations<br/>between stages"]
  end
```

**How to read it:** data parallelism communicates once per step (gradients). Sharded data parallelism
communicates per layer, but each GPU stores only a fraction. Tensor parallelism communicates inside every
layer and needs the fastest links. Pipeline parallelism sends only activations between stages, so it
tolerates slower links but adds idle bubbles.

In the diagram, **all-reduce** sums values across all GPUs and gives every GPU the result. **All-gather** gives every
GPU the concatenation of all GPUs' pieces, used to rebuild a full layer's weights before using it. **Reduce-scatter**
sums values and gives each GPU only its own slice of the result, so each keeps only the gradients for its shard (Section
8). **1/t** and **1/p** are each GPU's share with t-way tensor and p-way pipeline parallelism. **Point-to-point**
means one GPU sends directly to one other. A **bubble** is time when a pipeline stage sits idle, waiting for work to
reach it (Lecture 213).

**Core ideas.**

| Strategy | Memory per GPU | Communication | Link needed | Main cost |
|---|---|---|---|---|
| DDP | Full (16 B/param) | Gradients per step (~2× size per GPU, ring) | Network OK | Memory |
| FSDP / ZeRO-3 | 16/N B/param + gathered layer | ~1.5× DDP volume, per layer | Fast network | Extra communication |
| Tensor (t) | ~1/t of weights and activations | Activations, 2 all-reduces per layer per pass | NVLink | Small matmuls at high t |
| Pipeline (p) | ~1/p of layers | Activations at stage boundaries | Network OK | Bubble, imbalance |
| Context / sequence | Splits activations by sequence | Attention exchanges (ring attention) | Fast | Complexity |
| Expert (MoE) | 1/e of experts | All-to-all token routing | Fast network | Load balance |

- **Rules of thumb.** TP ≤ GPUs per NVLink domain. PP across nodes. DP (sharded) outermost. Choose the smallest TP
  and PP that fit, because each adds overhead.
- **HSDP (hybrid sharding).** Shard within a node and replicate across nodes. This cuts cross-node traffic compared
  with full sharding across all ranks.

**Example: choosing for a 30B model on 64 H100s.** Full training state is 480 GB. Option A: FSDP over 64 GPUs
(7.5 GB of state per GPU), with all-gathers crossing nodes on every layer, gave MFU 33%. Option B: TP 4 inside nodes
plus FSDP over 16 groups gave 41%. Option C: HSDP (shard over the 8 GPUs of a node, replicate across 8 nodes)
plus TP 2 gave 44%, because most traffic stayed on NVLink. They chose C.

**Senior / FAANG best practice.** Write down memory per GPU and communication volume per step for each
candidate layout, map every collective to the link it uses, and benchmark the top two or three for a few
hundred steps. Choose by measured MFU at the target scale.

---

## Lecture 213 — Pipeline parallelism in transformers

**Why it matters.** Pipelines let models span many nodes with only point-to-point traffic, but naive
schedules leave GPUs idle for a large part of each step. The schedule and the micro-batch count are worth
10–30 MFU points.

**In plain words.** An assembly line with four stations is idle at the start (later stations wait
for the first part) and at the end (early stations have nothing left). Smaller, more frequent parts and
smarter ordering keep every station busy more of the time.

**Architecture: GPipe vs 1F1B on 4 stages.**

```mermaid
flowchart LR
  subgraph GP["GPipe"]
    G1["All m forwards first"] --> G2["Then all m backwards"]
    G2 --> G3["Activations for m micro-batches<br/>held at once"]
  end
  subgraph OF["1F1B"]
    O1["Warm-up: p forwards"] --> O2["Steady state:<br/>1 forward, 1 backward"]
    O2 --> O3["At most p micro-batches<br/>of activations held"]
  end
  subgraph IL["Interleaved 1F1B"]
    I1["Each GPU holds v<br/>non-adjacent chunks"] --> I2["Bubble shrinks by v<br/>more point-to-point traffic"]
  end
```

**How to read it:** GPipe runs all forwards, then all backwards, so it stores activations for every
micro-batch. 1F1B alternates one forward and one backward in steady state, which holds activations for at most
p micro-batches. The bubble is the same, but memory is much lower. Interleaving gives each GPU several smaller
chunks of layers, which shrinks the bubble at the cost of more communication.

In the diagram, a **micro-batch** is one slice of the training batch, and **m** is how many there are per step. The
pipeline processes them one after another, so stages can work in parallel on different ones. **GPipe** is Google's
original pipeline schedule. **1F1B** means "one forward, one backward". **p** is the number of pipeline stages. In the
**warm-up** phase, the first p micro-batches enter the pipeline before any backward pass can start. In the **steady
state**, each stage alternates one forward and one backward. **Interleaved** 1F1B gives each GPU **v** separate
**non-adjacent chunks** of layers, for example layers 1–10 and 41–50, so the pipeline fills and drains faster.
"Activations held" is how many micro-batches' saved activations a GPU must keep in memory at once.

**Core ideas.**
- **Bubble fraction** ≈ (p − 1) / (m + p − 1) for GPipe and 1F1B (often approximated as (p − 1)/m). With p = 8 and
  m = 8, that's 47%. With m = 64, it's 10%.
- **Interleaved** (v virtual stages per GPU) divides the bubble by ~v. **Zero-bubble** schedules split backward
  into input-gradient and weight-gradient parts to fill the bubbles.
- **Balance.** Stages must have equal compute. The embedding and output layers (large vocab) often unbalance the
  first and last stages, so give them fewer transformer layers.
- **Micro-batch trade-off.** More micro-batches shrink the bubble but make each matmul smaller. Global batch =
  micro-batch size × m × DP.
- **Activation memory** with 1F1B scales with p, not m, so combine it with activation checkpointing.

```python
# bubble fraction for common settings
for p, m in [(4, 8), (4, 32), (8, 8), (8, 64), (16, 128)]:
    print(f"p={p:2d} m={m:3d} bubble={(p - 1) / (m + p - 1):.0%}")
# p= 4 m=  8 bubble=27%   p= 4 m= 32 bubble=9%   p= 8 m=  8 bubble=47%   p= 8 m= 64 bubble=10%   p=16 m=128 bubble=10%
```

**Example: the unbalanced last stage.** An 8-stage pipeline had uniform transformer layers per stage, but
the last stage also computed the 128 k-vocab output projection and loss, taking 1.4× longer than the others.
Every other stage waited for it each micro-batch. Moving two transformer layers off the last stage balanced
step times within 3% and raised throughput by 18%.

**Senior / FAANG best practice.** Use 1F1B or interleaved schedules with m ≥ 4p, balance stages by measured
time (not layer count), account for the embedding and output layers, and profile per-stage timelines. Prefer
the smallest pipeline depth that fits, since every stage adds a bubble and point-to-point latency.

---

## Lecture 214 — Distributed optimizers and gradient sync

**Why it matters.** Every data-parallel step synchronizes gradients, often gigabytes per step. Done naively, the
GPUs wait on the network. Done well, communication hides behind backward compute, and the optimizer state is
sharded across ranks.

**In plain words.** A team must agree on a shared average before each step. If they wait until everyone
finishes and then talk, everyone stands around. If they start comparing notes on finished pages while still
working on the rest, the conversation happens for free.

**Architecture: bucketed all-reduce overlapped with backward.**

```mermaid
flowchart LR
  BWD["Backward pass<br/>last layer first"] --> B1["Bucket 1 grads ready<br/>~25 MB"]
  B1 --> AR1["All-reduce bucket 1<br/>on comm stream"]
  BWD --> B2["Bucket 2 grads ready"]
  B2 --> AR2["All-reduce bucket 2"]
  BWD --> BN["Bucket N ready"]
  BN --> ARN["All-reduce bucket N"]
  AR1 --> OPT["Optimizer step<br/>sharded: each rank updates 1/N"]
  AR2 --> OPT
  ARN --> OPT
  OPT --> AG["All-gather updated params<br/>if optimizer is sharded"]
```

**How to read it:** as the backward pass produces gradients (last layers first), they're grouped into
buckets, and each bucket's all-reduce starts immediately on a separate communication stream while compute
continues. With a sharded optimizer, each rank updates only its slice and the updated parameters are
all-gathered (ZeRO-1 / distributed optimizer).

In the diagram, a **bucket** is a group of gradient tensors, about 25 MB by default in PyTorch DDP, sent together
because one large message is more efficient than many small ones. A **comm stream** is a separate CUDA stream, a queue
of GPU work that runs at the same time as the compute stream, which is how communication overlaps with computation.
The **optimizer step** applies the averaged gradients to the weights. **Sharded: each rank updates 1/N** means each of
the N processes (**ranks**) holds and updates only its share of the optimizer state.

**Core ideas.**
- **Ring all-reduce** sends and receives ~2 × (N − 1)/N × S bytes per GPU for S bytes of gradients. Time ≈
  2S/B for bandwidth B, almost independent of N. Tree algorithms reduce latency for small messages, and
  NVLink SHARP (NVLS) offloads reductions to the switches.
- **Example cost.** 7B params × 2 bytes (BF16 grads) = 14 GB per step. At ~50 GB/s per GPU (400 Gb/s), that's
  ≈ 0.56 s, which must hide behind backward compute.
- **Bucketing and overlap.** DDP's `bucket_cap_mb` (default 25). FSDP prefetches the next all-gather. Larger
  buckets are more efficient, smaller ones start earlier.
- **Distributed optimizer** (ZeRO-1, Megatron's distributed optimizer): reduce-scatter gradients, update local
  shard, all-gather parameters. This gives the same traffic as all-reduce and 1/N of the optimizer memory.
- **Precision and compression.** Use BF16 gradient reduction (FP32 accumulation is safer for some models) and
  FP8 communication in newer stacks. Gradient compression (PowerSGD, top-k) is rarely used at large scale,
  because accuracy and complexity costs outweigh the savings on fast fabrics.
- **Large-batch optimizers.** LAMB and LARS for very large batches, plus learning-rate warmup.

```python
# DDP with explicit overlap-friendly settings
model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[local_rank], bucket_cap_mb=50,
                                                  gradient_as_bucket_view=True, static_graph=True)
# FSDP2: from torch.distributed.fsdp import fully_shard; fully_shard(block, reshard_after_forward=True) per layer
```

**Example: the unhidden all-reduce.** A 13B data-parallel run on 128 GPUs spent 31% of each step in an
exposed all-reduce. The trace showed one 26 GB all-reduce after backward finished, because gradient
accumulation used `no_sync()` wrongly on every micro-batch, including the last one, so DDP's overlap was
disabled. Correctly syncing on the last micro-batch restored overlap, and exposed communication fell to 6%.

**Senior / FAANG best practice.** Compute gradient bytes and expected all-reduce time per step, verify in a
profiler trace that communication overlaps backward, tune bucket sizes, shard the optimizer, and validate
fabric bandwidth with `nccl-tests` before blaming the model.

---

## Lecture 215 — Infrastructure bottlenecks in training LLMs

**Why it matters.** When MFU is low, the cause can be compute kernels, memory, the network, input
data, checkpoint stalls, or one slow node. Each needs a different fix, and guessing wastes weeks on the
wrong layer.

**In plain words.** A slow factory can be slow because the machines are old, the conveyor belts jam, raw
materials arrive late, or one worker is slow and everyone waits for them. Time each part before buying new
machines.

**Architecture: a bottleneck triage tree.**

```mermaid
flowchart LR
  LOW["MFU below plan"] --> T1{"Profiler: GPU<br/>kernels busy?"}
  T1 -->|"idle gaps"| T2{"Waiting on what?"}
  T2 -->|"NCCL kernels"| NET["Network: exposed comms<br/>check nccl-tests, overlap, topology"]
  T2 -->|"data loader"| INP["Input: loader, storage,<br/>tokenization"]
  T2 -->|"checkpoint I/O"| CKP["Checkpoint stalls<br/>go async"]
  T2 -->|"other ranks"| STR["Stragglers<br/>per-rank skew, thermals, ECC"]
  T1 -->|"busy but slow"| T3{"Kernel efficiency"}
  T3 --> KER["Small matmuls, no fused attention,<br/>FP32 ops, memory-bound kernels"]
  T3 --> MEMB["Memory pressure: recompute,<br/>fragmentation, small micro-batch"]
```

**How to read it:** first ask whether the GPUs are busy. If there are idle gaps, find what they wait on:
communication, input data, checkpoint writes, or other ranks. If they're busy but slow, look at kernel
efficiency (fused attention, precision, matmul sizes) and memory pressure (recomputation, micro-batch size).

**Terms in this diagram.**
- **Profiler**: a tool such as the PyTorch profiler or NVIDIA Nsight Systems that records a timeline of every GPU
  kernel, so you can see busy periods and gaps.
- **NCCL kernels, exposed comms**: GPU time spent inside communication that *isn't* hidden behind compute.
- **nccl-tests, overlap, topology**: `nccl-tests` measures real collective bandwidth. **Overlap** checks that
  communication runs alongside compute. **Topology** checks that ranks are placed so that tensor-parallel groups share
  NVLink and the job uses the expected network rails.
- **Input: loader, storage, tokenization**: the data loader is too slow, storage reads are slow, or text is being
  tokenized during training instead of once beforehand (Section 28).
- **Checkpoint I/O, go async**: training pauses while checkpoints are written, so write them in the background.
- **Stragglers, thermals, ECC**: a **straggler** is one slow rank that makes every other rank wait at each collective.
  Causes include overheated GPUs (**thermals**) that slow down, and GPUs with memory error correction (**ECC**) problems.
- **Small matmuls, no fused attention, FP32 ops**: matrix multiplications too small to fill the GPU, attention without
  a fused kernel such as Flash Attention (Section 26), and operations accidentally running in slow 32-bit precision.
- **Memory-bound kernels**: operations limited by memory speed, such as element-wise ops, which **fusion** combines.
- **Recompute, fragmentation**: **recompute** (activation checkpointing) saves memory but repeats forward work.
  **Fragmentation** is GPU memory broken into unusable small gaps, which forces smaller micro-batches.

**Core ideas.**
- **MFU math.** tokens/s per GPU × 6 × N ÷ peak. Example: 7B at 3,500 tokens/s per H100 → 6 × 7e9 × 3,500 =
  1.47e14 FLOP/s ÷ 989e12 = 15%, which is poor. A good dense run is 40–55%. (Add attention FLOPs for long sequences.)
- **Tools.** PyTorch Profiler / Kineto traces, Nsight Systems for timelines, DCGM for SM activity, memory
  bandwidth, and throttling, NCCL tests and `NCCL_DEBUG=INFO`, and per-rank step-time histograms.
- **Usual fixes.**
  - Compute: fused attention, BF16/FP8, larger micro-batches, `torch.compile`.
  - Network: overlap, HSDP, topology-aware placement.
  - Input: pre-tokenized shards and more loader workers.
  - Checkpoints: asynchronous saves.
  - Stragglers: health checks and cordoning.
- **Synchronous training is gated by the slowest rank.** One GPU throttled by 20% slows all 1,000 GPUs by 20%.

**Example: the profiler said "network", the network said "fine".** A 256-GPU run showed 25% of step time in
NCCL all-reduce kernels, but `nccl-tests` reached full bandwidth. Per-rank timelines showed every rank
waiting inside all-reduce for rank 173, which arrived ~200 ms late every step. That GPU was running at reduced
clocks from a power-brake fault. Cordoning the node removed the "network problem".

**Senior / FAANG best practice.** Instrument MFU, step-time breakdown, and per-rank skew from day one. Triage in
order: GPU idle or busy, then what it waits on, and fix the measured cause. Keep a library of known-good
reference runs (nccl-tests numbers, single-node MFU) to compare against, and treat stragglers as a
first-class failure mode.

---

## Lecture 216 — Fault tolerance in multi-node training

**Why it matters.** At scale, hardware and software failures are routine. Meta reported 419 unexpected
interruptions in 54 days of Llama 3 405B pretraining on 16 k GPUs, about one every 3 hours. Fault tolerance
decides whether those failures cost minutes or days.

**In plain words.** Writing a long book on a computer that crashes every few hours is fine if you
save every few minutes and can reopen it instantly. It's a disaster if you save once a day and need an
hour to find a working computer.

**Architecture: a resilient training job.**

```mermaid
flowchart LR
  PRE["Pre-flight<br/>burn-in, DCGM diag, nccl-tests"] --> RUN["Training ranks"]
  RUN --> ACK["Async sharded checkpoint<br/>every 15-60 min"]
  ACK --> STORE[("Parallel FS or object store<br/>+ in-memory copy on peers")]
  RUN --> HB["Heartbeats + NCCL timeouts<br/>fail fast"]
  HB -->|"failure"| CTRL["Job controller<br/>torchrun elastic, operator"]
  CTRL --> EXC["Exclude bad node<br/>pull hot spare"]
  EXC --> RST["Restart all ranks"]
  RST --> LOAD["Load latest checkpoint<br/>model, optimizer, data loader, RNG"]
  LOAD --> RUN
```

**How to read it:** nodes are tested before joining. During training, checkpoints are written asynchronously
and often, optionally also kept in peer memory for instant recovery. Heartbeats and collective timeouts detect
failures quickly, and the controller excludes the bad node, brings in a spare, and restarts all ranks from the
latest checkpoint, including data loader position and random number generator state.

**Terms in this diagram.**
- **Pre-flight: burn-in, DCGM diag, nccl-tests**: checks before a node joins. **Burn-in** runs it under full load for
  hours to surface early hardware failures. **DCGM diag** runs NVIDIA's GPU diagnostics. **nccl-tests** confirms network
  bandwidth.
- **Async sharded checkpoint**: each rank saves its own shard in the background while training continues.
- **In-memory copy on peers**: each node also keeps a copy of a neighbor's checkpoint shard in RAM, so recovery doesn't
  have to read from storage.
- **Heartbeats + NCCL timeouts, fail fast**: **heartbeats** are regular "I'm alive" signals from each rank. **NCCL
  timeouts** abort a collective that has hung. Together they detect a failure in seconds or minutes, instead of the job
  hanging for hours.
- **torchrun elastic, operator**: `torchrun` is PyTorch's launcher, and its **elastic** mode can restart workers when
  one fails. An **operator** (such as Kubeflow's training operator) does this on Kubernetes (Section 11).
- **Hot spare**: a healthy, already-tested node kept idle to replace a failed one immediately.
- **RNG**: random number generator state. Restoring it makes dropout and data shuffling continue exactly as before.

**Core ideas.**
- **Expected lost work** per failure ≈ checkpoint interval ÷ 2 + restart time. A rough optimal interval
  (Young/Daly) is √(2 × checkpoint cost × MTBF). With asynchronous checkpoints the blocking cost is small, so
  checkpoint often.
- **Fail fast.** Set NCCL timeouts and watchdogs (for example `TORCH_NCCL_ASYNC_ERROR_HANDLING=1`), so a hung
  collective errors out in minutes, not hours.
- **Elastic restart.** `torchrun --max-restarts`, rendezvous with c10d or etcd, and Kubernetes operators
  (PyTorchJob, JobSet) or Slurm requeue. Spares are pre-warmed.
- **What to checkpoint.** Model and optimizer shards, learning-rate scheduler, step, data loader state, RNG
  states, and config, written atomically with a "complete" marker (Section 32 covers the shard plan).
- **Silent data corruption.** Rare bad GPUs produce wrong math without errors. Detect it with loss and
  gradient-norm anomaly checks and periodic deterministic replay on suspect nodes.

```bash
# elastic launch: up to 3 restarts, c10d rendezvous, fail-fast NCCL
export TORCH_NCCL_ASYNC_ERROR_HANDLING=1 NCCL_TIMEOUT=600
torchrun --nnodes 2:4 --nproc-per-node 8 --max-restarts 3 --rdzv-backend c10d \
  --rdzv-endpoint $HEAD:29500 --rdzv-id run42 train.py --resume-from latest
```

**Example: from hours to minutes.** A 512-GPU job checkpointed synchronously every 4 hours (each save
blocked 9 minutes), and hung collectives took up to 2 hours to time out. With ~4 failures a day, it lost ~10
hours of 512 GPUs daily. Fixes: asynchronous checkpoints every 20 minutes (blocking ~20 s), NCCL timeout 10
minutes, and 2 hot-spare nodes. Daily loss fell to ~1.3 hours, and goodput rose from 58% to 94%.

**Senior / FAANG best practice.** Assume failures. Burn in nodes, fail fast on hangs, checkpoint
asynchronously at an interval set from measured MTBF, restart automatically onto spares, save complete
training state (including data loader position), and monitor goodput as a top-line metric.

---

## Lecture 217 — Lab: train a transformer across multiple nodes

**Goal:** train a small GPT on Tiny Shakespeare with torchrun across 2 nodes (or 2 simulated nodes on one
machine), first with DDP, then with FSDP. Measure tokens/s, MFU, and scaling efficiency, then kill a rank and
resume from checkpoint.

**What you're building.**

```mermaid
flowchart LR
  DATA["tinyshakespeare.txt<br/>char tokens"] --> T["train.py<br/>GPT ~10M params"]
  N0["node 0: torchrun<br/>rank 0..k"] --> RDZV["c10d rendezvous<br/>head:29500"]
  N1["node 1: torchrun<br/>rank k+1..2k"] --> RDZV
  RDZV --> T
  T --> CK[("ckpt/<br/>model, optim, step, RNG")]
  T --> MET["tokens/s, MFU,<br/>scaling efficiency"]
```

**In plain words.** You run one training job across two machines, see what it costs to communicate, and
prove you can survive losing a worker.

**How to read the diagram:** the data is `tinyshakespeare.txt`, about 1 MB of Shakespeare, split into **char tokens**
(one token per character). `train.py` trains a small GPT of about 10 million parameters. On each node, `torchrun`
starts one process per GPU. Node 0 runs ranks 0 to k, and node 1 runs ranks k+1 to 2k. Both connect to the **c10d
rendezvous**, PyTorch's built-in meeting point, at `head:29500` (the head node's hostname and port), where all ranks
find each other before training starts. Checkpoints in `ckpt/` hold the model, the optimizer state, the step number,
and the RNG state. The job reports **tokens/s**, MFU, and **scaling efficiency**: two-node throughput divided by twice
the one-node throughput, where 100% is perfect.

### Step 1 — The training script

```python
# train.py: minimal GPT with DDP or FSDP, checkpoint/resume, throughput and MFU
import argparse, math, os, time, urllib.request
import torch, torch.distributed as dist, torch.nn as nn, torch.nn.functional as F

p = argparse.ArgumentParser()
p.add_argument("--mode", choices=["ddp", "fsdp"], default="ddp")
p.add_argument("--steps", type=int, default=300)
p.add_argument("--peak-tflops", type=float, default=0, help="per-device peak for MFU, e.g. 989 for H100 BF16")
a = p.parse_args()

dist.init_process_group("nccl" if torch.cuda.is_available() else "gloo")
rank, world, local = dist.get_rank(), dist.get_world_size(), int(os.environ.get("LOCAL_RANK", 0))
dev = torch.device(f"cuda:{local}" if torch.cuda.is_available() else "cpu")
if dev.type == "cuda":
    torch.cuda.set_device(dev)

if rank == 0 and not os.path.exists("input.txt"):
    urllib.request.urlretrieve("https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt", "input.txt")
dist.barrier()
text = open("input.txt").read()
vocab = sorted(set(text)); stoi = {c: i for i, c in enumerate(vocab)}
data = torch.tensor([stoi[c] for c in text], dtype=torch.long)

T, B, D, L, H = 256, 16, 384, 6, 6
class Block(nn.Module):
    def __init__(s):
        super().__init__(); s.ln1, s.ln2 = nn.LayerNorm(D), nn.LayerNorm(D)
        s.qkv, s.proj = nn.Linear(D, 3 * D), nn.Linear(D, D)
        s.mlp = nn.Sequential(nn.Linear(D, 4 * D), nn.GELU(), nn.Linear(4 * D, D))
    def forward(s, x):
        q, k, v = s.qkv(s.ln1(x)).view(x.size(0), T, 3, H, D // H).unbind(2)
        y = F.scaled_dot_product_attention(q.transpose(1, 2), k.transpose(1, 2), v.transpose(1, 2), is_causal=True)
        x = x + s.proj(y.transpose(1, 2).reshape(x.size(0), T, D))
        return x + s.mlp(s.ln2(x))
class GPT(nn.Module):
    def __init__(s):
        super().__init__(); s.tok, s.pos = nn.Embedding(len(vocab), D), nn.Embedding(T, D)
        s.blocks = nn.ModuleList(Block() for _ in range(L)); s.ln, s.head = nn.LayerNorm(D), nn.Linear(D, len(vocab))
    def forward(s, idx):
        x = s.tok(idx) + s.pos(torch.arange(T, device=idx.device))
        for b in s.blocks: x = b(x)
        return s.head(s.ln(x))

model = GPT().to(dev)
n_params = sum(p.numel() for p in model.parameters())
if a.mode == "ddp":
    model = nn.parallel.DistributedDataParallel(model, device_ids=[local] if dev.type == "cuda" else None)
else:
    from torch.distributed.fsdp import FullyShardedDataParallel as FSDP
    model = FSDP(model, device_id=dev if dev.type == "cuda" else None)
opt = torch.optim.AdamW(model.parameters(), lr=3e-4)

start = 0
if os.path.exists("ckpt/last.pt") and a.mode == "ddp":
    ck = torch.load("ckpt/last.pt", map_location=dev)
    model.module.load_state_dict(ck["model"]); opt.load_state_dict(ck["opt"]); start = ck["step"] + 1
    torch.set_rng_state(ck["rng"])
    if rank == 0: print(f"resumed at step {start}")

g = torch.Generator()
t0, tokens = time.time(), 0
for step in range(start, a.steps):
    g.manual_seed(1_000_003 * rank + step)          # data position is a function of (rank, step): exact resume
    ix = torch.randint(len(data) - T - 1, (B,), generator=g)
    x = torch.stack([data[i:i + T] for i in ix]).to(dev); y = torch.stack([data[i + 1:i + T + 1] for i in ix]).to(dev)
    with torch.autocast(dev.type, dtype=torch.bfloat16, enabled=dev.type == "cuda"):
        loss = F.cross_entropy(model(x).view(-1, len(vocab)), y.view(-1))
    opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
    tokens += B * T * world
    if step % 50 == 0 and rank == 0:
        dt = time.time() - t0; tps = tokens / dt
        mfu = 6 * n_params * tps / (world * a.peak_tflops * 1e12) if a.peak_tflops else float("nan")
        print(f"step {step} loss {loss.item():.3f} tokens/s {tps:,.0f} per-device {tps / world:,.0f} MFU {mfu:.1%}")
    if step % 100 == 0 and a.mode == "ddp" and rank == 0:
        os.makedirs("ckpt", exist_ok=True)
        torch.save({"model": model.module.state_dict(), "opt": opt.state_dict(), "step": step,
                    "rng": torch.get_rng_state()}, "ckpt/tmp.pt")
        os.replace("ckpt/tmp.pt", "ckpt/last.pt")              # atomic: never a half-written "last"
dist.destroy_process_group()
```

### Step 2 — Launch on one node, then two

```bash
# baseline: 1 node (GPUs: --nproc-per-node 8; CPU-only: 2 processes with gloo)
torchrun --standalone --nproc-per-node 2 train.py --mode ddp --peak-tflops 989
# two real nodes (run on each, same HEAD address)
torchrun --nnodes 2 --nproc-per-node 8 --node-rank 0 --rdzv-backend c10d --rdzv-endpoint $HEAD:29500 train.py   # node 0
torchrun --nnodes 2 --nproc-per-node 8 --node-rank 1 --rdzv-backend c10d --rdzv-endpoint $HEAD:29500 train.py   # node 1
# no second machine: simulate 2 nodes on localhost in two terminals
torchrun --nnodes 2 --nproc-per-node 1 --node-rank 0 --rdzv-backend c10d --rdzv-endpoint localhost:29500 train.py
torchrun --nnodes 2 --nproc-per-node 1 --node-rank 1 --rdzv-backend c10d --rdzv-endpoint localhost:29500 train.py
```

**If workers hang for 5 minutes, then fail with `DistNetworkError: The client socket has timed out ... trying to
connect to (<your-hostname>, <port>)`:** torchrun advertised the machine's hostname, and that name doesn't resolve
to a reachable address. This is common on laptops, especially macOS. Force the loopback address and interface:

```bash
GLOO_SOCKET_IFNAME=lo0 MASTER_ADDR=127.0.0.1 torchrun --nnodes 1 --nproc-per-node 2 --local-addr 127.0.0.1 \
  --rdzv-backend c10d --rdzv-endpoint 127.0.0.1:29500 train.py --mode ddp    # use lo instead of lo0 on Linux
```

`--local-addr` tells torchrun which address to advertise, and `GLOO_SOCKET_IFNAME` tells the gloo backend which
network interface to use. On real clusters, the same symptom usually means a firewall or DNS problem between nodes.

### Step 3 — FSDP and scaling efficiency

```bash
torchrun --standalone --nproc-per-node 2 train.py --mode fsdp
```

Compute scaling efficiency = (tokens/s at N devices) ÷ (N × tokens/s at 1 device), and compare DDP and FSDP
for this small model.

### Step 4 — Kill and resume

```bash
torchrun --standalone --nproc-per-node 2 --max-restarts 1 train.py --mode ddp --steps 600 &
sleep 60; pkill -9 -f "train.py --mode ddp" -n     # kill the newest worker process
wait; ls -l ckpt/
torchrun --standalone --nproc-per-node 2 train.py --mode ddp --steps 600   # prints "resumed at step ..."
```

**Expected results:**
- Loss falls from ~4.2 (uniform over ~65 characters) to ~1.6–1.9 in 300 steps. The model has ~10.8 M parameters.
- On GPUs, MFU for this tiny model is low (often 5–20%), because its matmuls are too small to fill an H100. That's a
  useful lesson in why MFU depends on model size and batch size.
- Scaling efficiency within one node over NVLink is high (≥ 90%). Across two nodes, it drops noticeably for this
  small model, because the gradient all-reduce isn't hidden behind so little compute. On CPU with gloo, it's lower
  still.
- FSDP is slightly slower than DDP for a model that fits, since it does extra all-gathers. It pays off only when
  memory requires it.
- After the kill, the job restarts (`--max-restarts 1`) or you relaunch it, and it prints `resumed at step 500` (or the last
  multiple of 100), with loss continuing smoothly because model, optimizer, and RNG state were saved together.

---

## FAANG deep-dive notes

**How big tech does it.** Large training organizations run standardized training platforms: topology-aware
schedulers, pre-flight health checks, a library of tuned parallelism layouts per model size and cluster, and
built-in asynchronous checkpointing with automatic restart onto spares. Every run reports MFU, goodput,
step-time breakdown, and per-rank skew on a shared dashboard. Scaling decisions come from short scaling
tests, and the infrastructure team is accountable for effective compute delivered, not GPUs allocated.

**Staff review questions.**
- What's the effective compute plan (GPUs × peak × MFU × goodput), and how does the first week compare?
- Why this parallelism layout, and which collectives cross the network?
- Is communication overlapped, and where are the exposed collectives in the trace?
- What's the MTBF at this scale, the checkpoint interval, and the expected lost work per failure?
- How are stragglers and silent data corruption detected?

**Interview question.** "Our 512-GPU job gets 30% MFU. How do you find out why and fix it?"

**Typical system-design prompt:** *Design the training setup for a 34B dense model on 1,024 H100s (128 nodes),
sequence length 8k, 3 T tokens, with a 40-day deadline and 95% goodput target.*

**1. Clarify first:** What is the cluster topology (NVLink domains, rails, oversubscription)? What are the
checkpoint storage bandwidth and the historical failure rate? What's the data readiness? Is FP8 allowed? Can the
global batch size grow, given convergence constraints?

**2. Back-of-envelope sizing:**
- Compute: 6 × 34e9 × 3e12 = 6.1e23 FLOPs. Effective per GPU at 45% MFU ≈ 445 TFLOP/s. × 1,024 × 0.95 goodput
  ≈ 4.3e17 FLOP/s, so ≈ 1.4e6 s ≈ 16.5 days. That fits the deadline with margin for evals and restarts.
- Memory: 34B × 16 B = 544 GB of state. HSDP within nodes plus TP 2 keeps per-GPU state and activations under
  80 GB with selective checkpointing at 8k.
- Gradient sync: 34B × 2 B = 68 GB of BF16 gradients per replica group per step. Hierarchical reduction (NVLink first,
  then network) and overlap are required.
- Failures: ~1 every 8–10 hours at this scale. Async checkpoints every 30 minutes (≈ 0.5 TB, ~10–20 s blocking)
  keep lost work ≈ 15 minutes + restart per failure.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Sharding | Full FSDP over all ranks | HSDP (shard in node, replicate across) | HSDP when cross-node all-gathers dominate |
| TP | 1–2 | 8 | Smallest TP that fits activations. Large TP shrinks matmuls |
| PP | None | 4+ stages | Add PP only if TP + sharding can't fit. It adds a bubble |
| Checkpoint | Synchronous every 2–4 h | Async every 15–60 min | Interval ≈ √(2 × cost × MTBF). Async makes cost tiny |
| Batch growth | Increase global batch | Keep batch, add model parallel | Stay below the critical batch size |

**4. Follow-up questions with crisp answers:**
- *How do you know communication is the bottleneck?* The profiler shows exposed NCCL time (not overlapped), and
  per-rank timelines show no single straggler. `nccl-tests` confirms whether the fabric meets its baseline.
- *Why is MFU low even though GPUs show 100% utilization?* "GPU utilization" only means a kernel is running. MFU
  counts useful FLOPs, so memory-bound kernels, small matmuls, and recomputation lower MFU while utilization stays at 100%.
- *What happens if one node fails at step 120k?* Watchdogs time out within minutes. The controller excludes the
  node, pulls a spare, and restarts all ranks from the checkpoint at, say, 119.6k, with data loader and RNG
  restored.
- *How do you scale from 512 to 1,024 GPUs?* Keep work per GPU constant, check that the global batch stays below the
  critical size, measure scaling efficiency with a short run, and adjust the layout.

**Debug this (common onsite question):** "A 1,024-GPU run's step time is stable at 6.1 s, but every ~45 minutes
there's a 90-second step, and goodput is 3 points below plan."
1. Correlate slow steps with events. They line up with checkpoint saves.
2. The "async" checkpoint still blocks: each rank copies its shard to CPU memory synchronously, and
   pinned-memory allocation for 1,024 shards stalls on host memory.
3. Storage writes then saturate the frontend network shared with data loading, so the next steps are slow too.
4. Fix: preallocate pinned buffers once, stage the copy to CPU in chunks overlapped with compute, rate-limit
   uploads on a separate network path, and stagger shards across ranks.

The lesson: measure what "asynchronous" really blocks. Checkpointing, data loading, and logging all share
resources with training and must be profiled like compute.

**5. What separates senior from staff answers:** a senior engineer picks a reasonable parallelism layout, tunes
overlap, and sets up checkpoint and restart. A staff engineer plans in effective compute, validates scaling
before committing, maps every collective to the topology, quantifies failure economics (MTBF, interval, spares),
builds triage tooling for MFU regressions, and reports goodput as a business metric.

**Red flags:**
- GPU count presented as the plan, without MFU and goodput.
- TP across nodes.
- Pipelines with m < p.
- Exposed all-reduce with no overlap check.
- Checkpoints every few hours.
- No per-rank skew metric.
- Restart that doesn't restore data loader and RNG state.

---

## Quiz

<details><summary>1. Define MFU and goodput.</summary>
MFU = achieved model FLOPs (≈ 6 × params × tokens/s) ÷ (GPUs × peak FLOPs). Goodput = productive training time ÷ wall-clock
time. Effective compute = GPUs × peak × MFU × goodput.
</details>

<details><summary>2. Why can't you scale data parallelism forever?</summary>
The global batch grows with the number of replicas, and beyond the critical batch size, more samples per step no longer
reduce the steps needed. Memory per GPU also stays at the full model size unless it's sharded.
</details>

<details><summary>3. Compute the pipeline bubble for p = 8, m = 32.</summary>
(p − 1)/(m + p − 1) = 7/39 ≈ 18%.
</details>

<details><summary>4. What does 1F1B improve over GPipe?</summary>
Activation memory. It keeps at most about p micro-batches of activations alive instead of all m, with the same bubble
fraction.
</details>

<details><summary>5. How many bytes does ring all-reduce send per GPU?</summary>
About 2 × (N − 1)/N × S for S bytes of data, which is nearly 2S regardless of N. Time is about 2S ÷ per-GPU bandwidth.
</details>

<details><summary>6. What is a distributed optimizer (ZeRO-1)?</summary>
Gradients are reduce-scattered, each rank updates only its shard of the optimizer states and parameters, and the
updated parameters are all-gathered. It has the same traffic as all-reduce and 1/N of the optimizer memory.
</details>

<details><summary>7. GPUs show 100% utilization but MFU is 20%. Why?</summary>
Utilization only means some kernel is running. Memory-bound or small kernels, recomputation, unfused operations, or
waiting inside communication kernels all count as "utilized" while delivering few useful FLOPs.
</details>

<details><summary>8. How do you choose a checkpoint interval?</summary>
Minimize expected lost work per failure plus checkpoint overhead. A rough optimum is √(2 × checkpoint cost × MTBF).
Asynchronous checkpointing lowers the cost, so you can checkpoint more often.
</details>

## Failure modes
- Planning by GPU count without MFU and goodput.
- Tensor parallelism across nodes, or pipelines with too few micro-batches.
- Unbalanced pipeline stages because of embedding and output layers.
- Gradient sync not overlapped with backward (misused `no_sync`, tiny buckets).
- One straggler GPU slowing the whole job unnoticed.
- Hung collectives without timeouts that waste hours.
- Synchronous or infrequent checkpoints, or "async" saves that still block.
- Restarts that don't restore data loader position and RNG state.
- Silent data corruption on a bad GPU, not detected by anomaly checks.

## Checklist
- [ ] You can compute MFU, goodput, and effective compute for a run
- [ ] You can choose DP, FSDP/HSDP, TP, and PP with memory and communication math
- [ ] You can compute pipeline bubbles and pick schedules and micro-batch counts
- [ ] You can estimate all-reduce time and verify overlap in a profiler trace
- [ ] You can triage low MFU into compute, network, input, checkpoint, or straggler causes
- [ ] You can design fault tolerance: burn-in, timeouts, async checkpoints, spares, full-state restore
- [ ] You trained a GPT with torchrun across 2 nodes (or simulated), measured scaling, and resumed after a kill
