# Section 36 — Advanced AI Infrastructure Optimization

> Lectures 246–252 • Assessment: quiz
> **After this section you can:** train with automatic mixed precision in FP16, BF16, and FP8, explain loss scaling,
> run quantization-aware training to recover quality lost by post-training quantization, plan large distillation
> jobs including teacher-logit storage, judge when sparse training speeds up hardware, use `torch.compile` and XLA
> and debug graph breaks, and choose an optimization on an accuracy-vs-cost Pareto frontier.
>
> Builds on: [Section 35](s35_optimization_foundations.md) (quantization, pruning, distillation, sparsity basics),
> [Section 7](../part02_data_gpus_training/s07_gpu_hardware.md) (tensor cores, number formats), and
> [Section 31](s31_large_scale_training.md) (large-scale training).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 246 | Mixed precision training with AMP | Compute in BF16 or FP16 (or FP8), keep master weights in FP32: about 2× faster and half the activation memory |
| 247 | Quantization-aware training (QAT) | Simulate low precision during training so the model learns to tolerate it, recovering most PTQ losses |
| 248 | Advanced distillation techniques | On-policy, reasoning-trace, and feature distillation, and the storage and compute plan behind them |
| 249 | Sparse training and hardware impacts | 2:4 and dynamic sparse training, and MoE, help only when kernels and hardware exploit them |
| 250 | Compiler optimizations (XLA, TorchDynamo) | Capture the graph, fuse operations, and cut overhead: 1.3–2× for free, if you avoid graph breaks |
| 251 | Infra trade-offs: accuracy vs efficiency | Plot options on a Pareto frontier and choose by cost per quality point at the SLO |
| 252 | Lab: train with mixed precision | Compare FP32, FP16 AMP, BF16 AMP, and `torch.compile` on speed, memory, and accuracy |

```mermaid
flowchart LR
  TRAIN["Training efficiency"] --> AMP["Mixed precision<br/>BF16, FP16, FP8"]
  TRAIN --> COMP["Compilers<br/>torch.compile, XLA"]
  TRAIN --> SPT["Sparse training<br/>2:4, MoE"]
  QUALITY["Deployable efficiency"] --> QAT["QAT<br/>low-bit without the drop"]
  QUALITY --> DIST["Advanced distillation<br/>small models, strong quality"]
  AMP & COMP & SPT & QAT & DIST --> PARETO{"Pareto frontier<br/>accuracy vs cost"}
  PARETO --> PICK["Choose by cost per quality point<br/>at the SLO"]
```

**How to read it:** the left branch makes training itself cheaper and faster, with mixed precision, compilers, and
sparse training. The lower branch makes the deployed model cheaper without losing quality, with quantization-aware
training and distillation. All options are compared on a Pareto frontier of accuracy against cost, and you choose the
one with the best cost per quality point that meets the service-level objective.

**Terms in this diagram.**
- **Training efficiency, deployable efficiency**: making training runs cheaper and faster, and making the model that
  ships cheaper to serve.
- **Mixed precision, BF16, FP16, FP8**: doing most math in a 16-bit or 8-bit format while keeping key values in
  32-bit (Lecture 246).
- **Compilers, torch.compile, XLA**: tools that turn model code into optimized GPU or TPU programs (Lecture 250).
- **Sparse training, 2:4, MoE**: training with many zero weights, or with mixture-of-experts models that use only some
  experts per token (Lecture 249).
- **QAT**: quantization-aware training (Lecture 247).
- **Pareto frontier**: the set of options where you can't improve accuracy without raising cost, or cut cost without
  losing accuracy (Lecture 251).
- **SLO**: service-level objective, the agreed latency or quality target (Section 16).

---

## Lecture 246 — Mixed precision training with AMP

**Why it matters.** Mixed precision is the single easiest training speedup: tensor cores run BF16 and FP16 math many
times faster than FP32, and activations take half the memory. Every large model today trains in mixed precision, and
FP8 training (on H100 and newer) adds up to another ~1.3–1.5× for large transformers.

**In plain words.** It's like doing quick calculations on a pocket calculator for speed, while keeping the official
account balance in a precise ledger. Each quick result is added to the ledger carefully, so small amounts don't get
lost over thousands of transactions.

**Architecture: one mixed-precision training step.**

```mermaid
flowchart TB
  MW["FP32 master weights"] -->|"cast"| LW["BF16 or FP16 copy"]
  LW --> FWD["Forward under autocast<br/>matmuls in low precision,<br/>softmax, norms, loss in FP32"]
  FWD --> LOSS["Loss"]
  LOSS -->|"FP16 only: multiply by scale S"| BWD["Backward<br/>low-precision gradients"]
  BWD -->|"FP16 only: divide by S,<br/>skip step if inf or NaN"| GR["FP32 gradients"]
  GR --> OPT["Optimizer update<br/>on FP32 master weights"]
  OPT --> MW
```

**How to read it:** the optimizer keeps master weights in FP32. Each step uses a BF16 or FP16 copy. Inside autocast,
matrix multiplies and convolutions run in low precision, while numerically sensitive operations (softmax,
normalization, the loss) stay in FP32. With FP16 only, the loss is multiplied by a scale factor before backward so
small gradients don't round to zero, then divided again, and steps with overflowed gradients are skipped. The
optimizer updates the FP32 master weights.

**Terms in this diagram.**
- **FP32 master weights**: the full-precision weights the optimizer updates, so tiny updates aren't lost to rounding.
- **BF16 or FP16 copy**: the low-precision weights used for computing. **FP16** has more precision but a small range
  (largest value about 65,504). **BF16** has FP32's range with less precision, so it rarely overflows.
- **Autocast**: PyTorch's context (`torch.autocast`) that automatically picks the precision for each operation from a
  built-in list.
- **Softmax, norms**: softmax turns scores into probabilities, and normalization layers (LayerNorm, BatchNorm)
  rescale activations. Both are sensitive to rounding, so they run in FP32.
- **Scale S**: the loss-scaling factor, such as 65,536, adjusted automatically by `GradScaler`.
- **Inf or NaN**: infinity, or "not a number", the results of overflow. A step with these gradients is skipped, and
  the scale is reduced.

**Core ideas.**
- **Prefer BF16 on Ampere (A100) and newer, and on TPUs.** Its FP32-sized range means no loss scaling is needed. Use
  FP16 with `GradScaler` on older GPUs such as V100 and T4, which lack fast BF16.
- **What speeds up.** Tensor core math (up to ~2× over TF32 on A100 and H100, much more over plain FP32), memory
  traffic for activations, and memory capacity, which allows larger batches. Small models that are limited by Python
  or data loading see less gain.
- **TF32.** On Ampere and newer, FP32 matrix multiplies can use TF32 tensor cores (enable with
  `torch.backends.cuda.matmul.allow_tf32 = True` or `torch.set_float32_matmul_precision("high")`). It's an easy
  speedup even without AMP, but AMP is faster still.
- **FP8 training.** NVIDIA Transformer Engine and PyTorch's `torchao.float8` run linear layers in FP8 with per-tensor
  or finer scales, using E4M3 for forward and E5M2 for gradients. Gains appear on large matrices (hidden size of
  4,096 or more), and it needs loss-curve comparison against BF16 at the start of each new model.
- **Memory.** Master weights plus Adam states are still FP32 (16 bytes per parameter with mixed precision, Section 7).
  Mixed precision mainly saves activation memory, and sharding (Section 32) saves the rest.

```python
import torch
from torch import nn

model = build_model().cuda()
opt = torch.optim.AdamW(model.parameters(), lr=3e-4, fused=True)
use_fp16 = not torch.cuda.is_bf16_supported()
dtype = torch.float16 if use_fp16 else torch.bfloat16
scaler = torch.amp.GradScaler("cuda", enabled=use_fp16)

for x, y in loader:
    x, y = x.cuda(non_blocking=True), y.cuda(non_blocking=True)
    with torch.autocast("cuda", dtype=dtype):
        loss = nn.functional.cross_entropy(model(x), y)
    scaler.scale(loss).backward()
    scaler.unscale_(opt)
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    scaler.step(opt)
    scaler.update()
    opt.zero_grad(set_to_none=True)
```

In the code, the GPU's BF16 support decides the format, and `GradScaler` is enabled only for FP16. With BF16, its
methods pass straight through, so one loop handles both. `scaler.unscale_` divides the gradients by the scale before
gradient clipping, so the clipping threshold applies to real gradient values. `scaler.step` skips the step if any
gradient is infinite. `fused=True` uses a single fused CUDA kernel for the AdamW update.

```python
import transformer_engine.pytorch as te
from transformer_engine.common.recipe import DelayedScaling, Format

layer = te.Linear(8192, 8192, bias=False).cuda()
recipe = DelayedScaling(fp8_format=Format.HYBRID, amax_history_len=16, amax_compute_algo="max")
with te.fp8_autocast(enabled=True, fp8_recipe=recipe):
    out = layer(x_bf16)
```

In the FP8 code, `te.Linear` is Transformer Engine's FP8-capable linear layer. `Format.HYBRID` uses E4M3 in the
forward pass and E5M2 for gradients. **Delayed scaling** sets each tensor's FP8 scale from the largest absolute value
(**amax**) seen over the last 16 steps.

**Example: a 2.1× faster vision model.** A team trained a ResNet-152 detector in FP32 on V100s at 210 images per
second per GPU. Switching to FP16 AMP with `GradScaler` and channels-last memory format raised it to 440 images per
second, and the batch size per GPU doubled because activations took half the memory. The run finished in 2 days
instead of 4.3, with the same final mAP.

**Senior / FAANG best practice.** Use BF16 autocast by default on Ampere, Hopper, Blackwell, and TPUs, and FP16 with
`GradScaler` only on older GPUs. Enable TF32 for remaining FP32 math. Adopt FP8 for large transformers after
comparing loss curves against BF16. Watch for skipped steps and the loss scale in logs, and remember that optimizer
memory still needs sharding.

---

## Lecture 247 — Quantization-aware training (QAT)

**Why it matters.** Post-training quantization works well at 8 bits, but at 4 bits or below it can cost several
points of accuracy, especially for small models. QAT lets the model adapt to quantization during training. Meta's
quantized Llama 3.2 1B and 3B and Google's Gemma 3 QAT models used it to keep quality close to BF16 at 4 bits.

**In plain words.** PTQ is like translating a speech after it's written and hoping it still fits the time slot. QAT is
like the speaker practicing with the time limit from the start, so the speech is written to fit.

**Architecture: QAT with fake quantization.**

```mermaid
flowchart LR
  W["FP32 or BF16 weights"] --> FQW["Fake-quantize weights<br/>round to INT4 grid, keep float"]
  A["Activations"] --> FQA["Fake-quantize activations<br/>INT8 grid"]
  FQW & FQA --> MM["Matmul in float"]
  MM --> L["Loss"]
  L -->|"backward: STE<br/>gradient passes through rounding"| W
  W -->|"after training: convert"| REAL["Real INT4 weights + scales<br/>deployed with low-bit kernels"]
```

**How to read it:** during QAT training, weights and activations are rounded to the low-precision grid but kept as
floating-point numbers (fake quantization), so the forward pass sees the same errors that real quantization will
cause. In the backward pass, gradients pass straight through the rounding as if it weren't there. After training, the
weights are converted to real low-bit integers with their scales and deployed with low-bit kernels.

**Terms in this diagram.**
- **Fake-quantize**: quantize and immediately dequantize, `x̂ = round(x / s) × s`, so the value is still a float but
  carries the rounding error.
- **INT4 grid, INT8 grid**: the set of values a 4-bit or 8-bit integer can represent after scaling (16 or 256 levels).
- **STE (straight-through estimator)**: rounding has a zero gradient almost everywhere, so QAT treats its gradient as
  1, letting the weights learn.
- **Convert**: replace the fake-quantized layers with real quantized weights for deployment.
- **Low-bit kernels**: GPU or CPU code that computes with INT4 or INT8 values directly.

**Core ideas.**
- **When to use QAT.** When PTQ (Section 35) loses more than your quality budget, typically at 4 bits for weights,
  8 bits for activations in small models, or on edge devices with integer-only hardware.
- **Cost.** QAT is fine-tuning, not pre-training: commonly 1–10% of the original training steps, though it's slower
  per step (fake quantization adds work, often 30–60% more step time).
- **Start from PTQ.** Initialize scales from a PTQ calibration, then fine-tune with a lower learning rate.
- **QAT + LoRA.** Freeze the base model, fake-quantize it, and train LoRA adapters (Section 26) to compensate. It's
  much cheaper than full QAT, and this was the approach for Meta's quantized Llama 3.2.
- **Match the deployment kernel.** Train with the exact scheme you'll deploy (bit width, group size, symmetric or not,
  per-token activations), or the gains disappear on conversion.

```python
from torchao.quantization import quantize_, Int8DynamicActivationInt4WeightConfig
from torchao.quantization.qat import QATConfig

base = Int8DynamicActivationInt4WeightConfig(group_size=32)
quantize_(model, QATConfig(base, step="prepare"))     # insert fake quantization
train(model, steps=2_000, lr=1e-5)                      # short fine-tune with fake quantization
quantize_(model, QATConfig(base, step="convert"))     # real INT4 weights, INT8 dynamic activations
```

In the code (torchao 0.13 or newer), `Int8DynamicActivationInt4WeightConfig` is the deployment scheme: INT4 weights in
groups of 32, and INT8 activations quantized per token at run time ("dynamic"). The `prepare` step inserts fake
quantization matching that scheme, training runs as usual, and the `convert` step produces real quantized weights.
Older torchao versions use `Int8DynActInt4WeightQATQuantizer` with `prepare` and `convert` methods.

**Example: recovering a 4-bit mobile model.** A 1B assistant model lost 6.1 points on its evaluation with INT4 PTQ,
too much for launch. QAT with the same INT4 group-32 scheme for 3,000 steps (about 2% of the original fine-tuning
compute) recovered to 1.2 points below BF16, and the model fit the 1 GB memory budget on target phones.

**Senior / FAANG best practice.** Try PTQ first and use QAT when the drop exceeds the budget. Train with exactly the
deployment scheme, start from PTQ-calibrated scales, use a low learning rate for a few percent of the original
steps, and consider QAT with LoRA to cut cost. Evaluate the converted model, not the fake-quantized one.

---

## Lecture 248 — Advanced distillation techniques

**Why it matters.** Simple logit distillation (Section 35) is just the start. Today's strongest small models come
from distilling reasoning traces, on-policy distillation, and carefully planned teacher pipelines. These are large
infrastructure jobs: the teacher may be a 400B model, and the data can reach billions of tokens.

**In plain words.** Basic distillation is copying the teacher's answers. Advanced distillation is copying how the
teacher works the problem out (reasoning traces), and having the teacher correct the student's own attempts
(on-policy), the way a tutor reviews your homework instead of handing you an answer key.

**Architecture: a large distillation pipeline.**

```mermaid
flowchart TB
  PROMPTS[("Prompt set<br/>in-domain + hard cases")] --> GEN["Teacher generation<br/>vLLM, batch, cheaper capacity"]
  GEN --> FILT["Filter + verify<br/>unit tests, math checkers, judges"]
  FILT --> SFT["Student SFT on traces<br/>sequence-level distillation"]
  GEN -->|"optional"| LOGITS[("Top-k teacher logits<br/>per token")]
  LOGITS --> KD["Token-level KD loss"]
  SFT --> ONP["On-policy stage<br/>student generates, teacher scores"]
  KD --> ONP
  ONP --> EVAL["Evaluate vs teacher<br/>task evals, slices"]
```

**How to read it:** a prompt set goes to the teacher, running as a large batch job on cheaper capacity. Its outputs
are filtered and verified (code with tests, math with checkers, other text with judge models). The student is first
fine-tuned on the verified traces. Optionally, the teacher's top-k token probabilities are stored to add a token-level
distillation loss. A final on-policy stage has the student generate its own answers and the teacher score them, which
fixes errors the student actually makes. The student is evaluated against the teacher on task evaluations and slices.

**Terms in this diagram.**
- **Teacher generation, vLLM, batch**: running the teacher model over all prompts as an offline job, using the vLLM
  serving engine for throughput (Section 15).
- **Cheaper capacity**: spot or preemptible GPUs, or idle reserved capacity at night (Section 12).
- **Filter + verify, unit tests, math checkers, judges**: removing wrong or low-quality outputs by running generated
  code against tests, checking math answers, or scoring with a judge model (an LLM grading outputs, Section 26).
- **SFT on traces, sequence-level distillation**: supervised fine-tuning of the student on the teacher's full
  responses, including its step-by-step reasoning.
- **Top-k teacher logits**: the teacher's k highest-scoring next tokens and their scores, stored for each position,
  instead of all ~128,000 vocabulary entries.
- **Token-level KD loss**: a distillation loss comparing the student's and teacher's probabilities at every token
  (Section 35).
- **On-policy stage**: training on sequences the student generates itself, scored token by token by the teacher.
  Methods include GKD (generalized knowledge distillation) and MiniLLM, which use reverse KL divergence.

**Core ideas.**
- **Reasoning-trace distillation.** DeepSeek fine-tuned Qwen and Llama models (1.5B to 70B) on about 800,000
  samples generated by DeepSeek-R1, and the distilled models outperformed much larger non-reasoning models on math
  benchmarks. Verification of traces matters as much as volume.
- **Why on-policy.** A student trained only on teacher outputs never sees its own mistakes. On-policy distillation
  scores the student's own outputs, fixing the mismatch between training and use (exposure bias).
- **Logit storage math.** Full-vocabulary logits are impossible to store: 128,256 × 2 bytes = 256 KB per token, so
  10 billion tokens would need 2.6 PB. The top 20 entries, as a 4-byte index plus a 2-byte value each, take
  120 bytes per token, or 1.2 TB for 10 billion tokens. Alternatively, run the teacher online beside the student.
- **Online vs offline teacher.** Offline (pre-generated) is simpler and reusable. Online (teacher served during
  training) is needed for on-policy methods, and needs teacher GPUs reserved for the whole run.
- **Feature and attention distillation** match hidden states or attention maps through small projection layers. They
  help when the student is a pruned version of the teacher (Section 35, Minitron).
- **Licenses and terms.** Many model licenses and API terms restrict using outputs to train competing models. Check
  before generating.

```python
import torch
import torch.nn.functional as F

def topk_kd_loss(student_logits, teacher_idx, teacher_vals, T=1.0):
    """student_logits: (B, L, V). teacher_idx, teacher_vals: (B, L, k) stored top-k teacher logits."""
    s = torch.gather(student_logits / T, -1, teacher_idx)               # student scores on teacher's top-k tokens
    t = F.softmax(teacher_vals.float() / T, dim=-1)                     # teacher distribution renormalized over top-k
    return F.kl_div(F.log_softmax(s, dim=-1), t, reduction="batchmean") * T * T
```

In the code, `torch.gather` picks the student's scores for the teacher's stored top-k token IDs at every position. Both
distributions are renormalized over those k tokens, an approximation that works well because the top 20 tokens
usually hold almost all the teacher's probability. The stored values are cast to `float` because they're kept in 16
bits on disk.

**Example: a distilled coding model.** A company needed a code-completion model that ran on one L4 GPU. They
generated 4 million solutions with a 70B teacher, kept the 1.9 million that passed unit tests, fine-tuned a 7B
student on them, then ran 2 days of on-policy distillation with the teacher served online on 16 GPUs. The student
reached 92% of the teacher's pass rate on their internal benchmark at about one-tenth of the serving cost.

**Senior / FAANG best practice.** Run teacher generation as a batch job on cheaper capacity, verify outputs before
training, start with sequence-level distillation, and add on-policy distillation to fix the student's own errors.
Store top-k logits rather than full distributions, size storage up front, reserve teacher GPUs for online stages, and
confirm the licenses allow distillation.

---

## Lecture 249 — Sparse training and hardware impacts

**Why it matters.** Training with sparsity promises less compute, but real speedups depend on whether the kernels and
hardware skip the zeros. The most successful "sparse" training today is mixture of experts, which brings its own
infrastructure costs: all-to-all communication, load balancing, and large memory.

**In plain words.** A sparse model is like a big company where each task is handled by only a few departments. It
saves effort only if the mailroom routes work quickly to the right departments, and every department needs its own
office space even when idle.

**Architecture: kinds of sparse training and what they cost.**

```mermaid
flowchart TB
  ST["Sparse training"] --> S24["2:4 semi-structured<br/>prune during training"]
  ST --> DST["Dynamic sparse training<br/>RigL: drop and regrow weights"]
  ST --> MOEX["Mixture of experts<br/>conditional compute"]
  S24 --> H1["Sparse tensor cores<br/>about 1.1-1.3x on large MLPs"]
  DST --> H2["Few GPU kernels exploit it<br/>Cerebras-style hardware can"]
  MOEX --> H3["Expert parallelism<br/>all-to-all over NVLink or InfiniBand"]
  H3 --> LB["Load balancing<br/>aux loss, capacity factor"]
  H3 --> MEMX["All experts in memory<br/>more GPUs or offload"]
```

**How to read it:** there are three main kinds of sparse training. 2:4 semi-structured sparsity prunes weights during
training and runs on sparse tensor cores, with modest speedups on large feed-forward layers. Dynamic sparse training,
such as RigL, keeps changing which weights are zero, and few GPU kernels can exploit it, though some specialized
hardware can. Mixture-of-experts models send each token to a few experts. That needs expert parallelism with
all-to-all communication, load balancing so experts are used evenly, and memory for every expert.

**Terms in this diagram.**
- **Prune during training**: applying the 2:4 pattern while training, so the model learns with it rather than having
  it forced on afterwards.
- **Large MLPs**: the big feed-forward (multi-layer perceptron) layers in each transformer block, where the matrices
  are large enough for sparse kernels to pay off.
- **Dynamic sparse training, RigL**: training a sparse network that periodically drops small weights and regrows
  connections where gradients are large. **RigL** ("rigging the lottery") is a well-known method from Google.
- **Cerebras-style hardware**: Cerebras' wafer-scale processors, which can skip unstructured zeros in hardware.
- **Conditional compute**: each input activates only part of the model.
- **Expert parallelism, all-to-all**: experts are spread over GPUs, and each layer sends every token to the GPUs
  holding its chosen experts, then back, which is all-to-all communication (Section 31).
- **NVLink, InfiniBand**: the fast GPU-to-GPU link inside a server and the network between servers (Section 13).
- **Aux loss, capacity factor**: an **auxiliary loss** that penalizes uneven expert use, and a **capacity factor**
  that caps tokens per expert (for example 1.25× the average), dropping or rerouting overflow.
- **Offload**: keeping some expert weights in CPU memory and fetching them when needed.

**Core ideas.**
- **2:4 sparse training** (for example PyTorch's `torchao.sparsity.training`) applies 2:4 sparsity to linear layers
  during training, with reported speedups around 1.1–1.3× on large MLP layers. It pays off only for big matrices on
  Ampere or newer GPUs.
- **Unstructured sparse training** gives good accuracy per parameter, but little speedup on GPUs. It's mainly useful
  for producing compressible models or on specialized hardware.
- **MoE is the sparse training that works at scale.** Mixtral, DeepSeek-V3 (671B total, 37B active per token), and
  many frontier models use it. Compute per token is low, but:
  - all-to-all traffic per layer can dominate step time without fast networks and overlap,
  - unbalanced routing leaves some GPUs idle while others overflow,
  - memory must hold every expert, so total parameters drive GPU count.
- **Hardware impact cuts both ways.** MoE favors large high-bandwidth domains (NVL72 racks, Section 31) and big
  memory. Dense models favor raw FLOPs. Hardware choice and model architecture should be decided together.

```python
from torchao.sparsity.training import SemiSparseLinear, swap_linear_with_semi_sparse_linear

sparse_config = {name: SemiSparseLinear for name, m in model.named_modules()
                 if isinstance(m, torch.nn.Linear) and m.in_features >= 4096 and "mlp" in name}
swap_linear_with_semi_sparse_linear(model, sparse_config)
```

In the code, only large MLP linear layers (4,096 or more input features) are swapped for 2:4 sparse versions, because
small matrices and attention projections gain little or lose accuracy. `SemiSparseLinear` prunes weights to 2:4 at
each step and runs the sparse kernels on supported GPUs.

**Example: the MoE that ran slower than dense.** A team trained a 64-expert MoE on 8-GPU nodes connected by
100 Gb/s Ethernet. All-to-all took 55% of step time, and routing sent 3× the average load to the busiest experts.
Moving to InfiniBand nodes, overlapping all-to-all with computation, raising the auxiliary load-balancing loss, and
setting a capacity factor of 1.25 cut step time by 2.4×. Only then did the MoE beat the dense model on cost to reach
the same quality.

**Senior / FAANG best practice.** Use 2:4 sparse training only on large layers on Ampere or newer, and measure the
end-to-end gain. Treat unstructured sparse training as a compression tool unless your hardware exploits it. For MoE,
plan fast interconnect, overlap of all-to-all, load balancing, and memory for all experts, and choose hardware and
architecture together.

---

## Lecture 250 — Compiler optimizations (XLA, TorchDynamo)

**Why it matters.** Eager PyTorch runs one operation at a time, launching a GPU kernel for each and reading and
writing memory between them. A compiler sees the whole graph, fuses operations, and removes overhead, often giving
1.3–2× speedups for one line of code. On TPUs, a compiler (XLA) is mandatory.

**In plain words.** Eager mode is like a cook who fetches one ingredient from the fridge, uses it, puts it back, and
fetches the next. A compiler reads the whole recipe first, gathers everything at once, and combines steps that can be
done together.

**Architecture: PyTorch 2 and XLA compilation.**

```mermaid
flowchart TB
  PY["Python model code"] --> DYN["TorchDynamo<br/>captures FX graph from bytecode"]
  DYN -->|"unsupported Python"| GB["Graph break<br/>falls back to eager"]
  DYN --> AOT["AOTAutograd<br/>forward + backward graphs"]
  AOT --> IND["TorchInductor<br/>fusion, Triton kernels, CUDA graphs"]
  IND --> GPU["GPU"]
  JAXC["JAX jit or torch_xla"] --> HLO["XLA HLO graph"]
  HLO --> XLAC["XLA compiler<br/>fusion, layout, sharding"]
  XLAC --> TPU["TPU or GPU"]
```

**How to read it:** in PyTorch 2, TorchDynamo reads the Python bytecode and captures the tensor operations as a graph.
Anything it can't capture causes a graph break and runs eagerly. AOTAutograd builds the forward and backward graphs,
and TorchInductor generates fused kernels (written in Triton) and can wrap them in CUDA graphs. On the XLA path, JAX
or `torch_xla` produce an HLO graph that the XLA compiler optimizes for TPUs or GPUs, including how tensors are
sharded across devices.

**Terms in this diagram.**
- **TorchDynamo, FX graph, bytecode**: Dynamo hooks into Python's execution of the function's **bytecode** (Python's
  compiled instructions) and records tensor operations into an **FX graph**, PyTorch's graph representation.
- **Graph break**: a point where Dynamo can't trace, such as printing a tensor value, calling an unsupported library,
  or data-dependent Python control flow. The graph is split there, losing optimization across the break.
- **AOTAutograd**: "ahead-of-time autograd", which traces the backward pass too, so the compiler can optimize
  training, not just inference.
- **TorchInductor, Triton kernels**: PyTorch's default compiler backend. It generates GPU kernels in **Triton**, a
  Python-like language for writing GPU kernels.
- **Fusion**: combining several operations (such as add, multiply, and an activation) into one kernel, so
  intermediate results stay in fast on-chip memory instead of going back to HBM.
- **CUDA graphs**: recording a sequence of GPU kernel launches once and replaying it with one call, which removes
  per-kernel CPU launch overhead.
- **JAX jit, torch_xla**: JAX's just-in-time compilation, and PyTorch's bridge to XLA.
- **XLA HLO**: XLA (Accelerated Linear Algebra) is Google's compiler, and **HLO** (High-Level Operations) is its
  graph format.
- **Layout, sharding**: the compiler chooses the memory arrangement of tensors, and with GSPMD, how they're split
  across devices.

**Core ideas.**
- **`torch.compile` modes.**
  - `default`: fusion with moderate compile time.
  - `reduce-overhead`: adds CUDA graphs, best for small batches and inference where launch overhead dominates.
  - `max-autotune`: benchmarks kernel options, with the longest compile and often the fastest run.
- **Graph breaks and recompiles are the main problems.** Find breaks with `TORCH_LOGS="graph_breaks"` or
  `torch._dynamo.explain(model)(x)`. Recompiles come from changing shapes or Python values. Mark dynamic dimensions,
  or pad to a few fixed sizes (bucketing).
- **Compile time is real.** Large models can take minutes to compile. Use caching (Inductor's cache across runs), and
  compile per block (`torch.compile` on each transformer layer) to cut compile time with repeated blocks.
- **XLA traits.** Static shapes are strongly preferred, since every new shape recompiles. Sharding annotations
  (GSPMD, `jax.sharding`) let the compiler handle parallelism, and that's how most TPU training is done.
- **Other compilers.** TensorRT and TensorRT-LLM for NVIDIA inference, OpenVINO for Intel, and Apple's Core ML for
  devices (Sections 22 and 23).

```python
import torch

model = build_model().cuda()
for i, block in enumerate(model.blocks):
    model.blocks[i] = torch.compile(block, mode="max-autotune", dynamic=False)   # compile repeated blocks once

explanation = torch._dynamo.explain(model)(torch.randn(8, 1024, device="cuda"))
print(explanation.graph_break_count, explanation.break_reasons[:3])
```

```bash
TORCH_LOGS="graph_breaks,recompiles" python3 train.py 2>&1 | head -50
```

In the code, compiling each transformer block separately means the compiled code is reused for every identical block,
and compile time doesn't grow with depth. `dynamic=False` tells the compiler to specialize on exact shapes.
`torch._dynamo.explain` traces the model and reports how many graph breaks occurred and why. The `TORCH_LOGS` setting
prints each graph break and recompilation with the source line responsible.

```python
import jax, jax.numpy as jnp

@jax.jit
def step(params, x, y):
    def loss_fn(p):
        return jnp.mean((x @ p["w"] + p["b"] - y) ** 2)
    loss, grads = jax.value_and_grad(loss_fn)(params)
    return jax.tree.map(lambda p, g: p - 1e-3 * g, params, grads), loss
```

In the JAX code, `@jax.jit` traces the function once for the given input shapes and compiles the whole step (forward,
backward, and update) with XLA. `jax.tree.map` applies the update to every parameter in the dictionary.

**Example: 1.7× from one line, after fixing two breaks.** A team added `torch.compile` to a 1.3B model and saw only a
1.1× speedup. `TORCH_LOGS` showed two graph breaks per layer: a `print` of a tensor's shape for debugging, and a call
to a NumPy function inside the attention code. Removing the print and replacing the NumPy call with the PyTorch
equivalent gave a single graph per block, and training ran 1.7× faster than eager.

**Senior / FAANG best practice.** Compile by default for training and inference, compile repeated blocks to keep
compile times short, and enable compile caches. Check for graph breaks and recompiles in CI with `TORCH_LOGS` or
`explain`. Keep shapes static or bucketed, especially on XLA, and use vendor compilers (TensorRT, OpenVINO) for
deployment.

---

## Lecture 251 — Infra trade-offs: accuracy vs efficiency

**Why it matters.** Every optimization in Sections 35 and 36 trades some quality for speed or cost. Without a clear
way to compare them, teams either refuse all trade-offs (overspending) or accept them blindly (shipping worse models).
A Pareto frontier and a cost-per-quality metric turn the debate into a decision.

**In plain words.** Buying a car: you plot price against fuel economy, ignore any car that's both pricier and worse
than another, and choose among the rest based on your budget and how much each extra mile per gallon is worth to you.

**Architecture: choosing on the frontier.**

```mermaid
flowchart LR
  OPTS["Candidate configs<br/>BF16, FP8, INT4, distilled, pruned"] --> MEAS["Measure each<br/>quality, p99, cost per 1K requests"]
  MEAS --> SLOF{"Meets latency SLO<br/>and quality floor?"}
  SLOF -->|"no"| DROP["Discard"]
  SLOF -->|"yes"| PF["Pareto frontier<br/>no option better on both"]
  PF --> VAL["Value of quality<br/>revenue or risk per point"]
  VAL --> CHOICE["Pick the config with<br/>best net value"]
```

**How to read it:** every candidate configuration is measured on quality, tail latency, and cost per 1,000 requests.
Those that miss the latency target or the quality floor are discarded. Of the rest, only options on the Pareto
frontier are worth considering. Putting a value on each quality point, in revenue or risk, picks the one with the best
net value.

**Terms in this diagram.**
- **Candidate configs**: different combinations of format, model size, and serving settings.
- **Cost per 1K requests**: the total serving cost (GPU-hours and other resources) divided by thousands of requests
  served at the target latency.
- **Quality floor**: the lowest quality you'll accept, such as no more than 1 point below BF16 on the product
  evaluation.
- **Value of quality, revenue or risk per point**: how much one point of quality is worth, for example extra
  conversions in recommendations or fewer losses in fraud detection.
- **Net value**: the value of the quality delivered minus the cost.

**Core ideas.**
- **Hard constraints first.** Latency SLOs, memory limits, and quality floors aren't trade-offs: they remove options.
- **Then the frontier.** An option that's both more expensive and worse than another (dominated) is never right.
- **Put a price on quality.**
  - In ads or recommendations, offline-to-online studies give revenue per point of AUC or NDCG.
  - In fraud, a point of recall is worth expected prevented losses.
  - In regulated areas, some quality drops are unacceptable at any savings.
- **Quality isn't one number.** Check slices, safety evaluations, and long-tail behavior. A config that wins on average
  and loses on a critical slice is off the table.
- **Revisit regularly.** New hardware (FP4 on Blackwell), new methods, and changing traffic move the frontier.

```python
def pareto(configs):
    """configs: list of (name, quality, cost). Returns the non-dominated ones, cheapest first."""
    front = [c for c in configs
             if not any(o[1] >= c[1] and o[2] <= c[2] and (o[1] > c[1] or o[2] < c[2]) for o in configs)]
    return sorted(front, key=lambda c: c[2])

cands = [("bf16-70b", 84.0, 10.0), ("fp8-70b", 83.8, 5.4), ("int4-70b", 82.1, 4.9),
         ("distilled-8b", 80.5, 1.1), ("int4-8b", 78.0, 0.9), ("bf16-8b-base", 79.0, 2.0)]
for name, q, c in pareto(cands):
    print(f"{name:14} quality {q:5.1f}  cost ${c:5.2f} per 1K")
# bf16-8b-base is dominated by distilled-8b (better and cheaper), so it's dropped
```

In the code, an option is dominated if some other option is at least as good on quality and at least as cheap, and
strictly better on one of them. The frontier is printed cheapest first. Choosing between frontier options needs the
value of a point: `fp8-70b` gives up 0.2 points to save $4.60 per 1,000 requests, so it wins whenever a quality point
is worth less than $23 per 1,000 requests (4.60 ÷ 0.2). Moving from `distilled-8b` to `fp8-70b` costs $4.30 for 3.3
points, which pays off only above about $1.30 per point.

**Example: pricing a point of AUC.** An ads team had a 3× cheaper distilled ranker at 0.4 points lower AUC. An A/B
test showed each AUC point was worth 0.9% of revenue, so 0.4 points was about $3.6 million a year, against $1.1
million of savings. They kept the large model for the main feed and used the distilled one for a low-value surface,
where the trade was positive.

**Senior / FAANG best practice.** Apply SLOs and quality floors as hard constraints, then compare only Pareto-optimal
options. Put a measured value on quality points, decide on net value, and check slices and safety before accepting
any trade. Re-run the analysis when hardware, methods, or traffic change.

---

## Lecture 252 — Lab: train with mixed precision

**Goal:** train ResNet-18 on CIFAR-10 four ways (FP32, FP16 AMP with `GradScaler`, BF16 AMP, and BF16 AMP with
`torch.compile` and channels-last) and compare throughput, peak GPU memory, and final accuracy.

**What you're building:** one training script with a `--mode` flag, run four times, printing images per second, peak
memory, and test accuracy, plus a small results table.

```mermaid
flowchart LR
  DATA["CIFAR-10<br/>50K train, 10K test"] --> RUN{"--mode"}
  RUN --> F32["fp32<br/>TF32 off"]
  RUN --> F16["fp16<br/>autocast + GradScaler"]
  RUN --> B16["bf16<br/>autocast"]
  RUN --> B16C["bf16-compile<br/>+ torch.compile, channels_last"]
  F32 & F16 & B16 & B16C --> OUT["images per second,<br/>peak memory, accuracy"]
```

**How to read the diagram:** the same data and model are trained in four modes. FP32 has TF32 turned off, to show the
true FP32 baseline. FP16 uses autocast with gradient scaling, BF16 uses autocast alone, and the last mode adds
`torch.compile` and channels-last memory layout. Each run reports throughput, peak memory, and accuracy. **CIFAR-10**
is a dataset of 60,000 small (32 × 32) color images in 10 classes. **Channels-last** stores image tensors with the
channel dimension last (NHWC), which tensor-core convolution kernels prefer.

**Prerequisites:** an NVIDIA GPU (BF16 modes need an Ampere-or-newer GPU such as A10, A100, L4, or H100. On a T4 or in
free Colab, run only `fp32` and `fp16`), Python 3.10+, and `pip install torch torchvision`.

### Step 1 — Training script

```python
# amp_train.py
import argparse, time
import torch, torchvision
import torchvision.transforms as T
from torch import nn

p = argparse.ArgumentParser()
p.add_argument("--mode", choices=["fp32", "fp16", "bf16", "bf16-compile"], required=True)
p.add_argument("--epochs", type=int, default=5)
p.add_argument("--batch", type=int, default=256)
a = p.parse_args()

torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
torch.manual_seed(0)
dev = "cuda"
norm = T.Normalize((0.4914, 0.4822, 0.4465), (0.247, 0.243, 0.261))
train_ds = torchvision.datasets.CIFAR10("data", train=True, download=True,
                                        transform=T.Compose([T.RandomCrop(32, padding=4), T.RandomHorizontalFlip(),
                                                             T.ToTensor(), norm]))
test_ds = torchvision.datasets.CIFAR10("data", train=False, download=True, transform=T.Compose([T.ToTensor(), norm]))
train = torch.utils.data.DataLoader(train_ds, batch_size=a.batch, shuffle=True, num_workers=8, pin_memory=True,
                                    drop_last=True, persistent_workers=True)
test = torch.utils.data.DataLoader(test_ds, batch_size=1024, num_workers=4)

model = torchvision.models.resnet18(num_classes=10)
model.conv1 = nn.Conv2d(3, 64, 3, 1, 1, bias=False); model.maxpool = nn.Identity()   # CIFAR-sized stem
model = model.to(dev)
fmt = torch.channels_last if a.mode == "bf16-compile" else torch.contiguous_format
model = model.to(memory_format=fmt)
if a.mode == "bf16-compile":
    model = torch.compile(model)

dtype = {"fp16": torch.float16, "bf16": torch.bfloat16, "bf16-compile": torch.bfloat16}.get(a.mode)
scaler = torch.amp.GradScaler("cuda", enabled=a.mode == "fp16")
opt = torch.optim.SGD(model.parameters(), lr=0.1, momentum=0.9, weight_decay=5e-4, nesterov=True)
sched = torch.optim.lr_scheduler.OneCycleLR(opt, 0.1, total_steps=a.epochs * len(train))
loss_fn = nn.CrossEntropyLoss()

def batches(loader):
    for x, y in loader:
        yield x.to(dev, non_blocking=True).to(memory_format=fmt), y.to(dev, non_blocking=True)

torch.cuda.reset_peak_memory_stats()
imgs, t_train = 0, 0.0
for ep in range(a.epochs):
    model.train(); torch.cuda.synchronize(); t0 = time.perf_counter()
    for x, y in batches(train):
        with torch.autocast("cuda", dtype=dtype, enabled=dtype is not None):
            loss = loss_fn(model(x), y)
        scaler.scale(loss).backward(); scaler.step(opt); scaler.update()
        opt.zero_grad(set_to_none=True); sched.step()
    torch.cuda.synchronize(); dt = time.perf_counter() - t0
    if ep > 0:                                   # epoch 0 includes warm-up and compilation
        imgs += len(train) * a.batch; t_train += dt
    print(f"epoch {ep}: {dt:.1f} s, loss {loss.item():.3f}")

model.eval(); correct = 0
with torch.no_grad(), torch.autocast("cuda", dtype=dtype, enabled=dtype is not None):
    for x, y in batches(test):
        correct += (model(x).argmax(1) == y).sum().item()
print(f"RESULT mode={a.mode} img/s={imgs / t_train:,.0f} peak_mem={torch.cuda.max_memory_allocated() / 2**30:.2f} GiB "
      f"acc={correct / len(test_ds):.4f}")
```

In the code, TF32 is turned off so that `fp32` is a true FP32 baseline. The ResNet-18 stem is replaced by a 3 × 3
convolution without max pooling, the usual change for 32 × 32 images. `OneCycleLR` ramps the learning rate up then
down, which reaches good accuracy in few epochs. Throughput skips epoch 0, which includes cuDNN autotuning and
compilation. `torch.cuda.synchronize()` makes the timer wait for the GPU to finish. `max_memory_allocated` reports the
peak GPU memory held by tensors.

### Step 2 — Run all modes

```bash
for m in fp32 fp16 bf16 bf16-compile; do python3 amp_train.py --mode $m --epochs 5 | tee log_$m.txt; done
grep RESULT log_*.txt
```

### Step 3 — Experiments

- Re-run `fp32` with TF32 enabled (delete the two `allow_tf32 = False` lines) and see how much of the AMP gain TF32
  alone provides on Ampere and newer.
- In `fp16` mode, print `scaler.get_scale()` every 100 steps and note when it drops (an overflow was detected and the
  step skipped).
- Double `--batch` to 512 in `bf16` mode, which fits in less memory than FP32 at 256.
- Run `bf16-compile` with `TORCH_LOGS=graph_breaks` and confirm there are no graph breaks.

**Expected results:**
- Throughput: on an A100 or H100, `fp16` and `bf16` are about 2–3× faster than true FP32, and `bf16-compile` adds
  another 10–30%. On a T4, `fp16` is about 2–3× faster than `fp32`. On an L4 or A10, gains are similar to the A100's.
- Peak memory: AMP modes use roughly 35–50% less than `fp32`, mostly from smaller activations.
- Accuracy after 5 epochs: about 0.88–0.91 in every mode, within about half a point of each other. Mixed precision
  doesn't cost accuracy.
- With TF32 enabled, `fp32` closes part of the gap but stays slower than BF16 AMP.
- The FP16 loss scale may drop a few times early in training, and then stays stable.

---

## FAANG deep-dive notes

**How big tech does it.** Frontier training runs use BF16 with FP32 master weights by default, and increasingly FP8
for linear layers. DeepSeek-V3 was trained largely in FP8 with fine-grained (block-wise) scaling, and NVIDIA's
Transformer Engine is standard on Hopper and Blackwell. Google's models train through XLA on TPUs with compiler-managed
sharding. PyTorch shops use `torch.compile` on repeated blocks. For deployment, QAT produces low-bit on-device models
(Meta's quantized Llama 3.2, Google's Gemma 3 QAT), and distillation from frontier teachers produces the small fast
models behind most high-traffic features. MoE has become the dominant sparse architecture, with large investment in
all-to-all networking and load balancing.

**Staff review questions.**
- Which precision is each part of training using, and how was FP8 validated against BF16?
- What does the profiler show: are we compute-bound, memory-bound, or overhead-bound?
- How many graph breaks and recompiles happen per step, and is compile time cached?
- Why QAT instead of PTQ here, and does training match the deployment scheme exactly?
- For distillation: what's the teacher's GPU budget, the logit storage size, and the license position?
- Which options are on the Pareto frontier, and what's a quality point worth?

**Interview question.** "Cut training cost for a 7B model by 3× without hurting quality."

**Typical system-design prompt:** *A 7B model takes 21 days on 256 A100s in FP32 with TF32. Cut cost 3× without
losing quality, then produce a 1B on-device version within 1 point of the 7B on the product evaluation.*

**1. Clarify first:** What GPUs can we use (A100 only, or H100)? Current MFU? Token budget? On-device memory and
latency limits? Is the 1B allowed to be distilled from the 7B (license, data)?

**2. Back-of-envelope sizing:**
- BF16 AMP over TF32: ~1.3–1.6× on A100 transformer training (TF32 is already tensor-core math).
- `torch.compile` per block and fused optimizers: ~1.2–1.4×.
- Moving to H100 with FP8: ~3× per GPU over A100 BF16 for large matrices, at ~2× the hourly price, so ~1.5× cost.
- Combined on H100: roughly 1.4 × 1.3 × 1.5 ≈ 2.7–3.2× cheaper.
- 1B distillation: generate ~5 billion teacher tokens at ~2,500 tokens per second per A100 for a 7B in vLLM, about 560
  GPU-hours, plus top-20 logits at 120 bytes per token = 600 GB.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Training precision | BF16 | FP8 | FP8 for large linears on H100 or newer, after loss-curve parity |
| Compilation | Eager | `torch.compile` per block | Compile, with graph-break checks in CI |
| Low-bit deployment | PTQ | QAT | PTQ first. QAT when the drop exceeds the budget |
| Distillation | Offline traces | On-policy with online teacher | Offline first, on-policy to close the last gap |
| Sparsity | 2:4 training | Dense + MoE | MoE for scale with good networking. 2:4 only on large MLPs |

**4. Follow-up questions with crisp answers:**
- *FP8 loss diverges at step 30,000. What do you do?* Compare with a BF16 rerun from the last checkpoint, keep
  sensitive layers (embeddings, output, attention softmax) in BF16, use finer-grained scaling, and lower the learning
  rate if spikes persist.
- *Why not FP16 on A100?* BF16 has FP32's range, so no loss scaling and fewer overflow failures, at the same speed.
- *Compile gives no speedup. Why?* Likely graph breaks, recompiles from changing shapes, or a data-loading bottleneck.
  Check `TORCH_LOGS` and the profiler.
- *The 1B is 2 points short after distillation. Next?* Add on-policy distillation on the student's failure cases, then
  QAT at the deployment bit width.

**Debug this (common onsite question):** "After switching to FP16 AMP, loss becomes NaN at random steps."
1. Check whether `GradScaler` is used: it is, but `clip_grad_norm_` is called before `unscale_`, so clipping acts on
   scaled gradients.
2. A custom attention layer computes softmax in FP16, and large logits overflow.
3. Fix: call `scaler.unscale_(opt)` before clipping, compute that softmax in FP32 (or use the built-in
   `scaled_dot_product_attention`), and on Ampere or newer switch to BF16.

The lesson: mixed precision needs the right order of scaler calls and FP32 for sensitive operations. BF16 removes most
of these problems.

**5. What separates senior from staff answers:** a senior engineer turns on AMP and `torch.compile`. A staff engineer
profiles to find the real bottleneck, stacks precision, compilation, and hardware choices with numbers, validates FP8
against BF16, plans distillation compute and storage, uses QAT only where PTQ falls short, and decides on a Pareto
frontier with a price on quality.

**Red flags:**
- Training in plain FP32 on tensor-core GPUs.
- FP16 without `GradScaler`, or clipping before unscaling.
- Adopting FP8 without comparing loss curves against BF16.
- `torch.compile` with unchecked graph breaks or constant recompiles.
- QAT with a different scheme from the deployment kernel.
- Distillation planned without counting teacher compute, logit storage, or license terms.
- Expecting dynamic unstructured sparse training to speed up GPUs.

---

## Quiz

<details><summary>1. Why does FP16 training need loss scaling but BF16 doesn't?</summary>
FP16 has a small range, so small gradients round to zero (underflow). Scaling the loss lifts them into range. BF16 has
FP32's exponent range, so gradients don't underflow.
</details>

<details><summary>2. Why are master weights kept in FP32 in mixed precision training?</summary>
Updates are often much smaller than the weights. In 16-bit formats, adding a tiny update to a large weight can round
to no change, so training stalls. FP32 keeps those small updates.
</details>

<details><summary>3. What is the straight-through estimator in QAT?</summary>
Rounding has a zero gradient almost everywhere, so QAT treats its gradient as 1 in backward, passing gradients
through the fake-quantization step so the weights can learn to tolerate quantization.
</details>

<details><summary>4. How much storage do top-20 teacher logits take for 10 billion tokens?</summary>
20 entries × (4-byte index + 2-byte value) = 120 bytes per token, so 1.2 TB, compared with about 2.6 PB for the full
128K-entry vocabulary in 16-bit.
</details>

<details><summary>5. Why does on-policy distillation help beyond training on teacher outputs?</summary>
The student learns from its own generated sequences, so it's corrected on the mistakes it actually makes, removing the
mismatch between training on teacher text and generating its own at inference time.
</details>

<details><summary>6. What are the main infrastructure costs of mixture-of-experts training?</summary>
All-to-all communication between GPUs every MoE layer, uneven expert load that leaves GPUs idle or overflowing, and
memory for every expert even though each token uses few.
</details>

<details><summary>7. What is a graph break, and how do you find one?</summary>
A point where TorchDynamo can't capture the code into the graph (such as printing a tensor, unsupported libraries, or
data-dependent control flow), so execution falls back to eager and optimization across it is lost. Find them with
TORCH_LOGS="graph_breaks" or torch._dynamo.explain.
</details>

<details><summary>8. What makes an option "dominated" on a Pareto frontier?</summary>
Another option is at least as good on quality and at least as cheap, and strictly better on at least one, so the
dominated option is never the right choice.
</details>

## Failure modes
- Training in FP32 on tensor-core GPUs, or forgetting TF32.
- FP16 without loss scaling, or gradient clipping before unscaling.
- Numerically sensitive operations forced into low precision by custom code.
- FP8 enabled without loss-curve comparison, then diverging late in training.
- QAT that doesn't match the deployment kernel, so gains vanish on conversion.
- Distillation runs blocked by teacher GPU shortages or unplanned logit storage.
- MoE training dominated by all-to-all and unbalanced experts.
- `torch.compile` with graph breaks or recompiles that remove the benefit.
- Choosing a dominated configuration because quality was never priced.

## Checklist
- [ ] You can write an AMP training loop that works in both FP16 and BF16
- [ ] You know when to use FP8 training and how to validate it
- [ ] You can run QAT with the deployment scheme and evaluate the converted model
- [ ] You can plan teacher generation compute and top-k logit storage for distillation
- [ ] You know which sparse training methods speed up which hardware, and the costs of MoE
- [ ] You can compile models per block and find graph breaks and recompiles
- [ ] You can build a Pareto frontier and choose by net value
- [ ] You trained ResNet-18 in four precision modes and compared speed, memory, and accuracy
