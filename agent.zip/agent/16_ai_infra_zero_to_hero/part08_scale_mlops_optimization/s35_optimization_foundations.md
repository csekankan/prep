# Section 35 — AI Infrastructure Optimization Foundations

> Lectures 239–245 • Assessments: quiz, [Calculate quantized model memory savings](#assessment--calculate-quantized-model-memory-savings)
> • Exercise: [`s35_quant_memory.py`](../exercises/s35_quant_memory.py)
> **After this section you can:** explain how model optimization turns into fewer GPUs and lower cost per request,
> pick a quantization format (FP8, INT8, INT4, FP4) for weights and the KV cache, prune and distill models, tell
> when sparsity actually speeds up hardware, benchmark an optimized model honestly, and quantize a vision model to
> INT8 with calibration.
>
> Builds on: [Section 22](../part06_edge_mobile/s22_edge_optimization.md) (quantization and pruning for edge
> devices), [Section 7](../part02_data_gpus_training/s07_gpu_hardware.md) (GPU memory and compute), and
> [Section 15](../part04_networking_serving/s15_advanced_serving.md) (LLM serving and the KV cache).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 239 | What is model optimization for infra efficiency? | Fewer bytes and fewer operations per request mean fewer GPUs, more users per GPU, and lower latency |
| 240 | Quantization basics | Store and compute in fewer bits. Weight-only INT4 cuts memory, FP8 and INT8 W8A8 also speed up compute |
| 241 | Pruning basics | Remove weights, channels, heads, or layers. Only structured pruning speeds up dense hardware |
| 242 | Distillation basics | Train a small student to imitate a big teacher, keeping most of the quality at a fraction of the cost |
| 243 | Structured vs unstructured sparsity | 2:4 patterns and removed channels run faster on GPUs. Scattered zeros mostly only compress |
| 244 | Benchmarking optimized models | Measure quality on real tasks, p99 latency at real load, throughput, memory, and cost per request |
| 245 | Lab: quantize a vision model | ResNet-50 to INT8 with ONNX Runtime calibration: 4× smaller, compared on accuracy and latency |

```mermaid
flowchart LR
  BIG["Trained model<br/>BF16, full size"] --> Q["Quantize<br/>fewer bits"]
  BIG --> P["Prune<br/>fewer weights"]
  BIG --> D["Distill<br/>smaller student"]
  Q & P & D --> OPT["Optimized model"]
  OPT --> BENCH{"Benchmark<br/>quality, p99, throughput, memory"}
  BENCH -->|"passes"| INFRA["Fewer GPUs<br/>more users per GPU,<br/>lower cost per request"]
  BENCH -->|"quality drop too large"| BIG
```

**How to read it:** a trained full-precision model can be quantized, pruned, distilled, or a combination. The
optimized model is benchmarked on quality, tail latency, throughput, and memory. If it passes, the infrastructure
benefit appears as fewer GPUs, more users per GPU, and a lower cost per request. If the quality loss is too large, you
go back and choose a gentler method.

**Terms in this diagram.**
- **BF16**: the 16-bit "brain floating point" format, the usual precision for training and serving large models.
- **Quantize**: store numbers with fewer bits, such as 8 or 4 instead of 16 (Lecture 240).
- **Prune**: remove weights or whole parts of the network (Lecture 241).
- **Distill**: train a smaller "student" model to copy a larger "teacher" (Lecture 242).
- **p99**: the 99th-percentile latency: 99% of requests finish faster than this. It's the latency users notice
  (Section 16).
- **Throughput**: how many requests or tokens per second a system serves.

---

## Lecture 239 — What is model optimization for infra efficiency?

**Why it matters.** Serving cost is roughly GPUs × hours, and for large models most of the bill is inference, not
training. Making a model half the size can halve the GPUs needed, or double the users per GPU. Optimization is usually
the biggest cost lever an infrastructure team has, bigger than any discount negotiation.

**In plain words.** It's like packing for a trip. A smaller suitcase (fewer bytes) fits in the overhead bin, so you
don't pay for checked luggage. Bringing fewer items (fewer operations) makes packing and unpacking faster. You keep
what you actually need for the trip.

**Architecture: where optimization pays off on a GPU.**

```mermaid
flowchart TB
  REQ["Request"] --> PRE["Prefill<br/>whole prompt at once"]
  PRE --> DEC["Decode<br/>one token at a time"]
  PRE -->|"compute-bound"| TC["Tensor cores<br/>FP8, INT8, 2:4 sparsity help"]
  DEC -->|"memory-bandwidth-bound"| HBM["HBM reads<br/>all weights + KV cache per step"]
  HBM --> FEWER["Fewer bytes per weight<br/>INT4, FP8 weights, FP8 KV"]
  MEM["GPU memory capacity"] --> FIT["Weights + KV cache<br/>must fit"]
  FIT --> FEWER
  FEWER --> WIN["Bigger batches,<br/>fewer GPUs per replica"]
```

**How to read it:** a language model request has two phases. Prefill processes the whole prompt in parallel and is
limited by compute, so faster math formats help. Decode produces one token at a time and must read all the weights
and the KV cache from GPU memory for every token, so it's limited by memory bandwidth, and fewer bytes per weight
help directly. GPU memory capacity must hold the weights and the KV cache. Using fewer bytes leaves room for bigger
batches and can reduce the number of GPUs each model copy needs.

**Terms in this diagram.**
- **Prefill, decode**: the two phases of LLM generation. **Prefill** handles the prompt. **Decode** generates
  output tokens one at a time (Section 15).
- **Compute-bound, memory-bandwidth-bound**: limited by arithmetic speed, or by how fast data can be read from memory.
- **Tensor cores**: GPU units specialized for matrix math. They run faster at lower precision: an H100's FP8 rate is
  about twice its BF16 rate (Section 7).
- **2:4 sparsity**: a pattern where 2 of every 4 weights are zero, which newer tensor cores can skip (Lecture 243).
- **HBM**: high-bandwidth memory, the GPU's main memory, such as 80 GB at about 3.35 TB/s on an H100 SXM.
- **KV cache**: the stored attention keys and values for every token in each active sequence, which grows with
  context length and batch size (Section 15).
- **FP8 KV**: storing the KV cache in 8-bit floating point, which halves its size.
- **Replica**: one complete copy of the model serving traffic, possibly spread over several GPUs.

**Core ideas.**
- **Three things to optimize.**
  - **Bytes**: weights, KV cache, and activations. These decide whether the model fits and how fast decode runs.
  - **Operations**: the floating-point operations per token. These decide prefill and training speed.
  - **Utilization**: how much of the hardware is kept busy, through batching, kernels, and compilers (Section 36).
- **Model-level vs system-level.** Quantization, pruning, and distillation change the model. Batching, KV cache
  paging, and speculative decoding change the serving system (Sections 14 and 15). The largest savings come from
  combining both.
- **Quality is the constraint.** Every method trades some quality for efficiency. Agree on the acceptable loss per
  task (for example, at most 1 point on the product's evaluation set) before optimizing.
- **Decide by cost per useful output.** Compare options on cost per 1,000 requests at the latency target, not on
  model size alone.

**Example: half the GPUs for a chat assistant.** A company served a 70B model in BF16 on 4 H100s per replica, with
12 replicas. Switching to FP8 weights and an FP8 KV cache, validated at a 0.4-point drop on their evaluation, let
each replica run on 2 H100s with the same batch size and p99 latency. The fleet went from 48 to 24 GPUs, saving about
$500,000 a year at $2.50 per GPU-hour.

**Senior / FAANG best practice.** Profile first: know whether the workload is limited by memory capacity, memory
bandwidth, or compute, and pick the optimization that addresses it. Agree on a quality budget per task before
starting. Combine model-level and system-level optimizations, and judge every change by cost per request at the
latency target.

---

## Lecture 240 — Quantization basics

**Why it matters.** Quantization is the most widely used optimization in production. It can cut weight memory by
2–4×, speed up decode by about as much, and on recent GPUs speed up the math itself. Choosing the wrong format, or
skipping calibration, can also quietly damage quality.

**In plain words.** Quantization is like rounding prices to the nearest 10 cents. You lose a tiny bit of precision,
and in exchange every number takes less space to write down. Per-group scales are like each aisle of a shop having its
own rounding rule, so cheap items aren't rounded to zero.

**Architecture: quantization choices.**

```mermaid
flowchart TB
  M["BF16 model"] --> WHEN{"When?"}
  WHEN -->|"after training"| PTQ["PTQ<br/>post-training quantization"]
  WHEN -->|"during training"| QAT["QAT<br/>quantization-aware training, Section 36"]
  PTQ --> WHAT{"What is quantized?"}
  WHAT --> WO["Weight-only<br/>INT4 GPTQ, AWQ<br/>dequantize to BF16 for math"]
  WHAT --> WA["Weights + activations<br/>FP8, INT8 W8A8 SmoothQuant<br/>math in low precision"]
  WHAT --> KVQ["KV cache<br/>FP8 or INT8"]
  CAL["Calibration set<br/>128 to 512 real samples"] --> PTQ
  WO --> GRAN["Scale granularity<br/>per-tensor, per-channel, per-group"]
  WA --> GRAN
```

**How to read it:** you can quantize after training (the common case) or during training. After training, you choose
what to quantize: only the weights (good for memory-bound decode), the weights and activations (which also speeds up
math), and optionally the KV cache. A small calibration set of real inputs helps choose good scales. Every method
also chooses how many numbers share one scale: a whole tensor, each output channel, or small groups.

**Terms in this diagram.**
- **PTQ (post-training quantization)**: converting a trained model to lower precision without retraining, using a
  small calibration set.
- **QAT (quantization-aware training)**: training with simulated quantization so the model learns to tolerate it
  (Section 36).
- **Weight-only, INT4, GPTQ, AWQ**: only weights are stored in low precision. **INT4** uses 4-bit integers. **GPTQ**
  rounds weights one column at a time while correcting the error of earlier columns. **AWQ** (activation-aware weight
  quantization) protects the weights that multiply large activations by scaling them first. At run time the weights
  are dequantized (expanded back) to BF16 inside the matrix kernel.
- **Weights + activations, FP8, INT8 W8A8, SmoothQuant**: both inputs to each matrix multiply are low precision, so
  the tensor cores compute in 8 bits. **FP8** is an 8-bit float (E4M3 or E5M2 layouts) supported on H100 and newer.
  **W8A8** means 8-bit weights and 8-bit activations. **SmoothQuant** moves outlier magnitude from activations into
  weights so both quantize well.
- **Calibration set**: a few hundred representative inputs, run through the model to measure value ranges.
- **Scale granularity, per-tensor, per-channel, per-group**: a **scale** maps integers back to real values. One scale
  can cover a whole tensor, one output channel, or a group of, for example, 128 weights. Smaller groups are more
  accurate and need more scale storage.

**Core ideas.**
- **The basic math.** Symmetric quantization stores `q = round(x / s)`, with `s = max|x| / 127` for INT8, and recovers
  `x ≈ q × s`. Asymmetric quantization adds a **zero point** for ranges that aren't centered on zero (Section 22).
- **Scales cost memory.** INT4 with groups of 128 and a 16-bit scale plus a 4-bit zero per group costs
  4 + 20/128 = 4.16 bits per weight. Embeddings and the output layer usually stay BF16. So a "4-bit" 70B model takes
  about 40 GB, not 35 GB (see the assessment).
- **Choose by bottleneck and hardware.**
  - **Memory-bound decode, small batches**: weight-only INT4 (AWQ, GPTQ) gives the biggest win.
  - **High-throughput serving on H100, H200, or B200**: FP8 W8A8 is close to lossless for most LLMs and speeds up
    both phases.
  - **Blackwell GPUs**: FP4 formats (NVFP4, MXFP4) with small-block scales double throughput again, with more careful
    validation.
  - **CPUs and older GPUs**: INT8 is the reliable choice, and the lab uses it.
- **Outliers are the enemy.** A few huge activation values force a large scale and crush everything else. Per-channel
  or per-group scales, SmoothQuant, AWQ, and rotation methods (QuaRot, SpinQuant) all exist to handle them.
- **KV cache quantization** halves the KV cache with FP8, doubling how many tokens fit. It's often the cheapest win
  for long-context serving.

```bash
vllm serve meta-llama/Llama-3.1-70B-Instruct --quantization fp8 --kv-cache-dtype fp8 --tensor-parallel-size 2
vllm serve hugging-quants/Meta-Llama-3.1-70B-Instruct-AWQ-INT4 --tensor-parallel-size 1 --max-model-len 8192
```

In the commands, `--quantization fp8` makes vLLM quantize BF16 weights to FP8 on load (dynamic quantization, no
calibration file needed). `--kv-cache-dtype fp8` stores the KV cache in FP8. The second command serves a model that
was already quantized to INT4 with AWQ: vLLM reads the quantization method from the model's config. On one 80 GB
GPU, `--max-model-len 8192` keeps the per-sequence context within the remaining KV space.

**Example: INT4 that broke math.** A team moved a 70B assistant to weight-only INT4 with per-tensor scales to fit one
GPU. General chat quality looked fine, but accuracy on their arithmetic test set fell from 82% to 61%. Switching to
AWQ with groups of 128, calibrated on their own traffic, recovered accuracy to 80% at 39.8 GB of weights, so it still
fit on one GPU.

**Senior / FAANG best practice.** Pick the format by bottleneck and hardware: FP8 W8A8 on Hopper and newer, INT4
weight-only for memory-bound single-GPU serving, and FP8 KV cache for long context. Use per-channel or per-group
scales, calibrate on real traffic, keep sensitive layers in BF16, and always evaluate on task-specific sets, not just
perplexity.

---

## Lecture 241 — Pruning basics

**Why it matters.** Many trained networks have weights, attention heads, or even whole layers that contribute little.
Removing them makes the model smaller and, if done in the right shape, faster. NVIDIA's Minitron work, for example,
pruned Llama 3.1 8B to 4B and recovered most of its quality with distillation.

**In plain words.** Pruning is like trimming a tree. Snipping single leaves here and there (unstructured) makes it
lighter but not much smaller to fit through a doorway. Cutting off whole branches (structured) really changes its
size, and you have to let it regrow a little afterwards (fine-tuning).

**Architecture: what can be pruned.**

```mermaid
flowchart LR
  MODEL["Trained model"] --> SCORE["Score importance<br/>magnitude, activations, gradients"]
  SCORE --> U["Unstructured<br/>individual weights to zero"]
  SCORE --> S["Structured<br/>channels, heads, MLP neurons"]
  SCORE --> DEPTH["Depth<br/>whole layers"]
  U --> SPF["Sparse file<br/>little GPU speedup"]
  S --> DENSE["Smaller dense matrices<br/>real speedup"]
  DEPTH --> DENSE
  DENSE --> HEAL["Heal: fine-tune or distill<br/>recover quality"]
  SPF --> HEAL
```

**How to read it:** first, score how important each part is, using weight size, activation size, or gradients. Then
remove individual weights (unstructured), whole channels, heads, or neurons (structured), or entire layers (depth).
Unstructured pruning leaves the matrices the same shape with zeros inside, which dense GPU kernels barely speed up.
Structured and depth pruning produce smaller dense matrices that are genuinely faster. Either way, a short fine-tune
or distillation recovers lost quality.

**Terms in this diagram.**
- **Importance score, magnitude, activations, gradients**: ways to estimate what a weight contributes. **Magnitude**
  uses the absolute weight value. Activation-based methods such as **Wanda** multiply weight size by input activation
  size. Gradient-based methods estimate how much the loss would change.
- **Unstructured**: zeroing individual weights anywhere in a matrix.
- **Structured, channels, heads, MLP neurons**: removing whole rows or columns, such as convolution channels,
  attention heads, or neurons in a transformer's feed-forward (MLP) block.
- **Depth**: removing entire transformer layers or blocks.
- **Sparse file**: the model compresses well, but runs at the same speed on dense kernels.
- **Heal: fine-tune or distill**: train briefly after pruning, either on data or by copying the original model's
  outputs (Lecture 242).

**Core ideas.**
- **Unstructured pruning gives high sparsity with little loss** (50% or more for many models, using methods such as
  SparseGPT and Wanda for LLMs), but needs sparse kernels or special hardware to run faster. On GPUs, the useful
  middle ground is 2:4 semi-structured sparsity (Lecture 243).
- **Structured pruning gives real speed.** Removing 25% of MLP neurons makes those matrices 25% smaller for every
  kernel and every device. The cost is a larger quality drop per removed parameter, so it needs healing.
- **Depth pruning** is simplest to deploy (fewer layers means proportionally less latency) and usually hurts quality
  more than width pruning at the same size.
- **Prune iteratively.** Prune a little, heal, and repeat. Removing 50% in one shot is worse than five 10% steps.
- **Pruning plus distillation** is the modern recipe for making a family of smaller models from one large one, much
  cheaper than training each from scratch.

```python
import torch
import torch.nn.utils.prune as prune
from torchvision.models import resnet50, ResNet50_Weights

model = resnet50(weights=ResNet50_Weights.IMAGENET1K_V2).eval()
convs = [(m, "weight") for m in model.modules() if isinstance(m, torch.nn.Conv2d)]
prune.global_unstructured(convs, pruning_method=prune.L1Unstructured, amount=0.5)    # 50% of conv weights -> 0
for m, name in convs:
    prune.remove(m, name)                                                          # make zeros permanent

layer = model.layer4[0].conv2
prune.ln_structured(layer, name="weight", amount=0.25, n=2, dim=0)                 # zero 25% of output channels
zeros = sum((m.weight == 0).sum().item() for m, _ in convs) / sum(m.weight.numel() for m, _ in convs)
print(f"conv sparsity {zeros:.1%}")
```

In the code, `global_unstructured` with `L1Unstructured` zeros the 50% of weights with the smallest absolute value
across all convolution layers together, so less important layers lose more. `prune.remove` makes the zeros
permanent. `ln_structured` with `dim=0` zeros whole output channels by their L2 norm (`n=2`). PyTorch's pruning
only zeros values. To get a real speedup from structured pruning, you then rebuild the layer with fewer channels,
using a tool such as Torch-Pruning, or the NVIDIA Model Optimizer for LLMs.

**Example: depth pruning a ranking model.** A recommendation team found that 4 of their ranker's 12 transformer
layers changed hidden states very little (high similarity between their inputs and outputs). Removing them and
distilling from the original for one day cut p99 latency from 21 ms to 15 ms at a 0.1% drop in offline AUC. That let
them add a richer feature set inside the same latency budget.

**Senior / FAANG best practice.** Use unstructured pruning only when you have sparse kernels or hardware that
benefit. Otherwise, prune structurally (channels, heads, neurons, or layers), prune iteratively, and always heal with
fine-tuning or distillation. Measure latency on the target device, since a sparse file isn't a faster model.

---

## Lecture 242 — Distillation basics

**Why it matters.** Distillation is how many production models stay small: DistilBERT kept 97% of BERT's
language-understanding performance with 40% fewer parameters and 60% faster inference, and today's small LLMs are
commonly distilled from larger ones. It turns an expensive model into a cheap one for a specific job.

**In plain words.** A master chef (teacher) can't work in every restaurant. An apprentice (student) learns by watching
not just the final dish, but how confident the master is between options ("this sauce could almost go either way").
That extra signal makes the apprentice learn much faster than from recipes alone.

**Architecture: knowledge distillation.**

```mermaid
flowchart LR
  X["Training inputs<br/>labeled or unlabeled"] --> T["Teacher<br/>large, frozen"]
  X --> S["Student<br/>small, training"]
  T --> SOFT["Soft targets<br/>teacher probabilities at temperature T"]
  S --> SP["Student probabilities<br/>at temperature T"]
  SOFT & SP --> KL["KL divergence loss<br/>times T squared"]
  Y["True labels, if any"] --> CE["Cross-entropy loss"]
  S --> CE
  KL & CE --> LOSS["Total loss<br/>alpha KL + (1 - alpha) CE"]
  LOSS -->|"update"| S
```

**How to read it:** each training input goes to both the frozen teacher and the student. The teacher's output
probabilities, softened by a temperature, become soft targets. The student is trained to match them using a KL
divergence loss, and, if true labels exist, also to predict them using the usual cross-entropy loss. A weight alpha
balances the two. Only the student is updated.

**Terms in this diagram.**
- **Teacher, student**: the large, accurate model and the small model being trained to imitate it.
- **Soft targets, temperature T**: the teacher's full probability distribution, not just its top answer. Dividing
  the logits (raw scores) by a temperature above 1 before the softmax spreads probability onto the runner-up answers,
  which carries more information.
- **KL divergence**: a measure of how different two probability distributions are. Zero means identical.
- **Times T squared**: scaling the KL loss by T² keeps its gradient size comparable when T changes (from Hinton et
  al., 2015).
- **Cross-entropy loss**: the standard classification loss against true labels.
- **Alpha**: the weight between the two losses, often 0.5–0.9 for the distillation term.

**Core ideas.**
- **Kinds of distillation.**
  - **Logit (response) distillation** matches output distributions, as above.
  - **Feature distillation** matches hidden layers, which helps when the student has a similar shape.
  - **Sequence-level distillation** for LLMs trains the student on text generated by the teacher, the most common
    way small chat models are made today (Section 36 covers advanced variants).
- **Unlabeled data works.** The teacher labels it, so you can distill on large amounts of in-domain traffic.
- **Task-specific students win big.** A 1B student distilled for one task (classifying support tickets, say) can
  match a 70B general model on that task at a small fraction of the cost.
- **The teacher's cost is paid once.** Generating teacher outputs is a batch job, often run on spare or cheaper
  capacity, while savings recur on every request.
- **Check licenses.** Some model licenses restrict using outputs to train other models.

```python
import torch
import torch.nn.functional as F

def distill_loss(student_logits, teacher_logits, labels, T=4.0, alpha=0.7):
    soft = F.kl_div(F.log_softmax(student_logits / T, dim=-1),
                    F.softmax(teacher_logits / T, dim=-1), reduction="batchmean") * T * T
    hard = F.cross_entropy(student_logits, labels)
    return alpha * soft + (1 - alpha) * hard

for x, y in loader:
    with torch.no_grad():
        t_logits = teacher(x)
    loss = distill_loss(student(x), t_logits, y)
    loss.backward(); opt.step(); opt.zero_grad()
```

In the code, `F.kl_div` expects the student's log-probabilities and the teacher's probabilities. `reduction=
"batchmean"` averages over the batch, which matches the mathematical definition. The teacher runs under
`torch.no_grad()`, so no memory is spent on its gradients. `loader`, `teacher`, `student`, and `opt` are your data
loader, the two models, and the student's optimizer.

**Example: from 70B to 3B for ticket routing.** A support platform routed tickets with a 70B model at $0.004 each,
on 2 million tickets a day. They labeled 3 million historical tickets with the 70B model, then fine-tuned a 3B model
on those outputs (sequence-level distillation). The 3B student matched the teacher within 0.6 points of accuracy,
ran on one L4 GPU per replica, and cut the cost per ticket by about 30×.

**Senior / FAANG best practice.** Distill task-specific students when one task carries heavy traffic. Use the teacher
to label large amounts of in-domain unlabeled data, combine soft and hard losses, and evaluate the student on the
production task, including its hardest slices. Confirm the teacher's license allows distillation, and pair pruning
with distillation when making smaller versions of a model family.

---

## Lecture 243 — Structured vs unstructured sparsity

**Why it matters.** "50% sparse" can mean 2× faster or 0% faster, depending on where the zeros are and what hardware
runs them. Teams often prune models, see no speedup, and abandon a useful technique, or buy into marketing numbers that
don't hold end to end.

**In plain words.** Imagine a parking lot where half the spaces are empty. If the empty spaces are scattered randomly,
you still have to drive past every row to find cars (no time saved). If whole rows are empty, you skip those rows
entirely. If every row has exactly two empty spots out of every four, a smart valet can learn the pattern and move
twice as fast.

**Architecture: sparsity patterns and hardware.**

```mermaid
flowchart TB
  UNS["Unstructured<br/>zeros anywhere, 50-90%"] --> UH["Dense GPU kernels: no speedup<br/>sparse kernels: only at very high sparsity<br/>compression: yes"]
  SEMI["Semi-structured 2:4<br/>2 zeros in every 4"] --> SH["Sparse tensor cores on A100, H100, B200<br/>up to 2x math, about 1.1-1.5x end to end"]
  BLK["Block sparsity<br/>zero tiles of 16x16 or 32x32"] --> BH["Block-sparse kernels<br/>speedup at moderate sparsity"]
  STR["Structured<br/>remove channels, heads, layers"] --> STH["Smaller dense model<br/>speedup everywhere"]
  MOE["Mixture of experts<br/>route each token to few experts"] --> MH["Fewer active parameters per token<br/>all experts still in memory"]
```

**How to read it:** unstructured sparsity places zeros anywhere. It compresses well but doesn't speed up dense GPU
kernels. 2:4 semi-structured sparsity, with two zeros in every group of four, runs on sparse tensor cores, with up to
twice the math speed in those kernels and a smaller gain for the whole model. Block sparsity zeros whole tiles and
needs special kernels. Structured pruning makes a smaller dense model that's faster everywhere. Mixture-of-experts
models are a different kind of sparsity: each token uses only a few experts, which saves compute but not memory.

**Terms in this diagram.**
- **Unstructured, 50-90%**: zeros scattered anywhere in the matrix, at high percentages.
- **Dense GPU kernels, sparse kernels**: normal matrix code computes every element, zeros included. **Sparse
  kernels** skip zeros using compressed formats, and usually only beat dense code at very high sparsity (often above
  90%) because of indexing overhead.
- **Semi-structured 2:4**: in every group of 4 consecutive weights, exactly 2 are zero. The hardware stores only the
  2 non-zero values plus a small index.
- **Sparse tensor cores on A100, H100, B200**: tensor cores in NVIDIA's Ampere, Hopper, and Blackwell generations
  that execute 2:4 sparse matrix multiplies at up to twice the dense rate.
- **About 1.1-1.5x end to end**: the whole-model speedup is smaller than 2×, because attention, normalization, and
  memory reads aren't sped up.
- **Block sparsity, tiles**: zeros grouped in square tiles, so a kernel can skip whole tiles.
- **Mixture of experts (MoE)**: a model with many expert feed-forward blocks, of which a router picks a few per token
  (Section 26). Mixtral 8x7B, for example, has about 47B parameters but uses about 13B per token.

**Core ideas.**
- **Ask "faster on what?"** Speedup depends on the pattern and the kernel library: cuSPARSELt for 2:4 on NVIDIA,
  block-sparse kernels in Triton, or CPU sparse kernels (Neural Magic's DeepSparse showed large CPU gains with
  unstructured sparsity).
- **2:4 needs fine-tuning.** Forcing a dense model into 2:4 loses quality. Prune to 2:4 (for example with SparseGPT or
  Wanda) and then fine-tune, or train sparse from the start (Section 36).
- **Combine with quantization.** 2:4 sparsity plus INT8 or FP8 stacks: TensorRT supports both together.
- **Activation sparsity** is another kind: after ReLU many activations are zero, and some LLM inference engines skip
  the matching weights. Gains depend on the model's activation function.
- **MoE saves compute, not memory.** All experts must be loaded, so MoE models need large GPU memory and
  expert parallelism (Section 31), and benefit strongly from weight quantization.

```python
import torch
from torch.sparse import to_sparse_semi_structured

W = torch.randn(4096, 4096, dtype=torch.float16, device="cuda")
mask = torch.zeros_like(W, dtype=torch.bool).view(-1, 4)
idx = W.abs().view(-1, 4).topk(2, dim=1).indices                  # keep the 2 largest of every 4
mask.scatter_(1, idx, True)
W_24 = (W.view(-1, 4) * mask).view(4096, 4096)
W_sparse = to_sparse_semi_structured(W_24)                        # compressed 2:4 format
x = torch.randn(4096, 8192, dtype=torch.float16, device="cuda")
y = torch.mm(W_sparse, x)                                         # runs on sparse tensor cores (A100 or newer)
```

In the code, the weights are viewed in groups of 4, and `topk(2)` keeps the two with the largest magnitude in each
group, which is magnitude-based 2:4 pruning. `to_sparse_semi_structured` converts the matrix to the compressed form
the hardware uses (half the values plus metadata). The matrix multiply then uses cuSPARSELt on supported GPUs.
Speedups show up for large matrices like these, and small ones may not benefit.

**Example: the 80% sparse model that wasn't faster.** A team pruned a BERT-style classifier to 80% unstructured
sparsity with no accuracy loss, deployed it on T4 GPUs, and saw identical latency. Switching to 2:4 sparsity
(50%) with fine-tuning, plus INT8, in TensorRT gave 1.6× lower latency than the dense INT8 version. On their CPU
fleet, the 80% unstructured version with a sparse CPU runtime gave 3× more throughput. Same model idea, but each kind
of hardware needed a different pattern.

**Senior / FAANG best practice.** Pick the sparsity pattern for the target hardware and kernel library: 2:4 with
fine-tuning on NVIDIA GPUs from Ampere onward, structured pruning for speedups on any device, unstructured only with
sparse runtimes at high sparsity. Stack sparsity with quantization, and always measure end-to-end latency, not kernel
speedups.

---

## Lecture 244 — Benchmarking optimized models

**Why it matters.** Optimization claims are easy to get wrong: a benchmark at batch size 1 with short prompts, no
warm-up, and perplexity as the only quality metric can make a harmful change look like a win. A benchmark that
matches production is what turns an optimization into a safe deployment decision.

**In plain words.** Testing a car's fuel economy downhill with no passengers gives a great number that no driver will
ever see. A fair test drives the real route, with real passengers, in real traffic.

**Architecture: an honest benchmark.**

```mermaid
flowchart LR
  subgraph QUAL["Quality"]
    EV["Task evals<br/>your eval set, lm-eval tasks"]
    SL["Slices + long-tail cases"]
    AGR["Agreement with baseline<br/>output diff rate"]
  end
  subgraph PERF["Performance"]
    WL["Realistic workload<br/>prompt and output length mix"]
    LOAD["Load sweep<br/>request rate up to saturation"]
    MET["p50, p99, TTFT, ITL,<br/>tokens per second, memory"]
  end
  QUAL & PERF --> COST["Cost per 1,000 requests<br/>at the latency SLO"]
  COST --> DEC{"Ship?"}
```

**How to read it:** quality is measured on the real task evaluation set and standard tasks, on slices and hard cases,
and by how often outputs differ from the baseline model. Performance is measured with a realistic mix of prompt and
output lengths, at increasing request rates up to saturation, recording latency percentiles, time to first token,
time between tokens, throughput, and memory. Both feed one number: cost per 1,000 requests while meeting the latency
target. That decides whether to ship.

**Terms in this diagram.**
- **Task evals, lm-eval tasks**: your own evaluation set, plus standard benchmarks run with EleutherAI's
  `lm-evaluation-harness` (such as MMLU for knowledge or GSM8K for grade-school math).
- **Slices + long-tail cases**: subgroups and rare but important inputs, where optimizations often fail first.
- **Agreement with baseline, output diff rate**: the share of inputs where the optimized model's answer differs from
  the original's. It catches changes that average metrics hide.
- **Realistic workload, prompt and output length mix**: input and output lengths sampled from production logs, not
  one fixed length.
- **Load sweep, saturation**: running at increasing request rates until latency or errors rise sharply, which shows
  the maximum useful throughput.
- **TTFT, ITL**: time to first token and inter-token latency, the two LLM latency measures (Section 15).
- **Latency SLO**: the agreed latency target, such as p99 TTFT under 800 ms (Section 16).

**Core ideas.**
- **Quality first, on the task.** Perplexity changes can be tiny while task accuracy drops several points,
  especially for math, code, and long context. Always run the product's evaluation.
- **Warm up and run long enough.** Discard the first runs (compilation, cache warm-up, GPU clock ramp). Report
  medians and p99 over enough requests (thousands) for stable tails.
- **Measure at realistic concurrency.** Quantization helps most at small batches, and throughput gains appear at high
  concurrency. Report the whole curve, not one point.
- **Same everything else.** Compare on the same hardware, software versions, serving settings, and inputs. Change one
  variable at a time.
- **Report cost.** Convert throughput at the SLO into cost per 1,000 requests or per million tokens, which is the
  number decision-makers use.
- **Use standard tools.** For LLM serving, `vllm bench serve` or NVIDIA's GenAI-Perf. For general inference,
  MLPerf Inference defines fair rules.

```bash
lm_eval --model vllm --model_args pretrained=meta-llama/Llama-3.1-8B-Instruct,quantization=fp8 \
        --tasks gsm8k,mmlu --batch_size auto --output_path results/fp8
vllm bench serve --model meta-llama/Llama-3.1-8B-Instruct --dataset-name random \
        --random-input-len 1024 --random-output-len 256 --num-prompts 1000 --request-rate 16
```

In the commands, `lm_eval` runs standard tasks through vLLM with FP8 weights, and saves the scores for comparison with
the BF16 run. `vllm bench serve` sends 1,000 requests at 16 requests per second to a running vLLM server, and reports
TTFT, inter-token latency, and throughput percentiles. Repeat it at several request rates to get the full curve. For
production fidelity, replay real prompt and output lengths instead of the random dataset.

**Example: the INT4 win that reversed under load.** At batch size 1, an INT4 weight-only model decoded 2.3× faster
than BF16. At the production load of 64 concurrent sequences, it was 10% slower, because the dequantization work
became the bottleneck once the GPU was compute-bound. FP8 W8A8 was 1.4× faster at both loads. The team shipped FP8 for
the high-traffic endpoint and INT4 for a low-traffic, single-GPU internal tool.

**Senior / FAANG best practice.** Benchmark quality on task evaluations and slices, with an output-difference rate,
before looking at speed. Measure performance with production-shaped inputs across a load sweep, with warm-up and
enough requests for stable p99, on identical software and hardware. Decide on cost per request at the latency SLO,
and keep the benchmark in CI so later changes can't regress silently.

---

## Lecture 245 — Lab: quantize a vision model

**Goal:** quantize ResNet-50 to INT8 with ONNX Runtime static quantization, calibrated on real images, and compare
size, accuracy, agreement with the original, and CPU latency.

**What you're building:** an export script (PyTorch to ONNX), a calibration data reader, a quantization step, and a
benchmark that evaluates both models on the Imagenette validation set.

```mermaid
flowchart LR
  PT["torchvision ResNet-50<br/>IMAGENET1K_V2, FP32"] -->|"torch.onnx.export"| ONNX["resnet50.onnx<br/>about 102 MB"]
  ONNX --> PREP["ORT preprocess<br/>shape inference, fusion"]
  CALIB["Calibration reader<br/>200 training images"] --> QS["quantize_static<br/>QDQ, per-channel INT8"]
  PREP --> QS
  QS --> INT8["resnet50_int8.onnx<br/>about 26 MB"]
  ONNX & INT8 --> BENCH["Benchmark<br/>top-1, agreement, latency p50 and p99"]
```

**How to read the diagram:** a pretrained ResNet-50 (25.6 million parameters × 4 bytes) is exported to ONNX at about
102 MB. ONNX Runtime's preprocessing step adds shape information and fuses operations. A calibration reader feeds 200
training images through the model to measure activation ranges, and static quantization writes an INT8 model of
about 26 MB with per-channel weight scales.
Both models are evaluated for accuracy, agreement, and latency.

The terms, briefly:
- **torchvision, IMAGENET1K_V2**: PyTorch's vision library and its improved ImageNet weights for ResNet-50 (80.9%
  top-1 on ImageNet).
- **ONNX, torch.onnx.export**: ONNX (Open Neural Network Exchange) is a portable model format, and this function
  converts a PyTorch model to it.
- **ORT preprocess, shape inference, fusion**: ONNX Runtime's preparation step, which works out tensor shapes and
  merges operations, such as convolution with batch normalization, before quantization.
- **QDQ**: the quantize-dequantize format, where the graph has explicit quantize and dequantize nodes that runtimes
  fuse into INT8 kernels.
- **Top-1, agreement**: the share of images where the top prediction is correct, and the share where the INT8 and
  FP32 models predict the same class.

**Prerequisites:** Python 3.10+, about 2 GB of disk, and:

```bash
pip install torch torchvision "onnx>=1.16" "onnxruntime>=1.18" pillow numpy
curl -LO https://s3.amazonaws.com/fast-ai-imageclas/imagenette2-320.tgz && tar xzf imagenette2-320.tgz
```

**Imagenette** is a free 10-class subset of ImageNet from fast.ai. Because its classes are ImageNet classes, an
ImageNet model can be scored on it directly.

### Step 1 — Export and preprocess

```python
# export.py
import torch
from torchvision.models import resnet50, ResNet50_Weights
m = resnet50(weights=ResNet50_Weights.IMAGENET1K_V2).eval()
torch.onnx.export(m, torch.randn(1, 3, 224, 224), "resnet50.onnx", input_names=["input"], output_names=["logits"],
                  dynamic_axes={"input": {0: "batch"}, "logits": {0: "batch"}}, opset_version=17)
```

```bash
python3 export.py
python3 -m onnxruntime.quantization.preprocess --input resnet50.onnx --output resnet50_pre.onnx
```

`dynamic_axes` lets the batch size vary at run time. `opset_version=17` picks the ONNX operator set version.

### Step 2 — Calibrate and quantize

```python
# quantize.py
import glob, random
import numpy as np
from PIL import Image
from onnxruntime.quantization import CalibrationDataReader, QuantFormat, QuantType, quantize_static

MEAN, STD = np.array([0.485, 0.456, 0.406]), np.array([0.229, 0.224, 0.225])

def load(path):
    im = Image.open(path).convert("RGB").resize((256, 256))
    im = np.asarray(im.crop((16, 16, 240, 240)), dtype=np.float32) / 255.0
    return ((im - MEAN) / STD).transpose(2, 0, 1)[None].astype(np.float32)

class Reader(CalibrationDataReader):
    def __init__(self, files):
        self.it = iter([{"input": load(f)} for f in files])
    def get_next(self):
        return next(self.it, None)

if __name__ == "__main__":
    files = sorted(glob.glob("imagenette2-320/train/*/*.JPEG"))
    random.Random(0).shuffle(files)
    quantize_static("resnet50_pre.onnx", "resnet50_int8.onnx", Reader(files[:200]),
                    quant_format=QuantFormat.QDQ, per_channel=True,
                    weight_type=QuantType.QInt8, activation_type=QuantType.QUInt8)
    print("wrote resnet50_int8.onnx")
```

In the code, `load` applies the standard ImageNet preprocessing: resize, center crop to 224 × 224, scale to 0–1, and
normalize with ImageNet's mean and standard deviation. The calibration images come from the training split, so the
validation images stay unseen. `per_channel=True` gives each output channel its own weight scale. Weights are signed
INT8. Activations are unsigned INT8 (`QUInt8`), because after ReLU they're non-negative. The `__main__` guard lets `bench.py` import `load`
without re-running quantization.

### Step 3 — Evaluate and benchmark

```python
# bench.py
import glob, os, time
import numpy as np
import onnxruntime as ort
from quantize import load

IMAGENET_IDX = {"n01440764": 0, "n02102040": 217, "n02979186": 482, "n03000684": 491, "n03028079": 497,
                "n03394916": 566, "n03417042": 569, "n03425413": 571, "n03445777": 574, "n03888605": 701}
files = sorted(glob.glob("imagenette2-320/val/*/*.JPEG"))[::4]          # every 4th image, about 980
labels = [IMAGENET_IDX[f.split("/")[-2]] for f in files]
X = [load(f) for f in files]

def run(path):
    s = ort.InferenceSession(path, providers=["CPUExecutionProvider"])
    for x in X[:20]:
        s.run(None, {"input": x})                                       # warm-up
    preds, lat = [], []
    for x in X:
        t = time.perf_counter(); out = s.run(None, {"input": x})[0]; lat.append((time.perf_counter() - t) * 1e3)
        preds.append(int(out.argmax()))
    return np.array(preds), np.percentile(lat, [50, 99])

p32, l32 = run("resnet50_pre.onnx")
p8, l8 = run("resnet50_int8.onnx")
y = np.array(labels)
for name, path, p, l in (("FP32", "resnet50_pre.onnx", p32, l32), ("INT8", "resnet50_int8.onnx", p8, l8)):
    print(f"{name}: {os.path.getsize(path) / 1e6:5.1f} MB  top-1 {np.mean(p == y):.3f}  "
          f"p50 {l[0]:.1f} ms  p99 {l[1]:.1f} ms")
print(f"agreement INT8 vs FP32: {np.mean(p8 == p32):.3f}")
```

```bash
python3 quantize.py && python3 bench.py
```

In the code, `IMAGENET_IDX` maps each Imagenette folder name to its ImageNet class index. Top-1 here means "the
model's best guess among all 1,000 ImageNet classes is the correct one", which is harder than choosing among 10.
The first 20 images are run only to warm up. Latency is measured per single image (batch size 1) on CPU.

### Step 4 — Experiments

- Quantize again with `per_channel=False` and compare accuracy and agreement.
- Calibrate with only 10 images, and then with 200 images from a single class. Watch agreement drop.
- Run `bench.py` with batch size 32 (stack 32 images) to compare throughput rather than single-image latency.
- On an x86 CPU with VNNI or AMX instructions (most recent Intel Xeon and AMD EPYC), compare with an ARM laptop.
  INT8 speedups depend heavily on the CPU.

**Expected results:**
- Model size: FP32 about 102 MB, INT8 about 26 MB (about 4× smaller).
- Top-1 on the Imagenette subset: FP32 roughly 0.85–0.90. INT8 within about 1 point of FP32.
- Agreement between INT8 and FP32 predictions: about 97–99%.
- Latency at batch size 1: on recent x86 server CPUs, INT8 is about 1.5–3× faster. On Apple Silicon, the gain is
  smaller and can be close to zero, because ONNX Runtime's INT8 kernels are best optimized for x86.
- With `per_channel=False`, or with calibration on one class, agreement and accuracy drop noticeably.

---

## Assessment — Calculate quantized model memory savings

**Scenario.** Your team serves Llama 3 70B on H100 80 GB GPUs, with 8,192-token contexts and a target of 32
concurrent sequences per replica. Product asks whether "going 4-bit" would cut the fleet by 4×. Calculate the real
weight memory for each format, including scale overhead and layers kept in BF16, then the KV cache budget, and the
minimum number of GPUs per replica for each format.

**Task.**

```bash
python3 exercises/s35_quant_memory.py                          # 70B on H100 80 GB + checks
python3 exercises/s35_quant_memory.py --kv fp8                 # same with an FP8 KV cache
python3 exercises/s35_quant_memory.py --model llama3-8b --gpu-gb 24 --target-seqs 8   # 8B on a 24 GB L4
```

**Formulas.**
- Bits per weight = value bits + (scale bits + zero bits) / group size. INT4 with groups of 128 costs
  4 + (16 + 4)/128 = 4.156 bits.
- Weight memory = Σ parameters × bits / 8. Embeddings and `lm_head` stay at 16 bits.
- KV bytes per token = 2 × layers × KV heads × head dim × bytes = 2 × 80 × 8 × 128 × 2 = 327,680 bytes (BF16).
- KV budget = GPUs × (80 × 0.9 − 2 GB overhead) − weights. Sequences = budget ÷ (KV bytes per token × 8,192).

**Expected output:**

| Format | Bits per weight | Weights | Saved vs BF16 | Sequences on 1 GPU | GPUs for 32 × 8K (BF16 KV) | With FP8 KV |
|---|---|---|---|---|---|---|
| BF16 | 16.000 | 141.1 GB | 0% | doesn't fit | 4 | 4 |
| FP8 | 8.004 | 72.7 GB | 48.5% | doesn't fit | 4 | 2 |
| INT4 g128 (GPTQ, AWQ) | 4.156 | 39.8 GB | 71.8% | 11 | 2 | 2 |
| NF4 | 4.127 | 39.5 GB | 72.0% | 11 | 2 | 2 |
| NVFP4 | 4.500 | 42.7 GB | 69.7% | 10 | 2 | 2 |

Also: Llama 3 70B has 70,553,706,496 parameters. FP8 weights on 2 GPUs leave 67.3 GB for KV, which holds 25 sequences
of 8K tokens with a BF16 KV cache, or 50 with an FP8 KV cache. INT4 on one GPU leaves 30.2 GB, or 11 sequences.

**What a strong answer explains:**
- **"4-bit" doesn't mean 4× smaller.** Scales, zero points, and BF16 embeddings make INT4 save 72%, not 75%. Quantizing
  the embeddings too only reaches 36.7 GB.
- **The fleet shrinks by 2×, not 4×.** BF16 needs 4 GPUs per replica, and INT4 needs 2 for 32 sequences of 8K tokens,
  because the KV cache, not the weights, becomes the limit. One GPU holds only 11 such sequences.
- **FP8 weights alone don't help at this target.** They still need 4 GPUs, because 2 GPUs leave room for only 25
  sequences. Adding an FP8 KV cache doubles the room to 50 and brings it to 2 GPUs, often with less quality risk than
  INT4.
- **Latency and quality still need checking.** INT4 weight-only can be slower than FP8 at 32 concurrent sequences
  (Lecture 244), so the recommendation depends on benchmarks and task evaluations: FP8 weights plus FP8 KV on 2 GPUs
  is often the safer choice.
- **Tensor parallelism has a cost.** Two GPUs per replica add communication, so per-GPU throughput is somewhat lower
  than one GPU. Compare cost per 1,000 requests, not GPU count alone.

---

## FAANG deep-dive notes

**How big tech does it.** Large inference fleets treat optimization as a continuous program. Models are served in
FP8 on Hopper and in FP4 on Blackwell where validated, KV caches are quantized, and smaller task models are distilled
from frontier models for high-traffic features. Meta published FP8 Llama 3.1 405B weights so the model fits on a
single 8-GPU node. Google distills Gemini Flash-class models. NVIDIA's Minitron pruned and distilled Llama models into
smaller ones at a fraction of the training cost. Every change goes through a quality gate (task evaluations, slices,
and output-difference rates) and a production-shaped load test, and decisions are made on cost per request at the
latency target.

**Staff review questions.**
- Is this workload limited by memory capacity, memory bandwidth, or compute, and does the optimization address that?
- What's the quality budget per task, and how was it measured, including slices?
- What are the real memory numbers with scales, BF16 layers, and the KV cache?
- Does the speedup hold at production concurrency and prompt lengths?
- What's the cost per 1,000 requests before and after, at the same latency target?
- Who owns re-validating when the base model or serving engine is upgraded?

**Interview question.** "Your LLM fleet costs $20 million a year. How would you cut it in half without hurting
quality?"

**Typical system-design prompt:** *Reduce serving cost by 50% for a 70B chat model on 400 H100s, keeping p99 TTFT
under 1 second and quality within 1 point on the product's evaluation set.*

**1. Clarify first:** What's the traffic shape (prompt and output lengths, peak vs average)? Batch size per replica
today? Which tasks matter most for quality? Is any traffic simple enough for a smaller model? What hardware can we
get?

**2. Back-of-envelope sizing:**
- Today: 400 GPUs at 4 per replica (BF16) = 100 replicas.
- FP8 weights + FP8 KV: 2 GPUs per replica at similar batch size and better per-GPU throughput, so ~200 GPUs: a 50%
  cut on its own, if quality holds.
- Routing: if 40% of requests are simple and can go to a distilled 8B model on one GPU at ~8× the throughput per GPU,
  the 70B fleet shrinks by another ~40%.
- Combined: roughly 120 H100s for the 70B plus ~10 for the 8B, about a 65–70% cut.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Weight format | INT4 weight-only | FP8 W8A8 | FP8 for high-concurrency serving. INT4 for memory-bound, low-batch |
| KV cache | BF16 | FP8 | FP8 KV for long context. Check long-context evaluations |
| Smaller model | Prune + distill own | Use an off-the-shelf small model | Distill for high-traffic, narrow tasks |
| Sparsity | Unstructured | 2:4 + fine-tune | 2:4 on Ampere and newer, only with fine-tuning |
| Validation | Perplexity | Task evals + diff rate + slices | Task evaluations always |

**4. Follow-up questions with crisp answers:**
- *Why not INT4 everywhere?* At high concurrency, dequantization can make it slower than FP8, and quality risk is
  higher on math and code.
- *How do you protect quality?* A task evaluation gate, slice checks, an output-difference rate, a shadow deployment,
  and a canary with automatic rollback.
- *What about the KV cache at 32K context?* It dominates memory, so FP8 KV and prefix caching matter more than weight
  format.
- *When does distillation pay off?* When one narrow task carries heavy traffic, the teacher's labeling cost is paid
  once and savings recur.

**Debug this (common onsite question):** "After moving to INT4, average quality is unchanged but customer complaints
about wrong numbers in answers doubled."
1. Compare outputs on prompts with numbers: the output-difference rate is 9%, against 2% overall.
2. Run GSM8K and the team's arithmetic slice: down 14 points.
3. The quantization used per-tensor scales and calibration on generic web text.
4. Fix: AWQ with groups of 128, calibrated on production prompts, keep the most sensitive layers in BF16, and add the
   arithmetic slice to the release gate.

The lesson: averages hide damage. Slice evaluations and output-difference rates catch it.

**5. What separates senior from staff answers:** a senior engineer applies a quantization method and benchmarks it. A
staff engineer starts from the bottleneck and cost model, combines formats, KV cache, routing to distilled models, and
serving changes, sizes the real memory and fleet impact, protects quality with task and slice gates, and decides on
cost per request at the SLO.

**Red flags:**
- Claiming "4-bit is 4× cheaper" without scales, BF16 layers, or the KV cache.
- Judging quality by perplexity alone.
- Benchmarking at batch size 1 with fixed short prompts.
- Expecting unstructured sparsity to speed up dense GPU kernels.
- Calibrating on data unlike production traffic.
- No re-validation when the serving engine or model is upgraded.

---

## Quiz

<details><summary>1. Why does weight quantization speed up LLM decode even without faster math?</summary>
Decode is memory-bandwidth-bound: every token reads all weights from HBM. Fewer bytes per weight means less data to
read per token, so each step finishes sooner.
</details>

<details><summary>2. Why is a "4-bit" 70B model about 40 GB rather than 35 GB?</summary>
Group scales and zero points add about 0.16 bits per weight (4.156 bits with groups of 128), and embeddings and the
output layer usually stay BF16, which adds about 4.2 GB.
</details>

<details><summary>3. When would you choose FP8 W8A8 over INT4 weight-only?</summary>
For high-concurrency serving on Hopper or newer GPUs, where compute matters and dequantization overhead would slow
INT4, and when you want quality closer to BF16.
</details>

<details><summary>4. Why doesn't 80% unstructured sparsity speed up a model on a GPU?</summary>
Dense kernels still compute every element, including zeros, and sparse kernels have indexing overhead that only pays
off at very high sparsity. The scattered zeros mainly help compression.
</details>

<details><summary>5. What is 2:4 sparsity, and what speedup should you expect?</summary>
Two zeros in every group of four weights. Sparse tensor cores run those matrix multiplies at up to 2× the dense rate,
typically giving about 1.1–1.5× end to end, after fine-tuning to recover quality.
</details>

<details><summary>6. Why use temperature in distillation?</summary>
Dividing logits by a temperature above 1 softens the teacher's distribution, revealing how it ranks the wrong answers.
That carries more information than the top label. The loss is scaled by T² to keep gradients comparable.
</details>

<details><summary>7. Name three mistakes that make an optimization benchmark misleading.</summary>
Any three of: no warm-up, batch size 1 only, fixed short prompts, perplexity as the only quality metric, different
software versions between runs, too few requests for a stable p99, and not reporting cost at the SLO.
</details>

<details><summary>8. Why calibrate static INT8 quantization on representative data?</summary>
Calibration sets the activation ranges. Unrepresentative data gives the wrong ranges, so real inputs are clipped or
lose precision, which lowers accuracy and agreement with the original model.
</details>

## Failure modes
- Assuming quantization savings equal the bit ratio, ignoring scales, BF16 layers, and the KV cache.
- Per-tensor scales destroyed by outliers.
- Calibration on data unlike production traffic.
- Validating with perplexity only, missing drops on math, code, or long context.
- Pruning unstructurally and expecting GPU speedups.
- 2:4 sparsity applied without fine-tuning.
- A distilled student that fails on hard slices the teacher handled.
- Benchmarks at batch size 1 that reverse at production concurrency.
- Optimizations that silently regress after serving engine or model upgrades.

## Checklist
- [ ] You know whether each workload is memory- or compute-bound before optimizing
- [ ] You can calculate real quantized memory, including scales, BF16 layers, and the KV cache
- [ ] You can pick FP8, INT8, INT4, or FP4 by hardware and bottleneck
- [ ] You know which pruning and sparsity patterns speed up which hardware
- [ ] You can write a distillation loss and plan a task-specific student
- [ ] Your benchmarks use task evaluations, slices, realistic load, and cost at the SLO
- [ ] You quantized ResNet-50 to INT8 with calibration and compared size, accuracy, and latency
- [ ] You ran the assessment and can explain why "4-bit" halves this fleet instead of quartering it
