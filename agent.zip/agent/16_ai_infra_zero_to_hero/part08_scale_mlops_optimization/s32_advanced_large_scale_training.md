# Section 32 — Advanced Large-Scale Training

> Lectures 218–224 • Assessments: quiz, [Plan distributed checkpoint shards](#assessment--plan-distributed-checkpoint-shards) • Exercise: [`s32_checkpoint_shards.py`](../exercises/s32_checkpoint_shards.py)
> **After this section you can:** configure DeepSpeed ZeRO-2 and ZeRO-3 (buckets, prefetch, persistence, offload,
> ZeRO++), shard models with PyTorch FSDP2 (full, hybrid, and mixed precision policies), run Flash Attention with
> packed variable-length batches and long context, design sharded asynchronous checkpoints with the right interval,
> run elastic training jobs on Kubernetes that survive node loss, plan the extra work that appears beyond 1,000
> GPUs, and train a model with DeepSpeed ZeRO-3 while measuring memory per stage.
>
> Builds on: [Section 26](../part07_workloads/s26_genai_advanced.md) (ZeRO stages, Megatron, LoRA) and
> [Section 31](s31_large_scale_training.md) (parallelism choice, MFU, fault tolerance).
> Go deeper: [13 / Lab 39 — Checkpointing to S3](../../13_sovereign_ai_infra_course/03_distributed_training/lab39_checkpointing_s3.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 218 | DeepSpeed ZeRO-2/3 optimizations | The stage sets memory. Buckets, prefetch, persistence thresholds, and ZeRO++ set the speed |
| 219 | Fully Sharded Data Parallel (FSDP) | Wrap per transformer block, pick full or hybrid sharding by network, and set a mixed precision policy |
| 220 | Flash Attention in large models | Exact attention in O(N) memory. Pack documents with variable-length kernels, and split long context across GPUs |
| 221 | Checkpointing strategies for multi-node systems | Save sharded, asynchronous, atomic, and resharding-friendly checkpoints, every √(2 × stall × MTBF) |
| 222 | Elastic training with Kubernetes | Gang-schedule, detect failure fast, restart from the last checkpoint with fewer or replacement nodes |
| 223 | Scaling beyond 1,000 GPUs | Failures every few hours, stragglers, silent data corruption, startup time, and network congestion become the job |
| 224 | Lab: train with DeepSpeed ZeRO-3 | Train the same model under ZeRO-0, 2, and 3, measure memory and speed, save, and consolidate the checkpoint |

```mermaid
flowchart LR
  MODEL["Model too big<br/>for one GPU"] --> SHARD{"Shard the training state"}
  SHARD --> DS["DeepSpeed ZeRO-2/3<br/>JSON config"]
  SHARD --> FSDP["PyTorch FSDP2<br/>fully_shard per block"]
  DS & FSDP --> ATTN["Flash Attention<br/>packed batches, long context"]
  ATTN --> CKPT["Sharded async checkpoints<br/>atomic, reshardable"]
  CKPT --> ELASTIC["Elastic restart on Kubernetes<br/>gang scheduling, spares"]
  ELASTIC --> SCALE["Beyond 1,000 GPUs<br/>stragglers, SDC, startup time"]
  SCALE -->|"measure MFU + goodput"| MODEL
```

**How to read it:** when the training state no longer fits one GPU, you shard it with DeepSpeed ZeRO or PyTorch
FSDP. Flash Attention then keeps activation memory under control, especially at long context. Because failures
are certain at this scale, sharded asynchronous checkpoints and elastic restarts decide how much work survives a
crash. Beyond 1,000 GPUs, new problems appear that no single library solves, and every change is judged by the
two numbers from Section 31: MFU and goodput.

**Terms in this diagram.**
- **Training state**: everything a training job holds in GPU memory: the weights, their gradients, and the
  optimizer state (for Adam, an FP32 master copy plus two running averages per weight), together about 16 bytes per
  parameter (Section 26).
- **Shard**: split into N pieces so each GPU stores only its own piece.
- **DeepSpeed ZeRO-2/3, JSON config**: Microsoft's DeepSpeed library implements ZeRO (Zero Redundancy Optimizer).
  Stage 2 shards gradients and optimizer state, and stage 3 also shards the weights. It's configured with a JSON file
  (Lecture 218).
- **PyTorch FSDP2, fully_shard per block**: Fully Sharded Data Parallel is PyTorch's built-in equivalent of ZeRO-3.
  FSDP2 is its current version, applied with the `fully_shard()` function to each transformer block (Lecture 219).
- **Packed batches, long context**: several short documents placed in one training row, and sequences of tens of
  thousands of tokens (Lecture 220).
- **Atomic, reshardable**: a checkpoint is either completely written or ignored, never half-written, and it can be
  loaded on a different number of GPUs (Lecture 221).
- **Gang scheduling, spares**: all of a job's pods start together or not at all, and healthy idle nodes wait to
  replace failed ones (Lecture 222).
- **Stragglers, SDC, startup time**: slow ranks that hold everyone back, **silent data corruption** (hardware that
  computes wrong numbers without reporting an error), and the minutes a 1,000-GPU job takes just to start
  (Lecture 223).
- **MFU + goodput**: model FLOPs utilization (share of peak math speed achieved) and goodput (share of paid time that
  produced useful training), from Section 31.

---

## Lecture 218 — DeepSpeed ZeRO-2/3 optimizations

**Why it matters.** Section 26 showed *what* each ZeRO stage shards. In practice, two teams with the same stage
and hardware can see a 2× difference in speed, because of a dozen settings that control how and when the shards
move. Knowing these settings is the difference between "it fits" and "it fits and runs at 45% MFU".

**In plain words.** Think of a shared tool library for a building crew. ZeRO-3 means no worker keeps their own full
toolbox: each worker stores a few tools, and before each job everyone briefly lends theirs out. The stage decides
how much is shared. The settings decide how efficiently it's shared: fetch the next job's tools while working on the
current one (prefetch), keep tiny tools that everyone always needs (persistence), and carry tools in big crates
rather than one at a time (buckets).

**Architecture: one ZeRO-3 training step.**

```mermaid
sequenceDiagram
  participant R as Each rank (GPU)
  participant G as Other ranks
  R->>G: all-gather layer k weights (prefetch layer k+1 meanwhile)
  R->>R: forward layer k, then free gathered weights
  Note over R,G: repeat for every layer, forward pass
  R->>G: all-gather layer k weights again for the backward pass
  R->>R: backward layer k, produce full gradients
  R->>G: reduce-scatter gradients in buckets
  Note over R: keep only my 1/N slice of gradients
  R->>R: optimizer step on my slice (FP32 master + Adam)
```

**How to read it:** under ZeRO-3, each GPU permanently stores only 1/N of the weights. Before a layer runs, the GPUs
all-gather that layer's full weights, use them, and free them again. The next layer's gather is started early so
it overlaps with the current layer's compute. In the backward pass, weights are gathered again, gradients are
computed, and a reduce-scatter both averages them and leaves each GPU with only its own slice. Each GPU then updates
only its slice of the weights.

**Terms in this diagram.**
- **Rank**: one training process, usually one per GPU (Section 8).
- **All-gather**: every rank sends its piece to all others, so every rank ends up with the full tensor.
- **Prefetch**: starting the gather for the *next* layer while the current layer computes, so the network transfer
  is hidden behind compute.
- **Free gathered weights**: the full copy is deleted right after use, which is how ZeRO-3 keeps memory low.
- **Reduce-scatter**: sums gradients across ranks and gives each rank only the slice it owns, in a single operation.
- **Buckets**: gradients are grouped into chunks of a set size before sending, because one large message is more
  efficient than many small ones.
- **FP32 master + Adam**: the optimizer keeps a 32-bit copy of each weight plus Adam's two running averages, even
  when training in 16-bit (Section 26).

**Core ideas.**
- **Choose the lowest stage that fits.**
  - ZeRO-1 shards optimizer state only, and communicates the same amount as plain data parallelism.
  - ZeRO-2 adds gradient sharding at almost no extra communication.
  - ZeRO-3 adds weight sharding, and costs about 1.5× the communication of data parallelism, because weights are
    gathered twice per step.
  - So use ZeRO-2 when the weights fit on each GPU, and ZeRO-3 only when they don't.
- **The settings that matter most (ZeRO-2).**
  - `overlap_comm: true` starts sending gradient buckets while the backward pass is still running.
  - `contiguous_gradients: true` copies gradients into one continuous memory block as they're produced, which
    avoids memory fragmentation (many small unusable gaps).
  - `reduce_bucket_size` sets the bucket size. Larger buckets use bandwidth better but hold more memory. 2e8 to 5e8
    elements is typical.
- **The settings that matter most (ZeRO-3).**
  - `stage3_prefetch_bucket_size` is how many parameters to gather ahead.
  - `stage3_param_persistence_threshold` keeps small parameters (biases, norms) permanently on every GPU, because
    gathering thousands of tiny tensors costs more in latency than it saves in memory.
  - `stage3_max_live_parameters` caps how many gathered parameters may exist at once, which bounds memory peaks.
  - `stage3_gather_16bit_weights_on_model_save` writes a normal consolidated model file when saving, instead of only
    shards.
- **Offload is the last resort.**
  - ZeRO-Offload moves optimizer state, and optionally weights, to CPU memory. ZeRO-Infinity also uses NVMe SSDs.
  - It lets a 13B model fine-tune on one GPU, but the CPU optimizer step can make each step several times slower.
  - Use it for small-scale fine-tuning, not for large pretraining runs where GPUs are the expensive part.
- **ZeRO++ cuts communication across slow networks.**
  - **qwZ** (quantized weights) sends weights in INT8 during all-gather.
  - **hpZ** (hierarchical partitioning) keeps a full copy of the weights inside each node, so the forward-pass
    gathers stay on NVLink.
  - **qgZ** (quantized gradients) sends gradients in INT4 with hierarchical reduction.
  - Together they cut cross-node traffic by up to 4×, which matters most on slower Ethernet clusters.

```json
{
  "train_micro_batch_size_per_gpu": 4,
  "gradient_accumulation_steps": 8,
  "bf16": { "enabled": true },
  "gradient_clipping": 1.0,
  "zero_optimization": {
    "stage": 3,
    "overlap_comm": true,
    "contiguous_gradients": true,
    "reduce_bucket_size": 5e8,
    "stage3_prefetch_bucket_size": 5e8,
    "stage3_param_persistence_threshold": 1e6,
    "stage3_max_live_parameters": 1e9,
    "stage3_gather_16bit_weights_on_model_save": true,
    "zero_hpz_partition_size": 8
  },
  "activation_checkpointing": { "partition_activations": true, "contiguous_memory_optimization": true }
}
```

In the config, `train_micro_batch_size_per_gpu` is how many samples each GPU processes per forward pass, and
`gradient_accumulation_steps` is how many such passes are summed before each optimizer step, so the global batch is
4 × 8 × (number of GPUs). `gradient_clipping` caps the gradient's overall size at 1.0. `zero_hpz_partition_size: 8`
turns on hpZ with a full weight copy per 8-GPU node. `partition_activations` splits saved activations across
tensor-parallel GPUs.

**Example: the same stage, twice the speed.** A team fine-tuned a 13B model with ZeRO-3 on 32 A100s and measured
21% MFU. Profiling showed thousands of tiny all-gathers for layer-norm weights and biases, each waiting on network
latency. Raising `stage3_param_persistence_threshold` to 1e6 kept those on every GPU (an extra ~40 MB per GPU).
Setting the prefetch bucket to 5e8 overlapped gathers with compute. MFU rose to 38%. Then they noticed the 13B model's
weights (26 GB in BF16) fit comfortably on 80 GB GPUs, switched to ZeRO-2, and reached 44%.

**Senior / FAANG best practice.** Start with the lowest ZeRO stage that fits, and prove the choice with a memory
estimate (`deepspeed.runtime.zero.stage3.estimate_zero3_model_states_mem_needs_all_live`). Profile one step before
tuning, and look at the count and size of collectives, not only their total time. Keep offload for small-scale
fine-tuning. On Ethernet or oversubscribed networks, test ZeRO++ (hpZ first, then qwZ and qgZ with a convergence
check). Pin DeepSpeed, PyTorch, and NCCL versions together, since settings change behavior across releases.

---

## Lecture 219 — Fully Sharded Data Parallel (FSDP)

**Why it matters.** FSDP is PyTorch's native way to shard training, and it's what most teams use when they don't
want an extra framework. It composes with tensor parallelism, `torch.compile`, and PyTorch's distributed
checkpointing, so it's the base layer of TorchTitan, torchtune, and many in-house training stacks.

**In plain words.** FSDP turns each transformer block into a "shareable unit". Only while a block is running does
each GPU hold the whole block. Before and after, it holds just its slice. How you draw the unit boundaries, and how
far you share (inside a node, or across the whole cluster), decides both memory and speed.

**Architecture: full sharding vs hybrid sharding.**

```mermaid
flowchart TB
  subgraph FULL["FULL_SHARD across all 32 GPUs"]
    F1["Each GPU stores 1/32<br/>of every block"] --> F2["all-gather crosses<br/>the network every layer"]
  end
  subgraph HSDP["HYBRID_SHARD: shard in node, replicate across"]
    H1["Shard group: 8 GPUs in a node<br/>each stores 1/8, gathers over NVLink"] --> H2["Replicate group: 4 nodes<br/>all-reduce gradients once per step"]
  end
  BLOCK["fully_shard on each<br/>transformer block, then the root"] --> FULL
  BLOCK --> HSDP
  MP["MixedPrecisionPolicy<br/>param BF16, reduce FP32"] -.-> FULL
  MP -.-> HSDP
```

**How to read it:** you apply `fully_shard` to each transformer block, then to the whole model. With full sharding,
every GPU in the job holds 1/32 of each block, so memory is lowest but every layer's gather crosses the network.
With hybrid sharding (HSDP), each node shards the model among its 8 GPUs, gathering over fast NVLink, and the 4
nodes keep identical copies that only average gradients once per step. That uses more memory per GPU (1/8 instead
of 1/32) but much less cross-node traffic. The mixed precision policy decides which number formats are used for
compute and for averaging gradients.

**Terms in this diagram.**
- **FULL_SHARD**: shard weights, gradients, and optimizer state across all GPUs, like ZeRO-3.
- **HYBRID_SHARD (HSDP)**: shard within a group (usually one node) and replicate across groups. In FSDP2 you express
  this with a 2-D **device mesh** of shape (replicate = 4, shard = 8).
- **Shard group, replicate group**: the GPUs that split one copy of the model, and the sets of GPUs holding
  identical slices that average their gradients.
- **NVLink**: the fast GPU-to-GPU connection inside a server, roughly 10 to 20 times faster than the network between
  servers (Section 13).
- **MixedPrecisionPolicy, param BF16, reduce FP32**: run the forward and backward passes with BF16 weights, but sum
  gradients across GPUs in FP32, which avoids rounding errors when many small numbers are added.
- **Root**: the top-level model module, wrapped last so leftover parameters (embeddings, final norm) are sharded too.

**Core ideas.**
- **Wrap granularity sets the memory peak.** Each wrapped unit is gathered as a whole. Wrap every transformer block.
  Wrapping only the whole model would gather everything at once and save nothing.
- **FSDP2 vs FSDP1.**
  - FSDP2 (`torch.distributed.fsdp.fully_shard`) represents each parameter as a **DTensor**, a tensor that knows how
    it's split across devices.
  - That makes it compose cleanly with tensor parallelism and distributed checkpointing, and it gives more
    predictable memory than FSDP1's flattened parameters.
  - New code should use FSDP2.
- **`reshard_after_forward`.** If true, weights are freed after the forward pass and gathered again for backward
  (ZeRO-3 behavior). If false, they're kept until backward finishes (ZeRO-2 behavior), trading memory for one fewer
  gather. A common choice is false for the last block, whose backward runs immediately.
- **Combine with activation checkpointing and compile.**
  - Activation checkpointing per block recomputes the forward pass during backward instead of storing activations.
  - `torch.compile` per block fuses small operations.
  - Apply checkpointing first, then compile, then `fully_shard`.
- **2-D and 3-D meshes.** Tensor parallelism on the inner, intra-node dimension, plus FSDP on the outer dimension, is
  the TorchTitan layout for large models.

```python
import torch
from torch.distributed.device_mesh import init_device_mesh
from torch.distributed.fsdp import fully_shard, MixedPrecisionPolicy
from torch.distributed.algorithms._checkpoint.checkpoint_wrapper import checkpoint_wrapper

# 4 nodes x 8 GPUs: replicate across nodes, shard inside each node (HSDP)
mesh = init_device_mesh("cuda", (4, 8), mesh_dim_names=("replicate", "shard"))
mp = MixedPrecisionPolicy(param_dtype=torch.bfloat16, reduce_dtype=torch.float32)

for i, block in enumerate(model.layers):
    model.layers[i] = block = checkpoint_wrapper(block)          # recompute activations in backward
    fully_shard(block, mesh=mesh, mp_policy=mp,
                reshard_after_forward=(i < len(model.layers) - 1))
fully_shard(model, mesh=mesh, mp_policy=mp)                     # root: embeddings, final norm, output head

optim = torch.optim.AdamW(model.parameters(), lr=3e-4, fused=True)
```

In the code, `init_device_mesh` arranges the 32 GPUs into a 4 × 8 grid with named dimensions. `checkpoint_wrapper`
adds activation checkpointing to a block. `fused=True` selects AdamW's fused CUDA kernel, which updates all
parameters in a few large GPU operations instead of many small ones.

**Example: hybrid sharding on Ethernet.** A team trained a 7B model on 64 GPUs (8 nodes) connected by 100 Gb/s
Ethernet. Full sharding across 64 GPUs gave 24% MFU, because every layer waited on cross-node gathers. Hybrid
sharding with 8-GPU shard groups raised memory per GPU from ~1.8 GB to ~14 GB of training state, which still fit
easily, and MFU rose to 41%. Cross-node traffic dropped to a single gradient all-reduce per step.

**Senior / FAANG best practice.** Use FSDP2 with per-block wrapping, BF16 parameters and FP32 reductions, and
choose full or hybrid sharding from the network: hybrid whenever the per-node shard fits. Write a one-page memory
budget per GPU (states, activations, temporary buffers) before launch. Save with PyTorch Distributed Checkpoint, so
the run can resume on a different GPU count (Lecture 221). Test numerical equivalence against a small unsharded run:
the loss curves should match closely for the first few hundred steps.

---

## Lecture 220 — Flash Attention in large models

**Why it matters.** Section 26 explained *how* Flash Attention computes exact attention without storing the N × N
matrix. In large-model training, the questions become practical: which kernel version runs on your GPU, how to
train on packed batches without documents attending to each other, and how to reach 128k-token context when even
O(N) memory doesn't fit on one GPU.

**In plain words.** Flash Attention is like reading a long book chapter by chapter while keeping a running summary,
instead of photocopying every page first. For large models, you also need rules for books bound together in one
volume (packing: don't let chapter 3 of one book refer to another book), and for books too long for one reader
(context parallelism: split the book among readers who pass notes).

**Architecture: attention choices for long, packed training.**

```mermaid
flowchart LR
  DOCS["Documents of mixed length"] --> PACK["Pack into 8,192-token rows<br/>record cu_seqlens"]
  PACK --> VAR["flash_attn_varlen_func<br/>attend only inside each document"]
  VAR --> KER{"Kernel on this GPU"}
  KER -->|"A100"| FA2["FlashAttention-2<br/>BF16"]
  KER -->|"H100"| FA3["FlashAttention-3<br/>BF16 or FP8, async"]
  VAR --> LONG{"Context over<br/>~32k tokens?"}
  LONG -->|"yes"| CP["Context parallel<br/>ring attention across GPUs"]
  LONG -->|"no"| ONE["One GPU per sequence"]
```

**How to read it:** documents are packed end to end into fixed-length rows, and the start positions of each
document are recorded. The variable-length attention kernel uses those positions so each token only attends to
tokens in its own document. The kernel version depends on the GPU generation. For very long sequences, the sequence
itself is split across several GPUs, which pass keys and values around a ring.

**Terms in this diagram.**
- **Pack into 8,192-token rows**: concatenate documents until a row is full, so no compute is wasted on padding
  (Section 28).
- **cu_seqlens**: "cumulative sequence lengths", the list of positions where each document starts in the packed row,
  for example `[0, 1200, 5000, 8192]` for three documents.
- **flash_attn_varlen_func**: the Flash Attention function for variable-length sequences that takes `cu_seqlens`.
- **FlashAttention-2, FlashAttention-3**: kernel generations. **FA2** works well on Ampere GPUs (A100). **FA3** is
  written for Hopper (H100). It uses Hopper's asynchronous data-movement hardware (TMA) and specialized groups of
  threads (warp specialization) to overlap memory loads with math, and supports FP8.
- **BF16 or FP8**: 16-bit and 8-bit floating-point formats. FP8 roughly doubles attention speed on H100, with care
  for accuracy.
- **Context parallel, ring attention**: each GPU holds a slice of the sequence. GPUs pass their key and value blocks
  around a ring, so each computes attention against the whole sequence without ever holding all of it.

**Core ideas.**
- **Always use a fused kernel.** In PyTorch, `F.scaled_dot_product_attention` (SDPA) picks a backend automatically:
  Flash, memory-efficient, or cuDNN. Confirm which one runs, because some masks or dtypes silently fall back to the
  slow "math" backend that stores the full matrix.
- **Packing needs document masking.**
  - Without it, a token in document B attends to the end of document A in the same row. That's
    **cross-contamination**: the model learns false connections, and quality drops measurably.
  - The variable-length kernel prevents it at no extra cost.
  - Reset position IDs at each document start too.
- **Memory math at long context.**
  - Attention memory with Flash is O(N), but the rest of the layer still scales with sequence length.
  - Activations per layer are about 34 × N × d bytes with BF16 and no recomputation, where d is the hidden size.
  - At N = 128k and d = 8,192, that's ~36 GB per layer, so long context needs activation checkpointing *and* context
    parallelism.
- **GQA and sliding windows reduce cost further.**
  - **Grouped-query attention** (GQA) shares key and value heads across several query heads, which shrinks the KV
    data that ring attention must pass around.
  - **Sliding-window attention** only attends to the last W tokens, which caps cost at long context (used in some
    Mistral and Gemma layers).
- **Long context is trained in stages.** Most models are pretrained at 4k–8k tokens, then extended to 32k–128k
  for a small fraction of tokens, with an adjusted RoPE base (the setting that controls how positions are encoded).

```python
from flash_attn import flash_attn_varlen_func

# q, k, v: (total_tokens, heads, head_dim) for a packed batch; cu_seqlens marks document boundaries
cu = torch.tensor([0, 1200, 5000, 8192], dtype=torch.int32, device="cuda")
out = flash_attn_varlen_func(q, k, v, cu_seqlens_q=cu, cu_seqlens_k=cu,
                             max_seqlen_q=3800, max_seqlen_k=3800, causal=True)
```

In the code, `max_seqlen_q` and `max_seqlen_k` are the length of the longest document in the batch (here 5,000 −
1,200 = 3,800), which the kernel uses to size its work. `causal=True` means each token attends only to earlier
tokens, as in GPT-style training.

**Example: the quality bug hidden in packing.** A team packed documents into 4,096-token rows with a plain causal
mask and saw their 1B model's downstream scores trail a reference run by 1–2 points. Inspection showed that ~60% of
tokens could attend across document boundaries. Switching to `flash_attn_varlen_func` with `cu_seqlens`, and
resetting position IDs per document, closed the gap. It also ran 8% faster, because attention no longer computed
scores across documents.

**Senior / FAANG best practice.** Verify the attention backend in a profile, not by assumption. Pack with document
masking and per-document positions. Budget long-context memory per layer, and plan context parallelism before the
context-extension phase rather than discovering OOMs (out-of-memory errors) at 64k. Test FP8 attention on a
convergence pilot before using it in a long run.

---

## Lecture 221 — Checkpointing strategies for multi-node systems

**Why it matters.** At 512 GPUs, a job fails about every four days. At 16,000 GPUs, it fails every few hours.
Whatever was computed since the last checkpoint is lost, and the restart costs more minutes. Checkpoint design is
often worth more goodput than any kernel optimization.

**In plain words.** Saving a video game: save too rarely and a crash costs an hour of play. Save by stopping the game
for a minute every five minutes and you barely play. The trick is a quick snapshot to memory while the game keeps
running, written to disk in the background, and done at the right interval for how often the game crashes.

**Architecture: an asynchronous sharded checkpoint.**

```mermaid
flowchart LR
  STEP["Training step N"] --> SNAP["Copy my shard to host RAM<br/>pinned memory, about 0.1 s"]
  SNAP --> RESUME["Training resumes<br/>step N+1"]
  SNAP --> UP["Background thread<br/>writes shard to storage"]
  UP --> STORE[("Object store or parallel FS<br/>step_N/rank_0000 ... rank_0511")]
  STORE --> META["Rank 0 writes .metadata<br/>after all ranks finish"]
  META --> COMMIT["Atomic commit:<br/>rename to step_N, update latest"]
  PEER["Optional: copy in peer node RAM<br/>for fastest recovery"] -.-> SNAP
```

**How to read it:** at a checkpoint step, every rank copies its own shard of the weights and optimizer state from
GPU memory to host memory, which takes a fraction of a second, and training continues immediately. A background
thread then writes the shard to shared storage. When every rank has finished, rank 0 writes a metadata file that
describes all the shards, and only then is the checkpoint marked complete. If anything fails before that, the
previous checkpoint remains the latest valid one.

**Terms in this diagram.**
- **Shard**: the part of the training state one rank owns.
- **Host RAM, pinned memory**: the server's CPU memory. **Pinned** (page-locked) memory can receive data from the GPU
  much faster, and asynchronously.
- **Background thread**: a separate thread that does the slow storage write while the GPU keeps training.
- **Object store or parallel FS**: S3-style storage or a shared high-speed file system such as Lustre (Section 6).
- **.metadata**: the index file of a PyTorch Distributed Checkpoint (DCP). It records every tensor's global shape and
  where each slice lives, which is what makes resharding possible.
- **Atomic commit**: the checkpoint becomes visible in one indivisible step, for example by writing into a temporary
  folder, then renaming it and updating a `latest` pointer.
- **Peer node RAM**: some systems keep a copy of each shard in another node's memory, so a restart can reload in
  seconds. Google's Gemini report describes recovering this way from redundant in-memory copies of the model state.

**Core ideas.**
- **What to save.**
  - Weights, optimizer state, the learning-rate scheduler, the step number, the data loader position, and random
    number generator states.
  - Not gradients, which are recomputed.
  - With mixed-precision Adam, that's about 14 bytes per parameter: a 70B model is ~980 GB.
- **Sharded, not consolidated.**
  - Each rank writes its own shard in parallel. Gathering everything to rank 0 would take far longer and need
    enormous memory.
  - Convert to a single consolidated file only for release or evaluation.
- **Layout-independent format.** PyTorch DCP and Megatron's `dist_checkpointing` store each tensor with its global
  shape and offsets. A job saved on 512 GPUs can then load on 384 after losing nodes, or with a different parallel
  layout.
- **The best interval: Young's formula.**
  - Interval ≈ √(2 × stall × MTBF), where **stall** is the time training is blocked per checkpoint and **MTBF** is
    the job's mean time between failures.
  - For a 70B model on 512 GPUs, with a 9.8-second synchronous stall and a 99-hour MTBF, that's ~44 minutes.
  - With asynchronous saves, the stall falls to ~0.1 s and the interval can shrink to minutes, limited by how fast
    the storage absorbs each write.
- **Restart time matters as much as interval.**
  - Expected lost work per failure is half an interval plus the restart time.
  - At 16k GPUs, a 10-minute restart every 3 hours costs ~5% goodput on its own. That's why large labs invest in
    fast failure detection, warm spares, and in-memory reloads.
- **Retention and verification.**
  - Keep the last few checkpoints plus one per day, and move old ones to cheaper storage.
  - Periodically load a checkpoint into a separate job and check its loss matches. An unreadable checkpoint is
    discovered at the worst possible time.

```python
import torch.distributed.checkpoint as dcp
from torch.distributed.checkpoint.state_dict import get_state_dict, set_state_dict

def save(step, model, optim, loader, future=None):
    if future is not None:
        future.result()                                     # previous async save must finish first
    model_sd, optim_sd = get_state_dict(model, optim)       # sharded DTensor state, no gathering
    state = {"model": model_sd, "optim": optim_sd, "step": step, "loader": loader.state_dict()}
    return dcp.async_save(state, checkpoint_id=f"/fsx/ckpts/run42/step_{step:07d}")

def load(path, model, optim, loader):
    model_sd, optim_sd = get_state_dict(model, optim)
    state = {"model": model_sd, "optim": optim_sd, "step": 0, "loader": loader.state_dict()}
    dcp.load(state, checkpoint_id=path)                     # works even if the GPU count changed
    set_state_dict(model, optim, model_state_dict=state["model"], optim_state_dict=state["optim"])
    loader.load_state_dict(state["loader"])
    return state["step"]
```

In the code, `get_state_dict` returns each rank's shards without gathering them. `dcp.async_save` copies them to
host memory, returns a **future** (a handle to work still in progress), and uploads in the background. Waiting on
the previous future first ensures only one save is in flight. The path `/fsx/...` is a shared parallel file system
(for example Amazon FSx for Lustre). To write straight to S3, pass an S3 storage writer, such as the one in the
Amazon S3 Connector for PyTorch, through the `storage_writer` argument. Many teams write to the parallel file
system first and copy to object storage afterwards.

**Example: four hours to forty minutes.** A 512-GPU team checkpointed synchronously every 4 hours, because each
save stalled training for ~10 minutes while rank 0 gathered and wrote a consolidated file. With a 4-day MTBF, they
lost on average 2 hours plus a 20-minute restart per failure, about 2.3% of compute. Switching to sharded DCP
saves cut the stall to ~10 seconds, and they moved to every 40 minutes. Then asynchronous saves cut the stall to
under a second, and in-memory peer copies cut restart to 4 minutes. Goodput rose from ~97% to ~99.7%.

**Senior / FAANG best practice.** Save sharded, asynchronous, layout-independent checkpoints with an atomic commit
and a `latest` pointer. Derive the interval from measured stall and MTBF, and re-derive it when the job size
changes. Treat restart time as a first-class metric with an owner. Test resume weekly by loading a recent checkpoint
in a separate job. Run the exercise to size any new run before it starts.

---

## Lecture 222 — Elastic training with Kubernetes

**Why it matters.** When a node dies at 3 a.m., something must notice, remove it, find a replacement, and restart
every rank from the last checkpoint, without a human. On Kubernetes, that's a combination of an elastic launcher,
a training-job controller, a gang scheduler, and spare capacity. Getting it right turns failures into minutes of
lost time instead of hours.

**In plain words.** A relay team that has agreed in advance: if a runner falls, the coach immediately sends in a
substitute from the bench, and everyone restarts from the last checkpoint marker, not from the start line. The
rules (who's on the bench, how to spot a fall, where the markers are) are set before the race.

**Architecture: elastic training on Kubernetes.**

```mermaid
flowchart TB
  JOB["TrainJob or PyTorchJob<br/>min 60, max 64 nodes"] --> KUEUE["Kueue<br/>admit only when all pods fit"]
  KUEUE --> PODS["Worker pods, one per node<br/>torchrun elastic agent"]
  PODS <--> RDZV["c10d rendezvous<br/>agree on members, assign ranks"]
  HEALTH["Node health: DCGM, NPD,<br/>NCCL timeout, heartbeats"] -->|"node bad"| CORDON["Cordon + taint node"]
  CORDON --> RESTART["Agents stop all workers,<br/>re-rendezvous with spare node"]
  SPARE["Warm spare pool<br/>pre-pulled images"] --> RESTART
  RESTART --> LOAD["Load latest checkpoint<br/>reshard if world size changed"]
  LOAD --> PODS
```

**How to read it:** the training job declares how many nodes it needs, with a range. Kueue admits it only when all
the pods can start at once. Each pod runs `torchrun`'s elastic agent, and the agents meet at a rendezvous point to
agree on the members and assign ranks. When health checks find a bad node, it's cordoned so nothing new lands on
it. The agents stop all workers, rendezvous again with a spare node (or with fewer nodes, if the minimum allows),
load the latest checkpoint, and continue.

**Terms in this diagram.**
- **TrainJob or PyTorchJob**: Kubernetes custom resources from the Kubeflow Training Operator. **PyTorchJob** is the
  long-standing one, and **TrainJob** is the newer v2 API built on **JobSet** (Section 11).
- **min 60, max 64 nodes**: the elastic range. The job can run with as few as 60 nodes, so losing up to 4 doesn't
  stop it.
- **Kueue, admit only when all pods fit**: Kubernetes' job queue. It holds the whole job until there's room for all
  of it, which is **gang scheduling** (Section 11).
- **torchrun elastic agent**: the process `torchrun` runs on each node. It starts the training workers, watches them,
  and restarts them on failure.
- **c10d rendezvous**: PyTorch's built-in meeting service, where agents agree on which nodes are in the job and
  assign each worker a rank.
- **DCGM, NPD, NCCL timeout, heartbeats**: GPU health checks, the node-problem-detector, a time limit after which a
  hung collective aborts, and regular "alive" signals (Sections 16 and 19).
- **Cordon + taint**: mark the node unschedulable, and add a taint so no new pods are placed on it (Section 5).
- **Warm spare pool, pre-pulled images**: healthy nodes kept idle with the training container image already
  downloaded, so they can join in seconds rather than minutes.
- **Reshard if world size changed**: if the job restarts with fewer GPUs, the checkpoint is loaded into the new
  layout (Lecture 221).

**Core ideas.**
- **Elastic means "restart smartly", not "keep running".** In synchronous training, a lost rank stops everyone.
  Elasticity is about restarting quickly with replacements, or with a smaller world, not continuing mid-step.
- **Fail fast.**
  - Set an NCCL timeout of a few minutes (the default can be 10–30 minutes).
  - Turn on heartbeat monitoring, for example `TORCH_NCCL_ENABLE_MONITORING` and a heartbeat timeout.
  - Alert on step-time stalls.
  - A hang that isn't detected wastes the whole cluster's time.
- **Handle a changing world size.**
  - If the job restarts with fewer GPUs, either keep the global batch constant by increasing gradient accumulation
    (preferred, so training dynamics don't change), or scale the learning rate with the batch.
  - The data loader must resume at the right sample for the new world size.
- **Spares beat elasticity.** Restarting on the same number of nodes keeps everything identical. A 2–5% warm spare
  pool is cheaper than the analysis effort of a changing world size, and much cheaper than idle hours.
- **Make startup fast.**
  - Image pulls of 20 GB, Python imports, and NCCL initialization can take 10+ minutes at scale.
  - Pre-pull images, use a local image cache, and keep the container small.
  - Measure "time from failure to first step" as a metric.

```yaml
apiVersion: kubeflow.org/v1
kind: PyTorchJob
metadata:
  name: llm-70b-run42
  labels:
    kueue.x-k8s.io/queue-name: training-h100
spec:
  elasticPolicy:
    rdzvBackend: c10d
    minReplicas: 60
    maxReplicas: 64
    maxRestarts: 100
  pytorchReplicaSpecs:
    Worker:
      replicas: 64
      restartPolicy: OnFailure
      template:
        spec:
          priorityClassName: training-high
          containers:
            - name: trainer
              image: registry.example.com/train:2026.11.1
              command: ["torchrun", "--nproc-per-node=8", "train.py", "--resume-from=latest"]
              env:
                - { name: TORCH_NCCL_ASYNC_ERROR_HANDLING, value: "1" }
                - { name: NCCL_TIMEOUT_SECONDS, value: "300" }
              resources:
                limits: { nvidia.com/gpu: 8, rdma/ib: 8 }
```

In the manifest, the `kueue.x-k8s.io/queue-name` label submits the job to a Kueue queue. `elasticPolicy` sets the
rendezvous backend and the node range, and `maxRestarts` caps automatic restarts. `restartPolicy: OnFailure`
restarts a failed container. `priorityClassName` sets the job's priority for preemption (Section 11).
`TORCH_NCCL_ASYNC_ERROR_HANDLING` makes NCCL errors crash the process so the agent can restart it, instead of
hanging. `NCCL_TIMEOUT_SECONDS` here is an application setting the training script reads to pass a 300-second
timeout to `init_process_group`. `rdma/ib: 8` requests 8 InfiniBand network interfaces from the RDMA device plugin
(Section 13).

**Example: from 3 hours to 7 minutes.** A team's 64-node job hung every few days when one GPU threw an XID error. The
NCCL default timeout was 30 minutes, and then a human restarted it the next morning: on average 3 hours lost per
failure. They set a 5-minute NCCL timeout, enabled async error handling, added DCGM-based automatic cordoning, and
kept 2 warm spares with pre-pulled images. Median failure-to-first-step fell to 7 minutes, including checkpoint
reload.

**Senior / FAANG best practice.** Gang-schedule every multi-node job. Detect failures in minutes (short NCCL
timeouts, heartbeats, step-time alerts), cordon bad nodes automatically, and keep warm spares with pre-pulled
images. Prefer restarting at the same size. When the world size must change, keep the global batch fixed with
gradient accumulation. Track failure-to-first-step time and its components (detection, scheduling, image pull,
initialization, checkpoint load), and drive each one down.

---

## Lecture 223 — Scaling beyond 1,000 GPUs

**Why it matters.** Most techniques that work on 64 GPUs keep working on 1,000, but a new class of problems appears:
the job is almost never fully healthy, one slow GPU slows 1,000 others, hardware silently computes wrong numbers,
and starting the job takes as long as a short training run. Beyond 1,000 GPUs, operations engineering is a large
share of the training program.

**In plain words.** Running a 10-person team is about the work. Running a 1,000-person company is about systems:
someone is always sick, the slowest department sets the pace, mistakes hide in reports, and a company-wide meeting
takes an hour just to get everyone in the room.

**Architecture: the operations loop around a 4,096-GPU run.**

```mermaid
flowchart LR
  PRE["Pre-flight<br/>burn-in, DCGM diag,<br/>nccl-tests per rail"] --> RUN["Training run<br/>4,096 GPUs"]
  RUN --> TEL["Telemetry<br/>per-rank step time,<br/>loss, grad norm, XID"]
  TEL --> DET{"Anomaly?"}
  DET -->|"straggler"| SWAP["Swap node from spares"]
  DET -->|"loss spike"| RB["Roll back, skip batch"]
  DET -->|"SDC suspected"| SDC["Re-run step on<br/>other GPUs, compare"]
  DET -->|"hang"| RST["Fast restart"]
  SWAP & RB & SDC & RST --> RUN
  RUN --> REPORT["Daily: MFU, goodput,<br/>failures by cause"]
```

**How to read it:** nodes are tested before they join the run. During the run, telemetry from every rank feeds
automatic detectors. Stragglers are swapped for spares, loss spikes trigger a rollback, suspected silent data
corruption is confirmed by recomputing on different hardware, and hangs trigger a fast restart. A daily report
tracks efficiency and failure causes, so the fleet gets healthier over time.

**Terms in this diagram.**
- **Burn-in, DCGM diag, nccl-tests per rail**: run new nodes under heavy load for hours to catch early hardware
  failures, run NVIDIA's GPU diagnostics, and measure network bandwidth on each rail (the set of same-numbered GPUs
  and their network links, Section 13).
- **Per-rank step time**: how long each rank takes per step. Comparing ranks reveals the slow ones.
- **Grad norm, XID**: the gradient's overall size, which spikes when training becomes unstable, and GPU driver error
  codes (Section 16).
- **Straggler**: a rank consistently slower than the rest, for example from a throttling GPU or a degraded link.
- **Loss spike, roll back, skip batch**: a sudden jump in training loss. The response is to reload an earlier
  checkpoint and skip the data that triggered it (Section 28).
- **SDC suspected, re-run step on other GPUs**: silent data corruption is suspected when, for example, the loss or
  gradient norm becomes NaN (not a number) or diverges with no data cause. Re-running the same step on other hardware
  and comparing results identifies the faulty GPU.
- **Goodput, failures by cause**: the share of time that produced useful training, and a breakdown of interruptions
  (GPU, network, software, storage).

**Core ideas.**
- **Failures are continuous.**
  - Meta reported 419 unexpected interruptions in 54 days of Llama 3 training on 16,384 H100s: one every ~3 hours.
  - 58% were GPU-related (including HBM memory), and most of the rest were network, host, and software.
  - At this scale, automation, spares, and fast restart *are* the training plan.
- **Stragglers.**
  - Synchronous training runs at the speed of the slowest rank.
  - Detect with per-rank step-time percentiles.
  - Causes include thermal throttling, a slow PCIe or NVLink link, a misbehaving network card, and noisy neighbors
    on shared storage.
- **Silent data corruption.**
  - A small fraction of chips compute wrong results occasionally, without any error.
  - Symptoms are NaNs or unexplained loss divergence.
  - Mitigations: regular known-answer tests on every GPU, checking gradient norms for anomalies, and recompute-and-
    compare when suspicious.
- **Network at scale.**
  - Use a topology-aware rank placement: tensor-parallel groups inside nodes, and pipeline neighbors in the same
    leaf-switch group.
  - Hierarchical collectives (NCCL's tree and NVLS algorithms) and SHARP (in-network reduction on InfiniBand
    switches) reduce cross-spine traffic.
  - Congestion from other jobs is real, so dedicated or partitioned fabrics are common for flagship runs.
- **Startup and checkpoint at scale.**
  - Pulling a 15 GB image onto 512 nodes at once can overwhelm a registry. Use a peer-to-peer image distribution
    tool or a node-local cache.
  - Python import storms on shared file systems are common. Package the environment into the image.
  - 4,096 ranks writing checkpoints at once need storage sized for that burst.
- **People and process.** A big run needs an on-call rotation, a run book for each failure type, a dashboard every
  engineer reads the same way, and a daily review of goodput losses with owners.

**Example: one bad cable, 4,096 GPUs.** A run's tokens per second dropped 11% with no errors. Per-rank step times
showed 8 ranks finishing their all-reduce ~20% later than the rest, all on rail 3 of two nodes. `nccl-tests` on rail
3 showed half the expected bandwidth: a network cable had fallen back to a lower link speed. Swapping in two spare
nodes restored throughput in 9 minutes, and the cable was replaced during the next maintenance window. The team then
added automatic alerts for link speed drops and per-rank skew above 5%.

**Senior / FAANG best practice.** Treat a flagship run as a production service: pre-flight every node, run automatic
detectors for stragglers, hangs, loss spikes, and SDC, keep spares, and publish daily MFU, goodput, and failure
breakdowns. Place ranks by topology, validate the fabric before and during the run, and size storage and image
distribution for the whole job starting at once. Write the expected failure rate into the schedule: a plan that
assumes no failures is wrong by design.

---

## Lecture 224 — Lab: train with DeepSpeed ZeRO-3

**Goal:** fine-tune the same model under plain data parallelism, ZeRO-2, and ZeRO-3 with DeepSpeed, measure memory
and speed for each, save a ZeRO-3 checkpoint, and convert it into a normal model file.

**What you're building:** one training script and three DeepSpeed configs. You run each config with the same
model, data, and batch size, record peak GPU memory and samples per second, then resume from a checkpoint and
consolidate it.

```mermaid
flowchart LR
  CFG0["ds_zero0.json<br/>plain data parallel"] --> TRAIN["train_ds.py<br/>Qwen2.5-0.5B, 200 steps"]
  CFG2["ds_zero2.json"] --> TRAIN
  CFG3["ds_zero3.json"] --> TRAIN
  TRAIN --> MET["results.csv<br/>peak memory, samples/s, loss"]
  TRAIN --> CK[("ckpt/global_step200<br/>ZeRO-3 shards")]
  CK --> CONV["zero_to_fp32.py<br/>consolidate"]
  CONV --> HF["model.safetensors<br/>loads with transformers"]
```

**How to read the diagram:** the same `train_ds.py` runs three times, once per config: **ZeRO-0** (no sharding, plain
data parallelism), ZeRO-2, and ZeRO-3. The model is **Qwen2.5-0.5B**, a 0.5-billion-parameter open model, trained for
200 steps. Each run appends its peak memory, throughput, and final loss to `results.csv`. The ZeRO-3 run saves sharded
checkpoint files under `ckpt/global_step200`. DeepSpeed's `zero_to_fp32.py` script gathers those shards into one
full-precision weight file, saved as **safetensors** (a safe, fast weight format) that the Hugging Face
`transformers` library loads normally.

**Prerequisites:** 2 or more NVIDIA GPUs with at least 16 GB each (one GPU also works, but sharding has nothing to
split), Python 3.10+, and:

```bash
pip install "torch>=2.4" "deepspeed>=0.15" "transformers>=4.45" datasets
```

### Step 1 — The training script

```python
# train_ds.py: same model and data for every ZeRO stage; records peak memory and throughput
import argparse, csv, os, time
import deepspeed, torch
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer

p = argparse.ArgumentParser()
p.add_argument("--steps", type=int, default=200)
p.add_argument("--tag", default="zero3")
p.add_argument("--local_rank", type=int, default=-1)
p = deepspeed.add_config_arguments(p)
a = p.parse_args()

name = "Qwen/Qwen2.5-0.5B"
tok = AutoTokenizer.from_pretrained(name)
model = AutoModelForCausalLM.from_pretrained(name, torch_dtype=torch.bfloat16)
model.gradient_checkpointing_enable()

ds = load_dataset("wikitext", "wikitext-103-raw-v1", split="train[:2%]")
ds = ds.filter(lambda r: len(r["text"]) > 200)
enc = ds.map(lambda r: tok(r["text"], truncation=True, max_length=1024, padding="max_length"),
             batched=True, remove_columns=ds.column_names).with_format("torch")

engine, _, loader, _ = deepspeed.initialize(args=a, model=model, model_parameters=model.parameters(),
                                            training_data=enc)
torch.cuda.reset_peak_memory_stats()
t0, samples = time.time(), 0
it = iter(loader)
for step in range(a.steps):
    batch = next(it)
    ids, mask = batch["input_ids"].to(engine.device), batch["attention_mask"].to(engine.device)
    out = engine(input_ids=ids, attention_mask=mask, labels=ids.masked_fill(mask == 0, -100))
    engine.backward(out.loss)
    engine.step()
    samples += ids.size(0) * engine.world_size
    if engine.global_rank == 0 and step % 20 == 0:
        print(f"step {step} loss {out.loss.item():.3f}")

dt = time.time() - t0
peak = torch.cuda.max_memory_allocated() / 2**30
engine.save_checkpoint("ckpt")
if engine.global_rank == 0:
    new = not os.path.exists("results.csv")
    with open("results.csv", "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["config", "gpus", "peak_gib_per_gpu", "samples_per_s", "final_loss"])
        w.writerow([a.tag, engine.world_size, f"{peak:.2f}", f"{samples / dt:.1f}", f"{out.loss.item():.3f}"])
```

In the script, `deepspeed.add_config_arguments` adds the `--deepspeed_config` option. `gradient_checkpointing_enable`
turns on activation checkpointing so the comparison focuses on model states. `deepspeed.initialize` wraps the model,
creates the optimizer from the config, and builds a distributed data loader. `engine.backward` and `engine.step`
replace the usual `loss.backward()` and `optimizer.step()`, because DeepSpeed manages sharded gradients and the
optimizer. Labels set to `-100` on padding positions are ignored by the loss, so padding doesn't count as training
text. `max_memory_allocated` reports the highest GPU memory used by tensors on this rank.

### Step 2 — Three configs

```bash
cat > ds_base.json <<'EOF'
{ "train_micro_batch_size_per_gpu": 4, "gradient_accumulation_steps": 1, "bf16": {"enabled": true},
  "gradient_clipping": 1.0,
  "optimizer": {"type": "AdamW", "params": {"lr": 2e-5, "weight_decay": 0.0}},
  "zero_optimization": {"stage": 0} }
EOF
python3 - <<'EOF'
import json
base = json.load(open("ds_base.json"))
for stage in (0, 2, 3):
    cfg = json.loads(json.dumps(base))
    z = {"stage": stage}
    if stage >= 2:
        z.update(overlap_comm=True, contiguous_gradients=True, reduce_bucket_size=5e7)
    if stage == 3:
        z.update(stage3_prefetch_bucket_size=5e7, stage3_param_persistence_threshold=1e5,
                 stage3_gather_16bit_weights_on_model_save=False)
    cfg["zero_optimization"] = z
    json.dump(cfg, open(f"ds_zero{stage}.json", "w"), indent=2)
EOF
```

The base config sets the micro-batch, BF16, gradient clipping, and the AdamW optimizer. The small script writes three
variants that differ only in `zero_optimization`. Smaller buckets than in Lecture 218 suit a 0.5B model.
`stage3_gather_16bit_weights_on_model_save: false` keeps only shards on save, so you practice the conversion step.

### Step 3 — Run all three

```bash
for s in 0 2 3; do
  deepspeed --num_gpus 2 train_ds.py --deepspeed_config ds_zero$s.json --tag zero$s --steps 200
done
column -s, -t results.csv
```

The `deepspeed` launcher starts one process per GPU (like `torchrun`). `column -s, -t` prints the CSV as an aligned
table.

### Step 4 — Resume and consolidate

```bash
ls ckpt/global_step200/                   # *_model_states.pt and per-rank *_optim_states.pt shards
python3 ckpt/zero_to_fp32.py ckpt ckpt/consolidated --safe_serialization
python3 - <<'EOF'
from transformers import AutoModelForCausalLM
import torch
m = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2.5-0.5B", torch_dtype=torch.float32)
from safetensors.torch import load_file
sd = load_file("ckpt/consolidated/model.safetensors")
missing, unexpected = m.load_state_dict(sd, strict=False)
print("loaded tensors:", len(sd), "missing:", len(missing), "unexpected:", len(unexpected))
EOF
```

`zero_to_fp32.py` is generated by DeepSpeed inside every checkpoint folder. It reads all shards and writes the
full FP32 weights. `--safe_serialization` writes safetensors instead of a pickle file. `strict=False` reports any
missing or unexpected tensors instead of failing, and tied weights (the input embedding reused as the output layer)
can legitimately appear as missing.

To test resume, rerun Step 3's ZeRO-3 command after adding `engine.load_checkpoint("ckpt")` right after
`deepspeed.initialize`. The first printed loss should match the last loss of the previous run, not the starting loss.

**Expected results:**
- On 2 × 24 GB GPUs, peak memory per GPU is roughly 9–11 GiB for ZeRO-0, 6–7 GiB for ZeRO-2, and 3–5 GiB for ZeRO-3,
  because a 0.5B model's training state is ~8 GB (16 bytes per parameter) and stages 2 and 3 split more of it.
- Throughput: ZeRO-2 is within ~5% of ZeRO-0. ZeRO-3 is 10–30% slower on two GPUs, because it gathers weights twice
  per step. The gap widens across nodes without hpZ.
- Final loss is the same to within normal noise (±0.02) for all three, because ZeRO changes only where data lives,
  not the math.
- The checkpoint folder holds one optimizer shard per rank. The consolidated safetensors file is ~2 GB (0.5B
  parameters × 4 bytes in FP32) and loads with zero unexpected tensors.
- Resume prints a first loss close to the previous run's last loss.

---

## Assessment — Plan distributed checkpoint shards

**Scenario:** your team is about to start a 30-day continued-pretraining run of a 70B model on 512 H100s (TP 8 ×
PP 4 × DP 16), with 100 GB/s of aggregate checkpoint storage bandwidth. The platform lead asks: how big is each
checkpoint, what does each rank write, how often should you save, what goodput should you expect, how much storage
does the retention policy need, and can the run continue on 384 GPUs if two racks fail?

**Task:** compute each number, explain the formulas, and compare synchronous with asynchronous saving. Then rerun
the plan for a 405B model on 16,384 GPUs with 1 TB/s storage, and explain what limits goodput there.

```bash
python3 exercises/s32_checkpoint_shards.py
python3 exercises/s32_checkpoint_shards.py --params 405e9 --tp 8 --pp 16 --dp 128 --storage-gbps 1000
```

**Formulas:**
- Checkpoint size = parameters × 14 bytes (BF16 weights 2 + FP32 master 4 + Adam first moment 4 + second moment 4).
- Shard per rank = size ÷ GPUs, because weights are split across TP × PP and their copies are divided among the DP
  replicas for writing, and the optimizer state is sharded across DP.
- Synchronous stall = size ÷ storage bandwidth. Asynchronous stall = shard ÷ GPU-to-host copy speed.
- Job MTBF = 1 ÷ (failure rate per GPU-hour × GPUs). The default rate comes from Meta's Llama 3 report: 419
  interruptions in 54 days on 16,384 GPUs.
- Best interval (Young) = √(2 × stall × MTBF). Goodput ≈ 1 − stall ÷ interval − (interval ÷ 2 + restart) ÷ MTBF.

**Expected output:**

| Quantity | 70B, 512 GPUs, 100 GB/s | 405B, 16,384 GPUs, 1 TB/s |
|---|---|---|
| Checkpoint size | 980 GB (weights 140, optimizer 840) | 5,670 GB |
| Shard per rank | 1.91 GB | 0.35 GB |
| Synchronous stall | 9.8 s | 5.7 s |
| Asynchronous stall | 0.10 s | 0.02 s |
| Job MTBF | 99 h | 3.1 h |
| Best interval, sync | 44 min → goodput 99.09% | 5.9 min → goodput 91.42% |
| Best interval, async | 4.4 min → goodput 99.76% | ~0.3 min (floored by upload) → goodput 94.44% |
| Naive every 4 h | goodput 97.74% | goodput 29.91% |
| Retention (last 3 + daily for 30 days) | 33 checkpoints, 32.3 TB | 187.1 TB |
| Reshard to 384 GPUs | possible with DCP or Megatron dist-ckpt | — |

**What a strong answer explains:** the optimizer state is six times bigger than the weights, so checkpoints are far
larger than the model file. Sharding spreads writing over every rank, so no single node is a bottleneck. Young's
formula balances the cost of saving against the work lost on failure, and asynchronous saves make the stall tiny,
so the interval can shrink. At 16,384 GPUs the MTBF is about 3 hours, and the 10-minute restart, not the
checkpoint, becomes the main loss: the 94% goodput only rises by cutting restart time (fast detection, warm spares,
in-memory reload). In practice, teams also cap how often they save, to limit storage load and retention cost.
Layout-independent formats let the run continue on fewer GPUs instead of waiting for repairs.

---

## FAANG deep-dive notes

**How big tech does it.** Frontier labs train with sharded data parallelism (FSDP2 or ZeRO), tensor and pipeline
parallelism mapped to the topology, and context parallelism for long context. Checkpoints are sharded,
asynchronous, and layout-independent, and some keep in-memory copies on peer nodes for reloads in seconds. Training
jobs run on Kubernetes or Slurm with gang scheduling, automatic node health checks, warm spares, and on-call
rotations. Every run reports MFU and goodput daily, with failure causes tracked like production incidents.

**Staff review questions.**
- Why this sharding stage or strategy, and what's the measured memory headroom per GPU?
- What does the profile show: how many collectives per step, and how much is exposed (not overlapped)?
- How is packing masked, and which attention kernel actually runs?
- What's the checkpoint size, stall, interval, and how was the interval derived?
- What's the failure-to-first-step time, broken into detection, scheduling, startup, and reload?
- How does the run detect stragglers and silent data corruption?

**Interview question.** "Your 2,048-GPU run has 88% goodput. Find the missing 12%."

**Typical system-design prompt:** *Design the training platform for a 175B dense model on 2,048 H100s (256 nodes,
8 × 400 Gb/s InfiniBand each), 3 T tokens, 45-day target, on Kubernetes.*

**1. Clarify first:** What sequence length, and is there a long-context phase? What storage exists, and how fast
does it write? What's this cluster's historical failure rate? Are spares available? Is the 45 days for training
only? Is FP8 approved?

**2. Back-of-envelope sizing:**
- Compute: 6 × 175e9 × 3e12 = 3.15e24 FLOPs. At 40% MFU (~400 TFLOP/s per GPU) × 2,048 = 8.2e17 FLOP/s, that's
  3.85e6 s ≈ 45 days *at 100% goodput*. With 95% goodput, it's 47 days, so you need FP8 or more GPUs.
- Memory: 175e9 × 16 B = 2.8 TB of state. With TP 8 × PP 8 × DP 32 and ZeRO-1 across DP, per-GPU state ≈ 2.8 TB ÷
  64 for weights and gradients, plus optimizer ÷ 2,048, which fits with activation checkpointing.
- Checkpoint: 175e9 × 14 B = 2.45 TB. At 200 GB/s, a synchronous stall is 12 s, and asynchronous is under a second.
- MTBF at 2,048 GPUs with the Meta rate: ~25 h. Young's interval with a 12 s stall is ~41 min.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Sharding | ZeRO-1 + TP + PP | FSDP full shard | Lowest sharding that fits. Full sharding when TP and PP aren't used |
| FSDP strategy | Full shard | Hybrid (shard in node) | Hybrid when the per-node shard fits, especially on slower networks |
| Checkpoints | Synchronous, consolidated | Sharded async, DCP | Always sharded. Async when the stall exceeds a few seconds |
| Failure response | Elastic shrink | Restart with spares | Spares keep training identical. Shrink only when spares run out |
| Precision | BF16 | FP8 | FP8 after a convergence pilot. It's often the difference that meets the deadline |

**4. Follow-up questions with crisp answers:**
- *How do you choose the checkpoint interval?* √(2 × stall × MTBF), recalculated when the job size or storage
  changes. Async saves let you checkpoint every few minutes.
- *Why does HSDP beat full sharding on Ethernet?* Weight gathers stay on NVLink inside the node, and only one
  gradient all-reduce per step crosses the network.
- *What happens if packing isn't masked?* Tokens attend across document boundaries, the model learns false
  connections, and quality drops. Use variable-length attention with `cu_seqlens`.
- *A loss spike at step 90k with no data cause?* Suspect silent data corruption: roll back, re-run the step on
  different GPUs, compare, and quarantine the GPU that disagrees.

**Debug this (common onsite question):** "Your 2,048-GPU run has 88% goodput. Where did 12% go?"
1. Break down lost time from the job log: failures × (half interval + restart), plus checkpoint stalls, plus hangs.
2. Found: checkpoints every 2 hours (synchronous, 45 s stall). With a 25-hour MTBF, the expected loss per failure
   is 1 hour + 25 minutes of restart. That's ~5.7% of all time.
3. Found: 4 hangs that waited the default 30-minute NCCL timeout before failing: another ~2%.
4. Found: image pulls took 9 minutes per restart, part of the 25 minutes.
5. Fix: sharded async DCP saves every 20 minutes, a 5-minute NCCL timeout, pre-pulled images and warm spares. Goodput
   rose to ~97%.

The lesson: goodput losses hide in intervals, timeouts, and startup time, not in kernels. Measure each component.

**5. What separates senior from staff answers:** a senior engineer configures ZeRO-3 or FSDP correctly, uses Flash
Attention, and saves sharded checkpoints. A staff engineer budgets the whole run in effective compute (MFU ×
goodput), derives checkpoint intervals from measured failure rates, designs failure detection and restart as a
system with an owner, plans topology-aware placement and SDC detection, and makes the schedule honest about
failures from day one.

**Red flags:**
- ZeRO-3 or offload when a lower stage fits.
- Full sharding across a slow network when hybrid sharding fits.
- Packing without document masking.
- Consolidated, synchronous checkpoints at hundreds of GPUs.
- Default NCCL timeouts and no heartbeat monitoring.
- No warm spares, and image pulls on every restart.
- No per-rank step-time monitoring.

---

## Quiz

<details><summary>1. When should you use ZeRO-2 instead of ZeRO-3?</summary>
When the BF16 weights fit on each GPU. ZeRO-2 shards gradients and optimizer state with about the same
communication as plain data parallelism, while ZeRO-3 adds weight gathers (about 1.5× the communication).
</details>

<details><summary>2. What does stage3_param_persistence_threshold do, and why does it help?</summary>
Parameters smaller than the threshold (biases, norm weights) stay unsharded on every GPU. Gathering thousands of tiny
tensors costs more in latency than the memory saved, so keeping them local speeds up each step.
</details>

<details><summary>3. What is hybrid sharding (HSDP), and when is it better than full sharding?</summary>
Shard within a node and replicate across nodes. It's better when the per-node shard fits in memory, especially on
slower networks: weight gathers stay on NVLink, and only one gradient all-reduce per step crosses nodes.
</details>

<details><summary>4. Why must packed training batches use cu_seqlens with Flash Attention?</summary>
Otherwise tokens attend across document boundaries in the same row. The variable-length kernel uses the document
start positions to restrict attention to each document, which avoids false connections and also skips wasted work.
</details>

<details><summary>5. A 70B checkpoint with mixed-precision Adam is how big, and why?</summary>
About 980 GB: 14 bytes per parameter (2 for BF16 weights, 4 for the FP32 master copy, 4 + 4 for Adam's two moments).
Gradients aren't saved.
</details>

<details><summary>6. State Young's formula for the checkpoint interval, and compute it for a 10 s stall and 100 h MTBF.</summary>
Interval ≈ √(2 × stall × MTBF) = √(2 × 10 × 360,000) ≈ 2,683 s ≈ 45 minutes.
</details>

<details><summary>7. Why are warm spares usually better than shrinking the world size after a failure?</summary>
Restarting at the same size keeps the batch, learning rate, and data order identical, so training dynamics don't
change. Spares with pre-pulled images also join in seconds.
</details>

<details><summary>8. What is silent data corruption, and how do large runs detect it?</summary>
Hardware that occasionally computes wrong results without reporting an error. Symptoms are NaNs or unexplained loss
divergence. Teams run known-answer tests on GPUs, watch gradient norms, and re-run suspicious steps on other GPUs to
find the faulty one.
</details>

<details><summary>9. Why does restart time dominate goodput at 16,000 GPUs?</summary>
The job fails every ~3 hours. Even with near-zero checkpoint stalls, each failure costs half an interval plus the
restart. A 10-minute restart every 3 hours alone is ~5% of all time.
</details>

## Failure modes
- ZeRO-3 with default persistence and prefetch settings, causing thousands of tiny, latency-bound gathers.
- CPU offload in a large pretraining run, where it makes every step several times slower.
- FSDP wrapping only at the root, so the whole model is gathered at once and memory isn't saved.
- Full sharding across slow Ethernet when hybrid sharding would fit.
- Packing documents without variable-length masking.
- SDPA silently falling back to the slow math backend because of an unsupported mask.
- Consolidating checkpoints through rank 0 at scale, stalling training for minutes.
- Non-atomic checkpoints that leave a half-written "latest" after a crash.
- Checkpoint intervals chosen by habit instead of from stall and MTBF.
- Default 30-minute NCCL timeouts, so hangs waste half an hour each.
- Image pulls on every restart at hundreds of nodes.
- No per-rank step-time monitoring, so stragglers go unnoticed.

## Checklist
- [ ] You can choose the lowest ZeRO stage that fits, and explain buckets, prefetch, and persistence
- [ ] You can shard a model with FSDP2, choose full or hybrid sharding, and set a mixed precision policy
- [ ] You pack training data with variable-length attention and per-document positions
- [ ] You can size activation memory at long context and plan context parallelism
- [ ] You save sharded, asynchronous, atomic, reshardable checkpoints
- [ ] You ran `s32_checkpoint_shards.py` and can derive checkpoint size, interval, and goodput by hand
- [ ] You can run an elastic PyTorchJob with gang scheduling, short timeouts, and warm spares
- [ ] You can list the problems that appear beyond 1,000 GPUs and the detector for each
- [ ] You trained with DeepSpeed ZeRO-0, 2, and 3, compared memory and speed, and consolidated a checkpoint
