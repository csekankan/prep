# Section 34 — Advanced Enterprise MLOps

> Lectures 232–238 • Assessment: quiz
> **After this section you can:** run an enterprise model registry with required metadata, approvals, signing, and
> cross-environment promotion, design continuous training pipelines with the right triggers and safeguards, automate
> drift-triggered retraining in Kubeflow, use a feature store with point-in-time correctness inside pipelines, set up
> model governance with risk tiers, and build tamper-evident audit trails that satisfy compliance reviews.
>
> Builds on: [Section 33](s33_enterprise_mlops.md) (Kubeflow, MLflow, cloud pipelines),
> [Section 17](../part05_operating_production/s17_drift.md) (drift and PSI),
> [Section 24](../part07_workloads/s24_data_pipelines.md) (feature stores), and
> [Section 18](../part05_operating_production/s18_security_compliance.md) (security and compliance).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 232 | Model registry in enterprise MLOps | The registry is the system of record: lineage, approvals, signatures, and promotion between environments |
| 233 | Continuous training (CT) pipelines | Retrain on schedule, on new data, or on drift, and promote only after beating the champion |
| 234 | Automating drift retraining with Kubeflow | A drift check step gates retraining, triggered by a recurring run or an alert webhook |
| 235 | Feature store integration in pipelines | Point-in-time joins for training, the same definitions for serving, and versioned feature services |
| 236 | Governance in enterprise MLOps | Risk tiers decide the required reviews, documentation, and monitoring for each model |
| 237 | Audit trails and compliance logging | Append-only, tamper-evident records of who changed what, linked to the evidence |
| 238 | Lab: automate drift retraining with Kubeflow | Detect drift with PSI, retrain, compare with the champion, and promote, on a schedule |

```mermaid
flowchart LR
  PROD["Production traffic<br/>predictions + features logged"] --> MON["Drift + performance monitor"]
  MON -->|"drift or schedule"| CT["Continuous training pipeline"]
  FS[("Feature store<br/>point-in-time training data")] --> CT
  CT --> EVAL{"Beats champion<br/>on holdout + slices?"}
  EVAL -->|"yes"| REG["Registry: new version<br/>lineage, signature, model card"]
  EVAL -->|"no"| KEEP["Keep champion, notify owner"]
  REG --> GOVN{"Governance gate<br/>by risk tier"}
  GOVN -->|"approved"| DEP["Canary deploy, then promote alias"]
  DEP --> PROD
  AUD[("Audit log<br/>append-only")] -.- REG
  AUD -.- GOVN
  AUD -.- DEP
```

**How to read it:** production logs every prediction and its features. A monitor watches for drift and falling
performance. On drift or on a schedule, a continuous training pipeline builds a new model from point-in-time
correct features. If the new model beats the current champion overall and on important slices, it's registered with
lineage, a signature, and a model card. A governance gate, stricter for higher-risk models, approves it, and it's
deployed as a canary before the production alias moves. Every registry change, approval, and deployment is written
to an append-only audit log.

**Terms in this diagram.**
- **Drift + performance monitor**: the service that compares current data and outcomes with a reference, using
  measures such as PSI (Section 17).
- **Continuous training pipeline**: a pipeline that retrains a model automatically, rather than when someone
  remembers to (Lecture 233).
- **Point-in-time training data**: feature values exactly as they were known at each training example's time, so no
  future information leaks into training (Lecture 235).
- **Champion**: the model version currently serving production. A new candidate is a **challenger**.
- **Holdout + slices**: a held-back test set, and subgroups of it (such as region or customer type) checked
  separately so that an overall gain can't hide a loss for one group.
- **Signature**: a cryptographic signature over the model files, proving they came from the pipeline and weren't
  changed (Lecture 232).
- **Model card**: a short document describing a model's purpose, data, metrics, limitations, and owners.
- **Governance gate, risk tier**: the approval step whose strictness depends on how much harm the model could cause
  (Lecture 236).
- **Canary deploy, promote alias**: sending a small share of traffic to the new version first (Section 15), then
  moving the production alias, such as `@champion`, to it (Section 33).
- **Append-only**: records can be added but never edited or deleted (Lecture 237).

---

## Lecture 232 — Model registry in enterprise MLOps

**Why it matters.** In an enterprise the model registry is the system of record. Regulators, auditors, incident
responders, and deployment tools all ask it the same questions: what is in production, who approved it, what data
and code produced it, and can we trust these files. If the registry can't answer, nobody can.

**In plain words.** A registry is like a pharmacy's controlled-drug register. Every batch has a lot number, a
manufacturer, test results, the pharmacist who released it, and a sealed package. Anything without those details
can't be dispensed.

**Architecture: registry as system of record.**

```mermaid
flowchart TB
  PIPE["Training pipeline run"] -->|"register"| MV["Model version<br/>artifact URI + digest"]
  MV --> META["Required metadata<br/>run ID, git SHA, data snapshot,<br/>feature service version, metrics"]
  MV --> SIG["Signature<br/>Sigstore or KMS key"]
  MV --> CARD["Model card + risk tier"]
  MV --> STATE["Lifecycle tags<br/>candidate, approved, deprecated"]
  STATE --> ALIAS["Aliases per environment<br/>staging, champion, shadow"]
  ALIAS --> DEV_REG[("Dev registry")]
  DEV_REG -->|"copy approved version<br/>verify signature"| PROD_REG[("Prod registry")]
  PROD_REG --> SERVE["Serving loads by alias<br/>verifies signature at load"]
```

**How to read it:** each pipeline run registers a version that points to its artifact and records the artifact's
content hash. Required metadata ties it to the run, the exact code, the data snapshot, the feature definitions, and
its metrics. The version is signed, has a model card and a risk tier, and carries lifecycle tags. Aliases point at
the version currently used in each role. Approved versions are copied from the development registry to the
production one after the signature is checked, and serving verifies the signature again when it loads the model.

**Terms in this diagram.**
- **Artifact URI + digest**: the storage location of the model files and their **digest**, a SHA-256 hash of the
  content. If one byte changes, the digest changes.
- **Run ID, git SHA, data snapshot, feature service version**: the tracking run that trained the model, the exact
  commit of the code, an immutable version of the training data (such as a dated table snapshot or a Delta or
  Iceberg version), and the version of the feature definitions used (Lecture 235).
- **Sigstore or KMS key**: **Sigstore** is an open-source signing system (its `cosign` tool signs container images
  and files). A **KMS** (key management service) key is a cloud-held private key used for signing without exposing it.
- **Lifecycle tags**: labels for where the version is in its life: candidate (just trained), approved, or deprecated.
- **Staging, champion, shadow**: aliases for the version under test, the version serving production, and a version
  that receives copies of traffic without affecting responses (Section 15).
- **Dev registry, prod registry**: separate registries per environment, so production permissions and networks stay
  isolated.

**Core ideas.**
- **Required metadata, enforced at registration.** The platform SDK refuses to register a model without a run ID,
  git SHA, data snapshot, owner, and risk tier. Optional metadata is always missing when the auditor arrives.
- **Immutable versions.** A version's artifacts never change. A fix is a new version.
- **Sign and verify.** The pipeline signs the artifact digest. Promotion and serving verify it, so a model copied in
  by hand, or tampered with in storage, won't load (this ties to the supply-chain controls of Section 18 and
  Section 39).
- **Promotion is a controlled action.**
  - Moving a production alias requires a role that pipelines and individuals don't have by default, plus an
    approval record.
  - Rollback is moving the alias back.
- **Retention and deprecation.** Keep every version that ever served production for the retention period that your
  regulations require. Mark old ones deprecated, so new deployments can't pick them up.

```python
import hashlib, pathlib
import mlflow
from mlflow import MlflowClient

REQUIRED = {"git_sha", "data_snapshot", "feature_service", "owner", "risk_tier"}

def dir_digest(path: str) -> str:
    h = hashlib.sha256()
    for f in sorted(pathlib.Path(path).rglob("*")):
        if f.is_file():
            h.update(f.relative_to(path).as_posix().encode()); h.update(f.read_bytes())
    return h.hexdigest()

def register(run_id: str, model_dir: str, name: str, tags: dict) -> str:
    missing = REQUIRED - tags.keys()
    if missing:
        raise ValueError(f"cannot register {name}: missing {sorted(missing)}")
    mv = mlflow.register_model(f"runs:/{run_id}/model", name,
                               tags={**tags, "digest": dir_digest(model_dir), "lifecycle": "candidate"})
    return mv.version

def promote(name: str, version: str, alias: str, approver: str, ticket: str):
    c = MlflowClient()
    c.set_model_version_tag(name, version, "approved_by", approver)
    c.set_model_version_tag(name, version, "approval_ticket", ticket)
    c.set_registered_model_alias(name, alias, version)
```

In the code, `dir_digest` hashes every file and its relative path in a stable order, so the same model folder
always gives the same digest. `register` refuses to create a version without the required tags, and records the
digest. `promote` writes who approved the version and the change ticket before moving the alias. In a real platform,
`promote` runs only in a CI job with a privileged role, and the signature step uses `cosign` or a KMS key over the
digest.

**Example: the model nobody could explain.** A lender's regulator asked which data trained the credit model that
declined a customer 14 months earlier. The registry showed the version, but the data location pointed at a table that
had been overwritten since. The fix: data snapshots became required metadata (a versioned table identifier, not a
path), registration failed without them, and a quarterly job checked that every production version's snapshot still
existed.

**Senior / FAANG best practice.** Treat the registry as the system of record. Enforce required lineage metadata at
registration, keep versions immutable, sign artifacts and verify at promotion and at load, and separate dev and prod
registries. Restrict production alias moves to an approval-backed CI role. Keep every production version and its
data snapshot for the regulated retention period.

---

## Lecture 233 — Continuous training (CT) pipelines

**Why it matters.** Models decay as the world changes: fraud patterns shift weekly, product catalogs change daily,
user tastes drift seasonally. Continuous training retrains automatically so models stay fresh, but done carelessly
it can also ship a worse model automatically. The safeguards matter as much as the automation.

**In plain words.** It's like a newspaper that's reprinted every morning with today's news, but with an editor who
reads each edition before it goes out and holds it if it's worse than yesterday's.

**Architecture: continuous training with safeguards.**

```mermaid
flowchart LR
  T1["Schedule<br/>nightly or weekly"] --> TRIG{"Trigger"}
  T2["New labeled data<br/>above N rows"] --> TRIG
  T3["Drift or KPI alert"] --> TRIG
  TRIG --> VAL["Data validation<br/>schema, volume, freshness"]
  VAL -->|"bad data"| STOP["Stop + alert"]
  VAL --> TR["Train challenger"]
  TR --> CMP["Compare with champion<br/>same holdout, slices"]
  CMP -->|"better by margin"| REG["Register + canary"]
  CMP -->|"not better"| LOG["Record result, keep champion"]
  REG --> WATCH["Watch canary KPIs<br/>auto-rollback"]
```

**How to read it:** a retraining run starts from a schedule, from enough new labeled data, or from a drift or
business-metric alert. The new data is validated first, and bad data stops the run. A challenger is trained and
compared with the current champion on the same holdout set and slices. Only a challenger that wins by a set margin
is registered and canaried, and the canary's metrics are watched with automatic rollback.

**Terms in this diagram.**
- **Trigger**: the event that starts a retraining run.
- **New labeled data above N rows**: start once enough new examples with known outcomes (labels) have arrived, such
  as 50,000 confirmed fraud decisions.
- **KPI alert**: an alert on a business metric (key performance indicator), such as approval rate or click-through
  rate.
- **Data validation, schema, volume, freshness**: checks that the data has the expected columns and types (schema),
  roughly the expected number of rows (volume), and recent timestamps (freshness), using tools such as Great
  Expectations or TFX Data Validation (Section 24).
- **Better by margin**: the challenger must beat the champion by more than noise, such as at least 0.3 AUC points
  with a confidence interval that excludes zero.
- **Watch canary KPIs, auto-rollback**: the canary's business metrics (KPIs) are compared with the champion's. If
  they fall below thresholds, traffic returns to the champion automatically.

**Core ideas.**
- **Pick the trigger by how the model decays.**
  - **Schedule** is simple and predictable. Use it when decay is steady.
  - **Data-volume** triggers fit when labels arrive in bursts.
  - **Drift** triggers save compute when the world changes rarely but suddenly. They need a reliable drift signal
    (Lecture 234).
  - Many teams combine a weekly schedule with drift triggers in between.
- **Champion-challenger is mandatory.** Never promote just because training finished. Compare on the same fixed
  holdout, plus a fresh recent window, and on critical slices.
- **Validate data before training.** Most automated-retraining incidents are bad data: a broken upstream join, a
  half-loaded day, or labels missing for recent rows.
- **Watch for label delay.** Fraud labels may arrive 30–90 days late. Train on windows with mature labels, and judge
  recent performance with proxy metrics.
- **Feedback loops.** A model trained on outcomes it influenced (for example, a recommender trained on clicks of items
  it chose to show) reinforces itself. Keep a small share of exploration traffic or randomized holdouts.
- **Cost.** Retraining nightly when weekly suffices multiplies GPU spend for no gain. Measure the accuracy gained per
  retrain and tune the schedule.

**Example: the retrain that shipped a broken model.** An e-commerce team's nightly retraining succeeded technically
one night, but an upstream job had loaded only 4 hours of the previous day's clicks. The model, trained on night-time
traffic, ranked items poorly for daytime shoppers, and revenue per session dropped 6% before anyone noticed. They
added volume and freshness validation (stop if rows are under 80% of the 7-day median) and a champion-challenger
comparison on a fixed holdout. The next bad load stopped the pipeline with an alert instead.

**Senior / FAANG best practice.** Combine a schedule with data and drift triggers, matched to how the model decays.
Validate data before training, require the challenger to beat the champion by a significant margin on fixed and
recent holdouts and on slices, and canary with auto-rollback. Account for label delay and feedback loops, and set
retraining frequency from measured accuracy gain per GPU-hour.

---

## Lecture 234 — Automating drift retraining with Kubeflow

**Why it matters.** A drift alert that only pages a human means retraining waits for someone's free afternoon. Wiring
the drift check into a Kubeflow pipeline makes the response automatic and consistent, while keeping the safeguards of
Lecture 233.

**In plain words.** It's a thermostat for your model: it checks the temperature on a schedule, and when it's drifted
too far from the setting, it switches the heating on by itself, while still keeping a safety limit.

**Architecture: two ways to trigger drift retraining.**

```mermaid
flowchart TB
  subgraph POLL["Option A: scheduled check"]
    RR["KFP recurring run<br/>cron every 6 hours"] --> DC["drift_check step<br/>PSI per feature"]
    DC --> IF1{"dsl.If max PSI<br/>above 0.25"}
    IF1 -->|"true"| RT["retrain, evaluate,<br/>compare, register"]
  end
  subgraph PUSH["Option B: alert-driven"]
    PM["Prometheus drift metric"] --> AM["Alertmanager rule"]
    AM --> WH["Webhook service<br/>dedupe, rate limit"]
    WH -->|"KFP API create run"| RT2["retraining pipeline run"]
  end
```

**How to read it:** in option A, a recurring Kubeflow run executes every 6 hours. Its first step computes PSI for
each feature, and a condition runs the retraining steps only when drift is high. In option B, a drift metric is
already exported to Prometheus. An Alertmanager rule fires a webhook, and a small service removes duplicates, limits
how often it acts, and starts a retraining run through the Kubeflow API.

**Terms in this diagram.**
- **KFP recurring run, cron**: a Kubeflow Pipelines schedule that starts a pipeline repeatedly. KFP cron expressions
  have six fields, starting with seconds, so `0 0 */6 * * *` means "every 6 hours".
- **drift_check step, PSI per feature**: a pipeline step computing the **Population Stability Index** for each
  feature between a reference window and the current window (Section 17).
- **dsl.If max PSI above 0.25**: a condition on the largest PSI. Above 0.25 is the usual "major shift" threshold.
- **Prometheus, Alertmanager**: Prometheus stores metrics, and Alertmanager routes alerts to receivers such as
  webhooks or PagerDuty (Section 16).
- **Webhook service, dedupe, rate limit**: a small HTTP service that receives the alert. **Dedupe** ignores repeats of
  the same alert, and a **rate limit** allows at most one retraining run per model in a set time.
- **KFP API create run**: the Kubeflow Pipelines REST or SDK call that starts a run (`kfp.Client().create_run_from_...`).

**Core ideas.**
- **Option A is simpler**: no extra service, and the drift calculation is versioned with the pipeline. Its delay is
  up to one schedule interval.
- **Option B reacts faster** and reuses existing monitoring, but adds a service that must be secured and rate-limited,
  so a flapping alert doesn't launch 50 training runs.
- **Limit concurrency.** Set the recurring run's `max_concurrency=1`, and skip retraining if one is already running for
  that model.
- **Drift isn't always a reason to retrain.**
  - A shift in an unimportant feature doesn't matter. Weight PSI by feature importance, or require drift on a top
    feature plus a drop in a proxy metric.
  - Seasonal shifts that the model already handles are expected. Compare with the same period last year.
- **Retraining isn't always the fix.** If drift comes from a broken upstream pipeline (a unit change, a null-filled
  column), retraining learns the bug. Data validation must run first, and some drift patterns (a feature suddenly 100%
  null) should page a human instead.

```python
import kfp
client = kfp.Client(host="http://localhost:8080")
exp = client.create_experiment("fraud-ct")
client.create_recurring_run(
    experiment_id=exp.experiment_id, job_name="fraud-drift-every-6h",
    pipeline_package_path="drift_retrain.yaml", cron_expression="0 0 */6 * * *",
    max_concurrency=1, no_catchup=True, params={"psi_threshold": 0.25, "min_gain": 0.003})
```

In the code, `no_catchup=True` means that if the schedule was paused, KFP doesn't launch all the missed runs at once
when it resumes. `params` are the pipeline's parameters for every scheduled run.

**Example: the flapping alert.** A team wired an Alertmanager drift alert straight to the KFP API. During a regional
outage, the alert fired and resolved 40 times in an hour, launching 40 training runs that filled the GPU quota and
blocked other teams. They added a webhook service that dedupes by model, allows one run per model per 12 hours, and
skips when a run is already active, and they made the alert require 30 minutes of sustained drift.

**Senior / FAANG best practice.** Start with a scheduled drift check inside the pipeline. Move to alert-driven
triggers only with deduplication, rate limits, and concurrency limits. Weight drift by feature importance, validate
data before retraining, route data-quality failures to humans, and keep the champion-challenger gate on every
automated run.

---

## Lecture 235 — Feature store integration in pipelines

**Why it matters.** The most common silent bug in ML is a mismatch between training features and serving features:
training used a feature computed with future data, or serving computes it differently. Feature stores fix this, but
only if pipelines use them the right way.

**In plain words.** A feature store is like a shared pantry with labeled jars and dates. The training kitchen takes
exactly what was in the jar on each historical date, and the serving kitchen takes today's jar from the same shelf,
so both cook with the same ingredients.

**Architecture: feature store in training and serving.**

```mermaid
flowchart LR
  SRC[("Source tables + streams")] --> FV["Feature views<br/>definitions in Git"]
  FV --> OFF[("Offline store<br/>warehouse, history")]
  FV -->|"materialize"| ON[("Online store<br/>Redis, DynamoDB")]
  LBL["Label events<br/>entity ID + timestamp"] --> PIT["Point-in-time join<br/>get_historical_features"]
  OFF --> PIT
  PIT --> TRAIN["Training step"]
  TRAIN --> REGV["Model version records<br/>feature service fraud_v3"]
  ON --> SERVE["Serving<br/>get_online_features fraud_v3"]
  REGV -.-> SERVE
```

**How to read it:** feature definitions live in Git and compute from source tables and streams. Their history goes to
an offline store in the data warehouse, and the latest values are copied (materialized) to a low-latency online
store. For training, label events with an entity ID and a timestamp are joined to the offline store "as of" each
timestamp. The model version records which feature service it used, and serving fetches that same feature service
from the online store.

**Terms in this diagram.**
- **Feature views**: named groups of features with their source, entity key, and freshness, defined in code (for
  example in Feast, an open-source feature store).
- **Offline store**: the historical feature values, kept in a warehouse such as BigQuery, Snowflake, or a data lake.
- **Materialize**: copying the latest feature values from the offline computation to the online store.
- **Online store, Redis, DynamoDB**: a key-value database answering "features for customer 123" in milliseconds.
  Redis is an in-memory store, and DynamoDB is AWS's managed key-value database.
- **Label events, entity ID + timestamp**: the training examples: which entity (customer, card, item), when, and the
  known outcome.
- **Point-in-time join, get_historical_features**: for each label event, fetch each feature's value as it was at that
  moment, never later. In Feast this is `get_historical_features`.
- **Feature service fraud_v3**: a named, versioned list of features a model uses. Training and serving both reference
  it, so they can't drift apart.
- **get_online_features**: the Feast call that serving uses to fetch current values.

**Core ideas.**
- **Point-in-time correctness.** A plain join on customer ID uses today's feature values for last year's labels,
  which leaks the future: training accuracy looks great, and production is worse. Always join "as of" the label time.
- **One definition, two paths.** The same feature view computes training history and serving values. Never
  re-implement a feature in serving code.
- **Version feature services.** Changing a feature's logic creates a new feature view version and a new feature
  service (`fraud_v4`). Running models keep using `fraud_v3` until retrained.
- **Materialization is a pipeline step.** Schedule `feast materialize-incremental` (or the managed equivalent), and
  monitor online feature freshness. A stale online store is training-serving skew.
- **Log served features.** Logging the exact features served with each prediction gives perfect training data later
  and makes skew measurable.

```python
import pandas as pd
from feast import FeatureStore

store = FeatureStore(repo_path="feature_repo")
labels = pd.read_parquet("s3://acme-ml/fraud/labels/2026-10.parquet")   # card_id, event_timestamp, is_fraud
training_df = store.get_historical_features(
    entity_df=labels, features=store.get_feature_service("fraud_v3")).to_df()

online = store.get_online_features(
    features=store.get_feature_service("fraud_v3"), entity_rows=[{"card_id": 4242}]).to_dict()
```

In the code, `entity_df` must have the entity key (`card_id`) and an `event_timestamp` column, which Feast uses for
the point-in-time join. Passing the feature service, rather than a list of feature names, makes training and serving
use the same set. `to_df()` returns a pandas DataFrame of labels with their features. `get_online_features` returns
current values for one card from the online store.

**Example: the 0.99 AUC that wasn't.** A fraud model scored 0.99 AUC offline and 0.81 in production. The training
query joined labels to a "chargebacks in the last 30 days" feature computed today, so it included the very chargeback
being predicted. Switching to Feast's point-in-time join dropped offline AUC to 0.88, which matched production within
a point, and the team could finally trust offline evaluation.

**Senior / FAANG best practice.** Build training data only through point-in-time joins, define each feature once for
both paths, and version feature services and record them in the registry. Schedule and monitor materialization, log
served features, and measure training-serving skew as a first-class metric.

---

## Lecture 236 — Governance in enterprise MLOps

**Why it matters.** Regulators and boards now ask how AI decisions are controlled. The EU AI Act, US banking model
risk guidance (SR 11-7), the NIST AI Risk Management Framework, and ISO/IEC 42001 all expect documented, risk-based
controls. Good governance is also how a platform says yes quickly to low-risk models while being careful with
high-risk ones.

**In plain words.** Governance is like building codes: a garden shed needs almost no paperwork, a house needs
inspections, and a hospital needs much more. Matching the paperwork to the risk keeps small projects fast and big
ones safe.

**Architecture: risk-tiered governance.**

```mermaid
flowchart TB
  INTAKE["Model intake form<br/>purpose, users, data, impact"] --> TIER{"Risk tier"}
  TIER -->|"low: internal tooling"| L["Automated checks only<br/>model card, owner"]
  TIER -->|"medium: customer-facing"| M["Peer review + fairness slices<br/>monitoring plan"]
  TIER -->|"high: credit, hiring, medical"| H["Independent validation<br/>explainability, human oversight,<br/>regulator documentation"]
  L & M & H --> GATE["Registry approval gate<br/>evidence attached"]
  GATE --> RUN["Production + monitoring<br/>tier-based review cadence"]
  RUN -->|"material change"| INTAKE
```

**How to read it:** every model starts with an intake form describing its purpose, users, data, and possible impact.
That decides its risk tier. Low-risk models need only automated checks and a model card. Medium-risk ones add peer
review, fairness checks, and a monitoring plan. High-risk ones add independent validation, explainability, human
oversight, and regulator documentation. All tiers pass through the same registry approval gate with evidence
attached. Production models are reviewed on a schedule set by their tier, and any material change sends the model
back to intake.

**Terms in this diagram.**
- **Model intake form**: a short questionnaire completed when a model project starts.
- **Risk tier**: a level, such as low, medium, or high, set by the potential harm to people or the business.
- **Fairness slices**: metrics computed separately per group (such as age band or region) to find unequal error rates.
- **Monitoring plan**: which metrics, thresholds, and owners will watch the model in production.
- **Independent validation**: review by a team that didn't build the model, as banks' model risk management
  functions do under SR 11-7.
- **Explainability**: methods that show why a model made a decision, such as SHAP values (per-feature contributions)
  or reason codes for credit decisions.
- **Human oversight**: a person can review, override, or stop the model's decisions.
- **Regulator documentation**: the technical documentation that laws such as the EU AI Act require for high-risk
  systems.
- **Tier-based review cadence**: how often the model is re-reviewed, such as yearly for low and quarterly for high.
- **Material change**: a change large enough to need re-review, such as new data sources, a new use, or a new model
  type.

**Core ideas.**
- **Frameworks to know.**
  - **EU AI Act**: classifies AI systems by risk (prohibited, high-risk, limited, minimal) with obligations phased in
    from 2025 onward. High-risk systems need risk management, data governance, technical documentation, logging,
    human oversight, and accuracy and robustness controls. Check the current application dates, since timelines have
    been revised.
  - **SR 11-7**: US Federal Reserve guidance on model risk management, requiring model inventory, independent
    validation, and ongoing monitoring.
  - **NIST AI RMF**: a voluntary framework organized as Govern, Map, Measure, Manage.
  - **ISO/IEC 42001**: a certifiable AI management system standard, similar in style to ISO 27001 for security.
- **Governance as code.** Encode tier rules in the platform: the registry gate checks that the evidence the tier
  needs (model card, fairness report, validator sign-off) is attached before approval is possible.
- **Model inventory.** One list of every production model, its owner, tier, and last review date, generated from the
  registry, not maintained by hand.
- **Proportionality.** Low-risk models flow through automated checks in hours. Reserve human review for the models
  that need it, or teams route around governance.

```python
TIER_REQUIREMENTS = {
    "low":    {"model_card"},
    "medium": {"model_card", "fairness_report", "monitoring_plan", "peer_review"},
    "high":   {"model_card", "fairness_report", "monitoring_plan", "peer_review",
               "independent_validation", "explainability_report", "human_oversight_plan"},
}

def can_approve(tier: str, evidence: set[str]) -> tuple[bool, set[str]]:
    missing = TIER_REQUIREMENTS[tier] - evidence
    return (not missing, missing)

print(can_approve("high", {"model_card", "fairness_report", "monitoring_plan", "peer_review"}))
# (False, {'independent_validation', 'explainability_report', 'human_oversight_plan'})
```

In the code, each tier lists the evidence that must be attached to the registry version before approval.
`can_approve` returns whether approval is allowed and what's missing, which the registry UI or CI job shows to the
model owner.

**Example: governance that sped things up.** A bank's model risk team reviewed every model by hand, including
internal ticket-routing classifiers, with a 4-month queue. Introducing tiers, with automated checks for low-risk
internal models, moved 60% of models to a same-week path. The validation team focused on the high-risk credit and
anti-money-laundering models, and their review depth improved.

**Senior / FAANG best practice.** Classify every model by risk at intake, encode each tier's required evidence as
checks in the registry gate, and generate the model inventory from the registry. Map tiers to the frameworks you're
subject to (EU AI Act, SR 11-7, NIST AI RMF, ISO/IEC 42001). Keep low-risk paths fast and automated, and require
re-review on material change.

---

## Lecture 237 — Audit trails and compliance logging

**Why it matters.** When something goes wrong, or an auditor arrives, you must prove who did what, when, and with what
authority. Logs that can be edited, are scattered across tools, or expire in 30 days prove nothing.

**In plain words.** An audit trail is like a bank's ledger written in ink with numbered pages. You can add entries,
but you can't erase or tear out a page without it being obvious.

**Architecture: tamper-evident audit logging.**

```mermaid
flowchart LR
  REG["Registry events<br/>register, approve, alias move"] --> BUS["Event stream<br/>Kafka or cloud bus"]
  K8SA["Kubernetes audit log"] --> BUS
  CT["CloudTrail / Cloud Audit Logs"] --> BUS
  PIPE2["Pipeline runs<br/>who started, parameters"] --> BUS
  BUS --> CHAIN["Audit writer<br/>hash chain per record"]
  CHAIN --> WORM[("Object storage with<br/>Object Lock, 7-year retention")]
  CHAIN --> SIEM["SIEM<br/>search + alerts"]
  WORM --> VERIFY["Daily verifier<br/>recompute chain"]
```

**How to read it:** registry events, the Kubernetes audit log, cloud API audit logs, and pipeline run records all
flow into one event stream. An audit writer links each record to the previous one with a hash, and writes them to
object storage locked against deletion for 7 years, and also to a security search system. A daily job recomputes
the hash chain to detect any tampering.

**Terms in this diagram.**
- **Registry events**: records of registration, approval, and alias moves from the model registry.
- **Kubernetes audit log**: the API server's record of every request: who, what resource, and when (Section 18).
- **CloudTrail / Cloud Audit Logs**: AWS's and Google Cloud's logs of every cloud API call. Azure's equivalent is the
  Activity Log.
- **Event stream, Kafka or cloud bus**: a durable message stream, such as Apache Kafka, Amazon Kinesis, or Google
  Pub/Sub (Section 24).
- **Hash chain**: each record includes the hash of the previous record, so changing or deleting any record breaks
  every hash after it.
- **Object Lock**: an S3 feature (with equivalents in Google Cloud and Azure) that makes objects **WORM**, write
  once, read many: they can't be changed or deleted until the retention date, even by administrators in compliance
  mode.
- **SIEM**: a security information and event management system, such as Splunk or Google Security Operations, used to
  search logs and raise alerts.
- **Daily verifier**: a job that re-reads the records and recomputes the chain, alerting if anything doesn't match.

**Core ideas.**
- **What to log.** Actor (human or service identity), action, target (model name and version), before and after
  values, time, source IP, the reason or ticket, and a link to the evidence (evaluation report, approval).
- **Make it tamper-evident.** Hash chains show changes. Object Lock stops deletion. Writing to a separate account
  that the platform team can't administer stops insiders from covering their tracks.
- **Retention follows regulation**, such as 7 years for many financial records, and the EU AI Act's logging duties
  for high-risk systems. Prediction logs may also need to be kept to explain individual decisions.
- **Prediction-level audit.** For regulated decisions, log the model version, feature values, output, and
  explanation for each decision, so you can answer "why was this customer declined?" years later. Mind privacy: hash
  or tokenize personal identifiers (Section 38).
- **Make it searchable.** An audit log nobody can query is useless. Ship it to a SIEM or warehouse with standard
  queries, such as "all alias moves for model X".

```python
import hashlib, json, time

def append(log: list, actor: str, action: str, target: str, detail: dict) -> dict:
    prev = log[-1]["hash"] if log else "0" * 64
    rec = {"ts": time.time(), "actor": actor, "action": action, "target": target, "detail": detail, "prev": prev}
    rec["hash"] = hashlib.sha256(json.dumps(rec, sort_keys=True).encode()).hexdigest()
    log.append(rec)
    return rec

def verify(log: list) -> int | None:
    prev = "0" * 64
    for i, rec in enumerate(log):
        body = {k: v for k, v in rec.items() if k != "hash"}
        if rec["prev"] != prev or hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest() != rec["hash"]:
            return i                        # first broken record
        prev = rec["hash"]
    return None

log = []
append(log, "ci-promoter@acme", "alias_move", "fraud-detector", {"alias": "champion", "from": 11, "to": 12})
append(log, "alice@acme", "approve", "fraud-detector/12", {"ticket": "MRM-4411"})
log[0]["detail"]["to"] = 13                 # tampering
print(verify(log))                          # 0
```

In the code, each record stores the previous record's hash in `prev`, and its own hash covers all its fields,
including `prev`. `json.dumps(..., sort_keys=True)` gives a stable byte form to hash. `verify` recomputes each hash
and returns the index of the first record that doesn't match. Changing record 0 after the fact is detected
immediately.

**Example: the alias that moved at 2 a.m.** A fraud model's production alias was moved to an untested version at
2 a.m., and fraud losses rose by morning. The registry's own history had been edited, but the hash-chained audit log
in a separate, Object-Locked account showed the move came from a contractor's personal token, not the CI role. The
team revoked personal permissions for alias moves, and the auditors accepted the separate log as evidence.

**Senior / FAANG best practice.** Send registry, pipeline, Kubernetes, and cloud audit events into one stream, chain
them, and write them to WORM storage in a separate security account with regulatory retention. Log actor, action,
target, before and after, reason, and evidence links. Verify the chain daily, keep it searchable in a SIEM, and log
prediction-level details for regulated decisions with personal data protected.

---

## Lecture 238 — Lab: automate drift retraining with Kubeflow

**Goal:** build a Kubeflow pipeline that checks drift with PSI, and only when drift is high, retrains a challenger,
compares it with the champion, and promotes it if it's better. Schedule it as a recurring run, and test it with
stable and drifted data.

**What you're building:** a `drift_retrain` pipeline with five components (drift check, train, evaluate on recent
data, gain, and promote), run on the kind cluster from Section 33's lab, plus a recurring run.

```mermaid
flowchart LR
  D["drift_check<br/>PSI per feature, shift param"] --> C1{"max PSI<br/>above threshold"}
  C1 -->|"true"| RT["retrain challenger<br/>on recent window"]
  C1 -->|"true"| EC["evaluate champion<br/>on recent window"]
  RT --> EN["evaluate challenger"]
  EN --> C2{"challenger AUC minus<br/>champion AUC at least min_gain"}
  EC --> C2
  C2 -->|"true"| PR["promote<br/>write new champion record"]
```

**How to read the diagram:** `drift_check` generates a reference window and a current window of synthetic data.
A `shift` parameter controls how much the current window has drifted, and the step computes PSI per feature. When
the largest PSI is above the threshold, the pipeline trains a challenger on the recent window and evaluates both the
old champion (trained on the reference window) and the challenger on held-out recent data. If the challenger's AUC
beats the champion's by at least `min_gain`, the `promote` step writes a new champion record.

**Prerequisites:** the kind cluster and Kubeflow Pipelines from [Lecture 231](s33_enterprise_mlops.md), port-forward
to `localhost:8080` running, and `pip install "kfp>=2.9,<3"`.

### Step 1 — Components

```python
# drift_retrain.py
from kfp import dsl, compiler

IMG = "python:3.11-slim"
PKGS = ["scikit-learn==1.5.2", "numpy==2.1.3"]

@dsl.component(base_image=IMG, packages_to_install=PKGS)
def drift_check(shift: float, ref: dsl.Output[dsl.Dataset], cur: dsl.Output[dsl.Dataset],
                report: dsl.Output[dsl.Metrics]) -> float:
    import numpy as np
    rng = np.random.default_rng(0)
    def make(n, s):
        X = rng.normal(0, 1, (n, 5)); X[:, 0] += s; X[:, 1] *= 1 + s
        y = (X[:, 0] + (0.5 - 1.5 * s) * X[:, 2] + rng.normal(0, 0.5, n) > s).astype(int)
        return np.column_stack([X, y])
    R, C = make(20000, 0.0), make(20000, shift)
    np.save(ref.path + ".npy", R); np.save(cur.path + ".npy", C)
    def psi(a, b, bins=10):
        edges = np.quantile(a, np.linspace(0, 1, bins + 1)[1:-1])
        pa = np.bincount(np.searchsorted(edges, a), minlength=bins) / len(a)
        pb = np.bincount(np.searchsorted(edges, b), minlength=bins) / len(b)
        pa, pb = np.clip(pa, 1e-4, None), np.clip(pb, 1e-4, None)
        return float(np.sum((pb - pa) * np.log(pb / pa)))
    scores = [psi(R[:, j], C[:, j]) for j in range(5)]
    for j, s in enumerate(scores):
        report.log_metric(f"psi_f{j}", round(s, 4))
    return max(scores)

@dsl.component(base_image=IMG, packages_to_install=PKGS)
def train_on(data: dsl.Input[dsl.Dataset], model: dsl.Output[dsl.Model]):
    import pickle, numpy as np
    from sklearn.ensemble import HistGradientBoostingClassifier
    D = np.load(data.path + ".npy"); tr = D[: len(D) // 2]
    clf = HistGradientBoostingClassifier(max_iter=200).fit(tr[:, :-1], tr[:, -1])
    with open(model.path, "wb") as f:
        pickle.dump(clf, f)

@dsl.component(base_image=IMG, packages_to_install=PKGS)
def auc_on_recent(model: dsl.Input[dsl.Model], data: dsl.Input[dsl.Dataset], m: dsl.Output[dsl.Metrics]) -> float:
    import pickle, numpy as np
    from sklearn.metrics import roc_auc_score
    D = np.load(data.path + ".npy"); te = D[len(D) // 2:]
    with open(model.path, "rb") as f:
        clf = pickle.load(f)
    auc = float(roc_auc_score(te[:, -1], clf.predict_proba(te[:, :-1])[:, 1]))
    m.log_metric("auc", round(auc, 4))
    return auc

@dsl.component(base_image=IMG)
def gain(champ_auc: float, chall_auc: float) -> float:
    return chall_auc - champ_auc

@dsl.component(base_image=IMG)
def promote(challenger: dsl.Input[dsl.Model], champ_auc: float, chall_auc: float, record: dsl.Output[dsl.Artifact]):
    import json
    with open(record.path, "w") as f:
        json.dump({"new_champion": challenger.uri, "old_auc": champ_auc, "new_auc": chall_auc}, f, indent=2)
    print(f"promoted: AUC {champ_auc:.4f} -> {chall_auc:.4f}")
```

In the code, the synthetic data has five features. `shift` moves feature 0's mean and widens feature 1, which PSI
can see. It also changes how feature 2 relates to the label: at `shift=1.0` its effect flips from +0.5 to −1.0. That
change in the relationship (concept drift) is what makes a model trained on the reference window worse on recent
data, and PSI on feature 2 alone can't see it.
The `psi` function uses 10 quantile bins from the reference window and floors empty bins at 0.0001, as in Section 17.
`np.save` appends `.npy` to the artifact path, which is why the readers add it too. Each training or evaluation step
uses the first half of a window for training and the second half for testing.

### Step 2 — Pipeline

```python
@dsl.pipeline(name="drift-retrain")
def drift_retrain(shift: float = 0.0, psi_threshold: float = 0.25, min_gain: float = 0.003):
    d = drift_check(shift=shift)
    with dsl.If(d.outputs["Output"] > psi_threshold, name="drifted"):
        champion = train_on(data=d.outputs["ref"]).set_display_name("champion (reference window)")
        challenger = train_on(data=d.outputs["cur"]).set_display_name("challenger (recent window)")
        ec = auc_on_recent(model=champion.outputs["model"], data=d.outputs["cur"]).set_display_name("eval champion")
        en = auc_on_recent(model=challenger.outputs["model"], data=d.outputs["cur"]).set_display_name("eval challenger")
        g = gain(champ_auc=ec.outputs["Output"], chall_auc=en.outputs["Output"])
        with dsl.If(g.output >= min_gain, name="beats-champion"):
            promote(challenger=challenger.outputs["model"], champ_auc=ec.outputs["Output"],
                    chall_auc=en.outputs["Output"])

if __name__ == "__main__":
    compiler.Compiler().compile(drift_retrain, "drift_retrain.yaml")
```

In a real platform the champion would be loaded from the registry by alias instead of retrained here. The lab trains
it on the reference window so the pipeline is self-contained. Nested `dsl.If` blocks make promotion depend on both
conditions. KFP conditions can compare an output with a value, but can't do arithmetic on outputs, so the small
`gain` component computes the AUC difference and its single output (`g.output`) feeds the inner condition.

### Step 3 — Run with stable and drifted data, then schedule

```python
# run_drift.py
import kfp
client = kfp.Client(host="http://localhost:8080")
exp = client.create_experiment("lab-238")
for shift in (0.0, 1.0):
    r = client.create_run_from_pipeline_package("drift_retrain.yaml", arguments={"shift": shift},
                                                experiment_id=exp.experiment_id, run_name=f"shift={shift}")
    print("shift", shift, "->", client.wait_for_run_completion(r.run_id, timeout=1800).state)

client.create_recurring_run(experiment_id=exp.experiment_id, job_name="drift-every-6h",
                            pipeline_package_path="drift_retrain.yaml", cron_expression="0 0 */6 * * *",
                            max_concurrency=1, no_catchup=True, params={"shift": 0.0})
```

```bash
python3 drift_retrain.py && python3 run_drift.py
```

### Step 4 — Inspect and extend

- In the `shift=0.0` run, `drift_check` shows all PSI values under 0.01, and the `drifted` branch is skipped.
- In the `shift=1.0` run, `psi_f0` and `psi_f1` are well above 0.25, both models train, and `promote` runs because
  the challenger beats the champion on recent data by about 0.3 AUC.
- In the UI's Recurring Runs page, the `drift-every-6h` schedule is listed. Disable it when you finish
  (`client.disable_recurring_run(...)`).
- Run once more with `shift=0.3`: max PSI is about 0.09, under the threshold, so nothing retrains, yet the champion
  has quietly lost about 4 AUC points. This is why Lecture 233 pairs drift triggers with a schedule and with
  performance monitoring on labeled data.
- Extension: add a data validation step before `drift_check` that fails the run if a feature is more than 50% null,
  and confirm that it stops before any retraining.

**Expected results:**
- `shift=0.0`: max PSI under 0.01, only `drift_check` runs, run state `SUCCEEDED`.
- `shift=1.0`: PSI about 0.95 for feature 0 and 0.49 for feature 1, and under 0.01 for the rest. The champion's AUC
  on recent data falls to about 0.64, the challenger reaches about 0.95, and `promote` writes a record with both
  values.
- `shift=0.3`: max PSI about 0.09, no retraining, champion AUC about 0.90 against 0.94 before drift.
- Increasing `min_gain` to 0.5 makes the inner condition skip `promote` even when drift is detected.
- The recurring run appears with a 6-hour cron schedule and concurrency 1.

---

## FAANG deep-dive notes

**How big tech does it.** Large platforms (Uber's Michelangelo, Meta's FBLearner, Google's TFX-based systems,
LinkedIn's Pro-ML) treat continuous training as standard. Pipelines run on schedules or data arrival, validate data
first (TFX Data Validation was built for this), compare against the serving model on fixed and recent data, and push
only after automated and, for sensitive models, human review. Feature platforms (Uber's Palette, Airbnb's Chronon,
Meta's feature store) make point-in-time training data the default. Registries are the system of record, with lineage
enforced, and audit logs feed company-wide compliance systems.

**Staff review questions.**
- What triggers retraining for this model, and how was the frequency chosen?
- What stops an automated run from shipping a worse model or training on broken data?
- Are training features built by point-in-time joins, and is training-serving skew measured?
- What's this model's risk tier, and is the required evidence enforced by the registry gate?
- Who can move the production alias, and where's that recorded, tamper-evidently?
- Can you reproduce the model that served a decision two years ago?

**Interview question.** "Design continuous training and governance for 200 models in a regulated company."

**Typical system-design prompt:** *Design continuous training, governance, and audit for 200 production models at a
bank: 30 high-risk (credit, anti-money-laundering), 70 medium, 100 low.*

**1. Clarify first:** How fast do these models decay? How long until labels arrive? What regulations apply, and what
retention? What's the current tooling? How many validators are there?

**2. Back-of-envelope sizing:**
- Retraining: 100 low-risk weekly, 70 medium biweekly, 30 high-risk quarterly (each needing validation) = ~100 + 35 + 2.5
  ≈ 140 training runs per week, and about 10 human validations per month for the high-risk tier.
- Audit volume: ~140 runs × ~20 events each + deployments + Kubernetes audit filtered to ML namespaces ≈ tens of
  thousands of events per week, which is small. Prediction-level logs for high-risk models dominate: 5 million
  decisions per day × 2 KB = 10 GB per day, ~25 TB over 7 years in compressed WORM storage.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Trigger | Fixed schedule | Drift-driven | Schedule plus drift checks. Drift-only needs a reliable signal |
| Promotion | Automatic when better | Human approval | Automatic for low tier with canary. Human for high tier |
| Training data | Ad-hoc SQL joins | Feature store point-in-time | Feature store for anything in production |
| Audit | Tool-native logs | Central hash-chained WORM | Central WORM in a separate account |
| Governance | Same process for all | Risk-tiered | Tiered, encoded as registry gate checks |

**4. Follow-up questions with crisp answers:**
- *Labels arrive 60 days late. How do you retrain?* Train on windows with mature labels, use proxy metrics and drift to
  decide urgency, and backtest on the newest mature data.
- *How do you stop a flapping drift alert from launching dozens of runs?* Dedupe, rate-limit per model, and limit
  concurrency to one.
- *How do you prove a log wasn't edited?* Hash chain verified daily, plus Object Lock in a separate account.
- *What if the auditor asks why one customer was declined?* Look up the prediction log by decision ID: model version,
  features, output, and reason codes, then the version's lineage in the registry.

**Debug this (common onsite question):** "Offline AUC improved with each retrain, but production approval quality
declined."
1. Compare the training features with the logged served features for the same requests: two features differ.
2. Those features are computed in serving code that was changed, while training uses the old warehouse logic.
3. Training-serving skew grew with each release.
4. Fix: move both features into the feature store as one definition, retrain on logged features, and add a skew
   monitor comparing served and recomputed values.

The lesson: offline improvement means nothing if training and serving features differ, so measure skew directly.

**5. What separates senior from staff answers:** a senior engineer builds a retraining pipeline with a drift trigger.
A staff engineer designs the controls around it: data validation, champion-challenger with slices, label delay,
feedback loops, risk-tiered approvals encoded in the registry, point-in-time features, and tamper-evident audit, and
sizes retraining frequency against measured gains.

**Red flags:**
- Automatic promotion without a champion-challenger comparison.
- Training data built with plain joins on entity ID.
- Drift alerts wired directly to training without dedupe or rate limits.
- Registry metadata that's optional, or data locations that point at mutable tables.
- The same manual review for every model regardless of risk.
- Audit logs editable by the same administrators whose actions they record.

---

## Quiz

<details><summary>1. Why must registry versions record a data snapshot rather than a table path?</summary>
A path points to data that can be overwritten. A snapshot (a dated copy or a table version) is immutable, so you can
reproduce or explain the model years later.
</details>

<details><summary>2. Name three continuous training triggers and when each fits.</summary>
A schedule for steady decay. A new-labeled-data volume for bursty label arrival. Drift or KPI alerts for rare,
sudden changes, as long as the drift signal is reliable.
</details>

<details><summary>3. What must happen before an automatically retrained model is promoted?</summary>
Data validation, then a champion-challenger comparison on the same holdout and recent data, including critical
slices, with a significant margin. Then a canary with auto-rollback, and for higher-risk tiers, human approval.
</details>

<details><summary>4. Why is a plain join of labels to features by customer ID dangerous?</summary>
It uses current feature values for past labels, leaking future information. Offline metrics look much better than
production. Point-in-time joins fetch each feature as it was at the label's timestamp.
</details>

<details><summary>5. What does a feature service give you that a list of feature names doesn't?</summary>
A named, versioned set that both training and serving reference, recorded in the registry, so the model can't be
served with different features from those it was trained on.
</details>

<details><summary>6. How does a hash chain make an audit log tamper-evident?</summary>
Each record includes the hash of the previous record, and its own hash covers its content. Changing or deleting a
record breaks every later hash, which a verifier detects.
</details>

<details><summary>7. Why tier governance by risk?</summary>
To match controls to potential harm. Low-risk models get fast automated checks, and reviewers can focus on high-risk
models. Uniform heavy review creates queues that teams route around.
</details>

<details><summary>8. A drift alert flaps 40 times in an hour. What prevents 40 training runs?</summary>
A webhook service that deduplicates and rate-limits per model, a concurrency limit of one run per model, and an alert
that requires sustained drift.
</details>

## Failure modes
- Automated retraining promoting a worse model because no champion comparison exists.
- Retraining on a half-loaded or broken day of data.
- Drift caused by an upstream bug being "fixed" by retraining on the bug.
- Point-in-time leakage making offline metrics far better than production.
- Training-serving skew from features implemented twice.
- Stale online features from a failed materialization job.
- Registry versions without lineage, or with data locations that no longer exist.
- Production alias moves by personal tokens, without approval records.
- Audit logs that can be edited or that expire before the regulatory retention period.
- Governance so slow for low-risk models that teams bypass the platform.

## Checklist
- [ ] Registration enforces required lineage metadata, and versions are immutable and signed
- [ ] Production alias moves need an approval record and a privileged CI role
- [ ] Retraining triggers match how each model decays, with data validation first
- [ ] Every automated run compares challenger and champion on fixed and recent holdouts and slices
- [ ] Drift-triggered retraining has dedupe, rate limits, and concurrency limits
- [ ] Training data comes from point-in-time joins via versioned feature services
- [ ] Models have risk tiers, and the registry gate checks each tier's evidence
- [ ] Audit events are hash-chained, in WORM storage, in a separate account, and searchable
- [ ] You built and scheduled a Kubeflow drift-retraining pipeline with a champion gate
