# Part VIII — Training at Scale, Enterprise MLOps and Optimization (Sections 31–36, lectures 211–252)

How to train models across hundreds of GPUs, run ML as a governed enterprise platform, and make models cheaper to
train and serve without losing quality.

| § | Section | You will be able to | Exercise |
|---|---|---|---|
| 31 | [Large-Scale Training Foundations](s31_large_scale_training.md) | Combine data, tensor, pipeline, and expert parallelism, size clusters with 6·N·D, tune NCCL, and run multi-node `torchrun` | — |
| 32 | [Advanced Large-Scale Training](s32_advanced_large_scale_training.md) | Choose ZeRO and FSDP2 settings, use Flash Attention, checkpoint asynchronously at the right interval, and run elastic jobs past 1,000 GPUs | [`s32_checkpoint_shards.py`](../exercises/s32_checkpoint_shards.py) |
| 33 | [Enterprise MLOps Foundations](s33_enterprise_mlops.md) | Design a paved-path ML platform, run Kubeflow and MLflow at scale, and build pipelines on SageMaker, Vertex AI, and Azure ML | — |
| 34 | [Advanced Enterprise MLOps](s34_advanced_enterprise_mlops.md) | Run the registry as the system of record, automate drift retraining with champion gates, use point-in-time features, and keep tamper-evident audit trails | — |
| 35 | [AI Infrastructure Optimization Foundations](s35_optimization_foundations.md) | Calculate real quantized memory, choose FP8, INT8, INT4, or FP4, prune and distill, and benchmark honestly | [`s35_quant_memory.py`](../exercises/s35_quant_memory.py) |
| 36 | [Advanced AI Infrastructure Optimization](s36_advanced_optimization.md) | Train with BF16, FP16, and FP8, run QAT, plan large distillation jobs, compile with `torch.compile` and XLA, and choose on a Pareto frontier | — |

```mermaid
flowchart LR
  P7["Part VII: workloads"] --> S31["§31 Large-scale training<br/>3D parallelism, NCCL"]
  S31 --> S32["§32 Advanced training<br/>ZeRO, FSDP2, checkpoints"]
  P7 --> S33["§33 Enterprise MLOps<br/>Kubeflow, MLflow, clouds"]
  S33 --> S34["§34 Advanced MLOps<br/>CT, governance, audit"]
  S32 --> S35["§35 Optimization basics<br/>quantize, prune, distill"]
  S35 --> S36["§36 Advanced optimization<br/>AMP, QAT, compilers"]
  S34 --> NEXT["Part IX: privacy, security,<br/>multi-tenancy"]
  S36 --> NEXT
```

**How to read it:** Part VIII has three tracks that build on Part VII's workloads. Sections 31 and 32 scale training
to large clusters. Sections 33 and 34 turn pipelines into a governed enterprise platform. Sections 35 and 36 make
training and serving cheaper through quantization, pruning, distillation, mixed precision, and compilers. Part IX
then covers privacy, security, and sharing infrastructure between teams.
