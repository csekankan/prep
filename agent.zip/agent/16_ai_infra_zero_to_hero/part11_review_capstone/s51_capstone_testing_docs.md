# Section 51 — Capstone Project 4: Testing, Reliability, and Documentation

> Lectures 351–357 • Exercise: [`s51_burn_rate.py`](../exercises/s51_burn_rate.py)
> **After this section you can:** test Atlas end to end after every deployment, fail over the database and model
> servers on purpose and measure recovery, page on SLO burn rate instead of noisy causes, write the documentation an
> on-call engineer needs, publish a clean versioned demo API, write a final report backed by evidence, and walk a
> reviewer through the whole system live.
>
> Builds on: [Section 50](s50_capstone_scale.md) (the scaled Atlas deployment),
> [Section 16](../part05_operating_production/s16_observability.md) (observability),
> [Section 19](../part05_operating_production/s19_reliability_ha.md) (reliability and HA), and
> [Section 10](../part03_mlops_cicd_cost/s10_cicd_for_ai.md) (CI/CD).

Section 50 made Atlas scalable. This section makes it trustworthy and understandable: tests prove each deployment
works, failover is practiced instead of hoped for, alerts wake someone only when users are affected, and the
documentation lets someone else run the system. The section ends with the final report and a live walkthrough, which
Section 52 turns into the stakeholder presentation.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 351 | Conducting end-to-end testing | Test the deployed system the way users and attackers use it, after every sync |
| 352 | Adding redundancy and failover mechanisms | Fail over the database, a zone, and the model servers on purpose, and measure RTO and RPO |
| 353 | Polishing monitoring and alerting dashboards | Page on error-budget burn rate, ticket on slow leaks, and link every alert to a runbook |
| 354 | Generating documentation for AI infra | README, architecture and ADRs, runbooks, API reference, system card, all in the repository |
| 355 | Creating demo API endpoints | A versioned, documented API with streaming, sources, request IDs, and a scoped demo key |
| 356 | Preparing the final capstone report | Every target with its measured result and evidence, including the misses |
| 357 | Lab: capstone infra walkthrough | A 30-minute scripted tour: deploy, test, break, recover, roll back, and explain |

```mermaid
flowchart LR
  E2E["(1) E2E tests<br/>after every sync"] --> FO["(2) Failover drills<br/>RTO, RPO"]
  FO --> AL["(3) Burn-rate alerts<br/>+ runbooks"]
  AL --> DOC["(4) Docs as code"]
  DOC --> API["(5) Demo API<br/>versioned, documented"]
  API --> REP["(6) Final report<br/>targets vs evidence"]
  REP --> WALK["(7) Live walkthrough"]
```

**How to read it:** each step builds evidence for the next. End-to-end tests and failover drills produce results.
Alerts and runbooks show the system can be operated. Documentation and a clean API make it usable by others. The final
report collects all the evidence, and the walkthrough demonstrates it live.

**Terms in this diagram.**
- **E2E tests**: end-to-end tests that call the deployed system through its public entry point.
- **Sync**: an Argo CD sync, the moment a new version is applied to the cluster.
- **RTO**: recovery time objective, how long recovery may take.
- **RPO**: recovery point objective, how much recent data you may lose.
- **Burn-rate alerts**: alerts based on how fast errors are using up the SLO's error budget.
- **Runbooks**: step-by-step instructions for handling a specific alert or task.

---

## Lecture 351 — Conducting end-to-end testing

**Why it matters.** Unit tests and the CI retrieval eval check pieces. They can't catch a wrong Ingress path, an expired
certificate, a NetworkPolicy that blocks the gateway from the model server, or a model that loads but answers in the
wrong language. End-to-end tests run against the deployed system after every deployment, so you find those problems
before users do.

**In plain words.** It's like a test drive after a car service. The mechanic checked each part, but you still drive
around the block to make sure the whole car works together before handing it back.

**Architecture: the Atlas test layers.**

```mermaid
flowchart TB
  U["Unit tests<br/>chunking, auth, parsing"] --> I["Integration tests<br/>gateway + pgvector in CI"]
  I --> Q["Quality eval<br/>recall@5, golden set"]
  Q --> SM["Post-sync smoke tests<br/>Argo CD PostSync hook"]
  SM --> E["Scheduled E2E suite<br/>answers, sources, auth, latency"]
  E --> J["Answer quality<br/>LLM judge + human sample"]
```

**How to read it:** the layers go from fast and narrow at the top to slow and broad at the bottom. Unit and integration
tests and the retrieval eval run in CI before merge (Section 49). After each deployment, Argo CD runs a short smoke
test as a PostSync hook. A fuller E2E suite runs on a schedule against the deployed system, and an answer-quality
evaluation with an LLM judge and human spot checks runs before each release.

**Terms in this diagram.**
- **Unit tests**: fast tests of single functions, such as chunking, auth (token checks), and parsing.
- **Integration tests**: tests of several components together, here the gateway with a real pgvector database.
- **Golden set**: the fixed list of questions with known correct articles.
- **PostSync hook**: an Argo CD resource, usually a Job, that runs after a sync and marks the sync failed if it fails.
- **LLM judge**: a language model asked to grade answers against a rubric, such as "is every claim supported by the
  articles?"

**Core ideas.** E2E tests check behaviors a user or attacker would see:

| Test | Checks |
|---|---|
| Ask a golden question | 200, streamed text, a `Sources:` section with the expected article |
| No token, bad token, missing scope | 401, 401, 403 |
| Unknown topic | The answer says it doesn't know, rather than inventing one |
| Latency budget | TTFT under 1.5 s and answer under 6 s for three short questions on an idle system |
| Info endpoint | Reports the image digest, model revision, and index version just deployed |
| Network isolation | A probe pod can't reach `llm:8000` |

- **Smoke tests are short** (under a minute) and block the rollout. The full suite runs every 15 minutes as a
  synthetic monitor, which doubles as an availability probe.
- **Assert on structure, not exact wording.** LLM answers vary, so check status, sources, refusals, and key terms.
- **Use a dedicated test identity** with its own scope, so test traffic is easy to filter out of metrics and cost.
- **Judge answers with care.** An LLM judge is biased and inconsistent. Fix the judge model and prompt, measure its
  agreement with human grades on a sample, and keep a human check of about 20 answers per release.

```python
# tests/e2e/test_atlas.py, run with ATLAS_URL and ATLAS_TOKEN set
import os
import time

import httpx
import pytest

URL, TOKEN = os.environ["ATLAS_URL"], os.environ["ATLAS_TOKEN"]
AUTH = {"authorization": f"Bearer {TOKEN}"}


def ask(question, headers=AUTH):
    t0, ttft, text = time.perf_counter(), None, ""
    with httpx.stream("POST", f"{URL}/v1/ask", json={"question": question, "stream": True},
                      headers=headers, timeout=30) as r:
        for chunk in r.iter_text():
            if ttft is None and chunk.strip():
                ttft = time.perf_counter() - t0
            text += chunk
        return r.status_code, text, ttft, time.perf_counter() - t0


def test_golden_question_streams_with_expected_source():
    code, text, _, _ = ask("How does Kueue let one team borrow another team's idle GPUs?")
    assert code == 200
    assert "s40_multi_tenant_ai" in text.split("event: sources", 1)[-1]


@pytest.mark.parametrize("headers,expected", [({}, 401), ({"authorization": "Bearer nope"}, 401)])
def test_rejects_bad_credentials(headers, expected):
    assert httpx.post(f"{URL}/v1/ask", json={"question": "x"}, headers=headers).status_code == expected


def test_unknown_topic_is_refused():
    _, text, _, _ = ask("What is the capital of the moon's largest crater?")
    assert any(p in text.lower() for p in ("don't know", "do not know", "not in the articles"))


def test_latency_budget_on_idle_system():
    for q in ("What is a PodDisruptionBudget?", "What does a startup probe do?", "What is PSI?"):
        code, _, ttft, total = ask(q)
        assert code == 200 and ttft < 1.5 and total < 6


def test_info_reports_deployed_versions():
    info = httpx.get(f"{URL}/v1/info").json()
    assert info["image"].startswith("sha256:") and info["model_revision"] and info["index_version"]
```

In the code, `ask` streams an answer and measures TTFT and total time from the client side. The tests check that a
golden question cites the right article in the sources event, that bad credentials are rejected, that an unanswerable
question gets a refusal, that three questions meet the latency budget on an idle system, and that the info endpoint
reports the deployed versions. The endpoints are the versioned demo API from Lecture 355.

```yaml
# deploy/base/smoke-test.yaml
apiVersion: batch/v1
kind: Job
metadata:
  name: smoke-test
  annotations:
    argocd.argoproj.io/hook: PostSync
    argocd.argoproj.io/hook-delete-policy: HookSucceeded
spec:
  backoffLimit: 0
  activeDeadlineSeconds: 180
  template:
    spec:
      restartPolicy: Never
      containers:
        - name: e2e
          image: ghcr.io/your-user/atlas-e2e@sha256:...
          args: ["pytest", "-q", "-x", "-k", "golden or rejects or info", "tests/e2e"]
          env: [{name: ATLAS_URL, value: "http://gateway:8080"}]
          envFrom: [{secretRef: {name: atlas-e2e-token}}]
```

The PostSync hook runs a three-test subset of the suite inside the cluster after every sync, with a 3-minute deadline.
If it fails, Argo CD marks the sync failed, and a notification goes to the team. The same image runs the full suite
on a 15-minute CronJob.

**Example: the green deployment that couldn't answer.** A NetworkPolicy change was merged and synced. All pods were
ready, because readiness only checked the gateway and the database. Every question got the retrieval-only fallback,
because the new policy blocked the gateway's traffic to the model server. The PostSync smoke test failed within a
minute on the golden question: the answer had sources but no generated text. The rollback was a Git revert.

**Senior / FAANG best practice.** Test the deployed system continuously with synthetic transactions that follow real
user journeys, and gate rollouts on them. For AI systems, add behavioral tests (refusals, citations, safety) and
release-time quality evaluations with calibrated judges and human review. Large companies run synthetic probes from
several regions as their primary availability signal.

---

## Lecture 352 — Adding redundancy and failover mechanisms

**Why it matters.** Section 50 added replicas and zones. Redundancy only counts if failover works when needed, and the
first real database failover is a bad time to learn that the gateway caches dead connections for 15 minutes. Drills
turn "should fail over" into a measured RTO and RPO.

**In plain words.** It's like a fire drill. Having exits isn't enough. People practice using them, and you time how
long it takes, so the real thing goes smoothly.

**Architecture: Atlas failure domains and recovery.**

```mermaid
flowchart LR
  subgraph R1["Primary region"]
    GW["Gateways<br/>3 zones"] --> LLM["vLLM<br/>2 zones"]
    GW --> PRI[("Postgres primary")]
    PRI -->|sync replication| STB[("Standby<br/>other zone")]
  end
  PRI -->|"snapshots + PITR"| BK[("Backups")]
  BK -->|copy| R2[("Second region<br/>backups, weights, Terraform")]
  S3W[("S3: docs, weights")] -->|replicate| R2
```

**How to read it:** inside the primary region, gateways and model servers run in several zones, and the database
replicates synchronously to a standby in another zone, which takes over automatically. Backups and point-in-time
recovery data are copied to a second region, along with documents and model weights. With the Terraform code, the
whole system can be rebuilt there. That's a pilot-light disaster recovery plan.

**Terms in this diagram.**
- **vLLM**: the model server running the LLM on GPUs.
- **Postgres primary**: the database instance that accepts writes.
- **Sync replication**: every write is confirmed on the standby before it counts, so failover loses no committed data.
- **Standby**: the database replica that becomes primary during failover.
- **Snapshots + PITR**: full backups plus point-in-time recovery, which replays logs to restore the database to any
  moment within the retention period.
- **Replicate**: copy objects automatically to a bucket in another region.
- **Pilot light**: a disaster recovery approach where only data and code are kept in the second region, and compute is
  created when needed.

**Core ideas.** Set an RTO and RPO per failure, and measure them in drills.

| Failure | Mechanism | RTO target | RPO target | Drill |
|---|---|---|---|---|
| Gateway pod or node | Replicas, readiness, PDB | 0 (no user impact) | 0 | Delete a pod under load |
| Model server pod | 2 replicas, fallback | Under 1 min degraded | 0 | Delete a pod under load |
| Zone | Spread across zones | Under 5 min degraded | 0 | Drain all nodes in a zone |
| Database primary | Multi-AZ failover, pool reconnect | Under 2 min | 0 | Forced failover |
| Database corruption or bad migration | PITR restore | Under 1 hour | Under 5 min | Restore to a new instance |
| Region | Pilot light: Terraform + copied backups | Under 8 hours | Under 1 hour | Yearly rebuild in region 2 |

- **The vector index is derived data.** It can be rebuilt from the documents in about the time ingestion takes, so its
  RPO doesn't matter, but query feedback and logs do.
- **Clients must survive failover.** Use a connection pool that checks connections, short timeouts, and retries with
  backoff for idempotent reads.
- **Retries need a budget.** Unlimited retries turn a small failure into a retry storm. Cap retries per request and
  overall.
- **Drill under load** and record the timeline, the user impact, and what surprised you.

```python
# in services/gateway/app.py: a pool that survives database failover
from psycopg_pool import ConnectionPool

pool = ConnectionPool(DB_URL, min_size=2, max_size=20, timeout=3, max_idle=300,
                      check=ConnectionPool.check_connection,
                      kwargs={"connect_timeout": 3, "options": "-c statement_timeout=2000"})


def retrieve(question, attempts=2):
    vec = next(iter(embedder().embed([question]))).tolist()
    for i in range(attempts):
        try:
            with pool.connection() as db:
                return db.execute("SELECT title, url, body FROM chunks ORDER BY embedding <=> %s::vector "
                                  "LIMIT %s", (str(vec), TOP_K)).fetchall()
        except psycopg.OperationalError:
            if i == attempts - 1:
                raise
            time.sleep(0.5)
```

In the code, the pool keeps 2 to 20 connections and checks each one before handing it out, so connections to the old
primary are discarded after failover instead of failing a request. Connect and statement timeouts keep a dead
database from hanging requests. Retrieval is a read, so it's safe to retry once after half a second. The managed
database's DNS name moves to the new primary, so new connections reach it automatically.

```bash
# drill: forced database failover under load, measuring client-visible impact
python3 load/loadtest.py $GW "$TOKEN" 5 > reports/failover-load.txt &
( while true; do
    printf '%s %s\n' "$(date +%T)" "$(curl -s -o /dev/null -w '%{http_code}' -m 5 $GW/v1/health/deep)"; sleep 1
  done ) > reports/failover-probe.txt &
sleep 60 && aws rds reboot-db-instance --db-instance-identifier atlas --force-failover
sleep 300 && kill %1 %2
awk '$2 != "200"' reports/failover-probe.txt | sed -n '1p;$p'     # first and last failing second = observed RTO
```

The drill runs 5 requests/s of load and a once-a-second probe of the deep health endpoint (which checks the database),
then forces a Multi-AZ failover. Afterwards, the first and last non-200 probe lines give the observed outage window.
Compare it with the target, and with the load test's error count for the same period.

**Example: the 14-minute failover.** In the first database drill, RDS failed over in about 40 seconds, but the gateway
returned errors for 14 minutes. Its connections pointed at the old primary's IP address and nothing checked them, so
each request waited for a TCP timeout. Adding the pool's connection check, short timeouts, and one retry cut the
client-visible outage to 45 seconds. The second drill confirmed it.

**Senior / FAANG best practice.** Write RTO and RPO per failure mode, design the mechanism, and prove it with regular
drills under load, including restores from backup (an untested backup isn't a backup). Large companies run disaster
recovery tests at least yearly, inject failures continuously in some systems, and keep retry budgets and circuit
breakers in client libraries so failover doesn't cause retry storms.

---

## Lecture 353 — Polishing monitoring and alerting dashboards

**Why it matters.** Alerts on every cause (CPU high, one pod restarted, GPU at 95%) page people for things users never
notice and train them to ignore pages. Alerts based on SLO burn rate page only when users are affected, scale urgency
with severity, and come with a runbook. That's the difference between a dashboard and an operable system.

**In plain words.** It's like a smoke alarm compared with a thermometer in every room. You want to be woken up when
there's a fire, not every time someone makes toast.

**Architecture: from metrics to the right person.**

```mermaid
flowchart LR
  M["Metrics<br/>requests, TTFT, degraded"] --> REC["Recording rules<br/>error ratio over 5m to 3d"]
  REC --> AL["Burn-rate alerts<br/>fast, slow, leak"]
  AL --> AM["Alertmanager<br/>route by severity"]
  AM -->|page| ONC["On-call phone"]
  AM -->|ticket| TK["Team channel + ticket"]
  AL -.runbook_url.-> RB["Runbook"]
  DEP["Deploy annotations"] --> DASH["SLO dashboard<br/>budget remaining"]
  REC --> DASH
```

**How to read it:** recording rules precompute the error ratio over several windows. Burn-rate alerts compare those
ratios with thresholds derived from the SLO. Alertmanager routes by severity: pages to the on-call engineer's phone,
tickets to the team channel. Each alert links to its runbook. The SLO dashboard shows the remaining error budget, with
deployments marked on the graphs.

**Terms in this diagram.**
- **Recording rules**: Prometheus rules that compute an expression regularly and store the result as a new series.
- **Alertmanager**: the Prometheus component that groups, silences, and routes alerts.
- **Page, ticket**: an urgent notification that wakes someone, or a non-urgent task for working hours.
- **runbook_url**: an alert annotation linking to the runbook for that alert.
- **Deploy annotations**: marks on dashboard graphs at each deployment time, so changes line up with effects.
- **Budget remaining**: the share of the 30-day error budget not yet used.

**Core ideas.** Run the exercise:

```text
SLO 99.5%: budget 0.5% of requests per 30 days

alert            windows  burn  error ratio threshold  budget used when it fires
fast burn        1h/  5m  14.4                 7.20%                      2.0%  -> page
slow burn        6h/ 30m     6                 3.00%                      5.0%  -> page
budget leak     72h/360m     1                 0.50%                     10.0%  -> ticket

full outage                    errors 100.0%: fast burn   page   after    4.3 min, budget used 2.0%
one bad gateway pod of three   errors  33.0%: fast burn   page   after   13.1 min, budget used 2.0%
DB failover retries failing    errors  10.0%: fast burn   page   after   43.2 min, budget used 2.0%
one zone's requests failing    errors   4.0%: slow burn   page   after  270.0 min, budget used 5.0%
slow leak: 2% errors           errors   2.0%: budget leak ticket after 1080.0 min, budget used 10.0%
background noise: 0.3% errors  errors   0.3%: no alert (within budget: uses 60% of the budget rate)
```

- **Burn rate** is the error ratio divided by the budget ratio. At a burn rate of 14.4, a 30-day budget lasts 50 hours,
  and one hour uses 2% of it.
- **Severity scales with speed.** A full outage pages in about 4 minutes. A 4% error rate pages after about 4.5 hours
  through the slow-burn alert, and a 2% leak becomes a ticket after 18 hours. Noise within budget never alerts.
- **Two windows per alert.** The long window decides whether to fire; the short window makes the alert stop soon after
  the problem is fixed.
- **Symptoms page, causes inform.** GPU memory, pod restarts, and queue depth belong on dashboards and in tickets, not
  pages, unless they predict an SLO breach.
- **Latency and degraded answers get their own SLO alerts**, because the fallback returns 200 and won't show as errors.

```yaml
# deploy/base/prometheusrule.yaml
apiVersion: monitoring.coreos.com/v1
kind: PrometheusRule
metadata: {name: atlas-slo}
spec:
  groups:
    - name: atlas-slo-recording
      rules:
        - record: atlas:error_ratio:rate5m
          expr: sum(rate(atlas_requests_total{code=~"5.."}[5m])) / sum(rate(atlas_requests_total[5m]))
        - record: atlas:error_ratio:rate30m
          expr: sum(rate(atlas_requests_total{code=~"5.."}[30m])) / sum(rate(atlas_requests_total[30m]))
        - record: atlas:error_ratio:rate1h
          expr: sum(rate(atlas_requests_total{code=~"5.."}[1h])) / sum(rate(atlas_requests_total[1h]))
        - record: atlas:error_ratio:rate6h
          expr: sum(rate(atlas_requests_total{code=~"5.."}[6h])) / sum(rate(atlas_requests_total[6h]))
        - record: atlas:error_ratio:rate3d
          expr: sum(rate(atlas_requests_total{code=~"5.."}[3d])) / sum(rate(atlas_requests_total[3d]))
    - name: atlas-slo-alerts
      rules:
        - alert: AtlasErrorBudgetFastBurn
          expr: atlas:error_ratio:rate1h > (14.4 * 0.005) and atlas:error_ratio:rate5m > (14.4 * 0.005)
          for: 2m
          labels: {severity: page}
          annotations:
            summary: "Atlas is burning its error budget 14x too fast ({{ $value | humanizePercentage }} errors)"
            runbook_url: https://github.com/your-user/atlas/blob/main/docs/runbooks/error-budget-burn.md
        - alert: AtlasErrorBudgetSlowBurn
          expr: atlas:error_ratio:rate6h > (6 * 0.005) and atlas:error_ratio:rate30m > (6 * 0.005)
          for: 15m
          labels: {severity: page}
          annotations:
            runbook_url: https://github.com/your-user/atlas/blob/main/docs/runbooks/error-budget-burn.md
        - alert: AtlasErrorBudgetLeak
          expr: atlas:error_ratio:rate3d > 0.005 and atlas:error_ratio:rate6h > 0.005
          for: 1h
          labels: {severity: ticket}
        - alert: AtlasTTFTSlow
          expr: histogram_quantile(0.95, sum by (le) (rate(atlas_ttft_seconds_bucket[10m]))) > 1.5
          for: 15m
          labels: {severity: page}
          annotations:
            runbook_url: https://github.com/your-user/atlas/blob/main/docs/runbooks/ttft-slow.md
        - alert: AtlasDegradedAnswers
          expr: sum(rate(atlas_degraded_total[10m])) / sum(rate(atlas_requests_total[10m])) > 0.05
          for: 10m
          labels: {severity: page}
          annotations:
            runbook_url: https://github.com/your-user/atlas/blob/main/docs/runbooks/llm-unavailable.md
```

In the rules, five recording rules compute the error ratio over 5 minutes to 3 days. The three burn-rate alerts use the
thresholds from the exercise, each with a long and a short window. Separate alerts cover TTFT p95 above the 1.5 s SLO
and degraded answers above 5%. Every paging alert links to a runbook.

```yaml
# Alertmanager routing (kube-prometheus-stack values)
alertmanager:
  config:
    route:
      receiver: team-channel
      group_by: [alertname]
      routes:
        - matchers: ['severity="page"']
          receiver: on-call
          repeat_interval: 30m
    receivers:
      - name: on-call
        pagerduty_configs: [{routing_key_file: /etc/alertmanager/secrets/pagerduty/key}]
      - name: team-channel
        slack_configs: [{api_url_file: /etc/alertmanager/secrets/slack/url, channel: "#atlas"}]
```

Pages go to PagerDuty (or a free alternative such as ntfy for a capstone) and repeat every 30 minutes while firing.
Everything else goes to the team channel. The secrets are mounted files, not values in the config.

**Example: the 40 pages a week.** The first version of Atlas alerting had 11 cause-based alerts, including "GPU
utilization above 90%" and "pod restarted". In a week of load testing they paged 40 times, and none of those pages
matched a user-visible problem: high GPU utilization is normal under load. Replacing them with the burn-rate, TTFT,
and degraded-answer alerts gave two pages in the following week, both real.

**Senior / FAANG best practice.** Page only on user-facing SLO symptoms, using multi-window, multi-burn-rate alerts as
described in Google's SRE Workbook. Every page has a runbook and an owner, and alert noise is reviewed weekly. Pages
that needed no action are removed or downgraded. Dashboards start with the SLOs and the remaining error budget, carry
deployment annotations, and drill down by component and model version.

---

## Lecture 354 — Generating documentation for AI infra

**Why it matters.** A system only one person can operate is a liability. Documentation lets an on-call engineer
handle an alert at 3 a.m., a new teammate deploy on day two, and a reviewer understand why the system looks the way it
does. For the capstone, the documents are also part of what you're graded on.

**In plain words.** It's like the manual and the maintenance log for a car. The manual says how to drive it, and the
log says what was changed, when, and why, so the next mechanic doesn't have to guess.

**Architecture: the Atlas documentation set.**

```mermaid
flowchart TB
  README["README<br/>what, quick start"] --> ARCH["Architecture<br/>diagrams + ADRs"]
  README --> OPS["Operations guide<br/>deploy, rollback, scale, restore"]
  OPS --> RB["Runbooks<br/>one per alert"]
  README --> APIREF["API reference<br/>OpenAPI from code"]
  README --> SYS["System card<br/>model, data, evals, limits"]
  README --> SEC["Security notes<br/>threat model, access"]
  CI["CI: link check, Mermaid render,<br/>runbook per alert"] -.checks.-> RB
```

**How to read it:** the README is the entry point, with what Atlas is and a quick start. It links to the architecture
document with diagrams and decision records, the operations guide and its runbooks, the API reference generated from
the code, the system card describing the model and its limits, and security notes. CI checks the documents: links
work, diagrams render, and every alert has a runbook.

**Terms in this diagram.**
- **ADRs**: architecture decision records, short documents recording one decision, its context, the options, and the
  consequences.
- **Operations guide**: how to run the system day to day.
- **OpenAPI**: a standard machine-readable description of an HTTP API, which FastAPI generates automatically.
- **System card**: a document describing an AI system's model, data, intended use, evaluation results, and known
  limitations.
- **Threat model**: the list of assets, attackers, and attack paths, with the defense for each.

**Core ideas.**
- **Docs live in the repository** next to the code, reviewed in the same pull requests, and published with a static
  site tool such as MkDocs.
- **Write for the reader's situation.** A runbook reader is stressed and in a hurry, so give commands, not essays.
- **Generate what you can.** The API reference comes from FastAPI's OpenAPI output, and diagrams are Mermaid in
  Markdown.
- **The system card is specific to AI:** model and revision, data sources, evaluation results with dates, known failure
  cases (for example, "answers questions outside the documents poorly"), and how users report problems.
- **Check docs in CI.** A small script fails the build if an alert in the PrometheusRule has no matching runbook file.

```markdown
### Runbook: AtlasDegradedAnswers

**Meaning:** over 5% of answers in the last 10 minutes were retrieval-only, because the model server failed or timed
out. Users get article links but no written answer.

**Impact:** answer quality is reduced. The availability SLO isn't affected, so this is easy to miss.

**Check, in order:**
1. `kubectl -n atlas get pods -l app=llm -o wide`: are model server pods running and ready, and in which zones?
2. Grafana, Atlas dashboard, model server row: queue length, KV-cache use, tokens/s.
3. `kubectl -n atlas logs deploy/llm --since=15m | tail -50`: out-of-memory errors, CUDA errors, load failures.
4. `kubectl get nodes -l atlas/pool=gpu`: are GPU nodes present? Check autoscaler events if not.

**Mitigate:**
- Pods crash-looping after a deploy: `git revert` the deploy commit, and Argo CD rolls back.
- Not enough GPUs: `kubectl -n atlas scale deploy/llm --replicas=3`, and check the GPU quota.
- A zone is down: confirm the other zone's replica is serving, and wait for the autoscaler to replace capacity.

**Escalate:** if it's not mitigated in 30 minutes, page the capstone owner. Record a timeline for the postmortem.
```

The runbook follows one pattern: what the alert means, what users feel, what to check in order with exact commands,
how to mitigate each likely cause, and when to escalate. Keep each runbook to one screen.

```python
# tools/check_runbooks.py, run in CI
import sys
from pathlib import Path

import yaml

rules = yaml.safe_load(Path("deploy/base/prometheusrule.yaml").read_text())
missing = []
for group in rules["spec"]["groups"]:
    for rule in group["rules"]:
        if "alert" in rule and rule.get("labels", {}).get("severity") == "page":
            url = rule.get("annotations", {}).get("runbook_url", "")
            path = Path("docs/runbooks") / url.rsplit("/", 1)[-1]
            if not url or not path.exists():
                missing.append(f"{rule['alert']}: {url or 'no runbook_url'}")
print("\n".join(missing) or "every paging alert has a runbook")
sys.exit(1 if missing else 0)
```

The check reads the PrometheusRule, finds every alert with `severity: page`, and fails CI if its `runbook_url` is
missing or points to a file that doesn't exist in `docs/runbooks/`.

**Example: the runbook that saved the demo rehearsal.** During a rehearsal, a classmate on call for the first time got
the `AtlasDegradedAnswers` page. Following the runbook, they found one model server pod pending because the GPU node
group had hit its maximum during a rollout surge, and scaled the old ReplicaSet back. Recovery took 6 minutes,
without asking the author anything.

**Senior / FAANG best practice.** Documentation is part of the definition of done: a new service needs a README,
architecture doc, runbooks for every page, and an on-call handover before launch. Large companies require launch
reviews that check these, and AI teams publish model or system cards. Keep docs close to the code and test them like
code, so they stay current.

---

## Lecture 355 — Creating demo API endpoints

**Why it matters.** The demo API is what stakeholders, reviewers, and any demo UI touch. A clean, versioned, documented
API with request IDs and stable error formats shows the engineering quality of the whole system. A messy one
undermines it, however good the infrastructure behind it is.

**In plain words.** It's like the front of a shop. The stockroom can be well organized, but customers judge the shop by
the counter, the signs, and how easy it is to get what they came for.

**Architecture: the Atlas v1 API.**

```mermaid
flowchart LR
  C["Client or demo UI"] --> V1["/v1 routes"]
  V1 --> ASK["POST /v1/ask<br/>SSE stream or JSON"]
  V1 --> FB["POST /v1/feedback<br/>thumbs up or down"]
  V1 --> INFO["GET /v1/info<br/>versions"]
  V1 --> H["GET /v1/health<br/>/v1/health/deep"]
  V1 --> DOCS["GET /docs<br/>OpenAPI UI"]
  ASK --> RID["x-request-id on every response"]
```

**How to read it:** all routes sit under `/v1`, so a future `/v2` can change them without breaking clients. The ask
endpoint returns either a stream of server-sent events or a single JSON response. Feedback records a rating against a
request ID. The info endpoint reports what's deployed, and two health endpoints check the process and its dependencies.
FastAPI serves interactive OpenAPI documentation. Every response carries a request ID that also appears in logs.

**Terms in this diagram.**
- **SSE**: server-sent events, a simple standard for streaming events over HTTP, one `event:` and `data:` pair at a
  time.
- **Feedback**: a user's rating of an answer, used for drift and quality monitoring.
- **Info**: deployment metadata such as image digest, model revision, and index version.
- **Health, deep health**: a liveness check of the process, and a check that also tests the database and model server.
- **x-request-id**: a unique ID per request, returned to the client and logged, so a complaint can be traced.

**Core ideas.**
- **Version from day one** (`/v1`), and never break a published version.
- **Typed requests and responses** with Pydantic, so the OpenAPI document is accurate and validation errors are clear.
- **Stream with SSE events** (`token`, `sources`, `done`), so clients can render sources separately from text.
- **Stable error format**, such as `{"error": {"code": "rate_limited", "message": "...", "request_id": "..."}}`.
- **A scoped demo identity.** The demo uses a token with an `atlas:demo` scope, a low rate limit, and an expiry date,
  so sharing it publicly is low-risk.
- **CORS only for the demo UI's origin**, so other websites can't call the API from users' browsers.

```python
# services/gateway/api_v1.py
import json
import uuid

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

router = APIRouter(prefix="/v1")


class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=1000)
    stream: bool = True


class Source(BaseModel):
    n: int
    title: str
    url: str


class AskResponse(BaseModel):
    request_id: str
    answer: str
    sources: list[Source]
    degraded: bool
    model_revision: str


class Feedback(BaseModel):
    request_id: str
    rating: int = Field(ge=-1, le=1)


@router.post("/ask", response_model=AskResponse, responses={200: {"content": {"text/event-stream": {}}}})
async def ask_v1(body: AskRequest, request: Request, claims: dict = Depends(require_any("atlas:ask", "atlas:demo"))):
    rid = request.state.request_id
    rows = await run_in_threadpool(retrieve, body.question)
    sources = [Source(n=i + 1, title=t, url=u) for i, (t, u, _) in enumerate(rows)]
    if not body.stream:
        text, degraded = await complete(body.question, rows)
        return AskResponse(request_id=rid, answer=text, sources=sources, degraded=degraded, model_revision=MODEL_REV)

    async def events():
        async for token in generate(body.question, rows):
            yield f"event: token\ndata: {json.dumps(token)}\n\n"
        yield f"event: sources\ndata: {json.dumps([s.model_dump() for s in sources])}\n\n"
        yield f"event: done\ndata: {json.dumps({'request_id': rid})}\n\n"
    return StreamingResponse(events(), media_type="text/event-stream")


@router.post("/feedback", status_code=204)
def feedback(body: Feedback, claims: dict = Depends(require_any("atlas:ask", "atlas:demo"))):
    with pool.connection() as db:
        db.execute("UPDATE queries SET feedback = %s WHERE request_id = %s", (body.rating, body.request_id))


@router.get("/info")
def info():
    return {"image": IMAGE_DIGEST, "model_revision": MODEL_REV, "index_version": INDEX_VERSION, "api": "v1"}


@app.middleware("http")
async def request_id(request: Request, call_next):
    request.state.request_id = request.headers.get("x-request-id") or uuid.uuid4().hex
    response = await call_next(request)
    response.headers["x-request-id"] = request.state.request_id
    return response
```

In the code, the request and response models define the API contract, and FastAPI turns them into the OpenAPI document
at `/docs`. The ask route accepts either the normal or demo scope, retrieves sources, and either returns one JSON object
or streams SSE events: one `token` event per piece of text, then `sources`, then `done` with the request ID. Tokens
are JSON-encoded so newlines inside them can't break the event format. Feedback updates the drift table (Lecture 345,
with a `request_id` column added), and `info` reports the deployed versions from environment variables set by the
deployment. The middleware gives every request an ID and returns it in a header. `require_any`, `retrieve`,
`complete`, and `generate` come from the gateway code in Sections 49 and 50.

```bash
curl -sN $GW/v1/ask -H "authorization: Bearer $DEMO_TOKEN" -H 'content-type: application/json' \
  -d '{"question": "What does a startup probe do?"}'
# event: token
# data: "A startup probe gives a slow-starting container time to load"
# ...
# event: sources
# data: [{"n": 1, "title": "Section 5 — Kubernetes Fundamentals", "url": "s05_kubernetes_fundamentals.md"}, ...]
# event: done
# data: {"request_id": "4f9c1e..."}
curl -s $GW/openapi.json -o docs/api/openapi.json     # committed and diffed in CI to catch breaking changes
```

The streamed output shows the event format, and the last command saves the OpenAPI document so CI can compare it with
the previous version and flag removed fields or routes as breaking changes.

**Example: the demo key on a slide.** A student put a demo token on a slide for a class presentation, and the slides
were shared publicly. Because the token had only the `atlas:demo` scope, a limit of 10 requests a minute, and a
one-week expiry, the abuse that followed was capped at a few dollars of GPU time and stopped when the token expired.
A full-access key with no limit would have kept the GPUs busy until someone noticed.

**Senior / FAANG best practice.** Design public APIs as products: versioned, typed, documented from code, with stable
errors, request IDs, idempotency where it matters, and compatibility checks in CI. Large API platforms publish OpenAPI
specs, use short-lived scoped credentials, apply per-key rate limits and quotas, and deprecate versions with notice
periods measured in months.

---

## Lecture 356 — Preparing the final capstone report

**Why it matters.** The report is the record of what you built and what it achieved. Reviewers and future employers
read it to judge your engineering, and the best reports show measured results against the original targets, with
evidence, including where the system fell short and why.

**In plain words.** It's like a home inspection report after renovation. It lists every item checked, the measurement,
whether it passed, and a photo as proof, plus what still needs fixing.

**Architecture: where the report's evidence comes from.**

```mermaid
flowchart LR
  SLO[("slo.yaml<br/>targets")] --> GEN["report generator"]
  LT[("Load test reports")] --> GEN
  EV[("Eval results<br/>recall, groundedness")] --> GEN
  GD[("Game-day timelines")] --> GEN
  COST[("Unit cost + bill")] --> GEN
  GEN --> TAB["Results table<br/>target, measured, evidence"]
  TAB --> REP["Final report<br/>8 sections"]
```

**How to read it:** the targets come from `slo.yaml`, written in Section 48. The measured values come from the load
test reports, the evaluation results, the game-day timelines, and the cost data. A small generator puts them in one
table with the evidence for each row, and the table is the center of the final report.

**Terms in this diagram.**
- **slo.yaml**: the file of SLO targets from Lecture 331, shared by tests, alerts, and the report.
- **Groundedness**: the share of answers whose claims are all supported by the retrieved articles.
- **Game-day timelines**: the minute-by-minute records of failure drills.

**Core ideas.** The report has eight sections:

| Section | Contents |
|---|---|
| Summary | One paragraph: what Atlas is, the headline results, and the main open issue |
| Problem and goals | From the proposal, with any scope changes and why |
| Architecture | The final diagram, environments, and links to ADRs |
| Results vs targets | The generated table, each row with evidence |
| Reliability | Game-day results: failures injected, RTO measured, what changed after |
| Cost | Estimate vs actual per environment, unit cost, the biggest savings |
| Security | Identity, network policy, secrets, scans and signatures, remaining risks |
| Lessons and next steps | What you'd do differently, and the top three improvements |

```python
import operator

OPS = {"<": operator.lt, "<=": operator.le, ">=": operator.ge, ">": operator.gt}
TARGETS = [  # name, unit, op, target, measured, evidence
    ("TTFT p95 at 5 req/s", "s", "<", 1.5, 0.52, "load/step.txt"),
    ("Full answer p95 at 5 req/s", "s", "<", 6.0, 4.1, "load/step.txt"),
    ("Capacity at SLO, 3 x L4", "req/s", ">=", 10, 10.1, "load/step.txt"),
    ("Availability, 14-day test window", "%", ">=", 99.5, 99.82, "Prometheus SLO panel"),
    ("Retrieval recall@5", "", ">=", 0.85, 0.89, "eval/results.json"),
    ("Grounded answers", "%", ">=", 90, 92.0, "eval/judge.json + 20 human checks"),
    ("Cost per 1,000 requests", "$", "<", 0.50, 0.31, "cost/unit_cost.log"),
    ("Monthly spend while building", "$", "<", 600, 412, "cloud bill"),
    ("Lead time, commit to production", "min", "<", 15, 11, "CI run history"),
    ("Rollback", "min", "<", 5, 3, "game day 2"),
    ("MTTR in game day", "min", "<", 15, 9, "game day 2"),
    ("Drift alert after injected shift", "min", "<=", 60, 75, "drift test"),
]
print("| Metric | Target | Measured | Status | Evidence |")
print("|---|---|---|---|---|")
met = 0
for name, unit, op, target, got, ev in TARGETS:
    ok = OPS[op](got, target)
    met += ok
    print(f"| {name} | {op} {target:g} {unit} | {got:g} {unit} | {'met' if ok else 'MISSED'} | {ev} |")
print(f"\n{met}/{len(TARGETS)} targets met")
```

In the code, each target has a comparison, a target value, the measured value, and where the evidence is. The script
prints a Markdown table and a count. In the real project, the measured values are read from the result files instead of
typed in, so the report can't drift from the evidence. With the Atlas values, it prints:

| Metric | Target | Measured | Status | Evidence |
|---|---|---|---|---|
| TTFT p95 at 5 req/s | < 1.5 s | 0.52 s | met | load/step.txt |
| Full answer p95 at 5 req/s | < 6 s | 4.1 s | met | load/step.txt |
| Capacity at SLO, 3 x L4 | >= 10 req/s | 10.1 req/s | met | load/step.txt |
| Availability, 14-day test window | >= 99.5 % | 99.82 % | met | Prometheus SLO panel |
| Retrieval recall@5 | >= 0.85 | 0.89 | met | eval/results.json |
| Grounded answers | >= 90 % | 92 % | met | eval/judge.json + 20 human checks |
| Cost per 1,000 requests | < 0.5 $ | 0.31 $ | met | cost/unit_cost.log |
| Monthly spend while building | < 600 $ | 412 $ | met | cloud bill |
| Lead time, commit to production | < 15 min | 11 min | met | CI run history |
| Rollback | < 5 min | 3 min | met | game day 2 |
| MTTR in game day | < 15 min | 9 min | met | game day 2 |
| Drift alert after injected shift | <= 60 min | 75 min | MISSED | drift test |

11 of 12 targets were met. The drift alert missed its target because the drift job runs hourly and the alert waits 15
minutes before firing, so detection took up to 75 minutes. The report says so and gives two options: run the job every
30 minutes, which costs almost nothing, or change the target to 90 minutes, since drift is a ticket, not a page.

**Example: the report that hid a miss.** One capstone report showed every target met. In the walkthrough, a reviewer
asked for the availability evidence, and the number came from a weekend with almost no traffic. The weekday figure
was 99.1%. The reviewer's feedback was that an honest miss with a plan would have scored higher than a cherry-picked
pass. The student rewrote the section with both numbers and the cause.

**Senior / FAANG best practice.** Report results the way a launch review expects: targets set in advance, measured
values with links to evidence, clear statements of misses and their causes, and the next actions with owners. Large
companies run postmortems and launch reviews without blame, which rewards honesty about gaps. Your report should do
the same.

---

## Lecture 357 — Lab: capstone infra walkthrough

**Goal:** run a 30-minute live walkthrough of Atlas for a reviewer, following a script that shows the system
working, changing, failing, recovering, and rolling back, with evidence on screen at each step.

**What you're building:** `docs/walkthrough.md`, the script with commands and expected results, plus a rehearsal log
with the real timings from at least one practice run.

```mermaid
flowchart LR
  T1["(1) Tour<br/>repo + diagram, 3 min"] --> T2["(2) Plan shows<br/>no drift, 2 min"]
  T2 --> T3["(3) Change via PR<br/>CI, Argo, smoke, 7 min"]
  T3 --> T4["(4) E2E + load, 4 min"]
  T4 --> T5["(5) Game day<br/>kill llm pod + DB failover, 6 min"]
  T5 --> T6["(6) Roll back, 3 min"]
  T6 --> T7["(7) Cost, drift,<br/>report, 5 min"]
```

**How to read the diagram:** the walkthrough has seven timed parts that add up to 30 minutes. It starts with a short
tour and a Terraform plan proving the cloud matches the code. Then a live change goes through the full pipeline, tests
and load run, two failures are injected and recovered, the change is rolled back, and it ends with cost, drift, and the
report. The terms, briefly: **drift** here means differences between the real cloud resources and the Terraform code,
and a **game day** is a planned exercise where you break things on purpose.

**Prerequisites:** the scale-test environment from Section 50 running, the alerts, runbooks, and API from this section,
a second screen or split screen with the Grafana SLO dashboard, and a small prepared change (for example, a new
`atlas_build_info` metric or a changed system prompt).

### Step 1 — Tour and infrastructure check (5 minutes)

```bash
tree -L 2 atlas/                              # services, deploy, infra, eval, load, docs
cd infra && terraform plan -detailed-exitcode  # exit code 0 = no changes: the cloud matches the code
kubectl -n atlas get pods -o wide             # gateways in 3 zones, llm in 2
curl -s $GW/v1/info | jq                      # image digest, model revision, index version
```

### Step 2 — A change through the pipeline (7 minutes)

```bash
git switch -c walkthrough-change && git commit -am "Add atlas_build_info metric" && git push -u origin HEAD
gh pr create --fill && gh pr checks --watch    # test, eval (recall@5), manifest checks
gh pr merge --squash --delete-branch
gh run watch                                   # build, scan, sign, commit digest to the overlay
argocd app wait atlas-scale-test --sync --health --timeout 600   # sync, then the PostSync smoke test
curl -s $GW/v1/info | jq .image                # the new digest
```

### Step 3 — Tests under load (4 minutes)

```bash
ATLAS_URL=$GW ATLAS_TOKEN=$TOKEN pytest -q tests/e2e
python3 load/loadtest.py $GW "$TOKEN" 5 &      # keep 5 req/s running for the game day
```

### Step 4 — Game day (6 minutes)

```bash
kubectl -n atlas delete "$(kubectl -n atlas get pod -l app=llm -o name | head -1)" --wait=false
# Dashboard: degraded answers rise briefly, no 5xx, replica returns after the model load time.
aws rds reboot-db-instance --db-instance-identifier atlas --force-failover
# Dashboard: a short spike of errors or slower retrieval, then normal. Probe log gives the observed RTO.
```

### Step 5 — Roll back (3 minutes)

```bash
git switch main && git pull                    # CI's digest commit is now the latest commit on main
git revert --no-edit HEAD && git push          # reverts it (or open a revert PR if main is protected)
argocd app wait atlas-scale-test --sync --health --timeout 300
curl -s $GW/v1/info | jq .image                # back to the previous digest
```

### Step 6 — Cost, drift, report (5 minutes)

Show the cost panel (cost per 1,000 requests and monthly spend against the budget), the drift gauges with the sample
size, and the results table from Lecture 356, pointing out the missed drift-alert target and its fix. Finish with the
top three next steps and open questions.

**Expected results:**
- `terraform plan -detailed-exitcode` exits with 0, showing no infrastructure drift.
- The change reaches the cluster from merge in under 15 minutes, the lead-time target, with the PostSync smoke test
  passing and the new digest visible in `/v1/info`.
- The E2E suite passes against the deployed system.
- Deleting a model server pod at 5 requests/s causes no 5xx responses. `atlas_degraded_total` rises briefly, and the
  `AtlasDegradedAnswers` alert stays silent unless degraded answers exceed 5% for 10 minutes.
- The forced database failover shows a client-visible outage under the 2-minute target in the probe log, and the error
  spike is small enough that the fast-burn alert doesn't fire, because errors are only briefly above 7.2%.
- The rollback completes in under 5 minutes and `/v1/info` shows the previous digest.
- The rehearsal log records each part's actual time. If the walkthrough runs over 30 minutes in rehearsal, cut the tour,
  not the failure and recovery parts.

---

## FAANG deep-dive notes

**How big tech does it.** Before launch, large companies run production readiness reviews that check for SLOs and
alerts, runbooks, on-call staffing, load-test results, disaster recovery plans and drills, security review, and
documentation. Google's SRE teams accept a service only once it meets those criteria. Amazon's operational readiness
reviews ask similar questions and track open items to launch. Synthetic monitoring, multi-window burn-rate alerts, and
regular failure drills (such as Netflix's chaos engineering) are standard. AI launches add model or system cards,
red-teaming results, and evaluation reports.

**Staff review questions.**
- What tests run after each deployment, and do they block a bad rollout?
- What's the measured RTO for a database failover, and when was it last drilled?
- Which alerts page, and how many pages last week needed no action?
- Can an engineer who has never seen this system handle each page with the runbook alone?
- What does the API guarantee to clients, and how are breaking changes caught?
- Which targets were missed, and what's the plan?

**Interview question.** "How do you decide a new AI service is ready for production?"

**Typical system-design prompt:** *Define the production readiness criteria and launch plan for an internal LLM
assistant moving from beta to general availability across the company.*

**1. Clarify first:** Users and traffic at GA versus beta? SLOs agreed with stakeholders? On-call team? Data
sensitivity? Dependencies (identity, document sources, GPU capacity)? Launch date constraints?

**2. Back-of-envelope sizing:**
- Beta of 500 users at 0.5 requests/s peak growing to 10,000 users at about 10 requests/s: a 20× load increase, so
  rerun the stress test at 12 to 15 requests/s with realistic prompts.
- A 99.5% SLO allows about 3.6 hours of errors a month. Fast-burn pages fire after 2% of the budget is used, about 4
  minutes into a full outage.
- On-call: a page every week is sustainable for a small team; ten a week isn't.
- Drills: database failover, zone loss, model server loss, and a restore from backup before GA.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Alerting | Cause-based alerts | SLO burn-rate alerts | Page on symptoms, ticket on causes |
| Post-deploy checks | Readiness probes only | Smoke tests as a rollout gate | Smoke tests on real user journeys |
| Failover proof | Design review | Drills under load | Drills, with measured RTO |
| Docs | Wiki pages | Docs as code in the repo | In the repo, checked in CI |
| Launch | Big bang | Staged rollout by user group | Staged, with SLO checks at each stage |

**4. Follow-up questions with crisp answers:**
- *The fast-burn alert fired for 2 minutes during a deploy and resolved.* The rollout dropped requests. Fix graceful
  shutdown and `maxUnavailable: 0`, rather than raising the threshold.
- *A judge model says groundedness went from 92% to 85% after a model upgrade.* Check judge agreement on the human
  sample first, then compare per question to find which kinds regressed.
- *Nobody reads the runbooks.* Use them in game days and rotate who's on call during rehearsals, and fix each runbook
  that was wrong.
- *Clients broke after a release.* Diff the OpenAPI document in CI, and add contract tests that run the published
  client examples.

**Debug this (common onsite question):** "The availability SLO dashboard shows 99.97%, but users say the assistant was
useless all afternoon."
1. Errors were near zero all afternoon.
2. `atlas_degraded_total` was high: the model server was overloaded, and most answers were retrieval-only.
3. The degraded answers returned 200, so the availability SLI counted them as successes, and the degraded-answer alert
   was routed to a channel nobody watched.
4. Fix: define a "good answer" SLI that excludes degraded answers, page on it, and capacity-plan the model servers for
   the afternoon peak.

The lesson: an SLI must match what users experience as success, not just HTTP status codes.

**5. What separates senior from staff answers:** a senior engineer writes tests, alerts, and docs. A staff engineer
defines readiness as evidence (E2E gates, drilled failover with measured RTO, burn-rate paging with runbooks, an
accurate SLI that includes answer quality, a versioned API contract), presents misses honestly with plans, and makes
the system operable by people who didn't build it.

**Red flags:**
- No tests after deployment.
- Failover that has never been drilled.
- Pages on CPU and GPU usage.
- Alerts without runbooks.
- An SLI that counts fallbacks as fully successful.
- An unversioned API with free-form errors.
- A final report with no misses and no evidence.

---

## Failure modes

- **Green deployments that don't work:** readiness passes but user journeys fail. Fix: PostSync smoke tests on real
  questions.
- **Failover that takes 14 minutes:** stale connections and no timeouts. Fix: checked pools, short timeouts, one retry,
  and drills.
- **Alert fatigue:** cause-based pages nobody acts on. Fix: burn-rate paging, tickets for causes, weekly noise review.
- **Silent degradation:** fallbacks count as success. Fix: a good-answer SLI and a degraded-answer alert.
- **Tribal knowledge:** only the author can operate the system. Fix: runbooks per page, tested in game days.
- **Breaking API changes:** clients fail after a release. Fix: versioned routes and OpenAPI diffs in CI.
- **Leaked demo credentials:** unlimited abuse. Fix: scoped, rate-limited, expiring demo tokens.
- **A report without evidence:** claims reviewers can't verify. Fix: generate the results table from result files.

## Checklist

- [ ] An E2E suite runs after every sync as a PostSync hook and every 15 minutes as a synthetic monitor.
- [ ] I drilled pod, zone, and database failover under load and recorded the measured RTO for each.
- [ ] I ran `s51_burn_rate.py`, and my alerts page on burn rate, TTFT, and degraded answers.
- [ ] Every paging alert has a runbook, checked in CI.
- [ ] The README, architecture with ADRs, operations guide, API reference, system card, and security notes are in the
  repository.
- [ ] The `/v1` API has typed models, SSE streaming, request IDs, stable errors, and a scoped demo token.
- [ ] My final report's results table is generated from evidence and explains every miss.
- [ ] I rehearsed the 30-minute walkthrough and recorded real timings.
