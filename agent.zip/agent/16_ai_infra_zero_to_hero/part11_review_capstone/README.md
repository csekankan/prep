# Part XI — Review and Capstone (Sections 47–52, lectures 323–365)

The course review and a five-part capstone. Section 47 connects everything you've learned and checks your readiness
with a practice test. Sections 48 to 52 then build one system from proposal to presentation: **Atlas**, a
retrieval-augmented support assistant that answers questions about this course's own 52 sections, with sources.

| § | Section | You will be able to | Exercise |
|---|---|---|---|
| 47 | [Course Review](s47_course_review.md) | Connect hardware, cloud, Kubernetes, MLOps, monitoring, security, and cost, fix a broken deployment under time pressure, and pass a 30-question practice test | — |
| 48 | [Capstone 1: Proposal and Design](s48_capstone_proposal.md) | Choose a domain, write numeric success metrics, draw a blueprint, estimate cost per environment, pick tools, write a risk register, and defend the proposal | [`s48_capstone_cost.py`](../exercises/s48_capstone_cost.py), [`s48_proposal/`](../exercises/s48_proposal/check_proposal.py) |
| 49 | [Capstone 2: Build the First Prototype](s49_capstone_prototype.md) | Terraform a GPU environment, containerize and deploy the gateway and model server, build idempotent ingestion into pgvector, ship through eval-gated CI/CD, and build the first dashboard | — |
| 50 | [Capstone 3: Scale and Harden](s50_capstone_scale.md) | Fine-tune with LoRA across nodes, detect drift, secure endpoints with tokens and network policy, measure unit cost, run HA across zones, and stress-test to find capacity | [`s50_scale_check.py`](../exercises/s50_scale_check.py) |
| 51 | [Capstone 4: Testing, Reliability, and Documentation](s51_capstone_testing_docs.md) | Gate deployments on E2E tests, drill failover, page on burn rate, write runbooks and a system card, publish a versioned API, and write an evidence-based report | [`s51_burn_rate.py`](../exercises/s51_burn_rate.py) |
| 52 | [Capstone 5: Demo, Presentation, and Graduation](s52_capstone_presentation.md) | Prepare a demo that won't fail, report benchmarks with intervals, present to stakeholders, review peers, and build a graduation portfolio | [`s52_benchmark_ci.py`](../exercises/s52_benchmark_ci.py) |

```mermaid
flowchart LR
  P10["Part X: AI infra<br/>in context"] --> S47["§47 Review<br/>practice test"]
  S47 --> S48["§48 Proposal<br/>metrics, cost, risks"]
  S48 --> S49["§49 Prototype<br/>K8s, pgvector, CI/CD"]
  S49 --> S50["§50 Scale + harden<br/>LoRA, drift, IAM, HA"]
  S50 --> S51["§51 Test + document<br/>E2E, failover, alerts"]
  S51 --> S52["§52 Present<br/>demo, benchmarks, portfolio"]
```

**How to read it:** after Part X, Section 47 reviews the whole course. The capstone then follows the life of a real
project. Section 48 proposes Atlas with measurable targets and a cost estimate. Section 49 builds a working prototype
on Kubernetes with a vector database and CI/CD. Section 50 scales it and makes it secure and highly available.
Section 51 tests it, drills failures, and documents it, and Section 52 demonstrates and presents it, then looks
ahead to what to learn next.

**Terms in this diagram.**
- **Practice test**: the 30-question self-check at the end of Section 47. Passing needs 24 correct.
- **pgvector**: the Postgres extension Atlas uses to store and search document embeddings.
- **CI/CD**: continuous integration and delivery, the automated path from a commit to a deployment.
- **LoRA**: low-rank adaptation, a cheap way to fine-tune a model by training small added weights.
- **IAM**: identity and access management.
- **HA**: high availability, staying up when parts fail.
- **E2E**: end-to-end tests that call the deployed system the way users do.
- **Failover**: switching to a standby component when the active one fails.
- **Portfolio**: the public repository, report, video, and diagrams you graduate with.

**The Atlas numbers that run through Part XI.** Each comes from an exercise or an earlier section:

| Number | Where it comes from |
|---|---|
| 3 L4 GPUs for 10 requests/s at peak | Sizing from 2,500 output tokens/s in `s48_capstone_cost.py` |
| $0.27 per 1,000 requests in production, $554 a month for scale-test | `s48_capstone_cost.py` |
| LoRA scales at 91% on 4 nodes; full fine-tuning at 37% on 2 | `s50_scale_check.py` |
| Availability 98.36% for the prototype vs 99.90% for the HA design | `s50_scale_check.py` |
| Measured capacity 10.1 requests/s at the SLO | The Section 50 stress test, checked in `s50_scale_check.py` |
| A full outage pages in 4.3 minutes, a 2% leak becomes a ticket after 18 hours | `s51_burn_rate.py` |
| Prefix caching cuts TTFT p95 by 29%, with intervals that don't overlap | `s52_benchmark_ci.py` |

**How to finish the course:** complete every section's checklist, pass the Section 47 practice test (24 of 30), and
score at least 70% on the Section 52 presentation rubric.
