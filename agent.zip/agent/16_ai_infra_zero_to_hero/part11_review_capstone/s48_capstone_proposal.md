# Section 48 — Capstone Project 1: Proposal and Design

> Lectures 330–336 • Assessments: [Defend the capstone infrastructure proposal](#assessment--defend-the-capstone-infrastructure-proposal) • Exercise: [`s48_capstone_cost.py`](../exercises/s48_capstone_cost.py)
> **After this section you can:** choose a capstone that exercises real infrastructure skills, define measurable success
> metrics, draw an initial blueprint, estimate cloud costs per environment, pick tools with reasons, write a risk
> register, and defend the whole proposal in front of a review panel.
>
> Builds on: [Section 47](s47_course_review.md) (course review), [Section 12](../part03_mlops_cicd_cost/s12_cost_optimization.md) (cost),
> [Section 41](../part10_ai_infra_in_context/s41_startups.md) (budgets), and
> [Section 42](../part10_ai_infra_in_context/s42_enterprises.md) (architecture review boards).

The capstone runs across Sections 48 to 52. You propose a project here, build a first prototype in Section 49, scale and
harden it in Section 50, test and document it in Section 51, and present it in Section 52. All five sections use one
reference project called **Atlas**, a retrieval-augmented support assistant. You can build Atlas as-is or swap in your
own domain and keep the same structure.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 330 | Choosing a capstone domain (NLP, vision, generative AI) | Pick the project that exercises the most infrastructure you can afford, not the flashiest model |
| 331 | Defining success metrics for an infra project | Write numeric targets for latency, availability, quality, cost, and operability before building |
| 332 | Designing the initial infrastructure blueprint | One diagram, four environments, and a clear request path and data path |
| 333 | Estimating hardware and cloud costs | Size GPUs from peak tokens per second, price each environment, and find the always-on costs |
| 334 | Selecting tools and frameworks for the build | Prefer boring, well-documented tools, and write down why each one won |
| 335 | Identifying risks and mitigation plans | Score risks by likelihood and impact, and give each one a mitigation, a trigger, and an owner |
| 336 | Lab: capstone project proposal | Write a proposal and check it with a small linter |

```mermaid
flowchart LR
  DOM["(1) Domain<br/>NLP, vision, GenAI"] --> MET["(2) Success metrics<br/>SLOs, quality, cost"]
  MET --> BLU["(3) Blueprint<br/>request + data paths"]
  BLU --> COST["(4) Cost estimate<br/>per environment"]
  COST --> TOOLS["(5) Tools<br/>with reasons"]
  TOOLS --> RISK["(6) Risk register"]
  RISK --> PROP["(7) Proposal<br/>reviewed + defended"]
  PROP -.feeds.-> BUILD["Sections 49 to 52<br/>build, scale, test, present"]
```

**How to read it:** a proposal is built in order. The domain decides what the metrics measure. The metrics decide what
the blueprint must achieve. The blueprint decides what you pay for, and the cost decides which tools are realistic.
Risks come from all of these. The finished proposal is defended in a review and then guides the build in Sections 49
to 52.

**Terms in this diagram.**
- **NLP**: natural language processing, models that read or write text.
- **GenAI**: generative AI, models that create text, images, audio, or code.
- **SLOs**: service level objectives, numeric targets for how the service behaves, such as "95% of requests under 2 s".
- **Blueprint**: the first architecture diagram and component list.
- **Risk register**: a table of what might go wrong, how likely and how bad it is, and what you'll do about it.

---

## Lecture 330 — Choosing a capstone domain (NLP, vision, generative AI)

**Why it matters.** The capstone shows what you can build and run. A project with an impressive model but a single
notebook demonstrates little infrastructure. A modest model behind a well-run platform, with CI/CD, monitoring,
autoscaling, security, and cost control, demonstrates almost everything in this course. The domain choice decides how
much of that you get to show.

**In plain words.** It's like choosing a house to renovate for a portfolio. A small house where you redo the wiring,
plumbing, and foundation shows more skill than a mansion where you only paint one wall.

**Architecture: what each domain exercises.**

```mermaid
flowchart TB
  subgraph NLP["NLP: RAG support assistant"]
    N1["Ingestion pipeline"] --> N2["Vector store"]
    N2 --> N3["LLM serving<br/>streaming, batching"]
  end
  subgraph VIS["Vision: defect detection"]
    V1["Image pipeline<br/>+ labeling"] --> V2["Training job<br/>multi-GPU"]
    V2 --> V3["Batch + edge inference"]
  end
  subgraph GEN["GenAI: image generation API"]
    G1["Diffusion model"] --> G2["Async queue<br/>GPU workers"]
    G2 --> G3["Object storage<br/>+ CDN"]
  end
  NLP --> COMMON["Common platform<br/>K8s, CI/CD, monitoring, IAM, cost"]
  VIS --> COMMON
  GEN --> COMMON
```

**How to read it:** each domain has its own core pipeline at the top, and all three sit on the same common platform at
the bottom. The NLP project exercises data ingestion, a vector store, and LLM serving. The vision project exercises
labeled image data, training, and batch or edge inference. The generative image project exercises long-running GPU
jobs behind a queue and large outputs in object storage. The common platform is where most of the course's skills
show.

**Terms in this diagram.**
- **RAG**: retrieval-augmented generation. The system first finds relevant documents and then asks the LLM to answer
  using them.
- **Ingestion pipeline**: the jobs that load documents, split them into chunks, embed them, and store them.
- **Vector store**: a database that finds the stored embeddings closest to a query embedding.
- **LLM serving**: running the language model behind an API, here with streaming output and request batching.
- **Multi-GPU**: training on more than one GPU at once (Section 8).
- **Batch + edge inference**: scoring many images offline, and running the model on devices near the camera.
- **Diffusion model**: an image model that generates pictures by removing noise step by step.
- **Async queue**: requests wait in a queue and GPU workers take them when free. The client checks back for the result.
- **CDN**: content delivery network, servers around the world that cache files close to users.
- **K8s, CI/CD, IAM**: Kubernetes; continuous integration and delivery; identity and access management.

**Core ideas.**
- **Score options against criteria**, not excitement. Useful criteria: infrastructure depth, feasibility on your
  budget, data availability, how clear the demo is, and relevance to the jobs you want.
- **Infrastructure depth** means how many course skills the project uses for real: data pipelines, training or
  fine-tuning, serving, autoscaling, monitoring, drift, security, multi-tenancy, and cost.
- **Feasibility** is mostly GPU cost and quota. A 7B LLM, a diffusion model, or multi-node training can blow a student
  budget. Small models such as 0.5B to 3B LLMs or a ResNet fine-tune are fine, because the infrastructure is the point.
- **Public data only.** Use open datasets or synthetic data, so you can share the repository and demo freely.
- **Pick one primary domain.** Combining a RAG assistant, a vision model, and an image generator triples the work and
  makes each part shallow.

```python
WEIGHTS = {"infra_depth": 0.30, "feasible_on_budget": 0.25, "data_available": 0.20,
           "demo_clarity": 0.15, "career_relevance": 0.10}
OPTIONS = {
    "NLP: RAG support assistant":  {"infra_depth": 5, "feasible_on_budget": 4, "data_available": 4,
                                    "demo_clarity": 5, "career_relevance": 5},
    "Vision: defect detection":    {"infra_depth": 4, "feasible_on_budget": 4, "data_available": 3,
                                    "demo_clarity": 4, "career_relevance": 3},
    "GenAI: image generation API": {"infra_depth": 4, "feasible_on_budget": 2, "data_available": 4,
                                    "demo_clarity": 5, "career_relevance": 4},
}
score = lambda s: sum(WEIGHTS[k] * v for k, v in s.items())
for name, s in sorted(OPTIONS.items(), key=lambda kv: -score(kv[1])):
    print(f"{score(s):.2f}  {name}")
# 4.55  NLP: RAG support assistant
# 3.70  Vision: defect detection
# 3.65  GenAI: image generation API
```

In the code, each option gets a 1-to-5 score on each criterion, and the weights add up to 1. The RAG assistant wins
mainly on infrastructure depth and career relevance. The image generator scores well on the demo but loses on budget,
because diffusion models need a GPU for several seconds per image. Change the weights to match your goals, and if two
options end up within about 0.2 of each other, choose the one you can finish.

**Example: the reference capstone, Atlas.** Atlas is a support assistant for the help center of a fictional software
company. Users ask questions in a chat box and get answers with links to the help articles used. Behind it: an
ingestion pipeline that turns a public documentation set (for example, the Kubernetes docs) into chunks and embeddings
in Postgres with pgvector, a FastAPI gateway with authentication and rate limits, a small open LLM served by vLLM on a
GPU (or llama.cpp on CPU for development), MLflow for prompt and model versions, and the full platform around it.
Atlas exercises almost every part of this course on a budget of a few hundred dollars.

**Senior / FAANG best practice.** Choose the project the way you'd choose a quarter's roadmap item: the highest impact
you can deliver with the resources you have. Write a one-paragraph problem statement ("who uses it, what it does for
them, how we'll know it works") before choosing tools. Reviewers trust a narrow project done properly far more than a
broad one that only works on the demo laptop.

---

## Lecture 331 — Defining success metrics for an infra project

**Why it matters.** Without numbers, "it works" means "it worked once on my machine". Success metrics turn the
capstone into something you can test, monitor, and defend. They also drive the design, because a 99.9% availability
target needs a different architecture from a 99% target.

**In plain words.** It's like agreeing on the finish line before a race. You decide in advance how fast, how
reliable, and how cheap counts as success, so nobody argues about it afterwards.

**Architecture: from user goals to measured metrics.**

```mermaid
flowchart LR
  GOAL["User goals<br/>fast, correct, available"] --> SLI["SLIs<br/>what we measure"]
  SLI --> SLO["SLOs<br/>numeric targets"]
  SLO --> DASH["Dashboards + alerts<br/>Section 49 and 51"]
  SLO --> TEST["Load + E2E tests<br/>Sections 50 and 51"]
  BIZ["Budget + operability goals"] --> SLO
```

**How to read it:** start from what users and the business care about. Each goal becomes one or more SLIs, things you
can measure. Each SLI gets an SLO, a numeric target. The same SLOs then appear in the dashboards and alerts you build
in Sections 49 and 51 and in the tests you run in Sections 50 and 51. Budget and operability goals, such as cost per
request and rollback time, become targets in the same way.

**Terms in this diagram.**
- **SLIs**: service level indicators, measured values such as latency, error rate, or retrieval recall.
- **E2E tests**: end-to-end tests that send real requests through the whole system.
- **Operability**: how easy the system is to deploy, change, debug, and recover.

**Core ideas.** Use five groups of metrics and write a target for each one.

| Group | Metric (SLI) | Atlas target (SLO) |
|---|---|---|
| Latency | Time to first token, p95, at 5 requests/s | under 1.5 s |
| Latency | Full answer time, p95, at 5 requests/s | under 6 s |
| Availability | Successful requests during the demo window | at least 99.5% |
| Quality | Retrieval recall@5 on a 100-question golden set | at least 0.85 |
| Quality | Answers grounded in the retrieved articles (judge plus human spot check) | at least 90% |
| Cost | Cost per 1,000 requests at average traffic | under $0.50 |
| Cost | Monthly spend while building | under $600 |
| Operability | Commit to production (lead time) | under 15 minutes |
| Operability | Rollback to the previous version | under 5 minutes |
| Operability | Recovery in a game day (MTTR) | under 15 minutes |
| Monitoring | Drift alert after an injected data shift | within 1 hour |

- **Percentiles, not averages.** p95 and p99 show what slow users feel. Averages hide them.
- **Quality needs a golden set.** A fixed set of questions with known correct articles lets you measure retrieval and
  answers after every change. Build it in week 1.
- **State the load** for each latency target. "p95 under 1.5 s" is meaningless without "at 5 requests/s".
- **Keep the list short.** Ten to twelve metrics is enough. Each one should change a decision if it's missed.

```yaml
# slo.yaml, read by the load test (Section 50) and the alert rules (Section 51)
service: atlas
slos:
  - name: ttft_p95
    sli: histogram_quantile(0.95, sum by (le) (rate(atlas_ttft_seconds_bucket[5m])))
    target: "< 1.5"
    at_load_rps: 5
  - name: availability
    sli: 1 - sum(rate(atlas_requests_total{code=~"5.."}[30m])) / sum(rate(atlas_requests_total[30m]))
    target: ">= 0.995"
  - name: retrieval_recall_at_5
    sli: offline, eval/golden_set.jsonl
    target: ">= 0.85"
  - name: cost_per_1k_requests
    sli: opencost namespace=atlas / requests
    target: "< 0.50"
```

In the code, each SLO has a name, how it's measured, and a target. The PromQL expressions compute the 95th percentile
of time to first token from a histogram, and availability as one minus the share of 5xx responses. Offline metrics,
such as retrieval recall, name the dataset they use. Keeping the targets in one file means the tests, alerts, and
final report all use the same numbers.

**Example: the target that changed the design.** A student first wrote "99.9% availability" for their capstone. Over a
30-day month that allows about 43 minutes of downtime, and a single GPU node with a 10-minute model load time uses a
quarter of that on every restart. They had two choices: run two GPU replicas across zones, or lower the target to
99.5% (about 3.6 hours a month) for a capstone measured during a demo window. They chose 99.5% with a written reason,
and the reviewers accepted it because the trade-off was explicit.

**Senior / FAANG best practice.** Every metric has an owner, a data source, and a target, and the targets come from
user needs and budget, not from what the system happens to do. Teams at Google write SLOs with error budgets, and a
missed budget changes priorities. Write yours the same way, and decide in advance what you'll do if one is missed.

---

## Lecture 332 — Designing the initial infrastructure blueprint

**Why it matters.** The blueprint is the shared picture that every later decision refers to. It shows reviewers you
understand how requests flow, where data lives, what can fail, and what you'll actually build. A clear blueprint also
keeps the build focused: anything not on it is out of scope until you change the blueprint.

**In plain words.** It's like an architect's floor plan before construction. You can move a wall on paper for free.
Moving it after the concrete is poured is expensive.

**Architecture: the Atlas blueprint.**

```mermaid
flowchart LR
  USER["User<br/>chat UI or API"] --> ING["Ingress<br/>TLS, WAF"]
  ING --> GW["Gateway<br/>FastAPI: auth, rate limit"]
  GW --> RET["Retriever<br/>embed + search"]
  RET --> PG[("Postgres<br/>+ pgvector")]
  GW --> LLM["LLM server<br/>vLLM on L4 GPU"]
  DOCS[("Docs bucket")] --> PIPE["Ingestion job<br/>chunk, embed"]
  PIPE --> PG
  REG["MLflow<br/>prompts + models"] -.version.-> GW
  REG -.version.-> LLM
  OBS["Prometheus, Grafana, Loki<br/>OpenCost"] -.scrape.-> GW
  OBS -.scrape.-> LLM
```

**How to read it:** the request path goes from left to right. A user's question arrives through the ingress, which
terminates TLS and filters bad traffic. The gateway checks the API key and rate limit, asks the retriever for the most
relevant chunks (the retriever embeds the question and searches pgvector), and sends the question plus chunks to the
LLM server, which streams the answer back. The data path runs underneath: documents land in a bucket, and an
ingestion job chunks and embeds them into Postgres. MLflow records which prompt and model versions the gateway and LLM
server use. The observability stack scrapes metrics from both services.

**Terms in this diagram.**
- **Ingress**: the Kubernetes entry point that routes outside traffic to services.
- **TLS**: transport layer security, the encryption behind HTTPS.
- **WAF**: web application firewall, rules that block common attacks and abusive traffic.
- **FastAPI**: a Python web framework for building APIs.
- **Retriever**: the component that turns a question into an embedding and finds the nearest chunks.
- **pgvector**: a Postgres extension that stores embeddings and runs nearest-neighbor search.
- **vLLM**: an open-source LLM server with continuous batching and paged attention (Sections 14 and 15).
- **L4 GPU**: an NVIDIA data-center GPU with 24 GB of memory, cheap enough for small models.
- **MLflow**: an open-source tool for experiment tracking and a model registry (Section 9).
- **Prometheus, Grafana, Loki**: metrics collection, dashboards, and log storage (Section 16).
- **OpenCost**: an open-source tool that assigns Kubernetes costs to namespaces and workloads (Section 12).

**Core ideas.**
- **Draw two paths.** The request path (latency matters) and the data path (freshness and correctness matter) have
  different failure modes and scaling needs.
- **Plan four environments.** Not every environment needs a GPU or a managed cluster.

| Environment | Where | Model server | Purpose |
|---|---|---|---|
| dev | Laptop, kind cluster | llama.cpp on CPU, 0.5B model | Fast iteration for free |
| demo | One L4 GPU VM | vLLM, 1.5B model | Realistic latency, run only when needed |
| scale-test | Managed Kubernetes, part-time | vLLM on a GPU node pool | Autoscaling, HA, and load tests (Section 50) |
| production (design only) | Managed Kubernetes, 24/7 | vLLM, 3 or more GPUs | Costed in the proposal, not necessarily run |

- **Same manifests everywhere.** Use one Helm chart or Kustomize base with an overlay per environment, so dev and
  scale-test differ only in values.
- **Mark failure domains.** Note which components are single points of failure in the first version and when you'll fix
  them. For Atlas, Postgres and the single GPU are both single points of failure until Section 50.
- **Show trust boundaries.** Mark where authentication happens and which components hold secrets.

```text
atlas/
├── services/
│   ├── gateway/          # FastAPI: auth, rate limit, retrieval, streaming proxy to the LLM
│   └── ingest/           # chunk + embed job, run as a Kubernetes Job or CronJob
├── deploy/
│   ├── base/             # Kustomize base: Deployments, Services, HPA, PDB, NetworkPolicy
│   └── overlays/{dev,demo,scale-test}/
├── infra/                # Terraform: VPC, cluster, GPU node pool, Postgres, bucket, budgets
├── eval/                 # golden_set.jsonl, eval.py (recall@5, groundedness)
├── load/                 # k6 or Locust scripts that read slo.yaml
├── .github/workflows/    # CI: test, scan, build, sign, push; CD via Argo CD
└── docs/                 # proposal, ADRs, runbooks, final report
```

In the code, the repository layout mirrors the blueprint. Each service has its own folder, deployment manifests have
one base and an overlay per environment, cloud resources live in Terraform, and evaluation and load tests are part of
the repository rather than ad hoc scripts. ADRs are architecture decision records, short documents that record each
major decision and its reasons.

**Example: the missing data path.** A first-draft blueprint showed only the chat request flow. In review, the panel
asked how documents get into the vector store, how often, and what happens when an article is deleted. The student
added the ingestion job, a nightly schedule, an upsert keyed on the article ID, and deletion of chunks for removed
articles. That addition later became one of the drift checks: the share of answers citing articles that no longer
exist.

**Senior / FAANG best practice.** Keep the blueprint to one page and update it whenever the design changes, with the
diagram checked into the repository as code (Mermaid or similar). Reviewers at large companies look first for the
request path, data path, failure domains, and trust boundaries. If they can't find those in one minute, the design
review stalls.

---

## Lecture 333 — Estimating hardware and cloud costs

**Why it matters.** Cost surprises end projects. A forgotten GPU VM, a NAT gateway, or a managed control plane left
running can spend a student budget in weeks. A cost estimate per environment also shows reviewers that you understand
which design choices drive spend.

**In plain words.** It's like planning a road trip budget. Fuel depends on distance, but parking, tolls, and the hotel
you forgot to cancel add up too. List every item, not only the obvious one.

**Architecture: how the estimate is built.**

```mermaid
flowchart LR
  LOAD["Traffic assumptions<br/>peak + average req/s"] --> TOK["Tokens per second<br/>req/s x output tokens"]
  TOK --> GPUS["GPU count<br/>tok/s / usable per GPU"]
  GPUS --> ENV["Price per environment<br/>hours x rate"]
  FIXED["Always-on items<br/>control plane, DB, NAT"] --> ENV
  ENV --> UNIT["Unit cost<br/>$ per 1,000 requests"]
  ENV --> BUD["Budget + alerts"]
```

**How to read it:** traffic assumptions become output tokens per second at peak, which divided by what one GPU can
sustain at a safe utilization gives the GPU count. Each environment is then priced as hours used times hourly rates,
plus the always-on items that bill every hour whether you use them or not. The result gives two numbers: the cost per
1,000 requests, and a monthly budget with alerts.

**Terms in this diagram.**
- **req/s**: requests per second.
- **tok/s**: tokens per second, here output tokens generated by the LLM.
- **Control plane**: the managed Kubernetes API servers, billed per cluster-hour.
- **NAT**: network address translation gateway, which lets private nodes reach the internet and bills per hour and per
  GB.
- **Unit cost**: the cost of one unit of work, such as 1,000 requests.

**Core ideas.**
- **Size from the bottleneck.** For LLM serving it's output tokens per second at peak. Atlas assumes 10 requests/s at
  peak and 250 output tokens per answer, which is 2,500 output tokens/s.
- **Benchmark one GPU, then divide.** The exercise assumes one L4 sustains 1,400 output tokens/s for a 1.5B to 3B
  model with vLLM batching, and uses 60% of that (840 tokens/s) to protect latency. 2,500 / 840 rounds up to 3 GPUs.
  Replace the 1,400 with your own benchmark from Section 49.
- **Separate always-on costs from usage costs.** Control planes, databases, NAT gateways, and load balancers bill every
  hour. GPU nodes bill only while running, so schedule them off.
- **Price every environment**, and set a budget alert per account or project at 50%, 80%, and 100%.

```bash
python3 exercises/s48_capstone_cost.py
```

```text
dev         $     0.00/month   (kind + llama.cpp on CPU)
demo        $    33.35/month   (1 L4 VM, 40 h/month)
scale-test  $   553.64/month   (EKS, 2 CPU + GPU pool, 8 h x 20 days)
    GPU nodes          $   386.40
    EKS control plane  $    73.00
    CPU nodes          $    30.72
    Postgres           $    23.36
    Load balancer      $     6.16
    NAT gateway        $    32.85
    Object storage     $     1.15
production  $ 2,142.01/month   (24/7, 10 req/s peak)

production GPUs for 10 req/s peak: 3 (peak 2,500 output tokens/s vs 840 usable per GPU)
production cost per 1,000 requests at 3.0 req/s average: $0.272
scale-test: always-on items (control plane, Postgres, NAT) are $129.21 = 23% of the bill even though nodes run only 160 h
```

In the output, the demo costs $33.35 a month because the GPU VM runs only 40 hours. The scale-test environment costs
$553.64, mostly for three GPUs running 160 hours, but $129.21 of it (23%) is always-on items that bill all 730 hours
of the month. Production at 24/7 would cost about $2,142 a month, or $0.272 per 1,000 requests at 3 requests/s
average, which meets the $0.50 target. Prices are illustrative on-demand rates, so replace them with current quotes for
your provider and region.

**Example: the weekend bill.** A student left a three-GPU scale-test node pool running from Friday evening to Monday
morning: 62 hours × 3 × $0.805, about $150, a quarter of the monthly budget. The fix took ten minutes: a scheduled job
that scales the GPU node pool to zero at 8 p.m., a TTL label on test clusters, and a budget alert at 50%. It's in the
risk register in Lecture 335 as "cloud bill overrun".

**Senior / FAANG best practice.** Present cost as a unit cost and a total, with assumptions listed and a sensitivity
range ("if peak doubles, GPUs go from 3 to 6 and cost per 1,000 requests stays about the same"). FinOps teams at large
companies ask for exactly this before approving spend, and they compare the estimate with actual spend every month.

---

## Lecture 334 — Selecting tools and frameworks for the build

**Why it matters.** Tool choices decide how much time goes into building the project and how much goes into fighting
the tools. A capstone with eight new tools you've never used rarely finishes. Reviewers also want to see that each
choice was made for a reason, with alternatives considered.

**In plain words.** It's like packing for a hike. You bring tools you know how to use and that have been tested on the
trail, not the newest gadget you've never tried.

**Architecture: the Atlas toolchain by layer.**

```mermaid
flowchart TB
  APP["App layer<br/>FastAPI, vLLM, llama.cpp"] --> DATA["Data layer<br/>Postgres + pgvector, S3"]
  APP --> PLAT["Platform layer<br/>Kubernetes, Helm or Kustomize, KEDA"]
  PLAT --> INFRA["Infra layer<br/>Terraform, managed K8s, GPU node pool"]
  DEL["Delivery<br/>GitHub Actions, GHCR, Argo CD, cosign"] --> PLAT
  OBS["Observability<br/>Prometheus, Grafana, Loki, OpenCost"] --> PLAT
  ML["ML lifecycle<br/>MLflow, eval scripts, drift checks"] --> APP
```

**How to read it:** the layers stack from the application at the top to the infrastructure at the bottom. The
delivery, observability, and ML lifecycle tools sit beside the stack and act on it: delivery deploys onto the
platform, observability watches it, and the ML lifecycle tools version and evaluate what the app layer serves.

**Terms in this diagram.**
- **llama.cpp**: a lightweight LLM runtime that runs quantized models on CPU or GPU.
- **S3**: object storage (Amazon S3 or a compatible service such as MinIO).
- **Helm or Kustomize**: tools that template or patch Kubernetes manifests for each environment.
- **KEDA**: Kubernetes event-driven autoscaling, which scales workloads on metrics such as queue length (Section 14).
- **Terraform**: infrastructure as code, which creates cloud resources from versioned files.
- **GHCR**: GitHub Container Registry, which stores the built images.
- **Argo CD**: a GitOps tool that keeps the cluster matching what's in the Git repository.
- **cosign**: a tool that signs container images and verifies the signatures (Section 10).

**Core ideas.** Write each choice as a short table row with its alternative and the reason.

| Need | Choice | Alternative considered | Why this choice |
|---|---|---|---|
| LLM serving (GPU) | vLLM | TGI, SGLang | Mature, OpenAI-compatible API, continuous batching, wide model support |
| LLM serving (CPU dev) | llama.cpp server | Ollama | Same OpenAI-style API on a laptop, small quantized models |
| Vector search | Postgres + pgvector | Qdrant, OpenSearch | One database for metadata and vectors; enough for under a few million chunks |
| Orchestration | Managed Kubernetes (EKS or GKE) + kind locally | Docker Compose, ECS | The course's main platform; same manifests locally |
| Infra as code | Terraform | Pulumi, console clicks | Reproducible, reviewable, easy to tear down |
| CI / CD | GitHub Actions + Argo CD | GitLab CI, Flux | Free for public repos; GitOps gives audit and rollback |
| Observability | kube-prometheus-stack, Loki | Datadog | Free and open source, standard PromQL |
| Model and prompt versions | MLflow | Weights & Biases | Self-hosted registry, covered in Section 9 |
| Cost | OpenCost + cloud budgets | Kubecost | Open source, cost per namespace |

- **Boring beats new.** Prefer tools with good documentation and many users, so you can find answers to problems.
- **Managed where it doesn't teach anything.** A managed database and control plane save days, and running them
  yourself teaches little the course hasn't covered.
- **Pin versions.** Record the exact image tags and chart versions you tested, and upgrade on purpose.
- **Check licenses** for models and tools, especially if the project might become public or commercial.

```bash
# versions.env, sourced by CI and the Makefile. Example values: pin the versions you actually test.
PYTHON_VERSION=3.11
K8S_VERSION=1.31
KIND_NODE_IMAGE=kindest/node:v1.31.0
VLLM_IMAGE=vllm/vllm-openai:v0.8.5
LLAMACPP_IMAGE=ghcr.io/ggml-org/llama.cpp:server
POSTGRES_IMAGE=pgvector/pgvector:pg16
MODEL_GPU=Qwen/Qwen2.5-1.5B-Instruct
MODEL_CPU=Qwen/Qwen2.5-0.5B-Instruct-GGUF:Q4_K_M
EMBED_MODEL=BAAI/bge-small-en-v1.5
```

In the code, every image, model, and version that the build depends on is in one file, so CI, the Makefile, and the
documentation all agree. The GPU and CPU models come from the same family, so prompts behave similarly in dev and in
the demo. The embedding model is small enough to run on CPU in the gateway or the ingestion job.

**Example: the vector database detour.** A student started with a dedicated vector database because a blog post
recommended it, then spent a week on its cluster setup, backups, and authentication. Their corpus had 40,000 chunks.
Switching to pgvector in the Postgres instance they already had for metadata removed a component, a backup job, and a
set of credentials, and searches still finished in a few milliseconds.

**Senior / FAANG best practice.** Write an ADR for each choice that's expensive to reverse (the serving engine, the
vector store, the cluster platform). Large companies limit new technologies per project for the same reason: each one
adds operations, security review, and on-call knowledge. Spend your novelty budget where it teaches you the most.

---

## Lecture 335 — Identifying risks and mitigation plans

**Why it matters.** Every project hits problems. The difference between projects that finish and those that don't is
usually whether the problems were expected and planned for. A risk register also shows reviewers you've thought past
the happy path.

**In plain words.** It's like checking the weather before a hike and packing a rain jacket. You can't stop the rain,
but you can decide in advance what you'll do if it comes.

**Architecture: the risk management loop.**

```mermaid
flowchart LR
  ID["Identify<br/>tech, cost, schedule, security"] --> SCORE["Score<br/>likelihood x impact"]
  SCORE --> PLAN["Mitigate<br/>reduce, avoid, accept"]
  PLAN --> TRIG["Trigger + owner<br/>when to act, who acts"]
  TRIG --> REV["Review weekly"]
  REV --> ID
```

**How to read it:** you identify risks across technology, cost, schedule, and security, score each one, choose a
mitigation, and give it a trigger (the signal that the risk is happening) and an owner. The register is reviewed every
week, and new risks are added as you learn.

**Terms in this diagram.**
- **Likelihood x impact**: a 1-to-5 score for how probable the risk is, times a 1-to-5 score for how bad it would be.
- **Mitigate**: act to reduce the likelihood or impact. **Avoid** means change the plan so the risk can't happen.
  **Accept** means consciously take the risk because it's small or too costly to reduce.
- **Trigger**: an observable signal that the risk is happening, such as "budget alert at 80%".

**Core ideas.**
- **Cover four kinds of risk:** technical (the model is too slow), cost (the bill overruns), schedule (scope creep), and
  security and compliance (leaked secrets, unlicensed data).
- **Mitigations must be concrete** actions, not "be careful".
- **Fallbacks are mitigations.** A CPU model server for development, a recorded demo video, and a local kind cluster
  each reduce the impact of a different failure.
- **Score and sort.** Work on the top few. A 25-item register nobody reads protects nothing.

```python
RISKS = [  # (risk, likelihood 1-5, impact 1-5, mitigation)
    ("GPU quota not granted in time", 3, 5, "Request quota in week 1; llama.cpp CPU fallback; second region"),
    ("Cloud bill overrun", 3, 4, "Budget alerts at 50/80/100%; nightly scale-to-zero; TTL on test clusters"),
    ("Model quality too low for the demo", 2, 4, "Golden set from week 1; try a 3B model; tune retrieval first"),
    ("Scope creep", 4, 3, "Must/should/could list; freeze scope after week 2"),
    ("Secrets leaked in the repo", 2, 5, "Secret scanning in CI; external secrets; no long-lived keys"),
    ("Single point of failure in Postgres", 3, 3, "Managed Postgres with backups; tested restore; read-only mode"),
    ("Demo-day outage", 2, 5, "Frozen release; recorded backup video; local kind fallback"),
]
for r in sorted(RISKS, key=lambda r: -r[1] * r[2]):
    print(f"{r[1] * r[2]:>2}  L{r[1]} x I{r[2]}  {r[0]}")
# 15  L3 x I5  GPU quota not granted in time
# 12  L3 x I4  Cloud bill overrun
# 12  L4 x I3  Scope creep
# 10  L2 x I5  Secrets leaked in the repo
# 10  L2 x I5  Demo-day outage
#  9  L3 x I3  Single point of failure in Postgres
#  8  L2 x I4  Model quality too low for the demo
```

In the code, each risk has a likelihood and an impact from 1 to 5, and the product sorts the register. GPU quota comes
first because new cloud accounts often start with zero GPU quota, and requests can take days. That's why the first
mitigation is to request quota in week 1, before writing any code.

**Example: the quota that saved the schedule.** One student requested L4 quota on day 1, and the approval took four
days. Another waited until week 3, when their prototype was ready, and lost a week waiting, so they demoed on CPU. The
first student's register listed "GPU quota" as the top risk with the trigger "quota not approved by day 5". On day 5
they would have switched regions, and they didn't need to.

**Senior / FAANG best practice.** Large teams keep a risk register in the design document and review it at each
milestone, with an owner for each risk. Include **pre-mortem** risks: imagine the project failed and ask why. The
answers are usually scope, dependencies, and quotas, not the model.

---

## Lecture 336 — Lab: capstone project proposal

**Goal:** write a complete capstone proposal for Atlas (or your own project) and check it with a small linter that
catches missing sections, metrics without numbers, and risks without owners.

**What you're building:** `proposal.md`, a filled-in proposal following the structure in this section, and
`check_proposal.py`, a linter you can also run in CI so the proposal stays complete as it evolves.

```mermaid
flowchart LR
  TPL["proposal.md<br/>8 required sections"] --> LINT["check_proposal.py"]
  LINT -->|PASS| REVIEW["Review panel<br/>assessment"]
  LINT -->|FAIL| FIX["Fix the gaps"]
  FIX --> TPL
```

**How to read the diagram:** you write `proposal.md` with eight required sections, then run `check_proposal.py`. If
any check fails, you fix the proposal and run it again. A passing proposal goes to the review panel in the assessment
below. The terms, briefly: a **linter** is a program that checks a file against rules, and the **review panel** is the
group that questions your proposal.

**Prerequisites:** Python 3.10+, the cost exercise from Lecture 333, and about two hours.

### Step 1 — Write the proposal

Create `docs/proposal.md` with eight `## ` sections. The Atlas version is in
[`exercises/s48_proposal/proposal.md`](../exercises/s48_proposal/proposal.md), and you can use it as a model answer.
Its contents, section by section:

| Section | What the Atlas proposal says |
|---|---|
| Problem and users | Support engineers and customers search hundreds of help articles. Atlas answers in chat with links to the articles used |
| Success metrics | A table of 8 metrics, each with a number: time to first token p95 under 1.5 s and full answer p95 under 6 s at 5 req/s, availability at least 99.5%, recall@5 at least 0.85, grounded answers at least 90%, under $0.50 per 1,000 requests, lead time under 15 minutes, rollback under 5 minutes |
| Architecture | A Mermaid diagram of user, gateway, retriever, Postgres with pgvector, vLLM, and the ingestion job, plus the four environments |
| Cost estimate | dev $0, demo $33, scale-test $554, production $2,142 a month, or $0.27 per 1,000 requests |
| Tools | vLLM, llama.cpp, Postgres + pgvector, FastAPI, Kubernetes, Terraform, GitHub Actions, Argo CD, Prometheus, Loki, MLflow, OpenCost, with reasons in ADRs |
| Risks | A table of 5 risks with likelihood, impact, mitigation, and owner |
| Milestones | One milestone per week, matching Sections 49 to 52 |
| Out of scope | Fine-tuning, multi-region, user accounts beyond API keys, a production SLA |

### Step 2 — Write the linter

Create `check_proposal.py` (also in [`exercises/s48_proposal/`](../exercises/s48_proposal/check_proposal.py)):

```python
import re
import sys
from pathlib import Path

REQUIRED = ["Problem and users", "Success metrics", "Architecture", "Cost estimate",
            "Tools", "Risks", "Milestones", "Out of scope"]


def sections(text):
    parts = re.split(r"(?m)^## (.+)$", text)
    return {parts[i].strip(): parts[i + 1] for i in range(1, len(parts) - 1, 2)}


def table_rows(body):
    rows = [r for r in body.splitlines() if r.startswith("|") and not re.match(r"^\|[\s|:-]+\|$", r)]
    return [[c.strip() for c in r.strip("|").split("|")] for r in rows[1:]]


def main(path):
    secs = sections(Path(path).read_text())
    checks = []
    for name in REQUIRED:
        checks.append((f"section '{name}' present", any(h.startswith(name) for h in secs)))
    metrics = table_rows(secs.get("Success metrics", ""))
    checks.append(("at least 6 success metrics", len(metrics) >= 6))
    checks.append(("every metric has a numeric target", all(re.search(r"\d", m[-1]) for m in metrics)))
    checks.append(("architecture has a diagram", bool(re.search(r"(?m)^`{3}mermaid", secs.get("Architecture", "")))))
    cost = secs.get("Cost estimate", "")
    checks.append(("cost has a unit cost per 1,000 requests", "per 1,000" in cost))
    risks = table_rows(secs.get("Risks", ""))
    checks.append(("at least 5 risks", len(risks) >= 5))
    checks.append(("every risk has an owner", all(r[-1] for r in risks)))
    for name, ok in checks:
        print(f"{'PASS' if ok else 'FAIL'}  {name}")
    failed = sum(not ok for _, ok in checks)
    print(f"\n{len(checks) - failed}/{len(checks)} checks passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).with_name("proposal.md")))
```

The linter splits the proposal on `## ` headings, checks that the eight required sections exist, reads the metrics and
risks tables, and checks for numbers, a Mermaid diagram, a unit cost, and owners. With no argument it checks the
sample proposal next to it. It exits with 1 when anything fails, so it can run in CI.

### Step 3 — Run it, break it, fix it

```bash
python3 check_proposal.py docs/proposal.md
# Now delete the "Owner" values from two risks and remove the "per 1,000" phrase, then run it again.
python3 check_proposal.py docs/proposal.md
```

### Step 4 — Add it to CI

```yaml
# .github/workflows/docs.yml
name: docs
on: [pull_request]
jobs:
  proposal:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: python3 check_proposal.py docs/proposal.md
```

**Expected results:**
- The first run prints 14 `PASS` lines and `14/14 checks passed`, exit code 0.
- After removing two owners and the unit cost, `every risk has an owner` and `cost has a unit cost per 1,000 requests`
  fail, the summary reads `12/14 checks passed`, and the exit code is 1.
- With the workflow added, a pull request that removes a required section fails the `docs` check.
- Your own proposal fits on about two pages, and every number in it traces back to the cost exercise, a benchmark, or
  a stated assumption.

---

## Assessment — Defend the capstone infrastructure proposal

**Scenario (live exercise, about 30 minutes):** you present the Atlas proposal (or your own) to a review panel of a
staff infrastructure engineer, a security engineer, and a finance partner. You have 10 minutes to present and 20
minutes for questions. The panel approves, approves with conditions, or asks for a revision.

**Deliverable:** a 10-minute presentation from the proposal, answers to the panel's questions, and a decision record.
The panel's likely questions, with model answers:

| Panel question | Model answer |
|---|---|
| Why this domain and not something more ambitious? | The RAG assistant scored 4.55 against 3.70 and 3.65 on infrastructure depth, budget, data, demo, and relevance. It exercises ingestion, vector search, LLM serving, autoscaling, drift, IAM, and cost in one project, on a budget under $600 a month |
| Where did the GPU count come from? | 10 requests/s peak × 250 output tokens = 2,500 tokens/s. One L4 sustains about 1,400 tokens/s for this model size, and I plan at 60% of that, so 3 GPUs. The 1,400 is an assumption until my Section 49 benchmark, and the proposal will be updated with the measured value |
| What happens when the GPU node dies? | In the prototype, the LLM is down and the gateway returns a clear error. In the scale-test design, two or more replicas run across zones with a PodDisruptionBudget, and the gateway can fall back to retrieval-only answers ("here are the most relevant articles") if all LLM replicas are down |
| How do you know answers are correct? | A 100-question golden set with the correct articles for each question. Recall@5 must be at least 0.85, and at least 90% of answers must be grounded in the retrieved articles, checked by an LLM judge with a human spot check of 20 answers each release |
| Where are the secrets, and who can call the API? | API keys for clients, stored hashed. Cloud access through workload identity, with no long-lived keys in the cluster. Database credentials come from the cloud secret manager through External Secrets. Secret scanning runs in CI |
| What stops the bill from running away? | Budget alerts at 50%, 80%, and 100%, a nightly job that scales the GPU node pool to zero, TTL labels on test clusters, and OpenCost per namespace. The always-on items, $129 a month, are listed so they're not a surprise |
| What's explicitly out of scope? | Fine-tuning, multi-region, user accounts beyond API keys, and a production SLA. These are listed so the scope can't grow silently |
| What's your biggest risk? | GPU quota, scored 15. I requested quota on day 1, with a CPU fallback and a second region if it isn't approved by day 5 |

**Decision record, model answer:**
- **Decision:** approved with conditions.
- **Conditions:** replace the assumed 1,400 tokens/s with a measured benchmark by the end of Section 49 and update the
  GPU count and cost. Add the retrieval-only fallback to the Section 50 scope. Show the budget alert configuration in
  the first prototype review.
- **Rationale:** the scope fits the budget, the metrics are measurable, and the main risks have owners and triggers. The
  open question is throughput, which a benchmark resolves cheaply.
- **Owner and date:** the capstone author, before the Section 49 review.

**Scoring rubric:**

| Area | Weight | Strong (full marks) | Weak |
|---|---|---|---|
| Problem and scope | 15% | Clear users, value, and an out-of-scope list | Vague goal, everything in scope |
| Success metrics | 20% | Numeric SLOs with load conditions, quality from a golden set, cost and operability targets | "Fast and reliable" |
| Architecture | 20% | Request and data paths, environments, failure domains, trust boundaries | A list of tools with arrows |
| Cost | 15% | Sized from peak tokens/s, per environment, always-on items, unit cost | One total with no assumptions |
| Tools | 10% | Choices with alternatives and reasons | Choices with no reasons, or many new tools |
| Risks | 10% | Scored, concrete mitigations, triggers, owners | Generic risks, "be careful" |
| Defense | 10% | Answers with numbers, admits unknowns and how to resolve them | Defensive or guesses |

**What reviewers look for:**
- **Numbers traced to sources:** each figure comes from a benchmark, a calculation, or a stated assumption.
- **Honesty about unknowns**, with a cheap plan to resolve each one.
- **A scope that fits the budget and the schedule**, with an explicit out-of-scope list.
- **Failure thinking:** what breaks, what users see when it breaks, and how it recovers.
- **Security and cost designed in from the start**, not added at the end.

---

## FAANG deep-dive notes

**How big tech does it.** Google teams write design documents with context, goals and non-goals, the design,
alternatives considered, and cross-cutting concerns (security, privacy, reliability, cost), and review them with senior
engineers before building. Amazon uses six-page narratives and PR/FAQ documents ("press release and frequently asked
questions") written as if the product had launched, read silently at the start of the meeting. Meta and others run
architecture and privacy reviews for significant launches. In all of them, the proposal is where scope, metrics, and
risks are agreed, because changing them later costs far more.

**Staff review questions.**
- What are the goals and, just as important, the non-goals?
- Which metric tells us this worked, and what's its target under what load?
- What's the unit cost, and what happens to it if traffic grows ten times?
- What are the single points of failure in version one, and when do they go away?
- Which decisions are hard to reverse, and what alternatives were considered?
- What's the riskiest assumption, and how will we test it first?

**Interview question.** "Design an internal assistant that answers employee questions from company documents."

**Typical system-design prompt:** *Design a RAG assistant for 20,000 employees over 2 million internal documents, with
answers in a few seconds and access control matching the source systems.*

**1. Clarify first:** Which sources (wiki, tickets, drive), and how often do they change? Must answers respect each
user's document permissions? Latency target? Expected usage? Data residency or compliance needs? Can we use a hosted
LLM API, or must the model run in our cloud?

**2. Back-of-envelope sizing:**
- Corpus: 2 million documents × 10 chunks = 20 million chunks. At 768 dimensions in FP32 that's about 3 KB per vector,
  or 61 GB of vectors before index overhead. That's beyond a small pgvector instance, so consider a dedicated vector
  store or a large Postgres with an HNSW index, plus quantized vectors.
- Traffic: 20,000 users × 5 questions a day = 100,000 requests a day, about 1.2 requests/s average and perhaps 10/s at
  the morning peak.
- Tokens: 10 requests/s × 300 output tokens = 3,000 output tokens/s at peak, a few mid-size GPUs or a hosted API.
- Ingestion: if 1% of documents change daily, that's 20,000 documents and 200,000 chunks to re-embed a day, easily
  done by one GPU or a CPU pool in an hour.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| LLM | Hosted API | Self-hosted open model | API first unless data rules or volume say otherwise (Section 41) |
| Vector store | Postgres + pgvector | Dedicated vector DB | pgvector up to a few million chunks, dedicated beyond |
| Permissions | Filter after retrieval | Filter during retrieval with ACL metadata | Filter during retrieval, so restricted text never reaches the prompt |
| Freshness | Nightly batch | Change-data-capture stream | Batch first, streaming for sources that need minutes |
| Quality | Manual testing | Golden set + judge in CI | Golden set from day one |

**4. Follow-up questions with crisp answers:**
- *A user sees a snippet from a document they can't open.* Retrieval ignored permissions. Store ACLs with each chunk,
  filter in the vector query by the user's groups, and test it with a permissions golden set.
- *Answers cite deleted documents.* Ingestion only upserts. Add deletes keyed on the document ID and a reconciliation
  job that compares the index with the source.
- *Costs doubled after launch.* Measure cost per request, cache frequent questions, trim the retrieved context, and
  route simple questions to a smaller model.
- *Latency spikes every morning.* Peak traffic exceeds the GPUs. Autoscale on queue length with pre-warmed replicas
  before 9 a.m.

**Debug this (common onsite question):** "The proposal's cost estimate was $2,000 a month, but the first month's bill
was $5,800."
1. GPU nodes were sized correctly and ran the expected hours.
2. The bill shows $1,900 in NAT gateway data processing: nodes pulled a 15 GB model image and weights from the internet
   on every scale-up.
3. Another $1,400 came from a forgotten scale-test cluster in a second region, and $500 from cross-zone traffic between
   the gateway and the LLM server.
4. Fix: cache images and weights in a regional registry and bucket with private endpoints, delete the orphan cluster,
   add TTL labels and a weekly cost review, and keep chatty services in the same zone where HA allows.

The lesson: estimates usually miss the always-on and data-transfer items, not the GPUs. List them explicitly and
compare the estimate with actual spend after the first week.

**5. What separates senior from staff answers:** a senior engineer proposes a sound architecture with the right tools. A
staff engineer frames the problem with goals and non-goals, ties every number to an assumption, sizes the cost per unit
and per environment, names the riskiest assumption and how to test it first, designs permissions and failure behavior
up front, and leaves the panel with a clear decision to make.

**Red flags:**
- No non-goals or out-of-scope list.
- Latency targets without a load condition.
- Quality measured by "it looked good in testing".
- A cost estimate with only GPU hours.
- New tools everywhere and no reasons.
- A risk register with no owners or triggers.
- Permissions added "later".

---

## Failure modes

- **Flashy model, thin infrastructure:** the project shows a model, not a platform. Fix: score domains by
  infrastructure depth and budget.
- **Unmeasurable goals:** "fast" and "reliable" with no numbers. Fix: SLOs with load conditions and a golden set.
- **Missing data path:** documents never refresh or deletions linger. Fix: an ingestion job with upserts, deletes, and
  reconciliation.
- **Cost surprises:** always-on items, data transfer, and forgotten clusters. Fix: price every environment, set budget
  alerts, and scale GPUs to zero.
- **Tool overload:** too many new tools to finish. Fix: boring tools, managed services, and pinned versions.
- **Late GPU quota:** the build stalls waiting for approval. Fix: request quota on day 1 with a CPU fallback.
- **Scope creep:** features keep growing. Fix: a must, should, and could list and a scope freeze.

## Checklist

- [ ] I scored at least three capstone options and wrote a one-paragraph problem statement.
- [ ] My success metrics have numeric targets, load conditions, and a golden set for quality.
- [ ] My blueprint shows the request path, data path, environments, failure domains, and trust boundaries.
- [ ] I ran `s48_capstone_cost.py` with my own assumptions and know my unit cost and always-on costs.
- [ ] Each tool choice has an alternative and a reason, and versions are pinned.
- [ ] My risk register is scored and sorted, with mitigations, triggers, and owners.
- [ ] I requested GPU quota and set budget alerts.
- [ ] `check_proposal.py` passes on my proposal, and I can defend each number in it.
