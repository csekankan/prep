# Section 52 — Capstone Project 5: Demo, Presentation, and Graduation

> Lectures 358–365 • Assessments: [Deliver the final AI infrastructure stakeholder presentation](#assessment--deliver-the-final-ai-infrastructure-stakeholder-presentation) • Exercise: [`s52_benchmark_ci.py`](../exercises/s52_benchmark_ci.py)
> **After this section you can:** prepare a demo environment that won't fail on the day, report benchmarks with
> confidence intervals, draw architecture visuals for each audience, present the capstone to stakeholders and answer
> their questions, give and take peer review, take stock of your skills, choose your next learning path, and present
> your work as a portfolio.
>
> Builds on: [Section 51](s51_capstone_testing_docs.md) (tests, reliability, docs, and the final report),
> [Section 48](s48_capstone_proposal.md) (the proposal and its targets), and
> [Section 47](s47_course_review.md) (the course review and practice test).

This is the last section of the course. Atlas is built, scaled, tested, and documented. What's left is to show it:
a demo that works on the day, numbers you can defend, pictures people understand, and a presentation that leads to a
decision. The section ends by looking back at the whole course and forward to what comes next.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 358 | Preparing the final demo environment | Freeze the release, keep capacity warm, run a preflight check, and have a fallback for everything |
| 359 | Recording metrics and performance benchmarks | Fixed setup, open-loop load, one change at a time, and percentiles with confidence intervals |
| 360 | Building visuals of infra architecture | One diagram per audience, from context to deployment, drawn as code with a legend |
| 361 | Delivering the stakeholder presentation | Lead with the problem and results, demo the key journey, and end with a clear ask |
| 362 | Peer review and feedback on projects | Review against a rubric, give specific evidence-based feedback, and turn feedback into actions |
| 363 | Reflection on the zero-to-hero journey | Map what you can do now across the 11 parts, and find your gaps honestly |
| 364 | Future learning paths in AI infrastructure | Pick a specialization, a certification if useful, and a 90-day plan |
| 365 | Graduation and certification showcase | A public portfolio: repository, report, video, and résumé lines with numbers |

```mermaid
flowchart LR
  DEMO["(1) Demo environment"] --> BENCH["(2) Benchmarks<br/>with intervals"]
  BENCH --> VIS["(3) Architecture visuals"]
  VIS --> PRES["(4) Stakeholder presentation"]
  PRES --> PEER["(5) Peer review"]
  PEER --> REFL["(6) Reflection"]
  REFL --> PATH["(7) Learning paths"]
  PATH --> GRAD["(8) Graduation showcase"]
```

**How to read it:** the first four lectures prepare and deliver the presentation: a reliable demo environment,
trustworthy numbers, clear visuals, and the presentation itself. The last four turn outward and forward: feedback from
peers, reflection on the course, the next learning path, and the portfolio you graduate with.

**Terms in this diagram.**
- **Benchmarks with intervals**: performance measurements reported with confidence intervals that show how certain
  they are.
- **Peer review**: classmates or colleagues reviewing your project against a shared rubric.
- **Showcase**: the public presentation of your finished work.

---

## Lecture 358 — Preparing the final demo environment

**Why it matters.** Live demos fail in predictable ways: a cold start because the GPU scaled to zero, an expired token,
a last-minute change, conference Wi-Fi. A failed demo makes reviewers doubt the whole project, even if the system is
solid. A prepared demo environment makes failure unlikely and survivable.

**In plain words.** It's like a theater's opening night. The set is finished days before, the actors do a dress
rehearsal, there's a stage manager's checklist, and an understudy is ready if someone gets sick.

**Architecture: the demo setup and its fallbacks.**

```mermaid
flowchart TB
  REL["Frozen release<br/>tag v1.0, pinned digests"] --> ENV["Demo environment<br/>scale-test, warm"]
  ENV --> PRE["Preflight script<br/>T-60 min and T-5 min"]
  PRE --> LIVE["Live demo"]
  LIVE -.if cloud fails.-> KIND["Fallback 1:<br/>local kind + llama.cpp"]
  LIVE -.if everything fails.-> VID["Fallback 2:<br/>recorded video"]
  WARM["Warm-up job<br/>golden questions"] --> ENV
```

**How to read it:** a frozen release, tagged and pinned by digest, runs in the demo environment with capacity kept warm.
A warm-up job runs golden questions to fill caches, and a preflight script checks everything an hour before and again
five minutes before. If the cloud environment fails during the demo, you switch to the local kind cluster. If
everything fails, you play the recorded video.

**Terms in this diagram.**
- **Frozen release**: a version that won't change before the demo, tagged in Git with images pinned by digest.
- **Pinned digests**: image references by content hash, so they can't change.
- **Warm**: replicas running and caches filled, so the first request isn't slow.
- **Preflight script**: an automated checklist that verifies the environment is ready.
- **T-60 min**: sixty minutes before the demo starts.
- **Warm-up job**: a job that sends realistic requests to load models and fill caches.

**Core ideas.**
- **Feature freeze 48 hours before.** Only fixes for demo-breaking bugs, each tested through the full pipeline.
- **Disable scale-to-zero** during the demo window and keep two model server replicas running. Cost: two L4s for a
  few hours, under $10.
- **Demo identity:** a fresh demo token with the `atlas:demo` scope that expires after the presentation.
- **Script the demo journey** with questions you've tested, plus one unscripted question if you're confident.
- **Prepare fallbacks** in order: local kind cluster, recorded video, screenshots in the slides.
- **Silence non-critical alerts** during the demo, but keep paging alerts active, because a real problem is still real.

```bash
#!/usr/bin/env bash
# scripts/preflight.sh: run at T-60 and T-5 minutes; any FAIL means switch to a fallback or fix now
set -u
GW=${GW:?set GW}; TOKEN=${DEMO_TOKEN:?set DEMO_TOKEN}; EXPECT=${EXPECT_DIGEST:?set EXPECT_DIGEST}
fail=0
check() { if eval "$2" >/dev/null 2>&1; then echo "PASS  $1"; else echo "FAIL  $1"; fail=1; fi; }

check "gateway deep health"          "curl -sf -m 5 $GW/v1/health/deep"
check "deployed image is the release" "[ \"\$(curl -s $GW/v1/info | jq -r .image)\" = \"$EXPECT\" ]"
check "2+ llm replicas ready"        "[ \$(kubectl -n atlas get deploy llm -o jsonpath='{.status.readyReplicas}') -ge 2 ]"
check "demo token works"             "curl -sf -m 30 $GW/v1/ask -H 'authorization: Bearer $TOKEN' \
                                        -H 'content-type: application/json' -d '{\"question\":\"What is a startup probe?\",\"stream\":false}'"
check "no firing page alerts"        "[ \$(curl -s \$PROM/api/v1/alerts | jq '[.data.alerts[] | select(.labels.severity==\"page\" and .state==\"firing\")] | length') -eq 0 ]"
check "fallback kind cluster up"     "kubectl --context kind-atlas get deploy gateway"
check "backup video present"         "test -s demo/backup.mp4"
exit $fail
```

In the script, each check runs a command and prints PASS or FAIL. It verifies the deep health endpoint, that the
deployed image digest matches the frozen release, that at least two model server replicas are ready, that the demo
token returns an answer, that no paging alerts are firing, that the local fallback cluster is running, and that the
backup video exists. It exits non-zero on any failure, so you can run it in a loop at T-5.

```yaml
# deploy/overlays/demo-day/llm-scaledobject-patch.yaml: keep 2 replicas warm during the demo window
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata: {name: llm}
spec:
  minReplicaCount: 2
```

The demo-day overlay raises the model server's minimum to two replicas, overriding the schedule and scale-to-zero. It's
merged the day before and reverted after the presentation, both through Git, so the change is visible and reversible.

**Example: the demo that started cold.** A student's demo began at 18:30, after the cron trigger had scaled the model
servers to zero at 18:00. The first question waited six minutes for a GPU node and the model to load, while the
audience watched a spinner. With a demo-day overlay and a T-5 preflight check for ready replicas, the same student's
second presentation answered the first question in under a second.

**Senior / FAANG best practice.** Treat a high-stakes demo like a launch: a change freeze, a dress rehearsal on the real
environment, a go/no-go checklist, warm capacity, and rehearsed fallbacks. Large companies do the same for keynote
demos and launch events, with dedicated capacity, frozen builds, and a recorded backup ready to play.

---

## Lecture 359 — Recording metrics and performance benchmarks

**Why it matters.** Stakeholders will ask "how fast is it?" and "how much did that change help?". A single number from
one run can be off by 30% from noise alone, especially at p99. Benchmarks with a fixed method and confidence intervals
let you say which improvements are real, and they survive a skeptical reviewer's questions.

**In plain words.** It's like timing a runner. One lap tells you little, since wind, shoes, and a bad start all matter.
Several laps on the same track, with the same shoes, tell you the runner's real speed and how much it varies.

**Architecture: a repeatable benchmark run.**

```mermaid
flowchart LR
  CFG["Config record<br/>GPU, driver, vLLM, model,<br/>flags, prompt lengths"] --> WARM["Warm-up<br/>discarded"]
  WARM --> RUN["Measured run<br/>open loop, fixed rate"]
  RUN --> STORE[("results.jsonl<br/>raw latencies + config")]
  STORE --> STATS["Percentiles +<br/>bootstrap intervals"]
  STATS --> CMP["Compare configs<br/>one change at a time"]
```

**How to read it:** each run starts by recording its full configuration. A warm-up period runs and is thrown away, then
the measured run sends open-loop load at a fixed rate. The raw latencies and the configuration are stored together.
Statistics come from the raw data, with bootstrap confidence intervals, and configurations are compared one change at
a time.

**Terms in this diagram.**
- **Config record**: everything that could affect the result, stored with it.
- **Driver**: the NVIDIA GPU driver version.
- **Flags**: the model server's command-line options, such as prefix caching or the maximum batch size.
- **Open loop**: requests sent on a schedule regardless of responses, like real users.
- **results.jsonl**: one JSON line per request, with the raw measurements.
- **Bootstrap intervals**: confidence intervals from resampling the measured data many times.

**Core ideas.** Run the exercise:

```text
TTFT, 300 requests per configuration, 95% bootstrap intervals (2000 resamples)

config                                p50                    p95                    p99
A baseline          0.55 s [0.51, 0.57]  0.97 s [0.90, 1.07]  1.24 s [1.09, 1.44]
B prefix caching    0.41 s [0.39, 0.42]  0.69 s [0.62, 0.71]  0.83 s [0.71, 0.97]

p95 improvement from prefix caching: 29%
relative width of the 95% interval for A: p50 12%, p99 28%
```

- **The improvement is real.** B's p95 interval (0.62 to 0.71 s) lies entirely below A's (0.90 to 1.07 s), so the 29%
  gain from prefix caching isn't noise. The baseline's p95 of 0.97 s matches the Section 50 stress test at 8 requests/s.
- **Tails are uncertain.** With 300 requests, the p99 interval spans 28% of its value, more than twice as wide as the
  p50's. To quote a p99, collect thousands of requests, or quote the interval.
- **Change one thing at a time**, and keep the model, prompts, rate, and hardware identical between runs.
- **Report the method with the numbers:** GPU, driver, vLLM version, model and precision, prompt and output lengths,
  request rate, number of requests, and how long the warm-up was.
- **Benchmark what users feel:** TTFT, full-answer time, and throughput at the SLO, plus cost per 1,000 requests.

```json
{"run": "2026-11-02T14:05Z-b", "gpu": "L4", "gpus": 3, "driver": "550.127", "vllm": "0.8.5",
 "model": "Qwen/Qwen2.5-1.5B-Instruct", "dtype": "bfloat16", "flags": ["--enable-prefix-caching"],
 "rate_rps": 8, "requests": 300, "warmup_s": 120, "prompt_tokens_p50": 1480, "output_tokens_p50": 210,
 "ttft_s": [0.41, 0.38, 0.52], "answer_s": [3.9, 4.4, 5.1]}
```

Each benchmark run is stored as one record with its full configuration and the raw per-request latencies (shortened
here), so anyone can recompute the statistics or check that two runs are comparable. A results table in the final
report links to these records.

The Atlas benchmark summary for the presentation:

| Metric (3 × L4, Qwen2.5-1.5B) | Baseline | + prefix caching | Evidence |
|---|---|---|---|
| TTFT p95 at 8 req/s | 0.97 s [0.90, 1.07] | 0.69 s [0.62, 0.71] | runs A and B |
| Capacity at SLO | 10.1 req/s | measure after the change | step test |
| Cost per 1,000 requests | $0.31 | same GPUs, more headroom | unit-cost job |

**Example: the 40% speedup that wasn't.** A student reported that switching to FP8 weights cut TTFT p95 by 40%. A
reviewer asked how many requests and runs. It was one run of 100 requests for each configuration, and the baseline
run had started before the model servers finished warming up. Rerun with a warm-up, 500 requests each, and bootstrap
intervals, the gain was 12% with overlapping intervals at p95. The report was corrected, and the student kept the
method as their standard.

**Senior / FAANG best practice.** Benchmarks are experiments: fixed environment, warm-up, enough samples for the
percentile you report, repeated runs, and intervals. Public benchmarks such as MLPerf Inference define the scenarios,
accuracy targets, and run rules for exactly this reason. Large teams keep benchmark results and configurations in a
database, run them in CI on reference hardware, and flag regressions that exceed the noise.

---

## Lecture 360 — Building visuals of infra architecture

**Why it matters.** Most stakeholders will understand Atlas through one or two pictures. A diagram that tries to show
everything to everyone shows nothing to anyone. Good architecture visuals are drawn for a specific audience and
question, and they make the request path, the failure domains, and the trust boundaries obvious.

**In plain words.** It's like maps of a city. A tourist map shows landmarks, a subway map shows lines and stations, and
a utility map shows pipes. Each is accurate, and each is useful to a different person.

**Architecture: four levels of Atlas diagrams.**

```mermaid
flowchart TB
  L1["Level 1, context<br/>users, Atlas, identity provider, docs source<br/>for executives"] --> L2["Level 2, containers<br/>gateway, retriever, llm, Postgres, ingest<br/>for engineers"]
  L2 --> L3["Level 3, deployment<br/>zones, node pools, managed services<br/>for SRE and security"]
  L2 --> L4["Request sequence<br/>numbered steps, timings<br/>for performance reviews"]
```

**How to read it:** the context diagram shows Atlas as one box with its users and the external systems it depends on,
for executives and anyone new. The container diagram opens that box into the running services and data stores, for
engineers. The deployment diagram maps those services onto zones, node pools, and managed services, for SRE and
security reviewers. A request sequence diagram shows one request's numbered steps with timings, for performance
discussions.

**Terms in this diagram.**
- **Context**: the system and its surroundings: who uses it and what it depends on.
- **Containers**: in the C4 model, the separately running parts of a system (services, databases), not only Docker
  containers.
- **Deployment**: where each part runs: zones, node pools, managed services.
- **Postgres**: the database holding Atlas's document chunks and request signals.
- **Request sequence**: the order of calls for one request, with time spent at each step.
- **SRE**: site reliability engineering, the people and practices that keep systems reliable.

**Core ideas.**
- **Use the C4 levels**: context, containers, components, and code. Most presentations need the first two plus a
  deployment view.
- **One question per diagram.** "What does Atlas depend on?" is a context diagram. "What happens when a zone fails?"
  is a deployment diagram.
- **Number the request path** and put timings on it, such as "(3) retrieve, 12 ms".
- **Draw boundaries:** zones and regions for failure domains, and dashed boxes for trust boundaries.
- **Add a legend** and use the same shapes and colors for the same things in every diagram.
- **Diagrams as code** (Mermaid, Python `diagrams`, Structurizr), stored with the docs, so they're reviewed and stay
  current.

```mermaid
flowchart LR
  U["Support engineer<br/>or customer"] -->|"(1) question"| GW["Gateway"]
  GW -->|"(2) embed, 8 ms"| EMB["Embedder"]
  GW -->|"(3) retrieve top 5, 12 ms"| PG[("Postgres + pgvector")]
  GW -->|"(4) prompt + chunks"| LLM["vLLM, L4"]
  LLM -->|"(5) first token, 0.4 s<br/>full answer, 4 s"| GW
  GW -->|"(6) answer + sources"| U
```

Here the embedder turns the question into a vector, and Postgres with the pgvector extension finds the nearest
chunks. This request sequence view numbers the six steps of one question and shows where the time goes: embedding and
retrieval take about 20 ms, and almost all the rest is the model. It answers the common question "why does it take 4
seconds?" in one picture, and shows that optimizing retrieval wouldn't help much.

```python
# docs/diagrams/deployment.py: renders docs/diagrams/deployment.png with the diagrams library (needs Graphviz)
from diagrams import Cluster, Diagram, Edge
from diagrams.aws.database import RDS
from diagrams.aws.network import ELB
from diagrams.aws.storage import S3
from diagrams.k8s.compute import Pod
from diagrams.onprem.monitoring import Grafana, Prometheus

with Diagram("Atlas deployment", filename="docs/diagrams/deployment", show=False, direction="LR"):
    lb = ELB("load balancer")
    with Cluster("Region us-east-1"):
        zones = []
        for z in ("a", "b", "c"):
            with Cluster(f"zone {z}"):
                gw = Pod(f"gateway-{z}")
                llm = Pod(f"llm-{z}") if z != "c" else None
            zones.append((gw, llm))
        db = RDS("Postgres Multi-AZ")
        docs = S3("docs + weights")
        with Cluster("monitoring"):
            Prometheus("prometheus") >> Grafana("grafana")
    for gw, _ in zones:
        lb >> gw >> db
        for _, llm in zones:
            if llm:
                gw >> Edge(style="dashed") >> llm
    docs >> Edge(label="ingest") >> db
```

The script draws the deployment view with AWS and Kubernetes icons: a load balancer, three zones with a gateway in each
and model servers in two, the Multi-AZ database, the S3 bucket, and the monitoring stack. Because it's code, the
diagram changes in the same pull request as the infrastructure and can be regenerated in CI.

**Example: the diagram that confused the CFO.** A student opened their presentation with the full deployment diagram:
37 icons, every Service, the monitoring stack, and CI. The finance partner asked, "So what does it do?" The rewrite
opened with the context diagram (users, Atlas, the identity provider, the docs), kept the container view for the
architecture slide, and moved the deployment view to the reliability slide, where the question was "what happens when
a zone fails?"

**Senior / FAANG best practice.** Pick the diagram for the audience and the question, keep notation consistent with a
legend, and store diagrams as code beside the system they describe. Large companies' design reviews usually ask for a
context diagram, a component diagram, and a data flow with trust boundaries for security review, and expect them to
match the deployed system.

---

## Lecture 361 — Delivering the stakeholder presentation

**Why it matters.** A great system that's badly presented gets less support, funding, or credit than it deserves.
Stakeholders have different questions: an executive asks about value and risk, finance about cost, security about
exposure, and engineers about design. A good presentation answers each in the time available and ends with a clear
decision for them to make.

**In plain words.** It's like a real-estate agent showing a house. They know the buyer cares about the school, the
commute, and the price, so they lead with those, show the best rooms, and are honest about the leaky gutter before the
inspector finds it.

**Architecture: the presentation flow.**

```mermaid
flowchart LR
  P["(1) Problem<br/>1 min"] --> S["(2) What we built<br/>context diagram, 2 min"]
  S --> D["(3) Live demo<br/>3 min"]
  D --> R["(4) Results vs targets<br/>2 min"]
  R --> C["(5) Cost<br/>2 min"]
  C --> REL["(6) Reliability + security<br/>2 min"]
  REL --> L["(7) Risks, lessons<br/>1 min"]
  L --> ASK["(8) The ask<br/>next steps, 2 min"]
```

**How to read it:** the presentation runs 15 minutes in eight parts. It opens with the problem, shows what was built in
one picture, and proves it with a live demo. Then the evidence: results against targets, cost, and reliability and
security. It closes with risks and lessons and a clear ask, the decision or support you want from the audience.

**Terms in this diagram.**
- **Results vs targets**: the generated table from the final report, with misses.
- **The ask**: the specific decision or support requested, such as "approve a pilot with 200 users for 4 weeks".

**Core ideas.**
- **Know the audience.** List each stakeholder, their top question, and the slide that answers it.

| Stakeholder | Top question | Where it's answered |
|---|---|---|
| VP of engineering | Does it work, and is it worth continuing? | Demo, results table, the ask |
| Finance partner | What does it cost now and at scale? | Cost slide: unit cost and monthly totals |
| Security lead | Who can access what, and what's exposed? | Reliability and security slide |
| Staff engineer | Are the design choices sound? | Architecture slide, ADR links, Q&A |

- **Lead with outcomes**, not tools. "Answers in under a second with sources, at $0.31 per 1,000 requests" before
  "vLLM on EKS".
- **Demo the main journey** only: one question, a streamed answer with sources, then one failure (kill a model server
  pod) to show it keeps working.
- **Show misses.** One honest miss with a plan builds more trust than a page of green.
- **End with a specific ask** with scope, time, and cost.
- **Answer questions directly:** the answer first, then the evidence. If you don't know, say so and say how you'd find
  out.
- **Rehearse twice** with a timer, once with someone playing a skeptical reviewer.

```markdown
---
marp: true
paginate: true
---

# Atlas: answers from our docs in under a second

Support engineers spend about 6 minutes per question searching 400 help articles.
Atlas answers in chat with sources. Built and run on Kubernetes for $412 a month.

---

# What we built

![w:900](diagrams/context.png)

---

# Results against the targets we set in week 1

| Target | Result |
|---|---|
| TTFT p95 < 1.5 s | 0.52 s |
| Availability >= 99.5% | 99.82% over 14 days |
| Grounded answers >= 90% | 92% |
| < $0.50 per 1,000 requests | $0.31 |
| Drift alert <= 60 min | 75 min (missed: hourly job, fix costs nothing) |

---

# The ask

A 4-week pilot with 200 support engineers: about $600 a month, success = 30% less time per question.
```

The slides are Markdown for Marp, so they live in the repository with the report and diagrams. The excerpt shows the
opening slide (outcome first), the architecture slide (one context diagram), the results slide with the miss included,
and the closing ask with scope, cost, and a success measure. The full deck has about ten slides, one per part of the
flow plus a title and a backup slide.

**Example: the question that saved the pilot.** At the end of a capstone presentation, the finance partner asked, "What
happens to the cost if all 2,000 support staff use it?" The student had the answer ready from the cost model: about 8
requests/s at peak, which 3 GPUs handle, so around $2,100 a month at 24/7 or $0.27 per 1,000 requests, with a spot and
scheduling plan to cut it. The pilot was approved in the meeting. A vague answer would likely have led to "come back
with numbers".

**Senior / FAANG best practice.** Write the narrative before the slides. Amazon's six-page memos and press-release
documents make teams state the customer problem and outcome first. Tailor depth to the room, bring evidence for each
claim in a backup appendix, and leave the meeting with a decision and owners. Staff engineers are often judged on
whether their presentations lead to decisions.

---

## Lecture 362 — Peer review and feedback on projects

**Why it matters.** Reviewing others' projects teaches you as much as building your own: you see different solutions
to the same problems, and you practice the design-review skills senior engineers use every week. Receiving feedback
well turns other people's attention into improvements to your project.

**In plain words.** It's like a writing workshop. Each writer reads the others' drafts with the same checklist, points
to specific passages, and gets their own draft back with notes they can act on.

**Architecture: the peer review loop.**

```mermaid
flowchart LR
  SUB["Submission<br/>repo, report, video"] --> REV["2 reviewers<br/>rubric + evidence"]
  REV --> FB["Written feedback<br/>strengths, issues, questions"]
  FB --> TRI["Author triage<br/>fix, plan, or explain"]
  TRI --> ACT["Action items<br/>with owners"]
  ACT --> SUB
```

**How to read it:** each submission (repository, report, and demo video) goes to two reviewers, who score it against
the rubric and cite evidence. They write feedback in three parts. The author triages each point: fix it now, plan it,
or explain why not. The fixes become action items, and the improved submission can be reviewed again.

**Terms in this diagram.**
- **Rubric**: the shared scoring guide, the same one used in the assessment below.
- **Triage**: sorting each point by what to do about it.
- **Action items**: specific follow-ups with an owner and a date.

**Core ideas.**
- **Review against the rubric**, not against how you would have built it.
- **Be specific and cite evidence:** "`llm.yaml` has no startup probe, so liveness kills the pod during the 6-minute
  load" beats "probes could be better".
- **Use situation, behavior, impact** for feedback on a presentation: "In the results slide (situation), the
  availability came from a weekend window (behavior), which made me doubt the other numbers (impact)."
- **Ask questions** when you're not sure something is wrong: "How does ingestion handle deleted articles?"
- **Start with real strengths**, then the most important issues, at most five.
- **As the author, respond to every point**, including the ones you won't fix, and thank reviewers for the time.

```markdown
### Peer review: Atlas (reviewer: Sam, author: Kim)

**Strengths**
- The results table is generated from evidence files, and the one miss is explained with a fix.
- The database failover drill shows a measured 45-second RTO, with the before and after.

**Issues, most important first**
1. Security: the demo token has no expiry date in `docs/demo.md`. Impact: a leaked token works forever.
2. Benchmarks: capacity was measured once. Impact: the 10.1 req/s claim has no interval.
3. Docs: there's no runbook for `AtlasTTFTSlow`, although it pages.

**Questions**
- What happens to retrieval quality when the corpus is 10 times larger?

**Rubric scores:** problem 4/4, metrics 4/4, architecture 3/4, reliability 4/4, security 2/4, cost 4/4, docs 3/4,
presentation 3/4
```

The review shows the format: two specific strengths, issues ordered by importance with the file or slide and the
impact, an open question, and rubric scores. The author's reply goes under each issue with "fixed in #42", "planned",
or a reason.

**Example: the review that found the real risk.** Kim's reviewers both scored security 2 of 4, for the same reason: the
model server's Service was type `LoadBalancer` in the scale-test overlay, left over from debugging. Kim had looked at
the manifests many times and never noticed. The fix took one line, and Kim added a CI check that rejects `LoadBalancer`
Services outside the ingress namespace.

**Senior / FAANG best practice.** Code review and design review are core skills at large companies: Google requires
review for every change, and design documents are reviewed by peers and senior engineers before building. Good
reviewers focus on correctness, risk, and clarity, write comments that teach, and separate blocking issues from
suggestions. Good authors make reviews easy with small, well-described changes.

---

## Lecture 363 — Reflection on the zero-to-hero journey

**Why it matters.** You've covered 52 sections, from Linux and GPUs to multi-tenant platforms and a full capstone.
Reflection turns that into a clear picture of what you can do now, where you're strong, and where you need practice,
which is what you need for interviews and for choosing what to learn next.

**In plain words.** It's like looking back at a long hike from the summit. You can see the whole route, the hard
climbs you made it through, and the paths you skipped that you might want to explore next time.

**Architecture: the course as a skill map.**

```mermaid
flowchart LR
  F["Foundations<br/>Parts I and II: Linux, cloud,<br/>containers, K8s, data, GPUs"] --> O["Operations<br/>Parts III to V: MLOps, CI/CD,<br/>cost, serving, observability, HA"]
  O --> W["Workloads<br/>Parts VI and VII: edge, GenAI,<br/>vision, NLP, RL"]
  W --> S["Scale + trust<br/>Parts VIII and IX: large training,<br/>optimization, privacy, security"]
  S --> C["Context + capstone<br/>Parts X and XI: startups,<br/>enterprises, real time, Atlas"]
```

**How to read it:** the course moved in five stages. The foundations covered the platform: Linux, cloud, containers,
Kubernetes, storage, and GPUs. Operations covered running models in production. Workloads covered the domains,
from edge devices to generative AI and reinforcement learning. Scale and trust covered large training, optimization,
privacy, and security. The last stage put it all in context and in the Atlas capstone.

**Terms in this diagram.**
- **Parts I to XI**: the eleven parts of this course, each a group of sections, numbered in Roman numerals: I, II,
  III, IV, V, VI, VII, VIII, IX, X, XI.
- **MLOps**: the practices and tools that take models from experiments to reliable production.
- **NLP**: natural language processing, models that read or write text.
- **RL**: reinforcement learning.
- **Atlas**: the reference capstone project, a retrieval-augmented support assistant.

**Core ideas.** Rate yourself on each domain from 1 to 4, honestly, with evidence for each rating.

| Level | Meaning | Evidence |
|---|---|---|
| 1 | I can explain it | I can answer the section quiz |
| 2 | I can do it with a guide | I completed the lab |
| 3 | I can do it alone | I used it in the capstone without the lab instructions |
| 4 | I can design and review it | I made the trade-offs and could defend them to a staff engineer |

```python
RATINGS = {  # domain: (level now, evidence)
    "Linux, cloud, networking": (3, "built the Atlas VPC and debugged NetworkPolicy"),
    "Containers and Kubernetes": (4, "designed overlays, probes, PDBs, topology spread"),
    "GPUs and distributed training": (2, "ran the 2-node LoRA job from the guide"),
    "Serving and performance": (3, "vLLM tuning, prefix caching benchmark with intervals"),
    "MLOps and CI/CD": (3, "eval-gated CI, GitOps, signed images"),
    "Observability and reliability": (4, "burn-rate alerts, failover drills with measured RTO"),
    "Security and privacy": (2, "JWT and NetworkPolicy, but no threat model review yet"),
    "Cost and FinOps": (3, "unit cost job, scale-to-zero, estimate vs actual"),
}
for domain, (level, why) in sorted(RATINGS.items(), key=lambda kv: kv[1][0]):
    print(f"{'#' * level:<4} {level}/4  {domain:32} {why}")
```

The script sorts your domains from weakest to strongest with a bar and the evidence. Your two or three lowest domains
are the input for Lecture 364. The point isn't high scores everywhere: specialists are often at 4 in two or three
domains and 2 in the rest.

**Example: the reflection that changed a job search.** A graduate expected to apply for ML engineer roles. Their
self-assessment showed 4s in Kubernetes, observability, and reliability, and 2s in training. They applied for ML
platform and SRE-for-AI roles instead, led with the failover drills and burn-rate alerts from their capstone, and got
offers from two of their first five applications.

**Senior / FAANG best practice.** Senior engineers know the shape of their skills and talk about it with evidence:
"I've designed and operated this; I've only read about that." Performance reviews and promotion documents at large
companies ask for exactly this: the scope of what you did, the decisions you made, and the impact. Keep a running log
of your work and its results, starting with this capstone.

---

## Lecture 364 — Future learning paths in AI infrastructure

**Why it matters.** AI infrastructure is broad and changes quickly. After this course, depth in one or two areas will do
more for your career than more breadth, and a plan beats collecting tutorials. Choosing a path deliberately also helps
you pick projects, certifications, and jobs.

**In plain words.** It's like finishing a general medical degree and choosing a specialty. Every doctor knows the basics,
but each specialist goes deep in one area and keeps up with it.

**Architecture: specialization paths from the common core.**

```mermaid
flowchart TB
  CORE["This course<br/>the common core"] --> P1["ML platform / MLOps<br/>pipelines, registries, Kubeflow"]
  CORE --> P2["Inference performance<br/>vLLM internals, CUDA, kernels"]
  CORE --> P3["GPU clusters / HPC<br/>InfiniBand, NCCL, Slurm, schedulers"]
  CORE --> P4["SRE for AI<br/>SLOs, capacity, incidents"]
  CORE --> P5["AI security<br/>supply chain, red teaming, privacy"]
  CORE --> P6["FinOps for AI<br/>unit economics, capacity planning"]
  CORE --> P7["Edge AI<br/>quantization, devices, fleets"]
```

**How to read it:** the course is the common core every path builds on. Seven paths branch from it, each with its
own deeper topics. Most people pick one main path and one supporting path, such as inference performance plus FinOps.

**Terms in this diagram.**
- **Kubeflow**: an open-source ML platform on Kubernetes for pipelines, training jobs, and serving.
- **CUDA**: NVIDIA's platform for programming GPUs.
- **Kernels**: the small GPU programs that run individual operations, such as attention or matrix multiplication.
- **HPC**: high-performance computing, large clusters for tightly coupled jobs.
- **InfiniBand**: a high-bandwidth, low-latency network used in GPU clusters.
- **NCCL**: NVIDIA's library for collective operations such as all-reduce across GPUs.
- **Slurm**: a job scheduler widely used in HPC and AI training clusters.
- **Red teaming**: attacking your own system on purpose to find weaknesses.
- **Unit economics**: the cost and value per unit of work, such as per request or per token.

**Core ideas.**

| Path | Go deeper with | A project that proves it | Certifications that can help |
|---|---|---|---|
| ML platform / MLOps | Kubeflow, Argo Workflows, feature stores, model registries | A self-service training and deployment platform for 3 teams | CKA, CKAD; a cloud ML engineer certification |
| Inference performance | vLLM and SGLang internals, CUDA, Triton (the kernel language), quantization | Double tokens/s per GPU on a real workload, with benchmark intervals | NVIDIA certifications |
| GPU clusters / HPC | NCCL, InfiniBand and RoCE, Slurm, Kueue, topology-aware scheduling | Multi-node training with measured scaling efficiency | NVIDIA AI infrastructure certifications |
| SRE for AI | SLOs, capacity planning, incident management, chaos engineering | Burn-rate alerting and drills for a GPU service | CKA, CKS |
| AI security | Supply-chain security (SLSA, Sigstore), LLM red teaming, privacy techniques | A threat model and red-team report for a RAG system | CKS; a cloud security certification |
| FinOps for AI | Cost allocation, commitments and spot, GPU utilization | A unit-cost dashboard that cut spend by 30% | FinOps Certified Practitioner |
| Edge AI | TensorRT, ONNX Runtime, model compression, fleet updates | A quantized model on a Jetson with OTA updates | NVIDIA Jetson courses |

- **Certifications are optional proof**, most useful early in a career or when changing fields. A public project with
  measured results usually counts for more. Check each vendor's current certification names, since they change.
- **Keep up deliberately:** release notes of the tools you use (Kubernetes, vLLM, PyTorch), MLPerf results, a few
  engineering blogs, and one conference talk a week.
- **Read the classics:** Google's *Site Reliability Engineering* and *The Site Reliability Workbook*, Chip Huyen's
  *Designing Machine Learning Systems* and *AI Engineering*, and Martin Kleppmann's *Designing Data-Intensive
  Applications*.
- **Plan in 90 days:** one main path, one project, one book, and one contribution (a docs fix, a bug report, a blog post).

```text
90-day plan: inference performance (main) + FinOps (supporting)

Days 1-30   Read the vLLM architecture docs and the PagedAttention paper. Profile Atlas with Nsight Systems.
            Deliverable: a write-up of where time goes per request, with traces.
Days 31-60  Try FP8 weights, speculative decoding, and chunked prefill on Atlas, one change at a time,
            with 500-request runs and bootstrap intervals. Deliverable: a benchmark report.
Days 61-90  Write a blog post on cost per 1,000 requests vs configuration. Open one docs or benchmark PR
            upstream. Deliverable: the post, the PR, and an updated résumé line with the numbers.
```

The plan has one deliverable per month, each building on the capstone, so the learning produces public evidence. The
supporting path appears as the cost angle in the final month.

**Example: the narrow path that paid off.** A graduate chose inference performance. In 90 days they profiled their
capstone, found that half the TTFT came from an oversized prompt template, cut it, then measured FP8 and speculative
decoding with proper intervals. Their blog post on the results was shared by a vLLM maintainer, and it came up in
three of their interviews.

**Senior / FAANG best practice.** Strong engineers grow in a "T" shape: broad enough to work across the stack and deep in
one or two areas where they're a go-to person. Large companies hire for that depth, such as inference performance or
GPU cluster reliability, and promote people whose depth turns into impact others can see. Choose a path, build in
public, and measure your results.

---

## Lecture 365 — Graduation and certification showcase

**Why it matters.** Finishing is worth showing. A clear portfolio turns 52 sections and a capstone into something
employers, managers, and peers can see and check in a few minutes. The course certificate shows you completed the
course. The portfolio shows what you can do.

**In plain words.** It's like an art school's graduation exhibition. Each graduate shows their best finished work,
with a short card explaining it, to anyone who walks through the door.

**Architecture: the graduation portfolio.**

```mermaid
flowchart LR
  REPO["Public repository<br/>README, code, IaC, docs"] --> HUB["Portfolio page"]
  REP["Final report<br/>results vs targets"] --> HUB
  VID["Demo video<br/>3 to 5 minutes"] --> HUB
  DIAG["Architecture diagrams"] --> HUB
  POST["Blog post<br/>one lesson in depth"] --> HUB
  HUB --> CV["Résumé lines<br/>with numbers"]
  HUB --> CERT["Course certificate"]
```

**How to read it:** the portfolio page links to the public repository, the final report, a short demo video, the
architecture diagrams, and a blog post on one lesson. From it come the résumé lines, each with measured numbers, and
the course certificate.

**Terms in this diagram.**
- **IaC**: infrastructure as code, here the Terraform and Kubernetes manifests.
- **Portfolio page**: one page (a README, personal site, or profile) that links to all the evidence.
- **Résumé lines**: short statements of what you did and the measured result.

**Core ideas.**
- **The README is the front door:** what Atlas does, the context diagram, the results table, a 60-second quick start,
  and links to the report and video. Remove secrets and account IDs before publishing.
- **The video shows, not tells:** one question with a streamed answer and sources, a killed pod with no errors, the
  dashboard, and the cost panel, in under five minutes.
- **Write résumé lines with numbers**, from your report:
  - "Built a retrieval-augmented assistant on EKS serving 10 requests/s on 3 L4 GPUs at $0.31 per 1,000 requests."
  - "Cut client-visible database failover from 14 minutes to 45 seconds with checked connection pools and drills."
  - "Replaced 11 cause-based alerts with SLO burn-rate alerts, reducing pages from 40 to 2 a week."
- **Certificate criteria for this course:** every section checklist completed, the Section 47 practice test passed (24
  of 30 or better), and the capstone presentation scored at least 70% on the rubric below.

```markdown
### Atlas: a retrieval-augmented support assistant on Kubernetes

Ask a question about AI infrastructure and get a streamed answer with sources from this course's 52 sections.

| | |
|---|---|
| Results | TTFT p95 0.52 s, 99.82% availability over 14 days, 92% grounded answers, $0.31 per 1,000 requests |
| Stack | FastAPI, vLLM on L4 GPUs, Postgres + pgvector, EKS, Terraform, Argo CD, Prometheus, OpenCost |
| Docs | [Final report](docs/report.md), [architecture](docs/architecture.md), [runbooks](docs/runbooks/) |
| Demo | [4-minute video](https://example.com/atlas-demo) |

Quick start on a laptop: `make kind-up && make ingest && make ask Q="What is a startup probe?"`
```

The README header leads with what Atlas does and the headline results, lists the stack in one line, and links to the
deeper evidence. A reviewer can judge the project in a minute and verify any claim in five. The `make` targets wrap
the Section 49 lab steps.

**Example: the portfolio that did the talking.** In an interview for an ML platform role, a graduate was asked to
describe a system they'd built. They shared their screen with the Atlas README, walked the interviewer from the context
diagram to the results table to the failover drill timeline, and answered follow-ups by opening the relevant runbook
and ADR. The interviewer said afterwards that the evidence answered most of the questions they'd planned to ask.

**Senior / FAANG best practice.** Present your work the way strong engineers write promotion documents: the problem, the
scope, the decisions you made, and the measured impact, with links to evidence. Keep the portfolio current as you
grow. Your next projects and your contributions to open source will matter more over time than any single
certificate.

---

## Assessment — Deliver the final AI infrastructure stakeholder presentation

**Scenario (live exercise, about 30 minutes):** you present Atlas to a panel playing four stakeholders: a VP of
engineering, a finance partner, a security lead, and a staff engineer. You have 15 minutes, including a live demo, and
then 15 minutes of questions. The panel decides whether to fund a 4-week pilot with 200 support engineers.

**Deliverable:** the presentation (about ten slides), the live demo with a fallback ready, answers to the panel's
questions, and a one-page follow-up with decisions and action items. The panel's likely questions, with model answers:

| Panel member and question | Model answer |
|---|---|
| VP: "Does it actually save time?" | "In the 14-day test, golden-set questions were answered with correct sources 89% of the time, with first tokens in 0.52 s at p95. We haven't measured time saved per support ticket yet. That's the pilot's success measure: 30% less time per question, measured against last quarter's tickets" |
| Finance: "What will the pilot and full rollout cost?" | "The pilot is about $600 a month at current settings. For all 2,000 support staff, the model sizes it at about 8 req/s at peak on 3 GPUs: around $2,100 a month at 24/7, or $0.27 per 1,000 requests, less with off-hours scaling. The estimate's main uncertainty is usage per person, which the pilot measures" |
| Security: "Can someone outside the company use it or see our documents?" | "Every call needs a token from our identity provider with the right scope. The model server and database aren't reachable from outside the cluster, by NetworkPolicy and security groups. The demo token expires today. Open item: ingested documents are all public help articles. Internal documents would need per-document access control, which is out of scope for the pilot" |
| Staff engineer: "What breaks first at 10× traffic?" | "GPU capacity: the step test showed the full-answer SLO breaking at 10.1 req/s on 3 L4s. Next is Postgres connections, at about 60 concurrent streams. The plan: autoscale to more GPUs on queue depth, pool connections, and rerun the stress test at the new peak before expanding" |
| Staff engineer: "Why not a hosted LLM API?" | "For public help articles, an API would be simpler, and the ADR says so. We self-hosted because the course goal was the platform, and because our unit cost is lower at sustained volume. For the pilot, either works, and the gateway's OpenAI-compatible interface means we can switch with a configuration change" |
| VP: "What's the biggest risk?" | "Answer quality on questions the docs don't cover. The drift pipeline watches the share of low-score questions, and the docs team gets a weekly list of gaps. A bad answer is the main way users lose trust, so refusals are tuned to say 'I don't know' rather than guess" |
| Finance: "What did you miss?" | "One of 12 targets: drift detection took 75 minutes against a 60-minute target, because the job runs hourly. Running it every 30 minutes costs almost nothing and fixes it" |

**Follow-up note, model answer:**
- **Decision:** pilot approved for 4 weeks with 200 support engineers, starting the week after next.
- **Success measures:** time per question down 30% against last quarter's tickets, grounded answers at least 90% in
  weekly human samples, and availability at least 99.5% during working hours.
- **Conditions:** the drift job moves to every 30 minutes, a security review of the pilot's identity setup, and a cost
  check-in at week 2.
- **Action items:** identity integration (author, Friday), drift schedule change (author, Tuesday), pilot onboarding
  guide (author with the support lead, before launch).

**Scoring rubric:**

| Area | Weight | Strong (full marks) | Weak |
|---|---|---|---|
| Problem and outcome | 10% | Opens with the user problem and the measured outcome | Opens with the tool list |
| Demo | 15% | The main journey and one failure, live, with a fallback ready | Scripted video only, or a demo that fails with no fallback |
| Evidence | 20% | Results against targets with sources, intervals where relevant, misses included | Claims without evidence, or only passes shown |
| Cost | 15% | Unit cost, current and at scale, with assumptions | One total, or no cost |
| Reliability and security | 15% | Measured failover, alerting, identity, and exposure, in plain words | "It's highly available and secure" |
| Audience fit | 10% | Each stakeholder's top question answered in the talk | One level of detail for everyone |
| Q&A | 10% | Direct answers with numbers, honest about unknowns | Evasive, or guesses presented as facts |
| The ask | 5% | A specific decision with scope, time, cost, and success measures | No ask, or "any questions?" |

A score of 70% or higher, together with the checklists and the Section 47 practice test, completes the course.

**What reviewers look for:**
- **Outcome before technology**, in the first minute.
- **Evidence for every number**, with misses stated and explained.
- **A demo that works, or a fallback that's ready**, including one failure shown live.
- **Answers tailored to each stakeholder's question**, in their language.
- **Honesty about scope and unknowns**, with a plan to resolve each.
- **A clear ask** that leads to a decision in the meeting.

---

## FAANG deep-dive notes

**How big tech does it.** Launches at large companies end with reviews where engineers present results to leadership,
product, finance, security, and partner teams. Amazon teams use written narratives read at the start of the meeting,
Google teams present design and launch documents with metrics against goals, and Meta runs product and infrastructure
reviews with data-driven decisions. Benchmarks follow strict methods: MLPerf for hardware and systems, and internal
benchmark suites with repeated runs and regression detection. Engineers' promotion cases rest on the same evidence:
scope, decisions, and measured impact.

**Staff review questions.**
- What decision do you want from this audience, and what evidence supports it?
- Which result would change the decision if it were wrong, and how certain is it?
- What did you miss, and what's the plan?
- What does it cost at 10× usage, and what breaks first?
- Which choices would you make differently, and why?
- Who operates this after you, and what do they need?

**Interview question.** "Tell me about a system you built. What was the impact, and how do you know?"

**Typical system-design prompt:** *Present the results of an AI infrastructure project to a leadership review and
propose the next phase, with a budget.*

**1. Clarify first:** Who's in the room and what decision is on the table? What were the original goals? What budget
range is realistic? What are the competing priorities? What would make leadership say no?

**2. Back-of-envelope sizing:**
- Pilot: 200 users × 10 questions a day = 2,000 requests a day, comfortably within 2 GPUs at about $600 a month.
- Full rollout: 2,000 users, about 8 requests/s at peak, 3 GPUs, about $2,100 a month at 24/7 or $0.27 per 1,000
  requests.
- Value: if each user saves 15 minutes a day at $60 an hour, 2,000 users save about $30,000 a day, which dwarfs the
  infrastructure cost, but only if the time saved is real, which is what the pilot measures.
- Benchmarks: 500 or more requests per configuration for p95, thousands for p99, with intervals.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Lead with | Architecture | Outcome and evidence | Outcome first, architecture on demand |
| Results | Only passes | All targets, including misses | All targets with plans for misses |
| Numbers | Single runs | Repeated runs with intervals | Intervals for anything that drives a decision |
| Demo | Live only | Live with rehearsed fallbacks | Live with fallbacks |
| Next phase | Full rollout | Pilot with success measures | Pilot first unless the evidence is overwhelming |

**4. Follow-up questions with crisp answers:**
- *"Your p99 looks great."* "It's from 300 requests, so the interval is about ±14%. I'd quote p95 for decisions and
  collect more data before relying on p99."
- *"Why should we fund this over the other project?"* State the expected value per dollar and the cheapest test of it,
  which is the pilot.
- *"What if the pilot fails?"* The success measures are agreed in advance. If they're not met, we stop and keep the
  platform pieces for other uses.
- *"Who supports it?"* The runbooks, alerts, and on-call rotation in the docs, plus a named owner during the pilot.

**Debug this (common onsite question):** "The presentation went well, but a week later leadership hasn't approved the
pilot."
1. The presentation ended with "any questions?", not a specific ask.
2. The follow-up note was never sent, so nobody owned the decision.
3. The finance partner's question about cost at full scale was answered with "we'll find out".
4. Fix: send a one-page follow-up with the specific decision, the cost at scale from the model, the success measures,
   and a date for the decision, and ask the VP to confirm the owner.

The lesson: a presentation is a means to a decision. Make the ask explicit and follow up in writing.

**5. What separates senior from staff answers:** a senior engineer presents a strong system clearly. A staff engineer
frames it around the decision, tailors evidence to each stakeholder, quantifies uncertainty, presents misses with
plans, sizes the next phase with costs and success measures, and makes sure the meeting ends with an owner and a date.

**Red flags:**
- Opening with the technology stack.
- Results with no evidence, or only passes.
- A single-run benchmark used for a decision.
- A live demo with no fallback.
- Vague answers about cost at scale.
- No ask, and no written follow-up.

---

## Failure modes

- **Cold demo:** the model server scaled to zero before the presentation. Fix: a demo-day overlay with warm replicas
  and a T-5 preflight.
- **Last-minute change breaks the demo:** fix with a feature freeze 48 hours before and a frozen, tagged release.
- **Benchmarks that don't hold up:** single runs, no warm-up, no intervals. Fix: a fixed method, enough samples, and
  bootstrap intervals.
- **Diagram overload:** one diagram for every audience. Fix: context, container, and deployment views for different
  questions.
- **Technology-first presentation:** the audience doesn't learn why it matters. Fix: problem and outcome first.
- **Hidden misses:** trust collapses when a reviewer finds one. Fix: show every target with its result.
- **No decision:** the meeting ends with "any questions?". Fix: a specific ask and a written follow-up.
- **Portfolio with secrets:** account IDs or tokens in the public repository. Fix: secret scanning and a review before
  publishing.

## Checklist

- [ ] The demo environment runs a frozen, tagged release with warm replicas, and the preflight script passes at T-5.
- [ ] I have a local kind fallback and a recorded backup video.
- [ ] I ran `s52_benchmark_ci.py`, and my benchmarks report method, sample sizes, and confidence intervals.
- [ ] I have context, container, deployment, and request sequence diagrams, drawn as code with a legend.
- [ ] My presentation leads with the outcome, shows every target with its result, and ends with a specific ask.
- [ ] I reviewed two peers' projects against the rubric and responded to every point in my own reviews.
- [ ] I rated myself on each domain with evidence and chose a learning path with a 90-day plan.
- [ ] My portfolio has a public repository, report, video, diagrams, and résumé lines with numbers, with no secrets.
