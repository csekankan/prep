# Section 50 — Capstone Project 3: Scale and Harden

> Lectures 344–350 • Exercise: [`s50_scale_check.py`](../exercises/s50_scale_check.py)
> **After this section you can:** fine-tune a model across several GPU nodes and know when it scales, detect drift in a
> RAG system from its own logs, secure the endpoints with real identity and network policy, measure cost per 1,000
> requests and cut it, make the serving path highly available, and stress-test the system to find its true capacity.
>
> Builds on: [Section 49](s49_capstone_prototype.md) (the Atlas prototype), [Section 8](../part02_data_gpus_training/s08_distributed_training.md)
> and [Section 31](../part08_scale_mlops_optimization/s31_large_scale_training.md) (distributed training),
> [Section 17](../part05_operating_production/s17_drift.md) (drift),
> [Section 18](../part05_operating_production/s18_security_compliance.md) (security),
> [Section 19](../part05_operating_production/s19_reliability_ha.md) (high availability),
> [Section 12](../part03_mlops_cicd_cost/s12_cost_optimization.md) (cost), and
> [Section 40](../part09_privacy_security_tenancy/s40_multi_tenant_ai.md) (tenancy).

The Section 49 prototype works, but it has a single point of failure at every layer, an API key in an environment
variable, no idea whether questions are changing, and no measured capacity. This section closes those gaps on the
scale-test environment: a managed Kubernetes cluster with a GPU node pool that scales from zero to three L4 GPUs. The
exercise computes the numbers behind each decision.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 344 | Scaling training across multi-GPU nodes | LoRA gradients are small enough to scale over ordinary networks; full fine-tuning isn't |
| 345 | Implementing a drift detection pipeline | Log what each request retrieved, then compare topics, scores, and refusals with a baseline daily |
| 346 | Securing model endpoints with IAM | Tokens from an identity provider, scopes, workload identity, and network policy around every component |
| 347 | Cost monitoring and optimization setup | Measure cost per 1,000 requests, scale GPUs on demand and on schedule, and cache the repeated prompt |
| 348 | Configuring high availability clusters | Replicas across zones, disruption budgets, a managed database, and a degraded mode when the model is down |
| 349 | Stress testing the AI system | Step the load until an SLO breaks, then soak, spike, and break things under load |
| 350 | Lab: deliver a scalable infra deployment | Deploy the scale-test environment, load it to capacity, kill a GPU pod, and read the cost |

```mermaid
flowchart LR
  P["Prototype<br/>Section 49"] --> T["(1) Fine-tune<br/>LoRA on 2 nodes"]
  P --> D["(2) Drift pipeline"]
  P --> S["(3) IAM + network policy"]
  P --> C["(4) Cost + autoscaling"]
  P --> H["(5) HA across zones"]
  T --> L["(6) Stress test"]
  D --> L
  S --> L
  C --> L
  H --> L
  L --> R["(7) Scalable deployment"]
```

**How to read it:** starting from the prototype, five pieces of work can happen in parallel: training at scale, drift
detection, security, cost and autoscaling, and high availability. The stress test then measures all of them together,
and the result is the scalable deployment delivered in the lab.

**Terms in this diagram.**
- **LoRA**: low-rank adaptation, fine-tuning a small set of added weights while the base model stays frozen.
- **Drift**: a change in the inputs or behavior of a model in production compared with when it was built.
- **IAM**: identity and access management, deciding who and what can call each component.
- **HA**: high availability, staying up when parts fail.
- **Stress test**: a load test that pushes the system to and past its limits.

---

## Lecture 344 — Scaling training across multi-GPU nodes

**Why it matters.** Atlas's answers improve when the model learns the product's tone and the course's terms. That
means fine-tuning, and fine-tuning on one GPU can take a day per experiment. Spreading it over several GPUs only helps
if the network can keep up with the gradients, and the exercise shows that the answer depends almost entirely on what
you train.

**In plain words.** It's like several cooks preparing one huge order. If they only need to compare a short note after
each batch, adding cooks speeds things up. If they have to swap every pot after each batch, they spend more time
passing pots than cooking.

**Architecture: data-parallel LoRA fine-tuning on two nodes.**

```mermaid
flowchart LR
  subgraph N0["Node 0: g6.xlarge, 1 L4"]
    R0["rank 0<br/>full model copy<br/>+ LoRA adapters"]
  end
  subgraph N1["Node 1: g6.xlarge, 1 L4"]
    R1["rank 1<br/>full model copy<br/>+ LoRA adapters"]
  end
  DATA[("Training data<br/>S3, sharded")] --> R0
  DATA --> R1
  R0 <-->|"all-reduce LoRA grads<br/>74 MB per step, 10 Gbps"| R1
  R0 --> CK[("Checkpoints<br/>S3 + MLflow")]
```

**How to read it:** each node runs one training process, called a rank, with a full copy of the frozen base model plus
the small LoRA adapters. Each rank reads a different shard of the data. After each backward pass, the ranks all-reduce
(average) the adapter gradients over the network, so every copy takes the same step. Rank 0 writes checkpoints and the
final adapter to S3 and MLflow.

**Terms in this diagram.**
- **g6.xlarge, L4**: an AWS instance with one NVIDIA L4 GPU (24 GB).
- **Rank**: one process in a distributed job, numbered from 0.
- **Adapters**: the small LoRA weight matrices added to the frozen model.
- **Sharded**: split so each rank reads a different part of the data.
- **All-reduce**: a collective operation that sums or averages a tensor across all ranks.
- **Grads**: gradients, the changes to apply to the trainable weights.
- **Checkpoints**: saved training state, so a stopped job can resume.

**Core ideas.** Run the exercise first:

```text
memory: full fine-tune 24.6 GB (plus activations), LoRA 3.4 GB, L4 has 24 GB; LoRA trains 18.5M parameters
  full x2 nodes: compute 1.79 s + all-reduce 3.08 s -> scaling efficiency 37%
  full x4 nodes: compute 1.79 s + all-reduce 4.62 s -> scaling efficiency 28%
  lora x2 nodes: compute 1.19 s + all-reduce 0.07 s -> scaling efficiency 94%
  lora x4 nodes: compute 1.19 s + all-reduce 0.11 s -> scaling efficiency 91%
```

- **Full fine-tuning doesn't fit.** Weights, gradients, and Adam states take about 16 bytes per parameter, which for
  Qwen2.5-1.5B is 24.6 GB before activations, more than an L4's 24 GB. You'd need sharding (FSDP or ZeRO) or bigger
  GPUs.
- **LoRA fits and scales.** It trains 18.5M parameters (rank 16 on all seven projection matrices in 28 layers), so each
  step all-reduces about 74 MB of FP32 gradients, about 0.07 s over 10 Gbps, against 1.19 s of compute.
- **Full gradients over 10 Gbps scale badly.** 3.1 GB of BF16 gradients per step takes about 3 s to all-reduce, so two
  nodes reach only 37% efficiency. Full fine-tuning across nodes needs NVLink inside a node or 100 Gbps-plus
  networking (EFA, InfiniBand) between nodes (Section 7).
- **Use spot capacity with checkpoints.** Training can restart, so it can use cheaper interruptible nodes, as long as it
  checkpoints every few minutes.

```python
# training/train_lora.py, launched by torchrun on every node
import json
import os
import time

import torch
import torch.distributed as dist
from peft import LoraConfig, get_peft_model
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler
from transformers import AutoModelForCausalLM, AutoTokenizer

MODEL, DATA, OUT = "Qwen/Qwen2.5-1.5B-Instruct", "/data/train.jsonl", "/ckpt"
dist.init_process_group("nccl")
rank, local = dist.get_rank(), int(os.environ["LOCAL_RANK"])
torch.cuda.set_device(local)

tok = AutoTokenizer.from_pretrained(MODEL)
model = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.bfloat16).cuda()
model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
model.enable_input_require_grads()
model = get_peft_model(model, LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, task_type="CAUSAL_LM",
                                         target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                                                         "gate_proj", "up_proj", "down_proj"]))
ddp = DDP(model, device_ids=[local])

rows = [json.loads(line) for line in open(DATA)]
encoded = [tok.apply_chat_template(r["messages"], tokenize=True, truncation=True, max_length=1024) for r in rows]


def collate(batch):
    n = max(len(x) for x in batch)
    ids = torch.full((len(batch), n), tok.pad_token_id)
    mask = torch.zeros((len(batch), n), dtype=torch.long)
    for i, x in enumerate(batch):
        ids[i, :len(x)], mask[i, :len(x)] = torch.tensor(x), 1
    return ids, mask, ids.masked_fill(mask == 0, -100)


sampler = DistributedSampler(encoded, shuffle=True)
loader = DataLoader(encoded, batch_size=8, sampler=sampler, collate_fn=collate)
opt = torch.optim.AdamW([p for p in ddp.parameters() if p.requires_grad], lr=2e-4)
step = 0
for epoch in range(2):
    sampler.set_epoch(epoch)
    for ids, mask, labels in loader:
        t = time.perf_counter()
        loss = ddp(input_ids=ids.cuda(), attention_mask=mask.cuda(), labels=labels.cuda()).loss
        loss.backward()
        opt.step()
        opt.zero_grad(set_to_none=True)
        step += 1
        if rank == 0 and step % 20 == 0:
            tps = mask.sum().item() * dist.get_world_size() / (time.perf_counter() - t)
            print(f"epoch={epoch} step={step} loss={loss.item():.3f} tokens/s={tps:,.0f}", flush=True)
        if rank == 0 and step % 200 == 0:
            model.save_pretrained(f"{OUT}/step-{step}")
if rank == 0:
    model.save_pretrained(f"{OUT}/final")
dist.destroy_process_group()
```

In the code, each rank loads the base model in BF16 on its own GPU, turns on gradient checkpointing to save activation
memory, and wraps it with LoRA adapters. DDP averages the adapter gradients across ranks during the backward pass.
`DistributedSampler` gives each rank a different part of the data, and `set_epoch` reshuffles it each epoch. Only rank
0 logs throughput (counting tokens on all ranks) and saves the adapters, which are about 37 MB in BF16. For
simplicity, labels cover the whole conversation. Masking the prompt tokens so only answers are learned usually works
better.

```yaml
# training/pytorchjob.yaml (Kubeflow Training Operator)
apiVersion: kubeflow.org/v1
kind: PyTorchJob
metadata: {name: atlas-lora}
spec:
  pytorchReplicaSpecs:
    Master: &replica
      replicas: 1
      restartPolicy: OnFailure
      template:
        spec:
          nodeSelector: {atlas/pool: gpu}
          tolerations: [{key: nvidia.com/gpu, operator: Exists, effect: NoSchedule}]
          containers:
            - name: pytorch
              image: ghcr.io/your-user/atlas-train@sha256:...
              command: [bash, -c]
              args: ["torchrun --nnodes=$WORLD_SIZE --node-rank=$RANK --nproc-per-node=1
                      --master-addr=$MASTER_ADDR --master-port=$MASTER_PORT train_lora.py"]
              env: [{name: NCCL_DEBUG, value: WARN}, {name: HF_HOME, value: /models}]
              resources: {limits: {nvidia.com/gpu: 1, memory: 28Gi}, requests: {cpu: "3", memory: 12Gi}}
              volumeMounts: [{name: data, mountPath: /data}, {name: ckpt, mountPath: /ckpt},
                             {name: shm, mountPath: /dev/shm}]
          volumes:
            - {name: data, persistentVolumeClaim: {claimName: atlas-train-data}}
            - {name: ckpt, persistentVolumeClaim: {claimName: atlas-ckpt}}
            - {name: shm, emptyDir: {medium: Memory, sizeLimit: 4Gi}}
    Worker: *replica
```

The PyTorchJob creates one master and one worker pod, each with one GPU, and sets `WORLD_SIZE`, `RANK`,
`MASTER_ADDR`, and `MASTER_PORT` for torchrun. The YAML anchor reuses the master's template for the worker. Both pods
need the same data and checkpoint volumes, so the checkpoint volume must support many readers and writers (EFS, or
upload to S3 instead). A g6.xlarge has 16 GB of memory, so the 28 Gi limit only fits larger instances. On g6.xlarge,
lower the limit to about 14 Gi. After training, the adapter is registered in MLflow and evaluated on the golden set
before vLLM serves it with `--enable-lora`.

**Example: the eight GPUs slower than one.** A team spread full fine-tuning of a 7B model over eight single-GPU cloud
nodes with ordinary networking and saw throughput fall below that of one node. Each step all-reduced 14 GB of
gradients over a 25 Gbps network. Switching to LoRA made the gradients about 1% of the size, and the same eight
nodes reached about 90% scaling efficiency. Full fine-tuning moved to one 8-GPU node with NVLink.

**Senior / FAANG best practice.** Before adding nodes, compute the ratio of communication to compute per step, as in the
exercise. Use NVLink domains for heavy communication and the network only for small or overlapped traffic, checkpoint
to object storage on spot capacity, and use gang scheduling (Kueue, Section 40) so a job starts only when all its pods
can. Large labs profile every new job's step for compute, communication, and data-loading time before scaling it up.

---

## Lecture 345 — Implementing a drift detection pipeline

**Why it matters.** A RAG assistant can degrade with nothing failing: users start asking about a new product the
documents don't cover, a docs reorganization breaks retrieval, or a model update changes answer style. Latency
dashboards stay green. Only checks on the content of requests and responses catch it.

**In plain words.** It's like a shop noticing that customers keep asking for an item it doesn't stock. No till is
broken, but sales are lost every day until someone looks at what people are asking for.

**Architecture: drift detection from request logs.**

```mermaid
flowchart LR
  GW["Gateway"] -->|"per request: top article,<br/>top score, refused, feedback"| QL[("queries table<br/>no raw text by default")]
  QL --> JOB["Daily drift CronJob"]
  BASE[("Baseline week")] --> JOB
  JOB -->|"topic PSI, low-score share,<br/>refusal rate, feedback"| PGW["Pushgateway"]
  PGW --> PROM["Prometheus alerts"]
  PROM --> OWN["Owner: review + act<br/>new docs, re-chunk, retrain"]
```

**How to read it:** for every request, the gateway records which article came top in retrieval, its similarity score,
whether the model refused ("I don't know"), and any user feedback. It stores these signals, not the question text, by
default. A daily CronJob compares the latest day or week with a baseline week and computes drift metrics. It pushes
them to the Pushgateway, Prometheus alerts when they cross thresholds, and the owner decides what to do.

**Terms in this diagram.**
- **Top article, top score**: the best-matching article for a question and its cosine similarity.
- **Refused**: the model said the articles don't contain the answer.
- **Feedback**: a thumbs up or down from the user.
- **Baseline**: a reference period, here a week when the system was known to work well.
- **PSI**: population stability index, a measure of how much a distribution has shifted. Under 0.1 is stable, 0.1 to
  0.2 is a moderate shift, and over 0.2 is a significant shift.
- **Pushgateway**: a Prometheus component that holds metrics pushed by batch jobs, so Prometheus can scrape them.

**Core ideas.** In a RAG system, watch four signals.

| Signal | What it catches | Alert |
|---|---|---|
| Topic mix (part of the top article), PSI vs baseline | Users asking about different things | PSI over 0.2 |
| Share of questions with top score below 0.5 ("other") | Questions the documents don't cover | Doubles vs baseline |
| Refusal rate | Coverage gaps or a retrieval break | Over 2× baseline |
| Thumbs-down rate | Answer quality problems | Over 2× baseline with at least 50 votes |

- **Topics for free:** use the section or product area of the top retrieved article as the question's topic. No extra
  model is needed.
- **Privacy by default:** log signals, not questions. If you keep sampled question text for review, mask personal data
  and set a retention period (Section 38).
- **Drift is a ticket, not a page.** It needs a human decision: write new documents, fix chunking, or update the
  golden set and model. Page only on sudden breaks such as the refusal rate tripling within an hour.

In the exercise, a week where "other" questions jump from 5% to 38% gives:

```text
question-topic PSI this week: 0.817 (alert above 0.2)
```

```python
# drift/drift_job.py, run daily as a CronJob
import math
import os
from datetime import datetime, timedelta, timezone

import psycopg
from prometheus_client import CollectorRegistry, Gauge, push_to_gateway

SQL = """SELECT CASE WHEN top_score < 0.5 THEN 'other' ELSE split_part(top_article, '_', 1) END AS topic,
                count(*), avg(refused::int), avg(CASE WHEN feedback = -1 THEN 1 ELSE 0 END)
         FROM queries WHERE ts >= %s AND ts < %s GROUP BY 1"""


def window(db, start, end):
    rows = db.execute(SQL, (start, end)).fetchall()
    total = sum(r[1] for r in rows) or 1
    share = {r[0]: r[1] / total for r in rows}
    refused = sum(r[1] * r[2] for r in rows) / total
    return share, refused, total


def psi(base, now, eps=1e-4):
    keys = set(base) | set(now)
    return sum((now.get(k, eps) - base.get(k, eps)) * math.log(now.get(k, eps) / base.get(k, eps)) for k in keys)


end = datetime.now(timezone.utc)
with psycopg.connect(os.environ["DATABASE_URL"]) as db:
    base, base_refused, _ = window(db, os.environ["BASELINE_START"], os.environ["BASELINE_END"])
    now, now_refused, n = window(db, end - timedelta(days=7), end)

reg = CollectorRegistry()
Gauge("atlas_drift_topic_psi", "Topic PSI vs baseline", registry=reg).set(psi(base, now))
Gauge("atlas_drift_other_share", "Share of low-score questions", registry=reg).set(now.get("other", 0))
Gauge("atlas_drift_refusal_ratio", "Refusal rate vs baseline", registry=reg).set(now_refused / max(base_refused, 1e-4))
Gauge("atlas_drift_sample_size", "Questions in window", registry=reg).set(n)
push_to_gateway(os.environ.get("PUSHGATEWAY", "pushgateway.monitoring:9091"), job="atlas-drift", registry=reg)
```

In the code, the query groups the window's questions by topic, taken from the prefix of the top article's ID (such as
`s40`), or "other" when the best match scores below 0.5. It also computes the refusal and thumbs-down rates. PSI
compares this week's topic shares with the baseline's, with a small floor so a topic missing on one side doesn't
divide by zero. The job pushes four gauges, including the sample size, so alerts can ignore windows with too few
questions. The baseline week comes from two ISO timestamps in the environment, such as `2026-10-05T00:00:00Z`, and
the current window is the seven days up to now.

```sql
-- the gateway writes one row per request
CREATE TABLE IF NOT EXISTS queries (
  ts timestamptz NOT NULL DEFAULT now(),
  top_article text, top_score real, refused boolean, feedback smallint, ttft_ms int, model_rev text
);
```

The table holds only signals, the timing, and the model revision, so drift can be split by model version when a new
adapter ships.

**Example: the product launch nobody told the docs team about.** Two weeks after a new feature launched, Atlas's "other"
share went from 5% to 31% and the topic PSI hit 0.6. Latency and errors were normal. The sampled masked questions were
mostly about the new feature, which had no help articles yet. The docs team published six articles, ingestion picked
them up that night, and the "other" share was back to 7% within a week.

**Senior / FAANG best practice.** Monitor drift on signals the system already produces (retrieval scores, topics,
refusals, feedback), split by model and index version, with a minimum sample size and an owner per alert. Large
search and assistant teams review sampled, privacy-filtered queries weekly, and feed confirmed gaps back into
documents, the golden set, and training data.

---

## Lecture 346 — Securing model endpoints with IAM

**Why it matters.** An LLM endpoint is an expensive, powerful resource. An unauthenticated one gets found and abused
within days, running up GPU bills or leaking the documents it retrieves. Inside the cluster, a compromised pod
shouldn't be able to reach the database or the model server directly, or read cloud storage with a long-lived key.

**In plain words.** It's like an office building. A badge gets you in the front door, your badge only opens the floors
you work on, and the server room has its own lock even for people already inside.

**Architecture: Atlas security layers.**

```mermaid
flowchart LR
  U["Client"] -->|"TLS + JWT"| EDGE["Ingress + WAF<br/>rate limits"]
  EDGE --> GW["Gateway<br/>verify JWT, check scope"]
  IDP["Identity provider<br/>OIDC, JWKS"] -.keys.-> GW
  GW -->|"NetworkPolicy allows"| LLM["llm<br/>not exposed"]
  GW -->|"NetworkPolicy allows"| PG[("Postgres")]
  ING["ingest Job<br/>pod identity"] -->|"read-only role"| S3[("S3 docs")]
  ESO["External Secrets"] -.DB password.-> GW
  SM[("Secrets Manager")] --> ESO
```

**How to read it:** clients connect over TLS and present a JWT, a signed token from the identity provider. The
ingress and WAF apply rate limits and block bad traffic. The gateway verifies the token's signature with the
provider's public keys and checks its scope. NetworkPolicies let only the gateway reach the model server and the
database, and the model server has no external route at all. The ingest job reads S3 with a short-lived role from
pod identity, not a stored key. External Secrets copies the database password from Secrets Manager into a Kubernetes
Secret.

**Terms in this diagram.**
- **JWT**: JSON Web Token, a signed token stating who the caller is and what they may do (scopes), with an expiry.
- **WAF**: web application firewall.
- **OIDC**: OpenID Connect, the standard for login and tokens built on OAuth 2.0.
- **JWKS**: JSON Web Key Set, the identity provider's published public keys used to verify JWT signatures.
- **Scope**: a permission inside the token, such as `atlas:ask` or `atlas:admin`.
- **Postgres**: the database holding Atlas's chunks and request signals.
- **NetworkPolicy**: a Kubernetes rule for which pods may connect to which.
- **Pod identity**: EKS Pod Identity (or IRSA), which gives a pod's service account a short-lived IAM role.
- **External Secrets**: an operator that syncs secrets from a cloud secret manager into Kubernetes Secrets.
- **Secrets Manager**: AWS's service for storing and rotating secrets.

**Core ideas.**
- **Replace static API keys with tokens** from an identity provider (Cognito, Auth0, Okta, Keycloak). Tokens expire,
  carry scopes, and can be revoked centrally. Keep API keys only for machine clients, stored hashed, with rotation.
- **Authorize by scope.** `atlas:ask` for chat, `atlas:admin` for re-indexing and feedback export.
- **Default-deny networking.** Start with a policy that blocks all ingress in the namespace, then allow only the paths
  in the diagram.
- **No long-lived cloud keys in the cluster.** Pod identity for S3 and MLflow artifacts, scoped to one bucket prefix.
- **Rate limits per caller** stop abuse and protect GPU capacity for everyone else.
- **Protect against prompt injection** in retrieved documents: the system prompt tells the model to treat articles as
  data, and only trusted sources are ingested (Section 39).

```python
# in services/gateway/app.py: JWT verification replaces the API-key check
import jwt
from fastapi import Depends, Header, HTTPException

ISSUER = os.environ["OIDC_ISSUER"]            # e.g. https://auth.example.com/
AUDIENCE = os.environ.get("OIDC_AUDIENCE", "atlas")
jwks = jwt.PyJWKClient(f"{ISSUER.rstrip('/')}/.well-known/jwks.json", cache_keys=True)


def require(scope):
    def check(authorization: str = Header(default="")):
        token = authorization.removeprefix("Bearer ").strip()
        try:
            key = jwks.get_signing_key_from_jwt(token).key
            claims = jwt.decode(token, key, algorithms=["RS256"], audience=AUDIENCE, issuer=ISSUER)
        except jwt.PyJWTError:
            REQS.labels("401").inc()
            raise HTTPException(401, "invalid or expired token")
        if scope not in claims.get("scope", "").split():
            REQS.labels("403").inc()
            raise HTTPException(403, f"missing scope {scope}")
        return claims
    return check


@app.post("/ask")
async def ask(req: Ask, claims: dict = Depends(require("atlas:ask"))):
    ...
```

In the code, the gateway fetches and caches the identity provider's public keys, verifies each token's signature,
expiry, audience, and issuer, and then checks that the token has the scope the route needs. An invalid token gets
401, and a valid token without the scope gets 403. Only `RS256` is accepted, which blocks attacks that switch the
algorithm. Some providers publish the key set at a different path, so read `jwks_uri` from
`/.well-known/openid-configuration` in production.

```yaml
# deploy/base/networkpolicy.yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: {name: default-deny}
spec: {podSelector: {}, policyTypes: [Ingress]}
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: {name: llm-from-gateway}
spec:
  podSelector: {matchLabels: {app: llm}}
  ingress:
    - from: [{podSelector: {matchLabels: {app: gateway}}}]
      ports: [{port: 8000}]
    - from: [{namespaceSelector: {matchLabels: {kubernetes.io/metadata.name: monitoring}}}]
      ports: [{port: 8000}]
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: {name: gateway-from-ingress}
spec:
  podSelector: {matchLabels: {app: gateway}}
  ingress:
    - from: [{namespaceSelector: {matchLabels: {kubernetes.io/metadata.name: ingress-nginx}}},
             {namespaceSelector: {matchLabels: {kubernetes.io/metadata.name: monitoring}}}]
      ports: [{port: 8080}]
```

The first policy denies all incoming traffic to every pod in the namespace. The others allow only the gateway (and
Prometheus, from the monitoring namespace) to reach the model server on port 8000, and only the ingress controller and
Prometheus to reach the gateway. With a managed database outside the cluster, the database is protected by its
security group, which allows only the node security group, plus TLS and a password. The cluster's network plugin must
enforce NetworkPolicy, as the VPC CNI does with network policy enabled, or Calico or Cilium.

```hcl
resource "aws_iam_role" "ingest" {
  name = "atlas-ingest"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{ Effect = "Allow", Principal = { Service = "pods.eks.amazonaws.com" },
                   Action = ["sts:AssumeRole", "sts:TagSession"] }]
  })
}
resource "aws_iam_role_policy" "ingest_read_docs" {
  role = aws_iam_role.ingest.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      { Effect = "Allow", Action = ["s3:ListBucket"], Resource = aws_s3_bucket.docs.arn,
        Condition = { StringLike = { "s3:prefix" = ["docs/*"] } } },
      { Effect = "Allow", Action = ["s3:GetObject"], Resource = "${aws_s3_bucket.docs.arn}/docs/*" }
    ]
  })
}
resource "aws_eks_pod_identity_association" "ingest" {
  cluster_name    = module.eks.cluster_name
  namespace       = "atlas"
  service_account = "ingest"
  role_arn        = aws_iam_role.ingest.arn
}
```

In the Terraform, the ingest role can be assumed only by EKS Pod Identity, can only list and read the `docs/` prefix of
one bucket, and is bound to the `ingest` service account in the `atlas` namespace. No access keys exist anywhere. The
`eks-pod-identity-agent` add-on must be installed on the cluster.

**Example: the open endpoint.** A student exposed the model server's port through a LoadBalancer Service "for
testing". Within four days, bots had found the OpenAI-compatible endpoint and were sending thousands of requests an
hour, keeping both GPUs at full load and the autoscaler at maximum. Removing the external Service, adding the
`llm-from-gateway` NetworkPolicy, and putting per-caller rate limits on the gateway fixed it. The budget alert at 80%
was what noticed it.

**Senior / FAANG best practice.** Use defense in depth: identity at the edge with short-lived tokens and scopes,
authorization in the service, default-deny networking, workload identity instead of keys, secrets from a manager with
rotation, and audit logs of who called what. Large companies add service-to-service mTLS through a mesh and policy
engines (OPA, Cedar) for fine-grained rules. Review the attack surface every time a new route or Service is added.

---

## Lecture 347 — Cost monitoring and optimization setup

**Why it matters.** The Section 48 proposal promised under $0.50 per 1,000 requests and under $600 a month. Without
measurement, nobody knows whether that holds, and GPU costs grow quietly: replicas idle overnight, an oversized
`max_tokens`, or the same long system prompt recomputed for every request.

**In plain words.** It's like a household budget with a meter on each appliance. Once you see which one burns the most
money, you can turn it off when nobody's home or swap it for a more efficient one.

**Architecture: measuring and cutting Atlas costs.**

```mermaid
flowchart LR
  OC["OpenCost<br/>cost per namespace"] --> UNIT["Unit cost job<br/>$ per 1,000 requests"]
  PROM["Prometheus<br/>request counts"] --> UNIT
  UNIT --> DASH["Cost panel + alert"]
  KEDA["KEDA<br/>cron + queue triggers"] --> LLM["llm replicas<br/>0 to 3"]
  LLM --> CA["Cluster autoscaler<br/>adds or removes GPU nodes"]
  PC["Prefix caching<br/>reuse system prompt"] --> LLM
```

**How to read it:** OpenCost assigns cluster costs to the `atlas` namespace, Prometheus counts requests, and a small job
divides one by the other to get cost per 1,000 requests for the dashboard and an alert. On the saving side, KEDA
scales the model server between zero and three replicas on a schedule and on queue length, and the cluster autoscaler
adds or removes GPU nodes to match. Prefix caching lets the model server reuse the computation for the shared system
prompt.

**Terms in this diagram.**
- **OpenCost**: an open-source tool that splits Kubernetes cluster costs by namespace, label, and workload.
- **Unit cost**: the cost of one unit of work, here 1,000 requests.
- **KEDA**: Kubernetes event-driven autoscaling, which can scale to zero and use triggers such as cron schedules and
  Prometheus queries.
- **Cron + queue triggers**: scale on a time schedule, and on the number of requests waiting.
- **Cluster autoscaler**: adds nodes when pods can't be scheduled and removes nodes that sit empty.
- **Prefix caching**: vLLM's reuse of the KV cache for prompt prefixes already processed, such as a shared system
  prompt.

**Core ideas.**
- **Measure the unit cost daily** and alert when it exceeds the target.
- **Scale GPUs to the schedule and the load.** For a capstone used in working hours, a cron trigger keeps two replicas
  from 08:00 to 20:00 on weekdays and zero otherwise, and a queue trigger adds a third under load.
- **Cache the repeated prompt.** Atlas sends the same system prompt with every request. With prefix caching, vLLM
  computes it once and reuses it, which cuts prefill work and TTFT.
- **Cap output.** `max_tokens: 300` stops runaway answers, the most expensive tokens in the system.
- **Right-size CPU pods** from measured use, and put training on spot capacity (Lecture 344).

```yaml
# deploy/overlays/scale-test/llm-scaledobject.yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata: {name: llm}
spec:
  scaleTargetRef: {name: llm}
  minReplicaCount: 0
  maxReplicaCount: 3
  cooldownPeriod: 900
  triggers:
    - type: cron
      metadata: {timezone: Europe/London, start: "0 8 * * 1-5", end: "0 20 * * 1-5", desiredReplicas: "2"}
    - type: prometheus
      metadata:
        serverAddress: http://mon-kube-prometheus-stack-prometheus.monitoring:9090
        query: sum(vllm:num_requests_waiting{namespace="atlas"})
        threshold: "4"
```

In the ScaledObject, the cron trigger asks for two replicas during weekday working hours, and the Prometheus trigger
adds replicas when more than about four requests per replica are waiting. KEDA uses whichever asks for more, up to
three, and scales to zero outside the schedule when nothing is waiting, after a 15-minute cooldown. Starting from zero
means the first request after hours waits for a GPU node and the model to load, several minutes, so the gateway
returns retrieval-only answers until a replica is ready (Lecture 348). Add
`--enable-prefix-caching` to the vLLM arguments (it's on by default in recent versions).

```python
# cost/unit_cost.py, run daily
import os

import httpx

OPENCOST = os.environ.get("OPENCOST_URL", "http://opencost.opencost:9003")
PROM = os.environ.get("PROM_URL", "http://mon-kube-prometheus-stack-prometheus.monitoring:9090")

alloc = httpx.get(f"{OPENCOST}/allocation", params={"window": "1d", "aggregate": "namespace"}).json()
cost = alloc["data"][0]["atlas"]["totalCost"]
q = 'sum(increase(atlas_requests_total{code="200"}[1d]))'
requests = float(httpx.get(f"{PROM}/api/v1/query", params={"query": q}).json()["data"]["result"][0]["value"][1])
print(f"atlas yesterday: ${cost:,.2f} for {requests:,.0f} requests = ${cost / requests * 1000:.3f} per 1,000")
```

The script asks OpenCost for the `atlas` namespace's cost over the last day and Prometheus for the number of
successful requests, then prints the unit cost. In the pipeline, it pushes the result as a gauge like the drift job
does. OpenCost covers in-cluster costs. Add the managed database, NAT gateway, and load balancer from the cloud bill
(tagged `project=atlas`) for the full number.

**Example: the idle nights.** In the first week of the scale-test environment, the unit cost was $1.90 per 1,000
requests, nearly four times the target. The cost panel showed two GPU replicas running all night and all weekend
with no traffic. Adding the cron trigger and scale-to-zero cut GPU hours by about 60%, and prefix caching cut TTFT p95
by about 30% at the same load. The unit cost fell to $0.31.

**Senior / FAANG best practice.** Make unit cost a first-class SLO next to latency and quality, visible on the same
dashboard and reviewed weekly. Attribute every dollar with tags and namespaces, scale GPU capacity to demand and
schedule, and treat token efficiency (prompt length, caching, output caps, model size) as an engineering metric.
FinOps teams at large companies review unit-cost trends per service, not just total spend.

---

## Lecture 348 — Configuring high availability clusters

**Why it matters.** The exercise shows the prototype's availability at about 98.4%, about 709 minutes of downtime a
month, which misses the 99.5% target. Every layer has a single replica in a single zone. HA design is what turns the
prototype into something you can promise to people.

**In plain words.** It's like a hospital with backup generators in different buildings. If one building loses power,
the others keep the lights on, and the most critical equipment has a battery that covers the gap.

**Architecture: the HA serving path.**

```mermaid
flowchart TB
  LB["Load balancer<br/>3 zones"] --> GA["gateway zone a"]
  LB --> GB["gateway zone b"]
  LB --> GC["gateway zone c"]
  GA --> LA["llm zone a<br/>L4"]
  GA --> LB2["llm zone b<br/>L4"]
  GB --> LA
  GB --> LB2
  GC --> LA
  GC --> LB2
  GA --> DB[("Managed Postgres<br/>Multi-AZ standby")]
  GB --> DB
  GC --> DB
  GA -.LLM down.-> FB["Fallback:<br/>retrieval-only answer"]
```

**How to read it:** the load balancer spreads traffic across gateway pods in three zones. Every gateway can call either
of two model server replicas, in different zones, and the managed database with a standby in another zone. If no
model server answers, the gateway still returns the most relevant articles, a degraded but useful answer.

**Terms in this diagram.**
- **Zone**: an availability zone, a separate data center in the region.
- **Managed Postgres**: a Postgres database run by the cloud provider, such as Amazon RDS.
- **Multi-AZ standby**: a database replica in another zone that takes over automatically if the primary fails.
- **Fallback**: a reduced service the system gives when a dependency is down.
- **Retrieval-only answer**: the top matching articles with links, without an LLM-written answer.

**Core ideas.** The exercise output:

```text
availability prototype: 98.3598%  ~709 min downtime per 30 days
availability HA design: 99.8964%  ~45 min downtime per 30 days
```

- **Replicas multiply, dependencies chain.** A group of replicas is down only if all of them are, but the request path
  is up only if every group on it is up. The HA design has three gateways and two model servers across zones and a
  managed Multi-AZ database. What's left is mostly the ingress and the database, at 99.95% each.
- **Spread across zones** with topology spread constraints. Two replicas in one zone protect against pod failures, not
  zone failures.
- **Protect against voluntary disruptions.** PodDisruptionBudgets stop node upgrades and autoscaler scale-downs from
  removing too many replicas at once.
- **Rollouts never reduce capacity**: `maxUnavailable: 0`, `maxSurge: 1`.
- **Degrade, don't fail.** When the LLM is down or slow, return retrieval-only answers and count them as degraded.
- **Cost of HA:** a second GPU replica all day costs about $590 a month at on-demand prices. During working hours only,
  it's about $210, which is why the cron trigger in Lecture 347 keeps two replicas in that window.

```yaml
# patches in deploy/overlays/scale-test for the llm Deployment
spec:
  replicas: 2
  strategy: {rollingUpdate: {maxUnavailable: 0, maxSurge: 1}}
  template:
    spec:
      topologySpreadConstraints:
        - maxSkew: 1
          topologyKey: topology.kubernetes.io/zone
          whenUnsatisfiable: DoNotSchedule
          labelSelector: {matchLabels: {app: llm}}
---
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata: {name: llm}
spec: {minAvailable: 1, selector: {matchLabels: {app: llm}}}
---
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata: {name: gateway}
spec: {minAvailable: 2, selector: {matchLabels: {app: gateway}}}
```

In the patches, the two model server replicas must be in different zones (`maxSkew: 1` with `DoNotSchedule`), and
rollouts add a new pod before removing an old one. The disruption budgets keep at least one model server and two
gateways running during node drains. The GPU node group must have subnets in at least two zones, and with
`maxSurge: 1` a rollout briefly needs a third GPU, which the node group's maximum of three allows.

```python
# in the gateway's stream(): fall back to retrieval-only when the model server fails before the first token
DEGRADED = Counter("atlas_degraded_total", "Retrieval-only answers")


def fallback(rows):
    DEGRADED.inc()
    lines = [f"[{i + 1}] {title} ({url})" for i, (title, url, _) in enumerate(rows)]
    return "The assistant is busy, but these articles match your question:\n" + "\n".join(lines) + "\n"

# ...
#   if r.status_code != 200:           -> yield fallback(rows); return
#   except httpx.HTTPError: if first:  -> yield fallback(rows)
```

In the fallback, the user gets the retrieved articles with titles and links instead of an error, and the counter
tracks how often it happens. An alert fires if degraded answers exceed 5% of requests for 10 minutes, so a model
server outage still pages someone even though users aren't seeing errors.

**Example: the zone that took both replicas.** In a game day, the student cordoned and drained all nodes in one zone.
The gateway stayed up, but both model server replicas had been scheduled in that zone because the topology spread
used `ScheduleAnyway`. Answers fell back to retrieval-only for 7 minutes while new GPU nodes started elsewhere. After
switching to `DoNotSchedule`, the same test caused no degraded answers.

**Senior / FAANG best practice.** Design HA by failure domain (pod, node, zone, region) and test each one with a game
day. Compute availability per path, as in the exercise, to find the weakest dependency. Graceful degradation is
standard at large companies: search shows cached results, feeds show older items, and assistants show sources when
generation fails. HA costs money, so match it to the SLO instead of maximizing it.

---

## Lecture 349 — Stress testing the AI system

**Why it matters.** The capacity in the Section 48 proposal (10 requests/s on 3 GPUs) was an estimate. A stress test
measures it, finds what breaks first, and checks that autoscaling, HA, and the fallback actually work under load.
Without it, the first real traffic peak is your stress test.

**In plain words.** It's like testing a bridge with weighted trucks before opening it. You add trucks step by step,
watch how much it bends, and stop before it's unsafe, so you know the limit before the public drives on it.

**Architecture: the stress test plan.**

```mermaid
flowchart LR
  GEN["Load generator<br/>open loop, real questions"] --> GW["Atlas gateway"]
  GW --> M["Metrics<br/>TTFT, answer time, errors,<br/>queue, GPU, replicas"]
  subgraph PLAN["Test stages"]
    S1["(1) Step: 1 to 14 req/s"] --> S2["(2) Soak: 8 req/s, 1 hour"]
    S2 --> S3["(3) Spike: 2 to 12 req/s"]
    S3 --> S4["(4) Chaos: kill an llm pod at 8 req/s"]
  end
  PLAN --> GEN
```

**How to read it:** a load generator sends real golden-set questions at a controlled rate, and the test records
latency, errors, queue depth, GPU use, and replica counts. The test runs in four stages: a step test to find capacity,
a soak test for leaks and slow degradation, a spike test for autoscaling, and a chaos test that kills a model server
pod under load.

**Terms in this diagram.**
- **Open loop**: requests are sent on a fixed schedule whatever the response time, as real users do. A closed-loop
  test waits for each response, which hides queueing.
- **Step**: raise the rate in steps, holding each long enough to measure.
- **Soak**: hold a steady load for a long time to find memory leaks and slow degradation.
- **Spike**: jump the load suddenly to test autoscaling and queues.
- **Chaos**: deliberately break something under load to check resilience.

**Core ideas.**
- **Measure what users feel:** TTFT and full-answer percentiles from the client side, not only server metrics.
- **Use realistic requests.** Golden-set questions give realistic prompt and answer lengths. One repeated short
  question flatters the result, especially with caching.
- **Capacity is where the first SLO breaks**, and the full-answer p95 often breaks before TTFT.
- **Little's law** gives concurrency: requests/s × seconds per request. At 10 requests/s and 5.9 s per answer, about
  60 streams are open at once, so the gateway, the connection pools, and vLLM's `--max-num-seqs` must allow that.

```python
# load/loadtest.py: open-loop load at fixed rates, client-side TTFT and answer time
import asyncio
import json
import random
import statistics
import sys
import time

import httpx

URL, TOKEN = sys.argv[1], sys.argv[2]
RATES = [float(r) for r in sys.argv[3].split(",")]      # e.g. 1,2,4,6,8,10,12,14
HOLD = 120                                                # seconds per step
QUESTIONS = [json.loads(line)["question"] for line in open("eval/golden_set.jsonl")]


async def one(client, out):
    t0, ttft = time.perf_counter(), None
    try:
        async with client.stream("POST", f"{URL}/ask", headers={"authorization": f"Bearer {TOKEN}"},
                                 json={"question": random.choice(QUESTIONS)}) as r:
            async for chunk in r.aiter_text():
                if ttft is None and chunk.strip():
                    ttft = time.perf_counter() - t0
            out.append((ttft, time.perf_counter() - t0, r.status_code))
    except httpx.HTTPError:
        out.append((None, time.perf_counter() - t0, 599))


def p95(xs):
    return statistics.quantiles(xs, n=20)[18] if len(xs) >= 20 else float("nan")


async def main():
    async with httpx.AsyncClient(timeout=60, limits=httpx.Limits(max_connections=500)) as client:
        print("req/s  ttft_p95  answer_p95  errors")
        for rate in RATES:
            out, tasks, start = [], [], time.perf_counter()
            while time.perf_counter() - start < HOLD:
                tasks.append(asyncio.create_task(one(client, out)))
                await asyncio.sleep(random.expovariate(rate))
            await asyncio.gather(*tasks)
            ok = [o for o in out if o[2] == 200 and o[0] is not None]
            err = 1 - len(ok) / len(out)
            print(f"{rate:5.0f}  {p95([o[0] for o in ok]):8.2f}  {p95([o[1] for o in ok]):10.2f}  {err:6.1%}")

asyncio.run(main())
```

In the code, each step sends requests with exponentially distributed gaps (a Poisson process, like independent users)
at the target rate for two minutes, without waiting for responses. Each request records the time to the first
non-empty chunk and the total time, from the client's side. After each step it prints the p95 values and the error
rate. Run it from a machine in the same region, so internet latency doesn't hide what the system does.

The measured step results on 3 L4 GPUs, and what the exercise computes from them:

| req/s | TTFT p95 (s) | Answer p95 (s) | Errors |
|---|---|---|---|
| 1 | 0.35 | 3.1 | 0% |
| 4 | 0.45 | 3.8 | 0% |
| 8 | 0.95 | 5.4 | 0% |
| 10 | 1.38 | 5.9 | 0% |
| 12 | 2.40 | 7.8 | 0.1% |
| 14 | 5.10 | 12.5 | 2.0% |

```text
stress test: TTFT p95 hits 1.5 s at 10.24 req/s, answer p95 hits 6 s at 10.11 req/s -> capacity 10.1 req/s on 3 GPUs;
concurrent streams at capacity ~60 (Little's law)
```

The full-answer SLO breaks first, at about 10.1 requests/s, within 5% of the proposal's estimate of 10. Above 12
requests/s, latency grows quickly as requests queue, the classic knee of a saturated system. The soak, spike, and chaos
stages then check that p95 stays flat for an hour at 8 requests/s, that replicas scale from 2 to 3 within the spike,
and that killing a model server pod at 8 requests/s causes a short rise in degraded answers but no errors.

**Example: the leak that took 40 minutes.** The step test passed cleanly. In the soak test, gateway memory grew
steadily and pods were killed for using too much memory after about 40 minutes, causing bursts of errors. A new
`httpx.AsyncClient` was created for each request and not always closed when clients disconnected mid-stream. Using one
shared client for the process fixed it. Only a long soak could have found it.

**Senior / FAANG best practice.** Stress-test before launch and after each major change, using production-like
requests, open-loop load, and client-side percentiles. Find the knee, set the autoscaling targets and alert thresholds
below it, and keep about 30% headroom at expected peak. Large services run load tests continuously in pre-production,
and some shadow or replay production traffic. Chaos experiments under load are the only proof that HA works.

---

## Lecture 350 — Lab: deliver a scalable infra deployment

**Goal:** deploy Atlas to the scale-test environment with everything from this section, load it to its measured
capacity, kill a GPU pod under load without user-visible errors, and report the drift signals and the unit cost.

**What you're building:** the scale-test overlay running on EKS: three gateways across zones, two to three vLLM
replicas on L4 nodes managed by KEDA and the cluster autoscaler, managed Postgres, JWT authentication, NetworkPolicies,
pod identity for ingestion, OpenCost, the drift CronJob, and a load test report.

```mermaid
flowchart LR
  TF["terraform apply<br/>VPC, EKS, GPU pool, RDS"] --> ADD["Add-ons<br/>device plugin, autoscaler,<br/>KEDA, monitoring, OpenCost"]
  ADD --> ARGO["Argo CD<br/>scale-test overlay"]
  ARGO --> RUN["Atlas running<br/>HA + autoscaled"]
  RUN --> LT["Load test<br/>step, spike, chaos"]
  LT --> REP["Report<br/>capacity, availability,<br/>drift, unit cost"]
```

**How to read the diagram:** Terraform creates the cloud resources, then the cluster add-ons are installed, then Argo
CD deploys the scale-test overlay from Git. With Atlas running, you run the load test stages and write a short report
with the measured capacity, availability during the chaos test, drift signals, and unit cost. The terms, briefly:
**add-ons** are cluster-wide components installed once, such as the GPU device plugin, the **autoscaler** that adds
nodes, KEDA, and the monitoring stack, and **RDS** is Amazon's managed relational database service.

**Prerequisites:** the Section 49 repository and CI, an AWS account with quota for at least 12 vCPUs of G instances
(three g6.xlarge), a budget alert configured, and an identity provider test tenant (Cognito, Auth0, or a Keycloak
container) to issue tokens. Budget about $30 for a full afternoon. Without GPU quota, run the same steps on kind with
llama.cpp replicas and expect lower capacity.

### Step 1 — Infrastructure and add-ons

```bash
cd infra && terraform apply                    # VPC, EKS, CPU + GPU node groups, RDS Postgres Multi-AZ, S3, budget
aws eks update-kubeconfig --name atlas
helm repo add nvdp https://nvidia.github.io/k8s-device-plugin
helm repo add autoscaler https://kubernetes.github.io/autoscaler
helm repo add kedacore https://kedacore.github.io/charts
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add opencost https://opencost.github.io/opencost-helm-chart
helm repo add argo https://argoproj.github.io/argo-helm
helm repo update
helm install nvdp nvdp/nvidia-device-plugin -n kube-system
helm install ca autoscaler/cluster-autoscaler -n kube-system \
  --set autoDiscovery.clusterName=atlas --set awsRegion=us-east-1   # plus its IAM role via pod identity
helm install keda kedacore/keda -n keda --create-namespace
helm install mon prometheus-community/kube-prometheus-stack -n monitoring --create-namespace \
  --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false
helm install pgw prometheus-community/prometheus-pushgateway -n monitoring
helm install opencost opencost/opencost -n opencost --create-namespace \
  --set opencost.prometheus.internal.serviceName=mon-kube-prometheus-stack-prometheus \
  --set opencost.prometheus.internal.namespaceName=monitoring --set opencost.prometheus.internal.port=9090
helm install argocd argo/argo-cd -n argocd --create-namespace
```

### Step 2 — Deploy through Argo CD

```bash
kubectl create namespace atlas
kubectl apply -n argocd -f - <<'EOF'
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata: {name: atlas-scale-test}
spec:
  project: default
  source: {repoURL: "https://github.com/your-user/atlas", targetRevision: main, path: deploy/overlays/scale-test}
  destination: {server: "https://kubernetes.default.svc", namespace: atlas}
  syncPolicy: {automated: {prune: true, selfHeal: true}}
EOF
kubectl -n atlas get pods -o wide -w     # gateways in 3 zones, 2 llm pods on GPU nodes in 2 zones
kubectl -n atlas create job ingest-now --from=cronjob/ingest && kubectl -n atlas logs -f job/ingest-now
```

### Step 3 — Security checks

```bash
GW=https://atlas.example.com
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GW/ask -d '{"question":"x"}'                 # 401
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GW/ask -H "authorization: Bearer $NO_SCOPE_TOKEN" \
  -H 'content-type: application/json' -d '{"question":"x"}'                                    # 403
kubectl -n atlas run probe --rm -it --image=curlimages/curl --restart=Never -- \
  curl -s -m 3 http://llm:8000/health || echo "blocked by NetworkPolicy"
```

### Step 4 — Load, spike, and chaos

```bash
python3 load/loadtest.py $GW "$TOKEN" 1,2,4,6,8,10,12,14 | tee reports/step.txt
python3 load/loadtest.py $GW "$TOKEN" 2,12 | tee reports/spike.txt &     # watch replicas in another terminal
kubectl -n atlas get scaledobject,deploy/llm -w
python3 load/loadtest.py $GW "$TOKEN" 8 | tee reports/chaos.txt &
sleep 60 && kubectl -n atlas delete --wait=false \
  "$(kubectl -n atlas get pod -l app=llm -o name | head -1)"            # deletes one llm pod, not both
```

### Step 5 — Drift and cost

```bash
kubectl -n atlas create job drift-now --from=cronjob/drift && kubectl -n atlas logs job/drift-now
kubectl -n atlas create job cost-now --from=cronjob/unit-cost && kubectl -n atlas logs job/cost-now
python3 exercises/s50_scale_check.py     # compare your measured numbers with the model's
terraform destroy                        # when you're done for the day, or scale the GPU group to 0
```

**Expected results:**
- Gateways run in three zones and model server replicas in two (`kubectl get pods -o wide` and node zone labels).
- Requests without a token get 401, tokens without `atlas:ask` get 403, and the probe pod can't reach `llm:8000`.
- The step test finds the full-answer p95 SLO breaking at about 10 requests/s on 3 L4 GPUs. Your number depends on the
  model, prompt length, and vLLM settings, so record it and update the proposal's GPU count.
- In the spike test, KEDA raises the model server from 2 to 3 replicas. If the third GPU node must start, scale-up takes
  several minutes, and TTFT rises meanwhile. That's the argument for keeping warm capacity before known peaks.
- Deleting a model server pod at 8 requests/s causes no 5xx errors. Some requests get slower or degraded
  (`atlas_degraded_total` rises), and the replica is back within the model load time.
- The drift job pushes `atlas_drift_topic_psi`. With only test traffic it's noisy, so check that the sample-size gauge
  is there to ignore small windows.
- The unit-cost job prints a cost per 1,000 requests. Under load-test traffic it's far below $0.50, and on an idle day
  it's far above, which is why it's reported over a realistic day.

---

## FAANG deep-dive notes

**How big tech does it.** Large inference platforms run model servers across zones with autoscaling on queue depth and
KV-cache pressure, keep warm pools of GPU capacity for known peaks, and fall back to smaller models or cached answers
under overload. Training platforms gang-schedule multi-node jobs on high-bandwidth fabrics and use parameter-efficient
fine-tuning to serve many adapters on one base model (multi-LoRA serving). Security uses short-lived workload
identities everywhere, default-deny networking, and central identity for users. Cost per request or per token is
tracked per product, with capacity planning tied to load-test results.

**Staff review questions.**
- What is the measured capacity per GPU, and how far below it are the autoscaling and alert thresholds?
- What is the availability of the request path, and which dependency limits it?
- What does the user see when the model server, the database, or a zone is down?
- Which identities can reach the model server, and how would you know if that changed?
- Which drift signals are monitored, with what thresholds and owners?
- What's the unit cost on a realistic day, and what's the biggest lever to cut it?

**Interview question.** "Your LLM feature is launching to 10× the users next month. What do you do?"

**Typical system-design prompt:** *Scale an LLM-backed assistant from 1 to 10 requests/s peak per region with 99.9%
availability, under $0.50 per 1,000 requests.*

**1. Clarify first:** Prompt and output lengths? TTFT and full-answer targets? Traffic shape: daily peak, launches,
regional? Fallback acceptable? GPU type and quota available? Self-hosted model or API?

**2. Back-of-envelope sizing:**
- 10 requests/s × 250 output tokens = 2,500 tokens/s. At about 840 usable tokens/s per L4 (Section 48), 3 GPUs at
  peak, plus one more so losing a zone keeps capacity: 4.
- Concurrency by Little's law: 10 × 6 s = 60 open streams, about 20 per GPU.
- 99.9% allows 43 minutes a month of downtime. The ingress and database at 99.95% each already use most of that, so
  they need multi-zone setups and the gateway needs a fallback.
- Cost: 4 L4 GPUs × 730 h × $0.805 = $2,351 a month for GPUs at 24/7. At 3 requests/s average that's
  7.9 million requests a month, about $0.30 per 1,000 for GPUs. Scaling down off-peak cuts it further.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Autoscaling signal | GPU utilization | Queue depth or KV-cache use | Queue depth: GPU utilization is high even when healthy |
| Warm capacity | Scale from zero | Minimum replicas + schedule | Warm replicas for known peaks, zero overnight |
| Fine-tuning | Full, multi-node | LoRA, small gradients | LoRA unless quality requires full, then NVLink nodes |
| Overload | Queue everything | Shed load or degrade | Degrade (smaller model, retrieval-only) before failing |
| Auth | Static API keys | OIDC tokens + scopes | Tokens for users, hashed rotated keys for machines |

**4. Follow-up questions with crisp answers:**
- *Scale-up takes 8 minutes.* Pre-pull images, cache weights on nodes or a fast volume, and keep warm replicas ahead of
  scheduled peaks.
- *TTFT is fine but answers are slow at peak.* Decode is saturated: too many concurrent sequences per GPU. Lower
  `--max-num-seqs` per replica and scale out, or use a smaller or quantized model.
- *One tenant's traffic slows everyone.* Per-tenant rate limits and quotas at the gateway, and priority classes
  (Section 40).
- *The drift alert fires every Monday.* Weekend traffic has a different mix. Compare with the same weekday in the
  baseline, or use a longer window.

**Debug this (common onsite question):** "During the load test, TTFT p95 is fine up to 12 requests/s, but users in
production complain about slow first tokens at only 4 requests/s."
1. The load test used one repeated question, so prefix caching and the short prompt flattered TTFT.
2. Production prompts include five retrieved chunks of 800 characters, about 1,500 tokens, so prefill is much heavier.
3. KEDA's queue trigger rarely fires because waiting requests stay low, but each request's prefill is long.
4. Fix: rerun the load test with golden-set questions and real retrieval, set the capacity from that result, and add a
   TTFT-based alert and a scaling trigger.

The lesson: a load test is only as good as how realistic its requests are.

**5. What separates senior from staff answers:** a senior engineer adds replicas, autoscaling, and authentication. A
staff engineer measures capacity with realistic load and plans from the knee, computes availability per path and fixes
the weakest dependency, designs degraded modes, uses identity and network policy as defaults, puts unit cost and drift
on the same dashboard as latency, and checks the communication-to-compute ratio before scaling training.

**Red flags:**
- Autoscaling on GPU utilization alone.
- Replicas in one zone called "HA".
- No fallback when the model server is down.
- An LLM endpoint reachable from the internet.
- Static cloud keys in pods.
- Load tests with one repeated question.
- Full fine-tuning across nodes on ordinary networking.

---

## Failure modes

- **Training that doesn't scale:** full gradients over a slow network. Fix: LoRA, or NVLink nodes for full fine-tuning;
  compute the ratio first.
- **Silent quality drift:** latency is green while questions move beyond the documents. Fix: topic PSI, low-score
  share, refusals, and feedback with owners.
- **Exposed model server:** bots find it and burn GPUs. Fix: no external route, NetworkPolicy, tokens, rate limits.
- **Long-lived keys in pods:** a leak gives lasting access. Fix: pod identity scoped to one prefix.
- **Idle GPUs:** replicas running overnight. Fix: cron and queue scaling to zero, plus unit-cost alerts.
- **False HA:** replicas in one zone or drained together. Fix: topology spread with `DoNotSchedule` and disruption budgets.
- **Hard failure on model outage:** users see errors. Fix: retrieval-only fallback with a degraded-answer alert.
- **Flattering load tests:** repeated short questions, closed loop. Fix: golden-set questions, open loop, client-side
  percentiles, and a soak.

## Checklist

- [ ] I ran `s50_scale_check.py` and can explain why LoRA scales over 10 Gbps and full fine-tuning doesn't.
- [ ] A two-node LoRA job runs as a PyTorchJob and saves adapters from rank 0.
- [ ] The gateway logs retrieval signals, and the drift job pushes PSI, low-score share, refusals, and sample size.
- [ ] Endpoints require JWTs with scopes, NetworkPolicies default-deny, and ingestion uses pod identity.
- [ ] KEDA scales the model server on schedule and queue depth, and unit cost is reported daily.
- [ ] Model servers spread across zones with disruption budgets, and the fallback works when they're down.
- [ ] I measured capacity with an open-loop step test and passed soak, spike, and chaos stages.
- [ ] The scale-test environment can be destroyed and recreated from code.
