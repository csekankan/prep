# Section 47 — Course Review

> Lectures 323–329 • Assessments: [Practice test: complete AI infrastructure final assessment](#practice-test--complete-ai-infrastructure-final-assessment)
> **After this section you can:** recall and connect the course's main ideas in hardware, cloud, containers and
> Kubernetes, MLOps, monitoring and security, and cost, find and fix the common mistakes in a small AI deployment under
> time pressure, and check your readiness with a 30-question practice test before starting the capstone.
>
> Builds on: every earlier section. Each review lecture links back to the sections it summarizes.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 323 | Review of hardware concepts | Memory decides what fits, bandwidth decides speed, interconnect decides scale |
| 324 | Review of cloud infrastructure | Right instance, private networking, the right storage tier, and least-privilege identity |
| 325 | Review of containerization and Kubernetes | Small, pinned, non-root images, and Kubernetes objects with requests, probes, and quotas |
| 326 | Review of MLOps pipelines | Versioned data, tracked experiments, a registry with gates, CI/CD, and monitored models |
| 327 | Review of monitoring and security | SLOs on what users feel, drift checks, and defense in depth from supply chain to tenants |
| 328 | Review of cost optimization strategies | Measure cost per unit, right-size, use spot and commitments wisely, and make models efficient |
| 329 | Lab: mini-project review sprint | Find and fix eight planted mistakes in a small model deployment in 90 minutes |

```mermaid
flowchart LR
  HWR["Hardware<br/>§1, §7, §8, §31"] --> CLR["Cloud<br/>§3, §13, §20"]
  CLR --> K8R["Containers + K8s<br/>§4, §5, §11, §40"]
  K8R --> MLR["MLOps<br/>§9, §10, §33, §34"]
  MLR --> MSR["Monitoring + security<br/>§16 to §19, §39"]
  MSR --> COR["Cost<br/>§12, §35, §41"]
  COR --> CAP["Capstone<br/>§48 to §52"]
```

**How to read it:** the review follows the stack from the bottom up. Hardware comes first, then cloud infrastructure,
then containers and Kubernetes on top of it, then MLOps pipelines running on Kubernetes, then monitoring and security
across everything, and cost optimization over the whole system. Each box lists the main sections it reviews. The
capstone in Sections 48 to 52 then uses all of it in one project.

**Terms in this diagram.**
- **§**: section number in this course.
- **Containers + K8s**: Docker images and Kubernetes, the platform most AI workloads run on.
- **MLOps**: the practices and tools that move models from experiments to reliable production.
- **Capstone**: the final, end-to-end project.

---

## Lecture 323 — Review of hardware concepts

**Why it matters.** Most AI infrastructure decisions start with hardware: whether a model fits, how fast it runs, and
how many machines a job needs. A handful of rules answer most of those questions.

**In plain words.** A GPU is like a kitchen. Memory is the counter space (does the meal fit?), memory bandwidth is how
fast ingredients reach the cooks, compute is how many cooks there are, and the interconnect is the hallway between
kitchens when one isn't enough.

**Architecture: the hardware hierarchy.**

```mermaid
flowchart TB
  CORE["Tensor cores<br/>FLOPs at a precision"] --> HBM2["HBM<br/>capacity and bandwidth"]
  HBM2 --> NVL["NVLink within a node<br/>hundreds of GB/s per GPU"]
  NVL --> NIC["InfiniBand or RoCE between nodes<br/>400 to 800 Gb/s per GPU"]
  NIC --> STOR["Storage<br/>checkpoints and data, GB/s to TB/s"]
```

**How to read it:** at the bottom, tensor cores do the math at a given precision. They're fed by HBM memory, whose
capacity decides what fits and whose bandwidth decides how fast memory-bound work runs. Within a server, NVLink
connects GPUs at hundreds of gigabytes per second each. Between servers, InfiniBand or RoCE networks give each GPU 400 to
800 gigabits per second. Storage supplies data and saves checkpoints, at gigabytes to terabytes per second for the
whole cluster.

**Terms in this diagram.**
- **Tensor cores, FLOPs**: GPU units specialized for matrix math, and floating-point operations per second, which
  double roughly each time precision halves (Section 7).
- **HBM**: high-bandwidth memory stacked next to the GPU chip (80 GB on an H100, 141 GB on an H200).
- **NVLink**: NVIDIA's fast GPU-to-GPU link inside a server or rack.
- **InfiniBand or RoCE**: high-speed networks between servers for distributed training (Section 13).
- **Gb/s, GB/s**: gigabits and gigabytes per second. 8 bits make a byte.

**Core ideas.**
- **Memory to fit (Section 7):**
  - Inference weights take parameters × bytes per parameter (2 for BF16, 1 for FP8 or INT8, about 0.5 for 4-bit), plus
    the KV cache.
  - Training with mixed-precision Adam takes about 16 bytes per parameter, plus activations.
- **Compute time (Section 31):** training FLOPs ≈ 6 × parameters × tokens. Time = FLOPs / (GPUs × peak × MFU), with
  MFU typically 35–50%.
- **Inference speed:** decoding is memory-bandwidth bound, so tokens per second per sequence ≈ bandwidth / bytes read
  per token. Batching raises throughput.
- **Scale (Sections 8, 31, 32):** data, tensor, pipeline, and expert parallelism, with ZeRO or FSDP sharding. Keep tensor
  parallelism within NVLink.
- **Reliability at scale:** failures every few hours on 10,000+ GPUs, so checkpoint asynchronously at Young's interval.

**Example: does it fit?** Question: can Llama 3 8B serve 32 concurrent 8K-token chats on one 24 GB GPU in BF16?
Weights are 16 GB. The KV cache is 128 KB per token (32 layers × 8 KV heads × 128 dimensions × 2 for keys and values × 2
bytes), so 32 × 8,192 tokens need 34 GB. Total 50 GB, so it doesn't fit. INT4 weights (about 5 GB) plus an FP8 KV cache
(17 GB) is 22 GB, which barely fits, with little headroom. A 48 GB GPU is the comfortable answer.

**Senior / FAANG best practice.** Answer hardware questions with numbers: bytes per parameter, KV cache per token,
6·N·D, and bandwidth-bound decode speed. Check fit with headroom (about 10–20% for runtime overhead), match parallelism
to the interconnect, and plan checkpointing from failure rates.

---

## Lecture 324 — Review of cloud infrastructure

**Why it matters.** Cloud mistakes are expensive or dangerous: the wrong instance type wastes money, public buckets leak
data, and missing private networking exposes services. The fundamentals from Part I still prevent most of them.

**In plain words.** Renting cloud infrastructure is like renting a building. Choose the right size of room, lock the
doors, put things in the right kind of storage, and give keys only to people who need them.

**Architecture: a secure cloud layout for AI.**

```mermaid
flowchart LR
  USERS2["Users"] --> LB3["Load balancer<br/>public subnet, TLS"]
  LB3 --> APP3["App + model servers<br/>private subnets, GPU instances"]
  APP3 --> OBJ["Object storage<br/>datasets, models, private endpoint"]
  APP3 --> DB3["Managed database"]
  APP3 --> FILE["Shared file system<br/>training data, checkpoints"]
  IAM2["IAM roles<br/>least privilege, workload identity"] -.-> APP3
```

**How to read it:** users reach a load balancer in a public subnet that terminates TLS. Application and model servers,
including GPU instances, sit in private subnets with no direct internet exposure. They read datasets and models from
object storage through a private endpoint, use a managed database, and share training data and checkpoints on a shared
file system. IAM roles with least privilege, assigned through workload identity, decide what each server can access.

**Terms in this diagram.**
- **Public subnet, private subnets**: parts of a virtual network that can or can't be reached from the internet
  (Section 3).
- **Private endpoint**: access to a cloud service (such as S3) from inside the virtual network, without going over the
  internet.
- **Managed database**: a database the cloud provider runs, such as RDS or Cloud SQL.
- **Shared file system**: network storage that many servers mount at once, such as FSx for Lustre or Filestore
  (Section 6).
- **Least privilege, workload identity**: granting only the permissions needed, and giving workloads short-lived cloud
  credentials instead of stored keys (Section 18).

**Core ideas.**
- **Instances (Section 3):** CPU instances for small models and preprocessing, GPU instances sized to the model, spot for
  interruptible work, and on-demand or reserved for steady serving.
- **Networking (Sections 3 and 13):** VPCs with private subnets, security groups allowing only needed ports, NAT for
  outbound traffic, private endpoints for storage, and VPN or private links for hybrid setups.
- **Storage tiers (Section 6):** object storage for datasets and models, block storage for single-server disks, and
  parallel file systems for high-throughput training. Lifecycle rules move old data to cheaper tiers.
- **Identity (Section 18):** roles per workload, no long-lived keys, and policies scoped to specific buckets and actions.
- **Multi-cloud and hybrid (Section 20):** use portable layers (containers, Terraform, standard APIs), and place work by
  data, cost, and capacity.

**Example: the 3 a.m. bill.** A team's training job wrote checkpoints across regions, from a GPU cluster in one region
to a bucket in another, paying cross-region transfer for 40 TB a week. Moving the bucket to the same region, and using a
private endpoint, cut the monthly bill by $3,200 and made checkpoints faster.

**Senior / FAANG best practice.** Keep compute and data in the same region, keep servers in private subnets behind load
balancers, use private endpoints and least-privilege roles with workload identity, choose storage tiers by access
pattern with lifecycle rules, and define everything as code.

---

## Lecture 325 — Review of containerization and Kubernetes

**Why it matters.** Almost every AI workload in this course ran in containers on Kubernetes. Well-built images and
well-specified Kubernetes objects make deployments reproducible, secure, and schedulable. Poor ones cause most
production surprises.

**In plain words.** A container is a sealed lunchbox with everything a meal needs. Kubernetes is the cafeteria
manager who decides which table each lunchbox goes to, replaces dropped ones, and makes sure nobody takes more than
their share.

**Architecture: what a good deployment declares.**

```mermaid
flowchart TB
  IMG["Image<br/>slim, pinned digest, non-root, scanned"] --> DEP["Deployment<br/>replicas, rolling update"]
  DEP --> RES["Requests + limits<br/>CPU, memory, nvidia.com/gpu"]
  DEP --> PROBE["Probes<br/>startup, readiness, liveness"]
  DEP --> SVC["Service + Ingress<br/>stable address, TLS"]
  DEP --> CFG["ConfigMap + Secret<br/>config outside the image"]
  NS3["Namespace<br/>quota, LimitRange, RBAC, NetworkPolicy"] --> DEP
  HPA2["Autoscaler<br/>HPA or KEDA"] --> DEP
```

**How to read it:** a good deployment starts from a slim image pinned by digest, running as a non-root user and
scanned for vulnerabilities. The Deployment sets the number of replicas and rolling updates. It declares resource
requests and limits, including GPUs, and startup, readiness, and liveness probes. A Service and Ingress give it a stable
address and TLS. Configuration and secrets live outside the image. The namespace provides quotas, defaults, access
control, and network policy, and an autoscaler adjusts replicas.

**Terms in this diagram.**
- **Pinned digest**: referring to an image by its content hash (`image@sha256:...`), so it can't change underneath you
  (Section 4).
- **Rolling update**: replacing pods gradually, so the service stays available.
- **Requests + limits**: the resources a pod is guaranteed and the most it may use. GPUs are requested in whole units or
  MIG slices (Section 5).
- **Startup, readiness, liveness probes**: checks for "has it finished starting", "should it get traffic", and "is it
  stuck and should it restart" (Section 5).
- **ConfigMap, Secret**: Kubernetes objects for configuration and sensitive values.
- **Quota, LimitRange, RBAC, NetworkPolicy**: a namespace's resource caps, its default and maximum container sizes, its
  access permissions, and its rules for which pods may talk to which (Sections 5 and 40).
- **HPA, KEDA**: the Horizontal Pod Autoscaler, and Kubernetes Event-Driven Autoscaling, which scales on metrics such as
  queue length (Section 11).

**Core ideas.**
- **Images (Section 4):** multi-stage builds, slim CUDA runtime bases, pinned versions, non-root users, no secrets in
  layers, models loaded from storage or baked deliberately, and scans in CI.
- **Kubernetes basics (Section 5):** Deployments for services, Jobs for batch, StatefulSets for stateful services, and
  DaemonSets for per-node agents such as the GPU device plugin.
- **GPU scheduling (Section 11):** the NVIDIA GPU Operator, taints for GPU nodes, Kueue for quotas and gang
  admission, and MIG or time-slicing for sharing.
- **Probes for models:** a startup probe long enough for model loading, readiness only after warmup, and a liveness
  probe that doesn't restart pods during long requests.
- **Multi-tenancy (Section 40):** namespace per team with quotas, LimitRanges, RBAC, and default-deny network policies.

**Example: the restart loop.** A model server took 4 minutes to load a 70B model, but its liveness probe started after
30 seconds and failed three times, so Kubernetes restarted it forever. Adding a startup probe allowing 10 minutes, and
making readiness depend on a warmup request, fixed it.

**Senior / FAANG best practice.** Build slim, pinned, non-root, scanned images. Give every pod requests, limits, and the
three probes tuned to model loading. Keep config outside images, use namespaces with quotas and policies, schedule GPUs
with taints and Kueue, and autoscale on the metric that tracks load.

---

## Lecture 326 — Review of MLOps pipelines

**Why it matters.** MLOps turns one good experiment into a model that can be retrained, reproduced, audited, and safely
updated. Each piece covered in Parts III and VIII prevents a specific production failure.

**In plain words.** It's like a car factory's assembly line. Every part is labeled, every step is recorded, every car is
inspected before leaving, and if a problem appears later, you can find exactly which batch it came from.

**Architecture: the end-to-end MLOps loop.**

```mermaid
flowchart LR
  DATA7["Versioned data<br/>DVC, lakeFS, snapshots"] --> PIPE["Pipeline<br/>Kubeflow, Airflow, SageMaker"]
  PIPE --> TRACK["Experiment tracking<br/>MLflow: params, metrics, artifacts"]
  TRACK --> REG2["Registry<br/>versions, aliases, risk tier"]
  REG2 --> GATE2["Quality gate<br/>evals, fairness, latency"]
  GATE2 --> CD2["CD<br/>canary, rollback"]
  CD2 --> MON7["Monitoring<br/>drift, performance"]
  MON7 -->|"retrain trigger"| PIPE
```

**How to read it:** versioned data feeds a pipeline orchestrator, such as Kubeflow, Airflow, or SageMaker Pipelines.
Each run is tracked in MLflow with its parameters, metrics, and artifacts, and promising models go to the registry with
versions, aliases, and a risk tier. A quality gate checks evaluations, fairness, and latency before continuous delivery
deploys with a canary and automatic rollback. Monitoring watches drift and performance, and can trigger retraining.

**Terms in this diagram.**
- **DVC, lakeFS, snapshots**: tools for versioning datasets, or storage snapshots that fix a dataset's exact state
  (Section 9).
- **Kubeflow, Airflow, SageMaker**: pipeline orchestrators (Sections 24 and 33).
- **Params, metrics, artifacts**: a run's settings, results, and output files.
- **Aliases, risk tier**: registry labels such as `champion`, and the model's risk level, which decides required
  checks (Section 34).
- **Quality gate**: automated checks a model must pass before deployment (Section 10).
- **Canary, rollback**: a small first release, and switching back if metrics worsen (Section 15).

**Core ideas.**
- **Reproducibility (Section 9):** data version, code commit, environment, and seeds recorded for every run.
- **CI/CD for models (Section 10):** tests for code and data, evaluation gates against the current champion, and
  progressive delivery.
- **Enterprise scale (Sections 33 and 34):** paved-path platforms, the registry as the system of record, continuous
  training, point-in-time correct features, risk-tier governance, and tamper-evident audit logs.
- **LLM specifics (Sections 25 and 26):** prompt and model versioning, eval suites with golden answers, and
  retrieval-quality checks for RAG.

**Example: the unreproducible model.** An auditor asked a team to reproduce a credit model from 18 months earlier. The
training data table had been overwritten, and nobody knew which code commit was used. The rebuild took six weeks and
didn't match exactly. Their new pipeline records a data snapshot ID, commit hash, container digest, and seed in MLflow,
so any model version can be rebuilt with one command.

**Senior / FAANG best practice.** Version data and record code, environment, and seeds for every run. Gate promotions
with evaluations against the champion, deploy progressively with rollback, monitor drift and performance with
retraining triggers, and keep the registry as the single source of truth with audit trails.

---

## Lecture 327 — Review of monitoring and security

**Why it matters.** Monitoring tells you when users are affected, and security keeps attackers and mistakes from
causing harm. Parts V and IX covered both. In production they work together: many security incidents are first seen as
anomalies in monitoring.

**In plain words.** It's like running a shop with both a smoke detector and good locks. The detector tells you quickly
when something's wrong, and the locks stop most problems from happening in the first place.

**Architecture: observability and defense in depth.**

```mermaid
flowchart TB
  subgraph OBS["Observability"]
    MET8["Metrics<br/>Prometheus, DCGM"] --> SLO8["SLOs + burn-rate alerts"]
    LOGS8["Logs + traces<br/>OpenTelemetry"] --> SLO8
    DRIFT8["Drift + quality<br/>PSI, evals"] --> SLO8
  end
  subgraph SEC8["Security layers"]
    SUP["Supply chain<br/>signed images and models"] --> ID8["Identity<br/>SSO, RBAC, workload identity"]
    ID8 --> NET8["Network<br/>private, default-deny, egress allowlist"]
    NET8 --> DATA8["Data<br/>encryption, residency, privacy"]
    DATA8 --> MOD8["Model<br/>poisoning, adversarial, prompt injection"]
  end
  SLO8 --> IR["Incident response<br/>runbooks, postmortems"]
  MOD8 --> IR
```

**How to read it:** observability collects metrics from Prometheus and DCGM, logs and traces through OpenTelemetry, and
drift and quality signals such as PSI and evaluations. All feed SLOs with burn-rate alerts. Security is layered: a
signed supply chain, identity and access control, private networks with default-deny rules, protected data, and
defenses at the model level against poisoning, adversarial inputs, and prompt injection. Both feed incident response,
with runbooks and postmortems.

**Terms in this diagram.**
- **DCGM**: NVIDIA's GPU metrics exporter (Section 16).
- **SLOs + burn-rate alerts**: service-level objectives, and alerts on how fast the error budget is being used
  (Section 16).
- **OpenTelemetry**: the open standard for collecting traces, metrics, and logs.
- **PSI**: population stability index, a drift measure (Section 17).
- **Signed images and models**: cryptographic signatures checked before running (Section 39).
- **SSO, RBAC, workload identity**: single sign-on through the company identity provider, role-based permissions, and
  short-lived credentials for workloads (Sections 18 and 40).
- **Egress allowlist**: only approved outbound destinations are reachable (Section 39).
- **Prompt injection**: instructions hidden in input that try to make an LLM ignore its rules (Section 25).
- **Runbooks, postmortems**: step-by-step response guides, and blameless reviews after incidents (Section 19).

**Core ideas.**
- **Monitor what users feel (Section 16):** latency percentiles, errors, and availability per endpoint, plus GPU
  utilization and memory for capacity.
- **Model health (Section 17):** input drift with PSI or embedding distance, prediction drift, and delayed ground-truth
  performance. Retrain or roll back by policy.
- **Reliability (Section 19):** redundancy across zones, graceful degradation, tested backups, and game days.
- **Security (Sections 18, 38, 39, 40):** least privilege, secrets management, signed artifacts, no public ML
  dashboards, privacy techniques for sensitive data, and tenant isolation.
- **Respond well:** declare, contain, preserve evidence, communicate, fix, and learn.

**Example: the alert that was a breach.** A GPU utilization alert fired on a weekend when no jobs were scheduled. The
on-call engineer found a crypto miner running through an exposed Jupyter server. Because the team had an egress
allowlist, the miner couldn't reach its pool and no data left the cluster. They contained it in 20 minutes and closed
the exposure.

**Senior / FAANG best practice.** Alert on SLO burn rates for user-facing metrics, watch drift and model quality,
correlate infrastructure anomalies with security signals, layer security from supply chain to model, practice incident
response, and write blameless postmortems with owned actions.

---

## Lecture 328 — Review of cost optimization strategies

**Why it matters.** GPU costs dominate AI budgets, and small inefficiencies multiply quickly. The cost tools from Parts
III, VIII, IX, and X work together: measure unit costs, right-size, buy wisely, and make models cheaper to run.

**In plain words.** It's like managing a household budget. Track where every dollar goes, stop paying for what you
don't use, buy in bulk only what you always need, and find cheaper ways to get the same result.

**Architecture: the cost optimization loop.**

```mermaid
flowchart LR
  MEAS["Measure<br/>cost per request, per training run, per team"] --> RIGHT["Right-size<br/>GPU type, replicas, idle shutdown"]
  RIGHT --> BUY["Buy wisely<br/>spot, commitments, credits"]
  BUY --> EFF["Make models efficient<br/>quantize, distill, batch, cache, route"]
  EFF --> ALLOC2["Allocate + govern<br/>labels, budgets, showback"]
  ALLOC2 --> MEAS
```

**How to read it:** cost work runs in a loop. Measure cost per request, per training run, and per team. Right-size the
GPU type and number of replicas, and shut down idle resources. Buy wisely, using spot for interruptible work,
commitments for steady load, and credits. Make models efficient through quantization, distillation, batching, caching,
and routing. Allocate and govern costs with labels, budgets, and showback reports, then measure again.

**Terms in this diagram.**
- **Cost per request**: unit cost of serving, compared with revenue per request (Section 41).
- **Idle shutdown**: automatically stopping unused notebooks and dev GPUs (Section 40).
- **Spot, commitments, credits**: discounted interruptible capacity, discounts for committed usage, and free startup or
  promotional credits (Sections 12 and 41).
- **Quantize, distill, batch, cache, route**: using fewer bits, training smaller student models, grouping requests,
  reusing results, and sending easy requests to cheap models (Sections 35, 36, and 41).
- **Showback**: reporting costs to the teams that caused them (Section 40).

**Core ideas.**
- **Unit economics first (Sections 12 and 41):** track cost per request and per training run, and gross margin.
- **Right-size (Sections 12 and 40):** the smallest GPU that meets latency, autoscaling with warm minimums, MIG for small
  models, and idle shutdown.
- **Purchasing (Sections 12, 41, and 42):** spot with checkpoints for training, commitments only for proven base load,
  and TCO on equal bases for on-prem vs cloud.
- **Efficiency (Sections 35, 36, and 43):** quantization and distillation, continuous batching, caching, cascades, and
  prompt trimming for LLMs.
- **Governance (Section 40):** required cost labels, budgets with alerts, and showback before chargeback.

**Example: four levers, one bill.** A team serving an 8B model on 8 H100s at 25% utilization applied four levers: FP8
quantization (twice the throughput), continuous batching tuning (1.5 times more), a semantic cache answering 20% of
requests, and autoscaling with a warm minimum. They served the same traffic on 3 GPUs, cutting the bill by 62%, with
evals confirming quality.

**Senior / FAANG best practice.** Measure unit costs and attribute them to teams, right-size before buying, use spot
and commitments deliberately, make models efficient with evals as the guard, and review costs monthly with clear owners
and budgets.

---

## Lecture 329 — Lab: mini-project review sprint

**Goal:** in 90 minutes, review a small model deployment, find the eight planted mistakes across the Dockerfile, the
application, the Kubernetes manifest, and the alert rule, fix them, and explain each fix in one sentence.

**What you're building:** corrected versions of `app.py`, `Dockerfile`, `deploy.yaml`, and `alert.yaml`, and a
`REVIEW.md` listing each problem, its risk, and the fix.

```mermaid
flowchart LR
  BROKEN["Broken mini-project<br/>4 files, 8 planted mistakes"] --> FIND["Find<br/>read, run, lint"]
  FIND --> FIX2["Fix<br/>one change per issue"]
  FIX2 --> VERIFY["Verify<br/>build, run, kubectl dry-run, promtool"]
  VERIFY --> WRITE["REVIEW.md<br/>issue, risk, fix"]
```

**How to read the diagram:** start from the broken mini-project (four files with eight planted mistakes), find the
problems by reading, running, and linting, fix each with one focused change, verify with a build, a local run, a
Kubernetes dry run, and Prometheus's rule checker, and write the review. **promtool** is Prometheus's command-line tool
for checking rule files, and a **dry run** validates a manifest without applying it.

**Prerequisites:** Docker, `kubectl` (a kind cluster is enough for dry runs), and optionally `promtool` and
`hadolint` (a Dockerfile linter).

### Step 1 — The broken files

```python
# app.py
import pickle, time
from fastapi import FastAPI

app = FastAPI()

@app.post("/predict")
def predict(features: list[float]):
    model = pickle.load(open("/models/model.pkl", "rb"))
    start = time.time()
    y = model.predict([features])[0]
    return {"prediction": float(y), "latency": time.time() - start}

@app.get("/health")
def health():
    return {"ok": True}
```

```dockerfile
# Dockerfile
FROM python:latest
COPY . /app
WORKDIR /app
ENV AWS_SECRET_ACCESS_KEY=AKIA...redacted
RUN pip install fastapi uvicorn scikit-learn
CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]
```

```yaml
# deploy.yaml
apiVersion: apps/v1
kind: Deployment
metadata: {name: model-api}
spec:
  replicas: 1
  selector: {matchLabels: {app: model-api}}
  template:
    metadata: {labels: {app: model-api}}
    spec:
      containers:
        - name: api
          image: registry.example.com/model-api:latest
          ports: [{containerPort: 8000}]
          livenessProbe: {httpGet: {path: /health, port: 8000}, initialDelaySeconds: 5}
```

```yaml
# alert.yaml
groups:
  - name: model-api
    rules:
      - alert: HighLatency
        expr: avg(rate(http_request_duration_seconds_sum[5m]) / rate(http_request_duration_seconds_count[5m])) > 0.5
        labels: {severity: page}
```

### Step 2 — Find, fix, verify

Review the files, fix every issue you find, then verify:

```bash
docker build -t model-api:fixed . && docker run --rm -p 8000:8000 -v $PWD/models:/models model-api:fixed
kubectl apply --dry-run=server -f deploy.yaml
promtool check rules alert.yaml
```

### Step 3 — Write REVIEW.md

For each issue, write `Issue | Risk | Fix` in one line each, then compare with the answer key below.

**Expected results:** the eight planted issues and their fixes:

| # | File | Issue | Risk | Fix |
|---|---|---|---|---|
| 1 | `app.py` | Model loaded from disk on every request | High latency and CPU use under load | Load once at startup (a module-level variable or FastAPI lifespan) |
| 2 | `app.py` | `pickle.load` of a model file | Arbitrary code execution if the file is tampered with | Load from a trusted, verified artifact (signature or hash check), or use a safe format such as ONNX or skops (Section 39) |
| 3 | `app.py` | No input validation (any list length) | Crashes and confusing errors | A Pydantic model with the expected number of features and value ranges |
| 4 | `Dockerfile` | `python:latest`, unpinned packages | Non-reproducible builds that can break without changes | Pin the base image by version or digest and pin package versions |
| 5 | `Dockerfile` | Secret in an `ENV` line | Credentials leak to anyone who can pull the image | Remove it, rotate the key, and use workload identity or a mounted Secret |
| 6 | `Dockerfile` | Runs as root | A container escape gets root | Add a non-root user and `USER` |
| 7 | `deploy.yaml` | `:latest` image, 1 replica, no requests, limits, or readiness probe | Unpredictable versions, downtime on restarts, noisy neighbors, traffic to unready pods | Image pinned by digest, 2+ replicas, requests and limits, a readiness probe, and a startup probe if loading is slow |
| 8 | `alert.yaml` | Pages on average latency with no `for` duration | Misses tail latency and pages on brief spikes | Alert on p99 with `histogram_quantile` over buckets, add `for: 10m`, or use SLO burn-rate alerts (Section 16) |

Each verification command succeeds on the fixed files, and `REVIEW.md` explains all eight in one line each. A strong
review also notes smaller issues, for example: the reported latency excludes request parsing, no metrics endpoint is
exposed, there's no `.dockerignore`, and the alert has no runbook annotation.

---

## Practice test — Complete AI infrastructure final assessment

**Instructions.** 30 questions across six domains, 5 per domain. Allow 60 minutes and answer before opening each
answer. Score 1 point per question. **24 or more** means you're ready for the capstone. 18–23 means review the sections
listed for the questions you missed. Below 18 means revisit the review lectures above first.

**Hardware (Lecture 323)**

<details><summary>1. How much memory do the BF16 weights of a 70B-parameter model need?</summary>
70 × 10⁹ × 2 bytes = 140 GB, so at least two 80 GB GPUs before the KV cache. (Section 7)
</details>

<details><summary>2. Roughly how many FLOPs does training a 7B model on 2 trillion tokens take?</summary>
6 × 7 × 10⁹ × 2 × 10¹² = 8.4 × 10²² FLOPs. (Section 31)
</details>

<details><summary>3. Why is LLM decoding usually memory-bandwidth bound?</summary>
Each token requires reading all weights (and the KV cache) from memory, but does relatively little math per byte, so memory
bandwidth limits speed. Batching shares each weight read across many sequences. (Section 7)
</details>

<details><summary>4. Why keep tensor parallelism within a server?</summary>
It communicates every layer, so it needs NVLink's bandwidth. Across servers, the slower network would stall it. Use pipeline
and data parallelism across servers. (Section 31)
</details>

<details><summary>5. A 4,096-GPU job sees a failure every 12 hours, and a checkpoint stalls it for 2 minutes. What's Young's checkpoint interval?</summary>
√(2 × 2 min × 720 min) = √2,880 ≈ 54 minutes. (Section 32)
</details>

**Cloud (Lecture 324)**

<details><summary>6. Why put GPU servers in private subnets?</summary>
So they can't be reached directly from the internet. Traffic comes through a load balancer, and outbound traffic goes
through NAT or private endpoints. (Section 3)
</details>

<details><summary>7. Which storage fits a multi-node training job reading many small files at high throughput?</summary>
A parallel file system such as FSx for Lustre, or object storage with sharded formats such as WebDataset and caching.
(Section 6)
</details>

<details><summary>8. What's wrong with an access key stored in a training container's environment?</summary>
It's long-lived and leaks to anyone who can read the image or pod. Use workload identity for short-lived credentials.
(Section 18)
</details>

<details><summary>9. Why keep checkpoints in the same region as the GPUs?</summary>
To avoid cross-region transfer fees and latency, which make saves slower and more expensive. (Section 12)
</details>

<details><summary>10. What makes a multi-cloud setup portable?</summary>
Containers, Kubernetes, infrastructure as code, standard APIs and formats, and data placement planned for egress costs.
(Section 20)
</details>

**Containers and Kubernetes (Lecture 325)**

<details><summary>11. What do readiness and liveness probes each control?</summary>
Readiness decides whether a pod receives traffic. Liveness decides whether it's restarted. A startup probe protects slow
model loading from liveness restarts. (Section 5)
</details>

<details><summary>12. Why must a pod's GPU request equal its limit?</summary>
GPUs are extended resources that can't be overcommitted, so Kubernetes requires the limit and treats the request as equal.
(Section 40)
</details>

<details><summary>13. What does Kueue's gang admission prevent?</summary>
A distributed job starting with only some of its workers, holding GPUs while waiting forever for the rest. (Section 11)
</details>

<details><summary>14. Name three image-hardening practices.</summary>
A slim, pinned base, a non-root user, no secrets in layers, vulnerability scanning, and signing. (Sections 4 and 39)
</details>

<details><summary>15. How do you share one A100 among several small inference services with isolation?</summary>
MIG, which splits it into hardware-isolated instances with their own memory and compute. (Section 11)
</details>

**MLOps (Lecture 326)**

<details><summary>16. What must be recorded to reproduce a model?</summary>
The data version, code commit, environment (container digest), hyperparameters, and seeds. (Section 9)
</details>

<details><summary>17. What should a deployment quality gate compare the candidate model against?</summary>
The current production champion, on the same evaluation data, with thresholds for quality, fairness, and latency.
(Section 10)
</details>

<details><summary>18. What is a point-in-time correct join?</summary>
Building training rows using only feature values available at each label's time, so no future information leaks.
(Section 34)
</details>

<details><summary>19. Why use a canary for a new model?</summary>
It exposes a small share of traffic first, so problems are caught with limited impact and rolled back automatically.
(Section 15)
</details>

<details><summary>20. What triggers retraining in continuous training?</summary>
A schedule, detected drift, a performance drop on fresh labels, or new data volume, followed by gated evaluation against the
champion. (Section 34)
</details>

**Monitoring and security (Lecture 327)**

<details><summary>21. Why alert on burn rate rather than raw error rate?</summary>
Burn rate measures how fast the error budget is being used, so it pages for serious, sustained problems and ignores brief
blips. (Section 16)
</details>

<details><summary>22. A feature's PSI is 0.31. What does it mean?</summary>
A significant distribution shift (above about 0.25 is usually considered major), worth investigating and possibly retraining.
(Section 17)
</details>

<details><summary>23. Why is loading a pickled model risky?</summary>
Unpickling can execute arbitrary code. Use safetensors or other safe formats, or verify signatures. (Section 39)
</details>

<details><summary>24. What does differential privacy guarantee in training?</summary>
The trained model changes very little whether or not any one person's data is included, bounded by ε. (Section 38)
</details>

<details><summary>25. What's the first step after discovering an exposed Ray dashboard running unknown jobs?</summary>
Declare an incident, then contain it (remove the exposure, block access, stop jobs) while preserving evidence such as disk
snapshots before terminating nodes. (Section 39)
</details>

**Cost (Lecture 328)**

<details><summary>26. A request uses 2,000 input and 400 output tokens at $3 and $15 per million. What does it cost?</summary>
2,000 × 3 / 10⁶ + 400 × 15 / 10⁶ = $0.006 + $0.006 = $0.012. (Section 41)
</details>

<details><summary>27. When are spot GPUs a good choice?</summary>
For interruptible work that checkpoints often, such as training and batch inference, not for latency-critical serving
without fallback. (Section 12)
</details>

<details><summary>28. How much smaller are INT4 weights than BF16?</summary>
About 4 times smaller (0.5 vs 2 bytes per parameter), slightly less with group scales. (Section 35)
</details>

<details><summary>29. Why charge teams for requested GPU-hours rather than utilization?</summary>
Requested GPUs are unavailable to others whether used or not. Report utilization separately as efficiency. (Section 40)
</details>

<details><summary>30. On-prem costs $3.13 per available GPU-hour, and cloud on-demand costs $6.00. Above what utilization is on-prem cheaper?</summary>
3.13 / 6.00 ≈ 52%. (Section 42)
</details>

---

## FAANG deep-dive notes

**How big tech does it.** Before major launches and in onboarding, big tech teams run structured reviews: production
readiness reviews with checklists covering capacity, reliability, monitoring, security, and cost; design reviews where
staff engineers question assumptions with numbers; and game days that practice failures. Engineers are expected to
connect concepts across the stack, for example, how a quantization choice changes memory, latency, cost, and evaluation
requirements at once.

**Staff review questions.**
- Can you size memory, compute, and time for a model from first principles?
- Which resources does every pod declare, and how is GPU capacity shared?
- Can every production model be reproduced and traced to its data?
- Which SLOs page, and which security layers would stop the last incident type?
- What is the cost per unit, and who owns it?

**Interview question.** "Walk me through deploying a new 8B model to production, from hardware sizing to on-call."

**Typical system-design prompt:** *Take a fine-tuned 8B model from a notebook to a production API serving 50 requests
per second at p99 under 1 second for the first token.*

**1. Clarify first:** Prompt and output lengths? Peak vs average traffic? Quality bar and evals? Data sensitivity?
Budget? Existing platform?

**2. Back-of-envelope sizing:**
- Memory: 16 GB BF16 weights, or 8 GB in FP8. With 1,500-token prompts and 300-token outputs, the KV cache is about
  128 KB per token in BF16 for Llama-3-8B-like models.
- Throughput: an H100 with vLLM serves roughly 20–40 such requests per second for an 8B model with batching, so 2 GPUs
  at peak plus 1 for redundancy. Benchmark to confirm.
- Cost: 3 GPUs × $2.50 × 730 hours ≈ $5,500 a month.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Precision | BF16 | FP8 | FP8 if evals hold |
| Serving | Custom FastAPI | vLLM | vLLM behind a gateway |
| Rollout | Big bang | Canary with eval and latency guards | Canary |
| Scaling | CPU-based HPA | Concurrency or queue-based | Concurrency or queue-based |
| Monitoring | Infrastructure only | Plus quality and drift | Both |

**4. Follow-up questions with crisp answers:**
- *p99 time to first token spikes at peak.* Check queueing and batch settings, add replicas, or limit max tokens per batch.
- *A new model version is slightly better but slower.* Canary with SLO guards, and decide by value within the latency
  target.
- *How do you know the model still works next month?* Drift monitoring, sampled evaluations, and user feedback signals.
- *Who's on call?* The platform team for infrastructure, the model owner for quality, with a shared runbook.

**Debug this (common onsite question):** "After a routine deployment, the model API's p99 latency doubled but CPU and
GPU utilization fell."
1. The new image used a different base with a CPU-only build of a preprocessing library.
2. Requests spent time in single-threaded preprocessing, so GPUs waited.
3. Tracing showed the extra time before model inference, not in it.
4. Fix: pin the library and base image by digest, add a latency regression test in CI, and include per-stage tracing in
   dashboards.

The lesson: pin everything, and trace by stage.

**5. What separates senior from staff answers:** a senior engineer knows each layer well. A staff engineer connects them:
how a choice in one layer changes memory, latency, cost, reliability, and governance in the others, backed by numbers
and a plan for operating the result.

**Red flags:**
- Sizing without numbers.
- Pods without requests or probes.
- Models that can't be reproduced.
- Alerts on averages.
- Long-lived keys.
- No unit cost tracking.

---

## Failure modes
- Reviewing each layer in isolation and missing cross-layer effects.
- Relying on memory instead of first-principles calculations.
- Skipping the boring basics: pinned images, probes, private networks, and least privilege.
- Treating the practice test as trivia instead of practicing the calculations.
- Starting the capstone with known gaps unreviewed.

## Checklist
- [ ] You can size memory, compute, and training time from first principles
- [ ] You can describe a secure cloud layout and choose storage tiers
- [ ] You can write a hardened image and a complete Kubernetes Deployment
- [ ] You can outline a reproducible, gated MLOps pipeline
- [ ] You can define SLOs, drift checks, and security layers for a model service
- [ ] You can compute unit costs and name the main optimization levers
- [ ] You found and fixed all eight issues in the review sprint
- [ ] You scored 24 or more on the practice test
