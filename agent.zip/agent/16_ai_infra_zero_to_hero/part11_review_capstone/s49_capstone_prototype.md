# Section 49 — Capstone Project 2: Build the First Prototype

> Lectures 337–343
> **After this section you can:** stand up a cloud GPU environment with Terraform, containerize the Atlas gateway and
> model server, deploy them on Kubernetes, build the document ingestion pipeline into Postgres with pgvector, ship
> changes through CI/CD with a quality gate, and watch the system on a first Grafana dashboard.
>
> Builds on: [Section 48](s48_capstone_proposal.md) (the Atlas proposal), [Section 4](../part01_foundations/s04_containerization.md) and
> [Section 5](../part01_foundations/s05_kubernetes_fundamentals.md) (containers and Kubernetes),
> [Section 10](../part03_mlops_cicd_cost/s10_cicd_for_ai.md) (CI/CD for AI), and
> [Section 16](../part05_operating_production/s16_observability.md) (monitoring).

This section builds the first working version of Atlas, the retrieval-augmented support assistant proposed in Section
48. "First working" means a user can ask a question and get a streamed answer with sources, every change goes through
CI, and you can see latency and errors on a dashboard. Scaling, high availability, IAM hardening, and drift come in
Section 50. The corpus is this course itself: Atlas answers questions about AI infrastructure using the course's own
section files.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 337 | Setting up the base cloud and GPU environment | Terraform a VPC, a cluster with a GPU node pool that scales to zero, and budgets, then prove a pod can see the GPU |
| 338 | Containerizing models for deployment | A small non-root gateway image, the upstream model server image, and weights cached outside the image |
| 339 | Setting up orchestration with Kubernetes | Deployments with requests, probes, and GPU scheduling, wired together by Services and overlays per environment |
| 340 | Configuring storage and data pipelines | Chunk, embed, and upsert documents into pgvector with deletes and content hashes |
| 341 | Implementing CI/CD for model deployment | Test, evaluate retrieval, build, scan, sign, and deploy by digest through GitOps |
| 342 | Building initial monitoring dashboards | Instrument the gateway, scrape the model server and GPUs, and build a four-row dashboard |
| 343 | Lab: deploy the first working infra prototype | Run all of Atlas on kind with a CPU model and ask it questions about this course |

```mermaid
flowchart LR
  TF["(1) Terraform<br/>VPC, cluster, GPU pool"] --> IMG["(2) Images<br/>gateway, model server"]
  IMG --> K8S["(3) Kubernetes<br/>Deployments, Services"]
  DATA["(4) Ingestion<br/>docs to pgvector"] --> K8S
  CI["(5) CI/CD<br/>test, eval, sign, GitOps"] --> K8S
  K8S --> MON["(6) Dashboards<br/>latency, errors, GPU"]
  MON --> LAB["(7) Prototype on kind"]
```

**How to read it:** the infrastructure comes first (Terraform), then the images that run on it, then the Kubernetes
objects that run the images. Two pipelines feed the cluster: ingestion fills the vector store, and CI/CD delivers new
versions. Monitoring watches everything that runs. The lab puts it all together on a local cluster.

**Terms in this diagram.**
- **Terraform**: infrastructure as code. You describe cloud resources in files, and Terraform creates or changes them.
- **VPC**: virtual private cloud, your private network in the cloud.
- **GPU pool**: a group of GPU nodes in the cluster that can grow and shrink.
- **pgvector**: a Postgres extension that stores embeddings and finds the nearest ones.
- **GitOps**: deploying by committing the desired state to Git, which a controller such as Argo CD applies.
- **kind**: Kubernetes in Docker, a full cluster on a laptop.

---

## Lecture 337 — Setting up the base cloud and GPU environment

**Why it matters.** Everything else runs on this layer. If it's created by hand in the console, nobody can reproduce
it, review it, or tear it down cleanly, and a forgotten GPU node quietly spends the budget. Creating it with Terraform
makes the environment repeatable and lets you destroy it every evening with one command.

**In plain words.** It's like building a house from blueprints instead of improvising. Anyone can build the same house
again from the same plans, and you can see exactly what changed between versions.

**Architecture: the scale-test environment on AWS.**

```mermaid
flowchart TB
  subgraph VPC["VPC, 3 availability zones"]
    subgraph PRIV["Private subnets"]
      CPU["CPU node group<br/>2 x m6i.large"]
      GPU["GPU node group<br/>0 to 3 x g6.xlarge, tainted"]
    end
    PUB["Public subnets<br/>load balancer, NAT"]
  end
  EKS["EKS control plane"] --> CPU
  EKS --> GPU
  RDS[("Managed Postgres<br/>+ pgvector")] --- PRIV
  S3[("S3 bucket<br/>docs + model weights")] --- PRIV
  BUD["Budgets<br/>alerts at 50/80/100%"]
```

**How to read it:** the VPC spans three availability zones. Nodes live in private subnets with no public IP addresses,
and only the load balancer and NAT gateway sit in public subnets. The EKS control plane manages two node groups: a
small always-on CPU group for the gateway and system pods, and a GPU group that scales from zero to three L4 nodes and
is tainted so only GPU workloads land on it. Managed Postgres and an S3 bucket sit beside the cluster. Budgets watch
the whole account.

**Terms in this diagram.**
- **Availability zones**: separate data centers in one region. Spreading across them survives a data-center failure.
- **Private and public subnets**: network ranges without and with direct internet access.
- **m6i.large, g6.xlarge**: AWS instance types. m6i.large has 2 vCPUs and 8 GB of memory. g6.xlarge has one NVIDIA L4
  GPU (24 GB) and 4 vCPUs.
- **Tainted**: a Kubernetes taint keeps pods off a node unless they declare a matching toleration.
- **NAT**: network address translation gateway, which lets private nodes reach the internet for downloads.
- **EKS**: Elastic Kubernetes Service, AWS's managed Kubernetes.
- **S3**: Amazon's object storage.
- **Budgets**: AWS Budgets, which email or notify you when spend crosses a threshold.

**Core ideas.**
- **Request GPU quota first.** New accounts often have zero quota for GPU instances. Check it on day 1.
- **Scale GPUs to zero.** Set the GPU node group's minimum to 0, so nodes exist only while GPU pods need them.
- **Taint GPU nodes** so CPU pods don't fill them, and label them so GPU pods can select them.
- **Install the NVIDIA device plugin**, which tells Kubernetes how many GPUs each node has (`nvidia.com/gpu`).
- **Remote state with locking** (an S3 backend), so two `terraform apply` runs can't conflict.
- **Tag everything** with `project=atlas` and `env=scale-test`, so cost reports can group by them.

```hcl
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"
  name    = "atlas"
  cidr    = "10.40.0.0/16"
  azs             = ["us-east-1a", "us-east-1b", "us-east-1c"]
  private_subnets = ["10.40.0.0/19", "10.40.32.0/19", "10.40.64.0/19"]
  public_subnets  = ["10.40.96.0/22", "10.40.100.0/22", "10.40.104.0/22"]
  enable_nat_gateway = true
  single_nat_gateway = true # one NAT for a capstone; one per zone in production
}

module "eks" {
  source          = "terraform-aws-modules/eks/aws"
  version         = "~> 20.0"
  cluster_name    = "atlas"
  cluster_version = "1.31"
  vpc_id          = module.vpc.vpc_id
  subnet_ids      = module.vpc.private_subnets
  cluster_endpoint_public_access = true
  enable_cluster_creator_admin_permissions = true

  eks_managed_node_groups = {
    cpu = {
      instance_types = ["m6i.large"]
      min_size = 2, max_size = 3, desired_size = 2
    }
    gpu = {
      ami_type       = "AL2023_x86_64_NVIDIA"
      instance_types = ["g6.xlarge"]
      min_size = 0, max_size = 3, desired_size = 0
      labels = { "atlas/pool" = "gpu" }
      taints = { gpu = { key = "nvidia.com/gpu", value = "true", effect = "NO_SCHEDULE" } }
    }
  }
  tags = { project = "atlas", env = "scale-test" }
}

resource "aws_budgets_budget" "atlas" {
  name         = "atlas-monthly"
  budget_type  = "COST"
  limit_amount = "600"
  limit_unit   = "USD"
  time_unit    = "MONTHLY"
  dynamic "notification" {
    for_each = [50, 80, 100]
    content {
      comparison_operator        = "GREATER_THAN"
      threshold                  = notification.value
      threshold_type             = "PERCENTAGE"
      notification_type          = "ACTUAL"
      subscriber_email_addresses = ["you@example.com"]
    }
  }
}
```

In the code, the VPC module creates private and public subnets in three zones with a single NAT gateway to save cost.
The EKS module creates the cluster in the private subnets with two managed node groups. The GPU group uses the
NVIDIA-enabled Amazon Linux 2023 image, starts at zero nodes, and carries a label and a taint. The budget sends email
at 50%, 80%, and 100% of $600, the limit from the Section 48 proposal.

```bash
# GPU quota: "Running On-Demand G and VT instances" is counted in vCPUs (one g6.xlarge = 4)
aws service-quotas get-service-quota --service-code ec2 --quota-code L-DB2E81BA --query Quota.Value

terraform init && terraform apply
aws eks update-kubeconfig --name atlas
helm repo add nvdp https://nvidia.github.io/k8s-device-plugin && helm repo update
helm install nvdp nvdp/nvidia-device-plugin -n kube-system

kubectl run gpu-check --rm -it --restart=Never --image=nvidia/cuda:12.4.1-base-ubuntu22.04 \
  --overrides='{"spec":{"tolerations":[{"key":"nvidia.com/gpu","operator":"Exists","effect":"NoSchedule"}],
  "nodeSelector":{"atlas/pool":"gpu"},"containers":[{"name":"c","image":"nvidia/cuda:12.4.1-base-ubuntu22.04",
  "command":["nvidia-smi"],"resources":{"limits":{"nvidia.com/gpu":1}}}]}}'
```

In the commands, the quota check comes first because a quota of 0 blocks everything after it. After the cluster is up,
the NVIDIA device plugin advertises the GPUs, and the check pod requests one GPU with the right toleration and node
selector. The cluster autoscaler or Karpenter must be installed for the zero-node group to grow (Section 11). When it
does, the pod prints the `nvidia-smi` table showing an L4.

**Example: the zero-quota afternoon.** A student's `terraform apply` succeeded, but the GPU check pod stayed Pending for
an hour. The node group events showed `VcpuLimitExceeded`: the account's G-instance quota was 0. They'd skipped the
quota check. The request was approved two days later, and the student added the quota query to the setup script so
it fails early with a clear message.

**Senior / FAANG best practice.** Treat environments as cattle: created from code, identical apart from their variables,
and destroyed when not needed. Use separate accounts or projects for dev, test, and production, remote state with
locking, required tags enforced by policy, and a nightly job that scales GPU groups to zero. Large companies use
landing zones (pre-built account templates with networking, logging, and guardrails), so a new project starts
compliant.

---

## Lecture 338 — Containerizing models for deployment

**Why it matters.** The image is what actually runs in production. A bloated image slows every scale-up, an image
running as root widens every security hole, and a model baked in without a version means you can't tell which model
answered a question. Getting the images right makes everything later faster and safer.

**In plain words.** It's like packing a lunchbox for a trip. Pack only what you need, label it, and keep the big items,
such as the cooler of drinks, in the car instead of inside the lunchbox.

**Architecture: the two Atlas images.**

```mermaid
flowchart LR
  subgraph GWI["Gateway image, about 400 MB"]
    BASE["python:3.11-slim<br/>non-root user"] --> DEPS["FastAPI, psycopg,<br/>fastembed, httpx"]
    DEPS --> CODE["app.py"]
  end
  subgraph LLMI["Model server image"]
    UP["Upstream image<br/>vLLM or llama.cpp"]
  end
  W[("Weights<br/>HF Hub or S3 cache")] -->|"download at start<br/>to a volume"| LLMI
  REG["Registry<br/>GHCR, by digest"] --> GWI
  REG --> LLMI
```

**How to read it:** the gateway image is built in this project from a slim Python base, with dependencies installed
first and the application code last, and runs as a non-root user. The model server uses an upstream image as-is,
pinned to a tested version. The model weights are not inside either image. The model server downloads them at
startup into a volume, from the Hugging Face Hub or an S3 cache. Both images are pulled from the registry by digest.

**Terms in this diagram.**
- **python:3.11-slim**: an official small Debian-based Python image.
- **Non-root user**: the container process runs as an unprivileged user, limiting damage if it's compromised.
- **psycopg**: the Postgres driver for Python.
- **fastembed**: a small library that computes text embeddings with ONNX Runtime, without PyTorch.
- **httpx**: an HTTP client for Python with streaming and async support.
- **Upstream image**: the image published by the project itself, such as `vllm/vllm-openai`.
- **HF Hub**: the Hugging Face Hub, where open model weights are hosted.
- **GHCR**: GitHub Container Registry.
- **Digest**: the content hash of an image (`sha256:...`). Unlike a tag, it can't be moved to a different image.

**Core ideas.**
- **Keep the gateway small.** Computing embeddings with fastembed (ONNX) instead of sentence-transformers (PyTorch)
  makes the image several times smaller and faster to start.
- **Order layers for caching.** Copy `requirements.txt` and install first, then copy code, so code changes don't
  reinstall everything.
- **Don't bake large weights into images.** A 3 GB model in the image slows every pull and ties model versions to code
  versions. Download to a volume at startup, or use a node-local cache, and record the model revision.
- **Pin model revisions.** Use a specific Hugging Face revision or your own S3 copy, so "the model" can't change under
  you.
- **One process per container**, with health endpoints the orchestrator can probe.

```dockerfile
# services/gateway/Dockerfile
FROM python:3.11-slim AS base
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 HF_HOME=/cache
RUN useradd --uid 10001 --create-home atlas && mkdir /cache && chown atlas /cache
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app.py .
USER 10001
RUN python -c "from fastembed import TextEmbedding; TextEmbedding('BAAI/bge-small-en-v1.5')"
EXPOSE 8080
CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8080", "--workers", "2"]
```

```text
# services/gateway/requirements.txt
fastapi==0.115.*
uvicorn[standard]==0.32.*
httpx==0.27.*
psycopg[binary]==3.2.*
fastembed==0.4.*
prometheus-client==0.21.*
```

In the code, the image creates a user with a fixed numeric ID, installs pinned dependencies before copying the code,
and switches to the non-root user. It downloads the small embedding model (about 130 MB) during the build, because a
model that size is fine to bake in and it removes a network call at startup. The large LLM weights are handled by the
model server, not this image.

**Example: the 9 GB gateway.** A first gateway image used `pip install sentence-transformers` and the full Python base
image. It came to 9 GB, mostly PyTorch with CUDA libraries the gateway never used. Pulling it on a new node took over
three minutes, which made autoscaling useless. Switching to `python:3.11-slim` and fastembed brought it to about
400 MB and the pull to under 15 seconds.

**Senior / FAANG best practice.** Build images in CI only, from pinned bases, scanned and signed, and deploy by digest.
Keep model artifacts in a registry or object store with versions, separate from code images, and record both the image
digest and the model revision in every deployment and in every response's logs. Large serving platforms preload
popular weights onto nodes or use streaming loaders, so a new replica doesn't wait for a multi-gigabyte download.

---

## Lecture 339 — Setting up orchestration with Kubernetes

**Why it matters.** Kubernetes keeps Atlas running: it restarts crashed containers, routes traffic only to ready pods,
places the model server on a GPU, and lets you roll out new versions gradually. The manifests you write now are the
ones you'll scale and harden in Section 50.

**In plain words.** It's like a theater stage manager. You hand over the script (the manifests), and the manager makes
sure every actor is on stage, replaces anyone who falls ill, and only opens the curtain when everyone is ready.

**Architecture: Atlas objects in the cluster.**

```mermaid
flowchart LR
  ING["Ingress"] --> SGW["Service: gateway"]
  SGW --> GW1["gateway pod"]
  SGW --> GW2["gateway pod"]
  GW1 --> SLLM["Service: llm"]
  GW2 --> SLLM
  SLLM --> LLM["llm pod<br/>GPU, toleration,<br/>startupProbe"]
  GW1 --> SPG["Service: postgres"]
  SPG --> PG["postgres pod + PVC<br/>dev only"]
  CM["ConfigMap + Secret"] -.env.-> GW1
  CM -.env.-> GW2
```

**How to read it:** traffic enters through the ingress to the gateway Service, which load-balances across two gateway
pods. Each gateway pod calls the `llm` Service, which routes to the model server pod running on a GPU node, and the
`postgres` Service for retrieval. In dev, Postgres runs in the cluster with a persistent volume; in scale-test it's a
managed database outside the cluster. Configuration and secrets reach the gateway pods as environment variables.

**Terms in this diagram.**
- **Ingress**: the object that routes outside HTTP traffic to Services.
- **Service**: a stable name and virtual IP address that load-balances across matching pods.
- **Toleration**: lets a pod run on a tainted node, here the GPU nodes.
- **startupProbe**: a check that gives a slow-starting container time to load before other probes begin.
- **PVC**: persistent volume claim, a request for storage that survives pod restarts.
- **ConfigMap + Secret**: objects holding configuration and sensitive values.

**Core ideas.**
- **Requests and limits on everything.** The scheduler places pods using requests. GPU pods request
  `nvidia.com/gpu: 1` as a limit.
- **Three probes for the model server.** A startup probe allows minutes for loading weights. A readiness probe takes
  the pod out of the Service when it can't serve. A liveness probe restarts it only if it's truly stuck.
- **Graceful shutdown.** A `preStop` sleep and a `terminationGracePeriodSeconds` longer than the longest request let
  streams finish during rollouts.
- **One base, overlays per environment.** Kustomize patches the model server image and arguments per environment:
  llama.cpp on CPU in dev and vLLM on GPU in scale-test.

```yaml
# deploy/base/llm.yaml (scale-test overlay values shown)
apiVersion: apps/v1
kind: Deployment
metadata: {name: llm, labels: {app: llm}}
spec:
  replicas: 1
  selector: {matchLabels: {app: llm}}
  template:
    metadata: {labels: {app: llm}}
    spec:
      terminationGracePeriodSeconds: 120
      nodeSelector: {atlas/pool: gpu}
      tolerations: [{key: nvidia.com/gpu, operator: Exists, effect: NoSchedule}]
      containers:
        - name: vllm
          image: vllm/vllm-openai:v0.8.5
          args: ["--model", "Qwen/Qwen2.5-1.5B-Instruct", "--served-model-name", "atlas",
                 "--max-model-len", "8192", "--gpu-memory-utilization", "0.90", "--port", "8000"]
          env: [{name: HF_HOME, value: /models}]
          ports: [{containerPort: 8000}]
          resources:
            requests: {cpu: "2", memory: 12Gi}
            limits: {memory: 14Gi, nvidia.com/gpu: 1}
          startupProbe: {httpGet: {path: /health, port: 8000}, periodSeconds: 10, failureThreshold: 60}
          readinessProbe: {httpGet: {path: /health, port: 8000}, periodSeconds: 5}
          livenessProbe: {httpGet: {path: /health, port: 8000}, periodSeconds: 20, failureThreshold: 3}
          lifecycle: {preStop: {exec: {command: ["sleep", "15"]}}}
          volumeMounts: [{name: models, mountPath: /models}, {name: shm, mountPath: /dev/shm}]
      volumes:
        - {name: models, emptyDir: {sizeLimit: 20Gi}}
        - {name: shm, emptyDir: {medium: Memory, sizeLimit: 2Gi}}
---
apiVersion: v1
kind: Service
metadata: {name: llm}
spec: {selector: {app: llm}, ports: [{port: 8000, targetPort: 8000}]}
```

In the code, the model server selects GPU nodes and tolerates their taint, requests one GPU, and gets up to 10 minutes
(60 checks × 10 s) to start before liveness checks begin. The weights download into an `emptyDir` volume, which a
node-local cache or a PVC replaces in Section 50, and a memory-backed `/dev/shm` gives the server shared memory. The
`preStop` sleep gives the Service time to stop sending new requests before the container shuts down. The
`--served-model-name atlas` lets the gateway use the same model name whatever model runs underneath.

```yaml
# deploy/overlays/dev/kustomization.yaml
resources: [../../base, postgres.yaml]
patches:
  - target: {kind: Deployment, name: llm}
    patch: |-
      - op: replace
        path: /spec/template/spec
        value:
          containers:
            - name: llamacpp
              image: ghcr.io/ggml-org/llama.cpp:server
              args: ["-hf", "Qwen/Qwen2.5-0.5B-Instruct-GGUF:Q4_K_M", "--host", "0.0.0.0", "--port", "8000",
                     "-c", "4096", "--metrics"]
              env: [{name: LLAMA_CACHE, value: /models}]
              ports: [{containerPort: 8000}]
              resources: {requests: {cpu: "2", memory: 2Gi}, limits: {memory: 3Gi}}
              startupProbe: {httpGet: {path: /health, port: 8000}, periodSeconds: 5, failureThreshold: 120}
              readinessProbe: {httpGet: {path: /health, port: 8000}, periodSeconds: 5}
              volumeMounts: [{name: models, mountPath: /models}]
          volumes: [{name: models, emptyDir: {}}]
```

In the dev overlay, the whole pod spec of the model server is replaced with llama.cpp running a 0.5B model on CPU, with
no GPU, node selector, or toleration. The Service name and port stay the same, so the gateway doesn't change. The
`--metrics` flag turns on llama.cpp's Prometheus endpoint.

**Example: the rollout that cut answers in half.** During a gateway rollout, users saw answers stop mid-sentence. The
old pods were killed after the default 30-second grace period while streaming answers that took up to 40 seconds. A
`preStop` sleep of 15 seconds plus a grace period of 120 seconds let in-flight streams finish, and the rollout became
invisible to users.

**Senior / FAANG best practice.** Every workload has requests, probes matched to its startup time, a disruption budget,
graceful shutdown, and resource-aware scheduling. Keep environment differences in overlays, not in copied manifests,
and render and validate manifests in CI (`kustomize build | kubeconform`) so a typo never reaches the cluster.

---

## Lecture 340 — Configuring storage and data pipelines

**Why it matters.** A RAG system is only as good as its index. If documents are chunked badly, never refreshed, or
deleted articles linger, the model answers confidently from stale or wrong text. The ingestion pipeline is where most
RAG quality problems start and where most can be fixed.

**In plain words.** It's like a library's cataloging team. New books are catalogued, changed editions replace old
entries, and withdrawn books are removed from the catalog, or readers keep looking for books that aren't there.

**Architecture: the Atlas ingestion pipeline.**

```mermaid
flowchart LR
  SRC[("Docs source<br/>bucket or Git")] --> LOAD["Load + clean<br/>markdown to text"]
  LOAD --> CHUNK["Chunk<br/>about 800 chars, overlap 100"]
  CHUNK --> HASH{"Hash changed?"}
  HASH -->|yes| EMB["Embed<br/>bge-small, 384 dims"]
  HASH -->|no| SKIP["Skip"]
  EMB --> UPS["Upsert<br/>article_id + chunk_no"]
  UPS --> PG[("Postgres + pgvector<br/>HNSW index")]
  LOAD --> DEL["Delete chunks of<br/>removed articles"]
  DEL --> PG
```

**How to read it:** the pipeline loads documents from the source and cleans them, then splits each into overlapping
chunks. For each chunk, a content hash decides whether anything changed: unchanged chunks are skipped, and changed
ones are embedded and upserted with a key of article ID plus chunk number. Separately, any article missing from the
source has its chunks deleted. The vector index in Postgres is an HNSW index for fast nearest-neighbor search.

**Terms in this diagram.**
- **Chunk**: a piece of a document small enough to embed and to fit several into the LLM's prompt.
- **Overlap**: the characters repeated between neighboring chunks, so a sentence split at a boundary isn't lost.
- **Hash**: a fingerprint of the text (SHA-256). If the hash is the same, the text is the same.
- **bge-small**: BAAI's small English embedding model, which outputs 384-number vectors.
- **Upsert**: insert a row, or update it if the key already exists.
- **HNSW**: hierarchical navigable small world, a graph index for approximate nearest-neighbor search.

**Core ideas.**
- **Chunk on structure.** Split on headings and paragraphs, then cap the size. Keep the title with each chunk so it
  makes sense alone.
- **Idempotent runs.** Running ingestion twice produces the same index. Keys and hashes make that true.
- **Handle deletes.** Remove chunks for removed articles, and chunks beyond the new last chunk of a shortened article.
- **Record lineage.** Store the source URL and update time for each chunk, so answers can cite sources and you can
  trace a bad answer to its text.
- **Separate the schedule from the code.** The same `ingest.py` runs as a Kubernetes Job by hand, as a CronJob nightly,
  and in CI against a test database.

```sql
-- services/ingest/schema.sql
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE IF NOT EXISTS chunks (
  article_id   text        NOT NULL,
  chunk_no     int         NOT NULL,
  title        text        NOT NULL,
  url          text        NOT NULL,
  body         text        NOT NULL,
  content_hash text        NOT NULL,
  embedding    vector(384) NOT NULL,
  updated_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (article_id, chunk_no)
);
CREATE INDEX IF NOT EXISTS chunks_hnsw ON chunks USING hnsw (embedding vector_cosine_ops);
```

```python
# services/ingest/ingest.py
import hashlib
import os
import re
import sys
from pathlib import Path

import psycopg
from fastembed import TextEmbedding

MAX, OVERLAP = 800, 100


def chunks(text):
    paras, out, cur = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()], [], ""
    for p in paras:
        if cur and len(cur) + len(p) > MAX:
            out.append(cur)
            cur = cur[-OVERLAP:]
        cur = f"{cur}\n\n{p}" if cur else p
        while len(cur) > MAX:
            out.append(cur[:MAX])
            cur = cur[MAX - OVERLAP:]
    return out + ([cur] if cur else [])


def main(root):
    db = psycopg.connect(os.environ["DATABASE_URL"], autocommit=True)
    db.execute(Path(__file__).with_name("schema.sql").read_text())
    model = TextEmbedding("BAAI/bge-small-en-v1.5")
    seen, written = set(), 0
    for f in sorted(Path(root).rglob("s[0-9][0-9]_*.md")):
        text = f.read_text()
        article_id, title = f.stem, text.splitlines()[0].lstrip("# ").strip()
        seen.add(article_id)
        parts = chunks(text)
        old = dict(db.execute("SELECT chunk_no, content_hash FROM chunks WHERE article_id = %s",
                              (article_id,)).fetchall())
        todo = [(i, c, hashlib.sha256(c.encode()).hexdigest()) for i, c in enumerate(parts)]
        todo = [t for t in todo if old.get(t[0]) != t[2]]
        for (i, c, h), vec in zip(todo, model.embed([f"{title}\n{c}" for _, c, _ in todo])):
            db.execute(
                """INSERT INTO chunks (article_id, chunk_no, title, url, body, content_hash, embedding)
                   VALUES (%s, %s, %s, %s, %s, %s, %s::vector)
                   ON CONFLICT (article_id, chunk_no) DO UPDATE SET body = EXCLUDED.body,
                     content_hash = EXCLUDED.content_hash, embedding = EXCLUDED.embedding, updated_at = now()""",
                (article_id, i, title, str(f.relative_to(root)), c, h, str(vec.tolist())))
            written += 1
        db.execute("DELETE FROM chunks WHERE article_id = %s AND chunk_no >= %s", (article_id, len(parts)))
    removed = db.execute("DELETE FROM chunks WHERE NOT (article_id = ANY(%s))", (list(seen),)).rowcount
    total = db.execute("SELECT count(*) FROM chunks").fetchone()[0]
    print(f"articles={len(seen)} chunks_written={written} chunks_removed={removed} total_chunks={total}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "/docs")
```

In the code, `chunks` packs paragraphs into pieces of up to 800 characters, carrying the last 100 characters into the
next piece, and hard-splits any paragraph longer than the limit. For each section file, the job compares the hash of
each chunk with what's stored and embeds only the changed ones, with the title prepended so each chunk carries its
context. It upserts by article and chunk number, deletes chunks past the new end of each article, and deletes articles
that no longer exist. The final line reports what changed, which makes runs easy to check and to alert on.

```yaml
# deploy/base/ingest-cronjob.yaml
apiVersion: batch/v1
kind: CronJob
metadata: {name: ingest}
spec:
  schedule: "0 2 * * *"
  concurrencyPolicy: Forbid
  jobTemplate:
    spec:
      backoffLimit: 2
      template:
        spec:
          restartPolicy: Never
          containers:
            - name: ingest
              image: ghcr.io/your-user/atlas-ingest:latest   # CI replaces this with a digest
              envFrom: [{secretRef: {name: atlas-db}}]
              resources: {requests: {cpu: "1", memory: 1Gi}, limits: {memory: 2Gi}}
```

The CronJob runs ingestion nightly at 02:00, never two at once, and retries twice on failure. The database URL comes
from a Secret. In the prototype the documents are copied into the ingest image. In Section 50 the job syncs them from
the S3 bucket first.

**Example: the answer from a deleted page.** A support assistant kept telling users to use an API that had been removed
three months earlier. The help article was gone, but its chunks were still in the vector store because ingestion only
inserted and updated. Adding the delete step and a nightly metric, "chunks whose article no longer exists", fixed it,
and the metric caught a broken sync job later that year.

**Senior / FAANG best practice.** Treat the index as a derived dataset with lineage: every chunk traces to a source
version, every run is idempotent and reports counts, and a reconciliation job compares the index with the source. Keep
a versioned evaluation set and rerun retrieval metrics after every ingestion or chunking change. Large search teams
version indexes and switch traffic between them atomically, so a bad rebuild can be rolled back.

---

## Lecture 341 — Implementing CI/CD for model deployment

**Why it matters.** Without CI/CD, every deployment is a manual, slightly different ritual, and nobody knows exactly what
is running. A pipeline makes each change tested, evaluated, scanned, and traceable, and makes rollback a one-line Git
revert.

**In plain words.** It's like a factory's quality line. Every product passes the same inspections in the same order,
and only products with a passing stamp leave the building.

**Architecture: the Atlas delivery pipeline.**

```mermaid
flowchart LR
  PR["Pull request"] --> TEST["Unit tests<br/>+ manifest checks"]
  TEST --> EVAL["Retrieval eval<br/>recall@5 >= 0.85"]
  EVAL --> MERGE["Merge to main"]
  MERGE --> BUILD["Build image"]
  BUILD --> SCAN["Trivy scan"]
  SCAN --> SIGN["cosign sign"]
  SIGN --> BUMP["Commit new digest<br/>to overlay"]
  BUMP --> ARGO["Argo CD sync"]
  ARGO --> K8S["Cluster"]
```

**How to read it:** a pull request runs unit tests, manifest checks, and a retrieval evaluation against the golden set,
and must pass all three to merge. On merge to main, CI builds the image, scans it for known vulnerabilities, signs it,
and commits the new image digest to the deployment overlay in Git. Argo CD sees the change and syncs the cluster.
Rollback is reverting that commit.

**Terms in this diagram.**
- **Recall@5**: the share of golden-set questions where a correct article appears in the top 5 retrieved chunks.
- **Trivy**: an open-source scanner that finds known vulnerabilities (CVEs) in images.
- **cosign**: a tool that signs container images and verifies the signatures.
- **Overlay**: the per-environment Kustomize folder whose image digest is updated.
- **Argo CD**: a GitOps controller that keeps the cluster matching the Git repository.

**Core ideas.**
- **Gate on quality, not just tests.** For an AI system, a change can pass every unit test and still make retrieval
  worse. Run the golden set in CI with a real pgvector service container.
- **Build once, deploy the same digest** to every environment.
- **Keyless signing** with the CI job's identity (OIDC), so there are no signing keys to leak.
- **GitOps for deployment.** CI never runs `kubectl apply` against the cluster. Argo CD pulls from Git, which gives an
  audit log and easy rollback.

```yaml
# .github/workflows/ci.yml
name: ci
on:
  pull_request:
  push: {branches: [main]}
permissions: {contents: write, packages: write, id-token: write}
env:
  IMAGE: ghcr.io/your-user/atlas-gateway   # must be lowercase
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: {python-version: "3.11"}
      - run: pip install -r services/gateway/requirements.txt pytest
      - run: pytest services/gateway/tests -q
      - run: |
          curl -sL https://github.com/yannh/kubeconform/releases/latest/download/kubeconform-linux-amd64.tar.gz | tar xz
          for o in deploy/overlays/*/; do kustomize build "$o" | ./kubeconform -strict -ignore-missing-schemas; done
  eval:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: pgvector/pgvector:pg16
        env: {POSTGRES_PASSWORD: ci}
        ports: ["5432:5432"]
        options: --health-cmd pg_isready --health-interval 5s --health-retries 10
    env: {DATABASE_URL: "postgresql://postgres:ci@localhost:5432/postgres"}
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: {python-version: "3.11"}
      - run: pip install psycopg[binary] fastembed
      - run: python services/ingest/ingest.py docs-src
      - run: python eval/eval_retrieval.py --golden eval/golden_set.jsonl --min-recall 0.85
  release:
    needs: [test, eval]
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with: {registry: ghcr.io, username: "${{ github.actor }}", password: "${{ secrets.GITHUB_TOKEN }}"}
      - id: build
        uses: docker/build-push-action@v6
        with: {context: services/gateway, push: true, tags: "${{ env.IMAGE }}:${{ github.sha }}"}
      - uses: aquasecurity/trivy-action@0.28.0
        with: {image-ref: "${{ env.IMAGE }}@${{ steps.build.outputs.digest }}", severity: "CRITICAL,HIGH",
               ignore-unfixed: true, exit-code: "1"}
      - uses: sigstore/cosign-installer@v3
      - run: cosign sign --yes "$IMAGE@${{ steps.build.outputs.digest }}"
      - run: |
          cd deploy/overlays/scale-test
          kustomize edit set image "gateway=$IMAGE@${{ steps.build.outputs.digest }}"
          git config user.name ci && git config user.email ci@users.noreply.github.com
          git commit -am "deploy gateway ${{ github.sha }}" && git push
```

In the code, the `test` job runs unit tests and validates every rendered overlay with kubeconform. The `eval` job starts
a pgvector service container, ingests the course documents, and fails if recall@5 on the golden set drops below 0.85.
Only on main, the `release` job builds and pushes the image, fails on fixable critical or high vulnerabilities, signs
the image by digest with the workflow's OIDC identity, and commits the new digest to the scale-test overlay. Pin
third-party actions to commit SHAs in a real project.

```python
# eval/eval_retrieval.py
import argparse
import json
import os
import sys

import psycopg
from fastembed import TextEmbedding

p = argparse.ArgumentParser()
p.add_argument("--golden", required=True)
p.add_argument("--min-recall", type=float, default=0.85)
p.add_argument("-k", type=int, default=5)
a = p.parse_args()
model = TextEmbedding("BAAI/bge-small-en-v1.5")
rows = [json.loads(line) for line in open(a.golden)]
db = psycopg.connect(os.environ["DATABASE_URL"])
hits = 0
for row, vec in zip(rows, model.embed([r["question"] for r in rows])):
    got = [r[0] for r in db.execute("SELECT article_id FROM chunks ORDER BY embedding <=> %s::vector LIMIT %s",
                                    (str(vec.tolist()), a.k))]
    hits += row["article_id"] in got
recall = hits / len(rows)
print(f"recall@{a.k} = {recall:.3f} on {len(rows)} questions (min {a.min_recall})")
sys.exit(0 if recall >= a.min_recall else 1)
```

The evaluation embeds each golden question, retrieves the top 5 chunks, and counts a hit if the expected article is
among them. Each golden-set line looks like
`{"question": "How does Kueue let one team borrow another team's idle GPUs?", "article_id": "s40_multi_tenant_ai"}`.

**Example: the chunking change that passed every test.** A student raised the chunk size from 800 to 3,000 characters
to "give the model more context". Unit tests passed. The CI eval failed: recall@5 dropped from 0.89 to 0.71, because
large chunks mixed several topics and their embeddings matched nothing well. Without the gate, the change would have
shipped and quietly made answers worse.

**Senior / FAANG best practice.** For ML systems, CI includes quality gates on versioned evaluation sets, alongside
tests, scans, and signatures. Deployments are declarative and pulled from Git, promotion between environments uses
the same digest, and every release is traceable from a commit to the image, the model revision, and the evaluation
result. Large companies add canary analysis in production on top (Section 50).

---

## Lecture 342 — Building initial monitoring dashboards

**Why it matters.** The first time Atlas is slow or wrong, you need to know whether the problem is the gateway,
retrieval, the model server, or the GPU, within minutes. A dashboard built on the Section 48 SLOs answers that, and
the same metrics feed the alerts in Section 51.

**In plain words.** It's like a car dashboard. Speed, fuel, engine temperature, and warning lights tell you at a
glance whether to keep driving or pull over, without opening the hood.

**Architecture: Atlas metrics flow.**

```mermaid
flowchart LR
  GW["gateway /metrics<br/>requests, TTFT, retrieval"] --> PROM["Prometheus"]
  LLM["llm /metrics<br/>queue, tokens, KV cache"] --> PROM
  DCGM["DCGM exporter<br/>GPU util, memory"] --> PROM
  PG["postgres exporter<br/>connections"] --> PROM
  PROM --> GRAF["Grafana dashboard<br/>4 rows"]
  LOGS["Pod logs"] --> LOKI["Loki"] --> GRAF
```

**How to read it:** the gateway exposes its own metrics, the model server exposes queue and token metrics, the DCGM
exporter exposes GPU metrics, and a Postgres exporter exposes database metrics. Prometheus scrapes them all. Grafana
shows one dashboard with four rows, plus logs from Loki for the same time range.

**Terms in this diagram.**
- **/metrics**: the HTTP endpoint where a service publishes metrics in Prometheus format.
- **TTFT**: time to first token, how long a user waits before the answer starts streaming.
- **KV cache**: GPU memory holding attention keys and values for running requests. When it's full, new requests wait.
- **DCGM exporter**: NVIDIA's Data Center GPU Manager exporter, which publishes GPU metrics for Prometheus.
- **Postgres exporter**: publishes database metrics such as connections and query rates.
- **Loki**: a log store that Grafana queries alongside metrics.

**Core ideas.**
- **Start from the SLOs.** The first row shows exactly the Section 48 targets: request rate, error rate, TTFT p95, and
  full-answer p95.
- **Then one row per layer:** gateway and retrieval, model server, and GPU and database. When the top row is red, the
  lower rows show where.
- **Histograms for latency**, with buckets around your targets (1.5 s and 6 s), so percentiles are accurate there.
- **Label carefully.** Status code and route are fine labels. User IDs or questions are not: they create unlimited
  time series.

```python
# in services/gateway/app.py
from prometheus_client import Counter, Histogram, make_asgi_app

REQS = Counter("atlas_requests_total", "Requests by status code", ["code"])
TTFT = Histogram("atlas_ttft_seconds", "Time to first token", buckets=(0.1, 0.25, 0.5, 1, 1.5, 2, 3, 5, 10))
TOTAL = Histogram("atlas_answer_seconds", "Full answer time", buckets=(0.5, 1, 2, 4, 6, 8, 12, 20, 40))
RETR = Histogram("atlas_retrieval_seconds", "Retrieval time", buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5))
app.mount("/metrics", make_asgi_app())
```

| Row | Panel | PromQL |
|---|---|---|
| SLOs | Requests/s | `sum(rate(atlas_requests_total[5m]))` |
| SLOs | Error rate | `sum(rate(atlas_requests_total{code=~"5.."}[5m])) / sum(rate(atlas_requests_total[5m]))` |
| SLOs | TTFT p95 | `histogram_quantile(0.95, sum by (le) (rate(atlas_ttft_seconds_bucket[5m])))` |
| SLOs | Full answer p95 | `histogram_quantile(0.95, sum by (le) (rate(atlas_answer_seconds_bucket[5m])))` |
| Gateway | Retrieval p95 | `histogram_quantile(0.95, sum by (le) (rate(atlas_retrieval_seconds_bucket[5m])))` |
| Model server | Running and waiting requests | `vllm:num_requests_running`, `vllm:num_requests_waiting` |
| Model server | Output tokens/s | `sum(rate(vllm:generation_tokens_total[5m]))` |
| Model server | KV cache use | `vllm:gpu_cache_usage_perc` (renamed `vllm:kv_cache_usage_perc` in newer vLLM) |
| GPU, DB | GPU utilization and memory | `DCGM_FI_DEV_GPU_UTIL`, `DCGM_FI_DEV_FB_USED` |
| GPU, DB | DB connections | `sum(pg_stat_activity_count)` |

In the code, the gateway defines a counter by status code and three histograms with buckets placed around the SLO
targets, and serves them on `/metrics`. The table lists the panels row by row with the PromQL behind each one. For
llama.cpp in dev, the model-server panels use its metrics instead, such as `llamacpp:tokens_predicted_total` and
`llamacpp:requests_processing`.

```yaml
# deploy/base/servicemonitor.yaml (needs the Prometheus Operator from kube-prometheus-stack)
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata: {name: atlas}
spec:
  selector: {matchExpressions: [{key: app, operator: In, values: [gateway, llm]}]}
  endpoints: [{port: http, path: /metrics, interval: 15s}]
```

The ServiceMonitor tells Prometheus to scrape every Service labeled `app=gateway` or `app=llm` on the port named
`http` every 15 seconds, so the Services must name their ports `http`.

**Example: the slow answers that weren't the GPU.** Full-answer p95 jumped from 4 s to 11 s. The model-server row was
calm: few waiting requests, steady tokens per second. The gateway row showed retrieval p95 at 6 s. The database row
showed connections at the maximum: each request opened a new Postgres connection and never pooled them. Adding a
connection pool fixed it in an hour, without touching the GPUs the team had first suspected.

**Senior / FAANG best practice.** Build dashboards top-down from SLOs to layers, so on-call engineers start from user
impact and drill down. Keep the dashboard as code in the repository (JSON in a ConfigMap picked up by Grafana's
sidecar), link each panel to its runbook, and review dashboards after each incident to add what was missing.

---

## Lecture 343 — Lab: deploy the first working infra prototype

**Goal:** run the whole Atlas prototype on a local kind cluster, with a CPU model, a real vector index of this
course's 52 section files, a streaming `/ask` endpoint with sources, and a Grafana dashboard showing its metrics.

**What you're building:** an `atlas/` folder with the gateway (`app.py`), the ingest job from Lecture 340, the dev
overlay from Lecture 339, and a kind cluster running Postgres with pgvector, llama.cpp with Qwen2.5-0.5B, two gateway
pods, and kube-prometheus-stack.

```mermaid
flowchart LR
  CURL["curl /ask"] --> PF["port-forward<br/>localhost:8080"]
  PF --> GW["gateway x2"]
  GW --> PG[("postgres<br/>pgvector")]
  GW --> LLM["llama.cpp<br/>Qwen2.5-0.5B, CPU"]
  JOB["ingest Job<br/>52 course files"] --> PG
  PROM["Prometheus + Grafana"] -.scrape.-> GW
  PROM -.scrape.-> LLM
```

**How to read the diagram:** you send a question with curl through a port-forward to one of two gateway pods. The
gateway retrieves chunks from Postgres and streams an answer from llama.cpp running a small model on CPU. The ingest
Job fills Postgres from the course's section files before any questions. Prometheus scrapes the gateway and model
server, and Grafana shows the dashboard. The terms, briefly: **port-forward** connects a local port to a Service in the
cluster, **localhost** is your own machine, and **Qwen2.5-0.5B** is a small open instruction-tuned model that runs on a laptop CPU.

**Prerequisites:** Docker with at least 8 GB of memory, `kind`, `kubectl`, `helm`, and about 6 GB of free disk. The
model server downloads about 400 MB of weights from Hugging Face on first start.

### Step 1 — The gateway

Create `atlas/services/gateway/app.py`:

```python
import json
import os
import time
from functools import lru_cache

import httpx
import psycopg
from fastapi import FastAPI, Header, HTTPException
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import StreamingResponse
from fastembed import TextEmbedding
from prometheus_client import Counter, Histogram, make_asgi_app
from pydantic import BaseModel

DB_URL = os.environ.get("DATABASE_URL", "")
LLM_URL = os.environ.get("LLM_URL", "http://llm:8000/v1")
API_KEYS = {k for k in os.environ.get("API_KEYS", "").split(",") if k}
TOP_K = int(os.environ.get("TOP_K", "5"))
SYSTEM = ("You answer questions about AI infrastructure using only the numbered articles provided. "
          "Cite articles like [1]. If the articles don't contain the answer, say you don't know.")

app = FastAPI()
app.mount("/metrics", make_asgi_app())
REQS = Counter("atlas_requests_total", "Requests by status code", ["code"])
TTFT = Histogram("atlas_ttft_seconds", "Time to first token", buckets=(0.1, 0.25, 0.5, 1, 1.5, 2, 3, 5, 10))
TOTAL = Histogram("atlas_answer_seconds", "Full answer time", buckets=(0.5, 1, 2, 4, 6, 8, 12, 20, 40))
RETR = Histogram("atlas_retrieval_seconds", "Retrieval time", buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5))


class Ask(BaseModel):
    question: str


@lru_cache
def embedder():
    return TextEmbedding("BAAI/bge-small-en-v1.5")


def retrieve(question):
    t = time.perf_counter()
    vec = next(iter(embedder().embed([question]))).tolist()
    with psycopg.connect(DB_URL) as db:
        rows = db.execute("SELECT title, url, body FROM chunks ORDER BY embedding <=> %s::vector LIMIT %s",
                          (str(vec), TOP_K)).fetchall()
    RETR.observe(time.perf_counter() - t)
    return rows


@app.get("/healthz")
def healthz():
    return {"ok": True}


@app.get("/readyz")
def readyz():
    try:
        with psycopg.connect(DB_URL, connect_timeout=2) as db:
            db.execute("SELECT 1")
    except psycopg.Error:
        raise HTTPException(503, "database unavailable")
    return {"ok": True}


@app.post("/ask")
async def ask(req: Ask, x_api_key: str = Header(default="")):
    if x_api_key not in API_KEYS:
        REQS.labels("401").inc()
        raise HTTPException(401, "invalid API key")
    start = time.perf_counter()
    rows = await run_in_threadpool(retrieve, req.question)
    context = "\n\n".join(f"[{i + 1}] {title}\n{body}" for i, (title, _, body) in enumerate(rows))
    messages = [{"role": "system", "content": SYSTEM},
                {"role": "user", "content": f"Articles:\n{context}\n\nQuestion: {req.question}"}]

    async def stream():
        first, code = True, "200"
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(60, connect=5)) as client:
                async with client.stream("POST", f"{LLM_URL}/chat/completions", json={
                        "model": "atlas", "messages": messages, "stream": True, "max_tokens": 300}) as r:
                    if r.status_code != 200:
                        code = "502"
                        yield "The model server is unavailable. Please try again.\n"
                        return
                    async for line in r.aiter_lines():
                        if not line.startswith("data: ") or line == "data: [DONE]":
                            continue
                        delta = json.loads(line[6:])["choices"][0]["delta"].get("content")
                        if delta:
                            if first:
                                TTFT.observe(time.perf_counter() - start)
                                first = False
                            yield delta
            yield "\n\nSources:\n" + "\n".join(f"[{i + 1}] {url}" for i, (_, url, _) in enumerate(rows)) + "\n"
        except httpx.HTTPError:
            code = "504"
            yield "\nThe model server timed out.\n"
        finally:
            REQS.labels(code).inc()
            TOTAL.observe(time.perf_counter() - start)

    return StreamingResponse(stream(), media_type="text/plain")
```

The gateway checks the API key, runs retrieval in a thread so it doesn't block the event loop, builds a prompt with
numbered articles, and streams the model's answer token by token from the OpenAI-compatible endpoint, followed by the
sources. It records TTFT on the first token, the full answer time, and the status code. Because a streaming response
has already sent its 200 status, upstream failures are recorded as 502 or 504 in the metrics and explained in the
text. Section 50 adds a retrieval-only fallback for that case.

### Step 2 — Build the images and the cluster

```bash
mkdir -p atlas/services/ingest/docs-src && cd atlas
cp ../16_ai_infra_zero_to_hero/part*/s[0-9][0-9]_*.md services/ingest/docs-src/
# services/ingest/ gets ingest.py and schema.sql from Lecture 340, plus this Dockerfile:
cat > services/ingest/Dockerfile <<'EOF'
FROM python:3.11-slim
RUN useradd --uid 10001 --create-home atlas && pip install --no-cache-dir "psycopg[binary]==3.2.*" "fastembed==0.4.*"
WORKDIR /app
COPY ingest.py schema.sql ./
COPY docs-src /docs
USER 10001
CMD ["python", "ingest.py", "/docs"]
EOF

docker build -t atlas-gateway:dev services/gateway
docker build -t atlas-ingest:dev services/ingest
kind create cluster --name atlas
kind load docker-image atlas-gateway:dev atlas-ingest:dev --name atlas
```

### Step 3 — Deploy Postgres, the model server, and the gateway

```bash
kubectl create secret generic atlas-db \
  --from-literal=DATABASE_URL=postgresql://postgres:atlas@postgres:5432/postgres
kubectl create secret generic atlas-keys --from-literal=API_KEYS=dev-key-123

kubectl apply -f - <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata: {name: postgres}
spec:
  selector: {matchLabels: {app: postgres}}
  template:
    metadata: {labels: {app: postgres}}
    spec:
      containers:
        - name: pg
          image: pgvector/pgvector:pg16
          env: [{name: POSTGRES_PASSWORD, value: atlas}, {name: PGDATA, value: /data/pgdata}]
          ports: [{containerPort: 5432}]
          readinessProbe: {exec: {command: [pg_isready, -U, postgres]}, periodSeconds: 5}
          volumeMounts: [{name: data, mountPath: /data}]
      volumes: [{name: data, persistentVolumeClaim: {claimName: pgdata}}]
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata: {name: pgdata}
spec: {accessModes: [ReadWriteOnce], resources: {requests: {storage: 2Gi}}}
---
apiVersion: v1
kind: Service
metadata: {name: postgres}
spec: {selector: {app: postgres}, ports: [{port: 5432}]}
---
apiVersion: apps/v1
kind: Deployment
metadata: {name: llm, labels: {app: llm}}
spec:
  selector: {matchLabels: {app: llm}}
  template:
    metadata: {labels: {app: llm}}
    spec:
      containers:
        - name: llamacpp
          image: ghcr.io/ggml-org/llama.cpp:server
          args: ["-hf", "Qwen/Qwen2.5-0.5B-Instruct-GGUF:Q4_K_M", "--host", "0.0.0.0", "--port", "8000",
                 "-c", "4096", "--metrics"]
          env: [{name: LLAMA_CACHE, value: /models}]
          ports: [{name: http, containerPort: 8000}]
          resources: {requests: {cpu: "2", memory: 2Gi}, limits: {memory: 3Gi}}
          startupProbe: {httpGet: {path: /health, port: 8000}, periodSeconds: 5, failureThreshold: 120}
          readinessProbe: {httpGet: {path: /health, port: 8000}, periodSeconds: 5}
          volumeMounts: [{name: models, mountPath: /models}]
      volumes: [{name: models, emptyDir: {}}]
---
apiVersion: v1
kind: Service
metadata: {name: llm, labels: {app: llm}}
spec: {selector: {app: llm}, ports: [{name: http, port: 8000}]}
---
apiVersion: apps/v1
kind: Deployment
metadata: {name: gateway, labels: {app: gateway}}
spec:
  replicas: 2
  selector: {matchLabels: {app: gateway}}
  template:
    metadata: {labels: {app: gateway}}
    spec:
      securityContext: {runAsNonRoot: true}
      terminationGracePeriodSeconds: 90
      containers:
        - name: gateway
          image: atlas-gateway:dev
          imagePullPolicy: Never
          envFrom: [{secretRef: {name: atlas-db}}, {secretRef: {name: atlas-keys}}]
          ports: [{name: http, containerPort: 8080}]
          resources: {requests: {cpu: 250m, memory: 512Mi}, limits: {memory: 1Gi}}
          readinessProbe: {httpGet: {path: /readyz, port: 8080}, periodSeconds: 5}
          livenessProbe: {httpGet: {path: /healthz, port: 8080}, periodSeconds: 10}
          lifecycle: {preStop: {exec: {command: ["sleep", "10"]}}}
---
apiVersion: v1
kind: Service
metadata: {name: gateway, labels: {app: gateway}}
spec: {selector: {app: gateway}, ports: [{name: http, port: 8080}]}
EOF
kubectl wait --for=condition=available deploy/postgres deploy/gateway --timeout=180s
kubectl wait --for=condition=available deploy/llm --timeout=600s
```

The manifests are the dev overlay written out in full: Postgres with a persistent volume, llama.cpp downloading the
0.5B model into a cache volume, and two gateway pods using the local images (`imagePullPolicy: Never`). Services name
their ports `http` for the ServiceMonitor. The model server wait allows 10 minutes for the first download.

### Step 4 — Ingest the course

```bash
cat > ingest-job.yaml <<'EOF'
apiVersion: batch/v1
kind: Job
metadata: {name: ingest}
spec:
  backoffLimit: 2
  template:
    spec:
      restartPolicy: Never
      containers:
        - name: ingest
          image: atlas-ingest:dev
          imagePullPolicy: Never
          envFrom: [{secretRef: {name: atlas-db}}]
EOF
kubectl apply -f ingest-job.yaml
kubectl wait --for=condition=complete job/ingest --timeout=900s && kubectl logs job/ingest
# Run it a second time to see that nothing is re-embedded:
kubectl delete job ingest && kubectl apply -f ingest-job.yaml
kubectl wait --for=condition=complete job/ingest --timeout=300s && kubectl logs job/ingest
```

### Step 5 — Ask questions

```bash
kubectl port-forward svc/gateway 8080:8080 &
curl -sN localhost:8080/ask -H 'x-api-key: dev-key-123' -H 'content-type: application/json' \
  -d '{"question": "How does Kueue let one team borrow idle GPUs from another team?"}'
curl -s -o /dev/null -w '%{http_code}\n' localhost:8080/ask -H 'content-type: application/json' -d '{"question":"x"}'
for i in $(seq 20); do
  curl -sN localhost:8080/ask -H 'x-api-key: dev-key-123' -H 'content-type: application/json' \
    -d '{"question": "What is a PodDisruptionBudget?"}' > /dev/null
done
```

### Step 6 — Monitoring

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts && helm repo update
helm install mon prometheus-community/kube-prometheus-stack -n monitoring --create-namespace \
  --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false --set grafana.adminPassword=admin
kubectl apply -f deploy/base/servicemonitor.yaml        # from Lecture 342
kubectl -n monitoring port-forward svc/mon-grafana 3000:80 &
# Open http://localhost:3000 (admin / admin), Explore, and run the SLO queries from Lecture 342.
```

**Expected results:**
- All pods are `Running`, and both gateway pods are ready only after Postgres is ready (the `/readyz` probe).
- The first ingest run reports `articles=52` and about 5,000 chunks written (a few minutes of CPU embedding), with
  `chunks_removed=0`. The second run reports `chunks_written=0`, because every hash matches.
- The `/ask` call streams an answer about Kueue cohorts, borrowing, and reclaim, then a `Sources:` list that includes
  `s40_multi_tenant_ai.md`. A 0.5B model writes short, sometimes clumsy answers; retrieval quality is what you're
  checking.
- The request without an API key returns `401`.
- On a laptop CPU, TTFT is typically 1 to 5 seconds and full answers 5 to 20 seconds. That's expected for CPU and is
  why the demo and scale-test environments use a GPU.
- In Grafana, `sum(rate(atlas_requests_total[5m]))` shows the 20-request burst, and the TTFT p95 query returns a value
  in that range. `llamacpp:tokens_predicted_total` rises with each answer.
- `kind delete cluster --name atlas` removes everything.

---

## FAANG deep-dive notes

**How big tech does it.** Large companies give teams a paved road: templates that create a service repository with a
Dockerfile, CI pipeline, deployment manifests, dashboards, and alerts already wired, so a first prototype runs in
production-like infrastructure on day one. Google's internal platforms, Netflix's Spinnaker-based delivery, and Spotify's
Backstage golden paths are examples. ML platforms such as Uber Michelangelo and Meta's internal serving stacks add model
registries, evaluation gates, and standard serving containers. RAG systems at scale run ingestion as versioned
pipelines with lineage, evaluate retrieval on curated sets, and monitor answer quality alongside latency.

**Staff review questions.**
- Can the whole environment be recreated from code, and destroyed, in under an hour?
- What exactly is running in production: which image digest, which model revision, which index version?
- What happens to in-flight streams during a rollout?
- How do we know a change didn't make retrieval or answers worse?
- Where do the model weights come from at startup, and how long does a cold start take?
- Which metric would tell us first that users are unhappy?

**Interview question.** "You have a working RAG notebook. Take it to a first production deployment in two weeks."

**Typical system-design prompt:** *Turn a RAG prototype into a deployed service for 500 internal users with streaming
answers, sources, and basic monitoring, in two weeks.*

**1. Clarify first:** Who are the users and what's the latency expectation? Which documents, how often do they change,
and are there permissions? Hosted LLM API allowed, or self-hosted? Existing platform (Kubernetes, CI) to reuse? Budget?

**2. Back-of-envelope sizing:**
- 500 users × 10 questions a day = 5,000 requests a day, about 0.06 requests/s average, perhaps 2 requests/s at peak.
- 2 requests/s × 300 output tokens = 600 output tokens/s at peak, within one small GPU or a hosted API.
- Corpus of 5,000 documents × 10 chunks × 384 dimensions × 4 bytes = about 77 MB of vectors, trivial for pgvector.
- Two gateway replicas for availability, one model server (or an API), one managed Postgres.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| LLM for v1 | Hosted API | Self-hosted on GPU | API for speed to launch unless data rules forbid it |
| Embeddings | In the gateway | Separate embedding service | In the gateway while small, separate when shared or on GPU |
| Weights | Baked into image | Downloaded to a volume or cache | Download or cache for anything over a few hundred MB |
| Deploy | CI runs kubectl | GitOps pull | GitOps for audit and rollback |
| Quality gate | Manual spot checks | Golden-set eval in CI | Golden set from the first week |

**4. Follow-up questions with crisp answers:**
- *The model server takes 8 minutes to start.* Cache weights on the node or a fast volume, use a startup probe sized for
  it, and keep a warm replica so scale-up never starts from zero during traffic.
- *Answers cite the wrong documents after a re-index.* Compare recall on the golden set before and after, version the
  index, and switch atomically with a way back.
- *Gateway pods restart under load.* Check memory limits against the embedding model's footprint and the connection
  pool size, and look at `OOMKilled` in pod status.
- *Who can call the API?* API keys or SSO at the gateway, NetworkPolicies so only the gateway reaches the model server
  and database (Section 50).

**Debug this (common onsite question):** "The prototype works locally, but in the cluster every `/ask` returns 502 after
exactly 5 seconds."
1. The gateway logs show `ConnectTimeout` to `http://llm:8000`.
2. `kubectl get endpoints llm` is empty: the Service selector is `app: llm`, but the model server pods are labeled
   `app: vllm` after an overlay change.
3. The Service had no endpoints, so connections timed out at the gateway's 5-second connect timeout.
4. Fix: align the labels, and add a CI check that every Service selector matches at least one workload in the rendered
   manifests.

The lesson: check the plumbing (Services, endpoints, labels, ports) before suspecting the model.

**5. What separates senior from staff answers:** a senior engineer deploys a working RAG service on Kubernetes. A staff
engineer builds it so the environment is reproducible and disposable, images are small and traceable to a model
revision, rollouts don't break streams, ingestion is idempotent with deletes and lineage, CI gates on retrieval quality
as well as tests, and dashboards start from SLOs. Each of those choices is cheap now and expensive to add later.

**Red flags:**
- Console-created infrastructure with no code.
- Multi-gigabyte images with weights and unused CUDA libraries.
- No startup probe on a model server.
- Ingestion that never deletes.
- CI that only runs unit tests on an ML system.
- `kubectl apply` from a laptop to production.
- Dashboards with GPU charts but no user-facing latency.

---

## Failure modes

- **GPU quota of zero:** nodes never appear. Fix: check quota on day 1 and fail the setup script early.
- **Huge images:** slow pulls make autoscaling useless. Fix: slim bases, ONNX embeddings, weights outside the image.
- **Model server killed during loading:** liveness probes fire before the model loads. Fix: a startup probe sized for the
  load time.
- **Cut-off streams during rollouts:** pods die mid-answer. Fix: `preStop` sleep and a long enough grace period.
- **Stale index:** deleted articles still answered from. Fix: deletes, hashes, and reconciliation in ingestion.
- **Quality regressions in CI:** tests pass, retrieval gets worse. Fix: a golden-set gate with a real vector database.
- **Empty Service endpoints:** label mismatches after overlay changes. Fix: check selectors in CI and
  `kubectl get endpoints` first when debugging.
- **Unbounded metric labels:** questions or user IDs as labels overload Prometheus. Fix: bounded labels only.

## Checklist

- [ ] My cloud environment is created and destroyed by Terraform, with budgets and tags.
- [ ] A pod on a GPU node runs `nvidia-smi` successfully.
- [ ] The gateway image is small, non-root, and built in CI, and model weights live outside it.
- [ ] Model server pods have startup, readiness, and liveness probes and graceful shutdown.
- [ ] Ingestion is idempotent, deletes removed content, and reports counts.
- [ ] CI runs tests, manifest checks, and a retrieval eval, then builds, scans, signs, and deploys by digest via GitOps.
- [ ] The dashboard shows SLO metrics first, then gateway, model server, GPU, and database rows.
- [ ] The kind prototype answers questions about this course with sources, and rejects requests without an API key.
