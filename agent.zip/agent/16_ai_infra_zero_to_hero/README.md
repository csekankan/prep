# The Complete Guide to AI Infrastructure — Zero to Hero

> 54 sections • 365 lectures • 50+ labs • ~61 hours of source material, rewritten as read-first notes.
> From your first GPU VM to presenting a production-ready enterprise AI platform.

This module follows the syllabus of the *Complete Guide to AI Infrastructure: Zero to Hero* course.
It does not copy that course. Each section is written from scratch in the style of this repo: the
notes are the lesson, and the code is the smallest thing that makes the idea concrete.

It sits between two neighbours:
- [`15_ml_dl_llm_engineering/`](../15_ml_dl_llm_engineering/README.md) teaches the *models*.
- [`13_sovereign_ai_infra_course/`](../13_sovereign_ai_infra_course/README.md) is the advanced,
  Kubernetes-native deep dive. This module is the broad, beginner-to-advanced path that comes first.
  When a topic is covered in more depth there, the section links to the matching lab.

## How every section is structured

| # | Block | Purpose |
|---|---|---|
| 1 | **Section at a glance** | Lecture list, a diagram of how the lectures connect, and what you can do afterwards |
| 2 | **Lecture notes** | One block per lecture: *why it matters*; *in plain words* (an everyday analogy, no jargon); an **architecture diagram** with a *how to read it* walkthrough wherever there's a system or flow to draw; core ideas; a concrete **example** with real numbers or a real incident; and a senior engineer's note |
| 3 | **Lab** | Step-by-step hands-on work, with expected output |
| 4 | **Assessments** | The section's exercises. Computational ones have a runnable solution in [`exercises/`](exercises/) |
| 5 | **Quiz** | Questions with hidden answers, so you can test yourself |
| 6 | **Failure modes** and **checklist** | How it breaks in real life, and what "done" looks like |

## Course map

Status: ✅ written • 🗺️ planned (the outline and cross-links below are the plan for the section).

### Part I — Foundations (Sections 1–5) ✅

Part index: [part01_foundations/README.md](part01_foundations/README.md)

| § | Section | Lectures | Assessments | Notes |
|---|---|---|---|---|
| 1 | AI Infrastructure Fundamentals | 1–7 | Quiz | ✅ [s01](part01_foundations/s01_ai_infra_fundamentals.md) |
| 2 | Linux Foundations for AI Engineers | 8–14 | Build a Linux system health script, quiz | ✅ [s02](part01_foundations/s02_linux_for_ai.md) |
| 3 | Cloud Infrastructure Basics | 15–21 | Recommend a cloud architecture for inference, quiz | ✅ [s03](part01_foundations/s03_cloud_basics.md) |
| 4 | Containerization Foundations | 22–28 | Audit a production Dockerfile, quiz | ✅ [s04](part01_foundations/s04_containerization.md) |
| 5 | Kubernetes Fundamentals | 29–35 | Quiz | ✅ [s05](part01_foundations/s05_kubernetes_fundamentals.md) |

### Part II — Data, GPUs and Distributed Training (Sections 6–8) 🗺️

| § | Section | Lectures | Assessments | Go deeper |
|---|---|---|---|---|
| 6 | Data Storage for AI | 36–42 | Build an idempotent data ingestion pipeline | [13/lab07](../13_sovereign_ai_infra_course/01_foundations_local_sandbox/lab07_persistent_volumes_data_lakes.md), [13/lab67](../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab67_minio_ha.md) |
| 7 | GPU Hardware and Performance | 43–49 | Estimate GPU memory requirements | [13/02](../13_sovereign_ai_infra_course/02_accelerated_compute/README.md), [14/09](../14_math_for_ml_dl_llm/09_ml_systems_math.md) |
| 8 | Distributed Training Basics | 50–56 | Plan a distributed global batch size | [13/03](../13_sovereign_ai_infra_course/03_distributed_training/README.md) |

### Part III — MLOps, CI/CD and Cost (Sections 9–12) 🗺️

| § | Section | Lectures | Assessments | Go deeper |
|---|---|---|---|---|
| 9 | Workflow Automation and Experiment Tracking | 57–63 | Build a reproducible experiment record | [10_llmops_pipeline](../10_llmops_pipeline/00_PIPELINE_FLOW.md) |
| 10 | CI/CD for AI Models | 64–70 | Implement a model deployment quality gate | [11_kubernetes](../11_kubernetes/00_K8S_DEPLOYMENT.md), [07_evaluation](../07_evaluation/) |
| 11 | Advanced Kubernetes for AI | 71–77 | Quiz | [13/lab25](../13_sovereign_ai_infra_course/02_accelerated_compute/lab25_taints_tolerations_affinity.md), [13/lab44](../13_sovereign_ai_infra_course/04_serving_inference/lab44_mlflow_model_registry.md) |
| 12 | Resource and Cost Optimization | 78–84 | Control a cost spike; calculate AI cloud workload cost | [13/lab28](../13_sovereign_ai_infra_course/02_accelerated_compute/lab28_spot_fleets.md), [13/lab30](../13_sovereign_ai_infra_course/02_accelerated_compute/lab30_karpenter_gpu.md) |

### Part IV — Networking and Model Serving (Sections 13–15) 🗺️

| § | Section | Lectures | Assessments | Go deeper |
|---|---|---|---|---|
| 13 | Networking for AI Systems | 85–91 | Quiz | [13/lab35](../13_sovereign_ai_infra_course/03_distributed_training/lab35_infiniband_rocev2.md), [13/lab49](../13_sovereign_ai_infra_course/04_serving_inference/lab49_envoy_grpc_lb.md) |
| 14 | Model Serving Basics | 92–98 | Implement a prediction API contract | [apps/support_copilot](../apps/support_copilot/) |
| 15 | Advanced Model Serving | 99–105 | Quiz | [13/lab41](../13_sovereign_ai_infra_course/04_serving_inference/lab41_triton_multi_framework.md), [13/lab43](../13_sovereign_ai_infra_course/04_serving_inference/lab43_tensorrt_llm_engines.md) |

### Part V — Operating AI in Production (Sections 16–20) 🗺️

| § | Section | Lectures | Assessments | Go deeper |
|---|---|---|---|---|
| 16 | Observability in AI Infrastructure | 106–112 | Evaluate sustained infrastructure alerts | [13/lab27](../13_sovereign_ai_infra_course/02_accelerated_compute/lab27_dcgm_telemetry.md), [08_production](../08_production/) |
| 17 | Model and Data Drift | 113–119 | Lead a drift incident review; detect population drift with PSI | [10_llmops_pipeline](../10_llmops_pipeline/01_online_monitor.py) |
| 18 | AI Security and Compliance | 120–126 | Defend a security design; validate a least-privilege IAM policy | [12_ai_security_governance](../12_ai_security_governance/README.md) |
| 19 | Reliability and High Availability | 127–133 | Coordinate a production outage | [13/lab50](../13_sovereign_ai_infra_course/04_serving_inference/lab50_blue_green_models.md) |
| 20 | Multi-Cloud AI Infrastructure | 134–140 | Quiz | [13/07](../13_sovereign_ai_infra_course/07_sovereign_deployment/README.md) |

### Part VI — Edge and Mobile AI (Sections 21–23) 🗺️

| § | Section | Lectures | Assessments |
|---|---|---|---|
| 21 | Edge AI Infrastructure Basics | 141–147 | Quiz |
| 22 | Optimizing AI for Edge Devices | 148–154 | Quiz |
| 23 | Mobile AI Infrastructure | 155–161 | Quiz, then the **Foundations and Production Systems practice test** |

### Part VII — Workload-Specific Infrastructure (Sections 24–30) 🗺️

| § | Section | Lectures | Assessments | Go deeper |
|---|---|---|---|---|
| 24 | Data Pipelines for AI at Scale | 162–168 | Aggregate streaming events into time windows | [13/lab63](../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab63_kafka_realtime_rag.md) |
| 25 | Generative AI Infrastructure Foundations | 169–175 | Present a RAG design; build permission-aware RAG retrieval | [04_rag](../04_rag/), [apps/secure_doc_search](../apps/secure_doc_search/) |
| 26 | Advanced Generative AI Infrastructure | 176–182 | Calculate LoRA trainable parameters | [13/lab45](../13_sovereign_ai_infra_course/04_serving_inference/lab45_multi_lora_serving.md) |
| 27 | Computer Vision Infrastructure at Scale | 183–189 | Quiz | |
| 28 | NLP Infrastructure at Scale | 190–196 | Quiz | |
| 29 | Multimodal AI Infrastructure | 197–203 | Quiz | |
| 30 | Reinforcement Learning Infrastructure | 204–210 | Quiz | [13/lab31](../13_sovereign_ai_infra_course/03_distributed_training/lab31_ray_kuberay_architecture.md) |

### Part VIII — Training at Scale, Enterprise MLOps and Optimization (Sections 31–36) 🗺️

| § | Section | Lectures | Assessments | Go deeper |
|---|---|---|---|---|
| 31 | Large-Scale Training Foundations | 211–217 | Quiz | [13/lab36](../13_sovereign_ai_infra_course/03_distributed_training/lab36_nccl_optimization.md), [13/lab40](../13_sovereign_ai_infra_course/03_distributed_training/lab40_megatron_lm.md) |
| 32 | Advanced Large-Scale Training | 218–224 | Plan distributed checkpoint shards | [13/lab34](../13_sovereign_ai_infra_course/03_distributed_training/lab34_pytorch_fsdp.md), [13/lab39](../13_sovereign_ai_infra_course/03_distributed_training/lab39_checkpointing_s3.md) |
| 33 | Enterprise MLOps Foundations | 225–231 | Quiz | |
| 34 | Advanced Enterprise MLOps | 232–238 | Quiz | [12/11–15](../12_ai_security_governance/11_governance_foundations.md) |
| 35 | AI Infrastructure Optimization Foundations | 239–245 | Calculate quantized model memory savings | |
| 36 | Advanced AI Infrastructure Optimization | 246–252 | Quiz | |

### Part IX — Privacy, Security and Multi-Tenancy (Sections 37–40) 🗺️

| § | Section | Lectures | Assessments |
|---|---|---|---|
| 37 | Federated Learning Infrastructure | 253–259 | Implement weighted federated averaging |
| 38 | Privacy-Preserving AI | 260–266 | Quiz |
| 39 | Advanced AI Infrastructure Security | 267–273 | Respond to an infrastructure security attack |
| 40 | Multi-Tenant AI Infrastructure | 274–280 | Enforce multi-tenant resource quotas ([13/lab26](../13_sovereign_ai_infra_course/02_accelerated_compute/lab26_resource_quotas_gpu.md)) |

### Part X — AI Infrastructure in Context (Sections 41–46) 🗺️

| § | Section | Lectures | Assessments |
|---|---|---|---|
| 41 | AI Infrastructure for Startups | 281–287 | Advise a startup CTO on a limited budget |
| 42 | AI Infrastructure for Enterprises | 288–294 | Defend an enterprise infrastructure proposal |
| 43 | Infrastructure for Real-Time AI | 295–301 | Evaluate an end-to-end latency SLO |
| 44 | Infrastructure for Autonomous Systems | 302–308 | Conduct a safety-critical deployment review |
| 45 | AI Infrastructure Case Studies (OpenAI, DeepMind, Meta, Tesla, Netflix, healthcare) | 309–315 | Quiz |
| 46 | Future of AI Infrastructure | 316–322 | Quiz |

### Part XI — Review and Capstone (Sections 47–52) 🗺️

| § | Section | Lectures | Assessments |
|---|---|---|---|
| 47 | Course Review | 323–329 | **Complete AI Infrastructure final assessment** (practice test) |
| 48 | Capstone 1: Proposal | 330–336 | Defend the capstone infrastructure proposal |
| 49 | Capstone 2: First working prototype | 337–343 | Lab: deploy the first prototype |
| 50 | Capstone 3: Scalable deployment | 344–350 | Lab: deliver a scalable deployment |
| 51 | Capstone 4: Hardening and documentation | 351–357 | Lab: infrastructure walkthrough |
| 52 | Capstone 5: Demo, presentation and graduation | 358–365 | Deliver the final stakeholder presentation |

The two remaining sections of the 54 are the course introduction (resource kit, certificate) and
the September 2026 update. Neither has teaching content to rewrite.

## The narrative arc

```mermaid
flowchart LR
  A[Foundations<br/>Linux, cloud,<br/>Docker, K8s] --> B[Data + GPUs<br/>storage, CUDA,<br/>distributed training]
  B --> C[MLOps<br/>tracking, CI/CD,<br/>cost]
  C --> D[Serving<br/>FastAPI, Triton,<br/>networking]
  D --> E[Operate<br/>observability, drift,<br/>security, HA]
  E --> F[Specialize<br/>edge, GenAI, CV,<br/>NLP, RL, scale]
  F --> G[Capstone<br/>design, build,<br/>present]
```

## Exercises

Runnable solutions live in [`exercises/`](exercises/). Each one is a single file that uses only the
standard library (or bash), so you can run it without installing anything:

| Section | Exercise | File |
|---|---|---|
| 2 | Build a Linux system health script | [`s02_system_health.sh`](exercises/s02_system_health.sh) |
| 3 | Compare cost and performance across clouds, then recommend an inference architecture | [`s03_cloud_cost_compare.py`](exercises/s03_cloud_cost_compare.py) |
| 4 | Audit a production Dockerfile | [`s04_dockerfile_audit.py`](exercises/s04_dockerfile_audit.py) |

```bash
bash exercises/s02_system_health.sh
python3 exercises/s03_cloud_cost_compare.py
python3 exercises/s04_dockerfile_audit.py                        # audits a built-in bad example
python3 exercises/s04_dockerfile_audit.py path/to/Dockerfile     # audits your own file
```

## Prerequisites

- No prior infrastructure experience. Basic Python helps.
- A computer that can run Docker. 16 GB of RAM is comfortable for the Kubernetes labs.
- A GPU is optional until Part II. Cloud GPUs are fine, and every GPU lab says what it costs.

## Tooling used across the course

`bash`, `docker`, `docker compose`, `kubectl`, `minikube`, `helm`, `aws`/`gcloud` CLIs, `nvidia-smi`,
`torchrun`, `mlflow`, `kafka`, `prometheus`, `grafana`, `tritonserver`, `kubeflow`, `evidently`.
