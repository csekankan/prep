# The Complete Guide to AI Infrastructure — Zero to Hero

> 54 sections • 365 numbered lectures (369 items) • 51 labs • ~61 hours of source material, rewritten as read-first notes.
> From your first GPU VM to presenting a production-ready enterprise AI platform.

This module follows the syllabus of the *Complete Guide to AI Infrastructure: Zero to Hero* course.
It does not copy that course. Each section is written from scratch in the style of this repo: the
notes are the lesson, and the code is the smallest thing that makes the idea concrete.

It sits between two neighbours:
- [`15_ml_dl_llm_engineering/`](../15_ml_dl_llm_engineering/README.md) teaches the *models*.
- [`13_sovereign_ai_infra_course/`](../13_sovereign_ai_infra_course/README.md) is the advanced,
  Kubernetes-native deep dive. This module is the broad, beginner-to-advanced path that comes first.
  When a topic is covered in more depth there, the section links to the matching lab.

## How every section is structured

| # | Block | Purpose |
|---|---|---|
| 1 | **Section at a glance** | Lecture list, a diagram of how the lectures connect, and what you can do afterwards |
| 2 | **Lecture notes** | One block per lecture: *why it matters*; *in plain words* (an everyday analogy, no jargon); an **architecture diagram** with a *how to read it* walkthrough wherever there's a system or flow to draw; core ideas; a concrete **example** with real numbers or a real incident; and a **senior / FAANG best-practice** note |
| 3 | **Lab** | Step-by-step hands-on work, with expected output |
| 4 | **Assessments** | The section's exercises. Computational ones have a runnable solution in [`exercises/`](exercises/) |
| 5 | **Quiz** | Questions with hidden answers, so you can test yourself |
| 6 | **FAANG deep-dive notes** | How big tech does it, a system-design prompt with sizing, trade-offs, follow-ups, a "debug this" scenario, and red flags |
| 7 | **Failure modes** and **checklist** | How it breaks in real life, and what "done" looks like |

## Course map

Status: ✅ written • 🗺️ planned. Assessment and lab names are copied exactly from the source syllabus.
Sections 1–46 each end with a lab and a quiz; the capstone sections (48–52) are labs and presentations.

### Part I — Foundations (Sections 1–5) ✅

Part index: [part01_foundations/README.md](part01_foundations/README.md)

| § | Section | Lectures | Assessments | Lab | Notes |
|---|---|---|---|---|---|
| 1 | AI Infrastructure Fundamentals | 1–7 | Quiz: AI Infrastructure Fundamentals Knowledge Check | Lab – Spin Up Your First AI VM | ✅ [s01](part01_foundations/s01_ai_infra_fundamentals.md) |
| 2 | Linux Foundations for AI Engineers | 8–14 | Build a Linux System Health Script ([solution](exercises/s02_system_health.sh)); Quiz: Linux Foundations for AI Engineers | Lab – Set Up Ubuntu for AI Development | ✅ [s02](part01_foundations/s02_linux_for_ai.md) |
| 3 | Cloud Infrastructure Basics | 15–21 | Quiz: Cloud Infrastructure Basics; Recommend a Cloud Architecture for AI Inference | Lab – Compare Cost & Performance Across Clouds ([solution](exercises/s03_cloud_cost_compare.py)) | ✅ [s03](part01_foundations/s03_cloud_basics.md) |
| 4 | Containerization Foundations | 22–28 | Quiz: Containerization Foundations; Audit a Production Dockerfile ([solution](exercises/s04_dockerfile_audit.py)) | Lab – Containerize a PyTorch Model | ✅ [s04](part01_foundations/s04_containerization.md) |
| 5 | Kubernetes Fundamentals | 29–35 | Quiz: Kubernetes Fundamentals | Lab – Deploy a Model on Minikube | ✅ [s05](part01_foundations/s05_kubernetes_fundamentals.md) |

### Part II — Data, GPUs and Distributed Training (Sections 6–8) ✅

Part index: [part02_data_gpus_training/README.md](part02_data_gpus_training/README.md)

| § | Section | Lectures | Assessments | Lab | Notes |
|---|---|---|---|---|---|
| 6 | Data Storage for AI | 36–42 | Quiz: Data Storage for AI; Build an Idempotent Data Ingestion Pipeline ([solution](exercises/s06_idempotent_ingest.py)) | Lab – Build a Data Ingestion Pipeline | ✅ [s06](part02_data_gpus_training/s06_data_storage.md) |
| 7 | GPU Hardware and Performance | 43–49 | Quiz: GPU Hardware and Performance; Estimate GPU Memory Requirements ([solution](exercises/s07_gpu_memory_estimate.py)) | Lab – Run a Model on GPU with CUDA | ✅ [s07](part02_data_gpus_training/s07_gpu_hardware.md) |
| 8 | Distributed Training Basics | 50–56 | Quiz: Distributed Training Basics; Plan a Distributed Global Batch Size ([solution](exercises/s08_global_batch_plan.py)) | Lab – Train ResNet Across Multiple GPUs | ✅ [s08](part02_data_gpus_training/s08_distributed_training.md) |

### Part III — MLOps, CI/CD and Cost (Sections 9–12) ✅

Part index: [part03_mlops_cicd_cost/README.md](part03_mlops_cicd_cost/README.md)

| § | Section | Lectures | Assessments | Lab | Notes |
|---|---|---|---|---|---|
| 9 | Workflow Automation and Experiment Tracking | 57–63 | Quiz: Workflow Automation and Experiment Tracking; Build a Reproducible Experiment Record ([solution](exercises/s09_experiment_record.py)) | Lab – Track Experiments with MLflow | ✅ [s09](part03_mlops_cicd_cost/s09_experiment_tracking.md) |
| 10 | CI/CD for AI Models | 64–70 | Quiz: CI/CD for AI Models; Implement a Model Deployment Quality Gate ([solution](exercises/s10_quality_gate.py)) | Lab – CI/CD Pipeline for Model Deployment | ✅ [s10](part03_mlops_cicd_cost/s10_cicd_for_ai.md) |
| 11 | Advanced Kubernetes for AI | 71–77 | Quiz: Advanced Kubernetes for AI | Lab – Deploy MLflow on Kubernetes | ✅ [s11](part03_mlops_cicd_cost/s11_advanced_kubernetes.md) |
| 12 | Resource and Cost Optimization | 78–84 | Quiz: Resource and Cost Optimization; Control an Unexpected AI Infrastructure Cost Spike; Calculate AI Cloud Workload Cost ([solution](exercises/s12_cost_tools.py)) | Lab – Optimize Cloud AI Workload Costs | ✅ [s12](part03_mlops_cicd_cost/s12_cost_optimization.md) |

### Part IV — Networking and Model Serving (Sections 13–15) ✅

Part index: [part04_networking_serving/README.md](part04_networking_serving/README.md)

| § | Section | Lectures | Assessments | Lab | Notes |
|---|---|---|---|---|---|
| 13 | Networking for AI Systems | 85–91 | Quiz: Networking for AI Systems | Lab – Configure Load Balancer for AI API | ✅ [s13](part04_networking_serving/s13_networking.md) |
| 14 | Model Serving Basics | 92–98 | Quiz: Model Serving Basics; Implement a Prediction API Contract ([solution](exercises/s14_prediction_contract.py)) | Lab – Serve an Image Classifier with FastAPI | ✅ [s14](part04_networking_serving/s14_model_serving.md) |
| 15 | Advanced Model Serving | 99–105 | Quiz: Advanced Model Serving | Lab – Deploy a Model on Triton Server | ✅ [s15](part04_networking_serving/s15_advanced_serving.md) |

### Part V — Operating AI in Production (Sections 16–20) ✅

Part index: [part05_operating_production/README.md](part05_operating_production/README.md)

| § | Section | Lectures | Assessments | Lab | Notes |
|---|---|---|---|---|---|
| 16 | Observability in AI Infrastructure | 106–112 | Quiz: Observability in AI Infrastructure; Evaluate Sustained Infrastructure Alerts ([solution](exercises/s16_alert_eval.py)) | Lab – Monitor GPU Cluster with Prometheus | ✅ [s16](part05_operating_production/s16_observability.md) |
| 17 | Model and Data Drift | 113–119 | Quiz: Model and Data Drift; Lead a Model Drift Incident Review; Detect Population Drift with PSI ([solution](exercises/s17_psi_drift.py)) | Lab – Build a Drift Detection Pipeline | ✅ [s17](part05_operating_production/s17_drift.md) |
| 18 | AI Security and Compliance | 120–126 | Quiz: AI Security and Compliance; Defend an AI Security and Compliance Design; Validate a Least-Privilege IAM Policy ([solution](exercises/s18_iam_policy_check.py)) | Lab – Secure a Model Endpoint with Authentication | ✅ [s18](part05_operating_production/s18_security_compliance.md) |
| 19 | Reliability and High Availability | 127–133 | Quiz: Reliability and High Availability; Coordinate a Production AI Service Outage | Lab – Build a HA AI Inference Cluster | ✅ [s19](part05_operating_production/s19_reliability_ha.md) |
| 20 | Multi-Cloud AI Infrastructure | 134–140 | Quiz: Multi-Cloud AI Infrastructure | Lab – Serve a Model Across AWS + GCP | ✅ [s20](part05_operating_production/s20_multi_cloud.md) |

### Part VI — Edge and Mobile AI (Sections 21–23) ✅

Part index: [part06_edge_mobile/README.md](part06_edge_mobile/README.md)

| § | Section | Lectures | Assessments | Lab | Notes |
|---|---|---|---|---|---|
| 21 | Edge AI Infrastructure Basics | 141–147 | Quiz: Edge AI Infrastructure Basics | Lab – Deploy YOLOv5 on Jetson Nano | ✅ [s21](part06_edge_mobile/s21_edge_ai_basics.md) |
| 22 | Optimizing AI for Edge Devices | 148–154 | Quiz: Optimizing AI for Edge Devices | Lab – Optimize a Model with TensorRT | ✅ [s22](part06_edge_mobile/s22_edge_optimization.md), exercise [s22_quantize_prune.py](exercises/s22_quantize_prune.py) |
| 23 | Mobile AI Infrastructure | 155–161 | Quiz: Mobile AI Infrastructure; **Practice Test: AI Infrastructure Foundations and Production Systems** (30 questions, in s23) | Lab – Build a Mobile AI App with TFLite | ✅ [s23](part06_edge_mobile/s23_mobile_ai.md) |

### Part VII — Workload-Specific Infrastructure (Sections 24–30) ✅

Part index: [part07_workloads/README.md](part07_workloads/README.md)

| § | Section | Lectures | Assessments | Lab | Notes |
|---|---|---|---|---|---|
| 24 | Data Pipelines for AI at Scale | 162–168 | Quiz: Data Pipelines for AI at Scale; Aggregate Streaming Events into Time Windows | Lab – Build a Streaming Pipeline with Kafka | ✅ [s24](part07_workloads/s24_data_pipelines.md), exercise [s24_stream_windows.py](exercises/s24_stream_windows.py) |
| 25 | Generative AI Infrastructure Foundations | 169–175 | Quiz: Generative AI Infrastructure Foundations; Present a Production RAG Infrastructure Design; Build Permission-Aware RAG Retrieval | Lab – Deploy a Simple RAG Pipeline | ✅ [s25](part07_workloads/s25_genai_foundations.md), exercise [s25_permission_rag.py](exercises/s25_permission_rag.py). Also see [04_rag](../04_rag/), [apps/secure_doc_search](../apps/secure_doc_search/) |
| 26 | Advanced Generative AI Infrastructure | 176–182 | Quiz: Advanced Generative AI Infrastructure; Calculate LoRA Trainable Parameters | Lab – Fine-Tune a Small LLM with PEFT | ✅ [s26](part07_workloads/s26_genai_advanced.md), exercise [s26_lora_params.py](exercises/s26_lora_params.py) |
| 27 | Computer Vision Infrastructure at Scale | 183–189 | Quiz: Computer Vision Infrastructure at Scale | Lab – Deploy Real-Time Object Detection | ✅ [s27](part07_workloads/s27_computer_vision.md) |
| 28 | NLP Infrastructure at Scale | 190–196 | Quiz: NLP Infrastructure at Scale | Lab – Deploy a BERT Model with FastAPI | ✅ [s28](part07_workloads/s28_nlp_infrastructure.md) |
| 29 | Multimodal AI Infrastructure | 197–203 | Quiz: Multimodal AI Infrastructure | Lab – Deploy CLIP for Image Search | ✅ [s29](part07_workloads/s29_multimodal.md) |
| 30 | Reinforcement Learning Infrastructure | 204–210 | Quiz: Reinforcement Learning Infrastructure | Lab – Train RL Agent with Ray RLlib | ✅ [s30](part07_workloads/s30_reinforcement_learning.md) |

### Part VIII — Training at Scale, Enterprise MLOps and Optimization (Sections 31–36) ✅

Part index: [part08_scale_mlops_optimization/README.md](part08_scale_mlops_optimization/README.md)

| § | Section | Lectures | Assessments | Lab | Notes |
|---|---|---|---|---|---|
| 31 | Large-Scale Training Foundations | 211–217 | Quiz: Large-Scale Training Foundations | Lab – Train Transformer Across Multiple Nodes | ✅ [s31](part08_scale_mlops_optimization/s31_large_scale_training.md). Go deeper: [13/lab36](../13_sovereign_ai_infra_course/03_distributed_training/lab36_nccl_optimization.md), [13/lab40](../13_sovereign_ai_infra_course/03_distributed_training/lab40_megatron_lm.md) |
| 32 | Advanced Large-Scale Training | 218–224 | Quiz: Advanced Large-Scale Training; Plan Distributed Checkpoint Shards | Lab – Train with DeepSpeed ZeRO-3 | ✅ [s32](part08_scale_mlops_optimization/s32_advanced_large_scale_training.md), exercise [s32_checkpoint_shards.py](exercises/s32_checkpoint_shards.py). Go deeper: [13/lab34](../13_sovereign_ai_infra_course/03_distributed_training/lab34_pytorch_fsdp.md), [13/lab39](../13_sovereign_ai_infra_course/03_distributed_training/lab39_checkpointing_s3.md) |
| 33 | Enterprise MLOps Foundations | 225–231 | Quiz: Enterprise MLOps Foundations | Lab – Build a Pipeline in Kubeflow | ✅ [s33](part08_scale_mlops_optimization/s33_enterprise_mlops.md) |
| 34 | Advanced Enterprise MLOps | 232–238 | Quiz: Advanced Enterprise MLOps | Lab – Automate Drift Retraining with Kubeflow | ✅ [s34](part08_scale_mlops_optimization/s34_advanced_enterprise_mlops.md). Go deeper: [12/11–15](../12_ai_security_governance/11_governance_foundations.md) |
| 35 | AI Infrastructure Optimization Foundations | 239–245 | Quiz: AI Infrastructure Optimization Foundations; Calculate Quantized Model Memory Savings | Lab – Quantize a Vision Model | ✅ [s35](part08_scale_mlops_optimization/s35_optimization_foundations.md), exercise [s35_quant_memory.py](exercises/s35_quant_memory.py) |
| 36 | Advanced AI Infrastructure Optimization | 246–252 | Quiz: Advanced AI Infrastructure Optimization | Lab – Train with Mixed Precision | ✅ [s36](part08_scale_mlops_optimization/s36_advanced_optimization.md) |

### Part IX — Privacy, Security and Multi-Tenancy (Sections 37–40) ✅

Part index: [part09_privacy_security_tenancy/README.md](part09_privacy_security_tenancy/README.md)

| § | Section | Lectures | Assessments | Lab | Notes |
|---|---|---|---|---|---|
| 37 | Federated Learning Infrastructure | 253–259 | Quiz: Federated Learning Infrastructure; Implement Weighted Federated Averaging | Lab – Train a Federated Model with TFF | ✅ [s37](part09_privacy_security_tenancy/s37_federated_learning.md), exercise [s37_fedavg.py](exercises/s37_fedavg.py) |
| 38 | Privacy-Preserving AI | 260–266 | Quiz: Privacy-Preserving AI | Lab – Apply Differential Privacy in Training | ✅ [s38](part09_privacy_security_tenancy/s38_privacy_preserving_ai.md) |
| 39 | Advanced AI Infrastructure Security | 267–273 | Quiz: Advanced AI Infrastructure Security; Respond to an AI Infrastructure Security Attack | Lab – Defend Against Adversarial Attacks | ✅ [s39](part09_privacy_security_tenancy/s39_advanced_ai_security.md). Go deeper: [12_ai_security_governance](../12_ai_security_governance/README.md) |
| 40 | Multi-Tenant AI Infrastructure | 274–280 | Quiz: Multi-Tenant AI Infrastructure; Enforce Multi-Tenant Resource Quotas | Lab – Configure Multi-Tenant Cluster | ✅ [s40](part09_privacy_security_tenancy/s40_multi_tenant_ai.md), exercise [s40_tenant_quotas.py](exercises/s40_tenant_quotas.py). Go deeper: [13/lab26](../13_sovereign_ai_infra_course/02_accelerated_compute/lab26_resource_quotas_gpu.md) |

### Part X — AI Infrastructure in Context (Sections 41–46) ✅

Part index: [part10_ai_infra_in_context/README.md](part10_ai_infra_in_context/README.md)

| § | Section | Lectures | Assessments | Lab | Notes |
|---|---|---|---|---|---|
| 41 | AI Infrastructure for Startups | 281–287 | Quiz: AI Infrastructure for Startups; Advise a Startup CTO on a Limited AI Budget | Lab – Deploy AI Infra on Low Budget | ✅ [s41](part10_ai_infra_in_context/s41_startups.md), exercise [s41_startup_budget.py](exercises/s41_startup_budget.py) |
| 42 | AI Infrastructure for Enterprises | 288–294 | Quiz: AI Infrastructure for Enterprises; Defend an Enterprise AI Infrastructure Proposal | Lab – Design Enterprise AI Infra Plan | ✅ [s42](part10_ai_infra_in_context/s42_enterprises.md). Go deeper: [13/enterprise architecture](../13_sovereign_ai_infra_course/ENTERPRISE_REFERENCE_ARCHITECTURE.md) |
| 43 | Infrastructure for Real-Time AI | 295–301 | Quiz: Infrastructure for Real-Time AI; Evaluate an End-to-End Latency SLO | Lab – Build Real-Time Fraud Detection Pipeline | ✅ [s43](part10_ai_infra_in_context/s43_real_time_ai.md), exercise [s43_latency_slo.py](exercises/s43_latency_slo.py) |
| 44 | Infrastructure for Autonomous Systems | 302–308 | Quiz: Infrastructure for Autonomous Systems; Conduct a Safety-Critical Deployment Review | Lab – Deploy AI Agent for Robotics Simulation | ✅ [s44](part10_ai_infra_in_context/s44_autonomous_systems.md) |
| 45 | AI Infrastructure Case Studies | 309–315 | Quiz: AI Infrastructure Case Studies | Lab – Analyze Case Study Infra Architecture | ✅ [s45](part10_ai_infra_in_context/s45_case_studies.md) |
| 46 | Future of AI Infrastructure | 316–322 | Quiz: Future of AI Infrastructure | Lab – Design Future-Proof AI Infra | ✅ [s46](part10_ai_infra_in_context/s46_future_of_ai_infra.md) |

### Part XI — Review and Capstone (Sections 47–52) ✅

Part index: [part11_review_capstone/README.md](part11_review_capstone/README.md)

| § | Section | Lectures | Assessments | Lab | Notes |
|---|---|---|---|---|---|
| 47 | Course Review | 323–329 | **Practice Test: Complete AI Infrastructure Final Assessment** | Lab – Mini-Project Review Sprint | ✅ [s47](part11_review_capstone/s47_course_review.md) |
| 48 | Capstone 1: Proposal and Design | 330–336 | Defend the Capstone Infrastructure Proposal | Lab – Capstone Project Proposal | ✅ [s48](part11_review_capstone/s48_capstone_proposal.md), exercises [s48_capstone_cost.py](exercises/s48_capstone_cost.py) and [s48_proposal/check_proposal.py](exercises/s48_proposal/check_proposal.py) |
| 49 | Capstone 2: Build the First Prototype | 337–343 | — | Lab – Deploy First Working Infra Prototype | ✅ [s49](part11_review_capstone/s49_capstone_prototype.md) |
| 50 | Capstone 3: Scale and Harden | 344–350 | — | Lab – Deliver Scalable Infra Deployment | ✅ [s50](part11_review_capstone/s50_capstone_scale.md), exercise [s50_scale_check.py](exercises/s50_scale_check.py) |
| 51 | Capstone 4: Testing, Reliability, and Documentation | 351–357 | — | Lab – Capstone Infra Walkthrough | ✅ [s51](part11_review_capstone/s51_capstone_testing_docs.md), exercise [s51_burn_rate.py](exercises/s51_burn_rate.py) |
| 52 | Capstone 5: Demo, Presentation, and Graduation | 358–365 | Deliver the Final AI Infrastructure Stakeholder Presentation | — | ✅ [s52](part11_review_capstone/s52_capstone_presentation.md), exercise [s52_benchmark_ci.py](exercises/s52_benchmark_ci.py) |

### Sections outside the numbered lectures

The source course lists **54 sections and 369 items**: the 52 sections above (365 numbered lectures),
plus a course introduction (*Introduction*, *AI Infrastructure Course Resource Kit*, *Certificate of
Completion*) and a *September 2026 Update*. Those four items are course logistics with no teaching
content, so they are not rewritten here.

The source syllabus does not print section titles. Sections 1–46 are named after their quizzes; the
names of Sections 47–52 are descriptive labels chosen for this module.

## The narrative arc

```mermaid
flowchart LR
  A[Foundations<br/>Linux, cloud,<br/>Docker, K8s] --> B[Data + GPUs<br/>storage, CUDA,<br/>distributed training]
  B --> C[MLOps<br/>tracking, CI/CD,<br/>cost]
  C --> D[Serving<br/>FastAPI, Triton,<br/>networking]
  D --> E[Operate<br/>observability, drift,<br/>security, HA]
  E --> F[Specialize<br/>edge, GenAI, CV,<br/>NLP, RL, scale]
  F --> G[Capstone<br/>design, build,<br/>present]
```

## Exercises

Runnable solutions live in [`exercises/`](exercises/). Each one is a single file that uses only the
standard library (or bash), so you can run it without installing anything:

| Section | Exercise | File |
|---|---|---|
| 2 | Build a Linux system health script | [`s02_system_health.sh`](exercises/s02_system_health.sh) |
| 3 | Compare cost and performance across clouds, then recommend an inference architecture | [`s03_cloud_cost_compare.py`](exercises/s03_cloud_cost_compare.py) |
| 4 | Audit a production Dockerfile | [`s04_dockerfile_audit.py`](exercises/s04_dockerfile_audit.py) |
| 6 | Build an idempotent data ingestion pipeline | [`s06_idempotent_ingest.py`](exercises/s06_idempotent_ingest.py) |
| 7 | Estimate GPU memory requirements | [`s07_gpu_memory_estimate.py`](exercises/s07_gpu_memory_estimate.py) |
| 8 | Plan a distributed global batch size | [`s08_global_batch_plan.py`](exercises/s08_global_batch_plan.py) |
| 9 | Build a reproducible experiment record | [`s09_experiment_record.py`](exercises/s09_experiment_record.py) |
| 10 | Implement a model deployment quality gate | [`s10_quality_gate.py`](exercises/s10_quality_gate.py) |
| 12 | Calculate AI cloud workload cost; control a cost spike | [`s12_cost_tools.py`](exercises/s12_cost_tools.py) |
| 14 | Implement a prediction API contract | [`s14_prediction_contract.py`](exercises/s14_prediction_contract.py) |
| 16 | Evaluate sustained infrastructure alerts | [`s16_alert_eval.py`](exercises/s16_alert_eval.py) |
| 17 | Detect population drift with PSI | [`s17_psi_drift.py`](exercises/s17_psi_drift.py) |
| 18 | Validate a least-privilege IAM policy | [`s18_iam_policy_check.py`](exercises/s18_iam_policy_check.py) |
| 22 | Quantization and pruning trade-offs (supporting exercise) | [`s22_quantize_prune.py`](exercises/s22_quantize_prune.py) |
| 24 | Aggregate streaming events into time windows | [`s24_stream_windows.py`](exercises/s24_stream_windows.py) |
| 25 | Build permission-aware RAG retrieval | [`s25_permission_rag.py`](exercises/s25_permission_rag.py) |
| 26 | Calculate LoRA trainable parameters | [`s26_lora_params.py`](exercises/s26_lora_params.py) |
| 32 | Plan distributed checkpoint shards | [`s32_checkpoint_shards.py`](exercises/s32_checkpoint_shards.py) |
| 35 | Calculate quantized model memory savings | [`s35_quant_memory.py`](exercises/s35_quant_memory.py) |
| 37 | Implement weighted federated averaging | [`s37_fedavg.py`](exercises/s37_fedavg.py) |
| 40 | Enforce multi-tenant resource quotas | [`s40_tenant_quotas.py`](exercises/s40_tenant_quotas.py) |
| 41 | Advise a startup CTO on a limited AI budget | [`s41_startup_budget.py`](exercises/s41_startup_budget.py) |
| 43 | Evaluate an end-to-end latency SLO | [`s43_latency_slo.py`](exercises/s43_latency_slo.py) |
| 48 | Estimate capstone cloud costs per environment; lint the capstone proposal | [`s48_capstone_cost.py`](exercises/s48_capstone_cost.py), [`s48_proposal/check_proposal.py`](exercises/s48_proposal/check_proposal.py) |
| 50 | Check multi-node training scaling, serving availability, stress-test capacity, and drift | [`s50_scale_check.py`](exercises/s50_scale_check.py) |
| 51 | Design multi-window burn-rate alerts for an SLO | [`s51_burn_rate.py`](exercises/s51_burn_rate.py) |
| 52 | Report benchmark percentiles with bootstrap confidence intervals | [`s52_benchmark_ci.py`](exercises/s52_benchmark_ci.py) |

```bash
bash exercises/s02_system_health.sh
python3 exercises/s03_cloud_cost_compare.py
python3 exercises/s04_dockerfile_audit.py                        # audits a built-in bad example
python3 exercises/s04_dockerfile_audit.py path/to/Dockerfile     # audits your own file
python3 exercises/s06_idempotent_ingest.py                       # crash, rerun, rerun: 8 checks
python3 exercises/s07_gpu_memory_estimate.py                     # assessment scenarios
python3 exercises/s08_global_batch_plan.py                       # assessment scenarios
python3 exercises/s09_experiment_record.py                       # reproduce, diff, lint records
python3 exercises/s10_quality_gate.py                            # 4 candidates: 1 promoted, 3 blocked
python3 exercises/s12_cost_tools.py                              # cost model + spike detection
python3 exercises/s14_prediction_contract.py                     # API contract tests + schema compatibility
python3 exercises/s16_alert_eval.py --timeline                   # naive vs sustained alert rules
python3 exercises/s17_psi_drift.py                               # PSI per feature + noise floor
python3 exercises/s18_iam_policy_check.py                        # lint, simulate, minimize IAM policies
python3 exercises/s22_quantize_prune.py                          # INT8/INT4 and pruning error on one layer
python3 exercises/s24_stream_windows.py                          # event-time windows, watermarks, lateness, dedupe
python3 exercises/s25_permission_rag.py                          # ACL pre-filtering, tenant scope, safe cache keys
python3 exercises/s26_lora_params.py                             # LoRA params that match PEFT, plus memory
python3 exercises/s32_checkpoint_shards.py                       # shard sizes, async vs sync stall, best interval
python3 exercises/s35_quant_memory.py                            # quantized weights + KV cache, GPUs needed
python3 exercises/s37_fedavg.py                                  # weighted vs unweighted FedAvg, secure sum
python3 exercises/s40_tenant_quotas.py                           # ResourceQuota, LimitRange, Kueue borrow/reclaim
python3 exercises/s41_startup_budget.py                          # API vs router vs self-host, budget and runway
python3 exercises/s43_latency_slo.py                             # fan-out tails, p99 vs SLO, hedged requests
python3 exercises/s48_capstone_cost.py                           # GPUs from peak tokens/s, cost per environment
python3 exercises/s48_proposal/check_proposal.py                 # lints the sample Atlas proposal (14 checks)
python3 exercises/s50_scale_check.py                             # LoRA vs full scaling, HA availability, capacity, PSI
python3 exercises/s51_burn_rate.py                               # burn-rate thresholds and time to detect incidents
python3 exercises/s52_benchmark_ci.py                            # p50/p95/p99 with bootstrap intervals
```

## Coverage check

[`tools/validate_coverage.py`](tools/validate_coverage.py) checks every written section against the
syllabus manifest [`tools/syllabus.txt`](tools/syllabus.txt) (365 lectures, 34 assessments, 46 quizzes).
Every lecture must have a plain-words analogy, an architecture diagram, an example, and a senior/FAANG
best-practice note. Every lab must have a goal and expected results. Every section must have its
assessments, its quiz, FAANG deep-dive notes, failure modes, and a checklist. Linked exercises must run.

```bash
python3 tools/validate_coverage.py --run          # all 52 sections pass; exit code 1 if any regresses
```

## Prerequisites

- No prior infrastructure experience. Basic Python helps.
- A computer that can run Docker. 16 GB of RAM is comfortable for the Kubernetes labs.
- A GPU is optional until Part II. Cloud GPUs are fine, and every GPU lab says what it costs.

## Tooling used across the course

`bash`, `docker`, `docker compose`, `kubectl`, `minikube`, `helm`, `aws`/`gcloud` CLIs, `nvidia-smi`,
`torchrun`, `mlflow`, `kafka`, `prometheus`, `grafana`, `tritonserver`, `kubeflow`, `evidently`.
