# Section 10 — CI/CD for AI Models

> Lectures 64–70 • Assessment: quiz + Implement a Model Deployment Quality Gate
> **After this section you can:** explain how CI/CD for ML differs from CI/CD for ordinary software, build
> ML pipelines in GitHub Actions, GitLab CI, and Jenkins, test data and models before deployment, build and
> sign images automatically, roll models out with canaries and roll back safely, and write a quality gate
> that blocks bad models.
>
> Go deeper: [07 — Evaluation (CI eval gate)](../../07_evaluation/03_ci_eval_gate.py),
> [11 — Kubernetes deployment (canary, GitOps)](../../11_kubernetes/00_K8S_DEPLOYMENT.md),
> [13 / Lab 50 — Blue/green models](../../13_sovereign_ai_infra_course/04_serving_inference/lab50_blue_green_models.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 64 | What is MLOps and CI/CD for AI? | Three loops: CI tests code, data, and models. CD ships them. CT retrains them |
| 65 | GitHub Actions basics for ML projects | Workflows of jobs on triggers, with caching, OIDC cloud access, and GPU runners when needed |
| 66 | GitLab CI and Jenkins pipelines | The same ideas in `.gitlab-ci.yml` stages or a `Jenkinsfile`. Pick what your company already runs |
| 67 | Testing models before deployment | Unit, data, model-quality, slice, behavioral, and load tests, each catching a different failure |
| 68 | Automating Docker builds for AI apps | Build once, tag by commit, scan, sign, and promote the same digest through environments |
| 69 | Canary deployments and rollbacks | Send 5% of traffic to the new model, compare live metrics, and roll back automatically |
| 70 | Lab: CI/CD pipeline for model deployment | A pipeline from pull request to canary, with a quality gate in the middle |

```mermaid
flowchart LR
  DEV[Pull request] --> CI["CI: lint, unit tests,<br/>data checks, smoke train"]
  CI --> MERGE[Merge to main]
  MERGE --> TRAIN["Train or fetch candidate<br/>logged to MLflow"]
  TRAIN --> GATE{"Quality gate<br/>vs champion,<br/>slices, latency, lineage"}
  GATE -->|block| STOP[Fail the pipeline,<br/>report why]
  GATE -->|pass| BUILD["Build image, scan, sign,<br/>push by digest"]
  BUILD --> STG[Deploy to staging<br/>integration + load test]
  STG --> CAN["Canary in production<br/>5% then 25% then 100%"]
  CAN -->|metrics bad| RB[Automatic rollback]
  CAN -->|metrics good| PROD[Promote: alias champion]
  MON[Monitoring and drift<br/>Section 17] -->|retrain trigger| TRAIN
```

**How to read it:** a change starts as a pull request and passes fast checks. After merge, a candidate
model is trained (or picked from the registry) and must pass the **quality gate** before anything is
built. The image is built once, then deployed to staging and to a small slice of production traffic.
Live metrics decide whether the rollout continues or rolls back automatically. Monitoring closes the
loop by triggering retraining when the data drifts.

**Terms in this diagram.**
- **Lint**: an automatic style and error check of the source code (for example `ruff` for Python) that
  catches typos, unused imports, and suspicious code before anything runs.
- **Smoke train**: training for a few dozen steps on a tiny data sample. It doesn't produce a useful
  model. It only proves the training code runs end to end, the way a "smoke test" checks that a new device
  doesn't start smoking when switched on.
- **Candidate** and **champion**: the candidate is the newly trained model being considered. The champion
  is the model currently serving users. The candidate must beat, or at least match, the champion.
- **MLflow**: an open-source tool that records every training run (parameters, metrics, files) and keeps a
  **model registry**, a catalog of model versions. Section 9 teaches it.
- **Lineage**: the recorded chain of where a model came from: which code commit, which dataset version,
  which parameters. The gate refuses a model whose lineage is unknown.
- **Scan, sign, push by digest**: scan the image for known security holes, attach a cryptographic
  signature proving who built it, and store it in the registry under its **digest**, a fingerprint
  (`sha256:...`) that changes if a single byte of the image changes. Lecture 68 explains each step.
- **Integration and load test**: an integration test checks the service works together with its real
  neighbors (database, feature store). A load test sends heavy, realistic traffic to measure latency.
- **Canary** and **rollback**: a canary gives the new version a small share of real traffic first. A
  rollback switches traffic back to the previous version. Lecture 69 covers both.
- **Alias champion**: in the registry, "champion" is a movable label (an **alias**) pointing to one model
  version. Promoting means moving the label, and rolling back means moving it back.
- **Drift**: the live data or its relationship to the labels changing over time, which makes a model
  less accurate (Section 17).

---

## Lecture 64 — What is MLOps and CI/CD for AI?

**Why it matters.** Software CI/CD assumes the code is the whole product. In ML, behavior also depends on
data and on trained weights, which change without any code change. Pipelines that only test code ship
broken models with green checkmarks.

**In plain words.** A normal software release is like printing a new edition of a book: check the text,
print it, ship it. An ML release is like releasing a new batch of wine. The recipe (code) may be the same,
but this year's grapes (data) are different, so you taste every batch (evaluate) before it goes on
sale, and you keep last year's bottles in case this one is bad.

**Architecture: the three loops.**

```mermaid
flowchart TB
  subgraph CI["Continuous integration"]
    C1[Code tests] --> C2[Data tests] --> C3[Model tests]
  end
  subgraph CD["Continuous delivery"]
    D1[Package model + server] --> D2[Staging] --> D3[Progressive rollout]
  end
  subgraph CT["Continuous training"]
    T1[Trigger: schedule, drift, new data] --> T2[Retrain pipeline<br/>Section 9]
  end
  CI --> CD
  T2 --> C3
  D3 --> MON[Production monitoring]
  MON --> T1
```

**How to read it:** CI checks every change, including data and model behavior, not just code. CD
packages and releases. CT retrains when the world changes. Monitoring connects production back to
training, so the system improves without a human remembering to retrain.

**Terms in this diagram.**
- **Staging**: a copy of production with no real users, where the release is tried first.
- **Progressive rollout**: releasing to production in steps (for example 5%, then 25%, then 100% of
  traffic) and checking health at each step, instead of switching everyone at once.
- **Trigger: schedule, drift, new data**: the three reasons to retrain automatically. A schedule retrains
  on a fixed calendar (every night). Drift means monitoring saw the live data change. New data means a
  fresh batch of labeled examples arrived.
- **Retrain pipeline**: the automated sequence of steps (fetch data, validate, train, evaluate, register)
  that produces a new candidate model without a person running notebooks (Section 9).

**Core ideas.**

| MLOps maturity (after Google's levels) | What it looks like |
|---|---|
| Level 0: manual | Notebooks. Models handed to engineers by hand. Rare, risky releases |
| Level 1: pipeline automation | Training is an automated pipeline. Continuous training on triggers. Registry |
| Level 2: CI/CD for pipelines | Pipeline code itself is tested and deployed by CI/CD. Gates, canaries, automatic rollback |

| What changes | Software CI/CD | ML CI/CD adds |
|---|---|---|
| Inputs | Code | Code + data + model weights + config |
| Tests | Unit, integration | + data validation, model quality vs champion, slice and fairness checks |
| Artifacts | Binary or image | + model versions in a registry, decoupled from the image |
| Release risk | Bugs | + silent quality loss that no error log shows |
| Rollback | Previous image | Previous image **or** previous model version (alias) |

**Example: the green pipeline that shipped a bad model.** A team's pipeline ran unit tests and built the
image, and everything passed. The new model had been trained on a week of data in which a logging bug
dropped every mobile event. Offline accuracy looked fine on a test set that had the same bug.
Production recommendations for mobile users degraded for 9 days. Adding a data-volume check (rows per
platform vs the last 4 weeks) and a mobile slice in the gate would have blocked it in minutes.

**Senior / FAANG best practice.** Version and release the model separately from the serving code, each
with its own gate and rollback. Then you can ship a model without a code change, and the reverse. Define
the release criteria (metrics, slices, latency, lineage) in a versioned policy file that product, ML, and
risk owners agree on, rather than in someone's head.

---

## Lecture 65 — GitHub Actions basics for ML projects

**Why it matters.** GitHub Actions is the most common CI system for new projects. Small mistakes, such as
stored cloud keys, no caching, or training full models on every PR, make it insecure, slow, or expensive.

**In plain words.** Actions is a robot assistant that watches your repository. When something happens (a
pull request, a merge, a schedule), it follows a checklist written in a YAML file, using rented machines
(runners), and reports back with a tick or a cross.

**Architecture: a typical ML workflow.**

```mermaid
flowchart LR
  EV{"Event"} -->|pull_request| PR["job: test<br/>ubuntu runner<br/>lint, unit, data checks,<br/>tiny smoke train"]
  EV -->|push to main| MAIN["job: train-and-gate<br/>self-hosted GPU runner"]
  MAIN --> IMG["job: build<br/>buildx, cache, trivy, cosign"]
  IMG --> DEP["job: deploy<br/>environment: production<br/>required reviewers"]
  OIDC[("Cloud IAM role<br/>trusts GitHub OIDC")] -.short-lived creds.-> MAIN & IMG & DEP
```

**How to read it:** pull requests run fast checks on GitHub's hosted runners. Merges to `main` run the
heavier jobs, including training on a self-hosted GPU runner, then build and deploy. No job stores cloud
keys: each exchanges a GitHub-issued **OIDC token** for short-lived credentials from a cloud role that
trusts only this repository and branch.

**Terms in this diagram.**
- **Event**: what starts a workflow, for example `pull_request` (a PR is opened or updated) or `push to
  main` (code is merged).
- **Runner**: the machine that executes a job. An **ubuntu runner** is a fresh Linux VM that GitHub
  rents you per job. A **self-hosted GPU runner** is your own GPU machine registered with GitHub, used
  because GitHub's standard runners have no GPU.
- **Job: train-and-gate**: one job that trains the candidate model and then runs the quality gate
  script, which compares it with the champion and fails the job if it's worse.
- **buildx**: Docker's modern build command. It supports remote build caches (reuse unchanged layers
  from earlier builds, so builds take seconds instead of minutes) and multi-architecture images.
- **trivy**: an open-source scanner that lists known vulnerabilities (CVEs, publicly catalogued security
  bugs) in the packages inside an image, and can fail the build on critical ones.
- **cosign**: a tool from the Sigstore project that attaches a cryptographic signature to an image, so the
  cluster can later verify the image really came from this pipeline.
- **environment: production, required reviewers**: a GitHub protection rule. The deploy job pauses until
  a named person approves it, and only that environment holds production secrets.
- **Cloud IAM role**: IAM (identity and access management) is the cloud's permission system. A role is a
  set of permissions that someone may temporarily "assume".
- **OIDC, short-lived creds**: OIDC (OpenID Connect) is a standard for proving identity with signed
  tokens. GitHub signs a token saying "this is repo X, branch main", the cloud checks it and hands back
  credentials that expire in about an hour, so there's no long-lived password to steal.

**Core ideas.**

```yaml
# .github/workflows/ml.yml
name: ml-ci
on:
  pull_request:
  push: { branches: [main] }
permissions: { contents: read, id-token: write }     # id-token for OIDC
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.11", cache: pip }
      - run: pip install -r requirements.txt
      - run: ruff check . && pytest -q tests/unit
      - run: python validate_data.py --sample data/sample.parquet      # schema, nulls, ranges
      - run: python train.py --smoke --max-steps 50                     # does training run at all?
  train-and-gate:
    if: github.ref == 'refs/heads/main'
    needs: test
    runs-on: [self-hosted, gpu]
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with: { role-to-assume: "arn:aws:iam::123456789012:role/ml-ci", aws-region: eu-west-1 }
      - run: python train.py --config configs/prod.yaml                 # logs to MLflow
      - run: python gate.py --candidate reports/cand.json --champion reports/champ.json
```

| Concept | Meaning |
|---|---|
| Workflow / job / step | A YAML file of jobs. Jobs run on runners. Steps run in order within a job |
| Trigger (`on`) | `pull_request`, `push`, `schedule` (cron), `workflow_dispatch` (manual) |
| `needs` | Job dependencies. Without it, jobs run in parallel |
| Environments | Named targets with protection rules (required reviewers, branches) and their own secrets |
| Self-hosted runners | Your machines (GPU nodes, Kubernetes runners with Actions Runner Controller) |

- **Smoke-train on PRs**, don't fully train: 50 steps on a sample proves the code path works in
  minutes.
- Pin third-party actions to a full commit SHA, not a tag, because a compromised tag can steal secrets.

**Example: removing stored cloud keys.** A repository stored `AWS_ACCESS_KEY_ID` and
`AWS_SECRET_ACCESS_KEY` as secrets, with admin rights, never rotated. After switching to OIDC, the role
only trusted `repo:org/fraud-model:ref:refs/heads/main` and could only write to one ECR repository and one
S3 prefix. A later compromise of a fork's PR workflow couldn't reach the cloud at all.

**Senior / FAANG best practice.** CI jobs get least-privilege, short-lived credentials (OIDC). Production
deploys go through protected environments with required approvers, from `main` only. Keep GPU runners
ephemeral (one job per runner pod), so nothing leaks between jobs. Measure CI time and cost per PR, and
keep the PR path under ~10 minutes, or engineers start bypassing it.

---

## Lecture 66 — GitLab CI and Jenkins pipelines

**Why it matters.** Many enterprises run GitLab or Jenkins, not GitHub. The concepts carry over, but the
syntax, runner model, and security pitfalls differ, and you'll be expected to work in whichever one the
company uses.

**In plain words.** These are three brands of the same robot assistant. GitLab's is built into the same
house as your code. Jenkins is an older, very customizable robot that you host and maintain yourself,
with a plugin for everything, including plugins you'd rather not have.

**Architecture: GitLab stages and runners.**

```mermaid
flowchart LR
  subgraph PIPE[".gitlab-ci.yml pipeline"]
    S1[stage: test] --> S2[stage: train] --> S3[stage: gate] --> S4[stage: build] --> S5[stage: deploy]
  end
  S1 -.runs on.-> R1["Kubernetes runner<br/>CPU pods"]
  S2 -.runs on.-> R2["Runner tagged gpu<br/>GPU node pool"]
  S4 -.runs on.-> R1
  S5 -->|"environment: production,<br/>manual approval"| K8S[Cluster]
```

**How to read it:** a pipeline is a sequence of stages. Jobs in the same stage run in parallel. Each job
is picked up by a runner whose tags match, so GPU jobs land on GPU runners. Deployment jobs target
named environments, with approvals and deployment history.

**Terms in this diagram.**
- **Stage**: a named step of the pipeline (test, train, gate, build, deploy). A stage starts only after
  every job in the previous stage has succeeded.
- **Kubernetes runner, CPU pods**: GitLab's runner can start each job as a temporary **pod** (a running
  container, Section 5) in a Kubernetes cluster, and delete it when the job ends, so every job gets a
  clean machine.
- **Runner tagged gpu, GPU node pool**: a **tag** is a label that matches jobs to runners. Jobs marked
  `tags: [gpu]` only run on runners with that tag, which sit on a **node pool** (a group of identical
  machines in the cluster) that has GPUs.
- **Manual approval**: the deploy job waits for a person to click "run", so nothing reaches production
  without a human decision.

**Core ideas.**

```yaml
# .gitlab-ci.yml
stages: [test, train, gate, build, deploy]
default: { image: python:3.11-slim }
test:
  stage: test
  script: [pip install -r requirements.txt, pytest -q tests/unit, python validate_data.py --sample]
train:
  stage: train
  tags: [gpu]
  rules: [{ if: '$CI_COMMIT_BRANCH == "main"' }]
  script: [python train.py --config configs/prod.yaml]
  artifacts: { paths: [reports/cand.json] }
gate:
  stage: gate
  script: [python gate.py --candidate reports/cand.json --champion reports/champ.json]
deploy:
  stage: deploy
  environment: production
  when: manual
  script: [kubectl argo rollouts set image fraud-api api=$IMAGE@$DIGEST]
```

```groovy
// Jenkinsfile (declarative)
pipeline {
  agent { kubernetes { yamlFile 'ci/pod.yaml' } }
  stages {
    stage('Test')  { steps { sh 'pytest -q tests/unit && python validate_data.py --sample' } }
    stage('Train') { when { branch 'main' } agent { label 'gpu' } steps { sh 'python train.py' } }
    stage('Gate')  { steps { sh 'python gate.py --candidate reports/cand.json --champion reports/champ.json' } }
    stage('Deploy'){ when { branch 'main' } input { message 'Deploy to production?' } steps { sh './deploy.sh' } }
  }
}
```

| | GitHub Actions | GitLab CI | Jenkins |
|---|---|---|---|
| Hosting | SaaS, or GitHub Enterprise Server | SaaS or self-managed | Self-hosted |
| Config | `.github/workflows/*.yml` | `.gitlab-ci.yml` | `Jenkinsfile` (Groovy) |
| Runners | Hosted + self-hosted (ARC on Kubernetes) | Shared + group/project runners (Kubernetes executor) | Agents (Kubernetes plugin) |
| Strengths | Marketplace, OIDC, simple | All-in-one DevOps, environments, built-in registry | Flexible, huge plugin ecosystem, legacy integrations |
| Watch out | Unpinned actions | Shared runners and secrets across projects | Plugin sprawl, controller security, upgrades |

**Example: a Jenkins controller as an attack path.** A Jenkins controller with 180 plugins (40 outdated)
had a credentials store holding production cloud keys and ran builds on the controller itself. A
vulnerable plugin let an attacker run code on the controller and read every stored secret. The fix
was to run all builds on ephemeral Kubernetes agents, cut the plugins to 35 maintained ones, upgrade the
controller, and replace stored keys with short-lived cloud credentials.

**Senior / FAANG best practice.** Whatever the CI system, standardize on **shared pipeline templates**
(GitLab `include`, Jenkins shared libraries, reusable GitHub workflows) that encode the company's ML
release steps. Teams then fill in parameters instead of copy-pasting YAML. Never run builds on the
controller, and treat the CI system as production infrastructure, with patching, backups, and audit.

---

## Lecture 67 — Testing models before deployment

**Why it matters.** Most ML failures don't raise exceptions. The model returns plausible but wrong
answers. Only tests designed for ML (data checks, quality vs the champion, slices, behavior) catch them
before users do.

**In plain words.** A pilot's pre-flight checklist checks the engine, fuel, and instruments, and the
plane also has to pass a test flight before carrying passengers. For models: check the parts (unit
tests), check the fuel (data tests), test-fly on known routes (evaluation), and test-fly in bad weather
(slices, edge cases, load).

**Architecture: the ML test pyramid.**

```mermaid
flowchart TB
  L1["Unit tests: feature functions, preprocessing,<br/>tokenizers. Milliseconds, on every PR"] --> L2
  L2["Data tests: schema, nulls, ranges, volume,<br/>distribution vs last week"] --> L3
  L3["Model quality: metrics vs floors and vs champion<br/>on a versioned golden set"] --> L4
  L4["Slices and fairness: per country, device,<br/>new users, protected groups"] --> L5
  L5["Behavioral: invariance, directional,<br/>minimum functionality tests"] --> L6
  L6["Serving: API contract, latency p95 under load,<br/>memory, model size"] --> L7
  L7["Online: shadow traffic and canary metrics"]
```

**How to read it:** the cheap, fast tests sit at the top, and run on every pull request. Moving down, the
tests get more expensive and closer to production, so they run after merge or during the rollout. Each
layer catches failures the layers above it can't. Here is what each box means.

1. **Unit tests** check one small piece of code in isolation: **feature functions** (code that turns raw
   data into model inputs) and **preprocessing** (cleaning and reshaping inputs before the model sees
   them). For example, "does the function that
   normalizes a transaction amount reject negative numbers?" or "does the tokenizer turn text into tokens
   and back without losing characters?" They take milliseconds, so they run on every pull request.
2. **Data tests** check the *input data*, not the code. A **schema** check confirms the expected columns
   and types exist. A **null** check finds missing values. A **range** check catches impossible values (a
   negative age). A **volume** check flags a sudden drop or spike in row count, which usually means an
   upstream pipeline broke. A **distribution** check compares this week's values with last week's, to
   catch silent shifts (Section 17 covers drift in depth).
3. **Model quality** compares the new model's metrics with two things. A **floor** is the minimum
   acceptable score (for example, recall of at least 0.60). The **champion** is the model currently in
   production, so the new model (the **challenger**) must also be at least as good as what users already
   have. Both are measured on a **golden set**: a fixed, versioned, carefully labeled evaluation dataset
   that doesn't change between runs, so scores are comparable.
4. **Slices and fairness** repeat the quality check for subgroups (a **slice** is a subset of the data,
   such as one country, one device type, or new users). A model can improve on average while getting
   worse for one group, and only per-slice metrics reveal it. **Protected groups** are groups covered
   by law or policy (for example by age or gender), where a regression is also a compliance problem.
5. **Behavioral tests** check *how* the model reasons, using hand-written cases (the CheckList method).
   An **invariance** test changes something that shouldn't matter (a person's name) and expects the same
   answer. A **directional** test changes something that should matter in a known direction (adding "not")
   and expects the answer to move that way. A **minimum functionality** test is a set of simple cases the
   model must always get right, like a unit test for the model's skills.
6. **Serving tests** check the model as a running service. The **API contract** is the agreed request
   and response format, which must not break existing clients. **Latency p95 under load** is the time
   within which 95% of requests finish, measured while sending realistic peak traffic. **Memory** and
   **model size** checks catch a model that no longer fits on its GPU or container.
7. **Online tests** run in production with real users' traffic, because no offline test perfectly matches
   reality. With **shadow traffic** (also called mirroring), every real request is copied to the new model
   too, its answer is recorded but thrown away, and users only ever see the old model's answer. This lets
   you compare the two models on real inputs with zero user risk. A **canary** sends a small share of real
   traffic (say 5%) to the new model, and users really do get its answers. **Canary metrics** are the
   numbers watched during that time: error rate, latency, and ML signals such as the prediction
   distribution and business outcomes (clicks, conversions, fraud caught), compared between canary and
   stable. If they look worse, traffic goes back automatically. Lecture 69 builds this end to end.

**Core ideas.**

| Test type | Catches | Example check |
|---|---|---|
| Unit | Broken feature code | `normalize_amount(-5)` raises. Tokenizer round-trips |
| Data validation | Bad inputs, pipeline bugs | `amount >= 0`, `country` in a known set, row count within ±20% of the 4-week average (Great Expectations, pandera, TFDV) |
| Quality vs champion | Regressions | AUC not lower by more than the noise margin. Business metric at a fixed operating point |
| Slices | Hidden regressions for groups | Recall per country no more than 2 points lower |
| Behavioral (CheckList-style) | Wrong reasoning | Invariance: changing a name doesn't change sentiment. Directional: adding "not" flips it |
| Robustness | Fragility | Typos, missing fields, extreme values, adversarial prompts (LLMs) |
| Serving and load | Latency and resource regressions | p95 under 60 ms at 2× peak QPS. No memory growth over 30 minutes |
| Contract | Broken clients | Request and response schema unchanged, or versioned |

```python
# pytest: behavioral tests for a sentiment model
def test_invariance_to_names(model):
    a = model.predict("Maria loved the delivery speed")
    b = model.predict("Ahmed loved the delivery speed")
    assert a.label == b.label and abs(a.score - b.score) < 0.05

def test_negation_flips(model):
    assert model.predict("The product works").label == "positive"
    assert model.predict("The product does not work").label == "negative"
```

- **Compare against the champion**, not only fixed thresholds. "AUC ≥ 0.80" lets a model drop from 0.91 to
  0.81 unnoticed.
- **Account for noise.** On 20,000 examples, a recall of 0.61 has a standard error of about
  √(0.61 × 0.39 ÷ 20,000) ≈ 0.0034, so a 0.004 drop could be chance. A 0.03 drop is not.
- For LLMs, add evaluation suites with graded rubrics, safety tests, and regression prompts (Section 25,
  and [07_evaluation](../../07_evaluation/00_EVAL_CONCEPTS.md)).

**Example: the slice that saved a launch.** A fraud model improved overall recall from 0.61 to 0.64,
and the team was ready to ship. The slice report showed recall for Brazilian cards falling from 0.56 to
0.50, because a new feature relied on an address field that's often missing in Brazilian data. Shipping
would have let through ~$400,000 a month more fraud in that market. The gate blocked it. The fixed
version imputed the field and improved every slice.

**Senior / FAANG best practice.** Keep **versioned golden datasets** per product, curated with
the business and refreshed deliberately, with change logs. Every production incident becomes a new
regression test case. Make slice definitions part of the release policy, owned jointly with product and
risk, so "better on average, worse for a group" is always caught.

---

## Lecture 68 — Automating Docker builds for AI apps

**Why it matters.** Every model server ships as an image. Building it by hand, retagging it per
environment, or skipping scans and signatures breaks reproducibility and opens supply-chain risks.

**In plain words.** A factory makes each product once, stamps it with a unique serial number, inspects it,
seals it, and ships the same sealed box to the test shop and then to the store. It never rebuilds the
product for the store, because then the store would get something different from what was tested.

**Architecture: build once, promote by digest.**

```mermaid
flowchart LR
  SRC["main @ commit d4e5f6"] --> BLD["docker buildx build<br/>remote cache, pinned base"]
  BLD --> SCAN["Trivy scan<br/>block on critical CVEs"]
  SCAN --> SBOM["Syft SBOM"]
  SBOM --> SIGN["cosign sign<br/>keyless via OIDC"]
  SIGN --> REG[("Registry<br/>fraud-api:d4e5f6<br/>sha256:7c1e...")]
  REG -->|same digest| STG[Staging]
  STG -->|same digest| PROD[Production]
  ADM["Admission policy<br/>signed, digest only"] -.enforces.-> PROD
```

**How to read it:** one commit produces one image, tagged with the commit SHA for humans and identified by
its **digest** for machines. It's scanned, documented (SBOM), and signed, then the same digest moves from
staging to production. The cluster's admission policy only runs signed images referenced by digest, so
nothing unreviewed sneaks in.

**Terms in this diagram.**
- **main @ commit d4e5f6**: the build starts from one exact commit on the `main` branch. `d4e5f6` is the
  start of that commit's SHA (its unique ID), and it becomes the image tag.
- **docker buildx build, remote cache, pinned base**: `buildx` is Docker's modern builder. The **remote
  cache** stores image layers from earlier builds in the registry or CI cache, so unchanged steps aren't
  rebuilt. A **pinned base** means the `FROM` image is fixed by digest, so it can't silently change
  between builds.
- **Trivy scan, block on critical CVEs**: Trivy (an open-source scanner from Aqua Security) lists every
  package in the image and matches it against CVEs, the public catalog of known security
  vulnerabilities. The job fails if any is rated critical.
- **Syft SBOM**: an SBOM (software bill of materials) is the ingredient list of the image: every library
  and version inside it. Syft (from Anchore) generates it. When a new vulnerability is announced, you
  search SBOMs to answer "which of our images are affected?" in minutes.
- **cosign sign, keyless via OIDC**: cosign (from the Sigstore project) attaches a signature to the image.
  **Keyless** means there's no long-lived private key to protect: the CI job proves its identity with its
  OIDC token (Lecture 65), Sigstore issues a certificate valid for a few minutes, and the signature is
  recorded in a public transparency log.
- **Registry, fraud-api:d4e5f6, sha256:7c1e...**: the registry stores the image. `fraud-api:d4e5f6` is the
  human-readable **tag**, which could later be moved to another image. `sha256:7c1e...` is the
  **digest**, a fingerprint of the exact bytes, which can never point to anything else.
- **Admission policy, signed, digest only**: a rule in the Kubernetes cluster (enforced by a tool such as
  Kyverno, Sigstore policy-controller, or a ValidatingAdmissionPolicy, Section 5 entry H4) that rejects
  any pod whose image isn't signed by this pipeline or isn't referenced by digest.

**Core ideas.**

```yaml
# GitHub Actions job: build, scan, sign, push
build:
  runs-on: ubuntu-latest
  permissions: { contents: read, packages: write, id-token: write }
  steps:
    - uses: actions/checkout@v4
    - uses: docker/setup-buildx-action@v3
    - uses: docker/login-action@v3
      with: { registry: ghcr.io, username: "${{ github.actor }}", password: "${{ secrets.GITHUB_TOKEN }}" }
    - id: build
      uses: docker/build-push-action@v6
      with:
        push: true
        tags: ghcr.io/org/fraud-api:${{ github.sha }}
        cache-from: type=gha
        cache-to: type=gha,mode=max
    - uses: aquasecurity/trivy-action@0.24.0
      with: { image-ref: "ghcr.io/org/fraud-api:${{ github.sha }}", severity: CRITICAL, exit-code: "1" }
    - uses: sigstore/cosign-installer@v3
    - run: cosign sign --yes ghcr.io/org/fraud-api@${{ steps.build.outputs.digest }}
```

| Practice | Why |
|---|---|
| Tag with the commit SHA, deploy by digest | Traceable and immutable |
| Remote layer cache | Rebuilds in seconds, not minutes |
| Weights outside the image (Section 4) | Image changes only when code changes. Models are versioned separately |
| Scan + SBOM + sign | Find CVEs, answer "are we affected?", prove where the image came from |
| Multi-arch only when needed (`linux/amd64,linux/arm64`) | Graviton or Apple silicon targets. Doubles build time |

**Example: "works in staging, broken in prod".** A team rebuilt the image for production from the same
commit a day after staging. In between, a base-image tag moved to a new minor version with a different
OpenSSL, and TLS calls to the feature store failed in production. Promoting the tested digest instead of
rebuilding made this class of bug impossible.

**Senior / FAANG best practice.** Build hermetically: pinned base digests, lock files, no network
downloads during the build except from internal mirrors. Generate SLSA provenance (who built what, from
which commit), and verify it at admission. Big-tech build systems (Bazel, Buck) take this further with
fully reproducible builds. The minimum bar is build once, sign, and promote by digest.

---

## Lecture 69 — Canary deployments and rollbacks

**Why it matters.** Offline tests can't capture everything about production traffic. Progressive
delivery limits the damage of a bad model to a small share of users for a few minutes, and automatic
rollback makes recovery a non-event.

**In plain words.** Miners once carried a canary into the mine. If the air was bad, the bird reacted
first, and the miners got out. A canary release sends a small share of real traffic to the new version,
and if its health signals look bad, everyone stays on the old version.

**Architecture: an automated canary with analysis.**

```mermaid
sequenceDiagram
  participant CD as Argo Rollouts / Flagger
  participant LB as Ingress / service mesh
  participant Old as Stable v12
  participant New as Canary v13
  participant Prom as Prometheus
  CD->>New: deploy v13 pods
  CD->>LB: route 5% to v13
  loop every 2 minutes for 20 minutes
    CD->>Prom: error rate, p95 latency, score distribution, business KPI
    Prom-->>CD: v13 vs v12
  end
  alt healthy
    CD->>LB: 25%, then 50%, then 100%
    CD->>Old: scale down
  else unhealthy
    CD->>LB: 0% to v13 (rollback)
    CD->>New: scale down, alert the team
  end
```

**How to read it:** the controller deploys the new version beside the old one and sends it a small
share of traffic. It queries metrics for both versions on a schedule, and only increases the traffic share
while the canary stays healthy. If a check fails, traffic goes back to the stable version without a human,
and the team is alerted.

**Terms in this diagram.**
- **Argo Rollouts / Flagger**: two open-source Kubernetes controllers for progressive delivery. They
  replace a plain Deployment's all-at-once update with steps: shift some traffic, check metrics, continue
  or roll back. Argo Rollouts uses a `Rollout` object, and Flagger wraps an existing Deployment.
- **Ingress / service mesh**: the component that actually splits traffic by percentage. An **Ingress**
  controller or **Gateway** is the HTTP entry point into the cluster (Section 5, entries D3 and D4). A
  **service mesh** (Istio, Linkerd) puts a small proxy next to every pod, so traffic between services
  can also be split, retried, and measured.
- **Stable v12** and **Canary v13**: stable is the version all users get today. The canary is the new
  version that receives the trial share of traffic.
- **Prometheus**: the open-source metrics database most Kubernetes clusters use (Section 16). The rollout
  controller asks it questions like "what is v13's error rate over the last 2 minutes?"
- **Error rate, p95 latency**: the share of requests that fail, and the time within which 95% of
  requests finish. p95 shows the slow tail that an average hides.
- **Score distribution**: how the model's output scores are spread (for example, the average fraud score
  and the share of transactions flagged). If v13's distribution differs sharply from v12's on the same
  traffic, something is wrong even when no request fails.
- **Business KPI**: a key performance indicator, the business number the model exists to move, such as
  click-through rate, conversion rate, or fraud caught per day.
- **Scale down**: reduce the version's pods to zero, freeing their CPUs or GPUs.

**Core ideas.**

| Strategy | How | Best for |
|---|---|---|
| Blue/green | Two full environments. Switch all traffic at once | Fast rollback, infrastructure changes |
| Canary | Gradually shift a share of traffic | Most model and code releases |
| Shadow (mirroring) | Copy traffic to the new model. Responses discarded | Risky models. Compare outputs without user impact |
| A/B test | Split users for a long time, and measure business outcomes | Proving a model improves the product |
| Feature flags | Per-user or per-tenant switch in the app | Gradual exposure by segment |

What to watch in an ML canary, beyond errors and latency:
- **Prediction distribution:** the mean score, the share of positives, and the top-k overlap with the
  stable version. A sudden shift means something is wrong.
- **Input distribution:** confirm the canary sees representative traffic.
- **Business proxies:** clicks, conversions, fraud caught. These are often slower, so use longer bake
  times or a follow-up A/B test.

```yaml
# Argo Rollouts: canary steps with automated analysis
strategy:
  canary:
    steps:
      - setWeight: 5
      - analysis: { templates: [{ templateName: model-health }] }
      - setWeight: 25
      - pause: { duration: 10m }
      - analysis: { templates: [{ templateName: model-health }] }
      - setWeight: 100
```

**Rollback has two levers:** roll back the **image** (Rollout abort or the previous digest), or roll back
the **model** (move the registry alias back, and the servers reload). Practise both.

**Example: a canary that caught a feature bug.** A new recommendation model passed every offline test. At
5% canary, the share of "no recommendations" responses rose from 0.2% to 6%, because a feature-store key
format had changed for the new model's features. Errors and latency were normal, so only the
prediction-distribution check caught it. The rollout aborted after 6 minutes, affecting 0.3% of users
briefly.

**Senior / FAANG best practice.** Every model rollout is progressive by default, with written
analysis templates per service that include ML-specific signals. Roll out per region or cell, one at a
time (Section 20). Keep the previous model warm for fast rollback, and run regular rollback drills. Pair
canaries (safety, minutes) with A/B tests (value, days to weeks). They answer different questions.

---

## Lecture 70 — Lab: CI/CD pipeline for model deployment

**Goal:** build a working CI/CD pipeline in GitHub Actions for a small model service. Pull requests run
tests and a smoke train. Merges train a candidate, run the quality gate, then build, scan, and push an
image. A canary manifest describes the production rollout. Then break the gate on purpose and watch the
pipeline stop.

**What you're building.**

```mermaid
flowchart LR
  PR[Pull request] --> T["test job<br/>pytest + data check + smoke train"]
  T --> M[Merge]
  M --> TG["train-and-gate job<br/>train.py writes reports/cand.json<br/>s10_quality_gate.py"]
  TG -->|exit 1| BLOCK[Pipeline red. Model not shipped]
  TG -->|exit 0| B["build job<br/>image to GHCR, trivy, cosign"]
  B --> R["rollout.yaml<br/>Argo Rollouts canary 5 / 25 / 100"]
```

**In plain words.** You wire the robot so it refuses to ship a model that's worse than the one in
production, and only ships through a gradual canary.

**Terms in this diagram.**
- **pytest**: the standard Python testing tool. It finds functions named `test_*` and reports which pass.
- **reports/cand.json**: the candidate model's report card, a JSON file of its metrics, per-slice results,
  and lineage, written by `train.py` and read by the gate.
- **s10_quality_gate.py, exit 1 / exit 0**: the gate script from this section's assessment. A program's
  **exit code** tells CI whether it succeeded: 0 means pass, and anything else fails the job and stops
  the pipeline.
- **GHCR**: the GitHub Container Registry (`ghcr.io`), where GitHub stores Docker images next to your
  repository.
- **trivy, cosign**: the vulnerability scanner and the signing tool from Lecture 68.
- **rollout.yaml, Argo Rollouts canary 5 / 25 / 100**: the Argo Rollouts manifest that sends 5%, then 25%,
  then 100% of traffic to the new version, checking health between steps (Lecture 69).

### Step 1 — Repository layout

```text
model-service/
├── .github/workflows/ml.yml        # the pipeline
├── train.py                        # trains, writes reports/cand.json (metrics, slices, lineage)
├── gate.py                         # copy of exercises/s10_quality_gate.py
├── reports/champ.json              # the current champion's evaluation report
├── app/main.py, Dockerfile         # the serving API from Section 4
├── tests/unit/test_features.py
└── deploy/rollout.yaml             # Argo Rollouts canary
```

### Step 2 — Try the gate locally

```bash
python3 exercises/s10_quality_gate.py          # four candidates: one promoted, three blocked with reasons
```

Save the champion and v14 reports from the script's `CHAMPION` and `CANDIDATES` dictionaries as JSON,
then run the CLI form:

```bash
python3 exercises/s10_quality_gate.py --candidate cand.json --champion champ.json; echo "exit=$?"
```

### Step 3 — The workflow

Use the `test` and `train-and-gate` jobs from Lecture 65, then the `build` job from Lecture 68, with
`needs: train-and-gate`. On a laptop, replace the self-hosted GPU runner with `ubuntu-latest`, because
the model here trains on a CPU in seconds.

### Step 4 — The canary manifest (`deploy/rollout.yaml`)

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata: { name: fraud-api }
spec:
  replicas: 4
  selector: { matchLabels: { app: fraud-api } }
  template:
    metadata: { labels: { app: fraud-api } }
    spec:
      containers:
        - name: api
          image: ghcr.io/org/fraud-api@sha256:REPLACED_BY_CI
          env: [{ name: MODEL_URI, value: "models:/fraud@champion" }]
  strategy:
    canary:
      steps: [{ setWeight: 5 }, { pause: { duration: 5m } }, { setWeight: 25 }, { pause: { duration: 10m } }, { setWeight: 100 }]
```

On a local `kind` or `minikube` cluster with Argo Rollouts installed, apply it, then run
`kubectl argo rollouts set image fraud-api api=<new digest>` and
`kubectl argo rollouts get rollout fraud-api --watch` to watch the steps.
`kubectl argo rollouts abort fraud-api` is the rollback.

### Step 5 — Break it on purpose

Make `train.py` drop a slice's performance (for example, train without one country's rows), push to
`main`, and watch `train-and-gate` fail with the slice named in the log, while `build` never runs.

**Expected results:**
- **Pull requests** show a green `test` job in a few minutes.
- **A merge with a good model** runs `train-and-gate` (PROMOTE, exit 0) and then `build`: an image tagged with
  the commit SHA, scanned and signed.
- **A merge with a slice regression** stops at the gate with `BLOCK` and the failing slice in the log.
- **Locally**, the demo prints four `PASS` checks, the CLI returns exit 1 for v14, and the rollout moves
  through 5% → 25% → 100%, or returns to stable on `abort`.

---

## Assessment — Implement a model deployment quality gate

**Task.** Write a gate that a CI job runs after training. It must exit 0 to promote and 1 to block, and it
must:
1. require complete lineage;
2. enforce absolute floors;
3. block regressions vs the champion beyond statistical noise;
4. block any slice regression beyond an allowance;
5. enforce serving budgets (latency, size);
6. explain every decision.

**Model answer.** The runnable solution is
[`exercises/s10_quality_gate.py`](../exercises/s10_quality_gate.py).

| Candidate | Overall vs champion | Result | Why |
|---|---|---|---|
| v13 | AUC +0.009, recall +0.024 | **PROMOTE** | Better beyond noise. Every slice and budget OK |
| v14 | AUC +0.012, recall +0.031 | **BLOCK** | Brazil recall 0.56 → 0.50 (drop 0.06 > 0.02 allowed) |
| v15 | AUC +0.018, recall +0.05 | **BLOCK** | p95 95 ms > 60 ms budget, size 1.4 GB > 500 MB |
| v16 | Within noise | **BLOCK** | No data snapshot or image digest (trained in a notebook) |

**Design notes:**
- The **noise margin** for proportion metrics is 2 standard errors, √(p(1 − p)/n) each. That's ±0.0069 for
  recall 0.61 on 20,000 examples. Smaller differences are "within noise". They are allowed, but don't
  count as improvements.
- **The policy is data.** Floors, slices, and budgets live in a versioned JSON or YAML file, owned
  jointly by ML, product, and risk, and reviewed like code.
- **Explainability:** every check prints its inputs and verdict, so a blocked engineer knows exactly
  what to fix.

---

## FAANG deep-dive notes

**How big tech does it.** Model releases flow through a standard release platform. Training pipelines
register candidates, automated evaluation produces a report against the champion on versioned golden sets
and slices, policy gates decide, and progressive delivery (shadow, canary per region or cell, then A/B)
exposes users gradually, with automatic rollback. Models and serving code are versioned and rolled back
independently. Every release is recorded for audit.

**Staff review questions.**
- What exactly blocks a model release, who owns that policy, and where is it versioned?
- How long does it take from merge to 100% of traffic, and from detecting a bad model to rolling it back?
- Which canary signals would catch a model that is fast and error-free but wrong?
- Can anyone deploy a model or image outside this pipeline?

**Interview question.** "Design CI/CD for hundreds of models that retrain and deploy daily."

**Typical system-design prompt:** *Design the CI/CD and release system for 200 production models (ranking,
fraud, forecasting) that retrain daily or weekly, with safe automated rollout and rollback, across
3 regions.*

**1. Clarify first:** How critical is each model (revenue, safety, regulation)? How quickly do business
metrics react? What traffic does each model get, and is a canary statistically meaningful? Who approves
releases? Are there regulated models that need human sign-off?

**2. Back-of-envelope sizing:**
- Releases: 200 models × ~4 releases a week ≈ 800 releases a week, ~115 a day. They must be automated
  end to end. Humans only handle exceptions.
- Evaluation: if each gate evaluates on ~100k examples in ~5 minutes on one GPU, that's ~10 GPU-hours
  a day. Cheap compared with training.
- Canary statistics: to detect a 2% relative drop in a 5% conversion rate at 5% traffic, you need on the
  order of 10⁵–10⁶ requests in the canary. High-traffic models get answers in minutes, low-traffic ones in
  days, so they need shadow evaluation or longer bakes.
- Rollback: alias moves take seconds. Image rollbacks take ~1–3 minutes with warm replicas.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Release cadence | Fully automated daily | Human approval | Automate low-risk models. Require approval for regulated or high-impact ones |
| Online validation | Canary | Shadow, then canary | Shadow first for new model families or risky changes |
| Gate thresholds | Fixed floors | Relative to champion with noise margins | Both: floors as a safety net, relative checks for regressions |
| Rollout scope | Global percentage | Region or cell at a time | Cell by cell: limits the blast radius and gives natural comparisons |
| Rollback | Redeploy the old image | Move the model alias | Alias for model issues, image rollback for code issues. Practise both |

**4. Follow-up questions with crisp answers:**
- *How do you test a model whose effect shows up only after days (e.g., churn)?* Use offline gates plus
  leading online proxies in the canary, then a longer A/B test with a holdout. Don't wait days to decide
  safety.
- *What if the champion itself is degraded?* Gates also enforce absolute floors and a minimum-quality
  baseline, so "better than a bad champion" isn't automatically good.
- *How do you avoid gate flakiness?* Fixed, versioned evaluation sets, seeded evaluation, noise-aware
  thresholds, and a record of every gate decision for tuning.

**Debug this (common onsite question):** "The canary passed and the model rolled out to 100%. The next day,
conversions were down 3%."
1. Check what the canary measured: only error rate and p95 latency. No prediction-distribution or
   business metrics.
2. Check canary traffic: it ran in one region at 5% for 10 minutes, mostly at night, so it wasn't
   representative.
3. Diff the models' outputs on yesterday's traffic (replay or shadow): the new model ranks discounted
   items much lower, because a price feature was scaled differently.
4. Fix: roll back by alias immediately. Add prediction-distribution and top-k-overlap checks to the
   analysis template, require a minimum canary sample per region, add a feature-scale check to the gate,
   and follow risky rollouts with an A/B test.

The lesson: canaries only catch what they measure. Health metrics catch broken services. ML-specific
and business signals catch broken models.

**5. What separates senior from staff answers:** a senior engineer builds a pipeline with tests, a gate,
and a canary. A staff engineer designs the release *system*: risk tiers with different policies,
statistically meaningful online validation per traffic level, independent model and code rollback, cell-based
rollouts, a policy owned across functions, and metrics on the release process itself (lead time, change
failure rate, time to restore).

**Red flags:**
- Tests on code only, with no data or model checks.
- Gates with fixed floors only, and no champion comparison or slices.
- Rebuilding images per environment instead of promoting digests.
- Canaries measuring only errors and latency.
- Long-lived cloud keys in CI, or production deploys from any branch.

---

## Quiz

<details><summary>1. What are CI, CD, and CT in MLOps?</summary>
CI tests every change: code, data, and model quality. CD packages and progressively releases models and
services. CT (continuous training) retrains models automatically on schedules, new data, or drift.
</details>

<details><summary>2. Why use OIDC instead of stored cloud keys in CI?</summary>
The CI job exchanges a signed identity token for short-lived credentials from a role that trusts only
specific repositories and branches. There are no long-lived secrets to leak or rotate.
</details>

<details><summary>3. Why does a pull request run a smoke train rather than a full training run?</summary>
It proves the training code path works (data loading, forward and backward, saving) in minutes and
cheaply. Full training runs after merge, in the pipeline.
</details>

<details><summary>4. A candidate's AUC is 0.82, above the 0.80 floor. The champion's is 0.91. Should it ship?</summary>
No. That's a large regression against the champion. Gates must compare with the champion (with a noise
margin), not only check floors.
</details>

<details><summary>5. Give one invariance test and one directional test for a sentiment model.</summary>
Invariance: replacing a person's name doesn't change the label. Directional: adding "not" to "works"
flips the sentiment from positive to negative.
</details>

<details><summary>6. Why promote the same image digest from staging to production instead of rebuilding?</summary>
Rebuilding can pull different base images or packages, so production would run something that was never
tested. A digest is immutable.
</details>

<details><summary>7. Which signals should an ML canary check, beyond error rate and latency?</summary>
Prediction distribution (score mean, positive rate, top-k overlap with stable), input distribution, and
business proxies (clicks, conversions, fraud caught).
</details>

<details><summary>8. Name the two rollback levers for a model service.</summary>
Roll back the image (abort the rollout, or redeploy the previous digest) for code problems. Roll back
the model (move the registry alias to the previous version) for model problems.
</details>

## Failure modes
- Pipelines that test code but never data or model quality.
- Gates with absolute floors only, letting large regressions vs the champion ship.
- Overall metrics improve while a slice (country, device, group) silently regresses.
- Rebuilding images per environment, so production runs untested bits.
- Long-lived, over-privileged cloud keys in CI, or unpinned third-party actions.
- Canaries that are too short, unrepresentative, or blind to prediction quality.
- No practised rollback path, or a rollback that requires retraining.

## Checklist
- [ ] You can explain CI, CD, and CT and the MLOps maturity levels
- [ ] You wrote a GitHub Actions workflow with PR tests, a gated main pipeline, and OIDC
- [ ] You can read and write the same pipeline in GitLab CI and a Jenkinsfile
- [ ] You have unit, data, quality, slice, behavioral, and load tests for one model
- [ ] Your images are built once, scanned, signed, and promoted by digest
- [ ] You ran a canary with Argo Rollouts (or Flagger) and practised an abort
- [ ] You ran `exercises/s10_quality_gate.py` and can explain each block decision
