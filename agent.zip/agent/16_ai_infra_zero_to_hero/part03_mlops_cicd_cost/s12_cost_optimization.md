# Section 12 — Resource and Cost Optimization

> Lectures 78–84 • Assessments: quiz + Control an Unexpected AI Infrastructure Cost Spike + Calculate AI
> Cloud Workload Cost
> **After this section you can:** explain why AI bills spike, train safely on spot capacity, autoscale GPU
> clusters without wasting idle nodes, measure real GPU utilization, cut storage costs, allocate costs fairly
> across teams, calculate a workload's monthly cost, and run a cost-spike investigation from alert to fix.
>
> Go deeper: [13 / Lab 28 — Spot fleets](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab28_spot_fleets.md),
> [Lab 30 — Karpenter for GPUs](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab30_karpenter_gpu.md),
> [Lab 27 — DCGM telemetry](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab27_dcgm_telemetry.md),
> [Lab 26 — GPU resource quotas](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab26_resource_quotas_gpu.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 78 | Why AI infrastructure costs spike | Idle GPUs, fixed peak capacity, data transfer, and forgotten resources cause most of it |
| 79 | Using spot instances for AI training | 60–90% cheaper if jobs checkpoint and restart automatically |
| 80 | Autoscaling AI clusters in cloud | Scale pods on demand signals, nodes on pending pods, and keep warm capacity only where latency needs it |
| 81 | Monitoring resource utilization | Compare requested, allocated, and actually used GPU, CPU, and memory per team |
| 82 | Storage cost optimization strategies | Lifecycle tiers, compact formats, and retention rules for checkpoints, logs, and datasets |
| 83 | Multi-tenant cost allocation in teams | Tag everything, allocate shared costs fairly, show each team its unit costs |
| 84 | Lab: optimize cloud AI workload costs | Model the bill, apply the levers, find idle resources, and set budget alerts |

```mermaid
flowchart LR
  subgraph SPEND["Where AI money goes"]
    TR[Training GPUs]
    INF[Inference GPUs]
    ST[Storage]
    NET[Data transfer]
    OPS[Logs, NAT, idle]
  end
  subgraph LEVERS["Levers"]
    L1["Spot + reserved mix<br/>checkpointing"]
    L2["Autoscaling, batching,<br/>smaller or quantized models"]
    L3["Lifecycle tiers,<br/>retention"]
    L4["Same-region data,<br/>VPC endpoints, CDN"]
    L5["Idle shutdown,<br/>quotas, cleanup"]
  end
  TR --> L1
  INF --> L2
  ST --> L3
  NET --> L4
  OPS --> L5
  LEVERS --> GOV["Governance: tags, budgets,<br/>anomaly alerts, showback,<br/>unit cost per 1k predictions"]
```

**How to read it:** each spending category on the left has its own levers on the right. Spot and
reservations for training, autoscaling and model efficiency for inference, tiers for storage,
locality for data transfer, and hygiene for the long tail. Governance ties it together: without tags,
budgets, and alerts, savings fade, and new spikes go unnoticed.

**Terms in this diagram** (each lever has its own lecture below):
- **Data transfer, NAT, idle**: clouds charge for data leaving a region or the internet (**egress**), for traffic
  through **NAT gateways** (the box that lets private servers reach the internet), and for resources left running
  with nothing to do (**idle**).
- **Spot + reserved mix, checkpointing**: **spot** instances are spare capacity at a 60–90% discount that the cloud
  can take back at short notice. **Reserved** capacity (or savings plans) is a 1–3 year commitment for a 30–70%
  discount. **Checkpointing** makes spot safe for training, because an interrupted job resumes (Lecture 79).
- **Batching, quantized models**: **batching** serves several requests in one GPU pass. A **quantized** model stores
  weights in fewer bits (8 or 4 instead of 16), so it needs less GPU memory and runs faster (Section 22).
- **Lifecycle tiers, retention**: automatic moves of old files to cheaper storage classes, and deleting data after
  a set time (Lecture 82).
- **Same-region data, VPC endpoints, CDN**: keep data and GPUs in the same region, reach cloud services through
  free private endpoints instead of NAT, and serve public files from a **CDN** (content delivery network) cache.
- **Tags, budgets, anomaly alerts, showback**: **tags** label each resource with its owner. **Budgets** alert when
  spending passes a limit. **Anomaly alerts** flag unusual jumps. **Showback** reports each team's costs to it,
  without actually charging it (Lecture 83).
- **Unit cost per 1k predictions**: total cost divided by work done. It's the number that shows whether you got
  more efficient or merely got more traffic.

---

## Lecture 78 — Why AI infrastructure costs spike

**Why it matters.** AI workloads use the most expensive cloud resources there are, often in bursts, and
often started by researchers rather than operations engineers. A single forgotten 8-GPU node costs as much
as a small team's entire CPU fleet.

**In plain words.** A house where the most expensive appliance (the GPU) is easy to switch on and easy to
forget. The electricity bill spikes not because anyone planned to use more power, but because someone left
the oven on all weekend, or the heating ran with the windows open.

**Architecture: the usual causes of a spike.**

```mermaid
flowchart TB
  SPIKE["Bill up 40% this month"] --> A["Idle or forgotten compute<br/>notebooks, dev VMs, stuck jobs"]
  SPIKE --> B["Over-provisioning<br/>fixed peak replicas, oversized GPUs"]
  SPIKE --> C["Data movement<br/>cross-region reads, NAT, internet egress"]
  SPIKE --> D["Runaway automation<br/>retry loops, autoscaler max too high,<br/>hyperparameter sweeps without limits"]
  SPIKE --> E["Growth nobody priced<br/>traffic, context length, LLM API tokens"]
  SPIKE --> F["Storage sprawl<br/>checkpoints, logs, snapshots, duplicate datasets"]
```

**How to read it:** a spike almost always traces back to one of six families. Two are about things
running when they shouldn't (idle, runaway). Two are about running too big (over-provisioning, unpriced
growth). Two are hidden line items (data movement, storage sprawl).

In the diagram, **stuck jobs** are jobs that hang without finishing but keep their GPUs. **Fixed peak replicas**
means always running enough servers for the busiest hour. **Cross-region reads** are training jobs in one region
reading data stored in another, charged per GB. **Internet egress** is data sent out to the internet. A **retry
loop** is code that keeps re-running a failing job, each time paying again. An **autoscaler max too high** lets a
traffic spike or a bug add machines without limit. **Hyperparameter sweeps** launch many
training runs to find the best settings. **Context length** is the number of tokens sent to an LLM per request,
and longer prompts cost proportionally more. **Snapshots** are disk backups that are easy to forget.

**Core ideas.**

| Cause | Typical signal | First fix |
|---|---|---|
| Idle GPU notebooks and VMs | GPU utilization ~0% for hours, on weekends | Idle shutdown, schedules, per-user quotas |
| Fixed peak capacity | Replicas flat all day while traffic varies 5× | Autoscaling (Lecture 80) |
| Oversized hardware | An H100 serving a model that fits on an L4 | Right-size by cost per 1M predictions (Section 3) |
| Cross-region or NAT traffic | "Data transfer" or "NAT gateway" line items jump | Co-locate data, VPC endpoints, caches |
| Retry storms and sweeps | Request or job counts jump, error rate high | Backoff, limits on concurrent trials, budgets |
| LLM token growth | Tokens per request creep up (longer prompts, RAG context) | Prompt budgets, caching, smaller models (Section 25) |
| Storage sprawl | TB grows linearly forever | Lifecycle and retention rules |

- **The FinOps loop:** *inform* (visibility, allocation), *optimize* (rightsizing, commitments), *operate*
  (budgets, policies, culture). Cost is an engineering metric like latency.
- **Unit economics** turn cost into a decision tool: cost per 1,000 predictions, per training run, per
  active user. A bill that grows with revenue is fine. A unit cost that grows is not.

**Example: the long weekend.** On a Friday, 40 researchers left their GPU notebooks running (an
`A10G`-class GPU each). From Friday evening to Tuesday morning, that's 40 × 84 hours × ~$1.0 ≈ **$3,400**
for nothing, and it happened every long weekend. A 2-hour idle-shutdown policy (CPU and GPU near zero,
with no kernel activity) plus a nightly "who is still running?" report cut notebook GPU cost by 62% in a
month.

**Senior / FAANG best practice.** Big tech treats cost as an engineering signal with owners. Every
resource is tagged to a team and service, every team has a budget and anomaly alerts, and every service
reports a unit cost on its dashboard next to latency and errors. Capacity reviews ask "cost per unit of
work this quarter vs last" just as they ask about p99.

---

## Lecture 79 — Using spot instances for AI training

**Why it matters.** Training is usually the largest line item, and spot (preemptible) capacity is 60–90%
cheaper. The catch is that instances can be taken back with short notice, so it only works when the
training system is built for interruptions.

**In plain words.** Flying standby: a much cheaper ticket, but you may be bumped. It works well if you can
take the next flight without losing your luggage (checkpoints), and badly if missing the flight ruins the
trip (a latency-sensitive production service).

**Architecture: interruption-tolerant training on spot.**

```mermaid
sequenceDiagram
  participant Cloud as Cloud provider
  participant Node as Spot GPU node
  participant Job as Training job
  participant S3 as Object storage
  participant Ctl as Controller (Karpenter, Kueue, job operator)
  Job->>S3: periodic sharded checkpoint every 20 min
  Cloud-->>Node: interruption notice (AWS about 2 min, GCP about 30 s)
  Node->>Job: SIGTERM via node termination handler
  Job->>S3: emergency checkpoint if time allows
  Cloud->>Node: reclaim instance
  Ctl->>Cloud: request replacement, any of several GPU types or zones
  Ctl->>Job: restart all ranks on the new nodes
  Job->>S3: load latest checkpoint and continue
```

**How to read it:** the job checkpoints regularly in normal operation. When the cloud announces a
reclaim, a handler signals the job, which tries a last checkpoint. The controller replaces the capacity,
ideally choosing from several instance types and zones, and the job resumes from the newest checkpoint.
The cost of an interruption is only the work since the last checkpoint plus the restart time.

In the diagram, **Karpenter** is a node autoscaler that launches right-sized machines, **Kueue** is a Kubernetes
job queue, and a **job operator** is a controller for training jobs (Section 11). A **sharded checkpoint** is one
where each GPU process saves its own piece in parallel. The **interruption notice** is the cloud's warning before
it reclaims a spot VM: about 2 minutes on AWS, and about 30 seconds on GCP (Google Cloud). The **node termination
handler** is a small agent on each node that receives that notice
and sends **SIGTERM** (the polite "please stop" signal) to the pods. **Ranks** are the training processes, one per
GPU (Section 8).

**Core ideas.**

| | On-demand | Reserved / committed (1–3 years) | Spot / preemptible |
|---|---|---|---|
| Discount | — | ~30–60% | ~60–90% |
| Availability | Usually (if capacity exists) | Guaranteed for the reservation | Can be reclaimed at any time |
| Best for | Spiky, short-term | Steady baseline (inference, always-on training) | Fault-tolerant training, batch inference, sweeps |

- **Expected overhead** ≈ interruptions per day × (average lost work + restart time). With checkpoints
  every 20 minutes (10 minutes lost on average) and 5-minute restarts, 4 interruptions a day cost
  ~1 hour, ~4% of the time. Small next to a 60% discount.
- **Diversify:** allow several instance types, sizes, and zones (EC2 Fleet `capacity-optimized`
  allocation, Karpenter with several instance families). Single-type spot requests are interrupted most.
- **Don't** put latency-SLO serving or tightly coupled jobs without checkpoints on spot only. Mix them
  with an on-demand baseline instead.
- Large multi-node jobs are hit by *any* node's interruption, so the job-level interruption rate grows
  with node count. Spot fits small and medium jobs, or large jobs with fast restarts.

**Example: fine-tuning on spot.** A team ran weekly fine-tuning jobs: 8 × A100 for 30 hours, on demand at
about $33 an hour per node, so ~$990 a run. On spot at ~70% off, with checkpoints every 15 minutes and 3
interruptions per run (~45 minutes lost in total), it cost ~$300. Over 52 runs a year, that saved ~$36,000,
with no change to the models.

**Senior / FAANG best practice.** Classify every workload by interruption tolerance and assign it to a
capacity tier (reserved, on-demand, or spot) explicitly. Make checkpoint-and-resume part of the training
template, with resume tested in CI. Track the spot interruption rate and cost saved per tier, and set the
reserved baseline from the 6–12-month low-water mark of steady usage.

---

## Lecture 80 — Autoscaling AI clusters in cloud

**Why it matters.** Traffic and job queues change hour by hour, but fixed clusters are sized for the
peak. Autoscaling at both the pod and node level is usually the largest inference saving, and it keeps
batch work moving without people resizing clusters.

**In plain words.** A supermarket that opens more checkouts when lines get long, and sends staff home
when it's quiet. But it can't hire a cashier in seconds: new staff take minutes to arrive and set up
(GPU nodes take minutes to boot and load models), so it must open lanes a little before the rush.

**Architecture: two layers of scaling.**

```mermaid
flowchart TB
  M["Demand signals<br/>queue depth, in-flight requests,<br/>tokens/s, pending jobs"] --> KEDA["Pod autoscaler<br/>HPA / KEDA: replicas 2 to 20"]
  KEDA --> PEND{"New pods fit on<br/>existing nodes?"}
  PEND -->|yes| RUN[Pods start in seconds]
  PEND -->|no, Pending| KARP["Node autoscaler<br/>Karpenter / Cluster Autoscaler"]
  KARP --> NEW["New GPU node<br/>boot + driver + image pull + model load<br/>about 4 to 10 minutes"]
  NEW --> RUN
  IDLE["Nodes underused"] --> CONS["Consolidation:<br/>move pods, remove nodes"]
  WARM["Warm pool / overprovisioning pods<br/>for latency-critical services"] -.absorbs bursts.-> RUN
```

**How to read it:** the pod autoscaler adds replicas from demand signals. If they don't fit, they go
Pending, and the node autoscaler launches capacity that matches them. A new GPU node takes minutes, so
latency-sensitive services keep a small warm buffer, and slower batch work simply waits. When load
falls, consolidation packs pods onto fewer nodes and removes the rest.

In the diagram, **queue depth** is the number of requests waiting, **in-flight requests** are those being
processed, and **tokens/s** is LLM output speed. **HPA** is the Kubernetes Horizontal Pod Autoscaler, and **KEDA**
adds event-based scaling and scale-to-zero. **Karpenter** and **Cluster Autoscaler** add and remove machines
(Section 5, entries G1–G4). **Overprovisioning pods** are low-priority placeholder pods that hold spare capacity
and are evicted instantly when a real pod needs the room. **Consolidation** finds underused nodes, moves their pods
elsewhere, and deletes the empty machines.

**Core ideas.**

```yaml
# KEDA: scale a GPU inference Deployment on queue depth (Prometheus metric)
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata: { name: llm-api }
spec:
  scaleTargetRef: { name: llm-api }
  minReplicaCount: 2
  maxReplicaCount: 20
  cooldownPeriod: 300
  triggers:
    - type: prometheus
      metadata:
        serverAddress: http://prometheus.monitoring:9090
        query: sum(vllm:num_requests_waiting{service="llm-api"})
        threshold: "8"            # target ~8 waiting requests per replica
```

| Layer | Tool | Scales on | Watch out |
|---|---|---|---|
| Pods | HPA | CPU/memory or custom metrics | CPU is a poor signal for GPU servers |
| Pods | KEDA | Queues (Kafka, SQS), Prometheus queries, schedules, and to zero | Cold starts from zero |
| Nodes | Cluster Autoscaler | Pending pods, per node group | Fixed instance types per group |
| Nodes | Karpenter (AWS, Azure) | Pending pods, picks the instance type, consolidates | Needs good requests and disruption budgets |
| Schedule | CronJobs, KEDA cron | Known daily patterns | Combine with reactive scaling |

- **Cut cold starts:** pre-pulled or lazily pulled images, weights on a node-local cache or fast volume,
  and an "overprovisioning" placeholder pod at low priority that holds a warm GPU, so it can be evicted
  instantly for a real pod.
- **Scale-down safety:** cooldowns, PodDisruptionBudgets, and `karpenter.sh/do-not-disrupt` on
  long-running training pods.
- **Cap the maximums.** An autoscaler with no ceiling turns a retry storm into a bill.

**Example: from fixed peak to autoscaling.** An API kept 12 L4 replicas around the clock for a daily
peak. Traffic needed 12 replicas for ~10 hours, 6 for 8 hours, and 2 at night. Queue-based KEDA scaling plus
Karpenter consolidation reduced the GPU-hours from 288 to 168 a day, a 42% saving. A warm placeholder
pod kept the p95 under its SLO during the morning ramp.

**Senior / FAANG best practice.** Autoscale on the metric users feel (queue time, in-flight
requests), not on utilization alone. Measure **time to ready** for a new GPU replica end to end, and
engineer it down, because it decides how much warm headroom you must pay for. Set maximums per service
from a capacity plan, and alert when a service sits at its maximum.

---

## Lecture 81 — Monitoring resource utilization

**Why it matters.** You can't cut waste you can't see. Most clusters run far below the capacity they
pay for, because requests are padded and GPUs sit allocated but idle. Utilization metrics per team and
workload make the waste visible and specific.

**In plain words.** A hotel can track rooms booked (requested), rooms with a key handed out (allocated),
and rooms someone actually slept in (used). The gaps between those three numbers are where the money
goes.

**Architecture: the utilization data path.**

```mermaid
flowchart LR
  DCGM["DCGM exporter<br/>per GPU: SM active, memory,<br/>power, tensor activity"] --> PROM[(Prometheus)]
  KSM["kube-state-metrics<br/>requests, limits, pod owners"] --> PROM
  CAD["cAdvisor / kubelet<br/>CPU and memory used"] --> PROM
  PROM --> OC["OpenCost / Kubecost<br/>cost per namespace, label, pod"]
  BILL[(Cloud billing export<br/>CUR, BigQuery)] --> OC
  PROM --> GRAF["Grafana:<br/>requested vs allocated vs used"]
  OC --> GRAF
  GRAF --> ALERT["Alerts: idle GPU > 2 h,<br/>requests 3x usage"]
```

**How to read it:** three sources feed Prometheus: GPU telemetry from DCGM, what pods *requested* from
kube-state-metrics, and what they actually *used* from the kubelet. OpenCost or Kubecost join these with
the cloud's real prices or billing export to produce cost per namespace and label. Dashboards show the
three-way gap, and alerts flag idle GPUs and padded requests.

**Terms in this diagram.**
- **DCGM exporter, SM active, tensor activity**: NVIDIA's GPU metrics agent (Section 7). **SM active** is the share
  of time the GPU's compute units are busy. **Tensor activity** is how much the Tensor Cores are used. Both are far
  more honest than `nvidia-smi`'s "utilization", which only means "some kernel was running".
- **kube-state-metrics**: a Kubernetes add-on that publishes the *declared* state of objects (requested CPU and
  GPUs, limits, which Deployment owns a pod) as metrics.
- **cAdvisor / kubelet**: **cAdvisor** is built into the kubelet and measures each container's *actual* CPU and
  memory use.
- **OpenCost / Kubecost**: tools that turn Kubernetes usage into money. OpenCost is the open-source CNCF project,
  and Kubecost is the commercial product built on it.
- **Cloud billing export, CUR, BigQuery**: the detailed line-by-line bill. **CUR** is AWS's Cost and Usage Report.
  Google Cloud exports billing into **BigQuery** tables.
- **Requested vs allocated vs used**: what pods asked for, what nodes reserved for them, and what they really
  consumed. The gaps are waste.
- **Grafana**: the open-source dashboard tool that draws these charts from Prometheus (Section 16).

**Core ideas.**

```promql
# GPU allocated to pods but idle (SM activity under 5%) for 2 hours, by namespace
avg_over_time(DCGM_FI_PROF_SM_ACTIVE[2h]) < 0.05
  and on (pod) kube_pod_container_resource_requests{resource="nvidia_com_gpu"} > 0

# CPU requested vs used, ratio per namespace (over 3 means heavy padding)
sum by (namespace) (kube_pod_container_resource_requests{resource="cpu"})
  / sum by (namespace) (rate(container_cpu_usage_seconds_total[1h]))
```

| Metric | Source | Tells you |
|---|---|---|
| `DCGM_FI_PROF_SM_ACTIVE` | DCGM | Share of time SMs are busy. Better than "GPU util" |
| `DCGM_FI_DEV_FB_USED` | DCGM | GPU memory used. Low usage hints at a smaller GPU or MIG |
| `DCGM_FI_DEV_POWER_USAGE` | DCGM | Power. Idle GPUs draw far below their limit |
| Requests vs usage | kube-state-metrics + cAdvisor | Padding to right-size |
| Cost per namespace/label | OpenCost/Kubecost | Who spends what, including idle share |

- **Right-sizing loop:** take the p95 of usage over 2–4 weeks, add headroom (20–30%), and set requests
  from that. The Vertical Pod Autoscaler in recommendation mode can suggest values.
- **Allocated is not used.** A pod holding a GPU at 3% SM activity costs the same as one at 90%.

**Example: finding a 30% saving in a week.** A dashboard of allocated vs used GPUs showed that 22 of 96
allocated GPUs had under 5% SM activity for most of the week: forgotten experiment pods, a staging
deployment at full production size, and a batch job waiting on a stuck upstream. Removing the
forgotten pods, scaling staging to one replica, and adding the idle-GPU alert freed ~23% of the fleet. Moving
two small models to MIG slices brought the total to ~30%.

**Senior / FAANG best practice.** Report **allocated vs used GPU-hours per team every week**, with
named top offenders. Make idle alerts go to the owning team, not a central inbox. Big tech sets
utilization targets per pool (for example, more than 70% SM-active hours for training pools), and
reviews outliers in the same meeting as reliability.

---

## Lecture 82 — Storage cost optimization strategies

**Why it matters.** Storage grows quietly: every checkpoint, log line, and dataset copy stays forever
unless someone deletes it. Unlike compute, it never scales down on its own.

**In plain words.** A family home's attic. Things go up and never come down, until the attic is full of
boxes nobody remembers. A rule like "label every box with a throw-away date, and move old boxes to the
cheap storage unit" keeps it under control.

**Architecture: data lifecycle for ML artifacts.**

```mermaid
flowchart LR
  NEW["New object<br/>Standard"] -->|"30 days without access"| IA["Infrequent Access<br/>about half price"]
  IA -->|"90 days"| ARC["Glacier IR / Archive<br/>about one fifth or less"]
  ARC -->|"retention ends"| DEL[Delete]
  CK["Checkpoints"] --> POL{"Retention policy"}
  POL -->|"keep last 3 + milestones"| NEW
  POL -->|"others"| DEL
  LOGS["Training and app logs"] -->|"7 to 30 days hot"| ARC
```

**How to read it:** new objects start in the standard tier and move down to cheaper tiers as they go
unaccessed, until their retention period ends. Checkpoints and logs get explicit policies: keep only what
you'll realistically use, and archive or delete the rest automatically.

In the diagram, **Standard**, **Infrequent Access**, and **Glacier IR** (Instant Retrieval) are S3 storage classes,
each cheaper to store but costlier to read than the one before. **Archive** classes (Glacier Deep Archive, GCS
Archive) are the cheapest and take hours to restore. **Milestones** are checkpoints you keep forever on purpose,
such as the one behind a released model.

**Core ideas.**

| Data | Policy that usually works |
|---|---|
| Training checkpoints | Keep the last 3 plus milestone checkpoints (best and final). Delete the rest when the run ends |
| Registered model versions | Keep all production versions and their run artifacts. Expire unregistered runs after ~90 days |
| Raw datasets | Keep (they're the source of truth), but in compressed columnar formats, tiered after 30–90 days |
| Derived datasets and features | Rebuildable from raw, so keep short retention, or only pinned snapshots |
| Logs | 7–30 days hot, then archive or delete. Sample debug logs |
| Block volumes and snapshots | Delete unattached volumes. Expire snapshots by policy |

```json
{ "Rules": [
  { "ID": "checkpoints-expire", "Filter": { "Prefix": "checkpoints/" }, "Status": "Enabled",
    "Expiration": { "Days": 30 }, "NoncurrentVersionExpiration": { "NoncurrentDays": 7 } },
  { "ID": "datasets-tier", "Filter": { "Prefix": "datasets/raw/" }, "Status": "Enabled",
    "Transitions": [ { "Days": 30, "StorageClass": "STANDARD_IA" }, { "Days": 90, "StorageClass": "GLACIER_IR" } ] }
] }
```

- **Formats matter.** CSV to Parquet with zstd compression often cuts size 5–10× and speeds up reads.
- **Intelligent-Tiering** (S3) or Autoclass (GCS) automate tiering when access patterns are unknown, for
  a small monitoring fee per object. That fee makes it bad for millions of tiny objects.
- Remember retrieval fees and minimum durations (Section 6). Don't tier hot training data.
- Incomplete multipart uploads silently cost money. Add an `AbortIncompleteMultipartUpload` rule.

**Example: checkpoint sprawl.** A research bucket had grown to 1.4 PB, mostly checkpoints from
experiments: some runs had saved a 140 GB checkpoint every 500 steps and kept all of them. A policy of
keeping the last 3 plus the best checkpoint per run, deleting checkpoints of runs older than 60 days unless
the model was registered, and tiering raw datasets cut the bucket to 410 TB, about $23,000 a month less.

**Senior / FAANG best practice.** Every bucket and prefix has an owner, a data class, and a lifecycle
policy defined in infrastructure as code. Buckets without a policy fail a compliance check. Run storage
reviews quarterly with "top 10 prefixes by growth". Tie retention to lineage (Section 9): keep exactly
what's needed to rebuild production models and meet legal holds, and nothing else.

---

## Lecture 83 — Multi-tenant cost allocation in teams

**Why it matters.** When the bill is one big number, nobody feels responsible for it. Allocating cost
to teams and services, including shared and idle costs, turns spending into decisions that the people
who cause it can act on.

**In plain words.** A shared apartment's utility bill. Splitting it equally annoys the roommate who's
never home, and nobody turns off the heater. Fitting a meter in each room (tags and labels), splitting the
shared hallway fairly (shared costs), and showing everyone their own number changes behavior.

**Architecture: from bill to team showback.**

```mermaid
flowchart TB
  BILL[(Cloud billing export)] --> JOIN[Cost allocation engine<br/>OpenCost, Kubecost, CUDOS, internal]
  TAGS["Account / project per team,<br/>tags: team, service, env"] --> JOIN
  K8S["Kubernetes labels:<br/>namespace to team"] --> JOIN
  JOIN --> DIRECT["Direct costs<br/>a team's own resources"]
  JOIN --> SHARED["Shared costs<br/>control plane, monitoring, idle capacity"]
  SHARED -->|"split by share of usage"| TEAMS
  DIRECT --> TEAMS["Per-team report:<br/>cost, budget, trend,<br/>cost per 1k predictions"]
  TEAMS --> BUD["Budgets + anomaly alerts<br/>to team owners"]
```

**How to read it:** raw billing data is joined with ownership information: accounts per team, resource
tags, and Kubernetes labels. Costs a team clearly caused are assigned directly. Shared costs (the cluster
control plane, monitoring, unallocated idle capacity) are split by each team's share of usage. Every team
sees its own numbers, budget, and unit costs, and gets its own alerts.

In the diagram, **CUDOS** (Cost and Usage Dashboards Operations Solution) is AWS's open-source set of cost
dashboards built on the billing export. An **account / project per team** means each team's resources live in
their own AWS account or Google Cloud project, the cleanest way to separate costs. **env** is the environment tag
(dev, staging, prod).

**Core ideas.**

| Practice | Detail |
|---|---|
| Tagging standard | Mandatory `team`, `service`, `env`, `cost-center`. Enforced by policy (SCPs, Kyverno, IaC checks) |
| Account or project per team | The cleanest allocation boundary for cloud resources |
| Namespace per team | The boundary inside shared Kubernetes clusters |
| Shared-cost rules | Split by usage share (CPU, GPU-hours), or a fixed overhead percentage, documented |
| Idle capacity | Show it explicitly ("cluster idle: 18%"), then allocate it or charge it to the platform |
| Showback vs chargeback | Showback reports costs. Chargeback moves budgets. Start with showback |
| Internal rates | Publish a GPU-hour price per type, so teams compare options easily |
| Unit costs | Cost per 1,000 predictions, per training run, per active customer |

- **Untagged spend** is a metric to drive toward zero (under ~5%), reported weekly.
- **Budgets with forecast alerts** ("on track to exceed budget by 20%") are more useful than alerts after
  the overspend.

**Example: what showback changed.** A platform team shared one 300-GPU cluster among 12 teams, and costs
were reported as one total. After introducing namespace-based showback with idle capacity charged to
teams by reserved quota, two teams discovered they held 70 GPUs of reserved quota they rarely used. They
released it, and quarterly GPU spend fell 19% without any technical change.

**Senior / FAANG best practice.** Allocation must be **trusted**: documented rules, reconciled with the
invoice each month (allocated total = billed total), and owned by a FinOps function with engineering
partners. Put unit cost on every service dashboard, and include cost in design reviews ("what will this
cost per month at launch and at 10×?").

---

## Lecture 84 — Lab: optimize cloud AI workload costs

**Goal:** model the monthly cost of an AI workload, apply four levers and measure each one's saving,
detect a cost spike in billing data and attribute it, then set up a real budget alert and find idle
resources in a cluster.

**What you're building.**

```mermaid
flowchart LR
  CALC["Part 1: cost model<br/>training, inference, storage, egress"] --> LEV["Apply levers<br/>spot + reserved, autoscale,<br/>lifecycle, CDN"]
  LEV --> CMP["Before vs after table"]
  BILL["Part 2: 30 days of billing<br/>by team and service"] --> DET["Detect anomaly<br/>3 sd over 14 normal days"]
  DET --> ATTR["Attribute to team and service,<br/>suggest the fix"]
  ATTR --> ACT["Part 3: real budget alert +<br/>idle GPU check"]
```

**In plain words.** You build the spreadsheet a FinOps engineer would build, then act on it as an
on-call engineer would when the alert fires.

**How to read the diagram:** part 1 builds a cost model (training, inference, storage, and **egress**, data leaving
the cloud), applies the savings levers, and compares before and after. Part 2 scans 30 days of bills and flags a
day more than 3 **sd** (standard deviations, a measure of normal day-to-day variation) above the average of the 14
normal days before it, then finds which team and service caused it. Part 3 sets up a real budget alert and a check
for idle GPUs. **FinOps** is the practice of managing cloud spending as a shared engineering and finance job.

### Step 1 — Model the bill and apply the levers

```bash
python3 exercises/s12_cost_tools.py --calc
```

Read each lever's line. Change one assumption in the script, such as the spot share or the night-time
replica count, and rerun to see how sensitive the total is.

### Step 2 — Investigate a spike

```bash
python3 exercises/s12_cost_tools.py --spike
```

The sample data contains two incidents: idle GPU notebooks from the 26th, and a NAT gateway surge from
the 27th. Read the attribution. Then export a real month of billing data (AWS Cost Explorer or the
GCP billing export, grouped by tag and service) into `date,team,service,cost` columns, and run
`--spike --csv billing.csv` on it.

### Step 3 — Create a budget with a forecast alert (AWS example)

```bash
aws budgets create-budget --account-id 123456789012 --budget '{
  "BudgetName": "ml-team-gpu", "BudgetLimit": {"Amount": "20000", "Unit": "USD"},
  "TimeUnit": "MONTHLY", "BudgetType": "COST",
  "CostFilters": {"TagKeyValue": ["user:team$ml"]} }' \
  --notifications-with-subscribers '[{
  "Notification": {"NotificationType": "FORECASTED", "ComparisonOperator": "GREATER_THAN", "Threshold": 100},
  "Subscribers": [{"SubscriptionType": "EMAIL", "Address": "ml-oncall@example.com"}] }]'
```

On GCP, use `gcloud billing budgets create` with a `--threshold-rule=percent=1.0,basis=forecasted-spend`.

### Step 4 — Find idle GPUs and padded requests in a cluster

With Prometheus and the DCGM exporter installed (Section 16 sets them up), run the two PromQL queries
from Lecture 81. On Minikube without GPUs, install OpenCost
(`helm install opencost opencost/opencost -n opencost --create-namespace`), and look at cost by namespace
for the Section 5 and 11 workloads.

**Expected results:**
- **Step 1** shows the monthly total falling from about $99,500 to about $56,200 (−43%), with training
  the largest saving in dollars, and storage and inference each saving 35–40%.
- **Step 2** flags 26–30 October, with no false alarms. It names `research / notebooks-gpu` as the top
  contributor from the 26th, adds `platform / nat-gateway` from the 27th, and estimates the cost of
  missing it for a month.
- **Step 3** creates a budget that alerts on forecast.
- **Step 4** lists any GPU pod idle for 2 hours, and each namespace's request-to-usage ratio.
- **The demo** prints five `PASS` lines.

---

## Assessment — Calculate AI cloud workload cost

**Task.** A team runs:
- training on 64 H100s for two weeks a month;
- an inference API sized for a peak of 12 L4 replicas;
- 200 TB in object storage;
- 20 TB a month of internet egress.

Calculate the monthly cost, then propose and price changes that cut it by at least 40% without risking the
SLOs.

**Model answer.** Run `python3 exercises/s12_cost_tools.py --calc`
([solution](../exercises/s12_cost_tools.py)). Prices are illustrative.

| Line | Before | Change | After | Saving |
|---|---|---|---|---|
| Training: 21,504 H100-hours | $86,016 (on-demand, $4.00) | 40% reserved ($2.60) + 60% spot ($1.80, +10% rework) | $47,911 | 44% |
| Inference: L4 at $0.80/h | $6,912 (12 replicas × 24 h × 30) | Autoscale 12 / 6 / 2 replicas by time of day | $4,320 | 38% |
| Storage: 200 TB | $4,710 (all Standard) | 40% Standard, 40% IA, 20% Glacier IR (cold data only) | $3,072 | 35% |
| Egress: 20 TB | $1,843 | CDN caching + compression halves the bytes | $922 | 50% |
| **Total** | **$99,482** | | **$56,225** | **43%** |

**Risks to state:**
- **Spot** requires checkpointing every ~15–20 minutes, and diversified instance types.
- **Autoscaling** needs a warm buffer, so the morning ramp doesn't break the p95.
- **Tiering** must leave hot training data in Standard (Section 6 retrieval fees).
- **Reservations** commit money for a year, so size them from the steady baseline only.

---

## Assessment — Control an unexpected AI infrastructure cost spike

**Task.** The daily cloud bill jumps from ~$6,700 to ~$9,600, then ~$11,000. Detect it, find the cause,
stop the bleeding, and prevent it from happening again.

**Model answer.** Run `python3 exercises/s12_cost_tools.py --spike`.

| Phase | Action in this incident |
|---|---|
| Detect | The anomaly rule (daily total above mean + 3 sd of the last 14 normal days) fires on 26 October, the first bad day |
| Attribute | By team and service: `research / notebooks-gpu` +$2,900 a day from the 26th, `platform / nat-gateway` +$1,400 a day from the 27th |
| Contain (hours) | Stop idle notebooks (owners notified first). Scale the churning deployment to stable replicas. Temporarily cap the autoscaler's maximum |
| Root cause | Notebooks: no idle shutdown, over a long weekend. NAT: a new autoscaler policy churned pods, and each new pod downloaded 15 GB of weights from the internet through NAT |
| Fix (days) | Idle-shutdown policy and per-user GPU quota. Weights served from S3 through a VPC endpoint and a node-local cache. Autoscaler cooldown |
| Prevent | Budgets with forecast alerts per team. Anomaly detection per team and service, not just the total. Tagging enforcement. A cost review in the deploy checklist for autoscaling changes |

Missed for a month, this incident would have cost roughly $130,000. Caught on day one, it cost about $3,000.

---

## FAANG deep-dive notes

**How big tech does it.** Cost is managed like reliability: every resource has an owner through
accounts, tags, and labels; FinOps teams reconcile allocation to invoices; capacity is a portfolio of
reserved, on-demand, and spot sized from usage history; services publish unit costs; anomaly detection runs
per team and service; and design reviews include a cost model. GPU fleets are measured on allocated vs used
hours, with utilization targets per pool.

**Staff review questions.**
- What is our cost per unit of work (per 1k predictions, per training run), and how has it trended this quarter?
- What share of GPU-hours is allocated but idle, and who owns it?
- How much of our steady baseline is covered by commitments, and how much is over-committed?
- How fast would we notice a $5,000-a-day spike, and who would get paged?

**Interview question.** "Our AI cloud bill went from $1.2M to $2.1M a month in a quarter. What do you do?"

**Typical system-design prompt:** *Design a cost governance and optimization program for an AI platform
spending $2.1M a month (65% GPUs), aiming to cut unit costs by 30% in two quarters without hurting
product SLOs.*

**1. Clarify first:** How is spend split between training, inference, storage, and network? Which of the
growth is real traffic or new products, and which is waste? What commitments exist today? Which SLOs are
critical? Do teams see their own costs today?

**2. Back-of-envelope sizing:**
- GPUs: $2.1M × 65% ≈ $1.37M a month. If 25% of allocated GPU-hours are idle, ~$340k a month is
  recoverable through hygiene alone.
- Commitments: if the steady baseline is 60% of GPU spend, ~$820k a month, and 1-year commitments
  save ~35%, that's ~$290k a month.
- Spot: moving half of training (say $300k a month) to spot at ~65% off, minus ~5% rework, saves ~$180k a month.
- Inference: autoscaling plus batching and quantization commonly cut serving GPU-hours by 30–50%.
- Combined, this is plausibly $700k–$900k a month, ~35–40% off, while traffic keeps growing.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Commitments | Commit high for the biggest discount | Commit to the low-water mark | Commit to the steady baseline. Flexibility is worth the difference |
| Spot | Maximize spot | Spot only for tolerant tiers | Only checkpointed, restartable jobs, with diversified instance types |
| Visibility | Central FinOps reports | Team-owned dashboards and alerts | Team-owned. People fix what they see and own |
| Allocation | Showback | Chargeback | Showback first. Chargeback once allocation is trusted |
| Inference savings | Smaller hardware | Model efficiency (quantize, batch, distill) | Both. Efficiency often saves more and compounds |

**4. Follow-up questions with crisp answers:**
- *How do you avoid hurting SLOs while cutting?* Change one lever at a time, behind canaries, with
  SLO-based autoscaling and warm headroom. Track unit cost and p95 side by side.
- *How do you handle shared cluster costs?* Allocate them by usage share, show idle explicitly, and
  reconcile to the invoice monthly.
- *What do you do in the first week?* Enforce tagging, publish allocated-vs-used GPU reports by team,
  kill the obvious idle resources, and set budgets and anomaly alerts. That's quick wins plus visibility.

**Debug this (common onsite question):** "The NAT gateway line item went from $5,000 to $43,000 a month, and
nothing changed in the product."
1. Break NAT cost into data processed vs hours: almost all of it is data processed, up ~9×.
2. Find the traffic with VPC Flow Logs, grouped by source pod IP and destination: the inference pods are
   downloading from `huggingface.co` and the public PyPI.
3. Correlate with deployments: an autoscaler change two weeks earlier made pods scale up and down
   every few minutes, and each new pod downloads 15 GB of weights at startup.
4. Fix: mirror the weights into S3 and read them through a VPC gateway endpoint (no NAT charge),
   add a node-local cache, bake packages into the image, add autoscaler cooldowns, and alert on NAT bytes
   per hour.

The lesson: data movement is a hidden cost multiplier. Every download at pod startup is paid on every
scale-up, so keep artifacts close and private.

**5. What separates senior from staff answers:** a senior engineer finds and fixes waste: idle resources,
rightsizing, spot, lifecycle rules. A staff engineer builds the operating system for cost: ownership
and allocation that people trust, unit-cost metrics on dashboards, a capacity portfolio sized from data,
per-team anomaly detection, cost in design reviews, and incentives that keep savings from decaying.

**Red flags:**
- No tags, or most spend untagged and unowned.
- Spot for jobs that can't checkpoint, or commitments sized to the peak.
- Fixed peak capacity for variable inference traffic.
- Storage with no lifecycle or retention policies.
- Cost reviewed only when the invoice arrives.

---

## Quiz

<details><summary>1. Name four common causes of AI cost spikes.</summary>
Idle or forgotten GPU resources (notebooks, dev VMs), fixed peak capacity instead of autoscaling,
data movement (cross-region, NAT, egress), and runaway automation (retry loops, unbounded sweeps or
autoscaling). Also storage sprawl, and unpriced growth such as token usage.
</details>

<details><summary>2. Checkpoints every 20 minutes, restarts take 5 minutes, 4 spot interruptions a day. What is the overhead?</summary>
Each interruption loses ~10 minutes of work on average plus 5 minutes of restart = 15 minutes. 4 × 15 = 60
minutes a day, ~4% of the time. Small compared with a 60–90% spot discount.
</details>

<details><summary>3. Why is CPU utilization a poor autoscaling signal for a GPU inference server?</summary>
The work happens on the GPU. CPU can stay low while requests queue. Scale on queue depth, in-flight
requests, or tokens per second instead.
</details>

<details><summary>4. What do "requested", "allocated", and "used" mean for GPUs, and where does waste hide?</summary>
Requested is what pods ask for. Allocated is what the scheduler assigned. Used is the actual activity
(DCGM SM activity). Waste hides between allocated and used: GPUs held by idle or barely active pods.
</details>

<details><summary>5. Give a sensible checkpoint retention policy.</summary>
Keep the last few (e.g., 3) plus milestone checkpoints (best and final) per run. Delete the others when the
run ends. Delete checkpoints of old unregistered runs after a set period.
</details>

<details><summary>6. What's the difference between showback and chargeback?</summary>
Showback reports each team's costs. Chargeback moves money or budget between teams based on them.
Showback usually comes first, until the allocation is trusted.
</details>

<details><summary>7. Why must anomaly detection exclude anomalous days from its baseline?</summary>
Otherwise the spike raises the mean and spread of the baseline, and the following days of the same
incident look normal and go unflagged.
</details>

<details><summary>8. How do you size reserved or committed capacity?</summary>
From the steady baseline, the low-water mark of usage over the last 6–12 months, not the peak. Cover
bursts with on-demand and spot.
</details>

## Failure modes
- Idle GPU notebooks and dev VMs running for days with nobody noticing.
- Inference fleets sized for peak 24/7, or autoscalers without maximums.
- Spot used for jobs without checkpoints, losing hours on every interruption.
- Hidden data-movement costs: cross-region reads, NAT downloads at every pod start, internet egress.
- Storage growing forever: checkpoints, logs, snapshots, unattached volumes.
- Untagged spend, and shared clusters reported as one number.
- Commitments sized to the peak, or never revisited as workloads change.

## Checklist
- [ ] You can list the six families of AI cost spikes and the first fix for each
- [ ] Your training jobs can run on spot with checkpoint and automatic resume
- [ ] Your inference autoscales on a demand metric, with a warm buffer and a maximum
- [ ] You have dashboards of requested vs allocated vs used GPU per team, and idle alerts
- [ ] Every bucket has a lifecycle and retention policy
- [ ] Every resource is tagged with team, service, and environment, and teams see their own costs
- [ ] You ran `exercises/s12_cost_tools.py` and can explain both assessments' answers
