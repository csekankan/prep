# Part III — MLOps, CI/CD and Cost (Sections 9–12, lectures 57–84)

How models are tracked, tested, released, scheduled on Kubernetes, and paid for.

| § | Section | You will be able to | Exercise |
|---|---|---|---|
| 9 | [Workflow Automation and Experiment Tracking](s09_experiment_tracking.md) | Run MLflow for a team, log and version everything a model depends on, choose MLflow vs W&B, automate retraining | [`s09_experiment_record.py`](../exercises/s09_experiment_record.py) |
| 10 | [CI/CD for AI Models](s10_cicd_for_ai.md) | Build ML pipelines in GitHub Actions, GitLab, or Jenkins, test models, ship by digest, canary and roll back, gate releases | [`s10_quality_gate.py`](../exercises/s10_quality_gate.py) |
| 11 | [Advanced Kubernetes for AI](s11_advanced_kubernetes.md) | Schedule GPUs without fragmentation, run StatefulSets and operators, write golden Helm charts, launch Kubeflow jobs, secure the cluster | — |
| 12 | [Resource and Cost Optimization](s12_cost_optimization.md) | Use spot and autoscaling safely, measure utilization, tier storage, allocate costs, handle a cost spike | [`s12_cost_tools.py`](../exercises/s12_cost_tools.py) |

```mermaid
flowchart LR
  P2["Part II: data, GPUs,<br/>distributed training"] --> S9["§9 Track and automate<br/>MLflow, pipelines"]
  S9 --> S10["§10 Release safely<br/>tests, gates, canaries"]
  S10 --> S11["§11 Run it on Kubernetes<br/>GPUs, operators, security"]
  S11 --> S12["§12 Pay less for it<br/>spot, autoscaling, FinOps"]
  S12 --> NEXT["Part IV: networking<br/>and serving"]
```

**How to read it:** Section 9 makes every model traceable. Section 10 uses that traceability to release
models safely. Section 11 hardens the cluster everything runs on. Section 12 keeps the whole system
affordable, and makes cost visible to the teams who spend it.
