# Section 9 — Workflow Automation and Experiment Tracking

> Lectures 57–63 • Assessment: quiz + Build a Reproducible Experiment Record
> **After this section you can:** explain why untracked experiments are a production risk, run an MLflow
> tracking server, log parameters, metrics, artifacts, and models properly, version data, models, and
> configs so any model can be rebuilt, choose between MLflow and Weights & Biases, and automate training
> as a pipeline.
>
> Go deeper: [13 / Lab 44 — MLflow model registry](../../13_sovereign_ai_infra_course/04_serving_inference/lab44_mlflow_model_registry.md)
> and [10 — LLMOps pipeline](../../10_llmops_pipeline/00_PIPELINE_FLOW.md) (curate, train, evaluate, gate, publish).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 57 | Why tracking ML experiments matters | If you can't say what data, code, and settings made a model, you can't debug, audit, or rebuild it |
| 58 | Introduction to MLflow | Tracking server + backend database + artifact store + model registry, open source and self-hostable |
| 59 | Logging metrics and artifacts | Log params once, metrics per step, artifacts and models with signatures, in batches |
| 60 | Versioning data, models, and parameters | Code in Git, data by content hash or snapshot, models in a registry with aliases, configs as files |
| 61 | Weights & Biases vs MLflow | W&B for a polished hosted experience and sweeps. MLflow for self-hosting, control, and an open registry |
| 62 | Automating training pipelines | Turn notebooks into a DAG of idempotent, cached steps triggered by schedules, data, or drift |
| 63 | Lab: track experiments with MLflow | Run a sweep, compare runs, register the best model, and load it by alias |

```mermaid
flowchart LR
  subgraph PIPE["Automated training pipeline (Airflow, Kubeflow, Argo)"]
    D[Get data<br/>pinned snapshot] --> F[Features] --> T[Train] --> E[Evaluate] --> G{Quality gate}
  end
  T -->|"params, metrics, artifacts"| TRK[MLflow tracking server]
  E -->|metrics| TRK
  TRK --> DB[(Backend store<br/>PostgreSQL: runs, params, metrics)]
  TRK --> ART[(Artifact store<br/>S3/GCS: models, plots, data hashes)]
  G -->|pass| REG[Model registry<br/>version 7, alias: challenger]
  REG -->|promote| SERVE[Serving: loads models:/fraud@champion]
  GIT[(Git commit)] -.recorded in.-> TRK
  SNAP[(Data snapshot ID)] -.recorded in.-> TRK
```

**How to read it:** a pipeline runs the steps from data to evaluation. Each step reports to the tracking
server, which stores small structured data (parameters, metrics) in a database and large files
(models, plots) in object storage. Every run also records the Git commit and data snapshot it used. A
model that passes the quality gate becomes a new version in the **registry**, and serving loads whatever
version carries the `champion` alias. Promoting or rolling back is just moving an alias.

**Terms in this diagram.**
- **Airflow, Kubeflow, Argo**: workflow engines that run multi-step pipelines on a schedule and retry failed steps.
  **Apache Airflow** is the most common general-purpose one. **Kubeflow Pipelines** and **Argo Workflows** run each
  step as a container on Kubernetes (Lecture 62).
- **Pinned snapshot**: a fixed, named version of the data, so rerunning the pipeline reads exactly the same rows.
- **Params, metrics, artifacts**: **parameters** are the settings you chose (learning rate, tree depth).
  **Metrics** are measured results (loss, accuracy, AUC). **Artifacts** are output files (the model, plots).
- **Backend store** and **artifact store**: MLflow keeps small records in a database (PostgreSQL) and big files in
  object storage (S3 or GCS).
- **Data hashes**: fingerprints of the training data files, proving which exact data was used.
- **Alias: challenger** and **champion**: named pointers to model versions. **Champion** is the version in
  production. **Challenger** is a new candidate being evaluated against it.
- **models:/fraud@champion**: MLflow's address format meaning "the version of model `fraud` that currently carries
  the alias `champion`".

---

## Lecture 57 — Why tracking ML experiments matters

**Why it matters.** ML code is only half of a model. The rest is the data, hyperparameters, random seed,
and library versions. Without a record of all of them, a model in production is a black box: you can't
reproduce it, explain a regression, or answer an auditor.

**In plain words.** A lab notebook for scientists. A chemist who writes "mixed some stuff, it turned
blue" can never repeat the experiment. One who writes the exact amounts, temperatures, and batch numbers of
the chemicals can repeat it, and so can a colleague.

**Architecture: what defines a model.**

```mermaid
flowchart LR
  CODE["Code<br/>git commit + dirty flag"] --> RUN((Training run))
  DATA["Data<br/>snapshot ID or content hash"] --> RUN
  PARAMS["Config<br/>hyperparameters + seed"] --> RUN
  ENV["Environment<br/>image digest, library versions, GPU type"] --> RUN
  RUN --> MODEL["Model artifact<br/>+ content hash"]
  RUN --> METRICS["Metrics<br/>per step and final"]
  MODEL --> LINEAGE[("Lineage record:<br/>this model came from exactly these inputs")]
  METRICS --> LINEAGE
```

**How to read it:** four inputs (code, data, configuration, environment) go into a run, and a model and
its metrics come out. If you record all four inputs and a hash of the output, the lineage record is
complete, and you can rebuild that model or explain how it differs from another.

In the diagram, the **dirty flag** records whether the code had uncommitted changes when the run started (if it
did, the commit alone doesn't describe the code). **Hyperparameters** are training settings chosen before
training, such as learning rate and batch size. The **seed** is the starting number for random-number
generators, fixing shuffling and initialization. The **image digest** identifies the exact container image. A
**content hash** is a fingerprint of the bytes, and **lineage** is the full record of what went in.

**Core ideas.**

| Without tracking | With tracking |
|---|---|
| "Which run produced the model in prod?" Nobody knows | The registry version points to the run, commit, and data snapshot |
| A new model is worse, and the cause is unknown | Diff two runs: a parameter, the data, or a library changed |
| Best results live in one person's notebook | Results are shared, searchable, and comparable |
| Audit asks what data trained the model | Lineage answers it in minutes |
| Retraining gives different results | Seeds, data hashes, and environment are pinned |

- Track **every** run, including the failures. Failed runs teach the team what not to try again.
- **Determinism has limits.** Some GPU kernels are non-deterministic (atomic adds in parallel). Use
  `torch.use_deterministic_algorithms(True)` when you need bit-exact reruns, and accept small variance
  otherwise, but always record the seed.
- Regulations such as the EU AI Act require documentation and traceability for high-risk systems.
  Tracking is how you produce that evidence.

**Example: the regression nobody could explain.** A ranking model's click-through rate dropped 4% after
a retrain. The team spent a week reviewing code changes. Once runs were tracked, a diff of the old and new
records showed the code and parameters were identical, but the data hash differed. An upstream job had
started deduplicating sessions, cutting positive examples by 18%. With tracking in place, the next
regression like it took 20 minutes to find.

**Senior / FAANG best practice.** Make tracking automatic and mandatory, not optional. The training
template or platform logs the commit, data snapshot, image digest, and config for every run. Production
deployments are only allowed from registry versions with complete lineage. Big-tech ML platforms treat
"can we rebuild this model?" as a release requirement.

---

## Lecture 58 — Introduction to MLflow

**Why it matters.** MLflow is the most widely used open-source platform for experiment tracking and model
registries, and it's built into Databricks, SageMaker, and Azure ML. Knowing its architecture lets you run
it reliably for a whole team.

**In plain words.** MLflow is a library catalog for models. The tracking server is the front desk, the
database is the card catalog (what each run was, and its numbers), the artifact store is the shelves
(the actual model files), and the registry is the "staff picks" display, showing which version is
currently recommended.

**Architecture: a production MLflow deployment.**

```mermaid
flowchart LR
  subgraph CLIENTS["Clients"]
    NB[Notebooks]
    JOBS[Training jobs]
    CI[CI pipeline]
  end
  NB & JOBS & CI -->|"REST over HTTPS,<br/>MLFLOW_TRACKING_URI"| SRV["MLflow tracking server<br/>2+ replicas behind a load balancer<br/>SSO / auth proxy"]
  SRV --> PG[("PostgreSQL<br/>experiments, runs, params,<br/>metrics, registry")]
  SRV -->|"artifact proxy, or clients<br/>write direct with IAM"| S3[("S3 / GCS / MinIO<br/>models, plots, logs")]
  SRV --> UI[Web UI: compare runs,<br/>charts, registry]
  SERVE[Model servers] -->|"load models:/name@champion"| S3
```

**How to read it:** clients talk to the tracking server over REST. The server writes structured data to
PostgreSQL and files to object storage. With the artifact proxy, the server uploads files for you.
Without it, clients write straight to the bucket using their own IAM role. Model servers never call the
training clients: they resolve a registry alias to a model version and load its files from object storage.

**Terms in this diagram.**
- **REST over HTTPS**: the clients call the server's web API with ordinary HTTPS requests.
- **MLFLOW_TRACKING_URI**: the environment variable that tells every MLflow client where the server is, for
  example `https://mlflow.internal.example.com`.
- **2+ replicas behind a load balancer**: at least two copies of the server, so one can fail or be upgraded
  without an outage.
- **SSO / auth proxy**: **SSO** (single sign-on) means people log in with their company account. An **auth proxy**
  (for example oauth2-proxy) sits in front of MLflow and checks that login, because open-source MLflow has only
  basic built-in authentication.
- **Artifact proxy**: a mode where the server itself uploads and downloads artifacts for clients, so clients need
  no bucket credentials.
- **MinIO**: open-source object storage that speaks the S3 API, often used on-premises or for local labs.

**Core ideas.**

| Component | What it does |
|---|---|
| Tracking | Runs grouped into experiments, holding params, metrics (with step and time), tags, and artifacts |
| Models | A standard model format (`MLmodel` file + flavors such as `sklearn`, `pytorch`, `transformers`, `pyfunc`), with a signature and an input example |
| Model registry | Named models with numbered versions, aliases (`champion`, `challenger`), tags, and descriptions |
| Evaluation and tracing | `mlflow.evaluate` and LLM tracing for GenAI apps (Section 25) |

```bash
pip install mlflow psycopg2-binary boto3
mlflow server --backend-store-uri postgresql://mlflow:***@db:5432/mlflow \
              --artifacts-destination s3://ml-artifacts/mlflow --host 0.0.0.0 --port 5000
export MLFLOW_TRACKING_URI=https://mlflow.internal.example.com
```

- The default local mode (`./mlruns` folder, or SQLite) is fine for one person. Teams need PostgreSQL or
  MySQL plus object storage.
- MLflow itself has no full user management. Put SSO in front of it (an OAuth proxy or a cloud
  identity-aware proxy), or use a managed MLflow (Databricks, SageMaker, Azure ML).
- Registry **aliases** (MLflow 2.9+) replace the older fixed stages ("Staging", "Production"). Serving code
  refers to `models:/fraud@champion`, and promotion moves the alias.

**Example: one shared server instead of many laptops.** A 25-person team had results scattered across
laptop `mlruns` folders. A shared MLflow on Kubernetes (2 replicas, RDS PostgreSQL, an S3 bucket, SSO
via an OAuth proxy) cost about $250 a month. The weekly model review went from screenshots to
comparing runs side by side in the UI, and every production model got a registry version that linked to
its run.

**Senior / FAANG best practice.** Run the tracking server like any production service: replicas, managed
PostgreSQL with backups, an artifact bucket with versioning and lifecycle rules, authentication, and
monitoring. Separate experiments by team, with naming conventions. Restrict who can move the `champion`
alias, preferably only CI after a quality gate (Section 10).

---

## Lecture 59 — Logging metrics and artifacts

**Why it matters.** What you log decides what you can debug later. Logging too little leaves gaps.
Logging too much, or too often, slows training and overloads the tracking server.

**In plain words.** A flight recorder. It records altitude and speed continuously (metrics per step), the
flight plan once (parameters), and keeps the final maintenance report (artifacts). It doesn't film every
passenger's seat, which would be too much data to be useful.

**Architecture: a training loop that logs well.**

```mermaid
sequenceDiagram
  participant Job as Training job
  participant ML as MLflow client
  participant Srv as Tracking server
  participant S3 as Artifact store
  Job->>ML: start_run, set_tags commit, data snapshot, image
  Job->>ML: log_params lr, batch, seed, model size
  loop every 50 steps
    Job->>ML: log_metrics loss, lr, grad_norm with step
    ML->>Srv: batched, async
  end
  Job->>ML: log_metrics final eval
  Job->>ML: log_model with signature and input example
  ML->>S3: model files, plots, confusion matrix
  ML->>Srv: run status FINISHED
```

**How to read it:** context (tags and params) is logged once at the start. Metrics are logged in batches at
a sensible interval, asynchronously, so logging never blocks the GPU. At the end, the model goes into the
artifact store with its signature (input and output schema) and an example input, so anyone can load
and call it correctly later.

In the diagram, `start_run`, `set_tags`, `log_params`, `log_metrics`, and `log_model` are MLflow's Python
functions. **Tags** are free-form labels on a run (commit, data snapshot, image). **lr** is the learning rate.
**grad_norm** is the size of the gradient vector, and a sudden spike warns of unstable training. A **confusion
matrix** is a table of predicted versus actual classes, showing which classes the model mixes up. `FINISHED` is
the run status the server shows once logging is complete.

**Core ideas.**

```python
import mlflow, mlflow.sklearn
from sklearn.ensemble import GradientBoostingClassifier
from mlflow.models import infer_signature

mlflow.set_experiment("fraud-gbm")
with mlflow.start_run(run_name="gbm-depth4") as run:
    mlflow.set_tags({"git_commit": commit, "data_snapshot": snapshot_id, "owner": "risk-ml"})
    params = {"n_estimators": 300, "max_depth": 4, "learning_rate": 0.05, "random_state": 42}
    mlflow.log_params(params)
    model = GradientBoostingClassifier(**params).fit(X_train, y_train)
    for i, score in enumerate(model.staged_score(X_val, y_val)):    # metric per step
        if i % 10 == 0:
            mlflow.log_metric("val_accuracy", score, step=i)
    mlflow.log_metrics({"val_auc": auc, "val_recall_at_1pct_fpr": recall})
    mlflow.log_figure(roc_figure, "plots/roc.png")
    mlflow.sklearn.log_model(model, "model", signature=infer_signature(X_val, model.predict_proba(X_val)),
                             input_example=X_val[:5])
```

| Log | How | Examples |
|---|---|---|
| Params | Once, at the start | Hyperparameters, seed, dataset ID, model size |
| Tags | Once | Git commit, data snapshot, image digest, owner, ticket |
| Metrics | Per step or epoch, in batches | Loss, learning rate, gradient norm, throughput, validation scores |
| Artifacts | At checkpoints or the end | Model, plots, confusion matrix, evaluation tables, sample predictions |
| System metrics | Background | GPU utilization and memory, CPU, I/O (`mlflow.enable_system_metrics_logging()`) |

- `mlflow.autolog()` captures params, metrics, and the model for common frameworks with one line. It's great
  for getting started, but add your own tags for lineage.
- Log metrics at a sensible rate: every 10–100 steps, not every step of a million-step run.
- Log **business metrics** (recall at a fixed false-positive rate, revenue impact) next to the ML metrics.
  Promotion decisions use them.

**Example: the logging that slowed training by 30%.** A team called `mlflow.log_metric` for 12 metrics on
every step of a 500k-step job. That's 6 million synchronous HTTP calls, each taking ~5 ms on the training
critical path. Switching to `log_metrics` every 50 steps with asynchronous logging (MLflow 2.8+,
`synchronous=False`) removed the slowdown, and the metric charts looked the same.

**Senior / FAANG best practice.** Provide a shared logging helper in the training template, so every team
logs the same required tags and standard system metrics. Log evaluation results on fixed **golden
datasets**, so runs are comparable across months. Never log raw personal data as artifacts: log
aggregates and hashed or sampled examples that have been approved.

---

## Lecture 60 — Versioning data, models, and parameters

**Why it matters.** Git versions code well, but it can't hold a 2 TB dataset or a 15 GB model. You need a
version system for each kind of input and output, linked together, or "rebuild model v12" is impossible.

**In plain words.** A recipe book (Git, the code) is useless if the pantry changes every day and nobody
wrote down which bag of flour was used. You label every bag (data snapshots), keep finished cakes in a
labeled freezer (the model registry), and write the oven settings on the recipe card (config files).

**Architecture: the version graph.**

```mermaid
flowchart TB
  GIT["Git: code + config files<br/>commit a1b2c3"] --> RUN["Run 7f3e<br/>MLflow"]
  DV["Data version<br/>Iceberg snapshot 8812,<br/>or DVC / lakeFS commit"] --> RUN
  IMG["Container image<br/>sha256:9be1..."] --> RUN
  RUN --> MV["Registry: fraud-model v12<br/>sha256 of weights"]
  MV -->|"alias champion"| PROD[Production]
  MV -.lineage.-> RUN
  RUN -.lineage.-> GIT & DV & IMG
```

**How to read it:** each kind of artifact has its own version system, and the run is the hub that links
them. From a production model you can walk back to the exact code commit, data snapshot, and image. From
a data snapshot you can find every model trained on it, which matters when data has to be deleted.

The data-version tools in the diagram: an **Iceberg snapshot** is a numbered version of an Apache Iceberg table
that can be read again later (Section 6). **DVC** (Data Version Control) stores data versions next to Git, with
the files in object storage. **lakeFS** adds Git-like branches and commits to a whole data lake.

**Core ideas.**

| What | Tool options | Version key |
|---|---|---|
| Code and configs | Git | Commit SHA (reject dirty working trees for production runs) |
| Data (tables) | Iceberg / Delta / Hudi time travel | Snapshot ID |
| Data (files) | DVC, lakeFS, versioned buckets + manifest | Content hash or commit |
| Configs | Hydra or YAML files in Git, logged as params | Commit + a hash of the resolved config |
| Models | MLflow, SageMaker, or Vertex model registries | Version number + weights hash + aliases |
| Environment | Container image | Image digest |

```bash
# DVC: data versioned beside the code, stored in object storage
dvc init && dvc remote add -d store s3://ml-data/dvc
dvc add data/train.parquet            # writes data/train.parquet.dvc (a small pointer file with an MD5 hash)
git add data/train.parquet.dvc .gitignore && git commit -m "train data v3"
dvc push                              # uploads the data; `dvc checkout` restores it for any commit
```

- **Hash content, not names.** `train_final_v2.csv` tells you nothing. `sha256:3017…` is exact.
- Use **semantic aliases** in the registry (`champion`, `challenger`, `shadow`), not hard-coded version
  numbers in serving configs.
- Version **evaluation datasets** too, or a metric improvement may only mean an easier test set.

**Example: rebuilding a model for an audit.** A regulator asked how a credit model from 14 months
earlier was built. The registry version pointed to its run, which listed the Git commit, the Iceberg
snapshot ID (still kept by the retention policy), and the image digest. The team re-ran training and got a
model with the same metrics to four decimal places. The audit closed in two days instead of two months.

**Senior / FAANG best practice.** Make lineage a property of the platform: the pipeline refuses to train on
unversioned data or a dirty Git tree, and the registry refuses versions without a run link. Set data
retention policies with model lineage in mind: you can't reproduce a model whose snapshot has expired. Keep
a "golden" reproduction test that rebuilds a small model every week, to prove the chain still works.

---

## Lecture 61 — Weights & Biases vs MLflow comparison

**Why it matters.** The tracking tool shapes daily research workflow and long-term governance. Picking
one without understanding the trade-offs leads to painful migrations or shadow tools.

**In plain words.** MLflow is like running your own self-hosted photo server: free, under your control,
and you maintain it. Weights & Biases is a polished cloud photo service: beautiful, collaborative, and
zero maintenance, but you pay per seat and your data lives with the vendor (unless you buy their
self-hosted version).

**Architecture: where each one usually runs.**

```mermaid
flowchart LR
  subgraph SELF["Self-hosted in your VPC"]
    MLF[MLflow server] --> PG[(Postgres)]
    MLF --> S3[(Your bucket)]
  end
  subgraph SAAS["Vendor cloud, or W&B dedicated / self-managed"]
    WB[W&B server] --> WBS[(W&B storage)]
  end
  TEAM1[Training jobs] -->|MLFLOW_TRACKING_URI| MLF
  TEAM2[Research jobs] -->|WANDB_API_KEY| WB
  WB -.artifact references.-> S3
```

**How to read it:** MLflow typically runs inside your network, writing to your own database and bucket.
W&B typically runs in the vendor's cloud, although dedicated and self-managed deployments exist. W&B
artifacts can store references to files in your bucket, so the data itself doesn't have to leave.

In the diagram, **W&B** is Weights & Biases, a commercial experiment-tracking service. **Self-hosted in your VPC**
means you run the software on your own servers inside your private cloud network. **Dedicated** means the vendor
runs a single-tenant copy just for you. **WANDB_API_KEY** is the secret token W&B clients use to log in.

**Core ideas.**

| | MLflow | Weights & Biases |
|---|---|---|
| License and hosting | Open source (Apache 2.0). Self-host, or managed in Databricks, SageMaker, Azure ML | Commercial SaaS. Dedicated or self-managed options for enterprises |
| Experiment UI | Good, functional | Excellent: rich charts, reports, collaboration |
| Hyperparameter sweeps | Via Optuna, Ray Tune, or Hyperopt | Built-in sweeps (grid, random, Bayesian) |
| Model registry | Built in, open, aliases | Built in (W&B Registry) |
| LLM tracing and evaluation | MLflow Tracing, `mlflow.evaluate` | W&B Weave |
| Data governance | Everything in your account | Vendor-hosted unless you pay for dedicated |
| Cost | Infrastructure + operations time | Per seat or usage. Free tier for individuals |

- Many companies use **both**: W&B for research iteration, and MLflow (or a cloud registry) as the
  governed production registry.
- Decide on the requirements, not the brand: data residency, SSO and audit, total cost at your team size,
  and integration with your deployment pipeline.

**Example: a decision for a 40-person team.** Requirements: data must stay in the EU account, SSO is
needed, the registry must integrate with Kubernetes deployments, and the budget is tight. W&B dedicated
cloud met everything, at a much higher price. Self-hosted MLflow met everything for ~$300 a month of
infrastructure plus about two days a month of platform time. The team chose MLflow, and let two research
groups keep W&B's free academic tier for sweeps that didn't touch production data.

**Senior / FAANG best practice.** Whichever tool you choose, keep the **registry and lineage in a system
you control and can export**, because that's the governance record. Abstract logging behind a thin
internal helper, so switching tools later changes one library, not every training script. Most big-tech
companies run internal platforms that combine both ideas: a research-friendly UI on top of an
authoritative registry.

---

## Lecture 62 — Automating training pipelines

**Why it matters.** A model trained by hand in a notebook is retrained irregularly, inconsistently, and
by one person. Automated pipelines make retraining routine, testable, and auditable, which is the core
of MLOps.

**In plain words.** A bakery that only bakes when the head baker remembers, by feel, is risky. A
production bakery runs the same steps on a schedule, checks each batch, and only puts good batches on the
shelf. Pipelines are that production line for models.

**Architecture: a retraining DAG.**

```mermaid
flowchart LR
  TRIG{"Trigger:<br/>schedule, new data,<br/>drift alert, code merge"} --> V[Validate data<br/>schema, volume, nulls]
  V --> FE[Build features<br/>pinned snapshot]
  FE --> TR[Train<br/>GPU step, logs to MLflow]
  TR --> EV[Evaluate on golden<br/>and recent data]
  EV --> GATE{"Beats champion?<br/>fairness and latency OK?"}
  GATE -->|yes| REG[Register version,<br/>alias challenger]
  GATE -->|no| STOP[Stop and notify]
  REG --> CD[CD: canary rollout<br/>Section 10]
  V -->|fails| STOP
```

**How to read it:** something triggers the pipeline. Data is validated first, so bad data stops the run
before any GPU time is spent. Features are built from a pinned snapshot, the model is trained and
evaluated, and a gate compares it with the current champion. Only a better model is registered and handed
to the deployment pipeline. Every step is a separate, retryable task.

**Terms in this diagram.**
- **Drift alert**: monitoring noticed the live data changing in a way that may hurt the model (Section 17).
- **Golden and recent data**: the **golden** set is a fixed, carefully labeled evaluation set that never changes
  between runs, so scores are comparable. **Recent** data checks the model on what production looks like now.
- **Fairness and latency OK**: the candidate must not be worse for any important group of users, and must answer
  fast enough.
- **CD: canary rollout**: CD (continuous delivery) is the automated release process. A **canary rollout** first
  gives the new model a small share of real traffic, such as 5%, watches its metrics, and only then increases the
  share, rolling back automatically if they get worse. Section 10 builds it.

**Core ideas.**

| Orchestrator | Strengths | Typical home |
|---|---|---|
| Apache Airflow (MWAA, Cloud Composer) | Mature, huge ecosystem, schedules | Data-engineering-heavy teams |
| Kubeflow Pipelines | Kubernetes-native, each step a container, ML-specific UI | Kubernetes ML platforms (Section 11) |
| Argo Workflows | Kubernetes-native, general-purpose, fast | Platform teams, CI-like workflows |
| Prefect / Dagster | Python-first, good developer experience, asset lineage (Dagster) | Python teams, modern data stacks |
| SageMaker / Vertex AI Pipelines | Managed, integrated with the cloud ML stack | Teams all-in on one cloud |

```python
# Airflow: a weekly retrain DAG where each task is a container on Kubernetes
from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator as Pod
import pendulum

with DAG("fraud_retrain", schedule="@weekly", start_date=pendulum.datetime(2026, 1, 1), catchup=False) as dag:
    img = "registry.internal/fraud-train@sha256:9be1..."
    validate = Pod(task_id="validate", image=img, cmds=["python", "validate.py", "--snapshot", "{{ ds }}"])
    train = Pod(task_id="train", image=img, cmds=["python", "train.py", "--snapshot", "{{ ds }}"],
                container_resources={"limits": {"nvidia.com/gpu": "1"}}, retries=2)
    evaluate = Pod(task_id="evaluate_and_gate", image=img, cmds=["python", "gate.py"])
    validate >> train >> evaluate
```

- **Steps must be idempotent** (Section 6): rerunning a step for the same date gives the same output.
- **Cache** expensive steps keyed by their inputs. If features for a snapshot exist, reuse them.
- Pass **references**, not data, between steps: an S3 path plus a hash, never a 5 GB DataFrame through
  the orchestrator's database.

**Example: from notebook to weekly pipeline.** A churn model was retrained by hand "when someone had
time", which was about every four months, and its accuracy decayed in between. A weekly Airflow
pipeline with a data-validation step and a champion comparison retrained it every Sunday. In the first
quarter, the data check blocked two bad upstream loads, and the gate rejected three candidates. The model's
average accuracy over the quarter rose by 6 points.

**Senior / FAANG best practice.** Pipelines are code: reviewed, tested in CI on a small sample, and
deployed from Git. Every step runs in a pinned image, with resource requests and retries. The pipeline
emits lineage and a summary to the registry. Alert on pipeline **freshness** (the last successful run),
not just failures, because a silently stopped pipeline is the most common failure of all.

---

## Lecture 63 — Lab: track experiments with MLflow

**Goal:** run a local MLflow server with a SQLite backend, log a small hyperparameter sweep with
lineage tags, compare runs in the UI, register the best model, give it the `champion` alias, and load it
by alias, the way a serving system would.

**What you're building.**

```mermaid
flowchart LR
  SWEEP["sweep.py<br/>6 runs: depth x learning rate"] -->|log| SRV["mlflow server :5000<br/>sqlite + ./mlartifacts"]
  SRV --> UI[UI: compare runs]
  UI --> PICK[Pick best by val_auc]
  PICK --> REG["Register: wine-quality v1<br/>alias champion"]
  REG --> LOAD["load_model('models:/wine-quality@champion')<br/>predict"]
```

**In plain words.** You run six experiments, let MLflow keep the lab notebook, choose the winner from a
chart instead of from memory, and hand it to "production" by name.

**How to read the diagram:** `sweep.py` trains six models, every combination of 3 tree depths and 2 learning
rates (a small **sweep**, or grid search). Each run logs to a local MLflow server on port 5000, which keeps its
records in a **SQLite** file (a database stored in a single file) and the model files in `./mlartifacts`. You
compare runs in the UI, pick the one with the best **val_auc** (AUC on the validation set, where 1.0 is perfect
ranking and 0.5 is random guessing), register it as `wine-quality` version 1 with the alias `champion`, and load it
by that name to predict.

### Step 1 — Start the server

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install "mlflow>=2.12" scikit-learn pandas
mlflow server --backend-store-uri sqlite:///mlflow.db --artifacts-destination ./mlartifacts \
              --host 127.0.0.1 --port 5000
# open http://127.0.0.1:5000
```

### Step 2 — Run a sweep with lineage tags (`sweep.py`)

```python
import hashlib, itertools, subprocess, mlflow, mlflow.sklearn
from sklearn.datasets import load_wine
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split
from mlflow.models import infer_signature

mlflow.set_tracking_uri("http://127.0.0.1:5000")
mlflow.set_experiment("wine-quality")
X, y = load_wine(return_X_y=True, as_frame=True)
y = (y == 0).astype(int)                                   # binary: class 0 vs rest
data_hash = hashlib.sha256(X.to_csv().encode()).hexdigest()
commit = subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip() or "none"
X_tr, X_val, y_tr, y_val = train_test_split(X, y, test_size=0.3, random_state=0, stratify=y)

for depth, lr in itertools.product([2, 3, 4], [0.05, 0.2]):
    with mlflow.start_run(run_name=f"d{depth}-lr{lr}"):
        mlflow.set_tags({"git_commit": commit, "data_sha256": data_hash})
        params = {"max_depth": depth, "learning_rate": lr, "n_estimators": 150, "random_state": 42}
        mlflow.log_params(params)
        m = GradientBoostingClassifier(**params).fit(X_tr, y_tr)
        auc = roc_auc_score(y_val, m.predict_proba(X_val)[:, 1])
        mlflow.log_metric("val_auc", auc)
        mlflow.sklearn.log_model(m, "model", signature=infer_signature(X_val, m.predict(X_val)),
                                 input_example=X_val.head(3))
        print(f"depth={depth} lr={lr} val_auc={auc:.4f}")
```

### Step 3 — Compare in the UI

In the `wine-quality` experiment, select all runs, then click **Compare**. Use the parallel-coordinates
chart (depth, learning rate, and `val_auc`), then sort by `val_auc`.

### Step 4 — Register the best run and set the alias

```python
import mlflow
from mlflow import MlflowClient
mlflow.set_tracking_uri("http://127.0.0.1:5000")
best = mlflow.search_runs(experiment_names=["wine-quality"], order_by=["metrics.val_auc DESC"]).iloc[0]
mv = mlflow.register_model(f"runs:/{best.run_id}/model", "wine-quality")
MlflowClient().set_registered_model_alias("wine-quality", "champion", mv.version)
print("registered version", mv.version, "from run", best.run_id)
```

### Step 5 — Load by alias, as serving would

```python
import mlflow, pandas as pd
from sklearn.datasets import load_wine
mlflow.set_tracking_uri("http://127.0.0.1:5000")
model = mlflow.pyfunc.load_model("models:/wine-quality@champion")
print(model.predict(load_wine(as_frame=True).data.head(3)))
```

### Step 6 — Check the record is reproducible

```bash
python3 exercises/s09_experiment_record.py
```

This exercise shows, without MLflow, exactly which fields make a run reproducible, and how to diff two
runs.

**Expected results:** six runs in the `wine-quality` experiment, each with params, `val_auc`, the
`git_commit` and `data_sha256` tags, and a logged model with a signature. The comparison view shows which
settings scored best. The registry lists `wine-quality` version 1 with the alias `champion`. Step 5 prints
three predictions loaded through the alias. The exercise prints five `PASS` lines.

---

## Assessment — Build a reproducible experiment record

**Task.** Define the record a training run must produce so that anyone can rebuild the same model. Then
prove it works: re-run from the record and get an identical model, and explain two runs that differ.

**Model answer.** The runnable solution is
[`exercises/s09_experiment_record.py`](../exercises/s09_experiment_record.py).

| Field group | Required fields | Why |
|---|---|---|
| Code | `git_commit`, `git_dirty`, `script_sha256` | A dirty tree means the commit doesn't describe the code that ran |
| Data | `uri`, `sha256` (or snapshot ID), `rows` | Paths change content. Hashes don't |
| Params | All hyperparameters + `seed` | No seed, no rerun |
| Environment | Python, OS/platform, key library versions, image digest | Library upgrades change results |
| Metrics | Final evaluation metrics on a named, versioned eval set | Comparable across runs |
| Artifacts | Path + `sha256` of each model file | Proves a rerun produced the same bytes |

The demo shows four things:
- **Run A** reproduces byte for byte from its record.
- **Run B** differs only in `params.lr`, and the diff names exactly that.
- **Run C** differs only in `data.sha256`, from one flipped label.
- **Record D**, typed by hand with a mutable path and no seed, is rejected by the linter with 8 missing fields.

**How it maps to MLflow:** fields go into tags (`git_commit`, `data_sha256`, `image_digest`), params,
metrics, and artifacts. The linter becomes a CI check (Section 10) that refuses to register a model whose
run is missing any required tag.

---

## FAANG deep-dive notes

**How big tech does it.** Internal ML platforms (Meta's FBLearner, Uber's Michelangelo, Google's TFX
and Vertex lineage, LinkedIn's Pro-ML) put experiment tracking, lineage, pipelines, and the registry behind
one interface. Training templates log lineage automatically, pipelines are mandatory for production
models, and deployments only accept registry versions that passed automated gates. Lineage graphs link
datasets, features, runs, models, and endpoints, which also drives data deletion and audits.

**Staff review questions.**
- For any production model, can we name its code commit, data snapshot, image, and evaluation results within five minutes?
- What stops someone from deploying a model trained in a notebook?
- How long is the data behind each production model retained, and does that match the reproducibility promise?
- What does the tracking platform cost, and what happens to training if it goes down?

**Interview question.** "Design experiment tracking and model lineage for 300 ML engineers."

**Typical system-design prompt:** *Design the experiment tracking, pipeline, and registry platform for
300 ML engineers running about 50,000 training runs a month, from small notebooks to multi-day GPU jobs,
with audit-grade lineage for production models.*

**1. Clarify first:** What share of runs are production candidates? Are there regulated models (credit,
health)? Which clouds and regions? Self-hosted or SaaS? What are the existing pipelines and registries?
What are the retention requirements?

**2. Back-of-envelope sizing:**
- Metrics: 50,000 runs × 20 metrics × ~1,000 logged points ≈ 1 billion points a month. At ~50 bytes per
  row, that's ~50 GB a month in the database. Partition by time, and downsample old runs.
- Artifacts: at ~200 MB per run on average, ~10 TB a month. With lifecycle rules (delete non-registered
  run artifacts after 90 days), the steady state is ~30 TB.
- Write traffic: 2,000 concurrent runs logging batches every 10 s ≈ 200 requests/s. That's easy for 3–4
  server replicas, if clients batch.
- Registry: a few thousand model versions. Tiny, but it's the most critical data in the system.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Hosting | Self-hosted MLflow | SaaS (W&B, managed MLflow) | SaaS when residency allows and the team is small. Self-host for control at scale |
| Logging | Synchronous per metric | Async batched | Async batched. Training must never wait on tracking |
| Artifact retention | Keep everything | Lifecycle by registry status | Keep registered versions and their data snapshots. Expire the rest |
| Orchestration | One orchestrator for everything | Team choice | One blessed orchestrator per platform, with templates. Allow exceptions with review |
| Promotion | Manual alias moves | CI gate moves aliases | CI only, with an audit trail. Humans approve, CI executes |

**4. Follow-up questions with crisp answers:**
- *What if the tracking server is down?* Clients buffer and retry asynchronously. Training continues, and
  the server is not on the critical path.
- *How do you enforce lineage?* The registry rejects versions whose run lacks the required tags. The
  pipeline refuses dirty trees and unversioned data.
- *How do you handle GDPR deletion?* Look up the models trained on the affected snapshots through the
  lineage graph. Retrain, or document why the model may be kept, by policy.

**Debug this (common onsite question):** "The MLflow UI times out, and training jobs got 20% slower this week."
1. Check the server: request rate is up 10×, mostly `log-metric` calls. The database CPU is at 100%.
2. Find the source: a new training template logs 30 metrics synchronously on every step, in 400 jobs.
3. Check the database: the metrics table has 3 billion rows, no time partitioning, and run-comparison
   queries scan it.
4. Fix: switch the template to async batched logging every 50 steps, add time partitioning and indexes,
   downsample metrics older than 90 days, and add per-client rate limits.

The lesson: experiment tracking is a write-heavy production system. Protect training from it with
async batching, and protect it from training with limits.

**5. What separates senior from staff answers:** a senior engineer sets up MLflow with a database and
bucket and logs runs well. A staff engineer designs the governance system: mandatory lineage enforced at
registration, CI-only promotion, retention linked to reproducibility promises, a lineage graph used for
audits and deletion, a capacity plan for metrics and artifacts, and a platform that keeps training
running when tracking is down.

**Red flags:**
- Production models with no link to a run, commit, or data snapshot.
- Training data referenced by mutable paths such as `latest.csv`.
- Synchronous per-step logging in large jobs.
- Anyone can move the `champion` alias by hand.
- Pipelines with no data-validation step, or no freshness alerts.

---

## Quiz

<details><summary>1. Which four inputs must be recorded to rebuild a model?</summary>
Code (commit, with a clean tree), data (a snapshot ID or content hash), configuration (all
hyperparameters, including the seed), and environment (image digest and library versions).
</details>

<details><summary>2. What are MLflow's backend store and artifact store, and what goes in each?</summary>
The backend store is a database (PostgreSQL or MySQL in production) holding experiments, runs, params,
metrics, tags, and the registry. The artifact store is object storage holding the files: models, plots,
and evaluation tables.
</details>

<details><summary>3. Why log a model with a signature and an input example?</summary>
The signature records the expected input and output schema, so serving can validate requests. The input
example shows how to call the model, and allows automated test predictions.
</details>

<details><summary>4. Why use registry aliases like `champion` instead of version numbers in serving config?</summary>
Promotion and rollback become a single alias move, with no config change or redeploy. Serving always
loads `models:/name@champion`.
</details>

<details><summary>5. A run's data is recorded as `s3://bucket/train/latest.parquet`. What's wrong?</summary>
The path is mutable: the file can be replaced later. Record a content hash or a table snapshot ID, so the
exact data can be identified and retrieved.
</details>

<details><summary>6. When would you pick W&B over MLflow?</summary>
When the team values a polished hosted UI, collaboration, and built-in sweeps, and data residency and
cost allow SaaS. MLflow fits when you need self-hosting, full control of data, an open registry, or
already use Databricks, SageMaker, or Azure ML.
</details>

<details><summary>7. Name three properties of a good training pipeline step.</summary>
It is idempotent, so reruns give the same output. It runs in a pinned image with resource requests and
retries. It passes references (path + hash) rather than data, and is cached by its inputs.
</details>

<details><summary>8. Training got slower after adding MLflow logging. What is the likely cause, and the fix?</summary>
Synchronous `log_metric` calls on every step put network round trips on the training critical path.
Batch the metrics (`log_metrics`), log every N steps, and enable asynchronous logging.
</details>

## Failure modes
- Production models with no run link, or runs without commit, data, and seed.
- Mutable data paths, so "the same dataset" changes between runs.
- Dirty Git trees: the recorded commit isn't the code that ran.
- Tracking on the training critical path (synchronous logging), or a tracking outage stopping training.
- Notebook-only retraining, done irregularly by one person.
- Pipelines failing silently, or stopping without a freshness alert.
- Evaluation sets that change between runs, making comparisons meaningless.

## Checklist
- [ ] You can list the code, data, config, and environment fields every run must record
- [ ] You ran an MLflow server with a database backend and an artifact store
- [ ] You logged params, step metrics, artifacts, and a model with a signature
- [ ] You registered a model version and loaded it through an alias
- [ ] You can version data with snapshots, DVC, or hashes, and link it to runs
- [ ] You can argue MLflow vs W&B from requirements
- [ ] You can sketch a retraining DAG with validation, a quality gate, and registration
- [ ] You ran `exercises/s09_experiment_record.py`, and all 5 checks pass
