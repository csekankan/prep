# Section 11 — Advanced Kubernetes for AI

> Lectures 71–77 • Assessment: quiz
> **After this section you can:** schedule GPU workloads precisely (device plugins, node pools, taints,
> affinity, gang scheduling, queues), run stateful AI services with StatefulSets, use and reason about
> operators, write production-grade Helm charts, launch distributed training with Kubeflow, secure a
> multi-tenant AI cluster, and deploy MLflow on Kubernetes.
>
> Go deeper: [13 / Lab 22 — Device plugin and NFD](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab22_device_plugin_nfd.md),
> [Lab 25 — Taints, tolerations, affinity](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab25_taints_tolerations_affinity.md),
> [Lab 26 — GPU resource quotas](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab26_resource_quotas_gpu.md),
> [Lab 38 — Volcano gang scheduling](../../13_sovereign_ai_infra_course/03_distributed_training/lab38_volcano_gang_scheduling.md),
> [Lab 44 — MLflow model registry](../../13_sovereign_ai_infra_course/04_serving_inference/lab44_mlflow_model_registry.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 71 | GPU scheduling in Kubernetes | GPUs are whole, non-shareable resources. Steer them with node pools, taints, affinity, and queues |
| 72 | StatefulSets for data-heavy workloads | Stable names and per-pod disks for databases, vector stores, and brokers |
| 73 | Kubernetes operators for ML | A custom resource + a controller that reconciles it: how PyTorchJob, RayCluster, and KServe work |
| 74 | Helm advanced templates for AI apps | Helpers, conditionals, loops, schemas, and tests, so one chart serves every model and environment |
| 75 | Scaling AI training with Kubeflow | PyTorchJob/TrainJob for distributed training, Katib for tuning, Pipelines for workflows |
| 76 | Kubernetes security best practices | Least-privilege RBAC, restricted pods, default-deny networking, signed images, and audit |
| 77 | Lab: deploy MLflow on Kubernetes | PostgreSQL + MinIO + MLflow server on Minikube, used by real training runs |

```mermaid
flowchart TB
  subgraph CP["Control plane"]
    API[API server] --> ADM["Admission: Kyverno / Gatekeeper<br/>signed images, restricted pods"]
    API --> Q["Kueue: queues, quotas,<br/>gang admission"]
    API --> SCH[Scheduler]
    API --> OPS["Operators: Training Operator,<br/>KubeRay, KServe, GPU Operator"]
  end
  subgraph CPU["CPU node pool"]
    MLF[MLflow, APIs, operators]
    STS[(StatefulSets:<br/>Postgres, Qdrant, Kafka)]
  end
  subgraph GPUP["GPU node pools, tainted"]
    TR["Training pods<br/>PyTorchJob, 8 GPUs each"]
    INF["Inference pods<br/>1 GPU or MIG slice"]
  end
  Q -->|admits whole job| SCH
  SCH --> CPU
  SCH --> GPUP
  DP["NVIDIA device plugin +<br/>feature discovery labels"] -.advertises GPUs.-> GPUP
  NP["NetworkPolicies:<br/>default deny"] -.-> CPU & GPUP
```

**How to read it:** requests pass admission policies first. Batch jobs wait in Kueue until their whole
quota is available, and then the scheduler places them. Operators turn high-level resources (a
`PyTorchJob`, a `RayCluster`) into pods. GPU nodes sit in tainted pools, advertised by the device plugin,
and stateful services run as StatefulSets on CPU nodes. Network policies wall everything off by default.

**Terms in this diagram.** Every Kubernetes object named here is explained with its own diagram and YAML in the
[Section 5 component and resource reference](../part01_foundations/s05_kubernetes_fundamentals.md#kubernetes-component-and-resource-reference).
- **Admission: Kyverno / Gatekeeper**: policy engines that check every object before it's saved, for example
  rejecting unsigned images or pods that run as root (Section 5, entry H4).
- **Kueue, gang admission**: **Kueue** is a Kubernetes job-queueing system. It holds a job until the team's quota
  has room, then admits it. **Gang admission** means all of the job's pods are admitted together or not at all,
  because a training job with 7 of its 8 workers running just wastes GPUs waiting (Lecture 75).
- **Operators: Training Operator, KubeRay, KServe, GPU Operator**: controllers that manage AI-specific resources.
  They handle distributed training jobs, Ray clusters, model serving, and GPU drivers and plugins (Lecture 73, and
  Section 5 entry I1).
- **Postgres, Qdrant, Kafka**: a relational database, a vector database, and an event-streaming system, all
  stateful, so they run as StatefulSets (Lecture 72).
- **Node pool, tainted**: a group of identical machines. GPU pools carry a **taint** so only pods that explicitly
  tolerate it (GPU workloads) can run there (Section 5, entry F5).
- **PyTorchJob**: the Kubeflow Training Operator's resource for a distributed PyTorch training run.
- **MIG slice**: a hardware partition of one GPU (Section 7).
- **Device plugin, feature discovery labels**: the NVIDIA device plugin tells Kubernetes how many GPUs each node
  has. **GPU Feature Discovery** (GFD) adds node labels describing them, such as model and memory (Lecture 71).
- **NetworkPolicies: default deny**: firewall rules between pods. Starting from "deny everything" and opening
  only the needed paths (Section 5, entry D5).

---

## Lecture 71 — GPU scheduling in Kubernetes

**Why it matters.** GPUs are the most expensive resource in the cluster. Bad scheduling wastes them
through fragmentation, idle reservations, CPU pods squatting on GPU nodes, or half-started distributed
jobs holding GPUs while waiting for the rest.

**In plain words.** A restaurant with a few huge tables (8-GPU nodes) and many small parties. If the
host seats every couple at a different big table, a party of eight can't be seated even though half the
chairs are empty. Good scheduling packs small parties together, keeps some big tables free, and seats
a large group only when all their chairs are ready at once.

**Architecture: from pod spec to GPU.**

```mermaid
flowchart LR
  POD["Pod requests<br/>nvidia.com/gpu: 1<br/>toleration: gpu=true<br/>affinity: gpu.product=H100"] --> SCH{Scheduler filters}
  SCH -->|"taint check"| T[Only GPU pools]
  SCH -->|"node labels from GFD"| L["gpu.product, gpu.memory,<br/>mig.capable"]
  SCH -->|"allocatable"| A["Node advertises 8 GPUs,<br/>6 already allocated"]
  A --> KUBELET[kubelet on chosen node]
  KUBELET --> DPL["Device plugin assigns<br/>GPU UUID to the container"]
  DPL --> CTR[Container sees exactly 1 GPU]
```

**How to read it:** the pod asks for a whole GPU, tolerates the GPU pool's taint, and prefers a GPU
model via a node label. The scheduler filters nodes by taint, labels (published by GPU Feature
Discovery), and remaining allocatable GPUs. On the chosen node, the device plugin hands the container one
specific GPU, and the container can't see the others.

In the diagram, **toleration: gpu=true** lets the pod onto nodes carrying the matching taint. **affinity:
gpu.product=H100** is a node-affinity rule, a requirement or preference for nodes with that label. **GFD** is GPU
Feature Discovery. **Allocatable** is how many GPUs the node offers to pods (8), and 6 are already taken by other
pods. The **kubelet** is the Kubernetes agent on each node that starts containers (Section 5, entry B1). The
**GPU UUID** is the GPU's unique hardware ID (like `GPU-3f2a...`), which the device plugin passes to the
container so it sees exactly that GPU.

**Core ideas.**

```yaml
apiVersion: v1
kind: Pod
metadata: { name: llm-server }
spec:
  tolerations: [{ key: nvidia.com/gpu, operator: Exists, effect: NoSchedule }]
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
          - matchExpressions: [{ key: nvidia.com/gpu.product, operator: In, values: [NVIDIA-H100-80GB-HBM3] }]
  priorityClassName: inference-high
  containers:
    - name: vllm
      image: vllm/vllm-openai@sha256:...
      resources:
        limits: { nvidia.com/gpu: 1, memory: 64Gi }
        requests: { cpu: "8", memory: 64Gi }
```

| Tool | Solves |
|---|---|
| NVIDIA GPU Operator | Installs the driver, container toolkit, device plugin, DCGM exporter, and MIG manager on GPU nodes |
| Taints + tolerations | Keeps non-GPU pods off GPU nodes |
| Node affinity + GFD labels | Picks the GPU model, memory size, or MIG profile |
| PriorityClasses + preemption | Inference beats batch. Production beats experiments |
| Kueue (or Volcano) | Queues, team quotas with borrowing, and **gang admission**: all of a job's pods start together, or none do |
| Topology-aware scheduling | Places a job's pods on nodes under the same network spine |
| Karpenter / Cluster Autoscaler | Adds GPU nodes when jobs are pending, and removes idle ones |
| Dynamic Resource Allocation (DRA) | Richer device requests (GPU slices, specific attributes), stable since Kubernetes 1.34 |

- `nvidia.com/gpu` is an **integer**, with no overcommit. Requests equal limits. Sharing needs MIG,
  time-slicing, or DRA (Section 7).
- **Fragmentation** is the main waste. Keep separate pools for whole-node training and small inference,
  and bin-pack small pods (a scheduler profile with the `MostAllocated` scoring strategy).

**Example: 120 free GPUs, but the 8-GPU job won't start.** A 40-node cluster (8 GPUs each) showed 120
free GPUs. Every free GPU was on a node that already ran 1–5 single-GPU inference pods, so no node had 8
free. The 64-GPU training job had been pending for 9 hours. The team moved inference to its own
bin-packed pool, admitted training through Kueue with gang scheduling on a dedicated pool, and made
experiments preemptible. Training jobs then started within minutes, and cluster allocation rose from
68% to 91%.

**Senior / FAANG best practice.** Run GPUs as a **queue-managed shared pool**: team quotas with
borrowing, priority tiers, gang admission, and preemption of the lowest tier, with checkpointing required
for preemptible jobs. Publish per-team allocated and *used* GPU-hours (from DCGM), so idle reservations
are visible. Separate the pools by workload shape (whole-node training, single-GPU inference, MIG).

---

## Lecture 72 — StatefulSets for data-heavy workloads

**Why it matters.** Vector databases, Kafka, PostgreSQL, Redis, and some training setups need stable
names and their own persistent disks. Running them as Deployments loses data or identity on every
reschedule.

**In plain words.** A Deployment is a team of temp workers: anyone can fill any shift, and they share no
lockers. A StatefulSet is a team of named staff, `db-0`, `db-1`, `db-2`. Each has their own locker (a
persistent volume) that is always theirs, they arrive and leave in order, and colleagues can always find
them by name.

**Architecture: a 3-replica vector database.**

```mermaid
flowchart TB
  HS["Headless Service: qdrant<br/>DNS: qdrant-0.qdrant.ml.svc"] --> P0 & P1 & P2
  subgraph STS["StatefulSet qdrant, replicas 3"]
    P0["qdrant-0<br/>zone a"] --- V0[("PVC data-qdrant-0<br/>gp3 200 GiB")]
    P1["qdrant-1<br/>zone b"] --- V1[("PVC data-qdrant-1")]
    P2["qdrant-2<br/>zone c"] --- V2[("PVC data-qdrant-2")]
  end
  SVC["ClusterIP Service: qdrant-client<br/>for queries"] --> P0 & P1 & P2
  PDB["PodDisruptionBudget<br/>maxUnavailable 1"] -.-> STS
  SNAP["VolumeSnapshots / app backups<br/>to object storage"] -.-> V0 & V1 & V2
```

**How to read it:** each pod gets a stable name and DNS entry through a headless Service, plus its own
volume created from a template. If `qdrant-1` is rescheduled, it comes back with the same name and the same
volume. Pods are spread across zones, a disruption budget keeps two of the three up during maintenance,
and backups go to object storage, because a volume is not a backup.

**Terms in this diagram.**
- **Headless Service**: a Service without a virtual IP (`clusterIP: None`), whose DNS returns each pod's own
  address. Here it gives each pod a stable name, `qdrant-0.qdrant.ml.svc`, read as "pod qdrant-0 of Service qdrant
  in namespace ml" (Section 5, entry D1).
- **PVC data-qdrant-0, gp3 200 GiB**: each pod's own PersistentVolumeClaim, a 200 GiB AWS gp3 SSD (Section 5,
  entries E4–E6).
- **ClusterIP Service: qdrant-client**: a normal Service with one virtual IP that spreads client queries across
  all three pods.
- **PodDisruptionBudget, maxUnavailable 1**: a rule that at most one pod may be taken down at a time during
  voluntary disruptions such as node upgrades (Section 5, entry F7).
- **VolumeSnapshots / app backups**: a **VolumeSnapshot** is a point-in-time copy of a disk made through the
  storage driver. An **app backup** uses the database's own snapshot feature (Qdrant snapshots), which is
  consistent even while writes happen. Both are copied to object storage.

**Core ideas.**

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata: { name: qdrant, namespace: ml }
spec:
  serviceName: qdrant
  replicas: 3
  podManagementPolicy: Parallel
  selector: { matchLabels: { app: qdrant } }
  template:
    metadata: { labels: { app: qdrant } }
    spec:
      topologySpreadConstraints:
        - { maxSkew: 1, topologyKey: topology.kubernetes.io/zone, whenUnsatisfiable: DoNotSchedule,
            labelSelector: { matchLabels: { app: qdrant } } }
      containers:
        - name: qdrant
          image: qdrant/qdrant:v1.12.1
          ports: [{ containerPort: 6333 }, { containerPort: 6335 }]
          volumeMounts: [{ name: data, mountPath: /qdrant/storage }]
          resources: { requests: { cpu: "2", memory: 16Gi }, limits: { memory: 16Gi } }
  volumeClaimTemplates:
    - metadata: { name: data }
      spec: { accessModes: [ReadWriteOnce], storageClassName: gp3-wffc, resources: { requests: { storage: 200Gi } } }
```

| | Deployment | StatefulSet |
|---|---|---|
| Pod names | Random | Ordered and stable (`name-0`, `name-1`) |
| Storage | Shared or none | One PVC per pod, kept across reschedules |
| Rollout | Any order, surge | Ordered (or parallel), one at a time by default |
| Use for | Stateless APIs, model servers | Databases, vector stores, Kafka, ZooKeeper, etcd |

- Use a StorageClass with `volumeBindingMode: WaitForFirstConsumer`, so a disk is created in the zone where
  the pod is scheduled.
- Deleting a StatefulSet **doesn't** delete its PVCs, by design. Clean them up deliberately (or set
  `persistentVolumeClaimRetentionPolicy`).
- For serious databases, prefer an **operator** (CloudNativePG, Strimzi for Kafka, the Qdrant or Milvus
  operators) or a managed service. They handle failover, backups, and upgrades.

**Example: the pod stuck after a zone outage.** A Milvus pod's node was in zone `a`, and its EBS
volume could only attach in zone `a`. During a zone-`a` incident, the pod was rescheduled to zone `b`
and stayed `Pending` (a volume node affinity conflict). Search degraded for 40 minutes. The fix: spread
replicas across three zones with replication inside the database, so losing one zone's pod doesn't matter,
plus a disruption budget and regular restore tests from snapshots.

**Senior / FAANG best practice.** Big tech mostly runs stateful systems either as managed services or
through mature operators with automated failover, backups, and tested restores. Raw StatefulSets are
reserved for simple or ephemeral state. Every stateful workload has a documented recovery point objective
(RPO) and recovery time objective (RTO), and a restore drill on a schedule (Section 20).

---

## Lecture 73 — Kubernetes operators for ML

**Why it matters.** Most ML infrastructure on Kubernetes (distributed training, Ray clusters, model
serving, GPU drivers) is delivered as operators. Knowing how they work lets you use them confidently and
debug them when a job won't start.

**In plain words.** An operator is a robot expert hired to look after one kind of system. You give it a
short wish ("I want a PyTorch job with 4 workers"). It knows all the steps to make that true (create
pods, services, environment variables), and keeps fixing things until reality matches the wish.

**Architecture: the reconcile loop.**

```mermaid
flowchart LR
  USER["kubectl apply<br/>kind: PyTorchJob<br/>workers: 4"] --> API[API server stores<br/>the custom resource]
  API -->|watch event| CTRL[Operator controller]
  CTRL --> OBS[Observe: which pods<br/>and services exist?]
  OBS --> DIFF{"Desired<br/>= actual?"}
  DIFF -->|no| ACT["Act: create master + 4 worker pods,<br/>headless service, env MASTER_ADDR,<br/>WORLD_SIZE, RANK"]
  ACT --> API
  DIFF -->|yes| STATUS[Update status:<br/>Running, Succeeded, Failed]
  STATUS --> API
```

**How to read it:** you create a **custom resource** (an instance of a CRD). The operator's controller
watches for it, compares the desired state with what actually exists, and creates or fixes the
low-level objects until they match. It writes progress back into the resource's `status`. If a pod
disappears, the next loop notices and acts, according to the restart policy.

In the diagram, a **watch event** is the API server notifying the controller that the object changed. The
**master** pod is rank 0, the one every worker connects to first. **MASTER_ADDR, WORLD_SIZE, RANK** are the
environment variables PyTorch distributed training reads: the master's address, the total number of processes,
and this process's number (Section 8, Lecture 52).

**Core ideas.**

| Operator | Custom resources | What it does for ML |
|---|---|---|
| Kubeflow Training Operator / Trainer | `PyTorchJob`, `TFJob`, `MPIJob`, and in Trainer v2 `TrainJob` + runtimes | Distributed training pods with the right ranks and env |
| KubeRay | `RayCluster`, `RayJob`, `RayService` | Ray clusters for data processing, training, and serving |
| KServe | `InferenceService` | Model serving with autoscaling, canaries, transformers |
| NVIDIA GPU Operator | `ClusterPolicy` | Drivers, device plugin, DCGM, MIG manager |
| Prometheus Operator | `ServiceMonitor`, `PrometheusRule` | Scrape configs and alerts as code |
| CloudNativePG / Strimzi | `Cluster`, `Kafka` | Databases and brokers with failover and backups |
| Kueue | `ClusterQueue`, `LocalQueue`, `Workload` | Quotas and queueing for batch jobs |

- Operators are built with **Kubebuilder** or the **Operator SDK** (Go), or Kopf (Python), on top of
  controller-runtime.
- `kubectl get <kind> -o yaml` shows a resource's `status.conditions`. That's the first place to look
  when an operator-managed thing misbehaves. Then read the operator's own pod logs.
- Operators run with broad cluster permissions. Install only the ones you need, from trusted sources,
  and keep them upgraded.

**Example: a stuck PyTorchJob.** A job showed `Created` but never `Running`. Its `status.conditions` were
empty, which meant the operator hadn't processed it at all. The Training Operator's logs showed it was
crash-looping after a cluster upgrade removed a deprecated API version it still used. Upgrading the
operator fixed every stuck job. The team added operator health and version compatibility to their
cluster upgrade checklist.

**Senior / FAANG best practice.** Treat operators as platform dependencies: pin their versions, test
them in a staging cluster against each Kubernetes upgrade, monitor their reconcile errors and queue
depth, and limit their RBAC. Write a custom operator only when you have a long-lived resource with real
lifecycle logic. For one-off automation, a CI job or a controller script is simpler to own.

---

## Lecture 74 — Helm advanced templates for AI apps

**Why it matters.** Once a team runs ten models in three environments, copy-pasted YAML drifts and
breaks. Good Helm charts give every model the same production defaults (probes, resources, PDBs,
GPU settings) with a few values.

**In plain words.** A good form template. Instead of writing a new letter for every customer, you fill in
the name, address, and options, and the template adds the standard paragraphs, signatures, and legal
text automatically, and refuses to print if a required box is empty.

**Architecture: one chart, many releases.**

```mermaid
flowchart LR
  CH["Chart model-server<br/>templates + _helpers.tpl<br/>values.schema.json"] --> R1["release fraud-prod<br/>values-prod.yaml<br/>gpu: true, replicas 4"]
  CH --> R2["release fraud-staging<br/>values-staging.yaml<br/>replicas 1"]
  CH --> R3["release ranker-prod<br/>models: two models via range"]
  R1 & R2 & R3 --> CI["CI: helm lint, helm template | kubeconform,<br/>policy checks"]
  CI --> GITOPS["Argo CD / Flux<br/>sync from Git"]
```

**How to read it:** one chart holds templates and shared helpers, plus a JSON schema that rejects bad
values. Each release combines the chart with an environment's values file. CI renders and validates
every release before a GitOps tool syncs it to the cluster.

**Terms in this diagram.**
- **_helpers.tpl**: a template file of reusable snippets (names, labels) that the other templates call.
- **values.schema.json**: a JSON Schema describing allowed values. Helm refuses to install if, say, `replicas` is
  a string or a required field is missing.
- **Release**: one installed instance of a chart with a name and its own values. The same chart can be installed
  many times.
- **Via range**: Helm's `range` loop, which creates one set of objects per item in a list, here one per model.
- **helm lint, helm template | kubeconform**: `helm lint` checks the chart for mistakes. `helm template` renders
  the final YAML without installing, and **kubeconform** validates that YAML against the Kubernetes API schemas.
- **Policy checks**: running admission-style rules (for example with Kyverno CLI or Conftest) in CI, before the
  cluster ever sees the YAML.
- **Argo CD / Flux, sync from Git**: **GitOps** tools. They watch a Git repository and continuously make the
  cluster match it, so Git is the single record of what's deployed and every change is a reviewed commit.

**Core ideas.**

```yaml
# templates/_helpers.tpl
{{- define "model.labels" -}}
app.kubernetes.io/name: {{ .Values.name }}
app.kubernetes.io/version: {{ .Values.model.version | quote }}
{{- end }}

# templates/deployment.yaml (excerpt)
spec:
  replicas: {{ .Values.replicas }}
  template:
    metadata:
      labels: {{- include "model.labels" . | nindent 8 }}
      annotations:
        checksum/config: {{ include (print $.Template.BasePath "/configmap.yaml") . | sha256sum }}
    spec:
      {{- if .Values.gpu.enabled }}
      tolerations: [{ key: nvidia.com/gpu, operator: Exists, effect: NoSchedule }]
      nodeSelector: { nvidia.com/gpu.product: {{ .Values.gpu.product | quote }} }
      {{- end }}
      containers:
        - name: server
          image: "{{ .Values.image.repository }}@{{ required "image.digest is required" .Values.image.digest }}"
          env:
            {{- range $k, $v := .Values.env }}
            - { name: {{ $k }}, value: {{ $v | quote }} }
            {{- end }}
          resources:
            limits:
              memory: {{ .Values.resources.memory }}
              {{- if .Values.gpu.enabled }}
              nvidia.com/gpu: {{ .Values.gpu.count }}
              {{- end }}
```

| Feature | Use |
|---|---|
| `_helpers.tpl` + `include` | Shared labels, names, and probes across templates |
| `required`, `fail` | Stop rendering when a critical value is missing |
| `values.schema.json` | Type-check values (e.g., `replicas` is an integer ≥ 2 in prod) |
| `if` / `range` / `with` | Optional GPU blocks, lists of models, environment variables |
| Checksum annotation | Restart pods when a ConfigMap changes |
| Library charts and dependencies | Shared building blocks. Bundled sub-charts (e.g., Redis) |
| Hooks + `helm test` | Pre-upgrade migrations, and post-install smoke tests |

```bash
helm lint charts/model-server -f values-prod.yaml
helm template fraud charts/model-server -f values-prod.yaml | kubeconform -strict -summary
helm upgrade --install fraud charts/model-server -f values-prod.yaml --atomic --timeout 10m
```

**Example: one chart for 14 models.** A team had 14 near-identical folders of YAML, and 5 of them lacked
readiness probes, which caused traffic to reach pods still loading models. A single chart with probe and
PDB defaults, `required` digests, and a schema forcing `replicas >= 2` in production replaced them all.
Onboarding a new model became a 25-line values file, and the probe bug disappeared everywhere at once.

**Senior / FAANG best practice.** Platform teams publish a **golden chart** (or a higher-level
abstraction on top of it) with secure, observable defaults baked in, and product teams only set values.
All rendering and validation happens in CI, and clusters are changed only by GitOps sync, never by
`helm install` from a laptop. Version charts semantically, and test upgrades of existing releases, not
just fresh installs.

---

## Lecture 75 — Scaling AI training with Kubeflow

**Why it matters.** Running multi-node training by hand means creating pods, services, ranks, and
environment variables yourself. Kubeflow packages these patterns, so distributed training and
hyperparameter tuning become a single resource each.

**In plain words.** Kubeflow is a toolkit of ready-made workstations for an ML team on Kubernetes:
notebooks to explore, a training station that sets up multi-GPU jobs for you, a tuning station that tries
many settings, and an assembly line (pipelines) that connects them.

**Architecture: the Kubeflow pieces.**

```mermaid
flowchart TB
  NB["Notebooks<br/>Jupyter / VS Code pods"] --> KFP
  KFP["Kubeflow Pipelines<br/>DAG of container steps"] --> TRN
  TRN["Trainer / Training Operator<br/>PyTorchJob or TrainJob"] --> PODS["master + workers<br/>torchrun env injected"]
  KFP --> KATIB["Katib<br/>hyperparameter search,<br/>early stopping"]
  KATIB --> TRN
  TRN --> REG["Model Registry / MLflow"]
  REG --> KS["KServe<br/>InferenceService"]
  KUEUE["Kueue: quotas, gang admission"] -.admits.-> TRN
```

**How to read it:** notebooks are for exploring. Pipelines turn the work into repeatable steps. A
training step creates a distributed training resource, and the operator expands it into pods with the
right ranks. Katib runs many such jobs to tune hyperparameters. Results go to a registry, and KServe
serves the chosen model. Kueue decides when each job may start.

**Terms in this diagram.**
- **Jupyter / VS Code pods**: interactive notebook or editor environments, each running as a pod with its own CPU,
  memory, and optionally a GPU.
- **Kubeflow Pipelines, DAG of container steps**: Kubeflow's workflow engine. A **DAG** (directed acyclic graph) is
  a set of steps with dependencies and no loops, and each step runs in its own container.
- **Trainer / Training Operator, PyTorchJob or TrainJob**: Kubeflow's operator for distributed training.
  `PyTorchJob` is the older resource, and `TrainJob` the newer, framework-neutral one in Kubeflow Trainer.
- **torchrun env injected**: the operator sets the environment variables torchrun needs (master address, world
  size, rank) in each pod.
- **Katib, hyperparameter search, early stopping**: Katib is Kubeflow's tuning service. It tries many settings
  combinations and stops unpromising trials early to save GPU time.
- **KServe InferenceService**: KServe's resource that deploys a model as an autoscaling HTTP or gRPC endpoint
  (Section 15).

**Core ideas.**

```yaml
apiVersion: kubeflow.org/v1
kind: PyTorchJob
metadata: { name: resnet-ddp, namespace: team-vision, labels: { kueue.x-k8s.io/queue-name: vision } }
spec:
  pytorchReplicaSpecs:
    Master:
      replicas: 1
      restartPolicy: OnFailure
      template: &pod
        spec:
          tolerations: [{ key: nvidia.com/gpu, operator: Exists, effect: NoSchedule }]
          containers:
            - name: pytorch
              image: registry.internal/vision-train@sha256:...
              command: [torchrun, --nproc-per-node=8, train.py, --epochs=30]
              resources: { limits: { nvidia.com/gpu: 8, memory: 400Gi } }
              volumeMounts: [{ name: shm, mountPath: /dev/shm }]
          volumes: [{ name: shm, emptyDir: { medium: Memory, sizeLimit: 64Gi } }]
    Worker:
      replicas: 3
      restartPolicy: OnFailure
      template: *pod
```

| Component | Use it for |
|---|---|
| Trainer (Training Operator) | PyTorch, TensorFlow, JAX, MPI, and XGBoost distributed jobs. Trainer v2 adds `TrainJob` + reusable runtimes |
| Katib | Hyperparameter tuning (random, Bayesian, Hyperband) and early stopping |
| Pipelines (KFP) | Python-defined DAGs compiled to containers. Caching and lineage |
| Notebooks | Self-service dev environments with GPUs and quotas |
| KServe | Serving with autoscaling (including scale to zero) and canaries |

- Mount a memory-backed `/dev/shm`. PyTorch data-loader workers share tensors through it, and the
  container default (64 MB) crashes multi-worker loaders.
- Combine with **Kueue**, so a 4-node job is admitted only when 32 GPUs are free, which prevents deadlock
  between half-started jobs.
- Kubeflow is modular: you can install only Trainer + Kueue, without the full platform.

**Example: from scripts to PyTorchJobs.** A vision team launched multi-node jobs with a shell script that
created pods by hand. Ranks were hard-coded, and a lost node meant re-running the script manually. Moving
to `PyTorchJob` with `restartPolicy: OnFailure`, elastic `torchrun` restarts, checkpoints in object storage,
and Kueue admission meant failed nodes were replaced automatically, and jobs resumed within ~6 minutes.

**Senior / FAANG best practice.** Offer training as a **self-service product**: templates or a CLI that
create a job with sane defaults (image, shared memory, checkpoint paths, queue label, cost tags) from a
few parameters. Enforce queue membership and quotas, and give every job a time-to-start SLO. Big
companies hide the CRDs behind internal tools, but the same pieces run underneath.

---

## Lecture 76 — Kubernetes security best practices

**Why it matters.** AI clusters hold valuable data, models, and expensive GPUs. They often run notebooks
and third-party images. A default Kubernetes setup is far too permissive for that: any pod can talk to
any pod, and many images run as root.

**In plain words.** A shared office building. Each team gets keys only to its own floor (RBAC and
namespaces). Doors between departments are locked by default (network policies). Visitors must show
ID at the entrance (admission control). Nobody is allowed to rewire the building (no privileged
containers). Cameras record everything (audit logs).

**Architecture: defense in depth for a multi-tenant AI cluster.**

```mermaid
flowchart TB
  U[User or CI] -->|"OIDC SSO, short-lived token"| API[API server]
  API --> RBAC{"RBAC: namespace-scoped roles<br/>no cluster-admin for users"}
  RBAC --> ADM{"Admission: Pod Security restricted,<br/>signed images, required labels and limits"}
  ADM --> NS["Namespace team-a<br/>ResourceQuota, LimitRange"]
  NS --> POD["Pod: non-root, read-only root FS,<br/>no privilege escalation, drop ALL caps,<br/>own ServiceAccount + workload identity"]
  POD --> NP{"NetworkPolicy:<br/>default deny, allow listed paths"}
  NP --> DATA[(Allowed: feature store,<br/>model bucket via endpoint)]
  POD -.runtime events.-> FALCO[Falco / runtime detection]
  API -.audit log.-> SIEM[(SIEM)]
```

**How to read it:** every request is authenticated through SSO and authorized by namespace-scoped roles.
Admission policies reject pods that run as root, use unsigned images, or lack limits. Pods run with minimal
privileges and their own identity, and can only reach what network policies allow. Runtime detection and
audit logs catch what slips through.

**Terms in this diagram** (Section 5 entries H1–H4, F1–F3, and D5 show each one with YAML):
- **OIDC SSO, short-lived token**: people log in with the company identity provider through OpenID Connect and get
  a token that expires within hours.
- **RBAC, cluster-admin**: role-based access control. `cluster-admin` is the built-in role that can do anything,
  which ordinary users should never hold.
- **Pod Security restricted**: the strictest built-in pod security level (non-root, no privilege escalation, and
  so on).
- **ResourceQuota, LimitRange**: per-namespace caps on total resources, and per-container default and maximum
  requests.
- **Read-only root FS, drop ALL caps**: the container can't modify its own filesystem (FS), and all Linux
  **capabilities** (special kernel privileges) are removed.
- **ServiceAccount + workload identity**: the pod's own Kubernetes identity, mapped to a cloud IAM role.
- **NetworkPolicy: default deny, allow listed paths**: pod-level firewall rules. Everything is blocked unless a
  rule explicitly allows that source, destination, and port.
- **Model bucket via endpoint**: the object storage bucket, reached through a private VPC endpoint.
- **Falco**: an open-source runtime security tool that watches system calls and alerts on suspicious behavior,
  such as a shell starting inside a model server container.
- **SIEM**: security information and event management, the central system where security teams collect and search
  logs, such as Splunk, Elastic Security, or Google Chronicle.

**Core ideas.**

```yaml
# restricted container settings (Pod Security "restricted" profile)
securityContext:
  runAsNonRoot: true
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
  capabilities: { drop: [ALL] }
  seccompProfile: { type: RuntimeDefault }
---
# default-deny ingress and egress for a namespace
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: { name: default-deny, namespace: team-a }
spec: { podSelector: {}, policyTypes: [Ingress, Egress] }
```

| Area | Practice |
|---|---|
| Identity | SSO for humans (OIDC). One ServiceAccount per workload. Cloud access via IRSA or Workload Identity |
| Authorization | Namespace-scoped Roles. No wildcard verbs. Review `cluster-admin` bindings |
| Pod security | Enforce `restricted` Pod Security Standards per namespace (`pod-security.kubernetes.io/enforce`) |
| Network | Default deny. Explicit allow rules. Egress control for notebooks |
| Supply chain | Signed images, digests only, internal registry, vulnerability scanning (Section 10) |
| Secrets | Encryption at rest, External Secrets / CSI driver from a vault, no secrets in env dumps or logs |
| Runtime and audit | Falco or a cloud equivalent. API audit logs to a SIEM |
| Tenancy | Namespaces + quotas for teams. Separate clusters for hard isolation |

- GPU components (device plugin, GPU Operator) need privileged access. Isolate them in system
  namespaces, and never grant users the same.
- **Notebooks are the riskiest workload**: arbitrary code, data access, and often internet egress. Give
  them their own namespace, egress restrictions, and no production credentials.

**Example: a crypto-miner on GPU nodes.** A public Jupyter service, without authentication, ran in a
research cluster. Attackers launched pods running crypto-miners on 32 GPUs, which went unnoticed for four
days, at about $9,000 of GPU time. The fixes: SSO in front of all UIs, `restricted` pod security, default-deny
egress (mining pools unreachable), per-namespace GPU quotas, Falco rules for mining processes, and alerts on
GPU utilization outside expected job patterns.

**Senior / FAANG best practice.** Encode security as **policy-as-code** (Kyverno or Gatekeeper),
versioned in Git, tested in CI, and applied to every cluster by GitOps. Track compliance continuously (CIS
benchmarks, `kube-bench`). Grant production access just in time, with approval and audit. Assume
breach: limit the blast radius with namespaces, network policies, and least-privilege identities.

---

## Lecture 77 — Lab: deploy MLflow on Kubernetes

**Goal:** run a team-ready MLflow on Minikube: PostgreSQL as the backend store (a StatefulSet), MinIO as
the S3-compatible artifact store, and the MLflow server as a Deployment with probes, then log real runs to
it from your laptop.

**What you're building.**

```mermaid
flowchart LR
  LAP["Laptop: sweep.py<br/>MLFLOW_TRACKING_URI=localhost:5000"] -->|port-forward| SVC[Service mlflow:5000]
  subgraph NS["namespace mlflow"]
    SVC --> MLF["Deployment mlflow<br/>2 replicas, probes"]
    MLF --> PG[("StatefulSet postgres<br/>PVC 5 GiB")]
    MLF --> MINIO[("Deployment minio<br/>bucket mlflow")]
    SEC["Secret: DB + MinIO credentials"] -.-> MLF & PG & MINIO
  end
```

**In plain words.** You move the Section 9 lab's single-laptop MLflow into a small cluster, with a real
database and object store behind it, which is what a team would actually share.

**How to read the diagram:** your laptop reaches the cluster through `kubectl port-forward`, which tunnels
`localhost:5000` to the `mlflow` Service. Two MLflow replicas with health probes serve the API. PostgreSQL runs
as a StatefulSet with a 5 GiB volume for run records, and **MinIO** (S3-compatible object storage you run
yourself) holds the artifacts. One Secret supplies the database and MinIO passwords to all three.

### Step 1 — Cluster and namespace

```bash
minikube start --cpus 4 --memory 8g
kubectl create namespace mlflow
kubectl -n mlflow create secret generic mlflow-secrets \
  --from-literal=POSTGRES_PASSWORD=change-me --from-literal=MINIO_ROOT_USER=minio \
  --from-literal=MINIO_ROOT_PASSWORD=change-me-too
```

### Step 2 — PostgreSQL and MinIO (`backing.yaml`)

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata: { name: postgres, namespace: mlflow }
spec:
  serviceName: postgres
  replicas: 1
  selector: { matchLabels: { app: postgres } }
  template:
    metadata: { labels: { app: postgres } }
    spec:
      containers:
        - name: postgres
          image: postgres:16
          env:
            - { name: POSTGRES_DB, value: mlflow }
            - { name: POSTGRES_USER, value: mlflow }
            - { name: POSTGRES_PASSWORD, valueFrom: { secretKeyRef: { name: mlflow-secrets, key: POSTGRES_PASSWORD } } }
            - { name: PGDATA, value: /var/lib/postgresql/data/pgdata }
          volumeMounts: [{ name: data, mountPath: /var/lib/postgresql/data }]
          readinessProbe: { exec: { command: [pg_isready, -U, mlflow] }, periodSeconds: 5 }
  volumeClaimTemplates:
    - metadata: { name: data }
      spec: { accessModes: [ReadWriteOnce], resources: { requests: { storage: 5Gi } } }
---
apiVersion: v1
kind: Service
metadata: { name: postgres, namespace: mlflow }
spec: { selector: { app: postgres }, ports: [{ port: 5432 }] }
---
apiVersion: apps/v1
kind: Deployment
metadata: { name: minio, namespace: mlflow }
spec:
  selector: { matchLabels: { app: minio } }
  template:
    metadata: { labels: { app: minio } }
    spec:
      containers:
        - name: minio
          image: minio/minio:RELEASE.2024-10-13T13-34-11Z
          args: [server, /data]
          envFrom: [{ secretRef: { name: mlflow-secrets } }]
          readinessProbe: { httpGet: { path: /minio/health/ready, port: 9000 } }
---
apiVersion: v1
kind: Service
metadata: { name: minio, namespace: mlflow }
spec: { selector: { app: minio }, ports: [{ port: 9000 }] }
```

```bash
kubectl apply -f backing.yaml
kubectl -n mlflow rollout status statefulset/postgres
kubectl -n mlflow run mc --rm -it --restart=Never --image=minio/mc --env MC_HOST_m=http://minio:change-me-too@minio:9000 \
  -- mb m/mlflow                                    # create the artifact bucket
```

### Step 3 — The MLflow server (`mlflow.yaml`)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: mlflow, namespace: mlflow }
spec:
  replicas: 2
  selector: { matchLabels: { app: mlflow } }
  template:
    metadata: { labels: { app: mlflow } }
    spec:
      containers:
        - name: mlflow
          image: ghcr.io/mlflow/mlflow:v2.17.2
          command: [sh, -c]
          args:
            - pip install -q psycopg2-binary boto3 &&
              mlflow server --host 0.0.0.0 --port 5000
              --backend-store-uri postgresql://mlflow:$(POSTGRES_PASSWORD)@postgres:5432/mlflow
              --artifacts-destination s3://mlflow
          env:
            - { name: MLFLOW_S3_ENDPOINT_URL, value: "http://minio:9000" }
            - { name: AWS_ACCESS_KEY_ID, valueFrom: { secretKeyRef: { name: mlflow-secrets, key: MINIO_ROOT_USER } } }
            - { name: AWS_SECRET_ACCESS_KEY, valueFrom: { secretKeyRef: { name: mlflow-secrets, key: MINIO_ROOT_PASSWORD } } }
            - { name: POSTGRES_PASSWORD, valueFrom: { secretKeyRef: { name: mlflow-secrets, key: POSTGRES_PASSWORD } } }
          ports: [{ containerPort: 5000 }]
          startupProbe: { httpGet: { path: /health, port: 5000 }, failureThreshold: 30, periodSeconds: 5 }
          readinessProbe: { httpGet: { path: /health, port: 5000 } }
          resources: { requests: { cpu: 250m, memory: 512Mi }, limits: { memory: 1Gi } }
---
apiVersion: v1
kind: Service
metadata: { name: mlflow, namespace: mlflow }
spec: { selector: { app: mlflow }, ports: [{ port: 5000 }] }
```

Installing packages at startup keeps the lab short. In production, build an image with them baked in
(Section 4).

```bash
kubectl apply -f mlflow.yaml && kubectl -n mlflow rollout status deploy/mlflow
kubectl -n mlflow port-forward svc/mlflow 5000:5000
```

### Step 4 — Log runs from your laptop

Run the Section 9 `sweep.py` unchanged. It already points at `http://127.0.0.1:5000`. Artifacts are
proxied by the server into MinIO, so the laptop needs no storage credentials.

### Step 5 — Prove it survives restarts

```bash
kubectl -n mlflow delete pod -l app=mlflow          # server pods replaced, runs still listed
kubectl -n mlflow delete pod postgres-0             # database pod restarts with the same PVC
```

**Expected results:**
- `kubectl -n mlflow get pods` shows `postgres-0`, one `minio` pod, and two `mlflow` pods, all `Running`
  and ready.
- The MLflow UI on `localhost:5000` lists the sweep's six runs, and their model artifacts are browsable,
  because they're stored in the MinIO `mlflow` bucket.
- After Step 5 deletes the MLflow and PostgreSQL pods, every run and artifact is still there.

---

## FAANG deep-dive notes

**How big tech does it.** Large companies run Kubernetes (or internal equivalents such as Borg) as a
fleet: many clusters built from the same templates, managed by GitOps, with policy-as-code and standard
operators. GPU capacity is a queue-managed shared pool with quotas, priorities, gang scheduling,
topology-aware placement, and automated node health remediation. Stateful systems are mostly managed
services or operator-run. Developers interact through internal tools, not raw YAML.

**Staff review questions.**
- What is the GPU allocation rate versus utilization rate, and what is fragmentation costing us?
- How long does a typical training job wait to start, per priority tier?
- Which operators run with cluster-wide privileges, and how are they upgraded and tested?
- What is the blast radius if one tenant's notebook is compromised?

**Interview question.** "Our big training jobs wait hours to start, but the cluster looks half empty. Design
the fix."

**Typical system-design prompt:** *Design the GPU scheduling layer of a Kubernetes platform with 2,000
GPUs (250 nodes × 8) shared by 40 teams, running multi-node training, batch inference, and online
serving, with fair sharing and good utilization.*

**1. Clarify first:** What's the mix of whole-node training, single-GPU serving, and fractional
workloads? Are SLOs needed for serving and for time-to-start? How do teams get quotas, and can they
borrow? Is preemption acceptable, and do jobs checkpoint? What is the network topology (spines, rails)?

**2. Back-of-envelope sizing:**
- 250 nodes × 8 = 2,000 GPUs. If serving needs 300 GPUs, keep it in a dedicated bin-packed pool of ~40
  nodes, with headroom.
- Training pool: ~200 nodes (1,600 GPUs). A 256-GPU job needs 32 *whole* nodes under the same spine.
  Topology-aware placement matters.
- Fragmentation: if 30% of nodes are partially used by small pods, then up to 75 nodes can't host
  whole-node jobs. That's the "half-empty but full" symptom.
- Quotas: 40 teams' nominal quotas sum to the pool size, and unused quota can be borrowed. Preemption
  reclaims it within the checkpoint interval (~15–30 minutes of lost work, at most).

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Pools | One shared pool | Pools per workload shape | Separate whole-node training from small pods. Fragmentation dominates otherwise |
| Admission | Default scheduler only | Kueue / Volcano gang admission | Gang admission for any multi-pod job, or jobs deadlock holding partial GPUs |
| Sharing | Hard quotas | Quotas + borrowing + preemption | Borrowing for utilization, preemption for fairness. Requires checkpointing |
| Placement | Any node | Topology-aware (same spine or rail group) | Topology-aware for big jobs. All-reduce suffers across spines |
| Small models | Whole GPUs | MIG / DRA slices | Slices for many small, steady services |

**4. Follow-up questions with crisp answers:**
- *Why not just use the default scheduler?* It places pods one at a time, so a 32-pod job can grab 20
  nodes and wait forever for the rest while blocking others. Gang admission avoids that.
- *How do you keep serving safe from training?* Separate pools, higher PriorityClass, PDBs, and never
  letting training borrow serving's reserved capacity.
- *What happens when a GPU node degrades mid-job?* Health checks taint or cordon it. The job restarts
  from its checkpoint on a spare, and the node goes to repair.

**Debug this (common onsite question):** "A 64-GPU PyTorchJob has been Pending for 6 hours. `kubectl` shows
150 free GPUs."
1. `kubectl describe pod` on a worker: `0/250 nodes are available: 210 Insufficient nvidia.com/gpu, 40
   node(s) had untolerated taint`. No node has 8 free GPUs.
2. Count free GPUs per node: most free GPUs sit in groups of 1–3 on nodes running single-GPU batch
   inference pods.
3. Check admission: there's no gang scheduling. Six of the eight workers started on the only fully free
   nodes and have held 48 GPUs idle for 6 hours.
4. Fix: move single-GPU pods to a bin-packed pool, admit training through Kueue (all-or-nothing), make
   batch inference preemptible, and alert on jobs pending longer than their time-to-start SLO.

The lesson: "free GPUs" means nothing without shape. Schedule by whole-node availability and admit jobs
as gangs.

**5. What separates senior from staff answers:** a senior engineer configures taints, affinity, and
quotas correctly. A staff engineer designs the capacity economics: pools by workload shape, queueing with
borrowing and preemption tied to checkpoint policy, topology-aware placement, fragmentation and
time-to-start metrics with SLOs, automated node remediation, and chargeback for allocated versus used
GPU-hours.

**Red flags:**
- Multi-pod jobs with no gang admission.
- Single-GPU pods scattered across whole-node training capacity.
- Users with cluster-admin, or notebooks with production credentials.
- Stateful databases as Deployments, or StatefulSets with no tested backup restore.
- Charts applied from laptops instead of through GitOps.

---

## Quiz

<details><summary>1. Why can't two pods share one `nvidia.com/gpu` by default, and how can they?</summary>
The device plugin advertises whole GPUs as an integer resource with no overcommit, so each one is assigned
exclusively. Sharing needs MIG (hardware partitions), time-slicing or MPS configured in the device plugin,
or DRA-based slicing.
</details>

<details><summary>2. What problem does gang scheduling solve for distributed training?</summary>
It admits all of a job's pods together, or none. Without it, partially started jobs hold GPUs while
waiting for the rest, which wastes capacity and can deadlock several jobs.
</details>

<details><summary>3. Name three things a StatefulSet gives you that a Deployment doesn't.</summary>
Stable, ordered pod names with stable DNS (through a headless Service), a dedicated PVC per pod kept across
reschedules (`volumeClaimTemplates`), and ordered rollout and termination.
</details>

<details><summary>4. What is a Kubernetes operator?</summary>
A custom resource definition plus a controller that watches those resources and reconciles the real cluster
state to match them, for example turning a `PyTorchJob` into pods and services with the right ranks.
</details>

<details><summary>5. Why add a checksum annotation of the ConfigMap to a Deployment template in Helm?</summary>
When the ConfigMap changes, the checksum changes the pod template, which triggers a rolling restart. Pods
otherwise keep the old config.
</details>

<details><summary>6. Why do PyTorch training pods often need a memory-backed `/dev/shm` volume?</summary>
DataLoader worker processes share tensors through shared memory. Containers default to a 64 MB `/dev/shm`,
which crashes or slows multi-worker loading.
</details>

<details><summary>7. List four settings of the Pod Security "restricted" profile.</summary>
`runAsNonRoot: true`, `allowPrivilegeEscalation: false`, `capabilities.drop: [ALL]`, and
`seccompProfile: RuntimeDefault`. Plus, commonly, `readOnlyRootFilesystem: true`.
</details>

<details><summary>8. A cluster reports 150 free GPUs, but an 8-GPU job is Pending. What's the likely cause?</summary>
Fragmentation: the free GPUs are spread across nodes in small numbers, so no node has 8 free. Separate
pools, bin-packing, and queue-based admission fix it.
</details>

## Failure modes
- Fragmented GPU nodes: many free GPUs, none usable by whole-node jobs.
- Half-started distributed jobs holding GPUs without gang admission.
- CPU pods landing on GPU nodes because the nodes have no taints.
- StatefulSet volumes pinned to a failed zone, or backups never restored in a test.
- Operators broken by a Kubernetes upgrade, silently ignoring their resources.
- Helm values that skip probes, limits, or digests, because the chart doesn't enforce them.
- Public, unauthenticated notebooks or dashboards, and pods running as root with open egress.

## Checklist
- [ ] You can write a GPU pod spec with tolerations, GPU-model affinity, and priority
- [ ] You can explain fragmentation and how pools, bin-packing, and Kueue fix it
- [ ] You deployed a StatefulSet with per-pod volumes and zone spreading
- [ ] You can describe the reconcile loop and debug an operator via `status.conditions` and its logs
- [ ] Your Helm chart has helpers, `required` values, a schema, and passes `kubeconform` in CI
- [ ] You can launch a multi-node `PyTorchJob` admitted through Kueue
- [ ] Your namespaces enforce restricted pod security and default-deny network policies
- [ ] You deployed MLflow with PostgreSQL and MinIO on Kubernetes, and it survived pod deletion
