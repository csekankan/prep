# Section 43 — Infrastructure for Real-Time AI

> Lectures 295–301 • Assessments: quiz, [Evaluate an end-to-end latency SLO](#assessment--evaluate-an-end-to-end-latency-slo)
> • Exercise: [`s43_latency_slo.py`](../exercises/s43_latency_slo.py)
> **After this section you can:** set latency budgets for ads, fraud, and personalization, explain where tail latency
> comes from (queueing, fan-out, pauses, cold starts), build streaming feature pipelines with fresh, consistent
> features, deploy low-latency model APIs with timeouts, fallbacks, and hedging, scale two-stage recommendation
> systems, control the cost of always-on low-latency capacity, and build a real-time fraud detection pipeline.
>
> Builds on: [Section 14](../part04_networking_serving/s14_model_serving.md) and
> [Section 15](../part04_networking_serving/s15_advanced_serving.md) (serving),
> [Section 16](../part05_operating_production/s16_observability.md) (SLOs), and
> [Section 24](../part07_workloads/s24_data_pipelines.md) (streaming pipelines).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 295 | Real-time AI use cases (ads, fraud, personalization) | Each has a hard latency budget set by the business. The model gets only part of it |
| 296 | Latency challenges in real-time AI | Tails come from queueing, fan-out, pauses, and cold starts. Measure end to end with histograms |
| 297 | Streaming infrastructure for real-time AI | Kafka plus a stream processor keep online features fresh, and the same logic must feed training |
| 298 | Deploying low-latency APIs | Small fast models, warm keep-alive connections, tight timeouts, fallbacks, hedging, and load shedding |
| 299 | Scaling real-time recommendation systems | Retrieve thousands of candidates cheaply, rank hundreds precisely, and cache what you can |
| 300 | Cost challenges in real-time AI | Peak-sized, always-on capacity is expensive. Use cascades, CPUs for small models, and smart autoscaling |
| 301 | Lab: build real-time fraud detection pipeline | Kafka-compatible events, streaming features in Redis, a scoring API with fallback, and a latency benchmark |

```mermaid
flowchart LR
  EV["Event<br/>card swipe, page view, bid request"] --> API2["Scoring API<br/>timeout, fallback"]
  API2 --> FS["Online features<br/>Redis or other key-value store"]
  API2 --> MOD["Model<br/>small, warm, batched"]
  API2 --> DEC["Decision<br/>within budget"]
  API2 --> LOG2["Event log<br/>Kafka"]
  LOG2 --> SP["Stream processor<br/>windows, aggregates"]
  SP --> FS
  LOG2 --> OFF["Offline store<br/>training data"]
```

**How to read it:** an event, such as a card swipe, a page view, or an ad bid request, arrives at a scoring API. The API
reads fresh features from an online store, runs a small, warm model, and returns a decision within its latency budget,
using a timeout and fallback if a dependency is slow. It also writes the event to a Kafka log. A stream processor reads
the log, computes windowed aggregates, and updates the online features. The same log feeds the offline store used for
training.

**Terms in this diagram.**
- **Scoring API**: the service that receives a request and returns a prediction or decision.
- **Timeout, fallback**: the maximum time to wait for a dependency, and what to return instead when it's exceeded, such
  as a simple rule (Lecture 298).
- **Online features**: precomputed values about an entity (such as a card's spending in the last 10 minutes), stored in
  a fast key-value store for lookups in about a millisecond.
- **Redis**: a popular in-memory key-value store, often used as an online feature store or cache.
- **Warm, batched**: a model already loaded in memory with its code paths compiled, and requests grouped to use
  hardware efficiently (Section 15).
- **Kafka**: a distributed, durable event log (Section 24).
- **Stream processor, windows, aggregates**: a program (such as Flink, Spark Structured Streaming, or a simple
  consumer) that continuously computes values over time windows, such as counts and sums (Lecture 297).
- **Offline store**: historical feature and event data used to build training sets.

---

## Lecture 295 — Real-time AI use cases (ads, fraud, personalization)

**Why it matters.** In real-time AI, a late answer is a wrong answer. An ad bid that misses the auction deadline earns
nothing, and a fraud check that times out must approve or decline without the model. The business sets the latency
budget, and the infrastructure has to fit inside it.

**In plain words.** It's like a goalkeeper facing a penalty. There's no prize for the perfect dive half a second late.
Speed is part of being right.

**Architecture: latency budgets for three use cases.**

```mermaid
flowchart TB
  subgraph ADS["Ad auction, about 100 ms total"]
    A1["Network to bidder<br/>about 20 to 40 ms"] --> A2["Candidate ads + CTR model<br/>about 10 to 20 ms"] --> A3["Bid response"]
  end
  subgraph FRAUD["Card authorization, about 50 to 100 ms for risk"]
    F1["Features: card history<br/>1 to 5 ms"] --> F2["Model + rules<br/>5 to 20 ms"] --> F3["Approve, decline, challenge"]
  end
  subgraph PERS["Feed personalization, about 100 to 200 ms"]
    P4["Retrieve 1,000s of candidates"] --> P5["Rank 100s with a large model"] --> P6["Re-rank for diversity"]
  end
```

**How to read it:** an ad auction gives a bidder about 100 milliseconds in total. Network time takes a large part, so
selecting candidate ads and predicting click-through rates must fit in roughly 10 to 20 milliseconds. A card
authorization allows tens of milliseconds for risk scoring: a few milliseconds to read the card's history, then the
model and rules, then a decision to approve, decline, or challenge. A personalized feed has more time, about 100 to 200
milliseconds, split between retrieving thousands of candidates, ranking hundreds with a larger model, and re-ranking for
diversity. Budgets vary by company, but this order of magnitude is typical.

**Terms in this diagram.**
- **Ad auction, bidder**: in real-time bidding, an exchange asks bidders for a price for each ad slot and gives them a
  fixed deadline, often around 100 ms.
- **CTR model**: a click-through-rate model predicting how likely a user is to click an ad.
- **Card authorization**: the request a payment network sends to the card issuer for each purchase, which must be
  answered within a strict time limit.
- **Challenge**: asking for extra verification, such as a one-time code, instead of approving or declining.
- **Candidates, rank, re-rank**: a cheap step finds possibly relevant items, an expensive model orders them, and a final
  step adjusts the order for diversity, freshness, or business rules (Lecture 299).

**Core ideas.**
- **Budget top-down.** Start from the end-to-end deadline, subtract network time and other services, and give each
  stage a budget with headroom. The model usually gets less time than people expect.
- **Accuracy and latency trade.** A bigger model may be more accurate but miss the deadline more often. Evaluate models
  by value delivered within the deadline.
- **Decide what happens on a miss.** For fraud, a timeout falls back to rules. For ads, a missed bid loses the auction.
  For feeds, a fallback ranking (popular or cached results) is shown.
- **Freshness matters as much as speed.** A fraud model using card history from an hour ago misses an attack happening
  right now (Lecture 297).

**Example: winning by being faster.** An ad-tech company's CTR model improved offline accuracy by 2%, but its p99
latency rose from 12 ms to 28 ms, and timeouts at the exchange rose from 0.3% to 4% of bid requests. Revenue fell. They
distilled the model to fit the 15 ms budget (Section 36), kept most of the accuracy gain, and brought timeouts back
under 0.5%.

**Senior / FAANG best practice.** Write down the end-to-end deadline and each stage's budget with headroom, evaluate
models by value delivered within the deadline, define the behavior on a miss for every stage, and treat feature
freshness as part of the latency requirement.

---

## Lecture 296 — Latency challenges in real-time AI

**Why it matters.** Average latency hides the problem. A service with a 5 ms average can still have a p99 of 50 ms,
and with fan-out, most user requests can hit that tail. Real-time systems succeed or fail on their tails.

**In plain words.** A dinner party starts when the last guest arrives. If you invite ten friends who are each late 1 time
in 20, the dinner will start late about 40% of the time.

**Architecture: where tail latency comes from.**

```mermaid
flowchart LR
  QUE["Queueing<br/>high utilization"] --> TAIL["Tail latency<br/>p99, p99.9"]
  FAN["Fan-out<br/>wait for the slowest of N"] --> TAIL
  PAUSE["Pauses<br/>garbage collection, compaction"] --> TAIL
  COLD["Cold starts<br/>new pods, model loading, JIT"] --> TAIL
  NETW["Network<br/>extra hops, TLS handshakes, retries"] --> TAIL
  BATCHW["Batching wait<br/>waiting for a batch to fill"] --> TAIL
```

**How to read it:** six common causes feed tail latency: queueing when servers are busy, fan-out where a request waits
for the slowest of many calls, pauses such as garbage collection or database compaction, cold starts of new pods or
models, network costs such as extra hops, TLS handshakes, and retries, and the time requests wait for a batch to fill.

**Terms in this diagram.**
- **Tail latency, p99, p99.9**: the slowest requests. p99 is the latency that 99% of requests are faster than, and p99.9
  is the latency 99.9% are faster than.
- **Queueing, utilization**: requests waiting because servers are busy. Waiting time rises sharply as utilization
  approaches 100%.
- **Fan-out**: one request calling many backends in parallel, such as feature shards or index partitions.
- **Garbage collection, compaction**: pauses when a runtime frees memory (in Java, Go, or Python), or when a database
  reorganizes its storage.
- **JIT**: just-in-time compilation, which makes the first requests after a start slower (Section 36).
- **TLS handshakes**: the setup of an encrypted connection, which adds round trips unless connections are reused.

**Core ideas.**
- **Queueing math.** For a simple single-server queue, mean time in the system is 1 / (service rate − arrival rate).
  At 50% utilization it's twice the service time, at 90% ten times. Keep headroom on latency-critical services.
- **Fan-out amplification.** If each of N calls has probability p of being slow, the chance at least one is slow is
  1 − (1 − p)^N. With p = 0.5% and N = 8, that's 3.9%, so a 1-in-200 event shows up in the p99 (the assessment
  simulates this).
- **Percentiles don't add.** The sum of per-stage p99s overstates the end-to-end p99, and the average of p99s across
  servers is meaningless. Measure end to end, with histograms you can merge.
- **Remedies by cause.**
  - Headroom and autoscaling for queueing.
  - Hedged requests and fewer shards for fan-out.
  - Tuning or avoiding garbage collection for pauses.
  - Warmup and minimum replicas for cold starts.
  - Keep-alive connections and co-location for network.
  - Bounded batch waits for batching.

```python
import math
service_ms = 5.0
mu = 1000 / service_ms                              # 200 requests/s capacity
for util in (0.5, 0.8, 0.9, 0.95):
    lam = util * mu
    mean = 1000 / (mu - lam)                        # M/M/1: time in system is exponential with rate mu - lambda
    p99 = math.log(100) * mean
    print(f"utilization {util:.0%}: mean {mean:5.1f} ms, p99 {p99:6.1f} ms")
# utilization 50%: mean  10.0 ms, p99   46.1 ms
# utilization 80%: mean  25.0 ms, p99  115.1 ms
# utilization 90%: mean  50.0 ms, p99  230.3 ms
# utilization 95%: mean 100.0 ms, p99  460.5 ms
```

In the code, a server that takes 5 ms per request can handle 200 requests a second. In the simplest queueing model
(M/M/1: random arrivals, random service times, one server), time in the system follows an exponential distribution, so
its p99 is ln(100) ≈ 4.6 times the mean. Even at 50% utilization, the p99 is 46 ms, nine times the service time. Real
servers handle requests concurrently and do better, but the shape is the same: latency explodes as utilization nears
100%.

**Example: the p99 that tracked GC.** A personalization service had a 9 ms median and a 70 ms p99. Latency histograms
lined up exactly with Java garbage collection pauses in the feature service it called on every request. Switching to a
low-pause collector and reducing allocation per request cut the p99 to 18 ms with no hardware change.

**Senior / FAANG best practice.** Measure end-to-end latency with mergeable histograms, set SLOs on p99 or p99.9, keep
utilization headroom on latency-critical services, and attack tails by cause: hedging for fan-out, pause tuning, warmup
and minimum replicas, connection reuse, and bounded batch waits.

---

## Lecture 297 — Streaming infrastructure for real-time AI

**Why it matters.** Real-time models need features that describe what's happening now, such as how many purchases a
card made in the last 5 minutes. Batch pipelines that update hourly can't provide them, and computing them differently
in training and serving quietly breaks models.

**In plain words.** It's like a scoreboard at a game. It updates the moment a goal is scored, and the official record
later is built from the same events in the same order, so they always agree.

**Architecture: a streaming feature pipeline.**

```mermaid
flowchart LR
  SRC["Sources<br/>transactions, clicks, CDC"] --> KAFKA2["Kafka topics<br/>partitioned by entity key"]
  KAFKA2 --> FLINK["Stream processor<br/>Flink: event-time windows,<br/>watermarks, exactly-once state"]
  FLINK --> ONL["Online store<br/>Redis, latest values"]
  FLINK --> OFFL["Offline store<br/>feature history with timestamps"]
  KAFKA2 --> LAKE["Data lake<br/>raw events"]
  OFFL --> TRN["Training<br/>point-in-time joins"]
  ONL --> SRV["Scoring API"]
```

**How to read it:** sources such as transactions, clicks, and change data capture from databases write to Kafka topics,
partitioned by entity key (such as card ID). A stream processor such as Flink computes features over event-time
windows, using watermarks to handle late events and checkpointed state for exactly-once results. It writes the latest
values to the online store used by the scoring API, and the full history with timestamps to the offline store. Raw
events also land in the data lake. Training uses point-in-time joins on the offline store, so it sees exactly what
serving would have seen.

**Terms in this diagram.**
- **CDC**: change data capture, streaming every insert, update, and delete from a database (Section 24).
- **Partitioned by entity key**: all events for one card go to the same partition, so they're processed in order by
  one worker.
- **Flink**: Apache Flink, a stream processing engine with event-time windows and fault-tolerant state.
- **Event-time windows, watermarks**: windows based on when events happened, not when they arrived. A watermark is the
  processor's estimate that no older events are still coming, which decides when a window is complete (Section 24).
- **Exactly-once state**: state that is updated exactly once per event, even after failures, using checkpoints and
  transactional output.
- **Point-in-time joins**: building training rows using only feature values that existed at each event's time, to avoid
  leaking future information (Section 34).

**Core ideas.**
- **Freshness is measurable.** Track the lag from event time to online availability (consumer lag plus processing
  time) as an SLO, for example p99 under 2 seconds.
- **One definition, two outputs.** Compute each feature once in the stream processor and write it to both stores, or
  use a feature platform (Feast, Tecton, or a cloud feature store) that does so. Separate batch and streaming code paths
  cause training-serving skew.
- **Idempotent updates.** With at-least-once delivery, the same event may be processed twice. Use updates that can be
  repeated safely, such as setting a value or adding a uniquely identified member to a set, or use exactly-once
  processing.
- **Hot keys.** A few entities (a popular merchant, a bot) can overload one partition. Detect and split or pre-aggregate
  them.
- **Backpressure.** When the processor falls behind, lag grows. Alert on lag, and scale consumers up to the number of
  partitions.

**Example: features that lagged an attack.** A payments company computed "transactions in the last 10 minutes" in a
batch job every 15 minutes. A card-testing attack made 40 small purchases in 3 minutes, and none were caught because the
feature still showed zero. Moving the feature to a Flink job with sub-second freshness let the model block the attack
from the third transaction.

**Senior / FAANG best practice.** Partition events by entity, compute features with event-time windows and watermarks,
write each feature from one definition to both online and offline stores, make updates idempotent, and treat freshness
lag as an SLO with alerts. Watch for hot keys and consumer lag.

---

## Lecture 298 — Deploying low-latency APIs

**Why it matters.** A model that scores in 2 ms can still give a 40 ms API if requests open new connections, wait in
queues, or call slow dependencies without limits. Low-latency serving is mostly about everything around the model.

**In plain words.** A fast pit stop isn't only about how quickly the tires are changed. The crew is ready before the car
arrives, tools are in place, and if something jams, there's a backup plan instead of a long wait.

**Architecture: a low-latency scoring service.**

```mermaid
flowchart LR
  CLI["Caller<br/>keep-alive, gRPC or HTTP/2"] --> LB2["Load balancer<br/>least outstanding requests"]
  LB2 --> POD["Scoring pod<br/>warm model, CPU pinning"]
  POD -->|"timeout 5 ms, hedge"| FS2["Feature store"]
  POD --> MODEL2["Model in-process<br/>GBDT, ONNX Runtime, or Triton"]
  POD -->|"on timeout"| FB["Fallback<br/>rules or cached score"]
  POD --> SHED["Load shedding<br/>reject early when overloaded"]
```

**How to read it:** callers keep connections open and use gRPC or HTTP/2. A load balancer sends each request to the pod
with the fewest outstanding requests. The scoring pod has its model loaded and warmed, with CPU cores reserved. It calls
the feature store with a short timeout and hedging, and runs the model in-process, using a gradient-boosted tree
library, ONNX Runtime, or a Triton server next to it. If a dependency times out, it falls back to rules or a cached
score. When overloaded, it rejects requests early rather than letting every request get slow.

**Terms in this diagram.**
- **Keep-alive, gRPC, HTTP/2**: reusing open connections instead of opening a new one per request. **gRPC** is a
  binary RPC framework over HTTP/2, which sends many requests over one connection.
- **Least outstanding requests**: a load-balancing rule that picks the backend with the fewest requests in progress,
  which avoids queueing behind slow pods.
- **CPU pinning**: giving a pod dedicated CPU cores (Kubernetes' static CPU manager policy), so it isn't interrupted by
  other workloads.
- **Hedge**: sending a duplicate request to another replica if the first hasn't answered within a short delay, and
  using whichever answers first.
- **GBDT, ONNX Runtime, Triton**: gradient-boosted decision trees (such as XGBoost or LightGBM, which score in
  microseconds on CPU), a fast cross-platform inference engine (Section 35), and NVIDIA's inference server (Section 15).
- **Fallback**: a safe, fast answer when the normal path fails or is too slow.
- **Load shedding**: rejecting some requests quickly during overload, so the rest still meet their latency targets.

**Core ideas.**
- **Choose the smallest model that meets accuracy.** Tree models on CPU often beat neural networks for tabular fraud
  and risk at a fraction of the latency. GPUs help for large models, with dynamic batching and a bounded queue delay
  (for example Triton's `max_queue_delay_microseconds`).
- **Avoid per-request overhead.** Reuse connections, avoid JSON for large payloads (use protobuf), keep models in
  process, and minimize Python work in the hot path, or use multiple worker processes.
- **Timeouts everywhere, budget-aware.** Each call's timeout is derived from the remaining budget. Retry only if the
  budget allows, and never retry in multiple layers.
- **Warmup and capacity.** Send warmup requests before a pod joins the load balancer, keep minimum replicas, and
  autoscale on concurrency or latency rather than CPU alone.
- **Deploy safely.** Canary new models with latency and decision-rate guards, because a slower model can breach the
  SLO even if it's more accurate (Section 15).

**Example: the 30 ms of handshakes.** A fraud API's server-side latency was 4 ms, but callers measured 35 ms. Tracing
showed every request opened a new TLS connection through two proxies. Enabling keep-alive connection pooling in the
callers and removing one proxy hop brought client-side p50 to 6 ms and p99 to 14 ms.

**Senior / FAANG best practice.** Use the smallest model that meets accuracy, run it in process or next to the service,
reuse connections, set budget-aware timeouts with fallbacks, hedge fan-out calls, shed load early under overload, warm
pods before traffic, and autoscale on concurrency or latency. Canary models with latency guards.

---

## Lecture 299 — Scaling real-time recommendation systems

**Why it matters.** Recommendation systems choose from millions or billions of items for every request, in about 100
milliseconds, for hundreds of millions of users. Scoring every item with a large model is impossible, so they rely on a
staged architecture and heavy caching.

**In plain words.** It's like a talent show. First, quick auditions narrow thousands of entrants to a hundred, then
judges watch each of those carefully, and finally the show's producer arranges the final lineup.

**Architecture: a multi-stage recommender.**

```mermaid
flowchart LR
  U["User request<br/>user ID, context"] --> RET["Retrieval<br/>ANN on embeddings, several sources<br/>millions to thousands"]
  RET --> PRE["Pre-ranking<br/>light model<br/>thousands to hundreds"]
  PRE --> RANK["Ranking<br/>large model on GPU<br/>hundreds scored precisely"]
  RANK --> RR["Re-ranking<br/>diversity, freshness, policy"]
  RR --> OUT["Top 20 shown"]
  EMB["Embedding tables<br/>sharded, cached"] -.-> RET & RANK
```

**How to read it:** a user request with context goes to retrieval, which uses approximate nearest-neighbor search on
embeddings, from several sources, to narrow millions of items to thousands. A light pre-ranking model narrows those to
hundreds. A large ranking model, usually on GPUs, scores those precisely. Re-ranking adjusts the list for diversity,
freshness, and policy rules, and the top 20 are shown. Large embedding tables for users and items are sharded across
machines and cached, and both retrieval and ranking use them.

**Terms in this diagram.**
- **ANN on embeddings**: approximate nearest-neighbor search, finding items whose embedding vectors are closest to the
  user's, using indexes such as HNSW or IVF (Section 25).
- **Several sources**: different candidate generators, such as "similar to recently watched", "popular in your
  region", and "followed creators", whose results are merged.
- **Pre-ranking, light model**: a cheap model, such as a small two-tower network, that filters candidates before the
  expensive model.
- **Ranking, large model**: a deep model with many features, predicting engagement such as clicks or watch time.
- **Re-ranking**: final adjustments for diversity (not ten similar items), freshness, and policy rules.
- **Embedding tables, sharded**: tables mapping IDs to vectors, which can hold billions of rows and terabytes of data,
  split across many machines.

**Core ideas.**
- **Budget per stage.** For example: retrieval 20 ms, pre-ranking 10 ms, ranking 40 ms, and re-ranking 5 ms, inside a
  100 ms total with headroom.
- **Embedding tables dominate memory.** Shard them across hosts, keep hot rows cached on GPU or in memory, and use
  mixed precision or quantization for embeddings.
- **Precompute what you can.** Item embeddings and indexes are built offline and refreshed often, user embeddings are
  updated in near real time, and candidate lists for inactive users can be cached.
- **Batch candidates on GPUs.** Ranking hundreds of candidates per request is a natural batch. Combine requests with
  dynamic batching for throughput.
- **Freshness.** New items need embeddings quickly (a cold-start path), and user actions should influence the next
  request through streaming features (Lecture 297).

**Example: cutting ranking cost by 60%.** A video platform scored 2,000 candidates per request with its large ranker.
Adding a pre-ranking stage (a small two-tower model) to keep the top 400 cut GPU ranking cost by 60% and p99 latency by
25 ms. Engagement was unchanged, because the large model's top results almost always came from the pre-ranker's top
400.

**Senior / FAANG best practice.** Use multi-stage retrieval, pre-ranking, ranking, and re-ranking with explicit
per-stage budgets, shard and cache embedding tables, precompute item embeddings and indexes, batch candidates on GPUs,
and keep user signals fresh through streaming. Check each stage's recall against the stage after it.

---

## Lecture 300 — Cost challenges in real-time AI

**Why it matters.** Real-time capacity must be running before requests arrive, sized for peaks with headroom for tail
latency. That's the most expensive way to run compute, and it can't use cheap tricks like large batches or spot
interruptions as easily as offline work.

**In plain words.** It's like staffing an emergency room. You can't wait for patients before calling in doctors, so you
pay for readiness, and the savings come from triage: send minor cases to a nurse and save the specialists for serious
ones.

**Architecture: cost levers for real-time inference.**

```mermaid
flowchart TB
  TRAFFIC["Traffic<br/>daily peaks, spikes"] --> CAPP["Capacity<br/>min replicas + autoscaling"]
  CAPP --> CASC["Cascade<br/>cheap model first, expensive if unsure"]
  CASC --> HWC["Hardware fit<br/>CPU for small models, GPU for large, batched"]
  HWC --> CACHEC["Caching<br/>repeated requests, precomputed scores"]
  CACHEC --> UNIT["Cost per 1,000 decisions<br/>tracked per use case"]
```

**How to read it:** traffic has daily peaks and spikes. Capacity is a minimum number of replicas plus autoscaling. A
cascade runs a cheap model first and calls the expensive one only for uncertain cases. Each model runs on hardware
that fits it: CPUs for small models, and GPUs for large ones with batching. Caching reuses results for repeated
requests and precomputed scores. Cost per 1,000 decisions is tracked for every use case.

**Terms in this diagram.**
- **Daily peaks, spikes**: regular busy hours, and sudden surges such as a sale or breaking news.
- **Min replicas + autoscaling**: a floor of always-running servers for warm capacity, plus automatic scaling with load
  (Section 11).
- **Cascade**: a sequence of models, where cheap ones handle confident cases and expensive ones only the uncertain
  rest.
- **Hardware fit**: matching each model to the cheapest hardware that meets its latency target.
- **Precomputed scores**: predictions computed in advance (for example, nightly risk scores per customer) that the
  real-time path combines with fresh signals.
- **Cost per 1,000 decisions**: a unit cost metric, comparable across models and over time.

**Core ideas.**
- **Peak-to-average ratio.** If peak traffic is 3 times the average and capacity is fixed for the peak, average
  utilization is at most 33%. Autoscaling with warm minimums and predictive scaling (scaling ahead of known peaks)
  narrows the gap.
- **Cascades.** If a cheap model is confident for 90% of requests, the expensive model runs on 10%. Cost falls roughly
  in proportion, as long as the cheap model's confident cases are accurate (check with evals).
- **CPU vs GPU.** A tree model or a small network on CPU can cost a fraction of a GPU for the same latency. GPUs pay
  off for large models, with batching.
- **Headroom costs money.** Low utilization buys tail latency (Lecture 296). Decide the headroom from the SLO, not by
  habit.
- **Multi-tenant serving.** Several models sharing GPUs (MIG, or multi-model servers such as Triton) improve utilization
  for small models (Section 40).

**Example: the cascade that halved the bill.** A marketplace scored every search for fraud with a 300M-parameter model
on GPUs. A gradient-boosted tree on CPU, trained on the large model's labels, was confident (score below 0.02 or above
0.9) for 88% of requests. Sending only the remaining 12% to the GPU model cut inference cost by 54%, with the same fraud
catch rate and a lower median latency.

**Senior / FAANG best practice.** Track cost per 1,000 decisions per use case, set warm minimum replicas and predictive
autoscaling for peaks, use cascades with eval-checked confidence thresholds, put small models on CPU and large ones on
batched GPUs, cache and precompute where possible, and size headroom from the SLO.

---

## Lecture 301 — Lab: build real-time fraud detection pipeline

**Goal:** build a working real-time fraud pipeline on a laptop: a scoring API that reads streaming features from Redis
with a 5 ms timeout and a rule-based fallback, Redpanda (a Kafka-compatible broker) for events, a stream processor that
maintains each card's last 10 minutes of activity, and a benchmark measuring latency, fallbacks, and fraud caught.

**What you're building:** `gen.py` (synthetic transactions), `train.py` (a logistic regression model), `score.py` (a
FastAPI scoring service), `features.py` (a stream processor), and `bench.py` (a replay and latency benchmark).

```mermaid
flowchart LR
  BENCH["bench.py<br/>replays transactions"] -->|"POST /score"| SCORE["score.py<br/>FastAPI, 5 ms feature timeout"]
  SCORE -->|"read last 10 min"| REDIS["Redis<br/>sorted set per card"]
  SCORE -->|"publish event"| RP["Redpanda topic tx"]
  RP --> FEAT["features.py<br/>consumer: update window"]
  FEAT --> REDIS
  TRAIN2["train.py<br/>same feature logic offline"] -->|"model.json"| SCORE
```

**How to read the diagram:** `bench.py` replays transactions to the scoring service as a card network would. For each
one, `score.py` reads the card's last 10 minutes of transactions from Redis, scores it, and publishes the transaction
to the `tx` topic in Redpanda. `features.py` consumes the topic and updates each card's window in Redis. `train.py`
computes the same features offline and saves the model as `model.json`, which the scoring service loads.

The terms, briefly:
- **POST /score**: an HTTP POST request to the service's `/score` endpoint, carrying one transaction as JSON.
- **Redpanda**: a Kafka-compatible event streaming platform that runs as a single binary, convenient for labs. Kafka
  clients work unchanged.
- **Sorted set per card**: a Redis data type storing members with scores. Here, each member is a transaction and its
  score is the event time, so the last 10 minutes is a range query.
- **FastAPI**: a Python web framework for APIs (Section 14).
- **Consumer**: a program that reads events from a topic, here as part of a consumer group that tracks its position.

**Prerequisites:** Docker, Python 3.10+, and `pip install fastapi uvicorn "redis>=5" confluent-kafka httpx scikit-learn
numpy`.

### Step 1 — Infrastructure

```bash
mkdir rtfraud && cd rtfraud
cat > docker-compose.yml <<'EOF'
services:
  redpanda:
    image: docker.redpanda.com/redpandadata/redpanda:v24.2.7
    command: [redpanda, start, --mode, dev-container, --smp, "1",
              --kafka-addr, "PLAINTEXT://0.0.0.0:9092", --advertise-kafka-addr, "PLAINTEXT://localhost:9092"]
    ports: ["9092:9092"]
  redis:
    image: redis:7.4
    ports: ["6379:6379"]
EOF
docker compose up -d
docker compose exec redpanda rpk topic create tx -p 6
```

In the file, Redpanda runs in development mode with one CPU core, and advertises `localhost:9092` so clients on your
machine can connect. The topic `tx` gets 6 partitions, and events are keyed by card ID so each card's events stay in
order.

### Step 2 — Data and model

```python
# gen.py
import math, random

def transactions(n, seed=0, cards=5000, burst_p=0.0012, start=1_700_000_000.0, rate=50.0):
    """Synthetic card transactions in time order. Normal spending is random over all cards. Occasionally a card is
    compromised and makes a burst of 5-12 larger transactions within 5 minutes (label fraud=1)."""
    rng = random.Random(seed)
    t, out = start, []
    for _ in range(n):
        t += rng.expovariate(rate)
        out.append({"card_id": rng.randrange(cards), "amount": round(math.exp(rng.gauss(3.2, 0.9)), 2), "ts": t, "fraud": 0})
        if rng.random() < burst_p:
            victim = rng.randrange(cards)
            for _ in range(rng.randint(5, 12)):
                out.append({"card_id": victim, "amount": round(math.exp(rng.gauss(4.8, 0.6)), 2),
                            "ts": t + rng.uniform(0, 300), "fraud": 1})
    out.sort(key=lambda x: x["ts"])
    return out

def features(amount, history):
    """history: list of (ts, amount) for this card in the last 10 minutes, before this transaction."""
    return [math.log1p(amount), len(history), math.log1p(sum(a for _, a in history))]
```

```python
# train.py
import json
from collections import defaultdict, deque
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from gen import transactions, features

txs = transactions(300_000, seed=1)
hist = defaultdict(deque)
X, y = [], []
for tx in txs:
    h = hist[tx["card_id"]]
    while h and h[0][0] < tx["ts"] - 600:
        h.popleft()
    X.append(features(tx["amount"], list(h)))
    y.append(tx["fraud"])
    h.append((tx["ts"], tx["amount"]))
X, y = np.array(X), np.array(y)
cut = int(len(y) * 0.8)                                   # time-based split: train on the past, test on the future
sc = StandardScaler().fit(X[:cut])
clf = LogisticRegression(max_iter=1000).fit(sc.transform(X[:cut]), y[:cut])
p = clf.predict_proba(sc.transform(X[cut:]))[:, 1]
coef = clf.coef_[0] / sc.scale_                            # fold scaling into the weights, so serving needs no scaler
intercept = clf.intercept_[0] - float((clf.coef_[0] * sc.mean_ / sc.scale_).sum())
neg = np.sort(p[y[cut:] == 0])
thr = float(neg[int(len(neg) * 0.995)])                   # flag at most 0.5% of legitimate transactions
recall = float((p[y[cut:] == 1] > thr).mean())
print(f"{len(y):,} transactions, fraud rate {y.mean():.2%}")
print(f"test AUC {roc_auc_score(y[cut:], p):.3f}; threshold {thr:.3f} flags 0.5% of legit and catches {recall:.0%} of fraud")
json.dump({"coef": coef.tolist(), "intercept": float(intercept), "threshold": thr}, open("model.json", "w"))
```

```bash
python3 train.py
```

In the code, `gen.py` creates normal transactions at random across 5,000 cards, plus rare bursts of larger
transactions on a compromised card. `features` gives three values per transaction: the log of the amount, the number of
the card's transactions in the previous 10 minutes, and the log of their total. `train.py` computes those features in
time order, exactly as the stream will, trains on the first 80% of time and tests on the last 20%, then sets the
threshold so only 0.5% of legitimate transactions are flagged. The scaler is folded into the weights, so the serving
code is just a dot product and a sigmoid. On macOS, some NumPy builds print spurious `RuntimeWarning: ... matmul`
messages here, which don't affect the results.

### Step 3 — Scoring service and stream processor

```python
# score.py: uvicorn score:app --port 8000 --log-level warning
import json, math, time
import redis.asyncio as redis
from redis.exceptions import ConnectionError as RedisConnectionError, TimeoutError as RedisTimeout
from confluent_kafka import Producer
from fastapi import FastAPI
from pydantic import BaseModel

M = json.load(open("model.json"))
r = redis.Redis(host="localhost", port=6379, socket_timeout=0.005, socket_connect_timeout=0.005)
producer = Producer({"bootstrap.servers": "localhost:9092", "linger.ms": 5})
app = FastAPI()

class Tx(BaseModel):
    card_id: int
    amount: float
    ts: float
    fraud: int = 0           # the label, only so the benchmark can score results; real requests don't carry it

@app.post("/score")
async def score(tx: Tx):
    t0 = time.perf_counter()
    fallback, p = False, None
    try:
        rows = await r.zrangebyscore(f"card:{tx.card_id}", tx.ts - 600, f"({tx.ts}")
        hist = [float(m.split(b":")[1]) for m in rows]
        x = [math.log1p(tx.amount), len(hist), math.log1p(sum(hist))]
        p = 1 / (1 + math.exp(-(M["intercept"] + sum(c * v for c, v in zip(M["coef"], x)))))
        flag = p > M["threshold"]
    except (RedisTimeout, RedisConnectionError):
        fallback, flag = True, tx.amount > 500            # rule used when features are unavailable
    producer.produce("tx", json.dumps(tx.model_dump()).encode(), key=str(tx.card_id))
    producer.poll(0)
    return {"flag": flag, "score": p, "fallback": fallback, "server_ms": (time.perf_counter() - t0) * 1000}
```

```python
# features.py: python3 features.py
import json, redis
from confluent_kafka import Consumer

r = redis.Redis()
c = Consumer({"bootstrap.servers": "localhost:9092", "group.id": "features", "auto.offset.reset": "earliest"})
c.subscribe(["tx"])
n = 0
while True:
    msgs = [m for m in c.consume(500, timeout=0.05) if not m.error()]
    if not msgs:
        continue
    pipe = r.pipeline(transaction=False)
    for m in msgs:
        tx = json.loads(m.value())
        key = f"card:{tx['card_id']}"
        pipe.zadd(key, {f"{tx['ts']:.6f}:{tx['amount']}": tx["ts"]})
        pipe.zremrangebyscore(key, "-inf", tx["ts"] - 600)
        pipe.expire(key, 900)
    pipe.execute()
    n += len(msgs)
    print(f"\r{n} events applied", end="")
```

In `score.py`, the Redis client has a 5 ms timeout, so a slow or unavailable feature store can't push the request past
its budget. The range query reads the card's transactions from the 10 minutes before this one (the `(` makes the upper
bound exclusive). On a timeout, a simple amount rule decides. Every scored transaction is published to `tx`, keyed by
card. The producer batches messages for up to 5 ms in the background, so publishing doesn't add to the request's
latency.

In `features.py`, the consumer reads batches of up to 500 events and applies them in one Redis pipeline. Each event adds
a member named by its time and amount (so replaying the same event sets the same member again, which makes updates
idempotent), removes members older than 10 minutes in event time, and sets an expiry so idle cards disappear.

### Step 4 — Benchmark and failure test

```python
# bench.py: python3 bench.py <concurrency> <transactions>
import asyncio, sys, time
import httpx
from gen import transactions

async def main(conc=16, n=20000):
    q = asyncio.Queue()
    for tx in transactions(n, seed=2):
        q.put_nowait(tx)
    lat, res = [], []
    async with httpx.AsyncClient(base_url="http://localhost:8000", limits=httpx.Limits(max_keepalive_connections=conc)) as cl:
        async def worker():
            while not q.empty():
                tx = q.get_nowait()
                t0 = time.perf_counter()
                out = (await cl.post("/score", json=tx, timeout=1.0)).json()
                lat.append((time.perf_counter() - t0) * 1000)
                res.append((tx["fraud"], out["flag"], out["fallback"], out["server_ms"]))
        start = time.perf_counter()
        await asyncio.gather(*[worker() for _ in range(conc)])
        wall = time.perf_counter() - start
    pct = lambda v, p: sorted(v)[int(p * (len(v) - 1))]
    srv = [x[3] for x in res]
    fraud, legit = [x for x in res if x[0] == 1], [x for x in res if x[0] == 0]
    print(f"{len(res)} requests in {wall:.1f}s = {len(res) / wall:.0f} req/s at concurrency {conc}")
    print(f"client p50 {pct(lat, .5):.1f} ms  p99 {pct(lat, .99):.1f} ms;  server p50 {pct(srv, .5):.2f} ms  p99 {pct(srv, .99):.2f} ms")
    print(f"fallbacks {sum(x[2] for x in res)};  fraud caught {sum(x[1] for x in fraud) / len(fraud):.0%};  "
          f"legit flagged {sum(x[1] for x in legit) / len(legit):.2%}")

asyncio.run(main(*map(int, sys.argv[1:])))
```

```bash
uvicorn score:app --port 8000 --log-level warning &      # terminal 1
python3 features.py &                                     # terminal 2
docker compose exec redis redis-cli FLUSHALL
python3 bench.py 16 20000                                 # normal run
docker compose exec redis redis-cli FLUSHALL
python3 bench.py 1 5000                                   # slow replay: fresher features
docker compose pause redis; python3 bench.py 16 2000; docker compose unpause redis    # feature store down
docker compose exec redpanda rpk group describe features  # consumer lag per partition
```

In the commands, `FLUSHALL` clears Redis before each replay so windows start empty. The first run replays transactions
as fast as 16 concurrent workers can send them, which squeezes many minutes of event time into seconds. The second run
replays one at a time. The third pauses the Redis container, so every feature read times out after 5 ms. The last
command shows the stream processor's lag.

**Expected results:**
- `train.py` prints about 303,000 transactions with a 1.00% fraud rate, test AUC about 0.97, and a threshold that flags
  0.5% of legitimate transactions while catching about 60% of fraud. The first transaction of each burst is almost
  never caught, because its card has no recent history: real systems add device, merchant, and location features for
  that.
- The normal run handles several hundred to a few thousand requests a second on a laptop, with server-side p99 of a few
  milliseconds and client p99 typically under 20 ms. There are no fallbacks.
- Fraud caught in the fast replay is somewhat below the offline 60%, because the stream processor lags behind a replay
  compressed into seconds: features miss the most recent transactions. The slow replay gets closer to the offline
  number. That gap is training-serving skew from feature freshness, made visible.
- With Redis paused, every request falls back to the amount rule, and server latency stays bounded by the 5 ms timeout
  instead of hanging.
- `rpk group describe features` shows lag near zero once the replay ends.

---

## Assessment — Evaluate an end-to-end latency SLO

**Scenario.** A card issuer's fraud scoring path must meet p99 ≤ 30 ms end to end. The path has a network round trip,
a gateway, parallel lookups to 8 feature store shards (each shard occasionally stalls for about 20 ms, 0.5% of calls), a
batched model, and business rules. Per-stage dashboards all look healthy. Evaluate whether the SLO is met, explain why
or why not, and test hedged feature requests as a fix.

**Task.**

```bash
python3 exercises/s43_latency_slo.py
```

**Formulas.**
- Probability a request hits at least one stall across N shards = 1 − (1 − p)^N.
- p-quantile = the value below which that share of samples falls (computed from 200,000 simulated requests).
- Hedged call = the first response, if it arrives within 2 ms. Otherwise, the faster of the first response and a second
  request sent at 2 ms.

**Expected output:**

| Measure | Without hedging | With hedging after 2 ms |
|---|---|---|
| One shard's p99 | 2.87 ms | — |
| Chance a request hits a stall (8 shards) | 3.93% | — |
| Features stage p99 | 21.13 ms | 3.30 ms |
| Sum of stage p99s | 45.58 ms | — |
| End-to-end p50 | 15.16 ms | about the same |
| End-to-end p99 | 35.77 ms (SLO missed) | 21.28 ms (SLO met) |
| End-to-end p99.9 | 39.38 ms | 24.15 ms |
| Requests over 30 ms | 3.96% (SLO allows 1%) | 0.02% |
| Extra shard calls from hedging | — | 3.8% |

All 8 checks print `PASS`.

**What a strong answer explains:**
- **Every shard looks healthy, but the request doesn't.** Each shard's p99 is under 3 ms, because stalls happen in only
  0.5% of calls. Fan-out to 8 shards makes 3.9% of requests wait for a stall, which puts it into the end-to-end p99.
- **The SLO is missed.** 3.96% of requests are over 30 ms against an allowance of 1%, and the p99 is 35.8 ms.
- **Adding stage p99s is wrong.** 45.6 ms overstates the real p99, because stages are rarely slow at the same time. Only
  end-to-end measurement tells the truth.
- **Hedging fixes the tail cheaply.** Sending a second request after 2 ms makes a stall matter only if both copies
  stall, bringing p99 to 21.3 ms. It costs 3.8% extra shard calls and leaves the median unchanged.
- **Alternatives and their trade-offs.** Fewer, larger shards reduce fan-out. Fixing the stall cause (garbage
  collection or compaction tuning) removes it at the source. A tighter timeout with a fallback bounds latency but
  lowers accuracy when it fires.
- **Monitoring.** Alert on end-to-end p99 and the share of requests over the SLO, not per-stage averages.

---

## FAANG deep-dive notes

**How big tech does it.** Real-time AI is the core of the largest internet businesses. Ad platforms score huge numbers
of candidate ads for every request within tight deadlines, using multi-stage ranking and heavily optimized serving.
Payment companies score every card transaction within the authorization window, with streaming features and rule
fallbacks. Feed and video recommenders use retrieval, pre-ranking, ranking, and re-ranking, with sharded embedding
tables and GPUs for the ranking stage. Google's paper *The Tail at Scale* popularized hedged and tied requests to tame
fan-out tails. All of them measure end-to-end latency with histograms and treat feature freshness as an SLO.

**Staff review questions.**
- What's the end-to-end deadline, and how is it divided between stages?
- What happens when each stage misses its budget?
- What's the fan-out, and how are tails from slow backends handled?
- How fresh are features, and is freshness measured?
- Are training features computed with the same logic as serving features?
- What's the cost per 1,000 decisions, and how much headroom does the SLO need?

**Interview question.** "Design a real-time fraud detection system for 20,000 card transactions per second."

**Typical system-design prompt:** *Design fraud scoring for a card issuer: 20,000 authorizations per second at peak, a
50 ms budget for risk, and features covering the last minutes, hours, and days.*

**1. Clarify first:** Peak vs average traffic? Decline vs challenge options? Acceptable false positive rate? Which
features need second-level freshness? Regions and residency? Fallback policy when the model is unavailable?

**2. Back-of-envelope sizing:**
- 20,000 requests a second × about 10 feature lookups = 200,000 key-value reads a second. A Redis cluster with a few
  shards handles that, with replicas for availability.
- Model: a gradient-boosted tree at about 0.2 ms per score on one core. 20,000 a second needs about 4 cores of pure
  model time, so plan 40 to 60 cores across pods, including the service overhead, headroom, and two regions.
- Events: 20,000 a second × 1 KB = 20 MB/s into Kafka, partitioned by card, with 7-day retention: about 12 TB with
  replication factor 1, 36 TB with 3.
- Budget: network 10 ms, features 5 ms with hedging, model 5 ms, rules 5 ms, total about 25 ms of the 50 ms, leaving
  headroom.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Model type | Deep network on GPU | GBDT on CPU | GBDT for tabular, deep models for sequences if budget allows |
| Feature freshness | Hourly batch | Streaming | Streaming for velocity features, batch for long-term |
| Timeout behavior | Wait | Fallback to rules | Fallback within budget |
| Fan-out tails | Accept | Hedge | Hedge after about the p95 delay |
| Capacity | Fixed for peak | Warm minimum + autoscaling | Warm minimum + predictive autoscaling |

**4. Follow-up questions with crisp answers:**
- *The feature store is slow in one region.* Hedge to replicas, fall back to rules when the budget is spent, and alert on
  the fallback rate.
- *How do you keep training and serving features consistent?* One feature definition writing to both online and
  offline stores, with point-in-time joins for training.
- *A new model is more accurate but 10 ms slower.* Evaluate value within the deadline and timeout rates in a canary
  before deciding.
- *Traffic doubles on Black Friday.* Predictive scaling ahead of time, load tests at 2–3 times peak, and load shedding
  to the rules path.

**Debug this (common onsite question):** "Fraud losses rose 30% in a week, but model metrics on the offline test set
are unchanged."
1. Online, the velocity features (transactions in the last 10 minutes) are much lower than offline for the same cards.
2. Consumer lag on the feature stream is 9 minutes since a deployment that halved consumer instances.
3. The model sees stale features, so bursts look like single transactions.
4. Fix: restore consumers and alert on freshness lag, add a freshness check to the scoring path (fallback rules if
   features are stale), and compare online and offline feature distributions daily.

The lesson: in real-time AI, feature freshness is a correctness property, not just a performance one.

**5. What separates senior from staff answers:** a senior engineer builds a fast scoring service. A staff engineer starts
from the business deadline, budgets every stage, designs behavior on misses, handles fan-out tails and feature freshness
as SLOs, keeps training and serving features consistent, and runs the system at a known cost per decision.

**Red flags:**
- Average latency as the SLO.
- Adding per-stage p99s.
- No timeouts or fallbacks on dependencies.
- Batch-computed velocity features for fraud.
- Separate feature code for training and serving.
- Autoscaling only on CPU for latency-critical services.
- Peak capacity always on with no cascade or caching.

---

## Quiz

<details><summary>1. Why can a backend with a healthy p99 still break an end-to-end p99 SLO?</summary>
Fan-out. If a request waits for the slowest of N calls, a rare slow event becomes common: with p = 0.5% and N = 8, 3.9% of
requests hit it.
</details>

<details><summary>2. Why is the sum of per-stage p99s a poor estimate of the end-to-end p99?</summary>
Stages are rarely slow at the same time, so the sum overstates it. Percentiles don't add, so measure end to end.
</details>

<details><summary>3. What is a hedged request?</summary>
Sending a second copy of a request to another replica if the first hasn't answered within a short delay, and using whichever
responds first. It cuts tail latency for a small amount of extra load.
</details>

<details><summary>4. Why does latency rise sharply as utilization approaches 100%?</summary>
Queueing: waiting time grows as 1 / (service rate − arrival rate), so at 90% utilization the mean time is ten times the
service time in a simple queue.
</details>

<details><summary>5. What causes training-serving skew in streaming features?</summary>
Different code paths for training and serving features, or stale online features (consumer lag) that don't match what
training assumed.
</details>

<details><summary>6. Why do recommenders use multiple stages?</summary>
Scoring millions of items with a large model per request is too slow and expensive, so cheap retrieval and pre-ranking
narrow candidates for the expensive ranker.
</details>

<details><summary>7. How does a model cascade reduce cost?</summary>
A cheap model handles confident cases, and the expensive model runs only on the uncertain rest, so its cost scales with
that smaller share.
</details>

## Failure modes
- SLOs set on averages, or per-stage metrics without end-to-end measurement.
- Dependencies called without timeouts, budgets, or fallbacks.
- Fan-out tails from rare backend stalls.
- Stale online features from consumer lag, unmonitored.
- Different feature logic in training and serving.
- Cold pods taking traffic before warmup.
- Running near full utilization on latency-critical services.
- Retries stacked in several layers, amplifying overload.

## Checklist
- [ ] End-to-end deadline and per-stage budgets are written down, with behavior on misses
- [ ] Latency is measured end to end with histograms, and SLOs are set on p99 or p99.9
- [ ] Fan-out calls use hedging or fewer shards, and dependencies have timeouts and fallbacks
- [ ] Streaming features use one definition for online and offline, and freshness is an SLO
- [ ] Models are the smallest that meet accuracy, warm, and served with reused connections
- [ ] Cost per 1,000 decisions is tracked, with cascades and right-sized hardware
- [ ] You built and benchmarked a real-time fraud pipeline, including a feature store failure
- [ ] You ran the assessment and can explain why fan-out breaks the SLO and how hedging fixes it
