# Section 44 — Infrastructure for Autonomous Systems

> Lectures 302–308 • Assessments: quiz, [Conduct a safety-critical deployment review](#assessment--conduct-a-safety-critical-deployment-review)
> **After this section you can:** describe the data engine behind self-driving cars, explain the robotics software stack
> (ROS 2, control loops, edge compute), design sensor fusion data pipelines with time sync and calibration, apply
> safety-critical patterns (safety monitors, fallbacks, watchdogs, standards), plan simulation infrastructure at scale,
> deploy and update models on robot fleets, and run a trained robot policy in a fixed-rate control loop with a safety
> envelope.
>
> Builds on: [Section 19](../part05_operating_production/s19_reliability_ha.md) (reliability),
> [Section 21](../part06_edge_mobile/s21_edge_ai_basics.md) and
> [Section 22](../part06_edge_mobile/s22_edge_optimization.md) (edge AI),
> [Section 27](../part07_workloads/s27_computer_vision.md) (computer vision), and
> [Section 30](../part07_workloads/s30_reinforcement_learning.md) (reinforcement learning).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 302 | AI infra in self-driving cars | A data engine: the fleet finds hard cases, the cloud trains on them, simulation validates, and OTA ships |
| 303 | Robotics AI infrastructure basics | ROS 2 nodes and topics, fast control loops under slower perception, and edge GPUs on the robot |
| 304 | Sensor fusion data pipelines | Time-synchronized, calibrated sensors, logged in replayable formats, and auto-labeled offline |
| 305 | Real-time AI in safety-critical systems | ML proposes, a simpler verified monitor checks, and a fallback reaches a safe state on any doubt |
| 306 | Simulation infrastructure for autonomous vehicles | Log replay and closed-loop scenarios on thousands of machines gate every release |
| 307 | Edge deployment in robotics | Optimized models, signed images, A/B updates with rollback, and staged fleet rollouts |
| 308 | Lab: deploy AI agent for robotics simulation | Train a policy in MuJoCo, export to ONNX, and run it at 50 Hz with a watchdog and safety envelope |

```mermaid
flowchart LR
  FLEET["Fleet<br/>vehicles, robots"] -->|"triggered clips"| INGEST["Ingest + sensor fusion data<br/>sync, calibrate, store"]
  INGEST --> LABEL["Auto-labeling<br/>large offline models + humans"]
  LABEL --> TRAINA["Training<br/>GPU cluster"]
  TRAINA --> SIMV["Simulation validation<br/>log replay, scenarios"]
  SIMV --> SAFE["Safety case review"]
  SAFE -->|"staged OTA"| FLEET
```

**How to read it:** autonomous systems run in a loop. The fleet of vehicles or robots uploads short clips when
something interesting happens. They're ingested, time-synchronized, and calibrated, then labeled automatically by
large offline models with human checks. Models train on GPU clusters, are validated in simulation by replaying logs and
running scenarios, and pass a safety review before being shipped to the fleet in stages with over-the-air updates.

**Terms in this diagram.**
- **Fleet**: all deployed vehicles or robots running the software.
- **Triggered clips**: short recordings uploaded only when a trigger fires (such as a hard brake, a disagreement between
  model and driver, or a rare object), because uploading everything is impossible.
- **Sensor fusion data**: combined data from cameras, lidar, radar, and motion sensors (Lecture 304).
- **Auto-labeling**: using large, slow offline models (which can look at the whole clip, including the future) to label
  data, with humans checking samples and hard cases.
- **Log replay, scenarios**: re-running recorded drives through new software, and testing designed situations in
  simulation (Lecture 306).
- **Safety case**: a structured argument with evidence that the system is acceptably safe for its intended use
  (Lecture 305).
- **Staged OTA**: over-the-air software updates released to small groups first, then wider (Lecture 307).

---

## Lecture 302 — AI infra in self-driving cars

**Why it matters.** Self-driving is the most demanding AI infrastructure problem outside frontier model training: it
combines car-side compute under strict power and latency limits, petabytes of sensor data, huge training clusters, and
simulation, all under safety regulation. Its central idea, the data engine, applies to any autonomous system.

**In plain words.** It's like training a new driver with a coach in the passenger seat. Most of the drive is boring,
so the coach only notes the tricky moments, practices those again and again, and only lets the driver take a harder
route after passing a test.

**Architecture: car and cloud.**

```mermaid
flowchart TB
  subgraph CAR["On the vehicle"]
    SENS["Sensors<br/>8 to 12 cameras, radar, lidar or not"] --> SOC["Vehicle computer<br/>DRIVE Orin or Thor, custom chips"]
    SOC --> PLAN["Perception, prediction, planning"]
    PLAN --> ACT["Control<br/>steering, braking"]
    SOC --> TRIG["Trigger logic<br/>save interesting clips"]
  end
  subgraph CLOUD2["In the data center"]
    STORE2["Clip storage<br/>petabytes"] --> TRN2["Training<br/>thousands of GPUs"]
    TRN2 --> SIM2["Simulation + evaluation"]
  end
  TRIG -->|"upload when connected"| STORE2
  SIM2 -->|"OTA release"| SOC
```

**How to read it:** on the vehicle, 8 to 12 cameras plus radar (and lidar on some designs) feed a vehicle computer,
such as NVIDIA DRIVE Orin or Thor, or a custom chip. It runs perception, prediction, and planning, and sends commands
to steering and braking. Trigger logic saves interesting clips, which upload when the car is connected. In the data
center, clips are stored (petabytes in total), used for training on thousands of GPUs, then simulation and evaluation
decide whether a new version ships back to the car as an over-the-air release.

**Terms in this diagram.**
- **Lidar**: a sensor that measures distance with laser pulses, producing 3D point clouds. Some companies (such as
  Waymo) use it, and others (such as Tesla) rely on cameras.
- **Radar**: a sensor measuring distance and speed with radio waves, robust in rain and fog.
- **DRIVE Orin or Thor, custom chips**: NVIDIA's automotive computers (Orin delivers about 250 TOPS, and Thor is the next
  generation), and in-house chips such as Tesla's FSD computer.
- **Perception, prediction, planning**: detecting objects and lanes, predicting how other road users will move, and
  choosing the car's path. End-to-end systems learn more of this in one network.
- **Petabytes**: millions of gigabytes. Large AV programs store many petabytes of sensor data.

**Core ideas.**
- **Car-side limits.** A power budget of tens to a few hundred watts, automotive temperature ranges, deterministic
  latency (sensor to actuator in roughly 100 ms or less), and no reliance on connectivity.
- **Data volume.** A test vehicle with full sensors can record several terabytes a day. Production fleets upload only
  triggered clips, chosen by rules, model uncertainty, or "shadow mode" disagreements.
- **Shadow mode.** A new model runs on the car without controlling it, and its decisions are compared with the active
  system or the human driver. Disagreements become training data and evaluation signals.
- **The data engine.** Find failure cases, mine similar cases across the fleet's data, label them, retrain, validate in
  simulation, and deploy. The speed of this loop is the main competitive advantage.
- **Offboard compute.** Training uses large GPU clusters, and simulation and auto-labeling use as much compute again.

**Example: the overturned truck.** A perception model rarely saw overturned trucks, and treated one as a low obstacle
in shadow mode. Engineers built a trigger for "large object with unusual shape on road", which collected 4,000
similar clips from the fleet in two weeks. Auto-labeling plus human review produced training data, and the next model
version handled the case in simulation and in shadow mode before release.

**Senior / FAANG best practice.** Build the data engine as the core system: triggers and shadow mode on the fleet,
efficient upload and storage, auto-labeling with human review, mining for similar cases, training, and simulation gates
before staged OTA releases. Design car-side software for fixed power, deterministic latency, and no connectivity.

---

## Lecture 303 — Robotics AI infrastructure basics

**Why it matters.** Robots combine fast, deterministic control with slower AI perception and planning, on computers
with limited power, often in places with poor connectivity. The software framework, compute layout, and data logging
decide how quickly a robotics team can improve its robots.

**In plain words.** A robot is like a person catching a ball. The reflexes in the arm react in milliseconds, while the
eyes and brain take longer to judge where the ball is going. Both must work together, and the reflexes can't wait for
the brain.

**Architecture: a robot software stack.**

```mermaid
flowchart TB
  CAM2["Cameras, depth, lidar"] --> PERC["Perception node<br/>10 to 30 Hz, GPU"]
  IMU2["IMU, joint encoders"] --> CTRL["Control loop<br/>100 Hz to 1 kHz, real-time CPU"]
  PERC --> PLANR["Planner or policy<br/>1 to 30 Hz, may be a VLA model"]
  PLANR --> CTRL
  CTRL --> MOT["Motors, actuators"]
  PERC & PLANR & CTRL --> BAG["Logging<br/>rosbag2 in MCAP format"]
  BAG --> FM["Fleet manager<br/>upload, monitoring, updates"]
```

**How to read it:** cameras, depth sensors, and lidar feed a perception node that runs at 10 to 30 times a second on a
GPU. Motion sensors and joint encoders feed a control loop running 100 to 1,000 times a second on a real-time CPU.
Perception feeds a planner or learned policy (possibly a vision-language-action model), which sends goals to the
control loop, which drives the motors. All nodes log to rosbag2 files in MCAP format, and a fleet manager handles
upload, monitoring, and updates.

**Terms in this diagram.**
- **Node**: in ROS 2, a process that does one job and communicates with others by publishing and subscribing to
  **topics** (named message streams).
- **Hz**: hertz, times per second. A 1 kHz loop runs every millisecond.
- **IMU, joint encoders**: an inertial measurement unit (accelerometers and gyroscopes) and sensors that measure each
  joint's angle.
- **Real-time CPU**: a processor running a real-time operating system or a real-time Linux kernel, so the control loop
  always runs on time.
- **VLA model**: vision-language-action model, a large model that takes images and instructions and outputs robot
  actions (such as Google's RT-2, OpenVLA, and Physical Intelligence's π0).
- **rosbag2, MCAP**: ROS 2's recording tool, and an open file format for timestamped multi-sensor logs that can be
  replayed.
- **Fleet manager**: software that tracks robots, collects logs and telemetry, and deploys updates (Lecture 307).

**Core ideas.**
- **ROS 2.** The standard open-source robotics framework, built on DDS (a publish-subscribe middleware) with
  quality-of-service settings for reliability and latency. It provides drivers, navigation (Nav2), and manipulation
  (MoveIt).
- **Separate rates and criticality.** Control loops must never wait for perception. Run them on separate cores or
  processors, with the last good command held and a timeout to a safe stop if the planner goes silent.
- **Edge compute.** NVIDIA Jetson Orin modules (up to about 275 TOPS at 15–60 W) are common, with TensorRT for
  inference (Section 22). Heavy planning or VLA models may run on a nearby server, with an on-robot fallback.
- **Learning from data.** Teleoperation and demonstrations create training data for imitation learning. Simulation
  creates data for reinforcement learning (Section 30). Both need good logging and curation infrastructure.
- **Fleet operations.** Remote monitoring, log upload when on Wi-Fi, remote assistance for stuck robots, and staged
  software updates.

**Example: the control loop that waited.** A mobile robot's motor controller ran in the same Python process as its
object detector. When the detector slowed to 200 ms on a cluttered scene, motor commands were late and the robot
jerked. Moving control to a separate real-time process at 200 Hz, holding the last velocity command, and stopping
smoothly if no new command arrived within 300 ms fixed the jerks and made the robot safe during detector stalls.

**Senior / FAANG best practice.** Use ROS 2 or an equivalent framework with clear nodes and topics, separate real-time
control from AI perception and planning, size edge compute to the power budget, log everything in replayable formats,
and build fleet tooling for logs, monitoring, and updates from the start.

---

## Lecture 304 — Sensor fusion data pipelines

**Why it matters.** Fusion models combine cameras, lidar, radar, and motion sensors. If timestamps are off by 50 ms or
calibration is slightly wrong, a lidar point lands on the wrong pixel and training data teaches the wrong thing. Data
pipelines must preserve time and geometry exactly.

**In plain words.** It's like assembling a film from several cameras at a concert. If the clocks aren't synchronized,
the singer's lips don't match the sound, and if you don't know where each camera stood, you can't combine the views.

**Architecture: a sensor data pipeline.**

```mermaid
flowchart LR
  SNS["Sensors<br/>cameras, lidar, radar, IMU, GNSS"] --> SYNC["Time sync<br/>PTP hardware clocks"]
  SYNC --> LOGR["On-vehicle logger<br/>MCAP, compressed"]
  LOGR --> UPL["Upload<br/>triggered clips"]
  UPL --> DEC["Decode + align<br/>interpolate to common times"]
  CAL["Calibration<br/>intrinsics, extrinsics"] --> DEC
  DEC --> FUSE["Fusion views<br/>BEV, projected points"]
  FUSE --> ALBL["Auto-label + QA"]
  ALBL --> CUR["Curated datasets<br/>versioned, searchable"]
```

**How to read it:** sensors (cameras, lidar, radar, motion sensors, and satellite positioning) share synchronized
hardware clocks. An on-vehicle logger records compressed MCAP files, and triggered clips are uploaded. In the data
center, data is decoded and aligned to common timestamps, using calibration parameters describing each sensor's lens
and position. The pipeline then builds fused views, such as a bird's-eye view or lidar points projected onto images,
auto-labels them with quality checks, and adds them to curated, versioned, searchable datasets.

**Terms in this diagram.**
- **GNSS**: global navigation satellite systems, such as GPS and Galileo, which also provide accurate time.
- **PTP hardware clocks**: Precision Time Protocol (IEEE 1588), which synchronizes clocks across devices on a network to
  within microseconds or better.
- **Decode + align, interpolate**: decompressing data and matching samples taken at different times, for example by
  interpolating the vehicle's position to each camera frame's timestamp.
- **Intrinsics, extrinsics**: a camera's internal parameters (focal length, lens distortion), and each sensor's position
  and orientation relative to the vehicle.
- **BEV**: bird's-eye view, a top-down grid representation that many fusion models use to combine sensors.
- **Projected points**: lidar points drawn onto camera images using calibration, to check alignment or to fuse.
- **QA**: quality assurance, checks on labels such as consistency across frames and human review of samples.

**Core ideas.**
- **Time first.** Hardware timestamps at capture (not on arrival), PTP sync, and checks for clock drift. Rolling-shutter
  cameras and spinning lidars capture over tens of milliseconds, so motion compensation is needed too.
- **Calibration is data.** Version calibration per vehicle and date, check it automatically (for example, lidar-to-camera
  edge alignment), and flag drift after impacts or maintenance.
- **Volumes add up fast.** For example, 8 cameras at 1080p and 30 frames per second, compressed to about 4 MB/s each,
  give 32 MB/s. One lidar adds about 10 MB/s. That's about 150 GB per hour of driving, which is why production fleets
  upload only triggered clips.
- **Fusion levels.** Early fusion combines raw data, mid-level fusion combines learned features (as in BEV models), and
  late fusion combines each sensor's detections. Data pipelines must support whichever the model uses.
- **Searchable data.** Index clips by scene attributes (weather, time, objects, maneuvers) and embeddings, so engineers
  can mine "pedestrians at night in rain" in minutes.

**Example: the 40 ms offset.** A lidar-camera fusion model performed worse at high speeds. Projecting lidar points onto
images showed them shifted along the direction of travel. The lidar timestamps were taken when packets arrived at the
logger, 40 ms after capture. Switching to hardware timestamps from the sensor's PTP-synchronized clock fixed the
offset, and highway detection recall improved by 6 points after retraining on corrected data.

**Senior / FAANG best practice.** Timestamp at capture with PTP-synchronized clocks, compensate for sensor motion,
version and automatically check calibration, log in replayable formats, upload selectively, and index data by scene
attributes and embeddings for mining. Validate alignment visually and automatically before training.

---

## Lecture 305 — Real-time AI in safety-critical systems

**Why it matters.** When a wrong decision can injure people, "accurate on the test set" isn't enough. Neural networks
can fail on unusual inputs without warning, so safety-critical systems surround them with deterministic checks,
fallbacks, and evidence that regulators and safety assessors accept.

**In plain words.** It's like a trainee pilot with an instructor holding a second set of controls. The trainee flies
most of the time, but the instructor follows simple, strict rules and takes over the moment anything looks unsafe.

**Architecture: a safety monitor around an ML controller.**

```mermaid
flowchart LR
  SENS3["Sensors"] --> ML["ML planner or policy<br/>high performance, hard to verify"]
  SENS3 --> MON["Safety monitor<br/>simple, verified rules"]
  ML -->|"proposed action"| MON
  MON -->|"safe: pass through"| ACT3["Actuators"]
  MON -->|"unsafe or timeout"| FALL["Fallback controller<br/>reach minimal-risk condition"]
  FALL --> ACT3
  WD["Watchdog<br/>heartbeat, deadline"] --> MON
  ODD["ODD check<br/>weather, speed, area"] --> MON
```

**How to read it:** sensors feed both the ML planner and a separate safety monitor. The planner proposes an action. The
monitor, built from simple rules that can be verified, passes safe actions through to the actuators. If an action is
unsafe, or the planner misses its deadline, the monitor switches to a fallback controller that brings the system to a
minimal-risk condition, such as stopping. A watchdog checks heartbeats and deadlines, and an operational design domain
check confirms that conditions (weather, speed, area) are within what the system was designed for.

**Terms in this diagram.**
- **Safety monitor**: an independent component that checks the ML output against limits (speed, distance to obstacles,
  joint limits). This pattern is called a **simplex architecture**.
- **Verified rules**: simple logic that can be tested exhaustively or proven correct, unlike a neural network.
- **Minimal-risk condition**: a safe state the system can always reach, such as stopping in lane, pulling over, or a
  robot halting with brakes on.
- **Watchdog, heartbeat, deadline**: a timer that triggers the fallback if a component stops sending regular signals
  (heartbeats) or misses its deadline.
- **ODD**: operational design domain, the conditions the system is designed to operate in (roads, speeds, weather, time
  of day). Outside it, the system must hand over or stop.

**Core ideas.**
- **Standards.**
  - **ISO 26262** covers functional safety of road vehicles, with integrity levels ASIL A to D.
  - **ISO 21448 (SOTIF)** covers "safety of the intended functionality", hazards from performance limits such as
    misperception, which matters most for ML.
  - **UL 4600** covers safety cases for autonomous products.
  - **IEC 61508** is the general industrial functional safety standard. Robots also have ISO 10218 and ISO 3691-4 for
    driverless industrial trucks.
- **Deterministic timing.** Fixed-rate loops, bounded inference time (fixed input sizes, no dynamic allocation in the
  loop, no garbage collection pauses), real-time scheduling, and measured worst-case execution time, not averages.
- **Redundancy and diversity.** Independent sensing and compute paths, ideally using different methods (for example,
  radar-based emergency braking alongside camera-based perception), so one failure doesn't disable both.
- **ML-specific safeguards.** Out-of-distribution and uncertainty detection, runtime monitors for perception
  consistency over time, and conservative behavior when confidence is low.
- **Safety case and change control.** Every model change needs evidence: test results, simulation coverage,
  hazard-analysis updates, and approval, with traceability from requirements to tests.

**Example: the monitor that caught a phantom.** A warehouse robot's learned policy occasionally commanded full speed
toward a shelf when a reflective surface confused its depth camera. The safety monitor, using a separate 2D safety
lidar and a simple rule (speed limited by distance to the nearest obstacle), capped the speed and stopped the robot
each time. Logs of the monitor's interventions became the training data that fixed the policy.

**Senior / FAANG best practice.** Wrap ML in an independent, verifiable safety monitor with a fallback to a
minimal-risk condition, enforce deterministic timing with watchdogs and measured worst-case latency, check the ODD at
runtime, use diverse redundancy, detect out-of-distribution inputs, and treat every model change as a safety change
with evidence and approval under the applicable standards.

---

## Lecture 306 — Simulation infrastructure for autonomous vehicles

**Why it matters.** Proving safety by road testing alone would take billions of miles. Simulation lets teams test every
software change against millions of scenarios, including dangerous ones that can't be staged on real roads, but only if
the simulation infrastructure is large, fast, deterministic, and realistic enough.

**In plain words.** It's like a flight simulator for pilots. They practice engine failures and storms safely, again and
again, and the simulator must be realistic enough that the practice counts.

**Architecture: AV simulation at scale.**

```mermaid
flowchart TB
  LOGS["Recorded drives"] --> RESIM["Log replay<br/>open-loop: does perception agree?"]
  LOGS --> RECON["Scene reconstruction<br/>neural rendering, Gaussian splatting"]
  SCEN["Scenario library<br/>OpenSCENARIO, fuzzed variations"] --> CLSIM["Closed-loop simulation<br/>software drives, world reacts"]
  RECON --> CLSIM
  CLSIM --> SENSIM["Sensor simulation<br/>cameras, lidar, radar"]
  RESIM & CLSIM --> FARM["Compute farm<br/>thousands of GPUs and CPUs, deterministic"]
  FARM --> MET2["Metrics + gates<br/>collisions, comfort, rule violations"]
  MET2 --> REL["Release decision"]
```

**How to read it:** recorded drives are replayed open-loop through new software to check whether perception and
planning still agree with what happened. Recorded scenes can also be rebuilt as 3D environments with neural rendering.
A scenario library of designed and automatically varied situations runs in closed-loop simulation, where the software
drives and the simulated world reacts, with simulated camera, lidar, and radar data. All of it runs on a compute farm
of thousands of GPUs and CPUs, deterministically. Metrics such as collisions, comfort, and traffic rule violations feed
gates for the release decision.

**Terms in this diagram.**
- **Log replay, open-loop**: feeding recorded sensor data to the software. The vehicle's path can't change, so it tests
  perception and decisions, not the consequences of different actions.
- **Neural rendering, Gaussian splatting**: methods that reconstruct a realistic 3D scene from recorded images, so
  cameras can be simulated from slightly different positions.
- **OpenSCENARIO, fuzzed variations**: an ASAM standard format for describing driving scenarios, and automatically
  generated variations (speeds, positions, timings) of each scenario.
- **Closed-loop simulation**: the software's actions change the simulated world, so other agents react and the
  consequences are tested.
- **Sensor simulation**: generating synthetic camera, lidar, and radar data from the simulated world (with tools such
  as CARLA or NVIDIA's Omniverse-based simulators).
- **Deterministic**: the same inputs and seed give the same result, so failures can be reproduced and compared
  between versions.

**Core ideas.**
- **Layers of simulation.** Unit-level tests for components, log replay for regressions on real data, closed-loop
  scenario simulation for behavior, and hardware-in-the-loop tests with the real vehicle computer.
- **Scale.** Every release candidate runs hundreds of thousands to millions of scenarios. That's batch compute with
  thousands of parallel jobs, scheduled like training (Section 11).
- **Determinism and reproducibility.** Fixed seeds, versioned simulators and assets, and fixed time steps, so a
  failure found today can be replayed exactly next week.
- **Realism gap.** Simulated sensors differ from real ones. Validate simulation against real data, and weigh evidence
  from simulation according to how well it matches reality.
- **Coverage, not miles.** Measure which scenario types, ODD conditions, and failure modes have been tested, rather than
  total simulated miles.

**Example: the regression caught overnight.** A planner change improved comfort metrics in road tests. The nightly
simulation run of 400,000 scenarios found 37 new near-collisions, all in unprotected left turns with an oncoming
motorcycle partially hidden by a truck. The change was blocked, the planner was fixed, and the scenario family was added
to the required release gate.

**Senior / FAANG best practice.** Build layered simulation (log replay, closed-loop scenarios, sensor simulation,
hardware-in-the-loop), run it at scale on every release candidate as a gate, keep it deterministic and versioned,
measure scenario and ODD coverage rather than miles, and validate simulation realism against real data.

---

## Lecture 307 — Edge deployment in robotics

**Why it matters.** A robot fleet may be thousands of machines in warehouses, farms, or homes, with patchy
connectivity and no technician nearby. A failed update can strand robots, and an insecure one can turn them into a
safety hazard. Edge deployment must be optimized, secure, and reversible.

**In plain words.** It's like updating the software on thousands of elevators. You test on a few, keep the old version
ready to switch back automatically, and make sure nobody can install their own version.

**Architecture: robot fleet update pipeline.**

```mermaid
flowchart LR
  BUILD2["CI build<br/>model optimized with TensorRT,<br/>container or OS image"] --> SIGN["Sign image<br/>keys in HSM"]
  SIGN --> REPO["Update server<br/>fleet manager"]
  REPO -->|"1% canary robots"| CAN["Canary group"]
  CAN -->|"health OK"| WAVE["Waves: 10%, 50%, 100%"]
  subgraph ROBOT["On each robot"]
    AB["A/B partitions<br/>install to inactive slot"] --> BOOT["Secure boot<br/>verify signature"]
    BOOT --> HC["Health check<br/>auto-rollback on failure"]
  end
  CAN & WAVE --> AB
```

**How to read it:** CI builds the release, with models optimized by TensorRT, packaged as a container or a full OS
image. The image is signed with keys kept in a hardware security module, then published to the fleet manager's update
server. It goes first to about 1% of robots as a canary. If their health is good, it rolls out in waves to 10%, 50%, and
100%. On each robot, the update installs to the inactive one of two partitions, secure boot verifies its signature,
and a health check after reboot rolls back to the previous partition automatically if anything fails.

**Terms in this diagram.**
- **TensorRT**: NVIDIA's inference optimizer and runtime for its GPUs, including Jetson (Section 22).
- **Container or OS image**: the software can be updated as application containers or as a complete operating system
  image, which includes drivers and the kernel.
- **Sign image, HSM**: attaching a cryptographic signature that the robot verifies, with signing keys protected in a
  hardware security module.
- **Canary group, waves**: a small first group of robots, then progressively larger groups if health stays good.
- **A/B partitions**: two copies of the system partition. The update writes to the inactive one, so the running system
  is untouched and the old version stays available.
- **Secure boot**: firmware that runs only software with a valid signature.
- **Auto-rollback**: switching back to the previous partition automatically if the new version fails its health checks.

**Core ideas.**
- **Optimize for the device.** Quantize (INT8, FP8 where supported), compile with TensorRT for the exact Jetson model and
  software version, and measure latency, power, and temperature on the real device (Section 22).
- **Update tooling.** Tools such as Mender, RAUC, and SWUpdate provide A/B OS updates. Container-based fleets use tools
  such as balena or k3s with GitOps. Either way, updates must be atomic, verifiable, and reversible.
- **Health gates.** Each wave advances only if the canary's metrics hold: intervention or safety-stop rate, task
  success, crash rate, temperature, and latency.
- **Offline-first.** Robots must work without the cloud, buffer telemetry, and download updates when connected,
  possibly on schedules that avoid working hours.
- **Security.** Secure boot, signed images, encrypted storage, unique device identities, and no shared default
  passwords. A compromised robot is a physical safety risk.

**Example: the update that bricked nothing.** A new perception model for 2,000 warehouse robots crashed on robots with
an older camera firmware. Only the 20 canary robots received it. Their health checks failed after reboot, A/B rollback
restored the previous version within 3 minutes, and the rollout stopped automatically. The fix added a firmware check
to the update's compatibility rules.

**Senior / FAANG best practice.** Optimize models on the exact target device, sign and verify every image with secure
boot, use atomic A/B updates with automatic rollback, roll out in canary waves gated on safety and task metrics, design
for offline operation, and give every robot a unique identity and encrypted storage.

---

## Lecture 308 — Lab: deploy AI agent for robotics simulation

**Goal:** train a reinforcement learning policy for a simulated two-joint robot arm in MuJoCo, export it to ONNX, and
deploy it in a fixed-rate 50 Hz control loop with a safety envelope (action limits and rate limits), a deadline
watchdog with a safe stop, and metrics. Then inject faults and test robustness to a change in the robot's dynamics.

**What you're building:** `train.py` (PPO training with Stable-Baselines3), `export.py` (ONNX export), and
`controller.py` (the deployed control loop), packaged in a container.

```mermaid
flowchart LR
  TR3["train.py<br/>PPO on Reacher-v5, MuJoCo"] --> EXP["export.py<br/>policy to ONNX"]
  EXP --> CTL["controller.py<br/>50 Hz loop, ONNX Runtime"]
  CTL --> ENV3["Simulated arm<br/>stands in for the real robot"]
  CTL --> ENVL["Safety envelope<br/>clamp, rate limit"]
  CTL --> WDG["Watchdog<br/>deadline misses, safe stop"]
  CTL --> MTR["Metrics<br/>loop time, misses, distance to target"]
```

**How to read the diagram:** `train.py` trains a policy with PPO on the MuJoCo Reacher task, a two-joint arm that must
move its fingertip to a target. `export.py` converts the policy to ONNX. `controller.py` loads it with ONNX Runtime and
runs a 50 Hz control loop against the simulated arm, which stands in for real hardware. The loop passes every action
through a safety envelope (clamping and rate limiting), a watchdog counts deadline misses and triggers a safe stop, and
the loop reports metrics such as loop time, misses, and distance to the target.

The terms, briefly:
- **PPO**: proximal policy optimization, a widely used reinforcement learning algorithm (Section 30).
- **Reacher-v5, MuJoCo**: a Gymnasium environment with a two-joint arm, simulated by the MuJoCo physics engine.
- **ONNX, ONNX Runtime**: a portable model format, and a fast inference engine for it (Section 35).
- **Safety envelope**: limits applied to every command regardless of what the policy outputs.
- **Clamp, rate limit**: forcing actions into an allowed range, and limiting how much they can change between steps.

**Prerequisites:** Python 3.10+, about 2 GB of disk, Docker for the last step, and
`pip install "gymnasium[mujoco]>=1.0" "stable-baselines3>=2.4" torch onnx onnxruntime`. A CPU is enough.

### Step 1 — Train

```python
# train.py
import gymnasium as gym
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.evaluation import evaluate_policy

def random_return(episodes=20):
    env, total = gym.make("Reacher-v5"), 0.0
    for i in range(episodes):
        env.reset(seed=i)
        done = False
        while not done:
            _, r, term, trunc, _ = env.step(env.action_space.sample())
            total += r
            done = term or trunc
    return total / episodes

env = make_vec_env("Reacher-v5", n_envs=8, seed=0)
model = PPO("MlpPolicy", env, n_steps=512, batch_size=256, learning_rate=3e-4, gamma=0.99, seed=0, verbose=0)
model.learn(total_timesteps=300_000)
mean, std = evaluate_policy(model, gym.make("Reacher-v5"), n_eval_episodes=20, deterministic=True)
print(f"random actions reward {random_return():.1f};  trained policy {mean:.1f} +/- {std:.1f}")
model.save("reacher_ppo")
```

```bash
python3 train.py
```

In the code, eight copies of the environment run in parallel to collect experience faster. PPO trains for 300,000
steps (about 6,000 episodes of 50 steps). The reward each step is minus the fingertip's distance to the target, minus a
small penalty for large actions, so rewards are negative and closer to zero is better. The script compares random
actions with the trained policy.

### Step 2 — Export to ONNX

```python
# export.py
import numpy as np, onnxruntime as ort, torch
from stable_baselines3 import PPO

class OnnxPolicy(torch.nn.Module):
    def __init__(self, policy):
        super().__init__()
        self.policy = policy
    def forward(self, obs):
        return self.policy(obs, deterministic=True)        # actions, values, log_prob

model = PPO.load("reacher_ppo", device="cpu")
dummy = torch.randn(1, *model.observation_space.shape)
torch.onnx.export(OnnxPolicy(model.policy), dummy, "reacher.onnx", opset_version=17, input_names=["obs"])
sess = ort.InferenceSession("reacher.onnx")
obs = np.random.randn(1, *model.observation_space.shape).astype(np.float32)
onnx_act = sess.run(None, {"obs": obs})[0]
torch_act, _ = model.predict(obs, deterministic=True)
print("max difference vs PyTorch:", float(np.abs(np.clip(onnx_act, -1, 1) - torch_act).max()))
```

```bash
python3 export.py
```

In the code, the wrapper exports the policy network with deterministic actions. The script then checks that ONNX
Runtime and PyTorch give the same action for a random observation. Stable-Baselines3 clips actions to the action space
after the network, so the comparison clips the ONNX output the same way, and the controller will clip too.

### Step 3 — The deployed control loop

```python
# controller.py: python3 controller.py [--steps N] [--inject-delay-ms MS --at STEP --stall-steps K] [--nan-at STEP] [--damping X]
import argparse, time
import gymnasium as gym
import numpy as np
import onnxruntime as ort

p = argparse.ArgumentParser()
p.add_argument("--steps", type=int, default=1000)
p.add_argument("--inject-delay-ms", type=float, default=0)
p.add_argument("--at", type=int, default=-1)
p.add_argument("--stall-steps", type=int, default=1)
p.add_argument("--nan-at", type=int, default=-1)
p.add_argument("--damping", type=float, default=1.0)
a = p.parse_args()

PERIOD, MAX_DELTA, MISS_LIMIT = 0.02, 0.5, 3            # 50 Hz, max action change per step, consecutive misses allowed
sess = ort.InferenceSession("reacher.onnx", providers=["CPUExecutionProvider"])
env = gym.make("Reacher-v5")
env.unwrapped.model.dof_damping[:] *= a.damping          # change the "real robot" dynamics
obs, _ = env.reset(seed=1)
last, misses, total_misses, interventions, dists, loop_ms = np.zeros(2), 0, 0, 0, [], []
state = "RUNNING"
next_t = time.perf_counter()

for step in range(a.steps):
    t0 = time.perf_counter()
    if step == a.nan_at:
        obs = obs * np.nan                               # simulate a failed sensor
    if not np.all(np.isfinite(obs)):
        state = "SAFE_STOP: invalid observation"
    if state == "RUNNING":
        act = sess.run(None, {"obs": obs[None].astype(np.float32)})[0][0]
        safe = np.clip(np.clip(act, -1, 1), last - MAX_DELTA, last + MAX_DELTA)
        interventions += int(not np.allclose(safe, np.clip(act, -1, 1)))
        if a.at <= step < a.at + a.stall_steps:
            time.sleep(a.inject_delay_ms / 1000)          # simulate an inference stall
    else:
        safe = np.zeros(2)                               # safe stop: zero torque
    obs, _, term, trunc, _ = env.step(safe)
    last = safe
    dists.append(float(np.linalg.norm(obs[8:10])))       # fingertip-to-target vector is obs[8:10]
    took = time.perf_counter() - t0
    loop_ms.append(took * 1000)
    misses = misses + 1 if took > PERIOD else 0
    total_misses += took > PERIOD
    if misses >= MISS_LIMIT and state == "RUNNING":
        state = f"SAFE_STOP: {MISS_LIMIT} consecutive deadline misses at step {step}"
    if term or trunc:
        obs, _ = env.reset()
    next_t += PERIOD
    time.sleep(max(0.0, next_t - time.perf_counter()))  # fixed-rate loop

lm = np.array(loop_ms)
print(f"state {state}")
print(f"loop time p50 {np.percentile(lm, 50):.2f} ms  p99 {np.percentile(lm, 99):.2f} ms  max {lm.max():.2f} ms;  "
      f"deadline misses {total_misses};  envelope interventions {interventions}")
print(f"mean distance to target {np.mean(dists):.3f} m")
```

```bash
python3 controller.py                                     # normal run, 20 seconds
python3 controller.py --inject-delay-ms 30 --at 300       # one stall: tolerated
python3 controller.py --inject-delay-ms 30 --at 300 --stall-steps 5    # repeated stalls: watchdog trips
python3 controller.py --nan-at 400                        # failed sensor
python3 controller.py --damping 3                         # stiffer joints than in training
```

In the code, the loop runs every 20 ms, sleeping until the next tick so the rate stays fixed even if a step finishes
early. Each action from the policy is clamped to [−1, 1] and rate-limited to change by at most 0.5 per step, and the
script counts how often the envelope changed the policy's output. If a step takes longer than 20 ms, that's a deadline
miss. Three in a row trigger a safe stop that applies zero torque from then on. A non-finite observation (a failed
sensor) also triggers a safe stop. The `--damping` flag changes the simulated arm's joint damping, standing in for a
real robot that differs from simulation. `--stall-steps` repeats the injected stall on consecutive steps. The safe
stop is latched: once triggered, the loop keeps applying zero torque until restarted, as a real robot would wait for an
operator.

### Step 4 — Package for the edge

```dockerfile
# Dockerfile
FROM python:3.12-slim
RUN pip install --no-cache-dir "gymnasium[mujoco]>=1.0" onnxruntime numpy
WORKDIR /app
COPY reacher.onnx controller.py ./
USER 1000
ENTRYPOINT ["python3", "controller.py"]
```

```bash
docker build -t reacher-controller:1.0 . && docker run --rm --cpus 1 reacher-controller:1.0 --steps 500
```

In the file, the runtime image contains only ONNX Runtime, the simulator, and NumPy, with no PyTorch or training
libraries, and runs as a non-root user. `--cpus 1` limits the container to one CPU, like a small edge device, to check
that the loop still meets its deadline.

**Expected results:**
- `train.py`: random actions score far below the trained policy (more negative). Well-trained Reacher policies reach
  about −4 to −5 per episode. After 300,000 steps, expect somewhere between about −10 and −4. RL results vary with the
  seed, so if yours is worse, train longer (1 million steps) before continuing.
- `export.py`: maximum difference versus PyTorch is about 1e-6 or smaller.
- Normal run: state `RUNNING`, loop time p99 well under 20 ms (inference takes well under a millisecond), zero deadline
  misses, and a mean distance to target of a few centimeters, much lower than an untrained policy.
- One 30 ms stall: one deadline miss, state still `RUNNING`.
- Five stalls in a row (`--stall-steps 5`): `SAFE_STOP: 3 consecutive deadline misses at step 302`. Only three stalls
  happen, because the policy stops running once the safe stop latches.
- Failed sensor: `SAFE_STOP: invalid observation`, and the arm holds zero torque instead of acting on bad data.
- `--damping 3`: the policy still runs, but the mean distance to target rises and envelope interventions may change. This
  is a small, visible example of the gap between simulation and reality, which domain randomization during training
  reduces.
- The container run meets its deadline on one CPU.

---

## Assessment — Conduct a safety-critical deployment review

**Scenario (live exercise, about 45 minutes):** you chair the safety review for releasing perception model v7 to a fleet
of 1,200 autonomous mobile robots in 14 warehouses, where robots share aisles with people. v7 improves pallet and person
detection recall in simulation and log replay. The release also moves the model from FP16 to INT8 on Jetson Orin, to
fit a new obstacle-tracking module in the latency budget. The team proposes a fleet-wide update next week.

**Deliverable:** run the review, then write the decision record. A model answer:

| Area | What the chair asks for (model answer) |
|---|---|
| Change scope | A list of everything changing: model weights, INT8 quantization and its calibration data, the new tracking module, the TensorRT version, and any configuration. Each change is mapped to the hazard analysis. The INT8 change alone can alter behavior and must be evaluated as a change |
| Hazard analysis | Updated hazards: missed person detection (the worst case), phantom obstacles causing sudden stops that a following robot or person may hit, and latency increases delaying braking. Each has a safety requirement, for example "person within 3 m detected with recall at least 99.9% within 100 ms" |
| Evidence: offline | Recall and precision by class, distance, lighting, and occlusion, for v6 and v7 on the same held-out set, **using the INT8 engine on the target device**, not the FP16 model. Person recall at close range must not regress in any slice. Results on known hard sets (reflective floors, high-vis vests, people carrying boxes) |
| Evidence: simulation and replay | Closed-loop scenario results for near-misses, stops, and collisions, compared with v6, plus log replay of the last 3 months of safety-stop events. Every regression is explained |
| Timing | Measured worst-case latency on the device under full load and at maximum temperature, not the average. Sensor-to-brake latency stays within the budget with margin, and the watchdog and safe-stop paths are tested |
| Independent safety layer | Confirmation that the certified safety lidar and its speed-and-separation monitor are unchanged and still have authority to stop the robot regardless of the ML output. ML improves efficiency, while the safety layer protects people |
| Rollout plan | Not fleet-wide. Shadow mode on 50 robots for a week, comparing v7 and v6 detections, then a canary of 2% of robots in one warehouse during low-traffic shifts, then waves by warehouse. A/B partitions with automatic rollback, and a one-command fleet rollback |
| Go/no-go metrics | Per wave: safety-stop rate, near-miss reports, person-detection disagreements with the safety lidar, task throughput, and latency p99.9. Thresholds are written in advance, and any threshold breach stops the rollout automatically |
| Operations | Site safety officers informed. Updated operating instructions if behavior changes. On-call engineers during each wave, and an incident process with a direct line to warehouse managers |

**Decision record, model answer:**
- **Decision:** conditional approval for shadow mode and the first canary only. Fleet-wide rollout is not approved.
- **Conditions before canary:** INT8 results on the device for every slice (the submission had FP16 results for the
  close-range person slice only), worst-case timing at maximum temperature, and a successful rollback rehearsal on 5
  robots.
- **Rationale:** v7's recall gains are real in simulation, but the quantization change is unvalidated in the most
  safety-relevant slice. The independent safety layer limits the worst-case harm, which makes a staged rollout
  acceptable.
- **Owners and dates:** the perception lead for INT8 slice results, the platform lead for timing and rollback, and the
  safety manager for site communication. Review again after shadow mode.

**What reviewers look for:**
- **Every change is evaluated**, including quantization, runtime versions, and configuration, not only the "new model".
- **Evidence on the target hardware and in the worst case**, not averages on a workstation.
- **Slices that matter for safety**, such as close-range people, with no regression accepted.
- **An independent safety layer** that doesn't depend on the ML.
- **Staged, reversible rollout** with go/no-go thresholds set in advance and automatic stops.
- **Clear decision, conditions, and owners**, written down for traceability.
- **Saying no or "not yet"** when evidence is missing, even under schedule pressure.

---

## FAANG deep-dive notes

**How big tech does it.** AV companies such as Waymo publish safety frameworks and safety cases, run huge simulation
programs, and validate releases through layered simulation, closed-course tests, and staged public deployment. Tesla
built a fleet data engine with triggers and shadow mode, and large training clusters for end-to-end driving models.
NVIDIA provides the DRIVE and Jetson platforms with safety-certified software components and Omniverse-based simulation.
Robotics groups at Google DeepMind and others train large robot foundation models on data from many robots and
simulation. Amazon Robotics runs hundreds of thousands of robots in fulfillment centers with fleet management, staged
updates, and safety systems separate from the ML.

**Staff review questions.**
- What's the ODD, and how does the system detect leaving it?
- What's the independent safety layer, and does it have authority over the ML?
- What's the worst-case sensor-to-actuator latency on the target hardware?
- How fast is the data engine loop from a field failure to a validated fix?
- What does simulation cover, and how realistic is it compared to real data?
- How are updates rolled out and rolled back across the fleet?

**Interview question.** "Design the data and training infrastructure for a fleet of 10,000 delivery robots."

**Typical system-design prompt:** *Design the infrastructure for 10,000 sidewalk delivery robots: on-robot compute,
data collection, training, simulation, and updates.*

**1. Clarify first:** Sensors per robot? Connectivity (cellular, Wi-Fi at depots)? ODD (cities, weather, hours)?
Remote assistance? Regulatory requirements per city? Release frequency?

**2. Back-of-envelope sizing:**
- Raw data: 6 cameras × 2 MB/s compressed = 12 MB/s, about 43 GB per hour of driving. 10,000 robots × 8 hours a day
  would be 3.5 PB a day, far too much to upload.
- Triggered clips: say 20 clips of 30 seconds per robot per day = 7.2 GB per robot, 72 TB a day, uploaded at depots
  over Wi-Fi. A year of retained clips: about 26 PB, with tiering to cold storage and deletion of uninteresting data.
- Training: a few hundred GPUs for perception and planning models, plus auto-labeling and simulation farms of similar
  size.
- Updates: monthly releases to 10,000 robots, in canary waves over one to two weeks.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Data collection | Upload everything | Triggers + shadow mode | Triggers and shadow mode |
| Safety | ML only | ML + independent monitor | Always an independent monitor |
| Validation | Road tests | Layered simulation + staged rollout | Simulation gates plus staged rollout |
| Model precision | FP16 | INT8 on device | INT8 if validated on device, per safety slice |
| Updates | Containers only | A/B OS images | A/B images with rollback for the whole stack |

**4. Follow-up questions with crisp answers:**
- *A robot fails in a new city.* Trigger and mine similar clips, add scenarios to simulation, retrain, and expand the
  ODD only after validation.
- *Connectivity drops mid-update.* A/B partitions keep the old system active, and the update resumes or rolls back.
- *Inference got slower after a driver update.* Timing tests on device in CI catch it before release, with a latency
  gate.
- *How do you prove the new model is safer?* Slice-level metrics, simulation coverage, shadow-mode comparisons, and
  staged rollout metrics against thresholds set in advance.

**Debug this (common onsite question):** "After an update, robots in one warehouse brake suddenly several times an hour,
and nowhere else."
1. The warehouse installed new polished floors last week.
2. Logs show phantom obstacles from floor reflections in the depth camera, detected by the new model more often than
   the old one.
3. The safety monitor is fine. The ML planner is braking for phantom obstacles.
4. Fix: roll back that warehouse, collect triggered clips of the floor, add reflective-floor data and scenarios, retrain,
   and add a reflective-floor slice to the release gate.

The lesson: deployment environments change, so per-site monitoring and fast data loops matter as much as the model.

**5. What separates senior from staff answers:** a senior engineer deploys an optimized model to robots. A staff engineer
designs the whole loop: triggers and shadow mode, sensor data with time and calibration, auto-labeling, layered
simulation as release gates, an independent safety layer, worst-case timing on device, staged A/B rollouts, and safety
reviews with evidence.

**Red flags:**
- ML with sole authority over safety.
- Average latency instead of worst case on the target device.
- Validating FP16 and shipping INT8.
- Uploading everything, or nothing.
- Arrival-time timestamps.
- Simulation that isn't deterministic.
- Fleet-wide updates without canaries or rollback.

---

## Quiz

<details><summary>1. What is the data engine in self-driving?</summary>
The loop of finding failures in the fleet (triggers, shadow mode), mining similar data, auto-labeling, retraining,
validating in simulation, and deploying with staged OTA updates.
</details>

<details><summary>2. Why should a robot's control loop be separate from perception?</summary>
Control must run at a fixed, fast rate. If it waits for slower perception, commands arrive late and the robot becomes
unstable or unsafe.
</details>

<details><summary>3. Why timestamp sensor data at capture with PTP?</summary>
Arrival times include variable delays, so fused data from different sensors would be misaligned. PTP keeps clocks
synchronized across devices.
</details>

<details><summary>4. What is a simplex architecture?</summary>
An ML controller whose outputs pass through a simple, verifiable safety monitor that can switch to a fallback controller
to reach a minimal-risk condition.
</details>

<details><summary>5. What's the difference between log replay and closed-loop simulation?</summary>
Log replay feeds recorded data, so the vehicle's actions can't change the scene. In closed-loop simulation, actions change
the world, and other agents react.
</details>

<details><summary>6. Why use A/B partitions for robot updates?</summary>
The update installs to the inactive copy, so the running system is untouched, and the robot can roll back automatically
if the new version fails health checks.
</details>

<details><summary>7. Why must quantized models be validated separately?</summary>
Quantization changes the model's outputs, and errors may concentrate in specific slices, so safety evidence must come from
the exact engine that ships.
</details>

## Failure modes
- ML outputs reaching actuators with no independent check.
- Control loops blocked by slow perception.
- Misaligned sensor data from arrival-time timestamps or stale calibration.
- Validation on a workstation model, not the shipped device engine.
- Simulation that isn't deterministic or realistic enough.
- Fleet-wide updates without canaries, A/B partitions, or rollback.
- No trigger strategy, so the rare cases never reach training.
- Operating outside the ODD without detection.

## Checklist
- [ ] The data engine has triggers, shadow mode, auto-labeling, and simulation gates
- [ ] Control loops are separated from perception and run at fixed rates with watchdogs
- [ ] Sensors are PTP-synchronized, timestamped at capture, and calibration is versioned
- [ ] An independent safety monitor can override ML and reach a minimal-risk condition
- [ ] Simulation is layered, deterministic, and measures scenario coverage
- [ ] Fleet updates are signed, A/B, canaried, and roll back automatically
- [ ] You trained, exported, and deployed a robot policy with a safety envelope and watchdog
- [ ] You can run a safety-critical deployment review and write the decision record
