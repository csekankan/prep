# Section 42 — AI Infrastructure for Enterprises

> Lectures 288–294 • Assessments: quiz, [Defend an enterprise AI infrastructure proposal](#assessment--defend-an-enterprise-ai-infrastructure-proposal)
> **After this section you can:** describe what enterprise-scale AI infrastructure must provide beyond GPUs, run a
> vendor selection with weighted scoring and a proof of concept, design a hybrid on-prem and cloud strategy with an
> honest TCO comparison, map regulations to infrastructure controls, integrate with identity, ITSM, SIEM, data, and
> FinOps systems, organize platform teams, and write and defend an enterprise AI infrastructure plan.
>
> Builds on: [Section 18](../part05_operating_production/s18_security_compliance.md) (security and compliance),
> [Section 20](../part05_operating_production/s20_multi_cloud.md) (multi-cloud and hybrid),
> [Section 33](../part08_scale_mlops_optimization/s33_enterprise_mlops.md) and
> [Section 34](../part08_scale_mlops_optimization/s34_advanced_enterprise_mlops.md) (enterprise MLOps), and
> [Section 40](../part09_privacy_security_tenancy/s40_multi_tenant_ai.md) (multi-tenancy).
> Go deeper: [13/enterprise reference architecture](../../13_sovereign_ai_infra_course/ENTERPRISE_REFERENCE_ARCHITECTURE.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 288 | Enterprise-scale infra needs | Many teams, regulators, and old systems. Governance, integration, and reliability matter as much as GPUs |
| 289 | Vendor selection for AI infrastructure | Weighted criteria agreed up front, a proof of concept on your own workloads, and exit terms in the contract |
| 290 | Hybrid on-prem + cloud AI strategy | Steady load on owned or committed capacity, bursts in the cloud, and one platform across both |
| 291 | Compliance and regulatory burdens | Map each regulation to concrete controls, evidence, and owners, and automate the evidence |
| 292 | Integration with enterprise IT systems | Identity, ITSM, SIEM, data platforms, API management, and FinOps are part of the AI platform |
| 293 | Scaling teams for AI infra management | A platform team runs the paved path, enabling teams spread it, and every service has an owner |
| 294 | Lab: design enterprise AI infra plan | Requirements, TCO, architecture, compliance mapping, and a phased roadmap in one document |

```mermaid
flowchart TB
  BIZ["Business units<br/>use cases, risk tiers"] --> PLAT["AI platform<br/>paved path, multi-tenant"]
  PLAT --> HYB["Compute: on-prem + cloud<br/>one control plane"]
  PLAT --> GOV["Governance<br/>controls, evidence, audits"]
  PLAT --> INT["Enterprise IT integration<br/>identity, ITSM, SIEM, data"]
  VEND["Vendors<br/>selected and contracted"] --> HYB
  TEAM["Teams<br/>platform, enabling, SRE"] --> PLAT
```

**How to read it:** business units bring use cases, each with a risk tier. They're served by one shared AI platform
offering a paved path for many tenants. The platform runs on compute across on-prem data centers and cloud, managed
from one control plane. It provides governance (controls, evidence, and audits) and integrates with existing enterprise
IT systems for identity, IT service management, security monitoring, and data. Vendors are selected and contracted to
supply the compute, and platform, enabling, and SRE teams run the platform.

**Terms in this diagram.**
- **Business units, risk tiers**: divisions of the company (such as retail banking or claims), and each use case's
  risk level, which decides the controls it needs (Section 34).
- **Paved path, multi-tenant**: the supported, standard way to build and deploy AI, shared safely by many teams
  (Sections 33 and 40).
- **One control plane**: the same tools (Kubernetes, CI/CD, policies, monitoring) managing workloads everywhere.
- **Controls, evidence, audits**: required safeguards, proof that they operate, and periodic checks by internal or
  external auditors (Lecture 291).
- **ITSM, SIEM**: IT service management (such as ServiceNow, for changes and incidents) and security information and
  event management (such as Splunk or Microsoft Sentinel, for security logs and alerts) (Lecture 292).
- **Enabling, SRE**: teams that help others adopt the platform, and site reliability engineers who run it to SLOs
  (Lecture 293).

---

## Lecture 288 — Enterprise-scale infra needs

**Why it matters.** Enterprise AI projects rarely fail for lack of GPUs. They fail in security review, stall waiting
for data access, or can't connect to the systems where the business actually runs. An enterprise AI platform must
satisfy many teams, auditors, and existing systems at once.

**In plain words.** A startup is a small boat that can turn quickly. An enterprise is a cargo ship: it carries far more,
but it needs harbors, schedules, safety inspections, and a crew with clear jobs.

**Architecture: capabilities an enterprise AI platform must provide.**

```mermaid
flowchart LR
  subgraph CAP["Platform capabilities"]
    C1["Compute<br/>GPU pools, quotas, regions"]
    C2["Data<br/>catalog, access, lineage"]
    C3["ML lifecycle<br/>pipelines, registry, serving"]
    C4["Governance<br/>risk tiers, approvals, audit"]
    C5["Security<br/>identity, secrets, network"]
    C6["Operations<br/>SLOs, on-call, DR, cost"]
  end
  USERS["Thousands of users,<br/>hundreds of models"] --> CAP
  CAP --> SYS["Existing systems<br/>ERP, CRM, warehouse, mainframe"]
```

**How to read it:** thousands of users building hundreds of models rely on six platform capabilities: compute (GPU
pools, quotas, and regions), data (a catalog, access control, and lineage), the ML lifecycle (pipelines, a registry,
and serving), governance (risk tiers, approvals, and audit trails), security (identity, secrets, and network
controls), and operations (SLOs, on-call, disaster recovery, and cost). All of these must connect to the systems that
already run the business: ERP, CRM, the data warehouse, and sometimes mainframes.

**Terms in this diagram.**
- **Catalog, access, lineage**: a searchable inventory of datasets with owners, a way to request and grant access, and
  records of which data produced which model (Section 24).
- **Pipelines, registry, serving**: automated training workflows, the system of record for models, and the deployment
  infrastructure (Sections 33 and 34).
- **DR**: disaster recovery, restoring service after a regional or data-center failure (Section 19).
- **ERP, CRM**: enterprise resource planning (such as SAP, for finance and operations) and customer relationship
  management (such as Salesforce).
- **Warehouse, mainframe**: the central analytics database (such as Snowflake, BigQuery, or Teradata), and the large
  legacy computers that still run core transactions in banks, insurers, and airlines.

**Core ideas.**
- **Scale is organizational.** Dozens of business units, each with different data, risk, and budgets, so multi-tenancy,
  chargeback, and self-service matter more than peak FLOPs (Section 40).
- **Long-lived and audited.** Models stay in production for years and must be explainable to auditors, so lineage and
  records are requirements, not extras.
- **Procurement and change cycles.** Hardware lead times, security reviews, and change approvals take weeks or months.
  Plan capacity and approvals ahead.
- **Reliability expectations.** Customer-facing AI inherits the company's SLAs, DR requirements, and incident processes.
- **Platform as a product.** Treat internal teams as customers, with a roadmap, documentation, support, and adoption
  metrics.

**Example: the model that couldn't reach its data.** A bank's fraud team built a strong model in six weeks, then waited
seven months to go live: data access approvals, a firewall change to reach the core banking system, a security review of
the serving stack, and model risk validation. The bank then built a platform with pre-approved data products, standard
network paths, a pre-reviewed serving stack, and a model risk workflow. The next three models went live in under eight
weeks each.

**Senior / FAANG best practice.** Design the enterprise AI platform around all six capabilities, not only compute.
Pre-approve the common paths (data access, network routes, the serving stack, risk workflows) so teams don't repeat
reviews, plan for procurement and change lead times, and run the platform as a product with adoption and time-to-production
metrics.

---

## Lecture 289 — Vendor selection for AI infrastructure

**Why it matters.** Enterprise AI infrastructure contracts are multi-year and worth millions. Choosing on demos, list
prices, or benchmark headlines leads to platforms that don't fit real workloads, or contracts that are expensive to
leave.

**In plain words.** It's like hiring for a key role. You agree on what matters before interviews, give every candidate
the same practical task, check references, and negotiate the contract, including how to part ways.

**Architecture: a vendor selection process.**

```mermaid
flowchart LR
  REQ2["Requirements<br/>workloads, constraints"] --> CRIT["Weighted criteria<br/>agreed before demos"]
  CRIT --> RFP["RFP<br/>3 to 5 vendors"]
  RFP --> POC["Proof of concept<br/>your workloads, your data"]
  POC --> SCORE["Scoring + sensitivity<br/>does the winner change?"]
  SCORE --> REFS["Reference checks"]
  REFS --> CONTRACT["Contract<br/>SLAs, price protection, data terms, exit"]
```

**How to read it:** the process starts with written requirements: the workloads to run and the constraints to respect.
Weighted criteria are agreed before any vendor demos. A request for proposal goes to three to five vendors, and the
shortlist runs a proof of concept with your own workloads and data. Scores are checked for sensitivity: would a small
change in weights change the winner? Reference customers are called, and the contract covers SLAs, price protection,
data terms, and exit.

**Terms in this diagram.**
- **RFP**: request for proposal, a formal document asking vendors to describe their offer against your requirements.
- **Proof of concept (POC)**: a short trial running your real workloads on the vendor's platform, measuring results
  against agreed success criteria.
- **Sensitivity**: checking whether the result depends on fine details of the weights, which shows how robust the
  decision is.
- **Reference checks**: conversations with existing customers of similar size and use case.
- **Price protection**: contract terms that limit price increases over the contract's life.
- **Exit**: terms for leaving: data export formats, egress fee waivers, transition support, and notice periods.

**Core ideas.**
- **Criteria to weight.**
  - Fit for workloads (measured in the POC).
  - Three-year TCO.
  - Security and compliance (certifications, data residency, audit rights).
  - Support quality and SLAs.
  - Roadmap and financial stability.
  - Ecosystem and skills availability.
  - Exit cost.
- **Benchmarks.** Public results such as MLPerf are useful references, but your POC should measure your models, at your
  batch sizes, with your data pipeline.
- **Total cost.** Include software licenses, support, networking, storage, egress, staff, and migration, not only GPU
  prices (Lecture 290).
- **Avoid single points of failure.** For critical capabilities, keep a credible second option, even if it's smaller.
- **Decide openly.** A written scoring record protects the decision in audits and when people change roles.

```python
WEIGHTS = {"workload fit": 0.30, "3-yr TCO": 0.25, "security/compliance": 0.20, "support": 0.10,
           "roadmap": 0.05, "exit cost": 0.10}
SCORES = {   # 1-5 from the POC and RFP answers
    "Vendor A": {"workload fit": 5, "3-yr TCO": 3, "security/compliance": 4, "support": 4, "roadmap": 5, "exit cost": 2},
    "Vendor B": {"workload fit": 4, "3-yr TCO": 4, "security/compliance": 5, "support": 3, "roadmap": 4, "exit cost": 4},
    "Vendor C": {"workload fit": 3, "3-yr TCO": 5, "security/compliance": 3, "support": 3, "roadmap": 3, "exit cost": 5},
}
def total(s, w=WEIGHTS):
    return sum(w[k] * s[k] for k in w)
for v, s in SCORES.items():
    print(v, round(total(s), 2))
# Vendor A 3.9, Vendor B 4.1, Vendor C 3.7
for k in WEIGHTS:                                    # sensitivity: +0.10 on one criterion, renormalized
    w = {c: WEIGHTS[c] + (0.10 if c == k else 0) for c in WEIGHTS}
    w = {c: x / sum(w.values()) for c, x in w.items()}
    print(f"+{k:20}", {v: round(total(SCORES[v], w), 2) for v in SCORES})
# Vendor B wins every case. Closest: +workload fit, A 4.0 vs B 4.09
```

In the code, each vendor's total is the weighted sum of its 1–5 scores. Vendor B wins with 4.1, ahead of Vendor A
(3.9), which has the best workload fit but a poor exit cost. The sensitivity loop raises each criterion's weight by
0.10 in turn and renormalizes so weights still sum to 1. Vendor B stays the winner every time, and the closest call is
when workload fit gets more weight. Vendor A would only win if workload fit's weight rose from 0.30 to above 0.50
(before renormalizing). That tells the committee the decision is robust, and the one disagreement worth discussing is
how much Vendor A's better fit is worth against its exit cost.

**Example: the benchmark that didn't transfer.** An enterprise nearly chose an inference platform for its leading
public throughput benchmark. The POC, using the company's own retrieval-augmented workload with long prompts and strict
p99 latency, showed the second vendor delivered 30% more requests per second within the latency target. The contract
also included a 3-year price cap and full egress waivers on exit.

**Senior / FAANG best practice.** Agree weighted criteria before demos, run POCs on your own workloads with success
criteria written in advance, check score sensitivity, call references of similar size, and negotiate SLAs, price
protection, data terms, and exit terms. Keep a credible alternative for critical capabilities, and record the
decision.

---

## Lecture 290 — Hybrid on-prem + cloud AI strategy

**Why it matters.** Few enterprises are fully cloud or fully on-prem for AI. Steady training and inference load may be
cheaper on owned or committed capacity, regulated data may need to stay in specific data centers, and bursts and new
services fit the cloud. Without a consistent platform across both, a hybrid strategy becomes two separate estates with
double the operations.

**In plain words.** It's like a company owning its delivery vans for daily routes, and renting extra trucks in the
holiday season. The drivers follow the same rules and use the same dispatch system for both.

**Architecture: a hybrid AI platform.**

```mermaid
flowchart LR
  subgraph ONP["On-prem data center"]
    G1["Owned GPU clusters<br/>steady training, sensitive data"]
    DL["Regulated data lake"]
  end
  subgraph CL["Cloud regions"]
    G2["Cloud GPUs<br/>bursts, new hardware"]
    INF["Inference near users<br/>managed services"]
  end
  CP["One control plane<br/>GitOps, policies, identity, monitoring"] --> G1 & G2 & INF
  ONP <-->|"private link<br/>Direct Connect, ExpressRoute, Interconnect"| CL
  SCHED2["Workload placement<br/>data location, cost, capacity"] --> G1 & G2
```

**How to read it:** the on-prem data center runs owned GPU clusters for steady training and sensitive data, next to the
regulated data lake. Cloud regions provide GPUs for bursts and for new hardware generations, plus inference close to
users with managed services. One control plane deploys and governs everything with GitOps, policies, identity, and
monitoring. A private network link connects the two sides, and a placement policy decides where each workload runs,
based on where its data lives, cost, and available capacity.

**Terms in this diagram.**
- **Owned GPU clusters**: servers the company buys and runs, depreciated over 3–5 years.
- **Regulated data lake**: storage for data that, by law or policy, must stay in specific locations or systems.
- **New hardware**: the cloud gets new GPU generations faster than an enterprise's purchase cycle.
- **GitOps**: managing all environments from configuration in Git, applied automatically by tools such as Argo CD
  (Section 10).
- **Direct Connect, ExpressRoute, Interconnect**: AWS, Azure, and Google Cloud's dedicated private network connections
  between data centers and the cloud (Section 13).
- **Workload placement**: the rules that decide where each job runs.

**Core ideas.**
- **Place by data, then cost.** Data gravity and regulation decide first. Moving petabytes costs time and egress.
  Then compare cost for the remaining flexible workloads.
- **Compare like with like.** Owned hardware is paid for whether used or not, as are cloud commitments. Compare on-prem
  cost per available GPU-hour with committed cloud prices, and on-prem cost per used GPU-hour with on-demand prices (the
  lab computes both).
- **Hidden on-prem costs.** Facilities and power (10 kW or more per 8-GPU server, and liquid cooling for the newest
  systems), networking, support contracts, staff, spare parts, and refresh risk when new GPU generations arrive.
- **One platform.** The same Kubernetes distribution or API, the same CI/CD and policies, the same identity, and the
  same observability on both sides. Otherwise teams learn two platforms and incidents take twice as long.
- **Burst rules.** Decide which workloads may burst to cloud (non-sensitive data, checkpointing jobs), and reserve cloud
  capacity ahead for known peaks.

**Example: the half-empty data center.** A manufacturer bought 512 GPUs for a forecast that assumed 85% utilization.
Actual utilization was 45% in the first year, as projects took longer to start, which made their cost per used
GPU-hour higher than cloud on-demand prices. They opened the cluster to every business unit through a shared Kueue
platform with chargeback (Section 40), moved bursts to cloud, and reached 78% utilization in the second year.

**Senior / FAANG best practice.** Place workloads by data location and regulation first, then by cost. Compare on-prem
and cloud on equivalent bases, include all hidden costs, and buy owned capacity only for load you're confident will keep
it highly utilized. Run one control plane, with the same identity, policies, and monitoring, across both environments,
and define which workloads may burst.

---

## Lecture 291 — Compliance and regulatory burdens

**Why it matters.** Enterprises in finance, healthcare, insurance, and the public sector must prove that AI systems meet
laws and standards. Compliance done by hand, through spreadsheets and screenshots before each audit, is slow and
fragile. Compliance built into the platform makes every model compliant by default.

**In plain words.** It's like building codes. A builder doesn't argue with each inspector from scratch: they use
pre-approved designs, keep records as they build, and the inspection becomes a quick check.

**Architecture: from regulation to automated evidence.**

```mermaid
flowchart LR
  REG["Regulations and standards<br/>EU AI Act, GDPR, HIPAA, SR 11-7,<br/>SOC 2, ISO 27001, ISO 42001"] --> CTRL["Control library<br/>one control, many regulations"]
  CTRL --> IMPL["Platform implementation<br/>policies as code, pipeline gates"]
  IMPL --> EVID["Automated evidence<br/>logs, model cards, approvals, lineage"]
  EVID --> AUD["Audit and reporting<br/>internal, external, regulators"]
  OWN2["Control owners"] --> CTRL
```

**How to read it:** regulations and standards are mapped to a control library, where one control (such as "every
production model has an approved risk assessment") can satisfy several regulations at once. The platform implements
controls as policies in code and as gates in pipelines. Each implementation automatically produces evidence: logs,
model cards, approval records, and lineage. Evidence feeds internal and external audits and regulator reporting. Every
control has a named owner.

**Terms in this diagram.**
- **EU AI Act**: the European Union's AI regulation, with obligations phased in from 2025 to 2027. It bans some uses,
  sets duties for general-purpose AI model providers, and imposes strict requirements on high-risk systems (such as
  credit scoring and hiring): risk management, data governance, logging, human oversight, accuracy, and robustness.
- **GDPR, HIPAA**: the EU's data protection law, and the US health privacy law (Sections 18 and 38).
- **SR 11-7**: US banking regulators' guidance on model risk management, requiring independent validation, documentation,
  and ongoing monitoring of models.
- **SOC 2, ISO 27001**: widely requested security assurance reports and certifications.
- **ISO 42001**: ISO/IEC 42001, a management-system standard for AI, covering policies, risk, and lifecycle processes.
- **Control library**: the company's list of controls, each mapped to the regulations it satisfies.
- **Policies as code, pipeline gates**: rules enforced by software, such as admission policies and CI checks that block
  deployment if requirements are missing (Sections 10 and 34).
- **Model cards, lineage**: standard documentation of a model's purpose, data, performance, and limits, and records of
  what data and code produced it.

**Core ideas.**
- **Map once, satisfy many.** Most regulations ask for similar things: inventory, risk assessment, data governance,
  access control, logging, testing, human oversight, and incident handling. A shared control library avoids separate
  programs per regulation.
- **Infrastructure implications.**
  - Regional deployment for data residency.
  - Immutable audit logs, retained for required periods.
  - Lineage from data to deployed model.
  - Access reviews.
  - Logging of inputs and outputs for high-risk systems, within privacy limits.
  - Reproducible training for validation.
- **Risk tiers decide effort.** Low-risk internal tools need light controls. High-risk decisions about people need
  independent validation, human oversight, and continuous monitoring (Section 34).
- **Evidence by default.** Pipelines record approvals, test results, and model cards automatically, so an audit is a
  query, not a project.
- **Watch the timelines.** Regulations change and phase in, so a named owner tracks obligations and updates controls.

**Example: the audit that took a day.** An insurer's model risk team used to spend six weeks gathering evidence for
each annual audit. After building controls into the platform (risk-tier approvals in the registry, model cards
generated in pipelines, lineage from the feature store, and tamper-evident audit logs, as in Section 34), the auditors
received a generated report per model, and sampling checks took one day.

**Senior / FAANG best practice.** Build one control library mapped to all applicable regulations, with owners.
Implement controls as policies and pipeline gates that generate evidence automatically, scale controls by risk tier,
deploy regionally where residency requires, and assign someone to track regulatory timelines.

---

## Lecture 292 — Integration with enterprise IT systems

**Why it matters.** An AI platform that doesn't use the company's identity provider, change process, security
monitoring, and data platforms gets blocked by security, bypassed by users, or duplicated. Integration is what makes
the platform acceptable to the rest of the enterprise.

**In plain words.** A new department in a large company must use the company's badge system, HR processes, finance
codes, and mail room. It can't invent its own and expect everyone to adapt.

**Architecture: AI platform integrations.**

```mermaid
flowchart TB
  PLAT2["AI platform"]
  IDP2["Identity<br/>Entra ID or Okta, SSO, SCIM"] --> PLAT2
  PLAT2 --> ITSM2["ITSM<br/>ServiceNow changes, incidents, CMDB"]
  PLAT2 --> SIEM2["SIEM<br/>Splunk or Sentinel audit and security logs"]
  DATA2["Data platforms<br/>Snowflake, Databricks, warehouse"] --> PLAT2
  PLAT2 --> APIM["API management<br/>Apigee, Kong, Azure APIM"]
  PLAT2 --> FIN["FinOps<br/>cost centers, chargeback"]
  SEC2["Secrets and keys<br/>Vault, HSM, KMS"] --> PLAT2
```

**How to read it:** the AI platform takes users and groups from the company identity provider. It records changes and
incidents in the IT service management system and registers its services in the configuration database. It sends audit
and security logs to the SIEM. It reads data from the company's data platforms, publishes model APIs through the
enterprise API management layer, reports cost to FinOps by cost center, and gets secrets and keys from the company's
vaults and hardware security modules.

**Terms in this diagram.**
- **Entra ID or Okta**: Microsoft's and Okta's identity providers, the systems that hold employee accounts and groups.
- **SSO, SCIM**: single sign-on, and System for Cross-domain Identity Management, a standard that automatically creates,
  updates, and removes user accounts and group memberships in other systems.
- **ServiceNow, CMDB**: a widely used ITSM product, and its configuration management database listing systems, owners,
  and dependencies.
- **Splunk, Sentinel**: common SIEM products from Splunk and Microsoft.
- **Snowflake, Databricks**: popular cloud data warehouse and lakehouse platforms.
- **API management (Apigee, Kong, Azure APIM)**: gateways that publish APIs with authentication, rate limits, and
  analytics for internal and external consumers.
- **Cost centers, chargeback**: accounting units that budgets and costs are assigned to (Section 40).
- **Vault, HSM, KMS**: HashiCorp Vault for secrets, hardware security modules for keys, and cloud key management
  services.

**Core ideas.**
- **Identity first.** SSO for every tool (notebooks, MLflow, dashboards, serving consoles), SCIM so leavers lose access
  automatically, and groups mapped to platform roles (Section 40).
- **Change management without slowness.** Register the platform's GitOps pipeline as a pre-approved standard change, so
  routine model deployments create change records automatically instead of waiting for a weekly review board.
- **Security monitoring.** Send Kubernetes audit logs, gateway logs, and model registry events to the SIEM, with
  AI-specific detections (Section 39).
- **Data access through the data platform.** Use the data platform's governed access and lineage, rather than copying
  data into ML-only buckets.
- **Publish through existing API management.** Model endpoints go through the same API gateway as other services, so
  consumers get familiar authentication, quotas, and documentation.
- **Integration patterns.** APIs for synchronous calls, events (such as Kafka) for asynchronous flows, and change data
  capture to stream updates from operational databases (Section 24).

**Example: the change board bottleneck.** Every model update at a telecom needed a weekly change advisory board
approval, so retraining happened monthly at best. The platform team documented the automated pipeline (tests,
evals, canary, and automatic rollback) and got it approved as a standard change. Model updates then created ServiceNow
change records automatically, the change board reviewed the process quarterly, and models were updated weekly.

**Senior / FAANG best practice.** Integrate identity with SSO and SCIM first, make the deployment pipeline a pre-approved
standard change that records itself in ITSM, send audit and security logs to the SIEM, use the data platform's governed
access, publish models through enterprise API management, and report cost by cost center.

---

## Lecture 293 — Scaling teams for AI infra management

**Why it matters.** Technology alone doesn't scale an enterprise AI platform. Without clear team responsibilities,
platform teams become ticket queues, every business unit builds its own stack, and nobody owns reliability.

**In plain words.** It's like a city's services. A utilities department runs water and power for everyone, advisors help
new businesses get set up, and each business runs its own shop. Everyone knows who to call when the water stops.

**Architecture: team topology for an AI platform.**

```mermaid
flowchart TB
  subgraph PLT["Platform team: product owner + engineers"]
    P1["Compute and scheduling"]
    P2["ML lifecycle tools"]
    P3["Serving and gateway"]
  end
  SRE2["SRE: SLOs, on-call, DR"] --- PLT
  EN["Enabling team or CoE<br/>training, templates, office hours"] --> ST["Stream-aligned ML teams<br/>in business units"]
  PLT -->|"self-service paved path"| ST
  CS["Specialist teams<br/>GPU performance, security, FinOps"] -.-> PLT
  ST -->|"feedback, requests"| PLT
```

**How to read it:** a platform team, with a product owner and engineers, runs compute and scheduling, ML lifecycle
tools, and serving and the gateway. An SRE group shares responsibility for SLOs, on-call, and disaster recovery. An
enabling team or center of excellence trains business-unit ML teams and gives them templates and office hours. The
platform team serves those teams through a self-service paved path, and they send feedback and requests back. Specialist
teams for GPU performance, security, and FinOps support the platform.

**Terms in this diagram.**
- **Platform team**: builds and runs the shared internal platform as a product.
- **Product owner**: decides the platform's priorities based on its internal users' needs.
- **SRE**: site reliability engineers, who own SLOs, incident response, and reliability work (Section 19).
- **Enabling team, CoE**: a team, or center of excellence, that helps others adopt practices and tools, then steps back.
- **Stream-aligned teams**: teams aligned to a business area or product, building and owning its ML models end to end.
  These four team types come from the book *Team Topologies*.
- **Specialist teams**: experts in a hard area (such as GPU kernel performance), called "complicated-subsystem" teams in
  *Team Topologies*.
- **Office hours**: regular open sessions where users can ask the platform team questions.

**Core ideas.**
- **Self-service over tickets.** If the platform team handles requests by hand, it can't scale. Every common request
  (namespace, quota, GPU type, endpoint) should be self-service with guardrails.
- **Clear ownership.** Business-unit teams own their models (on-call for model quality). The platform owns the platform
  (on-call for infrastructure). Write this down as a shared responsibility model.
- **Typical roles.** ML platform engineers, MLOps engineers, SREs, GPU infrastructure and HPC engineers, data platform
  engineers, security engineers for AI, FinOps analysts, and a product manager.
- **Measure the platform.**
  - Adoption (share of models on the paved path).
  - Time from idea to production.
  - Platform SLOs.
  - Cost per GPU-hour.
  - Internal satisfaction surveys.
- **Grow skills internally.** Training programs, internal communities, and rotations between the platform and
  business-unit teams spread knowledge faster than hiring alone.

**Example: from ticket queue to paved path.** A retailer's 6-person ML platform team had a backlog of 300 tickets for
namespaces, GPU quotas, and endpoints, with a 3-week wait. They made the top 10 request types self-service through a
portal backed by GitOps and policies, created a 3-person enabling team for onboarding, and set up shared on-call with
SRE. Wait time fell to under a day, and the platform team spent most of its time on roadmap work again.

**Senior / FAANG best practice.** Organize around a platform team run as a product, SRE for reliability, an enabling team
for adoption, and specialists for GPU performance, security, and FinOps. Make common requests self-service, write a
shared responsibility model, and measure adoption, time to production, SLOs, and cost.

---

## Lecture 294 — Lab: design enterprise AI infra plan

**Goal:** write a complete enterprise AI infrastructure plan for a fictional global insurer, including requirements, an
honest on-prem vs cloud TCO computed with a script, a target architecture, a compliance control mapping, a team plan,
and a phased roadmap with risks.

**What you're building:** a design document `ai_infra_plan.md` and a TCO script `tco.py`.

```mermaid
flowchart LR
  RQ["(1) Requirements<br/>workloads, data, risk tiers"] --> TCO2["(2) TCO model<br/>on-prem vs cloud"]
  TCO2 --> ARCH["(3) Target architecture<br/>hybrid platform"]
  ARCH --> CMAP["(4) Compliance mapping<br/>controls, evidence, owners"]
  CMAP --> ORG["(5) Teams and operating model"]
  ORG --> RM["(6) Roadmap and risks<br/>phases, decisions, mitigations"]
```

**How to read the diagram:** the plan is written in six steps: requirements (workloads, data, and risk tiers), a TCO
model comparing on-prem and cloud, the target architecture, a compliance mapping of controls, evidence, and owners, the
team and operating model, and a phased roadmap with risks. Each step builds on the previous one. **TCO** is total cost
of ownership: every cost of a choice over its life, not just the purchase price.

**Prerequisites:** Python 3, a text editor, and Sections 33, 34, and 40.

### Step 1 — Requirements

The insurer has 40,000 employees in the EU and US. Write the requirements section with these facts:

- **Workloads:** claims fraud models (high risk under the insurer's policy, and possibly high-risk under the EU AI Act
  if used for pricing life or health insurance), a document-processing LLM for claims (24/7, about 300 requests a
  second at peak), and fine-tuning several open 8B–70B models a quarter.
- **Data:** EU customer data must stay in EU data centers or EU cloud regions. Claims history (2 PB) lives in the
  on-prem data lake in Frankfurt.
- **Existing estate:** two on-prem data centers (Frankfurt, Dallas), Azure as the main cloud, Entra ID, ServiceNow,
  Splunk, and Snowflake.
- **Steady GPU demand forecast:** about 256 H100-class GPUs used around the clock, plus bursts of up to 256 more for
  fine-tuning a few weeks a quarter.

### Step 2 — TCO model

```python
# tco.py: on-prem 256-GPU cluster vs cloud, all numbers illustrative, so replace with your quotes
GPUS_PER_NODE, NODES = 8, 32
NODE_PRICE, NET_SHARE, STORAGE = 320_000, 0.20, 1_500_000     # $ per 8-GPU server, network as share, $ storage
YEARS = 4                                                       # depreciation
NODE_KW, PUE, KWH = 10.2, 1.3, 0.10                             # kW per server, facility overhead, $ per kWh
COLO_PER_KW_MONTH = 150                                         # $ per kW of IT load per month for space and cooling
SUPPORT_SHARE = 0.08                                            # yearly hardware support as share of capex
STAFF, STAFF_COST = 4, 250_000
SOFTWARE = 500_000                                              # $ per year
CLOUD = {"cloud on-demand": 6.00, "cloud 3-yr commit": 3.50}    # $ per GPU-hour

gpus = GPUS_PER_NODE * NODES
capex = NODES * NODE_PRICE * (1 + NET_SHARE) + STORAGE
lines = {
    "depreciation": capex / YEARS,
    "power": NODES * NODE_KW * PUE * 8760 * KWH,
    "colocation space": NODES * NODE_KW * COLO_PER_KW_MONTH * 12,
    "hardware support": capex * SUPPORT_SHARE,
    "operations staff": STAFF * STAFF_COST,
    "software": SOFTWARE,
}
annual = sum(lines.values())
hours = gpus * 8760
print(f"{gpus} GPUs, capex ${capex:,.0f}")
for k, v in lines.items():
    print(f"  {k:18} ${v:>12,.0f}/yr")
print(f"  {'total':18} ${annual:>12,.0f}/yr  = ${annual/hours:.2f} per available GPU-hour")
for u in (0.5, 0.7, 0.9):
    print(f"  at {u:.0%} utilization: ${annual/(hours*u):.2f} per used GPU-hour")
for name, p in CLOUD.items():
    print(f"{name}: ${p:.2f}/GPU-h, all 256 GPUs for a year ${p*hours:,.0f}")
print(f"break-even utilization vs on-demand: {annual/(hours*CLOUD['cloud on-demand']):.0%}")
print(f"on-prem vs 3-yr commit, both always-on: {1-annual/(hours*CLOUD['cloud 3-yr commit']):.0%} cheaper")
```

```bash
python3 tco.py
```

In the script, capital cost is 32 servers plus 20% for networking plus storage, depreciated over 4 years. Power is
server kW × PUE (the facility's overhead for cooling and power conversion) × hours × price. Colocation, support, staff,
and software are added per year. The script divides the yearly total by available GPU-hours, and by used GPU-hours at
several utilization levels, then compares with cloud prices.

### Step 3 — Target architecture

Draw the target architecture in Mermaid in your document. It should show: the Frankfurt GPU cluster next to the claims
data lake, Azure EU regions for bursts and LLM serving, Dallas for US workloads, one GitOps control plane, Entra ID,
Kueue quotas per business unit, the registry with risk-tier gates, enterprise API management in front of model
endpoints, and logs to Splunk.

### Step 4 — Compliance mapping

Write a table with columns `Control | Regulations | Implementation | Evidence | Owner`. Include at least: model
inventory, risk assessment by tier, data residency, access reviews, audit logging, human oversight for fraud decisions,
independent validation, and incident handling.

### Step 5 — Teams and operating model

Describe the platform team, SRE, enabling team, and specialists, the shared responsibility model (who is on call for
what), and the self-service requests.

### Step 6 — Roadmap and risks

Write three phases (for example, 0–6 months, 6–12 months, 12–24 months), each with goals, decisions, and exit
criteria, and a risk table `Risk | Likelihood | Impact | Mitigation`.

**Expected results:**
- `tco.py` prints a capex of $13,788,000 and an annual cost of $7,009,264, which is $3.13 per available GPU-hour.
- Cost per used GPU-hour: $6.25 at 50% utilization, $4.47 at 70%, and $3.47 at 90%.
- Running all 256 GPUs for a year costs $13,455,360 at cloud on-demand prices and $7,848,960 with a 3-year commitment.
- On-prem beats on-demand above 52% utilization, and is 11% cheaper than a 3-year commitment when both are fully paid
  for. Your plan should conclude: steady base load on-prem in Frankfurt (also required by data residency for the
  claims data), with bursts and LLM serving in Azure EU regions, and a utilization target of at least 70%.
- The document has all six sections, an architecture diagram, a compliance table with at least 8 controls, and a risk
  table with at least 6 risks.

---

## Assessment — Defend an enterprise AI infrastructure proposal

**Scenario (live exercise, about 45 minutes):** you present the plan from the lab to the insurer's architecture review
board: the CIO, the CISO, the head of model risk, the data protection officer, a finance director, and the enterprise
architect. You have 10 minutes to present, then 35 minutes of questions. Your proposal: $13.8 million capex for a
256-GPU cluster in Frankfurt, Azure EU for bursts and LLM serving, a shared multi-tenant platform with chargeback, and a
platform organization of 18 people over two years.

**Deliverable:** a 10-minute presentation and answers to the board's questions. A model answer:

| Board member and question | Strong answer (model) |
|---|---|
| Finance: "Why buy hardware when cloud is flexible?" | "Our forecast is 256 GPUs around the clock for at least four years, and the claims data must stay in Frankfurt. On-prem costs $3.13 per available GPU-hour against $3.50 for a 3-year commitment and $6.00 on demand. It beats on-demand above 52% utilization. We commit to a 70% utilization target, reported monthly, and bursts go to Azure, so we don't size for peaks" |
| Finance: "What if the forecast is wrong?" | "Phase 1 buys 128 GPUs, not 256. We buy the second half only when phase 1 utilization exceeds 70% for a quarter. Until then, extra demand goes to Azure. The downside is limited to half the capex" |
| CISO: "How is this secured?" | "Entra ID SSO and SCIM for every tool, namespaced RBAC by business unit, default-deny network policies, no public endpoints for ML tools, signed models verified at load, egress allowlists on GPU nodes, and all audit logs in Splunk with AI-specific detections. The design follows our Section 39 controls, and we'll run a red-team exercise before go-live" |
| Model risk: "How do we validate and monitor high-risk models?" | "The registry enforces risk-tier gates: high-risk models can't be promoted without an independent validation record, a model card, a fairness assessment, and named human-oversight procedures. Monitoring for drift and performance is required, with alerts to the model owner and model risk. Evidence is generated automatically, for SR 11-7-style validation and EU AI Act logging" |
| DPO: "Where does personal data go?" | "EU personal data stays in Frankfurt or Azure EU regions, enforced by policy on storage locations and workload placement. Training data is minimized and pseudonymized. LLM prompts are logged with redaction and 30-day retention. We've done a DPIA draft for the claims LLM and will finalize it with you before launch" |
| Enterprise architect: "Does this create a second IT estate?" | "No. It uses Entra ID, ServiceNow (deployments as standard changes), Splunk, Snowflake's governed access, and our API management. One GitOps control plane manages both Frankfurt and Azure, so there's one way to deploy" |
| CIO: "What are the biggest risks?" | "Three: GPU delivery lead times (mitigated by ordering phase 1 now and using Azure in the meantime), hiring GPU and platform skills (mitigated by an enabling team and training, with a partner for the first year), and adoption (mitigated by migrating the fraud team first as a reference case, and measuring time to production)" |
| CIO: "What does success look like in 12 months?" | "Fraud and claims models on the platform, time from approved idea to production under 8 weeks, utilization at or above 70%, platform availability of 99.9%, a passed internal audit using generated evidence, and chargeback live for all business units" |

**What reviewers look for:**
- **Numbers that survive challenge.** TCO on equivalent bases, with sensitivity to utilization and stated assumptions.
- **Risk-limiting phasing.** Buy capacity in stages with clear triggers, rather than one large bet.
- **Data and regulation first.** Placement justified by residency and data gravity before cost.
- **Security and compliance built in**, with specific controls and automatically generated evidence.
- **Integration with existing systems**, so the platform doesn't create a parallel estate.
- **People and operating model.** Owners, on-call, an enabling team, and skills plans.
- **Measurable success criteria** that the board can check later.
- **Honest answers.** Saying "we don't know yet, here's how we'll find out" is better than inventing certainty.

---

## FAANG deep-dive notes

**How big tech does it.** Hyperscalers sell to enterprises, and their enterprise field teams know these patterns well:
landing zones with identity, network, and policy guardrails, private connectivity to on-prem data centers, hybrid
platforms (Azure Arc, Google Distributed Cloud, AWS Outposts) that extend cloud control planes on-prem, and
compliance-ready services with certifications and data residency. Internally, big tech runs AI infrastructure as a
product with platform teams, SRE, chargeback, and governance processes, at a scale where every 1% of utilization is
worth millions. They choose owned capacity (their own data centers) for steady load, and decide on placement by data,
power availability, and cost.

**Staff review questions.**
- Which workloads, data, and risk tiers drive the design?
- Is the TCO comparison made on equivalent bases, and how sensitive is it to utilization?
- What is phased, and what triggers each phase?
- Which controls satisfy which regulations, and how is evidence produced?
- Which enterprise systems does the platform integrate with, and which does it replace?
- Who owns what, and how is the platform's success measured?

**Interview question.** "A global bank wants an AI platform for 200 data scientists across 10 countries. How do you
design it?"

**Typical system-design prompt:** *Design an enterprise AI platform for a bank with data residency requirements in the
EU, UK, and Singapore, serving 200 data scientists and 50 production models.*

**1. Clarify first:** Which models are high-risk? Existing data centers and cloud? Data residency rules per country?
GPU demand (training vs inference)? Current tools and identity? Budget and timeline?

**2. Back-of-envelope sizing:**
- 200 data scientists, about 1 GPU-hour per person per working hour for notebooks and experiments, at a 30%
  concurrency peak: about 60 GPUs of interactive capacity, mostly MIG slices.
- Training: say 4 fine-tunes a month × 64 GPUs × 3 days: about 18,400 GPU-hours a month, about 25 GPUs on average.
  Bursty, so committed cloud capacity or a shared pool.
- Serving: 50 models, most small on CPUs or MIG slices, and a few LLMs on 8 to 16 GPUs per region.
- Regions: EU, UK, and Singapore deployments, each with local data, and a shared control plane.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Compute | All cloud | Hybrid | Hybrid when steady load and data gravity justify owned capacity |
| Regions | Central | Per residency zone | Per zone for data, one control plane |
| Platform | Build | Buy (managed ML platform) | Buy where it meets controls, build the glue |
| Compliance | Manual audits | Evidence as code | Evidence as code |
| Organization | Central team only | Platform + enabling + BU teams | Platform with enabling team |

**4. Follow-up questions with crisp answers:**
- *A country tightens data residency.* Placement policies move workloads and data to the local zone, and the control
  plane is unchanged.
- *A business unit wants its own platform.* Show the cost and controls they'd need to rebuild, and offer dedicated node
  pools within the shared platform.
- *The board asks for AI Act readiness.* The control library maps obligations to platform controls, and generated
  evidence shows status per model.
- *GPU lead time is 9 months.* Commit cloud capacity for the gap, and order owned hardware in phases.

**Debug this (common onsite question):** "A year after go-live, the enterprise GPU cluster is 40% utilized, while teams
say they can't get GPUs."
1. Quotas were assigned statically per business unit, without borrowing.
2. Two units hold large quotas they rarely use, and others queue.
3. Notebooks hold whole GPUs overnight.
4. Fix: Kueue cohorts with borrowing and reclaim, MIG for notebooks, idle notebook shutdown, chargeback by requested
   GPU-hours, and quarterly quota reviews (Section 40).

The lesson: owned capacity only pays off with shared, actively managed allocation.

**5. What separates senior from staff answers:** a senior engineer designs a good technical platform. A staff engineer
connects it to regulation, finance, procurement, and organization: placement driven by data and law, TCO on equal
bases with phased commitments, controls that generate evidence, integration with existing IT, a team model, and
success criteria the board can hold them to.

**Red flags:**
- TCO comparing on-prem at 100% utilization with cloud on-demand.
- One large hardware purchase with no phasing.
- Compliance as a later project.
- A parallel identity or deployment system.
- No owner for models in production.
- Vendor chosen from benchmarks without a POC.
- No exit terms in contracts.

---

## Quiz

<details><summary>1. Why do enterprise AI projects often stall after the model is built?</summary>
Data access approvals, security reviews, network changes, model risk validation, and integration with existing systems.
Pre-approved paths in the platform remove these delays.
</details>

<details><summary>2. Why agree weighted vendor criteria before demos?</summary>
So the decision isn't swayed by presentations, every vendor is judged the same way, and the scoring record holds up in
audits.
</details>

<details><summary>3. How should on-prem GPU cost be compared with cloud?</summary>
On equivalent bases: cost per available GPU-hour against committed cloud prices (both paid whether used or not), and cost
per used GPU-hour, at realistic utilization, against on-demand prices.
</details>

<details><summary>4. What does a control library do for compliance?</summary>
It maps each control to every regulation it satisfies, so one implementation and its evidence serve several regulations,
each with a named owner.
</details>

<details><summary>5. What is SCIM, and why does an AI platform need it?</summary>
A standard for automatically creating, updating, and removing user accounts and group memberships, so people who leave or
change teams lose access to AI tools automatically.
</details>

<details><summary>6. How can model deployments avoid weekly change board delays?</summary>
Get the automated, tested pipeline approved as a standard change that creates its own change records, with the board
reviewing the process periodically.
</details>

<details><summary>7. What are the four team types in Team Topologies?</summary>
Stream-aligned, platform, enabling, and complicated-subsystem (specialist) teams.
</details>

## Failure modes
- Platforms built around GPUs, ignoring data access, governance, and integration.
- Vendor choices based on demos and public benchmarks.
- TCO comparisons on unequal bases, or ignoring facilities and staff.
- Big-bang hardware purchases with low utilization.
- Compliance evidence collected by hand before audits.
- Parallel identity, change, or logging systems.
- Platform teams overwhelmed by manual tickets.
- No shared responsibility model, so nobody owns model quality in production.

## Checklist
- [ ] The platform covers compute, data, lifecycle, governance, security, and operations
- [ ] Vendors are chosen with agreed weights, POCs on real workloads, sensitivity checks, and exit terms
- [ ] Hybrid placement follows data location and regulation first, then equivalent-basis TCO
- [ ] A control library maps regulations to controls, owners, and automated evidence
- [ ] Identity, ITSM, SIEM, data platforms, API management, and FinOps are integrated
- [ ] Teams follow a platform, SRE, enabling, and specialist model, with self-service and clear ownership
- [ ] You wrote an enterprise AI infrastructure plan with a TCO model
- [ ] You can defend the plan's numbers, phasing, controls, and risks to a review board
