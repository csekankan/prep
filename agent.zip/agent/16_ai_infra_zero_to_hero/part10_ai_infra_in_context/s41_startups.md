# Section 41 — AI Infrastructure for Startups

> Lectures 281–287 • Assessments: quiz, [Advise a startup CTO on a limited AI budget](#assessment--advise-a-startup-cto-on-a-limited-ai-budget)
> • Exercise: [`s41_startup_budget.py`](../exercises/s41_startup_budget.py)
> **After this section you can:** name the infrastructure risks that kill startups, pick lean GPU options (credits,
> neoclouds, spot, serverless GPUs), assemble an open-source MLOps stack a two-person team can run, cut serving cost
> with routing, caching, and batching, plan the move from MVP to production, limit vendor lock-in where it matters, and
> deploy a working model API for a few dollars a month.
>
> Builds on: [Section 3](../part01_foundations/s03_cloud_basics.md) (cloud),
> [Section 12](../part03_mlops_cicd_cost/s12_cost_optimization.md) (cost),
> [Section 14](../part04_networking_serving/s14_model_serving.md) (serving),
> [Section 25](../part07_workloads/s25_genai_foundations.md) (GenAI), and
> [Section 35](../part08_scale_mlops_optimization/s35_optimization_foundations.md) (quantization).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 281 | Challenges startups face in AI infra | Runway, no platform team, and uncertain demand. Speed matters more than elegance |
| 282 | Lean GPU cloud solutions | Credits first, then APIs, serverless GPUs, neoclouds, and spot. Commit only to steady load |
| 283 | Open-source MLOps tools for startups | A small, boring stack: Postgres, MLflow, vLLM, a gateway, and an LLM tracing tool |
| 284 | Budget optimization for small teams | Know cost per request against revenue per request, then route, cache, batch, and shrink prompts |
| 285 | Scaling from MVP to production AI | Move from API prototype to managed services to self-hosting only when the numbers say so |
| 286 | Vendor lock-in risks for startups | Accept lock-in for speed, but own your data, evals, and the API boundary |
| 287 | Lab: deploy AI infra on low budget | A quantized model behind an API key and TLS on a CPU VM, with measured cost per million tokens |

```mermaid
flowchart LR
  CR["Credits<br/>cloud and GPU programs"] --> API["Hosted model APIs<br/>prototype fast"]
  API --> GW["Own the boundary<br/>gateway, evals, logs"]
  GW --> OPT["Unit economics<br/>route, cache, batch"]
  OPT --> SH["Self-host when it pays<br/>vLLM on neocloud or spot"]
  SH --> PROD["Production basics<br/>monitoring, fallbacks, on-call"]
```

**How to read it:** a startup usually begins on cloud credits, building the first product on hosted model APIs because
that's fastest. Early on, it puts its own gateway, evaluation suite, and request logs between the product and any
model, so it can switch providers later. As traffic grows, it tracks cost per request and cuts it with routing,
caching, and batching. It moves to self-hosted open models only when volume makes that cheaper, and adds production
basics such as monitoring, fallbacks, and an on-call rotation.

**Terms in this diagram.**
- **Credits**: free cloud or GPU usage from startup programs such as AWS Activate, Google for Startups, Microsoft for
  Startups, and NVIDIA Inception partners. Often worth $100,000 or more, but they expire.
- **Hosted model APIs**: paying per token to a provider (OpenAI, Anthropic, Google, Mistral, or open-model hosts such as
  Together and Fireworks) instead of running models yourself.
- **Gateway, evals, logs**: a thin service you own that every model call goes through (for keys, routing, retries, and
  cost tracking), a test set that scores any model on your task, and stored requests and responses (Lecture 286).
- **Unit economics**: cost and revenue per unit of value, such as per request, per user, or per document.
- **Route, cache, batch**: send easy requests to cheaper models, reuse previous answers or prompt prefixes, and use
  discounted batch processing for work that isn't urgent (Lecture 284).
- **Neocloud, spot**: GPU-focused cloud providers (such as Lambda, CoreWeave, Crusoe, RunPod, and Nebius), and
  interruptible spare capacity sold at a discount (Lecture 282).
- **On-call**: a rotation of engineers who respond to production alerts.

---

## Lecture 281 — Challenges startups face in AI infra

**Why it matters.** Startups rarely die because their infrastructure isn't elegant. They die when they run out of
money or time. An AI startup can burn through its runway on GPU bills, or spend six months building a platform instead
of finding customers.

**In plain words.** A food truck doesn't build a restaurant kitchen before it knows what customers will order. It
rents, buys ready-made ingredients where it can, and invests once it knows what sells.

**Architecture: where a startup's AI money and time go.**

```mermaid
flowchart TB
  RUN["Runway<br/>cash / monthly burn"] --> SERVE["Serving cost<br/>grows with traffic"]
  RUN --> TRAIN["Training and fine-tuning<br/>bursty, often one-off"]
  RUN --> PEOPLE["People<br/>no dedicated platform team"]
  SERVE --> RISK1["Risk: cost grows faster than revenue"]
  TRAIN --> RISK2["Risk: big GPU commitments too early"]
  PEOPLE --> RISK3["Risk: building platforms, not product"]
  RISK1 & RISK2 & RISK3 --> RULE["Rule: buy before build,<br/>measure unit cost from day 1"]
```

**How to read it:** runway (months of cash left at the current burn rate) is spent on three things: serving, which
grows with traffic; training and fine-tuning, which comes in bursts; and people, with no dedicated platform team.
Each has a typical failure: serving cost growing faster than revenue, committing to GPUs before demand is known, and
engineers building infrastructure instead of product. The rule that addresses all three is to buy managed services
before building your own, and to measure cost per unit from the first day.

**Terms in this diagram.**
- **Runway**: cash in the bank divided by monthly net burn (spending minus revenue), the number of months left before
  money runs out.
- **Serving cost**: what it costs to answer user requests with models, in API fees or GPU-hours.
- **Bursty, one-off**: training or fine-tuning that needs many GPUs for days, then none for weeks.
- **GPU commitments**: reserved capacity or long contracts that lower the hourly price, but must be paid whether used
  or not.
- **Buy before build**: use a managed service or API first, and build your own only when it becomes a clear cost or
  capability advantage.

**Core ideas.**
- **Typical constraints.** One or two engineers covering infrastructure part-time, a few hundred thousand to a few
  million dollars of cash, demand that may grow tenfold or vanish, and investors watching gross margin.
- **GPU access.** Big reserved clusters require long contracts. Small teams depend on on-demand, spot, credits, and
  APIs, and must design around capacity that can disappear.
- **AI-specific risks.**
  - Gross margins can be thin when every request calls an expensive model.
  - Model quality changes when providers update models.
  - Data handling and compliance questions arrive with the first enterprise customer (Section 42).
- **What not to build early.** Custom Kubernetes platforms, a feature store, multi-region active-active setups, and
  in-house training clusters, unless the product depends on them.

**Example: the platform that ate the seed round.** A startup's first two engineers spent five months building a
Kubernetes cluster with GitOps, a feature store, and self-hosted model serving, before having ten paying customers.
Their competitor shipped on a hosted API and a single Postgres database, found product-market fit first, and raised the
next round. The first startup later moved its product to hosted APIs and recovered, but lost half a year.

**Senior / FAANG best practice.** Before building any infrastructure, write down the runway, the expected traffic
range, and the gross margin target. Buy managed services and APIs first, measure cost per request from day 1, and
build only the infrastructure that directly lowers that cost or that customers require.

---

## Lecture 282 — Lean GPU cloud solutions

**Why it matters.** The same H100-hour can cost three times more on one provider than another, and paying on-demand
prices for steady load, or reserving capacity for unproven demand, wastes a startup's most limited resource.

**In plain words.** It's like getting around a city. Use taxis for occasional trips (APIs and serverless), rent a car by
the day when you need one for a while (on-demand GPUs), take the cheap standby flight when your schedule is flexible
(spot), and only buy a car once you drive every day (reserved capacity).

**Architecture: matching GPU options to workloads.**

```mermaid
flowchart LR
  subgraph WL["Workload"]
    W1["Prototype, spiky inference"]
    W2["Fine-tuning runs"]
    W3["Steady production inference"]
  end
  W1 --> O1["Hosted APIs or<br/>serverless GPUs: Modal, RunPod"]
  W2 --> O2["Spot or on-demand<br/>neocloud GPUs + checkpoints"]
  W3 --> O3["Reserved or committed<br/>capacity, once load is stable"]
  CRED["Credits<br/>use first, track expiry"] -.-> O1 & O2
```

**How to read it:** spiky inference and prototypes go to hosted APIs or serverless GPUs, where you pay only while a
request runs. Fine-tuning runs go to spot or on-demand GPUs at a neocloud, with frequent checkpoints so interruptions
cost little. Steady production inference moves to reserved or committed capacity only once its load is stable.
Credits are used first for the first two, with their expiry dates tracked.

**Terms in this diagram.**
- **Serverless GPUs (Modal, RunPod)**: platforms that start a GPU container when a request arrives and stop it when
  idle, billing per second. The catch is cold start: loading a model can take tens of seconds.
- **Spot**: spare cloud capacity at 50–90% discounts that the provider can reclaim with short notice (about 30 seconds
  to 2 minutes).
- **Checkpoints**: saved training state, so an interrupted job resumes instead of restarting (Section 32).
- **Reserved or committed capacity**: paying for capacity for months or years in return for a lower hourly price.
- **Track expiry**: credits usually expire after one to two years, and sometimes exclude GPU instance types.

**Core ideas.**
- **Price landscape (illustrative, late 2026).** H100-hours range from about $2 to $3 at neoclouds, to considerably
  more at hyperscalers on-demand, with reserved and spot prices lower. Prices change quickly, so compare at the time
  you buy, including storage and egress.
- **Smaller GPUs for small models.** An 8B model in INT4 or FP8 fits on an L4 or A10G (24 GB) for a fraction of an
  H100's price. A 0.5B to 3B model can even run on CPU (Lecture 287).
- **Hyperscaler vs neocloud.** Hyperscalers bring everything around the GPU (IAM, networking, managed databases,
  compliance) and often credits. Neoclouds are cheaper and simpler for raw GPUs. Many startups use both: application on
  a hyperscaler, GPUs on a neocloud.
- **Commit late and small.** Commit only to the base load you've seen for at least two to three months, and keep
  peaks on demand.
- **Availability.** Single-GPU deployments go down. Run at least two replicas for production inference, or keep a
  hosted API as fallback.

**Example: fine-tuning on spot for $140.** A startup fine-tuned an 8B model with LoRA on 8 spot H100s at about $1.10 per
GPU-hour, checkpointing every 15 minutes. Two interruptions cost 20 minutes of work in total. The 16-hour job cost
about $140, against about $380 on-demand, and the credits they still had went to serving.

**Senior / FAANG best practice.** Use credits first and track their expiry, put spiky work on APIs or serverless GPUs,
run training on spot with frequent checkpoints, and commit only to stable base load. Compare full costs (storage,
egress, support) across providers, and use the smallest GPU that meets the latency target.

---

## Lecture 283 — Open-source MLOps tools for startups

**Why it matters.** A two-person team can't operate twenty tools. Picking a small set of well-known open-source and
managed tools gives most of the benefits of a mature MLOps platform at a fraction of the work.

**In plain words.** It's like setting up a small workshop. You buy a few good, standard tools that do many jobs,
rather than a specialized machine for every task.

**Architecture: a minimal startup AI stack.**

```mermaid
flowchart LR
  APP["App backend"] --> GW2["LLM gateway<br/>LiteLLM: keys, routing, budgets"]
  GW2 --> PROV["Hosted APIs"]
  GW2 --> VLLM["vLLM<br/>self-hosted open model"]
  APP --> PG["Postgres + pgvector<br/>app data, embeddings"]
  GW2 --> TRACE["LLM tracing<br/>Langfuse: prompts, cost, evals"]
  TRAINJ["Fine-tune jobs"] --> MLF["MLflow<br/>runs, model registry"]
  MLF --> VLLM
  CI["GitHub Actions<br/>tests, evals, deploy"] --> APP
```

**How to read it:** the app backend sends every model call through an LLM gateway, which holds API keys, routes
between hosted APIs and a self-hosted vLLM server, and enforces budgets. App data and embeddings live in one Postgres
database with pgvector. The gateway sends traces to an LLM tracing tool that records prompts, costs, and evaluation
scores. Fine-tuning jobs are tracked in MLflow, whose registry supplies models to vLLM. GitHub Actions runs tests and
evaluations, and deploys the app.

**Terms in this diagram.**
- **LiteLLM**: an open-source gateway and library that exposes many model providers through one OpenAI-compatible API,
  with keys, routing, fallbacks, and spend limits.
- **vLLM**: a high-throughput open-source LLM server with an OpenAI-compatible API (Section 25).
- **Postgres + pgvector**: the popular relational database, with an extension for storing and searching embeddings,
  which avoids a separate vector database early on.
- **Langfuse**: an open-source tool for tracing LLM calls, tracking cost and latency, managing prompts, and recording
  evaluation scores. Arize Phoenix and others are similar.
- **MLflow**: experiment tracking and model registry (Section 9).
- **GitHub Actions**: CI/CD that runs tests, evaluations, and deployments on each change (Section 10).

**Core ideas.**
- **Prefer boring defaults.** Postgres for almost everything, one cloud, containers on a managed platform (Cloud Run,
  ECS, Fly.io, Render), and Kubernetes only when the team already knows it or needs GPU scheduling.
- **Free tiers and managed open source.** Many tools (MLflow, Langfuse, Weights & Biases) offer hosted versions with
  free tiers, which save running them yourself.
- **Evals as code.** A small, versioned set of examples with expected outcomes, run in CI on every prompt or model
  change, is the most valuable MLOps tool for an LLM startup.
- **Add tools when the pain is real.** A feature store when you have many features shared by several models, an
  orchestrator such as Dagster or Prefect when cron jobs become fragile, Ray when one machine isn't enough.

**Example: one database instead of three.** A seed-stage team ran Postgres for app data, Pinecone for vectors, and
Redis for caching, with three bills and three backup stories. Moving vectors to pgvector and caching to Postgres
tables (fine at their 2 million vectors and 50 requests per second) cut costs by $900 a month and removed two sources
of outages. They planned to revisit at 50 million vectors.

**Senior / FAANG best practice.** Start with a small stack: Postgres with pgvector, a gateway, vLLM when self-hosting,
LLM tracing, MLflow for fine-tunes, and CI with evals. Use managed or free-tier hosting for tools, and add components
only when a measured pain justifies the extra operations.

---

## Lecture 284 — Budget optimization for small teams

**Why it matters.** If each request costs more than it earns, growth makes the company poorer. A few techniques, such
as routing, caching, batching, and shorter prompts, often cut LLM costs by 5–10 times with little quality loss.

**In plain words.** It's like running a delivery business. You don't send a truck for every envelope. You use bikes for
small packages, combine deliveries, and reuse routes you've already planned.

**Architecture: cost levers on the request path.**

```mermaid
flowchart LR
  REQ["Request"] --> SC["Semantic or exact cache<br/>repeat questions"]
  SC -->|"miss"| ROUTE["Router<br/>easy vs hard"]
  ROUTE -->|"80%"| SMALL["Small model"]
  ROUTE -->|"20%"| BIG["Frontier model<br/>prompt caching on long prefixes"]
  OFF["Offline jobs<br/>enrichment, evals"] --> BATCH["Batch API<br/>about 50% cheaper"]
  SMALL & BIG --> METER["Cost per request vs<br/>revenue per request"]
```

**How to read it:** a request first checks a cache of previous answers. On a miss, a router decides whether it's easy
or hard: most go to a small, cheap model and the rest to a frontier model, which uses prompt caching for long, repeated
prefixes. Work that isn't urgent, such as data enrichment and evaluations, goes to discounted batch APIs. Every
request's cost is compared with the revenue it brings in.

**Terms in this diagram.**
- **Semantic or exact cache**: returning a stored answer for an identical request (exact) or a very similar one
  (semantic, by embedding similarity). Keyed by tenant and permissions (Section 25).
- **Router (easy vs hard)**: a rule or small classifier choosing the cheapest model likely to answer well. Also called a
  model cascade when it tries the small model first and escalates if confidence is low.
- **Prompt caching**: provider-side reuse of a repeated prompt prefix (such as a long system prompt or document),
  billed at a large discount.
- **Batch API**: providers' asynchronous endpoints that process requests within hours, usually at about half price.
- **Cost per request vs revenue per request**: unit economics. Gross margin = 1 − cost / revenue.

**Core ideas.**
- **Measure first.** Log tokens, model, and cost per request and per customer from day 1. Most savings come from the
  top few request types.
- **Shrink prompts.** Remove redundant instructions, cap retrieved context, and summarize long histories. Input tokens
  are usually most of the bill.
- **Route by difficulty.** Start with rules (request type, length), then train a classifier on logged outcomes. Check
  quality per route with evals.
- **Self-hosting economics.** Fixed GPU cost plus engineering time against per-token fees. Worth it above a break-even
  volume, or for privacy, latency, or customization (the assessment computes this).
- **Guardrails on spend.** Per-customer rate limits and budgets at the gateway, alerts at 50%, 80%, and 100% of the
  monthly budget, and a kill switch for runaway loops (such as an agent calling itself).

```python
def margin(price_per_user, requests_per_user, cost_per_request):
    cost = requests_per_user * cost_per_request
    return cost, 1 - cost / price_per_user

for name, cpr in [("frontier only", 0.009), ("router + cache", 0.001638)]:
    cost, m = margin(price_per_user=20.0, requests_per_user=600, cost_per_request=cpr)
    print(f"{name:15} cost/user ${cost:.2f}  gross margin {m:.0%}")
# frontier only   cost/user $5.40  gross margin 73%
# router + cache  cost/user $0.98  gross margin 95%
```

In the code, a user paying $20 a month who sends 600 requests costs $5.40 to serve with a frontier model at $0.009 per
request, a 73% gross margin before any other costs. With routing and prompt caching at $0.0016 per request, the cost
falls to $0.98 and the margin rises to 95%. Heavy users matter: at 3,000 requests a month, frontier-only serving costs
$27, more than the user pays.

**Example: the agent loop.** A startup's coding agent occasionally got stuck retrying a failing tool, calling a frontier
model hundreds of times for one task. One weekend, a few such loops cost $11,000. They added a per-task budget of $2 at
the gateway, a maximum of 25 steps per task, and an alert on any customer's hourly spend above three times their usual
rate.

**Senior / FAANG best practice.** Track cost per request and gross margin per customer, shrink prompts, cache repeated
work, route by difficulty with eval-checked quality, use batch APIs for offline work, and set budgets, rate limits, and
kill switches at the gateway. Self-host only above the computed break-even volume, or for privacy or latency.

---

## Lecture 285 — Scaling from MVP to production AI

**Why it matters.** The infrastructure that gets the first ten customers isn't the one that serves ten thousand.
Moving too early wastes money, and moving too late causes outages and lost customers. Clear triggers tell you when to
take each step.

**In plain words.** It's like a band that starts playing in a garage, then rents a rehearsal studio, and buys its own
equipment only when it's touring every week.

**Architecture: stages and triggers.**

```mermaid
flowchart LR
  ST1["Stage 1: MVP<br/>hosted API, one service, Postgres"] -->|"paying users, first incident"| ST2["Stage 2: production basics<br/>gateway, evals in CI, monitoring, fallbacks"]
  ST2 -->|"bill above break-even, privacy or latency needs"| ST3["Stage 3: hybrid<br/>self-host open model for high-volume paths"]
  ST3 -->|"steady load, many models"| ST4["Stage 4: platform<br/>Kubernetes GPU pool, autoscaling, commitments"]
```

**How to read it:** in stage 1, an MVP calls a hosted API from one service with one database. Paying users or a first
incident trigger stage 2: a gateway, evaluations in CI, monitoring, and fallbacks. When the API bill passes the
break-even point, or customers need privacy or lower latency, stage 3 self-hosts an open model for the high-volume
paths while keeping APIs for the rest. Only with steady load and many models does stage 4 build a platform: a
Kubernetes GPU pool with autoscaling and committed capacity.

**Terms in this diagram.**
- **MVP**: minimum viable product, the simplest version that tests whether customers want it.
- **Fallbacks**: alternatives when a model or provider fails, such as a second provider or a simpler response.
- **Break-even**: the volume at which self-hosting's fixed cost equals what the API would cost (Lecture 284).
- **Hybrid**: self-hosted models for some paths, hosted APIs for others.
- **Kubernetes GPU pool**: a cluster of GPU nodes running several models, with autoscaling and scheduling (Section 11).
- **Commitments**: reserved capacity at lower prices (Lecture 282).

**Core ideas.**
- **Production basics, in order.**
  - Request logging with cost.
  - An eval suite in CI.
  - Uptime and latency monitoring with alerts.
  - Timeouts, retries, and a fallback provider.
  - Rate limits per customer.
  - Backups and a written incident process.
- **First enterprise customer.** Expect security questionnaires, SSO, data residency, and SOC 2 requests. Choosing
  providers that already have these (and data-processing agreements) saves months (Section 42).
- **Hiring.** The first dedicated infrastructure engineer usually arrives when infrastructure is clearly slowing product
  work or the API bill is large enough that saving 30% pays their salary.
- **Keep the exit open.** Each stage should keep the gateway and evals, so moving a path between API and self-hosting is
  a configuration change, not a rewrite.

**Example: the launch-day outage.** A startup's MVP called one provider directly. On launch day, the provider had a
regional outage for 40 minutes and the product was down. After that, they routed through a gateway with a second
provider as fallback (with prompts checked against both in CI), and the next provider outage caused only slightly
slower responses.

**Senior / FAANG best practice.** Define triggers for each stage (paying users, the first incident, bill above
break-even, privacy or latency requirements, steady load) and add production basics before scaling. Keep the gateway
and evals as the stable layer, so moving between APIs and self-hosting is cheap, and plan for enterprise requirements
before the first big deal.

---

## Lecture 286 — Vendor lock-in risks for startups

**Why it matters.** Depending on one model provider or cloud is often the right choice for speed, but it can hurt: price
increases, model deprecations, outages, or a provider launching a competing product. The goal isn't zero lock-in, but
being able to switch the parts that matter within weeks.

**In plain words.** It's fine to rent a furnished flat, but keep your important documents in your own folder, so moving
out takes a weekend instead of a year.

**Architecture: what to own and what to rent.**

```mermaid
flowchart TB
  subgraph OWN["Own: portable"]
    D1["Your data<br/>logs, labels, fine-tuning sets"]
    D2["Eval suite<br/>scores any model"]
    D3["API boundary<br/>gateway, OpenAI-compatible"]
    D4["Infrastructure as code<br/>Terraform, containers"]
  end
  subgraph RENT["Rent: replaceable"]
    R1["Model providers"]
    R2["Managed databases, queues"]
    R3["GPU clouds"]
  end
  D3 --> R1
  D4 --> R2 & R3
```

**How to read it:** the startup owns the parts that make switching possible: its data (logs, labels, and fine-tuning
sets), an evaluation suite that can score any model, an API boundary such as a gateway with an OpenAI-compatible
interface, and infrastructure defined as code with containers. It rents the replaceable parts: model providers,
managed databases and queues, and GPU clouds. The gateway connects to model providers, and infrastructure code creates
the managed services and GPU capacity.

**Terms in this diagram.**
- **Logs, labels, fine-tuning sets**: recorded requests and responses, human or automatic quality labels, and the
  datasets used to fine-tune models. These are what let you train or evaluate a replacement.
- **OpenAI-compatible**: following the widely copied OpenAI chat completions API format, which most providers and
  open-source servers (vLLM, llama.cpp) support.
- **Infrastructure as code, Terraform**: defining cloud resources in version-controlled files, so they can be
  recreated or ported (Section 10).
- **Managed databases, queues**: cloud services such as RDS, Cloud SQL, SQS, or Pub/Sub. Standard engines (Postgres,
  Kafka-compatible) are easier to move than proprietary ones.

**Core ideas.**
- **Model lock-in.**
  - Prompts tuned to one model.
  - Provider-only features (such as specific tool-calling formats).
  - Fine-tunes that exist only inside a provider.

  Mitigate with evals that score alternatives, a gateway that normalizes APIs, and keeping fine-tuning datasets so you
  can retrain on an open model.
- **Cloud lock-in.** Proprietary services (DynamoDB, BigQuery, Firestore) are productive but costly to leave. Data
  gravity and egress fees make moving large datasets expensive. Use standard engines where the difference is small.
- **Credits lock-in.** Credits pull startups into one cloud. That's fine, but plan the bill after credits expire.
- **Contract terms.** Check data-use terms (is your data used for training?), retention, deprecation notice periods, and
  rate limits. Enterprise customers will ask.
- **Accept lock-in deliberately.** A proprietary service that saves months is worth it if the exit cost is known.

**Example: the deprecation notice.** A provider announced the model a startup's product was built on would be retired
in 90 days. The startup had a 400-example eval suite and a gateway, so it tested three replacement models in two days,
adjusted prompts for the best one, and switched with a percentage rollout in a week. A competitor without evals spent
two months fixing regressions that customers reported.

**Senior / FAANG best practice.** Own your data, eval suite, API boundary, and infrastructure as code. Rent everything
else, accept lock-in deliberately where it buys speed, and know the exit cost. Read data-use and deprecation terms, and
test at least one alternative model against your evals every quarter.

---

## Lecture 287 — Lab: deploy AI infra on low budget

**Goal:** serve a small open LLM with an OpenAI-compatible API on a cheap CPU-only VM (or your laptop), protected by an
API key and TLS, with metrics, then measure throughput and compute cost per million output tokens.

**What you're building:** a Docker Compose stack with llama.cpp's server running a 4-bit Qwen2.5 0.5B model, Caddy in
front for HTTPS, and a load-test script.

```mermaid
flowchart LR
  CLIENT["Client<br/>OpenAI-compatible request"] -->|"HTTPS"| CADDY["Caddy<br/>automatic TLS"]
  CADDY --> LLAMA["llama.cpp server<br/>Qwen2.5-0.5B Q4_K_M, API key"]
  LLAMA --> METRICS["/metrics<br/>tokens/s, requests"]
  LOAD["loadtest.py<br/>concurrent requests"] --> CADDY
```

**How to read the diagram:** clients send OpenAI-style requests over HTTPS to Caddy, a web server that gets TLS
certificates automatically and forwards requests to the llama.cpp server. The model server runs a 4-bit quantized
Qwen2.5 0.5B model on CPU, requires an API key, and exposes Prometheus metrics. A load-test script sends concurrent
requests through Caddy to measure throughput.

The terms, briefly:
- **llama.cpp server**: a C++ LLM inference server that runs quantized GGUF models efficiently on CPUs and GPUs, with an
  OpenAI-compatible API.
- **Q4_K_M**: a 4-bit quantization format of llama.cpp (Section 35), which makes the 0.5B model about 400 MB.
- **Caddy, automatic TLS**: Caddy gets and renews HTTPS certificates from Let's Encrypt automatically when it has a
  public domain name, and uses a local certificate for `localhost`.
- **/metrics**: the Prometheus endpoint llama.cpp exposes with `--metrics`.

**Prerequisites:** Docker with Compose, about 2 GB of free RAM. For the public version, a small VM (2–4 vCPUs, any
cloud, roughly $10–40 a month) and a domain name pointing to it.

### Step 1 — Compose stack

```bash
mkdir lowbudget && cd lowbudget
export LLM_API_KEY=$(openssl rand -hex 16); echo "LLM_API_KEY=$LLM_API_KEY" > .env
cat > docker-compose.yml <<'EOF'
services:
  llm:
    image: ghcr.io/ggml-org/llama.cpp:server
    command: >
      -hf Qwen/Qwen2.5-0.5B-Instruct-GGUF:Q4_K_M
      --host 0.0.0.0 --port 8080 --ctx-size 8192 --parallel 4
      --api-key ${LLM_API_KEY} --metrics
    volumes: ["models:/root/.cache/llama.cpp"]
    restart: unless-stopped
  caddy:
    image: caddy:2
    ports: ["443:443", "80:80"]
    command: caddy reverse-proxy --from ${DOMAIN:-localhost} --to llm:8080
    volumes: ["caddy:/data"]
    restart: unless-stopped
volumes: {models: {}, caddy: {}}
EOF
docker compose up -d && docker compose logs -f llm    # wait for "server is listening", then Ctrl-C
```

In the file, `-hf` downloads the Q4_K_M file from the Hugging Face repository on first start and caches it in a volume.
`--parallel 4` serves four requests at once, sharing the 8,192-token context across them. `--api-key` rejects requests
without the key, and `--metrics` enables `/metrics`. Caddy's `reverse-proxy` command forwards HTTPS traffic for
`DOMAIN` (or `localhost`) to the model server, and keeps its certificates in a volume. Only Caddy publishes ports, so
the model server isn't reachable directly.

### Step 2 — Call it

```bash
curl -sk https://localhost/v1/chat/completions -H "Authorization: Bearer $LLM_API_KEY" \
  -H 'Content-Type: application/json' \
  -d '{"messages":[{"role":"user","content":"Give three tips to cut cloud costs."}],"max_tokens":120}' \
  | python3 -m json.tool | head -30
curl -sk -o /dev/null -w "%{http_code}\n" https://localhost/v1/chat/completions \
  -H 'Content-Type: application/json' -d '{"messages":[{"role":"user","content":"hi"}]}'   # no key
curl -sk https://localhost/metrics -H "Authorization: Bearer $LLM_API_KEY" | grep -E "tokens_predicted_total|requests_processing"
```

In the commands, `-k` accepts Caddy's local certificate for `localhost` (not needed with a real domain). The first call
returns a chat completion with a `usage` block. The second shows the API key is enforced. The third reads llama.cpp's
Prometheus counters.

### Step 3 — Load test and cost per million tokens

```python
# loadtest.py: python3 loadtest.py <concurrency> <requests> <vm_dollars_per_hour>
import json, os, ssl, sys, time, urllib.request
from concurrent.futures import ThreadPoolExecutor

URL, KEY = os.environ.get("URL", "https://localhost/v1/chat/completions"), os.environ["LLM_API_KEY"]
CTX = ssl._create_unverified_context()          # local certificate only; use the default context with a real domain

def one(i):
    body = json.dumps({"messages": [{"role": "user", "content": f"Write a 100-word product description #{i}."}],
                       "max_tokens": 150}).encode()
    req = urllib.request.Request(URL, body, {"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"})
    t = time.time()
    with urllib.request.urlopen(req, context=CTX, timeout=300) as r:
        usage = json.load(r)["usage"]
    return usage["completion_tokens"], time.time() - t

conc, n, price = int(sys.argv[1]), int(sys.argv[2]), float(sys.argv[3])
start = time.time()
with ThreadPoolExecutor(conc) as pool:
    results = list(pool.map(one, range(n)))
wall = time.time() - start
tokens = sum(t for t, _ in results)
lat = sorted(l for _, l in results)
tps = tokens / wall
print(f"{n} requests, concurrency {conc}: {tokens} output tokens in {wall:.1f}s = {tps:.1f} tokens/s")
print(f"latency p50 {lat[len(lat)//2]:.1f}s  p95 {lat[int(len(lat)*0.95)-1]:.1f}s")
print(f"cost per 1M output tokens at ${price}/h: ${price / (tps * 3600) * 1e6:.2f}")
```

```bash
python3 loadtest.py 1 8 0.05 && python3 loadtest.py 4 24 0.05
```

In the script, each worker sends a chat request and records the output tokens from `usage` and the latency. Throughput
is total output tokens divided by wall-clock time, and cost per million tokens is the VM's hourly price divided by
tokens per hour. Running at concurrency 1 and then 4 shows how batching parallel requests raises throughput.

**Expected results:**
- The chat call returns a short answer with a `usage` block. The call without a key returns `401`.
- `/metrics` shows `llamacpp:tokens_predicted_total` increasing after requests.
- On a 4-vCPU machine, expect roughly 20–60 output tokens/s at concurrency 1, and noticeably more in total at
  concurrency 4, while each request's latency rises.
- At $0.05 an hour and 80 tokens/s, cost is about $0.17 per million output tokens. That's cheap, but compare quality:
  a 0.5B model is fine for classification, extraction, and routing, and not for hard reasoning.
- With a real `DOMAIN` set in `.env`, Caddy serves a trusted Let's Encrypt certificate and `-k` is no longer needed.

---

## Assessment — Advise a startup CTO on a limited AI budget

**Scenario.** A seed-stage startup has $3 million in the bank, $180,000 a month of non-AI spending, and a board-approved
AI serving budget of $25,000 a month. Its document assistant handles 2 million requests in month 1 (1,500 input and
300 output tokens each), growing 25% a month. The CTO asks: use a frontier API for everything, a small-model API, a
router mixing both with prompt caching, or self-host an 8B model on H100s?

**Task.**

```bash
python3 exercises/s41_startup_budget.py
```

**Formulas.**
- API cost per request = input tokens × input price + output tokens × output price.
- Router = 80% × small cost + 20% × frontier cost, with 60% of frontier input tokens cached at a 90% discount.
- Self-host = max(2, GPUs needed for output tokens/s at 2,500 tokens/s × 40% utilization) × $2.50 × 730 hours + a
  quarter of an engineer ($4,167 a month).
- Cash after month m = $3M − Σ(non-AI spend + AI spend).

**Expected output:**

| Option | Cost per request | Month 1 | Month 12 | Over budget from | 12-month AI spend | Cash after 12 months |
|---|---|---|---|---|---|---|
| Frontier API | $0.009000 | $18,000 | $209,548 | Month 3 | $975,738 | −$135,738 (runs out in month 12) |
| Small-model API | $0.000405 | $810 | $9,430 | Never | $43,908 | $796,092 |
| Router + cache | $0.001638 | $3,276 | $38,138 | Month 11 | $177,584 | $662,416 |
| Self-host 8B | — | $7,817 | $9,642 | Never | $97,450 | $742,550 |

Self-hosting beats the small-model API only above 28.3 million requests a month, which this plan doesn't reach within
12 months. All 8 checks print `PASS`.

**What a strong answer explains:**
- **Frontier-only doesn't survive the year.** Its cost grows with traffic at 22 times the small model's price, and the
  company runs out of cash in month 12 without new funding.
- **The router is the default recommendation**, if evals show the small model handles the easy 80% well. It keeps
  frontier quality where it's needed, at about a fifth of the cost.
- **Even the router breaks the budget in month 11.** Traffic grows 11.6 times in a year, so the AI budget should be set
  as a share of revenue (a gross margin target), not a fixed number. The plan should include raising the small model's
  share or moving it to self-hosting as volume grows.
- **Self-hosting isn't cheaper yet.** Two GPUs for availability and a quarter of an engineer cost more than the
  small-model API until about 28 million requests a month. Choose it earlier only for privacy, latency, or
  customization.
- **Keep the exits open.** A gateway and an eval suite let the startup move any path between options as prices and
  traffic change.
- **Prices are assumptions.** Recompute with current prices, measured token counts, and measured self-hosted
  throughput.

---

## FAANG deep-dive notes

**How big tech does it.** Big tech companies aren't startups, but they work with thousands of them through cloud
startup programs, and their own new products often start lean. They prototype internally on shared model APIs and
platforms, measure cost per query before launch, and move high-volume paths to cheaper, distilled models once usage is
proven. Their cloud businesses offer startups credits, startup-focused solution architects, and marketplaces, precisely
because early infrastructure choices tend to stick. Their advice to startups is consistent: start managed, measure unit
economics, and design for portability where the exit cost would be high.

**Staff review questions.**
- What's the runway, and what share of burn is AI serving now and in 12 months?
- What's the cost per request and gross margin per customer segment?
- Which requests could go to a cheaper model, cache, or batch API?
- At what volume does self-hosting pay off, and what else (privacy, latency) would justify it earlier?
- If the main model provider doubled prices or retired the model, how long would switching take?
- What happens to the bill when credits expire?

**Interview question.** "You're the first infrastructure hire at a 10-person AI startup. What do you do in your first 90
days?"

**Typical system-design prompt:** *Design the AI infrastructure for a startup's AI meeting-notes product, from 1,000 to
100,000 users, on a $30,000-a-month budget.*

**1. Clarify first:** Revenue per user? Meeting length and transcription vs summarization split? Latency needs (live
vs after the meeting)? Data residency and privacy promises? Expected growth?

**2. Back-of-envelope sizing:**
- At 100,000 users × 20 meetings a month × 45 minutes: 90 million audio minutes a month. At $0.006 a minute for hosted
  speech-to-text, that's $540,000 a month. Way over budget, so transcription must be self-hosted or run on device.
- Self-hosted Whisper-class models on GPUs process audio hundreds of times faster than real time. 90 million minutes at
  300 times real time is 5,000 GPU-hours a month, about $12,500 at $2.50 an hour.
- Summaries: 2 million meetings × (8,000 input + 500 output tokens) on a small model at $0.15 and $0.60 per million
  tokens: about $3,000 a month.
- Live transcription at 100,000 users is the expensive part, so make it optional, or do it on device.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Transcription | Hosted API | Self-hosted on GPUs | API early, self-host past break-even |
| Summarization model | Frontier | Small or routed | Small model with eval-checked quality |
| Compute | Hyperscaler on-demand | Neocloud or spot | Neocloud or spot for batch audio |
| Platform | Kubernetes | Managed containers | Managed until the team knows Kubernetes |
| Provider dependence | One provider | Gateway with fallback | Gateway from day 1 |

**4. Follow-up questions with crisp answers:**
- *Credits run out next month. What changes?* Recompute the bill at list prices, move batch work to spot or a
  neocloud, and commit only to proven base load.
- *An enterprise customer wants data to stay in the EU.* Use EU regions or EU-hosted providers, self-host
  transcription there, and document data flows.
- *The frontier model provider raises prices by 50%.* Run the evals on alternatives, shift the router's share, and
  switch through the gateway.
- *When do you adopt Kubernetes?* When you run several self-hosted models on GPU nodes and need scheduling and
  autoscaling, and someone on the team can operate it.

**Debug this (common onsite question):** "A startup's AI bill tripled in one week, with flat user numbers."
1. Gateway logs show input tokens per request rose from 2,000 to 9,000.
2. A release had changed retrieval to return 20 chunks instead of 5, and added the full chat history to every call.
3. Quality evals improved slightly, but no one checked cost per request in review.
4. Fix: cap retrieved chunks and summarize history, add cost per request to the eval report in CI, and alert when the
   daily cost per request rises by more than 20%.

The lesson: treat cost per request as a tested metric, like latency and quality.

**5. What separates senior from staff answers:** a senior engineer picks a sensible cheap stack. A staff engineer ties
infrastructure decisions to runway and gross margin, computes break-even points for self-hosting, plans for credits
expiring and providers changing, keeps exits open with a gateway and evals, and sets triggers for each scaling step.

**Red flags:**
- Building a platform before product-market fit.
- No cost per request tracking.
- Frontier model for every request without evals of cheaper options.
- Large GPU commitments for unproven demand.
- Single-provider dependence without fallback or evals.
- Ignoring credit expiry.
- A fixed AI budget that doesn't scale with revenue.

---

## Quiz

<details><summary>1. Why should startups usually buy managed services before building infrastructure?</summary>
Their scarcest resources are time and runway. Managed services get to product-market fit faster, and building makes sense
only when it clearly lowers cost or customers require it.
</details>

<details><summary>2. When does self-hosting an open model beat a hosted API?</summary>
Above the break-even volume where fixed GPU cost (with at least two replicas) plus engineering time is less than the per-token
fees, or earlier when privacy, latency, or customization require it.
</details>

<details><summary>3. Name three ways to cut LLM serving cost with little quality loss.</summary>
Route easy requests to smaller models, cache repeated answers and prompt prefixes, shrink prompts, and use batch APIs for
offline work.
</details>

<details><summary>4. Why are spot GPUs good for fine-tuning but risky for serving?</summary>
Training can checkpoint and resume after an interruption. Serving needs capacity at all times, so spot needs on-demand
fallback or enough spare replicas.
</details>

<details><summary>5. What should a startup own to avoid harmful lock-in?</summary>
Its data (logs, labels, fine-tuning sets), an eval suite, the API boundary (a gateway), and infrastructure as code.
</details>

<details><summary>6. Why should an AI budget be tied to revenue rather than fixed?</summary>
Serving cost grows with traffic. A fixed number is broken by growth, while a gross margin target tells you when cost per
request must fall.
</details>

<details><summary>7. What's gross margin if a $20-per-month user costs $5.40 to serve?</summary>
1 − 5.40 / 20 = 73%, before other costs.
</details>

## Failure modes
- Spending months on infrastructure before customers.
- No logging of tokens and cost per request.
- Frontier models used for every request.
- Committing to GPUs before demand is proven.
- One provider with no fallback or evals.
- Credits expiring with no plan for the full bill.
- Runaway agent loops without budgets.
- Data-use and deprecation terms unread until an enterprise deal.

## Checklist
- [ ] Runway, traffic range, and gross margin target are written down
- [ ] Cost per request is logged and reviewed per customer
- [ ] Routing, caching, prompt trimming, and batch APIs are used where evals allow
- [ ] GPU choices match workloads: APIs or serverless for spikes, spot for training, commitments only for base load
- [ ] A gateway and an eval suite make switching models a configuration change
- [ ] Spend budgets, rate limits, and kill switches are in place
- [ ] You deployed a model API on a cheap VM and measured its cost per million tokens
- [ ] You ran the assessment and can defend the recommendation to a CTO
