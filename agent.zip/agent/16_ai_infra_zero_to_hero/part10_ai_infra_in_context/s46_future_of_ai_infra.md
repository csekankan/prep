# Section 46 — Future of AI Infrastructure

> Lectures 316–322 • Assessments: quiz
> **After this section you can:** explain where AI chips are heading (GPUs, TPUs, custom accelerators, NPUs, lower
> precision, rack-scale systems), describe how clouds are changing for AI, judge realistic roles for quantum computing
> and prepare for post-quantum cryptography, evaluate software trends such as Rust, Mojo, and compilers, measure and
> reduce AI's energy and carbon, plan for regulation's effect on infrastructure, and design infrastructure that adapts
> as all of these change.
>
> Builds on: [Section 7](../part02_data_gpus_training/s07_gpu_hardware.md) (GPUs),
> [Section 12](../part03_mlops_cicd_cost/s12_cost_optimization.md) (cost),
> [Section 36](../part08_scale_mlops_optimization/s36_advanced_optimization.md) (precision and compilers),
> [Section 42](s42_enterprises.md) (enterprise strategy), and [Section 45](s45_case_studies.md) (case studies).
>
> **A note on dates.** This section describes the state of the field as of late 2026, including products announced
> but not yet widely available. Specific chips, prices, and rules will change. The lasting lessons are the trends and
> the design principles.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 316 | Trends in AI chips (GPUs, TPUs, NPUs) | Lower precision, more HBM, rack-scale systems, liquid cooling, and more custom chips |
| 317 | Cloud evolution for AI | Neoclouds, AI factories limited by power, model APIs as a layer, and sovereign clouds |
| 318 | AI + quantum computing infrastructure | Quantum won't train LLMs soon. Hybrid workflows are research, and post-quantum crypto is urgent |
| 319 | Software trends in AI infra (Rust, Mojo) | Rust for safe, fast infrastructure, new kernel languages and compilers, and portable runtimes |
| 320 | Green AI and sustainable infrastructure | Measure energy and carbon, choose regions and times wisely, and make models efficient |
| 321 | Global AI regulation impact on infra | Residency, export controls, documentation, and compute thresholds shape where and how you build |
| 322 | Lab: design future-proof AI infra | Abstractions, short commitments, power headroom, and measured efficiency |

```mermaid
flowchart LR
  CHIP2["Chips<br/>precision, HBM, racks"] --> FP["Future-proof design"]
  CLOUD3["Cloud models<br/>neoclouds, APIs, sovereign"] --> FP
  SW2["Software<br/>compilers, Rust, portable runtimes"] --> FP
  ENERGY["Energy and carbon<br/>power is the constraint"] --> FP
  REG3["Regulation<br/>residency, export controls"] --> FP
  QC["Quantum<br/>post-quantum crypto now"] --> FP
```

**How to read it:** six forces shape the future of AI infrastructure, and a future-proof design must handle all of
them: chips (lower precision, more memory, rack-scale systems), cloud models (neoclouds, model APIs, sovereign clouds),
software (compilers, Rust, portable runtimes), energy and carbon (power is becoming the main limit), regulation (data
residency, export controls), and quantum computing (where the urgent work today is post-quantum cryptography).

**Terms in this diagram.**
- **Precision, HBM, racks**: number formats with fewer bits (FP8, FP4), high-bandwidth memory stacked next to the chip,
  and systems designed as whole racks rather than single servers (Lecture 316).
- **Neoclouds, sovereign**: GPU-focused cloud providers, and clouds operated under a country's or region's legal control
  (Lecture 317).
- **Portable runtimes**: inference engines and formats that run models on many kinds of hardware (Lecture 319).
- **Power is the constraint**: the availability of electricity, more than chips, increasingly limits where and how fast
  AI capacity can grow (Lecture 320).
- **Export controls**: government rules restricting which chips can be sold to which countries (Lecture 321).
- **Post-quantum crypto**: encryption designed to resist future quantum computers (Lecture 318).

---

## Lecture 316 — Trends in AI chips (GPUs, TPUs, NPUs)

**Why it matters.** Chip roadmaps decide how much compute a dollar and a watt buy, what precision models use, and what
data centers must look like. Infrastructure plans made today must anticipate hardware arriving in one to three years.

**In plain words.** It's like planning roads while cars keep changing. Cars are getting heavier and faster, and some
need charging stations, so roads, bridges, and power must be built for the cars that are coming, not just today's.

**Architecture: the AI chip landscape.**

```mermaid
flowchart TB
  subgraph DC4["Data center accelerators"]
    NV["NVIDIA GPUs<br/>Hopper, Blackwell, Rubin"]
    AMD2["AMD Instinct<br/>MI300 series, MI350 series"]
    CUST["Custom chips<br/>Google TPU, AWS Trainium, Microsoft Maia, Meta MTIA"]
    ALT["Alternative designs<br/>wafer-scale, SRAM-heavy inference chips"]
  end
  subgraph EDGE4["Devices"]
    NPU["NPUs<br/>phones, laptops, cars"]
  end
  TR1["Trends: FP8 and FP4, more HBM,<br/>rack-scale NVLink domains, liquid cooling"] -.-> DC4
  TR2["Trends: on-device LLMs,<br/>tens of TOPS at a few watts"] -.-> EDGE4
```

**How to read it:** data center accelerators come in four groups: NVIDIA GPUs (the Hopper, Blackwell, and announced
Rubin generations), AMD Instinct GPUs, custom chips built by cloud and internet companies, and alternative designs such
as wafer-scale chips and inference chips built around on-chip SRAM. On devices, NPUs in phones, laptops, and cars run
models locally. Data center trends are lower precision, more HBM, larger NVLink domains spanning whole racks, and
liquid cooling. Device trends are on-device language models and tens of TOPS at a few watts.

**Terms in this diagram.**
- **Hopper, Blackwell, Rubin**: NVIDIA GPU generations: H100 and H200 (Hopper), B200 and GB200 (Blackwell), and Rubin,
  announced for 2026.
- **MI300 series, MI350 series**: AMD's data center GPUs, notable for large HBM capacity (192 GB on MI300X, 288 GB on
  MI350-series parts).
- **Google TPU, AWS Trainium, Microsoft Maia, Meta MTIA**: accelerators designed by those companies for their own
  workloads and clouds.
- **Wafer-scale, SRAM-heavy**: Cerebras builds one chip from a whole silicon wafer. Others (such as Groq) keep model
  weights in fast on-chip SRAM for very low-latency inference.
- **NPUs**: neural processing units, low-power AI accelerators in phones (Apple Neural Engine, Qualcomm Hexagon) and
  laptops (Intel, AMD, and Qualcomm chips with 40+ TOPS).
- **FP8 and FP4**: 8-bit and 4-bit floating-point formats, including the block-scaled MXFP4 and NVFP4 (Section 35).
- **Rack-scale NVLink domains**: systems such as GB200 NVL72, where 72 GPUs in one rack share an NVLink network and act
  like one large GPU for communication.
- **TOPS**: trillions of operations per second, usually for INT8.

**Core ideas.**
- **Precision keeps dropping.** Training moved from FP32 to BF16 to FP8, and inference to FP8 and FP4. Each step roughly
  doubles throughput per chip, if models tolerate it (Sections 35 and 36).
- **Memory is the bottleneck.** LLM inference is limited by memory bandwidth and capacity, so HBM size and bandwidth grow
  every generation, and the price of HBM is a large part of a chip's cost.
- **The rack is the computer.** Larger NVLink domains reduce communication costs for tensor and expert parallelism. They
  draw 100 kW or more per rack, which requires liquid cooling and changes data-center design.
- **Custom chips grow.** Hyperscalers design chips for their highest-volume workloads, especially inference. GPUs stay
  dominant where flexibility and the CUDA ecosystem matter.
- **Edge AI grows.** NPUs make small language and vision models run locally on phones and laptops, moving some inference
  off data centers (Section 23).
- **Plan for change.** Hardware generations arrive about every one to two years. Avoid locking software to one chip
  where you can.

**Example: the cooling that wasn't ready.** A company ordered rack-scale Blackwell systems for an existing air-cooled
data hall designed for about 15 kW per rack. The racks needed over 100 kW each and liquid cooling. Deployment was delayed
by nine months while the facility installed coolant distribution units and new power feeds. The lesson was to plan
facilities for the generation after next.

**Senior / FAANG best practice.** Track chip roadmaps one to three years out, plan facilities for liquid cooling and
100 kW+ racks, adopt lower precision where quality allows, weigh memory capacity and bandwidth as heavily as FLOPs, keep
software portable across vendors where practical, and evaluate custom chips for high-volume, stable workloads.

---

## Lecture 317 — Cloud evolution for AI

**Why it matters.** The cloud market for AI is changing quickly: GPU-focused providers, model APIs, sovereign clouds,
and huge new data center campuses limited by power. Where and how you buy AI compute in three years may look very
different from today.

**In plain words.** It's like the way electricity markets changed. Instead of every factory running its own
generator, there are utilities, specialized suppliers, local grids, and contracts for every need, and the best choice
depends on how much you use and where.

**Architecture: layers of the AI cloud.**

```mermaid
flowchart TB
  APPS2["Applications and agents"] --> MAAS["Model APIs<br/>pay per token"]
  APPS2 --> PLATF["Managed ML platforms<br/>SageMaker, Vertex AI, Azure AI Foundry"]
  MAAS --> GPUAAS["GPU capacity<br/>hyperscalers, neoclouds, marketplaces"]
  PLATF --> GPUAAS
  GPUAAS --> FACT["AI factories<br/>gigawatt campuses, liquid cooling"]
  FACT --> POWER2["Power<br/>grid, on-site generation, nuclear deals"]
  SOV["Sovereign clouds<br/>local control and data residency"] -.-> GPUAAS
```

**How to read it:** applications and agents use model APIs, paying per token, or managed ML platforms. Both run on GPU
capacity from hyperscalers, neoclouds, and marketplaces. That capacity sits in AI factories, very large data center
campuses with liquid cooling, which depend on power from the grid, on-site generation, or long-term deals such as
contracts with nuclear plants. Sovereign clouds offer capacity under local legal control and data residency.

**Terms in this diagram.**
- **Model APIs**: hosted models priced per token, from model labs and cloud providers (Section 41).
- **SageMaker, Vertex AI, Azure AI Foundry**: AWS, Google Cloud, and Microsoft's managed platforms for building,
  training, and deploying models.
- **Marketplaces**: services that sell GPU capacity from many providers, often for short terms.
- **AI factories**: a term (popularized by NVIDIA) for data centers built specifically to train and serve AI at scale.
- **Gigawatt campuses**: data center sites drawing a gigawatt or more, roughly the output of a large power plant.
- **Nuclear deals**: agreements by cloud companies to buy power from existing or planned nuclear plants, including
  small modular reactors.

**Core ideas.**
- **Power decides location.** New AI capacity goes where power can be connected quickly. Grid connection waits of
  several years in some regions push builders to new locations and on-site generation.
- **Specialization.** Neoclouds compete on GPU price, availability, and simplicity. Hyperscalers compete on breadth,
  integration, compliance, and custom chips.
- **Model APIs as a layer.** Many companies consume intelligence as an API and never manage GPUs. Gateways that route
  across providers become standard (Section 41).
- **Inference architecture evolves.** Disaggregated serving (separate prefill and decode pools), KV cache offloading
  across memory tiers, and serving across regions for capacity and latency (Section 15).
- **Sovereign clouds.** Governments and regulated industries want AI capacity under local legal control, driving
  regional and national AI clouds (Lecture 321).
- **Contracts change.** Longer reservations for scarce capacity, flexible terms for inference, and capacity bought in
  megawatts, not GPUs.

**Example: buying megawatts.** A model company negotiating capacity for 2027 found that providers quoted in megawatts of
power with a matching GPU generation, not in GPU counts. Its plan had to translate model training and serving targets
into megawatts, including cooling and networking, and to pick sites by power availability and grid carbon intensity
as much as by price.

**Senior / FAANG best practice.** Plan capacity in power as well as GPUs, keep a mix of hyperscaler, neocloud, and API
options behind a gateway, follow serving architecture advances such as prefill and decode disaggregation, and account
for sovereign requirements where you operate. Revisit the mix every year as prices and offerings change.

---

## Lecture 318 — AI + quantum computing infrastructure

**Why it matters.** Quantum computing generates a lot of hype around AI. Infrastructure engineers need a realistic
view: what quantum computers can and can't do soon, how hybrid quantum and classical systems are built, and the one
quantum issue that needs action now, which is cryptography.

**In plain words.** A quantum computer isn't a faster laptop. It's more like a very special tool that may one day be
excellent at certain chemistry and math problems. Meanwhile, the locks on our data need upgrading before thieves get
that tool.

**Architecture: hybrid quantum-classical computing.**

```mermaid
flowchart LR
  HPC2["Classical HPC + GPUs<br/>most of the work"] <-->|"tight loop"| QPU["Quantum processor<br/>QPU, small and noisy"]
  HPC2 --> SIMQ["Quantum simulation on GPUs<br/>cuQuantum, CUDA-Q"]
  AIQ["AI for quantum<br/>error decoding, calibration"] --> QPU
  PQC["Post-quantum cryptography<br/>ML-KEM, ML-DSA"] -.->|"protects"| DATA6["Data, weights, keys today"]
```

**How to read it:** in hybrid systems, classical supercomputers and GPUs do most of the work, exchanging results with a
small, noisy quantum processor in a tight loop. GPUs also simulate quantum circuits, using tools such as cuQuantum and
CUDA-Q. AI helps quantum computers by decoding errors and calibrating devices. Separately, post-quantum cryptography
algorithms such as ML-KEM and ML-DSA protect data, model weights, and keys today against future quantum attacks.

**Terms in this diagram.**
- **Classical HPC**: high-performance computing, ordinary (non-quantum) supercomputers built from CPUs and GPUs.
- **QPU**: quantum processing unit, the quantum chip. Today's devices have limited numbers of qubits and high error
  rates, so they're called noisy.
- **Tight loop**: hybrid algorithms (such as variational algorithms) alternate between quantum circuit runs and
  classical optimization.
- **cuQuantum, CUDA-Q**: NVIDIA's libraries for simulating quantum circuits on GPUs, and its platform for programming
  hybrid quantum-classical applications.
- **Error decoding, calibration**: working out which errors happened from measurements so they can be corrected, and
  tuning the device's control signals. Machine learning is used for both, for example Google DeepMind's AlphaQubit
  decoder.
- **ML-KEM, ML-DSA**: post-quantum algorithms standardized by NIST in 2024 (FIPS 203 for key exchange and FIPS 204 for
  signatures), designed to resist attacks by quantum computers.

**Core ideas.**
- **Realistic expectations.** Quantum computers won't train or serve large neural networks in the foreseeable future.
  Their likely early value is in simulating molecules and materials, and some optimization and sampling problems,
  once error-corrected machines exist.
- **Error correction progress.** Experiments such as Google's 2024 Willow chip showed errors decreasing as more qubits
  are used for error correction, an important milestone, but useful fault-tolerant machines need far more qubits.
- **Infrastructure today.** Quantum processors are accessed through cloud services or installed next to
  supercomputers. GPU clusters simulate circuits and run the classical half of hybrid algorithms.
- **AI helps quantum.** Machine learning for decoding, calibration, and designing circuits is one of the most active
  areas where AI and quantum meet.
- **Post-quantum migration is urgent.** Data encrypted today could be recorded and decrypted later ("harvest now,
  decrypt later"). Model weights, training data, and long-lived secrets need post-quantum or hybrid key exchange.
  Inventory cryptography and plan the migration now.

**Example: the crypto inventory.** A bank's AI platform team, asked about quantum readiness, found that quantum
computing wouldn't change their AI workloads for many years. But their model weights and customer data moved over TLS
and VPN links between data centers using classical key exchange. They inventoried every protocol and key, enabled hybrid
post-quantum key exchange in TLS where their libraries supported it, and put the rest on a migration plan.

**Senior / FAANG best practice.** Don't plan AI capacity around quantum computing. Track error-correction milestones,
and use GPU-based simulation for research. Start post-quantum cryptography migration now: inventory cryptography,
prioritize long-lived sensitive data such as model weights, and adopt hybrid key exchange as libraries support it.

---

## Lecture 319 — Software trends in AI infra (Rust, Mojo)

**Why it matters.** AI infrastructure software is moving beyond pure Python and CUDA: Rust for safe, fast systems,
new languages such as Mojo for performance, compilers that target many chips, and specialized serving engines.
Choosing the right tools affects speed, safety, and portability.

**In plain words.** It's like a kitchen upgrading its knives and appliances. The recipes (Python and PyTorch) stay
familiar, but the tools underneath get sharper and safer, and some work for any stove you plug them into.

**Architecture: the AI software stack, today and emerging.**

```mermaid
flowchart TB
  PY["Python<br/>research and orchestration"] --> FWK["Frameworks<br/>PyTorch, JAX"]
  FWK --> COMP["Compilers<br/>torch.compile, XLA, MLIR, Triton"]
  COMP --> KERN["Kernels<br/>CUDA, ROCm, Triton, Mojo"]
  KERN --> HW5["Hardware<br/>GPUs, TPUs, NPUs"]
  RUST["Rust components<br/>tokenizers, safetensors, data tools, proxies"] -.-> PY
  SERVE5["Serving engines<br/>vLLM, SGLang, TensorRT-LLM"] --> COMP
  ORCH5["Orchestration<br/>Kubernetes, DRA, Ray"] --> SERVE5
```

**How to read it:** Python stays the language for research and orchestration, calling frameworks such as PyTorch and
JAX. Compilers such as torch.compile, XLA, MLIR, and Triton turn models into kernels, written in CUDA, ROCm, Triton, or
Mojo, which run on GPUs, TPUs, and NPUs. Rust provides fast, safe components that Python uses, such as tokenizers,
safetensors, data tools, and proxies. Serving engines such as vLLM, SGLang, and TensorRT-LLM build on compilers and
kernels, and orchestration with Kubernetes, Dynamic Resource Allocation, and Ray runs everything.

**Terms in this diagram.**
- **MLIR**: Multi-Level Intermediate Representation, a compiler framework (from the LLVM project) used to build
  compilers for many accelerators.
- **ROCm**: AMD's GPU software platform, its equivalent of CUDA.
- **Mojo**: a programming language from Modular with Python-like syntax, designed for high-performance code on CPUs
  and GPUs, used in Modular's MAX inference platform.
- **Rust**: a systems language that prevents whole classes of memory bugs at compile time, while being as fast as C++.
- **Tokenizers, safetensors**: Hugging Face's tokenization library and safe model file format, both written in Rust
  with Python bindings (Section 39).
- **SGLang, TensorRT-LLM**: an open-source LLM serving engine with fast structured generation and prefix caching, and
  NVIDIA's optimized LLM inference library.
- **DRA**: Dynamic Resource Allocation, a Kubernetes API for requesting devices such as GPUs with detailed attributes
  (for example, a MIG slice or GPUs on the same NVLink domain), replacing simple device counts.

**Core ideas.**
- **Rust in infrastructure.** Memory safety without garbage collection pauses suits data loaders, tokenizers, proxies,
  vector databases (Qdrant), and dataframes (Polars). Expect more Python packages with Rust cores.
- **Kernel languages multiply.** Triton made GPU kernels accessible from Python. Mojo, CUDA's own Python interfaces, and
  vendor languages compete to make fast kernels easier and more portable.
- **Compilers for portability.** Compiling through XLA, MLIR, or torch.compile backends lets the same model run on
  different chips, which matters as hardware diversifies (Lecture 316).
- **Serving engines move fast.** vLLM, SGLang, and TensorRT-LLM add features monthly (speculative decoding,
  disaggregation, new quantization). Pin versions, benchmark upgrades, and keep the OpenAI-compatible API as the stable
  boundary.
- **Kubernetes grows AI-aware.** DRA, gang scheduling with Kueue, and topology-aware placement turn Kubernetes into a
  better AI scheduler (Sections 11 and 40).

**Example: the tokenizer bottleneck.** A team's inference service spent 15% of its CPU time in a pure-Python
preprocessing step that tokenized and cleaned text. Replacing it with the Rust-based Hugging Face tokenizers library
and a small Rust extension for cleaning cut that CPU time by 90% and lowered p99 latency by 8 ms, with no change to the
model.

**Senior / FAANG best practice.** Keep Python for orchestration and research, use Rust-backed libraries for hot paths,
compile models through portable compilers where possible, pin and benchmark serving-engine versions, treat
OpenAI-compatible APIs and ONNX as stable boundaries, and adopt Kubernetes DRA and gang scheduling for GPU workloads.
Evaluate new languages such as Mojo on real kernels before committing.

---

## Lecture 320 — Green AI and sustainable infrastructure

**Why it matters.** AI is driving fast growth in data center electricity use. The IEA estimated data centers used about
415 TWh in 2024, about 1.5% of global electricity, and projected roughly a doubling to about 945 TWh by 2030, with AI the
main driver. Energy is a cost, a capacity limit, and a growing reporting obligation.

**In plain words.** It's like running a fleet of delivery trucks. You save fuel by choosing efficient trucks, planning
shorter routes, driving when roads are clear, and filling the vans properly, and you also need to report how much fuel
you used.

**Architecture: where to reduce AI's footprint.**

```mermaid
flowchart LR
  MODEL6["Model efficiency<br/>distill, quantize, smaller models"] --> ENERGY2["Energy per result"]
  HW6["Hardware efficiency<br/>perf per watt, utilization"] --> ENERGY2
  FAC2["Facility<br/>PUE, liquid cooling, heat reuse"] --> ENERGY2
  ENERGY2 --> CARBON["Carbon<br/>energy x grid intensity"]
  WHERE["Where and when<br/>region, time of day"] --> CARBON
  CARBON --> REPORT2["Measure + report<br/>CodeCarbon, GHG scopes, CSRD"]
  EMB2["Embodied carbon<br/>manufacturing chips, buildings"] --> REPORT2
```

**How to read it:** energy per result falls with model efficiency (distillation, quantization, smaller models),
hardware efficiency (performance per watt and high utilization), and facility efficiency (low PUE, liquid cooling, and
heat reuse). Carbon emissions are energy times the grid's carbon intensity, which depends on where and when work runs.
Emissions are measured and reported, including embodied carbon from manufacturing chips and buildings.

**Terms in this diagram.**
- **Perf per watt, utilization**: useful computation per unit of energy, and the share of time hardware does useful work
  (idle GPUs still draw power).
- **PUE**: power usage effectiveness, total facility energy divided by IT equipment energy. 1.1 to 1.2 is efficient, 1.5
  or more is poor.
- **Heat reuse**: using data center waste heat to warm buildings or water, as some Nordic data centers do.
- **Grid intensity**: grams of CO2 emitted per kWh of electricity, which varies more than 10 times between grids.
- **CodeCarbon, GHG scopes, CSRD**: a Python tool that estimates emissions from compute, the Greenhouse Gas Protocol's
  scopes for direct emissions, purchased energy, and supply chain, and the EU Corporate Sustainability Reporting
  Directive, which requires large companies to report emissions.
- **Embodied carbon**: emissions from manufacturing and transporting hardware and building data centers.

**Core ideas.**
- **Measure first.** Energy per training run and per 1,000 inferences, using power telemetry (DCGM, node power meters) or
  estimates, and carbon using the grid's intensity at the time and place of use.
- **Location and timing.** Running in a low-carbon region can cut emissions by more than ten times (the lab computes
  this). Carbon-aware schedulers shift flexible jobs, such as training and batch inference, to cleaner hours or
  regions.
- **Efficiency compounds.** A model that's 4 times smaller, served at 2 times higher utilization, on hardware with
  1.5 times better performance per watt, uses about 12 times less energy per request.
- **Inference dominates over time.** For popular products, serving energy exceeds training energy, so inference
  efficiency matters most.
- **Water.** Evaporative cooling uses a lot of water. Track water usage effectiveness (WUE), and prefer closed-loop
  liquid cooling in water-stressed regions.
- **Reporting.** Regulations such as the EU's Energy Efficiency Directive (data center reporting) and CSRD make energy
  and emissions disclosure mandatory for many companies.

**Example: the batch job that moved.** A company ran nightly embedding jobs for its search index in a region with a
coal-heavy grid. Moving them to a region with mostly hydro power, and scheduling them for that region's lowest-carbon
hours, cut the job's emissions by about 90%. Latency didn't matter for batch work, and the price was similar.

**Senior / FAANG best practice.** Measure energy and carbon per training run and per 1,000 inferences, prefer
low-carbon regions and carbon-aware scheduling for flexible work, make models efficient (distill, quantize, right-size),
keep utilization high, choose efficient facilities with liquid cooling and low PUE, track water, and report with
standard methods.

---

## Lecture 321 — Global AI regulation impact on infra

**Why it matters.** Regulation increasingly decides where data can be stored, which chips can be bought, what must be
logged and documented, and which models trigger extra obligations. Infrastructure built without considering it may
need expensive redesign, or may be illegal to operate in some markets.

**In plain words.** It's like building cars for many countries. Each has its own safety rules, emissions standards, and
import rules, so you design a platform that can meet them all with local options, instead of a separate car for each.

**Architecture: how regulation reaches infrastructure.**

```mermaid
flowchart TB
  subgraph RULES["Rules"]
    R1["Data protection and residency<br/>GDPR, India DPDP, China PIPL"]
    R2["AI-specific laws<br/>EU AI Act, China generative AI rules"]
    R3["Export controls<br/>advanced chips and model weights"]
    R4["Sector rules<br/>finance, health, public sector"]
  end
  R1 --> I1["Regional deployments<br/>data stays in region"]
  R2 --> I2["Documentation, logging,<br/>compute thresholds, labeling"]
  R3 --> I3["Chip supply and location<br/>of training capacity"]
  R4 --> I4["Validation, audit trails"]
  I1 & I2 & I3 & I4 --> PLAT6["Policy-driven platform<br/>controls as code per region"]
```

**How to read it:** four kinds of rules reach infrastructure. Data protection and residency laws, such as GDPR, India's
DPDP Act, and China's PIPL, require regional deployments where data stays in the region. AI-specific laws, such as the
EU AI Act and China's generative AI rules, require documentation, logging, obligations above compute thresholds, and
content labeling. Export controls on advanced chips (and in some proposals, model weights) affect chip supply and where
training capacity can be located. Sector rules in finance, health, and the public sector require validation and audit
trails. A policy-driven platform implements these as controls in code, per region.

**Terms in this diagram.**
- **GDPR, India DPDP, China PIPL**: the EU's General Data Protection Regulation, India's Digital Personal Data
  Protection Act (2023), and China's Personal Information Protection Law.
- **EU AI Act**: the EU's AI law, phased in from 2025 (Section 42). Some timelines have been under review, so check the
  current dates.
- **China generative AI rules**: interim measures for generative AI services (2023) and later rules, including
  labeling of AI-generated content.
- **Export controls**: rules such as US restrictions on selling advanced AI chips and chip-making equipment to some
  countries, which change frequently.
- **Compute thresholds**: rules triggered by training compute. For example, the EU AI Act presumes general-purpose
  models trained with more than 10²⁵ FLOPs have systemic risk, with extra obligations.
- **Labeling**: marking AI-generated content, for example with watermarks or C2PA provenance metadata.
- **Controls as code per region**: policies enforced automatically by the platform, configured for each region's rules.

**Core ideas.**
- **Residency by design.** Regional data stores, training and serving in region where required, and controls on
  cross-border transfers, including logs and backups.
- **Documentation and logging.** Model inventories, training data summaries, evaluation results, incident reports, and
  logs for high-risk systems, generated by pipelines (Sections 34 and 42).
- **Compute accounting.** Track training FLOPs per model, because thresholds such as 10²⁵ FLOPs trigger obligations.
  Llama 3 405B, at about 3.8 × 10²⁵ FLOPs, is above it (Section 45).
- **Supply and geography.** Export controls affect which chips are available where, and may drive where companies
  locate training clusters. Keep options across vendors and regions.
- **Provenance and labeling.** Content provenance standards such as C2PA, and watermarking, are becoming expected for
  generative outputs in several jurisdictions.
- **Expect change.** Regulations evolve and are sometimes delayed or revised. Assign owners to track them, and build
  configurable controls rather than hard-coded ones.

**Example: the 10²⁵ FLOPs question.** A European company planning a large foundation model computed training compute
early: 6 × 200B parameters × 10T tokens = 1.2 × 10²⁵ FLOPs, just above the EU AI Act's systemic-risk threshold. That
meant extra obligations, including model evaluation, adversarial testing, incident reporting, and cybersecurity
protections. The team budgeted for them from the start, rather than discovering them after training.

**Senior / FAANG best practice.** Build a policy-driven platform with residency, logging, documentation, and labeling
controls configurable per region. Track training compute per model against thresholds, plan chip supply and capacity
location around export controls, assign owners to follow regulatory changes, and keep controls as code so updates
don't require redesign.

---

## Lecture 322 — Lab: design future-proof AI infra

**Goal:** write a three-year AI infrastructure strategy for a mid-size company that stays useful as chips, clouds,
software, energy, and regulation change. It includes an energy and carbon comparison computed with a script, and a
list of decisions designed to be reversible.

**What you're building:** a strategy document `future_proof_plan.md` and a script `future_plan.py`.

```mermaid
flowchart LR
  ASSUME["(1) Assumptions<br/>demand, chips, prices, rules"] --> PRIN["(2) Principles<br/>abstractions, short commitments"]
  PRIN --> ENER["(3) Energy and carbon model<br/>future_plan.py"]
  ENER --> OPTS["(4) Options by horizon<br/>now, 1 year, 3 years"]
  OPTS --> REV["(5) Reversibility review<br/>cost to change each decision"]
  REV --> SIG["(6) Signposts<br/>what would change the plan"]
```

**How to read the diagram:** start by writing down assumptions about demand, chips, prices, and rules. Set principles
such as abstraction layers and short commitments. Run the energy and carbon model. Lay out options for now, one year,
and three years. Review how reversible each decision is (what it would cost to change), and list signposts: the events
that would make you change the plan. **Signposts** are early indicators you watch, such as a chip's real availability
or a regulation's final date.

**Prerequisites:** Python 3, and Sections 41, 42, and 45.

### Step 1 — Assumptions

Write a table `Assumption | Current value | Range | Source | Review date`. Include: inference demand growth (for example
3–5 times a year), training runs per year, GPU price per hour, the next chip generation's arrival and performance per
watt, regulatory dates in your markets, and power availability in your regions.

### Step 2 — Principles

Write five to eight principles. Examples:
- Models behind an OpenAI-compatible gateway.
- Models exported to portable formats where possible.
- Containers and Kubernetes with DRA for scheduling.
- Commitments no longer than the hardware generation.
- Power and cooling headroom for liquid-cooled racks.
- Controls as code per region.
- Energy and carbon measured per workload.

### Step 3 — Energy and carbon model

```python
# future_plan.py
FLOPS_RUN = 1e24                       # a mid-size training run
MFU = 0.40
CHIPS = {"current gen (H100-class)": (989e12, 700), "next gen (B200-class)": (2250e12, 1000)}   # dense BF16 FLOP/s, W
SERVER_OVERHEAD, PUE = 1.3, 1.2        # CPUs, memory, network per GPU watt; facility overhead
GRIDS = {"hydro/nuclear grid": 0.03, "average grid": 0.40, "coal-heavy grid": 0.70}               # kg CO2 per kWh

print(f"{'chip':26} {'GPU-hours':>11} {'MWh':>8} " + " ".join(f"{g:>20}" for g in GRIDS))
results = {}
for name, (peak, watts) in CHIPS.items():
    gpu_h = FLOPS_RUN / (peak * MFU) / 3600
    mwh = gpu_h * watts / 1000 * SERVER_OVERHEAD * PUE / 1000
    results[name] = mwh
    print(f"{name:26} {gpu_h:>11,.0f} {mwh:>8,.0f} " + " ".join(f"{mwh * c:>17,.0f} t" for c in GRIDS.values()))
cur, nxt = results.values()
print(f"next gen uses {1 - nxt / cur:.0%} less energy for the same run")
print(f"region choice changes emissions {GRIDS['coal-heavy grid'] / GRIDS['hydro/nuclear grid']:.0f}x; "
      f"chip generation changes them {cur / nxt:.2f}x")
```

```bash
python3 future_plan.py
```

In the script, GPU-hours for a 10²⁴ FLOP run come from dividing by each chip's achieved FLOPs (peak × MFU). Energy is
GPU-hours × GPU power, scaled by server overhead (CPUs, memory, networking) and the facility's PUE. Emissions are energy
× each grid's carbon intensity, in tonnes of CO2. The chip figures are approximate dense BF16 peaks and power for each
generation.

### Step 4 — Options, reversibility, and signposts

Write options for each horizon (now, 1 year, 3 years). For each major decision, add a row to a table `Decision |
Reversible? | Cost to change | How to keep it reversible`, for example: reserving capacity for 3 years (hard to reverse:
prefer 1-year terms or include upgrade rights), adopting a vendor-specific serving stack (medium: keep the API boundary
standard), and choosing a region (medium: keep infrastructure as code and data replication options). Finish with five
signposts, each with the action it triggers.

**Expected results:**
- `future_plan.py` prints, for the 10²⁴ FLOP run: 702,168 GPU-hours and 767 MWh on the current generation, and 308,642
  GPU-hours and 481 MWh on the next. Emissions are 23, 307, and 537 tonnes of CO2 on the current generation for the
  hydro/nuclear, average, and coal-heavy grids, and 14, 193, and 337 tonnes on the next.
- The next generation uses 37% less energy. The region changes emissions 23 times, against 1.59 times for the chip
  generation. Your plan should conclude that where (and when) flexible work runs matters more for carbon than which chip
  it runs on, while the chip matters more for cost and speed.
- The document has assumptions with ranges and review dates, principles, the model's results, options by horizon, a
  reversibility table, and signposts with actions.

---

## FAANG deep-dive notes

**How big tech does it.** The largest AI companies plan infrastructure years ahead in gigawatts: they sign long-term
power deals (including nuclear and renewables), design custom chips alongside buying GPUs, build liquid-cooled campuses,
and run global platforms with regional controls for residency and regulation. They publish sustainability reports with
energy, carbon, and water figures, and some run carbon-aware scheduling for flexible workloads. Internally, they keep
software portable across their own chips and GPUs through compilers and frameworks such as XLA, PyTorch, and Triton.

**Staff review questions.**
- What assumptions does the plan depend on, and when will each be reviewed?
- Which commitments are hard to reverse, and why are they worth it?
- Is the software portable to the next chip generation or another vendor?
- Is facility power and cooling ready for liquid-cooled, 100 kW+ racks?
- How are energy, carbon, and water measured and reported?
- Which regulations apply where, and how are controls updated as they change?

**Interview question.** "How would you design AI infrastructure that stays useful for five years when hardware changes
every one to two years?"

**Typical system-design prompt:** *Plan a three-year AI infrastructure roadmap for a company whose inference demand is
growing 4 times a year, with operations in the EU and Asia.*

**1. Clarify first:** Workload mix (training vs inference)? Model sources (own models or APIs)? Owned facilities or
cloud? Regulatory obligations per region? Sustainability targets? Budget growth?

**2. Back-of-envelope sizing:**
- Demand: 4 times a year for three years means 64 times today's inference load.
- Efficiency: two chip generations at about 2 times performance per dollar each give about 4 times. Software gains
  (quantization, batching, speculative decoding) give 2 to 4 times more. Together, 8 to 16 times.
- Remaining growth: 64 / 8 to 64 / 16 means 4 to 8 times more hardware spend, unless cheaper models or routing cut
  demand per request.
- Power: if today's serving uses 2 MW, 4 to 8 times means 8 to 16 MW, which requires facility or provider planning
  now.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Commitments | 3-year reservations | 1-year with upgrade rights | Match terms to hardware generations |
| Chips | Single vendor | Multi-vendor via compilers | Portable where cost of portability is low |
| Location | Cheapest power | Lowest carbon + residency | Residency first, then carbon and cost |
| Software | Vendor-specific stack | Standard APIs and formats | Standard boundaries, optimized internals |
| Facilities | Air-cooled | Liquid-ready | Liquid-ready for any new build |

**4. Follow-up questions with crisp answers:**
- *A new chip is twice as efficient next year. Buy now or wait?* Buy for proven current demand on short terms, and plan
  the next generation for growth.
- *A regulation changes residency rules.* Controls as code and regional deployments mean configuration changes, not
  redesign.
- *Should we bet on quantum?* No for AI capacity. Yes for post-quantum cryptography migration.
- *How do you reduce carbon without slowing products?* Move flexible jobs to low-carbon regions and hours, and make
  serving more efficient.

**Debug this (common onsite question):** "A company's 3-year GPU reservation is now more expensive per token than new
on-demand capacity."
1. The reservation was priced for the previous generation, at a price per hour that was a good deal at signing.
2. A new generation gives 2.5 times more tokens per dollar on demand.
3. The contract has no upgrade rights, and capacity is used for latency-insensitive work.
4. Fix: move batch and offline work onto the reserved capacity, put new latency-sensitive growth on the new generation,
   and negotiate future contracts with upgrade rights and shorter terms.

The lesson: in a fast-moving hardware market, long commitments need flexibility built in.

**5. What separates senior from staff answers:** a senior engineer knows the current best chips and tools. A staff
engineer plans for change: explicit assumptions with review dates, reversible decisions, portable software boundaries,
facilities ready for the next generation, measured energy and carbon, configurable regulatory controls, and signposts
that trigger a change of plan.

**Red flags:**
- Plans that assume today's prices and chips for five years.
- Long commitments without upgrade rights.
- Facilities that can't support liquid cooling.
- Software locked to one vendor's stack without need.
- No energy or carbon measurement.
- Hard-coded regulatory assumptions.
- Quantum hype in capacity plans.

---

## Quiz

<details><summary>1. Why is memory, not just FLOPs, a key trend in AI chips?</summary>
LLM inference is limited by memory bandwidth and capacity, so HBM size and bandwidth grow each generation, and they're a
large part of a chip's cost.
</details>

<details><summary>2. Why do rack-scale systems need different data centers?</summary>
They draw 100 kW or more per rack, which needs liquid cooling and much more power per rack than air-cooled halls provide.
</details>

<details><summary>3. What is the most urgent quantum-related task for AI infrastructure today?</summary>
Migrating to post-quantum cryptography, because data and model weights encrypted today could be recorded and decrypted
later.
</details>

<details><summary>4. Why is Rust increasingly used in AI infrastructure?</summary>
It gives C++-level speed with memory safety and no garbage collection pauses, which suits tokenizers, data loaders,
proxies, and databases.
</details>

<details><summary>5. What usually changes a training run's emissions more: the chip generation or the region?</summary>
The region. Grid carbon intensity can differ by more than 10 times, while a chip generation improves efficiency by roughly
1.5 to 2 times.
</details>

<details><summary>6. What training compute threshold does the EU AI Act use for systemic-risk general-purpose models?</summary>
10²⁵ FLOPs of training compute, above which models are presumed to have systemic risk and face extra obligations.
</details>

<details><summary>7. What makes an infrastructure decision future-proof?</summary>
Being reversible at a known cost: standard boundaries, short or flexible commitments, portable software, facility
headroom, and signposts for when to change.
</details>

## Failure modes
- Planning around today's chips and prices for many years.
- Facilities not ready for liquid cooling and rack-scale power.
- Software tightly bound to one vendor without a reason.
- Ignoring energy, carbon, and water until reporting is required.
- Hard-coded assumptions about regulation and residency.
- Long contracts with no upgrade or exit options.
- Quantum hype distorting plans, while post-quantum cryptography is neglected.

## Checklist
- [ ] You can describe current chip trends and their effect on facilities and software
- [ ] Capacity plans consider power, regions, providers, and sovereign requirements
- [ ] Post-quantum cryptography migration is planned for long-lived sensitive data
- [ ] Software boundaries (APIs, formats, schedulers) are portable
- [ ] Energy and carbon are measured per workload, with region and timing choices
- [ ] Regulatory controls are configurable per region, and compute is tracked against thresholds
- [ ] You wrote a three-year plan with assumptions, reversibility, and signposts
