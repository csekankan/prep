# Section 45 — AI Infrastructure Case Studies

> Lectures 309–315 • Assessments: quiz
> **After this section you can:** explain, from public sources, how OpenAI, Google DeepMind, Meta, Tesla, and Netflix
> built their AI infrastructure and why, describe what healthcare AI at scale requires, separate published facts from
> speculation, and analyze any company's AI architecture with a repeatable method that checks claims with
> back-of-envelope numbers.
>
> Builds on: [Section 31](../part08_scale_mlops_optimization/s31_large_scale_training.md) and
> [Section 32](../part08_scale_mlops_optimization/s32_advanced_large_scale_training.md) (large-scale training),
> [Section 43](s43_real_time_ai.md) (real-time AI), [Section 44](s44_autonomous_systems.md) (autonomous systems), and
> [Section 37](../part09_privacy_security_tenancy/s37_federated_learning.md) (federated learning).
>
> **A note on sources.** These case studies use what the companies have published (papers, engineering blogs, and
> official announcements) and widely reported news. Internal details change quickly and many are not public. Where
> something is reported rather than published by the company, the text says so. Treat numbers as snapshots in time.

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 309 | Case study: OpenAI infra for GPT | Supercomputers built with cloud partners, predictable scaling, Kubernetes at huge scale, and inference as the larger problem |
| 310 | Case study: Google infra for DeepMind | Custom TPUs in pods with optical switching, JAX and Pathways, and Borg, all designed together |
| 311 | Case study: Meta infra for LLaMA | 24K-GPU clusters, 4D parallelism, and a published account of failures at 16K GPUs |
| 312 | Case study: Tesla AI infra for FSD | A fleet data engine, end-to-end driving models, and large training clusters |
| 313 | Case study: Netflix AI infra for recommendations | Offline, nearline, and online layers, Metaflow, and experimentation at scale |
| 314 | Case study: Healthcare AI infra at scale | Regulated data, hospital integration, and validated, monitored models |
| 315 | Lab: analyze case study infra architecture | A repeatable method: claims, diagram, sizing, trade-offs, and lessons |

```mermaid
flowchart LR
  FM2["Frontier model labs<br/>OpenAI, Google DeepMind, Meta"] --> L1["Lesson: scale needs co-design<br/>chips, network, software, reliability"]
  AVC["Autonomous systems<br/>Tesla"] --> L2["Lesson: the data engine<br/>is the product"]
  REC2["Recommendations<br/>Netflix"] --> L3["Lesson: layer by latency,<br/>experiment constantly"]
  HC["Healthcare"] --> L4["Lesson: trust, regulation,<br/>and integration first"]
```

**How to read it:** the case studies fall into four groups, each with a main lesson. Frontier model labs show that
training at scale needs chips, network, software, and reliability designed together. Tesla shows that for autonomous
systems, the loop that collects and learns from data matters most. Netflix shows how to split recommendation work by
latency and improve it through constant experiments. Healthcare shows that trust, regulation, and integration with
clinical systems come before scale.

**Terms in this diagram.**
- **Frontier model labs**: organizations training the largest, most capable general-purpose models.
- **Co-design**: designing hardware, networking, and software together for the workload, rather than separately.
- **Data engine**: the loop that finds failures, collects data, labels it, retrains, and redeploys (Section 44).
- **Layer by latency**: splitting work into offline, nearline, and online parts according to how quickly results are
  needed (Lecture 313).
- **Experiment constantly**: running many A/B tests to decide changes by measured user impact.

---

## Lecture 309 — Case study: OpenAI infra for GPT

**Why it matters.** OpenAI's path from GPT-2 to ChatGPT shows what happens when a research lab's infrastructure must
suddenly serve hundreds of millions of users, while also training ever larger models. It's also the clearest example
of a lab building its compute through partnerships rather than its own data centers.

**In plain words.** It's like a small, famous restaurant that suddenly has to feed a whole city. It still needs its test
kitchen for new recipes, but now it also needs factories, delivery fleets, and suppliers, and has to build them while
the queue grows.

**Architecture: OpenAI's infrastructure, as publicly described.**

```mermaid
flowchart TB
  PART["Compute partners<br/>Microsoft Azure first, then more clouds, Stargate sites"] --> SC["Training supercomputers<br/>GPU clusters with InfiniBand"]
  SC --> K8S2["Kubernetes for research<br/>single clusters of thousands of nodes"]
  K8S2 --> PRED["Predictable scaling<br/>small runs forecast big ones"]
  PRED --> MODELS["GPT models"]
  MODELS --> INF2["Inference fleet<br/>ChatGPT and API, far more GPUs over time"]
  TRITON["Triton kernel language<br/>open source"] -.-> SC & INF2
```

**How to read it:** compute partners, first Microsoft Azure and later more clouds and large dedicated Stargate data
center sites, provide the training supercomputers: GPU clusters connected with InfiniBand. Research runs on
Kubernetes, with single clusters of thousands of nodes. Predictable scaling methods use small training runs to forecast
how big ones will perform, which guides the GPT models. Those models run on a growing inference fleet for ChatGPT and
the API. OpenAI's open-source Triton language is used to write fast GPU kernels for both training and inference.

**Terms in this diagram.**
- **Compute partners**: cloud providers and data-center developers that build and operate capacity for OpenAI.
- **Stargate sites**: the Stargate project, announced in January 2025 with SoftBank, Oracle, and MGX, plans very large
  AI data centers in the US, starting with a site in Abilene, Texas.
- **InfiniBand**: a high-bandwidth, low-latency network used to connect GPUs in training clusters (Section 13).
- **Predictable scaling**: fitting scaling laws on small runs to predict a large model's loss before training it.
- **Inference fleet**: the GPUs serving user requests, as opposed to training.
- **Triton kernel language**: an open-source, Python-like language from OpenAI for writing GPU kernels, also used by
  PyTorch's compiler (Section 36). It's unrelated to NVIDIA's Triton Inference Server.

**Core ideas.**
- **Partnership compute.** In 2020, Microsoft announced a supercomputer built for OpenAI on Azure with 285,000 CPU cores
  and 10,000 GPUs. Larger clusters followed for GPT-4 and later models. In 2025, OpenAI announced Stargate and
  multi-gigawatt agreements with several chip and cloud companies, moving toward more diverse suppliers.
- **Kubernetes at scale.** OpenAI's 2021 engineering post described scaling a single Kubernetes cluster to 7,500 nodes
  for research workloads such as GPT-3, CLIP, and DALL·E. Pods often used whole nodes, and the team had to tune etcd,
  the API servers, and monitoring for that scale.
- **Predictable scaling.** The GPT-4 technical report describes building infrastructure and methods that predicted
  the final loss from models trained with up to 10,000 times less compute. That lets a lab choose model sizes and data
  before committing a huge run.
- **Inference dominates over time.** After ChatGPT, serving demand grew faster than training. Inference needs capacity
  in many regions, batching, caching, rate limits by tier, and graceful degradation when demand exceeds capacity.
- **Software leverage.** Kernel languages like Triton, and attention to MFU and serving efficiency, multiply the value
  of every GPU.

**Example: capacity as the product limit.** After ChatGPT's launch in late 2022, demand quickly exceeded available
GPUs. Public signs included waitlists, usage caps on the most capable models, and paid tiers with priority access.
Infrastructure capacity, not model quality, decided how many people could use new features at launch, which is why
compute deals became a central part of OpenAI's strategy.

**Senior / FAANG best practice.** Plan compute years ahead and diversify suppliers, use scaling laws to de-risk large
runs, invest in kernel and serving efficiency, and design inference for overload: priority tiers, rate limits, caching,
and graceful degradation. Expect inference to outgrow training once a product succeeds.

---

## Lecture 310 — Case study: Google infra for DeepMind

**Why it matters.** Google is the main example of an AI company that designs its own chips, networks, compilers,
frameworks, and schedulers together. Google DeepMind's models, from AlphaGo and AlphaFold to Gemini, run on this
vertically integrated stack.

**In plain words.** Most teams buy a car and modify it. Google designs the engine, the gearbox, and the roads together,
so everything fits, at the cost of building it all yourself.

**Architecture: Google's AI stack.**

```mermaid
flowchart TB
  JAXF["JAX<br/>research code"] --> XLA2["XLA compiler<br/>graph to TPU code"]
  XLA2 --> PW["Pathways<br/>one controller across pods"]
  PW --> TPUPOD["TPU pods<br/>thousands of chips, ICI links"]
  TPUPOD --> OCS["Optical circuit switches<br/>reconfigurable topology"]
  BORG2["Borg<br/>cluster scheduling"] --> TPUPOD
  TPUPOD --> MULTI["Multi-pod, multi-data-center<br/>training for Gemini"]
```

**How to read it:** researchers write models in JAX. The XLA compiler turns the computation graph into TPU code.
Pathways runs one program across many TPU pods from a single controller. Each pod has thousands of TPU chips joined by
fast inter-chip links, and optical circuit switches can rewire the topology. Borg schedules work across Google's
clusters. Gemini models were trained across multiple pods and data centers.

**Terms in this diagram.**
- **JAX**: Google's Python library for array computing with automatic differentiation and compilation (Section 36).
- **XLA**: Accelerated Linear Algebra, a compiler that optimizes and fuses operations for TPUs and GPUs.
- **Pathways**: Google's system for running a single program across many accelerators and pods, with one controller
  that coordinates them.
- **TPU pods, ICI links**: groups of thousands of Tensor Processing Units connected by Google's inter-chip
  interconnect, a dedicated network between chips.
- **Optical circuit switches**: switches that redirect light with tiny mirrors, so the connections between groups of
  chips can be reconfigured without recabling.
- **Borg**: Google's internal cluster manager, which inspired Kubernetes.
- **Multi-pod, multi-data-center**: one training job spanning several TPU pods, and even pods in different data
  centers, connected over Google's network.

**Core ideas.**
- **TPU generations.** TPU v4 pods have 4,096 chips connected with optical circuit switches, described in a 2023 paper.
  TPU v5p pods have 8,960 chips. Trillium (v6e) followed in 2024, and Ironwood (v7), announced in 2025, is aimed at
  inference, with pods of up to 9,216 chips.
- **Reconfigurable topology.** Optical switches let Google build the shape of torus a job needs, route around failed
  racks, and use partial pods efficiently.
- **Single-controller programming.** Pathways lets one JAX program span many pods, which simplifies very large runs
  compared with launching thousands of independent processes.
- **Reliability at scale.** The Gemini 1.0 report describes keeping redundant in-memory copies of the model state for
  fast recovery instead of relying only on checkpoints in persistent storage, and detecting silent data corruption.
  It reports that this raised goodput on the largest run from 85% to 97%.
- **Co-design pays and costs.** Integration gives efficiency and control over supply, but requires large, long-term
  investment in hardware, compilers, and tools that few companies can afford.

**Example: AlphaFold's infrastructure beyond training.** AlphaFold 2 was trained on TPUs, but its biggest impact came
from inference: DeepMind and EMBL-EBI used it to predict over 200 million protein structures and published them in a
free database. That required a large batch inference pipeline and a public data service, showing that serving results
can matter as much as training the model.

**Senior / FAANG best practice.** Learn from Google's co-design even if you buy hardware: choose frameworks and
compilers that match your accelerators, design network topology for your parallelism, plan for fast in-memory recovery
and silent data corruption at large scale, and measure goodput, not just peak FLOPs.

---

## Lecture 311 — Case study: Meta infra for LLaMA

**Why it matters.** Meta published unusually detailed information about how it trained Llama 3, including cluster
designs, parallelism, storage, and failure statistics. It's the best public reference for what training a frontier
model on 16,000 GPUs actually looks like.

**In plain words.** It's like a mountaineering team that published not only its route to the summit, but also every
fall, broken rope, and weather delay along the way. That's what makes it so useful to the next team.

**Architecture: Meta's Llama 3 training infrastructure.**

```mermaid
flowchart TB
  CL1["Cluster A: 24K H100s<br/>RoCE Ethernet fabric"] --> JOB["Llama 3 405B job<br/>up to 16K GPUs"]
  CL2["Cluster B: 24K H100s<br/>InfiniBand fabric"] -.-> OTHER["Other training"]
  TECT["Tectonic storage<br/>240 PB, checkpoints, data"] --> JOB
  JOB --> PAR4["4D parallelism<br/>tensor, context, pipeline, FSDP"]
  JOB --> REL4["Reliability tooling<br/>fast diagnosis, restarts"]
  GT["Grand Teton servers<br/>Open Compute designs"] --> CL1 & CL2
```

**How to read it:** Meta built two clusters of about 24,000 H100 GPUs each, one with a RoCE Ethernet network and one
with InfiniBand. The Llama 3 405B model trained on up to 16,000 GPUs of the RoCE cluster. Training data and
checkpoints lived in Meta's Tectonic distributed storage, about 240 PB. The job combined four kinds of parallelism,
and depended on tooling to diagnose failures and restart quickly. The servers are Meta's Grand Teton design,
contributed to the Open Compute Project.

**Terms in this diagram.**
- **RoCE**: RDMA over Converged Ethernet, which lets GPUs exchange data directly over Ethernet with low latency
  (Section 13).
- **Tectonic**: Meta's distributed file system for exabyte-scale storage.
- **4D parallelism**: tensor parallelism (splitting layers), context parallelism (splitting long sequences), pipeline
  parallelism (splitting layers into stages), and FSDP (sharding weights and optimizer state across data-parallel
  ranks) (Sections 31 and 32).
- **Fast diagnosis, restarts**: tools that find the failed GPU or link quickly and restart the job from the last
  checkpoint.
- **Grand Teton, Open Compute**: Meta's GPU server platform, and the Open Compute Project, which shares data-center
  hardware designs openly.

**Core ideas.**
- **Scale.** The Llama 3 paper describes pretraining the 405B model on about 15.6 trillion tokens, using about 3.8 ×
  10²⁵ FLOPs, on up to 16,384 H100 GPUs at 38–43% MFU in BF16.
- **Failures are routine.** In a 54-day snapshot there were 466 job interruptions: 47 planned and 419 unexpected. About
  78% of the unexpected ones were attributed to confirmed or suspected hardware issues, with faulty GPUs (30.1%) and
  GPU HBM3 memory (17.2%) the largest categories. Despite that, Meta reports more than 90% effective training time.
- **Storage for checkpoints.** Tectonic provided 240 PB on 7,500 servers, with sustained throughput of 2 TB/s and peaks
  of 7 TB/s, so checkpoints of a huge model don't stall training for long.
- **Power and environment.** The paper notes throughput varying by 1–2% with daily temperature changes, and power draw
  across the data center swinging by tens of megawatts as all GPUs pause together, for example at checkpoints, which
  stresses the power grid.
- **Open sharing.** Publishing weights, server designs, and failure data strengthened the ecosystem and Meta's hiring
  and influence.

**Example: why two fabrics?** Meta built one 24K cluster on RoCE and one on InfiniBand to learn at scale how each
behaved. It reported that both could be tuned to handle large generative AI workloads without network bottlenecks,
and the largest Llama 3 run used RoCE. That evidence made Ethernet a credible choice for other companies building
large clusters.

**Senior / FAANG best practice.** Design for failure as a normal event: fast detection of bad GPUs and links, automated
restarts, asynchronous checkpoints to high-throughput storage, and goodput as a tracked metric. Combine parallelism
strategies to fit model and sequence length, plan power and cooling for synchronized load swings, and test network
fabrics at real scale before committing.

---

## Lecture 312 — Case study: Tesla AI infra for FSD

**Why it matters.** Tesla's Full Self-Driving program is the largest public example of a fleet-based data engine:
millions of customer cars collect data, and the company trains end-to-end driving models on large GPU clusters. It also
shows the risks of betting on custom training hardware.

**In plain words.** It's like having millions of student drivers who each send back only their most interesting
moments, so the teacher can build lessons from the hardest cases across the whole country.

**Architecture: Tesla's FSD data engine, as publicly described.**

```mermaid
flowchart LR
  CARS["Customer fleet<br/>cameras, FSD computer"] -->|"trigger campaigns,<br/>shadow mode"| CLIPS["Clip collection"]
  CLIPS --> AUTOL["Auto-labeling<br/>offline 3D reconstruction"]
  AUTOL --> TRAIN5["Training clusters<br/>NVIDIA GPUs; Dojo, later wound down"]
  TRAIN5 --> E2E["End-to-end network<br/>video in, controls out"]
  E2E --> SIMT["Simulation + evaluation"]
  SIMT -->|"OTA, staged"| CARS
```

**How to read it:** customer cars with cameras and Tesla's FSD computer collect clips when trigger campaigns or shadow
mode find interesting situations. The clips are auto-labeled offline, using 3D reconstruction of each scene. Training
runs on large clusters of NVIDIA GPUs (Tesla also built its own Dojo training system, which it reportedly wound down
in 2025). The result is an end-to-end network that maps camera video to driving controls, evaluated in simulation and
shipped to cars in staged over-the-air updates.

**Terms in this diagram.**
- **FSD computer**: Tesla's in-car computer with its own neural network accelerator chips (generations called HW3 and
  HW4, with AI5 announced).
- **Trigger campaigns**: queries sent to the fleet asking cars to save clips matching a pattern (for example, a certain
  sign or maneuver), as Tesla described at its 2019 Autonomy Day and later AI Days.
- **Shadow mode**: running a model without letting it control the car, to compare its decisions with the driver's
  (Section 44).
- **Offline 3D reconstruction**: rebuilding the scene from all cameras over the whole clip, so labels can use future
  frames and multiple views.
- **Dojo**: Tesla's custom training supercomputer built on its D1 chip, presented in 2021. Reports in 2025 said Tesla
  disbanded the Dojo team to focus on its inference chips and GPU clusters.
- **End-to-end network**: one neural network replacing much of the hand-written planning code. Tesla described FSD v12
  this way.
- **OTA, staged**: over-the-air software updates sent to cars over the internet, released to small groups before the
  whole fleet (Section 44).

**Core ideas.**
- **Fleet as sensor network.** Millions of cars give more data than any test fleet, but only a tiny fraction can be
  uploaded, so triggers and selection decide what the model learns.
- **Cameras only.** Tesla relies on cameras, without lidar, putting more weight on learned perception and on large
  amounts of video training data.
- **From modules to end-to-end.** Moving from hand-coded planning to an end-to-end network shifted effort from writing
  rules to curating data and training compute.
- **Compute build-out.** Tesla has described large NVIDIA GPU clusters, including one called Cortex at its Texas
  factory, alongside its Dojo effort.
- **Custom hardware risk.** Dojo shows that custom training chips need software, supply, and performance to keep up with
  fast-moving GPU generations. Inference chips in the car, which Tesla also designs, had a clearer payoff.

**Example: the stop sign campaign.** At Autonomy Day in 2019, Tesla described collecting examples of stop signs that
were partly hidden by trees. The team built a detector, sent a campaign to the fleet to return similar images, labeled
them, and retrained, improving detection of occluded signs. The same pattern of finding a failure, mining the fleet,
labeling, and retraining is the core of the data engine.

**Senior / FAANG best practice.** If you have a fleet, build the data engine first: triggers, shadow mode, efficient
upload, auto-labeling, and evaluation. Weigh custom training hardware against fast GPU improvements and its software
cost, put custom silicon where the payoff is clearest (often inference at the edge), and keep simulation and staged
rollout as safety gates.

---

## Lecture 313 — Case study: Netflix AI infra for recommendations

**Why it matters.** Netflix has said recommendations influence about 80% of the hours members stream, and estimated
that personalization saves it over $1 billion a year by reducing cancellations (a 2016 paper by its product leaders).
Its infrastructure shows how to run personalization for hundreds of millions of members with a strong culture of
experimentation.

**In plain words.** It's like a librarian who knows every reader. Some recommendations are prepared overnight,
some are updated as soon as you finish a book, and some are decided the moment you walk in, and the librarian keeps
testing which suggestions work best.

**Architecture: offline, nearline, and online.**

```mermaid
flowchart LR
  subgraph OFFL2["Offline: hours"]
    MF["Metaflow + Maestro<br/>training, batch scoring"]
  end
  subgraph NEAR["Nearline: seconds to minutes"]
    EVT["Events: plays, browsing"] --> NL["Update user state,<br/>precompute results"]
  end
  subgraph ONL2["Online: milliseconds"]
    REQ5["Homepage request"] --> RANK5["Rank rows and titles,<br/>choose artwork"]
  end
  MF --> CACHE5["Caches and stores<br/>EVCache, Cassandra"]
  NL --> CACHE5
  CACHE5 --> RANK5
  RANK5 --> AB["A/B tests + interleaving"]
```

**How to read it:** offline work runs for hours: Metaflow and the Maestro orchestrator train models and score in
batches. Nearline work reacts within seconds to minutes to events such as plays and browsing, updating each member's
state and precomputing results. Online work answers a homepage request in milliseconds, ranking rows and titles and
choosing the artwork to show. Offline and nearline results are stored in caches and databases such as EVCache and
Cassandra for the online layer. A/B tests and interleaving experiments measure every change.

**Terms in this diagram.**
- **Metaflow**: Netflix's open-source framework for building and running data science workflows, from notebooks to
  production (open-sourced in 2019).
- **Maestro**: Netflix's workflow orchestrator for large numbers of data and ML pipelines, open-sourced in 2024.
- **Nearline**: processing that happens soon after an event but not within the user's request, between batch and
  real time.
- **EVCache, Cassandra**: Netflix's distributed memcached-based cache, and the distributed database it uses heavily.
- **Choose artwork**: Netflix personalizes the image shown for each title, using contextual bandits (algorithms that
  learn which choice works best in each context while still exploring).
- **Interleaving**: an experiment method that mixes results from two rankers in one list and sees which one's items get
  chosen, which needs far fewer users than a standard A/B test.

**Core ideas.**
- **Layer by latency.** Netflix's 2013 architecture post split recommendation work into offline, nearline, and online,
  so heavy computation happens ahead of time and requests stay fast. That idea is now standard.
- **Experimentation platform.** Nearly every change is A/B tested on member engagement and retention, with interleaving
  to screen ranking ideas quickly.
- **ML platform for data scientists.** Metaflow lets scientists write workflows in Python and run them on Netflix's
  compute (originally the Titus container platform and AWS), with versioning and scheduling handled for them.
- **Foundation models for recommendations.** Netflix has written about building a large foundation model trained on
  member interaction histories, whose embeddings and predictions feed many downstream recommendation models, instead of
  many separate models each learning from scratch.
- **Cloud native.** Netflix runs on AWS, with its own tools for resilience such as Chaos Monkey.

**Example: the artwork experiment.** Netflix described personalizing title artwork: a member who watches many romances
might see a romantic scene from a film, while a comedy fan sees a funny one from the same film. Contextual bandits chose
images per member and learned from what was played. The infrastructure needed to precompute candidate images, log every
impression and choice for unbiased learning, and serve selections in the online path.

**Senior / FAANG best practice.** Split work by latency into offline, nearline, and online layers, precompute and cache
aggressively, give data scientists a platform that hides infrastructure, test every change with A/B tests or
interleaving, log impressions for unbiased learning, and consider shared foundation models for many recommendation
tasks.

---

## Lecture 314 — Case study: Healthcare AI infra at scale

**Why it matters.** Healthcare has huge amounts of valuable data and great potential for AI, but strict privacy rules,
fragmented systems, and high stakes for errors. Infrastructure for hospital AI must earn clinicians' trust, satisfy
regulators, and fit clinical workflows before scale matters.

**In plain words.** It's like bringing a new specialist into a hospital. They must be licensed, follow privacy rules,
use the hospital's records system, be supervised at first, and be reviewed regularly, however skilled they are.

**Architecture: AI in a hospital network.**

```mermaid
flowchart LR
  subgraph HOSP["Hospitals"]
    PACS["PACS imaging<br/>DICOM"] --> EDGEH["On-prem inference<br/>near scanners"]
    EHR["EHR<br/>Epic, Oracle Health"] <-->|"FHIR APIs"| INT2["Integration engine"]
  end
  EDGEH --> INT2
  INT2 --> CLIN["Clinician workflow<br/>worklist, alerts, human review"]
  HOSP -->|"de-identified data or federated"| RES["Research + training platform<br/>secure enclave, MONAI"]
  RES --> REGV["Validation + regulatory<br/>FDA, CE, PCCP"]
  REGV --> EDGEH
  CLIN --> MONH["Monitoring<br/>performance by site and group"]
```

**How to read it:** in each hospital, imaging comes from the PACS in DICOM format, and AI inference runs on-premises
near the scanners. The electronic health record exchanges data through FHIR APIs with an integration engine, which
also receives AI results and puts them into clinicians' workflows as worklist priorities and alerts, always reviewed by
a person. De-identified data, or federated learning that keeps data at each site, feeds a secure research and training
platform using tools such as MONAI. Models go through validation and regulatory clearance before deployment, and their
performance is monitored by hospital site and patient group.

**Terms in this diagram.**
- **PACS, DICOM**: picture archiving and communication system, the hospital's image store, and DICOM, the standard
  format and protocol for medical images.
- **EHR, Epic, Oracle Health**: electronic health record systems. Epic and Oracle Health (formerly Cerner) are two large
  vendors.
- **FHIR APIs**: Fast Healthcare Interoperability Resources, a standard for exchanging health records through web APIs.
- **Integration engine**: middleware that routes messages between hospital systems, translating formats.
- **De-identified, federated**: data with identifying details removed under HIPAA rules, or training where data stays
  at each site and only model updates move (Section 37).
- **MONAI**: an open-source PyTorch-based framework for medical imaging AI.
- **FDA, CE, PCCP**: US and EU regulatory approval for AI as a medical device, and the FDA's predetermined change
  control plan, which lets manufacturers describe in advance how a cleared model may be updated.

**Core ideas.**
- **Privacy and security.** HIPAA in the US and GDPR in Europe, business associate agreements with vendors, encryption,
  access logging, and minimum-necessary data use (Sections 18 and 38).
- **Integration is the hard part.** Value comes only when AI results appear inside the clinician's existing tools at
  the right moment. That needs DICOM, HL7, and FHIR interfaces and work with EHR vendors.
- **Hybrid placement.** Imaging AI often runs on-premises or in a hospital's private cloud, because of data volume,
  latency, and policy. Training uses de-identified central data or federated learning across institutions.
- **Regulated changes.** AI that influences diagnosis is often a regulated medical device. Updates follow a change
  control plan with validation, and drift monitoring by site, scanner model, and patient group is required for safety
  and fairness.
- **Human oversight.** Most deployments are decision support, with clinicians reviewing results, and the workflow must
  make that review practical, not a rubber stamp.

**Example: the scanner upgrade.** A hospital network's chest X-ray triage model lost sensitivity at one hospital after
it installed new X-ray machines with different image processing. Monitoring by site and scanner model caught the drop
within two weeks, the hospital reverted to manual prioritization for that site, and the vendor validated a retrained
model under its change control plan before re-enabling it.

**Senior / FAANG best practice.** Design healthcare AI infrastructure around privacy, integration, and regulation:
de-identification or federated learning for training, on-prem or private cloud inference near data, standard
interfaces (DICOM, HL7, FHIR) into clinician workflows, regulated change control, and monitoring by site, device, and
patient group with human oversight.

---

## Lecture 315 — Lab: analyze case study infra architecture

**Goal:** analyze one company's AI infrastructure from public sources, using a repeatable method: collect and grade
claims, draw the architecture, check key numbers with back-of-envelope calculations, analyze trade-offs, and write
lessons you'd apply. The worked example uses the Llama 3 405B training run.

**What you're building:** a case analysis document `case_analysis.md` and a sizing script `case_sizing.py`.

```mermaid
flowchart LR
  SRC2["(1) Sources<br/>papers, blogs, filings, news"] --> CLAIMS["(2) Claims table<br/>published vs reported"]
  CLAIMS --> DIAG["(3) Architecture diagram"]
  DIAG --> SIZE["(4) Sizing checks<br/>FLOPs, time, failures, power"]
  SIZE --> TRADE["(5) Trade-offs<br/>what they chose and why"]
  TRADE --> LESS["(6) Lessons<br/>what you'd copy, what not"]
```

**How to read the diagram:** start by collecting sources: papers, engineering blogs, company filings, and news. List
each claim in a table, marked as published by the company or only reported by others. Draw the architecture from the
claims, then check key numbers yourself: compute, training time, failure rates, and power. Analyze the trade-offs the
company made and why, and finish with lessons: what you'd copy and what you wouldn't. **Filings** are official
documents companies submit to regulators, such as annual reports.

**Prerequisites:** Python 3 and access to the *Llama 3 Herd of Models* paper (2024), or your chosen company's sources.

### Step 1 — Claims table

Make a table `Claim | Source | Type (published or reported) | Date`. For Llama 3, include at least: 405B parameters,
about 15.6T training tokens, 3.8 × 10²⁵ FLOPs, up to 16,384 H100s, 38–43% MFU, the 54-day snapshot of 466 interruptions
(419 unexpected), the two 24K-GPU clusters (RoCE and InfiniBand), and Tectonic's 240 PB.

### Step 2 — Architecture diagram

Draw the training architecture in Mermaid: clusters and fabrics, storage, the job and its parallelism, and reliability
tooling. Add a **Terms** list explaining every label.

### Step 3 — Sizing checks

```python
# case_sizing.py
import math
N, D = 405e9, 15.6e12                      # parameters, training tokens (Llama 3 paper)
GPUS, PEAK, MFU = 16_384, 989e12, 0.40     # H100 dense BF16 peak; the paper reports 38-43% MFU
UNEXPECTED, WINDOW_DAYS = 419, 54          # unexpected interruptions in the paper's 54-day snapshot

flops = 6 * N * D
print(f"training compute 6ND = {flops:.2e} FLOPs")
print(f"time on {GPUS:,} H100s at {MFU:.0%} MFU: {flops / (GPUS * PEAK * MFU) / 86400:.0f} days")
mtbf_h = WINDOW_DAYS * 24 / UNEXPECTED
print(f"job MTBF {mtbf_h:.1f} h;  per-GPU MTBF {mtbf_h * GPUS / 24 / 365:.1f} years")

def goodput(stall_min, restart_min):
    tau = math.sqrt(2 * stall_min / 60 * mtbf_h)                 # Young's interval, hours
    lost = (stall_min / 60) / tau + (tau / 2 + restart_min / 60) / mtbf_h
    return tau * 60, 1 - lost

for name, stall, restart in [("sync checkpoint 5 min, restart 15 min", 5, 15),
                             ("async checkpoint 30 s, restart 5 min", 0.5, 5)]:
    tau, g = goodput(stall, restart)
    print(f"{name}: checkpoint every {tau:.0f} min, goodput {g:.1%}")
print(f"weights BF16 {N * 2 / 1e12:.2f} TB;  weights + grads + Adam at 16 B/param {N * 16 / 1e12:.1f} TB "
      f"= {N * 16 / GPUS / 1e6:.0f} MB per GPU if fully sharded")
mw = GPUS * 700 / 1e6
print(f"GPU power {mw:.1f} MW;  facility at about 1.8x for servers, network, cooling: {mw * 1.8:.0f} MW")
```

```bash
python3 case_sizing.py
```

In the script, training compute uses the 6·N·D rule (Section 31), and training time divides it by the cluster's
achieved FLOPs (GPUs × peak × MFU). The job's mean time between failures is the snapshot length divided by the number
of unexpected interruptions, and multiplying by the GPU count gives a single GPU's MTBF. Goodput uses Young's
checkpoint interval (Section 32): time lost is the checkpoint stall per interval, plus, for each failure, half an
interval of lost work and the restart time. The last lines estimate memory for model state and power for 700 W GPUs.

### Step 4 — Trade-offs and lessons

Write a table `Decision | What they chose | Alternative | Why (from sources or your inference)` covering the network
fabric, dense vs mixture-of-experts architecture (Llama 3 chose dense for training stability), parallelism, storage,
and open release. Then list three lessons you'd apply to a smaller organization and one you wouldn't.

**Expected results:**
- `case_sizing.py` prints 3.79 × 10²⁵ FLOPs, matching the paper's 3.8 × 10²⁵, and about 68 days of pure training at
  40% MFU on 16,384 GPUs.
- Job MTBF of 3.1 hours, even though each GPU's MTBF is about 5.8 years: scale turns rare failures into constant ones.
- Goodput of about 68.7% with synchronous 5-minute checkpoints and 15-minute restarts, against 90.0% with 30-second
  asynchronous checkpoints and 5-minute restarts. That gap explains why Meta invested in fast checkpointing and
  automated recovery to reach more than 90% effective training time.
- Model state of 6.5 TB (396 MB per GPU if fully sharded, so activations, not weights, dominate GPU memory), and about
  11.5 MW of GPU power, roughly 21 MW for the facility.
- The document has a claims table with sources and types, a diagram with terms, sizing results, a trade-off table, and
  lessons.

---

## FAANG deep-dive notes

**How big tech does it.** Big tech companies publish case studies selectively: papers and engineering blogs that help
hiring, influence standards, or open-source strategy, while keeping cost, supplier, and some architecture details
private. Engineers there read competitors' papers closely, reproduce their numbers, and borrow ideas such as Google's
optical switching, Meta's failure accounting, and Netflix's offline, nearline, and online split. In design reviews, they
cite public case studies as evidence, and check them with their own sizing.

**Staff review questions.**
- Which claims are published by the company, and which are reported by others?
- Do the numbers agree with each other under back-of-envelope checks?
- What constraints (money, chips, regulation, product) drove each choice?
- Which lessons transfer to our scale, and which only make sense at theirs?
- What failed or was abandoned, and why?

**Interview question.** "Pick a well-known AI system and explain its infrastructure, including one design choice you'd
make differently."

**Typical system-design prompt:** *Using lessons from public case studies, design training infrastructure for a 70B
model run on 2,048 GPUs.*

**1. Clarify first:** Tokens? Deadline? Owned cluster or cloud? Network fabric? Checkpoint storage? Team experience
with large runs?

**2. Back-of-envelope sizing:**
- Compute: 6 × 70e9 × 15e12 = 6.3 × 10²⁴ FLOPs. At 2,048 H100s × 989 TFLOPS × 40% MFU = 8.1 × 10¹⁷ FLOP/s, about 90
  days.
- Failures: scaling Meta's rate (one unexpected interruption per 3.1 hours on 16K GPUs) to 2K GPUs gives about one
  every 25 hours.
- Checkpoints: 70B × 16 bytes ≈ 1.1 TB of state. At 100 GB/s to storage, a synchronous save is about 11 seconds, and
  asynchronous saves make it negligible.
- Power: 2,048 × 700 W ≈ 1.4 MW of GPU power, about 2.6 MW for the facility.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Fabric | InfiniBand | RoCE Ethernet | Either works at scale when tuned. Choose by team skills and supply |
| Architecture | Dense | Mixture of experts | Dense for stability and simplicity, MoE for cost per token at scale |
| Recovery | Restart from checkpoint | In-memory redundancy | Checkpoints first, in-memory copies at very large scale |
| Hardware | Custom chips | GPUs | GPUs unless you have the scale and software teams for custom chips |
| Publication | Closed | Open | Depends on strategy. Open data on failures helps the whole field |

**4. Follow-up questions with crisp answers:**
- *Why is 16K-GPU MTBF only 3 hours?* Thousands of components, each rarely failing, add up to frequent failures.
- *Why did Google build optical switching?* To reconfigure topology, route around failures, and use pods flexibly.
- *Why did Netflix split offline, nearline, and online?* To keep requests fast by precomputing heavy work.
- *What does Dojo teach?* Custom training hardware must keep pace with GPUs and their software ecosystem, or it falls
  behind.

**Debug this (common onsite question):** "A case study claims a model trained on 1,000 GPUs in 10 days with 2 × 10²⁵
FLOPs. Is it plausible?"
1. Required rate: 2 × 10²⁵ / (10 × 86,400 s) = 2.3 × 10¹⁹ FLOP/s.
2. Per GPU: 2.3 × 10¹⁶ FLOP/s, which is 23 PFLOPS per GPU.
3. That's more than 20 times an H100's dense BF16 peak, and even FP8 sparse peaks don't reach it.
4. Conclusion: the claim is wrong by more than an order of magnitude. Perhaps the GPU count, days, or FLOPs is
   misreported.

The lesson: a one-line calculation can test any infrastructure claim.

**5. What separates senior from staff answers:** a senior engineer retells a case study accurately. A staff engineer
separates published facts from reports, checks the numbers, explains the constraints behind each decision, and states
which lessons transfer to a different scale and which don't.

**Red flags:**
- Treating news reports as company facts.
- Repeating numbers without checking them.
- Copying hyperscaler designs at small scale.
- Ignoring failures and abandoned projects.
- Using outdated snapshots as current facts.

---

## Quiz

<details><summary>1. What did OpenAI's GPT-4 report say about predictable scaling?</summary>
Its infrastructure and methods predicted the final loss of GPT-4 from models trained with up to 10,000 times less compute,
which de-risks choosing model size and data before a huge run.
</details>

<details><summary>2. What do optical circuit switches give Google's TPU pods?</summary>
Reconfigurable connections between groups of chips, so jobs get the topology they need, failed racks are routed around, and
partial pods are used efficiently.
</details>

<details><summary>3. What did the Llama 3 paper report about failures?</summary>
466 interruptions in 54 days, 419 unexpected, about 78% from confirmed or suspected hardware (GPUs 30.1%, HBM3 17.2%), yet
more than 90% effective training time.
</details>

<details><summary>4. What is a trigger campaign in Tesla's data engine?</summary>
A query sent to the fleet asking cars to save and upload clips that match a pattern, to collect training data for a specific
failure.
</details>

<details><summary>5. What are Netflix's offline, nearline, and online layers?</summary>
Batch work over hours (training, batch scoring), event-driven updates within seconds to minutes, and request-time ranking
within milliseconds, using precomputed results.
</details>

<details><summary>6. Why is integration often the hardest part of healthcare AI?</summary>
Results only help when they appear inside clinicians' existing tools at the right time, which needs DICOM, HL7, FHIR
interfaces and EHR vendor work.
</details>

<details><summary>7. How do you check whether a reported training run is plausible?</summary>
Divide the claimed FLOPs by the time and GPU count, and compare the per-GPU rate with the hardware's peak and realistic MFU.
</details>

## Failure modes
- Repeating unverified or outdated claims as facts.
- Copying the architecture of a company at a very different scale.
- Ignoring the constraints (budget, regulation, supply) that drove a design.
- Studying successes only, not abandoned projects.
- Skipping the numbers that would expose an impossible claim.

## Checklist
- [ ] You can explain each case study's architecture and its main lesson
- [ ] You can separate published facts from reported ones and date them
- [ ] You can check training compute, time, failures, and power with quick calculations
- [ ] You analyzed a case with the claims, diagram, sizing, trade-offs, and lessons method
- [ ] You can say which lessons transfer to your organization's scale
