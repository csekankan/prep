# Part X — AI Infrastructure in Context (Sections 41–46, lectures 281–322)

How AI infrastructure changes with the organization and the workload: startups on tight budgets, regulated
enterprises, real-time systems with millisecond budgets, safety-critical autonomous machines, lessons from the
companies that built AI at the largest scale, and where the field is heading.

| § | Section | You will be able to | Exercise |
|---|---|---|---|
| 41 | [AI Infrastructure for Startups](s41_startups.md) | Pick lean GPU options, run a small open-source stack, cut cost per request with routing and caching, and advise a CTO with runway numbers | [`s41_startup_budget.py`](../exercises/s41_startup_budget.py) |
| 42 | [AI Infrastructure for Enterprises](s42_enterprises.md) | Select vendors with weighted scoring, compare on-prem and cloud TCO honestly, map regulations to controls, integrate with enterprise IT, and defend a plan to a review board | — |
| 43 | [Infrastructure for Real-Time AI](s43_real_time_ai.md) | Budget latency end to end, tame fan-out tails with hedging, build streaming features, and run a real-time fraud pipeline | [`s43_latency_slo.py`](../exercises/s43_latency_slo.py) |
| 44 | [Infrastructure for Autonomous Systems](s44_autonomous_systems.md) | Explain the AV data engine, sensor fusion pipelines, safety monitors, simulation, and fleet updates, and run a safety-critical deployment review | — |
| 45 | [AI Infrastructure Case Studies](s45_case_studies.md) | Analyze OpenAI, Google DeepMind, Meta, Tesla, Netflix, and healthcare AI infrastructure from public sources, and check claims with sizing | — |
| 46 | [Future of AI Infrastructure](s46_future_of_ai_infra.md) | Plan for chip, cloud, software, energy, quantum, and regulatory change with reversible decisions and signposts | — |

```mermaid
flowchart LR
  P9["Part IX: privacy, security,<br/>multi-tenancy"] --> S41["§41 Startups<br/>budget, runway"]
  P9 --> S42["§42 Enterprises<br/>vendors, hybrid, compliance"]
  S41 & S42 --> S43["§43 Real-time AI<br/>latency, streaming"]
  S43 --> S44["§44 Autonomous systems<br/>safety, simulation, fleets"]
  S44 --> S45["§45 Case studies<br/>lessons at scale"]
  S45 --> S46["§46 Future<br/>chips, energy, regulation"]
  S46 --> NEXT2["Part XI: review<br/>and capstone"]
```

**How to read it:** Part X starts from Part IX's secure, shared platform and asks how the right infrastructure depends
on context. Sections 41 and 42 contrast a startup's budget-driven choices with an enterprise's governance and
integration needs. Section 43 adds millisecond latency budgets and streaming features, and Section 44 adds physical
safety. Section 45 studies how the largest AI companies built their infrastructure, and Section 46 looks ahead. Part XI
then reviews the whole course and runs the capstone project.

**Terms in this diagram.**
- **Runway**: months of cash left at the current spending rate (Section 41).
- **Hybrid**: combining on-prem data centers and cloud on one platform (Section 42).
- **Streaming**: computing features continuously from event streams such as Kafka (Section 43).
- **Fleets**: many deployed vehicles or robots updated and monitored together (Section 44).
- **Capstone**: the final project that applies the whole course to one system (Part XI).
