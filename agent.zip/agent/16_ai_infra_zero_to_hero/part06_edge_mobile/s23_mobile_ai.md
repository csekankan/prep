# Section 23 — Mobile AI Infrastructure

> Lectures 155–161 • Assessments: quiz, **Practice Test: AI Infrastructure Foundations and Production Systems** (end of this file)
> **After this section you can:** explain why on-device AI is growing, convert and run models with Core ML
> on iOS and LiteRT (TensorFlow Lite) on Android, deploy on-device NLP and small language models, manage
> power and thermals, design privacy-preserving on-device AI, and build an Android app with on-device
> inference. The practice test then checks Sections 1–23.
>
> Go deeper: [13 / Lab 65 — Anonymization proxy](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab65_anonymization_proxy.md),
> [Lab 96 — Federated learning](../../13_sovereign_ai_infra_course/07_sovereign_deployment/lab96_federated_learning.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 155 | Why mobile AI is booming | Every new phone has an NPU. On-device means instant, private, offline, and free per call |
| 156 | Core ML for iOS: basics | Convert with coremltools, compress, and let Core ML schedule across the CPU, GPU, and Neural Engine |
| 157 | TensorFlow Lite for Android: basics | LiteRT models with GPU and NPU delegates, shipped in assets or delivered on demand |
| 158 | Deploying on-device NLP models | Small transformers and 1–4B quantized language models on phones, with the memory and speed limits |
| 159 | Power management in mobile AI | Energy per inference, NPU first, duty cycles, and OS background rules |
| 160 | Privacy considerations for on-device AI | Data stays local, but models, telemetry, and updates still need privacy design |
| 161 | Lab: build a mobile AI app with TFLite | Android camera classification with LiteRT, comparing CPU and GPU delegates |

```mermaid
flowchart LR
  subgraph CLOUD["Cloud (build and learn)"]
    TR["Train / distill"] --> CONV["Convert + compress<br/>Core ML, LiteRT, ExecuTorch"]
    CONV --> CDN["Model delivery<br/>app bundle or on-demand download"]
    AGG["Aggregate: federated updates,<br/>privacy-safe telemetry"]
  end
  subgraph PHONE["Phone"]
    APP["App"] --> RT["On-device runtime"]
    RT --> NPU["Neural Engine / Hexagon NPU"]
    RT --> GPU["Mobile GPU"]
    RT --> CPU["CPU fallback"]
    APP -.->|"hard cases, with consent"| PCC["Cloud model"]
  end
  CDN --> APP
  APP -.->|"aggregated, anonymized"| AGG --> TR
```

**How to read it:** models are trained and distilled in the cloud, converted to the mobile format, and
shipped in the app or downloaded later. On the phone, the runtime places work on the NPU, GPU, or CPU.
Only hard cases (with consent) go to a cloud model, and learning signals come back only in aggregated,
privacy-preserving form.

**Terms in this diagram.**
- **Train / distill**: train a large model, then teach a small one to imitate it, so it fits on a phone (Section 22).
- **Core ML, LiteRT, ExecuTorch**: the on-device model formats and runtimes. **Core ML** is Apple's (Lecture 156).
  **LiteRT** (formerly TensorFlow Lite) is Google's (Lecture 157). **ExecuTorch** is PyTorch's runtime for phones
  and embedded devices.
- **App bundle or on-demand download**: the model either ships inside the installed app, or the app downloads it
  later, so the install stays small.
- **Federated updates**: model improvements computed on phones from local data, sent as weight changes instead of
  raw data (Lecture 160).
- **Privacy-safe telemetry**: usage and performance statistics that contain no personal content.
- **Neural Engine / Hexagon NPU**: the neural processing units in Apple chips (the **Apple Neural Engine**, ANE) and
  Qualcomm Snapdragon chips (**Hexagon**).
- **CPU fallback**: operations the NPU and GPU can't run go to the main processor.
- **PCC / cloud model**: a larger model on servers. Apple's version is **Private Cloud Compute** (Lecture 155).
- **Aggregated, anonymized**: combined across many users, with identities removed, before anyone sees it.

**Terms in this diagram.**
- **Core ML, LiteRT, ExecuTorch**: the on-device model formats and runtimes. **Core ML** is Apple's (Lecture 156).
  **LiteRT**, formerly TensorFlow Lite, is Google's (Lecture 157). **ExecuTorch** is PyTorch's runtime for phones
  and embedded devices.
- **Model delivery, app bundle or on-demand download**: the model either ships inside the app package, or is
  downloaded after install, which keeps the app small and lets you update the model without an app release.
- **Federated updates**: model improvements computed on the phones themselves and sent as small weight changes,
  never raw data (Lecture 160).
- **Privacy-safe telemetry**: usage and performance statistics with no personal content.
- **Neural Engine / Hexagon NPU**: the AI accelerators in Apple's chips and in Qualcomm Snapdragon chips.
- **CPU fallback**: operations no accelerator supports run on the ordinary CPU cores.
- **PCC (cloud model)**: the node is labeled `PCC` after Apple's **Private Cloud Compute**, a cloud model service
  designed so requests aren't stored or visible to the operator (Lecture 155).
- **Aggregated, anonymized**: combined across many users, with identifiers removed, before anyone sees it.

---

## Lecture 155 — Why mobile AI is booming

**Why it matters.** Phones are the largest AI fleet in the world: billions of devices with dedicated AI
accelerators. Running models on them removes server cost per call, works offline, cuts latency, and keeps
personal data on the device, which is why on-device language models now ship in mainstream phones.

**In plain words.** Instead of phoning a translator every time you need a word, you carry a pocket
dictionary. It's instant, works on a plane, and nobody else hears what you look up. The trade-off is that the
pocket version is smaller than the full library.

**Architecture: on-device, cloud, and hybrid AI on phones.**

```mermaid
flowchart TB
  REQ["User action"] --> ROUTE{"Can the on-device model<br/>handle it well?"}
  ROUTE -->|"yes: most requests"| ON["On-device model<br/>~10-50 ms, private, free per call"]
  ROUTE -->|"no: complex, needs fresh knowledge"| CL["Cloud model<br/>bigger, costs per call,<br/>needs network + consent"]
  ON --> RES["Result"]
  CL --> RES
```

**How to read it:** the app routes each request. Most go to a compact model on the device, giving a fast,
private result at no per-call cost. Harder requests that need a much bigger model or fresh information
go to the cloud, with the user's data handled under clear privacy rules. Apple's on-device models plus
Private Cloud Compute, and Google's Gemini Nano plus cloud Gemini, follow this pattern.

In the diagram, **free per call** means running on the user's phone costs you nothing per request, whereas the cloud
model **costs per call** in GPU time or API fees. **Fresh knowledge** means information newer than the model on the
phone, such as today's news. **Consent** is the user's explicit permission before their data leaves the device.

In the diagram, **free per call** means running on the phone costs you nothing for each use, since the user's
hardware does the work, while the cloud model **costs per call** in GPU time. **Fresh knowledge** is information newer
than the on-device model, or too large to store on the phone. **Consent** means the user has agreed to send that data
off the device.

**Core ideas.**

| Driver | Detail |
|---|---|
| Hardware | Phone NPUs deliver roughly 35–50+ TOPS (Apple Neural Engine on A17 Pro/A18, Qualcomm Hexagon on Snapdragon 8 Gen 3/Elite) |
| Cost | Zero server cost per inference. For an app with 50M users, that's millions of dollars a year saved |
| Latency | Camera effects, keyboards, and speech need under 30 ms. The network can't guarantee that |
| Privacy | Photos, messages, health data, and voice stay on the device |
| Offline | Travel, poor coverage, airplane mode |
| On-device LLMs | ~1–4B parameter models (Gemini Nano, Apple's ~3B on-device model, Llama 3.2 1B/3B, Gemma, Phi) quantized to 4 bits |

- **Typical on-device tasks:** photo enhancement and segmentation, OCR and translation, speech
  recognition, keyboard prediction, smart replies, summarization, and accessibility features.
- **Constraints:** app size limits, RAM shared with every other app, battery, thermals, and a huge variety of
  devices (especially on Android).

**Example: moving speech recognition on-device.** A note-taking app paid ~$0.006 per minute for cloud speech
recognition across 120 million minutes a month, about $720,000 a month. Moving to an on-device model for
supported phones (~80% of users) cut that by ~$575,000 a month, made transcription work offline, and
reduced latency from ~1.2 s to ~250 ms. Older devices kept the cloud path.

**Senior / FAANG best practice.** Default to on-device for latency-sensitive and private features, and
design a hybrid path for capability gaps and older devices. Plan device tiers (which models run on which
hardware), and measure quality and battery impact per tier. The big platform owners treat on-device and
private-cloud inference as one product, with clear rules for what leaves the device.

---

## Lecture 156 — Core ML for iOS: basics

**Why it matters.** Core ML is how models run on Apple devices with the Neural Engine, GPU, and CPU used
automatically. Converting and compressing correctly decides speed, app size, and battery use for every
iPhone, iPad, and Mac user.

**In plain words.** Core ML is Apple's universal adapter. You plug in a model trained anywhere, and the
system decides which chip on the device should do each part of the work.

**Architecture: from PyTorch to an iPhone.**

```mermaid
flowchart LR
  PT["PyTorch model (eval)"] -->|"torch.jit.trace or torch.export"| TS["Traced graph"]
  TS -->|"coremltools.convert<br/>ML Program, iOS 17+ target"| PKG["Model.mlpackage"]
  PKG -->|"coremltools.optimize:<br/>INT8 / palettize / prune"| SMALL["Compressed .mlpackage"]
  SMALL --> XC["Xcode: generated Swift class,<br/>performance report"]
  XC --> APP["App: MLModel + Vision framework"]
  APP --> CU{"computeUnits"}
  CU --> ANE["Neural Engine"]
  CU --> G["GPU"]
  CU --> C["CPU"]
```

**How to read it:** the model is traced and converted with coremltools into an ML Program package
(`.mlpackage`), optionally compressed (weight quantization, palettization, which is weight clustering
into a small lookup table, or pruning), and added to Xcode, which generates a Swift interface and can
profile the model on a real device. At runtime, Core ML places each operation on the Neural Engine, GPU, or
CPU, within the compute units you allow.

**Terms in this diagram.**
- **eval**: PyTorch evaluation mode, which turns off training-only behavior such as dropout before export.
- **torch.jit.trace or torch.export**: two ways to capture the model as a fixed graph of operations. **Tracing** runs
  one example input and records what happened. `torch.export` is the newer, more complete method.
- **coremltools.convert, ML Program, iOS 17+ target**: **coremltools** is Apple's Python package for creating Core ML
  models. **ML Program** is the modern Core ML model type. The **deployment target** (here iOS 17 or later) decides
  which operations and compression features may be used.
- **.mlpackage**: the Core ML model package, a folder holding the model description and weights.
- **coremltools.optimize: INT8 / palettize / prune**: compression options. **INT8** stores weights as 8-bit integers.
  **Palettize** groups weights into, say, 16 shared values and stores only a 4-bit index per weight. **Prune** sets
  small weights to zero.
- **Xcode: generated Swift class, performance report**: Apple's development tool creates a typed Swift wrapper for
  the model, and its **performance report** shows, on a connected device, how long each layer takes and where it
  runs.
- **MLModel + Vision framework**: `MLModel` is the Core ML class that loads and runs a model. **Vision** is Apple's
  framework that handles image preparation (scaling, cropping, rotation) for vision models.
- **computeUnits**: the setting that allows Core ML to use all units, CPU and GPU only, CPU and Neural Engine only,
  or CPU only.

**Terms in this diagram.**
- **eval**: PyTorch's evaluation mode, which turns off training-only behavior such as dropout before export.
- **torch.jit.trace or torch.export**: two ways to capture the model as a fixed graph. **Tracing** runs one example
  input and records the operations. `torch.export` is the newer, more complete capture method.
- **coremltools.convert, ML Program, iOS 17+ target**: **coremltools** is Apple's Python package for converting models.
  **ML Program** is the modern Core ML model type. The **target** is the minimum iOS version, which decides which
  operations and compression features are allowed.
- **.mlpackage**: the folder-like file that holds a Core ML model.
- **coremltools.optimize: INT8 / palettize / prune**: compression options. **INT8** stores 8-bit weights.
  **Palettize** groups weights into a small "palette" (for example 16 shared values) and stores only each weight's
  4-bit index. **Prune** sets small weights to zero.
- **Xcode, Swift class, performance report**: **Xcode** is Apple's development environment. It generates a **Swift**
  class for calling the model, and its **performance report** shows per-layer timing and which unit runs each layer.
- **MLModel + Vision framework**: `MLModel` is the Core ML class that runs a model. Apple's **Vision** framework handles
  image scaling, cropping, and orientation for image models.
- **computeUnits**: the setting that lists which processors Core ML may use, for example `.all` or
  `.cpuAndNeuralEngine`.

**Core ideas.**

```python
import coremltools as ct, torch, torchvision
m = torchvision.models.mobilenet_v3_large(weights="DEFAULT").eval()
traced = torch.jit.trace(m, torch.rand(1, 3, 224, 224))
mlmodel = ct.convert(traced,
    inputs=[ct.ImageType(name="image", shape=(1, 3, 224, 224), scale=1 / 255.0,
                         bias=[-0.485 / 0.229, -0.456 / 0.224, -0.406 / 0.225])],
    classifier_config=ct.ClassifierConfig("imagenet_labels.txt"),
    minimum_deployment_target=ct.target.iOS17, compute_precision=ct.precision.FLOAT16)
mlmodel.save("MobileNetV3.mlpackage")

import coremltools.optimize as cto            # 8-bit weight quantization: ~2x smaller than FP16
cfg = cto.coreml.OptimizationConfig(global_config=cto.coreml.OpLinearQuantizerConfig(mode="linear_symmetric"))
cto.coreml.linear_quantize_weights(mlmodel, cfg).save("MobileNetV3_int8.mlpackage")
```

```swift
import CoreML, Vision
let config = MLModelConfiguration()
config.computeUnits = .cpuAndNeuralEngine          // or .all
let model = try VNCoreMLModel(for: MobileNetV3(configuration: config).model)
let request = VNCoreMLRequest(model: model) { req, _ in
    if let top = (req.results as? [VNClassificationObservation])?.first { print(top.identifier, top.confidence) }
}
try VNImageRequestHandler(cgImage: image).perform([request])
```

- **The Neural Engine prefers** FP16, static shapes, and supported operations. Unsupported operations fall back to the GPU
  or CPU, which can slow things down. Check placement in Xcode's performance report.
- **Compression:** 8-bit weights halve size versus FP16. 4-bit or 6-bit palettization is common for large
  models. Apple's on-device foundation model uses ~2–4 bits per weight on average.
- **Model delivery:** small models ship in the bundle. Large ones download after install (Background Assets),
  and can be encrypted with Core ML model encryption.

**Example: a model that skipped the Neural Engine.** A segmentation model converted with dynamic input
sizes ran at 95 ms on an iPhone, all on the GPU. Xcode's performance report showed the Neural Engine
rejected it because of flexible shapes. Converting with a fixed 512×512 input moved 98% of operations to the
Neural Engine and cut latency to 18 ms, with about 40% lower energy per frame.

**Senior / FAANG best practice.** Convert in CI with pinned coremltools versions, validate outputs
against the PyTorch model on golden inputs, and profile on the oldest supported device class. Track
compute-unit placement as a release metric. Compress for size and energy, and verify per-slice accuracy
before shipping.

---

## Lecture 157 — TensorFlow Lite for Android: basics

**Why it matters.** LiteRT (the new name for TensorFlow Lite) runs on billions of Android devices. Getting
conversion, delegates, and delivery right matters even more on Android, because hardware varies far more than
on iOS.

**In plain words.** LiteRT is a compact engine that runs a model file on any Android phone. Delegates
are optional turbochargers for each phone's GPU or NPU. If the phone doesn't have the turbo, the engine
still runs on the CPU.

**Architecture: LiteRT on Android.**

```mermaid
flowchart LR
  TF["TF / Keras / JAX"] -->|"TFLiteConverter"| TFL["model.tflite<br/>FP16 or INT8"]
  PTH["PyTorch"] -->|"ai-edge-torch"| TFL
  TFL --> DELIV{"Delivery"}
  DELIV --> ASSET["App assets<br/>(small models)"]
  DELIV --> PLAY["Play Feature Delivery /<br/>on-demand download (large)"]
  ASSET & PLAY --> INT["LiteRT Interpreter / CompiledModel"]
  INT --> GPUD["GPU delegate"]
  INT --> NPUD["NPU delegate<br/>(Qualcomm QNN, MediaTek)"]
  INT --> XNN["XNNPACK CPU (default)"]
```

**How to read it:** models are converted to `.tflite` from TensorFlow, Keras, or JAX, or from PyTorch with
AI Edge Torch, usually with FP16 or INT8 quantization. Small models ship in the app's assets, and large
ones are delivered on demand. At runtime, the interpreter uses the optimized XNNPACK CPU backend by default,
and can hand supported operations to a GPU or vendor NPU delegate.

**Terms in this diagram.**
- **Keras, JAX**: Keras is TensorFlow's high-level model API. JAX is Google's numerical library for high-performance
  machine learning.
- **TFLiteConverter**: the TensorFlow API that writes a `.tflite` file, optionally quantized.
- **ai-edge-torch**: Google's converter from PyTorch models straight to `.tflite`.
- **App assets**: files packaged inside the Android app (APK or AAB).
- **Play Feature Delivery**: a Google Play feature that downloads parts of an app, such as a large model, only when
  needed.
- **LiteRT Interpreter / CompiledModel**: the classic **Interpreter** API runs a model step by step. The newer
  **CompiledModel** API prepares it once for the chosen hardware accelerator.
- **Delegate**: a plug-in that takes over supported operations and runs them on other hardware, such as the GPU or an
  NPU.
- **Qualcomm QNN, MediaTek**: NPU delegates from the two largest Android chip makers. **QNN** is Qualcomm's AI Engine
  Direct.
- **XNNPACK**: Google's highly optimized CPU library and LiteRT's default backend.

**Terms in this diagram.**
- **TF / Keras / JAX**: TensorFlow, its high-level API Keras, and Google's JAX numerical library.
- **TFLiteConverter**: TensorFlow's converter that writes a `.tflite` file, optionally quantized.
- **ai-edge-torch**: Google's converter from PyTorch models directly to `.tflite`.
- **App assets**: files packed inside the Android app (APK or app bundle).
- **Play Feature Delivery**: a Google Play feature that downloads large parts of an app, such as a big model, only
  when needed.
- **Interpreter / CompiledModel**: LiteRT's two APIs for running a model. **CompiledModel** is the newer one, which
  prepares the model for the chosen accelerator ahead of time.
- **Delegate**: a plug-in that runs supported operations on specific hardware: the **GPU delegate**, an **NPU
  delegate** from the chip vendor (Qualcomm's **QNN**, or **MediaTek**'s NeuroPilot), or **XNNPACK**, the optimized CPU
  library used by default.

**Core ideas.**

```python
import tensorflow as tf
conv = tf.lite.TFLiteConverter.from_keras_model(model)
conv.optimizations = [tf.lite.Optimize.DEFAULT]
def rep():                                  # representative data for full INT8
    for x in calib_images[:300]: yield [x[None].astype("float32")]
conv.representative_dataset = rep
conv.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
conv.inference_input_type = conv.inference_output_type = tf.uint8
open("model_int8.tflite", "wb").write(conv.convert())
```

| Delegate | Good for | Note |
|---|---|---|
| XNNPACK (CPU) | Default, everywhere | Fast INT8 and FP32. Set threads to 2–4 |
| GPU | FP16 vision models | Big speedups for convolutions. Some ops unsupported |
| NNAPI | Legacy NPU access | Deprecated as of Android 15. Prefer vendor delegates or the LiteRT NPU path |
| Vendor NPU (Qualcomm QNN, MediaTek NeuroPilot) | Highest efficiency on supported chips | Device-specific, so test per chipset |

- **Device fragmentation:** keep a device-tier list (flagship, mid, low), and test models on real devices from
  each, for example through Firebase Test Lab or a device farm.
- **Model updates without app updates:** download versioned model files, verify their hash and signature,
  and fall back to the bundled model.
- **MediaPipe Tasks** offers ready pipelines (object detection, segmentation, LLM inference) on top of
  LiteRT.

**Example: GPU delegate gains, and one bad device.** A photo-filter model took 120 ms on the CPU and 22 ms with
the GPU delegate on most phones. On one popular mid-range chipset, the GPU delegate produced corrupted output
because of a driver bug. The team added an output sanity check on first run (comparing with the CPU on a test
image), plus a remote config to denylist the delegate per chipset, and fixed it without an app release.

**Senior / FAANG best practice.** On Android, assume heterogeneity: per-chipset delegate allow and deny lists via
remote config, first-run self-tests, CPU fallback, and telemetry of latency per device model. Deliver
models separately from app releases, with signatures and staged rollouts. Keep INT8 and FP16 variants for
different delegates.

---

## Lecture 158 — Deploying on-device NLP models

**Why it matters.** Text features (autocomplete, smart replies, summaries, translation, assistants)
increasingly run on the device, from small classifiers to multi-billion-parameter language models. Their
memory and speed limits shape what's possible.

**In plain words.** A phone can carry a small, quick-witted assistant who handles everyday questions.
For a 300-page report, you still call the specialist in the cloud.

**Architecture: an on-device LLM stack.**

```mermaid
flowchart LR
  APP["App feature<br/>e.g. summarize a message thread"] --> TOK["Tokenizer on device<br/>(SentencePiece / BPE)"]
  TOK --> RT["Runtime: MediaPipe LLM / LiteRT-LM,<br/>ExecuTorch, MLC LLM, llama.cpp, Core ML"]
  RT --> W[("Weights: 1-4B params,<br/>INT4, 0.6-2.2 GB")]
  RT --> KV[("KV cache<br/>grows with context")]
  RT --> ACC["NPU / GPU"]
  RT --> OUT["Streamed tokens<br/>10-40 tokens/s"]
  LORA["Small task adapters (LoRA)"] -.-> RT
```

**How to read it:** text is tokenized on the device, then a runtime runs a 4-bit quantized model of a few
billion parameters on the GPU or NPU, streaming tokens back. Memory goes to the weights plus a KV cache
that grows with context length. Small adapters (LoRA) can specialize one base model for several features,
without shipping several full models.

**Terms in this diagram.**
- **Tokenizer, SentencePiece / BPE**: splits text into **tokens** (word pieces) and maps them to numbers.
  **SentencePiece** is a common tokenizer library, and **BPE** (byte-pair encoding) is a common method for building
  the token vocabulary (Section 25).
- **MediaPipe LLM / LiteRT-LM, ExecuTorch, MLC LLM, llama.cpp**: on-device LLM runtimes. **MediaPipe LLM Inference**
  and **LiteRT-LM** are Google's, **ExecuTorch** is PyTorch's, **MLC LLM** compiles models for phone GPUs, and
  **llama.cpp** is a popular C++ runtime for quantized models.
- **1-4B params, INT4, 0.6-2.2 GB**: models with 1 to 4 billion parameters, each stored in 4 bits (half a byte), so
  the weights take roughly 0.6 to 2.2 GB.
- **KV cache, grows with context**: the attention keys and values stored for every token so far. A longer
  conversation or document uses more memory (Section 25).
- **Streamed tokens, 10-40 tokens/s**: the answer appears word by word as it's generated, at a typical phone speed.
- **LoRA**: low-rank adaptation, small add-on weight matrices of a few megabytes that specialize the model for one
  task (Section 15).

**Terms in this diagram.**
- **Tokenizer (SentencePiece / BPE)**: splits text into **tokens**, the word pieces a language model reads.
  **BPE** (byte-pair encoding) and **SentencePiece** are the common algorithms (Section 28).
- **MediaPipe LLM / LiteRT-LM, ExecuTorch, MLC LLM, llama.cpp, Core ML**: on-device LLM runtimes. **MediaPipe LLM
  Inference** and **LiteRT-LM** are Google's. **ExecuTorch** is PyTorch's. **MLC LLM** compiles models for many phone
  GPUs. **llama.cpp** is a popular C++ runtime for quantized LLMs (GGUF files). **Core ML** is Apple's.
- **1-4B params, INT4, 0.6-2.2 GB**: models of 1 to 4 billion parameters. Stored as **INT4** (4 bits, half a byte, per
  weight), they take roughly 0.6 to 2.2 GB, which fits in a phone's memory alongside other apps.
- **KV cache, grows with context**: the stored attention keys and values for every token so far. Longer
  conversations (more **context**) need more memory (Section 25).
- **10-40 tokens/s**: a typical phone generation speed, roughly as fast as people read.
- **LoRA**: low-rank adaptation, small add-on weights (a few megabytes) that teach the base model one task, such as
  summarizing or proofreading.

**Core ideas.**

| Model class | Size | Typical use | Memory (approx.) |
|---|---|---|---|
| Small classifiers / encoders (MobileBERT, DistilBERT) | 15–70M params | Intent, toxicity, spam, embeddings | 20–100 MB |
| On-device ASR / translation | 50–300M | Dictation, live captions | 50–400 MB |
| Small LLMs (Gemma 1B/2B, Llama 3.2 1B/3B, Phi-3-mini, Qwen 0.5–3B) | 0.5–4B | Smart reply, summarization, rewriting | INT4: ~0.35–2.2 GB + KV cache |

**Memory math for a 3B model at INT4:** 3 × 10⁹ × 0.5 bytes ≈ 1.5 GB of weights, plus ~10% for scales and
embeddings, plus a KV cache. For example, with 28 layers × 2 (K and V) × 8 KV heads × 128 dimensions ×
2 bytes × 4,096 tokens ≈ 470 MB. So a 3B model needs ~2–2.5 GB, which is only realistic on phones with
8 GB of RAM or more.

- **Speed:** decoding is memory-bandwidth-bound (Section 25). Phones with ~50–80 GB/s of memory bandwidth
  produce roughly 10–40 tokens/s for 1–3B INT4 models. Prefill (reading the prompt) is faster per token.
- **Context length** is limited by memory and time to first token. Keep prompts short, and summarize long
  histories.
- **Runtimes:** MediaPipe LLM Inference / LiteRT-LM (Android, iOS, web), ExecuTorch (PyTorch),
  MLC LLM, llama.cpp, and the Core ML / Apple Foundation Models framework on Apple platforms.
- **Quality gates:** evaluate the on-device model on the actual feature tasks, and route to the cloud when
  confidence is low or the task is too complex.

**Example: smart replies on-device.** A messaging app replaced cloud-generated reply suggestions with a 1B
INT4 model plus a task-specific LoRA adapter (~30 MB). On flagship phones it generated 3 suggestions in ~350 ms,
with no message text leaving the device. On phones under 6 GB of RAM, the feature used a 60M-parameter
classifier over a set of 2,000 template replies. Acceptance rates matched the old cloud system.

**Senior / FAANG best practice.** Design device tiers for NLP features (LLM on high-end, small models
on mid, templates or cloud on low), share one base model with adapters across features to save memory and
downloads, and measure quality, latency, memory pressure, and battery per tier. Keep a cloud fallback
with explicit consent rules for tasks beyond the device.

---

## Lecture 159 — Power management in mobile AI

**Why it matters.** Users uninstall apps that drain the battery or heat the phone. AI features can be the
most power-hungry part of an app, so energy has to be designed for, measured, and budgeted like latency.

**In plain words.** Running a model is like running a kettle. A big kettle boiling for a short time can use
less energy than a small one simmering all day. What matters is the total energy: power multiplied by
time.

**Architecture: where mobile AI energy goes, and how to cut it.**

```mermaid
flowchart TB
  E["Energy per feature use"] --> C1["Compute: which unit<br/>NPU much more efficient than CPU"]
  E --> C2["Memory traffic:<br/>weights + activations moved"]
  E --> C3["Sensors: camera, mic, GPS on"]
  E --> C4["Radio: network calls"]
  C1 --> F1["Run on NPU, quantize, smaller model"]
  C2 --> F2["INT8/INT4, fewer passes, caching"]
  C3 --> F3["Lower frame rate, trigger-based capture"]
  C4 --> F4["On-device first, batch uploads,<br/>Wi-Fi + charging for big jobs"]
```

**How to read it:** energy goes to compute (heavily dependent on which processing unit runs the model),
memory traffic (moving weights is expensive), sensors such as the camera, and the radio. Each has its own
fixes: run on the NPU with quantized models, reduce data movement, capture less often, and defer network work to
when the phone is charging on Wi-Fi.

In the diagram, **memory traffic** is the data moved between the phone's RAM and its processors. Reading a weight
from RAM can cost more energy than the math done with it, so smaller (**INT8/INT4**) weights save power. **Activations**
are the intermediate values between layers. **Fewer passes** means running the model less often, for example once
per second instead of every frame. **Trigger-based capture** turns the camera or microphone on only after a cheap
signal, such as motion or a wake word. **Batch uploads** group many small network calls into one, so the radio wakes
up less often.

**Core ideas.**

| Technique | Effect |
|---|---|
| Use the NPU instead of the CPU | Often 5–10× less energy per inference |
| Quantize (INT8/INT4) | Less memory traffic and faster, so less energy |
| Lower frame rates and resolution for camera AI | Linear savings in compute and sensor power |
| Event-triggered inference | Run only when something changes (motion, a wake word) |
| Batch background work | WorkManager (Android) and BGTaskScheduler (iOS) with constraints: charging, unmetered network, idle |
| Thermal awareness | React to thermal state (`ProcessInfo.thermalState`, Android `PowerManager` thermal status) by reducing quality or frequency |
| Cache results | Don't recompute embeddings or classifications for unchanged content |

- **Measure energy, not just latency:** Xcode Instruments (Energy Log, Power Profiler), Android Studio
  Power Profiler and Perfetto power rails on supported devices, and battery-drain tests over 30–60 minutes.
- **Sustained vs burst:** short benchmarks hide thermal throttling. Test the real usage pattern (for example, a
  10-minute video call with background blur).

**Example: background blur that drained batteries.** A video-call app's background segmentation ran at
30 fps on the GPU, and phones got hot within 8 minutes, then throttled. Moving the model to the NPU, running
segmentation at 15 fps with temporal smoothing between frames, and lowering the mask resolution cut feature
power by ~60%. Calls stayed cool, with no visible quality difference.

**Senior / FAANG best practice.** Give every AI feature an energy budget (for example, under 3% of battery per hour of
use) measured in CI on reference devices, adapt quality to thermal and battery state at runtime, and schedule
heavy work (indexing photos, re-embedding, model downloads) for charging and Wi-Fi. Platform teams at big
companies run battery-regression dashboards per release.

---

## Lecture 160 — Privacy considerations for on-device AI

**Why it matters.** On-device AI is often sold as "private", but that's only true if the whole system is
designed for it: telemetry, model updates, cloud fallbacks, and what the model itself can leak. Privacy is
also a regulatory and app-store requirement.

**In plain words.** Keeping your diary at home is more private than mailing it out, unless you also send
the neighbors a daily summary of what you wrote. On-device AI must keep both the diary *and* the summaries
private.

**Architecture: privacy controls across the on-device lifecycle.**

```mermaid
flowchart LR
  DATA["User data on device"] --> INF["On-device inference<br/>no upload by default"]
  INF --> TEL["Telemetry: aggregate counts,<br/>no content, differential privacy"]
  DATA --> FL["Federated learning:<br/>train locally, send clipped + noised updates"]
  FL --> SA["Secure aggregation on server<br/>sees only the sum"]
  INF -->|"explicit consent,<br/>minimal data"| CLOUD["Cloud fallback:<br/>no retention, attested servers"]
  KEY["Secure Enclave / Keystore:<br/>keys, encrypted model + data"] -.-> INF & DATA
```

**How to read it:** inference runs locally, and nothing is uploaded by default. Telemetry contains
aggregated, content-free metrics, often protected by differential privacy. Model improvement can use federated
learning: devices train on local data and send only clipped, noised updates, which a server combines without
seeing individual contributions. Any cloud fallback requires consent, sends the minimum, and runs on servers
that keep nothing. Hardware key storage protects models and data at rest.

**Terms in this diagram.**
- **Telemetry**: usage and performance data the app sends back.
- **Differential privacy**: adding carefully calibrated random noise to statistics, so the result is useful in
  aggregate but provably reveals almost nothing about any single user.
- **Federated learning, clipped + noised updates**: each phone trains on its own data and sends only a weight update.
  **Clipping** limits how much one user's update can change the model, and **noise** hides individual contributions.
- **Secure aggregation**: a cryptographic protocol where the server can only decrypt the *sum* of many phones'
  updates, never one phone's update.
- **No retention, attested servers**: the cloud deletes the request after answering. **Attested** means the server
  cryptographically proves which audited software it runs, before the phone sends data (as in Apple's Private Cloud
  Compute).
- **Secure Enclave / Keystore**: hardware-protected key storage on iPhones (Secure Enclave) and Android (Keystore),
  used to encrypt models and user data on the device.

**Core ideas.**

| Risk | Control |
|---|---|
| Telemetry leaks content | Log only counts, latencies, and error codes. Apply local differential privacy for usage stats |
| Training on user data | Federated learning + secure aggregation + differential privacy (Gboard uses this) |
| Model memorization | DP training, data minimization, deduplication. Don't train on secrets |
| Model theft from the app package | Encryption (Core ML model encryption, encrypted assets plus Keystore keys), server-side for valuable models |
| Cloud fallback exposure | Explicit consent, minimal payloads, no retention, attested environments (Apple Private Cloud Compute) |
| Personalization data | Stored encrypted on device, deleted with the account, excluded from backups if sensitive |
| Regulation and store rules | GDPR and CCPA, App Store privacy labels, Google Play Data safety section, children's data rules |

- **Prompt and output logs** from on-device LLM features are sensitive. Default to no logging, or opt-in only.
- **On-device doesn't remove the need for safety:** content filters and abuse protections run locally too.

**Example: telemetry that wasn't anonymous.** An on-device keyboard model reported "top predicted words"
per user for quality monitoring. It was intended as aggregate data, but the payload included rare words,
which could identify people. The team switched to local differential privacy with frequency estimation over a
fixed vocabulary, and dropped rare tokens entirely. Quality monitoring stayed useful, and the privacy review
passed.

**Senior / FAANG best practice.** Run a privacy review for every on-device AI feature that covers data
flows, telemetry, training, updates, and fallbacks. Use federated learning with secure aggregation and
differential privacy for learning from user data, and design cloud fallbacks with consent, minimization,
and no retention, verified technically (for example by attestation), not just stated in a policy.

---

## Lecture 161 — Lab: build a mobile AI app with TFLite

**Goal:** build an Android app that classifies camera frames on the device with LiteRT (TensorFlow Lite),
compare CPU (XNNPACK) and GPU delegate latency, and add a fallback if the GPU delegate isn't available.

**What you're building.**

```mermaid
flowchart LR
  CAM["CameraX ImageAnalysis<br/>~10 fps, 224x224"] --> BMP["Bitmap to tensor<br/>(TensorImage, uint8)"]
  BMP --> INT["LiteRT Interpreter<br/>mobilenet_v3_int8.tflite"]
  INT --> DEL{"GPU delegate supported?"}
  DEL -->|yes| GPU["GPU"]
  DEL -->|no| CPU["XNNPACK, 4 threads"]
  GPU & CPU --> UI["Top-3 labels + latency on screen"]
```

**In plain words.** You build a small, real Android app that recognizes objects through the camera,
entirely on the phone, and measure how much the phone's GPU helps.

**How to read the diagram:** **CameraX** is Android's camera library, and its **ImageAnalysis** use case delivers
frames to your code, here about 10 per second at 224 by 224 pixels. Each frame, an Android **Bitmap** (an image in
memory), is converted into a tensor of 8-bit values (`TensorImage`, uint8). The LiteRT interpreter runs
`mobilenet_v3_int8.tflite`, an INT8-quantized MobileNetV3 image classifier. The app checks whether the phone's GPU
delegate supports the model. If so it runs there, and otherwise it runs on the CPU with XNNPACK using 4 threads. The
screen shows the 3 most likely labels and how many milliseconds each frame took.

### Step 1 — Create the project and add dependencies

In Android Studio, create an "Empty Views Activity" project in Kotlin with minimum SDK 26. Then add:

```kotlin
// app/build.gradle.kts
android { androidResources { noCompress += "tflite" } }
dependencies {
    implementation("com.google.ai.edge.litert:litert:1.0.1")
    implementation("com.google.ai.edge.litert:litert-gpu:1.0.1")
    implementation("com.google.ai.edge.litert:litert-support:1.0.1")
    val camerax = "1.3.4"
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.camera:camera-view:$camerax")
}
```

Put `mobilenet_v3_int8.tflite` (converted as in Lecture 157, or downloaded from Kaggle Models) and
`labels.txt` into `app/src/main/assets/`.

### Step 2 — The classifier

```kotlin
class Classifier(ctx: Context, useGpu: Boolean) {
    private val labels = FileUtil.loadLabels(ctx, "labels.txt")
    private val gpu = if (useGpu && CompatibilityList().isDelegateSupportedOnThisDevice) GpuDelegate() else null
    val backend = if (gpu != null) "GPU" else "CPU"
    private val interpreter = Interpreter(FileUtil.loadMappedFile(ctx, "mobilenet_v3_int8.tflite"),
        Interpreter.Options().apply { gpu?.let { addDelegate(it) } ?: setNumThreads(4) })
    private val proc = ImageProcessor.Builder().add(ResizeOp(224, 224, ResizeOp.ResizeMethod.BILINEAR)).build()

    fun classify(bmp: Bitmap): Pair<List<Pair<String, Float>>, Long> {
        val img = proc.process(TensorImage(DataType.UINT8).apply { load(bmp) })
        val out = TensorBuffer.createFixedSize(intArrayOf(1, labels.size), DataType.UINT8)
        val t = SystemClock.elapsedRealtimeNanos()
        interpreter.run(img.buffer, out.buffer.rewind())
        val ms = (SystemClock.elapsedRealtimeNanos() - t) / 1_000_000
        val top = out.floatArray.withIndex().sortedByDescending { it.value }.take(3)
            .map { labels[it.index] to it.value / 255f }
        return top to ms
    }
    fun close() { interpreter.close(); gpu?.close() }
}
```

If your model's output is float rather than uint8, create the output buffer as `DataType.FLOAT32`, and skip
the division by 255.

### Step 3 — Wire it to the camera

```kotlin
val analysis = ImageAnalysis.Builder()
    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()
analysis.setAnalyzer(Executors.newSingleThreadExecutor()) { proxy ->
    val (top, ms) = classifier.classify(proxy.toBitmap())
    runOnUiThread { resultView.text = "${classifier.backend} ${ms} ms\n" + top.joinToString("\n") { "${it.first} ${"%.2f".format(it.second)}" } }
    proxy.close()
}
cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
```

Request the `CAMERA` permission at runtime before binding.

### Step 4 — Compare backends and measure

1. Run with `useGpu = false`, point the camera at objects, and note the latency shown.
2. Run with `useGpu = true`, and note the latency and the backend shown (it falls back to CPU if unsupported).
3. Open the Android Studio Profiler (CPU and Energy) for 2 minutes of continuous use with each setting.
4. Optional: benchmark the model file directly with LiteRT's `benchmark_model` tool over `adb`
   (`--use_gpu=true` vs `--num_threads=4`).

**Expected results:**
- **On device:** live top-3 labels (for example `coffee mug 0.82`, `water bottle 0.07`), fully offline (try
  airplane mode).
- **CPU:** on a mid-range phone, the INT8 model takes ~5–15 ms per frame on XNNPACK with 4 threads.
- **GPU:** for an INT8 model, the GPU delegate may not be faster (GPUs prefer FP16). Try an FP16 model to
  see a clear GPU speedup on convolutional models. This is a key lesson: match precision to the accelerator.
- **Fallback:** on unsupported devices, the app shows "CPU" and still works.
- **Energy:** the profiler shows lower CPU usage and energy with the faster backend, and further savings with
  a lower analysis frame rate.

---

## Practice test — AI infrastructure foundations and production systems

**Format:** 30 questions covering Sections 1–23, in roughly 60 minutes. Answer each one in a few sentences
before opening the answer. Score 1 point per question: **24+ is ready to continue**, 18–23 means review the
sections noted, and under 18 means revisit those parts before Part VII.

<details><summary>1. (§1) Name the layers of the AI infrastructure stack from hardware to application.</summary>
Hardware (GPUs, CPUs, networking, storage), then the OS and drivers (Linux, CUDA), then containers and
orchestration (Docker, Kubernetes), then data and ML platforms (pipelines, feature stores, training,
registry), then serving and observability, then applications. Security and cost management span all layers.
</details>

<details><summary>2. (§2) A training job's GPUs show 30% utilization and `top` shows one CPU core at 100%. What's the likely cause and fix?</summary>
The data loader is CPU-bound in a single process. Increase DataLoader workers, use faster decoding, pin
memory, and preprocess ahead of time or on the GPU.
</details>

<details><summary>3. (§3) Why are GPU instances often unavailable in a region, and what do you do about it?</summary>
Capacity is limited, and quotas are low by default. Request quota increases early, use capacity reservations
or commitments, spread across zones and regions, and design for spot or other instance types.
</details>

<details><summary>4. (§4) Why ship images by digest rather than by tag?</summary>
Tags can be moved, so the same tag can point to different contents. A digest is immutable, so what was tested
and signed is exactly what runs.
</details>

<details><summary>5. (§5) What's the difference between a Deployment and a StatefulSet, and which does a vector DB need?</summary>
Deployments manage interchangeable stateless pods. StatefulSets give stable identities and per-pod
persistent volumes. A self-hosted vector DB with local data needs a StatefulSet (or an operator).
</details>

<details><summary>6. (§6) How do you make a data ingestion job safe to re-run after a crash?</summary>
Make it idempotent: a manifest of processed files (by hash), upserts with a deterministic key and
a "newer wins" rule, one transaction per unit of work, and quarantine for bad records.
</details>

<details><summary>7. (§7) Estimate the GPU memory needed to serve an 8B model in BF16 with a modest KV cache.</summary>
Weights are 8B × 2 bytes ≈ 16 GB, plus KV cache (a few GB, depending on batch and context) plus ~10% overhead. So roughly
20–40 GB: one 40–80 GB GPU, or a 24 GB GPU with a small batch and context, or quantization.
</details>

<details><summary>8. (§8) With 64 GPUs, a micro-batch of 8, and a target global batch of 2,048, what gradient accumulation do you need?</summary>
64 × 8 = 512 per step, so 2,048 ÷ 512 = 4 accumulation steps.
</details>

<details><summary>9. (§9) What must an experiment record contain for a model to be reproducible?</summary>
Code version (commit, and whether the tree was dirty), data version (URI plus hash), parameters and seeds, environment
(image or dependencies), metrics, and artifact hashes.
</details>

<details><summary>10. (§10) Why compare a candidate model with the champion using a noise margin?</summary>
Small metric differences can be sampling noise. A margin (for example, about 2 standard errors) prevents
promoting models that aren't really better, and blocking ones that aren't really worse.
</details>

<details><summary>11. (§11) How do you keep CPU pods off expensive GPU nodes?</summary>
Taint the GPU nodes (for example `nvidia.com/gpu=present:NoSchedule`), so only pods with matching tolerations,
and GPU requests, are scheduled there.
</details>

<details><summary>12. (§12) A team's GPU bill doubled overnight. What are your first three steps?</summary>
Break down cost by service, team, and tag to find the growth. Find the resources behind it (idle notebooks,
a runaway job, a NAT gateway or egress). Contain them (scale down, stop), then add budgets, anomaly alerts,
and ownership tags.
</details>

<details><summary>13. (§13) Why must GPU training fabrics be non-blocking, and how do you verify one?</summary>
All-reduce makes every node send at full speed at once, so oversubscription cuts per-GPU bandwidth directly.
Verify with nccl-tests bus bandwidth across nodes, and link-level tests.
</details>

<details><summary>14. (§13) Why is round-robin load balancing a poor fit for LLM inference?</summary>
Request costs vary hugely (output length). Round robin ignores load, so queues build behind long requests.
Use least outstanding requests, queue- or KV-aware routing.
</details>

<details><summary>15. (§14) What's the difference between liveness and readiness probes for a model server?</summary>
Liveness restarts a stuck process. Readiness removes a pod from traffic until the model has loaded and warmed
up. A startup probe protects slow model loads.
</details>

<details><summary>16. (§14) Which API schema changes are breaking?</summary>
Removing a field, changing a type, making a field required, or narrowing an allowed range. Adding optional
fields is safe.
</details>

<details><summary>17. (§15) Triton shows high queue time and low compute time. What do you change?</summary>
Add model instances, or tune or enable dynamic batching. If the GPU is saturated, add replicas or GPUs.
</details>

<details><summary>18. (§15) What must a result-cache key include?</summary>
The model version, the normalized input, and the tenant or user scope that affects the answer or access.
</details>

<details><summary>19. (§16) Why is DCGM SM activity a better efficiency metric than nvidia-smi utilization?</summary>
Utilization only means "a kernel was running". SM activity measures how much of the compute units were
actually busy.
</details>

<details><summary>20. (§16) What do `for` and `keep_firing_for` do in alert rules?</summary>
`for` requires the condition to hold for a duration before firing, which filters spikes. `keep_firing_for`
holds the alert through brief dips, so one incident doesn't page twice.
</details>

<details><summary>21. (§17) A feature's null rate jumps from 2% to 31%. Drift or not, and what do you do?</summary>
It's a data-quality incident. Page data on-call, fix the source, fall back if predictions are harmed, and keep
the bad rows out of training.
</details>

<details><summary>22. (§17) Compute the PSI contribution of one bin with reference 10% and current 25%.</summary>
(0.25 − 0.10) × ln(0.25 ÷ 0.10) = 0.15 × 0.916 ≈ 0.137.
</details>

<details><summary>23. (§18) Why is `iam:PassRole` on `*` dangerous?</summary>
It allows attaching any role, including an admin role, to compute the principal launches, which is privilege
escalation.
</details>

<details><summary>24. (§18) How do you isolate tenants in a RAG system?</summary>
Tag chunks with tenant and ACLs, and enforce filters inside the retrieval query from the authenticated
identity (never from the prompt). Test cross-tenant retrieval in CI.
</details>

<details><summary>25. (§19) Two independent regions each have 99.9% availability. What's the combined availability if failover works?</summary>
1 − (0.001)² = 99.9999%.
</details>

<details><summary>26. (§19) In an outage, why roll back before finding the root cause?</summary>
Rollback is fast and reversible, and it fixes most change-induced outages. Diagnosis continues once users are safe.
</details>

<details><summary>27. (§20) Define RTO and RPO, and name what usually breaks AI DR plans.</summary>
RTO is the maximum downtime, and RPO is the maximum data loss in time. GPU capacity in the DR site and rebuilding
derived data (vector indexes) usually break them.
</details>

<details><summary>28. (§21) Give four reasons to run inference at the edge.</summary>
Latency, bandwidth and cost (send events, not video), privacy and regulation, and offline or WAN-independent
operation.
</details>

<details><summary>29. (§22) Why does unstructured pruning rarely speed up GPU inference?</summary>
Dense kernels still compute the zeros. Use structured pruning, 2:4 sparsity on supported GPUs, or smaller
architectures.
</details>

<details><summary>30. (§23) A 3B model at INT4 with a 4K context: roughly how much memory does it need on a phone?</summary>
Weights ≈ 1.5 GB (+10%), plus a KV cache of a few hundred MB, so ≈ 2–2.5 GB. Realistic only on phones with 8 GB+
of RAM.
</details>

**Review map:** questions 1–5 → Part I · 6–8 → Part II · 9–12 → Part III · 13–18 → Part IV · 19–27 → Part V · 28–30 → Part VI.

---

## FAANG deep-dive notes

**How big tech does it.** Platform owners co-design chips, OS frameworks, and models: on-device foundation
models with adapters per feature, aggressive compression (2–4 bits per weight), strict privacy architecture
(on-device by default, attested private cloud for overflow), and federated learning with secure aggregation
and differential privacy. App companies maintain device tiers, model delivery separate from app releases,
per-chipset delegate configuration, battery-regression testing, and hybrid on-device and cloud routing with
quality gates.

**Staff review questions.**
- Which device tiers get which model, and what happens on the lowest tier?
- What's the energy budget for this feature, and how is it tested per release?
- What data leaves the device: telemetry, training signals, fallback requests? Under what consent?
- How are models updated without app releases, and how do we roll back?

**Interview question.** "Design an on-device photo search feature for a phone gallery app."

**Typical system-design prompt:** *Add natural-language photo search ("dog on the beach") to a gallery app
with 30 million users. Photos must not leave the device by default, and the feature must work offline.*

**1. Clarify first:** What's the device range (oldest supported phone, RAM)? Typical library size (photos per
user)? Index freshness expectations? Languages? Is there a cloud backup product to integrate with, with consent?

**2. Back-of-envelope sizing:**
- Library of 10,000 photos per user. An image encoder (CLIP-like, INT8, ~80 MB) on the NPU at ~15 ms per photo means
  ~150 s of compute for the initial index. Run it while charging, in background batches.
- Embeddings: 10,000 × 512 dimensions × 1 byte (INT8) = 5 MB per user. Brute-force search over 10,000 vectors takes
  under 10 ms on device.
- Text encoder ~40 MB. Query latency ≈ 10 ms (encode) + 5 ms (search) + UI.
- Model downloads: 120 MB × 30M users = 3.6 PB of delivery. Stage it, use delta updates, and download on Wi-Fi.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Where to embed | Cloud | On device | On device for privacy and offline. The cloud only with consent for backed-up libraries |
| When to index | Immediately | Charging + idle | Charging and idle for bulk. Incremental for new photos |
| Model size | Large encoder | Distilled INT8 encoder | Distilled INT8. Measure recall on real queries per tier |
| Model delivery | In the app bundle | On demand | On demand for big models, with signatures and rollback |
| Low-end devices | Same model | Smaller model or a cloud opt-in | Tiered models, honest feature gating |

**4. Follow-up questions with crisp answers:**
- *How do you improve the model without collecting photos?* Federated evaluation and learning on devices with
  secure aggregation and differential privacy, plus licensed or synthetic data in the cloud.
- *How do you keep indexing from draining the battery?* Schedule with charging and idle constraints, use the NPU
  with INT8, process incrementally, and pause on thermal pressure.
- *How do you update the embedding model?* Version the embeddings with the model, re-embed in the background on
  charge, and keep the old index until the new one is complete.

**Debug this (common onsite question):** "After an app update, battery complaints spike on some Android phones."
1. Segment telemetry by device: the spike is concentrated on two chipsets.
2. Compare per-device latency telemetry: on those chipsets, the new model version falls back from the NPU
   delegate to the CPU (an unsupported operation added in the new model).
3. The background indexer runs on the CPU, ~8× longer, so devices stay awake and warm.
4. Fix: denylist the new model per chipset via remote config and serve the previous model, add a delegate
   coverage check in CI on those chipsets, and gate rollouts on per-device energy telemetry.

The lesson: on mobile, a model change can silently change which hardware runs it. Test placement per
chipset, and monitor energy and latency per device tier.

**5. What separates senior from staff answers:** a senior engineer converts, compresses, and integrates
models correctly with good fallbacks. A staff engineer designs the device-tier strategy, privacy
architecture, energy budgets, model delivery and rollback, and the hybrid routing and learning loop, so
the feature works for 30 million very different devices.

**Red flags:**
- One model for all devices.
- Bulk indexing without charging or idle constraints.
- Telemetry with user content.
- Model updates tied to app releases.
- No per-chipset testing on Android.
- A "private" feature with a silent cloud fallback.

---

## Quiz

<details><summary>1. Name three reasons on-device AI is growing.</summary>
Phone NPUs are powerful and everywhere, on-device inference has no per-call server cost, and it gives low
latency, offline operation, and privacy. On-device language models now fit flagship phones.
</details>

<details><summary>2. Why might a Core ML model run on the GPU instead of the Neural Engine, and how do you check?</summary>
Unsupported operations, flexible or dynamic shapes, or precision settings can prevent Neural Engine
execution. Check with Xcode's Core ML performance report, and convert with fixed shapes and FP16.
</details>

<details><summary>3. What are LiteRT delegates, and why keep a CPU fallback?</summary>
Delegates run supported operations on the GPU or an NPU. Support and drivers vary by device, so the CPU
(XNNPACK) path guarantees the app still works, and remote config can denylist broken delegates.
</details>

<details><summary>4. Estimate the weight memory of a 1B-parameter model at INT4.</summary>
1 × 10⁹ × 0.5 bytes ≈ 0.5 GB, plus ~10% for scales and embeddings, plus the KV cache at runtime.
</details>

<details><summary>5. Why is on-device LLM decoding usually limited by memory bandwidth?</summary>
Each generated token reads all the weights from memory. Phone memory bandwidth (~50–80 GB/s) divided by the
model size caps tokens per second.
</details>

<details><summary>6. Name three ways to reduce the energy of a mobile AI feature.</summary>
Run on the NPU with quantized models, lower the frame rate or trigger on events, and schedule heavy work for
charging and Wi-Fi. Also cache results, and adapt to thermal state.
</details>

<details><summary>7. What does federated learning with secure aggregation protect?</summary>
Raw data stays on devices, and the server only sees the aggregate of many clipped, noised updates, not any
individual's update.
</details>

<details><summary>8. Why might an INT8 model not run faster with the GPU delegate?</summary>
Mobile GPU delegates are optimized for FP16. INT8 runs efficiently on CPU (XNNPACK) or NPUs, so match the
precision to the accelerator.
</details>

## Failure modes
- One model for every device, making low-end phones slow and hot while high-end phones go underused.
- Neural Engine or NPU fallbacks to CPU or GPU after a model change, unnoticed without per-device telemetry.
- GPU delegate driver bugs on specific chipsets with no denylist or self-test.
- Background AI work draining batteries (no charging or idle constraints, no thermal handling).
- "Private" features leaking content through telemetry or silent cloud fallbacks.
- Large models shipped inside the app bundle, bloating installs, with no rollback for model updates.

## Checklist
- [ ] You can explain on-device vs cloud vs hybrid for a mobile feature, with device tiers
- [ ] You can convert a PyTorch model to Core ML, compress it, and check compute-unit placement
- [ ] You can convert to LiteRT (FP16 and INT8), and use delegates with a CPU fallback
- [ ] You can estimate memory and tokens per second for an on-device LLM
- [ ] Your AI features have energy budgets, background constraints, and thermal adaptation
- [ ] Your on-device features have a privacy design for telemetry, learning, updates, and fallbacks
- [ ] You built the Android LiteRT app and compared CPU and GPU backends
- [ ] You scored 24+ on the practice test, or reviewed the sections it pointed to
