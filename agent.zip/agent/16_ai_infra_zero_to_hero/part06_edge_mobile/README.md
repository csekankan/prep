# Part VI — Edge and Mobile AI (Sections 21–23, lectures 141–161)

How AI runs outside the data center: on edge boxes, small boards, microcontrollers, and phones. The part
ends with a practice test covering Sections 1–23.

| § | Section | You will be able to | Exercise |
|---|---|---|---|
| 21 | [Edge AI Infrastructure Basics](s21_edge_ai_basics.md) | Decide edge vs cloud with numbers, choose a Jetson, install JetPack, run ONNX Runtime across devices, and deploy YOLOv5 | — |
| 22 | [Optimizing AI for Edge Devices](s22_edge_optimization.md) | Quantize, prune, and distill, compile TensorRT engines (GPU and DLA), run on a Raspberry Pi and microcontrollers, and benchmark correctly | [`s22_quantize_prune.py`](../exercises/s22_quantize_prune.py) |
| 23 | [Mobile AI Infrastructure](s23_mobile_ai.md) | Ship Core ML and LiteRT models, run on-device NLP and small LLMs, manage power, and design for privacy. Includes the practice test | — |

```mermaid
flowchart LR
  P5["Part V: operating<br/>in production"] --> S21["§21 Edge basics<br/>Jetson, JetPack, ONNX"]
  S21 --> S22["§22 Make it fit<br/>quantize, prune, TensorRT, TinyML"]
  S22 --> S23["§23 Phones<br/>Core ML, LiteRT, on-device LLMs"]
  S23 --> PT["Practice test<br/>Sections 1-23"]
  PT --> NEXT["Part VII: AI workloads<br/>LLMs, RAG, agents"]
```

**How to read it:** Section 21 introduces edge hardware and deployment. Section 22 teaches the
optimizations that make models fit small devices. Section 23 applies both to phones, then the practice
test checks everything from Section 1 onward before the course moves to modern AI workloads.
