# Section 21 — Edge AI Infrastructure Basics

> Lectures 141–147 • Assessment: quiz
> **After this section you can:** explain what edge AI is and when it beats the cloud, map edge use cases
> in retail, healthcare, and smart cities, choose an NVIDIA Jetson device, install and verify JetPack,
> reason about edge vs cloud trade-offs with numbers, run models portably with ONNX Runtime, and deploy
> YOLOv5 object detection on a Jetson.
>
> Go deeper: [13 / Lab 94 — Air-gapped architecture](../../13_sovereign_ai_infra_course/07_sovereign_deployment/lab94_air_gapped_architecture.md),
> [Lab 43 — TensorRT-LLM engines](../../13_sovereign_ai_infra_course/04_serving_inference/lab43_tensorrt_llm_engines.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 141 | What is edge AI and why it matters | Run models where data is created: lower latency, less bandwidth, more privacy, works offline |
| 142 | Use cases: retail, healthcare, smart cities | Cameras and sensors that can't stream everything to the cloud |
| 143 | Introduction to NVIDIA Jetson devices | A GPU computer on a module: Orin Nano to AGX Orin to Thor |
| 144 | Installing JetPack SDK on Jetson | One image with Linux, CUDA, cuDNN, TensorRT, and the multimedia stack, matched to the module |
| 145 | Edge vs cloud trade-offs for AI deployment | Decide by latency, bandwidth cost, privacy, connectivity, and fleet operations |
| 146 | ONNX Runtime for edge models | One model format, many accelerators: CPU, CUDA, TensorRT, NNAPI, Core ML |
| 147 | Lab: deploy YOLOv5 on Jetson Nano | Camera to detection at the edge, then TensorRT for several times more FPS |

```mermaid
flowchart LR
  subgraph EDGE["At the edge: store, clinic, street"]
    CAM["Cameras / sensors"] --> DEV["Edge device<br/>Jetson / x86 + GPU / NPU"]
    DEV --> ACT["Local action:<br/>alert, open gate, count"]
  end
  DEV -->|"events + metadata only<br/>(KB, not video)"| CLOUD["Cloud"]
  subgraph CLOUD
    FLEET["Fleet management:<br/>OTA updates, monitoring"]
    TRAIN["Training on sampled data"]
    REG[(Model registry)]
  end
  TRAIN --> REG --> FLEET -->|"signed model + container"| DEV
```

**How to read it:** sensors feed an edge device that runs the model locally and acts immediately. Only
small events and sampled data go to the cloud, not raw video. The cloud trains improved models, stores
them in a registry, and pushes them back to the fleet as signed updates. The edge acts, and the cloud
learns and manages.

**Terms in this diagram.**
- **Edge device: Jetson / x86 + GPU / NPU**: the computer next to the sensors. **Jetson** is NVIDIA's small AI
  computer (Lecture 143). **x86 + GPU** is an ordinary Intel or AMD PC with a graphics card. An **NPU** (neural
  processing unit) is a chip built only for neural-network math, found in many phones and newer laptops.
- **Events + metadata only (KB, not video)**: the device sends short records such as "3 people in queue at 10:02",
  a few kilobytes, instead of gigabytes of video.
- **Fleet management**: managing thousands of devices as one group: inventory, health, and configuration.
- **OTA updates**: over-the-air updates, meaning new software and models are delivered over the network without
  anyone touching the device.
- **Sampled data**: a small, selected portion of inputs sent back for labeling and retraining.
- **Signed model + container**: the update is cryptographically signed, so the device only installs files that
  really came from you (Section 18).

---

## Lecture 141 — What is edge AI and why it matters

**Why it matters.** A growing share of AI runs outside data centers: in cameras, vehicles, factories,
hospitals, and phones. Infrastructure engineers increasingly manage fleets of thousands of small devices
alongside cloud clusters.

**In plain words.** Instead of mailing every photo to a central expert and waiting for an answer, you put
a trained assistant in each shop who looks at things on the spot, and only phones head office about the
interesting cases.

**Architecture: the edge-to-cloud continuum.**

```mermaid
flowchart LR
  D["Device edge<br/>sensor, phone, MCU<br/>mW to W"] --> N["Near edge<br/>Jetson, gateway box in store<br/>10-60 W"]
  N --> R["Regional edge<br/>telco MEC, CDN PoP<br/>servers with GPUs"]
  R --> C["Cloud region<br/>GPU clusters"]
  D -.->|"latency: <10 ms"| N
  N -.->|"10-30 ms"| R
  R -.->|"30-150 ms"| C
```

**How to read it:** "edge" is a range, not a single place. Compute can sit on the device itself (phones,
microcontrollers), on a nearby box (a Jetson in a store), in a regional site (a telco data center), or in the
cloud. Moving left gives lower latency and keeps data local, but devices get smaller, more numerous, and
harder to manage.

In the diagram, an **MCU** (microcontroller unit) is a tiny chip with kilobytes of memory, as found in thermostats
and wearables. **mW to W** means milliwatts to a few watts of power. A **gateway box** is a small computer in a store
or factory that collects data from local devices. **Telco MEC** (multi-access edge computing) is compute that phone
companies place inside their network, near cell towers. A **CDN PoP** (point of presence) is one of a content
network's many small data centers in cities. The arrows give typical network round-trip latency between levels.

**Core ideas.**

| Driver | Why the edge helps | Example |
|---|---|---|
| Latency | No round trip to the cloud | A robot arm stopping within 10 ms |
| Bandwidth and cost | Send events, not raw streams | 50 cameras × 4 Mb/s = 200 Mb/s per store, which can't go to the cloud economically |
| Privacy and regulation | Raw data never leaves the site | Patient video stays in the hospital |
| Offline operation | Works when the network is down | A ship, a mine, or a rural clinic |
| Reliability | No dependency on WAN links | Checkout keeps working during an outage |

- **Edge constraints:** limited compute and memory, power and heat limits, physical exposure (theft,
  tampering), unreliable networks, and *fleet scale*: thousands of devices to update and monitor.
- **Typical edge models:** object detection (YOLO, SSD), classification, segmentation, pose,
  speech-to-text, anomaly detection on sensor data, and increasingly small language and vision-language
  models (1–8B parameters, quantized).

**Example: a store doesn't stream video.** A retailer wanted shelf-gap detection across 800 stores with
20 cameras each. Streaming all video to the cloud would be ~800 × 20 × 3 Mb/s ≈ 48 Gb/s, at very high cost.
A Jetson per store ran detection locally and sent ~2 KB events ("shelf 14B empty, 0.91") a few hundred times
a day. Cloud costs became negligible, alerts arrived in about a second, and video never left the store.

**Senior / FAANG best practice.** Treat edge as a fleet-management problem first and a model problem
second: device identity, signed over-the-air updates, staged rollouts, remote monitoring, and a plan for
devices that are offline for days. Decide where each stage runs (device, store, region, cloud) from
latency, bandwidth, and privacy requirements, not from habit.

---

## Lecture 142 — Use cases: retail, healthcare, smart cities

**Why it matters.** Use cases set the requirements: frame rate, accuracy, latency, privacy, power, and
uptime. Knowing the common patterns helps you size hardware and design pipelines quickly.

**In plain words.** The same camera can count shoppers, watch a patient for falls, or monitor a busy
crossing. What changes is how fast it must react, how private the images are, and what happens if it's
wrong.

**Architecture: a typical edge video analytics pipeline.**

```mermaid
flowchart LR
  CAM["RTSP cameras<br/>1080p 15-30 fps"] --> DEC["Hardware video decode<br/>NVDEC"]
  DEC --> PRE["Resize + normalize<br/>on GPU"]
  PRE --> DET["Detector<br/>YOLO / SSD, TensorRT"]
  DET --> TRK["Tracker<br/>IOU / DeepSORT / ByteTrack"]
  TRK --> RULES["Business rules:<br/>zones, dwell time, counts"]
  RULES --> EVT["Events to cloud<br/>MQTT / HTTPS"]
  RULES --> LOCAL["Local action / display"]
  DET -.->|"low-confidence samples,<br/>privacy-filtered"| UP["Upload for retraining"]
```

**How to read it:** camera streams are decoded in hardware, preprocessed on the GPU, run through a
detector, and tracked across frames, so the system knows "the same person" over time. Business rules turn
tracks into events (a queue too long, a person fallen), which drive local actions and are sent to the cloud.
Low-confidence samples (with privacy filtering) are uploaded to improve the model. NVIDIA DeepStream
packages this pipeline.

**Terms in this diagram.**
- **RTSP cameras, 1080p 15-30 fps**: **RTSP** (Real-Time Streaming Protocol) is how IP security cameras stream video.
  **1080p** is 1920 by 1080 pixels, and **fps** is frames per second.
- **Hardware video decode, NVDEC**: compressed video (H.264 or H.265) must be decoded into raw frames. **NVDEC** is the
  dedicated decoder on NVIDIA chips, which does this without using the GPU's compute cores or the CPU.
- **Detector: YOLO / SSD, TensorRT**: a model that finds objects and draws boxes around them. **YOLO** (You Only Look
  Once) and **SSD** (Single Shot Detector) are fast detector families, compiled with TensorRT for speed (Section 15).
- **Tracker: IOU / DeepSORT / ByteTrack**: links detections across frames into the same object. **IOU**
  (intersection over union) tracking matches boxes that overlap. **DeepSORT** also compares appearance features.
  **ByteTrack** also uses low-confidence boxes to avoid losing objects.
- **Zones, dwell time**: **zones** are areas drawn on the camera image, such as a checkout lane. **Dwell time** is how
  long an object stays in a zone.
- **MQTT**: a lightweight publish-and-subscribe messaging protocol designed for IoT (internet of things) devices on
  unreliable networks.
- **Privacy-filtered**: faces and license plates are blurred, or images dropped, before anything leaves the site.

**Core ideas.**

| Domain | Use case | Key requirement | Typical model |
|---|---|---|---|
| Retail | Shelf gaps, queue length, self-checkout loss prevention, footfall | Many cameras per store, low cost per store | Detector + tracker |
| Healthcare | Fall detection, patient monitoring, point-of-care ultrasound and imaging assist | Privacy, reliability, regulatory approval (medical device rules) | Pose estimation, segmentation |
| Smart cities | Traffic counting, adaptive signals, parking, incident detection | Outdoor hardware, 24×7, public trust, retention rules | Detector + tracker + classifier |
| Manufacturing | Visual defect inspection, predictive maintenance | Very low miss rate, line speed | Classification, anomaly detection |
| Automotive / robotics | Perception, navigation | Hard real-time, functional safety | Multi-sensor fusion |

- **Privacy by design:** process on the device, blur faces or plates before any upload, send counts
  instead of images, and set short local retention. In the EU, real-time remote biometric identification
  in public spaces is heavily restricted by the AI Act.
- **Throughput sizing:** a stream at 1080p 30 fps × N cameras sets decode and inference load. Many use cases
  are fine at 5–10 fps, which cuts hardware needs 3–6×.

**Example: traffic counting on a budget.** A city wanted vehicle counts at 120 intersections. Instead of
one device per camera, one Jetson Orin NX per intersection handled 4 cameras at 10 fps each with a
TensorRT INT8 detector and a tracker. Only per-minute counts per lane (~1 KB) went to the cloud. No
images were stored, which simplified the privacy assessment and public acceptance.

**Senior / FAANG best practice.** Start from the decision the system supports and its error cost (a missed
fall vs a false alarm), set frame rates and accuracy targets from that, and make privacy controls part of
the pipeline design, not a policy document. Reuse a standard pipeline framework (DeepStream, GStreamer)
across use cases, so the fleet runs one software stack.

---

## Lecture 143 — Introduction to NVIDIA Jetson devices

**Why it matters.** Jetson is the most common platform for GPU-accelerated edge AI. Choosing the right
module (compute, memory, power, price) decides what models you can run and how many streams a device can
handle.

**In plain words.** A Jetson is a small computer with a GPU built in, about the size of a credit card,
using as much power as a light bulb. Bigger modules are like bigger engines: more power, more cost, more
heat.

**Architecture: what's on a Jetson module.**

```mermaid
flowchart TB
  subgraph SOC["Jetson SoC (e.g. Orin)"]
    CPU["Arm CPU cores"] 
    GPU["Ampere GPU<br/>CUDA + Tensor cores"]
    DLA["DLA: deep learning accelerators<br/>(Orin NX / AGX)"]
    PVA["Vision accelerators,<br/>video encode/decode"]
    MEM[("Unified LPDDR5 memory<br/>shared by CPU and GPU")]
  end
  CPU & GPU & DLA & PVA <--> MEM
  CARRIER["Carrier board: USB, Ethernet,<br/>MIPI CSI cameras, M.2 NVMe, GPIO"] --- SOC
```

**How to read it:** the module is a system-on-chip with Arm CPU cores, an NVIDIA GPU with tensor cores,
optional dedicated deep-learning accelerators (DLAs), and hardware video engines, all sharing one pool of
memory. Because CPU and GPU share memory, there's no PCIe copy, but the memory is also the total budget for
the OS, the app, and the model. A carrier board provides the connectors.

**Terms in this diagram.**
- **SoC (Orin)**: a **system-on-chip** puts CPU, GPU, and other processors on one chip. **Orin** is the current
  Jetson generation (Orin Nano, Orin NX, AGX Orin).
- **Arm CPU cores**: power-efficient processor cores using the Arm instruction set, as in phones. Software must be
  built for Arm (`aarch64` or `arm64`), not x86.
- **Ampere GPU, CUDA + Tensor cores**: **Ampere** is the NVIDIA GPU architecture also used in the A100. **CUDA cores**
  do general parallel math, and **Tensor cores** do fast matrix multiplication for neural networks (Section 7).
- **DLA**: a deep learning accelerator, a fixed-function engine that runs supported layers at very low power,
  through TensorRT.
- **Vision accelerators (PVA)**: the programmable vision accelerator, for classic image operations such as filtering
  and feature tracking. Video encode and decode have their own engines too.
- **Unified LPDDR5 memory**: **LPDDR5** is low-power memory, as in phones. **Unified** means the CPU and GPU use the
  same physical memory.
- **PCIe copy**: on a PC, data must cross the PCIe bus from CPU memory into separate GPU memory.
- **Carrier board: USB, Ethernet, MIPI CSI, M.2 NVMe, GPIO**: the board the module plugs into. It provides
  ordinary ports, **MIPI CSI** camera connectors (the ribbon-cable camera interface used in phones), an **M.2** slot
  for an **NVMe** SSD, and **GPIO** (general-purpose input and output) pins for LEDs, buttons, and relays.

**Core ideas.**

| Module | AI performance (sparse INT8) | Memory | Power | Typical use |
|---|---|---|---|---|
| Jetson Nano (2019, end of life) | ~0.5 TFLOPS FP16 | 4 GB | 5–10 W | Learning, simple detection (JetPack 4.6 only) |
| Jetson Orin Nano (Super) | up to ~67 TOPS | 4–8 GB | 7–25 W | Entry production, 1–4 streams |
| Jetson Orin NX | up to ~157 TOPS (Super) | 8–16 GB | 10–40 W | Multi-camera analytics, robotics |
| Jetson AGX Orin | up to 275 TOPS | 32–64 GB | 15–60 W | Many streams, small LLMs and VLMs, autonomous machines |
| Jetson AGX Thor (2025) | Blackwell GPU, ~2,000 FP4 TFLOPS | 128 GB | 40–130 W | Humanoid robots, large on-device models |

- **TOPS are marketing numbers** (sparse INT8, peak). Real throughput depends on the model, precision, and
  memory bandwidth. Benchmark your model (Section 22).
- **Power modes** (`nvpmodel`) trade performance for watts. `jetson_clocks` pins clocks at maximum for
  benchmarking.
- **Developer kits vs production modules:** dev kits for prototyping. Production uses modules on
  industrial carrier boards from partners, with wider temperature ranges and long-term availability.
- **Alternatives:** x86 boxes with small NVIDIA GPUs (L4, RTX), Intel Core Ultra NPUs with OpenVINO,
  Google Coral (Edge TPU), Hailo accelerators, Qualcomm and NXP NPUs, and Apple and Android phones
  (Section 23).

**Example: sizing for 8 cameras.** A warehouse needed 8 cameras at 15 fps with YOLOv8s. On an Orin
Nano 8GB, the TensorRT INT8 engine ran ~110 fps at 640×640, enough for 120 frames per second of demand
with little headroom once tracking and decode were added. The team chose an Orin NX 16GB (~2× the
throughput) to leave room for a second model later, at +$300 per site.

**Senior / FAANG best practice.** Choose hardware by measured throughput of *your* model at *your*
precision and resolution, with 30–50% headroom for model growth and additional features. Standardize
on as few module types as possible across the fleet, because every variant multiplies testing, images, and
spare parts. Check lifecycle availability (production modules are typically supported for 7+ years).

---

## Lecture 144 — Installing JetPack SDK on Jetson

**Why it matters.** On Jetson, the OS, drivers, CUDA, cuDNN, and TensorRT come as one matched bundle,
JetPack. Mismatched versions are the most common source of "it doesn't work" on edge devices, and a fleet
needs one known-good version.

**In plain words.** JetPack is the factory software for the device: operating system, GPU drivers, and
AI libraries that are known to work together, installed as one package. Mixing versions from different
boxes breaks things.

**Architecture: the JetPack software stack.**

```mermaid
flowchart TB
  APP["Your app / container<br/>(l4t-pytorch, DeepStream, Triton)"] --> LIBS
  subgraph LIBS["JetPack components"]
    TRT["TensorRT"] --- CUDNN["cuDNN"] --- CUDA["CUDA toolkit"]
    MM["Multimedia API, GStreamer,<br/>VPI, video codecs"]
    CT["NVIDIA Container Toolkit"]
  end
  LIBS --> L4T["Jetson Linux (L4T)<br/>Ubuntu-based rootfs, kernel, drivers, bootloader"]
  L4T --> HW["Jetson module"]
```

**How to read it:** Jetson Linux (L4T) is the base: an Ubuntu-based OS, kernel, drivers, and bootloader for the
module. JetPack adds the matched AI libraries (CUDA, cuDNN, TensorRT, multimedia, and container support).
Applications usually run in containers built on NVIDIA's L4T base images, which must match the L4T version on the
device.

**Terms in this diagram.**
- **l4t-pytorch, DeepStream, Triton**: ready-made NVIDIA containers. `l4t-pytorch` has PyTorch built for Jetson,
  **DeepStream** is the video analytics toolkit, and **Triton** is the inference server (Section 15).
- **cuDNN**: NVIDIA's library of fast neural-network building blocks, such as convolutions, used by PyTorch and
  TensorRT.
- **CUDA toolkit**: the compiler and libraries for programming NVIDIA GPUs.
- **Multimedia API, GStreamer, VPI, video codecs**: tools for camera capture and video. **GStreamer** is a widely used
  media pipeline framework. **VPI** (Vision Programming Interface) runs image-processing steps on the GPU, PVA, or CPU.
  **Codecs** compress and decompress video.
- **NVIDIA Container Toolkit**: lets Docker containers use the GPU (Section 4).
- **L4T, rootfs, bootloader**: **L4T** (Linux for Tegra, Tegra being NVIDIA's chip family) is Jetson's Linux. The
  **rootfs** (root filesystem) holds the operating system files. The **bootloader** is the first code that runs at
  power-on and starts the kernel.

**Core ideas.**

| JetPack | L4T | Ubuntu | Devices |
|---|---|---|---|
| 4.6.x | 32.7 | 18.04 | Jetson Nano, TX2, Xavier (final release for Nano) |
| 5.1.x | 35.x | 20.04 | Xavier, Orin |
| 6.x | 36.x | 22.04 | Orin family (CUDA 12.x, TensorRT 8.6/10.x) |
| 7.x | 38.x | 24.04 | Thor |

```bash
# Orin dev kits: flash the SD card image, or use SDK Manager / flash scripts for NVMe and production modules
cat /etc/nv_tegra_release                   # L4T version, for example R36 (release), REVISION: 4.x
sudo apt update && sudo apt install nvidia-jetpack   # installs the full JetPack on top of L4T
nvcc --version                              # CUDA
dpkg -l | grep -E "tensorrt|cudnn"          # TensorRT and cuDNN versions
sudo nvpmodel -q && sudo nvpmodel -m 0      # query and set power mode (0 = max on most dev kits)
sudo pip3 install jetson-stats && jtop      # live CPU, GPU, memory, temperature, power
docker run --rm --runtime nvidia nvcr.io/nvidia/l4t-jetpack:r36.4.0 nvidia-smi || true
```

- **Containers must match the L4T major version** (r36 containers on L4T 36). Use NVIDIA's `l4t-*`
  images or the `jetson-containers` project to build matching images.
- **Pip wheels:** standard PyPI `torch` wheels don't include Jetson GPU support. Use NVIDIA's Jetson
  wheels or containers.
- **Production flashing:** use the flash scripts with a customized rootfs (your app, configs, certificates)
  and secure boot (fused keys), so devices boot only signed images.

**Example: the fleet that drifted.** A pilot fleet of 60 devices was set up by hand over six months. They
ended up with 4 JetPack versions, and a new TensorRT engine failed on 22 of them (engines are tied to the
TensorRT version). The team rebuilt a single golden image (JetPack 6, pinned versions, their container
runtime), reflashed everything, and moved app updates to containers deployed over the air.

**Senior / FAANG best practice.** Pin one JetPack version per hardware generation for the fleet, build a
golden image with secure boot and a read-only root filesystem where possible, and ship applications as
containers matched to that L4T version. Build TensorRT engines per JetPack and module type in CI, and
test them on real hardware in a device lab before rollout.

---

## Lecture 145 — Edge vs cloud trade-offs for AI deployment

**Why it matters.** "Run it on the edge" and "send it to the cloud" each have real costs. A clear, numeric
comparison avoids both overbuilt edge fleets and huge cloud bandwidth bills.

**In plain words.** Cooking at home (edge) is fast and private, but you buy and maintain the kitchen.
Ordering delivery (cloud) needs no kitchen, but you wait, pay per meal, and the restaurant sees your order.

**Architecture: the decision and the common hybrid.**

```mermaid
flowchart TB
  Q1{"Latency need < 50 ms<br/>or must work offline?"} -->|yes| EDGE["Edge inference"]
  Q1 -->|no| Q2{"Raw data too big or<br/>too sensitive to send?"}
  Q2 -->|yes| EDGE
  Q2 -->|no| Q3{"Model too big for<br/>affordable edge hardware?"}
  Q3 -->|yes| CLOUD["Cloud inference"]
  Q3 -->|no| Q4{"Fleet ops cost vs<br/>cloud per-call cost?"}
  Q4 -->|"many devices, steady load"| EDGE
  Q4 -->|"few, bursty"| CLOUD
  EDGE --> HYB["Common hybrid: small model at the edge,<br/>escalate hard cases to a big cloud model"]
  CLOUD --> HYB
```

**How to read it:** hard requirements decide first: latency and offline operation push to the edge, as do
data that's too big or too private to send. Models too large for affordable edge hardware push to the cloud.
Otherwise it's an economics question. Many systems end up hybrid: a small model at the edge handles most
cases, and sends uncertain ones to a larger model in the cloud.

In the diagram, **fleet ops cost** is the cost of buying, installing, updating, monitoring, and replacing many
devices, compared with **per-call cost**, what the cloud charges for each prediction. **Steady load** means constant
use, which favors owned edge hardware. **Bursty** load comes in occasional spikes, which favors paying per call.
**Escalate** means send the case on to the bigger model.

**Core ideas.**

| Factor | Edge | Cloud |
|---|---|---|
| Latency | 5–30 ms, deterministic | 50–300 ms + network jitter |
| Bandwidth | Events only | Full inputs (video can be 2–8 Mb/s per camera) |
| Privacy | Data stays on site | Data leaves the site, needs agreements and controls |
| Model size | Limited by device memory (e.g. 8–64 GB) | Practically unlimited |
| Updates | OTA to thousands of devices, some offline | Deploy once |
| Hardware cost | Capex per site, refresh every 4–6 years | Opex per use |
| Monitoring | Remote, intermittent | Centralized |
| Physical risk | Theft, tampering, heat, dust | Provider's responsibility |

**Worked comparison: 500 stores, 10 cameras each, inference at 5 fps.**
- Cloud: 500 × 10 × 2 Mb/s upload = 10 Gb/s sustained, plus GPU inference for 25,000 frames per second, roughly
  30–60 GPUs around the clock, plus store bandwidth upgrades. Likely well over $100,000 a month.
- Edge: 500 × Orin NX (~$900 with enclosure) = $450,000 once, ~15 W each (~$15,000 a year in power), plus fleet
  management. Over 4 years, ~$10,000–15,000 a month equivalent.
- The edge wins clearly here. With 3 sites and occasional analysis, the cloud would win.

**Example: hybrid escalation.** A quality-inspection system ran a small classifier on each line's edge
device. 96% of parts were classified confidently on the device in ~8 ms. The 4% with low confidence were sent
(one image each, ~200 KB) to a larger cloud model and a human review queue. Cloud costs stayed small, and
miss rates dropped 40% compared with the edge model alone.

**Senior / FAANG best practice.** Model the total cost over the hardware's lifetime (devices, power,
bandwidth, fleet operations, cloud inference) and the hard requirements (latency, offline operation,
privacy) explicitly. Design hybrid escalation from the start: an edge model with calibrated confidence, plus a
cloud path for hard cases, which also gives you the training data to improve the edge model.

---

## Lecture 146 — ONNX Runtime for edge models

**Why it matters.** Edge fleets are diverse: Jetsons, x86 boxes, Arm gateways, phones. ONNX gives you one
model file, and ONNX Runtime runs it on each device's best accelerator through execution providers, avoiding
a separate toolchain per platform.

**In plain words.** ONNX is like PDF for models. Whatever program created the document (PyTorch,
TensorFlow, scikit-learn), anyone can open it, and each device uses its own best "reader" (accelerator) to
display it.

**Architecture: ONNX Runtime execution providers.**

```mermaid
flowchart LR
  PT["PyTorch / TF / sklearn"] -->|"export"| ONNX["model.onnx<br/>graph + weights, opset 17+"]
  ONNX --> OPT["Optional: optimize + quantize<br/>onnxruntime.quantization"]
  OPT --> ORT["ONNX Runtime session"]
  ORT --> EP{"Execution provider<br/>(first that supports each op)"}
  EP --> TRT["TensorRT EP (Jetson, NVIDIA GPU)"]
  EP --> CUDA["CUDA EP"]
  EP --> OV["OpenVINO EP (Intel CPU / NPU)"]
  EP --> NN["NNAPI / QNN (Android, Qualcomm)"]
  EP --> CML["Core ML EP (Apple)"]
  EP --> CPU["CPU EP (always available)"]
```

**How to read it:** you export the model once to ONNX, and optionally optimize and quantize it. At
runtime, ONNX Runtime splits the graph across execution providers in your preference order. Operations the
preferred accelerator supports run there, and the rest fall back to the CPU. The same file runs on a Jetson
(TensorRT), an Intel box (OpenVINO), or a phone (NNAPI, Core ML).

**Terms in this diagram.**
- **sklearn**: scikit-learn, the classic Python machine-learning library. Its models export to ONNX with
  `skl2onnx`.
- **Graph + weights, opset 17+**: an ONNX file holds the **graph** (the operations and how they connect) and the
  learned **weights**. The **opset** is the version of the ONNX operator set. Newer opsets support more operations,
  but older runtimes may not load them.
- **onnxruntime.quantization**: ONNX Runtime's module for converting weights and activations to INT8 (Section 22).
- **Session**: a loaded, ready-to-run model in ONNX Runtime.
- **Execution provider (EP)**: a plug-in that runs operations on specific hardware. ONNX Runtime assigns each
  operation to the first provider in your list that supports it.
- **OpenVINO EP**: Intel's toolkit for Intel CPUs, GPUs, and NPUs.
- **NNAPI / QNN**: **NNAPI** is Android's neural network API (now deprecated in favor of vendor runtimes). **QNN** is
  Qualcomm's AI Engine Direct for Snapdragon chips (Section 23).
- **Core ML EP**: uses Apple's Core ML, which runs on the Apple Neural Engine, GPU, or CPU (Section 23).

**Core ideas.**

```python
import numpy as np, onnxruntime as ort
providers = [
    ("TensorrtExecutionProvider", {"trt_fp16_enable": True, "trt_engine_cache_enable": True,
                                   "trt_engine_cache_path": "/var/cache/trt"}),
    "CUDAExecutionProvider",
    "CPUExecutionProvider",
]
sess = ort.InferenceSession("yolov5s.onnx", providers=providers)
print(sess.get_providers())                           # which providers were actually loaded
inp = sess.get_inputs()[0]
out = sess.run(None, {inp.name: np.random.rand(1, 3, 640, 640).astype(np.float32)})
```

```python
# dynamic INT8 quantization for CPU targets (weights only, no calibration data)
from onnxruntime.quantization import quantize_dynamic, QuantType
quantize_dynamic("model.onnx", "model.int8.onnx", weight_type=QuantType.QInt8)
```

- **Check placement:** with verbose logging, ONNX Runtime reports which nodes ran on which provider. Many
  CPU fallbacks in the middle of the graph mean slow copies back and forth.
- **TensorRT EP engine cache:** the first run builds the engine (can take minutes on Jetson). Cache it on
  disk, or prebuild it in CI for each device type.
- **Opset and operator support** vary per provider. Validate the exported model per target with a golden
  input and output comparison.

**Example: one model, three device types.** A logistics company had Jetson Orin NX gateways, Intel NUCs,
and Android handhelds. Exporting the package-label detector once to ONNX and running it with the TensorRT,
OpenVINO, and NNAPI providers replaced three separate conversion pipelines. They measured 9 ms, 21 ms,
and 34 ms per image, and a single CI job validated outputs on all three.

**Senior / FAANG best practice.** Make ONNX (or another portable format) the release artifact of the
training pipeline, with per-target validation (accuracy and latency) in CI on real hardware. Pin
ONNX Runtime and opset versions per device image. For peak performance on a single platform (for example, only
Jetson), compile native TensorRT engines, but keep the ONNX file as the source.

---

## Lecture 147 — Lab: deploy YOLOv5 on Jetson Nano

**Goal:** run YOLOv5 object detection on a Jetson from a USB or CSI camera, measure FPS, then export a
TensorRT FP16 engine and measure again. The steps cover the original Jetson Nano (JetPack 4.6) and the
current Orin Nano (JetPack 6), which is recommended for new projects.

**What you're building.**

```mermaid
flowchart LR
  CAM["USB / CSI camera<br/>or video file"] --> PY["detect.py<br/>YOLOv5s"]
  PY -->|"PyTorch FP32 baseline"| FPS1["FPS: baseline"]
  PT["yolov5s.pt"] -->|"export.py --include engine --half"| ENG["yolov5s.engine<br/>TensorRT FP16"]
  ENG --> PY2["detect.py --weights yolov5s.engine"]
  PY2 --> FPS2["FPS: several times higher"]
  JTOP["jtop: GPU %, power, temperature"] -.-> PY & PY2
```

**In plain words.** You get a real object detector running on a small device, and see how much faster it
gets when compiled for that device's GPU.

**How to read the diagram:** the input is a USB camera, a **CSI** ribbon-cable camera, or a video file. First you run
`detect.py` with **YOLOv5s** (the small version of YOLOv5) in plain PyTorch at **FP32** (32-bit floats), and note the
**FPS** (frames per second) as your baseline. Then `export.py --include engine --half` compiles the weights
`yolov5s.pt` into a TensorRT **engine** in **FP16** (`--half` means half precision, 16-bit). Running `detect.py`
again with that engine typically gives several times the FPS. **jtop** is a Jetson monitoring tool (like `top`)
that shows GPU load, power draw, and temperature while both runs happen.

### Step 1 — Prepare the device

```bash
cat /etc/nv_tegra_release                        # Nano: R32.7.x (JetPack 4.6). Orin: R36.x (JetPack 6)
sudo nvpmodel -m 0 && sudo jetson_clocks         # max performance mode for benchmarking
sudo apt install -y python3-pip libopenblas-dev && sudo pip3 install -U jetson-stats
```

The easiest way to get a working PyTorch is a matching container, for example on Orin with JetPack 6:

```bash
git clone https://github.com/dusty-nv/jetson-containers && bash jetson-containers/install.sh
jetson-containers run $(autotag l4t-pytorch)     # picks a PyTorch image matching your L4T version
```

On a Nano with JetPack 4.6, use NVIDIA's PyTorch 1.10 wheel for Python 3.6, or the `l4t-pytorch:r32.7.1`
container.

### Step 2 — Run YOLOv5 with PyTorch (baseline)

```bash
git clone https://github.com/ultralytics/yolov5 && cd yolov5
pip3 install -r requirements.txt --no-deps && pip3 install seaborn tqdm   # keep the Jetson torch wheel
python3 detect.py --weights yolov5s.pt --source 0 --img 640 --view-img      # USB camera 0
python3 detect.py --weights yolov5s.pt --source data/images --img 640       # or sample images
```

For a CSI camera, use a GStreamer source string:
`--source "nvarguscamerasrc ! video/x-raw(memory:NVMM),width=1280,height=720,framerate=30/1 ! nvvidconv ! video/x-raw,format=BGRx ! videoconvert ! appsink"`.

### Step 3 — Export a TensorRT FP16 engine on the device

```bash
python3 export.py --weights yolov5s.pt --include engine --half --device 0 --img 640
python3 detect.py --weights yolov5s.engine --source 0 --img 640 --half
python3 val.py --weights yolov5s.engine --data coco128.yaml --img 640 --half    # check accuracy
```

Engines must be built **on the same device type and JetPack** they run on. Don't copy an engine from a desktop
GPU.

### Step 4 — Measure and record

```bash
jtop          # in a second terminal: GPU utilization, power (W), temperature
```

Record per configuration: inference time per frame (printed by `detect.py`), end-to-end FPS, power, and
mAP from `val.py`.

| Config | Jetson Nano (rough) | Orin Nano 8GB (rough) |
|---|---|---|
| PyTorch FP32, 640 | ~2–4 FPS | ~15–25 FPS |
| TensorRT FP16, 640 | ~8–12 FPS | ~50–90 FPS |
| TensorRT FP16, 416 | ~15–20 FPS | ~100+ FPS |

**Expected results:**
- Detections (`person`, `car`, `bottle`, ...) drawn on the camera feed or saved images in `runs/detect/`.
- The TensorRT FP16 engine gives roughly 3–5× the PyTorch FPS on the same device, with mAP within about
  1 point of the original.
- On the Nano, the GPU stays near 100% in `jtop`, and power reaches ~10 W in max mode. Reducing the image
  size to 416 roughly doubles FPS for a small accuracy cost.
- You can explain why the engine must be rebuilt for each device type and JetPack version.

---

## FAANG deep-dive notes

**How big tech does it.** Edge fleets (store devices, vehicles, phones, home devices) are managed like
cloud fleets: hardware-backed device identity, secure boot, signed images, staged OTA rollouts with
automatic rollback, and remote telemetry. Models are trained in the cloud, compiled per hardware target in
CI, validated on device labs, and shipped as versioned artifacts. Edge devices send events and selected
samples, not raw streams. Hybrid designs escalate hard cases to cloud models, which also feeds the data
flywheel.

**Staff review questions.**
- What runs on the device, what in the cloud, and why, in latency, bandwidth, and privacy terms?
- How is a bad model update rolled back on a device that's been offline for three days?
- What measured throughput and headroom does the chosen hardware have for this model?
- What data leaves the site, and is it minimized and privacy-filtered?

**Interview question.** "Design a video analytics system for 2,000 retail stores."

**Typical system-design prompt:** *Design shelf-monitoring and queue-detection for 2,000 stores with
15 cameras each. Alerts must reach staff within 5 seconds. Video must not leave stores. Models will be
updated monthly.*

**1. Clarify first:** What frame rate does each use case need? What's the store network (bandwidth,
reliability)? Is there existing in-store hardware? What are the privacy rules (faces, retention)? What's the
budget per store? Who installs and services devices?

**2. Back-of-envelope sizing:**
- Load per store: 15 cameras × 5 fps = 75 inferences/s, plus decode of 15 streams. One Orin NX handles this with
  TensorRT INT8 and headroom.
- Fleet: 2,000 devices × ~$1,000 = $2M capex. Power ~20 W × 2,000 = 40 kW (~$50,000 a year).
- Cloud traffic: events ~500 per store per day × 2 KB = 1 MB per store per day, ~2 GB a day across the fleet, which is
  negligible. Sampled training images: 100 per store per week (blurred) ≈ 2 GB a week.
- Monthly model updates: ~50 MB engine + container delta per device = 100 GB of OTA per month, staged
  over a week.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Inference location | Cloud | Edge | Edge when video can't leave or bandwidth is large |
| Frame rate | 30 fps | 5 fps | The lowest rate that meets the use case. Most retail analytics is fine at 5 fps |
| Model format | Native TensorRT | ONNX + EPs | TensorRT for a single NVIDIA fleet, ONNX for mixed hardware |
| Updates | Push to all | Staged rings with automatic rollback | Rings: lab, 1%, 10%, 100%, with health gates |
| Training data | Upload video | Upload sampled, blurred frames | Sample and anonymize at the edge |

**4. Follow-up questions with crisp answers:**
- *How do you update a model safely on 2,000 devices?* A/B partitions or a container swap with the old version
  kept, staged rings, health and accuracy checks on the device after the update, automatic rollback, and
  resumable downloads for poor networks.
- *How do you monitor edge model accuracy?* Track confidence distributions and event rates per store
  (drift), review sampled frames with humans, and compare with ground truth from store systems (for example,
  restocking logs).
- *Why not use the biggest model that fits?* Headroom is needed for new features, heat, and future models.
  Bigger models also cost power and update bandwidth.

**Debug this (common onsite question):** "After a monthly update, 7% of store devices report half their normal FPS, and alerts are delayed."
1. Segment the affected devices: all are an older carrier board revision with a smaller heatsink, in stores with
   warm back rooms.
2. Telemetry: GPU clocks drop under sustained load, and temperatures sit above 95 °C, so they're thermally
   throttling. The new model is 30% heavier.
3. The lab didn't catch it: device-lab testing ran in a cool room, on the newer board revision.
4. Fix: a lighter power mode and INT8 for those devices, an image built per hardware revision, thermal
   soak tests in the lab, and the rollout ring gated on FPS and temperature telemetry.

The lesson: edge performance depends on the physical environment. Test with real hardware variants and
conditions, and gate rollouts on device telemetry.

**5. What separates senior from staff answers:** a senior engineer can optimize and deploy a model to a
device and pick suitable hardware. A staff engineer designs the fleet as a system: placement decisions
backed by numbers, device identity and secure boot, OTA with rings and rollback, privacy-preserving data
flows, telemetry-driven rollouts, and a data flywheel from edge samples back to training.

**Red flags:**
- Streaming raw video to the cloud by default.
- Hand-configured devices with mixed software versions.
- Engines built on a different device type.
- OTA without staged rollout or rollback.
- No telemetry from devices.
- Choosing hardware from TOPS numbers alone.

---

## Quiz

<details><summary>1. Name four reasons to run AI at the edge.</summary>
Low latency, less bandwidth and cost (events instead of raw streams), privacy and regulation (data stays on
site), and offline or WAN-independent operation.
</details>

<details><summary>2. What does a typical edge video analytics pipeline contain?</summary>
Hardware video decode, GPU preprocessing, a detector, a tracker across frames, business rules that create
events, and local actions plus event upload. Optionally, privacy-filtered sample uploads for retraining.
</details>

<details><summary>3. Why is unified memory on Jetson both an advantage and a constraint?</summary>
The CPU and GPU share it, so there are no PCIe copies. But the OS, application, and model all share the same
limited pool (for example 8 GB).
</details>

<details><summary>4. Why must TensorRT engines be built on the target device type and JetPack version?</summary>
Engines are optimized for a specific GPU architecture and TensorRT version. They aren't portable across
devices or JetPack releases.
</details>

<details><summary>5. What's the relationship between JetPack and L4T?</summary>
L4T (Jetson Linux) is the OS, kernel, drivers, and bootloader. JetPack bundles L4T with matched CUDA, cuDNN,
TensorRT, and multimedia libraries. Containers must match the L4T version.
</details>

<details><summary>6. When does cloud inference beat edge for a camera use case?</summary>
When there are few sites or occasional analysis, the model is too large for affordable edge hardware,
latency and offline needs are relaxed, and the data may leave the site.
</details>

<details><summary>7. What does an ONNX Runtime execution provider do?</summary>
It runs supported parts of the ONNX graph on a specific accelerator (TensorRT, CUDA, OpenVINO, NNAPI, Core ML),
with unsupported operations falling back to the next provider, usually the CPU.
</details>

<details><summary>8. Roughly how much faster is YOLOv5s with TensorRT FP16 than with PyTorch FP32 on a Jetson?</summary>
Typically about 3–5× higher FPS, with mAP within about one point.
</details>

## Failure modes
- Streaming everything to the cloud, then hitting bandwidth and privacy limits.
- Fleets with mixed JetPack and TensorRT versions, where engines fail on some devices.
- Hardware sized from peak TOPS rather than measured model throughput.
- Thermal throttling in real environments that lab tests never saw.
- OTA updates without staged rings, health checks, or rollback.
- No device telemetry, so edge failures go unnoticed for weeks.
- Raw images uploaded for training without anonymization or consent.

## Checklist
- [ ] You can decide edge vs cloud for a use case, with latency, bandwidth, privacy, and cost numbers
- [ ] You can size an edge device from measured throughput, with headroom
- [ ] You can identify JetPack and L4T versions, and run matching containers
- [ ] Your fleet has one golden image per hardware type, secure boot, and OTA with rings and rollback
- [ ] You can run an ONNX model with TensorRT, CUDA, and CPU providers, and check node placement
- [ ] You ran YOLOv5 on a Jetson, built a TensorRT engine, and measured FPS, power, and mAP
