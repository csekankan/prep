# Section 22 — Optimizing AI for Edge Devices

> Lectures 148–154 • Assessment: quiz • Exercise: [`s22_quantize_prune.py`](../exercises/s22_quantize_prune.py)
> **After this section you can:** quantize models (post-training and quantization-aware), prune and compress
> them, compile them with TensorRT for Jetson, run vision models on a Raspberry Pi, deploy TinyML on
> microcontrollers, benchmark edge hardware correctly, and take a model from FP32 to an INT8 TensorRT engine
> with measured speed and accuracy.
>
> Go deeper: [13 / Lab 43 — TensorRT-LLM engines](../../13_sovereign_ai_infra_course/04_serving_inference/lab43_tensorrt_llm_engines.md),
> [Lab 42 — Memory orchestration for inference](../../13_sovereign_ai_infra_course/04_serving_inference/lab42_memory_orchestration_inference.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 148 | Quantization for edge efficiency | INT8 gives 4× smaller and 2–4× faster models. Per-channel scales and calibration keep accuracy |
| 149 | Pruning and model compression basics | Remove weights or channels, distill into smaller students, then fine-tune to recover accuracy |
| 150 | TensorRT for edge inference | Compile per device with FP16/INT8, use the DLA on Orin, and cache engines |
| 151 | Running vision models on Raspberry Pi | CPU-only boards need small models, INT8 TFLite or ONNX, and threads tuned. Add an accelerator for more |
| 152 | TinyML and microcontrollers for AI | Kilobytes of RAM, milliwatts of power: keyword spotting, anomaly detection, LiteRT Micro |
| 153 | Benchmarking models on edge hardware | Measure end to end, warm up, fix power modes, and report latency percentiles, FPS, watts, and accuracy |
| 154 | Lab: optimize a model with TensorRT | FP32 to FP16 to INT8 with calibration, with speed, accuracy, and power compared |

```mermaid
flowchart LR
  FP32["Trained FP32 model"] --> ARCH["Choose an efficient architecture<br/>MobileNet, EfficientNet-Lite, YOLO-n/s"]
  ARCH --> DIST["Distill (optional)<br/>teacher to small student"]
  DIST --> PRUNE["Prune (optional)<br/>structured, then fine-tune"]
  PRUNE --> QUANT["Quantize<br/>FP16, INT8 PTQ, or QAT"]
  QUANT --> COMPILE["Compile per target<br/>TensorRT, TFLite, Core ML, OpenVINO"]
  COMPILE --> BENCH["Benchmark on the device<br/>latency, FPS, W, accuracy"]
  BENCH -->|"meets targets?"| SHIP["Ship"]
  BENCH -->|"no"| ARCH
```

**How to read it:** optimization is a loop. Start with an architecture designed for edge devices
(the biggest win), optionally distill and prune, then quantize, and compile for the exact target. Every
candidate is benchmarked *on the device* for speed, power, and accuracy, and if it misses the targets you go
back and change the model, not just the settings.

**Terms in this diagram.**
- **FP32**: 32-bit floating-point numbers, the default precision models are trained in.
- **MobileNet, EfficientNet-Lite, YOLO-n/s**: model families designed to be small and fast. **YOLO-n/s** are the
  "nano" and "small" sizes of the YOLO detector.
- **Distill, teacher to small student**: knowledge distillation trains a small **student** model to copy the outputs
  of a large, accurate **teacher** (Lecture 149).
- **Prune, structured, then fine-tune**: remove parts of the network. **Structured** pruning removes whole channels
  or layers. **Fine-tuning** afterwards retrains briefly to recover accuracy (Lecture 149).
- **FP16, INT8 PTQ, or QAT**: **FP16** is 16-bit floats. **INT8** uses 8-bit integers. **PTQ** (post-training
  quantization) converts a finished model using calibration data. **QAT** (quantization-aware training) simulates
  INT8 during training, so the model learns to tolerate it (Lecture 148).
- **TensorRT, TFLite, Core ML, OpenVINO**: compilers and runtimes for NVIDIA, Android and embedded (TFLite, now
  called LiteRT), Apple, and Intel hardware.
- **Latency, FPS, W, accuracy**: time per input, frames per second, watts of power, and the model's quality on the
  device.

---

## Lecture 148 — Quantization for edge efficiency

**Why it matters.** Edge devices have little memory, low bandwidth, and limited power. Storing and
computing with 8-bit integers instead of 32-bit floats makes models 4× smaller and typically 2–4× faster,
and it's usually the single biggest optimization after choosing the architecture.

**In plain words.** Measuring everything to the micrometer when centimeters would do wastes effort.
Quantization rounds the model's numbers to a coarser ruler with 256 marks (INT8), chosen carefully so
the important values still land on the right marks.

**Architecture: how INT8 quantization works.**

```mermaid
flowchart LR
  W["FP32 weights<br/>range -0.42 to 0.39"] --> SC["Scale per channel:<br/>s = max abs / 127"]
  SC --> Q["q = round(w / s)<br/>INT8 in -127..127"]
  A["FP32 activations"] --> CAL["Calibration on ~500 real inputs<br/>find activation ranges"]
  CAL --> QA["Activation scale + zero-point"]
  Q & QA --> INT["INT8 x INT8 matmul,<br/>INT32 accumulate"]
  INT --> DQ["Rescale to FP16/FP32<br/>for the next layer if needed"]
```

**How to read it:** each weight is divided by a scale and rounded to an integer between −127 and 127.
Using one scale *per output channel* fits each channel's own range. Activation ranges aren't known in
advance, so they're measured on calibration data. Matrix multiplies run in INT8 with INT32 accumulation,
and results are rescaled.

**Terms in this diagram.**
- **Scale, s = max abs / 127**: the **scale** maps real numbers to integers. Dividing the largest absolute weight
  (here 0.42) by 127 means that weight becomes 127, the largest INT8 value used.
- **Per channel**: each output channel of a layer (each filter) gets its own scale, instead of one scale for the
  whole tensor, so small-valued channels keep their precision.
- **q = round(w / s)**: the quantized integer for a weight `w`. To get back an approximate real value, multiply:
  `w ≈ q × s`.
- **Activations**: the intermediate values flowing between layers, which depend on the input.
- **Calibration**: running about 500 representative real inputs through the model to record the typical range of
  each activation.
- **Zero-point**: an integer offset that lets a range that isn't centered on zero (for example 0 to 6 after a ReLU)
  use all 256 integer values.
- **Matmul, INT32 accumulate**: matrix multiplication. Products of 8-bit numbers are summed in 32-bit integers so the
  totals don't overflow.
- **Rescale**: multiply the INT32 result by the combined scales to return to real-valued FP16 or FP32 numbers, or to
  the next layer's INT8 scale.

**Core ideas.**

| Method | How | Accuracy | Effort |
|---|---|---|---|
| FP16 / BF16 | Cast weights and math | Almost lossless | Trivial |
| Dynamic quantization | INT8 weights, activations quantized on the fly | Good for linear layers and LSTMs on CPU | Low |
| Static post-training quantization (PTQ) | INT8 weights + calibrated activation ranges | Typically under 1% drop for CNNs | Calibration data (~100–1,000 samples) |
| Quantization-aware training (QAT) | Simulate quantization during fine-tuning | Best for sensitive models | Training pipeline needed |
| INT4 / weight-only (LLMs) | 4-bit weights in small groups, FP16 activations (GPTQ, AWQ) | Good for LLMs with group-wise scales | Calibration, special kernels |

**What the numbers look like** (from [`s22_quantize_prune.py`](../exercises/s22_quantize_prune.py), one
64×128 layer):

| Weight format | Output error |
|---|---|
| INT8 per-tensor | 1.58% |
| INT8 per-channel | **0.64%** |
| INT4 per-tensor | 28.6% |
| INT4 per-channel | 12.3% (needs finer groups, for example 128 weights per scale) |
| INT8 per-tensor with one outlier weight | 11.0% |
| INT8 per-channel with the same outlier | 1.9% (the damage stays in one channel) |

- **Per-channel scales** for weights are the default in good toolchains for that reason.
- **Asymmetric (zero-point) quantization** suits non-negative activations (after ReLU). In the exercise its
  error is ~4× lower than symmetric.
- **Sensitive layers:** the first and last layers and attention softmax often stay in FP16. Mixed precision is
  normal.
- **Calibration data must be representative** (real images from the deployment cameras, at night as well as
  by day). Bad calibration is the most common cause of INT8 accuracy loss.

**Example: INT8 for a defect detector.** A factory's detector ran at 22 FPS in FP16 on an Orin Nano, and
the line needed 40. INT8 PTQ with 300 calibration images from the line raised it to 41 FPS, but recall on
small scratches fell from 94% to 88%. Keeping the detection head in FP16 and switching to QAT for 2 epochs
restored recall to 93.5% at 38 FPS. They also reduced the input resolution slightly, reaching 42 FPS.

**Senior / FAANG best practice.** Quantize by default for edge devices, but gate it on task metrics
*per slice* (small objects, night images), not just overall accuracy. Keep a calibration set curated and
versioned like test data. Start with PTQ, move to QAT only when needed, and keep sensitive layers in higher
precision.

---

## Lecture 149 — Pruning and model compression basics

**Why it matters.** Many networks are over-parameterized. Removing parts of them, or teaching a small model
to imitate a big one, can cut compute and size further, but only some forms of compression actually make
inference faster on real hardware.

**In plain words.** Pruning is trimming a hedge: cut the branches that contribute least, then let it
regrow a bit (fine-tune). Distillation is an apprentice learning from a master, ending up nearly as good,
but much faster and cheaper.

**Architecture: compression techniques and where speedups come from.**

```mermaid
flowchart TB
  M["Large model"] --> U["Unstructured pruning<br/>zero individual weights"]
  M --> S["Structured pruning<br/>remove channels, heads, layers"]
  M --> NM["2:4 semi-structured sparsity<br/>2 of every 4 weights zero"]
  M --> KD["Knowledge distillation<br/>teacher to student"]
  U --> U2["Smaller when compressed,<br/>rarely faster on GPU"]
  S --> S2["Smaller dense model:<br/>faster everywhere"]
  NM --> NM2["Up to ~2x matmul speed<br/>on Ampere+ sparse tensor cores"]
  KD --> KD2["New small architecture:<br/>faster everywhere"]
```

**How to read it:** unstructured pruning zeroes scattered weights. The file compresses well, but dense
hardware still does the same work, so it's rarely faster. Structured pruning removes whole channels, heads, or
layers, so the model is genuinely smaller and faster. NVIDIA's 2:4 pattern is a middle ground that
Ampere-and-newer tensor cores (including Jetson Orin) accelerate. Distillation trains a new, smaller model.

In the diagram, **heads** are the parallel attention units inside a transformer layer, which can be removed
individually. **2:4 semi-structured sparsity** means in every group of 4 consecutive weights, exactly 2 are zero. That
regular pattern lets **sparse tensor cores** skip the zeros in hardware. A **dense** model has no zeros to skip, so
"smaller dense model" means fewer, fully used weights. **Ampere+** means NVIDIA Ampere-generation GPUs (A100, Jetson
Orin) and newer.

**Core ideas.**

| Technique | Speedup on edge GPU/CPU | Accuracy cost | Notes |
|---|---|---|---|
| Unstructured magnitude pruning | Usually none without sparse kernels | Low at 50–80% *after fine-tuning* | Good for storage and transfer size |
| Structured pruning (channels, filters) | Real, roughly proportional | Higher, so fine-tune | Tools: Torch-Pruning, NVIDIA Model Optimizer |
| 2:4 sparsity | Up to ~1.5–2× on matmul-heavy layers | Low after fine-tuning | Ampere, Hopper, Orin |
| Distillation | Real (smaller architecture) | Small if the student is well chosen | DistilBERT ≈ 60% faster, keeping ~97% of BERT's quality |
| Weight sharing / low-rank | Moderate | Varies | Low-rank factorization of large linear layers |

- **Fine-tuning recovers accuracy.** In the exercise, *before* any fine-tuning, unstructured 50% pruning
  costs 16% output error and structured 50% costs 28%. Fine-tuning for a few epochs is what makes
  pruning practical.
- **Order of operations:** choose an architecture, distill, prune with fine-tuning, quantize last (QAT
  if needed), then compile.
- **Measure speed, not parameter count.** Fewer FLOPs don't guarantee lower latency (memory-bound layers,
  unsupported operations).

**Example: distilling for a doorbell camera.** A ResNet-50 person classifier (25M parameters) was too
slow for a battery-powered doorbell's NPU. Distilling into a MobileNetV3-Small student (2.5M parameters) on
2 million unlabeled frames labeled by the teacher kept accuracy within 1.2 points, and INT8 quantization
then cut inference from 180 ms to 14 ms on the device NPU.

**Senior / FAANG best practice.** Prefer architecture choice and distillation for big wins, structured
pruning and 2:4 for hardware-friendly speedups, and unstructured pruning only for size. Always fine-tune
after pruning, and benchmark latency on the target. Track the accuracy-latency curve, and pick the point
the product needs.

---

## Lecture 150 — TensorRT for edge inference

**Why it matters.** On Jetson, TensorRT is how models reach their real performance. It uses the GPU's tensor
cores and the Orin's DLAs efficiently, and it brings the same compilation workflow from Section 15 to
the edge, with edge-specific considerations.

**In plain words.** Same idea as in the data center: a custom-fitted version of the model for this exact
device. On edge devices, you also choose which engine inside the chip does the work (GPU or DLA), to
balance speed and power.

**Architecture: TensorRT on Jetson Orin.**

```mermaid
flowchart LR
  ONNX["model.onnx"] --> BUILD["trtexec / TensorRT builder<br/>on the target Jetson"]
  CAL[(Calibration images)] --> BUILD
  BUILD --> GPUE["Engine on GPU<br/>FP16 / INT8"]
  BUILD --> DLAE["Engine on DLA core 0/1<br/>INT8 / FP16, lower power,<br/>unsupported layers fall back to GPU"]
  GPUE & DLAE --> APP["DeepStream / Python app<br/>(engine cached on disk)"]
```

**How to read it:** you build engines on the target device (or the same module type) from ONNX, with
calibration data for INT8. On Orin NX and AGX, you can place a model on a DLA, a fixed-function accelerator
that's slower than the GPU for some models but much more power-efficient, which frees the GPU for other work.
Layers the DLA can't run fall back to the GPU.

In the diagram, `trtexec` is TensorRT's command-line tool for building and timing engines, and the **builder** is the
same function in its Python and C++ API. **DLA core 0/1** means Orin modules have up to two DLAs, and you choose
which one. **Engine cached on disk** means the app saves the built engine file and reuses it, because building can
take minutes. **DeepStream** is NVIDIA's video analytics framework (Section 21).

**Core ideas.**

```bash
# FP16 on GPU
trtexec --onnx=model.onnx --saveEngine=model_fp16.engine --fp16
# INT8 with a calibration cache (produced by a calibrator script or a previous build)
trtexec --onnx=model.onnx --saveEngine=model_int8.engine --int8 --fp16 --calib=calib.cache
# INT8 on DLA core 0 with GPU fallback (Orin NX / AGX)
trtexec --onnx=model.onnx --saveEngine=model_dla.engine --int8 --fp16 --useDLACore=0 --allowGPUFallback
# measure (latency percentiles, throughput)
trtexec --loadEngine=model_int8.engine --warmUp=500 --duration=20 --percentile=99
```

| Option | Effect on edge |
|---|---|
| `--fp16` | Usually 1.5–2× over FP32, near-lossless |
| `--int8` + calibration | A further 1.5–2×, check accuracy |
| `--useDLACore` | Lower power, runs in parallel with the GPU. Check how many layers fall back |
| Workspace / tactic sources | Memory available for the builder to try fast kernels. Limit it on small-memory devices |
| Engine cache | Building can take minutes on Jetson, so build once per JetPack and module in CI or at provisioning |

- **Explicit quantization (Q/DQ nodes in ONNX from QAT or the Model Optimizer)** is now preferred over
  implicit calibration for TensorRT 10, because it's more reproducible.
- **DeepStream** wraps TensorRT engines in a full video pipeline (decode, batch, infer, track, output),
  the standard for multi-camera Jetson apps.

**Example: GPU plus DLA on one module.** An AGX Orin ran two models: a detector (GPU, INT8) and a
classifier on detected crops. Moving the classifier to DLA 0 in INT8 cut total module power from 38 W
to 29 W at the same throughput, and freed ~25% of GPU time for a third camera stream.

**Senior / FAANG best practice.** Build and validate engines in CI on real devices, per module and
JetPack version, and ship them as versioned artifacts, rather than building on each device at boot. Use
explicit quantization from QAT or the Model Optimizer for reproducible INT8. Use DLAs where models
fit, to save power and free the GPU. Record the accuracy, latency, and power of every engine build.

---

## Lecture 151 — Running vision models on Raspberry Pi

**Why it matters.** Raspberry Pi boards are cheap, popular, and everywhere in prototypes and light
production. They have no CUDA GPU, so making vision models usable needs small models, CPU-optimized
runtimes, and sometimes an add-on accelerator.

**In plain words.** A Raspberry Pi is a bicycle compared with a Jetson's motorbike. It goes where you need
if the load is light (a small model, lower resolution) and you pedal efficiently (optimized runtimes, all
cores). For heavy loads, add a motor (an accelerator HAT).

**Architecture: vision on a Raspberry Pi 5.**

```mermaid
flowchart LR
  CAM["Pi Camera Module 3<br/>libcamera / picamera2"] --> PRE["Resize to 224-320,<br/>uint8"]
  PRE --> RT{"Runtime"}
  RT -->|"CPU: 4x Cortex-A76"| TFL["LiteRT (TFLite) INT8<br/>XNNPACK, 4 threads"]
  RT -->|"CPU"| ORT["ONNX Runtime /<br/>ncnn / OpenVINO"]
  RT -->|"accelerator"| HAILO["AI HAT+ (Hailo-8L/8)<br/>13-26 TOPS"]
  RT -->|"USB accelerator"| CORAL["Coral Edge TPU"]
  TFL & ORT & HAILO & CORAL --> OUT["Results, GPIO, MQTT"]
```

**How to read it:** the camera feeds small frames into a runtime. On the CPU alone, an INT8 model
through LiteRT with the XNNPACK delegate, or ONNX Runtime or ncnn, uses all four cores. For heavier
models or higher frame rates, an accelerator (the Raspberry Pi AI HAT+ with a Hailo chip, or a Coral Edge
TPU) runs the network, while the CPU handles the rest.

**Terms in this diagram.**
- **Pi Camera Module 3, libcamera / picamera2**: the official Raspberry Pi camera. **libcamera** is the Linux camera
  stack, and **picamera2** is its Python library.
- **Resize to 224-320, uint8**: frames are shrunk to the model's input size (224 to 320 pixels per side) and kept as
  8-bit unsigned integers (**uint8**, 0–255), which is what INT8 models expect.
- **4x Cortex-A76**: the Raspberry Pi 5 has four Arm Cortex-A76 CPU cores.
- **LiteRT (TFLite), XNNPACK, 4 threads**: **LiteRT** is the new name of TensorFlow Lite, Google's runtime for small
  devices. **XNNPACK** is its optimized CPU backend (a **delegate**), and using 4 threads keeps every core busy.
- **ncnn**: Tencent's lightweight neural network runtime, tuned for Arm CPUs.
- **AI HAT+ (Hailo-8L/8), 13-26 TOPS**: an add-on board (a **HAT**, "hardware attached on top") with a Hailo neural
  accelerator chip. **TOPS** means trillions of operations per second, a rough measure of AI speed.
- **Coral Edge TPU**: Google's small USB accelerator that runs INT8 TFLite models compiled for it.
- **GPIO, MQTT**: the Pi's general-purpose input and output pins, for driving lights or relays, and the lightweight
  IoT messaging protocol (Section 21).

**Core ideas.**

```python
# LiteRT / TFLite INT8 classification on a Pi 5 (pip install ai-edge-litert picamera2)
import numpy as np
from ai_edge_litert.interpreter import Interpreter
interp = Interpreter("mobilenet_v3_small_int8.tflite", num_threads=4)
interp.allocate_tensors()
inp, out = interp.get_input_details()[0], interp.get_output_details()[0]
frame = np.zeros((1, 224, 224, 3), dtype=np.uint8)           # replace with a picamera2 capture
interp.set_tensor(inp["index"], frame); interp.invoke()
scores = interp.get_tensor(out["index"])[0]
```

| Model (approx., Pi 5 CPU, 4 threads) | Input | Latency | Note |
|---|---|---|---|
| MobileNetV3-Small INT8 | 224 | ~5–10 ms | Classification at camera rate |
| EfficientDet-Lite0 INT8 | 320 | ~40–70 ms | Detection at ~15–20 FPS |
| YOLOv8n (ncnn / ONNX INT8) | 320–640 | ~60–250 ms | Use 320 for usable FPS |
| YOLOv8s on Hailo-8L AI HAT+ | 640 | ~10–15 ms | 60+ FPS possible |

- **Thermals:** a Pi 5 throttles without cooling under sustained load. Use the active cooler, and benchmark
  for minutes, not seconds.
- **Prefer uint8 input end to end** (camera to model) to avoid float conversions on the CPU.
- **Pi 4 vs Pi 5:** a Pi 5 is roughly 2–3× faster for CPU inference.

**Example: a wildlife camera on solar power.** A conservation project used Pi 5 boards with a 5 W power
budget to detect animals at waterholes. EfficientDet-Lite0 INT8 at 320 px ran at ~12 FPS on the CPU,
but drew ~7 W. Triggering inference only on motion (from a cheap PIR sensor), at 2 FPS during events,
brought average power to ~3 W, and the system ran on solar for a full season.

**Senior / FAANG best practice.** On CPU-only boards, design the duty cycle (when to run the model) as
carefully as the model itself: trigger on cheap sensors, use a low frame rate, and pick small INT8 models.
Choose accelerators when sustained FPS is a requirement, and keep the model export path portable (TFLite,
ONNX, HEF for Hailo) in CI.

---

## Lecture 152 — TinyML and microcontrollers for AI

**Why it matters.** Billions of microcontrollers sit in appliances, wearables, and sensors. TinyML runs
small models on them at milliwatts of power for years on a battery, enabling always-on sensing that would be
impossible with a phone-class chip.

**In plain words.** A TinyML device is a very small, very frugal helper with a tiny notebook (kilobytes of
memory). It can learn one simple job, like recognizing "Hey device" or a strange vibration, and do it
forever on a coin cell.

**Architecture: a TinyML pipeline.**

```mermaid
flowchart LR
  S["Sensor: mic, IMU,<br/>vibration, low-res camera"] --> FE["Feature extraction on MCU<br/>MFCC / FFT, fixed-point"]
  FE --> M["INT8 model<br/>10-500 KB, in flash"]
  M --> ARENA["Tensor arena in SRAM<br/>e.g. 50-300 KB"]
  M --> D{"Score above threshold?"}
  D -->|yes| WAKE["Wake a bigger chip / radio,<br/>send an event"]
  D -->|no| SLEEP["Back to low-power sleep"]
  TRAIN["Train in the cloud<br/>Edge Impulse / TF"] -->|"convert + quantize,<br/>compile into firmware"| M
```

**How to read it:** the sensor signal is turned into compact features (for audio, MFCC spectrograms)
on the microcontroller. A tiny INT8 model stored in flash runs using a fixed "tensor arena" of RAM. Most
of the time the result is "nothing", and the device sleeps. On a detection, it wakes a bigger processor or
the radio. Models are trained in the cloud, quantized, and compiled into the firmware.

**Terms in this diagram.**
- **IMU**: inertial measurement unit, a motion sensor combining an accelerometer and a gyroscope.
- **MCU**: microcontroller unit, a tiny low-power chip with built-in memory, often running at tens to hundreds of
  MHz.
- **MFCC / FFT, fixed-point**: an **FFT** (fast Fourier transform) splits a signal into its frequencies. **MFCCs**
  (mel-frequency cepstral coefficients) are compact audio features based on how humans hear. **Fixed-point** math
  uses integers with an implied decimal point, because many MCUs have no fast floating-point hardware.
- **10-500 KB, in flash**: the whole model is a few hundred kilobytes, stored in the chip's **flash** memory (which
  keeps its data without power, like a tiny SSD).
- **Tensor arena in SRAM**: **SRAM** is the chip's small, fast working memory. The **tensor arena** is one
  fixed-size block of it, reserved at compile time, holding all activations, so nothing is allocated while running.
- **Wake a bigger chip / radio**: the radio (Wi-Fi, Bluetooth, LoRa) and larger processors use far more power, so
  they stay off until needed.
- **Edge Impulse**: a popular hosted platform for collecting sensor data and training TinyML models.
- **Firmware**: the single program flashed onto the microcontroller, with the model compiled in.

**Core ideas.**

| Constraint | Typical MCU (Cortex-M4/M7, ESP32-S3) | Phone SoC |
|---|---|---|
| RAM | 256 KB – 1 MB | 8–16 GB |
| Storage | 1–16 MB flash | 128 GB+ |
| Power | 1–100 mW | 1–5 W |
| Typical models | Keyword spotting, gesture, anomaly detection, person detection at 96×96 | Large vision and language models |

- **Frameworks:** LiteRT for Microcontrollers (formerly TFLite Micro), Edge Impulse (end-to-end
  platform), CMSIS-NN kernels on Arm, ESP-DL on Espressif, and microTVM.
- **Everything is INT8**, and memory is planned at compile time. The tensor arena size is a key number.
- **Updates:** firmware OTA (if the device has a radio) with dual-bank flash for rollback.
- **Benchmark suite:** MLPerf Tiny (keyword spotting, visual wake words, anomaly detection, image
  classification).

**Example: predictive maintenance on a pump.** An anomaly-detection autoencoder (~18 KB INT8) on a
Cortex-M4 analyzed vibration FFTs every 10 seconds, using ~0.3 ms of compute per window. The device slept
otherwise, and a coin cell plus a low-power radio lasted over 2 years. It reported only anomaly scores
above threshold, plus a daily heartbeat.

**Senior / FAANG best practice.** For always-on sensing, put a tiny model first in a *cascade*: the
microcontroller detects candidates at milliwatts, and only then wakes a bigger processor or the cloud. Big
consumer devices use this pattern for wake words and activity detection. Treat firmware models like any
release: versioned, tested on hardware, signed, and updated with rollback.

---

## Lecture 153 — Benchmarking models on edge hardware

**Why it matters.** Edge benchmark numbers are easy to get wrong: cold caches, unfixed clocks, timing only
the model and not the pipeline, or a few seconds of data before thermal throttling. Wrong numbers lead to
wrong hardware purchases for thousands of devices.

**In plain words.** Timing a car's 0–100 km/h once, downhill, with a cold engine tells you little.
Fair benchmarks use the same road, a warmed-up engine, several runs, and the full journey, not just the
fastest stretch.

**Architecture: what to measure, and where.**

```mermaid
flowchart LR
  subgraph E2E["End-to-end latency (what users feel)"]
    CAP["Capture"] --> DEC["Decode"] --> PRE["Preprocess"] --> INF["Inference"] --> POST["Postprocess / NMS"] --> ACT["Action"]
  end
  INF -.->|"model-only latency<br/>(trtexec, benchmark_model)"| MOD["Model benchmark"]
  E2E --> REP["Report: p50/p95/p99 latency,<br/>FPS sustained over 10+ min,<br/>W and J per inference,<br/>accuracy on the device"]
  ENV["Fixed: power mode, clocks,<br/>temperature, versions"] -.-> E2E
```

**How to read it:** model-only benchmarks (`trtexec`, the TFLite `benchmark_model`) are useful for
comparing models, but users experience the *whole* pipeline: capture, decode, preprocessing, inference,
postprocessing such as non-maximum suppression, and the action. A proper report gives latency percentiles,
sustained throughput over at least 10 minutes (thermals), energy per inference, and accuracy measured on the
device, under a fixed, recorded configuration.

In the diagram, **NMS** (non-maximum suppression) removes duplicate overlapping boxes from a detector, keeping the
most confident one. `benchmark_model` is TFLite's (LiteRT's) timing tool. **p50/p95/p99** are latency percentiles:
the times within which 50%, 95%, and 99% of inputs finish. **Sustained** FPS is measured after the device has warmed
up, because small devices slow down (**throttle**) when hot. **W and J per inference** are power in watts and energy
in joules per input (watts × seconds), which matters for battery life. **Power mode, clocks** are settings such as
Jetson's `nvpmodel` profiles that cap power and processor frequencies. Record them, because results change with them.

**Core ideas.**

| Rule | Why |
|---|---|
| Warm up (hundreds of runs) before timing | First runs include memory allocation, engine loading, and caches |
| Fix and record the power mode and clocks | `nvpmodel`, `jetson_clocks`, CPU governor. Otherwise results vary run to run |
| Sustain for 10+ minutes in the real enclosure | Thermal throttling appears after minutes |
| Report percentiles, not averages | p99 decides missed frames and deadlines |
| Measure energy (J per inference) | Battery and solar devices care about energy, not just watts |
| Validate accuracy on the device output | Compilation and quantization can change results |
| Same input pipeline as production | Resolution, batch size 1, real camera formats |

```bash
# TFLite / LiteRT model benchmark on a Pi or Android device
./benchmark_model --graph=model_int8.tflite --num_threads=4 --warmup_runs=50 --num_runs=500
# Jetson: model-only with trtexec, then end-to-end with your app, while logging power
sudo tegrastats --interval 1000 --logfile power.log &
```

- **MLPerf Inference Edge** and **MLPerf Tiny** give standard workloads and rules for comparable numbers.

**Example: the benchmark that oversold the hardware.** A vendor demo reported 120 FPS for a detector on a
small module. The team's own end-to-end test with 1080p camera decode, NMS, and tracking, in a sealed
enclosure at 35 °C, gave 62 FPS after 15 minutes, as clocks dropped from thermal throttling. They
ordered the next module size up, and avoided a fleet that would have missed its 4-camera target.

**Senior / FAANG best practice.** Maintain a device lab with every hardware variant in realistic
enclosures, run standard end-to-end benchmarks in CI for every model and engine change, and store results
(latency percentiles, FPS, energy, accuracy) alongside the model version. Make hardware decisions from
these, not from data sheets.

---

## Lecture 154 — Lab: optimize a model with TensorRT

**Goal:** take a ResNet-50 (or YOLOv8s) from ONNX to TensorRT FP32, FP16, and INT8 with calibration,
on a Jetson or an NVIDIA GPU, and compare latency, throughput, power, and accuracy in one table.

**What you're building.**

```mermaid
flowchart LR
  EXP["export ONNX"] --> B32["engine FP32"]
  EXP --> B16["engine FP16"]
  EXP --> CALI["calibrator.py:<br/>500 real images to calib.cache"]
  CALI --> B8["engine INT8"]
  B32 & B16 & B8 --> BENCH["trtexec: latency p50/p99, QPS"]
  B32 & B16 & B8 --> ACC["eval.py: top-1 on 2,000 val images"]
  BENCH & ACC --> TABLE["results.md"]
```

**In plain words.** You build three versions of the same model at different precisions, then prove
with measurements which one to ship.

**How to read the diagram:** you export the model to ONNX once, then build three TensorRT engines: FP32, FP16, and
INT8. INT8 needs `calibrator.py`, which runs 500 real images through the model and saves the measured activation
ranges to `calib.cache`, so later builds can reuse them. `trtexec` measures each engine's latency (median p50 and
tail p99) and **QPS** (queries, meaning inputs, per second). `eval.py` measures **top-1 accuracy**, the share of
2,000 **validation images** (held-out labeled images not used in training) where the model's first guess is right.
Both results go into one comparison table, `results.md`.

### Step 1 — Export the model and prepare data

```bash
python - <<'EOF'
import torch, torchvision
m = torchvision.models.resnet50(weights="DEFAULT").eval()
torch.onnx.export(m, torch.randn(1, 3, 224, 224), "resnet50.onnx", input_names=["input"],
                  output_names=["logits"], dynamic_axes={"input": {0: "batch"}}, opset_version=17)
EOF
# calibration and validation images: e.g. 500 + 2,000 images from ImageNet val or Imagenette, in data/calib and data/val
```

### Step 2 — Build FP32 and FP16 engines

```bash
trtexec --onnx=resnet50.onnx --saveEngine=r50_fp32.engine --shapes=input:1x3x224x224
trtexec --onnx=resnet50.onnx --saveEngine=r50_fp16.engine --shapes=input:1x3x224x224 --fp16
```

### Step 3 — Calibrate and build INT8

```python
# calibrator.py: writes calib.cache using TensorRT's entropy calibrator (TensorRT 8.6/10 Python API)
import glob, numpy as np, tensorrt as trt
import pycuda.driver as cuda, pycuda.autoinit
from PIL import Image
MEAN, STD = np.array([0.485, 0.456, 0.406]), np.array([0.229, 0.224, 0.225])
def load(p):
    im = Image.open(p).convert("RGB").resize((256, 256)).crop((16, 16, 240, 240))
    return ((np.asarray(im) / 255.0 - MEAN) / STD).transpose(2, 0, 1).astype(np.float32)
class Calib(trt.IInt8EntropyCalibrator2):
    def __init__(self, files, batch=8):
        super().__init__(); self.files, self.batch, self.i = files, batch, 0
        self.dev = cuda.mem_alloc(batch * 3 * 224 * 224 * 4)
    def get_batch_size(self): return self.batch
    def get_batch(self, names):
        if self.i + self.batch > len(self.files): return None
        x = np.stack([load(f) for f in self.files[self.i:self.i + self.batch]]); self.i += self.batch
        cuda.memcpy_htod(self.dev, np.ascontiguousarray(x)); return [int(self.dev)]
    def read_calibration_cache(self): return None
    def write_calibration_cache(self, c): open("calib.cache", "wb").write(c)
logger = trt.Logger(trt.Logger.WARNING)
builder = trt.Builder(logger); net = builder.create_network(0)
trt.OnnxParser(net, logger).parse(open("resnet50.onnx", "rb").read())
cfg = builder.create_builder_config()
cfg.set_flag(trt.BuilderFlag.INT8); cfg.set_flag(trt.BuilderFlag.FP16)
cfg.int8_calibrator = Calib(sorted(glob.glob("data/calib/*.JPEG"))[:500])
prof = builder.create_optimization_profile()
prof.set_shape("input", (1, 3, 224, 224), (8, 3, 224, 224), (8, 3, 224, 224)); cfg.add_optimization_profile(prof)
cfg.set_calibration_profile(prof)
open("r50_int8.engine", "wb").write(builder.build_serialized_network(net, cfg))
```

```bash
python calibrator.py
```

The implicit calibrator API is deprecated in TensorRT 10 in favor of explicit Q/DQ quantization
(NVIDIA Model Optimizer). It still works, and it shows clearly what calibration does.

### Step 4 — Benchmark, evaluate, and tabulate

```bash
for e in r50_fp32 r50_fp16 r50_int8; do
  trtexec --loadEngine=$e.engine --shapes=input:1x3x224x224 --warmUp=500 --duration=20 --percentile=99 | \
    grep -E "Throughput|Latency: min" | sed "s/^/$e: /"
done
sudo tegrastats --interval 1000 --logfile power.log &       # Jetson: power while benchmarks run
python3 exercises/s22_quantize_prune.py                     # why per-channel scales and calibration matter
```

For accuracy, run the 2,000 validation images through each engine (TensorRT Python runtime or Polygraphy:
`polygraphy run r50_int8.engine --trt --load-inputs ...`) and compute top-1 accuracy against the labels.

**Expected results** (rough, batch size 1):

| Engine | Orin Nano latency | RTX/T4-class GPU latency | Top-1 change |
|---|---|---|---|
| FP32 | ~25–35 ms | ~3–5 ms | baseline (~80.9% with the V2 weights) |
| FP16 | ~10–15 ms | ~1.2–2 ms | about 0.0–0.1 points |
| INT8 (entropy calibration) | ~6–9 ms | ~0.8–1.2 ms | about −0.2 to −0.8 points |

- FP16 roughly halves latency, and INT8 cuts it a further ~1.5–2×.
- With a good calibration set, INT8 accuracy stays within about a point. With bad calibration (for example
  50 unrepresentative images), the drop is visibly larger. Try it.
- On Jetson, power per inference falls as precision drops (fewer joules per image at higher FPS).

---

## FAANG deep-dive notes

**How big tech does it.** Edge and on-device teams co-design models with hardware: efficient architectures
from the start (often with neural architecture search for the target chip), distillation from large cloud
models, quantization-aware training as standard, and per-target compilation in CI. Every model build is
benchmarked end to end on a device lab of real hardware variants, and results gate releases. Cascades
(a tiny always-on model, then a bigger on-device model, then the cloud) balance power and quality.

**Staff review questions.**
- What's the accuracy-latency-power curve, and which point does the product need?
- Was INT8 accuracy checked on the slices that matter (small objects, low light)?
- Were benchmarks end to end, sustained, in the real enclosure, with fixed and recorded power modes?
- How are engines built, versioned, and matched to device hardware and software versions?

**Interview question.** "Your detector runs at 12 FPS on the target device, and the product needs 30. What do you do?"

**Typical system-design prompt:** *Bring a 25 FPS FP32 detector to 60 FPS on an 8 GB edge module for a
4-camera product, with at most 1 point mAP loss, within a 20 W power budget.*

**1. Clarify first:** Is it 60 FPS total, or per camera? Which mAP slices matter? Can resolution drop? Is
retraining allowed (QAT, distillation)? Which hardware accelerators exist on the module (GPU, DLA)?

**2. Back-of-envelope sizing:**
- FP32 to FP16 ≈ 1.8× (45 FPS). INT8 ≈ a further 1.6× (~70 FPS) if accuracy holds.
- Resolution 640 to 512 ≈ 1.5× fewer pixels, at some cost for small objects.
- Decode for 4 × 1080p at 15 fps uses the hardware decoder, not the GPU.
- Power: ~15 W at full GPU load on an Orin NX-class module. A DLA offload of a secondary model saves ~20–30%.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Quantization | PTQ INT8 | QAT INT8 | PTQ first, QAT if slice accuracy drops |
| Compression | Unstructured pruning | Distillation / structured | Distill or structure for speed. Unstructured only for size |
| Resolution | Keep 640 | Lower to 512 or 416 | Lower if small-object recall allows |
| Accelerator | GPU only | GPU + DLA | Use the DLA for models that fit, to save power and free the GPU |
| Benchmark | Model-only | End to end, sustained | Decide only on end-to-end sustained numbers |

**4. Follow-up questions with crisp answers:**
- *Why per-channel weight scales?* Channels have very different ranges, and one scale for all wastes
  precision on small channels. In the exercise, per-channel INT8 has ~2.5× lower error, and it contains
  outliers.
- *Why didn't 80% unstructured pruning make the model faster?* Dense kernels still compute the zeros. Use
  structured pruning, 2:4 sparsity on supported hardware, or a smaller architecture.
- *Why do results differ between my laptop GPU and the Jetson?* Different architecture, TensorRT version,
  memory bandwidth, power limits, and thermal behavior. Benchmark on the target.

**Debug this (common onsite question):** "After INT8 quantization, overall mAP dropped only 0.5 points, but customers report missed detections at night."
1. Slice the evaluation: day mAP −0.2, night mAP −6.1.
2. Check calibration data: 500 images, all daytime. Activation ranges for dark images were never seen.
3. Inspect per-layer: early layers' activation scales clip low-intensity features.
4. Fix: recalibrate with representative day and night (and weather) images, keep the first layer in FP16, and
   add night slices to the accuracy gate. Consider QAT if the gap remains.

The lesson: quantization is a data problem. Calibration and evaluation sets must cover the real
deployment conditions, and gates must be per slice.

**5. What separates senior from staff answers:** a senior engineer applies FP16 and INT8 correctly, builds
engines, and benchmarks properly. A staff engineer frames the problem as an accuracy-latency-power curve,
chooses architecture and distillation for large wins, uses hardware-friendly compression, builds a device-lab
CI with per-slice accuracy gates, and plans cascades and duty cycles to meet product power budgets.

**Red flags:**
- Unstructured pruning reported as a speedup.
- INT8 shipped on overall accuracy only.
- Calibration on a handful of unrepresentative images.
- Benchmarks of a few seconds, model-only, in open air.
- Engines built on a different device or JetPack.

---

## Quiz

<details><summary>1. Why are per-channel scales better than per-tensor scales for weight quantization?</summary>
Output channels have different value ranges. A single scale wastes precision on channels with small
weights, and lets one outlier ruin every channel. Per-channel scales fit each channel.
</details>

<details><summary>2. What is calibration in post-training INT8 quantization?</summary>
Running representative inputs through the model to measure activation ranges, which set the activation
scales and zero-points.
</details>

<details><summary>3. When would you use QAT instead of PTQ?</summary>
When PTQ causes unacceptable accuracy loss, for example on sensitive models or important slices. QAT
simulates quantization during fine-tuning, so the model adapts.
</details>

<details><summary>4. Why might 80% unstructured sparsity give no speedup on a GPU?</summary>
Dense kernels still process every weight, zeros included. Speedups need structured pruning, supported
sparsity patterns (2:4), or sparse kernels.
</details>

<details><summary>5. What is the DLA on Jetson Orin, and why use it?</summary>
A fixed-function deep-learning accelerator. It runs supported layers (INT8/FP16) at lower power than the GPU,
and in parallel with it. Unsupported layers fall back to the GPU.
</details>

<details><summary>6. How do you make vision usable on a CPU-only Raspberry Pi?</summary>
Use small INT8 models (MobileNet, EfficientDet-Lite, YOLO-n at 320), LiteRT/XNNPACK or ncnn with all cores,
uint8 inputs, active cooling, and motion-triggered or low-FPS duty cycles. Add a Hailo or Coral accelerator for
more.
</details>

<details><summary>7. What limits a TinyML model?</summary>
Kilobytes of RAM (the tensor arena), limited flash for weights, milliwatt power budgets, and no OS
services. Models are INT8 and planned at compile time.
</details>

<details><summary>8. List four rules for trustworthy edge benchmarks.</summary>
Warm up first, fix and record power modes and clocks, measure the full pipeline sustained for 10+ minutes
in the real enclosure, and report latency percentiles, energy, and on-device accuracy.
</details>

## Failure modes
- INT8 accuracy losses hidden in slices (night, small objects) because the gates are overall-only.
- Unrepresentative calibration data.
- Expecting speedups from unstructured pruning, or skipping fine-tuning after pruning.
- Engines built on a different device type or software version.
- Model-only or short benchmarks that miss decode, postprocessing, and thermal throttling.
- CPU-only boards run at full duty cycle, overheating or draining batteries.
- TinyML firmware updates without rollback.

## Checklist
- [ ] You can explain scales, zero-points, per-channel quantization, and calibration, and you ran `s22_quantize_prune.py`
- [ ] You can choose between PTQ and QAT, and gate INT8 on slice accuracy
- [ ] You know which compression methods give real speedups on your hardware
- [ ] You can build TensorRT FP16/INT8 engines (and DLA engines) on Jetson, and cache them
- [ ] You can run INT8 vision models on a Raspberry Pi and plan the duty cycle
- [ ] You can describe a TinyML cascade and its constraints
- [ ] You benchmarked FP32, FP16, and INT8 end to end, with accuracy and power, in the lab
