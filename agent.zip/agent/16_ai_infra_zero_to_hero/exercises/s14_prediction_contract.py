#!/usr/bin/env python3
"""Section 14 assessment: implement a prediction API contract.

A standard-library model server that enforces a versioned contract:

  POST /v1/predict   {"instances": [{feature: number, ...}, ...]}
                     -> 200 {"predictions": [...], "model": {...}, "request_id": "..."}
  GET  /v1/model     -> the contract: model name, version, input schema, limits
  GET  /healthz      -> 200 while the process is alive (liveness)
  GET  /readyz       -> 200 only once the model is loaded (readiness), else 503

Every error uses one shape:
  {"error": {"code": "INVALID_ARGUMENT", "message": "...", "details": [{"field": ..., "issue": ...}]},
   "request_id": "..."}

It also includes check_compat(old_schema, new_schema), which classifies a schema change as breaking or
safe, the check a CI pipeline runs before publishing a new API version.

Usage:
  python3 s14_prediction_contract.py              # run the contract test suite (demo)
  python3 s14_prediction_contract.py --serve 8000 # run the server
"""
import argparse
import json
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MAX_BODY_BYTES = 64 * 1024
MAX_INSTANCES = 32

SCHEMA_V1 = {
    "sepal_length": {"type": "number", "min": 0, "max": 50, "required": True},
    "sepal_width": {"type": "number", "min": 0, "max": 50, "required": True},
    "petal_length": {"type": "number", "min": 0, "max": 50, "required": True},
    "petal_width": {"type": "number", "min": 0, "max": 50, "required": True},
}
MODEL = {"name": "iris-classifier", "version": "1.4.0", "schema_version": "v1"}
STATE = {"ready": False}


class ContractError(Exception):
    def __init__(self, status, code, message, details=None):
        super().__init__(message)
        self.status, self.code, self.message, self.details = status, code, message, details or []


def predict_one(x):
    if x["petal_length"] < 2.5:
        return {"label": "setosa", "score": 0.98}
    if x["petal_width"] < 1.75:
        return {"label": "versicolor", "score": 0.91}
    return {"label": "virginica", "score": 0.94}


def validate(payload, schema=SCHEMA_V1):
    if not isinstance(payload, dict) or "instances" not in payload:
        raise ContractError(400, "INVALID_ARGUMENT", "body must be an object with 'instances'",
                            [{"field": "instances", "issue": "required"}])
    inst = payload["instances"]
    if not isinstance(inst, list) or not inst:
        raise ContractError(400, "INVALID_ARGUMENT", "'instances' must be a non-empty list",
                            [{"field": "instances", "issue": "must be a non-empty list"}])
    if len(inst) > MAX_INSTANCES:
        raise ContractError(400, "INVALID_ARGUMENT", f"at most {MAX_INSTANCES} instances per request",
                            [{"field": "instances", "issue": f"length {len(inst)} > {MAX_INSTANCES}"}])
    details = []
    for i, row in enumerate(inst):
        if not isinstance(row, dict):
            details.append({"field": f"instances[{i}]", "issue": "must be an object"})
            continue
        for name, rule in schema.items():
            path = f"instances[{i}].{name}"
            if name not in row:
                if rule.get("required"):
                    details.append({"field": path, "issue": "required"})
                continue
            v = row[name]
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                details.append({"field": path, "issue": "must be a number"})
            elif not rule["min"] <= v <= rule["max"]:
                details.append({"field": path, "issue": f"must be in [{rule['min']}, {rule['max']}]"})
    if details:
        raise ContractError(400, "INVALID_ARGUMENT", f"{len(details)} invalid field(s)", details)
    return inst


def check_compat(old, new):
    """Return (breaking_changes, safe_changes) between two input schemas."""
    breaking, safe = [], []
    for name, rule in old.items():
        if name not in new:
            breaking.append(f"removed field '{name}'")
            continue
        n = new[name]
        if n["type"] != rule["type"]:
            breaking.append(f"type of '{name}' changed {rule['type']} -> {n['type']}")
        if n.get("required") and not rule.get("required"):
            breaking.append(f"'{name}' became required")
        if n.get("min", float("-inf")) > rule.get("min", float("-inf")) or \
           n.get("max", float("inf")) < rule.get("max", float("inf")):
            breaking.append(f"range of '{name}' narrowed")
    for name, rule in new.items():
        if name not in old:
            (breaking if rule.get("required") else safe).append(
                f"added {'required' if rule.get('required') else 'optional'} field '{name}'")
    return breaking, safe


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _send(self, status, body, rid):
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Request-ID", rid)
        self.end_headers()
        self.wfile.write(data)

    def _error(self, err, rid):
        self._send(err.status, {"error": {"code": err.code, "message": err.message, "details": err.details},
                                "request_id": rid}, rid)

    def do_GET(self):
        rid = self.headers.get("X-Request-ID") or str(uuid.uuid4())
        if self.path == "/healthz":
            return self._send(200, {"ok": True}, rid)
        if self.path == "/readyz":
            if STATE["ready"]:
                return self._send(200, {"ready": True}, rid)
            return self._error(ContractError(503, "UNAVAILABLE", "model not loaded"), rid)
        if self.path == "/v1/model":
            return self._send(200, {"model": MODEL, "input_schema": SCHEMA_V1,
                                    "limits": {"max_instances": MAX_INSTANCES, "max_body_bytes": MAX_BODY_BYTES}}, rid)
        self._error(ContractError(404, "NOT_FOUND", f"no route {self.path}"), rid)

    def do_POST(self):
        rid = self.headers.get("X-Request-ID") or str(uuid.uuid4())
        t0 = time.perf_counter()
        try:
            if self.path != "/v1/predict":
                raise ContractError(404, "NOT_FOUND", f"no route {self.path}")
            if not STATE["ready"]:
                raise ContractError(503, "UNAVAILABLE", "model not loaded")
            if not (self.headers.get("Content-Type") or "").startswith("application/json"):
                raise ContractError(415, "UNSUPPORTED_MEDIA_TYPE", "use Content-Type: application/json")
            length = int(self.headers.get("Content-Length") or 0)
            if length > MAX_BODY_BYTES:
                raise ContractError(413, "PAYLOAD_TOO_LARGE", f"body {length} B > {MAX_BODY_BYTES} B")
            try:
                payload = json.loads(self.rfile.read(length) or b"null")
            except json.JSONDecodeError as e:
                raise ContractError(400, "INVALID_ARGUMENT", f"invalid JSON: {e.msg}")
            rows = validate(payload)
            preds = [predict_one(r) for r in rows]
            self._send(200, {"predictions": preds, "model": MODEL, "request_id": rid,
                             "latency_ms": round((time.perf_counter() - t0) * 1000, 3)}, rid)
        except ContractError as e:
            self._error(e, rid)


def call(base, method, path, body=None, headers=None, raw=None):
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    h = {"Content-Type": "application/json"} if data is not None else {}
    h.update(headers or {})
    req = urllib.request.Request(base + path, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read()), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read()), dict(e.headers)


def demo():
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{srv.server_address[1]}"
    good = {"sepal_length": 5.1, "sepal_width": 3.5, "petal_length": 1.4, "petal_width": 0.2}
    other = {"sepal_length": 6.7, "sepal_width": 3.0, "petal_length": 5.2, "petal_width": 2.3}
    results = []

    def check(name, ok, info=""):
        results.append(ok)
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}{'  ' + info if info else ''}")

    print("Contract test suite")
    STATE["ready"] = False
    s, b, _ = call(base, "GET", "/readyz")
    check("readyz is 503 before the model loads", s == 503 and b["error"]["code"] == "UNAVAILABLE")
    s, _, _ = call(base, "GET", "/healthz")
    check("healthz is 200 even before ready (liveness != readiness)", s == 200)
    STATE["ready"] = True
    s, _, _ = call(base, "GET", "/readyz")
    check("readyz is 200 after load", s == 200)

    s, b, h = call(base, "POST", "/v1/predict", {"instances": [good, other]}, {"X-Request-ID": "req-123"})
    check("valid batch returns 200 with one prediction per instance",
          s == 200 and [p["label"] for p in b["predictions"]] == ["setosa", "virginica"])
    check("response carries model version and echoes request id",
          b["model"]["version"] == "1.4.0" and b["request_id"] == "req-123" and h.get("X-Request-ID") == "req-123")

    s, b, _ = call(base, "POST", "/v1/predict", {"instances": [{k: v for k, v in good.items() if k != "petal_width"}]})
    check("missing field -> 400 with field path",
          s == 400 and b["error"]["details"][0] == {"field": "instances[0].petal_width", "issue": "required"})
    s, b, _ = call(base, "POST", "/v1/predict", {"instances": [dict(good, sepal_length="5.1"), dict(good, petal_width=-1)]})
    fields = {d["field"]: d["issue"] for d in b["error"]["details"]}
    check("wrong type and out-of-range are both reported in one response",
          s == 400 and fields.get("instances[0].sepal_length") == "must be a number"
          and fields.get("instances[1].petal_width", "").startswith("must be in"), f"{len(fields)} details")
    s, b, _ = call(base, "POST", "/v1/predict", {"instances": [good] * (MAX_INSTANCES + 1)})
    check(f"more than {MAX_INSTANCES} instances -> 400", s == 400 and b["error"]["details"][0]["field"] == "instances")
    s, b, _ = call(base, "POST", "/v1/predict", raw=b"x" * (MAX_BODY_BYTES + 1))
    check("oversized body -> 413", s == 413 and b["error"]["code"] == "PAYLOAD_TOO_LARGE")
    s, b, _ = call(base, "POST", "/v1/predict", raw=b'{"instances": [', headers={})
    check("invalid JSON -> 400", s == 400 and b["error"]["message"].startswith("invalid JSON"))
    s, b, _ = call(base, "POST", "/v1/predict", raw=b"a,b", headers={"Content-Type": "text/csv"})
    check("wrong content type -> 415", s == 415)
    s, b, _ = call(base, "GET", "/v1/model")
    check("GET /v1/model publishes the schema and limits",
          s == 200 and set(b["input_schema"]) == set(SCHEMA_V1) and b["limits"]["max_instances"] == MAX_INSTANCES)
    STATE["ready"] = False
    s, b, _ = call(base, "POST", "/v1/predict", {"instances": [good]})
    check("predict while not ready -> 503 (load balancer retries elsewhere)", s == 503)
    STATE["ready"] = True
    srv.shutdown()

    print("\nSchema compatibility (run in CI before publishing a new version)")
    v1_1 = dict(SCHEMA_V1, sepal_area={"type": "number", "min": 0, "max": 2500, "required": False})
    br, sf = check_compat(SCHEMA_V1, v1_1)
    check("adding an optional field is safe", not br and sf == ["added optional field 'sepal_area'"])
    v2 = {k: v for k, v in SCHEMA_V1.items() if k != "sepal_width"}
    v2["petal_length"] = dict(SCHEMA_V1["petal_length"], type="string")
    v2["region"] = {"type": "string", "required": True}
    br, _ = check_compat(SCHEMA_V1, v2)
    for line in br:
        print(f"      breaking: {line}")
    check("removed field, type change, and new required field are all breaking", len(br) == 3)

    passed = sum(results)
    print(f"\n{passed}/{len(results)} checks passed")
    return 0 if passed == len(results) else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--serve", type=int, metavar="PORT", help="run the server on PORT")
    args = ap.parse_args()
    if args.serve:
        STATE["ready"] = True
        print(f"serving on http://0.0.0.0:{args.serve}")
        ThreadingHTTPServer(("0.0.0.0", args.serve), Handler).serve_forever()
        return 0
    return demo()


if __name__ == "__main__":
    sys.exit(main())
