#!/usr/bin/env python3
"""Calculate LoRA trainable parameters, adapter size, and fine-tuning memory from a model's shapes.

LoRA freezes a weight W (d_out x d_in) and learns B (d_out x r) @ A (r x d_in), so each adapted matrix adds
r * (d_in + d_out) trainable parameters. With grouped-query attention, k_proj and v_proj have
d_out = kv_heads * head_dim, which is smaller than hidden.

The demo reproduces the numbers Hugging Face PEFT prints with model.print_trainable_parameters():
  Llama 2 7B,  r=8,  q,v               -> trainable 4,194,304   all 6,742,609,920
  Llama 3 8B,  r=16, q,k,v,o           -> trainable 13,631,488
  Llama 3 8B,  r=16, all linear layers -> trainable 41,943,040  all 8,072,204,288
and compares GPU memory for full fine-tuning, LoRA, and QLoRA.

Usage:
  python3 s26_lora_params.py                                   # demo + PASS/FAIL checks
  python3 s26_lora_params.py --model llama3-70b --r 16 --targets q,k,v,o,gate,up,down
  python3 s26_lora_params.py --hidden 896 --layers 24 --heads 14 --kv-heads 2 --inter 4864 --vocab 151936 --tied \
      --r 16 --targets q,k,v,o,gate,up,down                 # Qwen2.5-0.5B (base excludes its 27,648 q/k/v biases)
"""
import argparse
import sys

MODELS = {   # hidden, layers, heads, kv_heads, intermediate, vocab, tied embeddings
    "llama2-7b": dict(hidden=4096, layers=32, heads=32, kv_heads=32, inter=11008, vocab=32000, tied=False),
    "llama3-8b": dict(hidden=4096, layers=32, heads=32, kv_heads=8, inter=14336, vocab=128256, tied=False),
    "llama3-70b": dict(hidden=8192, layers=80, heads=64, kv_heads=8, inter=28672, vocab=128256, tied=False),
}
ALL_LINEAR = ["q", "k", "v", "o", "gate", "up", "down"]


def linear_shapes(cfg):
    """(d_in, d_out) of every linear layer in one Llama-style decoder block."""
    h, hd = cfg["hidden"], cfg["hidden"] // cfg["heads"]
    kv = cfg["kv_heads"] * hd
    return {"q": (h, h), "k": (h, kv), "v": (h, kv), "o": (h, h),
            "gate": (h, cfg["inter"]), "up": (h, cfg["inter"]), "down": (cfg["inter"], h)}


def base_params(cfg):
    per_layer = sum(i * o for i, o in linear_shapes(cfg).values()) + 2 * cfg["hidden"]   # + 2 RMSNorms
    emb = cfg["vocab"] * cfg["hidden"]
    return emb * (1 if cfg["tied"] else 2) + cfg["layers"] * per_layer + cfg["hidden"]  # + final norm


def lora_params(cfg, r, targets):
    shapes = linear_shapes(cfg)
    unknown = set(targets) - set(shapes)
    if unknown:
        raise ValueError(f"unknown targets {sorted(unknown)}; choose from {ALL_LINEAR}")
    per_layer = {t: r * (shapes[t][0] + shapes[t][1]) for t in targets}
    return cfg["layers"] * sum(per_layer.values()), per_layer


def memory_gb(cfg, trainable):
    """Rough GPU memory before activations, for mixed-precision AdamW (Section 7 rules)."""
    n = base_params(cfg)
    return {
        "full fine-tune (BF16 weights+grads, FP32 master+Adam)": n * 16 / 1e9,
        "LoRA (frozen BF16 base + adapter at 16 B/param)": (n * 2 + trainable * 16) / 1e9,
        "QLoRA (NF4 base ~0.55 B/param + adapter)": (n * 0.55 + trainable * 16) / 1e9,
    }


def report(name, cfg, r, targets):
    trainable, per_layer = lora_params(cfg, r, targets)
    base = base_params(cfg)
    total = base + trainable
    print(f"\n{name}: base {base:,} params. LoRA r={r} on {','.join(targets)}")
    print("  per layer: " + ", ".join(f"{t}={n:,}" for t, n in per_layer.items()))
    print(f"  trainable params: {trainable:,} || all params: {total:,} || trainable%: {100 * trainable / total:.4f}")
    print(f"  adapter file (BF16): {trainable * 2 / 1e6:.1f} MB vs full weights {base * 2 / 1e9:.1f} GB")
    for k, v in memory_gb(cfg, trainable).items():
        print(f"  {k:55s} {v:7.1f} GB")
    return trainable, total


def demo():
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"  {'PASS' if cond else 'FAIL'}  {name}")

    t27, a27 = report("llama2-7b", MODELS["llama2-7b"], 8, ["q", "v"])
    t38a, _ = report("llama3-8b", MODELS["llama3-8b"], 16, ["q", "k", "v", "o"])
    t38, a38 = report("llama3-8b", MODELS["llama3-8b"], 16, ALL_LINEAR)
    t70, a70 = report("llama3-70b", MODELS["llama3-70b"], 16, ALL_LINEAR)
    t38_r64, _ = lora_params(MODELS["llama3-8b"], 64, ALL_LINEAR)
    mem8 = memory_gb(MODELS["llama3-8b"], t38)
    mem70 = memory_gb(MODELS["llama3-70b"], t70)

    print("\nChecks:")
    check("Llama 2 7B r=8 q,v matches PEFT: 4,194,304 of 6,742,609,920", (t27, a27) == (4_194_304, 6_742_609_920))
    check("Llama 3 8B r=16 q,k,v,o matches PEFT: 13,631,488", t38a == 13_631_488)
    check("Llama 3 8B r=16 all-linear matches PEFT: 41,943,040 of 8,072,204,288", (t38, a38) == (41_943_040, 8_072_204_288))
    check("GQA makes k/v adapters smaller than q/o (1024-wide outputs vs 4096)",
          lora_params(MODELS["llama3-8b"], 16, ["k"])[0] < lora_params(MODELS["llama3-8b"], 16, ["q"])[0])
    check("trainable params scale linearly with rank (r=64 is 4x r=16)", t38_r64 == 4 * t38)
    check(f"LoRA trains well under 1% of Llama 3 8B ({100 * t38 / a38:.2f}%)", t38 / a38 < 0.01)
    check(f"full fine-tune of 8B needs >80 GB ({mem8['full fine-tune (BF16 weights+grads, FP32 master+Adam)']:.0f} GB), "
          f"so it can't fit one H100 even before activations",
          mem8["full fine-tune (BF16 weights+grads, FP32 master+Adam)"] > 80)
    q70 = mem70["QLoRA (NF4 base ~0.55 B/param + adapter)"]
    check(f"QLoRA of 70B fits on one 80 GB GPU before activations ({q70:.0f} GB)", q70 < 80)
    check(f"100 multi-LoRA adapters for 8B (r=16 all-linear) total {100 * t38 * 2 / 1e9:.1f} GB, about half the base model",
          100 * t38 * 2 < base_params(MODELS["llama3-8b"]) * 2)
    return 0 if ok else 1


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model", choices=sorted(MODELS))
    p.add_argument("--r", type=int, default=16)
    p.add_argument("--targets", default="q,k,v,o", help=f"comma list from {','.join(ALL_LINEAR)}")
    for f in ("hidden", "layers", "heads", "kv-heads", "inter", "vocab"):
        p.add_argument(f"--{f}", type=int)
    p.add_argument("--tied", action="store_true", help="input and output embeddings share weights (e.g. Qwen2.5-0.5B)")
    a = p.parse_args()
    custom = all(getattr(a, f.replace("-", "_")) for f in ("hidden", "layers", "heads", "kv-heads", "inter", "vocab"))
    if not (a.model or custom):
        return demo()
    cfg = MODELS[a.model] if a.model else dict(hidden=a.hidden, layers=a.layers, heads=a.heads,
                                               kv_heads=a.kv_heads, inter=a.inter, vocab=a.vocab, tied=a.tied)
    report(a.model or "custom", cfg, a.r, [t.strip() for t in a.targets.split(",")])
    return 0


if __name__ == "__main__":
    sys.exit(main())
