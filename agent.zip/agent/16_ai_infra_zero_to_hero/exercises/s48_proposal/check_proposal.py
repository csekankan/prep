#!/usr/bin/env python3
"""Section 48 lab: lint a capstone proposal for missing sections, unmeasurable metrics, and unowned risks.

Usage:
  python3 check_proposal.py                    # checks proposal.md next to this script
  python3 check_proposal.py docs/proposal.md   # checks your own proposal
"""
import re
import sys
from pathlib import Path

REQUIRED = ["Problem and users", "Success metrics", "Architecture", "Cost estimate",
            "Tools", "Risks", "Milestones", "Out of scope"]


def sections(text):
    parts = re.split(r"(?m)^## (.+)$", text)
    return {parts[i].strip(): parts[i + 1] for i in range(1, len(parts) - 1, 2)}


def table_rows(body):
    rows = [r for r in body.splitlines() if r.startswith("|") and not re.match(r"^\|[\s|:-]+\|$", r)]
    return [[c.strip() for c in r.strip("|").split("|")] for r in rows[1:]]


def main(path):
    secs = sections(Path(path).read_text())
    checks = []
    for name in REQUIRED:
        checks.append((f"section '{name}' present", any(h.startswith(name) for h in secs)))
    metrics = table_rows(secs.get("Success metrics", ""))
    checks.append(("at least 6 success metrics", len(metrics) >= 6))
    checks.append(("every metric has a numeric target", all(re.search(r"\d", m[-1]) for m in metrics)))
    checks.append(("architecture has a diagram", bool(re.search(r"(?m)^`{3}mermaid", secs.get("Architecture", "")))))
    cost = secs.get("Cost estimate", "")
    checks.append(("cost has a unit cost per 1,000 requests", "per 1,000" in cost))
    risks = table_rows(secs.get("Risks", ""))
    checks.append(("at least 5 risks", len(risks) >= 5))
    checks.append(("every risk has an owner", all(r[-1] for r in risks)))
    for name, ok in checks:
        print(f"{'PASS' if ok else 'FAIL'}  {name}")
    failed = sum(not ok for _, ok in checks)
    print(f"\n{len(checks) - failed}/{len(checks)} checks passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).with_name("proposal.md")))
