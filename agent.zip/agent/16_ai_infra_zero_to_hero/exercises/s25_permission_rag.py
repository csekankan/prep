#!/usr/bin/env python3
"""Permission-aware RAG retrieval: never put a chunk in the prompt that the user may not read.

A tiny RAG retriever (TF-IDF cosine, standard library only) over a multi-tenant corpus with document ACLs.
It compares:
  - naive retrieval (no ACL)                      -> leaks restricted chunks
  - post-filtering (top-k, then drop forbidden)    -> safe, but returns fewer than k results (lost recall)
  - pre-filtering (ACL filter inside the search)  -> safe and returns k results
and shows four more production rules:
  - ACL groups are tenant-scoped ("acme/all" is not "globex/all")
  - user groups are resolved at query time, so revocation is immediate
  - documents without an ACL are denied by default
  - a semantic/answer cache must be keyed by (query, permission fingerprint), or it leaks across users
Finally it assembles a prompt within a token budget, with citations to authorized chunks only.

Usage:
  python3 s25_permission_rag.py                                  # demo + PASS/FAIL checks
  python3 s25_permission_rag.py --user alice --query "salary bands for engineers" [--k 3] [--mode pre|post|naive]
"""
import argparse
import hashlib
import math
import re
import sys
from collections import Counter

DOCS = [
    # id, tenant, allowed groups (tenant-scoped), text
    ("acme-eng-1", "acme", ["eng"], "Deploy runbook for the payments service. Roll out with canary at 5 percent and watch error rate."),
    ("acme-eng-2", "acme", ["eng"], "GPU cluster quota for engineers is 64 H100 GPUs. Request more quota through the platform team."),
    ("acme-eng-3", "acme", ["eng"], "On-call engineers rotate weekly. Escalate payments incidents to the service owner."),
    ("acme-hr-1", "acme", ["hr"], "Salary bands for engineers: L4 base 150k to 190k, L5 base 190k to 240k, L6 base 240k to 300k."),
    ("acme-hr-2", "acme", ["hr"], "Performance review calibration for engineers happens in March. Salary changes apply in April."),
    ("acme-fin-1", "acme", ["finance"], "Q3 GPU spend was 4.2 million dollars. Engineers' cluster quota drove 60 percent of spend."),
    ("acme-all-1", "acme", ["all"], "Company holiday calendar and office hours. Engineers may work remotely on Fridays."),
    ("acme-all-2", "acme", ["all"], "Expense policy: submit receipts within 30 days. Travel for engineers needs manager approval."),
    ("acme-legacy", "acme", [], "Legacy wiki export: engineers salary spreadsheet link and admin passwords for the old cluster."),
    ("globex-all-1", "globex", ["all"], "Globex onboarding guide for engineers. Laptop setup and VPN access."),
    ("globex-eng-1", "globex", ["eng"], "Globex GPU cluster quota for engineers is 16 A100 GPUs per team."),
    ("globex-hr-1", "globex", ["hr"], "Globex salary bands for engineers: E1 base 120k, E2 base 150k."),
]

DIRECTORY = {   # identity provider: user -> tenant and groups, read at query time
    "alice": ("acme", {"eng", "all"}),
    "bob": ("acme", {"hr", "all"}),
    "dave": ("acme", {"eng", "finance", "all"}),
    "carol": ("globex", {"eng", "all"}),
}

STOP = {"the", "a", "for", "and", "to", "of", "is", "in", "at", "with", "on", "per", "what", "are", "how", "our"}


def tokenize(text):
    return [t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in STOP]


def chunk(doc_id, tenant, groups, text):
    """Split by sentence. Every chunk inherits its document's ACL (tenant-scoped groups)."""
    parts = [s.strip() for s in re.split(r"(?<=[.:])\s+", text) if s.strip()]
    acl = {f"{tenant}/{g}" for g in groups}
    return [{"id": f"{doc_id}#{i}", "doc": doc_id, "tenant": tenant, "acl": acl, "text": s}
            for i, s in enumerate(parts)]


class Index:
    def __init__(self, docs, tenant_scoped=True):
        self.chunks = []
        for doc_id, tenant, groups, text in docs:
            for c in chunk(doc_id, tenant, groups, text):
                if not tenant_scoped:
                    c["acl"] = set(groups)       # the bug: bare group names collide across tenants
                self.chunks.append(c)
        df = Counter(t for c in self.chunks for t in set(tokenize(c["text"])))
        n = len(self.chunks)
        self.idf = {t: math.log((1 + n) / (1 + d)) + 1 for t, d in df.items()}
        for c in self.chunks:
            c["vec"] = self._vec(c["text"])

    def _vec(self, text):
        tf = Counter(tokenize(text))
        v = {t: tf[t] * self.idf.get(t, 0.0) for t in tf}
        norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        return {t: x / norm for t, x in v.items()}

    def score(self, qv, c):
        return sum(w * c["vec"].get(t, 0.0) for t, w in qv.items())

    def search(self, query, k, allow=None):
        """allow: a predicate applied INSIDE the search (pre-filter), like a vector DB metadata filter."""
        qv = self._vec(query)
        cands = [c for c in self.chunks if allow is None or allow(c)]
        ranked = sorted(cands, key=lambda c: (-self.score(qv, c), c["id"]))
        return [c for c in ranked[:k] if self.score(qv, c) > 0]


def principal(user, directory=DIRECTORY, tenant_scoped=True):
    tenant, groups = directory[user]
    return tenant, ({f"{tenant}/{g}" for g in groups} if tenant_scoped else set(groups))


def can_read(user, c, directory=DIRECTORY, tenant_scoped=True):
    tenant, groups = principal(user, directory, tenant_scoped)
    if not c["acl"]:
        return False                                   # deny by default
    if tenant_scoped and c["tenant"] != tenant:
        return False
    return bool(c["acl"] & groups)


def retrieve(index, user, query, k=3, mode="pre", directory=DIRECTORY, tenant_scoped=True):
    if mode == "naive":
        return index.search(query, k)
    if mode == "post":
        return [c for c in index.search(query, k) if can_read(user, c, directory, tenant_scoped)]
    return index.search(query, k, allow=lambda c: can_read(user, c, directory, tenant_scoped))


def acl_fingerprint(user, directory=DIRECTORY):
    tenant, groups = principal(user, directory)
    return hashlib.sha256((tenant + "|" + ",".join(sorted(groups))).encode()).hexdigest()[:12]


class AnswerCache:
    def __init__(self, permission_aware):
        self.permission_aware, self.store = permission_aware, {}

    def key(self, user, query):
        q = " ".join(sorted(set(tokenize(query))))
        return (q, acl_fingerprint(user)) if self.permission_aware else (q,)

    def get_or_compute(self, user, query, compute):
        k = self.key(user, query)
        if k not in self.store:
            self.store[k] = compute()
        return self.store[k]


def build_prompt(query, chunks, budget_tokens=60):
    """Add retrieved chunks until the token budget is reached (words ~ tokens here), with citations."""
    used, ctx, cites = 0, [], []
    for c in chunks:
        n = len(c["text"].split())
        if used + n > budget_tokens:
            break
        ctx.append(f"[{c['id']}] {c['text']}")
        cites.append(c["id"])
        used += n
    prompt = ("Answer only from the context. Cite chunk ids. If the context is insufficient, say so.\n\n"
              + "\n".join(ctx) + f"\n\nQuestion: {query}")
    return prompt, cites, used


def demo(k=3):
    idx = Index(DOCS)
    queries = ["salary bands for engineers", "GPU cluster quota for engineers", "engineers salary spreadsheet"]
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"  {'PASS' if cond else 'FAIL'}  {name}")

    leaks, short_post, full_pre = 0, 0, 0
    print(f"Corpus: {len(DOCS)} documents, {len(idx.chunks)} chunks, 2 tenants. k={k}\n")
    for user in DIRECTORY:
        for q in queries:
            naive = retrieve(idx, user, q, k, "naive")
            post = retrieve(idx, user, q, k, "post")
            pre = retrieve(idx, user, q, k, "pre")
            leaks += sum(not can_read(user, c) for c in naive)
            short_post += len(post) < len(pre)
            full_pre += len(pre) == k
            if q == queries[0]:
                print(f"{user:6s} '{q}'")
                print(f"   naive: {[c['id'] for c in naive]}")
                print(f"   post : {[c['id'] for c in post]}")
                print(f"   pre  : {[c['id'] for c in pre]}")

    print("\nChecks:")
    check(f"naive retrieval leaks forbidden chunks ({leaks} leaked across users and queries)", leaks > 0)
    all_safe = all(can_read(u, c) for u in DIRECTORY for q in queries
                   for m in ("pre", "post") for c in retrieve(idx, u, q, k, m))
    check("pre- and post-filtering never return a forbidden chunk", all_safe)
    check(f"post-filtering loses recall ({short_post} user/query pairs got fewer results than pre-filtering)",
          short_post > 0)
    check(f"pre-filtering returns a full top-{k} whenever enough authorized chunks exist", full_pre > 0)

    bad_idx = Index(DOCS, tenant_scoped=False)
    cross = [c["id"] for c in retrieve(bad_idx, "carol", "engineers remotely Fridays expense", k, "pre",
                                       tenant_scoped=False) if c["tenant"] != "globex"]
    good = [c["id"] for c in retrieve(idx, "carol", "engineers remotely Fridays expense", k, "pre")
            if c["tenant"] != "globex"]
    check(f"bare group names leak across tenants ({cross}), tenant-scoped ACLs do not", cross and not good)

    legacy = any(c["doc"] == "acme-legacy" for u in DIRECTORY
                 for c in retrieve(idx, u, "engineers salary spreadsheet passwords", k, "pre"))
    check("documents with no ACL are denied by default (acme-legacy never returned)", not legacy)

    before = {c["doc"] for c in retrieve(idx, "dave", "GPU spend quota", k, "pre")}
    revoked = dict(DIRECTORY, dave=("acme", {"eng", "all"}))
    after = {c["doc"] for c in retrieve(idx, "dave", "GPU spend quota", k, "pre", directory=revoked)}
    check(f"revoking dave from finance takes effect on the next query (before {sorted(before)}, after {sorted(after)})",
          "acme-fin-1" in before and "acme-fin-1" not in after)

    for aware in (False, True):
        cache = AnswerCache(permission_aware=aware)
        bob_ans = cache.get_or_compute("bob", "salary bands engineers",
                                       lambda: [c["id"] for c in retrieve(idx, "bob", "salary bands engineers", k)])
        alice_ans = cache.get_or_compute("alice", "engineers salary bands",
                                         lambda: [c["id"] for c in retrieve(idx, "alice", "engineers salary bands", k)])
        leaked = any(cid.startswith("acme-hr") for cid in alice_ans)
        if not aware:
            check(f"query-only cache key leaks bob's HR answer to alice ({alice_ans[:2]})", leaked)
        else:
            check("cache key (query, ACL fingerprint) keeps alice and bob separate", not leaked and bob_ans != alice_ans)

    chunks = retrieve(idx, "alice", "GPU cluster quota for engineers", 5)
    prompt, cites, used = build_prompt("What is our GPU quota?", chunks, budget_tokens=40)
    check(f"prompt fits the token budget ({used} <= 40) and cites only authorized chunks {cites}",
          used <= 40 and cites and all(can_read("alice", c) for c in idx.chunks if c["id"] in cites))
    return 0 if ok else 1


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--user", choices=sorted(DIRECTORY))
    p.add_argument("--query")
    p.add_argument("--k", type=int, default=3)
    p.add_argument("--mode", choices=["pre", "post", "naive"], default="pre")
    a = p.parse_args()
    if not (a.user and a.query):
        return demo(a.k)
    idx = Index(DOCS)
    chunks = retrieve(idx, a.user, a.query, a.k, a.mode)
    for c in chunks:
        flag = "" if can_read(a.user, c) else "   <-- FORBIDDEN"
        print(f"{idx.score(idx._vec(a.query), c):.3f}  {c['id']:14s}  {c['text']}{flag}")
    prompt, cites, used = build_prompt(a.query, chunks)
    print(f"\n--- prompt ({used} tokens, citations {cites}) ---\n{prompt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
