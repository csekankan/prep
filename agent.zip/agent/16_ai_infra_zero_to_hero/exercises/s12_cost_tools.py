"""Section 12 exercises: (1) calculate an AI cloud workload's monthly cost and the effect of each saving
lever, and (2) detect a cost spike in daily billing data and attribute it to team and service.

Prices are illustrative list prices; replace them with your own contract rates.

Part 1, cost model per month:
  training  = GPU-hours x price, split across on-demand / reserved / spot; spot adds rework overhead
  inference = sum over the day of replicas(hour) x price x 30   (autoscaling vs fixed peak)
  storage   = TB per tier x price per GB-month
  egress    = TB out x price per GB
Part 2, spike detection:
  a day is anomalous when total cost > mean + 3 x stdev of the previous 14 normal (non-anomalous) days;
  contributors = per (team, service) increase vs their own 14-day mean, largest first.

Usage:
  python3 s12_cost_tools.py              # both parts with sample data
  python3 s12_cost_tools.py --calc       # part 1 only
  python3 s12_cost_tools.py --spike      # part 2 only
  python3 s12_cost_tools.py --spike --csv billing.csv   # columns: date,team,service,cost
"""

import argparse
import csv
import random
import statistics
from collections import defaultdict

HOURS = 730
PRICE = {"h100_on_demand": 4.00, "h100_reserved_1y": 2.60, "h100_spot": 1.80, "l4": 0.80,
         "s3_standard": 0.023, "s3_ia": 0.0125, "s3_glacier_ir": 0.004, "egress_internet": 0.09}


def training_cost(gpu_hours, mix, spot_rework=0.10):
    od = gpu_hours * mix["on_demand"] * PRICE["h100_on_demand"]
    rs = gpu_hours * mix["reserved"] * PRICE["h100_reserved_1y"]
    sp = gpu_hours * mix["spot"] * (1 + spot_rework) * PRICE["h100_spot"]
    return od + rs + sp


def inference_cost(profile):
    """profile: list of (hours_per_day, replicas)."""
    return sum(h * r for h, r in profile) * 30 * PRICE["l4"]


def storage_cost(tb_by_tier):
    return sum(tb * 1024 * PRICE[tier] for tier, tb in tb_by_tier.items())


def egress_cost(tb):
    return tb * 1024 * PRICE["egress_internet"]


def calc_demo():
    print("Part 1 — monthly cost of an AI workload (illustrative prices)\n")
    base = {
        "training (64 H100s x 2 weeks, all on-demand)": training_cost(64 * 336, {"on_demand": 1, "reserved": 0, "spot": 0}),
        "inference (12 L4 replicas, fixed for peak, 24 h)": inference_cost([(24, 12)]),
        "storage (200 TB, all S3 Standard)": storage_cost({"s3_standard": 200}),
        "egress (20 TB to the internet)": egress_cost(20),
    }
    opt = {
        "training: 40% reserved + 60% spot (10% rework)": training_cost(64 * 336, {"on_demand": 0, "reserved": 0.4, "spot": 0.6}),
        "inference: autoscale 12 peak / 6 day / 2 night": inference_cost([(10, 12), (8, 6), (6, 2)]),
        "storage: lifecycle 40% Std / 40% IA / 20% Glacier IR": storage_cost({"s3_standard": 80, "s3_ia": 80, "s3_glacier_ir": 40}),
        "egress: CDN + compression halves bytes": egress_cost(10),
    }
    width = 56
    print(f"  {'BEFORE':<{width}} {'$/month':>10}")
    for k, v in base.items():
        print(f"  {k:<{width}} {v:>10,.0f}")
    tb = sum(base.values())
    print(f"  {'TOTAL':<{width}} {tb:>10,.0f}\n")
    print(f"  {'AFTER':<{width}} {'$/month':>10} {'saved':>9}")
    for (k, v), b in zip(opt.items(), base.values()):
        print(f"  {k:<{width}} {v:>10,.0f} {1 - v / b:>8.0%}")
    ta = sum(opt.values())
    print(f"  {'TOTAL':<{width}} {ta:>10,.0f} {1 - ta / tb:>8.0%}")
    return tb, ta


def sample_billing(seed=3):
    rng = random.Random(seed)
    base = {("search", "gpu-inference"): 2400, ("search", "storage"): 300, ("research", "gpu-training"): 3100,
            ("research", "notebooks-gpu"): 450, ("platform", "nat-gateway"): 180, ("platform", "logging"): 260}
    rows = []
    for day in range(1, 31):
        for (team, svc), cost in base.items():
            c = cost * rng.uniform(0.92, 1.08)
            if day >= 26 and svc == "notebooks-gpu":
                c = cost * 7.5      # 40 GPU notebooks left running over a long weekend
            if day >= 27 and svc == "nat-gateway":
                c = cost * 9        # new autoscaler churn: every new pod downloads 15 GB of weights via NAT
            rows.append({"date": f"2026-10-{day:02d}", "team": team, "service": svc, "cost": round(c, 2)})
    return rows


def detect_spikes(rows, window=14, z=3.0):
    by_day, by_key_day = defaultdict(float), defaultdict(lambda: defaultdict(float))
    for r in rows:
        by_day[r["date"]] += float(r["cost"])
        by_key_day[(r["team"], r["service"])][r["date"]] += float(r["cost"])
    days = sorted(by_day)
    normal = days[:window]  # anomalous days are kept out of the baseline, or one spike hides the next
    alerts = []
    for day in days[window:]:
        ref = normal[-window:]
        hist = [by_day[d] for d in ref]
        mean, sd = statistics.mean(hist), statistics.pstdev(hist) or 1.0
        today = by_day[day]
        if today > mean + z * sd:
            contrib = []
            for key, series in by_key_day.items():
                delta = series.get(day, 0.0) - statistics.mean(series.get(d, 0.0) for d in ref)
                if delta > 0:
                    contrib.append((delta, key))
            contrib.sort(reverse=True)
            alerts.append({"date": day, "total": today, "baseline": mean, "sd": sd, "top": contrib[:3]})
        else:
            normal.append(day)
    return alerts


ACTIONS = {
    "notebooks-gpu": "idle-shutdown for notebooks (e.g. 2 h), GPU quota per user, weekend schedule",
    "nat-gateway": "serve weights from S3 via VPC endpoint or a node-local cache; stop download-per-pod",
    "gpu-training": "check for duplicated or runaway jobs; require queue + budget per team",
    "gpu-inference": "check autoscaler max and traffic; look for retry storms",
    "logging": "cut debug logs, sample, shorten retention",
    "storage": "lifecycle rules; delete orphaned checkpoints",
}


def spike_demo(rows):
    print("\nPart 2 — cost spike detection on daily billing data\n")
    alerts = detect_spikes(rows)
    if not alerts:
        print("  no anomalous days")
        return alerts
    for a in alerts:
        print(f"  {a['date']}: ${a['total']:,.0f} vs baseline ${a['baseline']:,.0f} "
              f"(+{(a['total'] - a['baseline']) / a['sd']:.0f} sd)")
        for delta, (team, svc) in a["top"]:
            print(f"      +${delta:>7,.0f}  team={team:<9} service={svc:<14} -> {ACTIONS.get(svc, 'investigate')}")
    first = alerts[0]
    extra = sum(a["total"] - a["baseline"] for a in alerts)
    print(f"\n  First alert on {first['date']}; excess spend over the alert days: ${extra:,.0f}. "
          f"At this rate an unnoticed month costs ~${(alerts[-1]['total'] - alerts[-1]['baseline']) * 30:,.0f}.")
    return alerts


def demo():
    before, after = calc_demo()
    alerts = spike_demo(sample_billing())
    print("\nChecks:")
    checks = [
        ("optimized plan is cheaper by more than 40%", after < before * 0.6),
        ("spike detected on the first bad day (2026-10-26)", alerts and alerts[0]["date"] == "2026-10-26"),
        ("every bad day flagged (26 to 30), no false alarms", [a["date"][-2:] for a in alerts] == ["26", "27", "28", "29", "30"]),
        ("top contributor on day 26 is research notebooks-gpu", alerts and alerts[0]["top"][0][1] == ("research", "notebooks-gpu")),
        ("NAT gateway named from day 27", any(("platform", "nat-gateway") in [k for _, k in a["top"]] for a in alerts[1:])),
    ]
    for label, ok in checks:
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}")
    return 0 if all(ok for _, ok in checks) else 1


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--calc", action="store_true", help="run part 1 only")
    p.add_argument("--spike", action="store_true", help="run part 2 only")
    p.add_argument("--csv", help="billing CSV for --spike (date,team,service,cost)")
    a = p.parse_args()
    if a.calc:
        calc_demo()
        return 0
    if a.spike:
        rows = list(csv.DictReader(open(a.csv))) if a.csv else sample_billing()
        spike_demo(rows)
        return 0
    return demo()


if __name__ == "__main__":
    raise SystemExit(main())
