#!/usr/bin/env bash
# Section 2 exercise: a system health check for AI nodes.
#
# Usage:   bash s02_system_health.sh [--quiet]
# Exit:    0 = healthy, 1 = warning, 2 = critical  (so cron/monitoring can act on it)
# Tuning:  override thresholds with env vars, e.g. DISK_WARN=70 DISK_CRIT=85 bash s02_system_health.sh
#
# Works on Linux (full checks) and macOS (CPU, memory, disk only). Every check that can't run on this
# machine is reported as SKIP instead of failing.

set -uo pipefail   # no -e: a failing check must be recorded, not abort the whole script

LOAD_WARN="${LOAD_WARN:-1.0}"      # load average per core
LOAD_CRIT="${LOAD_CRIT:-2.0}"
MEM_WARN="${MEM_WARN:-15}"         # % memory available, below this is bad
MEM_CRIT="${MEM_CRIT:-5}"
DISK_WARN="${DISK_WARN:-80}"       # % used
DISK_CRIT="${DISK_CRIT:-90}"
GPU_TEMP_WARN="${GPU_TEMP_WARN:-80}"   # °C
GPU_TEMP_CRIT="${GPU_TEMP_CRIT:-88}"
GPU_MEM_WARN="${GPU_MEM_WARN:-95}"     # % used

QUIET=0
[[ "${1:-}" == "--quiet" ]] && QUIET=1

STATUS=0   # worst result seen so far
OS="$(uname -s)"

report() {   # report <level> <check> <message>
  local level="$1" check="$2" msg="$3"
  case "$level" in
    WARN) (( STATUS < 1 )) && STATUS=1 ;;
    CRIT) STATUS=2 ;;
  esac
  if (( QUIET == 0 )) || [[ "$level" == WARN || "$level" == CRIT ]]; then
    printf '%-5s %-8s %s\n' "$level" "$check" "$msg"
  fi
}

# Float comparison without bc: returns 0 (true) if $1 >= $2.
ge() { awk -v a="$1" -v b="$2" 'BEGIN { exit !(a >= b) }'; }

check_cpu() {
  local cores load1 per_core
  if [[ "$OS" == "Linux" ]]; then
    cores="$(nproc)"
    load1="$(cut -d' ' -f1 /proc/loadavg)"
  else
    cores="$(sysctl -n hw.ncpu 2>/dev/null)"
    load1="$(sysctl -n vm.loadavg 2>/dev/null | awk '{print $2}')"
  fi
  if [[ -z "${cores:-}" || -z "${load1:-}" ]]; then report SKIP cpu "cannot read load average"; return; fi
  per_core="$(awk -v l="$load1" -v c="$cores" 'BEGIN { printf "%.2f", l / c }')"
  local msg="load1=${load1} cores=${cores} per_core=${per_core}"
  if ge "$per_core" "$LOAD_CRIT"; then report CRIT cpu "$msg"
  elif ge "$per_core" "$LOAD_WARN"; then report WARN cpu "$msg"
  else report OK cpu "$msg"; fi
}

check_memory() {
  local avail_pct
  if [[ "$OS" == "Linux" ]]; then
    # MemAvailable is the kernel's estimate of memory usable without swapping; MemFree alone is misleading.
    avail_pct="$(awk '/MemTotal/ {t=$2} /MemAvailable/ {a=$2} END { printf "%.0f", a * 100 / t }' /proc/meminfo)"
  elif [[ "$OS" == "Darwin" ]]; then
    avail_pct="$(memory_pressure 2>/dev/null | awk -F': ' '/free percentage/ {gsub("%","",$2); print $2}')"
  fi
  if [[ -z "${avail_pct:-}" ]]; then report SKIP memory "cannot read memory stats"; return; fi
  local msg="available=${avail_pct}%"
  if (( avail_pct <= MEM_CRIT )); then report CRIT memory "$msg"
  elif (( avail_pct <= MEM_WARN )); then report WARN memory "$msg"
  else report OK memory "$msg"; fi
}

check_disks() {
  # -P gives one line per filesystem (POSIX format). Fields are read from the end because device names
  # can contain spaces; zero-size pseudo filesystems are skipped.
  df -P 2>/dev/null | awk 'NR > 1 && $(NF-4) > 0 { print $(NF-1), $NF }' | while read -r used mount; do
    used="${used%\%}"
    [[ "$used" =~ ^[0-9]+$ ]] || continue
    case "$mount" in /dev|/dev/*|/proc*|/sys*|/run*|/snap/*|/System/Volumes/*|/private/var/vm) continue ;; esac
    local msg="${mount} used=${used}%"
    if (( used >= DISK_CRIT )); then echo "CRIT $msg"
    elif (( used >= DISK_WARN )); then echo "WARN $msg"
    else echo "OK $msg"; fi
  done > /tmp/.health_disks.$$
  # The while-loop above runs in a subshell, so results are passed back through a file.
  while read -r level msg; do report "$level" disk "$msg"; done < /tmp/.health_disks.$$
  rm -f /tmp/.health_disks.$$
}

check_gpu() {
  if ! command -v nvidia-smi >/dev/null 2>&1; then
    report SKIP gpu "nvidia-smi not found (no NVIDIA GPU or driver)"
    return
  fi
  local out
  if ! out="$(nvidia-smi --query-gpu=index,name,utilization.gpu,memory.used,memory.total,temperature.gpu \
              --format=csv,noheader,nounits 2>&1)"; then
    report CRIT gpu "nvidia-smi failed: ${out}"   # driver/hardware problem, the node shouldn't take work
    return
  fi
  out="$(sed 's/, */,/g' <<< "$out")"   # nvidia-smi pads fields with spaces after commas
  while IFS=',' read -r idx name util mem_used mem_total temp; do
    local mem_pct=$(( mem_used * 100 / mem_total ))
    local msg="gpu${idx} ${name} util=${util}% mem=${mem_pct}% temp=${temp}C"
    if (( temp >= GPU_TEMP_CRIT )); then report CRIT gpu "$msg"
    elif (( temp >= GPU_TEMP_WARN || mem_pct >= GPU_MEM_WARN )); then report WARN gpu "$msg"
    else report OK gpu "$msg"; fi
  done <<< "$out"
}

check_kernel_log() {
  if [[ "$OS" != "Linux" ]]; then report SKIP kernel "kernel log checks are Linux-only"; return; fi
  local log
  if ! log="$(dmesg -T 2>/dev/null || journalctl -k --since '-1h' 2>/dev/null)" || [[ -z "$log" ]]; then
    report SKIP kernel "cannot read kernel log (try sudo)"
    return
  fi
  local ooms xids
  ooms="$(grep -ciE 'out of memory|oom-kill' <<< "$log" || true)"
  xids="$(grep -ciE 'NVRM: Xid' <<< "$log" || true)"
  if (( xids > 0 )); then report CRIT kernel "${xids} NVIDIA Xid error(s): check 'dmesg -T | grep Xid'"
  elif (( ooms > 0 )); then report WARN kernel "${ooms} OOM kill message(s) in kernel log"
  else report OK kernel "no OOM kills or Xid errors"; fi
}

(( QUIET == 0 )) && echo "Health check on $(hostname) ($OS) at $(date '+%Y-%m-%d %H:%M:%S')"
check_cpu
check_memory
check_disks
check_gpu
check_kernel_log

if (( QUIET == 0 )); then
  case "$STATUS" in 0) echo "RESULT: healthy" ;; 1) echo "RESULT: warning" ;; 2) echo "RESULT: critical" ;; esac
fi
exit "$STATUS"
