"""Section 7 exercise: estimate GPU memory for LLM inference and training, and which GPUs fit.

Inference memory = weights + KV cache + overhead
  weights   = params x bytes_per_param (fp32 4, bf16/fp16 2, fp8/int8 1, int4 0.5)
  KV cache  = 2 (K and V) x layers x kv_heads x head_dim x bytes x tokens_in_flight
  overhead  = CUDA context + activations + fragmentation (~1 GB + 10% here)

Training memory (mixed precision, Adam) = model states + activations
  model states = 16 bytes/param: bf16 weights 2 + bf16 grads 2 + fp32 master weights 4 + Adam m 4 + Adam v 4
                 divided by the number of GPUs when sharded with FSDP / ZeRO-3
  activations  = per layer ~34 x seq x micro_batch x hidden bytes (FlashAttention, no recompute)
                 or ~2 x seq x micro_batch x hidden bytes per layer with full activation checkpointing
                 plus fp32 logits: seq x micro_batch x vocab x 4 bytes

These are planning estimates (+/- 15%). Always confirm with torch.cuda.max_memory_allocated().

Usage:
  python3 s07_gpu_memory_estimate.py                                   # assessment scenarios
  python3 s07_gpu_memory_estimate.py --model llama3-8b --mode infer --dtype bf16 --batch 16 --seq 8192
  python3 s07_gpu_memory_estimate.py --model llama3-70b --mode infer --dtype int4 --batch 8 --seq 4096
  python3 s07_gpu_memory_estimate.py --model llama3-8b --mode train --gpus 8 --batch 1 --seq 4096 --checkpointing
  python3 s07_gpu_memory_estimate.py --list
"""

import argparse
import math

GB = 1e9

MODELS = {
    # name: params, layers, hidden, attention heads, kv heads, head_dim, vocab
    "llama3-8b": dict(params=8.03e9, layers=32, hidden=4096, heads=32, kv_heads=8, head_dim=128, vocab=128256),
    "llama3-70b": dict(params=70.6e9, layers=80, hidden=8192, heads=64, kv_heads=8, head_dim=128, vocab=128256),
    "mistral-7b": dict(params=7.24e9, layers=32, hidden=4096, heads=32, kv_heads=8, head_dim=128, vocab=32000),
    "gpt2-xl": dict(params=1.56e9, layers=48, hidden=1600, heads=25, kv_heads=25, head_dim=64, vocab=50257),
}

GPUS = [  # name, memory in GB as marketed
    ("T4", 16), ("L4", 24), ("A10G", 24), ("A100-40GB", 40), ("A100-80GB", 80),
    ("H100-80GB", 80), ("H200-141GB", 141), ("MI300X-192GB", 192),
]

DTYPE_BYTES = {"fp32": 4, "bf16": 2, "fp16": 2, "fp8": 1, "int8": 1, "int4": 0.5}
USABLE = 0.90  # leave ~10% of the card free for the allocator and spikes


def kv_bytes_per_token(m, kv_dtype_bytes):
    return 2 * m["layers"] * m["kv_heads"] * m["head_dim"] * kv_dtype_bytes


def inference(m, dtype, batch, seq, kv_dtype):
    weights = m["params"] * DTYPE_BYTES[dtype]
    kv_tok = kv_bytes_per_token(m, DTYPE_BYTES[kv_dtype])
    kv = kv_tok * batch * seq
    overhead = 1 * GB + 0.10 * (weights + kv)
    return {"weights": weights, "kv_cache": kv, "overhead": overhead}, kv_tok


def training(m, gpus, batch, seq, checkpointing):
    states = 16 * m["params"] / gpus
    sbh = seq * batch * m["hidden"]
    if checkpointing:
        acts = 2 * sbh * m["layers"] + 34 * sbh  # stored layer inputs + one layer being recomputed
    else:
        acts = 34 * sbh * m["layers"]
    logits = seq * batch * m["vocab"] * 4
    overhead = 1 * GB + 0.10 * (states + acts)
    return {"model_states(sharded)" if gpus > 1 else "model_states": states,
            "activations": acts, "logits_fp32": logits, "overhead": overhead}


def fit_table(total_bytes, per_gpu=False):
    rows = []
    for name, mem in GPUS:
        usable = mem * GB * USABLE
        if per_gpu:
            rows.append((name, mem, "fits" if total_bytes <= usable else "does NOT fit"))
        else:
            n = math.ceil(total_bytes / usable)
            n_tp = 1 << (n - 1).bit_length()  # tensor parallel sizes are powers of two
            rows.append((name, mem, f"{n_tp} GPU(s)" + ("" if n_tp <= 8 else "  (multi-node)")))
    return rows


def report(title, parts, rows, extra=""):
    total = sum(parts.values())
    print(f"\n=== {title}")
    for k, v in parts.items():
        print(f"  {k:<22} {v / GB:8.1f} GB")
    print(f"  {'TOTAL':<22} {total / GB:8.1f} GB" + (f"   {extra}" if extra else ""))
    print("  " + "  ".join(f"{n} ({mem} GB): {verdict}" for n, mem, verdict in rows[:4]))
    print("  " + "  ".join(f"{n} ({mem} GB): {verdict}" for n, mem, verdict in rows[4:]))
    return total


def run_infer(model, dtype, batch, seq, kv_dtype):
    m = MODELS[model]
    parts, kv_tok = inference(m, dtype, batch, seq, kv_dtype)
    title = f"Inference {model} weights={dtype} kv={kv_dtype} batch={batch} seq={seq}"
    extra = f"(KV cache {kv_tok / 1024:.0f} KiB per token)"
    return report(title, parts, fit_table(sum(parts.values())), extra)


def run_train(model, gpus, batch, seq, checkpointing):
    m = MODELS[model]
    parts = training(m, gpus, batch, seq, checkpointing)
    title = (f"Training {model} on {gpus} GPU(s) {'FSDP/ZeRO-3 ' if gpus > 1 else ''}micro_batch={batch} "
             f"seq={seq} checkpointing={'on' if checkpointing else 'off'}  (per GPU)")
    return report(title, parts, fit_table(sum(parts.values()), per_gpu=True))


def demo():
    print("GPU memory estimates (planning numbers, +/-15%). 'N GPU(s)' = smallest power-of-two tensor-parallel group.")
    run_infer("llama3-8b", "bf16", 1, 4096, "bf16")
    run_infer("llama3-8b", "bf16", 16, 8192, "bf16")
    run_infer("llama3-70b", "bf16", 8, 4096, "bf16")
    run_infer("llama3-70b", "int4", 8, 4096, "fp8")
    run_train("llama3-8b", 1, 1, 4096, False)
    run_train("llama3-8b", 8, 1, 4096, True)
    run_train("llama3-70b", 64, 1, 4096, True)
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model", choices=MODELS)
    p.add_argument("--mode", choices=["infer", "train"], default="infer")
    p.add_argument("--dtype", choices=DTYPE_BYTES, default="bf16", help="weight precision (inference)")
    p.add_argument("--kv-dtype", choices=DTYPE_BYTES, default="bf16")
    p.add_argument("--batch", type=int, default=1, help="concurrent sequences (inference) or micro-batch (training)")
    p.add_argument("--seq", type=int, default=4096, help="tokens per sequence")
    p.add_argument("--gpus", type=int, default=1, help="GPUs sharing model states (training, FSDP/ZeRO-3)")
    p.add_argument("--checkpointing", action="store_true", help="activation checkpointing (training)")
    p.add_argument("--list", action="store_true", help="list models and GPUs")
    args = p.parse_args()
    if args.list:
        for k, v in MODELS.items():
            print(f"{k:<12} {v['params'] / 1e9:5.1f}B params, {v['layers']} layers, hidden {v['hidden']}, "
                  f"kv_heads {v['kv_heads']}")
        print("GPUs:", ", ".join(f"{n} {m} GB" for n, m in GPUS))
        return 0
    if not args.model:
        return demo()
    if args.mode == "infer":
        run_infer(args.model, args.dtype, args.batch, args.seq, args.kv_dtype)
    else:
        run_train(args.model, args.gpus, args.batch, args.seq, args.checkpointing)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
