"""Section 8 exercise: plan a distributed global batch size.

  data_parallel (DP)   = GPUs / (tensor_parallel x pipeline_parallel)
  global_batch         = micro_batch x grad_accum_steps x DP
  grad_accum_steps     = global_batch / (micro_batch x DP)          must be a whole number
  learning rate        = base_lr x (global / base_batch)            linear rule (SGD)
                       = base_lr x sqrt(global / base_batch)        square-root rule (Adam-family, a starting point)
  pipeline bubble      = (PP - 1) / (micro_batches + PP - 1)        idle fraction with 1F1B scheduling

The micro-batch is the most samples one GPU can process at once (set by memory, see Section 7).
Everything else follows from the global batch you want for convergence.

Usage:
  python3 s08_global_batch_plan.py                       # worked scenarios from the section
  python3 s08_global_batch_plan.py --gpus 32 --micro-batch 64 --global-batch 2048 \
      --base-lr 0.1 --base-batch 256 --optimizer sgd --dataset 1281167
  python3 s08_global_batch_plan.py --gpus 2048 --tp 8 --pp 4 --micro-batch 1 --global-batch 1024 \
      --seq 4096 --base-lr 3e-4 --base-batch 1024 --optimizer adam
"""

import argparse
import math


def plan(gpus, micro, global_batch, tp=1, pp=1, seq=None, base_lr=None, base_batch=None,
         optimizer="sgd", dataset=None, warmup_epochs=5, step_time_s=None, quiet=False):
    out = {"ok": True, "problems": [], "suggestions": []}
    say = (lambda *a: None) if quiet else print

    if gpus % (tp * pp):
        out["ok"] = False
        out["problems"].append(f"{gpus} GPUs is not divisible by TP x PP = {tp * pp}")
        say("  PROBLEM:", out["problems"][-1])
        return out
    dp = gpus // (tp * pp)
    per_step = micro * dp
    out["dp"] = dp
    say(f"  layout          : {gpus} GPUs = DP {dp} x TP {tp} x PP {pp}")
    say(f"  one micro-step  : {micro} per GPU x {dp} replicas = {per_step} samples")

    if global_batch % per_step:
        out["ok"] = False
        out["problems"].append(f"global batch {global_batch} is not a multiple of micro x DP = {per_step}")
        lo = max(per_step, global_batch // per_step * per_step)
        hi = lo + per_step
        out["suggestions"].append(f"use global batch {lo} or {hi}")
        divisors = [m for m in range(1, micro + 1) if global_batch % (m * dp) == 0]
        if divisors:
            out["suggestions"].append(f"or keep {global_batch} with micro-batch {max(divisors)}")
        say("  PROBLEM         :", out["problems"][-1])
        for s in out["suggestions"]:
            say("  suggestion      :", s)
        return out

    accum = global_batch // per_step
    out["accum"] = accum
    say(f"  grad accumulation: {accum} micro-step(s) per optimizer step")
    say(f"  global batch    : {global_batch} samples" +
        (f" = {global_batch * seq:,} tokens per step" if seq else ""))

    if pp > 1:
        bubble = (pp - 1) / (accum + pp - 1)
        out["bubble"] = bubble
        flag = "  <- raise micro-batches per step (>= 4 x PP) or use interleaved stages" if bubble > 0.10 else ""
        say(f"  pipeline bubble : {bubble:.1%} idle ({accum} micro-batches through {pp} stages){flag}")

    if base_lr and base_batch:
        k = global_batch / base_batch
        lr = base_lr * (k if optimizer == "sgd" else math.sqrt(k))
        out["lr"] = lr
        rule = "linear" if optimizer == "sgd" else "square-root"
        say(f"  learning rate   : {lr:.4g} ({rule} rule from {base_lr:g} at batch {base_batch})")

    if dataset:
        steps = math.ceil(dataset / global_batch)
        out["steps_per_epoch"] = steps
        say(f"  steps per epoch : {steps:,}" + (f", warm-up {warmup_epochs} epochs = {steps * warmup_epochs:,} steps"
                                                if optimizer == "sgd" else ""))
        if step_time_s:
            say(f"  epoch time      : {steps * step_time_s / 60:.1f} min at {step_time_s:.2f} s per step")

    if global_batch / max(1, (base_batch or global_batch)) > 32:
        out["suggestions"].append("batch is >32x the reference: expect to need LARS/LAMB or retuning, and verify accuracy")
        say("  warning         :", out["suggestions"][-1])
    return out


SCENARIOS = [
    ("A. ResNet-50 on ImageNet, one 8-GPU node (Goyal et al. reference: lr 0.1 at batch 256)",
     dict(gpus=8, micro=128, global_batch=1024, base_lr=0.1, base_batch=256, optimizer="sgd",
          dataset=1_281_167, step_time_s=0.40)),
    ("B. Same job on 32 GPUs, keep the global batch (strong scaling): micro-batch shrinks",
     dict(gpus=32, micro=32, global_batch=1024, base_lr=0.1, base_batch=256, optimizer="sgd",
          dataset=1_281_167, step_time_s=0.12)),
    ("C. Same job on 32 GPUs, keep the micro-batch (weak scaling): global batch and LR grow",
     dict(gpus=32, micro=128, global_batch=4096, base_lr=0.1, base_batch=256, optimizer="sgd",
          dataset=1_281_167, step_time_s=0.42)),
    ("D. 70B LLM on 2,048 GPUs: 4M-token batch, TP 8 inside nodes, PP 4, sequence 4,096",
     dict(gpus=2048, micro=1, global_batch=1024, tp=8, pp=4, seq=4096, base_lr=1.5e-4, base_batch=1024,
          optimizer="adam")),
    ("E. A plan that does not divide: 48 GPUs, micro-batch 8, global batch 1,000",
     dict(gpus=48, micro=8, global_batch=1000)),
]


def demo():
    results = []
    for title, kw in SCENARIOS:
        print(f"\n{title}")
        results.append(plan(**kw))
    print("\nChecks:")
    checks = [
        ("A: accumulation 1, LR 0.4", results[0].get("accum") == 1 and abs(results[0]["lr"] - 0.4) < 1e-9),
        ("B: same global batch with micro-batch 32", results[1].get("accum") == 1),
        ("C: LR scaled to 1.6", abs(results[2].get("lr", 0) - 1.6) < 1e-9),
        ("D: DP 64, accumulation 16", results[3].get("dp") == 64 and results[3].get("accum") == 16),
        ("D: bubble flagged above 10%", results[3].get("bubble", 0) > 0.10),
        ("E: rejected with suggestions", not results[4]["ok"] and results[4]["suggestions"]),
    ]
    for label, ok in checks:
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}")
    return 0 if all(ok for _, ok in checks) else 1


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--gpus", type=int)
    p.add_argument("--micro-batch", type=int, help="max samples per GPU per forward/backward (memory-bound)")
    p.add_argument("--global-batch", type=int, help="samples per optimizer step across the job")
    p.add_argument("--tp", type=int, default=1, help="tensor-parallel size")
    p.add_argument("--pp", type=int, default=1, help="pipeline-parallel size")
    p.add_argument("--seq", type=int, help="sequence length (prints tokens per step)")
    p.add_argument("--base-lr", type=float, help="learning rate known to work at --base-batch")
    p.add_argument("--base-batch", type=int)
    p.add_argument("--optimizer", choices=["sgd", "adam"], default="sgd")
    p.add_argument("--dataset", type=int, help="samples in the dataset (prints steps per epoch)")
    p.add_argument("--step-time", type=float, help="seconds per optimizer step (prints epoch time)")
    a = p.parse_args()
    if not a.gpus:
        return demo()
    r = plan(a.gpus, a.micro_batch, a.global_batch, a.tp, a.pp, a.seq, a.base_lr, a.base_batch,
             a.optimizer, a.dataset, step_time_s=a.step_time)
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
