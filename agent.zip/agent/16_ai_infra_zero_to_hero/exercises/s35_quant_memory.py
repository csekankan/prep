#!/usr/bin/env python3
"""Section 35 assessment: calculate quantized model memory savings and what they buy on a GPU.

Weight memory = sum over tensors of params * bits_per_weight / 8, where quantized formats pay for their scales:

    bits_per_weight = value_bits + (scale_bits + zero_bits) / group_size

    format     value  scale  zero  group  -> bits/weight   typical tool
    bf16         16     -      -     -        16.000       baseline
    fp8           8    32      -    row        ~8.0         per-channel FP8 (H100/H200, vLLM, TensorRT-LLM)
    int8          8    16      -    row        ~8.0         per-channel INT8 weights (LLM.int8, SmoothQuant W8A8)
    int4-g128     4    16      4   128        4.156        GPTQ / AWQ (FP16 scale + packed 4-bit zero per 128)
    nf4           4     8      -    64        4.127        bitsandbytes NF4 + double quant (FP32 per 256 blocks)
    mxfp4         4     8      -    32        4.250        OCP microscaling FP4 (E8M0 scale per 32)
    nvfp4         4     8      -    16        4.500        NVIDIA Blackwell FP4 (FP8 scale per 16)

Embeddings, lm_head, and norms usually stay BF16 (GPTQ/AWQ skip them by default), so savings are below the
naive 16/bits ratio. The KV cache is separate:

    KV bytes per token = 2 (K and V) * layers * kv_heads * head_dim * kv_bytes

Serving fit on N GPUs with tensor parallelism:
    KV budget = N * (gpu_gb * util - overhead_gb) - weights_gb
    tokens    = KV budget / KV bytes per token,   concurrent sequences = tokens / context

Usage:
  python3 s35_quant_memory.py                                     # Llama 3 70B on H100 80GB + PASS/FAIL checks
  python3 s35_quant_memory.py --model llama3-8b --gpu-gb 24 --context 8192
  python3 s35_quant_memory.py --model llama3-70b --gpu-gb 141 --kv fp8 --target-seqs 64
"""
import argparse
import sys

MODELS = {   # hidden, layers, heads, kv_heads, intermediate, vocab, tied embeddings
    "llama3-8b": dict(hidden=4096, layers=32, heads=32, kv_heads=8, inter=14336, vocab=128256, tied=False),
    "llama3-70b": dict(hidden=8192, layers=80, heads=64, kv_heads=8, inter=28672, vocab=128256, tied=False),
    "llama3-405b": dict(hidden=16384, layers=126, heads=128, kv_heads=8, inter=53248, vocab=128256, tied=False),
}

FORMATS = {   # value bits, scale bits, zero bits, group size (None = one scale per output row)
    "bf16": (16, 0, 0, None),
    "fp8": (8, 32, 0, None),
    "int8": (8, 16, 0, None),
    "int4-g128": (4, 16, 4, 128),
    "nf4": (4, 8 + 32 / 256, 0, 64),
    "mxfp4": (4, 8, 0, 32),
    "nvfp4": (4, 8, 0, 16),
}
KV_BYTES = {"bf16": 2, "fp8": 1, "int4": 0.5}


def tensors(cfg):
    """(name, rows, cols, quantizable) for every weight tensor in a Llama-style model."""
    h, hd = cfg["hidden"], cfg["hidden"] // cfg["heads"]
    kv = cfg["kv_heads"] * hd
    out = [("embed", cfg["vocab"], h, False)]
    block = [("q", h, h), ("k", kv, h), ("v", kv, h), ("o", h, h),
             ("gate", cfg["inter"], h), ("up", cfg["inter"], h), ("down", h, cfg["inter"])]
    for _ in range(cfg["layers"]):
        out += [(n, r, c, True) for n, r, c in block]
        out += [("norm", 1, h, False), ("norm", 1, h, False)]
    out.append(("final_norm", 1, h, False))
    if not cfg["tied"]:
        out.append(("lm_head", cfg["vocab"], h, False))
    return out


def bits_per_weight(fmt, cols):
    v, s, z, g = FORMATS[fmt]
    return v + (s + z) / (g or cols)


def weights_gb(cfg, fmt, quantize_embeddings=False):
    total_bits = 0.0
    for name, rows, cols, quantizable in tensors(cfg):
        q = quantizable or (quantize_embeddings and name in ("embed", "lm_head"))
        total_bits += rows * cols * (bits_per_weight(fmt, cols) if q else 16)
    return total_bits / 8 / 1e9


def params(cfg):
    return sum(r * c for _, r, c, _ in tensors(cfg))


def kv_bytes_per_token(cfg, kv="bf16"):
    head_dim = cfg["hidden"] // cfg["heads"]
    return 2 * cfg["layers"] * cfg["kv_heads"] * head_dim * KV_BYTES[kv]


def fit(cfg, fmt, gpus, gpu_gb, util, overhead_gb, context, kv="bf16"):
    w = weights_gb(cfg, fmt)
    budget = gpus * (gpu_gb * util - overhead_gb) - w
    if budget <= 0:
        return {"weights_gb": w, "kv_budget_gb": budget, "tokens": 0, "seqs": 0}
    tokens = budget * 1e9 / kv_bytes_per_token(cfg, kv)
    return {"weights_gb": w, "kv_budget_gb": budget, "tokens": int(tokens), "seqs": int(tokens // context)}


def min_gpus(cfg, fmt, gpu_gb, util, overhead_gb, context, target_seqs, kv="bf16"):
    for n in (1, 2, 4, 8, 16):
        if fit(cfg, fmt, n, gpu_gb, util, overhead_gb, context, kv)["seqs"] >= target_seqs:
            return n
    return None


def report(a):
    cfg = MODELS[a.model]
    base = weights_gb(cfg, "bf16")
    print(f"{a.model}: {params(cfg):,} parameters, KV cache {kv_bytes_per_token(cfg, a.kv) / 1e6:.3f} MB/token "
          f"({a.kv})")
    print(f"GPU {a.gpu_gb:g} GB x util {a.util} - {a.overhead_gb:g} GB overhead, context {a.context:,} tokens, "
          f"target {a.target_seqs} concurrent sequences\n")
    print(f"{'format':10} {'bits/w':>7} {'weights':>9} {'saved':>6} {'1-GPU KV':>9} {'1-GPU seqs':>10} "
          f"{'GPUs for target':>15}")
    for fmt in FORMATS:
        w = weights_gb(cfg, fmt)
        one = fit(cfg, fmt, 1, a.gpu_gb, a.util, a.overhead_gb, a.context, a.kv)
        n = min_gpus(cfg, fmt, a.gpu_gb, a.util, a.overhead_gb, a.context, a.target_seqs, a.kv)
        kv = f"{one['kv_budget_gb']:.1f} GB" if one["kv_budget_gb"] > 0 else "no fit"
        print(f"{fmt:10} {bits_per_weight(fmt, cfg['hidden']):7.3f} {w:7.1f} GB {1 - w / base:6.1%} {kv:>9} "
              f"{one['seqs']:10d} {n if n else '>16':>15}")


def checks():
    l8, l70 = MODELS["llama3-8b"], MODELS["llama3-70b"]
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= cond
        print(f"{'PASS' if cond else 'FAIL'}  {name}")

    check("Llama 3 8B has 8,030,261,248 parameters (Hugging Face count)", params(l8) == 8_030_261_248)
    check("Llama 3 70B has 70,553,706,496 parameters", params(l70) == 70_553_706_496)
    check("70B BF16 weights = 141.1 GB", abs(weights_gb(l70, "bf16") - 141.1) < 0.05)
    check("INT4 g128 costs 4.156 bits per weight with scales and zeros", abs(bits_per_weight("int4-g128", 8192) - 4.15625) < 1e-6)
    w4 = weights_gb(l70, "int4-g128")
    check("70B INT4 g128 with BF16 embed/lm_head = 39.8 GB (saves ~72%, not 75%)",
          abs(w4 - 39.77) < 0.05 and 0.71 < 1 - w4 / weights_gb(l70, "bf16") < 0.72)
    check("quantizing embed/lm_head too brings 70B INT4 to 36.7 GB", abs(weights_gb(l70, "int4-g128", True) - 36.66) < 0.05)
    check("70B KV cache = 327,680 bytes/token in BF16, half in FP8",
          kv_bytes_per_token(l70) == 327_680 and kv_bytes_per_token(l70, "fp8") == 163_840)
    check("70B BF16 doesn't fit one 80 GB GPU", fit(l70, "bf16", 1, 80, 0.9, 2, 8192)["seqs"] == 0)
    check("70B INT4 on one 80 GB GPU holds 11 sequences of 8K tokens", fit(l70, "int4-g128", 1, 80, 0.9, 2, 8192)["seqs"] == 11)
    check("FP8 weights on 2 GPUs hold only 25 x 8K sequences (KV cache, not weights, is the limit)",
          fit(l70, "fp8", 2, 80, 0.9, 2, 8192)["seqs"] == 25)
    check("32 x 8K sequences: BF16 needs 4 GPUs, FP8 4, INT4 2, FP8 weights + FP8 KV 2",
          [min_gpus(l70, f, 80, 0.9, 2, 8192, 32) for f in ("bf16", "fp8", "int4-g128")] == [4, 4, 2]
          and min_gpus(l70, "fp8", 80, 0.9, 2, 8192, 32, "fp8") == 2)
    return ok


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model", choices=MODELS, default="llama3-70b")
    p.add_argument("--gpu-gb", type=float, default=80)
    p.add_argument("--util", type=float, default=0.90, help="share of GPU memory the server may use (vLLM default 0.9)")
    p.add_argument("--overhead-gb", type=float, default=2, help="per-GPU activations, CUDA graphs, runtime")
    p.add_argument("--context", type=int, default=8192)
    p.add_argument("--target-seqs", type=int, default=32)
    p.add_argument("--kv", choices=KV_BYTES, default="bf16")
    a = p.parse_args()
    report(a)
    if len(sys.argv) == 1:
        print()
        sys.exit(0 if checks() else 1)


if __name__ == "__main__":
    main()
