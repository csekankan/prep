#!/usr/bin/env python3
"""Section 18 assessment: validate a least-privilege IAM policy.

A small AWS-style IAM evaluator and linter for the role of an LLM inference service:

  evaluate(policy, request)   explicit Deny > Allow > implicit deny, with wildcards in Action/Resource
                              and Condition operators StringEquals, StringLike, Bool
  lint(policy, required)      flags wildcard actions/resources, dangerous permissions, missing required
                              access, over-grants beyond what the workload needs, and no TLS-only guard
  minimize(usage_log)         builds a least-privilege policy from 90 days of observed calls
                              (what IAM Access Analyzer policy generation does from CloudTrail)

Usage:
  python3 s18_iam_policy_check.py                     # scenario + checks
  python3 s18_iam_policy_check.py --lint policy.json  # lint your own policy (needs --required file too)
"""
import argparse
import json
import sys
from fnmatch import fnmatchcase

ACTIONS = [
    "s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:ListBucket", "s3:PutBucketPolicy",
    "kms:Decrypt", "kms:Encrypt", "kms:ScheduleKeyDeletion", "kms:CreateGrant",
    "secretsmanager:GetSecretValue", "secretsmanager:PutSecretValue", "secretsmanager:DeleteSecret",
    "logs:CreateLogStream", "logs:PutLogEvents", "logs:DeleteLogGroup",
    "iam:PassRole", "iam:CreateUser", "iam:AttachRolePolicy", "sts:AssumeRole",
]
DANGEROUS = {"iam:PassRole", "iam:CreateUser", "iam:AttachRolePolicy", "kms:ScheduleKeyDeletion",
             "s3:PutBucketPolicy", "secretsmanager:DeleteSecret", "logs:DeleteLogGroup", "sts:AssumeRole"}

ACCT = "123456789012"
MODEL_KEY = f"arn:aws:kms:eu-west-1:{ACCT}:key/1111-model"
REQUIRED = [   # what the inference service actually needs
    ("s3:GetObject", "arn:aws:s3:::models-prod/llm/*"),
    ("s3:ListBucket", "arn:aws:s3:::models-prod"),
    ("kms:Decrypt", MODEL_KEY),
    ("secretsmanager:GetSecretValue", f"arn:aws:secretsmanager:eu-west-1:{ACCT}:secret:llm/hf-token-*"),
    ("logs:CreateLogStream", f"arn:aws:logs:eu-west-1:{ACCT}:log-group:/llm/inference:*"),
    ("logs:PutLogEvents", f"arn:aws:logs:eu-west-1:{ACCT}:log-group:/llm/inference:*"),
]

POLICY_BROAD = {"Version": "2012-10-17", "Statement": [
    {"Sid": "S3", "Effect": "Allow", "Action": "s3:*", "Resource": "*"},
    {"Sid": "KMS", "Effect": "Allow", "Action": "kms:*", "Resource": "*"},
    {"Sid": "Secrets", "Effect": "Allow", "Action": "secretsmanager:GetSecretValue", "Resource": "*"},
    {"Sid": "Logs", "Effect": "Allow", "Action": "logs:*", "Resource": "*"},
    {"Sid": "Pass", "Effect": "Allow", "Action": "iam:PassRole", "Resource": "*"},
]}

POLICY_LEAST = {"Version": "2012-10-17", "Statement": [
    {"Sid": "ReadModels", "Effect": "Allow", "Action": "s3:GetObject",
     "Resource": "arn:aws:s3:::models-prod/llm/*"},
    {"Sid": "ListModelPrefix", "Effect": "Allow", "Action": "s3:ListBucket",
     "Resource": "arn:aws:s3:::models-prod", "Condition": {"StringLike": {"s3:prefix": "llm/*"}}},
    {"Sid": "DecryptModelKey", "Effect": "Allow", "Action": "kms:Decrypt", "Resource": MODEL_KEY,
     "Condition": {"StringEquals": {"kms:ViaService": "s3.eu-west-1.amazonaws.com"}}},
    {"Sid": "ReadHfToken", "Effect": "Allow", "Action": "secretsmanager:GetSecretValue",
     "Resource": f"arn:aws:secretsmanager:eu-west-1:{ACCT}:secret:llm/hf-token-*"},
    {"Sid": "WriteLogs", "Effect": "Allow", "Action": ["logs:CreateLogStream", "logs:PutLogEvents"],
     "Resource": f"arn:aws:logs:eu-west-1:{ACCT}:log-group:/llm/inference:*"},
    {"Sid": "DenyNonTLS", "Effect": "Deny", "Action": "s3:*", "Resource": "*",
     "Condition": {"Bool": {"aws:SecureTransport": "false"}}},
]}


def as_list(x):
    return x if isinstance(x, list) else [x]


def action_match(pattern, action):
    return fnmatchcase(action.lower(), pattern.lower())


def condition_ok(cond, ctx):
    for op, kv in (cond or {}).items():
        for key, expected in kv.items():
            actual = ctx.get(key)
            if actual is None:
                return False
            exp = as_list(expected)
            if op == "StringEquals" and actual not in exp:
                return False
            if op == "StringLike" and not any(fnmatchcase(actual, e) for e in exp):
                return False
            if op == "Bool" and str(actual).lower() not in [str(e).lower() for e in exp]:
                return False
    return True


def evaluate(policy, action, resource, ctx=None):
    """Return ('Allow'|'ExplicitDeny'|'ImplicitDeny', sid)."""
    ctx = ctx or {}
    allowed = None
    for st in policy["Statement"]:
        if not any(action_match(a, action) for a in as_list(st["Action"])):
            continue
        if not any(fnmatchcase(resource, r) for r in as_list(st["Resource"])):
            continue
        if not condition_ok(st.get("Condition"), ctx):
            continue
        if st["Effect"] == "Deny":
            return "ExplicitDeny", st.get("Sid")
        allowed = allowed or st.get("Sid")
    return ("Allow", allowed) if allowed else ("ImplicitDeny", None)


DEFAULT_CTX = {"aws:SecureTransport": "true", "kms:ViaService": "s3.eu-west-1.amazonaws.com", "s3:prefix": "llm/"}


def lint(policy, required):
    findings = []
    need_actions = {a for a, _ in required}
    for st in policy["Statement"]:
        if st["Effect"] != "Allow":
            continue
        sid = st.get("Sid", "?")
        acts, res = as_list(st["Action"]), as_list(st["Resource"])
        if any("*" in a for a in acts):
            granted = sorted({x for x in ACTIONS for a in acts if action_match(a, x)})
            findings.append(("ERROR", sid, f"wildcard action {acts} grants {len(granted)} actions, "
                                           f"{len([g for g in granted if g not in need_actions])} not needed"))
        if "*" in res:
            findings.append(("ERROR", sid, "Resource '*' (scope to specific ARNs)"))
        for a in acts:
            for d in sorted(DANGEROUS):
                if action_match(a, d):
                    findings.append(("ERROR", sid, f"dangerous permission {d}" + (" on *" if "*" in res else "")))
        extra = sorted({x for x in ACTIONS for a in acts if action_match(a, x)} - need_actions - DANGEROUS)
        if extra and not any("*" in a for a in acts):
            findings.append(("WARN", sid, f"grants actions the workload does not use: {extra}"))
    for a, r in required:
        if evaluate(policy, a, r.replace("*", "x"), DEFAULT_CTX)[0] != "Allow":
            findings.append(("ERROR", "-", f"required access missing: {a} on {r}"))
    if not any(st["Effect"] == "Deny" and "aws:SecureTransport" in json.dumps(st.get("Condition", {}))
               for st in policy["Statement"]):
        findings.append(("WARN", "-", "no Deny for non-TLS requests (aws:SecureTransport=false)"))
    return findings


def minimize(usage):
    """Least-privilege policy from observed (action, resource) calls: one statement per resource scope."""
    by_res = {}
    for action, resource in usage:
        if resource.startswith("arn:aws:s3:::") and "/" in resource:
            bucket, key = resource[len("arn:aws:s3:::"):].split("/", 1)
            prefix = key.split("/")[0]
            resource = f"arn:aws:s3:::{bucket}/{prefix}/*"
        by_res.setdefault(resource, set()).add(action)
    stmts = [{"Sid": f"Observed{i}", "Effect": "Allow", "Action": sorted(acts), "Resource": res}
             for i, (res, acts) in enumerate(sorted(by_res.items()))]
    stmts.append(POLICY_LEAST["Statement"][-1])
    return {"Version": "2012-10-17", "Statement": stmts}


def print_findings(name, findings):
    print(f"\n  lint: {name}")
    if not findings:
        print("    no findings")
    for sev, sid, msg in findings:
        print(f"    {sev:<5} [{sid}] {msg}")


def demo():
    results = []

    def check(name, ok, info=""):
        results.append(ok)
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}{'  ' + info if info else ''}")

    broad_f, least_f = lint(POLICY_BROAD, REQUIRED), lint(POLICY_LEAST, REQUIRED)
    print_findings("POLICY_BROAD (what teams often ship)", broad_f)
    print_findings("POLICY_LEAST (scoped)", least_f)

    print("\nAccess simulation")
    probes = [
        ("read a model shard", "s3:GetObject", "arn:aws:s3:::models-prod/llm/llama3-8b/model-00001.safetensors", {}),
        ("delete training data", "s3:DeleteObject", "arn:aws:s3:::training-data/2026/11/part-0.parquet", {}),
        ("read another team's model", "s3:GetObject", "arn:aws:s3:::models-prod/fraud/v7/model.bin", {}),
        ("schedule KMS key deletion", "kms:ScheduleKeyDeletion", MODEL_KEY, {}),
        ("read the database password", "secretsmanager:GetSecretValue",
         f"arn:aws:secretsmanager:eu-west-1:{ACCT}:secret:prod/db-password-AbC", {}),
        ("pass an admin role to a new service", "iam:PassRole", f"arn:aws:iam::{ACCT}:role/Admin", {}),
        ("read a model over plain HTTP", "s3:GetObject", "arn:aws:s3:::models-prod/llm/x.bin",
         {"aws:SecureTransport": "false"}),
    ]
    print(f"  {'request':<38} {'POLICY_BROAD':<14} POLICY_LEAST")
    sim = {}
    for name, a, r, extra in probes:
        ctx = dict(DEFAULT_CTX, **extra)
        b, l = evaluate(POLICY_BROAD, a, r, ctx)[0], evaluate(POLICY_LEAST, a, r, ctx)[0]
        sim[name] = (b, l)
        print(f"  {name:<38} {b:<14} {l}")

    print("\nChecks")
    check("the broad policy has at least 8 ERROR findings (wildcards, Resource *, PassRole)",
          sum(1 for f in broad_f if f[0] == "ERROR") >= 8, f"{sum(1 for f in broad_f if f[0] == 'ERROR')} errors")
    check("the least-privilege policy has no findings", not least_f)
    check("the least-privilege policy still allows every required call",
          all(evaluate(POLICY_LEAST, a, r.replace("*", "x"), DEFAULT_CTX)[0] == "Allow" for a, r in REQUIRED))
    harmful = ["delete training data", "read another team's model", "schedule KMS key deletion",
               "read the database password", "pass an admin role to a new service"]
    check("the broad policy allows all 5 harmful requests, the scoped one denies all 5",
          all(sim[h] == ("Allow", "ImplicitDeny") for h in harmful))
    check("an explicit Deny overrides the Allow for non-TLS access",
          sim["read a model over plain HTTP"] == ("Allow", "ExplicitDeny"))

    usage = [("s3:GetObject", f"arn:aws:s3:::models-prod/llm/llama3-8b/shard-{i}") for i in range(4)] + [
        ("kms:Decrypt", MODEL_KEY),
        ("secretsmanager:GetSecretValue", f"arn:aws:secretsmanager:eu-west-1:{ACCT}:secret:llm/hf-token-Xy12"),
        ("logs:PutLogEvents", f"arn:aws:logs:eu-west-1:{ACCT}:log-group:/llm/inference:*")]
    mini = minimize(usage)
    print("\n  policy generated from 90 days of observed calls:")
    for st in mini["Statement"]:
        cond = "  when " + json.dumps(st["Condition"]) if st.get("Condition") else ""
        print(f"    {st['Effect']:<5} {','.join(as_list(st['Action'])):<42} {st['Resource']}{cond}")
    check("the generated policy allows the observed calls and denies deleting training data",
          all(evaluate(mini, a, r, DEFAULT_CTX)[0] == "Allow" for a, r in usage)
          and evaluate(mini, "s3:DeleteObject", "arn:aws:s3:::training-data/x", DEFAULT_CTX)[0] != "Allow")

    passed = sum(results)
    print(f"\n{passed}/{len(results)} checks passed")
    return 0 if passed == len(results) else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--lint", help="policy JSON file to lint")
    ap.add_argument("--required", help='JSON list of [action, resource] pairs the workload needs')
    a = ap.parse_args()
    if a.lint:
        policy = json.load(open(a.lint))
        required = [tuple(x) for x in json.load(open(a.required))] if a.required else []
        f = lint(policy, required)
        print_findings(a.lint, f)
        return 1 if any(s == "ERROR" for s, _, _ in f) else 0
    return demo()


if __name__ == "__main__":
    sys.exit(main())
