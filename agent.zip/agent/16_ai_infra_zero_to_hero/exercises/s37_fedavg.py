#!/usr/bin/env python3
"""Section 37 assessment: implement weighted federated averaging (FedAvg) and secure aggregation masks.

Weighted FedAvg (McMahan et al., 2017). Each round, sampled clients start from the global model w, train locally,
and send back their new weights w_k and example counts n_k. The server averages over the clients that reported:

    w_next = sum_k n_k * w_k / sum_k n_k          (sum over participating clients only)

This demo trains linear regression on 12 simulated clients with unequal sizes (2,000 down to 20 examples) and
non-IID data (each client's true weights differ a little, with larger differences on small clients). It shows:

  1. with 1 local full-batch gradient step, weighted FedAvg equals one centralized gradient step on the pooled data
  2. weighted FedAvg reaches the pooled-data optimum; unweighted averaging over-weights small, unusual clients
  3. weighting by n_k assumes every client does the same amount of local work: with "2 local epochs", a 2,000-example
     client takes 126 steps and a 20-example client 2, so small clients barely move and are down-weighted again
     (the objective inconsistency that FedNova corrects)
  4. normalizing by the total of ALL clients instead of the participants shrinks the model toward zero
  5. secure aggregation: pairwise masks hide each update but cancel in the sum; a dropped client's masks must be
     recovered (in real protocols, from secret shares) or the sum is garbage

Usage:
  python3 s37_fedavg.py                                    # demo + PASS/FAIL checks
  python3 s37_fedavg.py --rounds 60 --local-steps 20 --sample 0.5
"""
import argparse
import random
import sys

DIM = 5
TRUE_W = [2.0, -1.0, 0.5, 3.0, -2.0]
SIZES = [2000, 1500, 1000, 800, 500, 300, 200, 100, 60, 40, 30, 20]
MOD = 2**32        # secure aggregation works on integers modulo 2^32
FIX = 10**6        # fixed-point scale for turning floats into integers


SKEW_DIR = [1, 1, -1, 1, -1]     # small clients share a systematic difference (say, a different population)


def make_clients(seed=0):
    rnd = random.Random(seed)
    clients = []
    for k, n in enumerate(SIZES):
        skew = 1.5 * (1 - n / SIZES[0]) ** 3                            # small clients differ more
        wk = [w + skew * d + rnd.gauss(0, 0.1) for w, d in zip(TRUE_W, SKEW_DIR)]
        X = [[rnd.gauss(0, 1) for _ in range(DIM)] for _ in range(n)]
        y = [sum(a * b for a, b in zip(x, wk)) + rnd.gauss(0, 0.3) for x in X]
        clients.append((X, y))
    return clients


def grad(w, X, y):
    g = [0.0] * DIM
    for x, t in zip(X, y):
        err = sum(a * b for a, b in zip(w, x)) - t
        for j in range(DIM):
            g[j] += 2 * err * x[j]
    return [v / len(X) for v in g]


def mse(w, X, y):
    return sum((sum(a * b for a, b in zip(w, x)) - t) ** 2 for x, t in zip(X, y)) / len(X)


def local_train(w, X, y, steps, lr, batch, rnd, epochs=None):
    """`steps` minibatch SGD steps (same for every client), or full `epochs` (steps then grow with client size)."""
    w = list(w)
    n = len(X)
    if epochs is not None:
        steps = epochs * -(-n // batch)
    for _ in range(steps):
        b = rnd.sample(range(n), min(batch, n))
        g = grad(w, [X[i] for i in b], [y[i] for i in b])
        w = [wi - lr * gi for wi, gi in zip(w, g)]
    return w


def fedavg(updates, total=None):
    """updates: list of (n_k, w_k). Weighted mean over participants; total overrides the denominator (a bug)."""
    denom = total if total is not None else sum(n for n, _ in updates)
    return [sum(n * w[j] for n, w in updates) / denom for j in range(DIM)]


def unweighted(updates):
    return [sum(w[j] for _, w in updates) / len(updates) for j in range(DIM)]


def train(clients, rounds, steps, lr, batch, sample, agg="weighted", seed=1, epochs=None):
    rnd = random.Random(seed)
    w = [0.0] * DIM
    for r in range(rounds):
        chosen = [c for c in clients if rnd.random() < sample] or [rnd.choice(clients)]
        lr_r = lr / (1 + r / 10)                                        # decay so SGD noise settles
        ups = [(len(X), local_train(w, X, y, steps, lr_r, batch, rnd, epochs)) for X, y in chosen]
        if agg == "weighted":
            w = fedavg(ups)
        elif agg == "unweighted":
            w = unweighted(ups)
        else:                                                           # "all-total" bug
            w = fedavg(ups, total=sum(len(X) for X, _ in clients))
    return w


def pooled_optimum(clients):
    """Exact least squares on all data pooled together: solve (X^T X) w = X^T y."""
    X = [x for c in clients for x in c[0]]
    y = [t for c in clients for t in c[1]]
    A = [[sum(x[i] * x[j] for x in X) for j in range(DIM)] + [sum(x[i] * t for x, t in zip(X, y))]
         for i in range(DIM)]
    for c in range(DIM):                                                # Gauss-Jordan elimination
        piv = max(range(c, DIM), key=lambda r: abs(A[r][c]))
        A[c], A[piv] = A[piv], A[c]
        A[c] = [v / A[c][c] for v in A[c]]
        for r in range(DIM):
            if r != c:
                A[r] = [a - A[r][c] * b for a, b in zip(A[r], A[c])]
    return [A[i][DIM] for i in range(DIM)], X, y


def dist(a, b):
    return sum((x - y) ** 2 for x, y in zip(a, b)) ** 0.5


# ---------- secure aggregation with pairwise masks ----------

def encode(w):
    return [int(round(v * FIX)) % MOD for v in w]


def decode(v, n_clients=1):
    return [((x + MOD // 2) % MOD - MOD // 2) / FIX for x in v]


def pair_mask(i, j, seed):
    r = random.Random(f"{seed}-{min(i, j)}-{max(i, j)}")                # shared secret from a key agreement
    return [r.randrange(MOD) for _ in range(DIM)]


def masked_update(i, vec, ids, seed):
    out = list(vec)
    for j in ids:
        if j == i:
            continue
        m = pair_mask(i, j, seed)
        sign = 1 if i < j else -1                                       # i adds, j subtracts: cancels in the sum
        out = [(a + sign * b) % MOD for a, b in zip(out, m)]
    return out


def secure_sum(updates, ids, seed, dropped=(), recover=True):
    """updates: {id: encoded vector}. Clients in `dropped` never send. Server sums what arrives."""
    total = [0] * DIM
    alive = [i for i in ids if i not in dropped]
    for i in alive:
        total = [(a + b) % MOD for a, b in zip(total, masked_update(i, updates[i], ids, seed))]
    if recover:                                                          # remove masks alive clients shared with dropped ones
        for d in dropped:
            for i in alive:
                m = pair_mask(i, d, seed)
                sign = 1 if i < d else -1
                total = [(a - sign * b) % MOD for a, b in zip(total, m)]
    return total


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--rounds", type=int, default=40)
    p.add_argument("--local-steps", type=int, default=10, help="SGD steps per client per round")
    p.add_argument("--lr", type=float, default=0.02)
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--sample", type=float, default=1.0, help="share of clients sampled per round")
    a = p.parse_args()

    clients = make_clients()
    w_star, X_all, y_all = pooled_optimum(clients)
    print(f"{len(clients)} clients, sizes {SIZES} (total {sum(SIZES):,})")
    print(f"pooled-data optimum w* = [{', '.join(f'{v:.3f}' for v in w_star)}], MSE {mse(w_star, X_all, y_all):.4f}\n")

    results = {}
    for agg in ("weighted", "unweighted"):
        w = train(clients, a.rounds, a.local_steps, a.lr, a.batch, a.sample, agg)
        results[agg] = w
        print(f"{agg:10} FedAvg, {a.local_steps} local steps each: distance to w* {dist(w, w_star):.3f}, "
              f"pooled MSE {mse(w, X_all, y_all):.4f}")
    w_ep = train(clients, a.rounds, None, a.lr, a.batch, a.sample, "weighted", epochs=2)
    print(f"weighted   FedAvg, 2 local epochs (big clients take 100x more steps): distance to w* "
          f"{dist(w_ep, w_star):.3f}, pooled MSE {mse(w_ep, X_all, y_all):.4f}")

    rs = train(clients, a.rounds, a.local_steps, a.lr, a.batch, 0.5, "weighted")
    rs_bug = train(clients, a.rounds, a.local_steps, a.lr, a.batch, 0.5, "all-total")
    print(f"\nwith 50% client sampling: weighted over participants MSE {mse(rs, X_all, y_all):.4f}, "
          f"divided by all clients' total MSE {mse(rs_bug, X_all, y_all):.4f}")

    # FedSGD equivalence: one full-batch step locally == one centralized step
    w0 = [0.1, 0.2, -0.1, 0.0, 0.3]
    lr = 0.05
    ups = [(len(X), [wi - lr * gi for wi, gi in zip(w0, grad(w0, X, y))]) for X, y in clients]
    fed = fedavg(ups)
    cen = [wi - lr * gi for wi, gi in zip(w0, grad(w0, X_all, y_all))]

    # secure aggregation
    ids = list(range(5))
    vecs = {i: encode([0.01 * (i + 1) * (j + 1) for j in range(DIM)]) for i in ids}
    plain = [sum(decode(vecs[i])[j] for i in ids) for j in range(DIM)]
    one_masked = decode(masked_update(2, vecs[2], ids, seed=42))
    agg_ok = decode(secure_sum(vecs, ids, seed=42))
    agg_drop_bad = decode(secure_sum(vecs, ids, seed=42, dropped=(3,), recover=False))
    agg_drop_fix = decode(secure_sum(vecs, ids, seed=42, dropped=(3,), recover=True))
    plain_minus3 = [sum(decode(vecs[i])[j] for i in ids if i != 3) for j in range(DIM)]
    print(f"\nsecure aggregation, 5 clients: client 2 sends {[round(v) for v in one_masked[:3]]}... (looks random)")
    print(f"  sum of masked updates  = {[round(v, 4) for v in agg_ok]}")
    print(f"  plain sum              = {[round(v, 4) for v in plain]}")
    print(f"  client 3 drops, no recovery: {[round(v) for v in agg_drop_bad[:3]]}...  (garbage)")
    print(f"  client 3 drops, masks recovered: {[round(v, 4) for v in agg_drop_fix]}")

    if len(sys.argv) > 1:
        return
    print()
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"{'PASS' if cond else 'FAIL'}  {name}")

    check("1 local full-batch step: weighted FedAvg == centralized gradient step", dist(fed, cen) < 1e-9)
    check("weighted FedAvg lands within 0.05 of the pooled optimum", dist(results["weighted"], w_star) < 0.05)
    check("unweighted averaging is biased (at least 5x farther from w*)",
          dist(results["unweighted"], w_star) > 5 * dist(results["weighted"], w_star))
    check("unweighted averaging has higher pooled MSE",
          mse(results["unweighted"], X_all, y_all) > mse(results["weighted"], X_all, y_all) + 0.05)
    check("epoch-based local training (uneven steps) is biased toward big clients (at least 10x farther)",
          dist(w_ep, w_star) > 10 * dist(results["weighted"], w_star))
    check("normalizing by all clients' total under 50% sampling shrinks the model (MSE at least 10x worse)",
          mse(rs_bug, X_all, y_all) > 10 * mse(rs, X_all, y_all))
    check("a single masked update reveals nothing like the real values", max(abs(v) for v in one_masked) > 1)
    check("pairwise masks cancel: secure sum == plain sum", max(abs(x - y) for x, y in zip(agg_ok, plain)) < 1e-5)
    check("a dropout without mask recovery corrupts the sum", max(abs(x - y) for x, y in zip(agg_drop_bad, plain_minus3)) > 1)
    check("with recovery the sum of the 4 survivors is exact",
          max(abs(x - y) for x, y in zip(agg_drop_fix, plain_minus3)) < 1e-5)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
