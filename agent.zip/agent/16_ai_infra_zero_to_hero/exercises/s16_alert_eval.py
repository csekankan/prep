#!/usr/bin/env python3
"""Section 16 assessment: evaluate sustained infrastructure alerts.

Simulates the Prometheus alerting state machine over 70 minutes of 30-second samples:

  inactive --expr true--> pending --true for `for`--> firing --false for `keep_firing_for`--> resolved

and Alertmanager-style inhibition (a firing critical NodeDown{node} suppresses warning alerts for the
same node). It compares naive rules (no `for`) with sustained rules, and shows how `for`,
`keep_firing_for`, and inhibition turn noisy pages into actionable ones.

Usage:
  python3 s16_alert_eval.py            # run the scenario and checks
  python3 s16_alert_eval.py --timeline # also print every state transition
"""
import argparse
import sys

STEP = 0.5          # minutes between samples (30 s scrape and evaluation interval)
END = 70.0


def frange(a, b, step=STEP):
    t = a
    while t < b - 1e-9:
        yield round(t, 2)
        t += step


def build_series():
    """Return {series_key: {t: value or None}}. None means the series is absent (no scrape)."""
    s = {}
    times = list(frange(0, END))

    def in_any(t, ranges):
        return any(a <= t < b for a, b in ranges)

    s[("gpu_temp_c", "node=a", "gpu=0")] = {t: 88 if in_any(t, [(5, 6), (20, 21), (33, 34)]) else 70 for t in times}
    s[("gpu_temp_c", "node=a", "gpu=3")] = {t: 90 if 10 <= t < 25 else 72 for t in times}
    s[("gpu_temp_c", "node=b", "gpu=1")] = {t: (None if t >= 60 else 71) for t in times}
    s[("error_ratio", "service=llm-api", "")] = {
        t: (0.015 if 40 <= t < 40.5 else 0.04) if 30 <= t < 50 else 0.005 for t in times}
    s[("up", "node=b", "")] = {t: 0 if t >= 60 else 1 for t in times}
    return s, times


class Rule:
    def __init__(self, name, metric, pred, for_m=0.0, keep_m=0.0, severity="warning"):
        self.name, self.metric, self.pred = name, metric, pred
        self.for_m, self.keep_m, self.severity = for_m, keep_m, severity


def evaluate(rule, series, times):
    """Return a list of events (t, labels, 'pending'|'firing'|'resolved') for one rule."""
    events = []
    for key, values in series.items():
        if key[0] != rule.metric:
            continue
        labels = ",".join(x for x in key[1:] if x)
        state, since, last_true = "inactive", None, None
        for t in times:
            true = rule.pred(values.get(t))
            if true:
                last_true = t
                if state == "inactive":
                    state, since = "pending", t
                    if rule.for_m == 0:
                        state = "firing"
                        events.append((t, labels, "firing"))
                    else:
                        events.append((t, labels, "pending"))
                elif state == "pending" and t - since >= rule.for_m - 1e-9:
                    state = "firing"
                    events.append((t, labels, "firing"))
            else:
                if state == "pending":
                    state = "inactive"
                elif state == "firing" and t - last_true >= max(rule.keep_m, STEP) - 1e-9:
                    state = "inactive"
                    events.append((t, labels, "resolved"))
    return events


def firing_windows(events):
    """{labels: [(start, end_or_None), ...]} from the event list."""
    out = {}
    for t, labels, kind in events:
        w = out.setdefault(labels, [])
        if kind == "firing":
            w.append([t, None])
        elif kind == "resolved" and w and w[-1][1] is None:
            w[-1][1] = t
    return out


def notifications(rules, series, times, inhibit=True):
    """Count notifications (firing transitions), applying NodeDown inhibition when requested."""
    all_events = {r.name: evaluate(r, series, times) for r in rules}
    node_down = firing_windows(all_events.get("NodeDown", []))
    sent, suppressed = [], []
    for r in rules:
        for t, labels, kind in all_events[r.name]:
            if kind != "firing":
                continue
            node = next((p for p in labels.split(",") if p.startswith("node=")), None)
            blocked = inhibit and r.severity == "warning" and node and any(
                s <= t and (e is None or t < e) for s, e in node_down.get(node, []))
            (suppressed if blocked else sent).append((t, r.name, labels))
    return sorted(sent), sorted(suppressed), all_events


hot = lambda v: v is not None and v > 85
absent = lambda v: v is None
high_err = lambda v: v is not None and v > 0.02
down = lambda v: v == 0

NAIVE = [
    Rule("GpuHot", "gpu_temp_c", hot),
    Rule("ErrorRateHigh", "error_ratio", high_err, severity="critical"),
    Rule("GpuMetricsAbsent", "gpu_temp_c", absent),
    Rule("NodeDown", "up", down, severity="critical"),
]
TUNED = [
    Rule("GpuHot", "gpu_temp_c", hot, for_m=5, keep_m=2),
    Rule("ErrorRateHigh", "error_ratio", high_err, for_m=5, keep_m=2, severity="critical"),
    Rule("GpuMetricsAbsent", "gpu_temp_c", absent, for_m=2),
    Rule("NodeDown", "up", down, for_m=1, severity="critical"),
]


def demo(timeline=False):
    series, times = build_series()
    results = []

    def check(name, ok, info=""):
        results.append(ok)
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}{'  ' + info if info else ''}")

    naive_sent, _, _ = notifications(NAIVE, series, times, inhibit=False)
    tuned_sent, tuned_supp, tuned_events = notifications(TUNED, series, times, inhibit=True)

    print("Notifications sent")
    print(f"  {'time':>6}  {'naive rules':<44}")
    for t, n, l in naive_sent:
        print(f"  {t:6.1f}  {n}{{{l}}}")
    print(f"\n  {'time':>6}  {'sustained rules + inhibition':<44}")
    for t, n, l in tuned_sent:
        print(f"  {t:6.1f}  {n}{{{l}}}")
    for t, n, l in tuned_supp:
        print(f"  {t:6.1f}  (inhibited by NodeDown) {n}{{{l}}}")

    if timeline:
        print("\nTimeline (sustained rules)")
        for name, evs in tuned_events.items():
            for t, l, k in evs:
                print(f"  {t:6.1f}  {name:<18} {l:<22} {k}")

    print("\nChecks")
    naive_gpu0 = [x for x in naive_sent if x[1] == "GpuHot" and "gpu=0" in x[2]]
    tuned_gpu0 = [x for x in tuned_sent if x[1] == "GpuHot" and "gpu=0" in x[2]]
    check("transient 1-minute spikes on gpu0 page 3 times without `for`, 0 times with for: 5m",
          len(naive_gpu0) == 3 and not tuned_gpu0)

    w = firing_windows(evaluate(TUNED[0], series, times)).get("node=a,gpu=3", [])
    check("sustained overheating on gpu3 fires at 15.0 (10 + 5m) and resolves at 26.5 (last true 24.5 + 2m)",
          w == [[15.0, 26.5]], f"windows={w}")

    no_keep = Rule("ErrorRateHigh", "error_ratio", high_err, for_m=5, keep_m=0, severity="critical")
    w_no_keep = firing_windows(evaluate(no_keep, series, times)).get("service=llm-api", [])
    w_keep = firing_windows(evaluate(TUNED[1], series, times)).get("service=llm-api", [])
    check("a 30-second dip splits one incident into 2 pages without keep_firing_for, 1 page with it",
          len(w_no_keep) == 2 and len(w_keep) == 1, f"without={w_no_keep} with={w_keep}")

    check("NodeDown{node=b} fires at 61.0 (down at 60 + 1m)",
          any(x == (61.0, "NodeDown", "node=b") for x in tuned_sent))
    check("GpuMetricsAbsent{node=b} is inhibited by NodeDown, so one page explains the cause",
          any(n == "GpuMetricsAbsent" and "node=b" in l for _, n, l in tuned_supp)
          and not any(n == "GpuMetricsAbsent" for _, n, _ in tuned_sent))

    reduction = 1 - len(tuned_sent) / len(naive_sent)
    check("pages cut by at least half while every real incident still pages",
          reduction >= 0.5 and {n for _, n, _ in tuned_sent} == {"GpuHot", "ErrorRateHigh", "NodeDown"},
          f"{len(naive_sent)} -> {len(tuned_sent)} ({reduction:.0%} fewer)")

    passed = sum(results)
    print(f"\n{passed}/{len(results)} checks passed")
    return 0 if passed == len(results) else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--timeline", action="store_true", help="print every state transition")
    return demo(ap.parse_args().timeline)


if __name__ == "__main__":
    sys.exit(main())
