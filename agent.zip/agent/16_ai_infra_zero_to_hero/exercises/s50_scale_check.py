#!/usr/bin/env python3
"""Section 50 support: the numbers behind scaling and hardening Atlas.

1. Multi-node fine-tuning of Qwen2.5-1.5B on L4 nodes (one GPU each, 10 Gbps network):
   does it fit in 24 GB, and how well does data-parallel training scale for LoRA vs full fine-tuning?
   step time = compute + ring all-reduce time, all-reduce bytes = 2 (n - 1) / n x gradient bytes.
2. Availability of the serving path: the single-replica prototype vs the HA design (replicas across zones).
   A replica is up if its pod and its zone are up; a group is up if any replica is up; the path multiplies groups.
3. Stress test: the highest request rate that meets both latency SLOs, by linear interpolation of measured points.
4. Drift: population stability index (PSI) of question topics, baseline week vs this week.

Usage:
  python3 s50_scale_check.py
"""
import math
import sys

# ---- 1. training
PARAMS = 1.54e9
L4_MEM_GB = 24
TOKENS_PER_STEP = 8 * 1024            # per GPU: batch 8 x 1,024 tokens
L4_EFFECTIVE_FLOPS = 121e12 * 0.35    # BF16 dense peak x 35% utilization
NET_BYTES_S = 10e9 / 8 * 0.8          # 10 Gbps at 80% efficiency
LAYERS, HID, INTER, KV, RANK = 28, 1536, 8960, 256, 16


def lora_params():
    mats = [(HID, HID), (HID, KV), (HID, KV), (HID, HID), (HID, INTER), (HID, INTER), (INTER, HID)]
    return LAYERS * sum(RANK * (i + o) for i, o in mats)


def train_plan():
    full_mem = PARAMS * 16 / 1e9                      # BF16 weights + grads, FP32 master + Adam moments
    lora_p = lora_params()
    lora_mem = PARAMS * 2 / 1e9 + lora_p * 16 / 1e9   # frozen BF16 weights + LoRA states
    compute_full = 6 * PARAMS * TOKENS_PER_STEP / L4_EFFECTIVE_FLOPS
    compute_lora = 4 * PARAMS * TOKENS_PER_STEP / L4_EFFECTIVE_FLOPS   # no weight gradients for frozen layers
    grads = {"full": PARAMS * 2, "lora": lora_p * 4}
    rows = {}
    for name, compute in (("full", compute_full), ("lora", compute_lora)):
        for n in (1, 2, 4):
            comm = 0 if n == 1 else 2 * (n - 1) / n * grads[name] / NET_BYTES_S
            rows[(name, n)] = (compute, comm, compute / (compute + comm))
    return full_mem, lora_mem, lora_p, rows


# ---- 2. availability
POD, ZONE, INGRESS, MANAGED_DB = 0.995, 0.999, 0.9995, 0.9995


def group(k):
    return 1 - (1 - POD * ZONE) ** k


def availability():
    proto = INGRESS * POD * POD * POD * ZONE        # 1 gateway, 1 llm, in-cluster postgres, all in one zone
    ha = INGRESS * group(3) * group(2) * MANAGED_DB  # 3 gateways, 2 llm replicas, multi-AZ managed postgres
    return proto, ha


# ---- 3. stress test: (req/s, TTFT p95 s, full answer p95 s, error %) measured on 3 x L4
POINTS = [(1, 0.35, 3.1, 0), (2, 0.38, 3.3, 0), (4, 0.45, 3.8, 0), (6, 0.62, 4.6, 0),
          (8, 0.95, 5.4, 0), (10, 1.38, 5.9, 0), (12, 2.40, 7.8, 0.1), (14, 5.10, 12.5, 2.0)]


def crossing(col, limit):
    for a, b in zip(POINTS, POINTS[1:]):
        if a[col] <= limit < b[col]:
            return a[0] + (b[0] - a[0]) * (limit - a[col]) / (b[col] - a[col])
    return POINTS[-1][0]


# ---- 4. drift
BASE = {"kubernetes": 0.30, "gpus": 0.20, "serving": 0.20, "mlops": 0.15, "cost": 0.10, "other": 0.05}
NOW = {"kubernetes": 0.18, "gpus": 0.12, "serving": 0.15, "mlops": 0.10, "cost": 0.07, "other": 0.38}


def psi(base, now):
    return sum((now[k] - base[k]) * math.log(now[k] / base[k]) for k in base)


def main():
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"{'PASS' if cond else 'FAIL'}  {name}")

    full_mem, lora_mem, lora_p, rows = train_plan()
    print(f"memory: full fine-tune {full_mem:.1f} GB (plus activations), LoRA {lora_mem:.1f} GB, "
          f"L4 has {L4_MEM_GB} GB; LoRA trains {lora_p / 1e6:.1f}M parameters")
    for (name, n), (c, m, eff) in rows.items():
        print(f"  {name:4} x{n} nodes: compute {c:.2f} s + all-reduce {m:.2f} s -> scaling efficiency {eff:.0%}")

    proto, ha = availability()
    for name, a in (("prototype", proto), ("HA design", ha)):
        print(f"availability {name:9}: {a:.4%}  ~{(1 - a) * 30 * 24 * 60:,.0f} min downtime per 30 days")

    ttft, total = crossing(1, 1.5), crossing(2, 6.0)
    cap = min(ttft, total)
    print(f"stress test: TTFT p95 hits 1.5 s at {ttft:.2f} req/s, answer p95 hits 6 s at {total:.2f} req/s "
          f"-> capacity {cap:.1f} req/s on 3 GPUs; concurrent streams at capacity ~{cap * 5.9:.0f} (Little's law)")
    d = psi(BASE, NOW)
    print(f"question-topic PSI this week: {d:.3f} (alert above 0.2)\n")

    check("full fine-tuning does not fit in one L4's 24 GB", full_mem > L4_MEM_GB)
    check("LoRA fits with room for activations (under 8 GB of weights and states)", lora_mem < 8)
    check("LoRA scales above 90% on 4 nodes over 10 Gbps", rows[("lora", 4)][2] > 0.90)
    check("full fine-tuning would scale below 50% on 2 nodes", rows[("full", 2)][2] < 0.50)
    check("prototype misses the 99.5% availability SLO", proto < 0.995)
    check("HA design meets 99.5% with margin (above 99.8%)", ha > 0.998)
    check("measured capacity on 3 GPUs is within 5% of the 10 req/s planned in Section 48", abs(cap - 10) / 10 < 0.05)
    check("this week's topic drift crosses the 0.2 PSI alert", d > 0.2)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
