"""Section 3 exercise: compare cloud instances by cost per unit of work, not price per hour.

Two views are printed:
  1. Cost per 1M predictions at full utilization: the best case each instance can reach.
  2. Monthly cost for *your* traffic: how many always-on replicas you need to serve the peak within the
     latency SLO, with a minimum for high availability. This is where idle time shows up.

Usage:
  python3 s03_cloud_cost_compare.py
  python3 s03_cloud_cost_compare.py --monthly-predictions 500000000 --peak-factor 4 --p95-slo-ms 80

The candidate numbers below are illustrative samples. Replace them with your own benchmark results
and current prices from each provider's pricing page.
"""

import argparse
import math
from dataclasses import dataclass

HOURS_PER_MONTH = 730


@dataclass
class Candidate:
    cloud: str
    instance: str
    gpu: str
    price_per_hour: float      # on-demand USD
    throughput_per_sec: float  # measured predictions/sec at the batch size that meets p95
    p95_ms: float              # measured p95 latency at that throughput

    def cost_per_million(self) -> float:
        return self.price_per_hour / (self.throughput_per_sec * 3600) * 1_000_000


SAMPLE_CANDIDATES = [
    Candidate("aws", "c7i.4xlarge", "none (16 vCPU)", 0.71, 120, 95),
    Candidate("aws", "g4dn.xlarge", "T4", 0.53, 380, 70),
    Candidate("aws", "g6.xlarge", "L4", 0.80, 650, 45),
    Candidate("aws", "p5.48xlarge/8", "H100 (1 of 8)", 12.29, 12000, 20),
    Candidate("gcp", "n1-standard-4+T4", "T4", 0.54, 370, 72),
    Candidate("gcp", "g2-standard-4", "L4", 0.71, 640, 46),
    Candidate("gcp", "a3-highgpu-1g", "H100", 11.06, 11800, 21),
]


def replicas_needed(c: Candidate, peak_rps: float, target_util: float, min_replicas: int) -> int:
    # Plan to run each replica at target_util of its measured max, leaving headroom for spikes.
    return max(min_replicas, math.ceil(peak_rps / (c.throughput_per_sec * target_util)))


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--monthly-predictions", type=float, default=780_000_000,
                   help="total predictions per month (default ≈ 300 req/s average)")
    p.add_argument("--peak-factor", type=float, default=4.0, help="peak traffic ÷ average traffic")
    p.add_argument("--p95-slo-ms", type=float, default=100.0, help="p95 latency target in ms")
    p.add_argument("--target-util", type=float, default=0.7, help="planned utilization per replica (0-1)")
    p.add_argument("--min-replicas", type=int, default=2, help="minimum replicas for availability")
    args = p.parse_args()

    avg_rps = args.monthly_predictions / (HOURS_PER_MONTH * 3600)
    peak_rps = avg_rps * args.peak_factor

    print(f"Traffic: {args.monthly_predictions:,.0f} predictions/month "
          f"= {avg_rps:,.0f} req/s average, {peak_rps:,.0f} req/s peak")
    print(f"SLO: p95 <= {args.p95_slo_ms:.0f} ms | planned utilization {args.target_util:.0%} "
          f"| min replicas {args.min_replicas}\n")

    header = (f"{'cloud':<5} {'instance':<17} {'gpu':<15} {'$/hr':>6} {'pred/s':>7} {'p95':>5} "
              f"{'$/1M (full)':>11} {'replicas':>8} {'$/month':>9} {'$/1M (real)':>11}  note")
    print(header)
    print("-" * len(header))

    rows = []
    for c in SAMPLE_CANDIDATES:
        meets_slo = c.p95_ms <= args.p95_slo_ms
        n = replicas_needed(c, peak_rps, args.target_util, args.min_replicas)
        monthly = n * c.price_per_hour * HOURS_PER_MONTH
        real_per_million = monthly / (args.monthly_predictions / 1_000_000)
        rows.append((c, meets_slo, n, monthly, real_per_million))
        note = "" if meets_slo else "misses SLO"
        print(f"{c.cloud:<5} {c.instance:<17} {c.gpu:<15} {c.price_per_hour:>6.2f} "
              f"{c.throughput_per_sec:>7,.0f} {c.p95_ms:>5.0f} {c.cost_per_million():>11.3f} "
              f"{n:>8} {monthly:>9,.0f} {real_per_million:>11.3f}  {note}")

    eligible = [r for r in rows if r[1]]
    if not eligible:
        print("\nNo candidate meets the latency SLO. Optimize the model (Section 15) or use bigger GPUs.")
        return

    best_full = min(eligible, key=lambda r: r[0].cost_per_million())
    best_real = min(eligible, key=lambda r: r[3])
    print(f"\nCheapest at full utilization: {best_full[0].cloud} {best_full[0].instance} "
          f"(${best_full[0].cost_per_million():.3f} per 1M)")
    print(f"Cheapest for YOUR traffic:     {best_real[0].cloud} {best_real[0].instance} "
          f"({best_real[2]} replicas, ${best_real[3]:,.0f}/month)")
    if best_full[0] is not best_real[0]:
        print("These differ because the minimum replica count forces you to pay for idle capacity "
              "on large instances at this traffic level.")


if __name__ == "__main__":
    main()
