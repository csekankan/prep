"""Section 6 exercise: an idempotent data ingestion pipeline (CSV landing zone -> SQLite table).

Idempotent means running it twice gives the same result as running it once. Four techniques make it so:
  1. File manifest: the SHA-256 of every ingested file is recorded; the same bytes are never loaded twice,
     even under a different file name.
  2. Upsert by natural key: rows are keyed by order_id; a newer updated_at wins, an older one is ignored,
     so replays and out-of-order files are harmless.
  3. One transaction per file: rows and the manifest entry commit together, so a crash mid-file leaves
     nothing behind and the rerun loads the whole file.
  4. Quarantine: rows that fail validation are stored with a reason instead of failing the whole batch.

Usage:
  python3 s06_idempotent_ingest.py                          # demo: crash, rerun, rerun again
  python3 s06_idempotent_ingest.py --landing DIR --db PATH  # ingest your own CSVs
      CSV header: order_id,customer_id,amount,currency,updated_at   (updated_at in ISO 8601)
"""

import argparse
import csv
import hashlib
import io
import sqlite3
import tempfile
from datetime import datetime
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (
  order_id     TEXT PRIMARY KEY,
  customer_id  TEXT NOT NULL,
  amount_cents INTEGER NOT NULL,
  currency     TEXT NOT NULL,
  updated_at   TEXT NOT NULL,
  source_file  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS ingested_files (
  sha256 TEXT PRIMARY KEY, name TEXT NOT NULL, rows_ok INTEGER, rows_bad INTEGER, ingested_at TEXT
);
CREATE TABLE IF NOT EXISTS quarantine (
  sha256 TEXT, line_no INTEGER, reason TEXT, raw TEXT, PRIMARY KEY (sha256, line_no)
);
"""

UPSERT = """
INSERT INTO orders (order_id, customer_id, amount_cents, currency, updated_at, source_file)
VALUES (?, ?, ?, ?, ?, ?)
ON CONFLICT(order_id) DO UPDATE SET
  customer_id = excluded.customer_id, amount_cents = excluded.amount_cents,
  currency = excluded.currency, updated_at = excluded.updated_at, source_file = excluded.source_file
WHERE excluded.updated_at > orders.updated_at
"""

CURRENCIES = {"USD", "EUR", "GBP", "INR"}


class SimulatedCrash(Exception):
    pass


def validate(row):
    """Return (clean_tuple, None) or (None, reason)."""
    if not row.get("order_id", "").strip():
        return None, "missing order_id"
    if not row.get("customer_id", "").strip():
        return None, "missing customer_id"
    try:
        cents = round(float(row["amount"]) * 100)
    except (KeyError, ValueError):
        return None, f"amount not a number: {row.get('amount')!r}"
    if cents < 0:
        return None, "negative amount"
    if row.get("currency") not in CURRENCIES:
        return None, f"unknown currency: {row.get('currency')!r}"
    try:
        ts = datetime.fromisoformat(row["updated_at"]).isoformat()
    except (KeyError, ValueError):
        return None, f"bad updated_at: {row.get('updated_at')!r}"
    return (row["order_id"].strip(), row["customer_id"].strip(), cents, row["currency"], ts), None


def ingest_file(db, path, crash_after=None):
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if db.execute("SELECT 1 FROM ingested_files WHERE sha256 = ?", (digest,)).fetchone():
        return "skipped (already ingested)", 0, 0
    ok = bad = 0
    with db:  # one transaction: all rows + manifest entry, or nothing
        reader = csv.DictReader(io.StringIO(data.decode("utf-8")))
        for line_no, row in enumerate(reader, start=2):
            clean, reason = validate(row)
            if reason:
                db.execute("INSERT OR REPLACE INTO quarantine VALUES (?, ?, ?, ?)",
                           (digest, line_no, reason, ",".join(f"{k}={v}" for k, v in row.items())))
                bad += 1
                continue
            db.execute(UPSERT, (*clean, path.name))
            ok += 1
            if crash_after is not None and ok == crash_after:
                raise SimulatedCrash(f"crashed after {ok} rows of {path.name}")
        db.execute("INSERT INTO ingested_files VALUES (?, ?, ?, ?, datetime('now'))", (digest, path.name, ok, bad))
    return "loaded", ok, bad


def run(landing, db_path, crash_on=None, crash_after=None):
    db = sqlite3.connect(db_path)
    db.executescript(SCHEMA)
    for path in sorted(landing.glob("*.csv")):
        try:
            status, ok, bad = ingest_file(db, path, crash_after if path.name == crash_on else None)
            print(f"  {path.name:<30} {status:<26} ok={ok:<3} quarantined={bad}")
        except SimulatedCrash as e:
            print(f"  {path.name:<30} CRASH: {e} -> transaction rolled back")
            break
    summary = report(db)
    db.close()
    return summary


def report(db):
    q = lambda sql: db.execute(sql).fetchone()[0]
    s = {
        "orders": q("SELECT COUNT(*) FROM orders"),
        "revenue_cents": q("SELECT COALESCE(SUM(amount_cents), 0) FROM orders"),
        "files": q("SELECT COUNT(*) FROM ingested_files"),
        "quarantined": q("SELECT COUNT(*) FROM quarantine"),
    }
    print(f"  -> orders={s['orders']} revenue=${s['revenue_cents'] / 100:,.2f} "
          f"files_in_manifest={s['files']} quarantined_rows={s['quarantined']}")
    return s


SAMPLE = {
    "2026-11-01_orders.csv": """order_id,customer_id,amount,currency,updated_at
o-1001,c-1,49.99,USD,2026-11-01T09:00:00
o-1002,c-2,15.00,EUR,2026-11-01T09:05:00
o-1003,c-3,abc,USD,2026-11-01T09:07:00
o-1004,c-1,120.00,USD,2026-11-01T09:10:00
""",
    "2026-11-02_orders.csv": """order_id,customer_id,amount,currency,updated_at
o-1002,c-2,18.00,EUR,2026-11-02T08:00:00
o-1005,c-4,7.50,GBP,2026-11-02T08:30:00
,c-5,10.00,USD,2026-11-02T08:31:00
o-1006,c-6,300.00,JPY,2026-11-02T08:40:00
o-1007,c-7,62.10,INR,2026-11-02T08:45:00
""",
    # Arrives late and out of order: the old o-1002 version must not overwrite the newer one,
    # but the o-1001 correction is newer than what we hold, so it must apply.
    "2026-11-03_late_replay.csv": """order_id,customer_id,amount,currency,updated_at
o-1002,c-2,15.00,EUR,2026-11-01T09:05:00
o-1001,c-1,44.99,USD,2026-11-01T12:00:00
""",
}
# The same bytes as the first file, re-sent by the upstream system under a new name.
SAMPLE["2026-11-04_resend_of_1101.csv"] = SAMPLE["2026-11-01_orders.csv"]


def demo():
    with tempfile.TemporaryDirectory() as tmp:
        landing, db_path = Path(tmp) / "landing", Path(tmp) / "warehouse.db"
        landing.mkdir()
        for name, body in SAMPLE.items():
            (landing / name).write_text(body)

        print("Run 1: crash in the middle of 2026-11-02_orders.csv")
        first = run(landing, db_path, crash_on="2026-11-02_orders.csv", crash_after=1)
        print("\nRun 2: rerun after the crash")
        second = run(landing, db_path)
        print("\nRun 3: run again with nothing new")
        third = run(landing, db_path)

        print("\nChecks:")
        checks = [
            ("crash left only fully committed files", first["files"] == 1),
            ("rerun loaded the rest", second["files"] == 3),
            ("third run changed nothing", second == third),
            ("resent duplicate file was skipped", third["files"] == 3),
            ("5 unique valid orders, no duplicates", third["orders"] == 5),
            ("3 bad rows quarantined, batch not failed", third["quarantined"] == 3),
        ]
        db = sqlite3.connect(db_path)
        amount = db.execute("SELECT amount_cents FROM orders WHERE order_id = 'o-1002'").fetchone()[0]
        late = db.execute("SELECT amount_cents FROM orders WHERE order_id = 'o-1001'").fetchone()[0]
        db.close()
        checks.append(("late replay did not overwrite newer o-1002 (18.00)", amount == 1800))
        checks.append(("newer late change to o-1001 applied (44.99)", late == 4499))
        for label, passed in checks:
            print(f"  [{'PASS' if passed else 'FAIL'}] {label}")
        return 0 if all(p for _, p in checks) else 1


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--landing", type=Path, help="folder of CSV files to ingest")
    p.add_argument("--db", type=Path, default=Path("warehouse.db"), help="SQLite database path")
    args = p.parse_args()
    if args.landing:
        run(args.landing, args.db)
        return 0
    return demo()


if __name__ == "__main__":
    raise SystemExit(main())
