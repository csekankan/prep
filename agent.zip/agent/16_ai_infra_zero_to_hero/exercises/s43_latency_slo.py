#!/usr/bin/env python3
"""Section 43 assessment: evaluate an end-to-end latency SLO for a real-time fraud scoring path.

A card authorization must be scored within an SLO of p99 <= 30 ms, measured end to end. The path:

  network     client <-> edge round trip
  gateway     authentication, routing
  features    parallel lookups to 8 online feature store shards; the stage waits for the slowest one.
              Each shard occasionally stalls (garbage collection, compaction) for about 20 ms
  model       batched inference: a wait for the batch to fill, then the forward pass
  rules       post-processing and business rules

Each stage's latency is drawn from a log-normal distribution (a common shape for service latency: most calls fast, a
long right tail). The simulation computes:
  - per-stage p50 and p99, and the end-to-end p50, p99, and p99.9
  - why adding per-stage p99s overstates the end-to-end p99, and why fan-out makes rare stalls common
  - the effect of hedged feature requests: send a second request to a replica if the first hasn't answered
    within a delay, and take whichever answers first
  - the share of requests over the SLO against the 1% the SLO allows

Usage:
  python3 s43_latency_slo.py
"""
import math
import random
import sys

N = 200_000
SLO_MS, SLO_Q = 30.0, 0.99
SHARDS = 8
STALL_P, STALL_MS = 0.005, 20.0
HEDGE_AFTER_MS = 2.0


def lognormal(rng, median, sigma):
    return median * math.exp(sigma * rng.gauss(0, 1))


def shard_call(rng):
    t = lognormal(rng, 0.8, 0.5)
    if rng.random() < STALL_P:
        t += STALL_MS
    return t


def hedged_call(rng, after=HEDGE_AFTER_MS):
    first = shard_call(rng)
    if first <= after:
        return first
    return min(first, after + shard_call(rng))


def simulate(rng, hedge=False, shards=SHARDS):
    call = hedged_call if hedge else shard_call
    stages = {
        "network": lognormal(rng, 4.0, 0.3),
        "gateway": lognormal(rng, 1.0, 0.4),
        "features": max(call(rng) for _ in range(shards)),
        "model": rng.uniform(0, 2.0) + lognormal(rng, 6.0, 0.25),
        "rules": lognormal(rng, 1.0, 0.3),
    }
    return stages, sum(stages.values())


def q(sorted_vals, p):
    return sorted_vals[min(len(sorted_vals) - 1, int(p * len(sorted_vals)))]


def run(seed, **kw):
    rng = random.Random(seed)
    per_stage, totals = {}, []
    for _ in range(N):
        stages, total = simulate(rng, **kw)
        totals.append(total)
        for k, v in stages.items():
            per_stage.setdefault(k, []).append(v)
    for v in per_stage.values():
        v.sort()
    totals.sort()
    return per_stage, totals


def main():
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"{'PASS' if cond else 'FAIL'}  {name}")

    per_stage, totals = run(7)
    print(f"{'stage':10} {'p50 ms':>8} {'p99 ms':>8}")
    for k, v in per_stage.items():
        print(f"{k:10} {q(v, .5):8.2f} {q(v, .99):8.2f}")
    sum_p99 = sum(q(v, .99) for v in per_stage.values())
    e2e = {p: q(totals, p) for p in (.5, .99, .999)}
    over = sum(t > SLO_MS for t in totals) / N
    print(f"\nsum of stage p99s: {sum_p99:.2f} ms")
    print(f"end-to-end p50 {e2e[.5]:.2f}  p99 {e2e[.99]:.2f}  p99.9 {e2e[.999]:.2f} ms;  over {SLO_MS:.0f} ms: {over:.2%}")

    rng = random.Random(11)
    single = sorted(shard_call(rng) for _ in range(N))
    p_any_stall = 1 - (1 - STALL_P) ** SHARDS
    print(f"\none shard p99 {q(single, .99):.2f} ms; chance a request hits at least one stall across {SHARDS} shards: "
          f"{p_any_stall:.2%}")

    per_h, totals_h = run(7, hedge=True)
    e2e_h = {p: q(totals_h, p) for p in (.5, .99, .999)}
    over_h = sum(t > SLO_MS for t in totals_h) / N
    rng = random.Random(13)
    hedges = sum(shard_call(rng) > HEDGE_AFTER_MS for _ in range(N)) / N
    print(f"hedged after {HEDGE_AFTER_MS} ms: features p99 {q(per_h['features'], .99):.2f} ms, end-to-end p99 "
          f"{e2e_h[.99]:.2f}  p99.9 {e2e_h[.999]:.2f} ms;  over SLO: {over_h:.2%};  extra shard load: {hedges:.1%}\n")

    check("each shard's own p99 is small (under 3 ms): stalls are rarer than 1 in 100 calls", q(single, .99) < 3)
    check("fan-out to 8 shards makes about 3.9% of requests hit a stall", abs(p_any_stall - 0.0393) < 0.0005)
    check("so the features stage p99 includes a ~20 ms stall", q(per_stage["features"], .99) > 20)
    check("sum of per-stage p99s is above the true end-to-end p99", sum_p99 > e2e[.99])
    check("without hedging the SLO is missed: p99 above 30 ms and more than 1% of requests over",
          e2e[.99] > SLO_MS and over > 0.01)
    check("hedged feature requests bring p99 under 30 ms and requests over the SLO under 1%",
          e2e_h[.99] < SLO_MS and over_h < 0.01)
    check("hedging costs few extra shard calls (under 10%)", hedges < 0.10)
    check("median barely changes with hedging (under 0.5 ms difference)", abs(e2e_h[.5] - e2e[.5]) < 0.5)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
