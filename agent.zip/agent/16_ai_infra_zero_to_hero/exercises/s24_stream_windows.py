#!/usr/bin/env python3
"""Aggregate streaming events into event-time windows with watermarks, allowed lateness, and dedup.

Simulates what Flink, Spark Structured Streaming, and Kafka Streams do for a windowed aggregation:
  - tumbling windows keyed by user, on EVENT time (when it happened), not arrival time
  - a watermark = max event time seen - allowed out-of-orderness; a window fires when the watermark passes its end
  - allowed lateness: late events still update a fired window (an "update" emission) until the window is purged
  - events later than that go to a side output (dead-letter list), never silently dropped
  - duplicate event ids are dropped (at-least-once delivery from Kafka means duplicates happen)
  - sliding and session windows, computed for comparison
The demo compares the streaming result with a batch "ground truth" and shows why processing-time windows are wrong.

Usage:
  python3 s24_stream_windows.py                          # demo + PASS/FAIL checks
  python3 s24_stream_windows.py --window 60 --ooo 10 --lateness 30
  python3 s24_stream_windows.py --events events.jsonl    # JSON lines in ARRIVAL order: {"id","key","ts","value"}
"""
import argparse
import json
import random
import sys
from collections import defaultdict


def make_stream(seed=7, n=400, keys=("u1", "u2", "u3"), span_s=600):
    """Events in arrival order, with realistic delays, a few very late events, and duplicates."""
    rng = random.Random(seed)
    events = []
    for i in range(n):
        ts = rng.uniform(0, span_s)
        r = rng.random()
        delay = rng.uniform(0, 4) if r < 0.88 else rng.uniform(5, 30) if r < 0.97 else rng.uniform(60, 150)
        e = {"id": f"e{i}", "key": rng.choice(keys), "ts": round(ts, 3), "value": round(rng.uniform(1, 100), 2),
             "arrival": round(ts + delay, 3)}
        events.append(e)
        if rng.random() < 0.04:
            events.append(dict(e, arrival=round(e["arrival"] + rng.uniform(0.1, 20), 3)))
    return sorted(events, key=lambda e: e["arrival"])


def make_bursty(seed=11, keys=("u1", "u2", "u3"), bursts=(3, 5, 2)):
    """Clickstream with known activity bursts per user: clicks 1-8 s apart, bursts 60-200 s apart."""
    rng = random.Random(seed)
    events, i = [], 0
    for key, nb in zip(keys, bursts):
        t = rng.uniform(0, 30)
        for _ in range(nb):
            for _ in range(rng.randint(4, 12)):
                events.append({"id": f"c{i}", "key": key, "ts": round(t, 3), "value": 1.0})
                i += 1
                t += rng.uniform(1, 8)
            t += rng.uniform(60, 200)
    return events, dict(zip(keys, bursts))


class TumblingAggregator:
    """Event-time tumbling windows with a bounded-out-of-orderness watermark and allowed lateness."""

    def __init__(self, window_s=60, ooo_s=10, lateness_s=30):
        self.w, self.ooo, self.lateness = window_s, ooo_s, lateness_s
        self.state = {}            # (key, start) -> [count, sum]
        self.fired = set()
        self.seen = set()          # in production: keyed state with a TTL, not an unbounded set
        self.max_ts = float("-inf")
        self.emissions = []        # (kind, key, start, count, sum, watermark)
        self.final = {}            # latest value per window, what a downstream upsert table would hold
        self.late_dropped, self.duplicates = [], 0
        self.max_open = 0

    @property
    def watermark(self):
        return self.max_ts - self.ooo

    def _emit(self, kind, k):
        c, s = self.state[k]
        self.emissions.append((kind, k[0], k[1], c, round(s, 2), round(self.watermark, 3)))
        self.final[k] = (c, round(s, 2))

    def process(self, e):
        if e["id"] in self.seen:
            self.duplicates += 1
            return
        self.seen.add(e["id"])
        start = e["ts"] - e["ts"] % self.w
        if start + self.w + self.lateness <= self.watermark:
            self.late_dropped.append(e)
            return
        k = (e["key"], start)
        agg = self.state.setdefault(k, [0, 0.0])
        agg[0] += 1
        agg[1] += e["value"]
        if k in self.fired:
            self._emit("update", k)
        self.max_ts = max(self.max_ts, e["ts"])
        self._advance()

    def _advance(self, flush=False):
        wm = float("inf") if flush else self.watermark
        self.max_open = max(self.max_open, len(self.state))
        for k in sorted(self.state):
            end = k[1] + self.w
            if end <= wm and k not in self.fired:
                self.fired.add(k)
                self._emit("final", k)
        for k in [k for k in self.state if k[1] + self.w + self.lateness <= wm]:
            del self.state[k]

    def flush(self):
        self._advance(flush=True)


def batch_tumbling(events, window_s, by="ts"):
    out = defaultdict(lambda: [0, 0.0])
    for e in events:
        start = e[by] - e[by] % window_s
        out[(e["key"], start)][0] += 1
        out[(e["key"], start)][1] += e["value"]
    return {k: (c, round(s, 2)) for k, (c, s) in out.items()}


def sliding_counts(events, size_s, hop_s):
    out = defaultdict(int)
    for e in events:
        first = (e["ts"] - size_s) // hop_s * hop_s + hop_s
        start = max(0.0, first)
        while start <= e["ts"]:
            if start <= e["ts"] < start + size_s:
                out[(e["key"], start)] += 1
            start += hop_s
    return dict(out)


def sessions(events, gap_s):
    by_key = defaultdict(list)
    for e in sorted(events, key=lambda e: e["ts"]):
        by_key[e["key"]].append(e["ts"])
    out = {}
    for key, times in by_key.items():
        cur, sess = [times[0]], []
        for t in times[1:]:
            if t - cur[-1] > gap_s:
                sess.append((cur[0], cur[-1], len(cur)))
                cur = []
            cur.append(t)
        sess.append((cur[0], cur[-1], len(cur)))
        out[key] = sess
    return out


def run(events, window_s, ooo_s, lateness_s):
    agg = TumblingAggregator(window_s, ooo_s, lateness_s)
    for e in events:
        agg.process(e)
    agg.flush()
    return agg


def demo(window_s=60, ooo_s=10, lateness_s=30):
    events = make_stream()
    agg = run(events, window_s, ooo_s, lateness_s)
    unique = list({e["id"]: e for e in events}.values())
    dropped_ids = {e["id"] for e in agg.late_dropped}
    accepted = [e for e in unique if e["id"] not in dropped_ids]
    truth = batch_tumbling(accepted, window_s)
    proc_time = batch_tumbling(accepted, window_s, by="arrival")
    finals = [x for x in agg.emissions if x[0] == "final"]
    updates = [x for x in agg.emissions if x[0] == "update"]
    wrong_proc = sum(1 for k, v in truth.items() if proc_time.get(k, (0, 0))[0] != v[0])

    print(f"Events received: {len(events)} (unique {len(unique)}, duplicates {agg.duplicates})")
    print(f"Window {window_s}s tumbling, watermark = max event time - {ooo_s}s, allowed lateness {lateness_s}s")
    print(f"Emissions: {len(finals)} final, {len(updates)} late updates. Side output (too late): {len(agg.late_dropped)}")
    print(f"Max windows held in state at once: {agg.max_open}")
    print("\nFirst windows for u1 (event time):")
    for (key, start), (c, s) in sorted(agg.final.items())[:4]:
        print(f"  [{start:5.0f}, {start + window_s:5.0f})  count={c:3d}  sum={s:8.2f}")
    print(f"\nProcessing-time windows disagree with event-time truth on {wrong_proc}/{len(truth)} windows")

    slide = sliding_counts(accepted, 60, 30)
    clicks, expected_bursts = make_bursty()
    sess = sessions(clicks, 30)
    print(f"Sliding 60s/30s windows: {len(slide)}. Clickstream sessions (gap 30s): "
          + ", ".join(f"{k}={len(v)}" for k, v in sorted(sess.items())))

    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"  {'PASS' if cond else 'FAIL'}  {name}")

    print("\nChecks:")
    check("streaming result equals batch ground truth on accepted events", agg.final == truth)
    check("every event accounted for: accepted + too-late + duplicates = received",
          len(accepted) + len(agg.late_dropped) + agg.duplicates == len(events))
    check("duplicates were removed (at-least-once input, exactly-once result)", agg.duplicates > 0)
    check("some events arrived late but within lateness and produced updates", len(updates) > 0)
    check("very late events went to the side output, not silently lost", len(agg.late_dropped) > 0)
    bound = len({e["key"] for e in events}) * ((ooo_s + lateness_s) // window_s + 3)
    check(f"state stays bounded (max open windows {agg.max_open} <= {bound})", agg.max_open <= bound)
    check("processing-time windows give a different (wrong) answer", wrong_proc > 0)
    check("sliding 60s/30s puts each accepted event in 2 windows",
          sum(slide.values()) == sum(2 if e["ts"] >= 30 else 1 for e in accepted))
    gaps_ok = all(b[0] - a[1] > 30 for v in sess.values() for a, b in zip(v, v[1:]))
    check("session windows recover the true activity bursts per user",
          {k: len(v) for k, v in sess.items()} == expected_bursts and gaps_ok
          and sum(s[2] for v in sess.values() for s in v) == len(clicks))
    return 0 if ok else 1


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--window", type=int, default=60)
    p.add_argument("--ooo", type=int, default=10, help="allowed out-of-orderness for the watermark, seconds")
    p.add_argument("--lateness", type=int, default=30, help="allowed lateness after a window fires, seconds")
    p.add_argument("--events", help="JSON lines in arrival order with id, key, ts, value")
    a = p.parse_args()
    if not a.events:
        return demo(a.window, a.ooo, a.lateness)
    with open(a.events) as f:
        events = [json.loads(line) for line in f if line.strip()]
    agg = run(events, a.window, a.ooo, a.lateness)
    for kind, key, start, c, s, wm in agg.emissions:
        print(json.dumps({"kind": kind, "key": key, "window_start": start, "count": c, "sum": s, "watermark": wm}))
    print(f"duplicates={agg.duplicates} too_late={len(agg.late_dropped)}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
