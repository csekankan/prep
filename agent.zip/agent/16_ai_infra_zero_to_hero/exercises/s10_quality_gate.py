"""Section 10 exercise: a model deployment quality gate for CI/CD.

The gate compares a candidate model's evaluation report with the current champion's and a policy, and
exits 0 (promote) or 1 (block), so a CI job can stop a bad model before it reaches users. It checks:
  1. lineage    : the run has a git commit, a data snapshot, and an image digest
  2. absolute   : every metric meets its floor (e.g. AUC >= 0.80)
  3. regression : no metric is worse than the champion by more than the noise margin
                  (2 standard errors for proportion metrics on an eval set of n examples, or a fixed delta)
  4. slices     : no segment (country, device, new users ...) regresses more than its allowance,
                  even if the overall number improved
  5. serving    : p95 latency and model size within budget

Usage:
  python3 s10_quality_gate.py                                     # demo with four candidates
  python3 s10_quality_gate.py --candidate cand.json --champion champ.json [--policy policy.json]
Report format (JSON):
  {"lineage": {...}, "n_eval": 20000, "metrics": {"auc": 0.91, "recall_at_1pct_fpr": 0.62},
   "slices": {"country=BR": {"recall_at_1pct_fpr": 0.55}}, "serving": {"p95_ms": 41, "size_mb": 180}}
"""

import argparse
import json
import math
import sys

DEFAULT_POLICY = {
    "required_lineage": ["git_commit", "data_snapshot", "image_digest"],
    "floors": {"auc": 0.80, "recall_at_1pct_fpr": 0.50},
    "max_regression": {"auc": 0.003},             # fixed deltas; proportion metrics use 2 standard errors
    "proportion_metrics": ["recall_at_1pct_fpr", "precision"],
    "slice_max_drop": 0.02,
    "serving": {"p95_ms": 60, "size_mb": 500},
}


def noise_margin(metric, value, n, policy):
    if metric in policy["proportion_metrics"] and n:
        return 2 * math.sqrt(value * (1 - value) / n)
    return policy["max_regression"].get(metric, 0.0)


def gate(cand, champ, policy=DEFAULT_POLICY):
    results = []

    def check(name, ok, detail):
        results.append((name, ok, detail))

    missing = [k for k in policy["required_lineage"] if not cand.get("lineage", {}).get(k)]
    check("lineage", not missing, "complete" if not missing else f"missing {', '.join(missing)}")

    for m, floor in policy["floors"].items():
        v = cand["metrics"].get(m)
        check(f"floor {m}", v is not None and v >= floor, f"{v} vs floor {floor}")

    n = cand.get("n_eval", 0)
    for m, v in cand["metrics"].items():
        if m not in champ.get("metrics", {}):
            continue
        base = champ["metrics"][m]
        margin = round(noise_margin(m, base, n, policy), 6)
        delta = round(v - base, 6)
        verdict = "better" if delta > margin else "worse" if delta < -margin else "within noise"
        check(f"vs champion {m}", delta >= -margin, f"{base} -> {v} ({delta:+.4f}, margin ±{margin:.4f}, {verdict})")

    for s, metrics in cand.get("slices", {}).items():
        for m, v in metrics.items():
            base = champ.get("slices", {}).get(s, {}).get(m)
            if base is None:
                continue
            drop = base - v
            check(f"slice {s} {m}", drop <= policy["slice_max_drop"],
                  f"{base} -> {v} (drop {drop:+.3f}, allowed {policy['slice_max_drop']})")

    for k, limit in policy["serving"].items():
        v = cand.get("serving", {}).get(k)
        check(f"serving {k}", v is not None and v <= limit, f"{v} vs budget {limit}")

    return all(ok for _, ok, _ in results), results


def print_report(name, ok, results):
    print(f"\n=== {name}: {'PROMOTE' if ok else 'BLOCK'}")
    for check_name, passed, detail in results:
        print(f"  [{'PASS' if passed else 'FAIL'}] {check_name:<38} {detail}")


CHAMPION = {
    "lineage": {"git_commit": "a1b2c3", "data_snapshot": "8801", "image_digest": "sha256:11aa"},
    "n_eval": 20000,
    "metrics": {"auc": 0.912, "recall_at_1pct_fpr": 0.610},
    "slices": {"country=US": {"recall_at_1pct_fpr": 0.640}, "country=BR": {"recall_at_1pct_fpr": 0.560},
               "new_users": {"recall_at_1pct_fpr": 0.480}},
    "serving": {"p95_ms": 38, "size_mb": 180},
}
LINEAGE = {"git_commit": "d4e5f6", "data_snapshot": "8812", "image_digest": "sha256:22bb"}

CANDIDATES = {
    "v13 better everywhere": {
        "lineage": LINEAGE, "n_eval": 20000,
        "metrics": {"auc": 0.921, "recall_at_1pct_fpr": 0.634},
        "slices": {"country=US": {"recall_at_1pct_fpr": 0.660}, "country=BR": {"recall_at_1pct_fpr": 0.575},
                   "new_users": {"recall_at_1pct_fpr": 0.500}},
        "serving": {"p95_ms": 40, "size_mb": 185},
    },
    "v14 better overall, worse for Brazil": {
        "lineage": LINEAGE, "n_eval": 20000,
        "metrics": {"auc": 0.924, "recall_at_1pct_fpr": 0.641},
        "slices": {"country=US": {"recall_at_1pct_fpr": 0.690}, "country=BR": {"recall_at_1pct_fpr": 0.500},
                   "new_users": {"recall_at_1pct_fpr": 0.490}},
        "serving": {"p95_ms": 39, "size_mb": 180},
    },
    "v15 more accurate but too slow": {
        "lineage": LINEAGE, "n_eval": 20000,
        "metrics": {"auc": 0.930, "recall_at_1pct_fpr": 0.660},
        "slices": {"country=US": {"recall_at_1pct_fpr": 0.680}, "country=BR": {"recall_at_1pct_fpr": 0.600},
                   "new_users": {"recall_at_1pct_fpr": 0.520}},
        "serving": {"p95_ms": 95, "size_mb": 1400},
    },
    "v16 trained in a notebook": {
        "lineage": {"git_commit": "d4e5f6"}, "n_eval": 20000,
        "metrics": {"auc": 0.915, "recall_at_1pct_fpr": 0.615},
        "slices": {}, "serving": {"p95_ms": 37, "size_mb": 180},
    },
}


def demo():
    verdicts = {}
    for name, cand in CANDIDATES.items():
        ok, results = gate(cand, CHAMPION)
        verdicts[name] = (ok, results)
        print_report(name, ok, results)

    def failed(name):
        return {r[0] for r in verdicts[name][1] if not r[1]}

    print("\nChecks:")
    checks = [
        ("v13 promoted", verdicts["v13 better everywhere"][0]),
        ("v14 blocked by the Brazil slice despite better overall metrics",
         not verdicts["v14 better overall, worse for Brazil"][0]
         and failed("v14 better overall, worse for Brazil") == {"slice country=BR recall_at_1pct_fpr"}),
        ("v15 blocked by latency and size", failed("v15 more accurate but too slow") == {"serving p95_ms", "serving size_mb"}),
        ("v16 blocked by missing lineage", "lineage" in failed("v16 trained in a notebook")),
    ]
    for label, ok in checks:
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}")
    return 0 if all(ok for _, ok in checks) else 1


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--candidate", help="candidate evaluation report (JSON)")
    p.add_argument("--champion", help="champion evaluation report (JSON)")
    p.add_argument("--policy", help="gate policy (JSON); defaults to the built-in policy")
    a = p.parse_args()
    if not a.candidate:
        return demo()
    load = lambda f: json.load(open(f))
    policy = {**DEFAULT_POLICY, **load(a.policy)} if a.policy else DEFAULT_POLICY
    ok, results = gate(load(a.candidate), load(a.champion), policy)
    print_report(a.candidate, ok, results)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
