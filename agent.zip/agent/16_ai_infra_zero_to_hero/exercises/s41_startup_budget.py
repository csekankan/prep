#!/usr/bin/env python3
"""Section 41 assessment: advise a startup CTO on a limited AI budget.

A seed-stage startup runs an LLM document assistant. Compare four ways to serve it, month by month as traffic grows:

  frontier-api   every request to a hosted frontier model (pay per token)
  small-api      every request to a hosted small model (pay per token)
  router         a cheap classifier sends easy requests to the small model, hard ones to the frontier model,
                 with a prompt cache cutting the frontier model's input cost
  self-host      an open 8B model on rented H100s with vLLM: GPU-hours (at least 2 for availability) plus the
                 engineering time to run it

For each option: cost per request, monthly cost over 12 months, the month the AI budget is exceeded, the month the
company runs out of cash without new funding, and the traffic at which self-hosting becomes cheaper than the
small-model API.

All prices are illustrative list prices, so you can swap in current ones. Only the standard library is used.

Usage:
  python3 s41_startup_budget.py
"""
import math
import sys

REQ_MONTH0 = 2_000_000          # requests in month 1
GROWTH = 0.25                   # month-over-month request growth
IN_TOK, OUT_TOK = 1_500, 300    # average tokens per request
AI_BUDGET = 25_000              # $ per month the board approved for AI serving
CASH, OTHER_BURN = 3_000_000, 180_000

PRICES = {"frontier": (3.00, 15.00), "small": (0.15, 0.60)}     # $ per 1M input, output tokens
ROUTER_SMALL_SHARE = 0.80       # share of requests the router sends to the small model
CACHE_HIT, CACHE_DISCOUNT = 0.60, 0.90   # share of frontier input tokens served from prompt cache, and its discount

GPU_HOUR = 2.50                 # $ per H100-hour (neocloud on-demand)
GPU_OUT_TOK_S = 2_500           # sustained output tokens/s for an 8B model per H100 with batching
GPU_UTIL = 0.40                 # average utilization (traffic is bursty)
MIN_GPUS = 2                    # availability: never run on a single GPU
ENG_MONTH = 0.25 * 200_000 / 12 # a quarter of an engineer's loaded cost to run self-hosting
HOURS = 730


def per_request(model, input_discount=0.0):
    pin, pout = PRICES[model]
    return IN_TOK * pin * (1 - input_discount) / 1e6 + OUT_TOK * pout / 1e6


def router_per_request():
    frontier = per_request("frontier", input_discount=CACHE_HIT * CACHE_DISCOUNT)
    return ROUTER_SMALL_SHARE * per_request("small") + (1 - ROUTER_SMALL_SHARE) * frontier


def self_host_gpus(requests):
    tokens_per_s = requests * OUT_TOK / (HOURS * 3600)
    return max(MIN_GPUS, math.ceil(tokens_per_s / (GPU_OUT_TOK_S * GPU_UTIL)))


def monthly_cost(option, requests):
    if option == "frontier-api":
        return requests * per_request("frontier")
    if option == "small-api":
        return requests * per_request("small")
    if option == "router":
        return requests * router_per_request()
    if option == "self-host":
        return self_host_gpus(requests) * GPU_HOUR * HOURS + ENG_MONTH
    raise ValueError(option)


OPTIONS = ["frontier-api", "small-api", "router", "self-host"]


def breakeven_requests():
    """Smallest monthly request volume where self-hosting is cheaper than the small-model API."""
    lo, hi = 1, 10**12
    while lo < hi:
        mid = (lo + hi) // 2
        if monthly_cost("self-host", mid) < monthly_cost("small-api", mid):
            hi = mid
        else:
            lo = mid + 1
    return lo


def main():
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"{'PASS' if cond else 'FAIL'}  {name}")

    print("Cost per request")
    cpr = {"frontier-api": per_request("frontier"), "small-api": per_request("small"), "router": router_per_request()}
    for k, v in cpr.items():
        print(f"  {k:13} ${v:.6f}")
    print()

    months = range(1, 13)
    reqs = [round(REQ_MONTH0 * (1 + GROWTH) ** (m - 1)) for m in months]
    table = {o: [monthly_cost(o, r) for r in reqs] for o in OPTIONS}
    print(f"{'month':>5} {'requests':>12} " + " ".join(f"{o:>13}" for o in OPTIONS) + "  self-host GPUs")
    for i, m in enumerate(months):
        print(f"{m:>5} {reqs[i]:>12,} " + " ".join(f"{table[o][i]:>13,.0f}" for o in OPTIONS)
              + f"  {self_host_gpus(reqs[i]):>3}")
    over = {o: next((m for m, c in zip(months, table[o]) if c > AI_BUDGET), None) for o in OPTIONS}
    totals = {o: sum(table[o]) for o in OPTIONS}
    print("\nFirst month over the $25,000 AI budget: " + ", ".join(f"{o} {over[o]}" for o in OPTIONS))
    print("12-month AI spend: " + ", ".join(f"{o} ${totals[o]:,.0f}" for o in OPTIONS))
    cash_end = {o: CASH - 12 * OTHER_BURN - totals[o] for o in OPTIONS}
    cash_out = {}
    for o in OPTIONS:
        cash = CASH
        for m, c in zip(months, table[o]):
            cash -= OTHER_BURN + c
            if cash < 0:
                cash_out[o] = m
                break
        else:
            cash_out[o] = None
    print("Cash left after 12 months: " + ", ".join(f"{o} ${cash_end[o]:,.0f}" for o in OPTIONS))
    print("Month cash runs out (no new funding): " + ", ".join(f"{o} {cash_out[o]}" for o in OPTIONS))
    be = breakeven_requests()
    be_month = next((m for m, r in zip(months, reqs) if r >= be), None)
    print(f"Self-hosting beats the small-model API above {be:,} requests/month (reached in month {be_month})\n")

    check("frontier API costs $0.009 per request (1,500 in x $3/M + 300 out x $15/M)", abs(cpr["frontier-api"] - 0.009) < 1e-9)
    check("frontier API is $18,000 in month 1 and blows the budget by month 3",
          round(table["frontier-api"][0]) == 18_000 and over["frontier-api"] == 3)
    check("small-model API is about 22x cheaper per request", round(cpr["frontier-api"] / cpr["small-api"]) == 22)
    check("router costs about a fifth of frontier-only", 0.15 < cpr["router"] / cpr["frontier-api"] < 0.25)
    check("router stays within budget for 10 months, then 25%/month growth breaks it in month 11",
          over["router"] == 11)
    check("self-hosting is dearer than the small API at launch traffic (fixed GPUs + engineer)",
          table["self-host"][0] > 5 * table["small-api"][0])
    check("self-host break-even volume is beyond the 12-month plan", be_month is None and be > reqs[-1])
    check("frontier-only runs out of cash in month 12; every other option survives the year",
          cash_out["frontier-api"] == 12 and all(cash_out[o] is None for o in OPTIONS[1:]))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
