"""Section 9 exercise: build a reproducible experiment record, then prove it reproduces.

A run is reproducible when someone else can rebuild the same model from its record. The record must pin:
  code     git commit (+ dirty flag) and a hash of the training script
  data     content hash of the exact dataset (not just its path)
  params   every hyperparameter, including the random seed
  env      Python version, OS, and versions of the key packages
  outputs  metrics and a content hash of every artifact (the model file)

This script trains a tiny logistic-regression model in pure Python, writes a record (JSON), re-runs it from
the record to verify the artifact hash matches byte for byte, and diffs records to explain why two runs
differ. MLflow or W&B store the same fields; the point is knowing which fields matter.

Usage:
  python3 s09_experiment_record.py                       # demo: reproduce, change a param, change the data
  python3 s09_experiment_record.py --lint record.json    # check a record has every required field
  python3 s09_experiment_record.py --diff a.json b.json  # explain the difference between two runs
"""

import argparse
import hashlib
import json
import math
import platform
import random
import subprocess
import sys
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

REQUIRED = {
    "code": ["git_commit", "script_sha256"],
    "data": ["uri", "sha256", "rows"],
    "params": ["seed", "lr", "epochs"],
    "env": ["python", "platform"],
    "metrics": ["accuracy", "log_loss"],
    "artifacts": ["model.json"],
}


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def make_dataset(path, n=400, seed=7, flip_row=None):
    rng = random.Random(seed)
    lines = ["x1,x2,label"]
    for i in range(n):
        x1, x2 = rng.gauss(0, 1), rng.gauss(0, 1)
        label = 1 if 1.5 * x1 - 2.0 * x2 + rng.gauss(0, 0.5) > 0 else 0
        if i == flip_row:
            label = 1 - label
        lines.append(f"{x1:.6f},{x2:.6f},{label}")
    Path(path).write_text("\n".join(lines) + "\n")


def load(path):
    rows = Path(path).read_text().strip().splitlines()[1:]
    return [(float(a), float(b), int(c)) for a, b, c in (r.split(",") for r in rows)]


def train(data, seed, lr, epochs):
    rng = random.Random(seed)
    w = [rng.uniform(-0.1, 0.1) for _ in range(3)]
    order = list(range(len(data)))
    for _ in range(epochs):
        rng.shuffle(order)
        for i in order:
            x1, x2, y = data[i]
            p = 1 / (1 + math.exp(-(w[0] + w[1] * x1 + w[2] * x2)))
            g = p - y
            w = [w[0] - lr * g, w[1] - lr * g * x1, w[2] - lr * g * x2]
    correct, loss = 0, 0.0
    for x1, x2, y in data:
        p = min(max(1 / (1 + math.exp(-(w[0] + w[1] * x1 + w[2] * x2))), 1e-12), 1 - 1e-12)
        correct += (p > 0.5) == bool(y)
        loss -= y * math.log(p) + (1 - y) * math.log(1 - p)
    return [round(v, 10) for v in w], {"accuracy": round(correct / len(data), 6), "log_loss": round(loss / len(data), 6)}


def git_info():
    try:
        commit = subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()
        dirty = bool(subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True).stdout.strip())
        return commit, dirty
    except (OSError, subprocess.CalledProcessError):
        return "not-a-git-repo", None


def run_experiment(data_path, params, out_dir, name):
    data = load(data_path)
    weights, metrics = train(data, params["seed"], params["lr"], params["epochs"])
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    model_path = out_dir / f"{name}_model.json"
    model_path.write_text(json.dumps({"weights": weights}, sort_keys=True))
    commit, dirty = git_info()
    record = {
        "run_id": uuid.uuid4().hex[:12],
        "name": name,
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "code": {"git_commit": commit, "git_dirty": dirty, "script_sha256": sha256_file(__file__)},
        "data": {"uri": str(data_path), "sha256": sha256_file(data_path), "rows": len(data)},
        "params": params,
        "env": {"python": platform.python_version(), "platform": platform.platform()},
        "metrics": metrics,
        "artifacts": {"model.json": {"path": str(model_path), "sha256": sha256_file(model_path)}},
    }
    record_path = out_dir / f"{name}_record.json"
    record_path.write_text(json.dumps(record, indent=2, sort_keys=True))
    return record, record_path


def lint(record):
    problems = []
    for section, keys in REQUIRED.items():
        if section not in record:
            problems.append(f"missing section '{section}'")
            continue
        for k in keys:
            if record[section].get(k) in (None, ""):
                problems.append(f"missing {section}.{k}")
    if record.get("code", {}).get("git_dirty"):
        problems.append("code.git_dirty is true: uncommitted changes make the run unreproducible")
    return problems


def verify(record, out_dir):
    """Re-run from the record alone; reproducible if data hash matches and the model hash is identical."""
    if sha256_file(record["data"]["uri"]) != record["data"]["sha256"]:
        return False, "data changed since the run (hash mismatch)"
    rerun, _ = run_experiment(record["data"]["uri"], record["params"], out_dir, record["name"] + "_rerun")
    same = rerun["artifacts"]["model.json"]["sha256"] == record["artifacts"]["model.json"]["sha256"]
    return same, "model hash identical" if same else "model hash differs"


def diff(a, b, prefix=""):
    ignore = {"run_id", "created_at", "name", "path", "uri"}
    out = []
    for k in sorted(set(a) | set(b)):
        if k in ignore:
            continue
        va, vb = a.get(k), b.get(k)
        if isinstance(va, dict) and isinstance(vb, dict):
            out += diff(va, vb, f"{prefix}{k}.")
        elif va != vb:
            out.append(f"{prefix}{k}: {va} -> {vb}")
    return out


def demo():
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        data_v1 = tmp / "data_v1.csv"
        make_dataset(data_v1)
        base = {"seed": 42, "lr": 0.05, "epochs": 20}

        print("Run A: baseline")
        a, a_path = run_experiment(data_v1, base, tmp, "A")
        print(f"  metrics={a['metrics']} model_sha={a['artifacts']['model.json']['sha256'][:12]}")
        problems = [p for p in lint(a) if "git_dirty" not in p]
        print(f"  lint: {'OK' if not problems else problems}")

        print("\nVerify A: re-run from the record alone")
        ok, why = verify(json.loads(a_path.read_text()), tmp)
        print(f"  reproducible={ok} ({why})")

        print("\nRun B: change one hyperparameter (lr 0.05 -> 0.2)")
        b, _ = run_experiment(data_v1, {**base, "lr": 0.2}, tmp, "B")
        d_ab = diff(a, b)
        print("  diff A->B:", *d_ab, sep="\n    ")

        print("\nRun C: same params, one label flipped in the data")
        data_v2 = tmp / "data_v2.csv"
        make_dataset(data_v2, flip_row=3)
        c, _ = run_experiment(data_v2, base, tmp, "C")
        d_ac = diff(a, c)
        print("  diff A->C:", *d_ac, sep="\n    ")

        print("\nRun D: a record someone logged by hand")
        bad = {"params": {"lr": 0.05}, "metrics": {"accuracy": 0.97}, "data": {"uri": "s3://bucket/latest.csv"}}
        bad_problems = lint(bad)
        print("  lint:", *bad_problems, sep="\n    ")

        print("\nChecks:")
        checks = [
            ("A has every required field", not problems),
            ("A reproduces byte for byte", ok),
            ("diff A->B names the lr change", any(line.startswith("params.lr") for line in d_ab)),
            ("diff A->C names the data hash change", any(line.startswith("data.sha256") for line in d_ac)),
            ("hand-logged record rejected (no seed, no data hash)",
             "missing params.seed" in bad_problems and "missing data.sha256" in bad_problems),
        ]
        for label, passed in checks:
            print(f"  [{'PASS' if passed else 'FAIL'}] {label}")
        return 0 if all(p for _, p in checks) else 1


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--lint", type=Path, help="record JSON to check")
    p.add_argument("--diff", nargs=2, type=Path, metavar=("A", "B"), help="two record JSONs to compare")
    args = p.parse_args()
    if args.lint:
        problems = lint(json.loads(args.lint.read_text()))
        print("OK" if not problems else "\n".join(problems))
        return 1 if problems else 0
    if args.diff:
        a, b = (json.loads(x.read_text()) for x in args.diff)
        print("\n".join(diff(a, b)) or "no differences")
        return 0
    return demo()


if __name__ == "__main__":
    sys.exit(main())
