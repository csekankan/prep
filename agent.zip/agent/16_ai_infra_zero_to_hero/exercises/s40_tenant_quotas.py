#!/usr/bin/env python3
"""Section 40 assessment: enforce multi-tenant resource quotas the way Kubernetes and Kueue do.

Two layers, as in a real GPU cluster:

1. Namespace admission (Kubernetes LimitRange + ResourceQuota), checked when a pod is created:
     - LimitRange fills in default CPU/memory requests and rejects containers above the per-container max
     - nvidia.com/gpu is an extended resource: it must have a limit, and request must equal limit (no overcommit)
     - ResourceQuota rejects the pod if the namespace's total requests would exceed its hard caps

2. Queue admission (Kueue ClusterQueues in one cohort), deciding when a GPU job may start:
     - each team has a nominal GPU quota; usage up to nominal is guaranteed
     - a team may borrow unused nominal quota of others in the cohort, up to its borrowingLimit
     - when a team below its nominal quota needs GPUs that are lent out, borrowed workloads are preempted
       (lowest priority first, then newest) until it fits: reclaimWithinCohort
     - jobs that can't be admitted wait in the queue (they are not rejected)

Usage:
  python3 s40_tenant_quotas.py              # scenario + PASS/FAIL checks
"""
import sys

# ---------------- layer 1: LimitRange + ResourceQuota ----------------

LIMIT_RANGE = {"default_cpu_m": 500, "default_mem_mi": 1024, "max_cpu_m": 32_000, "max_mem_mi": 256 * 1024}
QUOTA = {"ml-team-a": {"cpu_m": 200_000, "mem_mi": 1_600 * 1024, "gpu": 24},
         "ml-team-b": {"cpu_m": 100_000, "mem_mi": 800 * 1024, "gpu": 16},
         "ml-team-c": {"cpu_m": 100_000, "mem_mi": 800 * 1024, "gpu": 8}}


def admit_pod(ns, pod, used):
    """pod: dict with optional cpu_m, mem_mi, gpu_request, gpu_limit. Returns (ok, reason, effective requests)."""
    cpu = pod.get("cpu_m", LIMIT_RANGE["default_cpu_m"])
    mem = pod.get("mem_mi", LIMIT_RANGE["default_mem_mi"])
    if cpu > LIMIT_RANGE["max_cpu_m"] or mem > LIMIT_RANGE["max_mem_mi"]:
        return False, "LimitRange: container exceeds max cpu/memory", None
    req, lim = pod.get("gpu_request"), pod.get("gpu_limit")
    if req is not None and lim is None:
        return False, "nvidia.com/gpu needs a limit (extended resources can't be overcommitted)", None
    if req is not None and req != lim:
        return False, "nvidia.com/gpu request must equal limit", None
    gpu = lim or 0
    eff = {"cpu_m": cpu, "mem_mi": mem, "gpu": gpu}
    for k, v in eff.items():
        if used[ns][k] + v > QUOTA[ns][k]:
            return False, f"ResourceQuota: {k} {used[ns][k]} + {v} > hard {QUOTA[ns][k]}", None
    for k, v in eff.items():
        used[ns][k] += v
    return True, "admitted", eff


# ---------------- layer 2: Kueue-style cohort with borrowing and reclaim ----------------

QUEUES = {"team-a": {"nominal": 16, "borrowing_limit": 8},
          "team-b": {"nominal": 8, "borrowing_limit": 8},
          "team-c": {"nominal": 8, "borrowing_limit": 0}}
COHORT_GPUS = sum(q["nominal"] for q in QUEUES.values())


class Cohort:
    def __init__(self):
        self.running = []                    # (seq, name, team, gpus, priority)
        self.pending = []
        self.seq = 0
        self.log = []

    def usage(self, team):
        return sum(w[3] for w in self.running if w[2] == team)

    def total(self):
        return sum(w[3] for w in self.running)

    def borrowed(self, team):
        return max(0, self.usage(team) - QUEUES[team]["nominal"])

    def fits(self, team, gpus):
        q = QUEUES[team]
        if self.usage(team) + gpus > q["nominal"] + q["borrowing_limit"]:
            return False
        return self.total() + gpus <= COHORT_GPUS

    def submit(self, name, team, gpus, priority=0):
        self.seq += 1
        w = (self.seq, name, team, gpus, priority)
        if self.fits(team, gpus):
            self.running.append(w)
            kind = "borrowing" if self.usage(team) > QUEUES[team]["nominal"] else "within nominal"
            self.log.append(f"admit   {name:10} {team} {gpus:2d} GPUs ({kind})")
            return "admitted"
        if self.usage(team) + gpus <= QUEUES[team]["nominal"]:      # entitled: reclaim lent quota
            victims = sorted((v for v in self.running if self.borrowed(v[2]) > 0 and v[2] != team),
                             key=lambda v: (v[4], -v[0]))
            freed = []
            for v in victims:
                if self.total() + gpus <= COHORT_GPUS:
                    break
                if self.borrowed(v[2]) <= 0:
                    continue
                self.running.remove(v)
                self.pending.append(v)
                freed.append(v[1])
            if self.total() + gpus <= COHORT_GPUS:
                self.running.append(w)
                self.log.append(f"admit   {name:10} {team} {gpus:2d} GPUs (reclaimed by preempting {', '.join(freed)})")
                return "admitted after reclaim"
        self.pending.append(w)
        self.log.append(f"pending {name:10} {team} {gpus:2d} GPUs")
        return "pending"

    def finish(self, name):
        self.running = [w for w in self.running if w[1] != name]
        self.log.append(f"finish  {name}")
        for w in sorted(self.pending, key=lambda v: (-v[4], v[0])):
            if self.fits(w[2], w[3]):
                self.pending.remove(w)
                self.running.append(w)
                self.log.append(f"admit   {w[1]:10} {w[2]} {w[3]:2d} GPUs (from queue)")


def main():
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"{'PASS' if cond else 'FAIL'}  {name}")

    print("Layer 1: namespace admission (LimitRange + ResourceQuota)")
    used = {ns: {"cpu_m": 0, "mem_mi": 0, "gpu": 0} for ns in QUOTA}
    pods = [("ml-team-c", "notebook", {}),
            ("ml-team-c", "trainer-1", {"cpu_m": 16_000, "mem_mi": 64 * 1024, "gpu_request": 4, "gpu_limit": 4}),
            ("ml-team-c", "trainer-2", {"cpu_m": 16_000, "mem_mi": 64 * 1024, "gpu_request": 4}),
            ("ml-team-c", "trainer-3", {"cpu_m": 16_000, "mem_mi": 64 * 1024, "gpu_request": 2, "gpu_limit": 4}),
            ("ml-team-c", "huge-cpu", {"cpu_m": 64_000}),
            ("ml-team-c", "trainer-4", {"cpu_m": 16_000, "mem_mi": 64 * 1024, "gpu_request": 4, "gpu_limit": 4}),
            ("ml-team-c", "trainer-5", {"cpu_m": 8_000, "mem_mi": 32 * 1024, "gpu_request": 1, "gpu_limit": 1})]
    results = {}
    for ns, name, spec in pods:
        r = admit_pod(ns, spec, used)
        results[name] = r
        eff = r[2] or {}
        print(f"  {name:10} {'OK  ' if r[0] else 'DENY'} {r[1]}"
              + (f"  (cpu {eff['cpu_m']}m, mem {eff['mem_mi']}Mi, gpu {eff['gpu']})" if eff else ""))
    print(f"  ml-team-c usage: {used['ml-team-c']}  hard: {QUOTA['ml-team-c']}\n")

    check("LimitRange default: a pod with no requests is charged 500m CPU and 1Gi", results["notebook"][2] ==
          {"cpu_m": 500, "mem_mi": 1024, "gpu": 0})
    check("GPU request without a limit is rejected", not results["trainer-2"][0] and "limit" in results["trainer-2"][1])
    check("GPU request != limit is rejected", not results["trainer-3"][0])
    check("LimitRange max rejects a 64-CPU container", not results["huge-cpu"][0])
    check("ResourceQuota admits up to 8 GPUs, then rejects the 9th",
          results["trainer-1"][0] and results["trainer-4"][0] and not results["trainer-5"][0]
          and used["ml-team-c"]["gpu"] == 8)

    print("Layer 2: Kueue-style cohort, 32 GPUs (team-a 16, team-b 8, team-c 8 nominal)")
    c = Cohort()
    snap = {}
    c.submit("a-pretrain", "team-a", 8, priority=1)
    c.submit("b-sweep-1", "team-b", 8)
    snap["b_borrow"] = c.submit("b-sweep-2", "team-b", 8)                  # borrows team-a's idle 8
    snap["c_job"] = c.submit("c-finetune", "team-c", 8)                     # within nominal, fits exactly
    snap["c_borrow"] = c.submit("c-extra", "team-c", 4)                     # borrowing_limit 0
    snap["total_before"] = c.total()
    snap["a_reclaim"] = c.submit("a-urgent", "team-a", 8, priority=2)       # needs its lent quota back
    snap["b_after"] = c.usage("team-b")
    snap["pending_after"] = [w[1] for w in c.pending]
    snap["b_over"] = c.submit("b-sweep-3", "team-b", 9)                     # over nominal + borrowing limit
    c.finish("a-urgent")
    snap["requeued"] = [w[1] for w in c.running]
    for line in c.log:
        print("  " + line)
    print(f"  final usage: " + ", ".join(f"{t} {c.usage(t)}/{QUEUES[t]['nominal']}" for t in QUEUES)
          + f", total {c.total()}/{COHORT_GPUS}, pending {[w[1] for w in c.pending]}\n")

    check("team-b borrows team-a's idle 8 GPUs (usage 16 > nominal 8)", snap["b_borrow"] == "admitted")
    check("team-c within nominal is admitted, and its borrowing is refused (borrowingLimit 0)",
          snap["c_job"] == "admitted" and snap["c_borrow"] == "pending")
    check("cohort is full at 32 GPUs before the reclaim", snap["total_before"] == 32)
    check("team-a reclaims its nominal quota by preempting team-b's borrowed job only",
          snap["a_reclaim"] == "admitted after reclaim" and snap["b_after"] == 8 and "b-sweep-2" in snap["pending_after"])
    check("a request above nominal + borrowingLimit waits and never runs",
          snap["b_over"] == "pending" and "b-sweep-3" not in snap["requeued"])
    check("when a-urgent finishes, the preempted job is re-admitted from the queue", "b-sweep-2" in snap["requeued"])
    check("total GPUs never exceed the cohort's 32", c.total() <= COHORT_GPUS)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
