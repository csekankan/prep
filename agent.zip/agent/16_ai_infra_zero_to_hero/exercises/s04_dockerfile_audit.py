"""Section 4 exercise: audit a Dockerfile for AI-serving anti-patterns.

Usage:
  python3 s04_dockerfile_audit.py                  # audits the built-in example from the section
  python3 s04_dockerfile_audit.py path/to/Dockerfile

Exit code: 1 if any HIGH finding, else 0, so it can gate a CI pipeline.

This is a teaching linter: simple line-based rules that catch the most common mistakes. For real
pipelines, pair it with hadolint (Dockerfile lint) and trivy (image vulnerability scan).
"""

import re
import sys
from dataclasses import dataclass

EXAMPLE = """\
FROM pytorch/pytorch:latest
COPY . .
RUN pip install -r requirements.txt
RUN apt-get update && apt-get install -y libgl1 curl vim
ENV HF_TOKEN=hf_aBcD1234secret
ENV AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG
ADD https://example.com/model.bin /models/model.bin
EXPOSE 22 8000
CMD python serve.py
"""

SECRET_NAME = re.compile(r"(TOKEN|SECRET|PASSWORD|PASSWD|API_KEY|ACCESS_KEY|PRIVATE_KEY|CREDENTIAL)", re.I)
WEIGHT_FILE = re.compile(r"\.(bin|pt|pth|safetensors|ckpt|onnx|gguf|h5)\b", re.I)
DEBUG_TOOLS = {"vim", "nano", "emacs", "curl", "wget", "net-tools", "openssh-server", "gdb"}
SEVERITY_ORDER = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}


@dataclass
class Finding:
    severity: str
    line: int | None   # None = applies to the whole file
    problem: str
    fix: str


@dataclass
class Instruction:
    line: int          # line number where the instruction starts
    keyword: str
    args: str


def parse(text: str) -> list[Instruction]:
    """Split a Dockerfile into instructions, joining backslash-continued lines."""
    instructions, buf, start = [], "", None
    for n, raw in enumerate(text.splitlines(), start=1):
        line = raw.strip()
        if not buf and (not line or line.startswith("#")):
            continue
        if start is None:
            start = n
        if line.endswith("\\"):
            buf += line[:-1] + " "
            continue
        buf += line
        keyword, _, args = buf.partition(" ")
        instructions.append(Instruction(start, keyword.upper(), args.strip()))
        buf, start = "", None
    return instructions


def audit(text: str) -> list[Finding]:
    ins = parse(text)
    f: list[Finding] = []
    keywords = [i.keyword for i in ins]

    froms = [i for i in ins if i.keyword == "FROM"]
    for i in froms:
        image = i.args.split()[0]
        if image.lower() == "scratch" or "$" in image or "@sha256:" in image:
            continue
        # A tag is the part after the last ":" that comes after the last "/" (registry ports have ":" too).
        name = image.rsplit("/", 1)[-1]
        tag = name.split(":", 1)[1] if ":" in name else None
        if tag in (None, "latest"):
            f.append(Finding("HIGH", i.line, f"Base image '{image}' is unpinned (latest): builds change silently",
                             "Pin a version tag (e.g. 2.4.1-cuda12.4-cudnn9-runtime) and deploy by digest"))
    final_base = froms[-1].args.split()[0].lower() if froms else ""
    if "devel" in final_base:
        f.append(Finding("MEDIUM", froms[-1].line, "Final stage uses a CUDA 'devel' base (~3 GB of compilers)",
                         "Use a '-runtime' base in the final stage; keep 'devel' in a builder stage"))
    if len(froms) == 1 and any(k in final_base for k in ("pytorch", "cuda", "tensorflow")):
        f.append(Finding("LOW", None, "Single-stage build on a heavy ML base image",
                         "Use a multi-stage build so build tools and caches don't ship"))

    if "USER" not in keywords:
        f.append(Finding("HIGH", None, "No USER instruction: the app runs as root",
                         "RUN useradd --uid 10001 app, then USER 10001"))

    for i in ins:
        if i.keyword in ("ENV", "ARG"):
            for name in re.findall(r"([A-Za-z_][A-Za-z0-9_]*)\s*=", i.args) or i.args.split()[:1]:
                if SECRET_NAME.search(name):
                    f.append(Finding("HIGH", i.line, f"Secret-like variable '{name}' baked into the image "
                                     "(readable with docker history / inspect)",
                                     "Inject at runtime from a secrets manager; rotate the exposed value now"))
        if i.keyword in ("COPY", "ADD") and re.search(r"(\.env|id_rsa|\.pem|credentials)\b", i.args):
            f.append(Finding("HIGH", i.line, "Copies a credentials file into the image",
                             "Never copy secrets; mount them at runtime"))

    copy_all = next((i for i in ins if i.keyword == "COPY" and re.match(r"^(--\S+\s+)*\.\s+\S+$", i.args)), None)
    first_install = next((i for i in ins if i.keyword == "RUN" and re.search(r"pip3? install|uv pip|poetry install|conda install", i.args)), None)
    if copy_all and first_install and copy_all.line < first_install.line:
        f.append(Finding("MEDIUM", copy_all.line, "'COPY . .' before installing dependencies: every code change "
                         "reinstalls everything, and the whole build context is copied",
                         "COPY requirements.txt first, install, then COPY the code; add a .dockerignore"))

    for i in ins:
        if i.keyword in ("ADD", "COPY") and WEIGHT_FILE.search(i.args):
            f.append(Finding("MEDIUM", i.line, "Model weights baked into the image: huge layers on every deploy",
                             "Mount weights from a volume/PVC or download at startup from object storage"))
        if i.keyword == "ADD" and re.search(r"https?://", i.args):
            f.append(Finding("MEDIUM", i.line, "Remote ADD: unverified download, no checksum",
                             "Download in a RUN step and verify a sha256, or use ADD --checksum=sha256:..."))
        if i.keyword == "RUN" and re.search(r"curl[^|]*\|\s*(ba)?sh", i.args):
            f.append(Finding("MEDIUM", i.line, "Pipes a remote script into a shell",
                             "Download, verify a checksum, then execute"))
        if i.keyword == "EXPOSE" and re.search(r"\b22\b", i.args):
            f.append(Finding("MEDIUM", i.line, "Exposes port 22 (SSH inside a container)",
                             "Remove it; use docker exec / kubectl exec for debugging"))
        if i.keyword in ("CMD", "ENTRYPOINT") and not i.args.startswith("["):
            f.append(Finding("MEDIUM", i.line, f"Shell-form {i.keyword}: /bin/sh is PID 1 and doesn't forward "
                             "SIGTERM, so in-flight requests are cut off on shutdown",
                             f'Use exec form: {i.keyword} ["python", "serve.py"]'))
        if i.keyword == "RUN" and re.search(r"pip3? install", i.args) and "--no-cache-dir" not in i.args \
                and "--mount=type=cache" not in i.args:
            f.append(Finding("LOW", i.line, "pip install keeps its download cache in the image",
                             "Add --no-cache-dir or use RUN --mount=type=cache,target=/root/.cache/pip"))
        if i.keyword == "RUN" and "apt-get install" in i.args:
            if "--no-install-recommends" not in i.args:
                f.append(Finding("LOW", i.line, "apt-get install without --no-install-recommends",
                                 "Add --no-install-recommends to avoid pulling extra packages"))
            if "rm -rf /var/lib/apt/lists" not in i.args:
                f.append(Finding("LOW", i.line, "apt package lists not cleaned in the same layer",
                                 "Append '&& rm -rf /var/lib/apt/lists/*'"))
            tools = sorted(DEBUG_TOOLS & set(re.split(r"\s+", i.args)))
            if tools:
                f.append(Finding("LOW", i.line, f"Debug tools in the production image: {', '.join(tools)}",
                                 "Install only runtime needs; debug with an ephemeral debug container"))
        if i.keyword == "RUN" and re.search(r"\bsudo\b", i.args):
            f.append(Finding("LOW", i.line, "sudo inside a Dockerfile", "Build steps already run as root; drop sudo"))

    if "HEALTHCHECK" not in keywords:
        f.append(Finding("LOW", None, "No HEALTHCHECK", "Add one, or define readiness/liveness probes in Kubernetes"))
    if "WORKDIR" not in keywords:
        f.append(Finding("LOW", None, "No WORKDIR: files land in /", "Set WORKDIR /app"))

    return sorted(f, key=lambda x: (SEVERITY_ORDER[x.severity], x.line or 0))


def main() -> int:
    if len(sys.argv) > 1:
        path = sys.argv[1]
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
    else:
        path, text = "<built-in example from Section 4>", EXAMPLE

    findings = audit(text)
    print(f"Auditing {path}\n")
    if not findings:
        print("No findings. Still run hadolint and trivy before shipping.")
        return 0
    for x in findings:
        where = f"line {x.line}" if x.line else "file"
        print(f"[{x.severity:<6}] {where:<8} {x.problem}\n{'':18}fix: {x.fix}")
    counts = {s: sum(1 for x in findings if x.severity == s) for s in SEVERITY_ORDER}
    print(f"\n{counts['HIGH']} high, {counts['MEDIUM']} medium, {counts['LOW']} low")
    return 1 if counts["HIGH"] else 0


if __name__ == "__main__":
    sys.exit(main())
