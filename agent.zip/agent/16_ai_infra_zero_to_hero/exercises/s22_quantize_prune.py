#!/usr/bin/env python3
"""Section 22 exercise: measure what quantization and pruning do to a layer.

Uses one linear layer y = W x (64 outputs x 128 inputs) with realistic structure: output channels have
very different weight ranges, and one weight is an outlier. It compares:

  - per-tensor vs per-channel symmetric INT8 weight quantization (and INT4)
  - the effect of a single outlier on per-tensor scales
  - symmetric vs asymmetric (zero-point) INT8 for non-negative activations (after ReLU)
  - unstructured magnitude pruning at 50/80/90% vs structured pruning (whole output channels)

Error is the relative error of the layer output, ||y_q - y|| / ||y||, over 200 random inputs.

Usage:
  python3 s22_quantize_prune.py
"""
import argparse
import math
import random
import sys

OUT, IN, SAMPLES = 64, 128, 200


def make_layer(seed=0):
    rnd = random.Random(seed)
    W = []
    for o in range(OUT):
        scale = 0.02 * (1 + 9 * rnd.random() ** 3)           # channel ranges differ up to ~10x
        W.append([rnd.gauss(0, scale) for _ in range(IN)])
    xs = [[max(0.0, rnd.gauss(0.3, 1.0)) for _ in range(IN)] for _ in range(SAMPLES)]   # post-ReLU inputs
    return W, xs


def matvec(W, x):
    return [sum(w * v for w, v in zip(row, x)) for row in W]


def rel_err(W_ref, W_test, xs):
    num = den = 0.0
    for x in xs:
        a, b = matvec(W_ref, x), matvec(W_test, x)
        num += sum((p - q) ** 2 for p, q in zip(a, b))
        den += sum(p * p for p in a)
    return math.sqrt(num / den)


def q_sym(values, scale, bits=8):
    qmax = 2 ** (bits - 1) - 1
    return [max(-qmax, min(qmax, round(v / scale))) * scale for v in values]


def quant_per_tensor(W, bits=8):
    s = max(abs(v) for row in W for v in row) / (2 ** (bits - 1) - 1)
    return [q_sym(row, s, bits) for row in W]


def quant_per_channel(W, bits=8):
    return [q_sym(row, max(abs(v) for v in row) / (2 ** (bits - 1) - 1), bits) for row in W]


def quant_act_sym(x, bits=8):
    s = max(abs(v) for v in x) / (2 ** (bits - 1) - 1)
    return q_sym(x, s, bits)


def quant_act_asym(x, bits=8):
    lo, hi = min(x), max(x)
    scale = (hi - lo) / (2 ** bits - 1)
    zp = round(-lo / scale)
    return [(max(0, min(2 ** bits - 1, round(v / scale) + zp)) - zp) * scale for v in x]


def prune_unstructured(W, sparsity):
    mags = sorted(abs(v) for row in W for v in row)
    thr = mags[int(len(mags) * sparsity)]
    return [[v if abs(v) >= thr else 0.0 for v in row] for row in W]


def prune_structured(W, sparsity):
    norms = sorted(range(OUT), key=lambda o: sum(v * v for v in W[o]))
    drop = set(norms[:int(OUT * sparsity)])
    return [[0.0] * IN if o in drop else row[:] for o, row in enumerate(W)]


def demo():
    results = []

    def check(name, ok, info=""):
        results.append(ok)
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}{'  ' + info if info else ''}")

    W, xs = make_layer()
    print(f"Layer {OUT}x{IN}, output error over {SAMPLES} post-ReLU inputs\n")

    e_pt, e_pc = rel_err(W, quant_per_tensor(W), xs), rel_err(W, quant_per_channel(W), xs)
    e_pt4, e_pc4 = rel_err(W, quant_per_tensor(W, 4), xs), rel_err(W, quant_per_channel(W, 4), xs)
    W_out = [row[:] for row in W]
    W_out[5][7] = 5.0                                     # one outlier weight (~6x the largest normal one)
    e_pt_out = rel_err(W_out, quant_per_tensor(W_out), xs)
    e_pc_out = rel_err(W_out, quant_per_channel(W_out), xs)

    print("  weight quantization                     output error")
    print(f"  INT8 per-tensor                         {e_pt:8.3%}")
    print(f"  INT8 per-channel                        {e_pc:8.3%}")
    print(f"  INT4 per-tensor                         {e_pt4:8.3%}")
    print(f"  INT4 per-channel                        {e_pc4:8.3%}")
    print(f"  INT8 per-tensor, one outlier weight     {e_pt_out:8.3%}")
    print(f"  INT8 per-channel, one outlier weight    {e_pc_out:8.3%}")

    a_sym = sum(sum((p - q) ** 2 for p, q in zip(x, quant_act_sym(x))) for x in xs)
    a_asym = sum(sum((p - q) ** 2 for p, q in zip(x, quant_act_asym(x))) for x in xs)
    print(f"\n  activation INT8 MSE (post-ReLU, values >= 0): symmetric {a_sym / SAMPLES / IN:.2e}, "
          f"asymmetric {a_asym / SAMPLES / IN:.2e}")

    print("\n  pruning                                 output error")
    pr = {}
    for s in (0.5, 0.8, 0.9):
        pr[s] = rel_err(W, prune_unstructured(W, s), xs)
        print(f"  unstructured magnitude {int(s * 100)}%              {pr[s]:8.3%}")
    st50 = rel_err(W, prune_structured(W, 0.5), xs)
    print(f"  structured: drop 50% of output channels {st50:8.3%}")

    fp32 = OUT * IN * 4
    print(f"\n  size: FP32 {fp32:,} B, FP16 {fp32 // 2:,} B, INT8 {fp32 // 4:,} B (+{OUT * 4} B scales), "
          f"INT4 {fp32 // 8:,} B")

    print("\nChecks")
    check("per-channel INT8 is at least 2x more accurate than per-tensor (channel ranges differ)",
          e_pc * 2 < e_pt, f"{e_pt:.3%} vs {e_pc:.3%}")
    check("INT8 per-channel output error stays under 1%", e_pc < 0.01)
    check("one outlier makes per-tensor INT8 several times worse; per-channel confines it to one channel",
          e_pt_out > 3 * e_pt and e_pc_out * 3 < e_pt_out,
          f"per-tensor {e_pt:.2%} -> {e_pt_out:.2%}, per-channel {e_pc:.2%} -> {e_pc_out:.2%}")
    check("INT4 needs per-channel (or finer) scales: per-tensor INT4 error is far higher",
          e_pt4 > 2 * e_pc4, f"{e_pt4:.2%} vs {e_pc4:.2%}")
    check("asymmetric INT8 quantizes non-negative activations with lower error than symmetric",
          a_asym < a_sym)
    check("pruning error grows with sparsity (50% < 80% < 90%)", pr[0.5] < pr[0.8] < pr[0.9])
    check("structured 50% pruning costs more accuracy than unstructured 50% (before fine-tuning)",
          st50 > 1.5 * pr[0.5], f"{st50:.1%} vs {pr[0.5]:.1%}")

    passed = sum(results)
    print(f"\n{passed}/{len(results)} checks passed")
    return 0 if passed == len(results) else 1


def main():
    argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter).parse_args()
    return demo()


if __name__ == "__main__":
    sys.exit(main())
