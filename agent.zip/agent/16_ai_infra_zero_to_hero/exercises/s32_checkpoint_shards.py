#!/usr/bin/env python3
"""Plan distributed checkpoint shards for a large training run.

Given a model size, a parallel layout (TP x PP x DP), the optimizer, and storage, compute:
  - what a full training checkpoint contains, and its total size
  - the shard each rank writes (weights are de-duplicated across data-parallel replicas)
  - the training stall for a synchronous save vs an asynchronous save (copy to host memory, upload in background)
  - the job's mean time between failures (MTBF) from a per-GPU failure rate
  - the best checkpoint interval (Young's formula: sqrt(2 x stall x MTBF)), and the goodput it gives
  - storage needed for a retention policy, and whether the checkpoint can be resharded to a different GPU count

Bytes per parameter in a mixed-precision Adam checkpoint:
  BF16 weights 2 + FP32 master weights 4 + Adam first moment 4 + Adam second moment 4 = 14 bytes.
  Gradients are not saved: they're recomputed in the next step.

Default failure rate: Meta reported 419 unexpected interruptions in 54 days on 16,384 GPUs (Llama 3), which is
about 1.97e-5 failures per GPU-hour.

Usage:
  python3 s32_checkpoint_shards.py                       # 70B on 512 GPUs demo + PASS/FAIL checks
  python3 s32_checkpoint_shards.py --params 405e9 --tp 8 --pp 16 --dp 128 --storage-gbps 1000
"""
import argparse
import math
import sys

BYTES = {"bf16_weights": 2, "fp32_master": 4, "adam_m": 4, "adam_v": 4}
META_FAILS_PER_GPU_HOUR = 419 / (16_384 * 54 * 24)


def plan(params, tp, pp, dp, storage_gbps, d2h_gbps, restart_min, fail_rate, keep_last, keep_every_n_hours,
         run_days):
    gpus = tp * pp * dp
    model_parallel = tp * pp                       # ranks that together hold one copy of the model
    params_per_mp_rank = params / model_parallel
    weights_total = params * BYTES["bf16_weights"]
    optim_total = params * (BYTES["fp32_master"] + BYTES["adam_m"] + BYTES["adam_v"])
    total = weights_total + optim_total

    # Weights are identical across DP replicas, so each replica writes 1/dp of its model-parallel shard.
    # Optimizer state is sharded across DP (ZeRO-1 / distributed optimizer), so every rank writes its own slice.
    weight_shard = params_per_mp_rank * BYTES["bf16_weights"] / dp
    optim_shard = params_per_mp_rank * (BYTES["fp32_master"] + BYTES["adam_m"] + BYTES["adam_v"]) / dp
    per_rank = weight_shard + optim_shard

    sync_stall_s = total / (storage_gbps * 1e9)
    async_stall_s = per_rank / (d2h_gbps * 1e9)    # only the GPU-to-host copy blocks training
    upload_s = sync_stall_s                        # background upload still needs the storage bandwidth

    mtbf_h = 1 / (fail_rate * gpus)
    mtbf_s = mtbf_h * 3600
    restart_s = restart_min * 60

    def young(stall):
        return math.sqrt(2 * stall * mtbf_s)

    def goodput(interval, stall):
        lost_per_failure = interval / 2 + restart_s
        return max(0.0, 1 - stall / interval - lost_per_failure / mtbf_s)

    sync_int = young(sync_stall_s)
    async_int = max(young(async_stall_s), upload_s * 1.5)   # can't start a new save before the last one uploads

    saves_kept = keep_last + math.ceil(run_days * 24 / keep_every_n_hours)
    storage_tb = saves_kept * total / 1e12

    return dict(gpus=gpus, total=total, weights_total=weights_total, optim_total=optim_total,
                weight_shard=weight_shard, optim_shard=optim_shard, per_rank=per_rank,
                sync_stall_s=sync_stall_s, async_stall_s=async_stall_s, upload_s=upload_s,
                mtbf_h=mtbf_h, sync_int=sync_int, async_int=async_int,
                sync_goodput=goodput(sync_int, sync_stall_s), async_goodput=goodput(async_int, async_stall_s),
                naive_goodput=goodput(4 * 3600, sync_stall_s),
                saves_kept=saves_kept, storage_tb=storage_tb)


def reshard_ok(params, old, new):
    """A checkpoint saved with layout old=(tp,pp,dp) can load into new=(tp,pp,dp) if it's saved in a
    layout-independent format (PyTorch DCP / Megatron dist-ckpt): tensors are stored with their global
    shape and offsets, so loaders read the slices they need. Check the slices tile the same global bytes."""
    tp0, pp0, dp0 = old
    tp1, pp1, dp1 = new
    bytes_old = params / (tp0 * pp0) * 14 / dp0 * tp0 * pp0 * dp0
    bytes_new = params / (tp1 * pp1) * 14 / dp1 * tp1 * pp1 * dp1
    return abs(bytes_old - bytes_new) < 1, tp1 * pp1 * dp1


def gb(x):
    return f"{x / 1e9:,.2f} GB"


def report(params, a):
    r = plan(params, a.tp, a.pp, a.dp, a.storage_gbps, a.d2h_gbps, a.restart_min, a.fail_rate, a.keep_last,
             a.keep_every_n_hours, a.run_days)
    print(f"\n{params / 1e9:.0f}B params on {r['gpus']} GPUs (TP {a.tp} x PP {a.pp} x DP {a.dp})")
    print(f"  checkpoint total        {gb(r['total'])}  (weights {gb(r['weights_total'])}, optimizer {gb(r['optim_total'])})")
    print(f"  shard per rank          {gb(r['per_rank'])}  (weights {gb(r['weight_shard'])}, optimizer {gb(r['optim_shard'])})")
    print(f"  synchronous save stall  {r['sync_stall_s']:.1f} s at {a.storage_gbps} GB/s aggregate storage")
    print(f"  asynchronous stall      {r['async_stall_s']:.2f} s (GPU-to-host copy at {a.d2h_gbps} GB/s), "
          f"upload {r['upload_s']:.1f} s in background")
    print(f"  job MTBF                {r['mtbf_h']:.1f} h  (failure rate {a.fail_rate:.2e} per GPU-hour)")
    print(f"  best interval, sync     {r['sync_int'] / 60:.1f} min  -> goodput {r['sync_goodput']:.2%}")
    print(f"  best interval, async    {r['async_int'] / 60:.1f} min  -> goodput {r['async_goodput']:.2%}")
    print(f"  naive every 4 h, sync   goodput {r['naive_goodput']:.2%}")
    print(f"  retention               {r['saves_kept']} checkpoints kept -> {r['storage_tb']:.1f} TB")
    return r


def demo(a):
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"  {'PASS' if cond else 'FAIL'}  {name}")

    r = report(70e9, a)
    ok_reshard, new_gpus = reshard_ok(70e9, (a.tp, a.pp, a.dp), (8, 4, 12))
    print(f"  reshard to TP 8 x PP 4 x DP 12 ({new_gpus} GPUs) after losing nodes: "
          f"{'possible with a layout-independent format' if ok_reshard else 'NOT possible'}")

    print("\nChecks:")
    check("checkpoint is 14 bytes/param: 70B -> 980 GB", round(r["total"] / 1e9) == 980)
    check("rank shards add up to the whole checkpoint", abs(r["per_rank"] * r["gpus"] - r["total"]) < 1e3)
    check(f"each of 512 ranks writes under 2 GB ({gb(r['per_rank'])})", r["per_rank"] < 2e9)
    check(f"async stall is under 1 s ({r['async_stall_s']:.2f} s) vs sync {r['sync_stall_s']:.1f} s",
          r["async_stall_s"] < 1 < r["sync_stall_s"])
    check(f"512-GPU job fails about every 4 days (MTBF {r['mtbf_h']:.0f} h)", 80 < r["mtbf_h"] < 120)
    check("async allows checkpointing more often than sync", r["async_int"] < r["sync_int"])
    check(f"async goodput beats sync ({r['async_goodput']:.2%} vs {r['sync_goodput']:.2%})",
          r["async_goodput"] > r["sync_goodput"])
    check(f"tuned interval beats naive 4-hour saves ({r['sync_goodput']:.2%} vs {r['naive_goodput']:.2%})",
          r["sync_goodput"] > r["naive_goodput"])
    big = plan(70e9, a.tp, a.pp, 2048 // 32, a.storage_gbps, a.d2h_gbps, a.restart_min, a.fail_rate,
               a.keep_last, a.keep_every_n_hours, a.run_days)
    check(f"at 2,048 GPUs MTBF drops 4x to {big['mtbf_h']:.0f} h, so the best interval shrinks",
          big["sync_int"] < r["sync_int"])
    check("same checkpoint reloads at 384 GPUs (resharding)", ok_reshard and new_gpus == 384)
    return 0 if ok else 1


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--params", type=float)
    p.add_argument("--tp", type=int, default=8)
    p.add_argument("--pp", type=int, default=4)
    p.add_argument("--dp", type=int, default=16)
    p.add_argument("--storage-gbps", type=float, default=100, help="aggregate write bandwidth, GB/s")
    p.add_argument("--d2h-gbps", type=float, default=20, help="per-GPU device-to-host copy speed, GB/s")
    p.add_argument("--restart-min", type=float, default=10, help="detect + reschedule + reload time, minutes")
    p.add_argument("--fail-rate", type=float, default=META_FAILS_PER_GPU_HOUR, help="failures per GPU-hour")
    p.add_argument("--keep-last", type=int, default=3)
    p.add_argument("--keep-every-n-hours", type=float, default=24)
    p.add_argument("--run-days", type=float, default=30)
    a = p.parse_args()
    if a.params is None:
        return demo(a)
    report(a.params, a)
    return 0


if __name__ == "__main__":
    sys.exit(main())
