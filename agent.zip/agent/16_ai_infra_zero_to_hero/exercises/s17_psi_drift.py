#!/usr/bin/env python3
"""Section 17 assessment: detect population drift with PSI.

Population Stability Index between a reference sample (training or last month) and a current sample:

    PSI = sum over bins of (cur% - ref%) * ln(cur% / ref%)

  - numeric features: 10 quantile bins taken from the reference, plus a separate bin for missing values
  - categorical features: one bin per category, plus "other" for categories unseen in the reference
  - empty bins are floored at 1e-4 to avoid log(0)
  - rule of thumb: < 0.10 stable, 0.10-0.25 moderate (investigate), > 0.25 major (act)

PSI also rises from sampling noise alone when samples are small. noise_floor() bootstraps the
reference to estimate the 99th-percentile PSI under "no drift" for a given sample size, so alerts fire only
above max(0.10, noise floor).

Usage:
  python3 s17_psi_drift.py                                  # scenario with 5 features + checks
  python3 s17_psi_drift.py --ref ref.csv --cur cur.csv      # PSI per column of two CSV files
"""
import argparse
import csv
import math
import random
import sys

EPS = 1e-4


def is_missing(v):
    return v is None or v == "" or (isinstance(v, float) and math.isnan(v))


def quantile_edges(values, bins=10):
    xs = sorted(v for v in values if not is_missing(v))
    edges = []
    for i in range(1, bins):
        e = xs[min(len(xs) - 1, int(len(xs) * i / bins))]
        if not edges or e > edges[-1]:
            edges.append(e)
    return edges


def bin_numeric(values, edges):
    counts = [0] * (len(edges) + 2)          # last bin = missing
    for v in values:
        if is_missing(v):
            counts[-1] += 1
            continue
        lo, hi = 0, len(edges)
        while lo < hi:
            mid = (lo + hi) // 2
            if v < edges[mid]:
                hi = mid
            else:
                lo = mid + 1
        counts[lo] += 1
    return counts


def bin_categorical(values, categories):
    idx = {c: i for i, c in enumerate(categories)}
    counts = [0] * (len(categories) + 1)     # last bin = other / unseen
    for v in values:
        counts[idx.get(v, len(categories))] += 1
    return counts


def psi_from_counts(ref_counts, cur_counts):
    rn, cn = sum(ref_counts), sum(cur_counts)
    total, contrib = 0.0, []
    for r, c in zip(ref_counts, cur_counts):
        e, a = max(r / rn, EPS), max(c / cn, EPS)
        term = (a - e) * math.log(a / e)
        contrib.append(term)
        total += term
    return total, contrib


def psi(ref, cur, kind="numeric", bins=10):
    if kind == "numeric":
        edges = quantile_edges(ref, bins)
        return psi_from_counts(bin_numeric(ref, edges), bin_numeric(cur, edges))
    cats = sorted({v for v in ref})
    return psi_from_counts(bin_categorical(ref, cats), bin_categorical(cur, cats))


def noise_floor(ref, n_cur, kind="numeric", trials=200, q=0.99, seed=7):
    """99th-percentile PSI between the reference and same-distribution samples of size n_cur."""
    rnd = random.Random(seed)
    vals = sorted(psi(ref, [rnd.choice(ref) for _ in range(n_cur)], kind)[0] for _ in range(trials))
    return vals[int(q * (trials - 1))]


def verdict(p, floor=0.0):
    threshold = max(0.10, floor)
    if p < threshold:
        return "stable"
    return "moderate" if p < max(0.25, threshold) else "MAJOR"


def make_scenario(seed=42, n_ref=20000, n_cur=20000):
    rnd = random.Random(seed)
    ref, cur = {}, {}
    ref["age"] = [rnd.gauss(41, 12) for _ in range(n_ref)]
    cur["age"] = [rnd.gauss(41, 12) for _ in range(n_cur)]
    ref["income"] = [rnd.lognormvariate(10.8, 0.5) for _ in range(n_ref)]
    cur["income"] = [rnd.lognormvariate(10.8, 0.5) * 1.22 for _ in range(n_cur)]           # wage growth + new segment
    ref["device"] = rnd.choices(["mobile", "desktop", "tablet"], [55, 38, 7], k=n_ref)
    cur["device"] = rnd.choices(["mobile", "desktop", "tablet", "smart_tv"], [78, 17, 3, 2], k=n_cur)
    ref["txn_amount"] = [None if rnd.random() < 0.02 else rnd.expovariate(1 / 60) for _ in range(n_ref)]
    cur["txn_amount"] = [None if rnd.random() < 0.31 else rnd.expovariate(1 / 60) for _ in range(n_cur)]  # pipeline bug
    ref["score"] = [rnd.betavariate(2, 8) for _ in range(n_ref)]
    cur["score"] = [rnd.betavariate(2.6, 7.4) for _ in range(n_cur)]                          # model output drift
    kinds = {"age": "numeric", "income": "numeric", "device": "categorical",
             "txn_amount": "numeric", "score": "numeric"}
    return ref, cur, kinds


def report(ref, cur, kinds, floors=None):
    print(f"  {'feature':<12} {'kind':<12} {'PSI':>7}  {'verdict':<9} top contributing bin")
    rows = {}
    for f, kind in kinds.items():
        p, contrib = psi(ref[f], cur[f], kind)
        fl = (floors or {}).get(f, 0.0)
        v = verdict(p, fl)
        i = max(range(len(contrib)), key=lambda k: contrib[k])
        if kind == "categorical":
            cats = sorted(set(ref[f]))
            label = cats[i] if i < len(cats) else "other (unseen categories)"
        else:
            label = "missing values" if i == len(contrib) - 1 else f"bin {i + 1} of {len(contrib) - 1}"
        rows[f] = (p, v)
        print(f"  {f:<12} {kind:<12} {p:7.3f}  {v:<9} {label} ({contrib[i]:.3f})")
    return rows


def demo():
    results = []

    def check(name, ok, info=""):
        results.append(ok)
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}{'  ' + info if info else ''}")

    ref, cur, kinds = make_scenario()
    print("PSI report: reference = training window (20,000 rows), current = last 7 days (20,000 rows)")
    rows = report(ref, cur, kinds)

    print("\nChecks")
    check("age (same distribution) is stable", rows["age"][1] == "stable", f"PSI={rows['age'][0]:.3f}")
    check("income (22% upward shift) is moderate: investigate, maybe retrain",
          rows["income"][1] == "moderate", f"PSI={rows['income'][0]:.3f}")
    check("device mix shift with a new category (smart_tv) is MAJOR", rows["device"][1] == "MAJOR",
          f"PSI={rows['device'][0]:.3f}")
    check("txn_amount missing rate 2% -> 31% (pipeline bug) is MAJOR, driven by the missing bin",
          rows["txn_amount"][1] == "MAJOR", f"PSI={rows['txn_amount'][0]:.3f}")
    check("prediction score drift is detected (moderate or worse)", rows["score"][1] != "stable",
          f"PSI={rows['score'][0]:.3f}")

    sym = psi(ref["income"], cur["income"])[0]
    rev = psi(cur["income"], ref["income"])[0]
    check("PSI is roughly symmetric (sum of both KL directions)", abs(sym - rev) / sym < 0.25,
          f"ref->cur {sym:.3f} vs cur->ref {rev:.3f}")

    print("\nSample size matters: same distribution, small current window")
    rnd = random.Random(3)
    small = [rnd.gauss(41, 12) for _ in range(150)]
    p_small = psi(ref["age"], small)[0]
    floor_150 = noise_floor(ref["age"], 150)
    floor_20k = noise_floor(ref["age"], 20000, trials=40)
    print(f"  age PSI with n=150: {p_small:.3f}   noise floor (p99) n=150: {floor_150:.3f}   n=20,000: {floor_20k:.4f}")
    check("the noise floor for n=150 is far above n=20,000, so small windows need a higher threshold",
          floor_150 > 5 * floor_20k)
    check("with the noise floor applied, the small same-distribution window is not flagged",
          verdict(p_small, floor_150) == "stable", f"threshold={max(0.10, floor_150):.3f}")

    passed = sum(results)
    print(f"\n{passed}/{len(results)} checks passed")
    return 0 if passed == len(results) else 1


def load_csv(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    cols = {}
    for k in rows[0]:
        raw = [r[k] for r in rows]
        try:
            cols[k] = ([float(v) if v != "" else None for v in raw], "numeric")
        except ValueError:
            cols[k] = (raw, "categorical")
    return cols


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ref", help="reference CSV")
    ap.add_argument("--cur", help="current CSV")
    a = ap.parse_args()
    if a.ref and a.cur:
        r, c = load_csv(a.ref), load_csv(a.cur)
        common = [k for k in r if k in c]
        report({k: r[k][0] for k in common}, {k: c[k][0] for k in common}, {k: r[k][1] for k in common})
        return 0
    return demo()


if __name__ == "__main__":
    sys.exit(main())
