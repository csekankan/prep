#!/usr/bin/env python3
"""Section 52 support: report benchmark percentiles with confidence intervals.

Two Atlas configurations are compared on TTFT: A (baseline) and B (prefix caching on). Each run has N requests.
Latencies are simulated as log-normal with a fixed seed, which is how real latency distributions usually look
(a long right tail). The bootstrap resamples the measured values with replacement many times and takes the 2.5th and
97.5th percentiles of the statistic as a 95% confidence interval.

Questions this answers:
  - Is B's p95 really lower than A's, or could it be noise?
  - How trustworthy is a p99 from a few hundred requests?

Usage:
  python3 s52_benchmark_ci.py
"""
import math
import random
import sys

N, BOOT, SEED = 300, 2000, 52


def sample(rng, median, sigma, n):
    return [rng.lognormvariate(math.log(median), sigma) for _ in range(n)]


def pct(xs, q):
    s = sorted(xs)
    k = (len(s) - 1) * q
    lo, hi = math.floor(k), math.ceil(k)
    return s[lo] + (s[hi] - s[lo]) * (k - lo)


def bootstrap(rng, xs, q):
    stats = sorted(pct([rng.choice(xs) for _ in xs], q) for _ in range(BOOT))
    return stats[int(0.025 * BOOT)], stats[int(0.975 * BOOT)]


def main():
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"{'PASS' if cond else 'FAIL'}  {name}")

    rng = random.Random(SEED)
    runs = {"A baseline": sample(rng, 0.55, 0.35, N), "B prefix caching": sample(rng, 0.40, 0.35, N)}
    res = {}
    print(f"TTFT, {N} requests per configuration, 95% bootstrap intervals ({BOOT} resamples)\n")
    print(f"{'config':18} {'p50':>22} {'p95':>22} {'p99':>22}")
    for name, xs in runs.items():
        row = {}
        for q in (0.50, 0.95, 0.99):
            lo, hi = bootstrap(rng, xs, q)
            row[q] = (pct(xs, q), lo, hi)
        res[name] = row
        print(f"{name:18} " + " ".join(f"{v:5.2f} s [{lo:4.2f}, {hi:4.2f}]" for v, lo, hi in row.values()))
    a, b = res["A baseline"], res["B prefix caching"]
    gain = 1 - b[0.95][0] / a[0.95][0]
    width99 = (a[0.99][2] - a[0.99][1]) / a[0.99][0]
    width50 = (a[0.50][2] - a[0.50][1]) / a[0.50][0]
    print(f"\np95 improvement from prefix caching: {gain:.0%}")
    print(f"relative width of the 95% interval for A: p50 {width50:.0%}, p99 {width99:.0%}\n")

    check("B's p95 interval lies entirely below A's (the improvement is not noise)", b[0.95][2] < a[0.95][1])
    check("prefix caching improves p95 by 20% to 35%", 0.20 <= gain <= 0.35)
    check("the p99 interval is over twice as wide as the p50 interval (tails need more samples)", width99 > 2 * width50)
    check("the p99 from 300 requests is uncertain by more than 15% of its value", width99 > 0.15)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
