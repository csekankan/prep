#!/usr/bin/env python3
"""Section 51 support: multi-window burn-rate alerts for the Atlas availability SLO.

SLO 99.5% over 30 days -> error budget 0.5% of requests. Burn rate = error ratio / budget ratio; a burn rate of 1 uses
the whole budget in exactly 30 days. Each alert fires when the error ratio averaged over its long window (and its
short window, which makes it reset quickly) exceeds burn x 0.5%.

For an incident that starts at t = 0 with a constant error ratio e, the long-window average after t hours is e x t / W,
so the alert fires at t = threshold x W / e, or never if e is below the threshold.

Usage:
  python3 s51_burn_rate.py
"""
import sys

SLO = 0.995
BUDGET = 1 - SLO
PERIOD_H = 30 * 24
ALERTS = [  # name, long window (h), short window (h), burn rate, severity
    ("fast burn", 1, 5 / 60, 14.4, "page"),
    ("slow burn", 6, 0.5, 6, "page"),
    ("budget leak", 72, 6, 1, "ticket"),
]
INCIDENTS = [  # name, error ratio
    ("full outage", 1.00),
    ("LLM down, no fallback", 0.60),
    ("one bad gateway pod of three", 0.33),
    ("DB failover retries failing", 0.10),
    ("one zone's requests failing", 0.04),
    ("slow leak: 2% errors", 0.02),
    ("background noise: 0.3% errors", 0.003),
]


def detect(e):
    best = None
    for name, w, _, burn, sev in ALERTS:
        thr = burn * BUDGET
        if e >= thr:
            t = thr * w / e
            if best is None or t < best[0]:
                best = (t, name, sev)
    return best


def main():
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"{'PASS' if cond else 'FAIL'}  {name}")

    print(f"SLO {SLO:.1%}: budget {BUDGET:.1%} of requests per 30 days\n")
    print(f"{'alert':12} {'windows':>11} {'burn':>5} {'error ratio threshold':>22} {'budget used when it fires':>26}")
    for name, w, s, burn, sev in ALERTS:
        used = burn * w / PERIOD_H
        print(f"{name:12} {w:>5g}h/{s * 60:>3.0f}m {burn:>5g} {burn * BUDGET:>21.2%} {used:>25.1%}  -> {sev}")
    print()
    res = {}
    for name, e in INCIDENTS:
        d = detect(e)
        res[name] = d
        if d:
            t, alert, sev = d
            used = e * t / (BUDGET * PERIOD_H)
            print(f"{name:30} errors {e:>6.1%}: {alert:11} {sev:6} after {t * 60:>6.1f} min, budget used {used:.1%}")
        else:
            print(f"{name:30} errors {e:>6.1%}: no alert (within budget: uses "
                  f"{e / BUDGET:.0%} of the budget rate)")
    print()

    check("a full outage pages within 5 minutes", res["full outage"][0] * 60 < 5)
    check("a full outage has used only about 2% of the budget when it pages",
          abs(1.0 * res["full outage"][0] / (BUDGET * PERIOD_H) - 0.02) < 0.001)
    check("one bad pod of three pages within 15 minutes", res["one bad gateway pod of three"][0] * 60 < 15)
    check("10% errors page within 1 hour", res["DB failover retries failing"][0] < 1)
    check("4% errors are below the fast-burn threshold and page through the slow-burn alert",
          res["one zone's requests failing"][1] == "slow burn")
    check("a 2% leak raises a ticket, not a page", res["slow leak: 2% errors"][2] == "ticket")
    check("0.3% errors never alert, because they stay within budget", res["background noise: 0.3% errors"] is None)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
