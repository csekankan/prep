#!/usr/bin/env python3
"""Section 48 assessment support: estimate hardware and cloud costs for the Atlas capstone.

Atlas is the reference capstone: a retrieval-augmented support assistant (gateway + retrieval in Postgres/pgvector +
an open LLM served by vLLM) on Kubernetes. This script prices four environments:

  dev         laptop: kind + a CPU model server (llama.cpp)          -> $0, but slow
  demo        one L4 GPU VM, run only during build and demo hours
  scale-test  managed Kubernetes with CPU nodes, a GPU node pool, Postgres, load balancer, NAT, used part-time (§50)
  production  the same design running 24/7, with GPUs sized from peak traffic and at least 2 for availability

GPU count = max(min, ceil(peak output tokens/s / (per-GPU output tokens/s x target utilization))).
Prices are illustrative on-demand list prices (AWS us-east-1-like). Replace them with current quotes.

Usage:
  python3 s48_capstone_cost.py
"""
import math
import sys

HOURS_MONTH = 730
PRICE = {                       # $ per hour
    "gpu_l4": 0.805,            # g6.xlarge: 1 NVIDIA L4 (24 GB), 4 vCPU
    "cpu_node": 0.096,          # m6i.large: 2 vCPU, 8 GB
    "eks": 0.10,                # managed control plane
    "postgres": 0.032,          # small managed Postgres instance
    "alb": 0.0225 + 0.008 * 2,  # load balancer hour + about 2 capacity units
    "nat": 0.045,               # NAT gateway hour (data processing extra)
}
STORAGE_GB_MONTH = 0.023        # object storage
PER_GPU_TOK_S = 1_400           # sustained output tokens/s for a 1.5B-3B model on one L4 with vLLM batching
TARGET_UTIL = 0.6               # headroom for latency
OUT_TOK = 250                   # output tokens per request


def gpus_for(peak_rps, minimum):
    return max(minimum, math.ceil(peak_rps * OUT_TOK / (PER_GPU_TOK_S * TARGET_UTIL)))


def env_cost(hours, gpus, cpu_nodes=0, managed=False, storage_gb=50):
    items = {"GPU nodes": gpus * PRICE["gpu_l4"] * hours}
    if managed:
        items["EKS control plane"] = PRICE["eks"] * HOURS_MONTH
        items["CPU nodes"] = cpu_nodes * PRICE["cpu_node"] * hours
        items["Postgres"] = PRICE["postgres"] * HOURS_MONTH
        items["Load balancer"] = PRICE["alb"] * hours
        items["NAT gateway"] = PRICE["nat"] * HOURS_MONTH
    items["Object storage"] = storage_gb * STORAGE_GB_MONTH
    return items


def main():
    ok = True

    def check(name, cond):
        nonlocal ok
        ok &= bool(cond)
        print(f"{'PASS' if cond else 'FAIL'}  {name}")

    envs = {
        "dev": {"items": {"Laptop": 0.0}, "note": "kind + llama.cpp on CPU"},
        "demo": {"items": env_cost(hours=40, gpus=1), "note": "1 L4 VM, 40 h/month"},
        "scale-test": {"items": env_cost(hours=8 * 20, gpus=gpus_for(10, 2), cpu_nodes=2, managed=True),
                       "note": "EKS, 2 CPU + GPU pool, 8 h x 20 days"},
        "production": {"items": env_cost(hours=HOURS_MONTH, gpus=gpus_for(10, 2), cpu_nodes=3, managed=True,
                                         storage_gb=500), "note": "24/7, 10 req/s peak"},
    }
    totals = {}
    for name, e in envs.items():
        total = sum(e["items"].values())
        totals[name] = total
        print(f"{name:11} ${total:>9,.2f}/month   ({e['note']})")
        for k, v in e["items"].items():
            print(f"    {k:18} ${v:>9,.2f}")
    prod_gpus = gpus_for(10, 2)
    avg_rps = 3.0
    per_1k = totals["production"] / (avg_rps * 3600 * HOURS_MONTH) * 1000
    print(f"\nproduction GPUs for 10 req/s peak: {prod_gpus} "
          f"(peak {10 * OUT_TOK:,} output tokens/s vs {PER_GPU_TOK_S * TARGET_UTIL:,.0f} usable per GPU)")
    print(f"production cost per 1,000 requests at {avg_rps} req/s average: ${per_1k:.3f}")
    nat_share = envs["scale-test"]["items"]["NAT gateway"] / totals["scale-test"]
    fixed = sum(v for k, v in envs["scale-test"]["items"].items() if k in ("EKS control plane", "Postgres", "NAT gateway"))
    print(f"scale-test: always-on items (control plane, Postgres, NAT) are ${fixed:,.2f} "
          f"= {fixed / totals['scale-test']:.0%} of the bill even though nodes run only 160 h\n")

    check("demo costs under $40 a month when the GPU runs only 40 hours", totals["demo"] < 40)
    check("production needs 3 L4 GPUs for 10 req/s peak (2,500 tok/s / 840 usable per GPU)", prod_gpus == 3)
    check("scale-test stays under $600 a month", totals["scale-test"] < 600)
    check("always-on items are over 20% of the part-time scale-test bill", fixed / totals["scale-test"] > 0.20)
    check("NAT gateway alone is over 5% of the scale-test bill", nat_share > 0.05)
    check("production cost per 1,000 requests is under $0.50", per_1k < 0.50)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
