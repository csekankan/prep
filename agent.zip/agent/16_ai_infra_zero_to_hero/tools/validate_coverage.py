"""Strictly validate that the course covers every lecture, quiz, and assessment in the syllabus.

Source of truth: tools/syllabus.txt (365 lectures in 52 sections). For every section it checks:
  - the section file exists (part*/sNN_*.md)
  - every lecture has a "## Lecture N — <title>" heading whose title matches the syllabus
  - every non-lab lecture contains: "In plain words", a Mermaid diagram, an "**Example" and a senior/FAANG note
  - every lab lecture contains a "**Goal" and "Expected" results
  - every syllabus assessment has a matching "## Assessment — ..." or "## Practice test — ..." heading
  - sections with a syllabus quiz have "## Quiz" with at least 5 questions
  - section-level blocks: Section at a glance, FAANG deep-dive notes, Failure modes, Checklist
  - linked exercise files exist and compile (with --run they are also executed)
  - Mermaid blocks are closed and have no labels starting with "1. " (renders as "Unsupported markdown")

Usage:
  python3 tools/validate_coverage.py              # summary table + all errors, exit 1 if anything fails
  python3 tools/validate_coverage.py --section 6  # one section
  python3 tools/validate_coverage.py --run        # also execute every linked exercise
"""

import argparse
import py_compile
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STOP = {"a", "an", "and", "the", "for", "of", "in", "on", "to", "with", "vs", "ai", "is", "what", "how", "your"}
SECTION_BLOCKS = ["## Section at a glance", "## FAANG deep-dive notes", "## Failure modes", "## Checklist"]
LECTURE_BLOCKS = {
    r"In plain words": "In plain words",
    r"```mermaid": "diagram",
    r"\*\*(Worked )?[Ee]xample": "example",
    r"\*\*Senior": "senior/FAANG note",
}
LAB_BLOCKS = {r"\*\*Goal": "goal", r"\*\*Expected|[Ee]xpected (results|output)": "expected results"}


def tokens(s):
    return {t for t in re.findall(r"[a-z0-9]+", s.lower().replace("&", " and ")) if t not in STOP}


def similar(a, b):
    ta, tb = tokens(a), tokens(b)
    return len(ta & tb) / max(1, len(ta)) if ta else 0.0


def load_syllabus():
    sections, cur = {}, None
    for line in (ROOT / "tools" / "syllabus.txt").read_text().splitlines():
        if line.startswith("## Section"):
            cur = int(line.split()[-1])
            sections[cur] = {"lectures": [], "assessments": [], "quiz": None}
        elif line.startswith("L") and "|" in line:
            n, title = line.split("|", 1)
            sections[cur]["lectures"].append((int(n.strip()[1:]), title.strip()))
        elif line.startswith("A ") and cur:
            sections[cur]["assessments"].append(line.split("|", 1)[1].strip())
        elif line.startswith("Q ") and cur:
            sections[cur]["quiz"] = line.split("|", 1)[1].strip()
    return sections


def split_blocks(text):
    parts = re.split(r"(?m)^(## .+)$", text)
    return {parts[i].strip(): parts[i + 1] for i in range(1, len(parts) - 1, 2)}


def check_mermaid(text):
    problems, inside = [], False
    for i, line in enumerate(text.splitlines(), 1):
        if line.startswith("```mermaid"):
            inside = True
        elif line.startswith("```") and inside:
            inside = False
        elif inside and re.search(r'[\[{(|"]"?\d+\. ', line):
            problems.append(f"line {i}: Mermaid label starts with 'N. ' (use '(N) ')")
    if text.count("```") % 2:
        problems.append("unbalanced ``` code fences")
    return problems


def check_links(path, text):
    errors = []
    prose = re.sub(r"```.*?```", "", text, flags=re.S)
    for rel in sorted(set(re.findall(r"\]\(((?:\.\./|\./)?[\w./-]+?)(?:#[^)]*)?\)", prose))):
        if rel.startswith(("http", "mailto")) or "://" in rel:
            continue
        if not (path.parent / rel).exists():
            errors.append(f"broken link: {rel}")
    return errors


def check_exercises(path, text, run):
    errors = []
    for rel in sorted(set(re.findall(r"\]\((\.\./exercises/[^)#]+)\)", text))):
        f = (path.parent / rel).resolve()
        if not f.exists():
            errors.append(f"exercise missing: {rel}")
            continue
        try:
            if f.suffix == ".py":
                py_compile.compile(str(f), doraise=True)
                cmd = [sys.executable, str(f)]
            elif f.suffix == ".sh":
                subprocess.run(["bash", "-n", str(f)], check=True, capture_output=True)
                cmd = ["bash", str(f)]
            else:
                continue
        except (py_compile.PyCompileError, subprocess.CalledProcessError) as e:
            errors.append(f"exercise does not compile: {rel}: {e}")
            continue
        if run:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            if r.returncode not in (0, 1, 2) or "Traceback" in r.stderr:
                errors.append(f"exercise failed to run: {rel}: {r.stderr.strip()[-300:]}")
    return errors


def validate_section(num, spec, run):
    files = sorted(ROOT.glob(f"part*/s{num:02d}_*.md"))
    if not files:
        return {"file": None, "lectures": 0, "errors": ["section file missing"], "warnings": []}
    path = files[0]
    text = path.read_text()
    blocks = split_blocks(text)
    errors, warnings = [], []

    for b in SECTION_BLOCKS:
        if not any(h.startswith(b) for h in blocks):
            errors.append(f"missing block '{b}'")

    covered = 0
    for n, title in spec["lectures"]:
        head = next((h for h in blocks if re.match(rf"## Lecture {n} — ", h)), None)
        if not head:
            errors.append(f"lecture {n} missing: {title}")
            continue
        covered += 1
        if similar(title, head) < 0.5:
            warnings.append(f"lecture {n} title drift: '{head[3:]}' vs syllabus '{title}'")
        body = blocks[head]
        required = LAB_BLOCKS if title.lower().startswith("lab") else LECTURE_BLOCKS
        missing = [name for key, name in required.items() if not re.search(key, body)]
        if missing:
            errors.append(f"lecture {n} lacks: {', '.join(missing)}")

    assess_heads = [h for h in blocks if h.startswith(("## Assessment", "## Practice test"))]
    for a in spec["assessments"]:
        if not any(similar(a, h) >= 0.5 for h in assess_heads):
            errors.append(f"assessment missing: {a}")

    if spec["quiz"]:
        quiz = next((blocks[h] for h in blocks if h.startswith("## Quiz")), None)
        if quiz is None:
            errors.append(f"quiz missing: {spec['quiz']}")
        elif quiz.count("<details>") < 5:
            errors.append(f"quiz has only {quiz.count('<details>')} questions (need 5+)")

    errors += check_mermaid(text)
    errors += check_links(path, text)
    errors += check_exercises(path, text, run)
    return {"file": path.relative_to(ROOT), "lectures": covered, "errors": errors, "warnings": warnings}


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--section", type=int, action="append", help="validate only these sections")
    p.add_argument("--run", action="store_true", help="execute linked exercises")
    args = p.parse_args()

    syllabus = load_syllabus()
    nums = args.section or sorted(syllabus)
    total_l = total_ok = 0
    failed = []
    print(f"{'§':>3}  {'lectures':>9}  {'status':<6}  file")
    for num in nums:
        spec = syllabus[num]
        r = validate_section(num, spec, args.run)
        total_l += len(spec["lectures"])
        total_ok += r["lectures"]
        status = "OK" if not r["errors"] else "FAIL"
        print(f"{num:>3}  {r['lectures']:>4}/{len(spec['lectures']):<4}  {status:<6}  {r['file'] or '-'}")
        if r["errors"] or r["warnings"]:
            failed.append((num, r))

    for num, r in failed:
        print(f"\n§{num}:")
        for e in r["errors"]:
            print(f"  ERROR   {e}")
        for w in r["warnings"]:
            print(f"  warning {w}")

    n_fail = sum(1 for _, r in failed if r["errors"])
    print(f"\nLectures covered: {total_ok}/{total_l}. Sections passing: {len(nums) - n_fail}/{len(nums)}.")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
