"""Find words used in Mermaid diagram labels that the surrounding prose never explains.

For every section file, each word in a diagram label is looked up in the file's prose (everything outside
code fences). A word is reported as:
  missing  - it never appears in the prose of the file at all
  later    - the prose only mentions it in a later "## " block than the diagram (the reader meets it unexplained)
Diagrams in "## Section at a glance" preview the whole section, so they're only checked for "missing".

Usage:
  python3 tools/check_diagram_terms.py                 # summary per section
  python3 tools/check_diagram_terms.py --section 10 -v # list every flagged word with its diagram block
  python3 tools/check_diagram_terms.py --strict        # exit 1 if anything is flagged
"""

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STOP = set("""
a an and are as at be by can do does for from has have if in into is it its no not of on or per same so than that
the then to up via vs was we what when where which while who why will with yes all any each every more most less
new old one two three four five six seven ten only also back down out off over under after before again first last
next done stop start end ok fail fails pass passes true false none some many few use uses used using run runs
get gets set sets add adds make makes keep keeps send sends read reads write writes call calls step steps
""".split())
JARGON = set("""
shadow mirror mirroring canary champion challenger golden slice slices mesh sidecar spot preemptible preempt drain
taint toleration affinity quorum shard sharded replica rollout rollback cohort gang watermark lateness backpressure
eviction evict ingress egress gateway warm cold bake gate lineage registry artifact manifest digest provenance
attestation drift embedding chunk prefill decode headless keyless sealed signed lease leader follower consolidation
straggler bubble overlap fused kernel pinned paged speculative draft distill distillation prune pruning quantize
cohort holdout bandit ledger tombstone compaction upsert idempotent dedupe backfill pod pods namespace
""".split())
DICT = Path("/usr/share/dict/words")
COMMON = {w.strip() for w in DICT.read_text().splitlines() if w[:1].islower()} if DICT.exists() else set()
BASIC = set("CPU GPU GPUs RAM API APIs HTTP HTTPS URL SSD HDD JSON YAML CSV SQL OS VM VMs AI ML LLM UI "
            "KB MB GB TB PB Gi Mi Ti ms NVIDIA AWS GPS USB HTML DB".split())
FLOW_RES = [
    re.compile(r'"([^"]+)"'),
    re.compile(r"\|([^|\"]+)\|"),
    re.compile(r"\[([^\]\"]+)\]"),
    re.compile(r"\{([^}\"]+)\}"),
    re.compile(r"-\.([^.]+)\.-"),
]
SEQ_RES = [
    re.compile(r"^\s*(?:participant|actor)\s+\S+\s+as\s+(.+)$"),
    re.compile(r"^\s*\w+\s*-[->x)]+[+-]?\s*\w+\s*:\s*(.+)$"),
    re.compile(r"^\s*(?:Note\s+\w+(?:\s+of)?\s+[^:]+|loop|alt|else|opt)\s*:?\s*(.+)$"),
]


def stem(w):
    for suf in ("ing", "ies", "es", "ed", "s"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            return w[: -len(suf)]
    return w


def is_common(lw):
    cands = {lw, stem(lw), lw[:-1], lw[:-2], lw[:-3], lw[:-3] + "e", lw[:-3] + "y", lw[:-2] + "e"}
    if lw.endswith(("ed", "ing")) and len(lw) > 5:
        base = lw[:-2] if lw.endswith("ed") else lw[:-3]
        if len(base) > 2 and base[-1] == base[-2]:
            cands.add(base[:-1])  # skipped -> skip
    return any(c in COMMON for c in cands if len(c) > 2)


def label_words(line, seq=False):
    texts = []
    for rx in SEQ_RES if seq else FLOW_RES:
        texts += rx.findall(line)
    words = set()
    for t in texts:
        t = re.sub(r"<br\s*/?>", " ", t)
        for w in re.findall(r"(?<![A-Za-z0-9._/-])[A-Za-z][A-Za-z0-9+-]*[A-Za-z0-9](?![A-Za-z0-9]*[./_])", t):
            lw = w.lower()
            if lw in STOP or (len(lw) < 4 and not w.isupper()) or re.search(r"\d", lw):
                continue
            if "-" in lw and w == lw:
                continue  # lowercase-hyphenated names are identifiers (fraud-api, train-and-gate)
            if w in BASIC:
                continue
            if "-" in w and all(p.lower() not in JARGON and is_common(p.lower()) for p in w.split("-")):
                continue  # Per-team, Per-model: every part is plain English
            if lw not in JARGON and (not w.isupper() or len(w) > 4) and is_common(lw):
                continue  # everyday English (proper nouns like Prometheus are capitalized in the dictionary)
            words.add(w)
    return words


def analyze(path):
    text = path.read_text()
    parts = re.split(r"(?m)^(## .+)$", text)
    blocks = [("(header)", parts[0])] + [(parts[i].strip(), parts[i + 1]) for i in range(1, len(parts) - 1, 2)]
    prose, diagrams, offset = [], [], len(parts[0])
    for idx, (title, body) in enumerate(blocks):
        chunks = re.split(r"(?ms)^```.*?^```", body)
        prose.append((title + "\n" + "\n".join(chunks)).lower())
        start = 0 if idx == 0 else text.find(title, offset - 1) + len(title)
        for m in re.finditer(r"(?ms)^```mermaid\n(.*?)^```", body):
            words, seq = set(), m.group(1).lstrip().startswith("sequenceDiagram")
            for line in m.group(1).splitlines()[1:]:
                words |= label_words(line, seq)
            line_no = text.count("\n", 0, start + m.end()) + 1
            diagrams.append((idx, title, words, line_no))
        offset = start + len(body)
    flagged = []
    for idx, title, words, line_no in diagrams:
        for w in sorted(words, key=str.lower):
            rx = re.compile(r"(?<![a-z0-9])" + re.escape(stem(w.lower())))
            hits = [i for i, p in enumerate(prose) if rx.search(p)]
            if not hits:
                flagged.append(("missing", f"{title} (diagram ends line {line_no})", w))
            elif title != "## Section at a glance" and min(hits) > idx:
                flagged.append(("later", f"{title} (diagram ends line {line_no})", w))
    return flagged


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--section", type=int, action="append")
    ap.add_argument("-v", "--verbose", action="store_true")
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args()
    total = 0
    for path in sorted(ROOT.glob("part*/s[0-9][0-9]_*.md")):
        n = int(path.name[1:3])
        if a.section and n not in a.section:
            continue
        flagged = analyze(path)
        total += len(flagged)
        miss = sum(f[0] == "missing" for f in flagged)
        print(f"s{n:02d} {path.name:45s} missing={miss:3d} later={len(flagged) - miss:3d}")
        if a.verbose:
            for kind, title, w in flagged:
                print(f"    {kind:7s} {w:28s} in {title[:95]}")
    print(f"total flagged: {total}")
    return 1 if (a.strict and total) else 0


if __name__ == "__main__":
    sys.exit(main())
