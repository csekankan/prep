# Atlas: capstone proposal

## Problem and users
Support engineers and customers of a software company search hundreds of help articles. Atlas answers questions
in chat with links to the articles used, so users find answers in seconds instead of minutes.

## Success metrics
| Metric | Target |
|---|---|
| Time to first token p95 at 5 req/s | < 1.5 s |
| Full answer p95 at 5 req/s | < 6 s |
| Availability in demo window | >= 99.5% |
| Retrieval recall@5 on 100-question golden set | >= 0.85 |
| Grounded answers | >= 90% |
| Cost per 1,000 requests | < $0.50 |
| Lead time commit to production | < 15 min |
| Rollback | < 5 min |

## Architecture
```mermaid
flowchart LR
  U[User] --> G[Gateway] --> R[Retriever] --> P[(Postgres + pgvector)]
  G --> L[vLLM]
  D[(Docs)] --> I[Ingest job] --> P
```
Environments: dev (kind + llama.cpp), demo (1 L4 VM), scale-test (EKS part-time), production (design only).

## Cost estimate
| Environment | Monthly |
|---|---|
| dev | $0 |
| demo | $33 |
| scale-test | $554 |
| production (24/7, design) | $2,142, or $0.27 per 1,000 requests |

## Tools
vLLM, llama.cpp, Postgres + pgvector, FastAPI, Kubernetes (EKS + kind), Terraform, GitHub Actions, Argo CD,
kube-prometheus-stack, Loki, MLflow, OpenCost. Reasons and alternatives in docs/adr/.

## Risks
| Risk | L | I | Mitigation | Owner |
|---|---|---|---|---|
| GPU quota not granted in time | 3 | 5 | Request in week 1; CPU fallback; second region | Kim |
| Cloud bill overrun | 3 | 4 | Budget alerts; nightly scale-to-zero | Kim |
| Scope creep | 4 | 3 | Freeze scope after week 2 | Kim |
| Secrets leaked | 2 | 5 | Secret scanning; external secrets | Kim |
| Demo-day outage | 2 | 5 | Frozen release; backup video | Kim |

## Milestones
- Week 1 (Section 49): prototype on kind and the demo VM, CI, first dashboard.
- Week 2 (Section 50): scale-test cluster, autoscaling, HA, IAM, drift, load test.
- Week 3 (Section 51): end-to-end tests, failover, alerts, docs, final report.
- Week 4 (Section 52): demo environment, benchmarks, presentation.

## Out of scope
Fine-tuning the LLM, multi-region, user accounts beyond API keys, a production SLA.