# Section 15 — Advanced Model Serving

> Lectures 99–105 • Assessment: quiz
> **After this section you can:** compile models with TensorRT, serve many frameworks from Triton with
> dynamic batching, choose batch or online inference, design caches for inference, pack many models onto
> shared hardware, run statistically sound A/B tests between model endpoints, and deploy a model on Triton.
>
> Go deeper: [13 / Lab 41 — Triton multi-framework](../../13_sovereign_ai_infra_course/04_serving_inference/lab41_triton_multi_framework.md),
> [Lab 43 — TensorRT-LLM engines](../../13_sovereign_ai_infra_course/04_serving_inference/lab43_tensorrt_llm_engines.md),
> [Lab 45 — Multi-LoRA serving](../../13_sovereign_ai_infra_course/04_serving_inference/lab45_multi_lora_serving.md),
> [Lab 46 — Semantic routing](../../13_sovereign_ai_infra_course/04_serving_inference/lab46_semantic_routing.md),
> [Lab 47 — KV cache optimization](../../13_sovereign_ai_infra_course/04_serving_inference/lab47_kv_cache_optimization.md),
> [Lab 60 — Redis for AI](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab60_redis_for_ai.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 99 | NVIDIA TensorRT optimization | Fuse layers, lower precision (FP16/INT8/FP8), and tune kernels per GPU, for 2–6× speedups |
| 100 | Triton Inference Server basics | One server for TensorRT, ONNX, PyTorch, and Python models, with dynamic batching and ensembles |
| 101 | Batch inference vs online inference | Precompute when you can. Serve live only when freshness demands it |
| 102 | Caching for fast inference | Cache results, embeddings, features, and KV prefixes, with correct keys and invalidation |
| 103 | Multi-model serving strategies | Share GPUs across many models: packing, MIG, multi-LoRA, load on demand |
| 104 | A/B testing model endpoints | Sticky assignment, guardrails, enough samples, and business metrics, not just accuracy |
| 105 | Lab: deploy a model on Triton server | ONNX ResNet on Triton, dynamic batching, perf_analyzer, and a model_analyzer sweep |

```mermaid
flowchart LR
  M["Trained model<br/>PyTorch / TF"] --> EXP["Export ONNX"]
  EXP --> TRT["TensorRT engine<br/>fused, FP16/INT8, per GPU"]
  TRT --> TRITON["Triton model repository<br/>config.pbtxt, versions"]
  EXP --> TRITON
  TRITON --> DB["Dynamic batching<br/>+ instance groups"]
  REQ((Requests)) --> ROUTER["Router: cache, A/B split,<br/>model selection"]
  ROUTER -->|"cache hit"| REQ
  ROUTER --> DB
  BATCHJOB["Nightly batch scoring"] --> TRITON
  DB --> GPU["Shared GPUs:<br/>many models, MIG, LoRA"]
```

**How to read it:** models are exported to a portable format (ONNX) and optionally compiled into a
TensorRT engine for the target GPU. Triton serves them from a model repository with dynamic batching. In
front, a router checks caches, assigns A/B variants, and picks the model. Batch jobs reuse the same
server for offline scoring. GPUs are shared across many models to keep utilization high.

**Terms in this diagram.**
- **ONNX** (Open Neural Network Exchange): a   framework-neutral file format for models, so one export from PyTorch or
  TensorFlow (TF) runs on many runtimes (Lecture 99).
- **TensorRT engine, fused, FP16/INT8, per GPU**: TensorRT is NVIDIA's compiler that turns a model into an
  optimized **engine** file. **Fused** means several operations are merged into one GPU kernel. **FP16/INT8** are
  lower-precision number formats that run faster (Section 7). **Per GPU** means the engine only works on the GPU
  type it was built for.
- **Triton model repository, config.pbtxt**: Triton Inference Server loads models from a folder layout, and each
  model's `config.pbtxt` text file declares its inputs, outputs, batching, and instances (Lecture 100).
- **Dynamic batching + instance groups**: the server merges requests that arrive close together into one GPU
  call, and runs several copies (**instances**) of a model at once.
- **Cache hit, A/B split**: a **cache hit** returns a stored answer without running the model (Lecture 102). An
  **A/B split** sends part of the users to a new model for comparison (Lecture 104).
- **MIG, LoRA**: **MIG** splits one GPU into isolated hardware slices (Section 7). **LoRA** adapters are small add-on
  weights that customize one shared base LLM per team (Lecture 103).

---

## Lecture 99 — NVIDIA TensorRT optimization

**Why it matters.** The same model can run 2–6× faster on the same GPU after compilation, which means
2–6× fewer GPUs, or a much better latency. TensorRT is the standard way to get there on NVIDIA hardware.

**In plain words.** A model from PyTorch is like a recipe written step by step for a home cook. TensorRT
is a professional kitchen manager who rewrites it for *this* kitchen: combines steps that can be done
together, uses faster tools where precision doesn't matter, and times every station on this exact oven.

**Architecture: the TensorRT build pipeline.**

```mermaid
flowchart LR
  PT["PyTorch model"] -->|"torch.onnx.export<br/>dynamic axes"| ONNX["model.onnx"]
  ONNX --> PARSE["TensorRT parser"]
  PARSE --> OPT["Graph optimizations:<br/>layer and tensor fusion,<br/>dead-layer removal"]
  OPT --> PREC["Precision: FP16, BF16,<br/>INT8 / FP8 with calibration"]
  PREC --> TACT["Kernel auto-tuning<br/>for this GPU and shapes"]
  TACT --> ENG["model.plan engine<br/>tied to GPU arch + TRT version"]
  CAL[(Calibration data<br/>~500 real samples)] --> PREC
```

**How to read it:** the model is exported to ONNX, parsed, and optimized. Operations are fused
(convolution plus bias plus ReLU become one kernel), precision is lowered where allowed (INT8 and FP8
need calibration data to choose scales), and the fastest kernel is chosen for every layer by timing on
the actual GPU. The output engine is specific to the GPU architecture, the TensorRT version, and the
input shape ranges.

**Terms in this diagram.**
- **torch.onnx.export, dynamic axes**: the PyTorch function that writes an ONNX file. **Dynamic axes** mark
  dimensions, usually the batch size or sequence length, that may vary at run time instead of being fixed.
- **Parser**: the TensorRT component that reads the ONNX graph into its own representation.
- **Layer and tensor fusion, dead-layer removal**: **fusion** merges consecutive operations so data stays in fast
  on-chip memory. **Dead-layer removal** deletes operations whose outputs are never used.
- **FP16, BF16, INT8 / FP8**: 16-bit floats (BF16 keeps FP32's range with less precision), and 8-bit integer and
  float formats. Fewer bits means less memory traffic and faster math, with some accuracy risk (Section 7).
- **Calibration, ~500 real samples**: INT8 and FP8 store values in a small range, so TensorRT runs a few hundred
  representative inputs to measure each tensor's typical range and pick its **scale**.
- **Kernel auto-tuning**: TensorRT times several implementations of every layer on your actual GPU and keeps the
  fastest.
- **model.plan, GPU arch + TRT version**: the serialized engine file. It only loads on the same GPU
  **architecture** (for example Ampere or Hopper) and TensorRT version it was built with, so rebuild it on upgrades.

**Core ideas.**

```bash
python -c "import torch, torchvision; m=torchvision.models.resnet50(weights='DEFAULT').eval(); \
torch.onnx.export(m, torch.randn(1,3,224,224), 'resnet50.onnx', input_names=['input'], output_names=['logits'], \
dynamic_axes={'input':{0:'batch'}, 'logits':{0:'batch'}}, opset_version=17)"
trtexec --onnx=resnet50.onnx --saveEngine=resnet50_fp16.plan --fp16 \
  --minShapes=input:1x3x224x224 --optShapes=input:16x3x224x224 --maxShapes=input:64x3x224x224
trtexec --loadEngine=resnet50_fp16.plan --shapes=input:16x3x224x224     # reports throughput and latency
```

| Precision | Typical speedup vs FP32 | Accuracy risk | Needs |
|---|---|---|---|
| FP16 / BF16 | 2–3× | Very low | Nothing extra |
| INT8 | 3–5× | Low to moderate | Calibration data or quantization-aware training |
| FP8 (Hopper and newer) | ~2× over FP16 | Low with good scaling | H100/H200/B200, calibration |

- **Engines aren't portable:** build per GPU type (T4, L4, A100, H100) and TensorRT version, usually in CI,
  and store them alongside the model version.
- **Validate accuracy** after every build. Compare outputs on a golden set (top-1 agreement, maximum
  absolute difference) before deploying.
- For LLMs, **TensorRT-LLM** adds in-flight batching, paged KV cache, and FP8/INT4 kernels (Section 25).
  `torch.compile` and ONNX Runtime with the TensorRT execution provider are lighter-weight alternatives.

**Example: ResNet-50 on a T4.** PyTorch FP32 at batch 16 ran ~420 images per second. The TensorRT FP16
engine ran ~1,700 images per second (4×), and INT8 with 500 calibration images ran ~2,900 images per second
(7×), with top-1 accuracy dropping from 76.1% to 75.8%. The team shipped INT8 for the high-volume
thumbnail path, and FP16 for the premium path.

**Senior / FAANG best practice.** Make compilation a pipeline step: build engines per target GPU, run the
accuracy and performance gates automatically, and register the engine as an artifact of the model
version. Report cost per 1,000 inferences, not just latency, because that's how optimization work gets
prioritized.

---

## Lecture 100 — Triton Inference Server basics

**Why it matters.** Triton serves almost any model format from one server with production features: dynamic
batching, concurrent model execution, ensembles, metrics, and HTTP and gRPC. It's the most common
serving runtime for GPU inference that isn't an LLM, and a common one for LLMs too.

**In plain words.** Triton is a food court with one entrance. Every counter (model) can use a different
cuisine (TensorRT, ONNX, PyTorch, Python), and each counter groups orders together when it's busy, so the
cooks work efficiently.

**Architecture: inside Triton.**

```mermaid
flowchart TB
  CL((Clients)) -->|"HTTP :8000 / gRPC :8001"| FE["Triton frontend<br/>KServe v2 protocol"]
  FE --> SCHED["Per-model scheduler"]
  SCHED --> DYN["Dynamic batcher<br/>preferred sizes, max queue delay"]
  DYN --> I1["Instance 1 on GPU 0"]
  DYN --> I2["Instance 2 on GPU 0"]
  subgraph BACK["Backends"]
    I1 --> TRTB[TensorRT] 
    I2 --> ONNXB[ONNX Runtime]
    PY[Python] 
    PTB[PyTorch LibTorch]
  end
  REPO[(Model repository<br/>model/config.pbtxt, model/1/...)] --> SCHED
  FE --> MET["/metrics :8002<br/>queue time, compute time, batch sizes"]
```

**How to read it:** requests arrive over HTTP or gRPC using the standard KServe v2 inference protocol.
Each model has a scheduler. The dynamic batcher waits a few hundred microseconds to combine requests into
batches, then hands them to one of several model instances, which can run concurrently on the same GPU.
Each instance uses a backend for its format. Metrics show where time goes: queueing or compute.

**Terms in this diagram.**
- **Frontend, KServe v2 protocol**: the frontend is the part of Triton that accepts network requests. The **KServe
  v2** (Open Inference Protocol) is a standard request and response format for inference servers, so clients work
  with Triton, KServe, and others unchanged.
- **Per-model scheduler**: each model has its own queue and policy for how requests are grouped and dispatched.
- **Preferred sizes, max queue delay**: `preferred_batch_size` lists batch sizes the batcher tries to form, for
  example 8 or 16. `max_queue_delay_microseconds` caps how long a request may wait for others to join.
- **Instance**: one loaded copy of the model. Two instances on GPU 0 let one copy compute while the other receives
  data.
- **Backends**: the engine that actually runs a model format inside Triton: **TensorRT**, **ONNX Runtime**,
  **Python** (your own code), or **PyTorch LibTorch** (the C++ runtime for TorchScript models).
- **Queue time, compute time, batch sizes**: Triton's metrics on port 8002. High queue time means you need more
  instances or GPUs, and high compute time means the model itself is slow.

**Core ideas.**

```text
model_repository/
  resnet50/
    config.pbtxt
    1/model.plan          # or model.onnx, model.pt, model.py
```

```protobuf
name: "resnet50"
platform: "tensorrt_plan"
max_batch_size: 64
input  [{ name: "input",  data_type: TYPE_FP32, dims: [3, 224, 224] }]
output [{ name: "logits", data_type: TYPE_FP32, dims: [1000] }]
dynamic_batching { preferred_batch_size: [16, 32] max_queue_delay_microseconds: 2000 }
instance_group [{ count: 2, kind: KIND_GPU }]
```

| Feature | What it gives you |
|---|---|
| Dynamic batching | Higher GPU throughput at a small, bounded latency cost |
| Instance groups | Several copies per GPU, overlapping data transfer and compute |
| Ensembles / BLS | Chain preprocessing, model, and postprocessing on the server (no extra network hops) |
| Model control | `--model-control-mode=explicit` loads and unloads models via API (for multi-model serving) |
| Metrics | Queue vs compute time per model, which tells you whether to add instances or GPUs |
| LLMs | TensorRT-LLM and vLLM backends for generative models |

**Example: queue time tells the story.** A Triton model showed p99 of 45 ms: 38 ms queue time and
7 ms compute. The GPU was only 40% utilized, because one instance was running batch size 1. Adding
`dynamic_batching` and `count: 2` cut queue time to 3 ms, and throughput rose 3.5×.

**Senior / FAANG best practice.** Run `model_analyzer` to choose batch sizes, instance counts, and
precision against your latency SLO automatically, and check its recommended config into the repository.
Watch queue time vs compute time per model to diagnose capacity. Keep the model repository in object
storage, versioned with the registry, and deploy with explicit model control for safe rollouts.

---

## Lecture 101 — Batch inference vs online inference

**Why it matters.** Online inference is the most expensive way to make predictions: always-on capacity
sized for peaks, with tight latency. Many predictions can be computed in advance much more cheaply, and
choosing wrong either wastes money or gives stale results.

**In plain words.** A bakery can bake bread at 5 a.m. for the whole day (batch), or bake each loaf when a
customer orders it (online). Pre-baking is cheaper and simpler. Baking to order is needed only when every
customer wants something different, right now.

**Architecture: batch, online, and the hybrid most systems use.**

```mermaid
flowchart LR
  subgraph BATCH["Batch: scheduled"]
    WH[(Warehouse / lake)] --> JOB["Spark / Ray / Triton job<br/>spot GPUs, large batches"]
    JOB --> KV[(Key-value store<br/>precomputed predictions)]
  end
  subgraph ONLINE["Online: per request"]
    REQ((Request)) --> SVC["Model API"]
    SVC --> FS[(Online features)]
  end
  APP["Application"] -->|"lookup user_id, ~1 ms"| KV
  APP -->|"fresh context needed"| SVC
  KV -.->|"miss or stale"| SVC
```

**How to read it:** batch jobs score everyone on a schedule, using cheap interruptible capacity and big
batches, and write results to a fast key-value store. The application looks predictions up in about a
millisecond. Only requests that need fresh context (the current session, a new item, a user's
text) go to the online model, and a lookup miss can fall back to it.

In the diagram, the **warehouse / lake** is bulk analytical storage such as BigQuery or S3 (Section 6). **Spark**
and **Ray** are frameworks that split one big job across many machines (Section 24). **Spot GPUs** are spare cloud
GPUs sold at a large discount that can be taken back at short notice (Section 12). A **key-value store** such as
Redis or DynamoDB returns a stored value for a key, here a `user_id`, in about a millisecond. **Online features**
are fresh inputs served at request time. **Stale** means the stored prediction is older than allowed.

**Core ideas.**

| | Batch | Online | Streaming / near-real-time |
|---|---|---|---|
| Latency of result | Hours | Milliseconds | Seconds |
| Cost per prediction | Lowest (spot, high utilization) | Highest (peak capacity, idle time) | Medium |
| Freshness | As of the last run | Current request | Seconds-old events |
| Failure impact | Retry the job, serve yesterday's | User-facing errors | Lag builds up |
| Examples | Churn scores, daily recommendations, embeddings for a catalog | Fraud at checkout, search ranking, chat | Feed updates after a click |

- **Ask the freshness question:** "how wrong is a prediction that's 6 hours old?" If the answer is "barely",
  batch it.
- **Batch at scale:** Spark with pandas UDFs, Ray Data with GPU actors, or cloud batch-prediction jobs.
  Partition the input, make the output idempotent per partition (Section 6), and checkpoint progress.
- **LLM batch APIs** (OpenAI and Anthropic batch, vLLM offline mode) are typically ~50% cheaper for
  non-urgent workloads such as evaluations and summarizing documents.

**Example: recommendations at a fraction of the cost.** An online recommender served 3,000 RPS on
24 GPUs around the clock. Analysis showed that 85% of requests came from returning users whose
recommendations barely changed within a day. Nightly batch scoring on spot GPUs (2 hours on 16 GPUs),
plus a small online model for new users and session re-ranking (4 GPUs), cut GPU-hours by 78%.

**Senior / FAANG best practice.** Default to batch, and justify online inference with a freshness
requirement. Most large systems are hybrids: precomputed candidates or embeddings plus a light online
re-ranker. Monitor batch outputs like a service: freshness (time since the last run), coverage (share of
keys scored), and score drift.

---

## Lecture 102 — Caching for fast inference

**Why it matters.** The fastest, cheapest inference is the one you don't run. Caches at the right layer
can remove a large share of model calls, but wrong keys or missing invalidation serve wrong answers.

**In plain words.** A help desk that writes down answers to common questions. When someone asks the same
question again, they get the written answer instantly. The trick is recognizing that it's really the same
question, and tearing up the notes when the policy changes.

**Architecture: cache layers in an AI request path.**

```mermaid
flowchart LR
  R((Request)) --> RC{"Result cache<br/>key = model version + normalized input"}
  RC -->|hit| OUT((Response))
  RC -->|miss| SC{"Semantic cache<br/>embedding similarity >= 0.95"}
  SC -->|hit| OUT
  SC -->|miss| FC["Feature / embedding cache<br/>user and item vectors"]
  FC --> MODEL["Model server"]
  MODEL --> KVC["KV / prefix cache in GPU memory<br/>shared system prompts"]
  MODEL --> OUT
  MODEL -.->|"write with TTL"| RC & SC
```

**How to read it:** the request first checks an exact result cache keyed on the model version and the
normalized input. For LLMs, a semantic cache can return an answer to a near-identical question. On a miss,
the model uses cached features and embeddings, and inside the LLM server, the KV prefix cache skips
recomputing shared prompt prefixes. New results are written back with a time-to-live (TTL).

**Terms in this diagram.**
- **Result cache, normalized input**: stores whole answers. The key combines the model version, so a new model
  never returns old answers, and the **normalized input** (for example trimmed, lowercased text, with fields sorted)
  so trivially different requests match.
- **Semantic cache, embedding similarity >= 0.95**: converts the question into an **embedding** (a vector of
  numbers capturing its meaning) and returns a stored answer when an earlier question's vector is at least 0.95
  similar (cosine similarity, where 1.0 is identical). Too low a threshold returns wrong answers.
- **Feature / embedding cache**: keeps frequently used model inputs, such as user and item vectors, close to the
  server instead of re-fetching them.
- **KV / prefix cache**: inside an LLM server, the attention keys and values already computed for a prompt prefix,
  kept in GPU memory so later requests with the same system prompt skip that work (Section 25).
- **TTL** (time to live): how long an entry is kept before it expires and must be recomputed.

**Core ideas.**

| Cache | Key | Hit rate driver | Risk |
|---|---|---|---|
| Exact result | `hash(model_version, normalized input)` | Repeated identical requests (popular items, retries) | Stale results after a model update (fix: version in the key) |
| Semantic (LLMs) | Embedding of the prompt plus a similarity threshold | Paraphrased FAQs | Wrong answer for a subtly different question, personal data leaking across users |
| Feature / embedding | Entity ID + feature version | Hot entities | Stale features |
| KV / prefix (LLM servers) | Token prefix | Shared system prompts, multi-turn chat | GPU memory pressure. Needs cache-aware routing (Section 13) |

- **Put the model version in the key**, so a deployment never serves the previous model's answers.
- **Scope by tenant and user** for anything personalized or permission-dependent. A cache must never return
  another user's data.
- **Measure:** hit rate, latency saved, cost saved, and the correctness of hits (sample them and check them
  against fresh inference).
- Redis is the common choice for result, feature, and semantic caches (vector search). See course 13,
  Lab 60.

**Example: a support assistant.** Logs showed that 30% of questions were near-duplicates ("how do I reset my
password"). A semantic cache with a 0.95 similarity threshold, scoped per product and locale, served 24% of
requests in ~15 ms instead of ~2.5 s, and cut LLM spend by 22%. A sampled audit found 0.6% wrong hits, so
the team raised the threshold to 0.97 for billing questions.

**Senior / FAANG best practice.** Treat caches as part of correctness: versioned keys, tenant scoping,
TTLs that match how often the data changes, and invalidation on model or data updates. Report hit rate
and cost saved on the service dashboard, and make sure the system survives a cold cache (load-test with an
empty cache, because a cache flush shouldn't become an outage).

---

## Lecture 103 — Multi-model serving strategies

**Why it matters.** Large organizations run hundreds of models, and most get little traffic. A dedicated
GPU per model wastes most of the GPU. Sharing hardware safely is one of the biggest cost levers in serving.

**In plain words.** Instead of every small shop renting a whole building, a shopping mall shares one
building among many shops. Some get big units, some share a floor, and seasonal shops open only when
needed.

**Architecture: four ways to share GPUs across models.**

```mermaid
flowchart TB
  subgraph PACK["(1) Co-locate in one server"]
    T["Triton on 1 GPU:<br/>models A, B, C loaded,<br/>memory budget per model"]
  end
  subgraph MIG["(2) Hardware partitions"]
    G["A100/H100 with MIG:<br/>7 isolated slices"]
  end
  subgraph LORA["(3) One base, many adapters"]
    B["Base LLM in GPU memory"] --> A1["LoRA: team 1"] & A2["LoRA: team 2"] & A3["LoRA: team 3"]
  end
  subgraph DEMAND["(4) Load on demand"]
    REG[(Model store)] -->|"load on first request,<br/>evict least recently used"| S["Serving pool"]
  end
```

**How to read it:** (1) several small models share one server and GPU, each with a memory budget. (2) MIG
splits a GPU into isolated hardware slices, each with guaranteed memory and compute. (3) For LLMs, one base
model stays loaded and many small LoRA adapters are applied per request. (4) Rarely used models are loaded
when requested and evicted when idle, trading a cold-start delay for far less hardware.

In the diagram, **co-locate** means run several models in one process on one GPU. A **memory budget** caps how much
GPU memory each model may take so one can't starve the others. **A100/H100** are NVIDIA data-center GPUs that
support up to **7** MIG slices. **LoRA** (low-rank adaptation) adapters are small extra weight matrices, often a few
megabytes, that specialize a shared base model for each team. **Evict least recently used** (LRU) means that when
memory is full, the model that hasn't been called for the longest time is unloaded first. A **cold start** is the
delay while an unloaded model is read from storage and put on the GPU.

**Core ideas.**

| Strategy | Isolation | Best for | Watch out |
|---|---|---|---|
| Co-location (Triton, KServe ModelMesh) | Low: shared memory and compute | Many small models with spiky traffic | Noisy neighbors, total memory budget |
| MIG partitions | Strong: hardware isolation | Multi-tenant, predictable latency | Fixed slice sizes, reconfiguration needs the GPU drained |
| Time slicing / MPS | Low / medium | Dev, notebooks, light inference | No memory isolation (time slicing) |
| Multi-LoRA (vLLM, LoRAX) | Shared base | Many fine-tunes of one LLM | All adapters need the same base and rank limits |
| Load on demand / scale to zero | Per model | Long tail of rarely used models | Cold start of seconds to minutes. Keep top models warm |

- **Tier your models:** a few high-traffic models get dedicated, autoscaled replicas. The long tail
  shares pools.
- **Plan memory:** the sum of resident models' memory plus working memory (activations, batches, KV) must fit,
  with headroom.

**Example: 120 models on 9 GPUs.** A company had 120 small models (mostly under 500 MB), each on its own
T4, about 120 GPUs at 3% average utilization. They moved the top 8 models to dedicated autoscaled
replicas, and put the remaining 112 on a shared Triton pool with explicit model control and LRU eviction
(3 L4 GPUs, plus 2 for headroom). They went from 120 GPUs to 9, and p99 for long-tail models rose from 40 ms
to 55 ms (first requests after eviction took ~2 s).

**Senior / FAANG best practice.** Offer multi-model serving as a platform tier with clear SLOs per tier
(dedicated, shared-warm, on-demand), and per-model memory and QPS limits to contain noisy neighbors.
Charge back per model (Section 12), so teams see the cost of reserving dedicated hardware.

---

## Lecture 104 — A/B testing model endpoints

**Why it matters.** Offline metrics don't guarantee online impact. An A/B test is how you prove a new model
improves what the business cares about, without risking all users, and without fooling yourself with
noise.

**In plain words.** A coffee shop testing a new recipe gives it to half its customers, chosen at random,
for two weeks, and compares how often each group comes back. Random assignment, the same customer
always getting the same recipe, and enough customers are what make the result trustworthy.

**Architecture: a model A/B testing system.**

```mermaid
flowchart LR
  U((User)) --> ASSIGN["Assignment service<br/>hash(user_id, experiment) mod 100"]
  ASSIGN -->|"0-89 control"| A["Model A (champion)"]
  ASSIGN -->|"90-99 treatment"| B["Model B (challenger)"]
  A & B --> LOG[("Exposure + prediction log<br/>user, variant, model version")]
  APPDATA[("Outcome events<br/>clicks, purchases, retention")] --> JOIN["Join on user + time"]
  LOG --> JOIN
  JOIN --> STATS["Analysis: lift, confidence interval,<br/>guardrails: latency, errors, revenue"]
  STATS --> DEC{"Ship, iterate, or stop"}
```

**How to read it:** users are assigned to variants by hashing their ID, so the same user always sees the
same model (sticky), and the assignment is random with respect to behavior. Every exposure is logged with
variant and model version. Outcomes (clicks, purchases) are joined to exposures, and the analysis computes
the lift with confidence intervals, plus guardrail metrics that must not get worse.

**Terms in this diagram.**
- **hash(user_id, experiment) mod 100**: a hash turns the user ID plus the experiment name into a fixed, random-
  looking number. Taking the remainder after dividing by 100 gives a bucket from 0 to 99. Including the experiment
  name stops the same users from always landing in the treatment group of every experiment.
- **Control, treatment**: **control** (buckets 0–89, 90% of users) gets the current model. **Treatment** (buckets
  90–99, 10%) gets the new one.
- **Champion, challenger**: the **champion** is the model in production now. The **challenger** is the candidate
  trying to replace it.
- **Exposure**: a record that a given user actually saw a given variant's prediction. Only exposed users count in
  the analysis.
- **Outcome events, retention**: what users did afterwards. **Retention** is whether they came back later.
- **Lift, confidence interval**: **lift** is the percentage improvement of treatment over control. The **confidence
  interval** is the range the true lift probably lies in. If it includes zero, the result isn't proven.
- **Guardrails**: metrics that must not get worse, such as latency, error rate, and revenue, even if the main
  metric improves.

**Core ideas.**

| Concept | Meaning | Common mistake |
|---|---|---|
| Unit of randomization | User (usually), session, or request | Randomizing per request, so users see both models and effects blur |
| Primary metric | The one business metric that decides | Choosing it after seeing the data |
| Guardrails | Latency, errors, revenue, complaints that must not regress | Only watching the primary metric |
| Sample size | Enough users to detect the minimum effect that matters | Stopping as soon as the result looks significant ("peeking") |
| Shadow vs canary vs A/B | Shadow: no user impact, checks behavior. Canary: safety. A/B: measures impact | Using a canary to "prove" lift |

**Sample size, quickly:** to detect an absolute change of δ in a conversion rate p with ~80% power at
5% significance, you need about n ≈ 16·p(1−p)/δ² users **per variant**. For p = 5% and a 0.25-point lift
(5.00% → 5.25%): n ≈ 16 × 0.0475 ÷ 0.0025² = 0.76 ÷ 0.00000625 ≈ **122,000 per variant**.

- Run for whole weeks to cover weekly cycles. Fix the duration in advance, or use sequential testing
  methods designed for monitoring results along the way.
- Check **sample ratio mismatch**: if a 50/50 split arrives as 50.8/49.2 with millions of users, the
  assignment or logging is broken, and the result is invalid.

**Example: the model that won offline and lost online.** A new ranking model improved offline NDCG by 3%.
In a two-week A/B test with 10% of users, click-through rose 1.2%, but purchases per user fell 0.8% (the
confidence interval excluded zero), and p99 latency rose 30 ms. The model optimized clicks on cheaper
items. The team added purchase signals to the training objective before shipping.

**Senior / FAANG best practice.** Big tech runs experiments on a shared platform: deterministic
assignment, exposure logging, automatic sample-ratio checks, pre-registered metrics, guardrails, and
standard statistical analysis (often with variance reduction such as CUPED). Model teams don't build
their own. Always run shadow and canary *before* the A/B test, so the experiment measures value, not bugs.

---

## Lecture 105 — Lab: deploy a model on Triton server

**Goal:** export ResNet-50 to ONNX, serve it on Triton with dynamic batching, call it over HTTP, measure
throughput and latency with `perf_analyzer`, and compare batching configurations.

**What you're building.**

```mermaid
flowchart LR
  EXP["export.py<br/>ResNet-50 to ONNX"] --> REPO[("model_repository/resnet50/1/model.onnx<br/>+ config.pbtxt")]
  REPO --> TRI["Triton 24.xx container<br/>GPU or CPU"]
  CLIENT["client.py<br/>tritonclient HTTP"] --> TRI
  PA["perf_analyzer<br/>concurrency 1..16"] --> TRI
  TRI --> MET["/metrics :8002"]
```

**In plain words.** You set up a production inference server for a real model, then measure how batching
changes what one GPU can do.

**How to read the diagram:** `export.py` writes ResNet-50, a standard image classifier, to an ONNX file. You place it
in Triton's folder layout, `model_repository/<model name>/<version>/`, next to its `config.pbtxt`. The Triton
container (release tag `24.xx`, for example `24.08`) serves it on a GPU, or on a CPU if you have none. `client.py`
sends requests using `tritonclient`, NVIDIA's Python client library. `perf_analyzer` is Triton's load generator: it
sends requests at **concurrency** 1 to 16 (that many requests in flight at once) and reports throughput and latency
for each level. Port 8002 exposes the server's metrics.

### Step 1 — Export the model and write the config

```bash
mkdir -p model_repository/resnet50/1
python - <<'EOF'
import torch, torchvision
m = torchvision.models.resnet50(weights="DEFAULT").eval()
torch.onnx.export(m, torch.randn(1, 3, 224, 224), "model_repository/resnet50/1/model.onnx",
                  input_names=["input"], output_names=["logits"],
                  dynamic_axes={"input": {0: "batch"}, "logits": {0: "batch"}}, opset_version=17)
EOF
cat > model_repository/resnet50/config.pbtxt <<'EOF'
name: "resnet50"
backend: "onnxruntime"
max_batch_size: 32
input  [{ name: "input",  data_type: TYPE_FP32, dims: [3, 224, 224] }]
output [{ name: "logits", data_type: TYPE_FP32, dims: [1000] }]
dynamic_batching { max_queue_delay_microseconds: 2000 }
instance_group [{ count: 1, kind: KIND_GPU }]
EOF
```

On a CPU-only machine, use `kind: KIND_CPU`. Everything else stays the same.

### Step 2 — Start Triton and check the model is ready

```bash
docker run --rm -d --name triton --gpus all -p 8000:8000 -p 8001:8001 -p 8002:8002 \
  -v "$PWD/model_repository:/models" nvcr.io/nvidia/tritonserver:24.08-py3 \
  tritonserver --model-repository=/models
curl -s localhost:8000/v2/health/ready -o /dev/null -w "%{http_code}\n"     # 200
curl -s localhost:8000/v2/models/resnet50 | python -m json.tool
```

### Step 3 — Call it from Python

```python
# client.py   (pip install tritonclient[http] pillow torchvision)
import numpy as np, tritonclient.http as http
from PIL import Image
from torchvision.models import ResNet50_Weights
w = ResNet50_Weights.DEFAULT
x = w.transforms()(Image.open("kitten.jpg").convert("RGB")).unsqueeze(0).numpy().astype(np.float32)
c = http.InferenceServerClient("localhost:8000")
inp = http.InferInput("input", x.shape, "FP32"); inp.set_data_from_numpy(x)
out = c.infer("resnet50", [inp], outputs=[http.InferRequestedOutput("logits")]).as_numpy("logits")
print([w.meta["categories"][i] for i in out[0].argsort()[-3:][::-1]])
```

### Step 4 — Measure, then change the config and measure again

```bash
docker run --rm --net host nvcr.io/nvidia/tritonserver:24.08-py3-sdk \
  perf_analyzer -m resnet50 --concurrency-range 1:16:4 --shape input:3,224,224
# then: set instance_group count to 2, and remove dynamic_batching for comparison
docker restart triton && sleep 20   # re-run perf_analyzer for each config
curl -s localhost:8002/metrics | grep -E "nv_inference_(queue|compute_infer)_duration_us"
```

**Expected results:**
- `client.py` prints labels such as `['tabby', 'tiger cat', 'Egyptian cat']`.
- Without dynamic batching, throughput stays flat as concurrency rises, and latency grows linearly.
- With dynamic batching, throughput rises with concurrency: typically 2–4× more inferences per second at
  concurrency 16 on a GPU, with only a few milliseconds of added latency.
- The metrics show queue time falling, and compute time per request falling, as batches form.
- **Stretch goal:** build a TensorRT FP16 engine with `trtexec` (Lecture 99), set
  `platform: "tensorrt_plan"`, and compare. Expect another 2–3× on GPU.

---

## FAANG deep-dive notes

**How big tech does it.** Inference platforms compile models per hardware target (TensorRT, XLA, custom
compilers), serve them on standard runtimes with dynamic batching, and route through layers of caches.
Most predictions that can be precomputed are batch-scored. Long-tail models share pools, while high-traffic
models get dedicated, autoscaled capacity. Every model change goes shadow, then canary, then A/B on a shared
experimentation platform with guardrails. The metric that drives decisions is cost per 1,000 predictions
at the latency SLO.

**Staff review questions.**
- Does this need online inference? What's the freshness requirement?
- What is the cost per 1,000 inferences before and after compilation and batching?
- What's the cache hit rate, how are keys versioned and scoped, and what happens on a cold cache?
- What's the minimum detectable effect and sample size of this A/B test, and what are the guardrails?

**Interview question.** "Your inference bill doubled with traffic. How do you halve cost per prediction?"

**Typical system-design prompt:** *Design inference for an e-commerce site with 50 ranking and
recommendation models: 40,000 requests per second at peak, p99 under 80 ms, and a monthly GPU budget that
must shrink by 40%.*

**1. Clarify first:** Which models are real-time vs precomputable? What's the traffic distribution
across models (usually heavily skewed)? What GPU types are available? How often do models change? What's the
experiment cadence?

**2. Back-of-envelope sizing:**
- Traffic split: the top 5 models take ~85% (34,000 RPS). The other 45 share 6,000 RPS.
- Dedicated tier: TensorRT FP16 ranking model ≈ 4,000 RPS per L4 at the SLO, so 34,000 ÷ 4,000 ≈ 9 GPUs,
  ~12 with headroom.
- Shared tier: 45 models × ~400 MB = 18 GB resident, so 3 L4s (24 GB each) with LRU eviction, plus 1 spare.
- Batch: precomputing candidates for 20M users nightly at ~20,000 per second per GPU takes ~17 GPU-minutes, which is trivial
  on spot.
- Caching popular item scores, with a 30% hit rate, removes ~12,000 RPS from the GPUs.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Inference mode | Online for everything | Batch + online re-rank | Batch whatever tolerates hours of staleness |
| Precision | FP16 | INT8 / FP8 | INT8 when the golden-set accuracy delta is within tolerance |
| Model hosting | Dedicated per model | Shared pools | Dedicated for the head, shared for the tail |
| Cache | None | Exact + semantic | Exact always (versioned keys). Semantic only with audited accuracy |
| Rollout evidence | Offline metrics | Online A/B with guardrails | Ship only on A/B results, after shadow and canary |

**4. Follow-up questions with crisp answers:**
- *Why does dynamic batching help throughput but cost latency?* It waits up to the queue delay to fill a
  batch. GPUs process a batch of 16 almost as fast as a batch of 1, so throughput rises, at the cost of a
  bounded wait.
- *Why randomize A/B tests by user, not by request?* So each user has one consistent experience. Per-request
  randomization mixes effects and breaks metrics such as retention.
- *What invalidates a cache entry on model deploy?* The model version is part of the key, so new-version
  requests miss and fill fresh entries, and old entries expire by TTL.

**Debug this (common onsite question):** "After moving to Triton with dynamic batching, average latency improved, but p99 got worse."
1. Check Triton metrics: compute time is fine, but queue time p99 is high, because `max_queue_delay` is
   large and preferred batch sizes rarely fill at low traffic.
2. Check traffic shape: bursts, then quiet periods. At low load, requests wait the full delay for partners
   that never come.
3. Check the instance count: one instance means a big batch blocks the next one.
4. Fix: lower `max_queue_delay_microseconds`, drop strict preferred sizes, use 2 instances, and re-run
   `model_analyzer` with a p99 constraint.

The lesson: batching is a latency-for-throughput trade. Tune it against the p99 SLO at realistic
traffic shapes, not at peak load alone.

**5. What separates senior from staff answers:** a senior engineer optimizes a model (TensorRT, batching) and
deploys it correctly on Triton. A staff engineer decides what should be online at all, designs tiers
(dedicated, shared, batch), sets up caches with correct semantics, measures cost per prediction across the
fleet, and makes sure model changes are evaluated by trustworthy experiments with guardrails.

**Red flags:**
- Serving everything online by default.
- Caches without model versions or tenant scope in the key.
- One GPU per tiny model.
- A/B tests that stop at first significance or randomize per request.
- TensorRT engines deployed without an accuracy check.
- Tuning batching only for throughput.

---

## Quiz

<details><summary>1. What three things does TensorRT do to speed up a model?</summary>
It fuses layers and tensors, lowers precision (FP16, INT8, or FP8 with calibration), and auto-tunes the
fastest kernel per layer for the target GPU and shapes.
</details>

<details><summary>2. Why must TensorRT engines be built per GPU type?</summary>
Kernel choices and optimizations are specific to the GPU architecture and TensorRT version, so an engine built
for a T4 isn't valid or optimal on an H100.
</details>

<details><summary>3. Triton metrics show high queue time and low compute time. What do you change?</summary>
Add model instances, or enable or tune dynamic batching, so requests stop waiting. If the GPU is
saturated, add GPUs or replicas.
</details>

<details><summary>4. When is batch inference the right choice?</summary>
When predictions can be hours old without hurting the product: daily recommendations, churn scores,
catalog embeddings. It's cheaper (spot, high utilization) and more resilient.
</details>

<details><summary>5. What must a result-cache key include to be safe?</summary>
The model version, the normalized input, and any tenant or user scope that affects the answer or access
rights.
</details>

<details><summary>6. Name two ways to serve many models on few GPUs, with one trade-off each.</summary>
Co-locating models in one server (cheap, but noisy neighbors), MIG (strong isolation, but fixed slice
sizes), multi-LoRA (one base for many fine-tunes, but all must share the base), or load on demand (cheap
long tail, but cold starts).
</details>

<details><summary>7. Roughly how many users per variant do you need to detect a lift from 5.00% to 5.25% conversion?</summary>
n ≈ 16·p(1−p)/δ² = 16 × 0.0475 ÷ 0.0025² ≈ 122,000 per variant.
</details>

<details><summary>8. What is sample ratio mismatch, and why does it matter?</summary>
The observed split differs from the planned split by more than chance (for example 50.8/49.2 on millions
of users). It signals broken assignment or logging, so the test result can't be trusted.
</details>

## Failure modes
- Compiled engines deployed without an accuracy check, or on the wrong GPU type.
- Dynamic batching tuned for peak throughput, ruining p99 at normal load.
- Everything served online when most predictions could be precomputed.
- Cache keys without the model version (stale answers after a deploy), or without the user scope (data leaks).
- Semantic caches returning answers to subtly different questions.
- Noisy neighbors in shared model pools without memory and QPS limits.
- A/B tests that peek, randomize per request, or ignore guardrails and sample ratio mismatch.

## Checklist
- [ ] You can build a TensorRT engine and validate its accuracy against a golden set
- [ ] You can write a Triton config with dynamic batching and instance groups, and read queue vs compute metrics
- [ ] You can decide batch vs online inference from a freshness requirement
- [ ] Your caches have versioned, scoped keys, TTLs, hit-rate metrics, and survive a cold start
- [ ] You can design tiers for many models (dedicated, shared, on-demand)
- [ ] You can size an A/B test and list its guardrails
- [ ] You deployed ResNet-50 on Triton and measured the effect of dynamic batching with perf_analyzer
