# Section 13 — Networking for AI Systems

> Lectures 85–91 • Assessment: quiz
> **After this section you can:** explain how data-center networks are built (leaf-spine, oversubscription,
> front-end vs GPU fabric), use software-defined networking in clouds and Kubernetes, compare InfiniBand,
> RoCE, and cloud GPU networks, load-balance inference traffic correctly (including long LLM streams),
> find network bottlenecks in distributed training, secure networked AI systems, and put a load balancer in
> front of an AI API.
>
> Go deeper: [13 / Lab 35 — InfiniBand and RoCEv2](../../13_sovereign_ai_infra_course/03_distributed_training/lab35_infiniband_rocev2.md),
> [Lab 36 — NCCL optimization](../../13_sovereign_ai_infra_course/03_distributed_training/lab36_nccl_optimization.md),
> [Lab 49 — Envoy gRPC load balancing](../../13_sovereign_ai_infra_course/04_serving_inference/lab49_envoy_grpc_lb.md),
> [Lab 6 — CoreDNS and internal load balancing](../../13_sovereign_ai_infra_course/01_foundations_local_sandbox/lab06_coredns_internal_lb.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 85 | Fundamentals of data center networking | Leaf-spine fabrics, oversubscription, and two networks: front-end for users, back-end for GPUs |
| 86 | Software defined networking (SDN) for AI | Networks configured by software: VPCs, overlays, CNIs, eBPF, and extra pod NICs for RDMA |
| 87 | InfiniBand and high-speed interconnects | 400–800 Gb/s lossless fabrics with RDMA. InfiniBand vs RoCE vs cloud fabrics (EFA, TCPXO) |
| 88 | Load balancing for AI inference | Balance by outstanding work, not by request count. Long streams and caches change the rules |
| 89 | Network bottlenecks in distributed training | The slowest link sets the pace. Measure bus bandwidth, find stragglers, overlap communication |
| 90 | Security in networked AI systems | Zero trust: mTLS, segmentation, private endpoints, egress control, and API protection |
| 91 | Lab: configure a load balancer for an AI API | NGINX in front of three model replicas: algorithms, health checks, timeouts, rate limits |

```mermaid
flowchart TB
  USERS((Users)) --> EDGE["Edge: CDN, WAF, DDoS protection"]
  EDGE --> LB["L7 load balancer / API gateway<br/>TLS, auth, rate limits"]
  subgraph FE["Front-end network: Ethernet, TCP/IP"]
    LB --> SVC["Inference replicas<br/>least-outstanding-requests"]
    SVC --> DATA[(Feature store, vector DB,<br/>object storage via private endpoints)]
  end
  subgraph BE["Back-end GPU fabric: InfiniBand or RoCE, RDMA"]
    N1["Training node: 8 GPUs, 8 x 400G NICs"] <--> LEAF[Leaf switches per rail] <--> SPINE[Spine switches]
    N2["Training node"] <--> LEAF
  end
  SVC -.separate.-> BE
  MGMT["Management network:<br/>BMC, provisioning, SSH bastion"] -.isolated.-> N1 & N2
```

**How to read it:** AI data centers usually run several separate networks. User traffic enters through the
edge and an L7 load balancer, reaching inference replicas on the ordinary front-end network. Training nodes
also sit on a dedicated back-end **GPU fabric**, a high-bandwidth, low-latency, lossless network used only
for GPU-to-GPU traffic such as all-reduce. A third, isolated management network handles hardware
control. Keeping them apart stops user traffic and training traffic from hurting each other, and limits
the blast radius of an attack.

**Terms in this diagram.**
- **Edge: CDN, WAF, DDoS protection**: the **edge** is the provider's network of servers close to users. A **CDN**
  (content delivery network) caches and terminates connections there. A **WAF** (web application firewall) blocks
  malicious requests. **DDoS protection** absorbs floods of fake traffic meant to knock the service offline.
- **L7 load balancer / API gateway**: **L7** means layer 7, the application layer of the network model, so it
  understands HTTP: paths, headers, and API keys. An **API gateway** adds authentication and **rate limits** (a
  maximum number of requests per client per second).
- **Least-outstanding-requests**: a balancing rule that sends each new request to the replica with the fewest
  requests in progress (Lecture 88).
- **Ethernet, TCP/IP**: the ordinary networking used by almost all computers.
- **InfiniBand or RoCE, RDMA**: high-performance networks for GPU traffic, which move data directly between
  machines' memories (Lecture 87).
- **8 x 400G NICs**: eight network cards per server, each 400 gigabits per second, one per GPU.
- **Leaf switches per rail, spine switches**: the two-layer switch design explained in Lectures 85 and 87.
- **Feature store, vector DB**: the databases inference calls for model inputs and for similarity search
  (Section 6).
- **BMC, provisioning, SSH bastion**: the **BMC** (baseboard management controller) is a small computer on each
  server's motherboard that can power it on, off, or reinstall it remotely. **Provisioning** installs the
  operating system on new machines. An **SSH bastion** is the single hardened server engineers log in through to
  reach the others.
- **Lossless**: the network never drops packets under load, which RDMA needs to run at full speed.

---

## Lecture 85 — Fundamentals of data center networking

**Why it matters.** Every AI request and every gradient sync crosses a data-center network. Its shape
decides how fast nodes can talk to each other, how much it costs, and what fails when a switch dies.

**In plain words.** A leaf-spine network is a city road system. Every neighborhood (rack) has a local
road (the leaf switch). Every local road connects to every highway (spine switch). Any two neighborhoods
are always exactly "local road, highway, local road" apart, and there are many highways to share the
traffic. If one highway closes, cars use the others.

**Architecture: a two-tier leaf-spine (Clos) fabric.**

```mermaid
flowchart TB
  subgraph SPINES["Spine layer"]
    S1[Spine 1] & S2[Spine 2] & S3[Spine 3] & S4[Spine 4]
  end
  subgraph LEAVES["Leaf layer, top of rack"]
    L1[Leaf 1] & L2[Leaf 2] & L3[Leaf 3]
  end
  L1 --- S1 & S2 & S3 & S4
  L2 --- S1 & S2 & S3 & S4
  L3 --- S1 & S2 & S3 & S4
  L1 --- R1["Rack 1 servers"]
  L2 --- R2["Rack 2 servers"]
  L3 --- R3["Rack 3 servers"]
```

**How to read it:** every leaf connects to every spine, and servers connect only to their leaf. Traffic
between racks goes up to *some* spine and back down. Equal-cost multi-path routing (**ECMP**) spreads
flows across all spines. Adding spines adds bandwidth, and adding leaves adds racks. Losing a spine
removes only a fraction of the capacity.

**Core ideas.**

| Term | Meaning |
|---|---|
| North-south traffic | In and out of the data center (users to services) |
| East-west traffic | Server to server inside the data center. Dominant in AI (training sync, microservices, storage) |
| Oversubscription | Server-facing bandwidth ÷ uplink bandwidth on a leaf. 1:1 is non-blocking, and 3:1 is common for general compute |
| ECMP | Hashing flows across equal paths. Few large flows can collide on one path ("elephant flows") |
| Latency budget | Same rack ~1–2 µs per switch hop. Across a data center ~5–10 µs. Across regions tens of ms |

- **Separate fabrics** for different jobs: front-end (users, storage, control), back-end (GPU-to-GPU,
  non-blocking, often rail-optimized), and out-of-band management.
- AI training needs a **non-blocking** (1:1) back-end, because all-reduce makes every node send at line rate
  at the same moment. Inference and storage traffic tolerate some oversubscription.
- Bandwidth units: network links are quoted in **bits** (400 Gb/s), and memory in **bytes**. 400 Gb/s =
  50 GB/s.

**Example: what 3:1 oversubscription does to training.** A leaf has 32 servers × 100 Gb/s down =
3.2 Tb/s, but only 8 × 100 Gb/s = 800 Gb/s up, which is 4:1. When all 32 servers run a cross-rack
all-reduce together, each gets at most 800 ÷ 32 = 25 Gb/s across the spine, a quarter of its NIC speed.
Training that was compute-bound in one rack becomes network-bound across racks. That's why GPU fabrics are
built non-blocking.

**Senior / FAANG best practice.** Hyperscalers build networks from many identical, cheap switches in Clos
topologies, automate them completely (configuration from source control, automated failure detection and
drain), and design for **graceful degradation**: losing a switch or link removes a few percent of the
capacity, not a rack. For AI clusters, they build a separate non-blocking back-end fabric and
plan its scale (radix, tiers, optics, power) as carefully as the GPUs.

---

## Lecture 86 — Software defined networking (SDN) for AI

**Why it matters.** In clouds and Kubernetes, you never touch a switch. Networks are created by API calls
and controllers. Understanding the layers (VPC, overlay, CNI, policy) explains many latency, MTU, and
connectivity problems, and how to give pods high-performance network cards.

**In plain words.** Traditional networking is like a city where every traffic light is set by hand by a
person standing at the junction. SDN is a central traffic control room that sets every light from one
screen, by software, and can reconfigure the whole city in seconds.

**Architecture: the layers between two pods.**

```mermaid
flowchart TB
  subgraph CTRL["Control plane (software)"]
    CLOUD["Cloud VPC controller<br/>subnets, routes, security groups"]
    CNI["Kubernetes CNI controller<br/>Cilium, Calico, AWS VPC CNI"]
    POL["NetworkPolicies, eBPF programs"]
  end
  subgraph DATA["Data plane"]
    P1[Pod A] --> V1["veth / eBPF on node 1"]
    V1 -->|"VPC routing or VXLAN overlay"| V2["veth / eBPF on node 2"]
    V2 --> P2[Pod B]
    P3["Training pod"] -->|"secondary NIC via Multus + SR-IOV,<br/>RDMA, bypasses the CNI"| RDMA[GPU fabric]
  end
  CLOUD --> DATA
  CNI --> V1 & V2
  POL --> V1 & V2
```

**How to read it:** controllers in the control plane program the data plane. The cloud programs the VPC
routes and security groups. The CNI gives each pod an address and connects it, either natively in the VPC or
through an overlay that wraps packets (VXLAN). Policies are enforced as eBPF programs or iptables rules
on each node. Training pods that need RDMA get a **second network interface** attached directly to the
GPU fabric (via Multus and SR-IOV), skipping the ordinary pod network entirely.

**Terms in this diagram.**
- **Control plane** and **data plane**: the control plane decides how traffic should flow (routes, rules). The data
  plane is what actually moves each packet.
- **Cilium, Calico, AWS VPC CNI**: CNI plugins, the Kubernetes components that give pods network addresses and
  connectivity (Section 5, entry B4).
- **eBPF**: a Linux kernel feature that runs small, verified programs inside the kernel, for example to filter or
  redirect packets very fast. Cilium is built on it.
- **veth**: a virtual Ethernet pair, like a virtual cable whose one end is inside the pod and the other on the node.
- **NetworkPolicies**: Kubernetes firewall rules between pods, which the CNI turns into eBPF programs or iptables
  rules (Section 5, entry D5).
- **VXLAN overlay**: wrapping each pod packet inside a normal node-to-node packet, so pods can talk across nodes on
  any network.
- **Multus, SR-IOV**: **Multus** lets a pod have more than one network interface. **SR-IOV** (single-root I/O
  virtualization) splits one physical NIC into several virtual NICs that pods can use directly, at full hardware
  speed.

**Core ideas.**

| Layer | Examples | Watch out |
|---|---|---|
| Cloud SDN | VPC/VNet, subnets, route tables, security groups, private endpoints | IP address exhaustion with many pods, cross-AZ charges |
| Overlay | VXLAN, Geneve | ~50 bytes of header per packet (MTU 1500 → 1450), CPU cost |
| Kubernetes CNI | AWS VPC CNI, Azure CNI, Calico, Cilium | IP planning, kube-proxy scale (iptables with thousands of services) |
| eBPF dataplane | Cilium | Replaces kube-proxy, adds observability (Hubble), L7 policy |
| Secondary networks | Multus + SR-IOV, NVIDIA Network Operator | Needed for RDMA in pods. Device and driver setup per node |
| Service mesh | Istio, Linkerd, Cilium mesh | mTLS and traffic control, at a latency and CPU cost per hop |

- **MTU mismatches** cause mysterious failures. Small requests work, large ones hang. Use jumbo frames
  (9,000 bytes) on GPU fabrics, and make sure every hop agrees.
- **Cross-AZ traffic costs money** in most clouds (~$0.01/GB each way). Chatty services and replicated
  storage across zones can be a surprise line item.

**Example: giving training pods RDMA.** A team's PyTorchJobs on Kubernetes reached only 18 GB/s of
all-reduce bus bandwidth across nodes, while bare-metal runs on the same hardware reached 180 GB/s. Their
pods used only the default CNI interface (TCP over the front-end network). With the NVIDIA Network
Operator, SR-IOV virtual functions, and Multus attaching one RDMA interface per GPU, NCCL switched to
`NET/IB`, and bus bandwidth matched bare metal.

**Senior / FAANG best practice.** Plan IP space for pod growth from the start (secondary CIDRs, prefix
delegation), standardize on one CNI per fleet, and keep the GPU data path off the general-purpose pod
network. Use eBPF-based observability to see flows per service, and manage all network config (VPCs,
policies, CNI settings) as code with review.

---

## Lecture 87 — InfiniBand and high-speed interconnects

**Why it matters.** Large-scale training lives or dies by the GPU fabric. Choosing between InfiniBand,
RoCE, and a cloud's own fabric affects performance, cost, operations skills, and which failures you will
debug at 3 a.m.

**In plain words.** Normal Ethernet is a postal service. Letters can get lost, and the sender notices and
resends. RDMA over a lossless fabric is a pneumatic tube between offices: you put the item in, and it
lands directly in the other person's inbox, with nobody opening or copying it along the way.

**Architecture: GPUDirect RDMA across a rail-optimized fabric.**

```mermaid
flowchart LR
  subgraph NA["Node A"]
    GA0["GPU 0 HBM"] --> NICA0["NIC 0, 400G"]
    GA1["GPU 1 HBM"] --> NICA1["NIC 1"]
  end
  subgraph NB["Node B"]
    NICB0["NIC 0"] --> GB0["GPU 0 HBM"]
    NICB1["NIC 1"] --> GB1["GPU 1 HBM"]
  end
  NICA0 --> R0["Rail 0 leaf"] --> NICB0
  NICA1 --> R1["Rail 1 leaf"] --> NICB1
  R0 <--> SP[Spines]
  R1 <--> SP
```

**How to read it:** with **GPUDirect RDMA**, a NIC reads directly from GPU memory (**HBM**, the GPU's own
high-bandwidth memory) and writes directly
into the remote GPU's memory, with no CPU copies and no kernel involvement. In a rail-optimized design,
GPU 0 of every node connects to the "rail 0" leaf switch, GPU 1 to "rail 1", and so on. Most collective
traffic between matching GPUs stays one switch hop away, and only cross-rail traffic goes through the spines.

**Core ideas.**

| | InfiniBand (NVIDIA Quantum) | RoCEv2 (RDMA over Ethernet) | Cloud fabrics |
|---|---|---|---|
| Speeds | NDR 400 Gb/s, XDR 800 Gb/s | 400/800 GbE | AWS EFA (up to 3,200 Gb/s per instance), GCP GPUDirect-TCPXO/RDMA, Azure InfiniBand |
| Lossless | Built in (credit-based flow control) | Configured: PFC + ECN + congestion control (DCQCN) | Managed by the provider |
| Operations | Subnet manager, specialized skills | Ethernet skills, but tuning lossless is hard | Provider-managed. You tune NCCL plugins |
| Extras | SHARP in-network reductions, adaptive routing | Broad vendor choice. Ultra Ethernet is emerging | Integrated with instances and schedulers |
| Typical home | Largest training clusters | Hyperscalers and Ethernet-first data centers | Cloud training |

- **Bandwidth per GPU** is the number to plan: 8 × 400 Gb/s NICs per 8-GPU node = 400 Gb/s (50 GB/s)
  per GPU of scale-out bandwidth, against 900 GB/s of NVLink inside the node. That 18× gap is why
  tensor parallelism stays inside nodes.
- **Verify with tests, not specs:** `ib_write_bw` for raw link speed, and `nccl-tests all_reduce_perf` for
  the collective bus bandwidth across nodes.
- Cloud fabrics need their own **NCCL plugins** (aws-ofi-nccl for EFA, the TCPXO plugin on GCP).
  Without them, NCCL falls back to plain TCP.

**Example: picking a fabric for a 1,024-GPU on-prem cluster.** InfiniBand NDR gave the best measured
all-reduce and needed little tuning, but required new skills and a single vendor. RoCE on 400 GbE fit the
existing network team's skills and vendors, but needed weeks of PFC and ECN tuning to avoid congestion
collapse under all-reduce bursts. The team chose InfiniBand for the training fabric, and kept Ethernet for
the front-end and storage networks.

**Senior / FAANG best practice.** Treat the fabric as part of the training system: acceptance tests for
every link before a node joins (bandwidth, error counters, firmware versions), continuous error-counter
monitoring, automatic draining of flapping links, and NCCL tests in CI for new images. Choose the
fabric by measured collective performance at your scale and the operational skills you have, not by
spec sheets.

---

## Lecture 88 — Load balancing for AI inference

**Why it matters.** Inference requests vary hugely in cost: an LLM request can take 50 ms or 60 s
depending on output length. Classic load balancing assumes similar requests, and leaves some replicas
overloaded while others idle, which shows up as terrible tail latency.

**In plain words.** A bank with several tellers. "Next customer goes to the next teller in turn" (round
robin) works if every customer takes two minutes. If some customers bring a box of paperwork, the line
at that teller grows while others sit idle. Better: send each new customer to the teller with the least
work waiting. Even better: send a regular customer to the teller who already has their file open (cache
affinity).

**Architecture: AI-aware load balancing for an LLM service.**

```mermaid
flowchart LR
  C((Clients)) --> GW["L7 gateway<br/>TLS, auth, rate limit per key"]
  GW --> ROUTE{"Routing policy"}
  ROUTE -->|"least outstanding requests<br/>or queue depth"| R1["Replica 1<br/>queue 2"]
  ROUTE -->|"prefix hash:<br/>same system prompt"| R2["Replica 2<br/>KV cache has prefix"]
  ROUTE --> R3["Replica 3<br/>queue 9, avoided"]
  HC["Health checks:<br/>readiness = model loaded"] -.-> R1 & R2 & R3
  R1 & R2 & R3 -->|"streamed tokens, SSE or gRPC"| GW
```

**How to read it:** the gateway handles TLS, authentication, and per-key rate limits, then picks a
replica using live load (outstanding requests or queue depth), not a fixed rotation. For LLMs, it can also
route requests that share a prompt prefix to the same replica, so that replica's KV cache can be reused.
Health checks remove replicas that aren't ready. Responses stream back over long-lived connections,
which the load balancer must keep open.

In the diagram, a **prefix hash** computes a hash of the prompt's first part (for example the shared system
prompt) and always sends the same hash to the same replica. The **KV cache** is the GPU memory where an LLM keeps
the processed prompt, so a replica that already holds that prefix skips recomputing it. **Readiness** is the health
check that only passes once the model has finished loading. **SSE** (server-sent events) is a simple HTTP
streaming format that most LLM APIs use to send tokens as they're generated. **gRPC** is a binary RPC protocol over
HTTP/2 that also supports streaming.

**Core ideas.**

| Algorithm | How | Good for | Bad for |
|---|---|---|---|
| Round robin | Next replica in turn | Uniform, short requests | Variable-cost requests (LLMs) |
| Least connections / outstanding requests | Fewest in-flight requests | Variable request cost | Requests with very different sizes |
| Power of two choices | Pick 2 at random, send to the less loaded | Large fleets, low coordination | — |
| Consistent hashing / prefix affinity | Hash a key (user, prompt prefix) to a replica | Cache reuse (KV, prefix, sessions) | Hot keys overload one replica, so add bounded load |
| Model- or queue-aware | Use server metrics (KV cache usage, queue) | LLM serving (Gateway API Inference Extension, llm-d, vLLM router) | Needs metric plumbing |

- **L4 vs L7:** L4 balances TCP connections and never sees individual requests inside a long-lived
  HTTP/2 or gRPC connection, so all of them go to one backend. Use L7 (Envoy, NGINX, a cloud ALB, or a
  gRPC-aware mesh) for gRPC and streaming.
- **Timeouts:** idle and request timeouts must exceed the longest generation (for example 300 s), or
  streams get cut off mid-answer. Typical defaults are 60 s.
- **Readiness = model loaded and warm.** Drain connections on shutdown (`preStop` sleep plus a grace
  period longer than the longest request).

**Example: fixing p99 with one setting.** An LLM API ran 8 replicas behind round robin. A few long
generations (4,000 tokens) piled up on unlucky replicas, and p99 time-to-first-token reached 9 s while
the average stayed at 400 ms. Switching to least-outstanding-requests, and capping the queue per replica
(returning 429 to trigger client backoff), brought p99 to 1.6 s with the same hardware.

**Senior / FAANG best practice.** Balance on the signal that predicts latency (queue depth, KV cache
pressure), and keep admission control at the edge: per-tenant quotas, request size limits, and early
429s instead of unbounded queues. Big serving stacks use two levels: a global load balancer that picks a
region or cell, and a local model-aware router that picks a replica. Both levels are instrumented, so
you can see why each request went where it did.

---

## Lecture 89 — Network bottlenecks in distributed training

**Why it matters.** When training scales poorly, the network is the usual suspect, but proving it takes
measurement. One bad cable, a mis-set environment variable, or a congested spine can slow a
thousand-GPU job to the speed of its worst link.

**In plain words.** A rowing team can only go as fast as its slowest rower. Synchronous training waits for
every GPU at every step. One slow link (a straggler) and everyone waits.

**Architecture: a step's timeline, and where the network hides.**

```mermaid
gantt
  title One training step on one GPU (illustrative)
  dateFormat X
  axisFormat %L
  section Compute
  Forward pass            :0, 120
  Backward pass           :120, 360
  Optimizer step          :380, 400
  section Network (overlapped)
  All-reduce bucket A     :200, 290
  All-reduce bucket B     :290, 380
  section Exposed wait
  Waiting for last bucket :360, 380
```

**How to read it:** gradients are all-reduced in buckets during the backward pass, so most communication
hides behind compute. Only the part that outlasts the backward pass (here 20 ms of the 400 ms step) is
**exposed**, and that's what slows training. When the network is slower, or one link is degraded, the
exposed part grows, and every GPU waits. A **bucket** is a group of gradient tensors (about 25 MB by default in
PyTorch DDP) that's sent as soon as all its gradients are computed, instead of waiting for the whole backward pass.

**Core ideas.**

| Symptom | Likely cause | How to check |
|---|---|---|
| Scaling efficiency drops sharply past one node | Cross-node fabric not used (TCP fallback), wrong NIC | `NCCL_DEBUG=INFO` shows `NET/Socket` instead of `NET/IB` or the cloud plugin |
| Some steps much slower than others | Straggler: one slow GPU, NIC, or link | Per-rank step times. NCCL tests between pairs of nodes |
| Slow at certain times of day | Shared spine congestion, other jobs | Switch counters, ECN/PFC marks, job overlap |
| Good bandwidth on tests, poor in training | Communication not overlapped, too-small buckets | Profiler timeline (PyTorch profiler, Nsight Systems) |
| Hangs or timeouts | Firewall, MTU mismatch, broken link, version mismatch | NCCL timeout logs, `ibstat`, MTU on every hop |

```bash
# collective bus bandwidth across 4 nodes, 8 GPUs each (from nccl-tests)
mpirun -np 32 -H n1:8,n2:8,n3:8,n4:8 ./build/all_reduce_perf -b 1G -e 8G -f 2 -g 1
# raw RDMA bandwidth between two nodes on one NIC
ib_write_bw -d mlx5_0 --report_gbits n2
```

- **Overlap more:** larger or tuned DDP buckets, FSDP prefetching, and backward-forward overlap.
- **Send less:** bf16 gradients, gradient accumulation (fewer syncs per sample), hierarchical all-reduce
  (inside the node first, then across), and in-network reduction (SHARP).
- **Placement:** keep a job's nodes under the same spine or in the same rail group, with topology-aware
  scheduling (Section 11).

**Example: one bad cable in a 256-GPU job.** A job ran at 61% of its expected throughput. Per-rank step
times were uniform, so it wasn't a slow GPU, but every all-reduce took 2.3× longer than in benchmarks.
Pairwise `nccl-tests` between nodes found one node whose NIC 5 reached 140 Gb/s instead of 390. Its
port showed rising symbol errors from a damaged optical cable. Draining the node restored 97% of
expected throughput, and the cable was replaced the same day.

**Senior / FAANG best practice.** Run automated **pre-flight checks** before every large job (NCCL tests
across the allocated nodes, link error counters, GPU health), and exclude bad nodes automatically. Track
exposed communication time and per-rank step-time spread as standard training metrics. At big-tech scale,
straggler detection and automatic node exclusion run continuously during the job.

---

## Lecture 90 — Security in networked AI systems

**Why it matters.** AI systems expose valuable endpoints (model APIs that cost money per call), hold
sensitive data, and increasingly run agents that make outbound calls. The network is where you enforce
who can talk to what, and where you stop data from leaking out.

**In plain words.** Zero trust is a building where every door checks your badge, even inside, rather
than only the front door. Being in the lobby doesn't let you into the server room, and the mailroom
checks every outgoing package, not just incoming ones.

**Architecture: zero-trust network controls around a model service.**

```mermaid
flowchart LR
  U((Client)) -->|"TLS 1.3"| WAF["WAF + DDoS protection<br/>bot rules, size limits"]
  WAF --> GW["API gateway<br/>OAuth / API keys, quotas per tenant"]
  GW -->|"mTLS, identity-based"| API["Model API pods<br/>own service identity"]
  API -->|"mTLS, allowed by policy"| FS[(Feature store)]
  API -->|"private endpoint"| S3[(Model bucket)]
  API -->|"egress allow-list only"| EXT["Approved external APIs"]
  API -.x.-> NET(("Internet: denied by default"))
  TRAIN["Training fabric"] -.isolated, no route.-> API
  LOGS[(Flow logs + audit to SIEM)] -.-> GW & API
```

**How to read it:** clients pass DDoS protection, a WAF, and an API gateway that authenticates them and
enforces quotas. Inside, services talk only over mTLS with verified identities and explicit policies. Data
stores are reached through private endpoints. Outbound traffic is denied unless it's on an allow-list,
and the training fabric has no route to user-facing services at all. Flow logs and audits record
everything.

**Terms in this diagram.**
- **TLS 1.3**: the current version of the encryption protocol behind HTTPS.
- **Bot rules, size limits**: WAF rules that block automated abuse, and reject oversized requests such as giant
  prompts or images.
- **OAuth / API keys, quotas per tenant**: **OAuth** is the standard for granting apps access with expiring tokens.
  An **API key** is a long secret string identifying a client. A **quota** caps how much each **tenant** (customer
  or team) may use.
- **mTLS, identity-based**: mutual TLS. Both sides present certificates, so each service proves *who it is*, and
  policy allows calls by identity rather than by IP address. Service meshes such as Istio do this automatically.
- **Egress allow-list**: outbound connections are blocked except to a list of approved destinations.
- **Flow logs, SIEM**: **flow logs** record every network connection (source, destination, port, bytes). A **SIEM**
  (security information and event management system) is where security teams collect and search them.

**Core ideas.**

| Control | Purpose | Tools |
|---|---|---|
| Edge protection | Absorb floods, block abusive patterns | Cloud DDoS protection (Shield, Cloud Armor), CDN, WAF |
| Authentication and quotas | Stop unauthorized and runaway use of expensive endpoints | API gateway, OAuth, API keys with per-tenant rate limits |
| mTLS + service identity | Encrypt and authenticate service-to-service calls | Service mesh (Istio, Linkerd), SPIFFE/SPIRE |
| Segmentation | Limit lateral movement | Security groups, NetworkPolicies, separate VPCs per environment |
| Private connectivity | Keep data paths off the internet | VPC endpoints, Private Service Connect, PrivateLink |
| Egress control | Stop data exfiltration and command-and-control | Egress gateways, DNS and FQDN allow-lists, proxy |
| Visibility | Detect and investigate | VPC flow logs, mesh telemetry, SIEM |

- **Model APIs are expensive targets.** Stolen keys or unauthenticated endpoints get abused for free
  compute. Rate-limit by key and tenant, and alert on usage anomalies.
- **Agents and RAG need egress control.** A prompt-injected agent can be told to send data to an
  attacker's URL, so only allow outbound calls to approved tools and domains (Section 25).
- Isolate the **management plane** (BMCs, Kubernetes API, SSH). Reach it only through bastions or
  identity-aware proxies.

**Example: an internal endpoint that wasn't.** An embedding service was "internal only", but its
Kubernetes Service type had been set to `LoadBalancer` on a public subnet, giving it a public IP with no
authentication. Scanners found it within hours, and it served ~30 million requests to strangers in a week.
The fixes: an internal load-balancer annotation, a policy that blocks public LoadBalancers without
approval, authentication on every API, and an alert for new public IPs on the cluster.

**Senior / FAANG best practice.** Default deny everywhere: ingress, east-west, and egress, with
explicit, reviewed allow rules as code. Use workload identity (mTLS certificates tied to service
accounts) rather than IP-based trust. Continuously scan for unintended public exposure, and treat a
new public endpoint as a change that needs security review.

---

## Lecture 91 — Lab: configure a load balancer for an AI API

**Goal:** put NGINX in front of three replicas of a model API with uneven request costs, compare
round-robin with least-connections, add health checks, long timeouts, and per-client rate limits, and
measure the effect on tail latency.

**What you're building.**

```mermaid
flowchart LR
  LOAD["load.py<br/>200 requests, 20 concurrent,<br/>10% are slow"] --> NG["NGINX :8080<br/>least_conn, timeouts,<br/>limit_req, passive health"]
  NG --> A1["api1 :8000"]
  NG --> A2["api2 :8000"]
  NG --> A3["api3 :8000"]
```

**In plain words.** You build a tiny version of an inference front door, send it realistic, uneven
traffic, and see why the balancing algorithm matters.

**How to read the diagram:** `load.py` sends 200 requests, 20 at a time, and 10% of them are deliberately slow.
**NGINX**, a widely used web server and reverse proxy, listens on port 8080 and spreads them over three copies of
the API. `least_conn` is NGINX's "fewest active connections" algorithm. **Timeouts** cap how long it waits for a
backend. `limit_req` is its rate limiter. **Passive health** checking means NGINX stops sending to a backend after
real requests to it fail, without separate health probes.

### Step 1 — A model API with uneven request cost (`app.py`)

```python
import asyncio, os, random
from fastapi import FastAPI
app = FastAPI()
NAME = os.environ.get("NAME", "api")

@app.get("/healthz")
async def health():
    return {"ok": True}

@app.post("/generate")
async def generate(max_tokens: int = 50):
    await asyncio.sleep(max_tokens * 0.01 * random.uniform(0.8, 1.2))   # ~10 ms per token
    return {"replica": NAME, "tokens": max_tokens}
```

### Step 2 — Compose file and NGINX config

```yaml
# docker-compose.yml
services:
  api1: { build: ., environment: [NAME=api1] }
  api2: { build: ., environment: [NAME=api2] }
  api3: { build: ., environment: [NAME=api3] }
  lb:
    image: nginx:1.27
    ports: ["8080:8080"]
    volumes: ["./nginx.conf:/etc/nginx/nginx.conf:ro"]
    depends_on: [api1, api2, api3]
```

```nginx
# nginx.conf
events {}
http {
  limit_req_zone $binary_remote_addr zone=perclient:10m rate=50r/s;
  upstream model_api {
    least_conn;                                   # switch to round robin by removing this line
    server api1:8000 max_fails=3 fail_timeout=10s;
    server api2:8000 max_fails=3 fail_timeout=10s;
    server api3:8000 max_fails=3 fail_timeout=10s;
    keepalive 32;
  }
  server {
    listen 8080;
    client_max_body_size 1m;
    location / {
      limit_req zone=perclient burst=100 nodelay;
      limit_req_status 429;
      proxy_pass http://model_api;
      proxy_http_version 1.1;
      proxy_set_header Connection "";
      proxy_read_timeout 300s;                    # longer than the longest generation
      proxy_buffering off;                        # stream tokens as they come
      proxy_next_upstream error timeout http_502 http_503;
    }
  }
}
```

The Dockerfile is the one from Section 4, with `app.py` and
`CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]`.

### Step 3 — Generate uneven load (`load.py`)

```python
import asyncio, random, time, httpx, statistics
async def one(client, lat):
    tokens = 2000 if random.random() < 0.10 else 50          # 10% long generations
    t = time.perf_counter()
    r = await client.post("http://localhost:8080/generate", params={"max_tokens": tokens}, timeout=300)
    lat.append((time.perf_counter() - t, r.status_code, r.json().get("replica") if r.status_code == 200 else None))
async def main():
    lat = []
    async with httpx.AsyncClient() as c:
        sem = asyncio.Semaphore(20)
        async def run():
            async with sem: await one(c, lat)
        await asyncio.gather(*(run() for _ in range(200)))
    short = sorted(l for l, s, _ in lat if l < 5)
    print(f"short requests p50={statistics.median(short):.2f}s p99={short[int(len(short) * 0.99) - 1]:.2f}s")
    print({r: sum(1 for *_, x in lat if x == r) for r in ("api1", "api2", "api3")})
asyncio.run(main())
```

### Step 4 — Compare algorithms and test failure handling

```bash
docker compose up -d --build && python load.py           # least_conn
# remove "least_conn;" from nginx.conf, then:
docker compose restart lb && python load.py              # round robin
docker compose stop api2 && python load.py               # passive health checks route around it
```

**Expected results:**
- **Latency:** with round robin, the p99 of the *short* requests rises sharply, because short requests queue
  behind long ones on the same replica. With `least_conn`, the p99 of short requests stays much closer to
  their p50.
- **Replica down:** with `api2` stopped, requests still succeed. NGINX marks it failed and retries on the
  others.
- **Long requests:** they finish without a 504, because `proxy_read_timeout` is 300 s.
- **Rate limit:** sending more than 50 requests per second plus the burst from one client returns HTTP 429.

---

## FAANG deep-dive notes

**How big tech does it.** Hyperscalers run separate fabrics for front-end, AI back-end, and management,
each a Clos built from commodity switches and fully automated. AI back-ends are non-blocking and
rail-optimized, on InfiniBand or tuned RoCE (Meta has published running both at 24,000-GPU scale). Edge traffic
goes through global anycast load balancers, then regional L7 proxies, then model-aware local routers.
Zero-trust service identity (mTLS everywhere) and default-deny egress are the baseline. Every link's error
counters are monitored, and bad links are drained automatically.

**Staff review questions.**
- What is the back-end fabric's measured all-reduce bus bandwidth at full job scale, and how do we keep it there?
- How do we detect and exclude a degraded link or NIC before it slows a job?
- What routing policy does inference use, and what is the p99 under uneven request sizes?
- Which endpoints are reachable from the internet, and what egress is allowed from agent workloads?

**Interview question.** "Design the network for a 4,096-GPU training cluster."

**Typical system-design prompt:** *Design the networking for a new AI data hall: a 4,096-GPU training
cluster (512 nodes × 8 H100s) and an inference front end serving 50,000 requests per second.*

**1. Clarify first:** What are the largest job sizes, and will jobs span the whole cluster? InfiniBand or
Ethernet, and what are the team's operational skills? What storage bandwidth is needed for checkpoints? What
are the power and cooling limits for switches and optics? What are the multi-tenancy and isolation needs?

**2. Back-of-envelope sizing:**
- NICs: 512 nodes × 8 × 400 Gb/s = 4,096 back-end ports, ~1.6 Pb/s of injection bandwidth.
- Rail-optimized, non-blocking, with 64-port 400G switches: each leaf has 32 ports down and 32 up. Per rail,
  512 nodes ÷ 32 = 16 leaves. 8 rails × 16 = **128 leaves**. Uplinks: 128 × 32 = 4,096 ÷ 64 ports =
  **64 spines**.
- Optics and cables: ~4,096 node-to-leaf + 4,096 leaf-to-spine ≈ 8,200 links. With a ~0.1% annual
  failure rate per link, expect a failure every few weeks, so automate draining.
- Front end: 50,000 requests/s × ~5 KB ≈ 250 MB/s (2 Gb/s), which is small. Streaming connections dominate
  connection counts more than bandwidth.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Fabric | InfiniBand | RoCEv2 on Ethernet | InfiniBand for the least tuning at scale. RoCE when Ethernet skills and vendor choice matter |
| Topology | Rail-optimized | Plain fat tree | Rail-optimized for 8-GPU nodes running collectives |
| Oversubscription | 1:1 back-end | 2:1 to save cost | Non-blocking for training. Oversubscribe front-end and storage |
| Inference LB | Round robin | Load- and cache-aware | Load- or cache-aware for LLMs. Round robin only for uniform requests |
| Service security | IP allow-lists | mTLS identities | Identity-based mTLS. IPs change, identities don't |

**4. Follow-up questions with crisp answers:**
- *Why keep training traffic off the front-end network?* All-reduce bursts saturate links and would wreck
  user latency. Separate fabrics also isolate failures and attacks.
- *Why does gRPC need an L7 load balancer?* It multiplexes many requests over one HTTP/2 connection. An L4
  balancer pins the whole connection to one backend.
- *How do you know the fabric is healthy?* Acceptance tests per link, continuous error and congestion
  counters, and NCCL bus bandwidth tests before large jobs, with automatic exclusion of bad nodes.

**Debug this (common onsite question):** "A 512-GPU job runs 40% slower than last week. The GPUs and code are unchanged."
1. Compare per-rank step times: they're uniform, so it isn't a slow GPU. The NCCL all-reduce time is up 1.7×.
2. Run `nccl-tests` across the job's nodes, then pairwise. Two nodes show half the expected bandwidth on
   one rail.
3. Check switch and NIC counters: one leaf's uplinks show heavy ECN and PFC marks, and another job was
   scheduled onto the same spine group this week (congestion), plus one optic with rising errors.
4. Fix: drain the bad link, enable topology-aware placement so big jobs don't share spines, and add
   congestion counters to the job dashboard.

The lesson: in synchronous training, the slowest link sets the speed. Measure collectives directly,
and treat placement and link health as part of the training system.

**5. What separates senior from staff answers:** a senior engineer knows the technologies (leaf-spine,
RDMA, load-balancing algorithms) and configures them correctly. A staff engineer sizes the fabric from job
shapes, chooses technology by measured performance and team skills, designs isolation between fabrics, and
builds the operational loop: acceptance tests, counters, automated draining, topology-aware scheduling,
and model-aware routing with admission control at the edge.

**Red flags:**
- Training and user traffic sharing one oversubscribed network.
- Pods using TCP over the default CNI for multi-node training.
- Round robin for LLM traffic, or 60-second timeouts on streaming generation.
- "Internal" services with public IPs.
- No egress control for agents or notebooks.

---

## Quiz

<details><summary>1. What is oversubscription, and why must GPU fabrics avoid it?</summary>
It's the ratio of server-facing bandwidth to uplink bandwidth on a switch. All-reduce makes every node
send at full speed at the same time, so any oversubscription directly cuts per-GPU bandwidth and slows
training.
</details>

<details><summary>2. How does a training pod on Kubernetes get RDMA networking?</summary>
Through a secondary network interface attached with Multus and SR-IOV (often managed by the NVIDIA
Network Operator), connected to the GPU fabric. NCCL then uses `NET/IB` (or the cloud plugin) instead of TCP.
</details>

<details><summary>3. Compare InfiniBand and RoCEv2 in one sentence each.</summary>
InfiniBand is a purpose-built lossless RDMA fabric with built-in congestion handling and features like
SHARP. RoCEv2 runs RDMA over Ethernet, and needs PFC, ECN, and congestion-control tuning to be lossless.
</details>

<details><summary>4. Why is round robin a poor choice for LLM inference?</summary>
Requests vary hugely in cost (output length). Round robin ignores load, so long generations pile up on
some replicas and short requests queue behind them. Least outstanding requests or queue-aware routing
balances real load.
</details>

<details><summary>5. A 128-GPU job's all-reduce is 2× slower than benchmarks, but per-rank compute is uniform. What do you check?</summary>
Run NCCL tests across the nodes and pairwise to find a degraded NIC or link. Check link error counters
and congestion marks. Confirm NCCL is using the RDMA transport, and look for other jobs sharing the
spines.
</details>

<details><summary>6. Why is egress control especially important for AI agents?</summary>
A prompt-injected agent can be instructed to send data to an attacker. Allowing outbound calls only to
approved tools and domains blocks that exfiltration path.
</details>

<details><summary>7. Why do LLM streaming endpoints need longer load-balancer timeouts and no buffering?</summary>
Generations can last minutes. Default 60 s timeouts cut them off, and buffering holds back tokens instead
of streaming them to the user as they're generated.
</details>

<details><summary>8. Convert 400 Gb/s to GB/s, and compare it with NVLink 4 per GPU.</summary>
400 ÷ 8 = 50 GB/s. NVLink 4 gives ~900 GB/s per GPU, about 18× more, which is why tensor parallelism stays
inside a node.
</details>

## Failure modes
- Training traffic over oversubscribed or shared front-end networks.
- NCCL silently falling back to TCP sockets because RDMA isn't configured in pods.
- One degraded link or NIC slowing an entire synchronous job.
- MTU mismatches: small messages work, large transfers hang.
- Round-robin balancing of variable-cost requests, and L4 balancing of gRPC streams.
- Load-balancer timeouts shorter than generations, cutting off streamed answers.
- "Internal" endpoints exposed publicly, and unrestricted egress from agents and notebooks.

## Checklist
- [ ] You can draw a leaf-spine fabric and compute oversubscription
- [ ] You can explain the layers between two pods (VPC, CNI, overlay, policy) and how RDMA bypasses them
- [ ] You can compare InfiniBand, RoCE, and cloud GPU fabrics, and verify bandwidth with nccl-tests
- [ ] You can choose a load-balancing algorithm for uniform vs variable-cost inference
- [ ] You can find a network bottleneck in training from step-time and NCCL evidence
- [ ] Your AI services use mTLS, private endpoints, default-deny policies, and egress allow-lists
- [ ] You ran the NGINX lab and saw least_conn beat round robin for uneven requests
