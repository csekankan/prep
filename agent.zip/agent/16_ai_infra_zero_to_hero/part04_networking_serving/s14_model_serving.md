# Section 14 — Model Serving Basics

> Lectures 92–98 • Assessments: quiz, **Implement a Prediction API Contract** ([solution](../exercises/s14_prediction_contract.py))
> **After this section you can:** explain what changes between training and serving, choose REST or gRPC,
> serve models with TensorFlow Serving, TorchServe, and FastAPI, scale serving on Kubernetes, design a
> prediction API contract, and serve an image classifier end to end.
>
> Go deeper: [13 / Lab 44 — MLflow model registry](../../13_sovereign_ai_infra_course/04_serving_inference/lab44_mlflow_model_registry.md),
> [Lab 49 — Envoy gRPC load balancing](../../13_sovereign_ai_infra_course/04_serving_inference/lab49_envoy_grpc_lb.md),
> [Lab 50 — Blue-green model deployments](../../13_sovereign_ai_infra_course/04_serving_inference/lab50_blue_green_models.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 92 | From training to serving: the deployment gap | Serving optimizes latency, cost, and reliability. Training optimized accuracy |
| 93 | REST vs gRPC for model APIs | REST/JSON for reach and simplicity, gRPC/protobuf for internal speed and streaming |
| 94 | TensorFlow Serving for AI models | SavedModel versions in a directory, served with batching and hot reload |
| 95 | TorchServe for PyTorch models | `.mar` archives, handlers, a management API, and workers per model |
| 96 | Deploying models with FastAPI | Full control: load once, validate with Pydantic, async I/O, health endpoints |
| 97 | Scaling model serving with Kubernetes | Probes, resources, HPA on the right signal, PDBs, rollouts, and warm-up |
| 98 | Lab: serve an image classifier with FastAPI | A ResNet behind a validated API, containerized, load-tested, on Kubernetes |

```mermaid
flowchart LR
  REG[(Model registry<br/>version + signature)] --> PKG["Package<br/>SavedModel / .mar / container"]
  PKG --> SRV{"Serving runtime"}
  SRV --> TFS["TensorFlow Serving"]
  SRV --> TS["TorchServe"]
  SRV --> FA["FastAPI / custom"]
  TFS & TS & FA --> API["API contract<br/>REST or gRPC, schema, errors, limits"]
  API --> K8S["Kubernetes Deployment<br/>probes, HPA, PDB, rollout"]
  K8S --> CL((Clients))
  K8S --> MON["Metrics: latency, errors,<br/>throughput, saturation"]
```

**How to read it:** a model version from the registry is packaged in the format its serving runtime
expects. The runtime exposes the model behind an **API contract**: protocol, request and response schema,
error format, and limits. Kubernetes runs it with health probes, autoscaling, and safe rollouts, and
monitoring watches the four golden signals. The choice of runtime changes the packaging, not the overall
shape.

**Terms in this diagram.**
- **Version + signature**: the registry stores each model version with its **signature**, the names, types, and
  shapes of the inputs it expects and the outputs it returns (Section 9).
- **SavedModel / .mar / container**: **SavedModel** is TensorFlow's export folder format (Lecture 94). A **.mar**
  file is a TorchServe model archive (Lecture 95). A **container** image packages a custom server such as FastAPI
  (Lecture 96).
- **REST or gRPC**: the two common API styles, compared in Lecture 93.
- **Probes, HPA, PDB, rollout**: **probes** are Kubernetes health checks. The **HPA** (Horizontal Pod Autoscaler)
  adds and removes copies. A **PDB** (PodDisruptionBudget) keeps a minimum number running during maintenance. A
  **rollout** replaces old pods with new ones gradually (Lecture 97, and Section 5).
- **Latency, errors, throughput, saturation**: the **four golden signals** from Google's SRE book. Latency is time
  per request, errors is the failure rate, throughput is requests per second, and saturation is how full the
  resources are (GPU, queue, memory).

---

## Lecture 92 — From training to serving: the deployment gap

**Why it matters.** A model that scores well in a notebook can still fail in production. It might be too slow,
too large, crash on unexpected input, or behave differently because the features are computed differently.
The deployment gap is where most ML projects stall.

**In plain words.** Training is a chef perfecting a recipe in a test kitchen, taking as long as they
need. Serving is the same dish in a busy restaurant: hundreds of orders an hour, each in under ten
minutes, every plate identical, and a plan for when the oven breaks.

**Architecture: what changes from training to serving.**

```mermaid
flowchart LR
  subgraph TR["Training"]
    T1["Big batches, throughput"] --> T2["Hours to days, retries are fine"]
    T2 --> T3["Offline features from the warehouse"]
    T3 --> T4["Python, notebooks, latest libraries"]
  end
  subgraph SV["Serving"]
    S1["Single requests, latency p99"] --> S2["24x7, every error hurts users"]
    S2 --> S3["Online features, same logic"]
    S3 --> S4["Pinned image, small, scanned"]
  end
  TR -->|"the gap: latency, skew,<br/>packaging, reliability, cost"| SV
```

**How to read it:** each training habit has a serving counterpart. Throughput becomes latency, retries
become availability, offline features become online features (with the same logic, or the model is
skewed), and the notebook environment becomes a pinned, scanned image. Closing the gap means engineering
each pair.

In the diagram, **latency p99** is the time within which 99% of requests finish, so it describes the slowest 1%
that real users still feel. The **warehouse** is the analytics database training data is read from in bulk.
**Skew** (training-serving skew) is when the features computed at serving time differ from those used in
training, so the model silently gets worse. A **pinned** image fixes every library at an exact version, and a
**scanned** image has been checked for known security vulnerabilities (Section 4).

**Core ideas.**

| Gap | Symptom in production | How to close it |
|---|---|---|
| Latency | p99 too slow on real inputs | Budget per request, optimize the model (Section 15), batch, cache |
| Training-serving skew | Online accuracy below offline | Share feature code or a feature store, log online features and compare |
| Packaging | "Works on my machine" | Signature (inputs and outputs), pinned dependencies, container by digest |
| Robustness | Crashes on bad input | Validate the contract, set size limits, consistent errors |
| Operations | No idea it's broken | Health probes, golden-signal metrics, prediction logging, alerts |
| Cost | Expensive per prediction | Right-size hardware, autoscale, batch, quantize |

- **Model signature:** the exact input and output names, types, and shapes. Save it with the model
  (MLflow signature, TF SavedModel signature, TorchScript or ONNX), and test it in CI.
- **Online vs batch:** not every model needs an API. If predictions can be computed hours ahead, batch
  scoring (Section 15) is cheaper and simpler.

**Example: skew from a timezone.** A fraud model had 0.91 AUC offline and 0.78 online. The feature
"transactions in the last hour" was computed in UTC by the training pipeline and in local time by the
online service. For users in UTC−5, the window was off by five hours. Moving both to one shared feature
definition in the feature store brought online AUC to 0.90.

**Senior / FAANG best practice.** Define an SLO for every model service (for example, p99 < 100 ms, 99.9%
availability) before building it, and design back from that. Put feature definitions in one place used by
both training and serving. Log a sample of online inputs and predictions, so skew and drift can be measured
(Section 18).

---

## Lecture 93 — REST vs gRPC for model APIs

**Why it matters.** The protocol decides who can call the model easily, how much overhead each call
pays, and whether you can stream. Picking it wrong means rewriting clients later.

**In plain words.** REST with JSON is writing a letter in plain language that anyone can read. gRPC with
protobuf is a form in a shared, compact code both sides agreed on in advance. It's faster to fill and
process, but you need the codebook.

**Architecture: the same predict call in REST and gRPC.**

```mermaid
sequenceDiagram
  participant C as Client
  participant R as REST server
  participant G as gRPC server
  C->>R: POST /v1/predict, JSON text over HTTP/1.1 or 2
  R-->>C: 200 JSON
  Note over C,R: human-readable, curl-able, larger payloads, parse cost
  C->>G: Predict(PredictRequest), protobuf binary over HTTP/2
  G-->>C: PredictResponse
  Note over C,G: typed contract (.proto), small and fast, streaming, needs generated stubs
```

**How to read it:** both calls do the same work. REST sends readable JSON that any tool can call. gRPC
sends compact, typed binary messages defined in a `.proto` file, over HTTP/2, with built-in streaming,
deadlines, and generated client code.

In the diagram, **POST** is the HTTP method for sending data to a server, and `/v1/predict` is a versioned path.
`Predict(PredictRequest)` is a gRPC method call: `PredictRequest` and `PredictResponse` are the typed message
definitions from the `.proto` file. **HTTP/1.1** handles one request at a time per connection, while **HTTP/2** carries many requests
at once over one connection. **curl-able** means you can test it with the `curl` command-line tool. **Parse cost**
is the CPU time spent turning JSON text into numbers. **Protobuf** (Protocol Buffers) is Google's compact binary
format, and the `.proto` file is its schema. **Stubs** are client and server code generated from that schema, so
callers get typed functions instead of hand-built requests. A **deadline** is the time limit the caller sets, after
which gRPC cancels the call on both sides.

**Core ideas.**

| | REST + JSON | gRPC + protobuf |
|---|---|---|
| Contract | OpenAPI (optional, can drift) | `.proto` (required, code-generated) |
| Payload | Text. Large for tensors (a 224×224×3 float image is ~1.5 MB as JSON numbers) | Binary. ~600 KB raw floats, or send encoded JPEG bytes |
| Streaming | SSE or chunked responses (used by LLM APIs) | Native client, server, and bidirectional streams |
| Browser and partner reach | Universal | Needs gRPC-Web or a gateway |
| Load balancing | Any L7 or L4 | L7 only (one HTTP/2 connection carries many calls) |
| Typical use | Public APIs, partner integrations, simple services | Internal service-to-service calls, high QPS, low latency |

```protobuf
syntax = "proto3";
service Classifier { rpc Predict (PredictRequest) returns (PredictResponse); }
message PredictRequest  { bytes image_jpeg = 1; int32 top_k = 2; }
message PredictResponse { repeated Label labels = 1; string model_version = 2; }
message Label { string name = 1; float score = 2; }
```

- **Send compact inputs.** Encoded image bytes (base64 in JSON, or `bytes` in protobuf) instead of
  arrays of numbers, and token IDs instead of huge text for internal hops.
- Many serving runtimes (Triton, TF Serving, KServe's v2 protocol) support **both** protocols, so you can
  expose REST at the edge and gRPC internally.

**Example: shrinking the payload.** An image API received JSON arrays of 150,528 floats per image,
about 1.6 MB per request, and spent 35 ms parsing JSON per call. Switching to base64-encoded JPEGs
(~40 KB) cut the payload by 40× and parse time to under 2 ms. Moving internal callers to gRPC removed
another ~3 ms per hop.

**Senior / FAANG best practice.** Big tech uses typed IDL contracts (protobuf, Thrift) internally,
with code generation, versioned packages, and deadline propagation. REST and JSON gateways sit at the edge
for external clients. Whatever the protocol, the contract is reviewed like code and checked for breaking
changes in CI (see the assessment).

---

## Lecture 94 — TensorFlow Serving for AI models

**Why it matters.** TF Serving is a mature, high-performance server for TensorFlow and Keras models,
with versioning, batching, and hot reload built in. Many production stacks still run it.

**In plain words.** TF Serving is a vending machine that watches a shelf. Put a new numbered tray (model
version) on the shelf, and it starts selling from the new tray without closing. If the new tray is bad,
put the old number back.

**Architecture: TF Serving's version directory and serving path.**

```mermaid
flowchart LR
  subgraph STORE["Model base path, local or s3/gs"]
    V1["/models/resnet/1/saved_model.pb"]
    V2["/models/resnet/2/saved_model.pb"]
  end
  STORE -->|"file system poll"| MGR["Version manager<br/>policy: latest or specific"]
  MGR --> SERV["Servable: loaded SavedModel"]
  SERV --> BATCH["Batching scheduler<br/>max_batch_size, timeout"]
  REST["REST :8501"] --> BATCH
  GRPC["gRPC :8500"] --> BATCH
```

**How to read it:** you export numbered SavedModel directories under one base path. TF Serving polls it,
loads new versions according to the version policy, and unloads old ones. REST (port 8501) and gRPC
(port 8500) requests go through an optional batching scheduler that groups requests for GPU efficiency.

In the diagram, the **base path** is the folder (local disk, or an `s3://` or `gs://` bucket) holding one numbered
subfolder per version. **File system poll** means TF Serving re-checks that folder every few seconds for new
numbers. The **version manager** applies the **policy**: serve only the latest version, or specific pinned ones. A
**servable** is TF Serving's name for a loaded, ready-to-call model. `max_batch_size` is the most requests merged
into one GPU call, and the **timeout** (`batch_timeout_micros`) is how long it waits to fill a batch before running a
partial one.

**Core ideas.**

```bash
# export: model.export("models/resnet/2")  (Keras 3)  or tf.saved_model.save(model, "models/resnet/2")
docker run -p 8501:8501 -p 8500:8500 \
  -v "$PWD/models/resnet:/models/resnet" -e MODEL_NAME=resnet tensorflow/serving:2.17.0
curl -s localhost:8501/v1/models/resnet                       # version status
curl -s -X POST localhost:8501/v1/models/resnet:predict \
  -d '{"instances": [[...224x224x3 floats...]]}'
saved_model_cli show --dir models/resnet/2 --all              # inspect the signature
```

| Feature | How |
|---|---|
| Versions | Numbered subdirectories. `model_version_policy` (latest N, specific, all) in `models.config` |
| Multiple models | `--model_config_file` lists models and paths |
| Batching | `--enable_batching --batching_parameters_file` (max_batch_size, batch_timeout_micros) |
| GPU | `tensorflow/serving:<ver>-gpu` image |
| Warm-up | `assets.extra/tf_serving_warmup_requests` runs sample requests at load time, so the first real request isn't slow |

**Example: instant rollback.** Version 7 of a ranking model had a preprocessing bug. Because the config
pinned `specific { versions: 6 }` for the stable route and the label `canary` pointed at 7, rollback was one
config change: point `canary` back at 6. TF Serving reloaded the config in seconds, with no container
restart.

**Senior / FAANG best practice.** Always ship warm-up requests, so a new version loads its graphs before
traffic arrives. Tune batching against your latency SLO (start with a timeout of a few milliseconds). Pin the
serving image version and test the SavedModel signature in CI. For new projects, compare with Triton
(Section 15), which serves TensorFlow, PyTorch, ONNX, and TensorRT models from one server.

---

## Lecture 95 — TorchServe for PyTorch models

**Why it matters.** TorchServe packages PyTorch models with their preprocessing code and serves them with
worker management, batching, metrics, and a management API, without writing a server yourself.

**In plain words.** A `.mar` file is a lunchbox: the model weights, the recipe for preparing input (the
handler), and any extra files, all packed together. TorchServe is the cafeteria that opens lunchboxes
and serves them through several counters (workers).

**Architecture: TorchServe components.**

```mermaid
flowchart LR
  MAR["model.mar<br/>weights + handler.py + extras"] --> STORE[(Model store)]
  STORE --> FE["Frontend (Java)<br/>inference :8080, management :8081, metrics :8082"]
  FE --> W1["Worker 1: Python handler<br/>preprocess, inference, postprocess"]
  FE --> W2["Worker 2"]
  FE --> BQ["Per-model batch queue<br/>batch_size, max_batch_delay"]
  BQ --> W1 & W2
```

**How to read it:** you archive the model with `torch-model-archiver`. The TorchServe frontend receives
requests on the inference port, optionally batches them per model, and sends them to Python worker
processes running your handler. A separate management port registers, scales, and unregisters models at
runtime. Metrics go to a third port.

In the diagram, `handler.py` is your Python class with `preprocess`, `inference`, and `postprocess` methods, and
**extras** are additional files it needs, such as a label list. The **model store** is the folder of `.mar` files.
The **frontend** is TorchServe's Java process that accepts connections and routes work. **Workers** are separate
Python processes, each holding one copy of the model. `batch_size` is the most requests merged together, and
`max_batch_delay` is the longest wait, in milliseconds, to fill a batch.

**Core ideas.**

```python
# handler.py: a custom handler for image classification
from ts.torch_handler.base_handler import BaseHandler
import torch, io
from PIL import Image
from torchvision import transforms
TF = transforms.Compose([transforms.Resize(256), transforms.CenterCrop(224), transforms.ToTensor(),
                         transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
class ImageHandler(BaseHandler):
    def preprocess(self, data):
        return torch.stack([TF(Image.open(io.BytesIO(r.get("data") or r.get("body"))).convert("RGB")) for r in data])
    def postprocess(self, out):
        p = out.softmax(1).topk(3)
        return [[{"class": int(i), "score": float(s)} for s, i in zip(ps, ix)] for ps, ix in zip(p.values, p.indices)]
```

```bash
torch-model-archiver --model-name resnet --version 1.0 --serialized-file resnet18.pt \
  --handler handler.py --export-path model_store
torchserve --start --model-store model_store --models resnet=resnet.mar --disable-token-auth
curl -X POST localhost:8080/predictions/resnet -T kitten.jpg
curl -X PUT "localhost:8081/models/resnet?min_worker=2&max_worker=4"     # scale workers
```

- Batching is set per model (`batch_size`, `max_batch_delay`). The handler receives a list of requests.
- Recent versions require **token authentication** on the management API by default. Keep it on in
  production, and never expose port 8081 publicly (it can load arbitrary models).
- TorchServe is in limited maintenance upstream. For new LLM work, teams use vLLM or Triton, but the
  handler pattern (preprocess, infer, postprocess) carries over everywhere.

**Example: a worker per GPU.** A team ran 4 GPUs with the default worker settings and saw only GPU 0
busy. Setting `min_worker=4` (TorchServe assigns workers round-robin across GPUs) and enabling batching
(`batch_size=16, max_batch_delay=10`) raised throughput from 220 to 1,450 images per second.

**Senior / FAANG best practice.** Keep preprocessing in the versioned handler, and test it with the same
golden inputs used in training. Lock down the management API. Export metrics to Prometheus. Pin
TorchServe and PyTorch versions together. Big serving teams wrap whichever runtime they use in a standard
platform contract, so models can move between runtimes without clients noticing.

---

## Lecture 96 — Deploying models with FastAPI

**Why it matters.** FastAPI is the most common way to serve custom models, preprocessing pipelines, and
model ensembles. It gives you full control, and full responsibility for doing it correctly.

**In plain words.** Serving runtimes are restaurant chains with fixed menus. FastAPI is your own kitchen:
cook anything, but you install the fire alarm, check every order, and decide how many cooks to hire.

**Architecture: a production-shaped FastAPI model service.**

```mermaid
flowchart TB
  REQ["HTTP request"] --> MW["Middleware: request ID,<br/>timing, size limit"]
  MW --> VAL["Pydantic validation<br/>422 / 400 with field errors"]
  VAL --> PRE["Preprocess (CPU)"]
  PRE --> INF["Inference in a thread pool<br/>or batching queue"]
  INF --> POST["Postprocess + response model"]
  LIFE["lifespan: load model once,<br/>warm up, then set ready"] -.-> INF
  HZ["/healthz liveness, /readyz readiness"] -.-> LIFE
  POST --> METRICS["/metrics: latency, count, errors"]
```

**How to read it:** the model loads **once** at startup (lifespan), runs a warm-up, then reports ready.
Each request passes middleware (request ID, timing, size limits), then Pydantic validation, then
preprocessing and inference. Blocking inference runs in a thread pool, so the event loop keeps accepting
requests. Health, readiness, and metrics endpoints let Kubernetes and Prometheus manage the service.

**Terms in this diagram.**
- **Middleware**: code that runs around every request. Here it attaches a unique **request ID** for tracing logs,
  measures timing, and rejects bodies over a size limit.
- **Pydantic validation, 422 / 400**: Pydantic is the Python library FastAPI uses to check request fields against
  declared types. A bad field returns HTTP **422** (unprocessable entity), and other malformed requests return
  **400** (bad request), each with a message naming the field.
- **Thread pool, event loop**: FastAPI's **event loop** is a single thread juggling many connections. Model
  inference blocks for a long time, so it's handed to a **thread pool** (or a **batching queue**) to keep the loop
  free.
- **Response model**: the declared shape of the output, so every response has the same fields.
- **Lifespan**: FastAPI's startup and shutdown hook, where the model loads once and runs a **warm-up** request
  (the first calls are slow while GPU kernels and memory initialize).
- **/healthz liveness, /readyz readiness**: **liveness** answers "is the process alive?", and failing it restarts
  the pod. **Readiness** answers "can it serve now?", and failing it only removes the pod from traffic (Section 5,
  entry A5).
- **/metrics**: the endpoint Prometheus scrapes for counters and latency histograms (Section 16).

**Core ideas.**

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field, conlist
import joblib

STATE = {}
@asynccontextmanager
async def lifespan(app):
    STATE["model"] = joblib.load("model.joblib")       # load once, not per request
    STATE["model"].predict([[5.1, 3.5, 1.4, 0.2]])     # warm-up
    STATE["ready"] = True
    yield
app = FastAPI(lifespan=lifespan)

class Instance(BaseModel):
    sepal_length: float = Field(ge=0, le=50)
    sepal_width: float = Field(ge=0, le=50)
    petal_length: float = Field(ge=0, le=50)
    petal_width: float = Field(ge=0, le=50)
class PredictRequest(BaseModel):
    instances: conlist(Instance, min_length=1, max_length=32)

@app.post("/v1/predict")
async def predict(req: PredictRequest):
    X = [[i.sepal_length, i.sepal_width, i.petal_length, i.petal_width] for i in req.instances]
    y = await run_in_threadpool(STATE["model"].predict, X)
    return {"predictions": y.tolist(), "model_version": "1.4.0"}
```

| Pitfall | Fix |
|---|---|
| Loading the model inside the handler | Load in `lifespan`, keep in app state |
| `async def` calling blocking `model.predict` | `run_in_threadpool`, or a plain `def` endpoint (FastAPI runs those in a pool) |
| One process using one CPU core | Multiple Uvicorn workers or replicas. On GPU, usually 1 worker per GPU plus batching |
| Readiness true before the model loads | Separate `/readyz` that checks model state |
| Unbounded input sizes | Pydantic limits plus a body-size limit at the proxy |

**Example: the event loop that froze.** A FastAPI service with an `async def` endpoint called a 40 ms
CPU model directly. Under load, health checks timed out (the loop was blocked), Kubernetes restarted
pods, and the outage spread. Moving inference to `run_in_threadpool` and running 4 workers per pod fixed
both the throughput and the false restarts.

**Senior / FAANG best practice.** Standardize a service template (lifespan loading, validation, request
IDs, structured logs, metrics, probes, graceful shutdown) so every model service behaves the same in
operations. Generate the OpenAPI contract from the Pydantic models, and check it for breaking changes in CI.
For GPU models at scale, use a runtime with dynamic batching (Triton, vLLM) behind FastAPI, rather than
inference inside FastAPI.

---

## Lecture 97 — Scaling model serving with Kubernetes

**Why it matters.** Kubernetes can keep model services healthy and sized to demand, but only if probes,
resources, autoscaling signals, and rollouts are configured for how models actually behave: slow to
start, heavy in memory, and variable in cost.

**In plain words.** Kubernetes is a restaurant manager. Probes are the manager checking that each cook is
awake (liveness) and actually ready to take orders (readiness). Autoscaling is calling in more cooks when
the queue grows. A disruption budget means never sending everyone home at once.

**Architecture: a production model Deployment.**

```mermaid
flowchart TB
  ING["Ingress / Gateway"] --> SVC["Service"]
  SVC --> P1["Pod: model server<br/>requests = limits for memory<br/>GPU: nvidia.com/gpu 1"]
  SVC --> P2["Pod"]
  SVC --> P3["Pod (starting)<br/>startupProbe while model loads,<br/>not in Service yet"]
  HPA["HPA / KEDA<br/>target: in-flight requests or queue,<br/>not just CPU"] --> DEP["Deployment<br/>maxUnavailable 0, maxSurge 1"]
  DEP --> P1 & P2 & P3
  PDB["PodDisruptionBudget<br/>minAvailable 2"] -.-> P1 & P2
  PROM[(Prometheus)] --> HPA
```

**How to read it:** the Service sends traffic only to pods whose readiness probe passes. A starting pod
is protected by a startup probe while it loads the model, so it isn't killed for being slow. The
autoscaler scales on a signal that tracks load (in-flight requests, queue depth, or GPU utilization), and the
Deployment rolls out new versions without dropping capacity. The PodDisruptionBudget keeps enough
replicas running during node maintenance.

**Terms in this diagram.**
- **Ingress / Gateway, Service**: the Ingress or Gateway API brings outside HTTP traffic into the cluster, and the
  Service is the stable address that spreads it across ready pods (Section 5, entries D1–D4).
- **Requests = limits for memory**: setting the memory request equal to the limit, so the scheduler reserves all
  the memory the pod may use, and the pod isn't killed under node memory pressure.
- **nvidia.com/gpu 1**: the resource name that asks the NVIDIA device plugin for one whole GPU (Section 5, entry
  H4).
- **startupProbe**: a probe that only runs while the container starts. Liveness checks wait until it passes, which
  gives slow model loads time to finish.
- **HPA / KEDA, in-flight requests**: **KEDA** (Kubernetes Event-Driven Autoscaling) extends the HPA to scale on
  external metrics such as queue length. **In-flight requests** are those currently being processed. CPU is often
  a poor signal because GPU servers are busy even at low CPU.
- **maxUnavailable 0, maxSurge 1**: rollout settings. Never take an old pod away before a new one is ready, and
  add at most one extra pod at a time.
- **minAvailable 2**: the PodDisruptionBudget lets voluntary evictions (node drains, upgrades) proceed only while
  at least 2 pods stay up.

**Core ideas.**

```yaml
containers:
- name: model
  image: registry.example.com/classifier@sha256:...
  resources:
    requests: { cpu: "2", memory: 4Gi }
    limits:   { memory: 4Gi }                       # memory request = limit, avoid OOM surprises
  startupProbe:   { httpGet: { path: /readyz, port: 8000 }, periodSeconds: 5, failureThreshold: 60 }  # up to 5 min to load
  readinessProbe: { httpGet: { path: /readyz, port: 8000 }, periodSeconds: 5 }
  livenessProbe:  { httpGet: { path: /healthz, port: 8000 }, periodSeconds: 10, failureThreshold: 3 }
  lifecycle: { preStop: { exec: { command: ["sleep", "15"] } } }   # let the LB drain
terminationGracePeriodSeconds: 60
```

| Signal for autoscaling | Good for | Caveat |
|---|---|---|
| CPU utilization | CPU models | Misleading for GPU and I/O-bound services |
| In-flight requests / RPS per pod | Most APIs | Needs a custom-metrics adapter or KEDA |
| Queue depth / batch fill | Batching runtimes, LLMs | The best latency predictor for GPU serving |
| GPU utilization (DCGM) | GPU services | Saturates near 100%, so it scales late |

- **Cold start** can be minutes for large models: image pull plus weight download plus GPU load. Mitigate
  with pre-pulled images, weights on local NVMe or a fast cache, a minimum replica count, and scaling
  before you need it.
- **Rollouts:** `maxUnavailable: 0` with readiness gating, or canary via Argo Rollouts (Section 10).
  KServe packages all of this (InferenceService, autoscaling, canary) for model serving.

**Example: liveness probes killing healthy pods.** A 7 GB model took 140 s to load, but the liveness
probe started after 30 s and failed three times. Kubernetes restarted the pod forever (CrashLoopBackOff)
during a scale-up, at peak traffic. Adding a `startupProbe` with a 5-minute budget, and pre-caching
weights on nodes, cut startup to 45 s and removed the restart loop.

**Senior / FAANG best practice.** Scale on the signal that predicts latency, and keep enough warm
headroom (minimum replicas, spare capacity) for traffic spikes faster than cold start. Use separate probes
for liveness, readiness, and startup, and never make liveness depend on downstream services, or one
database blip restarts your entire fleet. Load-test every new model version for its maximum sustainable
RPS per pod, and set autoscaling targets from that number.

---

## Lecture 98 — Lab: serve an image classifier with FastAPI

**Goal:** serve a pretrained ResNet-18 behind a validated FastAPI contract, containerize it, load-test it to
find the maximum RPS per pod, and deploy it on Kubernetes with probes and autoscaling.

**What you're building.**

```mermaid
flowchart LR
  IMG["kitten.jpg"] -->|"POST /v1/classify multipart"| API["FastAPI<br/>validate type and size, top_k"]
  API --> PRE["resize 256, crop 224, normalize"]
  PRE --> M["ResNet-18 (torchvision),<br/>eval mode, inference_mode"]
  M --> RESP["top-k labels + model version"]
  API --> K["Kubernetes: Deployment,<br/>probes, HPA"]
```

**In plain words.** You build a small, real model service, the same shape as production ones, then
measure how much traffic one copy can handle.

**How to read the diagram:** the client uploads an image as **multipart** form data (the standard HTTP format
for file uploads). The API checks the file type, its size, and the `top_k` parameter (how many top labels to
return). Preprocessing **resizes** the shorter side to 256 pixels, **crops** the center 224 by 224, and
**normalizes** the pixel values with the same mean and standard deviation used in training. **ResNet-18** is a
small, standard image classifier from `torchvision`. **Eval mode** switches off training-only behavior such as
dropout, and `inference_mode` turns off gradient tracking to save memory and time. The response returns the
labels and the model version, so every prediction is traceable.

### Step 1 — The service (`app.py`)

```python
import io, time
from contextlib import asynccontextmanager
import torch
from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.concurrency import run_in_threadpool
from PIL import Image, UnidentifiedImageError
from torchvision.models import resnet18, ResNet18_Weights

MAX_BYTES = 5 * 1024 * 1024
STATE = {"ready": False}

@asynccontextmanager
async def lifespan(app):
    w = ResNet18_Weights.DEFAULT
    STATE.update(model=resnet18(weights=w).eval(), tf=w.transforms(), labels=w.meta["categories"])
    with torch.inference_mode():
        STATE["model"](torch.zeros(1, 3, 224, 224))     # warm-up
    torch.set_num_threads(2)
    STATE["ready"] = True
    yield

app = FastAPI(title="image-classifier", version="1.0.0", lifespan=lifespan)

@app.get("/healthz")
def healthz(): return {"ok": True}

@app.get("/readyz")
def readyz():
    if not STATE["ready"]: raise HTTPException(503, "loading")
    return {"ready": True}

def infer(img, k):
    with torch.inference_mode():
        p = STATE["model"](STATE["tf"](img).unsqueeze(0)).softmax(1)[0].topk(k)
    return [{"label": STATE["labels"][i], "score": round(float(s), 4)} for s, i in zip(p.values, p.indices)]

@app.post("/v1/classify")
async def classify(file: UploadFile = File(...), top_k: int = Query(3, ge=1, le=10)):
    if file.content_type not in ("image/jpeg", "image/png"):
        raise HTTPException(415, "only image/jpeg or image/png")
    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "image larger than 5 MB")
    try:
        img = Image.open(io.BytesIO(data)).convert("RGB")
    except UnidentifiedImageError:
        raise HTTPException(400, "not a valid image")
    t = time.perf_counter()
    labels = await run_in_threadpool(infer, img, top_k)
    return {"labels": labels, "model": "resnet18-imagenet1k-v1", "latency_ms": round((time.perf_counter() - t) * 1000, 1)}
```

### Step 2 — Run, call, and test the contract

```bash
pip install fastapi==0.115.* uvicorn[standard] python-multipart torch torchvision pillow
uvicorn app:app --port 8000 --workers 1
curl -s -F "file=@kitten.jpg;type=image/jpeg" "localhost:8000/v1/classify?top_k=3"
curl -s -o /dev/null -w "%{http_code}\n" -F "file=@notes.txt;type=text/plain" localhost:8000/v1/classify   # 415
curl -s -o /dev/null -w "%{http_code}\n" -F "file=@kitten.jpg;type=image/jpeg" "localhost:8000/v1/classify?top_k=99"  # 422
```

### Step 3 — Containerize and load-test

```dockerfile
FROM python:3.12-slim
RUN pip install --no-cache-dir fastapi==0.115.* "uvicorn[standard]" python-multipart pillow \
    torch torchvision --index-url https://download.pytorch.org/whl/cpu --extra-index-url https://pypi.org/simple
WORKDIR /app
COPY app.py .
RUN python -c "from torchvision.models import resnet18, ResNet18_Weights; resnet18(weights=ResNet18_Weights.DEFAULT)"
USER 1000
CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]
```

```bash
docker build -t classifier:1.0 . && docker run -d -p 8000:8000 --cpus 2 classifier:1.0
# load test: hey or locust. Find the RPS where p99 crosses your SLO
hey -n 2000 -c 8 -m POST -T "multipart/form-data; boundary=X" -D body.bin http://localhost:8000/v1/classify
```

The weights are downloaded at build time, so pods don't download them on every start.

### Step 4 — Deploy on Kubernetes with probes and autoscaling

```bash
kubectl create deployment classifier --image=classifier:1.0 --replicas=2 --port=8000
kubectl set resources deploy/classifier --requests=cpu=2,memory=2Gi --limits=memory=2Gi
kubectl patch deploy classifier --type=json -p='[
 {"op":"add","path":"/spec/template/spec/containers/0/readinessProbe","value":{"httpGet":{"path":"/readyz","port":8000},"periodSeconds":5}},
 {"op":"add","path":"/spec/template/spec/containers/0/startupProbe","value":{"httpGet":{"path":"/readyz","port":8000},"periodSeconds":5,"failureThreshold":36}}]'
kubectl expose deploy classifier --port 80 --target-port 8000
kubectl autoscale deploy classifier --cpu-percent=60 --min=2 --max=6
```

**Expected results:**
- `kitten.jpg` returns labels such as `tabby` or `tiger cat` with scores. Wrong types return 415, and
  `top_k=99` returns 422.
- CPU latency is roughly 20–60 ms per image on 2 cores. The load test shows a knee, typically ~30–80 RPS per
  2-CPU pod, where p99 rises sharply. That number sets your HPA target.
- Pods become Ready only after the model loads. Under load, the HPA scales from 2 toward 6 replicas.

---

## Assessment — Implement a prediction API contract

**Task:** design and implement a versioned prediction API that:
1. validates every input field (type, range, required), reports *all* field errors in one response, and
   enforces limits on body size and batch size;
2. returns a consistent error shape and correct status codes (400, 413, 415, 404, 503);
3. includes the model version and request ID in every response;
4. separates liveness from readiness, and publishes its schema;
5. detects breaking changes between schema versions, so CI can block them.

**Run the reference solution:**

```bash
python3 exercises/s14_prediction_contract.py              # 15 contract and compatibility checks
python3 exercises/s14_prediction_contract.py --serve 8000 # then curl it
curl -s -X POST localhost:8000/v1/predict -H 'Content-Type: application/json' \
  -d '{"instances":[{"sepal_length":5.1,"sepal_width":3.5,"petal_length":1.4,"petal_width":-1}]}'
```

**What a good contract looks like.**

| Element | Reference choice | Why |
|---|---|---|
| Versioning | `/v1/` in the path, `schema_version` in model metadata | Clients pin a major version. Breaking changes need `/v2` |
| Request | `{"instances": [...]}`, max 32, body max 64 KB | Batch-friendly and bounded |
| Response | `predictions`, `model {name, version}`, `request_id`, `latency_ms` | Traceable and debuggable |
| Errors | `{"error": {code, message, details[{field, issue}]}, request_id}` | One shape for clients to parse, every problem listed |
| Status codes | 400 invalid, 413 too large, 415 wrong type, 404 route, 503 not ready | Clients and load balancers react correctly (retry only 503) |
| Health | `/healthz` (process alive), `/readyz` (model loaded) | Kubernetes restarts on liveness, and routes on readiness |
| Compatibility | Adding optional fields is safe. Removing, retyping, requiring, or narrowing is breaking | Enforced in CI with `check_compat` |

**Expected output:** the demo prints 15 PASS lines, including the three breaking changes found between v1
and the candidate v2 schema.

---

## FAANG deep-dive notes

**How big tech does it.** Model serving is a platform: teams register a model with a signature in the
registry, choose a runtime from a supported set, and get a standard service with a typed contract (protobuf
internally), autoscaling, canary rollouts, request logging, and golden-signal dashboards. Contracts are
versioned and checked for breaking changes in CI. Feature computation is shared between training and
serving to prevent skew. Capacity is set from load tests of each model version (maximum RPS per replica at
the latency SLO).

**Staff review questions.**
- What is the latency SLO, and what was the maximum RPS per replica at that SLO in the load test?
- How is training-serving skew prevented and measured?
- What happens on cold start during a traffic spike?
- Which contract changes are breaking, and what enforces that?

**Interview question.** "Design a model serving platform for 200 models across 30 teams."

**Typical system-design prompt:** *Design an image classification API for a photo-sharing app:
20,000 images per second at peak, p99 latency under 150 ms, with a new model version every two weeks.*

**1. Clarify first:** Real-time or asynchronous (can tagging lag by seconds)? What are the image sizes and
formats? Is GPU available? Is accuracy or cost the priority? Is the API public or internal? Does a fallback model
exist?

**2. Back-of-envelope sizing:**
- On a GPU with batching (TensorRT ResNet-50 on a T4), ~2,000 images per second at batch 32, so ~10 GPUs at
  peak, ~15 with 50% headroom, spread over 3 zones.
- Bandwidth: 20,000/s × 200 KB = 4 GB/s (32 Gb/s) of ingress, so decode and resize near the edge or on the
  pod.
- Preprocessing (JPEG decode) costs ~2–5 ms of CPU per image, so 20,000/s needs ~60–100 CPU cores, or GPU
  decoding (DALI or nvJPEG).
- Latency: network 20 ms + decode 5 ms + batch wait ≤ 10 ms + inference 15 ms ≈ 50 ms, well under the
  150 ms p99.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Runtime | FastAPI + PyTorch | Triton / TF Serving | A runtime with dynamic batching for GPU throughput. FastAPI for custom logic |
| Protocol | REST + JSON | gRPC + protobuf | REST at the edge, gRPC internally |
| Online vs async | Synchronous API | Queue + workers | Async if the product tolerates delay. Much cheaper and more resilient |
| Autoscaling signal | CPU | Queue depth or in-flight requests | Queue depth for GPU and batching services |
| Rollout | All at once | Canary with metric gates | Always canary model changes |

**4. Follow-up questions with crisp answers:**
- *Why separate liveness and readiness?* Liveness restarts a stuck process. Readiness keeps traffic off a
  pod still loading its model. Mixing them causes restart loops or traffic to cold pods.
- *How do you change the API without breaking clients?* Add optional fields only. Breaking changes go to
  `/v2`, run side by side, with a deprecation period and usage tracking.
- *What does a 503 mean to a client?* Temporarily unavailable, so retry with backoff (on another
  replica). A 400 means fix the request, so never retry it.

**Debug this (common onsite question):** "After deploying a new model version, error rates are fine, but p99 latency doubled, and only on some pods."
1. Compare pods: the slow ones were scheduled on older nodes without AVX-512, or on a different GPU type.
2. Check the new version: it uses a larger input size (384 instead of 224), so roughly 3× the compute.
   The load-test number used for the HPA target is from the old version.
3. Check batching and threads: the new image sets `torch.set_num_threads` to the node's core count, so pods
   on large nodes oversubscribe CPUs.
4. Fix: pin the node type with affinity, re-run the load test and update the HPA target, and cap threads to
   match the CPU request.

The lesson: every model version is a new performance profile. Load-test it, and set capacity from
the results, not from the previous version.

**5. What separates senior from staff answers:** a senior engineer builds a correct, validated, observable
model service with good probes and autoscaling. A staff engineer designs the serving *platform*: standard
contracts and compatibility checks, runtime choices per workload, capacity from load tests per version,
skew prevention through shared features, and rollout gates. Teams ship models without reinventing serving.

**Red flags:**
- Loading the model per request.
- Blocking inference on the async event loop.
- One probe used for both liveness and readiness.
- Autoscaling GPU services on CPU.
- No input limits.
- Errors in different shapes from different endpoints.
- API changes without compatibility checks.

---

## Quiz

<details><summary>1. Name three things that change between training and serving.</summary>
Throughput becomes per-request latency, batch jobs become 24×7 availability, and offline features become
online features computed the same way (or skew appears). Notebooks become pinned, scanned containers.
</details>

<details><summary>2. When do you choose gRPC over REST?</summary>
For internal service-to-service calls that need low overhead, typed contracts, streaming, and
deadlines. Use REST and JSON for public, browser, and partner-facing APIs.
</details>

<details><summary>3. How does TensorFlow Serving roll out a new version?</summary>
You add a new numbered SavedModel directory. TF Serving polls the base path and loads it according to the
version policy. Labels or a specific-version policy allow canaries and instant rollback.
</details>

<details><summary>4. What is in a TorchServe .mar file?</summary>
The serialized model (weights), the handler code (preprocess, inference, postprocess), and extra files
such as label maps, packaged with `torch-model-archiver`.
</details>

<details><summary>5. Why can an async FastAPI endpoint calling model.predict() hurt the whole service?</summary>
Blocking calls freeze the event loop, so no other request (including health checks) is served. Use
`run_in_threadpool`, a sync endpoint, or a batching runtime.
</details>

<details><summary>6. What does a startupProbe protect against?</summary>
Slow model loading being mistaken for a dead process. It gives the container time to load before the
liveness probe can restart it.
</details>

<details><summary>7. Which schema changes are breaking for a prediction API?</summary>
Removing a field, changing a field's type, making a field required, and narrowing an allowed range.
Adding an optional field is safe.
</details>

<details><summary>8. Why autoscale GPU model servers on queue depth rather than CPU?</summary>
CPU usage doesn't track GPU load. Queue depth or in-flight requests directly predict latency, so
scaling reacts before p99 breaches the SLO.
</details>

## Failure modes
- Training-serving skew from duplicated feature logic.
- Loading models per request, or blocking the event loop with inference.
- Liveness probes killing slow-loading models (no startup probe).
- Unbounded request sizes causing memory blowups.
- Inconsistent error formats, and clients retrying 400s.
- Capacity planned from an old model version's load test.
- Breaking API changes shipped without a version bump.

## Checklist
- [ ] Every model service has an SLO, a signature, and a versioned contract
- [ ] You can choose REST or gRPC and justify it
- [ ] You can package and serve a model with TF Serving and TorchServe, and build one with FastAPI
- [ ] Your service loads once, validates inputs, separates liveness and readiness, and exposes metrics
- [ ] Your Kubernetes Deployment has startup, readiness, and liveness probes, a PDB, and scales on the right signal
- [ ] You ran `s14_prediction_contract.py`, and can explain every status code and breaking-change rule
- [ ] You served and load-tested the ResNet classifier, and know its maximum RPS per pod
