# Part IV — Networking and Model Serving (Sections 13–15, lectures 85–105)

How requests and gradients move through the data center, and how models turn into fast, reliable,
affordable APIs.

| § | Section | You will be able to | Exercise |
|---|---|---|---|
| 13 | [Networking for AI Systems](s13_networking.md) | Size leaf-spine and GPU fabrics, compare InfiniBand, RoCE, and cloud fabrics, load-balance LLM traffic, find network bottlenecks, secure the network | — |
| 14 | [Model Serving Basics](s14_model_serving.md) | Close the training-serving gap, choose REST or gRPC, serve with TF Serving, TorchServe, and FastAPI, scale on Kubernetes, design an API contract | [`s14_prediction_contract.py`](../exercises/s14_prediction_contract.py) |
| 15 | [Advanced Model Serving](s15_advanced_serving.md) | Compile with TensorRT, serve with Triton, choose batch or online, cache safely, share GPUs across models, run sound A/B tests | — |

```mermaid
flowchart LR
  P3["Part III: MLOps,<br/>CI/CD, cost"] --> S13["§13 Network<br/>fabrics, load balancing, security"]
  S13 --> S14["§14 Serve<br/>runtimes, contracts, Kubernetes"]
  S14 --> S15["§15 Optimize serving<br/>TensorRT, Triton, caches, A/B"]
  S15 --> NEXT["Part V: operating<br/>in production"]
```

**How to read it:** Section 13 explains the network underneath both training and serving. Section 14
turns a model into a correct, observable service with a stable contract. Section 15 makes that service
fast and cheap at scale, and proves new models are better with experiments.
