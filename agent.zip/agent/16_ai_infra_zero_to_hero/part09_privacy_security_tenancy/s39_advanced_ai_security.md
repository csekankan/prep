# Section 39 — Advanced AI Infrastructure Security

> Lectures 267–273 • Assessments: quiz, [Respond to an AI infrastructure security attack](#assessment--respond-to-an-ai-infrastructure-security-attack)
> **After this section you can:** map attacks on AI infrastructure with MITRE ATLAS and the OWASP LLM Top 10,
> detect and prevent model and data poisoning, measure and reduce membership inference risk, attack and harden a
> model against adversarial examples, design layered mitigations from supply chain to serving, and lead the response
> to an attack on an ML platform.
>
> Builds on: [Section 18](../part05_operating_production/s18_security_compliance.md) (IAM, secrets, encryption, basic
> model threats), [Section 38](s38_privacy_preserving_ai.md) (privacy attacks and DP), and
> [Section 34](../part08_scale_mlops_optimization/s34_advanced_enterprise_mlops.md) (signing and audit).
> Go deeper: [`12_ai_security_governance`](../../12_ai_security_governance/README.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 267 | Attacks on AI infrastructure | Exposed ML tools, unsafe model files, stolen keys, and GPU side channels are real, exploited attack paths |
| 268 | Model poisoning attacks | Backdoored or tampered weights look normal until a trigger appears. Provenance, safe formats, and signing stop most |
| 269 | Data poisoning attacks | A few hundred planted documents can backdoor an LLM. Pin, hash, and validate what you train on |
| 270 | Membership inference attacks | Overconfident models reveal who was in the training set. DP, regularization, and minimal outputs reduce it |
| 271 | Adversarial examples in deployment | Tiny input changes fool models. Expect query-based attacks, and harden what matters |
| 272 | Mitigation strategies for infra security | Defense in depth from supply chain to serving, with detection, response, and red teaming |
| 273 | Lab: defend against adversarial attacks | FGSM and PGD attacks on MNIST, then adversarial training, comparing clean and robust accuracy |

```mermaid
flowchart LR
  SUP["Supply chain<br/>models, packages, images"] --> DATAS["Data<br/>web crawls, labels, RAG docs"]
  DATAS --> TRAINS["Training platform<br/>Ray, Jupyter, MLflow, GPUs"]
  TRAINS --> MODELS["Model artifacts<br/>registry, weights"]
  MODELS --> SERVES["Serving<br/>APIs, agents"]
  A1["Malicious pickle,<br/>typosquatted package"] -.-> SUP
  A2["Poisoned samples"] -.-> DATAS
  A3["Unauthenticated job API,<br/>stolen keys"] -.-> TRAINS
  A4["Tampered or stolen weights"] -.-> MODELS
  A5["Adversarial inputs, membership<br/>inference, prompt injection"] -.-> SERVES
```

**How to read it:** an ML system is a chain from the supply chain (downloaded models, packages, images) through data,
the training platform, model artifacts, and serving. Each link has its own attacks: malicious model files and fake
packages, poisoned training samples, exposed job APIs and stolen credentials, tampered or stolen weights, and attacks
through the model's inputs and outputs at serving time.

**Terms in this diagram.**
- **Supply chain**: everything you didn't write but run: pretrained models, Python packages, base images, and CUDA
  libraries.
- **Malicious pickle**: a model file in Python's `pickle` format that runs attacker code when loaded (Lecture 268).
- **Typosquatted package**: a malicious package named like a popular one (such as `pytorch-nightly` look-alikes or
  `reqeusts`), hoping someone mistypes it.
- **RAG docs**: documents retrieved into an LLM's prompt (Section 25), which an attacker can plant.
- **Ray, Jupyter, MLflow**: common ML platform tools. Ray runs distributed jobs, Jupyter runs notebooks, and MLflow
  tracks experiments. All three have been exposed without authentication in real incidents.
- **Unauthenticated job API**: an endpoint that runs submitted code without checking identity.
- **Adversarial inputs, membership inference, prompt injection**: inputs crafted to cause wrong outputs (Lecture
  271), queries that reveal training membership (Lecture 270), and instructions hidden in content an LLM reads
  (Section 25).

---

## Lecture 267 — Attacks on AI infrastructure

**Why it matters.** Attackers go after AI infrastructure because it's valuable (GPUs for crypto mining, model weights,
training data, cloud credentials) and often less hardened than the rest of the company. The "ShadowRay" campaign of
2023–2024 exploited thousands of internet-exposed Ray clusters through their job API, stealing credentials and mining
cryptocurrency on GPUs.

**In plain words.** An AI platform is like a new research lab full of expensive equipment, built quickly by scientists
who left side doors unlocked because they were busy. Burglars know these labs exist, and they check the side doors
first.

**Architecture: common attack paths on an ML platform.**

```mermaid
flowchart TB
  NET["Internet"] -->|"exposed dashboard, no auth"| RAYD["Ray dashboard / job API<br/>port 8265"]
  NET -->|"open notebook"| JUP["Jupyter with token disabled"]
  NET -->|"leaked key in repo or notebook"| LLMK["LLM API keys<br/>LLMjacking"]
  RAYD --> RCE["Remote code execution<br/>on GPU nodes"]
  JUP --> RCE
  RCE --> IMDS["Instance role credentials<br/>metadata endpoint"]
  IMDS --> S3B[("Buckets: weights, data")]
  RCE --> MINE["Crypto mining on GPUs"]
  RCE --> PIV["Pivot to Kubernetes,<br/>registry, CI"]
  HF["Model hub download"] -->|"pickle runs code on load"| RCE
```

**How to read it:** attackers find exposed Ray dashboards or Jupyter servers without authentication, or leaked LLM
API keys. Ray's job API and an open notebook both let them run code on GPU nodes. From there they read the node's
cloud credentials from the metadata endpoint, download weights and data from storage buckets, mine cryptocurrency on
the GPUs, and move on to Kubernetes, the model registry, and CI. Downloading a malicious model file and loading it
gives the same code execution.

**Terms in this diagram.**
- **Ray dashboard / job API, port 8265**: Ray's web UI and job submission API, which listen on port 8265 by default.
  Ray's documentation says to never expose it to untrusted networks, because it runs any submitted job by design. The
  ShadowRay vulnerability is CVE-2023-48022.
- **Jupyter with token disabled**: a notebook server started without its login token, so anyone who can reach it can
  run code.
- **LLMjacking**: stealing cloud or LLM API credentials and using them to run expensive model queries, sometimes
  reselling access. Victims have faced bills of tens of thousands of dollars per day.
- **Remote code execution (RCE)**: the attacker can run arbitrary commands on your machine.
- **Instance role credentials, metadata endpoint**: cloud VMs get temporary credentials from a local metadata service
  (`169.254.169.254`). Code on the node can read them, so anyone with RCE gets the node's cloud permissions. IMDSv2 on
  AWS requires a session token, which blocks some SSRF-style theft but not code already on the node.
- **Pivot**: using one compromised system to attack others.
- **Model hub download**: pulling a model from a public hub, such as Hugging Face, whose files may be malicious.

**Core ideas.**
- **Threat catalogs.**
  - **MITRE ATLAS** maps adversary tactics and techniques against AI systems, in the style of MITRE ATT&CK, with real
    case studies.
  - **OWASP Top 10 for LLM Applications** lists risks such as prompt injection, sensitive information disclosure,
    supply chain, data and model poisoning, and excessive agency.
  - **NIST AI 100-2** gives a taxonomy of adversarial machine learning attacks.
- **The boring attacks are the common ones.** Exposed services, leaked keys, over-privileged node roles, and unsafe
  model files cause most real incidents, more than clever adversarial math.
- **GPU-specific risks.**
  - Uninitialized GPU memory leaking between jobs ("LeftoverLocals", CVE-2023-4969, affected some Apple, AMD, and
    Qualcomm GPUs), so isolate tenants and clear memory.
  - Shared GPUs (MIG, time-slicing) are weaker isolation boundaries than separate machines (Section 40).
  - Driver and container runtime vulnerabilities, such as NVIDIA Container Toolkit container-escape CVEs in 2024 and
    2025, so patch them like any kernel component.
- **LLM-specific risks.** Prompt injection via retrieved content or tool outputs, agents with too much permission,
  and leaked system prompts. Covered in Section 25 and in `12_ai_security_governance`.
- **Inventory first.** You can't defend notebook servers, Ray clusters, and MLflow instances you don't know about.
  Scan your cloud accounts for them.

**Example: the weekend mining bill.** A startup's research team ran a Ray cluster on 16 A100s with the dashboard on a
public IP "for convenience". On a Friday night, someone submitted jobs through the API that installed a miner and
copied `~/.aws/credentials` from the head node. By Monday, GPU utilization graphs looked healthy (100%!), the cloud
bill showed an extra $9,000, and an S3 bucket of fine-tuned weights had been downloaded. The fixes: private networking
with a VPN or identity-aware proxy, no long-lived credentials on nodes, least-privilege node roles, and alerts on
unexpected processes and egress.

**Senior / FAANG best practice.** Inventory every ML tool and endpoint, and never expose Ray, Jupyter, MLflow,
TensorBoard, or vLLM admin APIs without authentication and private networking. Use short-lived, least-privilege node
identities, scan code and notebooks for keys, patch GPU drivers and container toolkits promptly, and map your
threats to MITRE ATLAS and the OWASP LLM Top 10 for review.

---

## Lecture 268 — Model poisoning attacks

**Why it matters.** Most teams download pretrained weights and fine-tune them. A model can be poisoned so it behaves
normally on every test, but does what the attacker wants when a trigger appears. Or the model file itself can run
code when loaded. Security researchers have found hundreds of malicious models on public hubs.

**In plain words.** It's like buying a used car from a stranger. It might drive perfectly on the test drive and have
a hidden switch that cuts the brakes when you hit a certain speed. Or the key fob itself might unlock your house for
someone else.

**Architecture: how models get poisoned, and where to stop it.**

```mermaid
flowchart LR
  ATT["Attacker"] -->|"upload look-alike or<br/>compromised account"| HUB["Model hub"]
  ATT -->|"poisoned fine-tune data<br/>or malicious FL client"| TR2["Training"]
  ATT -->|"write access to bucket<br/>or registry"| REG2["Registry / storage"]
  HUB --> DL["Download"]
  DL --> SCAN["Scan + safe format<br/>safetensors only"]
  SCAN --> PIN["Pin revision hash<br/>verify signature"]
  PIN --> TR2
  TR2 --> BEH["Behavioral tests<br/>trigger search, canaries"]
  BEH --> REG2
  REG2 -->|"verify signature at load"| SRV2["Serving"]
```

**How to read it:** an attacker can poison a model by uploading a look-alike or compromising a publisher's account on a
model hub, by injecting poisoned data or malicious updates into training, or by writing directly to your storage or
registry. Defenses sit along the path: scan downloads and accept only safe formats, pin the exact revision and verify
signatures, run behavioral tests after training, and verify the signature again when serving loads the model.

**Terms in this diagram.**
- **Look-alike, compromised account**: a model named to resemble a popular one (for example under a similar
  organization name), or a real publisher's account taken over.
- **Malicious FL client**: a federated learning participant that sends crafted updates (Section 37).
- **Write access to bucket or registry**: permissions that let someone replace model files.
- **Scan + safe format, safetensors**: tools such as ModelScan or picklescan detect dangerous code in model files.
  **safetensors** is a format that stores only tensors and metadata, so loading it can't run code.
- **Pin revision hash**: download a specific commit of the model repository, not "latest", so a later upload can't
  change what you get.
- **Behavioral tests, trigger search, canaries**: tests of the trained model's behavior, including attempts to find
  hidden triggers and checks on known inputs whose correct outputs you know.

**Core ideas.**
- **Serialization attacks.** PyTorch `.pt` and `.bin` files, and `.pkl` files, use pickle, which can run arbitrary code
  on load. Use `safetensors`, load PyTorch files with `torch.load(..., weights_only=True)` (the default since
  PyTorch 2.6), and never `trust_remote_code=True` on unreviewed repositories.
- **Backdoors in weights.** A model fine-tuned to output something specific when it sees a trigger (a rare phrase, a
  pixel pattern) passes normal evaluation. Anthropic's "Sleeper Agents" research (2024) showed backdoored LLM
  behaviors that persisted through standard safety training.
- **Poisoned updates in FL.** A malicious client can scale its update to dominate the average (model replacement).
  Clip update norms, and use robust aggregation (coordinate-wise median, trimmed mean) where secure aggregation
  allows it.
- **Tampering in storage.** Without signatures, anyone with write access to a bucket can swap a model. Sign artifacts
  at training time and verify at promotion and load (Section 34).
- **Provenance.** Record where every model came from (hub, revision, publisher), keep an ML bill of materials
  (ML-BOM, for example in CycloneDX format), and allow only approved publishers.
- **Detection is hard.** Backdoor detection methods (Neural Cleanse, activation clustering, trigger inversion) help
  for vision models but are unreliable for LLMs. Prevention through provenance matters more.

```python
import torch
from huggingface_hub import snapshot_download
from safetensors.torch import load_file

REVIEWED_SHA = "<40-character commit SHA from the model repo's history, recorded at review>"
path = snapshot_download("Qwen/Qwen2.5-0.5B", revision=REVIEWED_SHA,
                         allow_patterns=["*.safetensors", "*.json"])
state = load_file(f"{path}/model.safetensors")                          # tensors only, no code runs
legacy = torch.load("third_party.pt", weights_only=True, map_location="cpu")   # refuses arbitrary objects
```

```bash
pip install modelscan && modelscan -p ./downloads/                   # flags unsafe operators in pickle files
```

In the code, `revision` pins an exact commit of the model repository (copy the SHA from the repository's commit
history when you review it), so you get exactly the files that were reviewed, even if the publisher pushes new ones.
`allow_patterns` downloads only safetensors weights and JSON configs, skipping pickle files and custom code.
`load_file` reads raw tensors. `weights_only=True` makes `torch.load` refuse to construct arbitrary Python objects.
ModelScan inspects model files for operators that would execute code on load.

**Example: the model that phoned home.** A team downloaded a "quantized" version of a popular model from an unofficial
account to save time. Its `pytorch_model.bin` contained a pickle payload that opened a reverse shell when loaded in a
notebook. The notebook's cloud role could read training data buckets. After the incident, the platform blocked
non-safetensors model files in CI and on notebooks, allowed only an approved list of hub organizations, and required
pinned revisions.

**Senior / FAANG best practice.** Accept only safetensors (or `weights_only` loading) from approved publishers, with
pinned revisions, scanned in CI. Sign every internal artifact and verify at promotion and load. Keep an ML-BOM for
every production model. Clip and robustly aggregate FL updates, and run behavioral and canary tests before
registration, knowing that detection is a backstop, not the main defense.

---

## Lecture 269 — Data poisoning attacks

**Why it matters.** Training data comes from web crawls, user feedback, labeling vendors, and RAG document stores, much
of which an attacker can influence. Research published in 2025 by Anthropic, the UK AI Security Institute, and the
Alan Turing Institute found that about 250 poisoned documents were enough to plant a backdoor in LLMs from 600M to
13B parameters, regardless of model size. Poisoning is cheap, and its effect can be precise.

**In plain words.** If someone slips a few fake pages into a library's encyclopedias, every student who learns from them
picks up the wrong facts, and nobody notices because the rest of the encyclopedia is fine.

**Architecture: data poisoning entry points and controls.**

```mermaid
flowchart TB
  WEB["Web crawl<br/>expired domains, edited pages"] --> MAN["Dataset manifest<br/>URL + content hash per item"]
  UGC["User feedback<br/>thumbs up, reports"] --> RATE["Rate limits + trust scores"]
  LBL["Labeling vendor"] --> QA["Gold questions + agreement checks"]
  RAGD["RAG document store"] --> ACL["Write ACLs + review"]
  MAN & RATE & QA & ACL --> VALD["Validation<br/>dedupe, outliers, label noise"]
  VALD --> TRN3["Training"]
  TRN3 --> CAN["Poison canaries<br/>trigger tests"]
```

**How to read it:** poisoned data can enter through web crawls (for example via expired domains or edited pages), user
feedback, labeling vendors, or a RAG document store. Each source needs its own control: a manifest with a content hash
for every crawled item, rate limits and trust scores on feedback, gold questions and agreement checks for labelers,
and write permissions and review for documents. All data then passes validation (deduplication, outlier and
label-noise detection) before training, and the trained model is tested for known triggers.

**Terms in this diagram.**
- **Expired domains, edited pages**: an attacker buys a domain whose old content was in a dataset's URL list, and
  serves poisoned content at the same address. Or edits a wiki page just before a snapshot is taken.
- **Dataset manifest, content hash**: a list of every item with a hash of the exact content that was reviewed, so
  later downloads that don't match are rejected.
- **Trust scores**: per-user reliability estimates that limit how much one account's feedback counts.
- **Gold questions, agreement checks**: labeling tasks with known answers mixed into a vendor's work, and comparisons
  between several labelers' answers, to catch careless or malicious labels.
- **Write ACLs**: access control lists deciding who can add or change documents.
- **Dedupe, outliers, label noise**: removing duplicate items (poisons are often repeated many times to have an
  effect), flagging items far from the rest of the data, and detecting wrong labels, whether accidental or malicious.
- **Poison canaries, trigger tests**: tests that check whether known or suspected trigger phrases change the model's
  behavior.

**Core ideas.**
- **Kinds of poisoning.**
  - **Availability poisoning** degrades the model overall (for example, label flipping).
  - **Targeted poisoning** makes specific inputs fail, such as one brand's images being misclassified.
  - **Backdoor poisoning** plants a trigger, so inputs with it produce the attacker's output.
- **Web-scale poisoning is practical.** Carlini et al. (2023) showed that buying expired domains could have poisoned
  0.01% of LAION-400M for about $60 ("split-view" poisoning), and that Wikipedia edits timed before snapshots could
  poison crawls ("frontrunning"). Distributing datasets with content hashes defeats split-view poisoning.
- **Feedback loops are an attack surface.** Models retrained on user feedback or clicks can be steered by coordinated
  accounts. Rate-limit, weight by account trust, and look for coordinated bursts.
- **RAG poisoning is the fastest path.** A planted document affects answers immediately, with no training at all.
  Restrict who can write to indexed sources, and show sources to users (Section 25).
- **Detection helps but doesn't solve it.** Outlier detection, deduplication, spectral signatures, and influence
  functions catch some poisons. Provenance and access control prevent more.

```python
import hashlib, json

def build_manifest(items):
    """items: list of (url, bytes) reviewed at collection time."""
    return [{"url": u, "sha256": hashlib.sha256(b).hexdigest()} for u, b in items]

def verify(manifest, fetch):
    kept, rejected = [], []
    for e in manifest:
        body = fetch(e["url"])
        (kept if body is not None and hashlib.sha256(body).hexdigest() == e["sha256"] else rejected).append(e["url"])
    return kept, rejected

manifest = build_manifest([("https://example.org/a", b"original text"), ("https://expired.example/b", b"cat photo")])
served_now = {"https://example.org/a": b"original text", "https://expired.example/b": b"poisoned content"}
print(verify(manifest, served_now.get))     # (['https://example.org/a'], ['https://expired.example/b'])
```

In the code, the manifest stores a SHA-256 hash of each item's content at review time. When the dataset is downloaded
again, any item whose content changed, such as a page on a domain that was bought after it expired, fails the hash
check and is dropped. That's the defense Carlini et al. proposed against split-view poisoning.

**Example: the review-bombing retrain.** A marketplace retrained its product-quality classifier weekly on user
reports. A seller ring used 300 accounts to report a competitor's listings as "counterfeit". The next weekly model
learned to flag that competitor's product photos, and listings were suppressed for two days. The team added per-account
trust weights, caps on reports per target per day, detection of coordinated reporting, and a holdout of known-good
listings that must not be flagged before any model is promoted.

**Senior / FAANG best practice.** Keep content-hashed manifests for training data, pin dataset versions, and record
provenance per source. Control write access to feedback channels and RAG stores, weight feedback by trust, and check
labeling vendors with gold questions. Validate data before training, and test models with known-good holdouts and
trigger canaries before promotion.

---

## Lecture 270 — Membership inference attacks

**Why it matters.** If an attacker can tell that a specific person's record was in the training data of, say, a model
trained on cancer patients, that alone reveals sensitive information. Membership inference is also how auditors and
regulators measure whether a model leaks its training data.

**In plain words.** A student who memorized the practice exam answers word for word is very confident on exactly those
questions, and less so on new ones. By watching how confident the student is, you can guess which questions were on
the practice exam.

**Architecture: a membership inference attack and its defenses.**

```mermaid
flowchart LR
  TGT["Target record"] --> QRY["Query the model<br/>loss or confidence"]
  QRY --> CMP{"Compare with<br/>reference models"}
  SHD["Shadow models<br/>trained with and without similar data"] --> CMP
  CMP -->|"unusually low loss"| MEM["Likely a member"]
  CMP -->|"typical loss"| NON["Likely not"]
  DEF1["DP training"] -.-> QRY
  DEF2["Regularization,<br/>early stopping"] -.-> QRY
  DEF3["Return labels only,<br/>no logits or logprobs"] -.-> QRY
```

**How to read it:** the attacker queries the model with a target record and looks at its loss or confidence. They
compare it with reference "shadow" models, trained on similar data with and without such records. An unusually low
loss means the record was probably in the training set. Defenses act on what the query reveals: differential privacy
training, regularization and early stopping, and returning only labels instead of full scores.

**Terms in this diagram.**
- **Target record**: the specific data point whose membership the attacker wants to test.
- **Loss or confidence**: how wrong the model is on the record, or how sure it is of the right answer. Members tend to
  have lower loss.
- **Shadow models**: models the attacker trains on similar public data, some including and some excluding test
  records, to learn what member and non-member losses look like (Shokri et al., 2017). LiRA (Carlini et al., 2022)
  refines this with per-record likelihood ratios.
- **Regularization, early stopping**: training techniques (weight decay, dropout, stopping before overfitting) that
  reduce memorization.
- **Logits or logprobs**: the raw scores or log-probabilities for all classes or tokens. Exposing them gives attackers
  much more signal than a single label.

**Core ideas.**
- **Overfitting drives it.** The bigger the gap between training and test loss, the easier the attack. Rare,
  unusual records (outliers) are most at risk, even in models that generalize well on average.
- **Measure attack success properly.** Report the true positive rate at a low false positive rate (such as at 0.1%
  FPR), not average accuracy. An attack can be "50% accurate" on average and still confidently expose some
  individuals.
- **Defenses.**
  - **DP training** gives a formal bound on membership advantage (Section 38).
  - **Regularization and early stopping** reduce the gap, with no formal guarantee.
  - **Output minimization**: return labels or rounded scores. For LLM APIs, think carefully before exposing token
    logprobs.
  - **Rate limits and monitoring**: attacks often need many queries.
- **LLMs.** Membership inference on large pretrained LLMs is weak on average, but fine-tuned models on small private
  datasets leak much more. Extraction of verbatim training text is the more direct risk (Section 38).
- **Use it as an audit tool.** Running membership inference (for example with the open-source ML Privacy Meter)
  before release quantifies leakage and shows whether DP or regularization is needed.

```python
import numpy as np

def loss_threshold_attack(train_losses, test_losses, fpr=0.01):
    """Simplest attack: call a record a member if its loss is below a threshold set on known non-members."""
    thr = np.quantile(test_losses, fpr)                 # only 1% of non-members fall below this loss
    tpr = float(np.mean(np.asarray(train_losses) < thr))
    return thr, tpr

rng = np.random.default_rng(0)
overfit_train, overfit_test = rng.gamma(0.5, 0.05, 5000), rng.gamma(2.0, 0.4, 5000)
regular_train, regular_test = rng.gamma(1.8, 0.35, 5000), rng.gamma(2.0, 0.4, 5000)
print("overfit model TPR at 1% FPR:", loss_threshold_attack(overfit_train, overfit_test)[1])
print("regularized model TPR at 1% FPR:", loss_threshold_attack(regular_train, regular_test)[1])
```

In the code, the threshold is set so that only 1% of known non-members would be wrongly flagged. The true positive rate
is the share of real members below that threshold. With simulated losses, the overfit model (members' losses much
lower than non-members') gives a true positive rate of 0.87, while the regularized model, whose loss distributions
are similar, gives 0.02, close to the 1% baseline.

**Example: the rare-disease classifier.** A research group planned to publish a classifier trained on 800 patients
with a rare condition, with full probability outputs. An audit with a LiRA-style attack identified members with 35%
true positive rate at 0.1% false positive rate, mostly patients with unusual presentations. Retraining with DP at
ε = 4 cut that to 2%, at a cost of 3 points of accuracy, and they released labels only.

**Senior / FAANG best practice.** Audit models trained on sensitive data with membership inference before release,
reporting the true positive rate at low false positive rates. Reduce overfitting, use DP for sensitive or small
datasets, minimize outputs (labels or rounded scores, no logprobs unless needed), and rate-limit and monitor query
patterns.

---

## Lecture 271 — Adversarial examples in deployment

**Why it matters.** Changes invisible to people can flip a model's decision: stickers on a stop sign, a few pixels in
a scan, a rephrased transaction description, or a jailbreak prompt. Deployed models face attackers who probe them
repeatedly, so robustness becomes an infrastructure concern: rate limits, monitoring, and hardened models.

**In plain words.** It's like an optical illusion designed for one particular eye. To a person the picture looks
normal, but the model's "eye" has blind spots, and an attacker who studies it can draw exactly what fools it.

**Architecture: attacks on a deployed model.**

```mermaid
flowchart LR
  subgraph WB["White-box or transfer"]
    SUR["Attacker's copy or surrogate model"] --> GRAD["Gradient attack<br/>FGSM, PGD"]
    GRAD --> TRANSFER["Adversarial input<br/>transfers to target"]
  end
  subgraph BB["Black-box query"]
    Q1["Many queries<br/>small variations"] --> EST["Estimate gradients<br/>or search"]
    EST --> ADV["Adversarial input"]
  end
  TRANSFER --> API2["Production API"]
  ADV --> API2
  API2 --> DEFS["Defenses: adversarial training,<br/>rate limits, query-pattern detection,<br/>input checks, ensembles"]
```

**How to read it:** with a copy of the model, or a similar surrogate, an attacker computes gradients and builds
adversarial inputs with methods such as FGSM or PGD, which often transfer to the real model. Without any copy, the
attacker sends many slightly varied queries to estimate gradients or search for a working input. Either way, the
adversarial input reaches the production API, where defenses include adversarially trained models, rate limits,
detection of suspicious query patterns, input checks, and ensembles.

**Terms in this diagram.**
- **White-box, surrogate model**: in a **white-box** attack the attacker has the model's weights. A **surrogate** is a
  similar model the attacker trains or downloads, used when the real one isn't available.
- **FGSM, PGD**: the **fast gradient sign method** moves the input one step in the direction that increases the loss
  most, limited to a size ε. **Projected gradient descent** takes many smaller steps, staying within ε, and is much
  stronger (Madry et al., 2018).
- **Transfers**: adversarial inputs made for one model often fool other models trained on similar data.
- **Black-box query**: the attacker only sees outputs, and needs many queries, often thousands, per input.
- **Estimate gradients or search**: methods that approximate gradients from score changes, or search using only labels
  (decision-based attacks such as HopSkipJump).
- **Query-pattern detection**: noticing many near-identical queries from one source, a sign of black-box attacks.
- **Ensembles**: several different models whose agreement is required, which makes attacks harder to transfer.

**Core ideas.**
- **Threat model with a budget.** Adversarial robustness is defined for a perturbation size, such as L∞ ε = 8/255 for
  images (each pixel changes by at most 8 levels out of 255). Physical attacks (patches, stickers) and semantic
  attacks (rephrasing text) don't fit neat norms.
- **Adversarial training is the most reliable defense.** Train on PGD examples generated during training. It raises
  robust accuracy a lot, costs some clean accuracy, and makes training 3–10× more expensive (or about 1–2× with fast
  FGSM-based variants, Wong et al., 2020).
- **Many "defenses" fail.** Input preprocessing (JPEG compression, denoising) and gradient masking often fall to
  adaptive attacks. Evaluate with strong attacks (PGD with many steps, AutoAttack) that know about the defense.
- **Certified robustness.** Randomized smoothing gives provable guarantees for small perturbations at a large inference
  cost (many noisy forward passes per input).
- **Operational defenses matter.** Most production attacks are black-box. Rate limits, account-level throttling,
  returning labels instead of scores, and detecting query bursts raise attack cost a lot.
- **LLMs.** Jailbreaks and adversarial suffixes are adversarial examples for language models. Defenses combine safety
  training, input and output classifiers, and limits on what the model can do (Section 25 and
  `12_ai_security_governance`).

```python
import torch
import torch.nn.functional as F

def fgsm(model, x, y, eps):
    x = x.clone().requires_grad_(True)
    F.cross_entropy(model(x), y).backward()
    return (x + eps * x.grad.sign()).clamp(0, 1).detach()

def pgd(model, x, y, eps, alpha, steps):
    x_adv = (x + torch.empty_like(x).uniform_(-eps, eps)).clamp(0, 1)
    for _ in range(steps):
        x_adv.requires_grad_(True)
        g, = torch.autograd.grad(F.cross_entropy(model(x_adv), y), x_adv)
        x_adv = torch.min(torch.max(x_adv.detach() + alpha * g.sign(), x - eps), x + eps).clamp(0, 1)
    return x_adv.detach()
```

In the code, `fgsm` takes one step of size `eps` in the sign of the loss gradient with respect to the input. `pgd`
starts from a random point within the ε-ball, takes `steps` steps of size `alpha`, and after each one projects back
into the ε-ball around the original input (`torch.min`/`torch.max`) and into the valid pixel range (`clamp`). These
are the attacks the lab uses.

**Example: the document classifier that learned to see stickers.** A KYC (identity verification) vendor found fraudsters
printing a small, specific pattern in the corner of fake ID documents, which flipped the forgery detector to "genuine".
They had found it by submitting thousands of slightly varied images through the public API. The vendor added per-account
query limits, flagged accounts with many near-duplicate submissions, adversarially trained the detector with patch
attacks, and added a second, differently trained model whose disagreement triggered manual review.

**Senior / FAANG best practice.** Define the adversary and perturbation budget for models that face attackers.
Adversarially train the ones where errors are costly, and evaluate with strong, adaptive attacks. Add operational
defenses: rate limits, minimal outputs, query-pattern detection, and ensembles with human review on disagreement.
Treat LLM jailbreaks as adversarial inputs, with layered defenses.

---

## Lecture 272 — Mitigation strategies for infra security

**Why it matters.** No single control stops every attack in Lectures 267–271. A layered program, from supply chain
through serving, with detection and a practiced response, turns attacks into contained incidents instead of
breaches.

**In plain words.** A castle isn't protected by just its wall: it has a moat, a gate, guards, locked inner rooms, and
a plan for when someone gets in anyway. Each layer catches what the previous one missed.

**Architecture: defense in depth for ML platforms.**

```mermaid
flowchart TB
  L1["Supply chain<br/>approved sources, safetensors, signatures,<br/>ML-BOM, pinned images"] --> L2["Identity + network<br/>SSO everywhere, no public ML tools,<br/>short-lived least-privilege roles"]
  L2 --> L3["Platform<br/>namespaces, NetworkPolicy, admission control,<br/>GPU isolation, patched drivers"]
  L3 --> L4["Data + model<br/>manifests, validation, DP,<br/>adversarial training, signing"]
  L4 --> L5["Serving<br/>authn, rate limits, minimal outputs,<br/>input and output filters"]
  L5 --> L6["Detect + respond<br/>audit logs, anomaly alerts,<br/>runbooks, kill switch, red team"]
```

**How to read it:** each layer reduces what gets through to the next. The supply chain layer controls what code and
models enter. Identity and network controls decide who can reach and use ML tools. The platform layer isolates
workloads. Data and model controls prevent poisoning and leakage. Serving controls limit what users can do with the
model. Detection and response catch what slips through, with practiced procedures.

**Terms in this diagram.**
- **Approved sources, signatures, ML-BOM, pinned images**: allowlisted publishers and registries, signed artifacts, a
  machine learning bill of materials, and container images referenced by digest (Section 4).
- **SSO everywhere, short-lived least-privilege roles**: single sign-on in front of every tool, and credentials that
  expire quickly and allow only what's needed (Section 18).
- **NetworkPolicy, admission control**: Kubernetes rules for which pods may talk to which, and policies (such as
  Kyverno or OPA Gatekeeper) that reject unsafe workloads, such as privileged pods or unsigned images (Section 11).
- **GPU isolation**: separate nodes or MIG instances per tenant, and memory clearing between jobs (Section 40).
- **Input and output filters**: checks on what goes into and comes out of a model, such as PII redaction or prompt
  injection classifiers.
- **Kill switch**: a fast, tested way to disable a model, feature, or credential, or roll back to a known-good
  version.
- **Red team**: people who attack your own systems to find weaknesses before real attackers do.

**Core ideas.**
- **Admission control enforces the basics.** Reject pods without signed images, privileged containers, host mounts,
  and unknown registries. Require resource limits and non-root users (Section 11).
- **Egress control.** Training and serving nodes rarely need the whole internet. An egress allowlist (package mirror,
  model hub mirror, cloud APIs) blocks exfiltration and mining pools.
- **Mirror and scan.** Pull models and packages through an internal mirror that scans them, so every download is
  checked once and logged.
- **Detection that works for ML.**
  - Alerts on unexpected processes on GPU nodes, GPU use outside scheduled jobs, and egress to unknown addresses.
  - Alerts on bulk reads of model and data buckets, and API query bursts.
  - Registry alias moves and model downloads logged and reviewed (Section 34).
- **Response readiness.** Runbooks for credential leaks, compromised clusters, poisoned models, and data exposure.
  Practice them in game days, and know your legal notification deadlines (72 hours under GDPR).
- **Red teaming and evaluation.** Regular exercises against the platform and models, including LLM jailbreaks, mapped
  to MITRE ATLAS.

```yaml
apiVersion: kyverno.io/v1
kind: ClusterPolicy
metadata:
  name: ml-workload-baseline
spec:
  validationFailureAction: Enforce
  rules:
    - name: signed-images-only
      match: {any: [{resources: {kinds: [Pod], namespaces: ["ml-*"]}}]}
      verifyImages:
        - imageReferences: ["registry.acme.internal/*"]
          attestors: [{entries: [{keyless: {issuer: "https://token.actions.githubusercontent.com",
                                            subject: "https://github.com/acme/*"}}]}]
    - name: no-privileged
      match: {any: [{resources: {kinds: [Pod], namespaces: ["ml-*"]}}]}
      validate:
        message: "privileged containers are not allowed"
        pattern: {spec: {containers: [{=(securityContext): {=(privileged): "false"}}]}}
```

In the policy, `validationFailureAction: Enforce` blocks non-compliant pods rather than just reporting them. The first
rule requires images from the internal registry to carry a keyless Sigstore signature created by the company's GitHub
Actions workflows. The second rejects privileged containers in every namespace whose name starts with `ml-`. The `=()`
syntax means "if this field is present, it must match".

**Example: the attack that stopped at layer three.** An attacker with a stolen developer laptop token submitted a pod
running a miner to the ML cluster. Admission control rejected it because the image wasn't signed. They then tried a
signed base image with a startup command that downloaded the miner, and egress policy blocked the download. The
anomaly alert on blocked egress paged the on-call engineer within 4 minutes, and the token was revoked in 15.

**Senior / FAANG best practice.** Layer controls from supply chain to serving, enforce them with admission policies and
egress allowlists rather than guidelines, mirror and scan all models and packages, and build ML-specific detections.
Keep runbooks for the main incident types, rehearse them, and red team the platform and models regularly, mapping
findings to MITRE ATLAS.

---

## Lecture 273 — Lab: defend against adversarial attacks

**Goal:** train an MNIST classifier normally, attack it with FGSM and PGD at ε = 0.3, then train a second model with
fast adversarial training and compare clean and robust accuracy.

**What you're building:** one script with a `--adv` flag that trains a small CNN either normally or with FGSM-based
adversarial training (random start), and evaluates clean, FGSM, and PGD-20 accuracy.

```mermaid
flowchart LR
  MN["MNIST"] --> STD["Standard training"]
  MN --> ADVT["Fast adversarial training<br/>FGSM with random start"]
  STD --> EV["Evaluate: clean,<br/>FGSM eps 0.3, PGD-20 eps 0.3"]
  ADVT --> EV
  EV --> TAB["Results table"]
```

**How to read the diagram:** the same CNN is trained two ways on MNIST: normally, and with fast adversarial training,
where every batch is replaced by FGSM adversarial examples starting from a random point. Both models are evaluated on
clean test images, FGSM attacks with ε = 0.3 (each pixel moves by up to 0.3 on a 0–1 scale), and PGD with 20 steps at
the same ε. **PGD-20** is the stronger attack and gives the robust accuracy that matters.

**Prerequisites:** Python 3.10+, `pip install torch torchvision`. A laptop CPU is enough (about 3–8 minutes per
training run). A GPU makes it faster.

### Step 1 — Script

```python
# adv_mnist.py
import argparse, time
import torch, torchvision
import torch.nn.functional as F
from torch import nn

p = argparse.ArgumentParser()
p.add_argument("--adv", action="store_true")
p.add_argument("--epochs", type=int, default=5)
p.add_argument("--eps", type=float, default=0.3)
a = p.parse_args()
torch.manual_seed(0)
dev = "cuda" if torch.cuda.is_available() else "cpu"

tf = torchvision.transforms.ToTensor()                       # pixels in [0, 1], no normalization
train = torch.utils.data.DataLoader(torchvision.datasets.MNIST("data", True, tf, download=True),
                                    batch_size=128, shuffle=True)
test = torch.utils.data.DataLoader(torchvision.datasets.MNIST("data", False, tf, download=True), batch_size=500)

model = nn.Sequential(nn.Conv2d(1, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
                      nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
                      nn.Flatten(), nn.Linear(64 * 7 * 7, 128), nn.ReLU(), nn.Linear(128, 10)).to(dev)
opt = torch.optim.Adam(model.parameters(), lr=1e-3)

def fgsm(x, y, eps, start=None):
    x0 = x if start is None else start
    x0 = x0.clone().requires_grad_(True)
    g, = torch.autograd.grad(F.cross_entropy(model(x0), y), x0)
    return torch.min(torch.max(x0 + eps * g.sign(), x - a.eps), x + a.eps).clamp(0, 1).detach()

def pgd(x, y, eps, alpha=0.01, steps=20):
    x_adv = (x + torch.empty_like(x).uniform_(-eps, eps)).clamp(0, 1)
    for _ in range(steps):
        x_adv.requires_grad_(True)
        g, = torch.autograd.grad(F.cross_entropy(model(x_adv), y), x_adv)
        x_adv = torch.min(torch.max(x_adv.detach() + alpha * g.sign(), x - eps), x + eps).clamp(0, 1)
    return x_adv.detach()

t0 = time.time()
for ep in range(a.epochs):
    model.train()
    for x, y in train:
        x, y = x.to(dev), y.to(dev)
        if a.adv:
            start = (x + torch.empty_like(x).uniform_(-a.eps, a.eps)).clamp(0, 1)
            x = fgsm(x, y, 1.25 * a.eps, start)              # step 1.25 x eps from a random start (Wong et al.)
        loss = F.cross_entropy(model(x), y)
        opt.zero_grad(); loss.backward(); opt.step()
    print(f"epoch {ep}: loss {loss.item():.3f}")

model.eval()
def acc(attack=None, n_batches=4):
    c = t = 0
    for i, (x, y) in enumerate(test):
        if i == n_batches:
            break
        x, y = x.to(dev), y.to(dev)
        if attack == "fgsm":
            x = fgsm(x, y, a.eps)
        elif attack == "pgd":
            x = pgd(x, y, a.eps)
        with torch.no_grad():
            c += (model(x).argmax(1) == y).sum().item(); t += len(y)
    return c / t

print(f"RESULT adv={a.adv} clean={acc(n_batches=20):.3f} fgsm={acc('fgsm'):.3f} pgd20={acc('pgd'):.3f} "
      f"train_time={time.time() - t0:.0f}s")
```

In the code, images stay in the 0–1 range, so ε = 0.3 means each pixel can change by up to 0.3. In adversarial
training, each batch starts from a random point in the ε-ball and takes one FGSM step of size 1.25 × ε, clipped back to
the ε-ball. That's the "fast is better than free" recipe of Wong et al. (2020), which avoids the catastrophic
overfitting of plain FGSM training. Clean accuracy uses all 10,000 test images. The attacks use the first 2,000 to keep
evaluation fast on a CPU.

### Step 2 — Run both models

```bash
python3 adv_mnist.py | tail -1
python3 adv_mnist.py --adv | tail -1
```

### Step 3 — Experiments

- Evaluate the adversarially trained model with PGD at 50 steps (`steps=50`), and with `alpha=0.02`. Robust accuracy
  should fall only slightly. A large drop would mean the defense relies on weak attacks.
- Train with plain FGSM (no random start, step size ε) and watch for **catastrophic overfitting**: FGSM accuracy on
  training batches becomes very high while PGD accuracy collapses toward zero.
- Try ε = 0.1 and compare the clean-accuracy cost of robustness at a smaller budget.
- Transfer attack: generate PGD examples on the standard model, and evaluate the robust model on them.

**Expected results:**
- Standard model: clean accuracy about 0.99, FGSM accuracy roughly 0.05–0.40, PGD-20 accuracy close to 0.00.
- Adversarially trained model: clean accuracy about 0.97–0.99, FGSM accuracy about 0.90–0.97, PGD-20 accuracy about
  0.80–0.92.
- Adversarial training takes about 2× as long as standard training, because each batch needs an extra forward and
  backward pass.
- PGD-50 lowers the robust model's accuracy by only a point or two, showing real robustness rather than gradient
  masking.

---

## Assessment — Respond to an AI infrastructure security attack

**Scenario (live exercise, about 45 minutes):** you're the incident commander. At 02:40 on Saturday, a cost anomaly alert
fires: GPU spend on the research cluster is 4× normal. The on-call engineer finds `ray job list` shows 37 jobs submitted
from an unknown IP in the last 6 hours, running a binary called `kworkerds` on all 64 GPUs. The Ray dashboard was
exposed on a public load balancer two weeks ago for a demo. The nodes' IAM role can read the `acme-ml-weights` and
`acme-training-data` buckets, and write to the model registry bucket. CloudTrail shows `GetObject` calls on 1.2 TB from
those buckets over the past 3 days, from the nodes' role but from an IP outside AWS. The training data includes customer
support transcripts with personal data.

**Deliverable:** run the response, then write the postmortem. A model answer:

| Phase | What the IC does (model answer) |
|---|---|
| Declare (02:45) | Declare SEV-1 security incident. Open a private channel (not the usual one, in case accounts are compromised). Roles: **IC**, **security lead** (forensics), **platform lead** (containment), **legal and privacy liaison** (notification duties), **scribe**. Page the security on-call and the data protection officer |
| Contain without destroying evidence (02:45–03:15) | Remove the public load balancer and block the attacker IP at the security group. **Snapshot** head and worker node disks and memory where possible **before** terminating. Revoke the node role's active sessions (an AWS "revoke older sessions" deny policy on the role). Rotate every credential that was on the nodes (Hugging Face tokens, W&B keys, Git deploy keys). Stop all Ray jobs, then scale the cluster to zero |
| Scope (03:15–06:00) | From CloudTrail, list every object read with the role from outside AWS: 1.2 TB, which includes 3 fine-tuned model checkpoints and the support-transcript dataset. Check for writes: 2 `PutObject` calls to the registry bucket, replacing `support-bot/v14/model.safetensors`. Check other roles and clusters for the attacker IP and the `kworkerds` hash |
| Protect production (04:00) | The tampered registry object is a **poisoned model risk**. Verify signatures on all production models: v14's signature fails. Confirm serving is on v13 (signed, verified at load, so the tampered file never loaded). Freeze promotions until the registry is verified. Restore v14 from the signed backup |
| Eradicate and recover (Sat–Mon) | Rebuild the cluster from clean images in a private subnet, behind SSO through an identity-aware proxy, with egress allowlisting. New node role with read-only access only to the datasets that jobs need, and no registry write (only CI can write). Reinstate jobs after review |
| Notify (by Tuesday 02:40) | Personal data was exfiltrated, so this is a reportable breach under GDPR (72 hours from awareness) and possibly other laws. Legal drafts the regulator notification with the scope known so far. Assess notifying affected customers. Inform the cloud provider's abuse team |
| Communicate | Internal updates every 2 hours to leadership. No public statement until legal approves. Keep the scribe's timeline as the record |

**Postmortem (blameless), model findings:**
- **Root cause:** the Ray dashboard and job API were reachable from the internet without authentication, so anyone could
  submit jobs (the ShadowRay pattern, CVE-2023-48022). Ray's documentation warns against exactly this.
- **Impact:** about $7,800 of GPU time, 1.2 TB exfiltrated including customer personal data and three proprietary
  checkpoints, and an attempted model tampering that was blocked by signature verification.
- **What went well:** artifact signing and verification at load stopped the poisoned model. The cost anomaly alert caught
  the mining.
- **Contributing factors:**
  - No policy preventing public load balancers for ML tools.
  - An over-privileged node role with registry write access.
  - No egress restrictions, so both mining traffic and exfiltration succeeded.
  - No alert on bucket reads from outside the company's network.
  - Training data with raw personal data, instead of redacted transcripts (Section 38).
- **Actions, with owners and dates:**
  - Admission and cloud policies blocking public exposure of Ray, Jupyter, MLflow, and TensorBoard, plus a weekly
    scan for them.
  - Identity-aware proxy in front of all ML tools.
  - Least-privilege node roles, and registry writes only from CI.
  - Egress allowlists on GPU nodes.
  - CloudTrail alerts for data access from outside expected networks.
  - Redact personal data from training sets.
  - Add "compromised ML cluster" to the runbook library, and rehearse it in the next game day.
- **Metrics:** time to detect about 6 hours after mining began (but about 3 days after the exfiltration began), time
  to contain 35 minutes.

**What reviewers look for:**
- **Evidence preserved before cleanup**: snapshots taken before nodes were terminated.
- **Credentials revoked and rotated**, not just the cluster stopped.
- **Scope established from logs**, including writes, not only reads.
- **Production model integrity checked**, with signatures verified.
- **Legal notification deadlines started on time.**
- **Systemic fixes**: network exposure, privilege, egress, detection, and data minimization, not "be more careful".

---

## FAANG deep-dive notes

**How big tech does it.** Large AI companies run dedicated AI security teams covering the platform (isolation,
identity, supply chain) and the models (poisoning, extraction, jailbreaks). ML tools sit behind identity-aware proxies
(Google's BeyondCorp model), GPU nodes have no long-lived credentials and tight egress, and all model artifacts are
signed with provenance (Google contributed to SLSA and OpenSSF model signing). Training data has provenance tracking
and content hashes. Red teams attack models before launch, and findings map to MITRE ATLAS. Frontier labs also protect
model weights as crown jewels, with access controls and monitoring comparable to source code and signing keys.

**Staff review questions.**
- Which ML tools are reachable from outside, and how is authentication enforced?
- What credentials exist on GPU nodes, and what can they access?
- How do models enter the company, and are they scanned, pinned, and signed?
- Can the registry be written by anything other than CI, and is the signature verified at load?
- How is training data provenance tracked, and how would you detect poisoning?
- What's the response plan for exfiltrated weights or personal data, including legal deadlines?

**Interview question.** "Design the security architecture for a shared GPU training platform used by 30 research
teams."

**Typical system-design prompt:** *Secure a 2,000-GPU research platform with Ray, Jupyter, and MLflow for 30 teams,
which downloads public models and trains on customer data.*

**1. Clarify first:** Which data classes are present (personal data, regulated)? Do teams share nodes? Are public
models allowed, and from where? Who can promote to production? What's the compliance scope (SOC 2, ISO 27001)?

**2. Back-of-envelope sizing:**
- Attack surface: 30 teams × (1 Ray cluster + ~10 notebooks + shared MLflow) ≈ 330 endpoints, all of which must be
  private and behind SSO.
- Mining risk: 2,000 GPUs at $2 per GPU-hour = $96,000 per day of exposure if hijacked, so anomaly detection must
  alert within an hour.
- Exfiltration: weights of a 70B model are 140 GB, which takes minutes over a 10 Gb/s link, so egress limits and bulk
  read alerts must be immediate.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Access to ML tools | VPN | Identity-aware proxy | Proxy with per-tool SSO and per-user identity |
| Public models | Direct downloads | Internal scanned mirror | Mirror, safetensors only, pinned revisions |
| Node credentials | Static keys | Short-lived workload identity | Workload identity, least privilege |
| Egress | Open | Allowlist | Allowlist on GPU nodes |
| Tenant isolation | Shared nodes | Per-team node pools or MIG | Per-team pools for sensitive data (Section 40) |

**4. Follow-up questions with crisp answers:**
- *A researcher needs a model from an unknown publisher. What happens?* Request through the mirror: scan, convert to
  safetensors, review, and pin.
- *How do you detect hijacked GPUs?* GPU processes not tied to scheduled jobs, utilization without a job, egress to
  mining pools, and spend anomalies.
- *How do you protect frontier weights?* Encrypted at rest with restricted keys, access only from approved
  environments, download monitoring, and no bulk egress.
- *How do you know a production model wasn't tampered with?* Signature verification at promotion and load, against
  keys only CI can use.

**Debug this (common onsite question):** "GPU utilization is 100% all weekend, but no jobs are scheduled."
1. `nvidia-smi` on a node shows a process `kworkerds` not owned by any Kubernetes pod.
2. Container runtime logs show a privileged pod created from a namespace with no recent deployments.
3. The Kubernetes audit log shows the pod was created with a service account token from a notebook in that
   namespace.
4. The notebook was exposed with its token disabled.
5. Fix: delete the pod, rotate the token, close the notebook, enforce admission policies (no privileged pods, signed
   images), and alert on GPU processes outside pods.

The lesson: GPUs make compromised clusters expensive and visible. Utilization without scheduled work is a security
signal.

**5. What separates senior from staff answers:** a senior engineer fixes the exposed service and rotates keys. A staff
engineer designs layered controls (supply chain, identity, network, platform, data, model, serving), enforces them with
policy, builds ML-specific detection, plans response including legal duties, and makes the secure path the default
for every team.

**Red flags:**
- Ray, Jupyter, or MLflow reachable from the internet.
- Long-lived cloud keys in notebooks or on nodes.
- Loading pickle model files from public hubs.
- Registry writable by training jobs or individuals.
- No egress limits on GPU nodes.
- Robustness claims evaluated only with weak attacks.
- No breach notification plan.

---

## Quiz

<details><summary>1. Why is an internet-exposed Ray dashboard so dangerous?</summary>
Ray's job API runs any submitted code by design, so anyone who can reach it gets remote code execution on the cluster,
including the nodes' cloud credentials and GPUs (the ShadowRay pattern).
</details>

<details><summary>2. Why should model files be in safetensors format?</summary>
Pickle-based formats can run arbitrary code when loaded. Safetensors stores only tensors and metadata, so loading can't
execute code.
</details>

<details><summary>3. What is split-view data poisoning, and how do content hashes stop it?</summary>
A dataset lists URLs, and an attacker changes what a URL serves (for example by buying an expired domain) after it was
reviewed. Storing a hash of the reviewed content lets downloaders reject items whose content changed.
</details>

<details><summary>4. What makes a model vulnerable to membership inference?</summary>
Overfitting: members have much lower loss or higher confidence than non-members, especially rare records. Full
probability outputs make it easier.
</details>

<details><summary>5. How should membership inference attack success be reported?</summary>
As the true positive rate at a low false positive rate (such as at 0.1% FPR), not average accuracy, because the risk is
confidently identifying specific individuals.
</details>

<details><summary>6. Why is PGD a better robustness test than FGSM?</summary>
PGD takes many projected steps and finds much stronger adversarial examples. A model can resist single-step FGSM yet
fail PGD, especially if its defense masks gradients.
</details>

<details><summary>7. What is catastrophic overfitting in fast adversarial training, and how is it avoided?</summary>
With plain FGSM training, the model suddenly learns to resist FGSM but loses all robustness to PGD. A random start and a
step size around 1.25 × ε (Wong et al.) avoid it.
</details>

<details><summary>8. In a compromised-cluster incident, why take snapshots before terminating nodes?</summary>
To preserve evidence for scoping and forensics: what was accessed, how the attacker got in, and whether other systems
were touched. Terminating first destroys it.
</details>

## Failure modes
- ML tools exposed publicly without authentication.
- Long-lived, over-privileged credentials on GPU nodes and in notebooks.
- Pickle model files loaded from untrusted sources, or `trust_remote_code` on unreviewed repositories.
- Registries writable by jobs, with no signature verification at load.
- Training data without provenance or content hashes, and unprotected feedback loops.
- Full probability or logprob outputs from models trained on sensitive data.
- Robustness evaluated with weak attacks only.
- No egress control, so mining and exfiltration succeed.
- Incident response that destroys evidence or misses notification deadlines.

## Checklist
- [ ] You can map attack paths on an ML platform to MITRE ATLAS and the OWASP LLM Top 10
- [ ] Model intake uses safetensors, pinned revisions, scanning, and signatures
- [ ] Training data has content-hashed manifests, provenance, and protected feedback channels
- [ ] You can run and report a membership inference audit
- [ ] You can attack a model with FGSM and PGD, and adversarially train it
- [ ] Your platform has layered controls enforced by policy, with ML-specific detection
- [ ] You can lead a security incident: contain, preserve evidence, scope, recover, notify, and learn
