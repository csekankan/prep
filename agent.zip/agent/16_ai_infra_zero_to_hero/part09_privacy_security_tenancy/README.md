# Part IX — Privacy, Security and Multi-Tenancy (Sections 37–40, lectures 253–280)

How to train on data you can't centralize, protect individuals' privacy in models, defend AI systems against attacks
on their supply chain, data, and models, and share GPU infrastructure safely and fairly between teams and customers.

| § | Section | You will be able to | Exercise |
|---|---|---|---|
| 37 | [Federated Learning Infrastructure](s37_federated_learning.md) | Design cross-device and cross-silo federated systems, aggregate updates with weighted FedAvg and secure aggregation, and handle non-IID clients | [`s37_fedavg.py`](../exercises/s37_fedavg.py) |
| 38 | [Privacy-Preserving AI](s38_privacy_preserving_ai.md) | Choose between homomorphic encryption, differential privacy, secure multi-party computation, and confidential computing, and train with DP-SGD at a chosen ε | — |
| 39 | [Advanced AI Infrastructure Security](s39_advanced_ai_security.md) | Secure the model supply chain, detect data poisoning and membership inference, harden models against adversarial examples, and respond to an AI infrastructure attack | — |
| 40 | [Multi-Tenant AI Infrastructure](s40_multi_tenant_ai.md) | Choose a tenancy model, share GPUs with Kueue quotas, borrowing, and reclaim, allocate cost, design RBAC, isolate tenants, and monitor per-tenant SLOs | [`s40_tenant_quotas.py`](../exercises/s40_tenant_quotas.py) |

```mermaid
flowchart LR
  P8["Part VIII: scale, MLOps,<br/>optimization"] --> S37["§37 Federated learning<br/>FedAvg, secure aggregation"]
  S37 --> S38["§38 Privacy-preserving AI<br/>HE, DP, MPC, enclaves"]
  P8 --> S39["§39 AI security<br/>supply chain, poisoning, adversarial"]
  S38 --> S39
  S39 --> S40["§40 Multi-tenancy<br/>quotas, RBAC, isolation, cost"]
  S40 --> NEXT["Part X: AI infrastructure<br/>in context"]
```

**How to read it:** Part IX builds on Part VIII's large-scale platform. Section 37 trains models where data stays on
devices or in separate organizations. Section 38 adds the cryptographic and statistical tools that keep individuals'
data private. Section 39 covers attacks on AI systems and how to defend against them. Section 40 brings it together on
shared infrastructure: quotas, access control, isolation, and cost per tenant. Part X then applies everything to
startups, enterprises, real-time and autonomous systems, and case studies.

**Terms in this diagram.**
- **FedAvg, secure aggregation**: federated averaging combines client model updates weighted by data size, and secure
  aggregation lets the server see only the sum of updates, not any single client's (Section 37).
- **HE, DP, MPC, enclaves**: homomorphic encryption (computing on encrypted data), differential privacy (adding
  calibrated noise so no individual's data changes results much), secure multi-party computation (several parties
  computing together on secret-shared data), and hardware enclaves for confidential computing (Section 38).
- **Supply chain, poisoning, adversarial**: attacks on models and code before deployment, on training data, and on
  model inputs at inference time (Section 39).
- **Quotas, RBAC, isolation, cost**: guaranteed and borrowable GPU shares, role-based access control, separation of
  tenants' network, nodes, GPUs, and data, and cost attribution per tenant (Section 40).
