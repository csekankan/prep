# Section 38 — Privacy-Preserving AI

> Lectures 260–266 • Assessment: quiz
> **After this section you can:** explain why models leak private data and which laws require protecting it, use
> homomorphic encryption for computation on encrypted data, train models with differential privacy (DP-SGD) and
> read ε and δ, explain secure multi-party computation and private set intersection, choose among DP, HE, MPC,
> TEEs, federated learning, and synthetic data for a given threat model and budget, and train a DP model with Opacus.
>
> Builds on: [Section 37](s37_federated_learning.md) (federated learning, secure aggregation),
> [Section 18](../part05_operating_production/s18_security_compliance.md) (security, encryption, compliance), and
> [Section 34](../part08_scale_mlops_optimization/s34_advanced_enterprise_mlops.md) (governance and audit).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 260 | Why privacy matters in AI infra | Models memorize and leak data, regulators fine for it, and infra decides where data can flow |
| 261 | Homomorphic encryption basics | Compute on encrypted data: practical for sums and small linear models, very slow for deep networks |
| 262 | Differential privacy for AI models | Clip per-example gradients and add noise, so no single record changes the model much, with a provable ε |
| 263 | Secure multi-party computation (MPC) | Parties compute a joint result from secret-shared inputs without revealing them to each other |
| 264 | Trade-offs in privacy-preserving AI | Each technique protects against different parties at a different cost in speed and accuracy |
| 265 | Industry applications of privacy-preserving AI | Telemetry, census, ads clean rooms, healthcare, and confidential AI in production |
| 266 | Lab: apply differential privacy in training | DP-SGD on MNIST with Opacus at several ε values, compared with non-private training |

```mermaid
flowchart LR
  DATA[("Sensitive data")] --> Q{"Who must not see it?"}
  Q -->|"the model's users"| DP["Differential privacy<br/>noisy training"]
  Q -->|"the compute provider"| HE["Homomorphic encryption<br/>or TEE"]
  Q -->|"the other parties"| MPC["MPC, PSI,<br/>federated learning"]
  DP & HE & MPC --> COST["Cost: accuracy, latency,<br/>compute, engineering"]
  COST --> DECIDE["Pick the cheapest layer set<br/>that covers the threat model"]
```

**How to read it:** start with who must not see the sensitive data. If it's whoever uses or queries the model,
differential privacy limits what the model reveals. If it's the provider running the computation, homomorphic
encryption or a trusted execution environment keeps data hidden during computation. If it's the other organizations
in a collaboration, MPC, private set intersection, or federated learning let them compute jointly. Every technique
costs something, and you pick the cheapest combination that covers the threats.

**Terms in this diagram.**
- **Differential privacy (DP)**: a mathematical guarantee that a result barely changes whether or not any one
  person's data is included (Lecture 262).
- **Homomorphic encryption (HE)**: encryption that allows computing on encrypted values, so the result decrypts to
  the answer (Lecture 261).
- **TEE**: trusted execution environment, hardware that keeps code and data hidden even from the machine's operator
  (Section 37).
- **MPC, PSI**: secure multi-party computation, and private set intersection, which finds common records between
  parties without revealing the rest (Lecture 263).
- **Federated learning**: training where data stays with each party (Section 37).
- **Threat model**: the written list of who you're protecting against and what they can do.

---

## Lecture 260 — Why privacy matters in AI infra

**Why it matters.** Language models have been shown to reproduce memorized training data verbatim, including names,
phone numbers, and addresses (Carlini et al. extracted such data from GPT-2 in 2021). Regulations such as GDPR allow
fines of up to 4% of global annual revenue. Where data is stored, copied, logged, and trained on is an
infrastructure decision, so privacy is an infrastructure responsibility.

**In plain words.** A model is like a student who read every letter in the archive. Even if the archive is locked,
the student might recite one of those letters word for word when asked the right question. You have to control both
the archive and what the student learned.

**Architecture: where private data flows and leaks in an AI system.**

```mermaid
flowchart LR
  SRC["Source systems<br/>PII, health, finance"] --> ING["Ingestion + lake"]
  ING --> FEATP["Features + training sets"]
  FEATP --> TRN["Training"]
  TRN --> MDL["Model weights<br/>may memorize"]
  MDL --> API["Inference API"]
  API --> LOGS[("Prompt + prediction logs")]
  ING -.->|"leak: copies, broad access"| L1["Exposure"]
  MDL -.->|"leak: extraction, membership"| L1
  LOGS -.->|"leak: sensitive prompts stored"| L1
  CTRL["Controls: minimize, pseudonymize,<br/>access control, DP, retention"] -.-> ING
  CTRL -.-> TRN
  CTRL -.-> LOGS
```

**How to read it:** sensitive data moves from source systems into a data lake, then into features and training sets,
then into the model's weights, and the model serves an API whose prompts and outputs are logged. Leaks happen at
each step: extra copies and broad access in the lake, memorization that can be extracted from the model, and
sensitive prompts kept in logs. Controls apply along the way: collect less, replace identifiers, restrict access,
train with DP, and delete on schedule.

**Terms in this diagram.**
- **PII**: personally identifiable information, such as names, emails, phone numbers, and government IDs.
- **Memorize**: a model storing specific training examples so it can reproduce them, rather than only general
  patterns.
- **Extraction, membership**: **training data extraction** prompts a model to output memorized examples. **Membership
  inference** decides whether a specific record was in the training data (Section 39).
- **Prompt + prediction logs**: stored inputs and outputs of the model, often the largest uncontrolled copy of
  sensitive data in an AI system.
- **Minimize**: collect and keep only the data needed for the purpose (data minimization, a GDPR principle).
- **Pseudonymize**: replace direct identifiers with tokens or keyed hashes. It reduces risk, but pseudonymized data is
  still personal data under GDPR.
- **Retention**: how long data is kept before deletion.

**Core ideas.**
- **Regulations that shape AI infrastructure.**
  - **GDPR** (EU): lawful basis, purpose limitation, data minimization, the right to erasure, and limits on transfers
    outside the EU.
  - **HIPAA** (US health data), **CCPA/CPRA** (California), **PIPL** (China), and **DPDP** (India) add their own rules
    on consent, residency, and breach notification.
  - The **EU AI Act** adds data governance duties for high-risk systems (Section 34).
- **Models are data.** If a model can reproduce personal data, the weights may themselves be personal data. Erasure
  requests then affect models, which is why "machine unlearning" and retraining policies exist.
- **Logs are the quiet risk.** Prompts to assistants often include health, financial, or HR details. Redact before
  storing, set short retention, and restrict access (Section 18).
- **Anonymization is hard.** Removing names isn't enough: 87% of Americans can be uniquely identified by ZIP code,
  birth date, and sex (Sweeney, 2000). Use DP or aggregation with minimum group sizes for releases.
- **Privacy by design.** Choose where data goes before building: region, which systems see raw data, and which see
  only tokens or aggregates.

**Example: the support bot that remembered a credit card.** A company fine-tuned a support model on raw chat
transcripts. A tester found that the prompt "my card number is 4111" made it complete a real customer's card number
from training data. The team retrained on transcripts with PII redacted by a detection pipeline, added a canary test
(unique fake secrets planted in training data and checked for in outputs), and cut log retention for raw prompts to
7 days.

**Senior / FAANG best practice.** Map every place sensitive data flows, including features, weights, and logs.
Minimize and pseudonymize at ingestion, redact PII before training and logging, and set retention by purpose. Treat
model weights as potentially personal data, test for memorization with planted canaries, and use DP when the model
is released or widely queried.

---

## Lecture 261 — Homomorphic encryption basics

**Why it matters.** Homomorphic encryption lets a server compute on data it can't read: a cloud service can score an
encrypted medical record and return an encrypted result only the patient can decrypt. It's the strongest protection
against the compute provider, and also the most expensive.

**In plain words.** It's like a locked glovebox in a lab. A technician can put their hands in the gloves and mix
what's inside, without ever opening the box or seeing the contents. Only the owner, with the key, can open it and see
the result. Working through gloves is just much slower than working by hand.

**Architecture: encrypted inference.**

```mermaid
sequenceDiagram
  participant C as Client (has secret key)
  participant S as Server (has model, no key)
  C->>C: encrypt features with public key, CKKS
  C->>S: ciphertext + evaluation keys
  S->>S: compute on ciphertext: dot products, polynomial activations
  S->>C: encrypted score
  C->>C: decrypt with secret key
  Note over S: server never sees features or score
```

**How to read it:** the client encrypts its features with the CKKS scheme and sends the ciphertext, plus evaluation
keys that let the server compute but not decrypt. The server runs the model's math directly on the ciphertext:
dot products and polynomial approximations of activation functions. It returns an encrypted score that only the
client can decrypt, so the server never sees either the input or the output.

**Terms in this diagram.**
- **Secret key, public key**: the client keeps the secret key for decryption. The public key encrypts.
- **CKKS**: a homomorphic encryption scheme for approximate arithmetic on real numbers, the usual choice for machine
  learning. **BFV** and **BGV** are schemes for exact integers.
- **Ciphertext**: encrypted data.
- **Evaluation keys**: extra public keys (relinearization and Galois keys) that the server needs to multiply and
  rotate encrypted vectors. They don't allow decryption.
- **Polynomial activations**: HE supports only addition and multiplication, so functions such as ReLU or sigmoid are
  replaced with polynomial approximations.

**Core ideas.**
- **Kinds of HE.**
  - **Partially homomorphic**: one operation only. **Paillier** supports addition (encrypted sums), and RSA
    supports multiplication.
  - **Fully homomorphic (FHE)**: both addition and multiplication, so any computation is possible in principle. CKKS,
    BFV, BGV, and TFHE are FHE schemes.
- **Cost.** FHE is typically 1,000–1,000,000× slower than plaintext, and ciphertexts are 10–1,000× larger.
  Multiplications add "noise" inside the ciphertext. After a set depth you must stop or "bootstrap" (an expensive
  refresh), so deep networks are very costly.
- **What's practical today.**
  - Encrypted sums and averages (Paillier, or CKKS), as in some cross-silo FL.
  - Linear and logistic regression scoring, and small tree ensembles or shallow networks.
  - Encrypted search and private information retrieval.
  - Libraries: Microsoft SEAL, OpenFHE, TenSEAL (Python), and Zama's Concrete ML (turns scikit-learn-style models into
    FHE circuits).
- **Hardware acceleration.** GPU FHE libraries and dedicated FHE accelerators are emerging. They narrow the gap but
  don't remove it.
- **HE protects data in use from the server, not the output.** Combine with DP if the results are published.

```python
import math, random

def keygen(p=1_000_003, q=1_000_033):            # toy primes. Real keys use 2048-bit or larger n
    n = p * q
    lam = math.lcm(p - 1, q - 1)
    return (n,), (n, lam, pow(lam, -1, n))

def encrypt(pub, m, rng=random.Random(1)):
    (n,) = pub; n2 = n * n
    r = rng.randrange(1, n)
    return pow(n + 1, m, n2) * pow(r, n, n2) % n2

def decrypt(priv, c):
    n, lam, mu = priv
    return (pow(c, lam, n * n) - 1) // n * mu % n

pub, priv = keygen()
salaries = [83_000, 91_500, 77_250]
cts = [encrypt(pub, s) for s in salaries]        # each department encrypts its value
total = math.prod(cts) % (pub[0] ** 2)           # server multiplies ciphertexts = adds plaintexts
print(decrypt(priv, total))                      # 251750, without the server seeing any salary
print(decrypt(priv, pow(cts[0], 3, pub[0] ** 2)))  # 249000: ciphertext^3 = 3 x plaintext
```

In the code, this is the **Paillier** scheme. Encryption raises n + 1 to the message and multiplies by a random
value to the power n, so the same message encrypts differently each time. Multiplying two ciphertexts gives an
encryption of the sum of their messages, and raising a ciphertext to the power k multiplies its message by k. The
server can compute totals and weighted sums without the secret key. The toy primes are far too small for security.

```python
import tenseal as ts

ctx = ts.context(ts.SCHEME_TYPE.CKKS, poly_modulus_degree=8192, coeff_mod_bit_sizes=[60, 40, 40, 60])
ctx.global_scale = 2**40
ctx.generate_galois_keys()
x_enc = ts.ckks_vector(ctx, [0.7, 1.2, -0.4, 2.1])           # client encrypts features
weights, bias = [0.5, -0.25, 1.1, 0.3], -0.2
logit_enc = x_enc.dot(weights) + bias                          # server computes on ciphertext
print(logit_enc.decrypt())                                     # about [0.04], decrypted by the client
```

In the TenSEAL code, `poly_modulus_degree` and `coeff_mod_bit_sizes` set the security level and how many
multiplications are possible before the noise is too large. `global_scale` sets the fixed-point precision for real
numbers. `generate_galois_keys` creates the keys that let the server rotate encrypted vectors, which dot products
need. The server applies a logistic regression's weights to the encrypted features. The client would decrypt and
apply the sigmoid itself.

**Example: encrypted credit scoring.** A fintech wanted to score applicants with a partner bank's model without
revealing applicants' raw data, and the bank didn't want to reveal its model. A logistic regression with 40 features
under CKKS took about 30 ms per score on a server CPU, against microseconds in plaintext, which was acceptable for
loan applications. A 3-layer neural network took over 2 seconds per score, so they kept the linear model for the
encrypted path.

**Senior / FAANG best practice.** Use HE when the compute provider must not see the data and the computation is
shallow: sums, linear models, small trees, or retrieval. Benchmark latency and ciphertext size early, use established
libraries with standard security parameters, and design the model for HE (low multiplicative depth, polynomial
activations). For deep models, consider TEEs instead.

---

## Lecture 262 — Differential privacy for AI models

**Why it matters.** Differential privacy is the only widely accepted mathematical definition of privacy for models
and statistics. It bounds what anyone can learn about an individual from the trained model, no matter what other
information they have. The US Census Bureau, Apple, Google, and Microsoft use it in production.

**In plain words.** Imagine a survey where each answer is slightly blurred before being counted. The overall results
are still accurate when many people answer, but nobody can be sure what any single person said. DP training blurs
each person's influence on the model in the same way.

**Architecture: one DP-SGD step.**

```mermaid
flowchart LR
  BATCH["Batch sampled<br/>with probability q"] --> PEG["Per-example gradients"]
  PEG --> CLIPD["Clip each to norm C"]
  CLIPD --> SUMD["Sum"]
  SUMD --> NOISED["Add Gaussian noise<br/>std = sigma times C"]
  NOISED --> AVGD["Divide by batch size"]
  AVGD --> UPD["Optimizer step"]
  UPD --> ACCD["Accountant<br/>epsilon after T steps"]
```

**How to read it:** each step samples a batch, with every example included with probability q. Instead of one
gradient for the whole batch, it computes each example's gradient separately and clips each to a maximum norm C, so
no example can push the model too far. The clipped gradients are summed, Gaussian noise proportional to C is added,
and the result is divided by the batch size and used for a normal optimizer step. An accountant tracks the total
privacy cost ε over all steps.

**Terms in this diagram.**
- **Sampled with probability q**: Poisson sampling, where each example independently joins the batch with
  probability q (such as batch size ÷ dataset size). The privacy analysis relies on this randomness.
- **Per-example gradients**: the gradient of the loss for each example separately, which costs more memory and compute
  than one batch gradient.
- **Clip to norm C**: rescale any per-example gradient whose L2 norm exceeds C down to norm C.
- **Sigma (noise multiplier)**: the noise standard deviation relative to C. Larger sigma means more privacy and more
  accuracy loss.
- **Accountant, epsilon after T steps**: a calculation (such as the Rényi DP or PRV accountant) of the total privacy
  loss ε for a given δ after T training steps.

**Core ideas.**
- **The definition.** A training algorithm is (ε, δ)-DP if, for any two datasets differing in one person, the
  probability of any output changes by at most a factor of e^ε, except with probability δ.
  - **ε** is the privacy budget: around 1 is strong, up to 8 is common in practice, and above 10 gives weak formal
    guarantees, though still better than none.
  - **δ** should be smaller than 1 ÷ (dataset size), such as 10⁻⁵ for 100,000 records.
- **The unit of privacy matters.** Example-level DP protects one record. If one person contributes many records (many
  messages), you need user-level DP, which bounds each user's total contribution.
- **Cost.** DP-SGD typically costs a few points of accuracy at ε around 8 on standard benchmarks, and more at smaller
  ε. It needs larger batches, more epochs, and per-example gradients, which can make training 2–10× slower.
- **Tricks that help.**
  - Pretrain on public data, then fine-tune privately: DP fine-tuning of large pretrained models loses far less
    accuracy than DP training from scratch.
  - Use large batches, and tune C (clip to around the median gradient norm).
  - Replace BatchNorm with GroupNorm, since BatchNorm mixes examples in a batch.
- **DP for LLMs.** DP fine-tuning with LoRA is practical. Google's VaultGemma (2025) showed a 1B model trained from
  scratch with DP, with quality comparable to non-private models from about five years earlier.
- **Tools.** Opacus (PyTorch), TensorFlow Privacy, JAX Privacy, and Google's DP libraries for statistics.

```python
from opacus import PrivacyEngine

model, optimizer, train_loader = PrivacyEngine(accountant="prv").make_private_with_epsilon(
    module=model, optimizer=optimizer, data_loader=train_loader,
    target_epsilon=3.0, target_delta=1e-5, epochs=10, max_grad_norm=1.0)
```

In the code, `make_private_with_epsilon` computes the noise multiplier needed to reach ε = 3 at δ = 10⁻⁵ after 10
epochs, and wraps the model, optimizer, and data loader. The model computes per-example gradients, the optimizer clips
and adds noise, and the loader uses Poisson sampling. `max_grad_norm` is the clipping bound C. `accountant="prv"`
selects the privacy random variable accountant, which gives tight ε estimates.

**Example: DP release for a hospital network.** A hospital network wanted to share a readmission-risk model with
partner clinics without exposing patients. DP-SGD from scratch at ε = 3 lost 6 points of AUC. Pretraining on a public
dataset of de-identified records and then DP fine-tuning on their own data at ε = 3, with batch size 4,096, reduced the
loss to 1.5 points. The model card stated the ε, δ, and unit of privacy (one patient).

**Senior / FAANG best practice.** Pick the privacy unit (record or user) and the (ε, δ) target before training, and
state them in the model card. Pretrain on public data and fine-tune with DP, use large batches and tuned clipping, and
replace BatchNorm. Use a tight accountant, report ε honestly, and test memorization with planted canaries as a sanity
check alongside the formal guarantee.

---

## Lecture 263 — Secure multi-party computation (MPC)

**Why it matters.** Banks that want to detect fraud rings across institutions, or advertisers and publishers that want
to measure campaigns, can't share raw data with each other. MPC lets several parties compute a joint result, such as
a model, a statistic, or a list of shared customers, while each party's inputs stay hidden from the others.

**In plain words.** Three friends want their average salary without telling anyone their own. Each splits their salary
into three random pieces that add up to it, keeps one, and gives one to each friend. Everyone adds up the pieces they
hold and announces only that sum. The three sums add up to the total, but no one ever saw anyone else's salary.

**Architecture: additive secret sharing and private set intersection.**

```mermaid
flowchart TB
  subgraph SS["Additive secret sharing"]
    X["Party A input x"] --> SH["Split into random shares<br/>x1 + x2 + x3 = x mod p"]
    SH --> P1["Server 1 holds x1, y1"]
    SH --> P2["Server 2 holds x2, y2"]
    SH --> P3["Server 3 holds x3, y3"]
    P1 & P2 & P3 --> RES["Each computes locally,<br/>combine only the result"]
  end
  subgraph PSIB["Private set intersection"]
    BA["Bank A customer IDs"] --> OPRF["Oblivious PRF / ECDH-blinded IDs"]
    BB["Bank B customer IDs"] --> OPRF
    OPRF --> INT["Only the overlap is learned"]
  end
```

**How to read it:** in additive secret sharing, each party splits its input into random shares that add up to the
input modulo a large prime, and sends one share to each of several servers. Each share alone looks random. The servers
compute on their shares, and only the final result is recombined. In private set intersection, two banks transform
their customer IDs with a blinding function, compare the blinded values, and learn only which customers they have
in common, nothing about the rest.

**Terms in this diagram.**
- **Random shares, mod p**: numbers chosen randomly except that their sum equals the input modulo a large prime p, so
  any subset smaller than all of them reveals nothing.
- **Compute locally**: addition can be done on shares directly. Multiplication needs extra interaction between
  servers, such as precomputed **Beaver triples**.
- **Private set intersection (PSI), overlap**: a protocol where two parties learn the items in both of their sets (the
  overlap), and nothing else.
- **Oblivious PRF / ECDH-blinded IDs**: ways to transform IDs so they can be compared without being revealed. In
  **ECDH-based PSI**, each party "locks" IDs with its own secret key on an elliptic curve. Doubly locked IDs match if
  and only if the originals match.

**Core ideas.**
- **Building blocks.**
  - **Secret sharing** (additive or Shamir, Section 37): good for arithmetic, such as sums and linear algebra, with
    several servers.
  - **Garbled circuits**: good for comparisons and non-linear functions between two parties.
  - **Oblivious transfer**: a primitive underneath both, where a receiver gets one of several items without the sender
    knowing which.
- **Trust models.**
  - **Semi-honest** (honest but curious): parties follow the protocol but try to learn. This is cheaper.
  - **Malicious**: parties may cheat, which needs extra checks that cost 2–10× more.
  - **Non-collusion assumption**: many protocols are secure only if the servers don't collude, so choose operators
    from different organizations.
- **Cost is mostly network.** MPC needs many rounds of messages between parties. Training even a modest neural
  network can be 100–10,000× slower than plaintext, and latency between parties matters a lot. Keep parties in nearby
  regions with fast links.
- **Practical uses today.** PSI for matching customers (ads measurement, fraud consortia), secure statistics and
  linear models across organizations, and key management (threshold signatures). Frameworks include CrypTen
  (PyTorch), MP-SPDZ, and commercial platforms.

```python
import random

P = 2**61 - 1                                     # a large prime modulus

def share(x, parties=3, rng=random.Random(7)):
    s = [rng.randrange(P) for _ in range(parties - 1)]
    return s + [(x - sum(s)) % P]

def reveal(shares):
    return sum(shares) % P

a = share(120)                                    # bank A's flagged-transaction count
b = share(345)                                    # bank B's
summed = [(x + y) % P for x, y in zip(a, b)]      # each server adds the shares it holds
print(a[0], summed[0])                            # random-looking numbers
print(reveal(summed))                             # 465, the only value anyone learns
```

In the code, each input becomes three shares that look random but add up to the input modulo P. Each server adds the
two shares it holds, one from each bank, without any communication. Combining the three result shares reveals only
the total, 465, and neither bank's count.

**Example: a fraud ring across five banks.** Five banks suspected the same mule accounts were moving money between
them. Using PSI on hashed-and-blinded account identifiers, then MPC to compute per-account transaction totals across
banks, they found 214 accounts present at three or more banks with large flows, without any bank revealing its other
customers. The PSI step on 20 million IDs per bank took about 40 minutes, and the MPC totals about 2 hours, run
weekly.

**Senior / FAANG best practice.** Use PSI for record matching and MPC for joint statistics or small models across
organizations. State the trust model (semi-honest or malicious, and who must not collude), pick operators from
different organizations, and place parties close together on the network. Keep the computation simple, benchmark
early, and combine with DP when the results are shared widely.

---

## Lecture 264 — Trade-offs in privacy-preserving AI

**Why it matters.** No privacy technique is free, and each protects against different parties. Choosing the wrong one
either leaves a real threat uncovered or spends 1,000× more compute than needed. Picking well starts from the threat
model and ends with a measured cost.

**In plain words.** Locks, alarms, safes, and guards all protect a house, but against different risks and at very
different prices. You don't put a bank vault door on a garden shed, and a garden lock doesn't stop a professional
burglar.

**Architecture: choosing privacy techniques.**

```mermaid
flowchart TB
  START["Threat model"] --> Q1{"Must the compute<br/>operator be blind?"}
  Q1 -->|"yes, shallow math"| HEC["HE"]
  Q1 -->|"yes, deep model"| TEEC["TEE with attestation"]
  Q1 -->|"no"| Q2{"Several organizations,<br/>data can't move?"}
  Q2 -->|"yes"| FLMPC["FL with secure aggregation,<br/>or MPC, PSI"]
  Q2 -->|"no"| Q3{"Model or stats<br/>released or widely queried?"}
  Q3 -->|"yes"| DPC["Differential privacy"]
  Q3 -->|"no"| BASE["Access control, minimization,<br/>pseudonymization, retention"]
  FLMPC --> Q3
  HEC --> Q3
  TEEC --> Q3
```

**How to read it:** if the compute operator must not see data, use HE for shallow math or a TEE for deep models. If
several organizations can't move their data, use federated learning with secure aggregation, or MPC and PSI. In every
case, if the model or statistics are released or queried widely, add differential privacy. If none of these apply,
standard controls (access control, data minimization, pseudonymization, retention) are the baseline.

**Terms in this diagram.**
- **Compute operator**: whoever runs the machines, such as a cloud provider or a partner's data center.
- **Shallow math, deep model**: computations with few multiplications in sequence (sums, linear models), and deep
  neural networks with many layers.
- **TEE with attestation**: a hardware enclave that proves to clients, through a signed report, exactly what code it's
  running before they send data. Examples include Intel TDX, AMD SEV-SNP, and NVIDIA H100 confidential computing.
- **Released or widely queried**: published, shared with partners, or served to many users who could probe it.
- **Baseline controls**: the standard measures from Sections 18 and 34, which every system needs regardless.

**Core ideas.**

| Technique | Protects against | Typical overhead | Accuracy impact | Maturity |
|---|---|---|---|---|
| Access control, minimization | Insiders, breaches of unneeded data | Low | None | High |
| Differential privacy | Model users, published results | 2–10× training time | Small to large, depends on ε | High (Census, Apple, Google) |
| Federated learning | Central collection of raw data | Communication, engineering | Some (non-IID) | Medium to high |
| Secure aggregation | FL server seeing single updates | Client CPU, protocol rounds | None | High at Google scale |
| TEE (confidential computing) | Cloud operator, host OS | ~5–15% CPU, GPU varies | None | Medium to high |
| Homomorphic encryption | Compute operator | 1,000–1,000,000× | Approximation for activations | Medium for shallow models |
| MPC, PSI | Other participating organizations | 100–10,000× (network) | None for exact protocols | Medium (PSI high) |
| Synthetic data | Downstream data users | Generator training | Fidelity loss | Medium, needs DP to be safe |

- **Combine layers.** The strongest systems stack them: FL + secure aggregation + DP (Section 37), or TEE + DP for
  confidential training.
- **Synthetic data is not automatically private.** Generators can memorize. Train the generator with DP if the
  synthetic data is to be shared.
- **Price the overhead in the infrastructure plan.** DP needs more GPU-hours, MPC needs low-latency links between
  parties, HE needs CPU or accelerators, and TEEs need specific instance types (Section 18).
- **Usability matters.** A technique that requires every data scientist to be a cryptographer won't be adopted. Wrap
  it in the platform (Section 33).

**Example: three proposals, one choice.** A health-tech company wanted to train on data from 6 hospitals. Proposals:
full MPC training (estimated 900× slower, months per model), HE (not feasible for their CNN), and FL with secure
aggregation plus DP fine-tuning at ε = 5 per patient, running on each hospital's GPUs (2.5× the cost of central
training, 1.8 points lower AUC). They chose FL with DP, and used PSI separately to deduplicate patients who visited
several hospitals.

**Senior / FAANG best practice.** Start from a written threat model, map each threat to a technique, and stack the
cheapest combination that covers them all. Price the overhead in GPU-hours, latency, and engineering. Treat synthetic
data as private only if its generator was trained with DP, and wrap privacy techniques in platform tooling so teams
actually use them.

---

## Lecture 265 — Industry applications of privacy-preserving AI

**Why it matters.** These techniques have moved from papers to production. Seeing where they're used, and the
infrastructure behind each, shows which are ready for your systems and what running them takes.

**In plain words.** Like seatbelts, airbags, and crumple zones, each privacy technique was once experimental and is now
standard in certain kinds of vehicles. Knowing which vehicles use which feature tells you what's proven.

**Architecture: production patterns.**

```mermaid
flowchart LR
  TEL["Device telemetry<br/>Apple, Google, Microsoft"] --> LDP["Local DP<br/>noise on device"]
  CEN["National statistics<br/>US Census 2020"] --> CDP["Central DP<br/>noise on published tables"]
  ADS["Ads measurement<br/>clean rooms"] --> PSIA["PSI + aggregation thresholds"]
  HC["Healthcare research<br/>hospital consortia"] --> FLH["Cross-silo FL<br/>FLARE, Flower"]
  KB["Keyboards, on-device AI"] --> XDFL["Cross-device FL + DP"]
  CAI["Confidential AI<br/>cloud LLM requests"] --> TEEA["GPU TEEs + attestation<br/>Private Cloud Compute"]
```

**How to read it:** each row pairs a production use with its technique. Device telemetry uses local DP, where noise
is added on the device. The US Census used central DP on its published tables. Advertising clean rooms use PSI with
minimum aggregation sizes. Hospital consortia use cross-silo FL. Keyboards use cross-device FL with DP. Confidential AI
services process requests in attested GPU enclaves.

**Terms in this diagram.**
- **Local DP**: each device randomizes its own data before sending, so even the collector can't trust any single
  report. It needs very large populations to get accurate totals.
- **Central DP**: a trusted curator holds the raw data and adds noise to outputs, which is more accurate for the same ε.
- **Clean rooms**: controlled environments (such as Google Ads Data Hub, AWS Clean Rooms, Snowflake data clean rooms)
  where two companies' data is joined and only aggregated results above a minimum group size leave.
- **Aggregation thresholds**: rules that results must cover at least N people (for example 50) before release.
- **Private Cloud Compute**: Apple's system for running AI requests in the cloud on attested servers that don't
  retain data and whose software images can be inspected by researchers.

**Core ideas.**
- **Telemetry with local DP.** Apple collects emoji and word-usage statistics with local DP. Google's RAPPOR did the
  same for Chrome settings. Microsoft uses it for Windows telemetry. These work because there are millions of users.
- **US Census 2020** published redistricting data with central DP, choosing a total privacy-loss budget and spending
  it across geographic levels. It sparked debate on accuracy for small areas, which shows that setting ε is a policy
  decision as well as a technical one.
- **Ads measurement.** Clean rooms and PSI match advertiser conversions with publisher exposure data. Aggregation
  thresholds and sometimes DP noise limit what's revealed about individuals.
- **Healthcare.** Cross-silo FL consortia train imaging and oncology models across hospitals with NVIDIA FLARE or
  Flower, often with secure aggregation, and sometimes DP.
- **Confidential AI.** Cloud providers offer confidential VMs and GPUs (H100 and newer support confidential
  computing), so model providers and customers can process sensitive data with attestation. Apple's Private Cloud
  Compute and similar designs make the server's software verifiable.
- **Common infrastructure needs.** Key management, attestation verification, privacy-budget tracking per dataset, and
  audit of every release (Section 34).

**Example: a retailer and a publisher in a clean room.** A retailer and a streaming publisher wanted to measure
whether ads drove store purchases. In a cloud clean room, they matched customers with PSI on hashed, salted emails, and
the query policy allowed only aggregates over at least 100 customers, with DP noise on the counts. The study showed a
4.2% lift (±0.6%), and neither company received the other's customer list.

**Senior / FAANG best practice.** Use proven patterns: local DP for large-scale telemetry, central DP for published
statistics, clean rooms with PSI and thresholds for partner measurement, cross-silo FL for consortia, and attested
TEEs for confidential AI. Run the supporting infrastructure (keys, attestation, budget tracking, audit) as shared
platform services, and treat ε choices as documented policy decisions.

---

## Lecture 266 — Lab: apply differential privacy in training

**Goal:** train an MNIST classifier with DP-SGD using Opacus at ε = 1, 3, and 8 (δ = 10⁻⁵), compare accuracy and
training time against non-private training, and read the privacy accounting.

**What you're building:** one training script with an `--epsilon` flag (or none, for non-private training), a small
CNN using GroupNorm, and a results table.

```mermaid
flowchart LR
  DATAL["MNIST<br/>60K train"] --> MODELL["Small CNN<br/>GroupNorm, no BatchNorm"]
  MODELL --> ENG{"--epsilon"}
  ENG -->|"none"| SGDL["Plain SGD"]
  ENG -->|"1, 3, 8"| PE["Opacus PrivacyEngine<br/>clip 1.0, noise from target"]
  SGDL & PE --> REP["Test accuracy, time,<br/>final epsilon"]
```

**How to read the diagram:** the same small CNN trains on MNIST either with plain SGD or through Opacus' privacy
engine (the `PrivacyEngine` class, which wraps the model, optimizer, and data loader for DP-SGD). Opacus computes the noise multiplier needed for each target ε, and clips per-example gradients at 1.0. Each run
reports test accuracy, training time, and the ε actually spent. The model uses **GroupNorm**, which normalizes within
each example, because **BatchNorm** mixes statistics across examples in a batch, which breaks per-example privacy
accounting.

**Prerequisites:** Python 3.10+, `pip install torch torchvision opacus`. A GPU helps but isn't required: each run takes
a few minutes on a laptop CPU.

### Step 1 — Training script

```python
# dp_mnist.py
import argparse, time, warnings
import torch, torchvision
from torch import nn
from opacus import PrivacyEngine

warnings.filterwarnings("ignore")
p = argparse.ArgumentParser()
p.add_argument("--epsilon", type=float, default=None)
p.add_argument("--epochs", type=int, default=10)
p.add_argument("--batch", type=int, default=512)
a = p.parse_args()
torch.manual_seed(0)
dev = "cuda" if torch.cuda.is_available() else "cpu"

tf = torchvision.transforms.Compose([torchvision.transforms.ToTensor(),
                                     torchvision.transforms.Normalize((0.1307,), (0.3081,))])
train_ds = torchvision.datasets.MNIST("data", train=True, download=True, transform=tf)
test_ds = torchvision.datasets.MNIST("data", train=False, download=True, transform=tf)
train = torch.utils.data.DataLoader(train_ds, batch_size=a.batch, shuffle=True, num_workers=2)
test = torch.utils.data.DataLoader(test_ds, batch_size=1024)

model = nn.Sequential(
    nn.Conv2d(1, 16, 8, 2, padding=3), nn.GroupNorm(4, 16), nn.Tanh(), nn.MaxPool2d(2, 1),
    nn.Conv2d(16, 32, 4, 2), nn.GroupNorm(4, 32), nn.Tanh(), nn.MaxPool2d(2, 1),
    nn.Flatten(), nn.Linear(32 * 4 * 4, 32), nn.Tanh(), nn.Linear(32, 10)).to(dev)
opt = torch.optim.SGD(model.parameters(), lr=2.0 if a.epsilon else 0.1, momentum=0.0 if a.epsilon else 0.9)

engine = None
if a.epsilon:
    engine = PrivacyEngine(accountant="prv")
    model, opt, train = engine.make_private_with_epsilon(
        module=model, optimizer=opt, data_loader=train, epochs=a.epochs,
        target_epsilon=a.epsilon, target_delta=1e-5, max_grad_norm=1.0)
    print(f"noise multiplier {opt.noise_multiplier:.3f}")

t0 = time.time()
for ep in range(a.epochs):
    model.train()
    for x, y in train:
        x, y = x.to(dev), y.to(dev)
        opt.zero_grad()
        nn.functional.cross_entropy(model(x), y).backward()
        opt.step()

model.eval(); correct = 0
with torch.no_grad():
    for x, y in test:
        correct += (model(x.to(dev)).argmax(1).cpu() == y).sum().item()
eps = engine.get_epsilon(1e-5) if engine else float("inf")
print(f"RESULT target_eps={a.epsilon} spent_eps={eps:.2f} acc={correct / len(test_ds):.4f} "
      f"time={time.time() - t0:.0f}s")
```

In the code, the CNN uses `tanh` activations and GroupNorm, a combination known to work well with DP-SGD. DP runs use
a high learning rate (2.0) without momentum, because the clipped, noisy gradients are small and averaged. Opacus
replaces the data loader with one that uses Poisson sampling, so batch sizes vary around 512. `opt.noise_multiplier`
is the σ that Opacus chose for the target ε. `engine.get_epsilon(1e-5)` reports the ε actually spent at δ = 10⁻⁵.

### Step 2 — Run four configurations

```bash
python3 dp_mnist.py | tail -1
for e in 8 3 1; do python3 dp_mnist.py --epsilon $e | tail -2; done
```

### Step 3 — Experiments

- Change `max_grad_norm` to 0.1 and 10 at ε = 3, and see accuracy fall on both sides of a good value.
- Halve `--batch` to 256 at ε = 3. The noise multiplier drops, but accuracy usually gets worse, because there's less
  signal per noisy step.
- Train for 20 epochs at the same target ε, and see the noise multiplier increase to keep the budget.
- Replace a GroupNorm with `nn.BatchNorm2d` and see Opacus refuse it (its validator flags incompatible layers).

**Expected results:**
- Non-private: test accuracy about 0.99.
- ε = 8: about 0.96–0.98. ε = 3: about 0.95–0.97. ε = 1: about 0.90–0.95.
- Spent ε printed for each DP run matches the target within about 0.01.
- Noise multiplier rises as ε falls, roughly 0.7–0.9 at ε = 8 and 1.5–2.5 at ε = 1 for these settings.
- DP runs take about 1.5–4× longer than the non-private run, because of per-example gradients.

---

## FAANG deep-dive notes

**How big tech does it.** Privacy is layered and owned as platform infrastructure. Google uses DP in Gboard training
and for published statistics (such as COVID-19 mobility reports), and offers open-source DP libraries. Apple uses
local DP for telemetry and Private Cloud Compute for server-side AI. Meta and Google run clean-room products for
advertisers with aggregation thresholds. Confidential computing on CPUs and GPUs is offered by all major clouds.
Internally, data is classified, PII is detected and redacted at ingestion, privacy budgets are tracked per dataset,
and privacy reviews are part of the launch process (Section 34).

**Staff review questions.**
- What's the threat model: which parties must not see which data?
- Where can personal data end up: features, weights, logs, caches, backups?
- What's the privacy unit and (ε, δ) for any DP release, and who approved the value?
- For HE or MPC, what's the measured latency and cost, and is the computation shallow enough?
- For TEEs, how is attestation verified, and what happens if verification fails?
- How are erasure requests handled for data that trained a model?

**Interview question.** "Design a system for 5 banks to jointly train a fraud model without sharing raw data."

**Typical system-design prompt:** *Five banks want a shared fraud model. Regulators forbid sharing raw customer
data. Design the training and serving infrastructure, and explain what each bank and the operator can learn.*

**1. Clarify first:** Do the banks share customers (needed for entity matching)? What features are allowed? Who
operates the infrastructure? What's the acceptable accuracy loss compared with a pooled model? Real-time scoring
latency?

**2. Back-of-envelope sizing:**
- Data: 50 million transactions per bank per month. Model: gradient-boosted trees or a small network.
- PSI for shared customers: 20 million IDs per bank, pairwise, about 30–60 minutes per pair with ECDH PSI, run weekly.
- Cross-silo FL: 5 clients, every round includes all of them. 200 rounds × a 50 MB update = 50 GB transferred per
  bank per training run, which is fine over dedicated links.
- DP at ε = 4 per customer adds roughly 2–3× training compute and an estimated 1–2 points of recall.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Joint training | MPC | FL + secure aggregation | FL for model training. MPC for simple joint statistics |
| Operator trust | Trusted third party | TEE with attestation | TEE so banks can verify the aggregator code |
| Release protection | None | User-level DP | DP if the model is shared with all banks |
| Entity matching | Hashed IDs | PSI | PSI. Plain hashes of IDs can be reversed by guessing |
| Serving | Central model in TEE | Each bank serves a copy | Each bank serves locally for latency and data control |

**4. Follow-up questions with crisp answers:**
- *Why not just hash customer IDs?* IDs are guessable, so hashes can be reversed by hashing candidates. Use PSI with
  secret keys.
- *How does a bank know the aggregator isn't logging updates?* Run it in a TEE with attestation of the exact code
  image, plus secure aggregation.
- *A bank sends poisoned updates. Defense?* Clip update norms, monitor per-round validation on each bank's holdout,
  and use robust aggregation (Section 39).
- *Erasure request for a customer?* Retrain from the next snapshot without them. DP bounds their influence meanwhile.

**Debug this (common onsite question):** "After moving training to DP-SGD at ε = 3, accuracy fell from 94% to 71%."
1. Check the model: it uses BatchNorm, which Opacus had to replace incorrectly with a custom workaround.
2. Check the batch size: 64, so noise overwhelms the signal.
3. Check pretraining: training from scratch, no public pretraining.
4. Fix: GroupNorm, batch size 4,096, a tuned clipping norm, and pretraining on public data. Accuracy recovers to 91%.

The lesson: DP accuracy depends heavily on setup. Large batches, compatible layers, and public pretraining matter
most.

**5. What separates senior from staff answers:** a senior engineer applies DP-SGD or sets up FL. A staff engineer
starts from the threat model, maps each threat to a technique, stacks them (PSI, FL, secure aggregation, TEE, DP),
prices the overhead, decides who chooses ε and documents it, and handles erasure and audit.

**Red flags:**
- "We removed names, so it's anonymous."
- Fine-tuning on raw transcripts and logs with PII.
- Hashing guessable IDs and calling it private matching.
- DP with no stated ε, δ, or privacy unit.
- HE or MPC proposed for deep networks without benchmarks.
- Synthetic data shared as "private" without a DP-trained generator.
- Prompt logs kept indefinitely.

---

## Quiz

<details><summary>1. Why can a trained model be a privacy risk even if the training data is deleted?</summary>
Models can memorize examples and reproduce them (training data extraction), or reveal whether a record was used
(membership inference). The weights themselves can contain personal data.
</details>

<details><summary>2. What can Paillier encryption compute on ciphertexts, and what can't it?</summary>
Additions of encrypted values and multiplication by plaintext constants. It can't multiply two encrypted values, which
needs a fully homomorphic scheme such as CKKS or BFV.
</details>

<details><summary>3. What are the two key operations in DP-SGD?</summary>
Clipping each example's gradient to a maximum norm C, and adding Gaussian noise scaled to C to the summed gradients
before the update. An accountant tracks the resulting ε.
</details>

<details><summary>4. What do ε and δ mean, and what are typical values?</summary>
ε bounds how much any one person can change the output distribution (factor e^ε). δ is a small probability that the
bound fails. ε around 1–8 is common in practice, and δ is set below 1 divided by the dataset size.
</details>

<details><summary>5. Why does DP-SGD use GroupNorm instead of BatchNorm?</summary>
BatchNorm computes statistics across all examples in a batch, so one example affects others' outputs, which breaks
per-example gradient clipping and privacy accounting. GroupNorm works within each example.
</details>

<details><summary>6. What does private set intersection reveal?</summary>
Only the items both parties have in common, and nothing about the items that aren't shared.
</details>

<details><summary>7. When would you choose a TEE over homomorphic encryption?</summary>
When the operator must not see the data but the computation is deep (such as a neural network or LLM), where HE would be
far too slow. A TEE runs at near-native speed, with trust placed in hardware and attestation.
</details>

<details><summary>8. Is synthetic data automatically private?</summary>
No. The generator can memorize and reproduce real records. Only synthetic data from a generator trained with
differential privacy has a formal guarantee.
</details>

## Failure modes
- PII in training data or logs, later reproduced by the model.
- "Anonymized" data re-identified through quasi-identifiers.
- Guessable IDs hashed and treated as private for matching.
- DP-SGD with small batches and BatchNorm, giving unusable accuracy, so DP is abandoned.
- ε chosen after training to look good, or not reported at all.
- HE or MPC projects started without latency benchmarks, then cancelled.
- MPC servers run by parties that can collude.
- TEE deployments that don't verify attestation.
- Erasure requests that ignore models trained on the data.

## Checklist
- [ ] You can map where personal data flows in an AI system, including weights and logs
- [ ] You can explain which computations are practical with HE, and demonstrate additive HE
- [ ] You can configure DP-SGD, choose ε and δ, and explain the privacy unit
- [ ] You can explain secret sharing, MPC trust models, and PSI
- [ ] You can choose a privacy technique stack from a threat model and price its overhead
- [ ] You know the production patterns for telemetry, census, clean rooms, healthcare, and confidential AI
- [ ] You trained MNIST with Opacus at several ε values and compared accuracy and time
