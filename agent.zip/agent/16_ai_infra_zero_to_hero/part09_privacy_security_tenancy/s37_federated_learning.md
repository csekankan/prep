# Section 37 — Federated Learning Infrastructure

> Lectures 253–259 • Assessments: quiz, [Implement weighted federated averaging](#assessment--implement-weighted-federated-averaging)
> • Exercise: [`s37_fedavg.py`](../exercises/s37_fedavg.py)
> **After this section you can:** explain when federated learning is the right tool and what it does and doesn't
> protect, design cross-device and cross-silo FL systems, run FedAvg in TensorFlow Federated, explain how secure
> aggregation hides individual updates and survives dropouts, handle non-IID data, client drift, and stragglers,
> and deploy and train models on edge devices at fleet scale.
>
> Builds on: [Section 21](../part06_edge_mobile/s21_edge_ai_basics.md) and
> [Section 23](../part06_edge_mobile/s23_mobile_ai.md) (edge and mobile AI),
> [Section 8](../part02_data_gpus_training/s08_distributed_training.md) (data-parallel training), and
> [Section 18](../part05_operating_production/s18_security_compliance.md) (security and compliance).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 253 | What is federated learning? | Send the model to the data, train locally, and combine only the updates |
| 254 | Privacy-preserving AI at scale | FL alone isn't private. Add secure aggregation and differential privacy, and account for the privacy budget |
| 255 | Federated learning with TensorFlow Federated | TFF simulates FedAvg over many clients in Python before you build production FL |
| 256 | Secure aggregation protocols | Pairwise masks cancel in the sum, so the server sees only the total, even when clients drop out |
| 257 | Federated data challenges | Non-IID data, client drift, uneven work, stragglers, and evaluating data you can't see |
| 258 | Edge deployment of federated models | Eligibility rules, small compressed updates, on-device training runtimes, and staged rollouts |
| 259 | Lab: train a federated model with TFF | FedAvg on federated EMNIST, with per-round metrics and centralized evaluation |

```mermaid
flowchart LR
  SRV["FL server<br/>global model, round plan"] -->|"model + config"| C1["Client 1<br/>phone or hospital"]
  SRV -->|"model + config"| C2["Client 2"]
  SRV -->|"model + config"| CN["Client N"]
  C1 -->|"masked update, n1"| SA["Secure aggregation<br/>only the sum is visible"]
  C2 -->|"masked update, n2"| SA
  CN -->|"masked update, nN"| SA
  SA --> AVG["Weighted average<br/>plus DP noise"]
  AVG --> SRV
  D1[("Local data<br/>never leaves")] -.- C1
```

**How to read it:** the server sends the current global model and a training configuration to a sample of clients,
such as phones or hospitals. Each client trains on its own local data, which never leaves the device, and sends back
an update with its example count. Secure aggregation lets the server see only the sum of the updates. The server
computes the weighted average, optionally adds differential privacy noise, updates the global model, and starts the
next round.

**Terms in this diagram.**
- **FL server, round plan**: the coordinating service holding the global model, and the plan for each round (which
  clients, how many local steps, and what to send back).
- **Client**: a participant holding private data. In **cross-device** FL it's a phone or other device. In
  **cross-silo** FL it's an organization, such as a hospital or bank.
- **Masked update, n1**: the client's model change, hidden by random masks (Lecture 256), and its number of training
  examples, used as the averaging weight.
- **Secure aggregation**: a protocol that lets the server learn the sum of updates but not any single one.
- **Weighted average**: each client's update counts in proportion to its example count (the assessment).
- **DP noise**: random noise added so the final model reveals almost nothing about any one client (Lecture 254,
  Section 38).

---

## Lecture 253 — What is federated learning?

**Why it matters.** Some of the most valuable data can't be collected centrally: keyboard input on billions of
phones, patient records spread across hospitals, or transactions at banks that can't share with competitors. Federated
learning (FL) trains on that data where it lives. Google's Gboard keyboard, Apple's on-device features, and medical
consortia use it in production.

**In plain words.** Instead of every student mailing their homework to the teacher, the teacher sends a lesson plan
to every home. Each student practices locally and mails back only "here's what I'd change about the lesson". The
teacher combines the suggestions into a better lesson plan, and never sees anyone's homework.

**Architecture: cross-device vs cross-silo FL.**

```mermaid
flowchart TB
  subgraph XD["Cross-device"]
    PH["Millions of phones<br/>small data each, often offline"]
    PH --> SEL["Selector picks a few thousand<br/>eligible: charging, Wi-Fi, idle"]
    SEL --> AGG1["Aggregator<br/>secure aggregation + DP"]
  end
  subgraph XS["Cross-silo"]
    H["2 to 100 organizations<br/>large data each, always on"]
    H --> COORD["Coordinator<br/>NVIDIA FLARE, Flower"]
    COORD --> AGG2["Aggregator<br/>TLS, audit, maybe TEE"]
  end
```

**How to read it:** cross-device FL involves millions of phones, each with a little data and often offline. Each
round, a selector picks a few thousand eligible devices (charging, on Wi-Fi, idle), and an aggregator combines their
updates with secure aggregation and differential privacy. Cross-silo FL involves a few organizations with lots of data
each and reliable servers. A coordinator runs the rounds, and aggregation is protected with encryption, audit logs,
and sometimes trusted hardware.

**Terms in this diagram.**
- **Cross-device**: FL across very many end-user devices, each contributing a small amount of data, with clients
  coming and going.
- **Selector, eligible**: the service that chooses which devices join a round. A device is **eligible** when it's
  charging, on an unmetered network (Wi-Fi), and idle, so training doesn't drain battery or data plans.
- **Aggregator**: the service that receives updates and computes the combined update.
- **Cross-silo**: FL between a small number of organizations, each acting as one reliable client.
- **Coordinator, NVIDIA FLARE, Flower**: the orchestration service for cross-silo rounds. **NVIDIA FLARE** (Federated
  Learning Application Runtime Environment) and **Flower** are open-source FL frameworks used in production.
- **TLS, audit, TEE**: encrypted connections, logged actions, and a **trusted execution environment**, a hardware
  enclave (such as Intel SGX/TDX, AMD SEV, or NVIDIA confidential computing) whose code and memory the host can't
  inspect (Section 38).

**Core ideas.**
- **FedAvg is the core algorithm.** Each round: sample clients, each trains for a few local steps starting from the
  global model, and the server averages their new weights, weighted by example count (McMahan et al., 2017). Local
  steps cut communication by 10–100× compared with sending a gradient every step.
- **Communication is the bottleneck in cross-device FL.** Uploads over mobile networks are slow and expensive, so
  models are small (often under 20 MB), and updates are compressed (Lecture 258).
- **When FL is the right tool.**
  - The data is sensitive, regulated, or too large to move, and the labels exist on the client (keyboard next-word,
    on-device feedback, local diagnoses).
  - Not when you could simply get consent and centralize the data, or when you need to inspect and clean the data
    by hand. FL makes debugging much harder.
- **What FL protects and what it doesn't.** Raw data stays on the client. But updates can leak information (Lecture
  254), so FL is a starting point for privacy, not a guarantee.
- **Production FL is a distributed system.** Device selection, versioning, partial failure, stragglers, and
  monitoring without seeing data all need engineering (Bonawitz et al., "Towards Federated Learning at Scale", 2019).

**Example: next-word prediction on a keyboard.** Google trained Gboard's next-word prediction with FL. Phones trained
locally on what users typed, only while charging, on Wi-Fi, and idle. Rounds took a few minutes with hundreds to
thousands of devices, and the federated model improved prediction recall over the server-trained baseline, which was
trained on proxy data rather than real typing. Later work added secure aggregation and formal differential privacy
guarantees.

**Senior / FAANG best practice.** Use FL when data can't move and labels live on the client, not as a substitute for
consent. Choose cross-device or cross-silo architecture explicitly. Plan for communication limits, partial
participation, and debugging without data. Treat FL as one layer of privacy, combined with secure aggregation and
differential privacy.

---

## Lecture 254 — Privacy-preserving AI at scale

**Why it matters.** Researchers have reconstructed training images and text from model gradients ("gradient
inversion"), and models can memorize rare examples. Federated learning alone keeps raw data local, but the updates and
the final model can still leak it. Real privacy at scale combines several layers, each with a clear threat model.

**In plain words.** Keeping letters in your own house (FL) is a good start, but if you hand a stranger a detailed
summary of each letter, they can still guess what you wrote. Mixing all summaries together before anyone reads them
(secure aggregation), and blurring the result slightly (differential privacy), means no single letter can be
recovered.

**Architecture: layered privacy for federated learning.**

```mermaid
flowchart TB
  DEV["On device<br/>raw data stays local"] --> CLIP["Clip each update<br/>bound one client's influence"]
  CLIP --> SECA["Secure aggregation<br/>server sees only the sum"]
  SECA --> NOISE["Add Gaussian noise<br/>to the sum"]
  NOISE --> ACC["Privacy accountant<br/>epsilon, delta over all rounds"]
  ACC --> MODEL["Released model<br/>formal DP guarantee"]
  TH["Threats: curious server,<br/>model inversion, membership inference"] -.-> SECA
  TH -.-> NOISE
```

**How to read it:** raw data stays on the device. Each client's update is clipped to a maximum size, so no single
client can move the model too much. Secure aggregation hides individual updates from the server. Noise is added to
the sum, and a privacy accountant tracks the total privacy loss, measured as epsilon and delta, across all rounds. The
released model then has a formal differential privacy guarantee. Each layer addresses specific threats: a curious
server, attempts to reconstruct data from the model, and attempts to tell whether someone's data was used.

**Terms in this diagram.**
- **Clip each update**: scale an update down if its size (L2 norm) exceeds a bound C, so every client's influence is
  limited.
- **Gaussian noise**: random values from a normal distribution, with a size set relative to C, added to the
  aggregated update.
- **Privacy accountant, epsilon, delta**: a calculation that adds up the privacy cost of every round. **Epsilon (ε)**
  bounds how much the output can change because of one client: smaller is more private. **Delta (δ)** is a tiny
  probability that the bound fails (Section 38).
- **Formal DP guarantee**: a mathematical statement that the model would be almost the same whether or not any one
  client took part.
- **Curious server**: an aggregator that follows the protocol but tries to learn from what it sees.
- **Model inversion**: reconstructing training inputs from a model or its gradients.
- **Membership inference**: deciding whether a specific record was in the training data (Section 39).

**Core ideas.**
- **Threat model first.** Who are you protecting against: the server operator, other clients, people querying the
  final model, or someone who steals it? Each layer covers different threats.
- **Secure aggregation** protects individual updates from the server. It doesn't protect against what the final
  model memorizes.
- **Differential privacy** protects against what the final model reveals about any participant.
  - **User-level DP** (one whole client's data) is the right unit for FL, not single examples.
  - **DP-FedAvg** clips each client's update and adds noise to the sum. Utility improves with more clients per round,
    since noise is spread over a bigger sum. That's why cross-device FL with thousands of clients per round can
    reach useful ε values.
  - **Distributed DP** has clients add small pieces of noise before secure aggregation, so even the server never sees
    a noise-free sum.
- **Privacy is a budget.** Every round spends some of it. Accountants (Rényi DP and similar) compute the total ε for
  the planned number of rounds before training starts.
- **Trusted hardware** (TEEs) is another layer: the aggregation runs in an attested enclave whose code clients can
  verify, used for example in Apple's Private Cloud Compute and Google's confidential federated analytics.

```python
import math

def dp_fedavg_aggregate(updates, clip, noise_multiplier, rng):
    """updates: list of client update vectors. Returns the noisy mean (user-level DP, uniform weighting)."""
    clipped = []
    for u in updates:
        norm = math.sqrt(sum(v * v for v in u))
        clipped.append([v * min(1.0, clip / (norm + 1e-12)) for v in u])
    total = [sum(col) for col in zip(*clipped)]
    sigma = noise_multiplier * clip
    return [(t + rng.gauss(0, sigma)) / len(updates) for t in total]
```

In the code, each update is clipped to norm `clip`, so one client changes the sum by at most `clip`. Gaussian noise
with standard deviation `noise_multiplier × clip` is added to the sum, then the result is divided by the number of
clients. With 1,000 clients per round, the noise in the mean is 1,000 times smaller than in one client's update,
which is why scale makes DP practical. DP-FedAvg usually weights clients equally (or caps the weights), because a
weight proportional to example count would let one big client dominate the sensitivity.

**Example: formal DP for a production keyboard model.** Google reported training Gboard language models with
DP-FedAvg and secure aggregation, with thousands of devices per round and formal user-level guarantees, and
publishing the ε achieved. The trade-off: more clients per round and more rounds were needed to reach the same
accuracy as non-private FL, which cost more device time but no extra data exposure.

**Senior / FAANG best practice.** Write down the threat model, then layer controls: FL for raw data, secure
aggregation against the server, user-level DP against the released model, and TEEs where code attestation helps.
Clip updates, plan the privacy budget with an accountant before training, report ε and δ, and use large cohorts per
round so noise doesn't destroy utility.

---

## Lecture 255 — Federated learning with TensorFlow Federated

**Why it matters.** Before running FL on real devices, teams simulate it: hundreds of virtual clients with realistic
non-IID data on one machine, to choose algorithms, local steps, and learning rates. TensorFlow Federated (TFF) is
Google's open-source framework for this, with ready-made federated datasets and FedAvg implementations.

**In plain words.** TFF is a flight simulator for federated learning. You can practice with thousands of virtual
planes (clients) and bad weather (uneven, unusual data) before risking real ones.

**Architecture: a TFF simulation.**

```mermaid
flowchart LR
  CD["ClientData<br/>federated EMNIST, 3,400 writers"] --> SAMP["Sample clients per round<br/>create_tf_dataset_for_client"]
  KM["Keras model_fn"] --> PROC["build_weighted_fed_avg<br/>client + server optimizers"]
  PROC --> INIT["process.initialize<br/>server state"]
  INIT --> NEXT["process.next state, client datasets<br/>one federated round"]
  SAMP --> NEXT
  NEXT --> MET["metrics: loss, accuracy,<br/>num_examples"]
  NEXT -->|"new state"| NEXT
  NEXT --> EVAL["Central eval<br/>get_model_weights, assign to Keras"]
```

**How to read it:** a federated dataset (EMNIST, split by the person who wrote each character) provides a dataset per
client. A Keras model definition and two optimizers build a FedAvg process. The process creates an initial server
state. Each round, you sample clients, pass their datasets to `process.next`, and get back the new state and metrics.
At the end, you copy the global weights into a Keras model to evaluate it centrally.

**Terms in this diagram.**
- **ClientData, federated EMNIST**: TFF's container for datasets split by client. **EMNIST** is a dataset of
  handwritten digits and letters. The federated version groups characters by writer (about 3,400 writers), which
  gives natural non-IID clients.
- **create_tf_dataset_for_client**: returns one client's data as a `tf.data.Dataset`.
- **model_fn**: a function that builds a new model each time TFF needs one, wrapping a Keras model with
  `tff.learning.models.from_keras_model`.
- **build_weighted_fed_avg, client + server optimizers**: TFF's FedAvg builder. The **client optimizer** runs the local
  steps. The **server optimizer** applies the averaged update to the global model, and SGD with learning rate 1.0
  means "replace with the average".
- **process.initialize, server state**: creates the starting global model and optimizer state.
- **process.next**: runs one round: broadcast, local training, and weighted aggregation.
- **num_examples**: the number of examples used, which also sets each client's weight.
- **get_model_weights, assign to Keras**: extracts the global weights from the server state and loads them into a
  normal Keras model.

**Core ideas.**
- **Simulation, not production.** TFF runs all clients in one process (or a simulation cluster). For production
  cross-silo FL, teams use NVIDIA FLARE, Flower, or OpenFL. Cross-device production systems are mostly in-house
  (Google, Apple), built on the same algorithms.
- **Weighted by examples, by default.** `build_weighted_fed_avg` weights each client by its number of examples, which
  is the assessment's formula. `build_unweighted_fed_avg` exists for DP settings.
- **Local work per client.** Clients usually run a fixed number of local epochs over their data. As the assessment
  shows, big clients then do many more steps. Capping local steps (`dataset.take(n)`) keeps the averaging consistent.
- **Server optimizers.** FedAdam or FedYogi (adaptive server optimizers, Reddi et al.) often converge faster on
  non-IID data than plain averaging.
- **Environment.** TFF pins specific TensorFlow versions and the Keras 2 API, and installs most reliably on Linux or
  Google Colab with Python 3.10–3.11.

```python
import tensorflow as tf
import tensorflow_federated as tff

train, test = tff.simulation.datasets.emnist.load_data(only_digits=True)

def preprocess(ds):
    return (ds.repeat(1).shuffle(100, seed=0).batch(20)
              .map(lambda e: (tf.reshape(e["pixels"], [-1, 784]), tf.reshape(e["label"], [-1, 1]))))

example = preprocess(train.create_tf_dataset_for_client(train.client_ids[0]))

def model_fn():
    keras = tf.keras.Sequential([tf.keras.layers.InputLayer(input_shape=(784,)),
                                 tf.keras.layers.Dense(200, activation="relu"),
                                 tf.keras.layers.Dense(10, activation="softmax")])
    return tff.learning.models.from_keras_model(
        keras, input_spec=example.element_spec, loss=tf.keras.losses.SparseCategoricalCrossentropy(),
        metrics=[tf.keras.metrics.SparseCategoricalAccuracy()])

process = tff.learning.algorithms.build_weighted_fed_avg(
    model_fn, client_optimizer_fn=tff.learning.optimizers.build_sgdm(learning_rate=0.02),
    server_optimizer_fn=tff.learning.optimizers.build_sgdm(learning_rate=1.0))
state = process.initialize()
```

In the code, `only_digits=True` keeps the 10 digit classes. `preprocess` batches each client's data and flattens each
28 × 28 image into 784 numbers. `input_spec` tells TFF the shape and type of a batch. `build_sgdm` is TFF's SGD with
optional momentum. The lab continues from here.

**Example: choosing local steps in simulation.** Before launching on devices, a team simulated their FL model in TFF
with 500 clients per round. One local epoch converged in 1,200 rounds. Five epochs converged in 400 rounds on
balanced clients, but stalled 2 points lower on the most skewed clients because of client drift. They chose 2 local
epochs capped at 50 steps, with FedAdam on the server, which reached target accuracy in 500 rounds. That saved
roughly 60% of device time compared with 1 epoch.

**Senior / FAANG best practice.** Simulate FL with realistic non-IID client splits before touching devices, and tune
local steps, cohort size, and the server optimizer there. Cap local work per client, compare FedAvg with FedAdam, and
track metrics per client group, not only averages. Move to a production framework for real deployments.

---

## Lecture 256 — Secure aggregation protocols

**Why it matters.** Without secure aggregation, the FL server sees each client's update, and updates can reveal
private data. Secure aggregation guarantees that the server learns only the sum of many updates. It's what makes "we
can't see your data" a technical claim, not a policy promise.

**In plain words.** Each pair of friends agrees on a secret random number. One adds it to their vote count and the
other subtracts it. Every individual count the teller sees looks random, but when all counts are added up, the
secret numbers cancel exactly and the true total appears.

**Architecture: pairwise masking with dropout recovery.**

```mermaid
sequenceDiagram
  participant A as Client A
  participant B as Client B
  participant C as Client C
  participant S as Server
  A->>S: public key
  B->>S: public key
  C->>S: public key
  S->>A: everyone's public keys
  Note over A,C: each pair derives a shared mask (key agreement), and secret-shares its mask seed
  A->>S: update A + mask AB + mask AC
  B->>S: update B - mask AB + mask BC
  Note over C: C drops out
  S->>A: who dropped? send your share of C's seeds
  S->>B: who dropped? send your share of C's seeds
  A->>S: share
  B->>S: share
  Note over S: rebuild masks AC and BC, remove them, sum = A + B
```

**How to read it:** each client publishes a public key, and the server passes all keys to everyone. Every pair of
clients derives a shared random mask from their keys, and each client also splits its secrets into shares held by
the others. Each client sends its update plus or minus its pairwise masks. In the sum, every mask appears once with a
plus sign and once with a minus sign, so they cancel. When client C drops out, its masks with A and B don't cancel,
so the server asks the survivors for their shares of C's secrets, rebuilds those masks, and removes them. The result
is the exact sum of A and B.

**Terms in this diagram.**
- **Public key, key agreement**: each client has a key pair. With **Diffie–Hellman key agreement**, two clients
  combine one's private key with the other's public key to get the same shared secret, without the server learning it.
- **Mask, mask AB, AC, BC**: a vector of random numbers generated from a pair's shared secret, the same length as the
  update, and added using modular arithmetic so it fully hides the values. **Mask AB** is the one shared by clients A
  and B, and likewise for AC and BC.
- **Secret-shares, share**: **Shamir secret sharing** splits a secret into n shares so that any t of them rebuild it,
  and fewer reveal nothing. Clients share their mask seeds this way so the survivors can recover a dropped client's
  masks.
- **Drops out**: a client disconnects after the protocol starts, which happens constantly with phones.

**Core ideas.**
- **The protocol (Bonawitz et al., 2017)** uses pairwise masks to hide updates, secret sharing to recover from
  dropouts, and a second "self-mask" per client, so a client that's merely slow can't have its update unmasked by a
  server that falsely claims it dropped ("double masking").
- **Integers, not floats.** Updates are converted to fixed-point integers and added modulo 2³² (or similar), so masks
  hide the values perfectly and cancel exactly, as in the exercise.
- **Cost.** Every pair of clients shares a mask, so work grows with n². **SecAgg+** connects each client to only
  about log n neighbors, making cohorts of thousands practical.
- **Thresholds.** The server must not be able to unmask a tiny group. A minimum number of surviving clients is
  required, or the round is abandoned.
- **Alternatives.** Homomorphic encryption sums encrypted updates directly (Section 38), and TEEs aggregate inside an
  attested enclave. Both are used in cross-silo settings, where there are few clients and each is powerful.
- **What it doesn't stop.** A malicious client can still send a poisoned update, which hides inside the sum.
  Robustness needs clipping, and possibly norm-bound proofs (Section 39).

**Example: 300 clients, 30% dropout.** A simulation of a cohort of 300 phones, with 30% dropping out mid-round, showed
the full pairwise protocol needed about 45,000 pairwise masks and noticeable phone CPU time. Switching to SecAgg+ with
about 20 neighbors per client cut per-client work by over 90%. The surviving 210 updates were still summed exactly,
because each dropped client's neighbors provided enough shares.

**Senior / FAANG best practice.** Use secure aggregation for any FL where the server shouldn't see individual updates.
Use SecAgg+ or a similar sparse variant for large cohorts, enforce a minimum cohort size, and combine it with update
clipping and DP. Prefer TEEs or homomorphic encryption for small cross-silo groups, and remember that secure
aggregation hides poisoned updates too.

---

## Lecture 257 — Federated data challenges

**Why it matters.** Federated data is messy in ways central data isn't: every client has a different distribution,
different amounts of data, and different availability, and you can't look at any of it. These issues, not the
algorithm, decide whether an FL project succeeds.

**In plain words.** Imagine writing a cookbook from recipes sent by home cooks, without ever tasting their food. Some
cooks only bake, some send one recipe and others a hundred, most only reply in the evening, and you still have to
judge whether the cookbook is good.

**Architecture: where federated data goes wrong.**

```mermaid
flowchart TB
  NIID["Non-IID data<br/>label, feature, quantity skew"] --> DRIFT["Client drift<br/>local models pull apart"]
  DRIFT --> FIX1["FedProx, SCAFFOLD,<br/>fewer local steps"]
  WORK["Uneven local work<br/>epochs over unequal data"] --> INC["Objective inconsistency<br/>biased global model"]
  INC --> FIX2["Fixed local steps<br/>or FedNova normalization"]
  AVAIL["Availability bias<br/>only charging phones at night"] --> SKEW["Model fits who shows up"]
  SKEW --> FIX3["Time-zone-aware sampling,<br/>monitor cohort makeup"]
  STRAG["Stragglers + dropouts"] --> SLOW["Rounds wait on the slowest"]
  SLOW --> FIX4["Over-select, deadline, drop late clients"]
  BLIND["No central data to inspect"] --> FIX5["Federated evaluation + analytics"]
```

**How to read it:** each row is a problem, its effect, and its fix. Non-IID data makes local models pull apart
(client drift), which methods such as FedProx and SCAFFOLD or fewer local steps reduce. Unequal amounts of local work
bias the global model, fixed by using the same number of local steps or by FedNova's normalization. Only some devices
are available at a time, so the model fits whoever shows up, which needs careful sampling and monitoring. Slow and
dropped clients delay rounds, so the server over-selects and sets deadlines. Since there's no central data to look
at, evaluation and data analysis themselves must be federated.

**Terms in this diagram.**
- **Non-IID, label, feature, quantity skew**: not independent and identically distributed. **Label skew**: clients
  have different class mixes (one user types mostly in Spanish). **Feature skew**: the same classes look different
  (different handwriting or cameras). **Quantity skew**: very different amounts of data.
- **Client drift**: with many local steps on skewed data, each client's model moves toward its own optimum, and their
  average ends up somewhere that isn't good for anyone.
- **FedProx, SCAFFOLD**: **FedProx** adds a penalty that keeps local weights close to the global model. **SCAFFOLD**
  uses control variates (estimates of each client's drift) to correct local updates.
- **Objective inconsistency, FedNova**: when clients do different numbers of local steps, FedAvg optimizes a
  distorted objective. **FedNova** normalizes each update by its number of steps.
- **Availability bias**: the set of eligible clients isn't representative, such as phones that are charging on Wi-Fi
  overnight in one time zone.
- **Cohort makeup**: the mix of client types (region, device, language) taking part in each round.
- **Stragglers, over-select, deadline**: slow clients. The server invites more clients than needed (for example
  130% of the target) and closes the round at a deadline, ignoring late arrivals.
- **Federated evaluation + analytics**: computing metrics and data statistics on clients and aggregating them
  securely, instead of inspecting data centrally.

**Core ideas.**
- **Non-IID is the default.** Expect accuracy below centralized training, and more rounds to converge. Measure the
  gap in simulation (Lecture 255).
- **Equal work makes weighting meaningful.** The assessment shows that with local epochs, a 2,000-example client
  takes 63× more steps than a 32-example client, and the model ends up 60× farther from the right answer than with
  fixed local steps.
- **Personalization.** When clients differ a lot, one global model may suit no one. Fine-tune the last layers locally,
  or use per-client adapters, and keep the shared backbone federated.
- **Labels are scarce and noisy.** On-device labels usually come from user behavior (accepting a suggestion, deleting
  a word), which is implicit and biased.
- **Debugging blind.** Use federated analytics (secure histograms of feature values, label counts) and synthetic or
  donated data for development. Log per-round cohort statistics, not raw data.
- **Fairness.** Averages hide small groups. Evaluate per region, language, and device type with federated evaluation.

**Example: the model that only knew night owls.** A wellness app's federated sleep model looked fine in aggregate,
but performed poorly for shift workers. Training happened only when phones were charging on Wi-Fi, which mostly
meant nighttime in Europe and the Americas, so day sleepers were rarely selected. Spreading rounds across the whole
day, capping participation per time zone, and evaluating per segment closed most of the gap.

**Senior / FAANG best practice.** Simulate with realistic non-IID splits, fix local steps or use FedNova so weighting
stays consistent, and reduce drift with fewer local steps, FedProx, or SCAFFOLD. Over-select clients with round
deadlines, monitor cohort makeup for availability bias, and evaluate per segment with federated evaluation. Use
personalization when one global model can't serve everyone.

---

## Lecture 258 — Edge deployment of federated models

**Why it matters.** A federated model runs on hundreds of millions of devices with different chips, OS versions,
memory limits, and networks, and devices also train it. Deployment must protect battery, data plans, and user
experience, and support safe rollback, all without seeing user data.

**In plain words.** It's like running a library's book club across a whole country. Each reading circle gets the
right edition for its members, meets only when convenient, sends back short notes rather than whole essays, and if a
new edition turns out to be bad, every circle can go back to the old one quickly.

**Architecture: the fleet side of production FL.**

```mermaid
flowchart LR
  REGM["Model registry<br/>model + training plan versions"] --> CFG["Config service<br/>eligibility, cohorts, rollout %"]
  CFG --> DEVF["Devices<br/>on-device runtime: TFLite, ExecuTorch, Core ML"]
  DEVF -->|"check-in when eligible"| SELS["Selectors<br/>regional, rate-limited"]
  SELS --> COORDS["Round coordinator"]
  COORDS --> AGGS["Aggregators<br/>secure aggregation"]
  DEVF -->|"compressed update<br/>quantized, sparse"| AGGS
  AGGS --> REGM
  REGM -->|"staged rollout<br/>1%, 10%, 100%"| DEVF
  DEVF -->|"federated metrics"| MON["Monitoring<br/>no raw data"]
```

**How to read it:** the registry holds model versions and their training plans. A configuration service sets which
devices are eligible, how cohorts are formed, and what share of devices get each version. Devices run the model in an
on-device runtime, and check in with regional selectors when they're eligible. A round coordinator manages each
round, and devices send compressed updates to aggregators, which use secure aggregation. New global versions are
rolled out in stages, and devices report federated metrics to monitoring, without raw data.

**Terms in this diagram.**
- **Training plan**: the instructions a device needs for one round: the computation to run, the number of steps,
  and what to report.
- **Config service, rollout %**: the service that sets eligibility rules and controls which share of devices gets a
  version.
- **On-device runtime: TFLite, ExecuTorch, Core ML**: engines that run (and in some cases train) models on devices.
  **TensorFlow Lite** (now LiteRT) supports on-device training with exported training signatures. **ExecuTorch** is
  PyTorch's on-device runtime. **Core ML** is Apple's, and supports updatable models (Section 23).
- **Check-in**: a device telling the server it's available for work.
- **Selectors, regional, rate-limited**: servers that accept check-ins, spread across regions, and that limit how many
  devices join, so millions of check-ins don't overwhelm the system.
- **Compressed update, quantized, sparse**: updates shrunk by sending fewer bits per value (quantized) or only the
  largest values (sparse).
- **Staged rollout**: releasing a new version to 1%, then 10%, then everyone, with checks at each stage (Section 15).
- **Federated metrics**: quality and health metrics computed on devices and aggregated, without collecting data.

**Core ideas.**
- **Eligibility protects users.** Train only when charging, on unmetered networks, idle, and above minimum storage and
  memory, and limit how often each device participates (for example, once a day).
- **Shrink updates.** An 8 MB model update from 10,000 devices per round is 80 GB of uploads per round.
  - 8-bit quantization of updates cuts that 4×.
  - Top-k sparsification (sending only the largest 1–10% of values, with error feedback that carries the rest to the
    next round) cuts it 10–100×.
  - Training only some layers (for example, the last layers or LoRA adapters, Section 26) shrinks updates further.
- **Device diversity.** Older phones may not support training. Pick model sizes and runtimes that cover most of the
  fleet, and use a separate cohort for capable devices.
- **Versioning and rollback.** Every update names the model version it was trained from. The server discards updates
  computed on stale versions (or applies them with a limit on staleness).
- **Rollout of the trained model** follows the same staged pattern as any mobile model: canary, federated metrics, then
  wider release, with an automatic rollback path (Section 23).

**Example: cutting upload cost 40×.** A photo app's federated model sent full 32-bit updates of 12 MB from 20,000
devices per round, and users on capped data plans complained even though training was restricted to Wi-Fi (some
"Wi-Fi" connections were mobile hotspots). Training only the last two layers (1.5 MB), 8-bit quantization, and top-10%
sparsification with error feedback cut each upload to about 300 KB, a 40× reduction, with accuracy within 0.3 points.
They also added a check for metered hotspot connections.

**Senior / FAANG best practice.** Gate participation by charging, unmetered network, idle state, and a per-device
frequency cap. Train small parts of the model and compress updates with quantization and sparsification with error
feedback. Version every training plan and reject stale updates, design selectors for millions of check-ins, and roll
out trained models in stages with federated metrics and automatic rollback.

---

## Lecture 259 — Lab: train a federated model with TFF

**Goal:** train a digit classifier with weighted FedAvg on federated EMNIST, sampling 10 clients per round, and
evaluate the global model on held-out clients after 30 rounds.

**What you're building:** a script that loads federated EMNIST, builds a FedAvg process, runs 30 rounds while
printing training metrics, and evaluates the final model centrally on test clients.

```mermaid
flowchart LR
  LOAD["emnist.load_data<br/>only_digits"] --> PICK["Each round: sample<br/>10 of 3,383 clients"]
  PICK --> ROUND["process.next<br/>local SGD, weighted average"]
  ROUND --> LOGM["Print loss, accuracy,<br/>examples per round"]
  ROUND -->|"30 rounds"| EVALF["Keras evaluate on<br/>500 test clients"]
```

**How to read the diagram:** the script loads the digit-only federated EMNIST dataset. Each round it samples 10 of the
3,383 training clients, runs one round of local SGD and weighted averaging, and prints the training metrics. After 30
rounds, it copies the global weights into a Keras model and evaluates it on data from 500 test clients.

**Prerequisites:** a Linux machine or Google Colab with Python 3.10 or 3.11, and `pip install --upgrade
tensorflow-federated` in a fresh virtual environment (it installs a matching TensorFlow version).

### Step 1 — Data and model

```python
# fl_emnist.py
import collections, random
import numpy as np
import tensorflow as tf
import tensorflow_federated as tff

train, test = tff.simulation.datasets.emnist.load_data(only_digits=True)
print("train clients:", len(train.client_ids))

def preprocess(ds, epochs=1):
    return (ds.repeat(epochs).shuffle(100, seed=0).batch(20).take(50)
              .map(lambda e: (tf.reshape(e["pixels"], [-1, 784]), tf.reshape(e["label"], [-1, 1]))))

example = preprocess(train.create_tf_dataset_for_client(train.client_ids[0]))

def keras_model():
    return tf.keras.Sequential([tf.keras.layers.InputLayer(input_shape=(784,)),
                                tf.keras.layers.Dense(200, activation="relu"),
                                tf.keras.layers.Dense(200, activation="relu"),
                                tf.keras.layers.Dense(10, activation="softmax")])

def model_fn():
    return tff.learning.models.from_keras_model(
        keras_model(), input_spec=example.element_spec, loss=tf.keras.losses.SparseCategoricalCrossentropy(),
        metrics=[tf.keras.metrics.SparseCategoricalAccuracy()])
```

In the code, `.take(50)` caps each client at 50 batches per round, so big clients don't do many more local steps than
small ones (Lecture 257 and the assessment). The model is a small two-hidden-layer network on flattened 28 × 28 images.

### Step 2 — FedAvg rounds

```python
process = tff.learning.algorithms.build_weighted_fed_avg(
    model_fn, client_optimizer_fn=tff.learning.optimizers.build_sgdm(learning_rate=0.05),
    server_optimizer_fn=tff.learning.optimizers.build_sgdm(learning_rate=1.0))
state = process.initialize()
rng = random.Random(0)

for rnd in range(1, 31):
    ids = rng.sample(train.client_ids, 10)
    data = [preprocess(train.create_tf_dataset_for_client(c)) for c in ids]
    result = process.next(state, data)
    state = result.state
    m = result.metrics["client_work"]["train"]
    if rnd % 5 == 0 or rnd == 1:
        print(f"round {rnd:2d}: loss {m['loss']:.3f}  accuracy {m['sparse_categorical_accuracy']:.3f}  "
              f"examples {m['num_examples']}")
```

In the code, each round samples 10 clients and passes their datasets to `process.next`, which simulates sending the
model, training locally, and computing the weighted average. `result.metrics["client_work"]["train"]` holds the
training metrics averaged over the round's clients, weighted by examples.

### Step 3 — Central evaluation

```python
k = keras_model()
k.compile(loss="sparse_categorical_crossentropy", metrics=["accuracy"])
process.get_model_weights(state).assign_weights_to(k)

test_ids = test.client_ids[:500]
xs, ys = [], []
for c in test_ids:
    for e in test.create_tf_dataset_for_client(c):
        xs.append(np.reshape(e["pixels"].numpy(), 784)); ys.append(int(e["label"].numpy()))
loss, acc = k.evaluate(np.array(xs), np.array(ys), verbose=0)
print(f"global model on {len(test_ids)} test clients ({len(xs)} images): accuracy {acc:.3f}")
```

```bash
python3 fl_emnist.py
```

`get_model_weights(state)` extracts the global model's weights from the server state, and `assign_weights_to` loads
them into an ordinary Keras model, which is then evaluated on images from held-out test clients.

### Step 4 — Experiments

- Change `server_optimizer_fn` to `tff.learning.optimizers.build_adam(learning_rate=0.003)` (FedAdam) and compare the
  round-30 accuracy.
- Raise clients per round from 10 to 50 and compare the accuracy curve's smoothness.
- Remove `.take(50)` and use `epochs=5` in `preprocess`, then compare final accuracy and round time.
- Replace `build_weighted_fed_avg` with `build_unweighted_fed_avg`, and compare the result with the assessment's
  findings.

**Expected results:**
- About 3,383 training clients reported.
- Training accuracy climbs from roughly 0.15–0.30 in round 1 to about 0.80–0.90 by round 30. Values jump between
  rounds, because each round sees different writers.
- Central accuracy on 500 test clients after 30 rounds: about 0.85–0.92.
- FedAdam and 50 clients per round both usually reach higher accuracy at round 30, with a smoother curve.
- Each round runs in a few seconds on a laptop CPU or Colab.

---

## Assessment — Implement weighted federated averaging

**Scenario.** Your team is building cross-silo FL across 12 hospitals with very different patient counts (2,000 down
to 20). A teammate proposes averaging every hospital's model equally, and another normalizes by the total patient
count of all hospitals even when only some join a round. Implement weighted FedAvg correctly, show what goes wrong in
each alternative, and add secure aggregation so the server never sees one hospital's update.

**Task.**

```bash
python3 exercises/s37_fedavg.py                                      # demo + checks
python3 exercises/s37_fedavg.py --rounds 60 --local-steps 20 --sample 0.5
```

**Formulas.**
- Weighted FedAvg over the participating clients P: \( w_{t+1} = \sum_{k \in P} n_k w_k / \sum_{k \in P} n_k \).
- With one full-batch local gradient step, this equals one centralized step on the pooled data, so it's the correct
  generalization of ordinary training.
- Secure aggregation: client i sends \( x_i + \sum_{j>i} m_{ij} - \sum_{j<i} m_{ji} \) mod \(2^{32}\), and the masks
  cancel in the sum.

**Expected output:**

| Check | Result |
|---|---|
| Pooled-data optimum w* | [2.259, −0.758, 0.222, 3.271, −2.287], MSE 0.7794 |
| Weighted FedAvg, 10 local steps per client | 0.005 from w*, MSE 0.7794 |
| Unweighted average | 1.319 from w*, MSE 2.5124 |
| Weighted, but 2 local epochs (uneven steps) | 0.293 from w*, MSE 0.8649 |
| 50% sampling, divided by participants' total | MSE 0.8125 |
| 50% sampling, divided by all clients' total | MSE 18.64 (model shrinks toward zero) |
| One masked update | values in the thousands, unrelated to the real update |
| Masked sum vs plain sum | identical: [0.15, 0.3, 0.45, 0.6, 0.75] |
| Client 3 drops, no recovery | garbage |
| Client 3 drops, masks recovered | exact sum of the 4 survivors: [0.11, 0.22, 0.33, 0.44, 0.55] |

All 10 checks print `PASS`.

**What a strong answer explains:**
- **Weighting by examples reproduces centralized training.** One full-batch local step makes weighted FedAvg exactly
  equal to a centralized gradient step, which is why it's the default.
- **Unweighted averaging gives 20 patients as much say as 2,000**, so the model is pulled toward small, unusual
  hospitals, and pooled error triples.
- **Weighting assumes equal local work.** With local epochs, big clients take ~63× more steps and dominate again, the
  objective inconsistency that fixed local steps or FedNova correct.
- **Normalize by the participants**, not by everyone. Dividing by all clients' total under 50% sampling shrinks the
  model toward zero every round.
- **Secure aggregation** hides every single update behind masks that cancel only in the sum, and needs a recovery
  step (secret shares in real protocols) when a client drops, or the round is lost.
- **For privacy-critical settings**, pair it with clipping and differential privacy, which usually uses uniform or
  capped weights (Lecture 254).

---

## FAANG deep-dive notes

**How big tech does it.** Google runs cross-device FL in production for Gboard and other Android features, with
eligibility rules, secure aggregation, and user-level differential privacy, built on the system described in
"Towards Federated Learning at Scale". Apple uses on-device learning with differential privacy and, for server-side
processing, attested enclaves (Private Cloud Compute). In healthcare, cross-silo FL runs on NVIDIA FLARE and Flower,
for example in multi-hospital imaging consortia. Common patterns: simulate first, cap local work, compress updates,
evaluate with federated metrics, and publish privacy parameters.

**Staff review questions.**
- Why FL instead of consented central collection, and what's the threat model?
- Cross-device or cross-silo? What are the cohort size, round time, and dropout rate?
- How are updates weighted, and is local work equal across clients?
- Is secure aggregation used, with what minimum cohort, and how are dropouts handled?
- What's the user-level ε and δ for the planned rounds?
- How do you evaluate per segment and detect availability bias without seeing data?
- What's the upload size per device per day, and how is it compressed?

**Interview question.** "Design federated learning for next-word prediction on 500 million phones."

**Typical system-design prompt:** *Design FL for a keyboard model on 500 million Android phones, with user-level
DP, secure aggregation, and no impact on battery or data plans.*

**1. Clarify first:** Model size limit? Languages and regions? Required privacy level (ε target)? Device
participation limits? How fresh must the model be? On-device training runtime available on which OS versions?

**2. Back-of-envelope sizing:**
- Eligible at any time: ~5% of devices (charging, Wi-Fi, idle) = 25 million. Cohort per round: 5,000 devices,
  over-selected to 6,500 for 23% dropout.
- Model: 20 MB. Train only the output and last layers, a 2 MB update, quantized to 8 bits = 0.5 MB. Per round: 5,000
  × 0.5 MB = 2.5 GB of uploads, and 6,500 × 20 MB = 130 GB of downloads (cache with a CDN, and send only weight
  diffs to devices with the previous version).
- Rounds: ~3 minutes each, ~2,000 rounds to converge ≈ 4 days, using 10 million device-rounds, so each eligible
  device participates less than once.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Aggregation weights | By example count | Uniform or capped | By count without DP. Uniform or capped with user-level DP |
| Local work | Epochs | Fixed steps | Fixed or capped steps, or FedNova |
| Secure aggregation | Full pairwise | SecAgg+ | SecAgg+ beyond a few hundred clients |
| Update size | Full model, FP32 | Partial layers, 8-bit, sparse | Partial layers plus compression |
| Server optimizer | Averaging | FedAdam | FedAdam for non-IID data |

**4. Follow-up questions with crisp answers:**
- *How do you know the model is better without seeing typing data?* Federated evaluation on held-out devices, then a
  staged rollout with federated metrics, such as suggestion acceptance rate.
- *A region is under-represented. Fix?* Cohort quotas per region and time zone, and monitoring of cohort makeup.
- *How do you stop a malicious device from poisoning the model?* Clip updates, use DP noise, limit per-device
  participation, and run robust aggregation checks before secure aggregation hides individual updates (Section 39).
- *What if a device trained on an old version?* Reject updates beyond a staleness limit.

**Debug this (common onsite question):** "Federated accuracy is 6 points below the centralized proxy model and stops
improving after round 300."
1. Check local work: clients run 5 local epochs, and the biggest clients take 100× more steps than the median.
2. Check data skew: label distributions differ a lot per user.
3. Diagnosis: client drift and objective inconsistency.
4. Fix: cap local steps, switch to FedAdam on the server, and try FedProx. Accuracy closes to within 1.5 points.

The lesson: FL quality problems are usually local-work and data-skew problems, not model problems.

**5. What separates senior from staff answers:** a senior engineer runs FedAvg and gets it to converge. A staff
engineer starts from the threat model and constraints, designs the fleet side (eligibility, selectors, compression,
versioning), layers secure aggregation and user-level DP with a privacy budget, handles non-IID data and availability
bias, and proves quality with federated evaluation and staged rollout.

**Red flags:**
- Claiming FL alone makes training private.
- Unweighted averaging, or normalizing by clients who didn't participate.
- Local epochs with very unequal client sizes, without capping steps.
- No secure aggregation, or no minimum cohort size.
- DP without a stated ε, δ, or accountant.
- Full FP32 model uploads from phones.
- Evaluating only on a central proxy dataset.

---

## Quiz

<details><summary>1. What is the difference between cross-device and cross-silo federated learning?</summary>
Cross-device involves millions of devices with little data each, intermittent availability, and large sampled cohorts.
Cross-silo involves a few organizations with large data and reliable servers, where every client usually participates
in every round.
</details>

<details><summary>2. Why weight FedAvg by example count?</summary>
It makes the average match training on the pooled data: with one full-batch local step it equals a centralized
gradient step exactly. Unweighted averaging gives small clients outsized influence.
</details>

<details><summary>3. Why can weighted FedAvg still be biased when clients run local epochs?</summary>
Clients with more data take more local steps and move further, so they dominate beyond their weight (objective
inconsistency). Fixed local steps or FedNova normalization correct it.
</details>

<details><summary>4. Why isn't federated learning private on its own?</summary>
Updates can leak training data (gradient inversion, memorization), and the final model can reveal membership. Secure
aggregation and differential privacy are needed for meaningful guarantees.
</details>

<details><summary>5. How do pairwise masks let the server compute a sum without seeing individual updates?</summary>
Each pair of clients shares a random mask. One adds it and the other subtracts it, so each masked update looks random,
but all masks cancel in the sum, which is computed with modular arithmetic.
</details>

<details><summary>6. What happens in secure aggregation when a client drops out, and how is it handled?</summary>
Its masks with other clients no longer cancel. Survivors provide their secret shares of the dropped client's seeds, and
the server rebuilds and removes those masks to get the exact sum of the survivors.
</details>

<details><summary>7. What is availability bias in cross-device FL?</summary>
Only devices that are charging, idle, and on Wi-Fi participate, often at night in certain time zones, so the model fits
those users. Cohort quotas and monitoring of cohort makeup reduce it.
</details>

<details><summary>8. Name three ways to reduce upload size from devices.</summary>
Train only some layers or adapters, quantize updates (for example to 8 bits), and sparsify them (top-k values with
error feedback).
</details>

## Failure modes
- Treating FL as a privacy guarantee without secure aggregation or DP.
- Unweighted averaging, or dividing by clients who didn't participate.
- Unequal local work biasing the model toward large clients.
- Client drift on non-IID data from too many local steps.
- Availability bias from training only on certain devices or time zones.
- Rounds stalled by stragglers because there's no over-selection or deadline.
- Upload sizes that hurt users' data plans or battery.
- Secure aggregation with a tiny cohort, letting the server isolate individuals.
- Stale updates from old model versions applied without limits.
- Evaluating only on central proxy data, missing per-segment failures.

## Checklist
- [ ] You can explain when FL is the right tool and choose cross-device or cross-silo
- [ ] You can write down a threat model and the privacy layers that address it
- [ ] You implemented weighted FedAvg and explained each wrong alternative
- [ ] You can explain pairwise masking and dropout recovery in secure aggregation
- [ ] You cap or fix local work, and handle non-IID data and client drift
- [ ] You plan eligibility, update compression, versioning, and staged rollout for devices
- [ ] You ran FedAvg on federated EMNIST in TFF and evaluated the global model
