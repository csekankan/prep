# Section 40 — Multi-Tenant AI Infrastructure

> Lectures 274–280 • Assessments: quiz, [Enforce multi-tenant resource quotas](#assessment--enforce-multi-tenant-resource-quotas)
> • Exercise: [`s40_tenant_quotas.py`](../exercises/s40_tenant_quotas.py)
> **After this section you can:** choose a tenancy model (cluster, namespace, or virtual cluster per tenant), share
> GPUs fairly with Kueue quotas, borrowing, and preemption, and with MIG, time-slicing, and MPS, attribute GPU cost to
> tenants including idle time, design least-privilege RBAC, isolate tenants' network, nodes, data, and caches, monitor
> per-tenant SLOs and noisy neighbors, and configure a multi-tenant cluster end to end.
>
> Builds on: [Section 5](../part01_foundations/s05_kubernetes_fundamentals.md) (namespaces, RBAC, quotas),
> [Section 11](../part03_mlops_cicd_cost/s11_advanced_kubernetes.md) (Kueue, GPU Operator, scheduling),
> [Section 12](../part03_mlops_cicd_cost/s12_cost_optimization.md) (cost), and
> [Section 39](s39_advanced_ai_security.md) (security).
> Go deeper: [13/lab26](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab26_resource_quotas_gpu.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 274 | What is multi-tenancy? | Many teams or customers share infrastructure. Pick soft or hard isolation per tenant and risk |
| 275 | Resource sharing across teams | Guaranteed quotas, borrowing of idle GPUs, and preemption to reclaim them keep GPUs busy and fair |
| 276 | Cost allocation for multi-tenant infra | Charge requested GPU-hours, spread idle and shared costs by a stated rule, and show every team its bill |
| 277 | Role-based access control (RBAC) | Groups from SSO bound to namespaced roles. Nobody gets cluster-admin by default |
| 278 | Isolation strategies in AI systems | Network policies, dedicated node pools, MIG, sandboxed runtimes, and per-tenant keys and caches |
| 279 | Monitoring multi-tenant environments | Per-tenant SLOs and usage, noisy-neighbor detection, and dashboards each tenant can see |
| 280 | Lab: configure multi-tenant cluster | Namespaces, quotas, LimitRanges, RBAC, NetworkPolicies, and Kueue queues with borrowing on kind |

```mermaid
flowchart TB
  IDP["SSO groups<br/>team-a, team-b"] --> RBACG["RBAC per namespace"]
  RBACG --> NS["Namespace per tenant<br/>quota, LimitRange, NetworkPolicy"]
  NS --> LQ["LocalQueue"]
  LQ --> CQ["ClusterQueues in a cohort<br/>nominal, borrowing, preemption"]
  CQ --> POOLS["GPU node pools<br/>whole GPUs, MIG, time-sliced"]
  POOLS --> MET["Per-tenant metrics<br/>usage, SLOs, cost"]
  MET --> BILL["Showback / chargeback"]
```

**How to read it:** users sign in with SSO, and their groups map to roles in their team's namespace. Each namespace
has quotas, default and maximum resource sizes, and network rules. Jobs go to the namespace's local queue, which
feeds a cluster queue. Cluster queues share GPUs in a cohort, with guaranteed amounts, borrowing, and preemption. Jobs
run on GPU node pools with whole GPUs, MIG slices, or time-shared GPUs. Metrics per tenant feed SLO dashboards and the
monthly cost report.

**Terms in this diagram.**
- **SSO groups**: teams defined in the company identity provider (such as Okta or Entra ID), passed to Kubernetes
  through OIDC (Section 18).
- **RBAC per namespace**: Kubernetes role-based access control, granting each group permissions only in its own
  namespace (Lecture 277).
- **Quota, LimitRange, NetworkPolicy**: a **ResourceQuota** caps a namespace's total resources, a **LimitRange** sets
  default and maximum sizes per container, and a **NetworkPolicy** controls which pods may talk to which (Section 5).
- **LocalQueue, ClusterQueue, cohort**: Kueue objects. A **LocalQueue** is a namespace's entry point. A
  **ClusterQueue** holds a quota. A **cohort** is a group of ClusterQueues that can lend each other unused quota
  (Lecture 275, Section 11).
- **Nominal, borrowing, preemption**: the guaranteed quota, the extra a queue may borrow from the cohort, and stopping
  lower-priority or borrowed jobs to make room.
- **Whole GPUs, MIG, time-sliced**: ways to give GPUs to jobs: a full GPU, a hardware-isolated slice (Multi-Instance
  GPU), or a GPU shared in turns (Lecture 275).
- **Showback / chargeback**: reporting each tenant's cost, or actually billing it to their budget (Lecture 276).

---

## Lecture 274 — What is multi-tenancy?

**Why it matters.** GPUs are expensive and bursty: one team's cluster sits idle on weekends while another team waits
in a queue. Sharing infrastructure across teams, or across customers in a SaaS product, can double utilization. Done
badly, it lets one tenant starve, slow down, or even see another's data.

**In plain words.** It's an apartment building instead of separate houses. Sharing walls, plumbing, and a lobby is much
cheaper, but you need locks on every door, fair rules for the laundry room, and walls thick enough that a neighbor's
party doesn't keep you awake.

**Architecture: tenancy models.**

```mermaid
flowchart LR
  subgraph SOFT["Soft: namespace per tenant"]
    C1["One cluster"] --> N1["ns team-a"]
    C1 --> N2["ns team-b"]
  end
  subgraph MID["Middle: virtual cluster per tenant"]
    C2["Host cluster"] --> V1["vCluster team-a<br/>own API server"]
    C2 --> V2["vCluster team-b"]
  end
  subgraph HARD["Hard: cluster or account per tenant"]
    A1["Account + cluster<br/>customer X"]
    A2["Account + cluster<br/>customer Y"]
  end
```

**How to read it:** with soft multi-tenancy, tenants share one cluster and are separated by namespaces. In the
middle, each tenant gets a virtual cluster with its own API server, running inside a shared host cluster. With hard
multi-tenancy, each tenant has its own cloud account and cluster. Isolation and cost both increase from left to right.

**Terms in this diagram.**
- **Soft multi-tenancy**: tenants trust each other somewhat (such as teams in one company), and share one control
  plane, separated by namespaces and policies.
- **Virtual cluster (vCluster)**: a Kubernetes control plane (API server and controllers) running as pods inside a host
  cluster's namespace. Each tenant sees what looks like a full cluster, including its own custom resources, while
  workloads actually run on the host's nodes.
- **Hard multi-tenancy**: tenants don't trust each other (such as different customers), so they're separated at the
  account, network, and cluster level.
- **Account**: a cloud account or project, the strongest common boundary for identity, billing, and networking.

**Core ideas.**
- **Who are the tenants?** Internal teams (soft tenancy is usually fine), business units with separate compliance needs
  (often separate node pools or clusters), or external customers (usually hard isolation, or very careful soft
  isolation for SaaS).
- **What's shared determines the risks.**
  - Shared control plane: one tenant's misconfiguration or API flood can affect all, and custom resources (CRDs) are
    cluster-wide.
  - Shared nodes: kernel and GPU driver vulnerabilities cross tenants.
  - Shared GPUs: memory and performance interference (Lecture 278).
  - Shared services: caches, vector stores, and logs can leak data between tenants.
- **Multi-tenant serving.** SaaS inference often serves many customers from one model deployment, with per-tenant
  rate limits, routing, and sometimes per-tenant LoRA adapters loaded on shared base models (vLLM and LoRAX support
  this).
- **Mixed approach.** Most companies combine models: soft tenancy for internal research, dedicated node pools for
  regulated data, and separate clusters or accounts for production customer workloads.

**Example: from 34% to 71% utilization.** A company ran six separate GPU clusters, one per team, averaging 34%
utilization, while teams still complained about waiting. Consolidating into one cluster with namespace tenancy and
Kueue quotas with borrowing raised utilization to 71% in a quarter, because idle GPUs were lent across teams. They
kept the medical-imaging team on a dedicated node pool with its own keys, since its data was regulated.

**Senior / FAANG best practice.** Classify tenants by trust and data sensitivity, and choose the tenancy model per
class: namespaces for internal teams, dedicated node pools or virtual clusters for sensitive groups, and separate
accounts and clusters for external customers. List every shared component (control plane, nodes, GPUs, caches, logs)
and decide how each is isolated.

---

## Lecture 275 — Resource sharing across teams

**Why it matters.** Static per-team GPU allocations waste money, and a free-for-all lets the most aggressive team take
everything. Quotas with borrowing and preemption give each team a guarantee while lending idle capacity, so the
cluster stays busy and fair.

**In plain words.** It's like a shared office with assigned desks. Everyone's desk is guaranteed, but if a colleague is
on holiday, you may use theirs. When they come back, you move.

**Architecture: Kueue quotas with borrowing and reclaim.**

```mermaid
flowchart TB
  subgraph COH["Cohort: research, 32 GPUs"]
    CQA["ClusterQueue team-a<br/>nominal 16, borrow up to 8"]
    CQB["ClusterQueue team-b<br/>nominal 8, borrow up to 8"]
    CQC["ClusterQueue team-c<br/>nominal 8, no borrowing"]
  end
  JB["team-b job, 8 GPUs<br/>over its nominal"] -->|"admitted: borrows team-a's idle GPUs"| CQB
  JA["team-a job, within nominal"] -->|"needs them back"| CQA
  CQA -->|"reclaimWithinCohort: preempt borrowed job"| JB
  PR["WorkloadPriorityClass<br/>within a queue, higher priority first"] -.-> CQA
```

**How to read it:** three cluster queues share a cohort of 32 GPUs. Team A is guaranteed 16, and teams B and C 8 each.
When team A is idle, team B's extra job borrows team A's GPUs. When team A then submits a job within its guarantee,
Kueue preempts team B's borrowed job to give team A its GPUs back. Within each queue, workload priority classes
decide which jobs go first.

**Terms in this diagram.**
- **Nominal quota**: the amount a queue is guaranteed. It can always get this much, by reclaiming if needed.
- **Borrow up to (borrowingLimit)**: the most a queue may use above its nominal quota, taken from other queues'
  unused nominal quota.
- **No borrowing**: a borrowing limit of 0, for teams that should never exceed their share (for example, for
  predictable cost).
- **reclaimWithinCohort**: a Kueue preemption setting that lets a queue under its nominal quota preempt workloads that
  other queues are running on borrowed quota.
- **WorkloadPriorityClass**: Kueue's priority for jobs, which decides order and preemption within a queue
  (`withinClusterQueue: LowerPriority`).

**Core ideas.**
- **Queue, don't reject.** Kueue suspends jobs until quota is available, instead of letting pods fail. It admits whole
  jobs at once (gang admission), so a 16-GPU distributed job doesn't start with only 12 workers (Section 11).
- **Preemption needs checkpointing.** Preempted jobs restart, so borrowed capacity is only useful for jobs that
  checkpoint often (Section 32). Mark long non-checkpointing jobs as not allowed to borrow.
- **Fair sharing.** Kueue's fair sharing mode divides surplus capacity by weights, instead of first-come-first-served.
- **GPU sharing within a node.**
  - **MIG** (Multi-Instance GPU, A100, H100, and newer): splits one GPU into up to 7 hardware-isolated instances, each
    with its own memory and compute. Good for inference and notebooks.
  - **Time-slicing**: several pods take turns on one GPU, with no memory isolation and unpredictable latency. Fine for
    development.
  - **MPS** (Multi-Process Service): runs several processes on one GPU concurrently, with better throughput than
    time-slicing, but limited isolation.
- **Priority classes for interactive vs batch.** Notebooks and inference get higher priority than batch training,
  with small guaranteed quotas so they never wait long.

**Example: reclaim that stopped wasting a weekend.** A research team's 64-GPU nominal quota sat idle every weekend,
while another team's hyperparameter sweeps queued. With borrowing enabled, the sweeps (checkpointing every 10 minutes)
ran on the idle GPUs. On Monday morning, the first team's jobs reclaimed their quota within 2 minutes, and the sweeps
resumed from checkpoints. Weekend utilization went from 22% to 88%.

**Senior / FAANG best practice.** Give each team a nominal quota sized to its steady need, allow borrowing for jobs
that checkpoint, and enable reclaim within the cohort. Use gang admission for distributed jobs, priority classes for
interactive work, MIG for inference and notebooks, and time-slicing only for development. Review quotas quarterly
against actual usage.

---

## Lecture 276 — Cost allocation for multi-tenant infra

**Why it matters.** When GPUs are shared, nobody feels the cost unless it's attributed. A clear, accepted cost model
changes behavior: teams release idle notebooks, right-size requests, and plan budgets. A disputed one starts political
arguments.

**In plain words.** It's like splitting a shared house's bills. Each person pays for their own room, and the shared
kitchen and heating are split by an agreed rule, written down, so nobody argues each month.

**Architecture: allocating a multi-tenant GPU bill.**

```mermaid
flowchart LR
  BILLC["Cloud bill<br/>GPU nodes, storage, network"] --> ALLOC["Allocation engine<br/>OpenCost, Kubecost, custom"]
  K8SM["Kubernetes metadata<br/>namespace, labels, requests"] --> ALLOC
  DCGMC["GPU metrics<br/>DCGM per pod"] --> ALLOC
  ALLOC --> DIRECT["Direct: requested GPU-hours<br/>per team"]
  ALLOC --> IDLE["Idle + reserved but unused<br/>spread by rule"]
  ALLOC --> SHARED["Shared services<br/>control plane, monitoring, platform team"]
  DIRECT & IDLE & SHARED --> REPORT["Monthly report per tenant<br/>showback or chargeback"]
```

**How to read it:** the allocation engine combines the cloud bill with Kubernetes metadata (namespace, labels, and
resource requests) and per-pod GPU metrics. It splits cost into three parts: direct cost for each team's requested
GPU-hours, idle and unused reserved capacity spread by an agreed rule, and shared services such as the control plane,
monitoring, and platform team. Each tenant gets a monthly report, which is either informational (showback) or charged to
their budget (chargeback).

**Terms in this diagram.**
- **Allocation engine, OpenCost, Kubecost**: tools that split cluster cost by namespace, label, and workload.
  **OpenCost** is an open-source CNCF project, and **Kubecost** is a commercial product built on it.
- **Kubernetes metadata, labels**: namespace, labels such as `team`, `project`, and `cost-center`, and each pod's
  resource requests.
- **DCGM per pod**: NVIDIA's Data Center GPU Manager exporter, which reports GPU utilization and memory per pod
  (Section 16).
- **Requested GPU-hours**: GPUs requested × hours, the fair basis for charging, since requested GPUs are unavailable to
  others whether or not they're used.
- **Idle, reserved but unused**: GPUs that nobody requested, including reserved or committed capacity paid for but
  not used.
- **Shared services**: costs that serve everyone, such as the Kubernetes control plane, monitoring, logging, and
  platform engineers.

**Core ideas.**
- **Charge for requests, not utilization.** A pod holding 8 GPUs at 10% utilization still blocks 8 GPUs. Report
  utilization separately as an efficiency score.
- **Pick an idle rule and write it down.** Common choices: spread idle proportionally to each team's usage, charge it
  to teams in proportion to their nominal quotas (since quotas reserve capacity), or keep it on the platform's budget
  as an incentive to right-size the cluster.
- **Commitments.** Reserved instances or savings plans lower the rate. Decide whether teams pay the discounted rate or
  the on-demand rate, with the difference funding the platform.
- **LLM serving per tenant.** For shared model endpoints, meter tokens (input and output separately) or GPU-seconds
  per tenant at the gateway, and convert to cost with a measured cost per million tokens.
- **Labels are a contract.** Admission policies require `team` and `cost-center` labels on every workload, or the cost
  lands in "unallocated", which should be close to zero.

```python
def allocate(gpu_hours_requested, node_gpu_hours, rate, shared_cost, idle_rule="proportional", nominal=None):
    """Split one month of GPU cost. Returns {team: cost}."""
    used = sum(gpu_hours_requested.values())
    idle = node_gpu_hours - used
    out = {t: h * rate for t, h in gpu_hours_requested.items()}
    weights = gpu_hours_requested if idle_rule == "proportional" else nominal
    wsum = sum(weights.values())
    for t in out:
        out[t] += (idle * rate + shared_cost) * weights[t] / wsum
    return {t: round(v) for t, v in out.items()}

req = {"team-a": 7_000, "team-b": 6_500, "team-c": 2_100}            # requested GPU-hours this month
nodes = 32 * 730                                                     # 32 GPUs for a 730-hour month
print(allocate(req, nodes, 2.50, 9_000))                             # idle spread by usage
# {'team-a': 30244, 'team-b': 28083, 'team-c': 9073}
print(allocate(req, nodes, 2.50, 9_000, "quota", {"team-a": 16, "team-b": 8, "team-c": 8}))
# {'team-a': 31700, 'team-b': 23350, 'team-c': 12350}
```

In the code, 32 GPUs for a 730-hour month give 23,360 GPU-hours, of which the teams requested 15,600, leaving 7,760
idle. Each team pays its requested hours at $2.50, plus a share of idle cost and $9,000 of shared services. With the
`proportional` rule, shares follow usage. With the `quota` rule, they follow nominal quotas, so team A, with half the
quota, pays half the idle and shared cost even in a light month. Team C's bill rises from $9,073 to $12,350 under the
quota rule, because it holds a quarter of the quota while using only 13% of the hours. That encourages teams to give
back quota they don't need. Total cost is $67,400 either way.

**Example: the notebook tax.** Showback reports revealed that 41% of one org's GPU-hours came from notebooks holding
GPUs overnight with near-zero utilization. Charging requested GPU-hours, plus an automatic notebook shutdown after 2
idle hours, cut the org's monthly GPU spend by $180,000 without slowing any training.

**Senior / FAANG best practice.** Allocate cost by requested GPU-hours, report utilization as a separate efficiency
metric, and write down the rules for idle and shared costs. Enforce cost labels with admission policies, keep
unallocated cost near zero, meter tokens or GPU-seconds per tenant for shared model endpoints, and publish monthly
showback before moving to chargeback.

---

## Lecture 277 — Role-based access control (RBAC)

**Why it matters.** In a shared cluster, RBAC decides who can see another team's secrets, delete their jobs, or read
their model weights. Over-broad roles are the most common multi-tenancy failure, and one compromised account with
cluster-admin can affect every tenant.

**In plain words.** It's like keycards in an office building. Your card opens your floor and the shared kitchen, and
only a few facility managers have cards for every floor. Cards are issued to roles ("engineer on team A"), not handed
out one door at a time.

**Architecture: identity to permissions.**

```mermaid
flowchart LR
  IDPU["Identity provider<br/>Okta, Entra ID, Google"] -->|"OIDC token with groups"| APIS["Kubernetes API server"]
  APIS --> RB["RoleBinding in ml-team-a<br/>group team-a to role ml-developer"]
  RB --> ROLE["Role ml-developer<br/>jobs, pods, logs, own secrets"]
  APIS --> CRB["ClusterRoleBinding<br/>platform-admins only"]
  SA["ServiceAccount per workload"] --> WI["Workload identity<br/>IRSA, GKE Workload Identity"]
  WI --> CLOUD["Cloud IAM role<br/>team-a buckets only"]
```

**How to read it:** users log in through the company identity provider, which issues a token listing their groups.
In each team namespace, a RoleBinding grants the team's group a role that allows managing jobs, pods, logs, and the
team's own secrets. Only platform administrators get cluster-wide bindings. Workloads run as service accounts, which
map to cloud IAM roles through workload identity, so a team's pods can reach only the team's buckets.

**Terms in this diagram.**
- **OIDC token with groups**: an OpenID Connect token that includes the user's group memberships, which Kubernetes
  can use as RBAC subjects.
- **RoleBinding, Role**: a **Role** lists allowed actions on resources in one namespace. A **RoleBinding** grants it to
  users, groups, or service accounts in that namespace.
- **ClusterRoleBinding**: grants a **ClusterRole** across the whole cluster. Keep these to a minimum.
- **ServiceAccount**: the identity a pod runs as inside Kubernetes.
- **Workload identity, IRSA, GKE Workload Identity**: mapping a Kubernetes service account to a cloud IAM role, so
  pods get short-lived cloud credentials without stored keys. **IRSA** (IAM Roles for Service Accounts) and EKS Pod
  Identity are AWS's versions. GKE Workload Identity is Google's, and Azure has Workload Identity too.

**Core ideas.**
- **Bind groups, not people.** Users join and leave teams in the identity provider, and permissions follow
  automatically.
- **Standard roles per namespace.** For example: `ml-viewer` (read), `ml-developer` (create jobs, read logs, use
  secrets), and `ml-admin` (manage quotas within the namespace's limits, role bindings for their team). Built-in
  `view`, `edit`, and `admin` ClusterRoles can be bound per namespace too.
- **Dangerous permissions.** Watch for `create pods/exec` (shell into any pod in the namespace), `get secrets`
  across namespaces, `create` on `rolebindings` (self-escalation), `nodes/proxy`, and any wildcard `*`. Audit them
  with `kubectl auth can-i --list` and tools such as rbac-lookup.
- **Cloud IAM follows tenancy.** One cloud role per team's service account, scoped to the team's buckets and
  registries. Never put shared node roles with access to everything (Section 39).
- **Beyond Kubernetes.** The same group model should drive MLflow permissions, registry access, feature store
  projects, and serving API keys, so a user's access is consistent everywhere (Section 33).

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata: {name: ml-developer, namespace: ml-team-a}
rules:
  - apiGroups: ["batch"]
    resources: ["jobs"]
    verbs: ["get", "list", "watch", "create", "delete"]
  - apiGroups: [""]
    resources: ["pods", "pods/log"]
    verbs: ["get", "list", "watch"]
  - apiGroups: ["kueue.x-k8s.io"]
    resources: ["workloads", "localqueues"]
    verbs: ["get", "list", "watch"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata: {name: team-a-developers, namespace: ml-team-a}
subjects: [{kind: Group, name: team-a, apiGroup: rbac.authorization.k8s.io}]
roleRef: {kind: Role, name: ml-developer, apiGroup: rbac.authorization.k8s.io}
```

In the YAML, the role lets team members create and delete jobs, read pods and logs, and see their Kueue workloads and
queue, but not exec into pods, read secrets, or change quotas. The binding grants it to everyone in the `team-a` group
from the identity provider, only in the `ml-team-a` namespace.

**Example: the intern with cluster-admin.** To unblock an urgent demo, an intern was given cluster-admin "for a day".
Six months later, a phishing attack stole their laptop token, and the attacker listed secrets in every namespace,
including another team's Hugging Face and cloud keys. The company moved to group-based namespace roles only,
time-limited elevation through an access request tool, and a weekly report of all ClusterRoleBindings.

**Senior / FAANG best practice.** Map identity-provider groups to standard namespaced roles, keep cluster-wide bindings
to a small platform group with time-limited elevation, and audit dangerous verbs regularly. Use workload identity with
one cloud role per tenant, and drive MLflow, registry, feature store, and serving permissions from the same groups.

---

## Lecture 278 — Isolation strategies in AI systems

**Why it matters.** Quotas and RBAC stop tenants from taking each other's resources or permissions, but they don't stop
a pod from connecting to another team's database, a GPU job from slowing a neighbor's inference, or a shared prompt
cache from leaking one customer's data to another. AI systems add GPU, cache, and vector-store isolation problems on
top of the usual ones.

**In plain words.** Locks on doors (RBAC) aren't enough in an apartment building. You also need soundproof walls
(performance isolation), separate mailboxes (data isolation), and maybe a separate building for the bank vault (hard
isolation).

**Architecture: isolation layers for tenants.**

```mermaid
flowchart TB
  NETL["Network<br/>default-deny NetworkPolicy, egress allowlist"] --> NODEL["Nodes<br/>tenant node pools via taints, tolerations"]
  NODEL --> RT["Runtime<br/>gVisor or Kata for untrusted code"]
  RT --> GPUL["GPU<br/>whole GPU or MIG for strong isolation,<br/>time-slicing for dev only"]
  GPUL --> DATAL["Data<br/>per-tenant buckets, KMS keys,<br/>vector DB namespaces + filters"]
  DATAL --> CACHE["Caches<br/>prefix and KV cache keyed by tenant"]
```

**How to read it:** isolation stacks in layers. Network policies deny traffic by default and allow only what's needed.
Tenant-specific node pools keep workloads apart on separate machines. Sandboxed runtimes protect against untrusted code.
GPUs are given whole or as MIG slices when isolation matters. Data is split into per-tenant buckets, encryption keys,
and vector-store namespaces. Caches, including LLM prefix and KV caches, are keyed by tenant so one tenant's data is
never served to another.

**Terms in this diagram.**
- **Default-deny NetworkPolicy, egress allowlist**: block all pod traffic unless explicitly allowed, including
  outbound traffic to the internet (Section 39).
- **Taints, tolerations**: a **taint** on a node repels pods. Only pods with a matching **toleration** can run there,
  which dedicates node pools to tenants (Section 5).
- **gVisor, Kata**: sandboxed container runtimes. **gVisor** intercepts system calls in a user-space kernel. **Kata
  Containers** runs each pod in a lightweight virtual machine. Both reduce the risk of a container escaping to the
  host.
- **MIG**: Multi-Instance GPU, which partitions a GPU into instances with separate memory, cache, and compute units.
- **Per-tenant buckets, KMS keys**: separate storage locations, each encrypted with a key that only that tenant's roles
  can use, so even a misconfigured bucket policy doesn't expose plaintext to others.
- **Vector DB namespaces + filters**: separate collections or namespaces per tenant in a vector database, or mandatory
  tenant filters on every query (Section 25).
- **Prefix and KV cache**: LLM servers reuse the computed attention state for repeated prompt prefixes. If shared
  across tenants, timing differences can reveal whether another tenant sent the same prefix.

**Core ideas.**
- **Network isolation is the first wall.** Default-deny ingress and egress per namespace, then allow traffic within
  the namespace, to shared services (DNS, registry, MLflow), and to approved external endpoints. It requires a CNI that
  enforces NetworkPolicy, such as Calico or Cilium.
- **Noisy neighbors on GPUs.**
  - Time-slicing and MPS share memory bandwidth and caches, so one tenant's job can double another's latency.
  - MIG gives predictable performance with hardware partitions.
  - Separate nodes also avoid PCIe, NVLink, and network interference.
- **Data isolation patterns.** Silo (a database per tenant), bridge (a schema or namespace per tenant), or pool (shared
  tables with a tenant ID column and enforced filters). The pool pattern is cheapest, but a missing filter is a data
  breach, so enforce it in the data layer, not in application code.
- **LLM-specific isolation.** Key prompt caches and semantic caches by tenant (Section 25). Load per-tenant adapters
  only for that tenant's requests. Never mix tenants' data in one fine-tuning job unless contracts allow it.
- **Hard isolation where trust is low.** Separate clusters or accounts for external customers handling regulated
  data, and confidential computing for the strongest guarantees (Section 38).

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: {name: default-deny, namespace: ml-team-a}
spec:
  podSelector: {}
  policyTypes: ["Ingress", "Egress"]
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: {name: allow-same-ns-and-dns, namespace: ml-team-a}
spec:
  podSelector: {}
  policyTypes: ["Ingress", "Egress"]
  ingress: [{from: [{podSelector: {}}]}]
  egress:
    - to: [{podSelector: {}}]
    - to: [{namespaceSelector: {matchLabels: {kubernetes.io/metadata.name: kube-system}},
            podSelector: {matchLabels: {k8s-app: kube-dns}}}]
      ports: [{protocol: UDP, port: 53}, {protocol: TCP, port: 53}]
```

In the YAML, the first policy selects every pod in the namespace (`podSelector: {}`) and lists both policy types with no
rules, which denies all traffic in and out. The second allows traffic between pods in the same namespace, and DNS
lookups to the cluster DNS pods in `kube-system`. Further policies would allow access to shared services such as the
model registry.

**Example: the shared prompt cache.** A SaaS assistant served many customers from one vLLM deployment with automatic
prefix caching. A security review showed that a request beginning with another customer's long, confidential system
prompt returned its first token noticeably faster when that prompt was cached, which leaked whether that prompt had
been used. The team added the tenant ID to the cache key (separate cache salts per tenant), and documented that
isolation in their security whitepaper.

**Senior / FAANG best practice.** Apply default-deny network policies with explicit allows and egress allowlists, and
use dedicated node pools and MIG for tenants needing predictable performance or stronger isolation. Sandbox untrusted
code with gVisor or Kata, isolate data with per-tenant keys and enforced filters, key every cache by tenant, and use
separate accounts or clusters where tenants don't trust each other.

---

## Lecture 279 — Monitoring multi-tenant environments

**Why it matters.** "The cluster is healthy" means little to a team whose jobs have been pending for 6 hours, or a
customer whose p99 latency doubled because of a neighbor. Multi-tenant monitoring shows each tenant's experience,
detects interference, and gives each tenant visibility into its own usage without seeing others'.

**In plain words.** A building manager watches the whole building, but each tenant also needs their own meter readings
and a way to know if the noise is coming from next door.

**Architecture: per-tenant observability.**

```mermaid
flowchart LR
  DCGMM["DCGM exporter<br/>GPU util, memory, per pod"] --> PROM["Prometheus or Mimir<br/>tenant label or tenant ID"]
  KSM["kube-state-metrics<br/>quotas, pending pods"] --> PROM
  KQ["Kueue metrics<br/>pending workloads, admission wait"] --> PROM
  GW["Serving gateway<br/>latency, tokens, errors per tenant"] --> PROM
  PROM --> SLOT["Per-tenant SLOs<br/>queue wait, p99, error rate"]
  PROM --> NN["Noisy-neighbor detection<br/>latency vs co-located load"]
  PROM --> DASH["Grafana dashboards<br/>each tenant sees its own"]
  SLOT --> ALERT["Alerts to the tenant<br/>and the platform"]
```

**How to read it:** GPU metrics per pod, Kubernetes quota and pod state, Kueue queue metrics, and serving gateway metrics
per tenant all go into Prometheus (or a multi-tenant store such as Mimir) with a tenant label. From there, per-tenant
SLOs track queue wait, latency, and error rate. Noisy-neighbor detection compares a tenant's latency with the load of
workloads sharing its nodes or GPUs. Each tenant gets dashboards limited to its own data, and alerts go to both the
tenant and the platform team.

**Terms in this diagram.**
- **DCGM exporter**: NVIDIA's Prometheus exporter for GPU metrics, which can attach pod and namespace labels (Section
  16).
- **Prometheus or Mimir, tenant ID**: Prometheus stores metrics. **Grafana Mimir** (and Thanos or Cortex) are scalable
  stores with built-in tenant separation, where each tenant's metrics are kept apart by a tenant ID header.
- **kube-state-metrics**: an exporter of Kubernetes object state, such as quota usage and pending pods.
- **Kueue metrics**: Kueue's own metrics, such as pending workloads per queue and time to admission.
- **Serving gateway**: the API layer in front of models, which tags each request with its tenant (Section 14).
- **Noisy-neighbor detection**: comparing one tenant's performance with the activity of others on shared hardware to
  find interference.
- **Grafana dashboards, each tenant sees its own**: dashboards filtered by tenant, with Grafana teams or organizations
  controlling who sees which.

**Core ideas.**
- **Per-tenant SLOs.** For training: time from submission to admission (queue wait), and job success rate. For serving:
  p99 latency, error rate, and throttling rate per tenant. A cluster-wide average hides the unlucky tenant.
- **Usage against quota.** Alert tenants when they're near their quota or constantly borrowing, and alert the platform
  when quotas are mostly unused (time to rebalance).
- **Noisy neighbors.** Correlate a tenant's latency with other workloads on the same nodes or GPUs (from scheduler and
  DCGM data). Persistent interference is a signal to move workloads to MIG or dedicated nodes.
- **Cardinality.** A tenant label on every metric multiplies series counts. Use per-tenant labels on key metrics, and
  aggregate the rest.
- **Tenant-visible data.** Tenants should see their own usage, cost, queue position, and SLOs. Exposing other tenants'
  job names or metrics can itself leak information.

```promql
# p95 time to admission per ClusterQueue over the last hour (Kueue metric)
histogram_quantile(0.95, sum by (le, cluster_queue) (rate(kueue_admission_wait_time_seconds_bucket[1h])))

# GPU-hours requested per namespace today (DCGM labels pods with namespace)
sum by (namespace) (count_over_time(DCGM_FI_DEV_GPU_UTIL[24h:1m])) / 60

# average GPU utilization of allocated GPUs per namespace, to spot idle holders
avg by (namespace) (avg_over_time(DCGM_FI_DEV_GPU_UTIL[6h]))
```

In the queries, the first gives the time within which 95% of each queue's workloads were admitted, from Kueue's
admission wait histogram. The second counts one-minute samples of each allocated GPU over 24 hours and divides by 60 to
get GPU-hours per namespace. The third averages utilization of allocated GPUs per namespace over 6 hours, which finds
teams holding GPUs they aren't using.

**Example: the tenant who was always last.** One team complained jobs "never start", while cluster dashboards showed
spare capacity. Per-queue admission-wait metrics showed their p95 wait was 5 hours, against 10 minutes for others. Their
jobs requested 8 GPUs on a single node with a specific GPU type, which only a few nodes had, and smaller jobs kept
fragmenting those nodes. The platform added a dedicated flavor in Kueue for that GPU type and topology-aware placement,
and their p95 wait fell to 25 minutes.

**Senior / FAANG best practice.** Define SLOs per tenant (queue wait, job success, serving latency, errors), track usage
against quota, and detect noisy neighbors by correlating latency with co-located load. Use a tenant-aware metrics store,
control label cardinality, and give each tenant dashboards and alerts for their own data only.

---

## Lecture 280 — Lab: configure multi-tenant cluster

**Goal:** set up a kind cluster with two team namespaces, each with a ResourceQuota, a LimitRange, a namespaced RBAC role,
and default-deny network policies, and install Kueue with two ClusterQueues in a cohort, then show borrowing and reclaim
with simulated GPUs.

**What you're building:** a kind cluster running Calico, team namespaces with guardrails, Kueue queues sharing 8 fake GPUs,
and a set of test jobs.

```mermaid
flowchart LR
  KIND2["kind + Calico<br/>node advertises 8 fake GPUs"] --> NSA["ml-team-a<br/>quota, LimitRange, RBAC, netpol"]
  KIND2 --> NSB["ml-team-b<br/>same guardrails"]
  NSA --> LQA["LocalQueue team-a"] --> CQA2["ClusterQueue a<br/>nominal 4 GPUs"]
  NSB --> LQB["LocalQueue team-b"] --> CQB2["ClusterQueue b<br/>nominal 4, borrow 4"]
  CQA2 & CQB2 --> COH2["Cohort research"]
```

**How to read the diagram:** a kind cluster runs Calico, so network policies are enforced, and its node is patched to
advertise 8 fake GPUs. Each team namespace gets the same guardrails, and a local queue pointing to its cluster queue.
Team A's queue is guaranteed 4 GPUs. Team B's is guaranteed 4 and may borrow 4 more. Both queues belong to the cohort
`research`. **Calico** is a CNI (container network interface) plugin that enforces NetworkPolicy, which kind's default
network plugin doesn't.

**Prerequisites:** Docker, `kind`, `kubectl` 1.28+, about 4 GB of free RAM.

### Step 1 — Cluster with Calico and fake GPUs

```bash
cat > kind.yaml <<'EOF'
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
networking: {disableDefaultCNI: true, podSubnet: 192.168.0.0/16}
EOF
kind create cluster --name tenancy --config kind.yaml
kubectl apply -f https://raw.githubusercontent.com/projectcalico/calico/v3.28.2/manifests/calico.yaml
kubectl -n kube-system rollout status ds/calico-node --timeout=300s
kubectl patch node tenancy-control-plane --subresource=status --type=json \
  -p '[{"op":"add","path":"/status/capacity/nvidia.com~1gpu","value":"8"}]'
kubectl get node tenancy-control-plane -o jsonpath='{.status.allocatable.nvidia\.com/gpu}'; echo
```

In the commands, `disableDefaultCNI` starts kind without its own network plugin so Calico can be installed. The node
patch adds an extended resource called `nvidia.com/gpu` with capacity 8 to the node's status. Nothing uses real GPUs:
the scheduler and Kueue just count it, which is enough to test quotas. `~1` is the JSON Patch escape for `/` in a key.

### Step 2 — Namespaces with guardrails

```bash
for t in a b; do
kubectl create namespace ml-team-$t
kubectl apply -n ml-team-$t -f - <<EOF
apiVersion: v1
kind: ResourceQuota
metadata: {name: team-quota}
spec:
  hard: {requests.cpu: "4", requests.memory: 8Gi, requests.nvidia.com/gpu: "8", pods: "20"}
---
apiVersion: v1
kind: LimitRange
metadata: {name: defaults}
spec:
  limits:
    - type: Container
      default: {cpu: 500m, memory: 512Mi}
      defaultRequest: {cpu: 100m, memory: 128Mi}
      max: {cpu: "2", memory: 4Gi}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata: {name: ml-developer}
rules:
  - {apiGroups: ["batch"], resources: ["jobs"], verbs: ["get", "list", "watch", "create", "delete"]}
  - {apiGroups: [""], resources: ["pods", "pods/log"], verbs: ["get", "list", "watch"]}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata: {name: team-$t-developers}
subjects: [{kind: Group, name: team-$t, apiGroup: rbac.authorization.k8s.io}]
roleRef: {kind: Role, name: ml-developer, apiGroup: rbac.authorization.k8s.io}
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: {name: default-deny-ingress-from-other-ns}
spec:
  podSelector: {}
  policyTypes: ["Ingress"]
  ingress: [{from: [{podSelector: {}}]}]
EOF
done
```

In the YAML, the quota caps each namespace at 4 CPUs, 8 GiB of memory requests, 8 GPUs, and 20 pods. The LimitRange
gives containers without requests 100m CPU and 128 MiB, and limits of 500m and 512 MiB, and rejects containers above
2 CPUs or 4 GiB. The role and binding grant the `team-a` or `team-b` group job and pod access in its own namespace only.
The network policy allows ingress only from pods in the same namespace.

### Step 3 — Kueue with a cohort

```bash
KUEUE_VERSION=v0.13.0      # check https://github.com/kubernetes-sigs/kueue/releases for the latest
kubectl apply --server-side -f https://github.com/kubernetes-sigs/kueue/releases/download/$KUEUE_VERSION/manifests.yaml
kubectl -n kueue-system rollout status deploy/kueue-controller-manager --timeout=300s
kubectl apply -f - <<'EOF'
apiVersion: kueue.x-k8s.io/v1beta1
kind: ResourceFlavor
metadata: {name: fake-gpu}
---
apiVersion: kueue.x-k8s.io/v1beta1
kind: ClusterQueue
metadata: {name: cq-team-a}
spec:
  cohort: research
  namespaceSelector: {matchLabels: {kubernetes.io/metadata.name: ml-team-a}}
  preemption: {reclaimWithinCohort: Any, withinClusterQueue: LowerPriority}
  resourceGroups:
    - coveredResources: ["cpu", "memory", "nvidia.com/gpu"]
      flavors:
        - name: fake-gpu
          resources:
            - {name: cpu, nominalQuota: 2}
            - {name: memory, nominalQuota: 4Gi}
            - {name: nvidia.com/gpu, nominalQuota: 4, borrowingLimit: 0}
---
apiVersion: kueue.x-k8s.io/v1beta1
kind: ClusterQueue
metadata: {name: cq-team-b}
spec:
  cohort: research
  namespaceSelector: {matchLabels: {kubernetes.io/metadata.name: ml-team-b}}
  preemption: {reclaimWithinCohort: Any, withinClusterQueue: LowerPriority}
  resourceGroups:
    - coveredResources: ["cpu", "memory", "nvidia.com/gpu"]
      flavors:
        - name: fake-gpu
          resources:
            - {name: cpu, nominalQuota: 2}
            - {name: memory, nominalQuota: 4Gi}
            - {name: nvidia.com/gpu, nominalQuota: 4, borrowingLimit: 4}
---
apiVersion: kueue.x-k8s.io/v1beta1
kind: LocalQueue
metadata: {name: team-a, namespace: ml-team-a}
spec: {clusterQueue: cq-team-a}
---
apiVersion: kueue.x-k8s.io/v1beta1
kind: LocalQueue
metadata: {name: team-b, namespace: ml-team-b}
spec: {clusterQueue: cq-team-b}
EOF
```

In the YAML, the `ResourceFlavor` names a kind of resource (here, "the fake GPUs on this node"). Each ClusterQueue
accepts workloads only from its team's namespace, and both join the cohort `research`. Team A is guaranteed 4 GPUs and
can't borrow. Team B is guaranteed 4 and may borrow 4. `reclaimWithinCohort: Any` lets a queue under its nominal quota
preempt borrowed workloads. Each LocalQueue connects a namespace to its ClusterQueue.

### Step 4 — Borrowing, reclaim, and guardrail tests

```bash
job() {   # job <namespace> <queue> <name> <gpus>
kubectl create -n $1 -f - <<EOF
apiVersion: batch/v1
kind: Job
metadata: {name: $3, labels: {kueue.x-k8s.io/queue-name: $2}}
spec:
  template:
    spec:
      restartPolicy: Never
      containers:
        - name: work
          image: busybox:1.36
          command: ["sh", "-c", "sleep 600"]
          resources: {requests: {cpu: 100m, memory: 64Mi, nvidia.com/gpu: "$4"}, limits: {nvidia.com/gpu: "$4"}}
EOF
}
job ml-team-b team-b b-1 4 && job ml-team-b team-b b-2 4      # b-2 borrows team-a's idle 4
sleep 10 && kubectl get workloads -A
job ml-team-a team-a a-1 4                                     # team-a reclaims: b-2 is preempted
sleep 15 && kubectl get workloads -A && kubectl get jobs -A
kubectl auth can-i create jobs -n ml-team-b --as alice --as-group team-a
kubectl auth can-i get secrets -n ml-team-a --as alice --as-group team-a
kubectl run probe -n ml-team-b --image=busybox:1.36 --restart=Never -- sleep 600
kubectl run web -n ml-team-a --image=nginx:1.27 --port 80 && kubectl expose -n ml-team-a pod web --port 80
kubectl exec -n ml-team-b probe -- wget -qO- -T 3 http://web.ml-team-a.svc.cluster.local || echo "blocked"
```

In the commands, the `job` helper creates a suspended-until-admitted Job: the `kueue.x-k8s.io/queue-name` label sends
it to the namespace's LocalQueue, and Kueue unsuspends it when quota is available. `kubectl get workloads -A` shows
Kueue's view of each job, including whether it's admitted. `kubectl auth can-i --as ... --as-group` checks what a
user in a group may do, without real logins. The last commands start a pod in team B's namespace and try to reach a
web server in team A's namespace, which the network policy blocks.

**Expected results:**
- The node reports `8` allocatable `nvidia.com/gpu`.
- `b-1` and `b-2` are both admitted. `b-2` is using quota borrowed from team A.
- After `a-1` is submitted, `b-2` is evicted (its workload shows `Preempted` or goes back to pending, and its job
  suspends), and `a-1` is admitted. Team B keeps `b-1`.
- `kubectl auth can-i create jobs -n ml-team-b` for a `team-a` member: `no`. `get secrets -n ml-team-a`: `no`.
- The cross-namespace `wget` times out and prints `blocked`.
- A pod requesting 3 CPUs in either namespace is rejected by the LimitRange (max 2).

---

## Assessment — Enforce multi-tenant resource quotas

**Scenario.** Three ML teams share a 32-GPU cohort. Team A is guaranteed 16 GPUs and may borrow 8, team B 8 and may
borrow 8, and team C 8 with no borrowing. Each namespace also has a ResourceQuota and LimitRange. Implement both layers
of enforcement (namespace admission and queue admission with borrowing and reclaim) and show that every rule holds.

**Task.**

```bash
python3 exercises/s40_tenant_quotas.py
```

**Formulas.**
- Pod admission: effective request = explicit request, or the LimitRange default. Reject if above the LimitRange max.
  GPU request must equal its limit. Reject if namespace usage + request is over the quota's hard limit.
- Queue admission: admit if usage + request ≤ nominal + borrowingLimit and cohort total + request ≤ cohort capacity.
- Reclaim: if usage + request ≤ nominal, preempt other queues' borrowed workloads (lowest priority, then newest) until it
  fits.

**Expected output:**

| Event | Result |
|---|---|
| Notebook pod with no requests | Admitted, charged 500m CPU and 1 GiB (LimitRange defaults) |
| GPU request without a limit | Denied: extended resources need a limit |
| GPU request 2, limit 4 | Denied: request must equal limit |
| 64-CPU container | Denied by LimitRange max |
| Team C GPU pods: 4 + 4, then 1 more | First two admitted, the 9th GPU denied by ResourceQuota (hard 8) |
| team-b second 8-GPU job | Admitted by borrowing team A's idle 8 |
| team-c 8 GPUs, then 4 more | First admitted. Second pending (borrowingLimit 0) |
| Cohort usage before reclaim | 32 of 32 GPUs |
| team-a 8-GPU urgent job | Admitted after preempting `b-sweep-2` (team B back to 8) |
| team-b 9-GPU job | Pending: over nominal + borrowingLimit (8 + 8 = 16, with 8 already used) |
| `a-urgent` finishes | `b-sweep-2` re-admitted from the queue |

All 12 checks print `PASS`.

**What a strong answer explains:**
- **Two layers do different jobs.** ResourceQuota is a hard cap that rejects pods immediately. Kueue decides when a
  whole job may start, queues instead of rejecting, and shares idle capacity.
- **Namespace quota must allow borrowing.** If team B's ResourceQuota were 8 GPUs, Kueue could never let it borrow. Set
  the hard cap to nominal + borrowingLimit.
- **GPUs can't be overcommitted.** Extended resources require request equal to limit, so quotas on GPUs are exact.
- **Defaults count against the quota.** Containers without requests are charged LimitRange defaults, so tiny notebooks
  still use quota.
- **Reclaim protects guarantees.** A team under its nominal quota always gets its GPUs back, preempting only borrowed
  work, so borrowing should be reserved for jobs that checkpoint.
- **No borrowing is a valid choice.** Team C's fixed share gives predictable cost, at the price of sometimes waiting
  while others have idle GPUs.

---

## FAANG deep-dive notes

**How big tech does it.** Large companies run a few very large shared GPU fleets, rather than per-team clusters. Google's
Borg introduced priority-based quotas and preemption for shared clusters, which shaped Kubernetes and Kueue. Meta,
Microsoft, and others run shared research clusters with team quotas, borrowing, gang scheduling, and preemption of
lower-priority jobs, and charge internal budgets for GPU-hours. External customers are isolated with separate projects
or accounts, and SaaS model APIs use per-tenant rate limits, keyed caches, and strict data separation. Cost dashboards
and quotas are reviewed regularly against demand.

**Staff review questions.**
- Who are the tenants, and what tenancy model does each class get?
- What's each team's guaranteed GPU quota, and how much borrowing and preemption is allowed?
- How are idle and shared costs allocated, and do teams agree with the rule?
- Which identities have cluster-wide permissions, and how is elevation granted?
- What isolates tenants on the network, nodes, GPUs, data, and caches?
- What are the per-tenant SLOs, and how are noisy neighbors detected?

**Interview question.** "Design a shared GPU platform for 40 teams on 2,000 GPUs."

**Typical system-design prompt:** *Design a multi-tenant training and inference platform on 2,000 H100s for 40 teams,
including two regulated teams and an external-customer inference product.*

**1. Clarify first:** Training vs inference split? Peak vs average demand per team? Which teams handle regulated data?
Do external customers need dedicated hardware? Budget model: showback or chargeback?

**2. Back-of-envelope sizing:**
- Guarantees: 2,000 GPUs, keep ~10% (200) for interactive and inference headroom. Nominal quotas sum to ~1,800, sized
  from the last quarter's p50 demand per team. Borrowing covers peaks.
- Utilization target: 80% of GPU-hours requested. At $2.50 per GPU-hour, every 10 points of utilization is worth about
  $4.4 million a year (2,000 × 8,760 × 0.10 × $2.50).
- Regulated teams: dedicated node pools (say 128 GPUs), no borrowing in or out.
- External inference: separate cluster in a separate account (say 256 GPUs), with per-customer rate limits and
  tenant-keyed caches.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Tenancy for internal teams | Cluster per team | Namespaces + Kueue | Namespaces with quotas and borrowing |
| Regulated data | Shared nodes | Dedicated pool or cluster | Dedicated, with separate keys |
| External customers | Shared cluster | Separate account and cluster | Separate account |
| GPU sharing | Time-slicing | MIG or whole GPUs | MIG or whole GPUs for production |
| Cost | Showback | Chargeback | Showback first, chargeback after rules are trusted |

**4. Follow-up questions with crisp answers:**
- *A team says their jobs are always preempted.* They're running on borrowed quota. Either raise their nominal quota,
  or make them checkpoint more often and use priority.
- *How do you stop one team grabbing everything on Monday morning?* Nominal guarantees plus reclaim, and fair sharing
  of the surplus.
- *How do you handle a request for cluster-admin?* Time-limited elevation through an access tool, logged and reviewed.
- *Who pays for idle GPUs?* A written rule, such as by nominal quota, so teams return quota they don't use.

**Debug this (common onsite question):** "A customer's p99 latency on the shared inference cluster doubles every
afternoon."
1. Per-tenant latency rises at 14:00 daily, and other tenants' latency is unchanged.
2. Their replicas share GPUs, using time-slicing, with a batch embedding job from another tenant that runs at 14:00.
3. DCGM shows memory bandwidth saturation on those GPUs during the batch job.
4. Fix: move the customer's replicas to MIG instances or dedicated GPUs, put batch jobs on a separate pool, and add a
   noisy-neighbor alert correlating latency with co-located load.

The lesson: shared GPUs without hardware isolation make one tenant's batch job another's outage.

**5. What separates senior from staff answers:** a senior engineer sets up namespaces, quotas, and RBAC. A staff engineer
classifies tenants by trust, designs quotas with borrowing and reclaim from demand data, agrees on a cost allocation
rule with finance and teams, layers isolation across network, nodes, GPUs, data, and caches, and runs the platform on
per-tenant SLOs.

**Red flags:**
- Static per-team clusters at low utilization.
- ResourceQuota lower than nominal + borrowing, so borrowing can't work.
- Charging by utilization, so idle holders pay nothing.
- Cluster-admin for convenience.
- No NetworkPolicy enforcement (a CNI that ignores it).
- Time-sliced GPUs for latency-sensitive production inference.
- Caches shared across external customers.

---

## Quiz

<details><summary>1. What is the difference between soft and hard multi-tenancy?</summary>
Soft tenancy shares one cluster and control plane among somewhat trusted tenants, separated by namespaces and policies.
Hard tenancy separates untrusted tenants at the account, network, and cluster level.
</details>

<details><summary>2. What do Kueue's nominal quota and borrowingLimit mean?</summary>
Nominal quota is what a ClusterQueue is guaranteed. borrowingLimit is how much extra it may use from other queues'
unused nominal quota in the same cohort.
</details>

<details><summary>3. What happens with reclaimWithinCohort when a team under its nominal quota submits a job?</summary>
Kueue preempts other queues' workloads that are running on borrowed quota, until the new job fits within the team's
guarantee.
</details>

<details><summary>4. Why charge tenants for requested GPU-hours rather than utilization?</summary>
Requested GPUs are unavailable to others whether used or not. Charging utilization lets idle holders pay nothing.
Utilization is reported separately as an efficiency metric.
</details>

<details><summary>5. Why must a GPU request equal its limit in Kubernetes?</summary>
nvidia.com/gpu is an extended resource, which can't be overcommitted, so Kubernetes requires a limit and treats the request
as equal to it.
</details>

<details><summary>6. What's the difference between MIG and time-slicing for GPU sharing?</summary>
MIG partitions the GPU into hardware-isolated instances with dedicated memory and compute, giving predictable performance.
Time-slicing has pods take turns with no memory isolation and unpredictable latency.
</details>

<details><summary>7. Why can a shared LLM prefix cache leak data between tenants?</summary>
A cached prefix makes the first token arrive faster, so another tenant can detect whether someone already sent that exact
prompt prefix. Keying caches by tenant prevents it.
</details>

<details><summary>8. Why might network policies have no effect on a cluster?</summary>
NetworkPolicy is enforced by the CNI plugin, and some (such as kind's default) don't enforce it. Use Calico, Cilium, or
another enforcing CNI.
</details>

## Failure modes
- Per-team clusters with low utilization while teams wait.
- Quotas so tight borrowing can't happen, or none at all, letting one team take everything.
- Borrowed capacity used by jobs that don't checkpoint, losing work on reclaim.
- Unlabeled workloads, so costs land in "unallocated".
- Broad RBAC, cluster-admin grants, and long-lived personal credentials.
- A CNI that silently ignores NetworkPolicy.
- Latency-sensitive tenants on time-sliced GPUs next to batch jobs.
- Shared caches, vector stores, or logs leaking between tenants.
- Cluster-wide dashboards that hide one tenant's bad experience.

## Checklist
- [ ] Tenants are classified, and each class has an explicit tenancy model
- [ ] Teams have nominal quotas, borrowing limits, and reclaim, with ResourceQuota set to nominal + borrowing
- [ ] Cost is allocated by requested GPU-hours with written idle and shared-cost rules
- [ ] RBAC binds SSO groups to namespaced roles, and cluster-wide access is time-limited
- [ ] Network, node, GPU, data, and cache isolation match each tenant's trust level
- [ ] Per-tenant SLOs, quota usage, and noisy-neighbor detection are in place
- [ ] You configured a multi-tenant kind cluster with Kueue borrowing and reclaim
- [ ] You ran the assessment and can explain both enforcement layers
