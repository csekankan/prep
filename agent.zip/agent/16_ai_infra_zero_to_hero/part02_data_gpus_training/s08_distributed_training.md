# Section 8 — Distributed Training Basics

> Lectures 50–56 • Assessment: quiz + Plan a Distributed Global Batch Size
> **After this section you can:** explain when and why training must span many GPUs, choose between data,
> tensor, and pipeline parallelism (and FSDP/ZeRO), launch PyTorch and TensorFlow multi-GPU jobs, explain
> how ring all-reduce works and what it costs, design for failures with checkpoints and elastic restarts,
> and plan a global batch size with the right learning rate.
>
> Go deeper: [13 / Part 3 — Distributed training](../../13_sovereign_ai_infra_course/03_distributed_training/README.md)
> ([FSDP](../../13_sovereign_ai_infra_course/03_distributed_training/lab34_pytorch_fsdp.md),
> [NCCL tuning](../../13_sovereign_ai_infra_course/03_distributed_training/lab36_nccl_optimization.md),
> [checkpointing to S3](../../13_sovereign_ai_infra_course/03_distributed_training/lab39_checkpointing_s3.md),
> [Megatron-LM](../../13_sovereign_ai_infra_course/03_distributed_training/lab40_megatron_lm.md)).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 50 | Why distributed training is needed | Big models need more memory than one GPU has, and more compute than one GPU can do in a useful time |
| 51 | Data parallelism vs model parallelism | Copy the model and split the data, or split the model itself. Large jobs combine both |
| 52 | PyTorch distributed training | `torchrun` + NCCL + DDP or FSDP: one process per GPU, gradients averaged every step |
| 53 | TensorFlow multi-GPU training | `tf.distribute` strategies wrap the same ideas for Keras |
| 54 | Horovod and all-reduce explained | Ring all-reduce sums gradients with bandwidth-optimal traffic. Horovod popularized it |
| 55 | Fault tolerance in distributed training | At scale something fails every few hours. Checkpoint, restart automatically, and resume |
| 56 | Lab: train ResNet across multiple GPUs | Run DDP on 1, 2, 4, 8 GPUs (or CPU processes), measure scaling, and survive a killed worker |

```mermaid
flowchart TB
  DATA[(Sharded dataset)] --> S0 & S1 & S2 & S3
  subgraph JOB["One training job, 4 GPUs, data parallel"]
    S0["Rank 0<br/>full model copy<br/>batch slice 0"]
    S1["Rank 1<br/>full model copy<br/>batch slice 1"]
    S2["Rank 2<br/>full model copy<br/>batch slice 2"]
    S3["Rank 3<br/>full model copy<br/>batch slice 3"]
  end
  S0 & S1 & S2 & S3 --> AR["All-reduce gradients<br/>NCCL over NVLink / InfiniBand"]
  AR --> UPD["Each rank applies the same update<br/>so all copies stay identical"]
  UPD -->|next step| S0 & S1 & S2 & S3
  UPD -->|every N steps| CK[(Checkpoint)]
  CTRL["Launcher: torchrun / Slurm / Kubernetes<br/>restarts the job if a rank dies"] -.-> JOB
```

**How to read it:** each GPU (a **rank**) holds a full copy of the model and processes a different slice
of the batch. After the backward pass, an **all-reduce** averages the gradients across ranks, so every rank
applies the same update and the copies stay identical. Checkpoints are written periodically. A launcher
watches the processes and restarts the job from the last checkpoint if one dies. This is **data
parallelism**, the starting point for everything in this section.

**Terms in this diagram.**
- **Sharded dataset**: the data split into many files, so each rank reads a different part.
- **NCCL** (pronounced "nickel"): the NVIDIA Collective Communications Library. It runs the all-reduce, choosing
  the fastest path: **NVLink** between GPUs in one server, **InfiniBand** between servers (Section 7).
- **Launcher: torchrun / Slurm / Kubernetes**: what starts and watches the processes. **torchrun** is PyTorch's
  launcher (Lecture 52). **Slurm** is the job scheduler used on most HPC and research clusters. On
  **Kubernetes**, operators such as the Kubeflow training operator or JobSet play this role (Section 11).

---

## Lecture 50 — Why distributed training is needed

**Why it matters.** Before you split a job across GPUs, you should be able to prove it doesn't fit, or
doesn't finish in time, on one. Distribution adds cost, complexity, and failure modes, so the reason
must be clear and quantified.

**In plain words.** One person can paint a room in a day. Painting a skyscraper alone would take a
lifetime, and some walls are too tall to reach without scaffolding. You need a crew (many GPUs working in
parallel), and for the tallest walls you need people on different floors working on parts of the same wall
(model parallelism).

**Architecture: the two walls you hit.**

```mermaid
flowchart LR
  M["Model + data"] --> Q1{"Do weights, gradients,<br/>optimizer states, activations<br/>fit in one GPU?"}
  Q1 -->|no| MEM["Memory wall<br/>shard states: FSDP / ZeRO,<br/>or split the model: TP, PP"]
  Q1 -->|yes| Q2{"Does training finish<br/>in an acceptable time<br/>on one GPU?"}
  Q2 -->|no| TIME["Compute wall<br/>data parallelism:<br/>more GPUs, bigger global batch"]
  Q2 -->|yes| ONE["Stay on one GPU.<br/>Simplest and cheapest"]
```

**How to read it:** the first question is about memory, and the answer is sharding or model
parallelism. The second is about time, and the answer is data parallelism. Many jobs hit both walls.
If neither applies, a single GPU is the right answer.

**Terms in this diagram** (Lecture 51 explains each with a picture):
- **Optimizer states**: extra numbers the optimizer keeps per weight. Adam keeps two, a running average of
  gradients and of their squares, so they often take more memory than the weights.
- **Activations**: the intermediate outputs of every layer, saved during the forward pass for the backward pass.
- **FSDP / ZeRO**: **FSDP** (PyTorch Fully Sharded Data Parallel) and **ZeRO** (DeepSpeed's Zero Redundancy
  Optimizer) split the weights, gradients, and optimizer states across GPUs instead of copying them.
- **TP** (tensor parallelism) splits each weight matrix across GPUs. **PP** (pipeline parallelism) puts different
  layers on different GPUs.
- **Global batch**: the total number of examples processed in one optimizer step, across all GPUs.

**Core ideas.**
- **Training compute ≈ 6 × parameters × tokens** for transformers (2 for the forward pass, 4 for the
  backward pass).
- **Memory ≈ 16 bytes per parameter** for mixed-precision Adam, plus activations (Section 7).
- Time = compute ÷ (number of GPUs × peak FLOPS × MFU). MFU is typically 35–55% for well-tuned LLM
  training.

| Model and data | Compute (6ND) | 1 × H100 at 40% MFU (~396 TFLOPS) | 1,024 × H100 |
|---|---|---|---|
| ResNet-50, 90 epochs of ImageNet | ~1.4×10¹⁸ (≈ 4 GFLOPs × 3 × 1.28M × 90) | ~1 hour of math (in practice many hours, limited by data loading and real MFU) | Minutes |
| 1B model, 20B tokens | 1.2×10²⁰ | ~3.5 days | ~5 minutes |
| 8B model, 15T tokens | 7.2×10²³ | ~58 years | ~21 days |
| 70B model, 2T tokens | 8.4×10²³ | ~67 years | ~24 days |

**Example: the memory wall for 70B.** Model states are 70B × 16 bytes ≈ 1.1 TB, which is 14 H100s' worth of
memory before a single activation. No amount of data parallelism helps, because each replica would still
need 1.1 TB. The states must be sharded (FSDP/ZeRO-3 across at least 16–32 GPUs) or the model split
(tensor and pipeline parallelism). Only then does data parallelism add speed.

**Senior / FAANG best practice.** Start every training design with the 6ND compute estimate and the
16-bytes-per-parameter memory estimate, then state the target wall-clock time and budget. Use the
smallest scale that meets the deadline: scaling efficiency drops as GPU count grows, and so does
reliability. Big labs run small-scale "proxy" experiments to fix hyperparameters before the large run.

---

## Lecture 51 — Data parallelism vs model parallelism

**Why it matters.** Picking the wrong parallelism strategy can waste half a cluster. The choice
depends on model size, GPU memory, and the interconnect, and real large jobs combine several kinds.

**In plain words.** Imagine translating a huge book. **Data parallelism:** every translator has the full
dictionary and works on different chapters. Afterwards they agree on any new vocabulary. **Tensor
parallelism:** the dictionary is too heavy to lift, so four translators each hold a quarter of it and work
on every sentence together, constantly passing notes. **Pipeline parallelism:** an assembly line, where
one translator does the first pass, hands the page on for the second pass, and so on.

**Architecture: the main strategies.**

```mermaid
flowchart TB
  subgraph DP["Data parallel (DDP)"]
    D1["GPU 0: full model, batch A"]
    D2["GPU 1: full model, batch B"]
    D1 <-->|all-reduce gradients| D2
  end
  subgraph FSDP["Sharded data parallel (FSDP / ZeRO-3)"]
    F1["GPU 0: 1/2 of params, grads, optimizer"]
    F2["GPU 1: other 1/2"]
    F1 <-->|"all-gather params per layer,<br/>reduce-scatter grads"| F2
  end
  subgraph TP["Tensor parallel"]
    T1["GPU 0: left half of every weight matrix"]
    T2["GPU 1: right half"]
    T1 <-->|"all-reduce activations,<br/>every layer, NVLink only"| T2
  end
  subgraph PP["Pipeline parallel"]
    P1["GPU 0: layers 1 to 40"] -->|activations| P2["GPU 1: layers 41 to 80"]
    P2 -->|gradients| P1
  end
```

**How to read it:** DDP copies everything and syncs gradients once per step. FSDP shards the copies, and
gathers each layer's weights just in time. Tensor parallelism splits each matrix, so GPUs exchange
activations inside every layer, which needs NVLink. Pipeline parallelism splits by layers, so only the
activations at stage boundaries move, but stages wait for each other (the **bubble**).

The communication names in the diagram are standard **collective operations**, where every GPU takes part.
**All-reduce** sums (or averages) a tensor across all GPUs and gives everyone the result. **All-gather** collects
every GPU's piece so each GPU gets the full tensor. **Reduce-scatter** sums across GPUs but leaves each GPU with
only its own slice of the result. Lecture 54 shows how they run.

**Core ideas.**

| Strategy | Splits | Communication | Memory per GPU | Use when |
|---|---|---|---|---|
| DDP | Data | All-reduce gradients once per step | Full model + states | Model fits on one GPU. The default |
| FSDP / ZeRO-3 | Data + model states | All-gather params + reduce-scatter grads, per layer | States ÷ N | Model states don't fit, up to ~100B on fast networks |
| Tensor parallel (TP) | Each layer's matrices | All-reduce activations inside every layer | Weights ÷ TP | Very large layers. Keep TP ≤ 8, inside one NVLink node |
| Pipeline parallel (PP) | Layers into stages | Point-to-point activations between stages | Layers ÷ PP | Very deep models across nodes. Needs many micro-batches |
| Context / sequence parallel | The sequence | Exchange attention blocks | Activations ÷ N | Very long contexts (64k+) |
| Expert parallel (MoE) | Experts across GPUs | All-to-all token routing | Experts ÷ N | Mixture-of-experts models |

- **3D parallelism** combines them: TP inside a node, PP across a few nodes, and DP (often FSDP) across
  the rest. GPUs = TP × PP × DP.
- **ZeRO stages:** stage 1 shards the optimizer states, stage 2 also shards the gradients, and stage 3 also
  shards the parameters. PyTorch FSDP corresponds to stage 3, or stage 2 with `SHARD_GRAD_OP`.
- **Pipeline bubble** with 1F1B scheduling ≈ (PP − 1) ÷ (micro-batches + PP − 1). With 4 stages and
  16 micro-batches, 3 ÷ 19 ≈ 16% of the time is idle. Use more micro-batches or interleaved stages.

**Example: one layout for a 70B model on 2,048 H100s.** TP = 8 inside each node over NVLink, so each
GPU holds 1/8 of every layer. PP = 4 across 4 nodes, so each stage has 20 of the 80 layers. That makes one
model replica 32 GPUs. DP = 2,048 ÷ 32 = **64 replicas**. With a 4M-token global batch at sequence length
4,096 (1,024 sequences) and micro-batch 1, each replica handles 16 micro-batches per step, which is
exactly the bubble case above.

**Senior / FAANG best practice.** Prefer the simplest strategy that fits: DDP, then FSDP, then add TP
and PP only when needed. Map parallelism to the network: TP on NVLink, PP and DP over InfiniBand. Use
proven frameworks (PyTorch FSDP2, Megatron-Core, DeepSpeed, TorchTitan) instead of custom parallelism,
and tune layouts with short benchmark runs measuring MFU before committing the cluster.

---

## Lecture 52 — PyTorch distributed training

**Why it matters.** PyTorch is the default framework for training. Getting launch, ranks, data
sharding, and checkpointing right is the difference between linear speedup and a job that hangs, or
quietly trains every GPU on the same data.

**In plain words.** `torchrun` is a coordinator that starts one worker per GPU, gives each a name tag
(its rank) and the address of a meeting point, and restarts them if one collapses. DDP is the rule that,
after each step, everyone shares their notes and agrees on one average before moving on.

**Architecture: a two-node `torchrun` job.**

```mermaid
flowchart TB
  subgraph N0["Node 0: torchrun --nnodes 2 --nproc-per-node 8"]
    A0[agent] --> R0["rank 0, local_rank 0"] & R7["... rank 7"]
  end
  subgraph N1["Node 1: same command"]
    A1[agent] --> R8["rank 8, local_rank 0"] & R15["... rank 15"]
  end
  A0 <-->|"rendezvous:<br/>agree on world size, ranks"| RDZV[(c10d rendezvous<br/>host:29400)]
  A1 <--> RDZV
  R0 & R7 & R8 & R15 <-->|NCCL process group| NCCL["All-reduce over<br/>NVLink + InfiniBand"]
```

**How to read it:** the same command runs on every node. Each node's agent starts 8 worker processes, and
the agents meet at a **rendezvous** endpoint to agree on the world size and which rank is which. Each
worker sets its GPU from `LOCAL_RANK`, joins the NCCL process group, and from then on gradient syncs go
GPU to GPU. If a worker dies, the agents tear down and restart the whole group, up to `--max-restarts`.

In the diagram, `--nnodes 2 --nproc-per-node 8` means 2 machines with 8 processes (one per GPU) each, so the
**world size** (total number of processes) is 16. **rank** is a process's global number from 0 to 15, and
**local_rank** its number within its own machine, from 0 to 7. **c10d** is PyTorch's built-in communication
library, whose rendezvous service listens on `host:29400`. The **process group** is the set of ranks that
communicate together.

**Core ideas: a minimal DDP training script.**

```python
import os, torch, torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler

dist.init_process_group("nccl")                      # reads RANK, WORLD_SIZE, MASTER_ADDR from torchrun
local_rank = int(os.environ["LOCAL_RANK"])
torch.cuda.set_device(local_rank)

model = build_model().cuda()
model = DDP(model, device_ids=[local_rank])          # syncs gradients during backward, in buckets
sampler = DistributedSampler(dataset, shuffle=True)  # each rank gets a different 1/world_size slice
loader = DataLoader(dataset, batch_size=micro_batch, sampler=sampler, num_workers=8, pin_memory=True)
opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.9)

for epoch in range(start_epoch, epochs):
    sampler.set_epoch(epoch)                         # different shuffle each epoch
    for x, y in loader:
        x, y = x.cuda(non_blocking=True), y.cuda(non_blocking=True)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            loss = loss_fn(model(x), y)
        opt.zero_grad(set_to_none=True)
        loss.backward()                              # all-reduce overlaps with the backward pass
        opt.step()
    if dist.get_rank() == 0:
        torch.save({"model": model.module.state_dict(), "opt": opt.state_dict(), "epoch": epoch}, "ckpt.pt")
dist.destroy_process_group()
```

```bash
# one node, 8 GPUs
torchrun --nproc-per-node 8 train.py
# two nodes: run on each node (same rendezvous endpoint), restart up to 3 times on failure
torchrun --nnodes 2 --nproc-per-node 8 --rdzv-backend c10d --rdzv-endpoint node0:29400 \
         --rdzv-id resnet-run-17 --max-restarts 3 train.py
```

| Variable | Meaning |
|---|---|
| `WORLD_SIZE` | Total processes (GPUs) in the job |
| `RANK` | This process's global ID, 0 … world size − 1 |
| `LOCAL_RANK` | ID within the node. Selects the GPU |
| `MASTER_ADDR` / rendezvous endpoint | Where the processes meet |

- **FSDP2** (`torch.distributed.fsdp.fully_shard`) shards each module's parameters. Wrap each transformer
  block, then the root model. The training loop stays the same.
- Gradient accumulation with DDP: wrap non-final micro-steps in `model.no_sync()` to skip redundant
  all-reduces.
- Use `gloo` instead of `nccl` to practise on CPUs. The lab does this.

**Example: the job that trained 8 copies of the same thing.** A team moved from 1 to 8 GPUs and got no
faster convergence per epoch. They had used a normal `DataLoader` without `DistributedSampler`, so
every rank processed the full dataset in the same order. The epochs took 8× the GPU time to learn what
one GPU learned. Adding the sampler (and `set_epoch`) gave a 7.3× speedup.

**Senior / FAANG best practice.** Write rank-aware code from day one: only rank 0 logs and writes
summaries, and every rank writes its own shard of a distributed checkpoint (`torch.distributed.checkpoint`).
Set `NCCL_DEBUG=WARN` in production and `INFO` when debugging, plus explicit NCCL timeouts, so a hang
fails fast instead of burning a cluster for hours. Launch through a scheduler (Slurm, Kubeflow
Trainer, or Ray) with gang scheduling, so a job gets all its GPUs or none (Section 11).

---

## Lecture 53 — TensorFlow multi-GPU training

**Why it matters.** Many production systems, especially older recommendation and ads models and
TPU-based teams, still train with TensorFlow and Keras. The concepts are the same as PyTorch, but the
APIs and failure modes differ.

**In plain words.** TensorFlow's `tf.distribute` strategies are recipe cards. You pick the card
("mirror across my GPUs", "mirror across machines", "use TPUs"), and Keras follows it without you
rewriting the training loop.

**Architecture: the strategy picks the topology.**

```mermaid
flowchart TB
  CODE["Keras model built inside<br/>strategy.scope()"] --> STRAT{"Which strategy?"}
  STRAT -->|one machine, many GPUs| MIR["MirroredStrategy<br/>NCCL all-reduce"]
  STRAT -->|many machines| MW["MultiWorkerMirroredStrategy<br/>TF_CONFIG lists workers"]
  STRAT -->|Cloud TPU pod| TPU["TPUStrategy"]
  STRAT -->|huge sparse embeddings| PS["ParameterServerStrategy<br/>async updates"]
  MIR & MW & TPU & PS --> FIT["model.fit(dataset)<br/>global batch split across replicas"]
```

**How to read it:** the model and optimizer are created inside the strategy's scope, so their variables
are placed correctly: mirrored on every replica, or on parameter servers. `model.fit` then splits each
global batch across the replicas. The code stays the same, and only the strategy line changes.

**Terms in this diagram.**
- **Keras, strategy.scope()**: Keras is TensorFlow's high-level model API. A **distribution strategy** decides how
  training is spread across devices, and code inside `strategy.scope()` creates variables the strategy's way.
- **MirroredStrategy**: one machine, one model copy (**replica**) per GPU, gradients combined with NCCL all-reduce.
- **MultiWorkerMirroredStrategy, TF_CONFIG**: the same across several machines. **TF_CONFIG** is an environment
  variable on each machine listing all workers' addresses and this machine's role.
- **TPUStrategy, Cloud TPU pod**: training on Google TPUs. A **pod** is a large group of TPU chips connected by a
  dedicated high-speed network.
- **ParameterServerStrategy, async updates**: some machines (**parameter servers**) hold the weights, and workers
  send updates without waiting for each other (**asynchronous**). It suits models with huge sparse embedding
  tables, as in recommenders.

**Core ideas.**

```python
import tensorflow as tf
strategy = tf.distribute.MirroredStrategy()               # all local GPUs
print("replicas:", strategy.num_replicas_in_sync)
GLOBAL_BATCH = 64 * strategy.num_replicas_in_sync          # per-replica batch x replicas

with strategy.scope():                                     # variables created here are mirrored
    model = tf.keras.applications.ResNet50(weights=None, classes=10, input_shape=(32, 32, 3))
    model.compile(optimizer=tf.keras.optimizers.SGD(0.1 * GLOBAL_BATCH / 256, momentum=0.9),
                  loss="sparse_categorical_crossentropy", metrics=["accuracy"])

ds = (tf.data.Dataset.from_tensor_slices((x_train, y_train))
        .shuffle(50_000).batch(GLOBAL_BATCH).prefetch(tf.data.AUTOTUNE))
model.fit(ds, epochs=30, callbacks=[tf.keras.callbacks.BackupAndRestore("/ckpt/backup")])
```

For multiple machines, every worker runs the same script with a different `TF_CONFIG`:

```bash
export TF_CONFIG='{"cluster": {"worker": ["w0:12345", "w1:12345"]}, "task": {"type": "worker", "index": 0}}'
```

| Strategy | Sync | Typical use |
|---|---|---|
| `MirroredStrategy` | Synchronous all-reduce | One multi-GPU machine |
| `MultiWorkerMirroredStrategy` | Synchronous, collective ops across hosts | Multi-node GPU clusters |
| `TPUStrategy` | Synchronous on the TPU interconnect | Google Cloud TPUs |
| `ParameterServerStrategy` | Asynchronous | Very large embedding tables, recommendation models |

- The batch you pass to `fit` is the **global** batch. TensorFlow divides it by the number of replicas.
  In PyTorch you set the per-GPU batch. Mixing these up silently changes the effective learning rate.
- `BackupAndRestore` makes `fit` resume from the last epoch after a worker restarts.
- Input pipelines (`tf.data` with `prefetch`, `interleave`, and `cache`) matter as much as the strategy.

**Example: a learning-rate mix-up during migration.** A team ported a PyTorch recipe (64 per GPU × 8 GPUs,
lr 0.2) to TensorFlow and passed `batch(64)` to `fit`. That became a **global** batch of 64, or 8 per GPU,
with the same learning rate of 0.2. Training diverged in the first epoch. Setting the global batch to
512 restored the recipe.

**Senior / FAANG best practice.** Pin the TensorFlow, CUDA, and cuDNN versions together (TensorFlow is
stricter about this than PyTorch), and test the multi-worker path in CI on two small workers, not just
on one machine. For new large-model work, most big-tech teams standardize on PyTorch or JAX. Keep
TensorFlow for existing systems where the migration cost isn't justified.

---

## Lecture 54 — Horovod and all-reduce explained

**Why it matters.** All-reduce is the heartbeat of data-parallel training. Understanding its cost
tells you whether adding GPUs will help, and what network you need. Horovod was the tool that brought
ring all-reduce into mainstream deep learning, and you will still find it in many codebases.

**In plain words.** Twelve people around a table each have a pile of numbers, and everyone needs the
total of every pile. Sending everything to one person (a parameter server) creates a traffic jam at
that person. Instead, everyone passes a portion to their neighbor, adds what they received, and passes
it on. After two laps around the table, everyone has every total, and nobody was overloaded.

**Architecture: ring all-reduce on 4 GPUs.**

```mermaid
sequenceDiagram
  participant G0 as GPU 0
  participant G1 as GPU 1
  participant G2 as GPU 2
  participant G3 as GPU 3
  Note over G0,G3: Each GPU splits its gradients into 4 chunks
  Note over G0,G3: Phase 1, reduce-scatter, 3 steps
  G0->>G1: chunk, partial sum
  G1->>G2: chunk, partial sum
  G2->>G3: chunk, partial sum
  G3->>G0: chunk, partial sum
  Note over G0,G3: After 3 steps each GPU owns one fully summed chunk
  Note over G0,G3: Phase 2, all-gather, 3 steps
  G0->>G1: finished chunk
  G1->>G2: finished chunk
  G2->>G3: finished chunk
  G3->>G0: finished chunk
  Note over G0,G3: After 3 more steps every GPU has all summed chunks
```

**How to read it:** in the first phase (reduce-scatter), each GPU sends one chunk to its neighbor and adds
the chunk it receives. After N − 1 steps, each GPU holds the complete sum for one chunk. In the second phase
(all-gather), the finished chunks travel around the ring for another N − 1 steps until everyone has all of
them. Every link is busy at once, and no single GPU is a bottleneck.

**Core ideas.**
- **Cost:** each GPU sends and receives 2 × (N − 1)/N × S bytes for gradients of size S. That is almost
  2S, *independent of N*, which is why rings scale well. Latency grows with N, so NCCL also uses **tree**
  algorithms for large N and small messages.
- **Parameter server vs all-reduce:** a parameter server receives N × S bytes and becomes a bottleneck.
  It is still used for huge sparse embeddings with asynchronous updates.
- **Overlap:** DDP and Horovod bucket gradients (~25 MB) and start all-reducing the last layers while the
  backward pass is still computing earlier ones, hiding most of the communication.

| | Horovod | PyTorch DDP |
|---|---|---|
| Frameworks | TensorFlow, Keras, PyTorch, MXNet | PyTorch |
| Launch | `horovodrun -np 16 -H host1:8,host2:8 python train.py` (MPI or Gloo) | `torchrun` |
| API | `hvd.init()`, `hvd.DistributedOptimizer(opt)`, `hvd.broadcast_parameters(...)` | `DDP(model)` |
| Status today | Mature, less active development | The default for PyTorch |

```python
import horovod.torch as hvd
hvd.init(); torch.cuda.set_device(hvd.local_rank())
opt = hvd.DistributedOptimizer(torch.optim.SGD(model.parameters(), lr=0.1 * hvd.size()),
                               named_parameters=model.named_parameters())
hvd.broadcast_parameters(model.state_dict(), root_rank=0)   # everyone starts from rank 0's weights
```

**Example: how much faster can 64 GPUs go?** ResNet-50 has 25.6M parameters, so ~51 MB of fp16
gradients. A ring on 64 GPUs moves 2 × 63/64 × 51 MB ≈ 100 MB per GPU per step. At 25 GB/s of effective
InfiniBand bandwidth that's ~4 ms, against a ~100 ms compute step, so scaling efficiency can exceed 90%. A
7B model's 14 GB of gradients is ~1.1 s per step on the same network, which is why large models use FSDP's
overlapped, sharded communication and faster networks.

**Senior / FAANG best practice.** Compute the all-reduce time for every design (bytes ÷ measured bus
bandwidth from `nccl-tests`), and compare it with the backward-pass time. If communication can't be hidden,
change the plan: shard, compress (bf16 gradients), accumulate gradients, or get a faster network. Treat
measured bus bandwidth per link as a monitored fleet metric.

---

## Lecture 55 — Fault tolerance in distributed training

**Why it matters.** The more GPUs a job uses, the more often one of them fails. A 1,000-GPU job will be
interrupted several times a week. Without checkpointing and automatic restart, large training runs
can't finish at all.

**In plain words.** A long relay race through a storm will lose a runner sometimes. You place
checkpoints along the route, so a new runner starts from the last checkpoint, not from the start line.
Checkpoints too far apart lose a lot of distance on each failure. Checkpoints too close together waste
time stopping.

**Architecture: detect, restart, resume.**

```mermaid
flowchart LR
  RUN[Training at step N] --> FAIL{"Failure: GPU Xid, ECC,<br/>NCCL timeout, node lost"}
  FAIL --> DET["Detect: health checks,<br/>NCCL timeout, missing heartbeat"]
  DET --> EVICT["Cordon bad node,<br/>swap in a hot spare"]
  EVICT --> RESTART["Launcher restarts all ranks<br/>torchrun --max-restarts, Slurm, JobSet"]
  RESTART --> LOAD["Load latest good checkpoint<br/>model + optimizer + data position + RNG"]
  LOAD --> RUN
  RUN -->|"every K steps, async"| CK[(Sharded checkpoint<br/>object storage)]
```

**How to read it:** when any rank fails, the whole synchronous job stops. A health system detects the
failure, removes the bad node, and brings in a spare. The launcher then restarts every rank, and they
reload the latest checkpoint. That checkpoint must include optimizer states, the data-loader position,
and random-number generator states, not just the weights, so training continues exactly where it was.

**Terms in this diagram.**
- **GPU Xid, ECC**: **Xid** errors are numbered fault codes the NVIDIA driver writes to the kernel log. **ECC**
  (error-correcting code) errors are memory bit flips the GPU detected. Uncorrectable ECC errors mean the GPU must
  be reset or replaced.
- **NCCL timeout**: a rank waited too long (often 10–30 minutes by default) for others in a collective, usually
  because one rank crashed or hung.
- **Missing heartbeat**: a process or node stopped sending its regular "I'm alive" signal.
- **Cordon, hot spare**: **cordoning** marks a node so nothing new is scheduled on it. A **hot spare** is an idle,
  already-healthy node kept ready to replace a failed one immediately.
- **JobSet**: a Kubernetes API for running a group of related Jobs (such as all the workers of a training run)
  that are restarted together.
- **RNG**: random-number generator. Saving its state makes data shuffling and dropout continue identically after a
  restart.
- **Sharded checkpoint**: each rank saves its own piece in parallel, which is much faster than one rank writing
  everything (Section 31).

**Core ideas.**
- **Failures are routine at scale.** Meta reported 419 unexpected interruptions in 54 days while training
  Llama 3 405B on 16,384 H100s, about one every 3 hours. Most came from hardware, with GPUs and HBM the largest
  category.
- **Checkpoint interval (Young–Daly):** interval ≈ √(2 × checkpoint cost × mean time between failures).
  If a checkpoint takes 2 minutes and the job fails every 3 hours: √(2 × 2 × 180) ≈ **27 minutes**.
- **Async, sharded checkpoints** (each rank writes its own piece in the background, with
  `torch.distributed.checkpoint` async save) cut the checkpoint cost from minutes to seconds of stall.
- **What goes in a checkpoint:** model weights, optimizer states, learning-rate scheduler, step count,
  data-loader or sampler position, RNG states, and the config with code version.
- **Elastic training** lets a job continue with fewer nodes (`torchrun --nnodes 2:4`), adjusting the data
  shards. Most large LLM runs instead keep a fixed size with hot spares, so the global batch stays the same.

| Failure | Detection | Response |
|---|---|---|
| GPU Xid or ECC error | `dmesg`, DCGM health | Cordon the node, restart from checkpoint on a spare |
| NCCL hang (bad link, straggler) | `NCCL_TIMEOUT` or watchdog, step time alarm | Fail fast, restart, flag the slow link |
| Spot or preemption | Cloud notice (~30–120 s) | Emergency checkpoint, then resume elsewhere |
| Loss spike or NaN | Loss and gradient-norm monitors | Roll back to an earlier checkpoint, skip the bad data batch, lower the LR |
| Storage outage during save | Write errors, checksum mismatch | Keep the last N checkpoints, and verify before deleting older ones |

**Example: what restarts really cost.** A 512-GPU job checkpointed every 4 hours, taking 10 minutes
each time, and failed about every 6 hours. Each failure lost ~2 hours of work on average plus ~15 minutes
to restart, and checkpoints stalled another 4% of the time, so ~40% of GPU time was wasted. Switching to
async sharded checkpoints (30 s of stall) every 30 minutes, plus a hot-spare node pool (5-minute
restarts), cut the waste to ~7%: about 15 minutes of lost work plus 5 minutes of restart per 6 hours, plus
under 2% stall. That paid for the spares many times over.

**Senior / FAANG best practice.** Measure **goodput**: the fraction of GPU time that produced training
progress that was kept. Big labs track it as a first-class metric. Automate the full loop (detect,
cordon, replace, restart, resume) so no human is needed at 3 a.m. Regularly test resuming from checkpoints
in staging, because an untested checkpoint is a hope, not a backup.

---

## Lecture 56 — Lab: train ResNet across multiple GPUs

**Goal:** train ResNet-18 on CIFAR-10 with PyTorch DDP on 1, 2, 4, and 8 GPUs (or 2–4 CPU processes with
`gloo` if you have no GPUs), measure the scaling efficiency, then kill a worker and watch the job
resume from its checkpoint.

**Cost:** an 8-GPU node such as AWS `g5.48xlarge` (8 × A10G) costs about $16/hour on demand, and this lab
needs ~45 minutes. A 4 × T4 or 4 × L4 node is cheaper. The CPU version is free.

**What you're building.**

```mermaid
flowchart LR
  TR["torchrun --nproc-per-node N<br/>--max-restarts 3"] --> R0["rank 0"] & R1["rank 1"] & RN["rank N-1"]
  DS[(CIFAR-10<br/>DistributedSampler)] --> R0 & R1 & RN
  R0 & R1 & RN <-->|"all-reduce, NCCL or gloo"| AR[Gradient average]
  R0 -->|every epoch| CK[(ckpt.pt)]
  CK -->|on restart| R0 & R1 & RN
  R0 --> LOG["images/s, epoch time,<br/>accuracy"]
```

**How to read it:** `torchrun` starts N ranks and restarts them up to 3 times if one fails. Each rank reads its own
part of **CIFAR-10** (a classic dataset of 60,000 small 32×32 images in 10 classes) through a
**DistributedSampler**, PyTorch's helper that gives every rank a different, non-overlapping slice of the dataset.
Gradients are averaged with NCCL on GPUs, or with **gloo** (PyTorch's CPU communication backend) if you have no
GPUs. Rank 0 alone writes the checkpoint and the log, so files aren't written N times.

**In plain words.** You run the same training script with more and more workers, time each run, and
compute how close you got to perfect speedup. Then you pull the plug on one worker, to see the
fault-tolerance loop from Lecture 55 actually work.

### Step 1 — The script (`ddp_resnet.py`)

```python
import os, time, torch, torch.distributed as dist, torchvision, torchvision.transforms as T
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler

backend = "nccl" if torch.cuda.is_available() else "gloo"
dist.init_process_group(backend)
rank, world, local = dist.get_rank(), dist.get_world_size(), int(os.environ["LOCAL_RANK"])
dev = torch.device(f"cuda:{local}" if backend == "nccl" else "cpu")
if backend == "nccl": torch.cuda.set_device(dev)

tf = T.Compose([T.RandomCrop(32, padding=4), T.RandomHorizontalFlip(), T.ToTensor()])
if rank == 0: torchvision.datasets.CIFAR10("data", download=True)
dist.barrier()                                              # only rank 0 downloads
ds = torchvision.datasets.CIFAR10("data", train=True, transform=tf)
sampler = DistributedSampler(ds)
MICRO = int(os.environ.get("MICRO", 128))
dl = DataLoader(ds, batch_size=MICRO, sampler=sampler, num_workers=4, pin_memory=True, drop_last=True)

model = DDP(torchvision.models.resnet18(num_classes=10).to(dev), device_ids=[local] if backend == "nccl" else None)
lr = 0.1 * MICRO * world / 256                              # linear scaling rule
opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=5e-4)
start = 0
if os.path.exists("ckpt.pt"):                               # resume after a restart
    ck = torch.load("ckpt.pt", map_location=dev)
    model.module.load_state_dict(ck["model"]); opt.load_state_dict(ck["opt"]); start = ck["epoch"] + 1

for epoch in range(start, int(os.environ.get("EPOCHS", 5))):
    sampler.set_epoch(epoch); t = time.time(); model.train()
    for x, y in dl:
        x, y = x.to(dev, non_blocking=True), y.to(dev, non_blocking=True)
        loss = torch.nn.functional.cross_entropy(model(x), y)
        opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
    if backend == "nccl": torch.cuda.synchronize()
    if rank == 0:
        ips = len(dl) * MICRO * world / (time.time() - t)
        print(f"epoch {epoch} world={world} global_batch={MICRO * world} lr={lr:.3f} "
              f"loss={loss.item():.3f} {ips:,.0f} img/s", flush=True)
        torch.save({"model": model.module.state_dict(), "opt": opt.state_dict(), "epoch": epoch}, "ckpt.pt")
    dist.barrier()
dist.destroy_process_group()
```

### Step 2 — Plan the batch, then run at each scale

```bash
python3 exercises/s08_global_batch_plan.py --gpus 8 --micro-batch 128 --global-batch 1024 \
    --base-lr 0.1 --base-batch 256 --optimizer sgd --dataset 50000
for n in 1 2 4 8; do rm -f ckpt.pt; EPOCHS=2 torchrun --nproc-per-node $n ddp_resnet.py; done
# no GPU? use CPU processes:
for n in 1 2 4; do rm -f ckpt.pt; MICRO=32 EPOCHS=1 torchrun --nproc-per-node $n ddp_resnet.py; done
```

Record the images/s from the second epoch (the first includes warm-up) in a table:

| GPUs | Images/s | Speedup vs 1 GPU | Scaling efficiency = speedup ÷ GPUs |
|---|---|---|---|
| 1 | | 1.0 | 100% |
| 2 | | | |
| 4 | | | |
| 8 | | | |

### Step 3 — Kill a worker and watch it recover

```bash
rm -f ckpt.pt
EPOCHS=6 torchrun --nproc-per-node 4 --max-restarts 3 ddp_resnet.py &
sleep 90; pkill -f -n "ddp_resnet.py"         # kill the newest worker process mid-epoch
wait
```

`torchrun` logs that a worker failed, restarts all ranks, and the script resumes from the last
saved epoch.

### Step 4 — Look at the communication

Rerun with `NCCL_DEBUG=INFO` and find the lines that show which transport NCCL chose (`P2P/NVLink`,
`SHM`, or `NET`). Run `nvidia-smi topo -m` and match them to the topology.

**Expected results:** on an NVLink node, scaling efficiency is ~90% or more at 8 GPUs. On PCIe-only
GPUs it is lower (often 70–85%), because ResNet-18 is small and its step time is short. Accuracy after the
same number of epochs is similar at each scale, because the linear LR rule kept the update size in
proportion. In Step 3, the job restarts once and continues from the last checkpointed epoch, instead of
epoch 0. On CPU, the scaling is weaker, but the restart behaves the same way.

---

## Assessment — Plan a distributed global batch size

**Task.** For each case, give the data-parallel size, the micro-batch, the gradient accumulation steps,
the learning rate, and anything that would make you change the plan.
1. ResNet-50 on ImageNet: 8 GPUs, at most 128 images per GPU, a recipe of lr 0.1 at batch 256 (SGD).
2. The same model on 32 GPUs: (a) keep the global batch, or (b) keep the per-GPU batch.
3. A 70B LLM on 2,048 GPUs with TP 8 and PP 4, a 4M-token global batch at sequence length 4,096, micro-batch 1.
4. 48 GPUs, micro-batch 8, a requested global batch of 1,000.

**Model answer.** Run [`exercises/s08_global_batch_plan.py`](../exercises/s08_global_batch_plan.py) with
no arguments to reproduce these numbers.

| Case | DP | Micro × accumulation | Global batch | LR | Notes |
|---|---|---|---|---|---|
| 1 | 8 | 128 × 1 | 1,024 | 0.4 (linear) | 1,252 steps per epoch. Warm up over ~5 epochs |
| 2a strong scaling | 32 | 32 × 1 | 1,024 | 0.4 | Same convergence. Each GPU has less work, so communication is a bigger share |
| 2b weak scaling | 32 | 128 × 1 | 4,096 | 1.6 (linear) | 313 steps per epoch. Needs warm-up, and verify accuracy (large-batch regime) |
| 3 | 64 (= 2,048 ÷ 8 ÷ 4) | 1 × 16 | 1,024 sequences = 4.19M tokens | Keep the recipe's LR. Adam scaling is not linear | Pipeline bubble 3/19 ≈ 16%: use interleaved stages or more micro-batches |
| 4 | 48 | 8 × ? | 1,000 is impossible | — | 384 per micro-step does not divide 1,000. Use 768 or 1,152, or change the GPU count |

**Rules behind the answer:**
- global batch = micro-batch × accumulation × DP;
- DP = GPUs ÷ (TP × PP);
- SGD: scale the LR linearly with the global batch, with warm-up. Adam-family: start from the square-root
  rule or the published recipe, then tune;
- above roughly 8–16k images per batch for ResNet-50, linear scaling breaks down, and you need LARS or LAMB
  optimizers and retuning;
- the micro-batch comes from memory (Section 7). The global batch comes from convergence, not from the
  number of GPUs you happen to have.

---

## FAANG deep-dive notes

**How big tech does it.** Large training is a platform: gang-scheduled jobs on dedicated clusters with
rail-optimized InfiniBand or RoCE, standard parallelism frameworks (Megatron-Core, FSDP2, DeepSpeed, JAX
pjit and shardings), async sharded checkpoints to object storage, automated detect-cordon-replace-restart
loops with hot spares, and dashboards for MFU, goodput, and step time per rank. Hyperparameters and
parallel layouts are chosen at small scale and validated with short runs before the full launch.

**Staff review questions.**
- What is the expected MFU and goodput, and how will we measure both from day one?
- What is the checkpoint interval, and how was it derived from the cluster's failure rate?
- What happens to the global batch, LR schedule, and data order if we lose nodes or add them mid-run?
- Which runs prove these hyperparameters work at this batch size?

**Interview question.** "Plan the training of a 70B model on 2,048 H100s."

**Typical system-design prompt:** *Plan the infrastructure and parallelism to pre-train a 70B-parameter
transformer on 2 trillion tokens using 2,048 H100s, finishing in under a month.*

**1. Clarify first:** What sequence length and global batch size does the recipe use? What is the cluster
network (InfiniBand NDR, rail-optimized)? What is the cluster's historical failure rate? What storage
bandwidth do checkpoints get? Is the GPU count fixed for the whole run?

**2. Back-of-envelope sizing:**
- Compute: 6 × 70×10⁹ × 2×10¹² = 8.4×10²³ FLOPs. At 40% MFU (396 TFLOPS per GPU) × 2,048 GPUs ≈
  8.1×10¹⁷ FLOPs/s → **~12 days** of pure compute. At 90% goodput, ~13 days.
- Memory: 70B × 16 bytes = 1.1 TB of states. TP 8 × PP 4 gives 32 GPUs per replica, ~35 GB of states per
  GPU before ZeRO-1 sharding across DP, leaving room for activations.
- Layout: TP 8 (NVLink) × PP 4 × DP 64. Global batch 4M tokens = 1,024 × 4,096 → micro-batch 1 ×
  16 accumulation. Bubble ~16%, so use interleaved 1F1B (virtual stages) to cut it roughly in half.
- Checkpoint: ~1.1 TB. At 50 GB/s aggregate to object storage, ~22 s, if written async and sharded. With
  failures every ~3 hours: √(2 × 0.5 × 180) ≈ 13 minutes. Checkpoint every ~15 minutes.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Sharding | FSDP / ZeRO-3 only | 3D (TP + PP + DP) | FSDP up to tens of billions on good networks. 3D for 70B+ at thousands of GPUs |
| TP size | 4 | 8 | The smallest that fits activations and memory, and never across nodes |
| Global batch | Smaller (better per-token efficiency) | Larger (more parallelism) | Stay below the critical batch size known from small-scale runs |
| Failure handling | Elastic (shrink and continue) | Fixed size + hot spares | Hot spares keep the batch and data order fixed. Elastic suits preemptible capacity |
| Checkpoint | Synchronous, to shared FS | Async sharded, to object storage | Async sharded. Keep the last N, and verify them |

**4. Follow-up questions with crisp answers:**
- *Why not just DDP?* A full replica of 1.1 TB of states can't fit on one GPU. DP alone doesn't
  reduce the memory per GPU.
- *Why keep TP inside a node?* TP does an all-reduce in every layer, on the critical path. It needs
  NVLink bandwidth.
- *What breaks if you double the GPU count?* With a fixed global batch, each replica's work halves, so the
  bubble and communication share grow and MFU falls. With a doubled batch, convergence per token may
  get worse.

**Debug this (common onsite question):** "A 4-node job hangs at the first all-reduce. Single-node runs work."
1. Rerun with `NCCL_DEBUG=INFO`. The logs show NCCL choosing the `docker0` or a management interface for
   bootstrap and `NET/Socket` instead of `NET/IB`.
2. Check the network: `ibstat` shows the InfiniBand ports are up, but the container lacks the RDMA devices
   or the `NCCL_IB_HCA` setting, and a firewall blocks the TCP bootstrap ports between nodes.
3. Fix: pass the RDMA devices into the container (the network operator or device plugin), set
   `NCCL_SOCKET_IFNAME` to the right interface, open the ports, and confirm the NCCL and driver versions
   are the same on every node.
4. Verify with `nccl-tests` across all nodes before relaunching, then add that test to node
   acceptance.

The lesson: multi-node hangs are almost always network configuration. Prove the fabric with
`nccl-tests` before blaming the model code.

**5. What separates senior from staff answers:** a senior engineer gets DDP/FSDP running and picks a sane
layout. A staff engineer owns the whole run economics: the compute and time estimate, the parallel layout
mapped to the topology, MFU and goodput targets with monitoring, the checkpoint interval derived from
failure data, automated recovery, and small-scale evidence that the batch size and LR schedule converge.

**Red flags:**
- No `DistributedSampler`, so every GPU sees the same data.
- Scaling the GPU count without revisiting the global batch and learning rate.
- Checkpoints with weights only (no optimizer, data position, or RNG state).
- Checkpointing every few hours on a cluster that fails every few hours.
- Tensor parallelism across nodes, or no `nccl-tests` before a big launch.

---

## Quiz

<details><summary>1. A model has 13B parameters. Can plain DDP train it on 80 GB GPUs with Adam? Why or why not?</summary>
No. Model states are 13B × 16 bytes ≈ 208 GB per replica, and DDP keeps a full copy on every GPU. Use FSDP
or ZeRO-3 to shard the states (or add tensor or pipeline parallelism).
</details>

<details><summary>2. What does each GPU exchange in DDP, FSDP, tensor parallelism, and pipeline parallelism?</summary>
DDP: an all-reduce of gradients once per step. FSDP: an all-gather of parameters per layer and a
reduce-scatter of gradients. Tensor parallel: all-reduces of activations inside every layer. Pipeline:
point-to-point activations forward and gradients backward between stages.
</details>

<details><summary>3. Why must you call `sampler.set_epoch(epoch)` with `DistributedSampler`?</summary>
The sampler shuffles with a seed based on the epoch. Without `set_epoch`, every epoch uses the same order.
</details>

<details><summary>4. In TensorFlow MirroredStrategy, is the batch passed to `fit` per replica or global?</summary>
Global. It is divided across replicas. In PyTorch DDP you set the per-GPU batch size.
</details>

<details><summary>5. Why does ring all-reduce scale well with the number of GPUs?</summary>
Each GPU sends about 2 × (N − 1)/N × S bytes, which is close to 2S regardless of N, and all links work in
parallel. No single node receives N × S bytes, unlike a parameter server.
</details>

<details><summary>6. Checkpoints take 2 minutes, and the job fails about every 3 hours. What checkpoint interval does Young–Daly suggest?</summary>
√(2 × 2 × 180) ≈ 27 minutes.
</details>

<details><summary>7. You go from 8 to 32 GPUs with the same micro-batch of 128 and SGD at lr 0.4 at batch 1,024. What should the LR be?</summary>
The global batch becomes 4,096 (4×), so the linear rule gives lr 1.6, with a warm-up period. Check
accuracy, because large batches can need retuning.
</details>

<details><summary>8. With PP = 4 and 16 micro-batches per step, what fraction of time is the pipeline bubble?</summary>
(PP − 1) ÷ (micro-batches + PP − 1) = 3 ÷ 19 ≈ 16%.
</details>

## Failure modes
- Every rank reading the full dataset (no `DistributedSampler`), or the same shuffle every epoch.
- Changing the GPU count but not the global batch, learning rate, or warm-up.
- Multi-node jobs hanging on NCCL because of the wrong network interface, missing RDMA devices, or blocked ports.
- Tensor parallelism across nodes, or communication that can't be hidden behind compute.
- Checkpoints missing optimizer, scheduler, data position, or RNG state, so "resumed" runs diverge.
- Checkpoint intervals far longer than the time between failures, wasting much of the GPU time.
- One slow GPU or link (a straggler) slowing the whole synchronous job, unnoticed.

## Checklist
- [ ] You can estimate training compute (6ND) and memory (16 bytes/param) and say which wall you hit
- [ ] You can choose between DDP, FSDP, TP, and PP and explain what each one communicates
- [ ] You can launch a `torchrun` job on one and two nodes, and explain RANK, LOCAL_RANK, and WORLD_SIZE
- [ ] You can explain where TensorFlow's global batch is split, and how `TF_CONFIG` works
- [ ] You can explain ring all-reduce and compute its traffic per GPU
- [ ] You set a checkpoint interval from the failure rate, and tested resuming
- [ ] You measured scaling efficiency at 1, 2, 4, 8 GPUs (or CPU processes) in the lab
- [ ] You ran `exercises/s08_global_batch_plan.py` and can derive each case by hand
