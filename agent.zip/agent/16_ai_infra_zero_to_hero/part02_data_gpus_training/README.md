# Part II — Data, GPUs and Distributed Training (Sections 6–8, lectures 36–56)

Where training data lives and how it reaches the GPU, what a GPU is and how to size one, and how to
spread one training job across many GPUs.

| § | Section | You will be able to | Exercise |
|---|---|---|---|
| 6 | [Data Storage for AI](s06_data_storage.md) | Choose lake, warehouse, or feature store; use S3/GCS well; pick databases; stream with Kafka; feed GPUs fast; secure data; build an idempotent pipeline | [`s06_idempotent_ingest.py`](../exercises/s06_idempotent_ingest.py) |
| 7 | [GPU Hardware and Performance](s07_gpu_hardware.md) | Explain GPU anatomy, CUDA, and the memory hierarchy; choose interconnects; use MIG; benchmark honestly; estimate GPU memory | [`s07_gpu_memory_estimate.py`](../exercises/s07_gpu_memory_estimate.py) |
| 8 | [Distributed Training Basics](s08_distributed_training.md) | Choose DDP, FSDP, TP, or PP; launch PyTorch and TensorFlow multi-GPU jobs; explain all-reduce; design for failures; plan a global batch | [`s08_global_batch_plan.py`](../exercises/s08_global_batch_plan.py) |

```mermaid
flowchart LR
  P1["Part I: a model<br/>on Kubernetes"] --> S6["§6 Data<br/>lake, streams, shards"]
  S6 --> S7["§7 GPUs<br/>compute, memory, links"]
  S7 --> S8["§8 Distributed training<br/>many GPUs, one job"]
  S8 --> NEXT["Part III: MLOps,<br/>CI/CD, cost"]
```

**How to read it:** Section 6 gets data into shape and onto fast storage. Section 7 explains the
machine that consumes it, and how much of that machine a model needs. Section 8 combines many of those
machines into one training job, and shows how to keep it running when parts fail.
