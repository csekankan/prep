# Section 7 — GPU Hardware and Performance

> Lectures 43–49 • Assessment: quiz + Estimate GPU Memory Requirements
> **After this section you can:** explain what is inside a GPU and why it suits AI, read and launch a
> CUDA kernel, reason about the GPU memory hierarchy and what fills GPU memory, choose between PCIe,
> NVLink and InfiniBand, split a GPU with MIG, benchmark honestly, and estimate how many GPUs a model
> needs before you rent them.
>
> Go deeper: [13 / Part 2 — Accelerated compute](../../13_sovereign_ai_infra_course/02_accelerated_compute/README.md)
> (drivers, device plugin, [MIG](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab23_mig_hopper.md),
> [DCGM](../../13_sovereign_ai_infra_course/02_accelerated_compute/lab27_dcgm_telemetry.md)) and
> [14 / ML systems math](../../14_math_for_ml_dl_llm/09_ml_systems_math.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 43 | Anatomy of a GPU for AI | Thousands of simple cores, Tensor Cores for matrix math, and very fast HBM memory |
| 44 | CUDA basics and GPU programming | The CPU launches kernels. Thousands of GPU threads run them in parallel, asynchronously |
| 45 | GPU memory hierarchy: optimizing usage | Registers and SRAM are tiny but fast, and HBM is big but slower. Fast code reuses data close to the cores |
| 46 | Multi-GPU scaling and interconnects (NVLink) | Inside a node, NVLink is ~7× faster than PCIe. Between nodes, InfiniBand or RoCE carries the traffic |
| 47 | Multi-Instance GPU (MIG) configurations | Split one A100 or H100 into up to 7 isolated GPUs for small models |
| 48 | Benchmarking AI workloads on GPUs | Measure tokens/s, latency percentiles, and MFU, not "GPU utilization %" |
| 49 | Lab: run a model on GPU with CUDA | Benchmark CPU vs GPU, fp32 vs fp16, and check your memory estimate against reality |

```mermaid
flowchart TB
  subgraph HOST["Host: CPU + system RAM"]
    PY[Python / PyTorch] --> RT[CUDA runtime + driver]
  end
  RT -->|"PCIe Gen5 x16, ~64 GB/s each way"| GPU0
  subgraph GPU0["One GPU, e.g. H100 SXM"]
    SMs["132 streaming multiprocessors<br/>CUDA cores + Tensor Cores"]
    REG["Registers + shared memory/L1<br/>~256 KB per SM, fastest"]
    L2["L2 cache, 50 MB"]
    HBM[("HBM3, 80 GB<br/>~3.35 TB/s")]
    SMs --- REG --- L2 --- HBM
  end
  GPU0 <-->|"NVLink 4, 900 GB/s"| GPU1[Other GPUs in the node]
  GPU0 <-->|"InfiniBand / RoCE NIC<br/>400 Gb/s = 50 GB/s"| NET[Other nodes]
```

**How to read it:** your Python code runs on the CPU and asks the CUDA driver to launch work on the GPU.
Inside the GPU, many streaming multiprocessors (SMs) do the math, pulling data from a small amount of very
fast on-chip memory, then a larger L2 cache, then the big HBM. GPUs in the same server talk over NVLink.
Servers talk over InfiniBand or RoCE. Each step outward is bigger, and slower by roughly an order of
magnitude, which is the theme of this whole section.

**Terms in this diagram** (each lecture below goes deeper):
- **CUDA runtime + driver**: CUDA is NVIDIA's GPU programming platform. The runtime is the library programs call,
  and the driver is the kernel-level software that actually controls the GPU (Lecture 44).
- **PCIe Gen5 x16**: PCI Express is the standard slot connecting a GPU to the CPU. "Gen5" is the version and "x16"
  the number of lanes, together about 64 GB/s in each direction.
- **H100 SXM**: NVIDIA's H100 GPU in the SXM form factor, a board that plugs straight into the server's
  motherboard to allow higher power and NVLink. The other form is a normal PCIe card.
- **Streaming multiprocessors, CUDA cores, Tensor Cores**: the GPU's compute blocks, their general-purpose cores,
  and their matrix-math units (Lecture 43).
- **Registers, shared memory/L1, L2 cache**: on-chip memories, from smallest and fastest to largest and slower
  (Lecture 45).
- **HBM3, 80 GB, ~3.35 TB/s**: high-bandwidth memory, stacked memory chips next to the GPU die. This is the "GPU
  memory" that must hold the model.
- **NVLink 4, 900 GB/s**: NVIDIA's direct GPU-to-GPU link inside a server (Lecture 46).
- **InfiniBand / RoCE NIC, 400 Gb/s = 50 GB/s**: the network card for traffic between servers. **InfiniBand** is
  a specialized low-latency network. **RoCE** (RDMA over Converged Ethernet) brings similar direct-memory
  transfers to Ethernet. Note the units: network speeds are in gigabits (**Gb**), memory speeds in gigabytes
  (**GB**), and 8 bits make a byte, so 400 Gb/s is 50 GB/s.

---

## Lecture 43 — Anatomy of a GPU for AI

**Why it matters.** You can't size, buy, or debug GPU infrastructure without knowing the four numbers
that matter for each card: compute (TFLOPS at your precision), memory capacity, memory bandwidth, and
interconnect bandwidth.

**In plain words.** A CPU is a few master chefs who can cook anything. A GPU is a factory floor with
thousands of line workers, organized into teams (SMs). Each team shares a small workbench (shared memory).
A special machine in each team (the Tensor Core) stamps out whole small matrix multiplications at once.
Ingredients come from a huge, fast warehouse next door (HBM).

**Architecture: inside one streaming multiprocessor.**

```mermaid
flowchart TB
  subgraph SM["One SM (H100 has 132 of these)"]
    WS["4 warp schedulers<br/>each issues work for 32 threads at once"]
    CC["128 FP32 CUDA cores<br/>general math"]
    TC["4 Tensor Cores<br/>matrix multiply-accumulate<br/>FP16, BF16, FP8, INT8"]
    RF["Register file 256 KB"]
    SMEM["Shared memory / L1<br/>up to 228 KB, programmer-managed"]
    WS --> CC
    WS --> TC
    CC --- RF
    TC --- RF
    RF --- SMEM
  end
  SMEM --- L2[(L2 cache shared by all SMs)]
  L2 --- HBM[(HBM)]
```

**How to read it:** threads run in groups of 32 called **warps**. Every thread in a warp runs the same
instruction at the same time on different data. Schedulers keep many warps in flight, so when one warp
waits for memory, another computes. Tensor Cores do the heavy lifting for neural networks: each one
multiplies small matrix tiles in a single step. That is why low-precision matrix math is so much faster
than ordinary FP32 math.

**Number formats in the diagram.** **FP32** is the standard 32-bit floating-point number. **FP16** and **BF16**
use 16 bits. FP16 keeps more precision digits, while BF16 ("brain float") keeps FP32's range of magnitudes,
which makes it safer for training. **FP8** uses 8 bits and is supported from H100 on. **INT8** is an 8-bit
integer, used for quantized inference. Fewer bits mean less memory and more operations per second, at some cost
in accuracy (Section 22). **Multiply-accumulate** means computing `a × b + c` in one step, the core operation of
matrix multiplication.

**Core ideas.**

| GPU (data-center) | Memory | Bandwidth | Dense BF16/FP16 Tensor TFLOPS | Interconnect | Typical use |
|---|---|---|---|---|---|
| T4 | 16 GB GDDR6 | 320 GB/s | ~65 | PCIe | Cheap inference, older |
| L4 | 24 GB GDDR6 | 300 GB/s | ~121 | PCIe | Efficient inference, video |
| A10G | 24 GB GDDR6 | 600 GB/s | ~70 | PCIe | Inference on AWS g5 |
| A100 80GB SXM | 80 GB HBM2e | ~2.0 TB/s | 312 | NVLink 3, 600 GB/s | Training and inference |
| H100 SXM | 80 GB HBM3 | ~3.35 TB/s | ~989 | NVLink 4, 900 GB/s | Large training, LLM serving |
| H200 SXM | 141 GB HBM3e | ~4.8 TB/s | ~989 | NVLink 4, 900 GB/s | Memory-hungry LLM serving |
| AMD MI300X | 192 GB HBM3 | ~5.3 TB/s | ~1,300 | Infinity Fabric | Large-memory inference and training |

Vendor figures, rounded. Sparsity can double the TFLOPS on paper, but most workloads don't use it.

- **Precision is a speed multiplier.** On an H100, FP32 without Tensor Cores gives ~67 TFLOPS, BF16 on
  Tensor Cores ~989, and FP8 ~1,979. Training uses BF16 with FP32 master weights (*mixed precision*).
  Inference increasingly uses FP8 or INT4.
- **The roofline.** Divide peak FLOPS by memory bandwidth to get the *ridge point*: H100 ≈ 989 TFLOPS ÷
  3.35 TB/s ≈ 295 FLOPs per byte. A kernel doing fewer FLOPs per byte than that is limited by memory.
  One doing more is limited by compute. Large matrix multiplies are compute-bound. LLM decode at small
  batch sizes, layer norms, and element-wise operations are memory-bound.
- SXM cards (on a board with NVLink, ~700 W) and PCIe cards (in a normal slot, ~350 W) with the same name
  differ a lot in power, clock speeds, and interconnect.

**Example: why a cheaper card can serve faster.** For decode at batch size 1, every token reads all
the weights once. A 7B model in FP16 is 14 GB.
- L4: 300 GB/s ÷ 14 GB ≈ **21 tokens/s** at best.
- A10G: 600 GB/s ÷ 14 GB ≈ **43 tokens/s**, even though it has fewer TFLOPS than the L4.
- H100: 3,350 GB/s ÷ 14 GB ≈ **240 tokens/s**.

For single-stream decode, bandwidth, not TFLOPS, decides the speed. Batching many users together
raises the FLOPs per byte and moves the work toward the compute roof.

**Senior / FAANG best practice.** Write the four numbers next to every GPU option in a design doc,
and state which one limits your workload, with a back-of-envelope calculation. Big-tech capacity teams
compare chips on **cost per useful unit of work** (cost per 1M tokens at the target latency, or per
training step), measured on their own models, not on vendor peak numbers.

---

## Lecture 44 — CUDA basics and GPU programming

**Why it matters.** You rarely write CUDA yourself, but every AI framework sits on top of it. Version
mismatches, asynchronous execution, and kernel-launch overhead explain a large share of real
production problems: wrong timings, idle GPUs, and "CUDA not available" errors.

**In plain words.** The CPU is a manager handing out work orders (kernels) to a huge crew. The manager
doesn't wait for each job to finish before writing the next order. Orders go into a queue (a
**stream**), and the crew works through them. If the manager stops to ask "is it done yet?" after every
order, the crew sits idle between orders.

**Architecture: what happens when PyTorch runs `a @ b` on the GPU.**

```mermaid
sequenceDiagram
  participant Py as Python (CPU)
  participant PT as PyTorch dispatcher
  participant Lib as cuBLAS / cuDNN
  participant Drv as CUDA driver
  participant GPU as GPU stream
  Py->>PT: c = a @ b
  PT->>Lib: pick the fastest matmul kernel
  Lib->>Drv: launch kernel with grid and block sizes
  Drv->>GPU: enqueue, returns immediately
  PT-->>Py: c is ready to use in more GPU ops
  Py->>PT: print(c.sum().item())
  PT->>GPU: wait until the stream is done
  GPU-->>Py: value copied to CPU
```

**How to read it:** the launch returns at once, and Python keeps going while the GPU works. Only when
you need a value on the CPU (`.item()`, `print`, `.cpu()`, `.numpy()`) does the CPU wait for the GPU.
That wait is a **synchronization**. Too many of them in a training loop leave the GPU idle.

**Terms in this diagram.**
- **PyTorch dispatcher**: the part of PyTorch that looks at an operation (`a @ b` is matrix multiplication) and
  the tensors' device and type, and picks the right implementation.
- **cuBLAS / cuDNN**: NVIDIA's tuned GPU libraries. **cuBLAS** does linear algebra, such as matrix multiplication.
  **cuDNN** does neural-network operations, such as convolutions.
- **Kernel**: a function that runs on the GPU, executed by thousands of threads at once. (This isn't the Linux
  kernel.)
- **Grid and block sizes**: how the work is split. Threads are grouped into **blocks**, and each block runs on one
  SM. All the blocks of one launch form the **grid**.
- **GPU stream**: a queue of GPU work that runs in order. **Enqueue** means adding the kernel to that queue, and
  the CPU doesn't wait for it to run.
- **.item()**: copy a single value from the GPU to a Python number, which forces the CPU to wait for the queue.

**Core ideas.**

| Term | Meaning |
|---|---|
| Kernel | A function that runs on the GPU, executed by many threads |
| Thread / block / grid | Threads are grouped into blocks (up to 1,024 threads). Blocks form a grid. Each block runs on one SM |
| Warp | 32 threads that execute together. Branches that split a warp slow it down |
| Stream | An ordered queue of GPU work. Separate streams can overlap compute and copies |
| Host / device | CPU memory / GPU memory. Copies between them cross PCIe |
| Toolkit vs driver | The CUDA toolkit (compiler, libraries) ships with your framework or image. The driver is on the host, and must be new enough for that toolkit |

A minimal CUDA kernel: every thread adds one pair of numbers.

```cuda
__global__ void add(const float* a, const float* b, float* c, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;   // this thread's global index
    if (i < n) c[i] = a[i] + b[i];
}
// launch: enough blocks of 256 threads to cover n elements
add<<<(n + 255) / 256, 256>>>(d_a, d_b, d_c, n);
```

Most engineers never write this. They use PyTorch, which calls cuBLAS and cuDNN, or they write custom
kernels in **Triton**, a Python-like language that compiles to GPU code. `torch.compile` generates Triton
kernels automatically, fusing operations to cut launches and memory traffic.

```bash
nvidia-smi                       # driver version and the highest CUDA version it supports
python -c "import torch; print(torch.version.cuda, torch.cuda.is_available())"   # toolkit PyTorch was built with
```

**Example: the timing that lied.** An engineer timed a model at 0.4 ms per batch. It was really 31 ms:
without `torch.cuda.synchronize()` before stopping the timer, they had only measured how long it took
to *queue* the kernels. The opposite bug is just as common: a `loss.item()` logged every step forced a
sync each iteration. Logging every 50 steps raised throughput by 12%.

**Senior / FAANG best practice.** Pin the driver on the host, and the CUDA toolkit plus framework inside the
image, as one tested matrix (Section 2). Watch for **host-side bottlenecks**: launch overhead, Python
loops, and syncs. CUDA Graphs and `torch.compile` remove much of it. Profile before writing custom
kernels. Most speedups come from batching, fusion, and precision, not hand-written CUDA.

---

## Lecture 45 — GPU memory hierarchy: optimizing usage

**Why it matters.** "CUDA out of memory" is the most common GPU error, and memory bandwidth is the most
common speed limit. Knowing what fills memory, and which level of the hierarchy your data lives in,
turns guesswork into engineering.

**In plain words.** It's like a kitchen. The cutting board in front of you (registers) holds a few
items, instantly. The counter (shared memory) holds a bit more, close by. The pantry (L2) takes a few
steps. The walk-in fridge (HBM) is large but a longer walk. The supermarket across town (CPU RAM, over
PCIe) is huge and slow. Good cooks bring a whole tray from the fridge and do all the chopping at the
counter, instead of walking back for every onion.

**Architecture: the hierarchy, with rough H100 numbers.**

```mermaid
flowchart TB
  R["Registers: ~256 KB per SM<br/>about 1 cycle"] --> S["Shared memory / L1: up to 228 KB per SM<br/>tens of TB/s in total"]
  S --> L2["L2 cache: 50 MB<br/>~10 TB/s-class"]
  L2 --> H["HBM3: 80 GB<br/>~3.35 TB/s"]
  H --> P["Host RAM over PCIe Gen5: hundreds of GB<br/>~64 GB/s each way"]
  P --> D["NVMe / network storage: TBs<br/>~5 to 50 GB/s"]
```

**How to read it:** each level down is bigger and slower. A kernel that reads a value from HBM, does one
multiply, and writes it back is limited by HBM bandwidth. A kernel that loads a tile into shared memory and
reuses it hundreds of times runs near peak compute. **FlashAttention** is the famous example: it computes
attention in tiles that stay in on-chip SRAM, instead of writing the full attention matrix to HBM.
(**SRAM** is the very fast on-chip memory that registers, shared memory, and caches are built from. A **cycle**
is one tick of the GPU's clock, about 0.5 nanoseconds at 2 GHz. At the bottom, **NVMe** SSDs and network storage
hold datasets and checkpoints, thousands of times slower than registers.)

**Core ideas: what fills GPU memory.**

| During | What | Size rule of thumb |
|---|---|---|
| Inference | Weights | params × bytes (fp16/bf16 2, fp8/int8 1, int4 0.5) |
| Inference | KV cache (LLMs) | 2 × layers × KV heads × head dim × bytes × tokens in flight |
| Training | Weights + gradients + Adam states | ~16 bytes per parameter in mixed precision |
| Training | Activations | Grows with batch × sequence length × hidden size × layers |
| Both | CUDA context, workspace, fragmentation | ~0.5–2 GB + 5–15% |

**Optimization techniques, and what each one trades:**

| Technique | Saves | Costs |
|---|---|---|
| Mixed precision (BF16) | ~2× activations and weight copies, ~2–8× faster math | Little, if loss scaling and FP32 master weights are kept |
| Activation checkpointing | Most activation memory | ~30% more compute (recomputation) |
| FlashAttention / fused kernels | Attention memory from quadratic to linear in sequence length, and bandwidth | Nothing, use it |
| Sharding (FSDP / ZeRO-3) | Model states ÷ number of GPUs | Communication every step (Section 8) |
| Quantization (inference) | 2–4× weight memory | Small accuracy loss. Must evaluate (Section 35) |
| Paged KV cache (vLLM) | Fragmentation waste in the KV cache | None for most uses (Section 15) |
| Pinned host memory | Faster CPU-to-GPU copies, overlap with compute | Locked RAM |

```python
torch.cuda.reset_peak_memory_stats()
loss = model(batch).loss; loss.backward()
print(torch.cuda.max_memory_allocated() / 1e9, "GB peak")       # what your tensors used
print(torch.cuda.memory_summary(abbreviated=True))              # allocator view, incl. fragmentation
# reduce fragmentation for variable-size workloads:
#   PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
```

**Example: the KV cache is the real budget.** Llama 3 8B in bf16 has 16 GB of weights. Its KV cache is
128 KiB per token: 2 × 32 layers × 8 KV heads × 128 dims × 2 bytes. Sixteen concurrent users at 8,192
tokens each hold 131,072 tokens, which is **17.2 GB**, more than the weights. With overhead that's ~38 GB:
one 80 GB GPU is fine, a 40 GB GPU is too tight. Grouped-query attention (8 KV heads instead of 32) is
why this number is 4× smaller than it would otherwise be.

**Senior / FAANG best practice.** Budget memory explicitly in every design: weights, KV cache or
activations, and headroom (~10%). Run at the budgeted batch size and context in a load test before launch.
Serving teams set the maximum batch size and context length from that budget, so a long prompt can't
take down a replica. Track **peak** memory, not average, because out-of-memory errors happen at peaks.

---

## Lecture 46 — Multi-GPU scaling and interconnects (NVLink)

**Why it matters.** When one GPU isn't enough, the link between GPUs decides how well you scale. The
same 8 GPUs can train at 95% efficiency on NVLink or 40% on PCIe. Interconnects are also a large part
of what makes training clusters expensive.

**In plain words.** GPUs in a server are coworkers. PCIe is passing notes through the office mail room.
NVLink is a direct hotline between every pair of desks. InfiniBand is a dedicated high-speed train
between office buildings. Ordinary Ethernet without RDMA is the public bus.

**Architecture: an 8-GPU HGX node and how nodes connect.**

```mermaid
flowchart TB
  subgraph NODE1["HGX H100 node 1"]
    G0[GPU 0] & G1[GPU 1] & G2[GPU 2] & G3[GPU 3] --- NVS["NVSwitch fabric<br/>900 GB/s per GPU,<br/>any-to-any"]
    G4[GPU 4] & G5[GPU 5] & G6[GPU 6] & G7[GPU 7] --- NVS
    CPU1[2 CPUs] ---|PCIe Gen5| PCIESW[PCIe switches]
    PCIESW --- NIC1["8 × 400 Gb/s NICs<br/>one per GPU, GPUDirect RDMA"]
  end
  NIC1 ==>|"InfiniBand NDR or RoCE,<br/>rail-optimized fat tree"| SW[Leaf and spine switches]
  SW ==> NIC2[8 NICs on node 2]
  NIC2 --- NODE2[HGX node 2]
```

**How to read it:** inside a node, all 8 GPUs connect through NVSwitch chips, so any GPU can talk to any
other at full NVLink speed. Each GPU also has its own network card. With **GPUDirect RDMA**, a GPU sends data
straight from its memory to another node's GPU memory, without going through the CPU. "Rail-optimized"
means GPU 0 of every node connects to the same leaf switch, GPU 1 to the next, and so on, which keeps
the most common traffic one switch hop away.

**Terms in this diagram.**
- **HGX H100 node**: NVIDIA's standard 8-GPU server board design, which server makers build systems around.
- **NVSwitch fabric**: switch chips that connect all 8 GPUs' NVLinks, so every pair of GPUs gets full speed at
  the same time ("any-to-any").
- **PCIe switches**: chips that fan out PCIe lanes from the CPUs to the GPUs and NICs.
- **InfiniBand NDR**: the 400 Gb/s generation of InfiniBand (NDR stands for "next data rate").
- **Fat tree, leaf and spine switches**: a common network layout. Servers connect to **leaf** switches, and every
  leaf connects to every **spine** switch above it. "Fat" means the links get wider toward the top, so any server
  can reach any other at full speed.

**Core ideas.**

| Link | Bandwidth per GPU (approx.) | Scope |
|---|---|---|
| PCIe Gen4 x16 | ~32 GB/s each way | GPU to CPU, or GPU to GPU without NVLink |
| PCIe Gen5 x16 | ~64 GB/s each way | Same, newer servers |
| NVLink 3 (A100) | 600 GB/s total | Within a node |
| NVLink 4 (H100) | 900 GB/s total | Within a node, through NVSwitch |
| InfiniBand NDR / RoCE 400G | 50 GB/s per NIC, ×8 NICs per node | Between nodes |

- **All-reduce** is the main operation in data-parallel training: every GPU ends up with the sum of all
  gradients. A ring all-reduce moves about 2 × (N − 1)/N × the gradient size through each GPU's link.
  Section 8 explains the algorithm.
- **NCCL** is NVIDIA's library for these collective operations. It detects the topology and picks the
  fastest route automatically, if the drivers, NICs, and environment variables are right.
- Check the topology with `nvidia-smi topo -m`. `NV#` means NVLink, while `PIX`, `PXB`, and `SYS` mean
  increasingly distant PCIe paths.

**Example: syncing gradients for a 7B model across 8 GPUs.** bf16 gradients are 14 GB, so each
GPU moves 2 × 7/8 × 14 GB ≈ 24.5 GB per step.
- NVLink at ~360 GB/s effective bus bandwidth: 24.5 ÷ 360 ≈ **68 ms**. This hides behind the backward
  pass.
- PCIe at ~20 GB/s effective: 24.5 ÷ 20 ≈ **1.2 s** per step, which can exceed the compute time and
  halve throughput.

That's why multi-GPU training uses SXM/NVLink nodes, while inference replicas that never sync can live
on cheap PCIe cards.

**Senior / FAANG best practice.** Before trusting a new cluster, run `nccl-tests` (`all_reduce_perf`)
within a node and across nodes, and compare the measured bus bandwidth with the expected value. A
single bad cable or misconfigured NIC drags the whole job down to the slowest link. Keep tightly
coupled parallelism (tensor parallel) inside a node on NVLink, and put only the looser parallelism
(data and pipeline) across the network.

---

## Lecture 47 — Multi-Instance GPU (MIG) configurations

**Why it matters.** Many inference models are small. Giving each one a whole 80 GB GPU wastes most of
the card. MIG splits a GPU into isolated slices, so several services share it safely.

**In plain words.** MIG turns one big apartment into separate studio flats, each with its own front
door, kitchen, and meter. Neighbors can't use your kitchen, and a party next door doesn't slow you
down. Time-slicing, by contrast, is a shared house with a rota: everyone gets the whole kitchen, but only
in turns, and a messy housemate affects everyone.

**Architecture: one H100 80 GB split three ways.**

```mermaid
flowchart LR
  subgraph GPU["H100 80 GB, MIG enabled: 7 compute slices, 8 memory slices"]
    I1["3g.40gb<br/>3 compute slices, 40 GB<br/>7B model, bf16"]
    I2["2g.20gb<br/>2 slices, 20 GB<br/>embedding model"]
    I3["1g.10gb<br/>reranker"]
    I4["1g.10gb<br/>small classifier"]
  end
  K8S[Kubernetes + GPU Operator] -->|"nvidia.com/mig-3g.40gb: 1"| I1
  K8S -->|"nvidia.com/mig-2g.20gb: 1"| I2
  K8S -->|"nvidia.com/mig-1g.10gb: 1"| I3 & I4
```

**How to read it:** each instance gets its own SMs, its own share of L2 cache and memory bandwidth, and its
own memory, with hardware isolation and separate error containment. Kubernetes exposes each profile as
a separate resource name, so a pod asks for `nvidia.com/mig-1g.10gb` the same way it would ask for a
whole GPU.

**Core ideas.**

| Sharing method | Isolation | Good for | Not for |
|---|---|---|---|
| Whole GPU | Full | Large models, training | Small models (wasted memory) |
| MIG (A100, H100, H200, B200) | Hardware: memory, compute, faults | Several small, steady inference services, multi-tenant notebooks | Workloads that need the whole GPU or NVLink between slices |
| Time-slicing | None: shared memory, turns at compute | Dev, bursty light jobs | Production latency SLOs, anything memory-heavy |
| MPS (Multi-Process Service) | Partial: shared memory space | Many small processes from one trusted team | Multi-tenant isolation |

```bash
sudo nvidia-smi -i 0 -mig 1                                   # enable MIG mode on GPU 0 (drain it first)
sudo nvidia-smi mig -lgip                                     # list available profiles
sudo nvidia-smi mig -i 0 -cgi 3g.40gb,2g.20gb,1g.10gb,1g.10gb -C   # create instances + compute instances
nvidia-smi -L                                                 # each MIG device now has its own UUID
```

In Kubernetes, the GPU Operator's MIG manager applies a named layout per node from a label, such as
`nvidia.com/mig.config=all-1g.10gb`, so you don't run these commands by hand.

**Example: consolidating small models.** A team ran seven small models (rerankers, classifiers, an
embedding model), each on its own A100 80GB, at 6–15% utilization. They moved them to one A100 as
seven `1g.10gb` instances, and kept the two busiest on `2g.20gb` slices of a second card. That freed
five GPUs, about $10,000 a month at on-demand prices. p95 latency rose by 8%, within the SLO, because
each slice has a fixed share of compute.

**Senior / FAANG best practice.** Standardize on a few MIG layouts per node pool. Changing layouts
needs an idle GPU, so treat it like a node reconfiguration, not a per-pod setting. Load-test every model
on its slice, because a slice has a fraction of the bandwidth as well as the memory. Track allocation
by slice in chargeback, so teams see the savings.

---

## Lecture 48 — Benchmarking AI workloads on GPUs

**Why it matters.** Capacity plans, chip choices, and cost per request all rest on benchmarks. Bad
benchmarks (no warm-up, no synchronization, wrong metric) lead to buying the wrong hardware or missing
an SLO in production.

**In plain words.** Testing a car properly means warming up the engine, driving the real route with a
real load, timing many laps, and reporting both average and worst laps. Revving the engine in the
garage tells you nothing about the commute.

**Architecture: a benchmark method you can trust.**

```mermaid
flowchart LR
  FIX["Fix the setup<br/>same image, driver, clocks,<br/>batch, sequence lengths"] --> WARM["Warm up<br/>compile, cache, allocator"]
  WARM --> RUN["Steady-state runs<br/>synchronize before timing<br/>repeat 3 to 5 times"]
  RUN --> MET["Record<br/>throughput, p50 p95 p99,<br/>memory peak, power"]
  MET --> PROF{"Below expectation?"}
  PROF -->|yes| NS["Profile<br/>PyTorch profiler, Nsight Systems,<br/>DCGM metrics"]
  PROF -->|no| REP["Report cost per unit of work<br/>at the latency target"]
  NS --> FIX
```

**How to read it:** control everything except what you're comparing, discard the first iterations, time
with proper synchronization, and repeat. Report percentiles and the cost per unit of work. If the
numbers look low, profile to find the bottleneck before drawing conclusions.

**Terms in this diagram.**
- **Clocks**: GPU clock speeds change with temperature and power. Benchmark at stable or locked clocks, or results
  vary run to run.
- **Warm up: compile, cache, allocator**: the first iterations are slow because kernels get compiled or selected
  (`torch.compile`, cuDNN autotuning), caches fill, and PyTorch's **memory allocator** reserves GPU memory. Throw
  those iterations away.
- **Steady-state runs**: measurements taken once performance has stopped changing.
- **p50 p95 p99**: latency percentiles: the time that 50%, 95%, and 99% of requests beat.
- **Memory peak, power**: the highest GPU memory used (`torch.cuda.max_memory_allocated()`) and the power draw in
  watts.
- **Profile, PyTorch profiler, Nsight Systems, DCGM**: **profiling** records where time goes. The **PyTorch
  profiler** shows time per operation. **Nsight Systems** is NVIDIA's timeline tool, showing CPU, GPU kernels,
  and memory copies side by side. **DCGM** (Data Center GPU Manager) reports live GPU utilization, memory, and
  temperature.

**Core ideas.**

| Metric | Use for | Note |
|---|---|---|
| Samples or tokens per second | Training and batch throughput | Report per GPU and in total |
| Time to first token (TTFT) | LLM chat responsiveness | Dominated by prefill and queueing |
| Time per output token (TPOT) | LLM streaming speed | Dominated by memory bandwidth and batching |
| p50 / p95 / p99 latency | Online SLOs | Averages hide the tail |
| MFU (model FLOPs utilization) | Training efficiency | Useful FLOPs ÷ peak FLOPs. 35–55% is good for LLM training |
| SM activity, tensor activity, DRAM activity (DCGM) | Where time goes | Far more informative than `nvidia-smi` utilization % |

- **`nvidia-smi` "GPU-Util" is misleading.** It is the percentage of time *any* kernel was running, so
  a tiny kernel on one SM shows 100%. Use DCGM's `SM_ACTIVE` and `PIPE_TENSOR_ACTIVE` metrics instead.
- **MFU for transformer training** ≈ 6 × parameters × tokens per second ÷ (number of GPUs × peak FLOPS).
- Industry benchmarks such as **MLPerf** (Training and Inference) compare systems on standard
  models. They're useful for shortlisting, but always rerun on your own model.

**Example: computing MFU.** An 8B model trains at 3,500 tokens/s per H100.
MFU = 6 × 8×10⁹ × 3,500 ÷ 989×10¹² ≈ **17%**. A good run reaches ~40%, which is ~8,200 tokens/s per GPU.
The profiler showed 30% of each step in the data loader and 15% in un-overlapped gradient sync. Fixing
both brought MFU to 38%, which halved the cost of the training run.

**Senior / FAANG best practice.** Big-tech teams keep a **benchmark suite in CI** for their own key
models. Every new driver, framework, or chip runs it, and a regression above a threshold blocks the
rollout. They compare chips on cost per 1M tokens (or per training step) at the production latency
target, with clock speeds and power limits recorded, because a power-capped GPU can be 20–30% slower.

---

## Lecture 49 — Lab: run a model on GPU with CUDA

**Goal:** run real workloads on a GPU, measure the speedups from the GPU and from lower precision, see
what fills memory, and check the memory estimator against reality.

**Cost:** one T4, L4, or A10G instance for about an hour, roughly $0.50–$1.20. You can run Steps 1 and
4 on any laptop.

**What you're building.**

```mermaid
flowchart LR
  S1["Step 1: estimate memory<br/>with the exercise script"] --> S2["Step 2: matmul TFLOPS<br/>fp32 vs fp16"]
  S2 --> S3["Step 3: ResNet-50 inference<br/>CPU vs GPU, batch sizes"]
  S3 --> S4["Step 4: compare estimated vs<br/>measured peak memory"]
  S4 --> S5["Step 5: watch DCGM / nvidia-smi<br/>while it runs"]
```

**How to read it:** five steps in order. You estimate memory with this section's exercise script, then measure
raw matrix-multiply speed in **TFLOPS** (trillions of floating-point operations per second) at 32-bit and 16-bit
precision. Next you time **ResNet-50** (a standard 50-layer image classifier) on CPU and GPU at several batch
sizes, and compare the memory estimate with the real peak. Throughout, you watch the GPU live with DCGM or
`nvidia-smi`.

**In plain words.** You predict how much memory and speed you'll get, then measure, then explain the gap.
That loop is what capacity planning is.

### Step 1 — Estimate before you measure

```bash
python3 exercises/s07_gpu_memory_estimate.py --model gpt2-xl --mode infer --dtype fp16 --batch 8 --seq 1024
```

Write down the predicted total memory.

### Step 2 — Measure matrix-multiply throughput

```python
import time, torch
def tflops(dtype, n=8192, iters=20):
    a = torch.randn(n, n, device="cuda", dtype=dtype); b = torch.randn(n, n, device="cuda", dtype=dtype)
    for _ in range(3): a @ b                        # warm-up
    torch.cuda.synchronize(); t = time.perf_counter()
    for _ in range(iters): a @ b
    torch.cuda.synchronize()
    return 2 * n**3 * iters / (time.perf_counter() - t) / 1e12
print(torch.cuda.get_device_name(0))
for dt in (torch.float32, torch.float16, torch.bfloat16):
    try: print(dt, f"{tflops(dt):.1f} TFLOPS")
    except RuntimeError as e: print(dt, "unsupported:", e)
```

Compare the result with the spec table in Lecture 43. 60–80% of the vendor peak is normal for a big matmul.
(The T4 has no bf16 support, so that line may fail or fall back to a slow path.)

### Step 3 — Run a real model, CPU vs GPU, at several batch sizes

```python
import time, torch, torchvision
model = torchvision.models.resnet50(weights=None).eval()
def bench(device, dtype, batch, iters=20):
    m = model.to(device, dtype); x = torch.randn(batch, 3, 224, 224, device=device, dtype=dtype)
    with torch.inference_mode():
        for _ in range(3): m(x)
        if device == "cuda": torch.cuda.synchronize()
        t = time.perf_counter()
        for _ in range(iters): m(x)
        if device == "cuda": torch.cuda.synchronize()
    return batch * iters / (time.perf_counter() - t)
print("cpu  fp32 b=8  ", round(bench("cpu", torch.float32, 8)), "img/s")
for b in (1, 8, 32, 128):
    print(f"cuda fp16 b={b:<4}", round(bench("cuda", torch.float16, b)), "img/s")
print("cuda fp32 b=32 ", round(bench("cuda", torch.float32, 32)), "img/s")
```

### Step 4 — Compare estimated and measured memory

```python
from transformers import AutoModelForCausalLM
import torch
m = AutoModelForCausalLM.from_pretrained("gpt2-xl", torch_dtype=torch.float16).cuda()
torch.cuda.reset_peak_memory_stats()
ids = torch.randint(0, 50000, (8, 1024), device="cuda")
with torch.inference_mode(): m(ids, use_cache=True)
print(f"peak {torch.cuda.max_memory_allocated() / 1e9:.1f} GB")
```

The prefill pass also holds activations and logits (8 × 1,024 × 50,257 × 2 bytes ≈ 0.8 GB), which the
inference estimate folds into overhead.

### Step 5 — Watch the GPU while it runs

```bash
nvidia-smi dmon -s pucm          # power, utilization, clocks, memory, once per second
nvidia-smi -q -d PERFORMANCE     # throttle reasons: power cap, thermal, idle
```

**Expected results:**
- **Step 2:** fp16 matmul is several times faster than fp32. On an L4 that's tens of TFLOPS, not hundreds.
- **Step 3:** the GPU is 10–50× faster than the CPU, throughput rises with batch size until it levels off,
  and fp16 beats fp32.
- **Step 4:** measured peak memory is within about ±20% of the estimate, and you can name what makes up
  the difference.
- **Step 5:** `dmon` shows clocks and power rise during the runs. Write down any throttle reason that appears.

---

## Assessment — Estimate GPU memory requirements

**Task.** For each scenario, estimate the memory needed, say which GPUs can run it and how many, and name
the biggest lever for reducing the memory needed.
1. Serve Llama 3 8B in bf16 to 16 concurrent users with 8k-token contexts.
2. Serve Llama 3 70B in bf16 to 8 users with 4k contexts, then again with int4 weights and an fp8 KV cache.
3. Fully fine-tune Llama 3 8B (AdamW, mixed precision) with a 4k sequence length, first on one GPU, then on 8 GPUs with FSDP and activation checkpointing.

**Model answer.** Run [`exercises/s07_gpu_memory_estimate.py`](../exercises/s07_gpu_memory_estimate.py)
with no arguments to reproduce these numbers.

| Scenario | Weights / states | KV or activations | Total (incl. overhead) | Fits on | Biggest lever |
|---|---|---|---|---|---|
| 1. 8B bf16, 16 × 8k | 16.1 GB weights | 17.2 GB KV (128 KiB/token) | ~38 GB | 1 × A100/H100 80GB, or 2 × L4 with tensor parallel | fp8 KV cache, or limit max context |
| 2a. 70B bf16, 8 × 4k | 141 GB weights | 10.7 GB KV (320 KiB/token) | ~168 GB | 4 × H100 80GB, 2 × H200, or 1 × MI300X | Quantize weights |
| 2b. 70B int4, fp8 KV | 35 GB weights | 5.4 GB KV | ~46 GB | 1 × A100/H100 80GB | Evaluate accuracy at int4 first |
| 3a. 8B full fine-tune, 1 GPU | 128.5 GB states (16 B/param) | 18 GB activations + 2 GB logits | ~165 GB | Only a 192 GB MI300X | Shard the states |
| 3b. Same, 8 GPUs FSDP + checkpointing | 16 GB per GPU | ~4 GB | ~23 GB per GPU | 8 × A100 40GB or larger | LoRA (Section 26) cuts it further |

**The method, in three lines:**
- inference = params × bytes + 2 × layers × KV heads × head dim × bytes × tokens + ~10% + 1 GB;
- training = 16 × params ÷ shards + activations + logits + ~10%;
- divide by 90% of the card's memory, and round up to a power of two for tensor parallelism.

---

## FAANG deep-dive notes

**How big tech does it.** GPU capacity is planned from models, not guessed. Capacity teams keep a
model of each workload (memory, FLOPs, and bandwidth per request or step), validated by in-house
benchmarks on every chip generation. They buy accelerator generations in large commitments,
standardize node types (8-GPU NVLink nodes for training, smaller or MIG-partitioned nodes for
inference), and run fleet telemetry (DCGM) to retire or repair failing GPUs before they hurt jobs.

**Staff review questions.**
- What limits this workload: compute, HBM capacity, HBM bandwidth, or interconnect? Show the arithmetic.
- What is cost per 1M tokens (or per training step) on each candidate chip, measured on our model?
- What happens when context length doubles? Does the KV cache budget still hold?
- How do we detect throttled, failing, or misconfigured GPUs in the fleet?

**Interview question.** "How many GPUs do we need to serve a 70B model to 2,000 concurrent users?"

**Typical system-design prompt:** *Choose the GPU type and count to serve Llama 3 70B to 2,000 concurrent
chat sessions with up to 8k tokens of context, p95 time-to-first-token under 1 second, and about
30 tokens/s per user while streaming.*

**1. Clarify first:** What are the average and maximum context lengths, and the prompt/output split? Can
we quantize (fp8 weights, fp8 KV)? What is the traffic shape over the day? Is there a regional or data
residency constraint? Is prefix caching possible (shared system prompts)?

**2. Back-of-envelope sizing:**
- KV per token: 2 × 80 layers × 8 KV heads × 128 × 2 bytes = 320 KiB. At an average of 4k tokens in
  flight per session: 2,000 × 4,096 × 320 KiB ≈ **2.7 TB of KV cache**.
- One 8 × H100 node: 640 GB. Minus 141 GB of bf16 weights and ~10% headroom leaves ~430 GB for KV,
  which is ~330 sessions at 4k. 2,000 ÷ 330 ≈ **6–7 nodes**, before any traffic headroom.
- With fp8 weights (71 GB) and an fp8 KV cache (160 KiB/token), one node holds ~900 sessions, so
  **3 nodes** plus headroom. That halves the fleet, if quality holds.
- Bandwidth check: 30 tokens/s × ~250 sessions per tensor-parallel group of 4 GPUs is feasible with
  continuous batching on H100-class bandwidth. Confirm it with a load test.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| GPU | H100 80 GB | H200 / MI300X (more HBM) | More HBM wins when the KV cache dominates. Compare cost per 1M tokens |
| Precision | bf16 | fp8 weights + fp8 KV | fp8 on Hopper-class GPUs usually costs little quality. Evaluate it on your own tasks |
| Parallelism | TP = 8 (one replica per node) | TP = 4 (two replicas per node) | Smallest TP that fits with good KV room. Fewer GPUs per replica means less sync overhead |
| Small models | Whole GPUs | MIG slices | MIG for many small, steady models |
| Interconnect | PCIe nodes | NVLink nodes | NVLink for tensor parallelism and training. PCIe is fine for single-GPU replicas |

**4. Follow-up questions with crisp answers:**
- *Why is decode memory-bound?* Each step reads all weights and the KV cache to produce one token per
  sequence. Batching raises FLOPs per byte read.
- *Why not just buy the GPU with the most TFLOPS?* For serving, HBM capacity and bandwidth usually
  limit you first. TFLOPS matter for prefill and training.
- *How do you protect latency when contexts grow?* Cap the context length per tier, use a paged KV
  cache, prefer prefix caching, and route long-context requests to a separate pool.

**Debug this (common onsite question):** "Throughput on the new rack of H100s is 25% lower than on the old
rack, with the same image and model."
1. Compare `nvidia-smi -q -d PERFORMANCE,POWER,CLOCK` on both racks. The new nodes show
   `SW Power Cap: Active`, with the power limit at 500 W instead of 700 W.
2. Check the other common causes: PCIe link width and generation (`nvidia-smi -q | grep -i "link"`),
   NVLink status (`nvidia-smi nvlink -s`), and ECC or Xid errors in `dmesg`.
3. Root cause: the rack's power budget was configured below the GPUs' rating, and the BMC capped every
   GPU.
4. Fix: correct the power policy. Add power limit, clock speed, and throttle reasons to the node
   acceptance test and to fleet dashboards.

The lesson: identical GPUs aren't identical in production. Power, cooling, firmware, and links must
be checked as part of accepting every node.

**5. What separates senior from staff answers:** a senior engineer estimates memory correctly and picks a
card that fits. A staff engineer turns it into a capacity model: cost per 1M tokens per chip, the
quantization decision backed by evaluation, peak-hour headroom and failure domains, a node-acceptance and
health process, and a plan for the next chip generation.

**Red flags:**
- Sizing by weights alone and forgetting the KV cache or activations.
- Citing `nvidia-smi` utilization as proof of efficiency.
- Benchmarks without warm-up or `torch.cuda.synchronize()`.
- Tensor parallelism across nodes over the network.
- Time-slicing GPUs for latency-critical production services.

---

## Quiz

<details><summary>1. What are the four numbers to know for any AI GPU, and which usually limits LLM decode?</summary>
Compute (TFLOPS at your precision), memory capacity, memory bandwidth, and interconnect bandwidth.
LLM decode at small batch sizes is usually limited by memory bandwidth, because each token reads all
the weights.
</details>

<details><summary>2. Why can `a @ b` appear to take 0.1 ms on a GPU when it really takes 20 ms?</summary>
CUDA launches are asynchronous: the call returns once the kernel is queued. You must call
`torch.cuda.synchronize()` before stopping the timer.
</details>

<details><summary>3. Estimate the memory for Llama 3 8B bf16 inference with 4 users at 8k context. (KV = 128 KiB per token.)</summary>
Weights 16 GB. KV = 4 × 8,192 × 128 KiB ≈ 4.3 GB. Plus ~1 GB + 10% overhead, about 23 GB in total. It fits
tightly on a 24 GB L4 or A10G, and comfortably on a 40 GB or 80 GB card.
</details>

<details><summary>4. Why does full fine-tuning need ~16 bytes per parameter?</summary>
bf16 weights (2) + bf16 gradients (2) + fp32 master weights (4) + Adam first moment (4) + Adam second
moment (4) = 16 bytes, before activations.
</details>

<details><summary>5. What does FlashAttention change, in memory-hierarchy terms?</summary>
It computes attention in tiles that stay in on-chip SRAM, instead of writing the full sequence × sequence
attention matrix to HBM. That cuts HBM traffic and memory use from quadratic to linear in sequence length.
</details>

<details><summary>6. Ring all-reduce of 14 GB of gradients on 8 GPUs: roughly how much data does each GPU send?</summary>
2 × (N − 1)/N × size = 2 × 7/8 × 14 ≈ 24.5 GB per step. That's ~68 ms at ~360 GB/s on NVLink, but over a
second on PCIe.
</details>

<details><summary>7. When should you use MIG instead of time-slicing?</summary>
When several production services need predictable latency and isolation on one GPU. MIG gives each
instance dedicated memory, compute, and fault isolation. Time-slicing shares everything and has no
memory isolation.
</details>

<details><summary>8. An 8B model trains at 3,500 tokens/s per H100 (989 TFLOPS bf16). What is the MFU, and is it good?</summary>
6 × 8×10⁹ × 3,500 ÷ 989×10¹² ≈ 17%. That's low. 35–55% is typical for a well-tuned LLM run, so profile the
data loading, communication overlap, and kernel efficiency.
</details>

## Failure modes
- Sizing GPUs from model weights alone, then running out of memory under real context lengths.
- Driver too old for the CUDA version inside the image ("CUDA driver version is insufficient").
- Benchmarks without warm-up or synchronization, or reporting averages instead of p95/p99.
- Treating `nvidia-smi` utilization at 100% as proof that the GPU is busy doing useful work.
- Multi-GPU training on PCIe-only servers, or tensor parallelism stretched across nodes.
- Power-capped, thermally throttled, or ECC-failing GPUs that silently slow whole jobs.
- Time-sliced GPUs shared by production services with latency SLOs.

## Checklist
- [ ] You can name the memory, bandwidth, and BF16 TFLOPS of a T4, L4, A100, and H100
- [ ] You can explain warps, kernels, streams, and why GPU calls are asynchronous
- [ ] You can list what fills GPU memory in inference and in training, and compute each part
- [ ] You know when NVLink matters and how to check the topology with `nvidia-smi topo -m`
- [ ] You can create MIG instances and request them from Kubernetes
- [ ] You can compute MFU and benchmark with warm-up, synchronization, and percentiles
- [ ] You ran the lab and compared measured peak memory with the estimate
- [ ] You ran `exercises/s07_gpu_memory_estimate.py` and can explain every line of its output
