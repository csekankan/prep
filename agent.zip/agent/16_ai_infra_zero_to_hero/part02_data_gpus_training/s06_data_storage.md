# Section 6 — Data Storage for AI

> Lectures 36–42 • Assessment: quiz + Build an Idempotent Data Ingestion Pipeline
> **After this section you can:** choose between a data lake, a warehouse, and a feature store; use S3 and
> GCS correctly and cheaply; pick the right database for each AI job; explain how Kafka and Pub/Sub carry
> real-time data; feed a GPU cluster fast enough that it never waits; lock data down with IAM and
> encryption; and build an ingestion pipeline that is safe to rerun.
>
> Go deeper: [13 / Lab 7 — Persistent volumes and data lakes](../../13_sovereign_ai_infra_course/01_foundations_local_sandbox/lab07_persistent_volumes_data_lakes.md),
> [13 / Lab 67 — MinIO HA](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab67_minio_ha.md),
> [13 / Lab 60 — Redis for AI](../../13_sovereign_ai_infra_course/05_sovereign_data_vector/lab60_redis_for_ai.md),
> [13 / Lab 33 — Distributed data loading](../../13_sovereign_ai_infra_course/03_distributed_training/lab33_distributed_data_loading.md).

## Section at a glance

| # | Lecture | One-line takeaway |
|---|---|---|
| 36 | Data lakes vs data warehouses vs feature stores | Lake = cheap raw storage, warehouse = clean tables for questions, feature store = the same features for training and serving |
| 37 | Object storage with AWS S3 and GCP GCS | The default home for AI data: cheap, durable, effectively unlimited, but not a file system |
| 38 | Relational vs NoSQL databases in AI | Pick the database by access pattern: transactions, key lookups, wide time series, or similarity search |
| 39 | Streaming data with Kafka and Pub/Sub | A durable, replayable log that turns events into real-time features |
| 40 | Scaling storage for AI training datasets | Big shards, local caches, and parallel reads keep GPUs busy. Millions of small files don't |
| 41 | Secure data access and encryption | Least-privilege identities, encryption with managed keys, and audit logs on every read |
| 42 | Lab: build a data ingestion pipeline | A pipeline that survives crashes, duplicates, bad rows, and late data |

```mermaid
flowchart LR
  subgraph SRC["Sources"]
    APP[App databases]
    EVT[Click and payment events]
    FILES[Partner files, images, docs]
  end
  subgraph ING["Ingestion"]
    BATCH[Batch loads<br/>hourly or daily]
    STREAM[Stream<br/>Kafka or Pub/Sub]
  end
  subgraph LAKE["Data lake on object storage"]
    RAW[(Raw / bronze<br/>as received)]
    CLEAN[(Clean / silver<br/>validated, deduplicated)]
    CUR[(Curated / gold<br/>business tables)]
  end
  APP --> BATCH
  FILES --> BATCH
  EVT --> STREAM
  BATCH --> RAW
  STREAM --> RAW
  RAW --> CLEAN --> CUR
  CUR --> WH[(Warehouse<br/>BI and analysts)]
  CUR --> FSO[(Feature store<br/>offline)]
  STREAM --> FSN[(Feature store<br/>online, ms reads)]
  CUR --> SHARDS[(Training shards<br/>Parquet, WebDataset)]
  SHARDS --> TRAIN[GPU training]
  FSO --> TRAIN
  FSN --> SERVE[Model serving]
```

**How to read it:** data enters on the left in two ways. Batch loads bring files and database snapshots
every hour or day. Streams bring events within seconds. Everything lands first in the **raw** zone of a
data lake, exactly as received, so you can always reprocess it. It is then cleaned and curated. From the
curated zone, three consumers read: analysts through a warehouse, training jobs through a feature store
and dataset shards, and the live model through an online feature store fed by the stream.

**Terms in this diagram.**
- **Batch loads** and **stream**: batch moves data in big chunks on a schedule. A stream moves each event as it
  happens. **Kafka** (open source) and **Pub/Sub** (Google Cloud) are the common streaming systems (Lecture 39).
- **Data lake on object storage**: all data kept as files in a bucket (S3, GCS), cheap and unlimited (Lecture 36).
- **Raw / bronze, clean / silver, curated / gold**: the three standard zones of a lake, also called the
  **medallion** layout. Bronze is the untouched copy. Silver is validated and **deduplicated** (duplicate records
  removed). Gold holds business-ready tables such as daily totals per customer or labeled training sets.
- **Warehouse, BI**: a **data warehouse** is a database built for fast analytical queries over clean tables.
  **BI** (business intelligence) means dashboards and reports for analysts.
- **Feature store offline / online**: a **feature** is an input value for a model (for example "payments by this
  card in the last hour"). The **offline** store keeps the full history for training. The **online** store keeps
  only the latest value per key, readable in milliseconds by the live model (Lecture 36).
- **Training shards, Parquet, WebDataset**: the training data split into many large files in training-friendly
  formats (Lecture 40).

---

## Lecture 36 — Data lakes vs data warehouses vs feature stores

**Why it matters.** Most "the model is worse in production" incidents are really data incidents: the
model was trained on features computed one way and served features computed another way. Choosing the
right store for each job, and connecting them properly, prevents a whole class of these failures.

**In plain words.** A **data lake** is a huge storage unit. You put everything in it in its original
boxes, cheaply, and sort it out later. A **data warehouse** is a shop with labeled shelves: everything is
cleaned, priced, and easy to find, but you must decide the layout up front. A **feature store** is a
restaurant's prep station: ingredients are pre-cut the same way for the cooks who are practicing
(training) and the cooks who are serving customers (inference).

**Architecture: the lakehouse with a feature store.**

```mermaid
flowchart TB
  subgraph OBJ["Object storage: S3 or GCS"]
    B[(Bronze: raw JSON, CSV, images)]
    S[(Silver: Parquet tables<br/>Iceberg or Delta format)]
    G[(Gold: aggregates,<br/>labels, training sets)]
  end
  B -->|Spark or dbt jobs| S -->|joins, aggregates| G
  CAT[Catalog<br/>schemas, versions, owners] -.describes.-> S & G
  G --> ENG[Query engines<br/>Trino, BigQuery, Snowflake]
  subgraph FS["Feature store, e.g. Feast"]
    DEF[Feature definitions<br/>one piece of code]
    OFF[(Offline store<br/>full history)]
    ON[(Online store<br/>latest value per key)]
  end
  DEF --> OFF
  DEF --> ON
  G --> OFF
  OFF -->|point-in-time join| TS[Training set]
  OFF -->|materialize latest| ON
  ON -->|"lookup by user_id, under 10 ms"| MS[Model server]
```

**How to read it:** the three lake zones are folders of open-format files in object storage. A **table
format** (Apache Iceberg, Delta Lake, or Hudi) adds a transaction log on top, so those files behave like
database tables, with schemas, atomic commits, and "time travel" to older versions. A **lakehouse** is a
lake with that table layer, so you don't need a separate warehouse copy for most queries. The feature
store sits beside it. One **feature definition** fills both the offline store (history, for training)
and the online store (latest value, for serving), so training and serving compute the feature the same
way.

**Terms in this diagram.**
- **Spark or dbt jobs**: **Apache Spark** is a distributed engine that processes huge datasets across many
  machines. **dbt** (data build tool) turns SQL `SELECT` statements into tested, versioned tables.
- **Catalog**: the lake's index of tables: their schemas (columns and types), versions, and owners. Examples are
  AWS Glue Data Catalog, Unity Catalog, and Hive Metastore.
- **Query engines: Trino, BigQuery, Snowflake**: tools that run SQL over the files. **Trino** is open source and
  queries files in place. **BigQuery** (Google) and **Snowflake** are managed cloud warehouses.
- **Feast**: a popular open-source feature store.
- **Point-in-time join**: building training rows using only the feature values that were known *at the moment*
  of each historical event. That prevents **leakage**, where a model trains on information from the future that
  won't exist at prediction time.
- **Materialize latest**: copy the newest value of each feature from the offline store into the online store.
- **Lookup by user_id, under 10 ms**: the model server fetches all features for one key (one user) in a single
  fast read.

**Core ideas.**

| | Data lake | Data warehouse | Feature store |
|---|---|---|---|
| Stores | Anything: raw files, logs, images, Parquet | Structured, cleaned tables | Model features keyed by entity (user, card, item) |
| Schema | On read: decide when you query | On write: enforced at load time | Defined once in code, versioned |
| Typical tools | S3/GCS + Iceberg/Delta, Spark | BigQuery, Snowflake, Redshift | Feast, Tecton, SageMaker / Vertex Feature Store |
| Main users | Data engineers, training pipelines | Analysts, dashboards | Training pipelines and model servers |
| Latency | Seconds to minutes | Seconds | Offline: minutes. Online: milliseconds |
| Cost | Lowest per TB | Higher (compute + managed storage) | Online store memory is the expensive part |

- **Point-in-time correctness.** When you build a training row for "did this user churn on
  1 March?", each feature must use only data known **before** 1 March. Otherwise the model learns from
  the future (*label leakage*) and looks brilliant offline but fails in production.
- **Training-serving skew.** The same feature computed by two different code paths, say SQL for
  training and Java in the serving app, will drift apart. A feature store removes the second path.
- Don't buy a feature store on day one. You need one once several models share features, or once one
  model needs fresh features at serving time.

A point-in-time ("as-of") join in SQL picks, for each label, the latest feature value from **before** the
label time:

```sql
SELECT l.user_id, l.label_time, l.churned,
       f.tickets_30d
FROM labels l
LEFT JOIN LATERAL (
  SELECT tickets_30d FROM user_features f
  WHERE f.user_id = l.user_id AND f.computed_at <= l.label_time
  ORDER BY f.computed_at DESC LIMIT 1
) f ON TRUE;
```

**Example: leakage that cost a quarter.** A churn model used `support_tickets_last_30d`, computed from
*today's* table for all historical labels. Customers who churned had filed angry tickets *after*
deciding to leave, so the feature leaked the answer. Offline AUC was 0.93, and production AUC was 0.71.
Rebuilding the training set with an as-of join dropped offline AUC to 0.82, which turned out to match
production almost exactly. The lower offline number was the honest one.

**Senior / FAANG best practice.** Keep raw data immutable and forever, within your retention policy,
so any table can be rebuilt. Use an open table format with snapshots, and have every training run
record the **snapshot ID** it read. Then "which data trained model v42?" has an exact answer. Define each
feature once, with an owner, and serve it to training and inference from the same definition.

---

## Lecture 37 — Object storage with AWS S3 and GCP GCS

**Why it matters.** Almost every AI dataset, checkpoint, and model artifact lives in object storage.
Used well, it is cheap and nearly indestructible. Used badly, it is slow (millions of tiny reads) or
surprisingly expensive (wrong storage class, cross-region traffic).

**In plain words.** Object storage is valet parking. You hand over the whole car (an object) and get a
ticket (a key like `datasets/v3/shard-0001.tar`). You can't open the trunk while it's parked and change
one bag: to change anything you hand over a new car. There are no real folders. The slashes in the key
are just part of the ticket number.

**Architecture: how a training job reads from a bucket.**

```mermaid
flowchart LR
  subgraph VPC["Your VPC, private subnet"]
    POD[Training pod<br/>IAM role via workload identity]
  end
  POD -->|"HTTPS GET, signed request"| EP[VPC gateway endpoint<br/>no NAT, no internet]
  EP --> S3[(Bucket: ml-data-prod<br/>versioning on<br/>block public access)]
  S3 --> KMS[KMS key<br/>decrypts data key]
  S3 --> LOG[(Access logs,<br/>CloudTrail data events)]
  subgraph LC["Lifecycle rules"]
    T1[Standard<br/>hot data] -->|after 30 days| T2[Infrequent access]
    T2 -->|after 180 days| T3[Archive<br/>Glacier, GCS Archive]
  end
  S3 -.-> LC
```

**How to read it:** the pod has no stored keys. It gets temporary credentials from its IAM role and
reaches the bucket through a private endpoint, so traffic never crosses the internet or a paid NAT
gateway. The bucket encrypts each object with a key protected by KMS, logs every access, and moves old
objects to cheaper tiers on a schedule.

**Terms in this diagram.**
- **Workload identity**: the link between a Kubernetes pod's ServiceAccount and a cloud IAM role, so the pod gets
  cloud permissions without stored keys (Section 5, entry H1).
- **HTTPS GET, signed request**: every S3 request is an HTTPS call. It's **signed**, meaning the client adds a
  cryptographic signature made with its temporary credentials, which proves who sent it and that nothing was
  changed in transit.
- **VPC gateway endpoint**: a free private route from your VPC to S3 or DynamoDB, so traffic skips the NAT gateway
  and the internet.
- **Versioning on**: S3 keeps every old version of an object, so an overwrite or delete can be undone.
- **Block public access**: an account and bucket setting that refuses any rule making data public, protecting
  against misconfiguration.
- **KMS key**: a master key in AWS KMS (Key Management Service), which never leaves KMS and is used to protect the
  per-object data keys (Lecture 41).
- **CloudTrail data events**: **CloudTrail** is AWS's audit log of API calls. **Data events** record each object
  read and write: who, what, when.
- **Lifecycle rules, Standard, Infrequent access, Glacier**: lifecycle rules move objects between **storage
  classes** automatically. Standard is for hot data. Infrequent Access is cheaper to store but charges per read.
  **Glacier** and GCS Archive are very cheap archives that take minutes to hours to restore.

**Core ideas.**

| Fact | S3 | GCS |
|---|---|---|
| Consistency | Strong read-after-write (since 2020) | Strong |
| Max object size | 5 TB (multipart upload, up to 10,000 parts) | 5 TiB |
| Throughput scaling | ≥ 3,500 writes and 5,500 reads per second **per prefix**, scales with more prefixes | Auto-scales. Ramp up gradually and avoid sequential key names |
| Storage classes | Standard, Intelligent-Tiering, Standard-IA, Glacier tiers | Standard, Nearline, Coldline, Archive |
| Protection | Versioning, Object Lock (WORM), replication | Object versioning, retention locks, dual/multi-region |
| Private access | VPC gateway or interface endpoint | Private Google Access, VPC Service Controls |

```bash
# upload a large file in parallel parts, then list it
aws s3 cp shard-0001.tar s3://ml-data-prod/datasets/v3/ --storage-class STANDARD
gcloud storage cp shard-0001.tar gs://ml-data-prod/datasets/v3/
# read only what you need: byte-range GET of the first 1 MB
aws s3api get-object --bucket ml-data-prod --key datasets/v3/shard-0001.tar --range bytes=0-1048575 head.bin
```

- **It is not a file system.** There is no rename (rename means copy then delete), no append, and
  listing millions of keys is slow. Write large immutable objects, and keep a manifest of what exists
  instead of listing the bucket.
- **Cheap classes have read fees.** Infrequent-access and archive tiers charge per GB retrieved and
  have minimum storage durations.
- FUSE mounts (Mountpoint for S3, Cloud Storage FUSE) make a bucket look like a folder. They work well
  for large sequential reads, and badly for many small random reads or in-place edits.

**Example: the "cheaper" storage class that cost more (illustrative list prices).** A team moved a
10 TB training dataset from Standard to Standard-IA to save money.

| | Standard | Standard-IA |
|---|---|---|
| Storage: 10,240 GB per month | × $0.023 = $236 | × $0.0125 = $128 |
| Retrieval: 5 full reads per month (51,200 GB) | $0 | × $0.01 = $512 |
| **Total per month** | **$236** | **$640** |

Hot training data belongs in Standard. Infrequent access is for data you really do read infrequently,
like last year's raw logs.

**Senior / FAANG best practice.** Turn on Block Public Access at the account level, plus versioning,
default KMS encryption, and lifecycle rules on every bucket, all through infrastructure as code. Use
separate buckets for separate sensitivity levels, because policies are easiest to reason about per
bucket. Put buckets in the same region as the GPUs that read them, reach them through VPC endpoints,
and alert on any cross-region or internet egress.

---

## Lecture 38 — Relational vs NoSQL databases in AI

**Why it matters.** An ML system usually needs several databases: one for metadata and labels, one for
millisecond feature lookups, maybe one for embeddings. Forcing all of these jobs into one database is a
common cause of slow serving and painful migrations.

**In plain words.** A **relational database** is a set of spreadsheets with strict columns and rules
that link them together. A **key-value store** is a coat check: hand over a ticket, get your coat back
instantly, and nothing else. A **document store** keeps whole forms in folders. A **wide-column store** is
a giant ledger built for a firehose of writes. A **vector database** is a librarian who finds "books
like this one".

**Architecture: which database does which job.**

```mermaid
flowchart TB
  subgraph META["Relational: PostgreSQL, MySQL, Cloud SQL"]
    EXP[(Experiments, model registry,<br/>labels, annotations, users)]
  end
  subgraph KV["Key-value: Redis, DynamoDB, Bigtable"]
    FEAT[(Online features<br/>user:123 to a feature vector)]
  end
  subgraph WIDE["Wide-column: Cassandra, Bigtable, ScyllaDB"]
    TS[(Event history,<br/>sensor time series)]
  end
  subgraph VEC["Vector: pgvector, Milvus, Qdrant, OpenSearch"]
    EMB[(Embeddings for RAG<br/>and recommendations)]
  end
  TRAINJ[Training pipeline] --> EXP
  TRAINJ --> TS
  API[Model API] -->|"1 to 5 ms lookup"| FEAT
  API -->|"top-k similar, 10 to 50 ms"| EMB
  API -->|log prediction| TS
  UI[Labeling tool] --> EXP
```

**How to read it:** each box is a different access pattern. Metadata needs joins and transactions, so it
is relational. Feature lookups need single-key reads in milliseconds at high traffic, so they use a
key-value store. Event history needs huge write rates, so it uses a wide-column store. Similarity search
needs special indexes, so it uses a vector store.

**Terms in this diagram.**
- **PostgreSQL, MySQL, Cloud SQL**: relational (SQL) databases with tables, joins, and transactions. Cloud SQL is
  Google's managed version.
- **Redis, DynamoDB, Bigtable**: key-value stores. **Redis** keeps data in memory for sub-millisecond reads.
  **DynamoDB** is AWS's managed key-value database. **Bigtable** is Google's managed wide-column database, also
  used as a key-value store.
- **Feature vector**: the list of feature values for one entity, for example the 40 numbers describing user 123.
- **Cassandra, ScyllaDB**: wide-column databases spread over many machines, built for very high write rates,
  such as event logs and sensor time series.
- **pgvector, Milvus, Qdrant, OpenSearch**: vector stores. **pgvector** adds vector search to PostgreSQL.
  **Milvus** and **Qdrant** are dedicated vector databases. **OpenSearch** is a search engine (a fork of
  Elasticsearch) with vector search built in.
- **Embeddings, RAG, top-k similar**: an **embedding** is a list of numbers that represents the meaning of a text
  or image, where similar items have nearby vectors. **RAG** (retrieval-augmented generation) retrieves relevant
  documents by embedding similarity and gives them to an LLM (Section 25). **Top-k** means the k closest matches.
- **Labeling tool**: an app where people attach correct answers (labels) to examples for training.

**Core ideas.**

| Type | Examples | Strong at | AI use | Watch out |
|---|---|---|---|---|
| Relational | PostgreSQL, MySQL, Aurora, Cloud SQL, Spanner | Transactions, joins, constraints | Registry, labels, metadata, small feature tables | Vertical scaling limits. Sharding is hard |
| Key-value | Redis, DynamoDB, Memorystore | Single-key reads in ~1 ms at huge scale | Online features, caches, rate limits, sessions | No ad-hoc queries. Design keys around reads |
| Document | MongoDB, Firestore | Flexible nested records | Prompt and conversation logs, configs | Schema drift. Weak multi-record transactions |
| Wide-column | Cassandra, Bigtable, ScyllaDB | Very high write rates, time-ordered rows | Event history, user activity, IoT | Model the queries first. No joins |
| Vector | pgvector, Milvus, Qdrant, Weaviate | Approximate nearest-neighbor search | RAG, semantic search, recommendations | Index memory, recall vs speed tuning (Section 25) |

- **Start from the access pattern**, not the brand: "read one user's 40 features by `user_id`, p99 under
  5 ms, at 20,000 requests per second" picks the database for you.
- **Postgres goes far.** With pgvector it handles millions of vectors, and with good indexes it handles
  thousands of queries per second. Add a specialized store when measurements say so.
- Distributed databases trade consistency for availability during network splits (the CAP theorem).
  For a feature lookup, slightly stale is fine. For a payment ledger, it is not.

**Example: moving online features out of Postgres.** A recommender read 60 features per request from
Postgres. At 3,000 requests per second, the p99 was 9 ms. When traffic grew to 25,000 per second, the p99
reached 120 ms, and the database CPU sat at 95%. Moving the online features to Redis, with one hash per
user written by the feature pipeline, brought the p99 to 2 ms. Postgres kept the training history and
metadata, the jobs it is good at.

**Senior / FAANG best practice.** Write down each store's access pattern, consistency need, and p99
target before choosing it, and load-test at 3× expected peak. Keep the online store a **derived** copy
that can be rebuilt from the offline store, never the only copy of anything. Big tech often uses one
managed key-value store, such as DynamoDB, Bigtable, or an internal one, for all online features, so
there is one thing to scale and monitor.

---

## Lecture 39 — Streaming data with Kafka and Pub/Sub

**Why it matters.** Fraud detection, recommendations, and dynamic pricing need features that are
seconds old, not a day old. Streaming systems also decouple producers from consumers: the checkout
service doesn't need to know that five ML pipelines read its events.

**In plain words.** A stream is a conveyor belt where every item gets a numbered position and stays on
the belt for days. Many teams can read the belt, each keeping its own bookmark (an **offset**). If a
reader crashes, it restarts from its bookmark. If a reader has a bug, it rewinds and reads again.

**Architecture: real-time features from a stream.**

```mermaid
flowchart LR
  CHK[Checkout service] -->|"key = card_id"| T
  APPS[Mobile and web apps] -->|"key = user_id"| T2
  subgraph K["Kafka cluster or Pub/Sub"]
    T[Topic: payments<br/>partitions 0 to 11]
    T2[Topic: clicks]
  end
  T --> FL[Stream processor<br/>Flink, Spark, Dataflow<br/>consumer group: fraud-features]
  T --> SINK[Lake sink<br/>consumer group: archiver]
  T2 --> FL
  FL -->|"txn_count_10m, avg_amount_1h"| ON[(Online feature store)]
  SINK --> RAW[(Lake raw zone<br/>Parquet every 5 minutes)]
  ON --> FRAUD[Fraud model API]
```

**How to read it:** producers write events to a **topic**, which is split into **partitions** for
parallelism. Events with the same key, such as one card, always go to the same partition, so they stay
in order. Each **consumer group** reads independently: the stream processor computes rolling features
for the online store, while the archiver writes the same events to the lake for training. One stream
feeds both serving and training, which keeps them consistent.

**Terms in this diagram.**
- **Producer** and **key = card_id**: the checkout service is a **producer** (it writes events). The **key**
  decides the partition, so all events for one card land in the same partition, in order.
- **Stream processor: Flink, Spark, Dataflow**: programs that compute results continuously over events.
  **Apache Flink** is the leading open-source one. **Spark** Structured Streaming is Spark's streaming mode.
  **Dataflow** is Google's managed service for Apache Beam pipelines.
- **txn_count_10m, avg_amount_1h**: example rolling features: the number of transactions in the last 10 minutes,
  and the average amount over the last hour.
- **Lake sink**: a consumer that copies events from the topic into files in the lake, here as Parquet every 5
  minutes.

**Core ideas.**

| Concept | Meaning |
|---|---|
| Partition | An ordered, append-only log. The unit of parallelism and ordering |
| Offset | An event's position in a partition. Consumers commit offsets as bookmarks |
| Consumer group | Consumers that share the work. Each partition goes to one consumer in the group |
| Retention | How long events stay (for example 7 days), so you can replay them |
| Delivery semantics | At-most-once (may lose), at-least-once (may duplicate), exactly-once (transactions plus idempotent writes) |

| | Apache Kafka (or MSK, Confluent) | Google Pub/Sub |
|---|---|---|
| Model | Partitioned log you size and operate | Fully managed. No partitions to manage |
| Ordering | Per partition | Per ordering key, when enabled |
| Replay | Seek to any offset within retention | Seek to a timestamp or snapshot |
| Operations | Brokers, partitions, rebalancing (managed services help) | None. Pay per message volume |
| Pick when | High throughput, ecosystem (Kafka Connect, Flink), multi-cloud | You're on GCP and want zero operations |

- **Plan for duplicates.** At-least-once delivery is the practical default, so every consumer must be
  idempotent: upsert by event ID, or keep a set of processed IDs (the lab does this for files).
- **Event time is not arrival time.** Mobile events can arrive minutes late. Stream processors use
  *watermarks* to decide when a time window is complete.
- The **outbox pattern** stops a service from saving to its database but failing to publish the event.
  The service writes the event into an outbox table in the same transaction, and a relay publishes it.

**Example: sizing a payments topic.** 50,000 events per second × 1 KB = 50 MB/s in.
- Partitions: if one consumer handles ~5 MB/s of feature computation, you need at least 10. Choose 24 to
  leave room to grow, because adding partitions later reshuffles which partition a key goes to.
- Storage for 7 days of retention: 50 MB/s × 604,800 s ≈ 30 TB, × 3 replicas ≈ 90 TB of broker disk.
- If the fraud feature `txn_count_10m` is computed from this stream, model decisions reflect activity
  from seconds ago, instead of last night's batch.

**Senior / FAANG best practice.** Every topic gets a **schema** in a schema registry (Avro or Protobuf),
with compatibility rules enforced in CI, so a producer can't break consumers by renaming a field.
Monitor **consumer lag** in seconds, not messages, and alert on it: lag is how fresh your features
really are. Keep enough retention to replay a full day after a bad deploy.

---

## Lecture 40 — Scaling storage for AI training datasets

**Why it matters.** A GPU that waits for data is the most expensive idle machine in the building. At
scale, storage throughput, not GPU speed, often sets how fast training goes, and checkpoint writes can
stall the whole cluster.

**In plain words.** Feeding a training cluster is like feeding a stadium. One food stand with a long
line (one server, millions of tiny files) leaves everyone hungry. Pre-packed meal boxes (big shards),
handed out at many counters at once (parallel reads), with a snack bar in every row (a local cache),
keep everyone eating.

**Architecture: the data path from bucket to GPU.**

```mermaid
flowchart LR
  subgraph OS["Object storage"]
    SH[(Dataset as shards<br/>1,000 files of ~1 GB<br/>Parquet, WebDataset tar, MDS)]
    MAN[manifest.json<br/>shard list + checksums]
  end
  subgraph NODE["Each training node, 8 GPUs"]
    NV[(Local NVMe cache<br/>3 to 30 TB)]
    W1[Loader worker 1]
    W2[Loader worker 2]
    WN[Loader worker N]
    PIN[Pinned memory<br/>prefetch queue]
    GPU[GPUs 0 to 7]
  end
  MAN --> W1
  SH -->|"parallel range GETs,<br/>first epoch"| NV
  NV --> W1 & W2 & WN
  W1 & W2 & WN -->|decode, augment| PIN --> GPU
  GPU -->|"checkpoint, async"| CK[(Checkpoints<br/>object storage)]
```

**How to read it:** the dataset is stored as about a thousand large shards plus a manifest. Each node
reads the shards assigned to it in parallel, keeps them on local NVMe after the first epoch, and runs
several loader workers that decode and augment the samples. The workers fill a prefetch queue in
pinned memory, so the GPU always has the next batch ready. Checkpoints flow the other way, written in
the background.

**Terms in this diagram.**
- **Parquet, WebDataset tar, MDS**: three shard formats. Parquet is for tables, WebDataset packs samples into
  `.tar` files, and **MDS** is the format of MosaicML Streaming, a library for streaming training data.
- **manifest.json, checksums**: a list of every shard with its size and checksum (a hash of its bytes), so loaders
  know what to read and can detect a corrupt or partial file.
- **Local NVMe cache**: the node's own fast SSDs, used to keep shards after the first download.
- **Parallel range GETs**: many simultaneous HTTP requests, each fetching one byte range of a large object, which
  together reach much higher throughput than one request.
- **Epoch**: one full pass over the training dataset.
- **Loader worker, decode, augment**: worker processes (PyTorch DataLoader workers) that **decode** samples (for
  example JPEG to pixels) and **augment** them (random crops and flips that make the model more robust).
- **Pinned memory, prefetch queue**: **pinned** (page-locked) CPU memory can be copied to the GPU faster and in
  the background. The **prefetch queue** holds the next few ready batches.
- **Checkpoint, async**: saving the model in the background while training continues, so the GPUs don't wait for
  the upload.

**Core ideas.**
- **Small files kill throughput.** Each object read costs a request round trip of about 10–50 ms. Ten
  million 100 KB images means ten million requests per epoch. The same data packed into 1 GB shards
  needs about a thousand large, sequential reads.
- **Formats:** Parquet for tabular data and text, WebDataset tar shards or MosaicML MDS for images and
  audio, and TFRecord in TensorFlow shops. All of them support streaming and shuffling across shards.
- **Shuffle in two levels:** shuffle the shard order each epoch, plus a buffer of samples within
  shards. That is close enough to a global shuffle for most models.

| Option | Throughput | Best for | Watch out |
|---|---|---|---|
| Read straight from object storage | High in aggregate, if parallel and sharded | Most training jobs | Small files and listing |
| Object storage + local NVMe cache | Very high after the first epoch | Multi-epoch jobs that fit on node disks | Cache warm-up time. Disk is lost with the node |
| Managed parallel file system (FSx for Lustre, GCP Parallelstore, Filestore) | Very high, POSIX | Many small files you can't repack, shared scratch | Cost per TB-month, sizing for throughput |
| Self-managed parallel FS (Lustre, GPFS, Weka, VAST) | Highest | Large on-prem clusters | Needs a storage team |

**Example: the throughput math for two workloads.**

| Workload | Calculation | Read bandwidth needed |
|---|---|---|
| Image training: 64 A100s × ~2,500 images/s each × ~110 KB per image | 160,000 images/s × 110 KB | **~17.6 GB/s** |
| LLM pre-training: 1,024 GPUs × ~3,000 tokens/s each × 4 bytes per token | 3.1M tokens/s × 4 B | **~12 MB/s** |
| LLM checkpoint: 70B parameters × 16 bytes (weights + optimizer), written in 5 minutes | 1.1 TB ÷ 300 s | **~3.7 GB/s of writes** |

Image and video training are limited by reads. LLM training reads almost nothing, but its checkpoints
are huge bursts of writes. A team whose image job sat at 35% GPU utilization repacked 10M small JPEGs
into 1,000 WebDataset shards and added a node-local cache. Utilization rose to 92%, and the epoch time fell
from 41 minutes to 16.

**Senior / FAANG best practice.** Measure the data path on its own first: run the loader without the
model and check that it delivers more samples per second than the GPUs consume, with ~30% headroom.
Store datasets as immutable, versioned shard sets with a manifest. Write checkpoints asynchronously and
sharded (each GPU writes its own part), so a 1 TB checkpoint doesn't freeze training for minutes.

---

## Lecture 41 — Secure data access and encryption

**Why it matters.** Training data often contains personal, financial, or proprietary information.
Leaked buckets are among the most common cloud breaches, and regulators ask where personal data went,
including into which models.

**In plain words.** Think of an office building. Every person wears a badge that opens only the floors
they need (least privilege). Sensitive files sit in locked cabinets (encryption at rest). Documents are
carried between floors in sealed envelopes (encryption in transit). The keys to the cabinets live in
a guarded key room, never taped to the cabinets (a key management service). Cameras record who opened
what (audit logs).

**Architecture: envelope encryption and access checks on every read.**

```mermaid
sequenceDiagram
  participant Job as Training job (IAM role)
  participant S3 as Object storage
  participant IAM as IAM policy check
  participant KMS as Key management service
  participant Log as Audit log
  Job->>S3: GET datasets/pii/part-001.parquet over TLS
  S3->>IAM: Is this role allowed to read this prefix?
  IAM-->>S3: Allowed, condition: request via VPC endpoint
  S3->>KMS: Decrypt this object's data key
  KMS->>KMS: Role allowed to use this key?
  KMS-->>S3: Plaintext data key, in memory only
  S3-->>Job: Decrypted object over TLS
  S3->>Log: Who, what, when, from where
  KMS->>Log: Key used by whom
```

**How to read it:** each object is encrypted with its own **data key**. That data key is itself encrypted
by a master key that never leaves the key management service (this is **envelope encryption**). A read
needs two permissions: one to read the object, and one to use the key. Both decisions are logged. Even a
leaked copy of the raw disk is useless without the key, and access to the key can be revoked.

In the diagram, **TLS** is the encryption that protects data while it travels over the network (the "S" in
HTTPS). `datasets/pii/` is a **prefix**, the folder-like start of object names that policies can target. **PII**
means personally identifiable information. The **plaintext data key** is the unencrypted key, held only in
memory just long enough to decrypt the object.

**Core ideas.**

| Layer | What to do | Tools |
|---|---|---|
| Identity | No long-lived keys. Workloads get short-lived credentials from their role | IAM roles, IRSA, GCP Workload Identity |
| Authorization | Least privilege per prefix, conditions on network and tags | Bucket policies, IAM conditions, VPC Service Controls |
| At rest | Default encryption with customer-managed keys for sensitive data | SSE-KMS, Cloud KMS CMEK |
| In transit | TLS everywhere. Deny non-TLS requests | `aws:SecureTransport` condition |
| Data minimization | Remove or tokenize PII before it reaches training | DLP scanners, tokenization services |
| Audit | Log data access, not just admin actions | CloudTrail data events, Cloud Audit Logs |

A least-privilege policy for a training role allows reading one dataset prefix, through one VPC endpoint,
and nothing else:

```json
{
  "Effect": "Allow",
  "Action": ["s3:GetObject"],
  "Resource": "arn:aws:s3:::ml-data-prod/datasets/fraud/v7/*",
  "Condition": { "StringEquals": { "aws:SourceVpce": "vpce-0abc123" } }
}
```

- **Encryption at rest doesn't stop a user who has permission.** Most breaches use valid credentials
  with too many permissions. Least privilege matters more than ciphers.
- **Deletion requests reach models.** When a user asks to be deleted, you must find their rows in raw,
  clean, and feature data. Lineage (which snapshot fed which model) decides whether you also need to
  retrain.
- Separate duties: the people who manage keys shouldn't be the people who read the data.

**Example: the role that could read everything.** A security review found that the training job's role
had `s3:*` on `*`, copied from a tutorial. A compromised notebook using that role could have read HR
data, finance exports, and every other team's datasets. The fix scoped the role to `GetObject` on two
dataset prefixes, required the VPC endpoint, moved PII columns to a separate KMS key that only the
feature pipeline can use, and added an alert for any access from outside the VPC.

**Senior / FAANG best practice.** Classify data (public, internal, confidential, restricted) and map each
class to a bucket, a key, and an access process. Grant access to restricted data through time-bound,
approved requests, not standing permissions. Run automated checks continuously for public buckets,
wildcard policies, and unencrypted stores. Treat a trained model as derived data with the same
sensitivity as the data it learned from.

---

## Lecture 42 — Lab: build a data ingestion pipeline

**Goal:** build and break an ingestion pipeline that loads CSV order files from a landing folder into a
database table, and prove that it is **idempotent**: crashes, reruns, resent files, bad rows, and late
data never create duplicates or lose good data.

**What you're building.**

```mermaid
flowchart LR
  LAND[(Landing folder<br/>CSV files arrive)] --> HASH{"SHA-256 of file<br/>already in manifest?"}
  HASH -->|yes| SKIP[Skip the file]
  HASH -->|no| TX[Begin transaction]
  TX --> VAL{"Row valid?"}
  VAL -->|no| Q[(quarantine table<br/>row + reason)]
  VAL -->|yes| UP["Upsert by order_id<br/>newer updated_at wins"]
  UP --> ORD[(orders table)]
  Q --> COMMIT
  ORD --> COMMIT[Record file in manifest<br/>then commit]
  COMMIT --> MANI[(ingested_files)]
```

**How to read it:** each file is checked against a manifest of file hashes, so the same bytes are never
loaded twice, even under a new name. Inside one transaction, every row is validated: bad rows go to
quarantine, and good rows are upserted by their natural key. The file is recorded in the manifest in the
same transaction, so it is either fully loaded and recorded, or not loaded at all.

In the diagram, **SHA-256** is a hash function: it turns a file's bytes into a 64-character fingerprint, and any
change to the file changes the fingerprint. A **transaction** groups several database writes so they all
succeed or all fail together. **Upsert** means "update the row if it exists, insert it if not". **Newer
updated_at wins** means that if the same order arrives twice, the version with the later timestamp is kept. The
**quarantine table** holds rejected rows with the reason, for a human to review.

**In plain words.** It's a mailroom that stamps every envelope it opens, so it never processes the same
letter twice. It files each letter under the customer's number, keeping only the newest version, and puts
unreadable letters in a separate tray instead of shutting down.

### Step 1 — Run the demo

```bash
python3 exercises/s06_idempotent_ingest.py
```

The script creates four sample files in a temporary folder:
- a day of orders with one bad amount;
- the next day's orders, with an update to order `o-1002`, a missing ID, and an unknown currency;
- a late replay with an old version of `o-1002` and a newer correction to `o-1001`;
- an exact resend of the first file under a new name.

It then runs three times. The first run crashes on purpose halfway through the second file.

### Step 2 — Read the output

| Run | What happens | What it proves |
|---|---|---|
| 1 | The first file loads, then a crash rolls back the second file | No half-loaded files |
| 2 | The rerun skips file 1, loads files 2 and 3, and skips the resend | Restarts are safe. Duplicate files are detected by content |
| 3 | Everything is skipped. Counts are identical | Running twice equals running once |

### Step 3 — Inspect the database

Run it on a real folder, so the database stays on disk:

```bash
mkdir -p /tmp/landing && cp my_orders.csv /tmp/landing/     # header: order_id,customer_id,amount,currency,updated_at
python3 exercises/s06_idempotent_ingest.py --landing /tmp/landing --db /tmp/wh.db
sqlite3 /tmp/wh.db "SELECT * FROM quarantine;"
sqlite3 /tmp/wh.db "SELECT name, rows_ok, rows_bad FROM ingested_files;"
```

### Step 4 — Break it on purpose

1. Copy a file to a new name and rerun. It is skipped (same hash).
2. Edit one amount in an already-loaded file and rerun. It is a new file (new hash), so it loads. The
   upsert changes that order only if its `updated_at` is newer. This is why the natural key, not the file,
   decides what the truth is.
3. Add a row with `amount=-5` and rerun. It lands in quarantine, and the rest of the file still loads.

### Step 5 (optional) — Land files in S3-compatible storage

Run MinIO locally (`docker run -p 9000:9000 minio/minio server /data`), upload files under
`landing/dt=2026-11-12/`, and adapt the script to download new objects before ingesting. The manifest
logic stays the same: object storage plus a content hash is how production pipelines detect new data.

**Expected results:** after Run 1, there is 1 file in the manifest and 3 orders. After Runs 2 and 3, there
are 3 files in the manifest, 5 unique orders, $252.59 of revenue, and 3 quarantined rows. All 8
checks print `PASS`, `o-1002` holds the newer 18.00, and `o-1001` holds the corrected 44.99.

---

## Assessment — Build an idempotent data ingestion pipeline

**Task.** Design and implement a pipeline that loads daily order files from a landing zone into a table.
It must satisfy all of these requirements:
1. Rerunning it after success changes nothing.
2. Rerunning it after a crash completes the job, with no duplicates.
3. A file resent under a new name is not loaded twice.
4. Late, out-of-order updates never overwrite newer data.
5. Bad rows don't fail the batch, and are kept with a reason.
6. You can answer "which file did this row come from?".

**Model answer.** The runnable solution is
[`exercises/s06_idempotent_ingest.py`](../exercises/s06_idempotent_ingest.py).

| Requirement | Technique | Where in the code |
|---|---|---|
| Rerun changes nothing | File manifest keyed by SHA-256 | `ingested_files` table, checked before loading |
| Crash safety | One transaction per file, including the manifest row | `with db:` block in `ingest_file` |
| Resent files | Hash the content, not the name | `hashlib.sha256(data)` |
| Late data | Upsert with `WHERE excluded.updated_at > orders.updated_at` | `UPSERT` SQL |
| Bad rows | Validate each row, insert failures into quarantine | `validate` and the `quarantine` table |
| Lineage | Store `source_file` on each row | `orders.source_file` |

The core of the late-data rule is one SQL statement:

```sql
INSERT INTO orders (order_id, customer_id, amount_cents, currency, updated_at, source_file)
VALUES (?, ?, ?, ?, ?, ?)
ON CONFLICT(order_id) DO UPDATE SET
  amount_cents = excluded.amount_cents, updated_at = excluded.updated_at, source_file = excluded.source_file
WHERE excluded.updated_at > orders.updated_at;
```

**How it maps to production.** In a real platform, the landing folder is an S3 or GCS prefix. The
manifest is a table, or the table format's own commit log (Iceberg and Delta record which files were
committed). The transaction is an atomic table commit. Quarantine is a "dead-letter" table with alerts
when its row count spikes. Money is stored as integer cents, never floats.

---

## FAANG deep-dive notes

**How big tech does it.** Data platforms are layered: immutable raw data in object storage, open table
formats with snapshots, a catalog with owners and schemas, data contracts between producing and consuming
teams, and quality checks that block bad data before it reaches training. Every training run records
the exact snapshot it read. Real-time features come from the same event stream that is archived for
training, so serving and training see the same history.

**Staff review questions.**
- If a source sends corrupted data for 6 hours, how do we detect it, stop it, and rebuild what it touched?
- Which model versions were trained on data from a user who just asked to be deleted?
- What is the freshness of each online feature, and who gets paged when it goes stale?
- What does our storage cost per TB per month by tier, and how much is never read?

**Interview question.** "Design the data platform for a real-time fraud model."

**Typical system-design prompt:** *Design the data platform that feeds both training and real-time features
for a fraud model at a payments company processing 20,000 transactions per second, with a 50 ms budget
for the feature lookup.*

**1. Clarify first:** What latency does the fraud decision have in total? How fresh must features be
(seconds or hours)? How many features, and over what windows? How far back does training need data? What
are the PII and regional compliance rules (PCI DSS for card data)? How quickly do labels (chargebacks)
arrive? Usually it takes weeks.

**2. Back-of-envelope sizing:**
- Events: 20,000/s × 1 KB = 20 MB/s ≈ 1.7 TB/day raw, or ~0.3 TB/day as compressed Parquet.
- Two years of history: ~0.3 TB × 730 ≈ 220 TB in the lake. That's cheap in object storage (~$5,000/month in Standard).
- Online store: 200M cards × 50 features × 8 bytes ≈ 80 GB, plus overhead ≈ 150–200 GB. It fits in a
  Redis cluster or a DynamoDB table.
- Lookups: 20,000/s at p99 under 5 ms leaves most of the 50 ms budget for the model.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Feature freshness | Batch (hourly or daily) | Streaming (seconds) | Stream only the features where freshness measurably lifts accuracy, like velocity counts |
| Storage layout | Warehouse copy of everything | Lakehouse on open formats | Lakehouse as the source of truth. Warehouse for BI-heavy teams |
| Online store | Redis (memory, fastest) | DynamoDB or Bigtable (managed, larger) | Memory for small, hot sets. Managed key-value stores for large, durable ones |
| Ingestion guarantee | At-least-once + idempotent writes | Exactly-once transactions | At-least-once + idempotency: simpler, and survives replays |
| Backfills | Recompute from raw | Patch derived tables in place | Always recompute from immutable raw data |

**4. Follow-up questions with crisp answers:**
- *How do you avoid training-serving skew?* One feature definition feeds both stores. Point-in-time
  joins for training. Log the features actually served, and compare their distribution with training.
- *Labels arrive 60 days late. Now what?* Train on windows whose labels have matured. Use the served
  feature logs for training, so features match what the model actually saw.
- *How do you reprocess after a bug?* Fix the code, recompute from raw into a new table snapshot,
  validate the counts, then atomically switch readers to the new snapshot.

**Debug this (common onsite question):** "Two training runs on the 'same' dataset produced different row
counts, and the model metrics differ."
1. Check what each run read: both used `SELECT * FROM transactions WHERE dt <= '2026-10-31'`, not a
   fixed snapshot.
2. Check the table history: a late-arriving backfill committed between the two runs and added rows for
   October.
3. Confirm it: the count difference equals the number of rows in that commit.
4. Fix: every run pins a table snapshot ID (Iceberg and Delta support time travel). The training metadata
   records the snapshot, and the pipeline refuses to run on an unpinned table.

The lesson: a dataset is defined by an immutable snapshot, not by a query over a table that keeps
changing.

**5. What separates senior from staff answers:** a senior engineer builds pipelines that are correct,
idempotent, and fast enough. A staff engineer designs for the whole lifecycle: data contracts with
producers, lineage from source rows to model versions, deletion and retention, freshness SLOs with
owners, reprocessing as a routine operation, and a storage-cost model per tier and per team.

**Red flags:**
- Training on a mutable table with no snapshot or version recorded.
- Two code paths computing the same feature for training and serving.
- Pipelines that only work if they run exactly once.
- Millions of tiny files fed straight into GPU training.
- Wildcard IAM on data buckets, or long-lived access keys in notebooks.

---

## Quiz

<details><summary>1. Name one job each for a data lake, a data warehouse, and a feature store.</summary>
Lake: keep raw and cleaned data cheaply in open formats, so it can be reprocessed. Warehouse: fast SQL
over clean tables for analysts and dashboards. Feature store: serve the same feature definitions to
training (history) and to live models (latest value, in milliseconds).
</details>

<details><summary>2. What is label leakage, and how does a point-in-time join prevent it?</summary>
Leakage is when training features include information from after the moment the label was decided,
so the model "sees the future". A point-in-time join picks, for each label, only feature values computed
at or before the label time.
</details>

<details><summary>3. Why can moving hot training data to S3 Standard-IA increase cost?</summary>
Infrequent-access tiers charge per GB retrieved. A dataset read several times a month pays retrieval fees
that exceed the storage savings.
</details>

<details><summary>4. A model API needs 40 features per user in under 5 ms at 20,000 requests per second. Which database type, and why?</summary>
A key-value store (Redis, DynamoDB, Bigtable) with one record per user. It is built for single-key
reads at very high rates and low latency. A relational database would need heavy scaling for the same
pattern.
</details>

<details><summary>5. What do partitions, offsets, and consumer groups do in Kafka?</summary>
Partitions split a topic into ordered logs for parallelism, and keep per-key ordering. Offsets are each
consumer's bookmark in a partition. Consumer groups let several consumers share partitions, while
different groups read the same data independently.
</details>

<details><summary>6. Your image training job runs at 35% GPU utilization, reading 10M small JPEGs from object storage. What do you change first?</summary>
Repack the images into large shards (WebDataset or similar, ~1 GB each). Read them in parallel with
enough loader workers and prefetching, and cache them on local NVMe. Measure loader throughput on its
own to confirm it exceeds GPU demand.
</details>

<details><summary>7. What is envelope encryption?</summary>
Data is encrypted with a data key, and the data key is encrypted with a master key held in a key
management service. Reading needs permission to use the master key, so access can be centrally
controlled, audited, and revoked.
</details>

<details><summary>8. What makes an ingestion pipeline idempotent? Name three techniques.</summary>
A manifest of processed files keyed by content hash, upserts by natural key (with newer-wins for late
data), and one atomic transaction per file that includes the manifest entry. Quarantining bad rows keeps
a few bad records from failing the whole batch.
</details>

## Failure modes
- Training on a mutable table without a pinned snapshot, so results can't be reproduced.
- Label leakage from features computed "as of today" for historical labels.
- Features computed differently in training and serving code (training-serving skew).
- Millions of small files starving GPUs, or listing a bucket to find work.
- Wrong storage class with retrieval fees, or data in a different region from the GPUs.
- Pipelines that double-load on rerun, or fail a whole day's batch because of one bad row.
- Wildcard IAM policies, public buckets, or PII copied into every derived dataset.
- Consumer lag growing unnoticed, so the "real-time" features are hours old.

## Checklist
- [ ] You can explain lake vs warehouse vs feature store and draw how data flows between them
- [ ] You can write a point-in-time join and explain why it prevents leakage
- [ ] Your buckets have versioning, encryption, lifecycle rules, and block public access
- [ ] You chose each database by its access pattern and p99 target
- [ ] You can size a Kafka topic (partitions and retention) from an event rate
- [ ] You can compute the read bandwidth a training job needs, and you know where checkpoints go
- [ ] Your training role has least-privilege, prefix-scoped access through a private endpoint
- [ ] You ran `exercises/s06_idempotent_ingest.py`, and all 8 checks pass
