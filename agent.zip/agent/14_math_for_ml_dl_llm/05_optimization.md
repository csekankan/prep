# 05 — Optimization: Making the Loss Go Down

> **Why it matters:** every model — from linear regression to a 70B-parameter LLM — is trained
> by an optimizer that repeatedly nudges weights against the gradient. The choice of optimizer,
> learning rate, and schedule often matters more than architecture tweaks.

## 1. The setup

Find weights $\theta$ minimizing the average loss over data:

$$
\theta^* = \arg\min_\theta \; \frac{1}{N}\sum_{i=1}^{N} \ell(f_\theta(x_i), y_i)
$$

Common losses:

| Task | Loss | Formula |
|---|---|---|
| Regression | Mean squared error | $\frac{1}{N}\sum (y - \hat{y})^2$ |
| Binary classification | Binary cross-entropy | $-[y\log\hat{p} + (1-y)\log(1-\hat{p})]$ |
| Multi-class / next token | Cross-entropy | $-\log \hat{p}_y$ |
| Embeddings / retrieval | Contrastive (InfoNCE) | $-\log \frac{e^{s(q,d^+)/\tau}}{\sum_j e^{s(q,d_j)/\tau}}$ |

## 2. Gradient descent

$$
\theta \leftarrow \theta - \eta\,\nabla_\theta \mathcal{L}(\theta)
$$

```python
import numpy as np
# Fit y = 3x + 2 with gradient descent on MSE
rng = np.random.default_rng(0)
X = rng.uniform(-1, 1, 200); y = 3 * X + 2 + rng.normal(0, 0.1, 200)
w, b, lr = 0.0, 0.0, 0.1
for step in range(500):
    y_hat = w * X + b
    grad_w = 2 * np.mean((y_hat - y) * X)
    grad_b = 2 * np.mean(y_hat - y)
    w -= lr * grad_w; b -= lr * grad_b
print(round(w, 2), round(b, 2))   # ≈ 3.0, 2.0
```

> **In plain English:** guess, measure the error, nudge the guess in the direction that reduces the
> error, repeat. **Example:** the code above starts at $w = 0, b = 0$ (a flat line), sees the line is too
> low and too flat, and nudges both up a little — 500 times — until it lands on $w ≈ 3, b ≈ 2$.

**Learning rate $\eta$:** too small → painfully slow; too large → oscillates or diverges (loss
becomes NaN). It is the single most important hyperparameter. *Plain English:* walking downhill
with baby steps takes forever; with giant leaps you jump right over the valley onto the opposite slope.

## 3. Stochastic & mini-batch gradient descent (SGD)

Computing the gradient on all $N$ examples is too expensive. Instead, estimate it on a random
**mini-batch** of size $B$:

$$
\nabla \mathcal{L} \approx \frac{1}{B}\sum_{i \in \text{batch}} \nabla \ell_i
$$

*Plain English:* to learn what 1 million customers think, survey 64 random ones, act on it, then
survey 64 more. Each survey is a bit off, but you improve thousands of times faster than waiting for
the full census each time.

The estimate is noisy but unbiased; the noise even helps escape sharp minima. One pass over the
dataset = one **epoch**. LLM pretraining usually sees most data roughly once.

## 4. Momentum

Accumulate a running direction so the optimizer rolls through noise and small bumps:

$$
v \leftarrow \beta v + \nabla \mathcal{L}, \qquad \theta \leftarrow \theta - \eta v \qquad (\beta \approx 0.9)
$$

*Plain English:* a ball rolling downhill builds up speed in a consistent direction and isn't knocked
off course by every small bump.

## 5. Adam and AdamW — the default for deep learning

**The lineage that leads to Adam:**
- **AdaGrad:** accumulate $G \mathrel{+}= g^2$ and step $\eta\,g/(\sqrt{G}+\epsilon)$. Rarely-updated parameters get
  larger steps (great for sparse features), but $G$ only grows, so the learning rate decays toward zero on long runs.
- **RMSProp:** replace the sum with a moving average $v = \rho v + (1-\rho)g^2$, so old history is forgotten and
  the step size stays alive.
- **Adam** = RMSProp + momentum + bias correction.

Adam keeps two exponential moving averages per parameter: the gradient (first moment $m$) and the
squared gradient (second moment $v$), so each parameter gets its own adaptive step size.

$$
m_t = \beta_1 m_{t-1} + (1-\beta_1) g_t, \qquad v_t = \beta_2 v_{t-1} + (1-\beta_2) g_t^2
$$
$$
\hat{m}_t = \frac{m_t}{1-\beta_1^t}, \quad \hat{v}_t = \frac{v_t}{1-\beta_2^t}, \qquad
\theta_t = \theta_{t-1} - \eta \frac{\hat{m}_t}{\sqrt{\hat{v}_t} + \epsilon}
$$

> **In plain English:** Adam gives every weight its own personal step size. $m$ remembers "which way
> have I been pushed lately?", $v$ remembers "how big/noisy are my pushes usually?". Dividing one by
> the other means a weight that gets huge, jittery gradients takes careful steps, while a weight that
> rarely gets a signal takes a relatively bigger step when it finally does.
>
> **Example:** in an LLM, the embedding for a common word like "the" gets a gradient on almost every
> batch; the embedding for a rare word like "photosynthesis" gets one occasionally. Plain SGD would
> barely train the rare word; Adam scales its step up so it still learns.

Typical values: $\beta_1 = 0.9$, $\beta_2 = 0.999$ (LLMs often use $0.95$), $\epsilon = 10^{-8}$.
The $1-\beta^t$ terms correct the bias from initializing $m, v$ at zero.

**AdamW** applies weight decay directly to the weights ($\theta \leftarrow \theta - \eta\lambda\theta$)
instead of mixing it into the gradient. It is the standard optimizer for transformers.

```python
def adam_step(theta, g, m, v, t, lr=1e-3, b1=0.9, b2=0.999, eps=1e-8, wd=0.0):
    m = b1 * m + (1 - b1) * g
    v = b2 * v + (1 - b2) * g**2
    m_hat = m / (1 - b1**t); v_hat = v / (1 - b2**t)
    theta = theta - lr * (m_hat / (np.sqrt(v_hat) + eps) + wd * theta)   # AdamW-style decay
    return theta, m, v
```

**Memory cost:** Adam stores 2 extra values per parameter. With fp32 optimizer states, training a
7B model needs ~56 GB just for $m$ and $v$ — a major reason for ZeRO/FSDP sharding and 8-bit optimizers.

## 6. Learning-rate schedules

LLM training almost always uses **linear warmup then cosine decay**:

$$
\eta_t =
\begin{cases}
\eta_{\max}\cdot \dfrac{t}{T_w} & t < T_w \\[2mm]
\eta_{\min} + \tfrac{1}{2}(\eta_{\max}-\eta_{\min})\left(1 + \cos\!\left(\pi \dfrac{t - T_w}{T - T_w}\right)\right) & t \ge T_w
\end{cases}
$$

*Plain English:* jog slowly before sprinting (warmup), sprint for most of the race, then slow down
as you approach the finish so you stop exactly on the line (decay).

Warmup avoids huge early updates while Adam's statistics are still unreliable; decay lets the
model settle into a good minimum.

## 7. Convexity and the loss landscape

- **Convex** losses (linear/logistic regression) have one global minimum — gradient descent finds it.
- *Plain English:* a convex loss is a single smooth bowl — roll downhill from anywhere and you reach
  the bottom. A neural-network loss is a mountain range with many valleys, ridges, and flat plateaus.
- Neural-network losses are **non-convex**, full of saddle points and flat regions. In practice,
  over-parameterized networks still train well; flat minima tend to generalize better.

## 8. Practical stability tools

| Problem | Tool |
|---|---|
| Exploding gradients | **Gradient clipping**: rescale $g$ if $\|g\| > c$ (e.g. $c = 1.0$) |
| Batch too big for GPU | **Gradient accumulation**: sum gradients over several micro-batches before stepping |
| Overfitting | Weight decay, dropout, early stopping, more data |
| Loss spikes / NaN | Lower LR, longer warmup, check for fp16 overflow, use bf16 |

```python
def clip_by_norm(g, max_norm=1.0):
    n = np.linalg.norm(g)
    return g * (max_norm / n) if n > max_norm else g
```

## 9. Senior track: going deeper

### 9.1 Convergence and conditioning

If $\mathcal{L}$ is **$\beta$-smooth** (gradient is $\beta$-Lipschitz, i.e. curvature $\le \beta$), gradient descent with
$\eta \le 1/\beta$ never increases the loss. If it is also **$\mu$-strongly convex**, the error shrinks by a factor of about
$(1 - \mu/\beta)$ per step. The **condition number $\kappa = \beta/\mu$** therefore controls speed: ~$\kappa$ steps per
factor-of-$e$ improvement. Momentum improves this to ~$\sqrt{\kappa}$ (Nesterov).

```python
# GD on a 2-D quadratic: L = 0.5 * (a*x^2 + b*y^2). Condition number = a/b.
def gd_steps(a, b, lr, tol=1e-6):
    x = np.array([1.0, 1.0])
    for t in range(100_000):
        x = x - lr * np.array([a, b]) * x
        if np.linalg.norm(x) < tol:
            return t
for kappa in [1, 10, 100, 1000]:
    print(f"kappa={kappa:5d}  steps={gd_steps(1.0, 1.0 / kappa, lr=1.0)}")   # lr = 1/beta
```

*Plain English:* the higher the condition number, the more the valley looks like a long thin canyon —
the output above shows that every 10× more "stretch" costs ~10× more steps.

Deep-net losses are not convex, but these local quantities still govern behaviour, and they explain why Adam
(a diagonal preconditioner that roughly rescales each coordinate by its curvature proxy $\sqrt{v}$) trains
transformers far better than plain SGD.

### 9.2 Why weight decay and L2 differ under Adam

With SGD, adding $\frac{\lambda}{2}\|\theta\|^2$ to the loss and decaying weights are identical. With Adam, an L2 term
goes into the gradient and gets **divided by $\sqrt{\hat v}$** — parameters with large gradient history get less
regularization. AdamW decouples the decay so every weight shrinks at the same relative rate. Common practice:
no weight decay on biases, norm gains, and (often) embeddings.

### 9.3 Batch size and learning-rate scaling

- **SGD, linear scaling rule:** multiply batch by $k$ ⇒ multiply LR by $k$ (with warmup), valid up to the
  critical batch size (module 03).
- **Adam:** closer to **square-root** scaling ($\eta \propto \sqrt{B}$) in many regimes; past the critical batch size
  returns diminish regardless.
- In practice, scaling-law papers fit optimal LR and batch as power laws of compute — re-tune when you change scale.

### 9.4 μP (maximal update parametrization)

Under standard parametrization, the optimal learning rate shifts as you widen a model, so hyperparameters
tuned on a small model do not transfer. **μP** rescales initialization and per-layer learning rates with width so the
optimum stays (approximately) fixed — tune on a ~100M model, transfer to a multi-billion one. Worth knowing
when someone proposes "just sweep LR on the big model".

### 9.5 Stability tricks used in real LLM training

| Trick | Math | Purpose |
|---|---|---|
| z-loss | add $10^{-4}\,(\log\sum_j e^{z_j})^2$ | keeps output logits from drifting large; reduces loss spikes |
| QK-norm | normalize $\mathbf{q}, \mathbf{k}$ before dot product | bounds attention logits |
| Lower $\beta_2$ (0.95) | faster-adapting $v$ | Adam reacts faster to gradient-scale changes |
| Larger $\epsilon$ (1e-6 to 1e-8, tuned) | caps step size when $v$ is tiny | prevents huge updates for rarely-updated params |
| Skip / rewind | skip batches with gradient-norm outliers, or restart from checkpoint with new data order | spike recovery |

### 9.6 Optimizer frontier (know the names and ideas)

- **Lion:** uses only the *sign* of a momentum-interpolated gradient — less memory (one state), uniform step magnitudes.
- **Shampoo / SOAP:** approximate full-matrix preconditioning with per-layer Kronecker factors.
- **Muon:** orthogonalizes each 2-D weight update (via a Newton–Schulz iteration) so all singular directions
  move equally; reported strong results at LLM scale.
- **Schedule-free / WSD (warmup-stable-decay):** avoid committing to a total step count up front — useful when
  you want to keep training or branch checkpoints.

### 9.7 Constrained optimization: Lagrange multipliers and KKT

To minimize $f(\mathbf{x})$ subject to $g(\mathbf{x}) = 0$: at the optimum you cannot slide along the constraint and still
go downhill, so the gradients must be parallel:

$$
\nabla f = \lambda\,\nabla g \quad\Longleftrightarrow\quad \nabla_{\mathbf{x},\lambda}\,\mathcal{L} = 0 \text{ for } \mathcal{L}(\mathbf{x}, \lambda) = f(\mathbf{x}) - \lambda\,g(\mathbf{x})
$$

For inequality constraints $h(\mathbf{x}) \le 0$, the **KKT conditions** add: multiplier $\mu \ge 0$ and
**complementary slackness** $\mu\,h(\mathbf{x}) = 0$ — either the constraint is active (you are pressed against it)
or its multiplier is zero (it doesn't matter).

The multiplier has a meaning: it is the **shadow price** — how much the optimum improves per unit of loosening the constraint.

Where this exact tool appears in ML:

| Problem | Constraint | Result |
|---|---|---|
| PCA (module 08) | $\|\mathbf{w}\| = 1$ | $\Sigma\mathbf{w} = \lambda\mathbf{w}$ — top eigenvector |
| SVM (module 08) | every point outside the margin | dual problem; support vectors are the points with $\mu > 0$ |
| Softmax | maximize entropy with a fixed expected score | $p_i \propto e^{z_i/\tau}$ |
| RLHF / DPO (module 07) | probabilities sum to 1, KL penalty | $\pi^* \propto \pi_{ref}\,e^{r/\beta}$ |
| PPO / TRPO | $D_{KL}(\pi_{new}\|\pi_{old}) \le \delta$ | trust-region updates |

**Derivation — softmax is the maximum-entropy distribution.** Maximize $-\sum_i p_i\log p_i$ subject to
$\sum_i p_i z_i = c$ and $\sum_i p_i = 1$. Setting the derivative of
$-\sum p_i\log p_i + \lambda(\sum p_i z_i - c) + \nu(\sum p_i - 1)$ to zero gives $-\log p_i - 1 + \lambda z_i + \nu = 0$,
so $p_i \propto e^{\lambda z_i}$ — softmax, with $\lambda$ playing the role of $1/\tau$.

> **In plain English:** you want the lowest point on a hillside but must stay on a hiking trail. The lowest
> point on the trail is where the trail runs level across the slope — where the trail and the contour line
> touch. The multiplier is the "price" of the trail: how much lower you could get if you were allowed to step
> one metre off it. **Example:** maximize $xy$ with $x + y = 10$ → $x = y = 5$, $\lambda = 5$; raise the budget to
> 11 and the best value goes from 25 to 30.25 — about 5 more, as $\lambda$ predicted.

```python
Sigma = np.array([[3.0, 1.0], [1.0, 2.0]])
angles = np.linspace(0, np.pi, 100_001)
W = np.stack([np.cos(angles), np.sin(angles)], 1)                 # every unit vector (the constraint)
best = W[np.argmax(np.einsum("ni,ij,nj->n", W, Sigma, W))]        # brute-force constrained max
top_eig = np.linalg.eigh(Sigma)[1][:, -1]
print("brute force:", best.round(4), " eigenvector:", (top_eig * np.sign(top_eig[0])).round(4))
```

## Key takeaways

1. Optimization = repeatedly step against a (mini-batch) gradient.
2. The learning rate is the most important knob; use warmup + cosine decay for transformers.
3. AdamW is the default; it adapts per-parameter step sizes and costs 2× parameter memory.
4. Clip gradients and watch for NaNs.

Next: [06 — Math of deep learning](06_math_of_deep_learning.md)
