# 01 — Linear Algebra: The Language of Models

> **Why it matters:** every input, weight, activation, and embedding in ML is a vector or a
> matrix. A neural network forward pass is mostly matrix multiplication. GPUs exist to do it fast.

## 1. Scalars, vectors, matrices, tensors

| Object | Shape | Example in ML |
|---|---|---|
| Scalar | `()` | learning rate `0.001`, a loss value |
| Vector | `(d,)` | one token embedding of size 4096 |
| Matrix | `(m, n)` | a weight matrix of a linear layer |
| Tensor | `(b, t, d)` | a batch of `b` sequences, `t` tokens each, `d` features per token |

```python
import numpy as np
x = np.array([1.0, 2.0, 3.0])          # vector, shape (3,)
W = np.random.randn(4, 3)              # matrix, shape (4, 3)
X = np.random.randn(8, 16, 3)          # tensor: batch=8, seq=16, dim=3
```

**Habit to build:** always track shapes. Most bugs in ML code are shape bugs.

> **In plain English:** a vector is just a list of numbers describing one thing. A matrix is a
> spreadsheet. A tensor is a stack of spreadsheets.
>
> **Example:** a house as a vector `[bedrooms=3, sqft=1500, age=10]`. 1,000 houses = a `(1000, 3)`
> matrix (one row per house). The same data for 12 months = a `(12, 1000, 3)` tensor. An LLM does
> the same with words: each token becomes a list of ~4,096 numbers that capture its meaning.

## 2. Vector operations

- **Addition / scaling:** element-wise. $\mathbf{a} + \mathbf{b}$, $c\,\mathbf{a}$.
- **Dot product:** $\mathbf{a}\cdot\mathbf{b} = \sum_i a_i b_i$ — a single number measuring
  how much two vectors "agree".
- **Norm (length):** $\|\mathbf{a}\|_2 = \sqrt{\sum_i a_i^2}$. The L1 norm is $\sum_i |a_i|$.
- **Cosine similarity:**

$$
\cos(\mathbf{a}, \mathbf{b}) = \frac{\mathbf{a}\cdot\mathbf{b}}{\|\mathbf{a}\|\,\|\mathbf{b}\|} \in [-1, 1]
$$

```python
a = np.array([1.0, 2.0, 3.0]); b = np.array([2.0, 4.0, 6.5])
dot = a @ b
cos = dot / (np.linalg.norm(a) * np.linalg.norm(b))
print(dot, round(cos, 4))   # cos ≈ 1 → same direction
```

> **In plain English:** the dot product asks "do these two lists go up and down together?".
> Cosine similarity asks the same question but ignores *how big* the numbers are — only the
> *direction* (what they are about) matters.
>
> **Example:** movie taste as `[action, romance, comedy]`. You rate `[5, 1, 3]`, your friend rates
> `[4, 1, 2]` (stingier overall but same taste) → cosine ≈ 0.99. Someone rating `[1, 5, 1]` → cosine ≈ 0.42.
> Search engines do exactly this with document meanings instead of movie tastes.

**Where you meet it:** RAG retrieval ranks documents by cosine similarity between the query
embedding and document embeddings. If embeddings are L2-normalized (length 1), cosine
similarity equals the dot product — which is why vector DBs often normalize first.

## 3. Matrices and matrix multiplication

For $A \in \mathbb{R}^{m\times n}$ and $B \in \mathbb{R}^{n\times p}$:

$$
(AB)_{ij} = \sum_{k=1}^{n} A_{ik} B_{kj}, \qquad AB \in \mathbb{R}^{m\times p}
$$

Rule: **inner dimensions must match** (`(m,n) @ (n,p) → (m,p)`). Each output entry is a dot
product of a row of $A$ with a column of $B$.

> **In plain English:** matrix multiplication = "score the same input many different ways at once".
> Each row of the matrix is one scorer with its own opinions (weights).
>
> **Example:** you buy apples, bread, milk in quantities `[3, 1, 2]`. Store A charges `[1, 2, 3]`,
> Store B charges `[2, 1, 1]`. Stack the price lists as a `(2, 3)` matrix and multiply by your
> `(3,)` basket: bills = `[3+2+6, 6+1+2] = [11, 9]`. A neural-network layer is the same thing — each
> output neuron is a "store" pricing your input with its own weights.

A **linear layer** is exactly this:

$$
\mathbf{y} = W\mathbf{x} + \mathbf{b}
$$

```python
x = np.random.randn(3)        # input features
W = np.random.randn(4, 3)     # 3 inputs → 4 outputs
b = np.zeros(4)
y = W @ x + b                 # shape (4,)
```

With a batch, rows are examples: `Y = X @ W.T + b` where `X` is `(batch, 3)`.

**Cost:** multiplying `(m,n) @ (n,p)` takes about $2mnp$ floating-point operations (FLOPs).
This is why model size and sequence length drive GPU cost.

### Other matrix facts you will see

- **Transpose** $A^\top$: swap rows and columns. $(AB)^\top = B^\top A^\top$.
- **Identity** $I$: $AI = A$.
- **Inverse** $A^{-1}$: $AA^{-1} = I$ (only for square, non-singular matrices). Rarely computed
  directly in DL; used in closed-form linear regression.
- **Element-wise (Hadamard) product** $A \odot B$: multiply matching entries (`A * B` in NumPy).
  Used in gating (LSTMs, SwiGLU).
- **Broadcasting:** NumPy/PyTorch stretch size-1 dimensions automatically, e.g. adding a bias
  `(4,)` to a batch `(32, 4)`.

## 4. Linear transformations: geometric intuition

A matrix **is** a function that rotates, scales, shears, or projects space. A neural network
layer moves points (your data) into a new space where the task is easier — e.g. where classes
become separable, or where similar meanings sit close together.

## 5. Rank, eigenvalues, and SVD

- **Rank:** number of linearly independent rows/columns = the "true dimensionality" of what the
  matrix can express.
- **Eigenvectors:** directions that a square matrix only stretches: $A\mathbf{v} = \lambda\mathbf{v}$.
  $\lambda$ is the stretch factor (eigenvalue).
- **SVD (Singular Value Decomposition):** every matrix factors as

$$
A = U \Sigma V^\top
$$

  where $U, V$ are rotations and $\Sigma$ is diagonal with singular values $\sigma_1 \ge \sigma_2 \ge \dots \ge 0$.
  Keeping only the top $r$ singular values gives the **best rank-$r$ approximation** of $A$.

```python
A = np.random.randn(100, 10) @ np.random.randn(10, 80) + 0.01 * np.random.randn(100, 80)  # rank ~10 + noise
U, S, Vt = np.linalg.svd(A, full_matrices=False)
r = 10
A_r = U[:, :r] @ np.diag(S[:r]) @ Vt[:r, :]
print("top singular values:", S[:12].round(1))           # sharp drop after 10
print("relative error:", np.linalg.norm(A - A_r) / np.linalg.norm(A))   # ~0.003
print("params: full", A.size, "vs rank-10 factors", U[:, :r].size + r + Vt[:r].size)
```

> **In plain English:** SVD finds the few "hidden themes" that explain most of a big table. Rank =
> how many genuinely independent themes there are.
>
> **Example:** a Netflix table of 1M users × 10k movies looks huge, but most ratings are explained by
> a handful of tastes ("likes action", "likes romance", "likes kids' films"). Keep the top 50 themes
> and you can rebuild the table almost perfectly from far fewer numbers — that is the demo above
> (8,000 numbers squeezed into 1,810).

**Where you meet it:**
- **PCA** (dimensionality reduction) = SVD of centered data.
- **LoRA** fine-tuning assumes the weight *update* is low rank: $\Delta W = BA$ with
  $B \in \mathbb{R}^{d\times r}$, $A \in \mathbb{R}^{r\times k}$, $r \ll d$. See module 07.
- **Stability:** very large singular values in weight matrices can cause exploding activations.

### Supporting vocabulary you will see in papers

- **Linear combination / span:** $c_1\mathbf{v}_1 + \dots + c_k\mathbf{v}_k$. The span of a set is every vector you can reach that way.
- **Linear independence:** no vector in the set can be built from the others. Rank = the number of independent columns.
- **Basis:** an independent set that spans the space ($d$ vectors for $\mathbb{R}^d$). The same vector has different
  coordinates in different bases; a learned layer is often best read as "re-expressing the input in a more useful basis".
- **Determinant** $\det(A)$ (square $A$): the factor by which $A$ scales volume. $\det A = \prod_i \lambda_i$ and
  $\det(AB) = \det A\,\det B$. $\det A = 0$ ⇔ space is squashed flat ⇔ rank-deficient ⇔ not invertible.
  Where: the $|\Sigma|$ in the Gaussian density (module 03), the log-det-Jacobian in normalizing flows.
- **Trace** $\text{tr}(A) = \sum_i A_{ii} = \sum_i \lambda_i$, and it is cyclic: $\text{tr}(ABC) = \text{tr}(CAB)$.
  Where: matrix-calculus identities (section 7.5), the gradient noise scale $\text{tr}(\Sigma)$ (module 03).
- **Matrix norms:** Frobenius $\|A\|_F = \sqrt{\sum_{ij}A_{ij}^2} = \sqrt{\sum_i\sigma_i^2}$ (size of all entries);
  spectral $\|A\|_2 = \sigma_{\max}$ (the most the matrix can stretch any vector). The spectral norm bounds how much a
  layer can amplify its input — the basis of spectral normalization and Lipschitz arguments about stability.

> **In plain English:** a basis is your choice of axes — "3 km east, 4 km north" and "5 km north-east"
> describe the same place in two bases. The determinant is how much a transformation stretches area:
> a matrix with determinant 6 turns a 1 m² tile into 6 m². Determinant 0 flattens the tile into a line —
> information is destroyed and cannot be undone, which is why such a matrix has no inverse.

```python
A = np.array([[2.0, 1.0], [0.0, 3.0]])
eig = np.linalg.eigvals(A); sv = np.linalg.svd(A, compute_uv=False)
print("det", np.linalg.det(A).round(6), "= prod(eig)", np.prod(eig).round(6))      # 6.0
print("trace", np.trace(A), "= sum(eig)", eig.sum().round(6))                     # 5.0
print("frobenius", np.linalg.norm(A, "fro").round(4), "= sqrt(sum sv^2)", np.sqrt((sv**2).sum()).round(4))
print("spectral", np.linalg.norm(A, 2).round(4), "= max sv", sv.max().round(4))
S = np.array([[1.0, 2.0], [2.0, 4.0]])                                            # 2nd row = 2 × 1st row
print("singular: det", np.linalg.det(S).round(6), "rank", np.linalg.matrix_rank(S))
```

## 6. Embeddings as linear algebra

An embedding table is a matrix $E \in \mathbb{R}^{V\times d}$ (vocabulary size $V$, dimension $d$).
Looking up token $i$ = taking row $i$, which equals multiplying a one-hot vector by $E$:

```python
V, d = 10, 4
E = np.random.randn(V, d)
token_id = 7
one_hot = np.eye(V)[token_id]
assert np.allclose(one_hot @ E, E[token_id])
```

## 7. Senior track: going deeper

### 7.1 einsum — the notation papers actually use

Index notation removes ambiguity about which axes are contracted. Learn it; it makes attention
and batched code self-documenting.

```python
B, T, H, Dk = 2, 5, 4, 8
Q = np.random.randn(B, H, T, Dk); K = np.random.randn(B, H, T, Dk); V = np.random.randn(B, H, T, Dk)
scores = np.einsum("bhqd,bhkd->bhqk", Q, K) / np.sqrt(Dk)      # contract over d
weights = np.exp(scores - scores.max(-1, keepdims=True)); weights /= weights.sum(-1, keepdims=True)
out = np.einsum("bhqk,bhkd->bhqd", weights, V)                 # contract over k
print(out.shape)   # (2, 4, 5, 8)
```

Rule: any index that appears in the inputs but not the output is summed over.

### 7.2 Orthogonal matrices

$Q^\top Q = I$. They preserve lengths and angles: $\|Q\mathbf{x}\| = \|\mathbf{x}\|$, and all singular values are 1.
- **RoPE** applies orthogonal rotations to queries and keys, which is why it does not change their norms (module 07).
- **Orthogonal initialization** keeps signal magnitude stable through deep linear stacks.
- Some newer optimizers (e.g. Muon) orthogonalize the update matrix so every direction moves at a similar rate.

### 7.3 Symmetric and positive (semi)definite matrices

$A$ is PSD if $\mathbf{x}^\top A\mathbf{x} \ge 0$ for all $\mathbf{x}$ (all eigenvalues $\ge 0$).
- Covariance matrices, Gram/kernel matrices $XX^\top$, and the Hessian at a minimum are PSD.
- **Spectral theorem:** symmetric $A = Q\Lambda Q^\top$ with orthogonal $Q$ — real eigenvalues, orthogonal eigenvectors.
  This is why PCA is an eigendecomposition of the covariance matrix (module 08).

### 7.4 Conditioning — why numerics break

The condition number $\kappa(A) = \sigma_{\max}/\sigma_{\min}$ measures how much relative error in the input can
amplify in the output. Roughly, you lose $\log_{10}\kappa$ decimal digits of precision.
> **In plain English:** an ill-conditioned problem is a wobbly table — a tiny nudge on one leg makes
> everything shake. **Example:** a recipe where 1% too much salt ruins the dish is badly conditioned;
> one where it barely matters is well conditioned.

- bf16 has only ~3 significant decimal digits, so ill-conditioned computations break much sooner in low precision.
- For optimization, an ill-conditioned Hessian means a long, narrow valley: gradient descent zig-zags
  (module 05). Normalization layers and Adam both act partly as conditioning fixes.

### 7.5 Matrix calculus identities you will use

| Expression | Gradient |
|---|---|
| $\mathbf{a}^\top\mathbf{x}$ | $\mathbf{a}$ |
| $\mathbf{x}^\top A\mathbf{x}$ | $(A + A^\top)\mathbf{x}$ (= $2A\mathbf{x}$ if symmetric) |
| $\|A\mathbf{x} - \mathbf{b}\|^2$ | $2A^\top(A\mathbf{x} - \mathbf{b})$ |
| $\text{tr}(AX)$ w.r.t. $X$ | $A^\top$ |
| $\|X\|_F^2 = \text{tr}(X^\top X)$ | $2X$ |

### 7.6 High-dimensional geometry (counter-intuitive and important)

For random vectors with i.i.d. $\mathcal{N}(0,1)$ entries in $\mathbb{R}^d$:
- **Norms concentrate:** $\|\mathbf{x}\| \approx \sqrt{d}$ with small relative spread.
- **Random vectors are nearly orthogonal:** $\cos(\mathbf{x}, \mathbf{y}) \approx \mathcal{N}(0, 1/d)$.

```python
for d in [3, 100, 4096]:
    A = np.random.randn(2000, d); Bm = np.random.randn(2000, d)
    cos = (A * Bm).sum(1) / (np.linalg.norm(A, axis=1) * np.linalg.norm(Bm, axis=1))
    print(f"d={d:5d}  mean|cos|={np.abs(cos).mean():.3f}  std(cos)={cos.std():.4f}  1/sqrt(d)={1/np.sqrt(d):.4f}")
```

> **In plain English:** high-dimensional space is unimaginably roomy. In 3-D, two random arrows often
> point roughly the same way; in 4,096-D they almost never do.
>
> **Example:** ask two random people 3 yes/no questions and they may well agree on all of them. Ask
> 4,096 random questions and their answers will match about half the time — no more, no less. That
> "about half" is what "nearly perpendicular" means.

Consequences:
- A 4096-dim space can hold far more than 4096 *almost*-orthogonal directions, which is one explanation for
  **superposition** — models packing more features than dimensions.
- **Johnson–Lindenstrauss:** random projection to $k = O(\log n / \varepsilon^2)$ dims preserves pairwise distances
  within $1 \pm \varepsilon$ — the theory behind random-projection hashing and why embedding truncation often works.
- The $\sqrt{d}$ norm growth is exactly why attention divides by $\sqrt{d_k}$ (module 07).
- Raw cosine similarities from real embedding models are often all high (e.g. 0.6–0.9) because the space
  is **anisotropic** (vectors cluster in a narrow cone). Compare scores by rank, not absolute thresholds,
  unless you have calibrated them.

## Key takeaways

1. Track shapes religiously: `(m,n) @ (n,p) → (m,p)`.
2. Dot product / cosine similarity = "how similar" — the core of retrieval and attention.
3. A layer = matrix multiply + bias; its cost is ~$2mnp$ FLOPs.
4. SVD and rank explain PCA, compression, and LoRA.

Next: [02 — Calculus & gradients](02_calculus_gradients.md)
