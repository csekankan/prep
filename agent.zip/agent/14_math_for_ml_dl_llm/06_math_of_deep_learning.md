# 06 — Math of Deep Learning: Layers, Backprop, Stability

> **Why it matters:** this module combines linear algebra (layers), calculus (backprop),
> probability (initialization, dropout), and optimization into one working neural network —
> and explains the tricks that make deep networks trainable.

## 1. A neuron and a layer

A neuron computes a weighted sum then a nonlinearity:

$$
a = \phi(\mathbf{w}^\top \mathbf{x} + b)
$$

> **In plain English:** a neuron is a tiny decision-maker that weighs evidence.
>
> **Example:** "Should I go to the beach?" Inputs: sunny (1), temperature 30°C (scaled to 0.8),
> weekend (1). Weights: sunny matters a lot (+2), heat matters some (+1), weekend matters a lot (+1.5).
> Bias −3 = "I'm lazy by default". Score $= 2 + 0.8 + 1.5 - 3 = 1.3 > 0$ → go. Training = learning
> those weights from examples instead of choosing them by hand.

A layer is many neurons at once: $\mathbf{h} = \phi(W\mathbf{x} + \mathbf{b})$.
A **multi-layer perceptron (MLP)** stacks them:

$$
\mathbf{h}_1 = \phi(W_1\mathbf{x} + \mathbf{b}_1), \quad
\mathbf{h}_2 = \phi(W_2\mathbf{h}_1 + \mathbf{b}_2), \quad
\hat{\mathbf{y}} = W_3\mathbf{h}_2 + \mathbf{b}_3
$$

**Why the nonlinearity?** Without it, $W_3 W_2 W_1$ collapses into a single matrix — a deep
network would be no more powerful than one linear layer.

*Plain English:* stacking straight-line functions gives you... another straight line. The nonlinearity
is the "bend" that lets the network draw curves. Example: XOR (output 1 when exactly one input is 1)
cannot be separated by any single straight line — section 3 solves it with one ReLU layer.

## 2. Activation functions

| Activation | Formula | Notes |
|---|---|---|
| Sigmoid | $\frac{1}{1+e^{-x}}$ | outputs (0,1); saturates → vanishing gradients; used for binary outputs/gates |
| Tanh | $\frac{e^x - e^{-x}}{e^x + e^{-x}}$ | outputs (−1,1); still saturates |
| ReLU | $\max(0, x)$ | cheap, no saturation for $x>0$; "dead" neurons possible |
| GELU | $x\,\Phi(x)$ | smooth ReLU; used in BERT/GPT-2/3 |
| SiLU / Swish | $x\,\sigma(x)$ | used inside SwiGLU (LLaMA, Mistral) |
| Softmax | $\frac{e^{z_i}}{\sum_j e^{z_j}}$ | turns a vector of scores into probabilities |

**SwiGLU** (the feed-forward block in many modern LLMs):

$$
\text{FFN}(\mathbf{x}) = W_2\big(\text{SiLU}(W_1\mathbf{x}) \odot W_3\mathbf{x}\big)
$$

## 3. Backpropagation, step by step

For a 2-layer network with loss $L$:

1. **Forward:** compute and cache $\mathbf{z}_1 = W_1\mathbf{x}$, $\mathbf{h} = \phi(\mathbf{z}_1)$,
   $\mathbf{z}_2 = W_2\mathbf{h}$, $L = \ell(\mathbf{z}_2, y)$.
2. **Backward** (chain rule from the end):
   - $\mathbf{g}_2 = \partial L / \partial \mathbf{z}_2$
   - $\partial L/\partial W_2 = \mathbf{g}_2 \mathbf{h}^\top$
   - $\partial L/\partial \mathbf{h} = W_2^\top \mathbf{g}_2$
   - $\mathbf{g}_1 = \partial L/\partial \mathbf{h} \odot \phi'(\mathbf{z}_1)$
   - $\partial L/\partial W_1 = \mathbf{g}_1 \mathbf{x}^\top$
3. **Update** every weight with the optimizer.

> **In plain English:** a restaurant gets a bad review. Backprop walks backward through the kitchen and
> hands out blame in proportion to each person's contribution: the waiter (last layer) gets some, the
> chef who cooked it (middle layer) gets some, the supplier who sent bad ingredients (first layer) gets
> some. Each one then adjusts a little. Forward pass = cooking the meal; backward pass = the post-mortem.

### A complete tiny network in NumPy (learns XOR)

```python
import numpy as np
rng = np.random.default_rng(0)
X = np.array([[0,0],[0,1],[1,0],[1,1]], dtype=float)
y = np.array([0,1,1,0])

W1 = rng.normal(0, 1, (2, 8)); b1 = np.zeros(8)
W2 = rng.normal(0, 1, (8, 2)); b2 = np.zeros(2)
lr = 0.5

for step in range(2000):
    # forward
    z1 = X @ W1 + b1
    h = np.maximum(0, z1)                          # ReLU
    logits = h @ W2 + b2
    logits -= logits.max(axis=1, keepdims=True)
    probs = np.exp(logits) / np.exp(logits).sum(axis=1, keepdims=True)
    loss = -np.log(probs[np.arange(4), y]).mean()

    # backward
    g2 = probs.copy(); g2[np.arange(4), y] -= 1; g2 /= 4   # softmax+CE: p - y
    dW2 = h.T @ g2; db2 = g2.sum(0)
    dh = g2 @ W2.T
    g1 = dh * (z1 > 0)                              # ReLU derivative
    dW1 = X.T @ g1; db1 = g1.sum(0)

    # update
    W1 -= lr * dW1; b1 -= lr * db1; W2 -= lr * dW2; b2 -= lr * db2

print("loss:", round(loss, 4), "preds:", probs.argmax(1))   # preds: [0 1 1 0]
```

(Batch convention here is rows = examples, so the gradient is `X.T @ g` instead of $\mathbf{g}\mathbf{x}^\top$ — same math, transposed.)

## 4. Initialization: keep the variance stable

If weights are too large, activations explode through layers; too small, they vanish. Good init
keeps $\mathrm{Var}(\text{output}) \approx \mathrm{Var}(\text{input})$.

For a layer with $n_{in}$ inputs, $\mathrm{Var}(\mathbf{w}^\top\mathbf{x}) = n_{in}\,\mathrm{Var}(w)\,\mathrm{Var}(x)$
(assuming zero-mean, independent terms). So choose:

| Scheme | $\mathrm{Var}(w)$ | Use with |
|---|---|---|
| Xavier / Glorot | $\frac{2}{n_{in} + n_{out}}$ | tanh, sigmoid |
| He / Kaiming | $\frac{2}{n_{in}}$ | ReLU (ReLU zeroes half the signal, hence the 2) |

> **In plain English:** a chain of 50 audio amplifiers. If each one outputs half the volume, you hear
> silence at the end; if each doubles it, you get screeching feedback. You want each amplifier set to
> "×1". Initialization picks the starting weights so each layer is roughly a ×1 amplifier.

Transformers typically use small normal init (std ≈ 0.02) and scale down the residual output
projections by depth.

## 5. Residual connections

$$
\mathbf{h}_{l+1} = \mathbf{h}_l + F(\mathbf{h}_l)
$$

The derivative is $I + \partial F/\partial \mathbf{h}_l$ — the identity term gives gradients a
"highway" straight back to early layers, which is what makes 100+-layer networks (and every
transformer) trainable.

> **In plain English:** like editing a document with "track changes". Each layer does not rewrite the
> document from scratch; it keeps the original and adds suggested edits. If a layer has nothing useful to
> add, it can contribute ~zero and the information passes through untouched.

## 6. Normalization

Normalize activations to zero mean and unit variance, then rescale with learned $\gamma, \beta$:

$$
\text{LayerNorm}(\mathbf{x}) = \gamma \odot \frac{\mathbf{x} - \mu}{\sqrt{\sigma^2 + \epsilon}} + \beta
$$

> **In plain English:** grading on a curve. Raw scores from different exams (one out of 10, one out of
> 1,000) are converted to "how far above or below average, in standard deviations", so every layer
> receives numbers in a familiar range no matter what the previous layer did.

- **BatchNorm** computes $\mu, \sigma$ across the batch (common in CNNs).
- **LayerNorm** computes them across features of a single example (transformers — independent of batch size).
- **RMSNorm** skips the mean: $\mathbf{x} / \sqrt{\frac{1}{d}\sum x_i^2 + \epsilon} \odot \gamma$ — cheaper; used in LLaMA-family models.

```python
def rms_norm(x, gamma, eps=1e-6):
    return x / np.sqrt((x**2).mean(-1, keepdims=True) + eps) * gamma
```

## 7. Regularization

| Technique | Math | Effect |
|---|---|---|
| L2 / weight decay | add $\lambda\|\theta\|^2$ to loss | keeps weights small; equals a Gaussian prior |
| L1 | add $\lambda\|\theta\|_1$ | encourages sparsity |
| Dropout | zero each activation with prob $p$, scale survivors by $\frac{1}{1-p}$ | prevents co-adaptation; acts like an ensemble |
| Early stopping | stop when validation loss rises | cheapest regularizer |
| Label smoothing | target $= (1-\varepsilon)\,\text{one-hot} + \varepsilon/K$ | less overconfident predictions |

*Plain English for dropout:* randomly send some team members home each day during practice, so the
team cannot rely on one star player — everyone learns to contribute.

## 8. Numerical stability tricks

- **Stable softmax:** subtract $\max(\mathbf{z})$ before exponentiating — the result is mathematically
  identical but avoids overflow.
  *Example:* logits `[1000, 999]` → $e^{1000}$ overflows to infinity. Subtract the max → `[0, −1]` →
  $e^0 = 1$, $e^{-1} = 0.37$ → probabilities `[0.73, 0.27]`, the same answer, no overflow.
- **Log-sum-exp:** $\log\sum e^{z_i} = m + \log\sum e^{z_i - m}$ with $m = \max z$.
- **Mixed precision:** fp16 has max ≈ 65,504 and overflows easily; **bf16** keeps fp32's exponent
  range with less precision, which is why it is preferred for LLM training.

## 9. Senior track: going deeper

### 9.1 Derive He initialization

Let $z = \sum_{i=1}^{n_{in}} w_i x_i$ with $w_i$ i.i.d., mean 0, independent of $x_i$. Then

$$
\mathrm{Var}(z) = n_{in}\,\mathrm{Var}(w)\,\mathbb{E}[x^2]
$$

If $x = \text{ReLU}(z_{prev})$ and $z_{prev}$ is symmetric around 0, half its mass is zeroed:
$\mathbb{E}[x^2] = \frac{1}{2}\mathrm{Var}(z_{prev})$. Requiring $\mathrm{Var}(z) = \mathrm{Var}(z_{prev})$ gives

$$
n_{in}\,\mathrm{Var}(w)\cdot\tfrac{1}{2} = 1 \;\Rightarrow\; \mathrm{Var}(w) = \frac{2}{n_{in}}
$$

```python
def activation_std_through_depth(init_std_fn, depth=50, width=512):
    x = np.random.randn(1000, width)
    for _ in range(depth):
        W = np.random.randn(width, width) * init_std_fn(width)
        x = np.maximum(0, x @ W)
    return x.std()

print("std=0.01   :", activation_std_through_depth(lambda n: 0.01))            # vanishes to ~0
print("Xavier     :", activation_std_through_depth(lambda n: np.sqrt(1 / n)))  # shrinks with ReLU
print("He         :", activation_std_through_depth(lambda n: np.sqrt(2 / n)))  # stays O(1)
```

*Plain English:* with weights that are too small, the signal fades to nothing by layer 50 (≈ 1e-40 in the
output above); He init keeps it at a healthy ~0.7 all the way through.

### 9.2 Residual Jacobians — why depth stops hurting

Without residuals, the gradient through $L$ layers is a product $\prod_l J_l$, whose norm tends to grow or shrink
exponentially. With residuals,

$$
\frac{\partial\mathbf{h}_L}{\partial\mathbf{h}_0} = \prod_{l}\big(I + J_{F_l}\big) = I + \sum_l J_{F_l} + \dots
$$

The identity term means there is always a direct gradient path. You can also read a residual network as an
implicit ensemble of many shallower paths.

### 9.3 Pre-norm vs post-norm

- **Post-norm** (original Transformer): $\text{Norm}(\mathbf{x} + F(\mathbf{x}))$ — the norm sits on the residual path, gradients near the
  input can be poorly scaled; needs careful warmup, unstable when deep.
- **Pre-norm** (GPT-2 onward, LLaMA): $\mathbf{x} + F(\text{Norm}(\mathbf{x}))$ — clean identity path, stable at depth; the residual
  stream's norm grows with depth, so a final norm is applied before the LM head.

### 9.4 Dropout — the expectation argument

With keep probability $1-p$ and mask $m \sim \text{Bernoulli}(1-p)$, inverted dropout outputs $\frac{m}{1-p}x$, so
$\mathbb{E}[\text{output}] = x$ — training and inference activations match in expectation, so inference needs no rescaling.
Large-scale LLM pretraining usually sets $p = 0$ (data is abundant and seen ~once, so overfitting is not the
bottleneck); dropout returns in small-data fine-tuning.

### 9.5 Expressivity

- **Universal approximation:** a single hidden layer with enough units can approximate any continuous function on
  a compact set — but may need exponentially many units.
- **Depth gives efficiency:** some functions need exponentially fewer units when expressed deeply (composition reuses features).
- Practical takeaway: the question is never *can* the network represent it, but whether **optimization finds it**
  and whether it **generalizes** — which is why init, normalization, and data dominate practice.

### 9.6 A math-driven debugging checklist

1. **Loss at step 0 ≈ $\ln K$** ($K$ classes or vocab size). Much higher ⇒ logits too large at init.
2. **Overfit one batch** to ~0 loss. If you cannot, there is a bug (wrong labels/mask/shift), not a capacity problem.
3. **Check the label shift** for LMs: logits at position $t$ predict token $t+1$. Off-by-one errors produce a model that
   "learns" to copy the input with suspiciously low loss.
4. **Monitor gradient norm per layer** — exploding/vanishing shows up here first.
5. **Monitor update-to-weight ratio** $\|\Delta W\|/\|W\|$ ≈ $10^{-3}$ per step is a common healthy range.
6. **NaNs:** look for $\log 0$, division by zero in norms (missing $\epsilon$), fp16 overflow (> 65,504), or an LR spike.
7. **Gradient check** a new custom op against finite differences in float64 (module 02).

## Key takeaways

1. Layer = matmul + bias + nonlinearity; nonlinearity is what gives depth its power.
2. Backprop = cache forward values, apply chain rule backward, reuse partial results.
3. Init, residuals, and normalization all exist to keep signal and gradient variance stable.
4. Regularization fights overfitting; numerical tricks fight overflow.

Next: [07 — Math of transformers & LLMs](07_math_of_transformers_llms.md)
