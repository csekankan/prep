# 09 — ML Systems Math: Memory, FLOPs, Bandwidth, Communication, Cost

> **Why it matters:** this is where an SDE background becomes a superpower. Most senior AI
> engineering decisions — which GPU, how many, which parallelism, what batch size, what it costs
> per million tokens — are back-of-envelope arithmetic. Get within 2× on paper before you spend
> a dollar on hardware.

Reference hardware numbers (dense, no sparsity; check your exact SKU):

| GPU | bf16 peak | HBM | HBM bandwidth | Ridge point (FLOP/byte) |
|---|---|---|---|---|
| A100 SXM 80GB | ~312 TFLOP/s | 80 GB | ~2.0 TB/s | ~150 |
| H100 SXM | ~989 TFLOP/s | 80 GB | ~3.35 TB/s | ~295 |

---

## 1. Training memory: the 16-bytes-per-parameter rule

Mixed-precision training with Adam keeps, per parameter:

| Item | Precision | Bytes |
|---|---|---|
| Weights (compute copy) | bf16 | 2 |
| Gradients | bf16 | 2 |
| Master weights | fp32 | 4 |
| Adam $m$ | fp32 | 4 |
| Adam $v$ | fp32 | 4 |
| **Total (excluding activations)** | | **16** |

> **In plain English:** every weight drags luggage along during training: a working copy, its gradient
> ("which way should I move?"), a precise master copy, and Adam's two notebooks (momentum and
> step-size history). The weight itself is 2 bytes; the luggage is 14 more.

7B model ⇒ $7\times10^9 \times 16 \approx 112$ GB **before activations** — it does not fit on one 80 GB GPU.

**ZeRO / FSDP sharding** across $N_d$ data-parallel GPUs:

| Stage | Sharded | Bytes/param/GPU |
|---|---|---|
| DDP (none) | — | 16 |
| ZeRO-1 | optimizer states | $4 + 12/N_d$ |
| ZeRO-2 | + gradients | $2 + 14/N_d$ |
| ZeRO-3 / FSDP | + weights | $16/N_d$ |

7B on 8 GPUs with ZeRO-3: $112/8 = 14$ GB/GPU of model state, leaving room for activations.

> **In plain English:** instead of every GPU carrying the whole library, each carries 1/8 of the books
> and they lend pages to each other the moment someone needs them. Less memory per GPU, more network chatter.

---

## 2. Activation memory — usually the real limit

For a GPT-style layer with sequence length $s$, micro-batch $b$, hidden $h$, heads $a$, 16-bit
activations, no parallelism (Korthikanti et al., 2022):

$$
\text{activations per layer} \approx s\,b\,h\left(34 + \frac{5\,a\,s}{h}\right)\ \text{bytes}
$$

The $\frac{5as}{h}$ term is the $T\times T$ attention matrix; FlashAttention removes most of it.

```python
def act_gb(s, b, h, a, L, flash=False, full_recompute=False):
    if full_recompute:                       # store only each layer's input
        return 2 * s * b * h * L / 1e9
    per_layer = s * b * h * (34 + (0 if flash else 5 * a * s / h))
    return per_layer * L / 1e9

cfg = dict(s=4096, b=1, h=4096, a=32, L=32)   # ~7B model, one 4k sequence
print("naive attention:", round(act_gb(**cfg), 1), "GB")                 # ≈ 104 GB
print("flash attention:", round(act_gb(**cfg, flash=True), 1), "GB")     # ≈ 18 GB
print("full recompute :", round(act_gb(**cfg, full_recompute=True), 2), "GB")  # ≈ 1 GB
```

> **In plain English:** the forward pass drops breadcrumbs (intermediate results) so the backward pass can
> find its way back. Long sequences = a long trail of breadcrumbs. Activation checkpointing keeps only a
> breadcrumb every few layers and re-walks the missing stretch when needed — less memory, a bit more work.
> The demo shows the swing: 104 GB → 18 GB → 1 GB for the same 4k-token sequence.

Activation memory scales **linearly with batch and (with Flash) sequence length**. Levers: activation
checkpointing (trade ~33% more compute for memory), sequence/context parallelism, smaller micro-batches
with gradient accumulation.

---

## 3. Inference memory

$$
\text{memory} \approx \underbrace{N \cdot \tfrac{\text{bits}}{8}}_{\text{weights}} + \underbrace{2 L g d_k \cdot \text{bytes} \cdot \textstyle\sum_{\text{seqs}} T_i}_{\text{KV cache}} + \text{activations/workspace}
$$

Capacity planning example — LLaMA-2 70B, bf16, on 2× H100 (160 GB):
- Weights: ~140 GB ⇒ ~20 GB left for KV cache (minus framework overhead, say ~14 GB usable).
- KV per token (GQA, $L = 80$, $g = 8$, $d_k = 128$): $2 \cdot 80 \cdot 8 \cdot 128 \cdot 2 = 327{,}680$ bytes ≈ 0.31 MiB.
- ⇒ ~43k cached tokens total ≈ 10 concurrent 4k-token conversations. With int8 weights (~70 GB) the KV
  budget jumps to ~80 GB ⇒ ~60 concurrent conversations. **Quantization buys concurrency, not just fit.**

---

## 4. Arithmetic intensity and the roofline

$$
\text{arithmetic intensity } I = \frac{\text{FLOPs}}{\text{bytes moved to/from HBM}}, \qquad
\text{attainable FLOP/s} = \min\big(\text{peak FLOP/s},\; I \times \text{bandwidth}\big)
$$

If $I$ is below the GPU's ridge point (~150 on A100, ~295 on H100), you are **memory-bound** — extra
FLOPs are free, bytes are the cost.

| Operation | FLOPs | Bytes (bf16) | Intensity |
|---|---|---|---|
| Square matmul $n\times n$ | $2n^3$ | $3 \cdot 2n^2$ | $n/3$ (compute-bound for large $n$) |
| Decode step, batch $b$, weight $d\times d$ | $2bd^2$ | $\approx 2d^2$ (weights dominate) | $\approx b$ |
| Element-wise op (add, GELU, norm) | ~1 per element | ~4 per element | ~0.25 (always memory-bound) |

> **In plain English:** a GPU is a super-fast chef (compute) fed by a delivery van bringing ingredients
> from the warehouse (memory bandwidth). If each ingredient is used in hundreds of dishes (big matmuls),
> the chef is the bottleneck. If each ingredient is used once and thrown away (decode at batch 1, or simple
> element-wise ops), the chef stands idle waiting for the van — buying a faster chef does nothing.

Consequences:
- **Decode is memory-bound until batch ≈ ridge point** (~150–300 concurrent sequences). That is why serving
  engines do *continuous batching*: more concurrent requests ≈ free throughput.
- **Kernel fusion** (fused RMSNorm+matmul, FlashAttention) wins by eliminating HBM round-trips for low-intensity ops.
- **Quantization speeds up decode** mainly by moving fewer bytes, even if the math is dequantized to bf16.

---

## 5. Latency and throughput for serving

$$
\text{latency} \approx \text{TTFT} + (n_{out} - 1)\times\text{TPOT}
$$

- **TTFT** (prefill) ≈ $\frac{2N \cdot T_{prompt}}{\text{achieved FLOP/s}}$ — compute-bound, grows with prompt length.
- **TPOT** (decode, small batch) ≈ $\frac{\text{weight bytes} + \text{KV bytes read}}{\text{bandwidth}}$.
- *Plain English:* TTFT is how long until the first word appears (users feel this as "is it thinking?");
  TPOT is how fast the words then stream out (users feel this as reading speed — ~10+ tokens/s feels fine).
- **Little's law:** concurrent requests $=$ throughput $\times$ latency (a café serving 20 customers/min with a
  3-minute stay always has ~60 people inside). 20 req/s at 3 s each ⇒ 60 in flight —
  size your KV cache for that.

Worked TPOT: 7B bf16 (13.5 GB) on H100 at ~70% of 3.35 TB/s ⇒ $13.5 / 2.35 \approx 5.7$ ms ⇒ ~175 tokens/s per sequence at batch 1.

---

## 6. Model FLOPs Utilization (MFU)

$$
\text{MFU} = \frac{6N \times \text{tokens/s (training)}}{\text{num GPUs} \times \text{peak FLOP/s}}
$$

Good large-scale training reaches ~35–55% MFU. Below ~25% usually means communication stalls,
small matmuls, data-loader starvation, or too much recomputation.

```python
def mfu(N, tokens_per_s, gpus, peak=989e12):
    return 6 * N * tokens_per_s / (gpus * peak)
print(f"MFU = {mfu(N=7e9, tokens_per_s=95_000, gpus=8):.1%}")   # 7B at 95k tok/s on 8×H100 ≈ 50%
```

---

## 7. Communication math for distributed training

**Ring all-reduce** of $S$ bytes over $p$ GPUs: each GPU sends and receives $2\frac{p-1}{p}S \approx 2S$ bytes, so

$$
t_{\text{all-reduce}} \approx \frac{2S}{\text{per-GPU link bandwidth}}
$$

independent of $p$ (bandwidth-optimal) — plus a latency term that grows with $p$.

> **In plain English:** 8 people each hold a partial sum and all need the total. Instead of everyone
> shouting to everyone, they sit in a circle and pass chunks to the left: one lap to add up, one lap to
> share the result. Each person passes about twice the data size, no matter how big the circle.

| Parallelism | What is communicated | Volume per step | Where it fits |
|---|---|---|---|
| Data parallel (DDP/FSDP) | gradients (FSDP also all-gathers weights) | $\sim 2 \times$ model bytes | across nodes; overlap with backward |
| Tensor parallel | activations, 2 all-reduces per layer forward (+2 backward) | $\propto b\,s\,h$ per layer | **within a node** (NVLink) only |
| Pipeline parallel | activations at stage boundaries (point-to-point) | small | across nodes |
| Expert parallel (MoE) | all-to-all token routing | $\propto$ tokens × $h$ | needs fast fabric |

Example: syncing 7B bf16 gradients (14 GB) once per step
- NVLink-class ~300 GB/s effective: $2 \times 14 / 300 \approx 0.09$ s.
- 400 Gb/s InfiniBand (50 GB/s): $2 \times 14 / 50 \approx 0.56$ s — must be overlapped with compute or
  amortized with gradient accumulation.

**Pipeline bubble:** with $p$ stages and $m$ micro-batches (GPipe/1F1B), idle fraction

$$
\text{bubble} = \frac{p - 1}{m + p - 1}
$$

$p = 8$, $m = 32$ ⇒ 18% idle. *Plain English:* an assembly line with 8 stations — at the start the later
stations wait for the first car to arrive, at the end the early stations sit idle. Pushing more cars
(micro-batches) through makes that start-up and wind-down a smaller share of the day. More micro-batches shrink the bubble but raise activation memory.

**Batch size limits:** global batch $= \text{micro-batch} \times \text{grad-accum} \times N_d$. Beyond the
*critical batch size* (module 03) extra data parallelism stops reducing the number of steps needed — you
spend more GPUs for the same wall-clock.

---

## 8. Cost math

$$
\text{\$ per 1M tokens} = \frac{\text{GPU \$/hour} \times \text{num GPUs}}{\text{tokens/hour}} \times 10^6
$$

```python
def usd_per_million(gpu_hourly, gpus, tokens_per_s):
    return gpu_hourly * gpus / (tokens_per_s * 3600) * 1e6

print(round(usd_per_million(2.5, 1, 2500), 3))   # 8B model, 1×H100, batched decode ≈ $0.28 / 1M tokens
print(round(usd_per_million(2.5, 1, 60), 2))     # same GPU at batch 1 ≈ $11.57 / 1M tokens
```

*Plain English:* you rent the GPU like a taxi — by the hour, not by the passenger. A taxi carrying one
passenger is expensive per person; the same taxi as a full bus is cheap per person.

The 40× gap between those two lines is the whole business case for batching, KV-cache management,
and high-utilization serving. Training cost: $\text{GPU-hours} \approx \frac{6ND}{\text{peak} \times \text{MFU} \times 3600}$ (module 07).

## Key takeaways

1. Training state ≈ 16 bytes/param; ZeRO-3 divides it by GPU count.
2. Activations scale with batch × sequence; FlashAttention and checkpointing are memory tools.
3. Roofline: below ~150–300 FLOP/byte you are bandwidth-bound — decode at small batch always is.
4. Little's law sizes concurrency; KV cache sizes how much concurrency fits.
5. Ring all-reduce costs ~2× the payload per GPU; keep tensor parallelism inside a node.
6. Cost per token is dominated by utilization — batching is the biggest lever.

Next: [10 — Cheat sheet & exercises](10_cheatsheet_exercises.md)
