# 07 — Math of Transformers & LLMs

> **Why it matters:** an LLM is a stack of identical blocks (attention + feed-forward) trained
> with next-token cross-entropy. Once you can derive attention, count parameters and FLOPs,
> size a KV cache, and read the RLHF/DPO objectives, you can reason about any LLM paper,
> capacity plan, or inference bill.

Notation used throughout: $T$ = sequence length, $d$ = model width (`d_model`), $h$ = number of
heads, $d_k = d/h$ = head dim, $L$ = number of layers, $V$ = vocabulary size, $N$ = parameters,
$D$ = training tokens, $B$ = batch size.

---

## 1. From tokens to vectors

1. Text → token ids via a tokenizer (BPE / SentencePiece). Typical $V$ = 32k–256k.
   **How BPE is built:** start from single bytes/characters and repeatedly merge the most frequent adjacent
   pair into a new token until the vocabulary reaches $V$. Example: `aaabdaaabac` → merge `aa`→`Z`:
   `ZabdZabac` → merge `ab`→`Y`: `ZYdZYac` → merge `ZY`→`X`: `XdXac`. Consequences you will feel in
   production: English averages ~4 characters/token, while code, numbers, and many non-English languages need
   more tokens for the same content (higher cost, shorter effective context), and digits split unevenly,
   which is one reason LLMs are shaky at arithmetic.
2. Ids → embeddings: row lookup in $E \in \mathbb{R}^{V\times d}$ (see module 01).
3. Final hidden state $\mathbf{h}_T \in \mathbb{R}^d$ → logits $\mathbf{z} = W_U \mathbf{h}_T \in \mathbb{R}^V$
   (the "unembedding" / LM head). Some models **tie** $W_U = E$ to save $Vd$ parameters.
4. $p(\text{next token}) = \text{softmax}(\mathbf{z})$.

> **In plain English:** the tokenizer chops text into common chunks, the embedding table is a giant
> dictionary that turns each chunk into a list of numbers, and the LM head turns the final numbers back
> into "how likely is each chunk to come next?".
>
> **Example:** "unbelievable!" → tokens `["un", "believ", "able", "!"]` → ids like `[403, 21734, 481, 0]` (illustrative) →
> four rows of the embedding table (4 vectors of 4,096 numbers). After all the layers, the last vector
> is scored against all 32,000 tokens and softmax says e.g. `" It": 12%, " The": 8%, ...`.

**Sanity check you should always do:** at initialization logits are ~uniform, so the loss should
start near $\ln V$. For $V = 32{,}000$ that is $\approx 10.37$. If your first loss is 50, init or
scaling is broken.

---

## 2. Scaled dot-product attention — derived

Each token asks a question (query), advertises what it contains (key), and carries a payload (value):

$$
Q = XW_Q,\quad K = XW_K,\quad V = XW_V \qquad X \in \mathbb{R}^{T\times d},\; W_\cdot \in \mathbb{R}^{d\times d_k}
$$

$$
\text{Attention}(Q,K,V) = \text{softmax}\!\left(\frac{QK^\top}{\sqrt{d_k}} + M\right) V
$$

- $QK^\top \in \mathbb{R}^{T\times T}$: score $s_{ij} = \mathbf{q}_i\cdot\mathbf{k}_j$ — how relevant token $j$ is to token $i$.
- Row-wise softmax turns scores into weights $a_{ij} \ge 0$, $\sum_j a_{ij} = 1$.
- Output row $i$ is $\sum_j a_{ij}\mathbf{v}_j$ — a **weighted average of values**: a differentiable
  dictionary lookup (or, equivalently, a kernel smoother with kernel $e^{\mathbf{q}\cdot\mathbf{k}/\sqrt{d_k}}$).
- **Causal mask** $M_{ij} = -\infty$ if $j > i$ else $0$: token $i$ cannot see the future. $e^{-\infty} = 0$.

> **In plain English:** attention lets every word look around the sentence and borrow meaning from the
> words that matter to it.
>
> **Example:** "The animal didn't cross the street because **it** was too tired."
> - The token "it" sends out a **query**: "I'm a pronoun — what noun am I referring to?"
> - Every token shows a **key** (a label): "animal" says "I'm a living noun", "street" says "I'm a place noun".
> - "it"'s query matches "animal"'s key best → attention weights like `animal: 0.7, street: 0.1, tired: 0.1, …`.
> - "it" then takes a weighted mix of the **values** (the actual content) → its vector now carries
>   "animal-ness", so later layers know who was tired.
>
> Library analogy: query = what you type in the search box, keys = book titles, values = the books'
> contents. Attention returns a blend of books, weighted by how well each title matches your search.
> The causal mask simply means you are only allowed to read books that were written *before* you.

### Why divide by $\sqrt{d_k}$?

If components of $\mathbf{q}, \mathbf{k}$ are independent with mean 0 and variance 1, then
$\mathbf{q}\cdot\mathbf{k} = \sum_{m=1}^{d_k} q_m k_m$ is a sum of $d_k$ terms each with variance 1, so

$$
\mathrm{Var}(\mathbf{q}\cdot\mathbf{k}) = d_k \quad\Rightarrow\quad \mathrm{Var}\!\left(\frac{\mathbf{q}\cdot\mathbf{k}}{\sqrt{d_k}}\right) = 1
$$

Without scaling, scores grow like $\sqrt{d_k}$, softmax saturates to near one-hot, and its
gradient $\text{diag}(\mathbf{p}) - \mathbf{p}\mathbf{p}^\top$ (section 3) goes to ~0 — training stalls.

> **In plain English:** adding up 4,096 small random numbers gives a big number. Big scores make softmax
> "winner-takes-all" (one word gets 100% attention, the rest 0%), and a winner-takes-all choice gives no
> hint about how to improve. Dividing by $\sqrt{d_k}$ turns the volume back down so attention stays a
> soft blend. The demo below shows max attention weight 1.0 (fully saturated) without scaling at
> $d_k = 4096$, vs ~0.27 with scaling.

```python
import numpy as np
rng = np.random.default_rng(0)
def softmax(z, axis=-1):
    z = z - z.max(axis=axis, keepdims=True); e = np.exp(z); return e / e.sum(axis=axis, keepdims=True)

for dk in [16, 256, 4096]:
    q = rng.normal(size=dk); K = rng.normal(size=(8, dk))
    raw, scaled = K @ q, K @ q / np.sqrt(dk)
    print(dk, "raw std≈", raw.std().round(1), "max p raw:", softmax(raw).max().round(3),
          "max p scaled:", softmax(scaled).max().round(3))
```

### Full causal self-attention (single head) in NumPy

```python
def causal_self_attention(X, Wq, Wk, Wv):
    T, dk = X.shape[0], Wq.shape[1]
    Q, K, V = X @ Wq, X @ Wk, X @ Wv
    scores = Q @ K.T / np.sqrt(dk)
    scores = np.where(np.tril(np.ones((T, T), bool)), scores, -np.inf)
    return softmax(scores) @ V

T, d, dk = 5, 16, 8
X = rng.normal(size=(T, d))
Wq, Wk, Wv = (rng.normal(size=(d, dk)) / np.sqrt(d) for _ in range(3))
print(causal_self_attention(X, Wq, Wk, Wv).shape)   # (5, 8)
```

### Multi-head attention

Split $d$ into $h$ heads of size $d_k = d/h$, attend independently, concatenate, project:

$$
\text{MHA}(X) = \text{Concat}(\text{head}_1,\dots,\text{head}_h)\,W_O, \qquad W_O \in \mathbb{R}^{d\times d}
$$

Parameters: $W_Q, W_K, W_V, W_O$ = $4d^2$ (independent of $h$). Heads let the model attend to
different relations (syntax, coreference, position) in different subspaces at the same cost.

*Plain English:* multi-head attention is a team of readers going through the same sentence, each with a
different job — one tracks grammar (which verb goes with which subject), one tracks who "he/she/it"
refers to, one tracks nearby words. Their notes are combined at the end.

**Variants that change KV cost (section 9):**
- **MQA** (multi-query): all heads share one K and one V head.
- **GQA** (grouped-query): $h$ query heads share $g$ KV heads ($1 < g < h$). LLaMA-2/3 70B use $g = 8$.
- **MLA** (multi-head latent attention, DeepSeek-V2/V3): cache a low-rank latent $\mathbf{c} = W_{DKV}\mathbf{x}$
  and up-project to K, V — low-rank factorization (module 01) applied to the cache.

---

## 3. Softmax: Jacobian, temperature, stability

$$
p_i = \frac{e^{z_i}}{\sum_j e^{z_j}}, \qquad
\frac{\partial p_i}{\partial z_j} = p_i(\delta_{ij} - p_j) \;\Longleftrightarrow\; J = \text{diag}(\mathbf{p}) - \mathbf{p}\mathbf{p}^\top
$$

- Softmax is **shift-invariant**: $\text{softmax}(\mathbf{z} + c) = \text{softmax}(\mathbf{z})$ — that is
  why subtracting $\max \mathbf{z}$ is free and prevents overflow.
- When $\mathbf{p}$ is one-hot, $J \to 0$: saturated softmax kills gradients.
- **Attention entropy collapse / logit growth:** large-scale training can see attention logits grow
  until heads become one-hot and loss spikes. Mitigations: QK-norm (normalize $\mathbf{q}, \mathbf{k}$ before
  the dot product), logit soft-capping ($c\tanh(z/c)$, used in Gemma 2), and z-loss (module 05).

---

## 4. Positional information

Attention is **permutation-equivariant** — shuffle the input tokens and outputs shuffle the same way.
Order must be injected.

**Sinusoidal (original Transformer):**

$$
PE_{(pos, 2i)} = \sin\!\left(\frac{pos}{10000^{2i/d}}\right), \qquad PE_{(pos, 2i+1)} = \cos\!\left(\frac{pos}{10000^{2i/d}}\right)
$$

**RoPE (rotary embeddings — LLaMA, Mistral, Qwen, most modern LLMs):** rotate each 2-D pair
$(x_{2i}, x_{2i+1})$ of $\mathbf{q}$ and $\mathbf{k}$ by angle $m\theta_i$, with $m$ the position and
$\theta_i = b^{-2i/d_k}$ ($b = 10000$ by default):

$$
R_m^{(i)} = \begin{pmatrix} \cos m\theta_i & -\sin m\theta_i \\ \sin m\theta_i & \cos m\theta_i \end{pmatrix}
$$

Because rotations are orthogonal and $R_m^\top R_n = R_{n-m}$:

$$
(R_m\mathbf{q})^\top (R_n\mathbf{k}) = \mathbf{q}^\top R_{n-m}\,\mathbf{k}
$$

The attention score depends only on the **relative** offset $n - m$, and norms are preserved.

> **In plain English:** without position info, "dog bites man" and "man bites dog" look identical to
> attention. RoPE turns each word's vector like the hand of a clock — word 1 a little, word 2 a bit more,
> and so on. When two words are compared, only the *angle between* their hands matters, which depends
> only on how far apart they are.
>
> **Example:** clock hands at 1 and 4 o'clock are "3 hours apart", exactly like 9 and 12 o'clock. So
> "the word 3 positions back" looks the same to the model whether it is at the start or the middle of a
> 100-page document. (The code below checks exactly this: positions 3 vs 10 and 103 vs 110 give the same score.)

```python
def rope(x, pos, base=10000.0):
    d = x.shape[-1]; i = np.arange(d // 2)
    ang = pos * base ** (-2 * i / d)
    x1, x2 = x[0::2], x[1::2]
    out = np.empty_like(x)
    out[0::2] = x1 * np.cos(ang) - x2 * np.sin(ang)
    out[1::2] = x1 * np.sin(ang) + x2 * np.cos(ang)
    return out

q, k = rng.normal(size=64), rng.normal(size=64)
print(np.isclose(rope(q, 3) @ rope(k, 10), rope(q, 103) @ rope(k, 110)))   # True: only offset 7 matters
```

**Context extension** works by changing the frequencies: *position interpolation* rescales $m \to m \cdot \frac{L_{train}}{L_{target}}$;
*NTK-aware scaling* / *YaRN* increase the base $b$ (stretching low frequencies more than high ones) so
long positions map into angles the model has seen.

---

## 5. The transformer block (pre-norm, modern form)

$$
\mathbf{x} \leftarrow \mathbf{x} + \text{MHA}(\text{RMSNorm}(\mathbf{x}))
$$
$$
\mathbf{x} \leftarrow \mathbf{x} + \text{FFN}(\text{RMSNorm}(\mathbf{x})), \qquad
\text{FFN}(\mathbf{x}) = W_2\big(\text{SiLU}(W_1\mathbf{x}) \odot W_3\mathbf{x}\big)
$$

Mental model ("residual stream"): the residual vector is a shared bus; each attention and FFN
sub-layer **reads** from it and **adds** a write back. Attention moves information *between*
positions; the FFN transforms information *within* a position (and acts as key–value memory for facts).

---

## 6. Counting parameters

Per layer (ignoring norms/biases):
- Attention: $4d^2$ (with GQA, $W_K, W_V$ shrink to $d \cdot g\,d_k$ each).
- FFN, classic 4× MLP: $2 \cdot d \cdot 4d = 8d^2$. SwiGLU with hidden $\approx \frac{8}{3}d$: $3 \cdot d \cdot \frac{8}{3}d = 8d^2$ — same budget.

$$
N \approx 12\,L\,d^2 + Vd \;\;(\text{+}\,Vd\text{ again if the LM head is untied})
$$

```python
def gpt_params(L, d, V, ffn_hidden=None, untied=False, kv_frac=1.0):
    ffn = 3 * d * ffn_hidden if ffn_hidden else 8 * d * d     # SwiGLU vs 4x MLP
    attn = 2 * d * d + 2 * d * d * kv_frac                    # Q,O full; K,V scaled by GQA
    return L * (attn + ffn) + V * d * (2 if untied else 1)

print(f"GPT-3   : {gpt_params(96, 12288, 50257) / 1e9:.1f}B")                          # ≈ 174.6B (reported 175B)
print(f"LLaMA-2 7B: {gpt_params(32, 4096, 32000, ffn_hidden=11008, untied=True) / 1e9:.2f}B")  # ≈ 6.74B
```

---

## 7. FLOPs: the 2N / 6N rules

A matmul with an $N$-parameter weight matrix costs ~$2N$ FLOPs per token (one multiply + one add per weight). Hence:

| Pass | FLOPs per token |
|---|---|
| Forward (inference) | $\approx 2N$ (+ attention term $\approx 2LTd$ for context length $T$) |
| Backward | $\approx 4N$ (gradients w.r.t. both activations and weights) |
| **Training total** | $\approx 6N$ per token ⇒ $C \approx 6ND$ |

> **In plain English:** every parameter does one multiply and one add for every token it processes,
> hence $2N$. Learning needs the forward pass plus a backward pass that costs about twice as much, hence $6N$.
>
> **Example:** a 7B model generating one word ≈ 14 billion operations. Generating a 500-word answer ≈
> 7 trillion operations. Training it on one word ≈ 42 billion operations.

**Worked estimate — LLaMA-2 7B, 2T tokens, A100s at 40% utilization:**

$$
C = 6 \times 6.7\times10^9 \times 2\times10^{12} \approx 8.0\times10^{22}\ \text{FLOPs}
$$
$$
\frac{8.0\times10^{22}}{312\times10^{12} \times 0.40} \approx 6.4\times10^8\ \text{GPU-s} \approx 179\text{k GPU-hours}
$$

Meta reported ~184k A100-hours. Back-of-envelope math gets you within a few percent — this is how
you sanity-check training budgets and vendor claims.

The attention term matters when $T$ is large relative to $d$: per token it is $\approx 2LTd$ forward
(QKᵀ and AV) vs $\approx 24Ld^2$ for the dense weights, so attention dominates once $T \gtrsim 12d$.

---

## 8. Training objective and scaling laws

**Next-token prediction** over a sequence (teacher forcing — the true previous tokens are fed in,
and the causal mask lets all $T$ positions train in parallel):

$$
\mathcal{L}(\theta) = -\frac{1}{T}\sum_{t=1}^{T}\log p_\theta(x_t \mid x_{<t})
$$

**Chinchilla scaling law** (Hoffmann et al., 2022) fits loss as a function of $N$ and $D$:

$$
L(N, D) = E + \frac{A}{N^{\alpha}} + \frac{B}{D^{\beta}}, \quad
E \approx 1.69,\; A \approx 406.4,\; B \approx 410.7,\; \alpha \approx 0.34,\; \beta \approx 0.28
$$

> **In plain English:** a bigger brain needs more books to read. If you have a fixed budget, don't build
> a giant brain that reads very little, or a tiny brain that reads everything — grow both together.
> Chinchilla's rule of thumb: about **20 training tokens per parameter**.

- $E$ = irreducible entropy of text; the other terms are model-size and data limits.
- Minimizing $L$ subject to $C = 6ND$ gives $N^* \propto C^{a}$, $D^* \propto C^{b}$ with $a \approx b \approx 0.5$ —
  scale parameters and tokens **together**; rule of thumb **$D \approx 20N$** (Chinchilla: 70B params, 1.4T tokens).
- **Production nuance:** Chinchilla minimizes *training* compute. If a model will serve billions of
  tokens, it pays to "over-train" a smaller model far past $20N$ (LLaMA-3 8B saw ~15T tokens ≈ 1,900 tokens/param),
  because inference cost scales with $N$, not $D$.

---

## 9. Inference math: KV cache, prefill vs decode

During generation, K and V for past tokens never change, so they are cached. Memory:

$$
\text{KV bytes} = 2 \times L \times g \times d_k \times T \times B \times \text{bytes per element}
$$

(2 for K and V; $g$ = number of KV heads.)

```python
def kv_cache_gib(L, kv_heads, head_dim, T, B=1, bytes_per=2):
    return 2 * L * kv_heads * head_dim * T * B * bytes_per / 2**30

print(kv_cache_gib(32, 32, 128, 4096))            # LLaMA-2 7B (MHA): 2.0 GiB per 4k-token sequence
print(kv_cache_gib(80, 8, 128, 4096))             # LLaMA-2 70B (GQA g=8): 1.25 GiB per 4k sequence
print(kv_cache_gib(80, 64, 128, 4096))            # same 70B if it were MHA: 10 GiB — GQA saves 8x
```

> **In plain English:** the KV cache is the model's notes while reading. Without notes, writing word
> 501 would mean re-reading all 500 previous words from scratch; with notes, it only processes the new
> word and glances at the notes. The catch: notes take memory, and every user conversation has its own
> notebook. **Example:** 2 GiB of notes per 4,000-word chat on a 7B model means 20 simultaneous long chats
> already need 40 GiB — more than the model weights themselves.

At high concurrency the KV cache, not the weights, becomes the memory bottleneck — hence GQA/MLA,
KV quantization, and paged allocation (vLLM's PagedAttention treats the cache like OS virtual-memory pages).

**Two phases with opposite bottlenecks:**

| Phase | Work | Bottleneck | Metric |
|---|---|---|---|
| Prefill (prompt) | all $T$ prompt tokens in one big matmul | compute (FLOPs) | time to first token (TTFT) |
| Decode | one token per step per sequence; must read **all weights + KV cache** each step | memory bandwidth | time per output token (TPOT) |

> **In plain English:** prefill = reading the whole question at once — lots of parallel work, the GPU's
> math units are busy. Decode = writing the answer one word at a time, and for every single word the GPU
> has to flip through the entire "book" of weights in memory. The math is quick; the page-flipping is slow.
> That is why answers stream out word by word, and why serving many users at once is cheaper: flip through
> the book once, write the next word for 64 users.

Decode ceiling at batch size 1: $\text{tokens/s} \le \frac{\text{HBM bandwidth}}{\text{weight bytes}}$.
A 7B model in bf16 is ~13.5 GB; on an A100 (~2 TB/s) that is $\le$ ~150 tokens/s. Batching $B$
sequences reuses each weight read $B$ times, which is why throughput rises almost linearly with
batch until compute or KV memory runs out (module 09, roofline).

### Speculative decoding (exact, not approximate)

A small draft model $q$ proposes $\gamma$ tokens; the big model $p$ scores them in one parallel pass.
Accept draft token $x$ with probability $\min(1, p(x)/q(x))$; on rejection, resample from
$\text{norm}(\max(0, p - q))$. This provably yields samples **exactly** from $p$. With per-token
acceptance rate $\alpha$, expected tokens per big-model pass:

$$
\mathbb{E}[\text{tokens}] = \frac{1 - \alpha^{\gamma+1}}{1 - \alpha}
$$

e.g. $\alpha = 0.8, \gamma = 4$ ⇒ ~3.4 tokens per expensive forward pass.

> **In plain English:** a junior writer quickly drafts the next 4 words; the senior editor checks all 4 in
> one glance, keeps the ones they agree with, and fixes the first wrong one. Easy text ("Thank you for
> your …") gets accepted wholesale; tricky text gets corrected. The final output is exactly what the
> senior would have written alone — just faster.

---

## 10. FlashAttention and the online softmax

Naive attention materializes the $T\times T$ score matrix in GPU HBM — $O(T^2)$ memory and slow
memory traffic. FlashAttention computes the *exact same result* block by block in on-chip SRAM, using
an **online softmax** that rescales partial results as new maxima appear:

For each new block of scores $\mathbf{s}$ with values $V_b$:

$$
m' = \max(m, \max \mathbf{s}), \quad
\ell' = \ell\,e^{m - m'} + \sum_j e^{s_j - m'}, \quad
\mathbf{acc}' = \mathbf{acc}\,e^{m - m'} + \sum_j e^{s_j - m'}\mathbf{v}_j
$$

and finally $\mathbf{o} = \mathbf{acc} / \ell$.

```python
def online_attention_row(q, K, V, block=4):
    m, l, acc = -np.inf, 0.0, np.zeros(V.shape[1])
    for s in range(0, K.shape[0], block):
        scores = K[s:s+block] @ q / np.sqrt(q.size)
        m_new = max(m, scores.max())
        scale = np.exp(m - m_new)
        p = np.exp(scores - m_new)
        l = l * scale + p.sum()
        acc = acc * scale + p @ V[s:s+block]
        m = m_new
    return acc / l

q = rng.normal(size=32); K = rng.normal(size=(20, 32)); V = rng.normal(size=(20, 16))
full = softmax(K @ q / np.sqrt(32)) @ V
print(np.allclose(online_attention_row(q, K, V), full))   # True — exact, never stores all scores
```

> **In plain English:** to average a giant spreadsheet you don't need to print the whole thing first —
> you can go page by page keeping a running total. The only trick is that softmax needs the maximum, so
> when a new page has a bigger number, you rescale your running total. FlashAttention does exactly that,
> in fast on-chip memory, never writing the giant $T\times T$ table to slow GPU memory.

Compute is still $O(T^2 d)$; the win is IO — memory drops to $O(T)$ and HBM reads/writes fall sharply.

---

## 11. Decoding: temperature, top-k, top-p

$$
p_i^{(\tau)} = \frac{e^{z_i/\tau}}{\sum_j e^{z_j/\tau}}
$$

- $\tau \to 0$: argmax (greedy). $\tau = 1$: model's distribution. $\tau \to \infty$: uniform.
> **In plain English:** temperature is a creativity dial. **Example:** "The sky is ___" with logits
> `blue: 3, clear: 2, falling: 0`:
>
> | Temperature | blue | clear | falling | Feels like |
> |---|---|---|---|---|
> | 0.5 | 88% | 12% | 0.2% | safe, predictable |
> | 1.0 | 71% | 26% | 3.5% | the model's natural voice |
> | 2.0 | 55% | 33% | 12% | creative, sometimes nonsense |
>
> Top-k / top-p cut off the long tail of silly options (like "falling") before rolling the die.

- **Top-k:** keep the $k$ highest logits. **Top-p (nucleus):** keep the smallest set whose
  probability mass $\ge p$ — adapts to how peaked the distribution is. **Min-p:** keep tokens with
  $p_i \ge p_{\min}\cdot \max_j p_j$.
- **Beam search:** keep the $B$ highest-scoring partial sequences by total log-probability $\sum_t\log p(x_t\mid x_{<t})$,
  usually divided by $\text{length}^\alpha$ because every extra token adds a negative term and would otherwise
  favour short outputs. *Example:* greedy takes "The" (0.5) then "cat" (0.4) = 0.20 overall; beam search with
  $B = 2$ also keeps "A" (0.4), whose best continuation "dog" (0.9) gives 0.36 — a better full sequence that
  greedy never sees. Good for translation, speech recognition, and short structured outputs; for open-ended
  chat it yields bland, repetitive text, so sampling is the default there.
- **Note for engineers:** `temperature=0` makes sampling deterministic in *math*, but GPU batching and
  floating-point non-associativity can still change outputs across runs. Do not build correctness on it.

```python
def sample(logits, temperature=1.0, top_k=None, top_p=None, rng=rng):
    z = logits / max(temperature, 1e-6)
    if top_k is not None:
        kth = np.sort(z)[-top_k]
        z = np.where(z < kth, -np.inf, z)
    p = softmax(z)
    if top_p is not None:
        order = np.argsort(p)[::-1]
        cum = np.cumsum(p[order])
        keep = order[(cum - p[order]) < top_p]       # include the token that crosses the threshold
        mask = np.zeros_like(p, bool); mask[keep] = True
        p = np.where(mask, p, 0.0); p /= p.sum()
    return rng.choice(len(p), p=p)

logits = np.array([3.0, 2.5, 1.0, 0.2, -1.0])
print([sample(logits, temperature=0.7, top_p=0.9) for _ in range(12)])
```

---

## 12. Fine-tuning math: LoRA and QLoRA

Freeze $W_0 \in \mathbb{R}^{d\times k}$; learn a low-rank update:

$$
W = W_0 + \frac{\alpha}{r} BA, \qquad B \in \mathbb{R}^{d\times r},\; A \in \mathbb{R}^{r\times k},\; r \ll \min(d,k)
$$

- $B$ is initialized to **zero**, so training starts exactly at the pretrained model.
- Trainable params: $r(d + k)$ instead of $dk$. For $d = k = 4096$, $r = 16$: 131k vs 16.8M — **0.78%**.
- At deployment, merge $W_0 + \frac{\alpha}{r}BA$ into one matrix: zero extra latency. Or keep adapters
  separate to hot-swap many tenants on one base model.
- *Plain English:* instead of rewriting a 1,000-page company manual for a new department, you clip on a
  2-page appendix of adjustments. The manual (base model) stays untouched; the appendix (adapter) is tiny,
  cheap to train, and you can keep a different appendix per customer.
- Why it works: empirically, fine-tuning updates have low "intrinsic rank" — the SVD of $\Delta W$
  concentrates in a few directions.
- **QLoRA:** store $W_0$ in 4-bit NF4 (quantile levels designed for normally distributed weights),
  dequantize on the fly, train LoRA adapters in bf16 — fine-tune a 65B model on a single 48 GB GPU.

---

## 13. Quantization math

**Affine (asymmetric) quantization** to $b$ bits:

$$
q = \text{clip}\!\left(\text{round}\!\left(\frac{x}{s}\right) + z,\; 0,\; 2^b - 1\right), \qquad \hat{x} = s\,(q - z)
$$

**Symmetric int8:** $s = \max|x| / 127$, $z = 0$. Rounding error is roughly uniform on $[-s/2, s/2]$,
variance $s^2/12$ — so **one outlier inflates $s$ and destroys precision for everyone else** in the group.

```python
def quant_sym(x, bits=8, axis=None):
    qmax = 2 ** (bits - 1) - 1
    s = np.abs(x).max(axis=axis, keepdims=True) / qmax
    return np.round(x / s).clip(-qmax, qmax) * s

W = rng.normal(0, 0.02, size=(256, 256)); W[3, 7] = 2.0          # one outlier weight
err = lambda Wq: np.abs(W - Wq).mean()
print("per-tensor int8:", err(quant_sym(W)))                   # large error everywhere
print("per-row    int8:", err(quant_sym(W, axis=1)))           # outlier only hurts its own row
print("per-row    int4:", err(quant_sym(W, bits=4, axis=1)))
```

> **In plain English:** quantization = storing numbers with fewer digits, like rounding prices to the
> nearest rupee instead of keeping paise. It shrinks the model 2–4× and speeds it up, at a small accuracy cost.
>
> **Example of the outlier problem:** you must measure every item in a shop with one ruler that has
> only 255 marks. If the most expensive item is ₹1,000, each mark is ~₹8 — fine. If one item costs
> ₹1 crore, each mark is ~₹78,000, and every normal item rounds to ₹0. Fix: a separate ruler per shelf
> (per-channel / group-wise scales). That is what the demo above shows: per-row scales cut the error ~30×.

Industry techniques are all about outliers and error compensation:
- **Per-channel / group-wise** scales (e.g. groups of 128 weights).
- **LLM.int8()**: keep outlier feature dimensions in fp16, the rest in int8.
- **GPTQ**: quantize column by column and update remaining weights to compensate, using second-order
  (Hessian $\approx 2XX^\top$ of layer inputs) information.
- **AWQ / SmoothQuant**: rescale channels so activation outliers move into weights, which quantize more easily.

Memory rule: bytes ≈ $N \times \frac{\text{bits}}{8}$. 70B params: fp16 ≈ 140 GB, int8 ≈ 70 GB, int4 ≈ 35 GB (+ scales, KV cache, activations).

---

## 14. Alignment math: reward models, RLHF, DPO, GRPO

**Reward model (Bradley–Terry):** humans prefer $y_w$ over $y_l$ with probability

$$
P(y_w \succ y_l \mid x) = \sigma\big(r(x, y_w) - r(x, y_l)\big), \qquad
\mathcal{L}_{RM} = -\log\sigma\big(r(x, y_w) - r(x, y_l)\big)
$$

**RLHF objective:** maximize reward while staying close to the reference (SFT) model:

$$
\max_\pi \; \mathbb{E}_{x, y\sim\pi}\big[r(x, y)\big] - \beta\, D_{KL}\big(\pi(\cdot\mid x)\,\|\,\pi_{ref}(\cdot\mid x)\big)
$$

Optimized with **policy gradient** — the log-derivative trick lets you differentiate an expectation
over discrete samples:

$$
\nabla_\theta\,\mathbb{E}_{y\sim\pi_\theta}[R(y)] = \mathbb{E}_{y\sim\pi_\theta}\big[R(y)\,\nabla_\theta\log\pi_\theta(y)\big]
$$

**PPO** stabilizes this by clipping the probability ratio $\rho = \pi_\theta/\pi_{old}$ to $[1-\epsilon, 1+\epsilon]$:
$\mathcal{L} = -\mathbb{E}\big[\min(\rho A,\ \text{clip}(\rho, 1-\epsilon, 1+\epsilon)A)\big]$, with advantage $A$ from a learned value model.

> **In plain English:** RLHF is like training a dog: a judge (reward model) hands out treats for good
> answers, and a leash (the KL term) stops the model wandering too far from how it originally behaved —
> otherwise it learns to game the judge with weird answers that score high but read badly.

**DPO** — the RLHF objective has a closed-form optimal policy
$\pi^*(y\mid x) \propto \pi_{ref}(y\mid x)\,e^{r(x,y)/\beta}$. Inverting it expresses the reward through the
policy, and plugging into Bradley–Terry gives a plain classification loss — no reward model, no RL loop:

$$
\mathcal{L}_{DPO} = -\log\sigma\!\left(\beta\log\frac{\pi_\theta(y_w\mid x)}{\pi_{ref}(y_w\mid x)} - \beta\log\frac{\pi_\theta(y_l\mid x)}{\pi_{ref}(y_l\mid x)}\right)
$$

```python
def dpo_loss(logp_w, logp_l, ref_logp_w, ref_logp_l, beta=0.1):
    margin = beta * ((logp_w - ref_logp_w) - (logp_l - ref_logp_l))
    return np.log1p(np.exp(-margin))          # = -log σ(margin), numerically stable for margin > -30

print(dpo_loss(-12.0, -15.0, -13.0, -14.0))   # policy prefers y_w more than ref does → loss < ln2
```

*Plain English for DPO:* skip the judge and the treats. Show the model pairs — "for this question,
answer A was better than answer B" — and directly make A more likely and B less likely (relative to
the original model).

**GRPO** (DeepSeekMath / R1, used for reasoning RL): sample a group of $G$ answers per prompt,
score them (often with a verifier: unit tests, exact-match math), and use the group-normalized reward as
the advantage — no value network:

$$
A_i = \frac{r_i - \text{mean}(r_{1..G})}{\text{std}(r_{1..G})}
$$

*Plain English for GRPO:* the model attempts the same math problem 8 times; answers are graded right or
wrong. Answers better than the group average get reinforced, worse ones get discouraged — grading on a
curve within the group, so no separate "critic" model is needed.

---

## 15. Mixture of Experts (MoE)

Replace the FFN with $E$ expert FFNs and a router:

$$
\mathbf{y} = \sum_{i \in \text{TopK}(\mathbf{g})} \tilde{g}_i\,\text{FFN}_i(\mathbf{x}), \qquad \mathbf{g} = \text{softmax}(W_r\mathbf{x})
$$

where $\tilde{g}_i$ are the top-$k$ gate values (renormalized in most implementations).

- *Plain English:* a hospital with 8 specialists and a receptionist (the router). Each patient (token)
  sees only the 2 most relevant specialists. The hospital has lots of expertise (total parameters),
  but each visit costs only two consultations (active parameters).
- **Total vs active parameters:** Mixtral 8×7B has ~47B total but ~13B active per token (top-2 of 8).
  Memory scales with *total*, FLOPs per token with *active*.
- **Load balancing:** without help the router collapses onto a few experts. Switch Transformer adds
  $\mathcal{L}_{aux} = \alpha E\sum_i f_i P_i$ ($f_i$ = fraction of tokens routed to expert $i$, $P_i$ = mean router
  probability); DeepSeek-V3 uses bias-based balancing without an auxiliary loss.

---

## 16. Embedding models (the math behind RAG)

Trained with **contrastive InfoNCE** over a batch: one positive document $d^+$ per query, other batch
items as negatives:

$$
\mathcal{L} = -\log\frac{\exp(\cos(\mathbf{q}, \mathbf{d}^+)/\tau)}{\sum_{j}\exp(\cos(\mathbf{q}, \mathbf{d}_j)/\tau)}
$$

- *Plain English:* a matching game. Put 1,000 questions and their 1,000 correct answers on a table; the
  model is rewarded for pulling each question's vector close to its own answer and pushing it away from
  the other 999. After millions of rounds, "similar meaning" = "nearby vectors".
- It is softmax cross-entropy where the "classes" are the documents in the batch → larger batches =
  more negatives = better embeddings. Hard negatives matter more than random ones.
- Temperature $\tau$ (~0.01–0.05) sharpens the distribution.
- **Matryoshka embeddings** train so that prefixes of the vector (e.g. first 256 of 1024 dims) are
  themselves good embeddings — trade accuracy for index size.
- **ANN search** (HNSW, IVF-PQ) trades exact recall for speed; product quantization splits a vector into
  $m$ sub-vectors and replaces each with a centroid id — k-means (module 08) applied to compression.

## Key takeaways

1. Attention = softmax$(QK^\top/\sqrt{d_k})V$; the $\sqrt{d_k}$ keeps score variance at 1.
2. $N \approx 12Ld^2$; training $C \approx 6ND$; inference $\approx 2N$ FLOPs/token.
3. KV cache $= 2 L g d_k T B \times$ bytes — it limits concurrency; GQA/MLA/paging fight it.
4. Prefill is compute-bound, decode is bandwidth-bound.
5. LoRA = low-rank update; quantization = scale/round with outlier management.
6. RLHF = reward − β·KL; DPO turns it into a classification loss; GRPO uses group-relative advantages.

Next: [08 — Classical ML math](08_classical_ml_math.md)
