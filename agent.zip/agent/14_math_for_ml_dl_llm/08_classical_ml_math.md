# 08 — Classical ML Math: The Derivations Interviewers and Papers Assume

> **Why it matters:** deep learning did not replace this math — it generalizes it. Linear
> regression is a one-layer net with MSE; logistic regression is one layer + sigmoid + cross-entropy;
> PCA is SVD; k-means is the core of product quantization; gradient boosting still wins on tabular data.
> Senior ML interviews and design reviews expect you to derive these on a whiteboard.

---

## 1. Linear regression — three views of one answer

Model $\hat{\mathbf{y}} = X\mathbf{w}$, with $X \in \mathbb{R}^{n\times p}$. Minimize squared error:

$$
\mathcal{L}(\mathbf{w}) = \|X\mathbf{w} - \mathbf{y}\|^2 = \mathbf{w}^\top X^\top X\mathbf{w} - 2\mathbf{y}^\top X\mathbf{w} + \mathbf{y}^\top\mathbf{y}
$$

> **In plain English:** draw the straight line through a scatter of points that has the smallest total
> squared miss. **Example:** house price ≈ ₹20 lakh base + ₹5,000 per sq ft × size. Linear regression
> learns the "₹20 lakh" and the "₹5,000" from past sales. Squaring the misses means one ₹10 lakh miss
> hurts as much as a hundred ₹1 lakh misses — big errors are punished hard.

**Calculus view.** Using $\nabla_\mathbf{w}(\mathbf{w}^\top A\mathbf{w}) = 2A\mathbf{w}$ for symmetric $A$:

$$
\nabla\mathcal{L} = 2X^\top X\mathbf{w} - 2X^\top\mathbf{y} = 0 \;\Rightarrow\; \boxed{\mathbf{w}^* = (X^\top X)^{-1}X^\top\mathbf{y}}
$$

**Geometry view.** $X\mathbf{w}^*$ is the orthogonal projection of $\mathbf{y}$ onto the column space of $X$;
the residual is perpendicular to every column: $X^\top(\mathbf{y} - X\mathbf{w}^*) = 0$ (the "normal equations").
The projection ("hat") matrix is $H = X(X^\top X)^{-1}X^\top$.

**Probability view.** If $y = \mathbf{w}^\top\mathbf{x} + \varepsilon$, $\varepsilon \sim \mathcal{N}(0,\sigma^2)$, maximizing likelihood
gives the same $\mathbf{w}^*$ (module 03): MSE = Gaussian MLE.

**Engineering note:** never compute the inverse. $\kappa(X^\top X) = \kappa(X)^2$, so forming $X^\top X$ squares the
condition number and loses precision. Use QR/SVD (`np.linalg.lstsq`) or iterative solvers.

### Ridge (L2) regression

$$
\mathbf{w}^*_\lambda = (X^\top X + \lambda I)^{-1}X^\top\mathbf{y}
$$

With the SVD $X = U\Sigma V^\top$:

$$
\mathbf{w}^*_\lambda = \sum_i \frac{\sigma_i}{\sigma_i^2 + \lambda}\,(\mathbf{u}_i^\top\mathbf{y})\,\mathbf{v}_i
$$

*Plain English:* ridge adds a "keep it simple" penalty — weights must earn their size. **Example:** if
"square feet" and "number of rooms" carry nearly the same information, plain regression might give one
a weight of +900 and the other −880 (cancelling out, wildly unstable). Ridge prefers +10 and +10.

Directions with small singular values (noisy, poorly determined) are shrunk the most; $\lambda I$ also
guarantees invertibility. Bayesian view: ridge = MAP estimate under a Gaussian prior $\mathbf{w}\sim\mathcal{N}(0, \frac{\sigma^2}{\lambda}I)$.
**Lasso** (L1) = Laplace prior; its corners at zero produce sparse solutions.

```python
import numpy as np
rng = np.random.default_rng(0)
n, p = 200, 5
X = rng.normal(size=(n, p)); w_true = np.array([1.5, -2.0, 0.0, 0.7, 3.0])
y = X @ w_true + rng.normal(0, 0.1, n)

w_normal = np.linalg.solve(X.T @ X, X.T @ y)
w_lstsq = np.linalg.lstsq(X, y, rcond=None)[0]
lam = 10.0
w_ridge = np.linalg.solve(X.T @ X + lam * np.eye(p), X.T @ y)
print(np.round(w_normal, 3), np.allclose(w_normal, w_lstsq))
print("ridge shrinks:", np.round(w_ridge, 3))
print("residual ⟂ columns:", np.allclose(X.T @ (y - X @ w_lstsq), 0, atol=1e-8))
```

---

## 2. Logistic regression — convex, with a clean gradient

$p_i = \sigma(\mathbf{w}^\top\mathbf{x}_i)$, negative log-likelihood:

$$
\mathcal{L} = -\sum_i \big[y_i\log p_i + (1-y_i)\log(1-p_i)\big]
$$

Using $\sigma' = \sigma(1-\sigma)$, the terms cancel beautifully:

$$
\nabla\mathcal{L} = X^\top(\mathbf{p} - \mathbf{y}), \qquad \nabla^2\mathcal{L} = X^\top S X,\; S = \text{diag}\big(p_i(1-p_i)\big)
$$

*Plain English:* logistic regression is linear regression squashed into a probability between 0 and 1.
**Example:** spam score $= 2\times(\text{has "free money"}) + 1.5\times(\text{unknown sender}) - 3$; the sigmoid
turns a score of 0.5 into a 62% spam probability. The gradient "predicted minus actual" says: if you
said 62% and it *was* spam, nudge the weights up by 0.38-worth.

$X^\top S X$ is positive semidefinite ⇒ the loss is **convex** ⇒ one global minimum. Newton's method
$\mathbf{w} \leftarrow \mathbf{w} - (X^\top SX)^{-1}X^\top(\mathbf{p}-\mathbf{y})$ is known as IRLS and converges in a handful of steps.

Gotcha: on **linearly separable** data the MLE does not exist — $\|\mathbf{w}\| \to \infty$ to push probabilities to 0/1.
Regularization fixes it. (The same overconfidence pressure exists in neural nets; label smoothing is one fix.)

```python
sigmoid = lambda z: 1 / (1 + np.exp(-z))
Xc = np.c_[np.ones(n), X[:, :2]]
yc = (X[:, 0] - 2 * X[:, 1] + rng.normal(0, 1.0, n) > 0).astype(float)
w = np.zeros(3)
for it in range(8):                                   # Newton / IRLS
    p_ = sigmoid(Xc @ w)
    grad = Xc.T @ (p_ - yc)
    H = Xc.T @ (Xc * (p_ * (1 - p_))[:, None]) + 1e-6 * np.eye(3)
    w -= np.linalg.solve(H, grad)
print("logistic weights:", np.round(w, 2))
```

**Softmax regression** generalizes to $K$ classes: $\nabla_W\mathcal{L} = X^\top(P - Y)$ — the identical
"predicted minus true" gradient you meet again at the top of every LLM (module 04).

---

## 3. Bias–variance decomposition (derive it)

Let $y = f(x) + \varepsilon$, $\mathbb{E}[\varepsilon] = 0$, $\mathrm{Var}(\varepsilon) = \sigma^2$, and $\hat{f}$ trained on a random dataset.
Write $\bar{f} = \mathbb{E}[\hat{f}(x)]$. Expanding and noting the cross terms have zero expectation:

$$
\mathbb{E}\big[(y - \hat{f}(x))^2\big] = \underbrace{(f(x) - \bar{f}(x))^2}_{\text{bias}^2} + \underbrace{\mathbb{E}\big[(\hat{f}(x) - \bar{f}(x))^2\big]}_{\text{variance}} + \underbrace{\sigma^2}_{\text{irreducible}}
$$

> **In plain English — the dartboard:** bias = your darts are consistently off to the left (wrong aim);
> variance = your darts are scattered all over (shaky hand); noise = the wind, which you cannot control.
> A straight line fit to a curved trend has high bias; a wiggly curve through every training point has
> high variance.

- Simple models: high bias. Flexible models: high variance. Regularization, more data, and
  ensembling (bagging averages away variance) move along the tradeoff.
- **Modern caveat — double descent:** past the interpolation threshold (params ≈ data points),
  test error can fall again as models grow. Over-parameterized nets plus implicit regularization from
  SGD generalize well, which is why "bigger model + more data" works for LLMs despite the classical curve.

---

## 4. Support Vector Machines and the kernel trick

Maximize the margin $\frac{2}{\|\mathbf{w}\|}$ between classes $y_i \in \{-1, +1\}$. Soft-margin primal:

$$
\min_{\mathbf{w}, b}\; \frac{1}{2}\|\mathbf{w}\|^2 + C\sum_i \max\big(0,\; 1 - y_i(\mathbf{w}^\top\mathbf{x}_i + b)\big)
$$

The second term is the **hinge loss**. The Lagrangian dual depends on the data only through inner
products $\mathbf{x}_i^\top\mathbf{x}_j$, so replace them with a kernel $K(\mathbf{x}_i, \mathbf{x}_j) = \phi(\mathbf{x}_i)^\top\phi(\mathbf{x}_j)$ and you
get a linear classifier in a (possibly infinite-dimensional) feature space without ever computing $\phi$.
RBF kernel: $K(\mathbf{x}, \mathbf{x}') = \exp(-\gamma\|\mathbf{x} - \mathbf{x}'\|^2)$.

> **In plain English:** an SVM draws the *widest possible street* between two neighbourhoods, so new
> houses near the border are still classified confidently. The kernel trick: if red and blue dots are
> mixed on a flat table (say blue in the middle, red in a ring around them), lift the middle ones up into
> a hill — now a flat sheet can slice between them. The kernel does that "lifting" implicitly.

Connection: attention weights $\propto \exp(\mathbf{q}^\top\mathbf{k})$ are an (unnormalized) exponential kernel —
attention is a learned kernel smoother, and "linear attention" papers approximate that kernel with feature maps.

---

## 5. PCA — derived as an eigenproblem

Center the data; covariance $\Sigma = \frac{1}{n-1}X^\top X$. Find the unit direction of maximum variance:

$$
\max_{\mathbf{w}}\; \mathbf{w}^\top\Sigma\mathbf{w} \quad \text{s.t.}\; \|\mathbf{w}\| = 1
$$

Lagrangian $\mathbf{w}^\top\Sigma\mathbf{w} - \lambda(\mathbf{w}^\top\mathbf{w} - 1)$ ⇒ $\Sigma\mathbf{w} = \lambda\mathbf{w}$. The variance captured equals $\lambda$, so take
the top eigenvectors. Equivalently, from the SVD $X = U S V^\top$: principal directions are columns of $V$,
and eigenvalues are $s_i^2/(n-1)$. Fraction of variance explained by top $k$: $\sum_{i\le k} s_i^2 / \sum_i s_i^2$.

```python
Z = rng.normal(size=(500, 2)) @ np.array([[3.0, 0.0], [1.0, 0.5]])   # correlated 2-D data
Zc = Z - Z.mean(0)
U, S, Vt = np.linalg.svd(Zc, full_matrices=False)
eig = np.linalg.eigh(np.cov(Zc.T))[0][::-1]
print("SVD-based eigenvalues:", np.round(S**2 / (len(Z) - 1), 3), " eigh:", np.round(eig, 3))
print("variance explained by PC1:", round(S[0]**2 / (S**2).sum(), 3))
```

> **In plain English:** PCA finds the camera angle that shows the most of an object. **Example:** height
> and weight of people are strongly related, so one combined "body size" number captures ~90% of what
> both columns say. The demo above: one direction explains 98% of the variation in the 2-D data.
> For 4,096-D embeddings, PCA down to 2-D lets you plot them and *see* clusters.

Used for: visualizing embeddings, whitening, denoising, and analyzing the (often anisotropic) geometry of LLM embedding spaces.

---

## 6. k-means and Gaussian mixtures

Objective: $\min \sum_i \|\mathbf{x}_i - \boldsymbol{\mu}_{c(i)}\|^2$. Lloyd's algorithm alternates
(1) assign each point to the nearest centroid, (2) move each centroid to its cluster mean. Each step
cannot increase the objective, so it converges — to a *local* optimum (use k-means++ init and restarts).

*Plain English:* place $k$ pizza shops in a city so customers walk as little as possible. Assign each
customer to the nearest shop, move each shop to the middle of its customers, repeat until nothing moves.

k-means is the hard-assignment, equal-isotropic-variance limit of **EM for a Gaussian mixture model**.
In AI systems you meet it in IVF vector indexes (coarse clustering), product quantization (codebooks),
and data deduplication / curation pipelines.

---

## 7. Trees and gradient boosting

- **Split criteria:** entropy $H = -\sum_k p_k\log p_k$ or Gini $G = 1 - \sum_k p_k^2$; choose the split
  maximizing information gain $H(\text{parent}) - \sum_c \frac{n_c}{n}H(c)$.
- **Gradient boosting = gradient descent in function space.** Model $F_m = F_{m-1} + \eta\,h_m$ where tree $h_m$
  is fit to the negative gradient $-\partial\ell/\partial F$ at each training point. For MSE that is literally the
  residuals $y - F_{m-1}(x)$; for log-loss it is $y - p$. XGBoost/LightGBM add a second-order (Newton) term
  and regularization on leaf weights.

*Plain English:* a decision tree is a game of 20 questions ("income > 50k?", "age < 30?"). Boosting is a
relay of students: the first answers the exam, the second studies only what the first got wrong, the
third fixes what's still wrong, and so on. The final answer is the sum of all their contributions.

---

## 8. Naive Bayes

$$
P(y \mid \mathbf{x}) \propto P(y)\prod_j P(x_j \mid y)
$$

Assumes features are conditionally independent given the class — wrong, but often good enough for text.
Compute in log space ($\log P(y) + \sum_j \log P(x_j\mid y)$) to avoid underflow; use Laplace smoothing
to avoid zero probabilities. It is a useful, cheap baseline for routing/classification before reaching for an LLM.

---

## 9. Evaluation math you will be asked about

| Metric | Formula | Notes |
|---|---|---|
| Precision / recall | $\frac{TP}{TP+FP}$, $\frac{TP}{TP+FN}$ | trade off via threshold |
| $F_\beta$ | $(1+\beta^2)\frac{PR}{\beta^2 P + R}$ | $\beta > 1$ weights recall |
| ROC-AUC | $P(\text{score}(x^+) > \text{score}(x^-))$ | threshold-free; misleading under heavy imbalance |
| PR-AUC | area under precision–recall | prefer for rare positives (fraud, safety violations) |
| ECE (calibration) | $\sum_m \frac{\lvert B_m\rvert}{n}\lvert\text{acc}(B_m) - \text{conf}(B_m)\rvert$ | are 80%-confidence answers right 80% of the time? |
| Recall@k | fraction of relevant docs in top $k$ | RAG retriever quality |
| MRR | $\frac{1}{\lvert Q\rvert}\sum_q \frac{1}{\text{rank}_q}$ | first relevant result position |
| nDCG@k | $\frac{\text{DCG}}{\text{IDCG}}$, $\text{DCG} = \sum_{i=1}^{k}\frac{2^{rel_i}-1}{\log_2(i+1)}$ | graded relevance, position-discounted |

> **In plain English:** AUC answers "pick one random sick patient and one random healthy one — how often
> does the test give the sick one a higher score?" 0.5 = coin flip, 1.0 = perfect. **Precision vs
> recall example:** a guardrail flags 100 prompts, 80 truly malicious → precision 80%. There were 200
> malicious prompts in total → recall 40% (it missed 120). **MRR example:** the right document is ranked
> 1st, 3rd, and 2nd for three queries → MRR = (1 + 1/3 + 1/2) / 3 ≈ 0.61.

ROC-AUC equals the normalized Mann–Whitney U statistic — computable by ranking:

```python
def auc(scores, labels):
    order = np.argsort(scores); ranks = np.empty(len(scores)); ranks[order] = np.arange(1, len(scores) + 1)
    pos = labels == 1; n_pos, n_neg = pos.sum(), (~pos).sum()
    return (ranks[pos].sum() - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)

s = rng.normal(size=1000); lab = (s + rng.normal(0, 1, 1000) > 0).astype(int)
pairs = (s[lab == 1][:, None] > s[lab == 0][None, :]).mean()
print(round(auc(s, lab), 4), round(pairs, 4))   # identical
```

## Key takeaways

1. Linear regression = projection = Gaussian MLE; solve with QR/SVD, never an explicit inverse.
2. Logistic/softmax regression gradient = $X^\top(\mathbf{p} - \mathbf{y})$; loss is convex.
3. Ridge shrinks low-singular-value directions; L2 = Gaussian prior, L1 = Laplace prior.
4. Bias² + variance + noise — and double descent explains why huge models still generalize.
5. PCA = top eigenvectors of covariance = SVD; k-means powers vector-index compression.
6. Boosting is gradient descent over functions.

Next: [09 — ML systems math](09_ml_systems_math.md)
