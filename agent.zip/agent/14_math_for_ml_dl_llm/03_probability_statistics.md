# 03 — Probability & Statistics: Reasoning Under Uncertainty

> **Why it matters:** ML models output probabilities, are trained by maximizing likelihood,
> and are evaluated with statistics. An LLM is literally a probability distribution over the
> next token: $P(x_t \mid x_1, \dots, x_{t-1})$.

## 1. Basics

- **Random variable** $X$: a quantity with uncertain value (a die roll, the next token).
- **Probability distribution:** assigns probabilities to outcomes; they sum (or integrate) to 1.
- **Discrete** (tokens, classes) uses a probability mass function $P(X=x)$.
  **Continuous** (heights, weights of a network) uses a density $p(x)$.

> **In plain English:** an LLM's next-token prediction is a loaded die with ~32,000 faces, one per
> token. After "The capital of France is", the "Paris" face is weighted at, say, 90%; "a" at 3%; and
> so on. Generating text = rolling that die, appending the result, and rolling a freshly loaded die.

Rules:

$$
P(A, B) = P(A \mid B)\,P(B) \qquad \text{(product rule)}
$$
$$
P(A) = \sum_b P(A, B=b) \qquad \text{(sum rule / marginalization)}
$$

**Chain rule of probability** — the foundation of autoregressive LLMs:

$$
P(x_1, \dots, x_T) = \prod_{t=1}^{T} P(x_t \mid x_1, \dots, x_{t-1})
$$

## 2. Bayes' theorem

$$
P(H \mid D) = \frac{P(D \mid H)\,P(H)}{P(D)}
$$

posterior = likelihood × prior / evidence.

**Example:** a spam filter flags 99% of spam and 2% of normal mail. 10% of mail is spam.
Given a flag, the chance it is spam:

$$
\frac{0.99 \times 0.10}{0.99 \times 0.10 + 0.02 \times 0.90} = \frac{0.099}{0.117} \approx 0.846
$$

> **In plain English (the easy way to do Bayes): count people, not probabilities.** Take 1,000 emails.
> 100 are spam → 99 get flagged. 900 are normal → 2% = 18 get flagged by mistake. Total flagged = 117,
> of which 99 are spam → 99/117 ≈ 85%. Same answer, no formula.

Lesson: base rates matter. The same reasoning applies to guardrail classifiers and
hallucination detectors — a "99% accurate" detector can still be wrong most of the time on rare events.

## 3. Expectation, variance, standard deviation

$$
\mathbb{E}[X] = \sum_x x\,P(x), \qquad
\mathrm{Var}(X) = \mathbb{E}[(X - \mathbb{E}[X])^2], \qquad
\sigma = \sqrt{\mathrm{Var}(X)}
$$

> **In plain English:** expectation = the long-run average; variance = how spread out the results are.
> **Example:** a fair die averages 3.5 (you never roll 3.5, but that is the average over many rolls).
> Two salespeople both average ₹50k/month, but one earns ₹49–51k (low variance) and the other ₹0–100k
> (high variance).

- The training loss is an **expectation** over the data distribution; a mini-batch average is an
  estimate of it — that is why SGD is noisy.
- **Variance of activations** across layers is what initialization schemes control (module 06).

```python
import numpy as np
samples = np.random.normal(loc=2.0, scale=3.0, size=100_000)
print(samples.mean(), samples.var())   # ≈ 2.0, ≈ 9.0
```

## 4. Distributions you will meet

| Distribution | What it models | ML use |
|---|---|---|
| Bernoulli($p$) | one yes/no | binary classification output |
| Categorical($\mathbf{p}$) | one of $K$ classes | softmax output, next-token prediction |
| Gaussian $\mathcal{N}(\mu, \sigma^2)$ | continuous noise | weight init, regression noise, diffusion models, VAEs |
| Uniform | equal chance | random init, dropout masks |
| Poisson($\lambda$) | count of events in a time window | requests/second hitting an inference endpoint (capacity planning) |
| Beta($\alpha, \beta$) | an unknown probability (between 0 and 1) | uncertainty about a success/click rate, A/B tests, Thompson sampling |
| Dirichlet($\boldsymbol{\alpha}$) | an unknown probability *vector* | prior over categorical distributions, topic models (LDA) |

*Plain English for Poisson:* if an endpoint averages $\lambda = 50$ requests/s, the count in any given second
varies with standard deviation $\sqrt{\lambda} \approx 7$ — so provisioning for ~71 req/s (mean + 3 std) covers
almost every second. *Beta:* after 8 successes and 2 failures, Beta(9, 3) describes your belief about the
true success rate — centred near 0.75 but still wide, because 10 trials is not much evidence.

Gaussian density:

$$
p(x) = \frac{1}{\sqrt{2\pi\sigma^2}} \exp\!\left(-\frac{(x-\mu)^2}{2\sigma^2}\right)
$$

### Integrals — the one place you need them

For continuous variables, sums become integrals:

$$
\int_{-\infty}^{\infty} p(x)\,dx = 1, \qquad P(a \le X \le b) = \int_a^b p(x)\,dx, \qquad \mathbb{E}[X] = \int x\,p(x)\,dx
$$

A density value is **not** a probability and can exceed 1 (the peak of $\mathcal{N}(0, 0.1^2)$ is ≈ 3.99); only
areas under the curve are probabilities. In ML you rarely solve integrals by hand: they cancel in ratios,
have closed forms (Gaussians), or are approximated with samples (Monte Carlo, section 8.4).

> **In plain English:** an integral is the area under a curve, found by adding up infinitely many thin
> slices. "Probability that a user waits between 1 and 2 seconds" = the area under the wait-time curve
> between 1 and 2.

```python
x = np.linspace(-10, 10, 200_001); dx = x[1] - x[0]
p = np.exp(-x**2 / (2 * 0.1**2)) / np.sqrt(2 * np.pi * 0.1**2)       # N(0, 0.1^2)
print("peak density:", p.max().round(2), " total area:", (p * dx).sum().round(4),
      " P(-0.1<X<0.1):", (p[np.abs(x) < 0.1] * dx).sum().round(3))  # 3.99, 1.0, 0.683
```

## 5. Maximum Likelihood Estimation (MLE)

Pick parameters $\theta$ that make the observed data most probable:

$$
\theta^* = \arg\max_\theta \prod_i P(x_i \mid \theta)
= \arg\min_\theta \; -\sum_i \log P(x_i \mid \theta)
$$

> **In plain English:** "which explanation makes what I actually saw least surprising?"
> **Example:** a coin lands heads 7 times out of 10. If $p(\text{heads}) = 0.5$, that result has probability
> ~0.117; if $p = 0.7$, ~0.267; if $p = 0.9$, ~0.057. The best guess is $p = 0.7$ — the maximum likelihood
> estimate. Training an LLM is the same idea: adjust weights so the real text in the training data
> becomes as unsurprising as possible.

We take the log because products of tiny probabilities underflow, and sums are easier to
differentiate. **Minimizing negative log-likelihood (NLL) is exactly minimizing cross-entropy loss**
(module 04). This is how classifiers and LLMs are trained.

Connections:
- MLE with Gaussian noise ⇒ **mean squared error** loss.
- MLE with Bernoulli/Categorical outputs ⇒ **(binary) cross-entropy** loss.
- Adding a Gaussian prior on weights (MAP estimation) ⇒ **L2 regularization / weight decay**.

## 6. Sampling

Generating text = sampling repeatedly from a categorical distribution:

```python
probs = np.array([0.6, 0.25, 0.1, 0.05])     # model's next-token distribution
vocab = ["the", "a", "cat", "dog"]
rng = np.random.default_rng(0)
print([vocab[rng.choice(len(vocab), p=probs)] for _ in range(10)])
```

Greedy decoding always takes the argmax; sampling adds diversity. Temperature, top-k, and
top-p reshape the distribution before sampling (module 07).

## 7. Statistics for evaluation

- **Mean & confidence intervals:** an eval score on 100 examples has noise. For accuracy $p$
  on $n$ examples, standard error $\approx \sqrt{p(1-p)/n}$. At $p=0.8, n=100$ that is $0.04$ —
  so 80% vs 83% is *not* a meaningful difference.
- **Bias–variance tradeoff:** underfitting (high bias) vs overfitting (high variance). Validation
  sets detect the latter. *Plain English:* a student who learned only one rule ("answer C") is biased;
  a student who memorized last year's paper word-for-word has high variance and fails on new questions.
- **Metrics:** precision $= \frac{TP}{TP+FP}$, recall $= \frac{TP}{TP+FN}$,
  $F_1 = \frac{2PR}{P+R}$. Used for classifiers, guardrails, and retrieval.
- **Correlation ≠ causation;** distribution shift between training and production breaks models.
- **Hypothesis tests and p-values:** assume "no real difference" (the null hypothesis); the p-value is the
  probability of seeing a result at least this extreme *if the null were true*. It is **not** the probability
  that your model is better, and $p < 0.05$ is a convention, not a law. Run 20 prompt variants against a
  baseline and about one will look "significant" by pure chance — correct for multiple comparisons
  (Bonferroni: divide the threshold by the number of tests) or confirm on a fresh held-out set.
  *Example:* a coin lands heads 60 times in 100 flips. If it were fair, a result this lopsided (≥ 60 or ≤ 40)
  happens ~5.7% of the time — so p ≈ 0.057: suspicious, but not conclusive.

## 8. Senior track: going deeper

### 8.1 Law of large numbers, CLT, and mini-batch noise

If per-example gradients $\mathbf{g}_i$ have mean $G$ and covariance $\Sigma$, the mini-batch mean over $B$ examples has

$$
\mathbb{E}[\hat{\mathbf{g}}] = G, \qquad \mathrm{Cov}(\hat{\mathbf{g}}) = \frac{\Sigma}{B}
$$

Noise std shrinks like $1/\sqrt{B}$: 4× the batch halves the noise. (Same as opinion polls: asking 400
voters instead of 100 halves the margin of error, it does not quarter it.) The **gradient noise scale**
(McCandlish et al., 2018) $B_{noise} \approx \frac{\text{tr}(\Sigma)}{\|G\|^2}$ estimates the **critical batch size**: well below
it, doubling the batch nearly halves the steps needed; well above it, extra batch (and extra GPUs) buys little.
It grows during training as the loss falls — one reason LLM runs ramp up batch size over time.

### 8.2 Multivariate Gaussian

$$
p(\mathbf{x}) = \frac{1}{(2\pi)^{d/2}|\Sigma|^{1/2}}\exp\!\left(-\tfrac{1}{2}(\mathbf{x}-\boldsymbol{\mu})^\top\Sigma^{-1}(\mathbf{x}-\boldsymbol{\mu})\right)
$$

- $(\mathbf{x}-\boldsymbol{\mu})^\top\Sigma^{-1}(\mathbf{x}-\boldsymbol{\mu})$ is the **Mahalanobis distance** — used for out-of-distribution detection on embeddings.
- **Reparameterization trick** (VAEs, diffusion): sample $\mathbf{z} = \boldsymbol{\mu} + \sigma\odot\boldsymbol{\epsilon}$, $\boldsymbol{\epsilon}\sim\mathcal{N}(0, I)$, so gradients flow
  through $\boldsymbol{\mu}, \sigma$ while randomness sits in a parameter-free $\boldsymbol{\epsilon}$.
- Diffusion models are built on the identity: noising $\mathbf{x}_0$ in steps gives $\mathbf{x}_t = \sqrt{\bar\alpha_t}\,\mathbf{x}_0 + \sqrt{1-\bar\alpha_t}\,\boldsymbol{\epsilon}$,
  and the network learns to predict $\boldsymbol{\epsilon}$ with a plain MSE loss.

### 8.3 MLE derivations to know cold

**Gaussian ⇒ MSE.** $-\log p(y\mid\mathbf{x}) = \frac{(y - f(\mathbf{x}))^2}{2\sigma^2} + \text{const}$. Minimizing NLL = minimizing squared error.

**Bernoulli ⇒ BCE.** $p(y\mid\mathbf{x}) = \hat{p}^y(1-\hat{p})^{1-y}$ ⇒ $-\log p = -[y\log\hat{p} + (1-y)\log(1-\hat{p})]$.

**Laplace ⇒ MAE (L1 loss)** — more robust to outliers; its MLE location is the median, not the mean.

**MAP = MLE + prior:** $\arg\max_\theta \log p(D\mid\theta) + \log p(\theta)$. Gaussian prior ⇒ $+\lambda\|\theta\|^2$ (weight decay).

### 8.4 Monte Carlo and importance sampling

Estimate $\mathbb{E}_{p}[f(x)]$ with samples from a *different* distribution $q$:

$$
\mathbb{E}_{p}[f(x)] = \mathbb{E}_{q}\!\left[\frac{p(x)}{q(x)}f(x)\right]
$$

The ratio $\frac{p}{q}$ is the importance weight. *Plain English:* a survey that accidentally reached
twice as many students as their share of the population counts each student's answer at half weight. This is exactly the probability ratio $\rho = \pi_\theta/\pi_{old}$ in PPO
and the acceptance test in speculative decoding (module 07). High-variance weights (when $q$ is far from $p$)
are why PPO clips the ratio.

### 8.5 Comparing two models properly

Two models evaluated on the **same** questions are correlated — use a **paired** analysis, which is much
more sensitive than comparing two independent accuracies.

```python
rng = np.random.default_rng(42)
n = 300
a_correct = rng.random(n) < 0.72
b_correct = np.where(rng.random(n) < 0.85, a_correct, rng.random(n) < 0.80)   # correlated with A

diffs = b_correct.astype(float) - a_correct.astype(float)
boot = [rng.choice(diffs, n).mean() for _ in range(5000)]
lo, hi = np.percentile(boot, [2.5, 97.5])
print(f"A={a_correct.mean():.3f} B={b_correct.mean():.3f}  paired 95% CI for B-A: [{lo:+.3f}, {hi:+.3f}]")
```

The code is a **bootstrap**: resample the eval set with replacement thousands of times, recompute the
metric each time, and read the confidence interval off the spread — no distributional formulas needed.
If the confidence interval includes 0, you have not shown an improvement. For binary outcomes, McNemar's
test uses only the discordant pairs (questions where exactly one model is right).

### 8.6 Calibration

A model is calibrated if, among answers given with confidence 0.8, 80% are right. Modern LLMs after RLHF
are often **less** calibrated than their base models. Temperature scaling — dividing logits by a single learned
$T$ on a validation set — is the standard post-hoc fix for classifiers. Calibration matters whenever you threshold
a score (guardrails, routing to a human, "abstain if unsure").

## Key takeaways

1. An LLM models $P(\text{next token} \mid \text{context})$ and uses the probability chain rule.
2. Bayes: always consider base rates.
3. Training = MLE = minimize negative log-likelihood.
4. Small eval sets are noisy — compute the standard error before celebrating.

Next: [04 — Information theory](04_information_theory.md)
