# 10 — Cheat Sheet & Exercises

## Part A — Formula cheat sheet

### Linear algebra
| Concept | Formula |
|---|---|
| Matmul shape / cost | $(m,n)@(n,p) \to (m,p)$, $\approx 2mnp$ FLOPs |
| Cosine similarity | $\frac{\mathbf{a}\cdot\mathbf{b}}{\|\mathbf{a}\|\|\mathbf{b}\|}$ |
| SVD / best rank-$r$ | $A = U\Sigma V^\top$; keep top $r$ singular values |
| Condition number | $\kappa = \sigma_{\max}/\sigma_{\min}$; $\kappa(X^\top X) = \kappa(X)^2$ |
| Random vectors in $\mathbb{R}^d$ | $\cos \approx \mathcal{N}(0, 1/d)$ — nearly orthogonal |

### Calculus
| Concept | Formula |
|---|---|
| Gradient step | $\theta \leftarrow \theta - \eta\nabla\mathcal{L}$ |
| Linear layer backward | $\partial L/\partial W = \mathbf{g}\mathbf{x}^\top$, $\partial L/\partial\mathbf{x} = W^\top\mathbf{g}$ |
| Sigmoid' | $\sigma(1-\sigma)$ (max 0.25) |
| Softmax Jacobian | $\text{diag}(\mathbf{p}) - \mathbf{p}\mathbf{p}^\top$ |
| Softmax + CE gradient | $\mathbf{p} - \mathbf{y}$ |
| GD stability (quadratic) | $\eta < 2/\lambda_{\max}(H)$ |

### Probability & information
| Concept | Formula |
|---|---|
| Bayes | $P(H\mid D) = P(D\mid H)P(H)/P(D)$ |
| Autoregressive LM | $P(x_{1:T}) = \prod_t P(x_t\mid x_{<t})$ |
| Entropy / CE / KL | $-\sum p\log p$, $-\sum p\log q$, $\sum p\log\frac{p}{q}$ |
| Perplexity | $e^{\text{mean NLL}}$ |
| Init loss sanity check | $\ln V$ (or $\ln K$ classes) |
| Eval standard error | $\sqrt{p(1-p)/n}$ |

### Optimization & DL
| Concept | Formula |
|---|---|
| Adam | $\theta \mathrel{-}= \eta\,\hat{m}/(\sqrt{\hat{v}}+\epsilon)$ |
| He init | $\mathrm{Var}(w) = 2/n_{in}$ |
| Residual | $\mathbf{x} + F(\mathbf{x})$, Jacobian $I + J_F$ |
| RMSNorm | $\mathbf{x}/\sqrt{\text{mean}(x^2)+\epsilon}\odot\gamma$ |
| Dropout | keep w.p. $1-p$, scale by $\frac{1}{1-p}$ |

### Transformers & LLMs
| Concept | Formula |
|---|---|
| Attention | $\text{softmax}(QK^\top/\sqrt{d_k} + M)V$ |
| Params | $\approx 12Ld^2 + Vd$ |
| FLOPs | inference $2N$/token, training $6N$/token, $C = 6ND$ |
| Chinchilla | $D \approx 20N$ |
| KV cache | $2\,L\,g\,d_k\,T\,B \times$ bytes |
| LoRA | $W_0 + \frac{\alpha}{r}BA$, params $r(d+k)$ |
| Quantization | $\hat{x} = s(q - z)$, sym int8 $s = \max|x|/127$ |
| DPO | $-\log\sigma\big(\beta[\Delta\log\pi_w - \Delta\log\pi_l]\big)$ |
| Speculative decoding | $\mathbb{E}[\text{tokens}] = \frac{1-\alpha^{\gamma+1}}{1-\alpha}$ |

### Systems
| Concept | Formula |
|---|---|
| Training state | 16 bytes/param (mixed-precision Adam) |
| Decode ceiling | tokens/s $\le$ bandwidth / weight bytes |
| Roofline | $\min(\text{peak}, I \times \text{BW})$ |
| Ring all-reduce | $\approx 2S/\text{BW}$ per GPU |
| Pipeline bubble | $(p-1)/(m+p-1)$ |
| MFU | $6N\cdot\text{tok/s} / (\text{GPUs}\cdot\text{peak})$ |
| Little's law | concurrency = throughput × latency |

---

## Part B — Exercises (try first, answers below)

1. **Shapes.** $X$ is `(32, 128, 768)` (batch, seq, dim). You apply $W_Q$ of shape `(768, 768)` and split
   into 12 heads. What is the shape of $QK^\top$ per head, for the whole batch?
2. **Cosine.** Two L2-normalized embeddings have dot product 0.82. What is their cosine similarity and
   their Euclidean distance?
3. **Chain rule.** $L = (\text{ReLU}(wx) - y)^2$ with $w = 2, x = 3, y = 4$. Compute $\partial L/\partial w$.
4. **Bayes.** A jailbreak detector has 95% recall and a 3% false-positive rate. 1 in 500 prompts is a
   jailbreak. What fraction of flagged prompts are real jailbreaks?
5. **Cross-entropy.** The model gives the correct token probability 0.25. Loss in nats? In bits?
   If that were the average, what is the perplexity?
6. **Init loss.** You start training a model with $V = 128{,}256$. Roughly what loss do you expect at step 0?
7. **Scaling.** Why divide attention scores by $\sqrt{d_k}$? What is the score std for $d_k = 128$ without it?
8. **Parameters.** $L = 24$, $d = 2048$, $V = 50{,}000$, tied embeddings, 4× MLP. Estimate $N$.
9. **Compute.** Train that model Chinchilla-optimally. How many tokens and FLOPs? GPU-hours on H100 at 40% MFU?
10. **KV cache.** A model has $L = 32$, 8 KV heads, $d_k = 128$, bf16. KV bytes per token? How many
    concurrent 8k-token sequences fit in 40 GB?
11. **Decode speed.** A 13B model in int4 on a GPU with 1 TB/s bandwidth. Upper bound on tokens/s at batch 1?
12. **LoRA.** LoRA $r = 8$ on $W_Q, W_V$ (each $4096\times4096$) in 32 layers. Trainable parameters?
13. **Training memory.** Minimum GPUs (80 GB) to hold full fine-tuning model state of a 13B model with
    ZeRO-3, ignoring activations?
14. **Eval noise.** Model A scores 72% and model B 75% on a 200-question eval. Is this meaningful?
15. **Bubble.** Pipeline with 4 stages. How many micro-batches keep the bubble under 10%?
16. **Temperature.** Logits $[2, 1, 0]$. Compute softmax at $\tau = 1$ and $\tau = 0.5$.
17. **Speculative decoding.** Acceptance rate 0.6, draft length 5. Expected tokens per target-model pass?
18. **Roofline.** On an H100, at what decode batch size do the dense matmuls become compute-bound (roughly)?

---

## Part C — Answers

1. Each head: $d_k = 64$. $Q, K$ per head are `(32, 128, 64)`; $QK^\top$ is `(32, 12, 128, 128)` for all heads.
2. Cosine = 0.82 (normalized ⇒ dot = cosine). $\|\mathbf{a}-\mathbf{b}\| = \sqrt{2 - 2\cdot0.82} = \sqrt{0.36} = 0.6$.
3. $wx = 6 > 0$, ReLU' = 1. $\partial L/\partial w = 2(6-4)\cdot1\cdot x = 2\cdot2\cdot3 = 12$.
4. $\frac{0.95\cdot0.002}{0.95\cdot0.002 + 0.03\cdot0.998} = \frac{0.0019}{0.0019 + 0.02994} \approx 6\%$. Base rates dominate — use the
   detector for routing/triage, not as a sole blocker.
5. $-\ln 0.25 = 1.386$ nats $= 2$ bits. Perplexity $= e^{1.386} = 4$.
6. $\ln 128256 \approx 11.76$.
7. Keeps score variance ≈ 1 so softmax does not saturate. Without it std $= \sqrt{128} \approx 11.3$.
8. $12 \cdot 24 \cdot 2048^2 + 50000 \cdot 2048 = 1.208\text{B} + 0.102\text{B} \approx 1.31$B.
9. $D \approx 20N \approx 26$B tokens. $C = 6 \cdot 1.31\text{e}9 \cdot 2.62\text{e}10 \approx 2.06\times10^{20}$ FLOPs.
   $2.06\text{e}20 / (989\text{e}12 \cdot 0.4) \approx 5.2\times10^5$ s ≈ 145 GPU-hours.
10. $2\cdot32\cdot8\cdot128\cdot2 = 131{,}072$ bytes = 128 KiB/token. 8k tokens ⇒ 1 GiB/sequence ⇒ ~37 sequences in 40 GB.
11. Weights ≈ $13\text{e}9 \times 0.5 = 6.5$ GB ⇒ $\le 1000/6.5 \approx 154$ tokens/s (real: lower, KV reads + overhead).
12. Per matrix $r(d+k) = 8 \cdot 8192 = 65{,}536$; ×2 matrices ×32 layers = 4.19M parameters.
13. $13\text{e}9 \times 16 = 208$ GB ⇒ at least 3 GPUs (realistically 4–8 once activations and buffers are counted).
14. SE per model $\approx \sqrt{0.735\cdot0.265/200} \approx 0.031$; difference SE $\approx 0.044$ (unpaired). A 3-point gap is
    < 1 SE — not significant. Use a paired test/bootstrap on the same questions, or a larger eval.
15. $\frac{3}{m+3} < 0.1 \Rightarrow m > 27$ ⇒ 28+ micro-batches.
16. $\tau = 1$: $[0.665, 0.245, 0.090]$. $\tau = 0.5$ (logits $[4, 2, 0]$): $[0.867, 0.117, 0.016]$ — sharper.
17. $\frac{1 - 0.6^6}{1 - 0.6} = \frac{1 - 0.0467}{0.4} \approx 2.38$ tokens.
18. Intensity ≈ batch size; ridge ≈ 989e12 / 3.35e12 ≈ 295 ⇒ around batch ~300 (lower in practice once
    KV-cache reads, which do not amortize across sequences, are included — attention stays memory-bound).

```python
# Verify a few answers numerically
import numpy as np
sm = lambda z: np.exp(z - z.max()) / np.exp(z - z.max()).sum()
print(np.round(sm(np.array([2., 1, 0])), 3), np.round(sm(np.array([4., 2, 0])), 3))      # Q16
print(round(0.95 * 0.002 / (0.95 * 0.002 + 0.03 * 0.998), 3))                            # Q4
print(round((1 - 0.6**6) / 0.4, 2))                                                       # Q17
print(round(np.log(128256), 2), round(12 * 24 * 2048**2 / 1e9 + 50000 * 2048 / 1e9, 2))   # Q6, Q8
```

---

## Part D — Recommended next reading

| Topic | Resource |
|---|---|
| Linear algebra intuition | 3Blue1Brown, *Essence of Linear Algebra*; Strang, *Linear Algebra and Learning from Data* |
| Math for ML (all-in-one) | Deisenroth, Faisal, Ong — *Mathematics for Machine Learning* (free PDF) |
| Deep learning theory + practice | Prince — *Understanding Deep Learning* (free PDF); Goodfellow et al. — *Deep Learning* |
| Build it from scratch | Karpathy — *micrograd*, *nanoGPT*, "Let's build GPT" |
| Transformers | Vaswani et al. 2017; *The Annotated Transformer*; Anthropic's *Transformer Circuits* |
| Scaling & systems | Kaplan et al. 2020; Hoffmann et al. 2022 (Chinchilla); *How to Scale Your Model* (JAX scaling book); Korthikanti et al. 2022 |
| Inference | FlashAttention 1–3 papers; vLLM / PagedAttention paper; speculative decoding (Leviathan et al. 2023) |
| Fine-tuning & alignment | LoRA (Hu et al. 2021); QLoRA (Dettmers et al. 2023); InstructGPT; DPO (Rafailov et al. 2023); DeepSeekMath (GRPO) |
