# Math for ML, Deep Learning & LLMs — A Senior Engineer's Course

Written for an **experienced software engineer moving into a senior AI/ML/DL role**. You already
think in complexity, memory, throughput, and failure modes — this course maps that instinct onto
the math behind models. Each module goes from intuition → formula → derivation → runnable NumPy →
**production consequence** (what it changes in training, serving, cost, or debugging).

> Mindset for the whole course: **the goal is not to memorize formulas, it is to reason
> quantitatively.** A senior AI engineer can derive why attention divides by $\sqrt{d_k}$, estimate a
> training run's GPU-hours on a napkin, size a KV cache before buying hardware, and tell whether a
> 3-point eval gain is noise.

## How each module is structured

1. **Core concepts** — the intuition and the formulas everyone uses. Every important formula is followed
   by an **"In plain English"** note with an everyday example (shopping bills, foggy mountains, weather
   forecasters, clock hands, libraries) — read those first if a formula looks scary.
2. **Senior track** — derivations, edge cases, numerical stability, and the research-paper version of the idea.
3. **Key takeaways** — what to carry into design reviews and interviews.

Skim the core sections if they are familiar; the senior tracks and modules 07–09 are where the depth is.

## Roadmap

```
 FOUNDATIONS                                   APPLIED TO MODELS                   APPLIED TO SYSTEMS
 01 Linear algebra ──┐
 02 Calculus ────────┼─► 05 Optimization ─► 06 Deep learning ─► 07 Transformers & LLMs ─► 09 ML systems math
 03 Probability ─────┤                                                 ▲                 (memory, roofline,
 04 Information ─────┘──────────────► 08 Classical ML ─────────────────┘                  comms, cost)
                                                                                                │
                                                                     10 Cheat sheet & exercises ◄┘
```

| # | Module | Core | Senior track highlights |
|---|---|---|---|
| 01 | [Linear algebra](01_linear_algebra.md) | vectors, matmul, norms, cosine, SVD, low rank | einsum, orthogonality, PSD, conditioning, matrix-calculus identities, high-dim geometry & superposition |
| 02 | [Calculus & gradients](02_calculus_gradients.md) | derivatives, gradient, chain rule, Jacobian | Taylor/curvature & max LR, forward vs reverse autodiff, build an autograd engine, gradient checking |
| 03 | [Probability & statistics](03_probability_statistics.md) | distributions, Bayes, MLE, sampling, eval stats | mini-batch noise & critical batch size, multivariate Gaussian, reparameterization, importance sampling, paired bootstrap, calibration |
| 04 | [Information theory](04_information_theory.md) | entropy, cross-entropy, KL, perplexity | softmax-CE gradient derivation, forward vs reverse KL, RLHF KL estimators, distillation, bits-per-byte, InfoNCE bound |
| 05 | [Optimization](05_optimization.md) | losses, SGD, momentum, AdamW, schedules, clipping | convergence & condition number, AdamW vs L2, batch/LR scaling, μP, z-loss, Lion/Shampoo/Muon |
| 06 | [Math of deep learning](06_math_of_deep_learning.md) | MLPs, activations, backprop, init, norms, regularization | He-init derivation, residual Jacobians, pre- vs post-norm, dropout expectation, debugging checklist |
| 07 | [Math of transformers & LLMs](07_math_of_transformers_llms.md) | attention, RoPE, parameter/FLOP counting, scaling laws | KV cache, prefill vs decode, FlashAttention online softmax, speculative decoding, LoRA, quantization, RLHF/DPO/GRPO, MoE, embeddings |
| 08 | [Classical ML math](08_classical_ml_math.md) | linear/logistic regression, bias–variance, SVM, PCA, k-means, boosting | projection view, ridge via SVD, IRLS, kernel ↔ attention, AUC as ranking, retrieval metrics |
| 09 | [ML systems math](09_ml_systems_math.md) | training & inference memory, roofline, latency | ZeRO arithmetic, activation memory, KV capacity planning, MFU, all-reduce & pipeline bubbles, $/token |
| 10 | [Cheat sheet & exercises](10_cheatsheet_exercises.md) | every key formula on one page | 18 quantitative problems with worked answers + reading list |

## Suggested paths

| You are… | Path |
|---|---|
| Building LLM apps/agents and want to understand the model | 01 → 03 → 04 → 07 → 09 → 10 |
| Moving into model training / fine-tuning | 01 → 02 → 05 → 06 → 07 → 09 |
| Preparing for senior ML interviews | everything, then all of 10 without notes |
| Owning inference / platform cost | 01 → 07 (sections 6–13) → 09 |

## How this connects to the rest of the repo

| Math topic here | Where it shows up elsewhere |
|---|---|
| Cosine similarity, embeddings, InfoNCE, ANN | `04_rag/`, `05_memory/` |
| Softmax, temperature, sampling, determinism | `01_foundations/`, `08_production/` |
| Cross-entropy, KL, perplexity, paired eval stats | `07_evaluation/`, `10_llmops_pipeline/` |
| Bayes and base rates for detectors | `06_guardrails/`, `12_ai_security_governance/` |
| FLOPs, memory, KV cache, quantization, comms | `11_kubernetes/`, `13_sovereign_ai_infra_course/` |

## Setup (optional)

```bash
pip install numpy
```

Every snippet runs with NumPy only and is self-contained per module (run a module's snippets top to bottom).

## The seven laws this course repeats

1. **Everything is a vector.** Words, images, users, documents — models only see numbers.
2. **A layer is a matrix multiply plus a nonlinearity.** Deep learning is that, stacked, with residuals.
3. **Learning = following the negative gradient of a loss.** Reverse-mode autodiff makes it cheap.
4. **Outputs are probability distributions.** Softmax makes them; cross-entropy grades them; KL compares them.
5. **Variance is the enemy of depth.** Init, normalization, residuals, and $\sqrt{d_k}$ all exist to keep it near 1.
6. **Count before you build.** $12Ld^2$ params, $6ND$ FLOPs, 16 bytes/param, $2LgdT$ KV — know them cold.
7. **Bytes, not FLOPs, usually set the speed.** Most inference is memory-bandwidth-bound.
