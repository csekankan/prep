# 02 — Calculus & Gradients: How Models Learn

> **Why it matters:** training means adjusting millions (or billions) of weights to reduce a
> loss. The derivative tells each weight which direction to move. The chain rule lets us
> compute that for deep stacks of layers — that algorithm is called backpropagation.

## 1. Derivative = sensitivity

The derivative $f'(x)$ answers: *if I nudge $x$ a tiny bit, how much does $f(x)$ change?*

$$
f'(x) = \lim_{h\to 0} \frac{f(x+h) - f(x)}{h}
$$

> **In plain English:** a derivative is a sensitivity meter.
>
> **Example:** turn the shower knob a tiny bit — how much does the water temperature change? Near the
> middle of the knob, a lot (big derivative); at the extremes, barely at all (small derivative). In
> ML the "knob" is a weight and the "temperature" is the error.

Rules you will use constantly:

| Function | Derivative |
|---|---|
| $c$ | $0$ |
| $x^n$ | $n x^{n-1}$ |
| $e^x$ | $e^x$ |
| $\ln x$ | $1/x$ |
| $\sigma(x) = \frac{1}{1+e^{-x}}$ | $\sigma(x)(1-\sigma(x))$ |
| $\tanh x$ | $1 - \tanh^2 x$ |
| $\text{ReLU}(x) = \max(0,x)$ | $1$ if $x>0$ else $0$ |

## 2. Numerical check (finite differences)

You can always sanity-check a derivative numerically — this is how people debug hand-written
gradients:

```python
import numpy as np
f = lambda x: x**3 + 2*x
df = lambda x: 3*x**2 + 2
x, h = 1.5, 1e-5
numeric = (f(x + h) - f(x - h)) / (2 * h)   # central difference
print(numeric, df(x))                        # both ≈ 8.75
```

## 3. Partial derivatives and the gradient

A loss depends on many weights: $L(w_1, w_2, \dots, w_n)$. A **partial derivative**
$\frac{\partial L}{\partial w_i}$ changes only $w_i$ and holds the rest fixed.

The **gradient** stacks them into a vector:

$$
\nabla L = \left[\frac{\partial L}{\partial w_1}, \dots, \frac{\partial L}{\partial w_n}\right]
$$

Key fact: **the gradient points in the direction of steepest increase.** So to reduce the loss,
step the opposite way:

$$
\mathbf{w} \leftarrow \mathbf{w} - \eta\, \nabla L(\mathbf{w})
$$

where $\eta$ is the learning rate. That one line is gradient descent (module 05).

> **In plain English:** you are on a foggy mountain and want to reach the valley. You cannot see far,
> but you can feel the slope under your feet. The gradient is that slope (for every direction at once);
> you take a step downhill and repeat. The learning rate is your stride length.
>
> **Example:** a model with 3 weights gets gradient `[+2.0, -0.5, 0.0]`: increasing weight 1 raises the
> error a lot (so decrease it), increasing weight 2 lowers the error a bit (so increase it), and weight 3
> doesn't matter right now (leave it).

## 4. The chain rule — the engine of deep learning

If $y = f(g(x))$, then

$$
\frac{dy}{dx} = \frac{dy}{dg}\cdot\frac{dg}{dx}
$$

A neural network is a long composition: $L = \ell(f_3(f_2(f_1(x))))$. The chain rule multiplies
local derivatives backward from the loss to each weight. **Backpropagation is just the chain
rule applied efficiently, reusing intermediate results.**

> **In plain English:** effects multiply through a chain.
>
> **Example:** gears. Gear A turns gear B 2× as fast; gear B turns gear C 3× as fast. So turning A
> spins C 2 × 3 = 6× as fast. In a network, "how much does weight 1 affect the final error?" = the
> product of how much each layer amplifies the change on the way to the output.

### Worked example: one neuron

$z = wx + b$, $\hat{y} = \sigma(z)$, $L = (\hat{y} - y)^2$.

$$
\frac{\partial L}{\partial w}
= \underbrace{2(\hat{y}-y)}_{\partial L/\partial \hat{y}}
\cdot \underbrace{\sigma(z)(1-\sigma(z))}_{\partial \hat{y}/\partial z}
\cdot \underbrace{x}_{\partial z/\partial w}
$$

```python
sigmoid = lambda z: 1 / (1 + np.exp(-z))
x, y, w, b = 2.0, 1.0, 0.5, 0.1
z = w * x + b
y_hat = sigmoid(z)
L = (y_hat - y) ** 2
dL_dw = 2 * (y_hat - y) * y_hat * (1 - y_hat) * x
# numeric check
h = 1e-6
L2 = (sigmoid((w + h) * x + b) - y) ** 2
print(dL_dw, (L2 - L) / h)   # should match closely
```

## 5. Vector and matrix calculus (just what you need)

- **Jacobian:** for $\mathbf{f}: \mathbb{R}^n \to \mathbb{R}^m$, the $m\times n$ matrix of all
  partials $J_{ij} = \partial f_i / \partial x_j$. Backprop multiplies vectors by Jacobians
  ("vector–Jacobian products") without ever building the full matrix.
- **Linear layer gradients** for $\mathbf{y} = W\mathbf{x}$ with upstream gradient
  $\mathbf{g} = \partial L/\partial \mathbf{y}$:

$$
\frac{\partial L}{\partial W} = \mathbf{g}\,\mathbf{x}^\top, \qquad
\frac{\partial L}{\partial \mathbf{x}} = W^\top \mathbf{g}
$$

  Memorize these two — they are the heart of every backward pass.
- **Hessian:** matrix of second derivatives (curvature). Too big to compute for large models,
  but it explains why some directions train fast and others slowly.

## 6. Why gradients vanish or explode

Backprop multiplies many local derivatives together. If they are mostly $< 1$ (e.g. sigmoid's
max slope is $0.25$), the product shrinks toward $0$ → **vanishing gradients**: early layers stop
learning. If they are mostly $> 1$ → **exploding gradients**: training diverges.

> **In plain English:** like the telephone (whisper) game. If each person passes on only a quarter of
> the message, after 10 people $0.25^{10} \approx 0.000001$ of it survives — the first layers "hear"
> nothing and stop learning. If each person shouts twice as loud, after 10 people it is $2^{10} = 1024\times$
> — chaos.

Fixes you will see in module 06: ReLU-family activations, careful initialization, residual
connections, normalization layers, and gradient clipping.

## 7. Autodiff: you rarely do this by hand

PyTorch/JAX record operations and apply the chain rule automatically:

```python
# PyTorch equivalent of the worked example (not required for this course)
# import torch
# w = torch.tensor(0.5, requires_grad=True)
# L = (torch.sigmoid(w * 2.0 + 0.1) - 1.0) ** 2
# L.backward(); print(w.grad)
```

You still need the math to debug NaNs, understand optimizers, and reason about stability.

## 8. Senior track: going deeper

### 8.1 Taylor expansion — the lens for every optimizer

Around the current weights $\theta$, for a step $\Delta$:

$$
\mathcal{L}(\theta + \Delta) \approx \mathcal{L}(\theta) + \mathbf{g}^\top\Delta + \tfrac{1}{2}\Delta^\top H\Delta
$$

- First-order methods (SGD, Adam) use only $\mathbf{g}$. Newton's method minimizes the quadratic exactly:
  $\Delta = -H^{-1}\mathbf{g}$ — impossible at LLM scale ($H$ has $N^2$ entries), so we approximate (Adam's diagonal
  preconditioner, Shampoo/K-FAC block approximations).
- Along an eigenvector of $H$ with eigenvalue $\lambda$, gradient descent multiplies the error by $(1 - \eta\lambda)$
  each step. It converges only if $|1 - \eta\lambda| < 1$, i.e. **$\eta < 2/\lambda_{\max}$**. The sharpest direction
  sets the maximum learning rate; the flattest sets how slow convergence is. Ratio = condition number.
> **In plain English:** zoom in far enough on any curve and it looks like a straight line (first order)
> or a bowl (second order). **Example:** in a narrow, steep valley, a big stride makes you bounce from
> one wall to the other instead of walking down the middle — that is a learning rate above $2/\lambda_{\max}$.

- Empirically, training often self-tunes to sit near $\lambda_{\max} \approx 2/\eta$ ("edge of stability") — which is
  why loss curves are noisy even when training is healthy.

### 8.2 Forward vs reverse mode autodiff — why backprop is the right choice

For $f: \mathbb{R}^n \to \mathbb{R}^m$:
- **Forward mode** pushes derivatives from inputs to outputs; one pass gives one *column* of the Jacobian
  (cost ≈ $n$ passes for the full gradient).
- **Reverse mode** (backprop) pulls derivatives from outputs to inputs; one pass gives one *row*.

> **In plain English:** to learn how every ingredient affects a cake's final taste score, forward mode
> bakes the cake once per ingredient; reverse mode bakes it once and walks backward through the recipe
> handing out credit. With billions of "ingredients", only the backward walk is affordable.

A loss is a scalar ($m = 1$) of billions of parameters ($n \approx 10^9$), so reverse mode gets the *entire* gradient
for ~2–3× the cost of a forward pass. The price: it must **store intermediate activations** from the forward pass —
the root of activation-memory problems and of activation checkpointing (recompute instead of store; module 09).

### 8.3 Build a tiny autograd engine (the SDE way to really get it)

```python
import math

class Value:
    def __init__(self, data, parents=(), op=""):
        self.data, self.grad, self._parents, self._backward = data, 0.0, parents, lambda: None

    def __add__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        out = Value(self.data + other.data, (self, other))
        def _backward():
            self.grad += out.grad
            other.grad += out.grad
        out._backward = _backward
        return out

    def __mul__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        out = Value(self.data * other.data, (self, other))
        def _backward():
            self.grad += other.data * out.grad
            other.grad += self.data * out.grad
        out._backward = _backward
        return out

    def tanh(self):
        t = math.tanh(self.data)
        out = Value(t, (self,))
        def _backward():
            self.grad += (1 - t * t) * out.grad
        out._backward = _backward
        return out

    def backward(self):
        order, seen = [], set()
        def topo(v):
            if v not in seen:
                seen.add(v)
                for p in v._parents:
                    topo(p)
                order.append(v)
        topo(self)
        self.grad = 1.0
        for v in reversed(order):
            v._backward()

x, w, b = Value(0.5), Value(-1.2), Value(0.3)
y = (x * w + b).tanh()
y.backward()
print(round(y.data, 4), round(w.grad, 4), round(x.grad, 4))
```

Three engineering details that carry over to PyTorch:
1. **Gradients accumulate** (`+=`) because a value can feed multiple consumers — that is why frameworks need
   `zero_grad()` and why gradient accumulation across micro-batches is free.
2. **Topological order** guarantees a node's gradient is complete before it propagates further.
3. Each op only needs its **local derivative** — new ops plug in without touching the rest.

### 8.4 Gradient checking done right

Use central differences in float64 and compare with a **relative** error:

$$
\text{rel\_err} = \frac{\|g_{analytic} - g_{numeric}\|}{\|g_{analytic}\| + \|g_{numeric}\|}
$$

Rough guide: $< 10^{-7}$ great, $10^{-5}$ suspicious, $> 10^{-3}$ a bug. Kinks (ReLU at 0, max) cause false alarms.

### 8.5 Softmax Jacobian (you will need it in module 07)

$$
\frac{\partial p_i}{\partial z_j} = p_i(\delta_{ij} - p_j) \quad\Longleftrightarrow\quad J = \text{diag}(\mathbf{p}) - \mathbf{p}\mathbf{p}^\top
$$

When one $p_i \to 1$, $J \to 0$: a saturated softmax passes back no gradient.

## Key takeaways

1. Derivative = sensitivity; gradient = vector of sensitivities pointing uphill.
2. Learning = step against the gradient.
3. Chain rule → backpropagation.
4. Linear layer: $\partial L/\partial W = \mathbf{g}\mathbf{x}^\top$, $\partial L/\partial \mathbf{x} = W^\top\mathbf{g}$.
5. Multiplying many small/large derivatives causes vanishing/exploding gradients.

Next: [03 — Probability & statistics](03_probability_statistics.md)
