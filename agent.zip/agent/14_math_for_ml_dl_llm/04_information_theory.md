# 04 — Information Theory: Entropy, Cross-Entropy, KL, Perplexity

> **Why it matters:** cross-entropy is *the* loss for classification and LLM pretraining.
> KL divergence appears in RLHF, distillation, and VAEs. Perplexity is the standard
> language-model metric. All of them come from one idea: measuring surprise.

## 1. Information = surprise

The information content of an event with probability $p$:

$$
I(x) = -\log p(x)
$$

Rare events carry more information.

> **In plain English:** information = how surprised you are. **Example:** "the sun rose this morning"
> tells you nothing (probability ≈ 1, surprise ≈ 0). "It snowed in Chennai in May" is huge news
> (tiny probability, big surprise). With $\log_2$ the unit is **bits**; with natural log
$\ln$ it is **nats** (ML frameworks use nats).

## 2. Entropy — average surprise of a distribution

$$
H(P) = -\sum_x P(x)\log P(x)
$$

- A fair coin: $H = 1$ bit (maximally uncertain for 2 outcomes).
- A coin that always lands heads: $H = 0$.
- Uniform over $K$ outcomes: $H = \log K$ (the maximum).

> **In plain English:** entropy = the average number of yes/no questions you need to guess the outcome.
> **Example:** a fair coin needs 1 question. One of 4 equally likely cards needs 2 ("red?", "hearts?").
> A coin that is heads 90% of the time needs fewer than 1 on average (0.47) because you can usually guess.
> An LLM that is sure the next word is "Paris" has low entropy; one torn between many words has high entropy.

```python
import numpy as np
def entropy(p): p = np.asarray(p); p = p[p > 0]; return -(p * np.log2(p)).sum()
print(entropy([0.5, 0.5]), entropy([0.9, 0.1]), entropy([0.25] * 4))  # 1.0, 0.469, 2.0
```

**LLM use:** the entropy of the next-token distribution measures model uncertainty — a signal
used for hallucination detection and adaptive decoding.

## 3. Cross-entropy — the training loss

If the true distribution is $P$ and the model predicts $Q$:

$$
H(P, Q) = -\sum_x P(x)\log Q(x)
$$

For classification and next-token prediction, $P$ is one-hot (the correct class $y$), so it
collapses to:

$$
\mathcal{L}_{CE} = -\log Q(y)
$$

"Make the probability of the correct answer high." Predicting $0.9$ for the right token costs
$0.105$ nats; predicting $0.01$ costs $4.6$ nats.

> **In plain English:** cross-entropy grades a forecaster by how much probability she put on what
> actually happened. **Example:** she said 90% rain and it rained → small penalty. She said 1% rain and
> it poured → huge penalty. Confidently wrong is punished far more than unsure. An LLM gets graded
> this way on every single word of its training text.

```python
def cross_entropy(logits, target):
    logits = logits - logits.max()                 # numerical stability
    log_probs = logits - np.log(np.exp(logits).sum())
    return -log_probs[target]

logits = np.array([2.0, 1.0, 0.1])                 # raw model scores
print(cross_entropy(logits, target=0))             # ≈ 0.417
```

**Beautiful gradient fact:** for softmax + cross-entropy, the gradient with respect to the logits is

$$
\frac{\partial \mathcal{L}}{\partial \mathbf{z}} = \text{softmax}(\mathbf{z}) - \mathbf{y}_{\text{one-hot}}
$$

"predicted minus true" — simple, stable, and why this pairing is universal.

## 4. KL divergence — distance between distributions

$$
D_{KL}(P \,\|\, Q) = \sum_x P(x)\log\frac{P(x)}{Q(x)} = H(P, Q) - H(P)
$$

> **In plain English:** KL = the extra cost of believing the wrong thing. **Example:** you pack for a
> trip assuming the weather is like Mumbai ($Q$), but the destination is actually like Shimla ($P$). KL is
> how much extra discomfort (surprise) you pay on average for using the wrong forecast. Same forecast → zero cost.

- Always $\ge 0$, and $= 0$ only when $P = Q$.
- **Not symmetric:** $D_{KL}(P\|Q) \ne D_{KL}(Q\|P)$, so it is not a true distance.
- Since $H(P)$ is fixed by the data, minimizing cross-entropy = minimizing KL to the data.

```python
def kl(p, q): p, q = np.asarray(p), np.asarray(q); return (p * np.log(p / q)).sum()
print(kl([0.5, 0.5], [0.9, 0.1]), kl([0.9, 0.1], [0.5, 0.5]))   # different values
```

**Where you meet it:**
- **RLHF / PPO / DPO:** a KL penalty keeps the fine-tuned policy close to the reference model
  so it does not drift into gibberish that games the reward.
- **Knowledge distillation:** a small student model minimizes KL to a large teacher's softened
  distribution.
- **VAEs:** KL pulls the latent distribution toward a Gaussian prior.

## 5. Perplexity — the LM metric

Average cross-entropy per token over a text of $T$ tokens, exponentiated:

$$
\text{PPL} = \exp\!\left(-\frac{1}{T}\sum_{t=1}^{T}\log Q(x_t \mid x_{<t})\right)
$$

Intuition: the model is "as confused as if choosing uniformly among PPL options" at each step.
Lower is better. A loss of $2.0$ nats/token ⇒ PPL $= e^2 \approx 7.4$.

> **Example:** PPL 7.4 means the model is, on average, as unsure as someone picking from ~7 equally
> likely words. A model guessing randomly from a 32,000-word vocabulary has PPL 32,000. A perfect model
> has PPL 1.

Caveat: perplexity is only comparable between models that share the same tokenizer.

## 6. Mutual information (brief)

$$
I(X; Y) = H(X) - H(X \mid Y)
$$

How much knowing $Y$ reduces uncertainty about $X$. Used in contrastive learning objectives
(e.g. InfoNCE, the loss behind CLIP and many embedding models) and feature selection.

## 7. Senior track: going deeper

### 7.1 Derive the softmax + cross-entropy gradient

With $\mathcal{L} = -\log p_y$ and $p_i = e^{z_i}/\sum_j e^{z_j}$, write $\mathcal{L} = -z_y + \log\sum_j e^{z_j}$. Then

$$
\frac{\partial\mathcal{L}}{\partial z_k} = -\delta_{ky} + \frac{e^{z_k}}{\sum_j e^{z_j}} = p_k - \delta_{ky}
$$

No division by small probabilities appears, which is why frameworks fuse softmax and CE into one op
(`cross_entropy(logits, target)`) rather than computing `log(softmax(x))` — the fused version is both faster and
numerically safer.

### 7.2 Forward vs reverse KL: mode-covering vs mode-seeking

Let $P$ be the target (data or teacher) and $Q_\theta$ the model.

| | Forward KL $D_{KL}(P\|Q)$ | Reverse KL $D_{KL}(Q\|P)$ |
|---|---|---|
| Penalizes | $Q \approx 0$ where $P > 0$ | $Q > 0$ where $P \approx 0$ |
| Behaviour | **mode-covering** — spreads mass over all modes, may put mass in between | **mode-seeking** — locks onto one mode, ignores others |
| Where | MLE / pretraining, standard distillation | RLHF KL penalty (expectation over the policy's own samples), variational inference |

> **In plain English:** imagine fish in two ponds. Forward KL says "never miss a fish" → you spread your
> net over both ponds (and the empty land between them). Reverse KL says "never cast where there are no
> fish" → you pick one pond and fish only there.

This explains real behaviour: pretraining (forward KL to the data) yields diverse but sometimes "blurry"
outputs; RL fine-tuning with reverse-KL-style objectives yields sharper, less diverse outputs (mode collapse in
style and tone is a known RLHF side effect).

### 7.3 Estimating KL from samples (what RLHF code actually computes)

You cannot sum over all possible sequences, so KL is estimated from samples $y \sim \pi$ with $r = \frac{\pi_{ref}(y)}{\pi(y)}$:

| Estimator | Formula | Properties |
|---|---|---|
| $k_1$ | $-\log r$ | unbiased, high variance, can be negative per-sample |
| $k_2$ | $\frac{1}{2}(\log r)^2$ | biased, low variance |
| $k_3$ | $(r - 1) - \log r$ | unbiased, always $\ge 0$, low variance |

Many RLHF/GRPO implementations use $k_3$ per token.

### 7.4 Distillation with temperature

Student matches the teacher's softened distribution:

$$
\mathcal{L} = (1-\alpha)\,\text{CE}(y, p_s) + \alpha\,\tau^2\,D_{KL}\big(\text{softmax}(\mathbf{z}_t/\tau)\,\|\,\text{softmax}(\mathbf{z}_s/\tau)\big)
$$

Higher $\tau$ exposes "dark knowledge" (which wrong answers the teacher thinks are almost right). The $\tau^2$ factor
keeps gradient magnitudes comparable because soft-target gradients scale as $1/\tau^2$.

### 7.5 Bits-per-byte: comparing models with different tokenizers

Perplexity per token is not comparable across tokenizers (a tokenizer with longer tokens has fewer, harder
predictions). Normalize by raw bytes instead:

$$
\text{BPB} = \frac{\sum_t -\ln p(x_t\mid x_{<t})}{\ln 2 \times \text{number of UTF-8 bytes}}
$$

```python
total_nats, n_tokens, n_bytes = 2.3 * 1000, 1000, 4200    # mean loss 2.3 nats/token, ~4.2 bytes/token
print("PPL:", round(np.exp(total_nats / n_tokens), 2), " BPB:", round(total_nats / (np.log(2) * n_bytes), 3))
```

### 7.6 Compression = prediction

By Shannon's source-coding theorem, a model with cross-entropy $H$ bits/token can losslessly compress text to
~$H$ bits/token (via arithmetic coding). Lower loss literally means better compression — one useful way to think
about what pretraining optimizes.

### 7.7 InfoNCE bounds mutual information

For contrastive learning with $N$ candidates (1 positive, $N-1$ negatives),

$$
I(X; Y) \ge \log N - \mathcal{L}_{InfoNCE}
$$

So the bound saturates at $\log N$ — another reason embedding models are trained with very large batches.

## Key takeaways

1. Information = $-\log p$; entropy = expected surprise.
2. Cross-entropy with one-hot targets = $-\log$(probability of the correct answer) — the LLM loss.
3. Softmax + cross-entropy gradient = predicted − true.
4. KL measures how far one distribution is from another; it is asymmetric.
5. Perplexity = $e^{\text{loss}}$.

Next: [05 — Optimization](05_optimization.md)
