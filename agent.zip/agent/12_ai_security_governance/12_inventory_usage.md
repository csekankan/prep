# 12 — AI Inventory, Usage, Cost, and Ownership

You cannot govern what you cannot see. This module builds **visibility**: which AI systems exist,
who uses them, how much they cost, and who is accountable.

## Architecture: from raw signals to an inventory and a cost report

Visibility comes from joining several imperfect sources. Each one finds things the others miss.

```mermaid
flowchart LR
  subgraph DISC[Discovery sources]
    GW[Gateway logs]
    BILL[Cloud billing]
    CODE[Code search<br/>SDK imports, keys]
    PROC[Procurement<br/>SaaS AI features]
    CASB[Browser and CASB<br/>public chatbot use]
  end
  DISC --> REC[Reconciliation job<br/>match to registry]
  REC -->|known| INV[(AI inventory<br/>registry)]
  REC -->|unknown| SH[Shadow AI queue<br/>owner must register]
  SH --> INV
  HR[HR directory] -->|owner status| INV
  GW --> UE[(Usage events<br/>tagged system, team, model)]
  PRICE[Model price table] --> COST[Cost allocation<br/>per team and system]
  UE --> COST
  INV --> DASH[Inventory and<br/>usage dashboard]
  COST --> DASH
```

| Component | Responsibility | Why it sits here |
|---|---|---|
| Gateway logs | real model calls with `system_id` and team tags | the most accurate source, but only for traffic that goes through the gateway |
| Cloud billing | AI spend per account | catches systems that bypass the gateway |
| Code search | finds SDK imports and hard-coded keys | catches systems before they generate spend |
| Procurement | vendor tools with AI features | catches AI that you *buy*, not build |
| Browser and CASB (cloud access security broker) logs | employee use of public AI sites | catches individual shadow AI use |
| Reconciliation job | matches every finding to a registry entry | turns raw detections into a work queue |
| Usage events and cost allocation | tokens times price, grouped by team | makes cost visible to the people who can reduce it |

### Follow one case through it: shadow AI found by billing

1. The nightly reconciliation sees $1,900 of model spend in the marketing cloud account. No inventory entry points to that account.
2. Code search finds a repository in the marketing organization that imports an AI SDK and calls a model directly, bypassing the gateway.
3. The reconciliation job opens a shadow-AI ticket assigned to the repository's most active maintainer.
4. The team registers the system ("CampaignWriter", owner Mia, medium risk). Its entry now links the billing account and repository.
5. The team moves its calls behind the gateway. Usage events now arrive tagged `system_id=sys-campaignwriter, team=Marketing`.
6. The next monthly cost report shows CampaignWriter under the Marketing cost center, and the shadow-AI KRI drops by one.

**The one idea to keep:** **no single source sees everything.** Visibility is a reconciliation
problem: join gateway, billing, code, and procurement data against one registry.

## Enterprise AI inventory

An inventory entry per AI system (including vendor features and "shadow AI"):

```yaml
id: sys-codeassist
name: CodeAssist
purpose: AI coding assistant in IDEs
owner: priya@acme.com          # accountable person, not a team alias
team: Developer Platform
cost_center: CC-300
risk_tier: medium
users: 400 engineers (internal)
models: [{provider: AWS Bedrock, model: anthropic.claude-sonnet, region: eu-central-1}]
data: [{name: source code, sensitivity: confidential}]
integrations: [GitHub, Jira]
status: live
last_assessment: 2026-08-02
```

### How to discover AI systems (shadow AI)
| Source | Finds | Example |
|---|---|---|
| AI gateway / proxy logs | apps calling LLM APIs | an unknown service calling `api.openai.com` |
| Cloud billing | Bedrock/Azure OpenAI spend by account | $1,900 Bedrock spend in a marketing account |
| Code search | SDK imports, API keys | `from openai import` in 37 repos |
| Procurement | SaaS with AI features | new CRM "AI email writer" enabled |
| Browser/CASB | employees using public chatbots | 120 users on a free AI chat site |
| Surveys / intake | planned projects | HR wants a CV screener (→ EU AI Act high-risk!) |

## AI usage telemetry

Emit one usage event per model call (the gateway from module 09 does this):
```json
{"ts":"2026-11-12T07:01:00Z","system_id":"sys-helpbot","user_id":"cust_88","team":"CX",
 "model":"gpt-4o-mini","tokens_in":1200,"tokens_out":180,"latency_ms":900,
 "guardrail_events":["pii_redacted"],"outcome":"answered"}
```
Required tags: `system_id`, `team`/`cost_center`, `model`, `environment`. Without tags, cost can't be allocated.

## Model usage analytics — example questions and queries

```sql
-- Which models are used by which systems?
SELECT system_id, model, COUNT(*) AS calls FROM usage_event
WHERE ts > now() - interval '30 days' GROUP BY 1,2 ORDER BY calls DESC;

-- Are unapproved models in use?
SELECT DISTINCT u.system_id, u.model FROM usage_event u
LEFT JOIN model_version m ON m.system_id = u.system_id AND m.model = u.model
WHERE m.id IS NULL;
```
Example finding: *ContractLens switched to a new model without re-approval* → governance exception (module 13).

## Token consumption and cost allocation

`cost = tokens_in × price_in + tokens_out × price_out` (per model, from a price table).

| Team | System | Tokens (M) | Cost / month | Cost per resolved ticket |
|---|---|---|---|---|
| CX | HelpBot | 310 | $1,240 | $0.03 |
| Dev Platform | CodeAssist | 820 | $9,800 | — |
| Finance | InvoiceAgent | 45 | $2,100 | $0.42 per invoice |

Cost controls: budgets per cost center, alert at 80%, hard limit per user/day, cheaper model routing
for simple tasks, caching. **Example**: InvoiceAgent loop bug → 30M tokens in a night → budget alert
at 02:00, kill switch → $600 instead of $9,000.

## AI ownership and accountability

Every system needs named people:
| Role | Accountable for | Acme HelpBot |
|---|---|---|
| **System owner** (business) | purpose, risk acceptance, budget | Ana (Head of CX) |
| **Technical owner** | build, operate, fix | Leo (Eng manager) |
| **Data owner** | data used for RAG/training | Knowledge team lead |
| **Risk/compliance contact** | assessments, reviews | AI Gov Office |

Rules: an owner must be a person; on leaving the company, ownership is reassigned within 30 days
(an HR offboarding event triggers a check); systems without owners are a **KRI** (module 15).

## Project: AI inventory and usage dashboard

Build (Streamlit / Grafana / any BI) on the schema from module 11 + `usage_event`:

1. **Inventory view** — table of systems with owner, tier, status, last assessment; filter "missing owner", "assessment overdue".
2. **Usage view** — calls & tokens per system per day; top users.
3. **Cost view** — cost per team vs budget; forecast to month-end.
4. **Risk view** — unapproved models in use, shadow AI detections, systems live without approval.

Example dashboard tiles:
```
 Systems: 4 (1 high risk)   Shadow AI found: 2   Monthly cost: $13.1k (budget $15k)
 Unapproved model usage: 1 (ContractLens → llama-3.1-70b)   Owners missing: 0
```

## FAANG deep-dive notes

**Typical design-review prompt:** *"Build AI usage and cost visibility for a company spending $2
million per month on models across 300 teams. Finance wants cost per team, and security wants to know about every AI system."*

**1. Clarify first:**
- Is all model traffic forced through a gateway, or can teams hold their own provider keys? This decides whether telemetry is complete.
- What granularity does finance need: team, cost center, product feature, or customer? Tags must be designed for the finest level required.
- Are provider prices fixed per token, or are there committed-use discounts and self-hosted GPUs? Self-hosted cost needs a different allocation method (GPU-hours, not tokens).
- What happens when a team exceeds its budget: an alert, approval, or a hard stop?

**2. Back-of-envelope:**
- Event volume: if the average request uses about 2,000 tokens and the blended price is an illustrative $2 per million tokens, $2M per month is about 1 trillion tokens, about 500M requests per month, roughly 190 per second.
- Storage: 500M events × about 300 bytes = 150 GB per month raw, which is small for a columnar analytics store. Keep a year of raw events and aggregate after that.
- Untagged cost: if 10% of requests lack a team tag, $200,000 a month is unallocated, which is usually enough to get tagging enforced.
- Budget alerts: 300 teams with 80% and 100% thresholds is up to 600 alerts per month at most; route them to team owners, not to a central team.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Tagging | optional, best effort | required, untagged calls rejected | required at the gateway; reject or default-route untagged calls to the system owner |
| Allocation | showback (report only) | chargeback (bill teams) | start with showback, move to chargeback when numbers are trusted |
| Self-hosted models | ignore in cost reports | allocate GPU-hours by token share | allocate, or self-hosting looks "free" and grows unchecked |
| Budget enforcement | alert only | hard stop | alert for most teams; hard stop for runaway agents and per-user limits |
| Shadow AI response | block immediately | register within a deadline | register within a deadline; block only for high-risk data exposure |

**4. Follow-up questions with crisp answers:**
- *Why measure cost per outcome (per ticket, per invoice) instead of total cost?* Total cost rises with adoption, which can be good. Cost per outcome shows efficiency and makes model-routing decisions clear.
- *How do you allocate shared platform costs like the gateway itself?* Proportionally to usage (tokens or requests), shown as a separate line so teams can see it.
- *How do you find AI features inside SaaS tools you buy?* Procurement questionnaires, contract reviews, and vendor-assessment renewals. Telemetry usually can't see them.
- *What makes an ownership record trustworthy?* A named person from the HR directory, checked automatically, so a departure triggers reassignment within a deadline.
- *How do you detect unapproved model usage?* Compare the model in each usage event with the approved model list for that system. Any mismatch is an exception or a violation.
- *How do you handle employees using public chatbots?* Provide an approved internal alternative first, then use browser or CASB controls to warn or block, and track usage as a KRI.
- *What's a good first dashboard?* Four tiles: systems by risk tier and status, cost versus budget by team, shadow AI findings, and unapproved model usage.
- *How do you forecast cost?* Use trailing usage growth per system plus planned launches. Agents and long-context features change cost per request sharply, so forecast them separately.
- *Why are cached tokens or batch discounts a reporting problem?* Prices differ for cached input, batch jobs, and committed capacity. Use the actual per-request price, or the reports will disagree with the invoice.
- *How do you reconcile your numbers with the provider's invoice?* Monthly. Differences above a few percent point to untagged traffic, traffic that bypasses the gateway, or a stale price table.

**Debug this:** *"The monthly cost report says 40% of tokens are untagged, up from 5% last month."*
1. Break down the untagged tokens by source. 90% come from one gateway route used by the new agent framework.
2. Inspect sample requests. The framework sends model calls from a background worker that doesn't forward the `team` and `system_id` headers.
3. Mechanism: tags are attached by the calling app per request, and a new code path skipped them. The gateway accepted untagged calls.
4. Fix: give each API key a default owner and system at the gateway (tags come from the key, not only the headers), and patch the framework to pass headers.
5. Prevention: an alert when the untagged share exceeds 5%, and a gateway rule rejecting untagged calls from production keys.

Lesson: **attach ownership to credentials, not to request headers.** Headers are easy to forget, but every call carries a key.

**5. Senior vs. staff:**
- Senior: builds the inventory, usage events, cost dashboards, and owner tracking.
- Staff: designs discovery as reconciliation across sources, makes tagging impossible to skip, allocates self-hosted cost, reconciles with invoices, and ties findings to KRIs.

**Red flags:** an inventory without discovery; optional tags; self-hosted models reported as free; owners who left the company; cost reports that never match the invoice.
