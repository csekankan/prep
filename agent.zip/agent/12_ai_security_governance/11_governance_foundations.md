# 11 — AI Governance Foundations

## Running example used in modules 11–15: Acme Corp

| System | What it does | Users | Data | Model |
|---|---|---|---|---|
| **HelpBot** | customer support chat with RAG over help center | public customers | product docs, order status | GPT-4o-mini (vendor) |
| **CodeAssist** | coding assistant in IDE | 400 engineers | source code | Claude via Bedrock |
| **ContractLens** | extracts clauses & risks from supplier contracts | legal, procurement | contracts, prices | Llama 3 (self-hosted) |
| **InvoiceAgent** | agent that matches invoices and **schedules payments** | finance | invoices, bank details | GPT-4o + tools |

Governance must answer for each: *Do we know it exists? Who owns it? How risky is it? Was it
approved? What controls apply? Is it working? Can we prove it?*

## Governance across the AI lifecycle

| Lifecycle stage | Governance activity | Acme example |
|---|---|---|
| Idea / intake | register use case, initial risk tier | finance proposes InvoiceAgent |
| Design | impact assessment, data approval | bank details = high sensitivity |
| Build | security requirements, guardrails | payment tool requires approval |
| Evaluate | test evidence, red-team | 200 injection tests, 0 unauthorized payments |
| Approve | sign-off by accountable roles | CFO + CISO + DPO |
| Deploy | controls on, monitoring wired | gateway policy `invoice-v1` |
| Operate | KPIs, KRIs, incidents | weekly report |
| Change | re-assessment on material change | switching model → re-approve |
| Retire | decommission, data deletion | delete vector index & logs per retention |

## Governance vs related disciplines

| Discipline | Core question | Example at Acme |
|---|---|---|
| **AI governance** | are we making AI decisions the right way, with accountability? | approval process, ownership, inventory |
| **Risk management** | what can go wrong, how likely, how bad? | InvoiceAgent pays fraudulent invoice |
| **Compliance** | do we meet laws and contracts? | EU AI Act, GDPR, vendor DPA |
| **Security** | can attackers misuse or break it? | prompt injection → payment |
| **Privacy** | is personal data handled lawfully? | customer emails in HelpBot logs |
| **Safety** | can it harm people? | HelpBot gives dangerous product-use advice |
| **Responsible AI** | is it fair, transparent, and human-centred? | disclose "you are chatting with an AI" |

Governance is the **umbrella** that makes sure the others happen, and the evidence exists.

## AI governance operating model

```
                 Board / Risk Committee         ← sets risk appetite, receives reports
                          │
                 AI Governance Council          ← CISO, DPO, Legal, CTO, business heads
                          │                       approves high-risk systems, owns policy
          ┌───────────────┼────────────────┐
   AI Governance Office   Security          Privacy        ← 2nd line: standards, reviews, monitoring
          │
   System owners + builders (product, data science, engineering)   ← 1st line: build & operate
          │
   Internal audit                              ← 3rd line: independent assurance
```
**Three lines model**: 1st line owns the risk, 2nd line sets rules and checks, 3rd line audits independently.

RACI example for "approve InvoiceAgent go-live":
| Task | System owner | AI Gov Office | CISO | DPO | CFO |
|---|---|---|---|---|---|
| impact assessment | **R** | C | C | C | I |
| security review | C | I | **A/R** | I | I |
| final approval | R | C | C | C | **A** |

## Governance data architecture

Governance runs on **data**, not documents in email. Core entities:

```
 AISystem ──< ModelVersion          (which models, versions, vendors)
    │  └──< Dataset                 (training/RAG data, sensitivity)
    ├──< Assessment ──< Approval    (impact/security/privacy reviews, sign-offs)
    ├──< Control ──< ControlTest    (guardrails, policies, test results)
    ├──< Exception                  (approved deviations, expiry)
    ├──< Incident                   (breaches, near-misses)
    └──< UsageRecord                (requests, tokens, cost, guardrail events)
 Owner / Team / CostCenter          (accountability)
```
Sources feeding it: the AI gateway (usage, guardrail events), cloud billing, CI (eval results),
ticketing (approvals, incidents), HR directory (owners).

## Architecture: the governance platform

The entity model above says *what* governance tracks. This diagram shows *how the data gets there*
and who uses it. Most of it should be collected automatically, because self-reported data goes stale.

```mermaid
flowchart LR
  subgraph SOURCES[Automatic sources]
    GW[AI gateway<br/>usage, guardrail events]
    BILL[Cloud billing<br/>AI spend by account]
    CI[CI pipelines<br/>eval and control tests]
    HR[HR directory<br/>owners, teams]
  end
  subgraph HUMAN[Human workflows]
    IN[Intake form<br/>new use case]
    WF[Assessment and<br/>approval workflow]
    INC[Incident tickets]
  end
  SOURCES --> GDB[(Governance data store<br/>systems, models, controls,<br/>approvals, incidents, usage)]
  HUMAN --> GDB
  GDB --> DASH[Dashboards<br/>inventory, cost, risk]
  GDB --> REP[Reports<br/>board, audit, regulators]
  GDB --> ALERT[Policy checks<br/>live without approval,<br/>expired exceptions]
  ALERT --> WF
```

| Component | Responsibility | Why it sits here |
|---|---|---|
| AI gateway | records which system called which model, how much, and with which guardrail outcomes | the only source that sees real usage, including systems nobody registered |
| Cloud billing | shows AI spend by account and project | finds shadow AI that bypasses the gateway |
| CI pipelines | publish eval and control-test results | turns "we tested it" into stored evidence |
| HR directory | keeps owners current | owners leave; systems shouldn't become orphans |
| Intake and approval workflow | the human decisions: risk tier, sign-offs, conditions | judgement can't be automated, but it can be recorded |
| Governance data store | one place joining all of the above | every question ("which high-risk systems lack approval?") becomes a query |
| Policy checks | continuously compare reality against rules | governance that only runs at approval time misses drift |

### Follow one case through it: InvoiceAgent

1. Finance submits an intake form for InvoiceAgent. The data store creates `sys-invoice` with status `proposed` and owner Raj.
2. The assessment workflow scores it as **high** risk (payments, untrusted invoice PDFs). That tier requires a security review, red-team evidence, and approval by the governance council.
3. CI publishes the red-team results (200 injection tests, 0 unauthorized payments) to the data store as evidence linked to the system.
4. The CFO and CISO approve with conditions (a €10,000 payment limit, monthly sample audits). Status becomes `approved`, valid for six months.
5. Go-live: the gateway starts sending usage and guardrail events tagged `system_id=sys-invoice`.
6. Two months later, the gateway reports InvoiceAgent calling a model version that isn't in its approved list. A policy check opens a re-assessment task automatically.
7. The quarterly board report pulls InvoiceAgent's incidents, KRIs, and approval status straight from the store.

**The one idea to keep:** governance runs on **data that flows in automatically**. Documents and
meetings record decisions; telemetry tells you whether reality still matches them.

## Governance frameworks (what each is for)

| Framework | Type | Use it for |
|---|---|---|
| **NIST AI RMF 1.0** | voluntary US framework | four functions: **Govern, Map, Measure, Manage** — structure of your program |
| **NIST AI 600-1** | GenAI profile of AI RMF | GenAI-specific risks (confabulation, data privacy, info security…) |
| **ISO/IEC 42001** | certifiable management-system standard | an auditable AI management system (like ISO 27001 for AI) |
| **ISO/IEC 23894** | risk-management guidance | AI risk process |
| **EU AI Act** | law (EU) | risk tiers: prohibited, high-risk, limited (transparency), minimal; GPAI obligations |
| **OWASP LLM Top 10** | security risk list | threat modelling (module 01) |
| **MITRE ATLAS** | adversary tactics knowledge base | red-teaming and detection mapping |

**Example mapping** — HelpBot:
- EU AI Act: *limited risk* → must disclose that users interact with an AI.
- NIST Map: context = public users; Measure: injection ASR, groundedness; Manage: guardrails + incident playbook.

InvoiceAgent is not an Annex III high-risk use under the EU AI Act, but Acme treats it as
**internally high-risk** (financial impact) — your internal tiers can be stricter than the law.

## Project: governance data foundation

Build a small schema + seed data you will reuse in modules 12–15.

```sql
CREATE TABLE ai_system (
  id TEXT PRIMARY KEY, name TEXT, purpose TEXT, owner_email TEXT, team TEXT, cost_center TEXT,
  risk_tier TEXT CHECK (risk_tier IN ('low','medium','high','prohibited')),
  lifecycle_stage TEXT, user_population TEXT, data_sensitivity TEXT,
  status TEXT CHECK (status IN ('proposed','in_review','approved','live','suspended','retired'))
);
CREATE TABLE model_version (id TEXT PRIMARY KEY, system_id TEXT REFERENCES ai_system,
  provider TEXT, model TEXT, version TEXT, hosting TEXT);
CREATE TABLE control (id TEXT PRIMARY KEY, system_id TEXT REFERENCES ai_system,
  name TEXT, type TEXT, layer TEXT, status TEXT);
```
```sql
INSERT INTO ai_system VALUES
 ('sys-helpbot','HelpBot','customer support','ana@acme.com','CX','CC-210','medium','operate','public','internal','live'),
 ('sys-invoice','InvoiceAgent','invoice matching & payment','raj@acme.com','Finance','CC-400','high','build','internal','confidential','in_review');
```
Deliverable: the schema, seed data for the 4 systems, and one query: *"list high-risk systems that are live without an approved assessment"* (should return none).

## FAANG deep-dive notes

**Typical design-review prompt (staff or principal level):** *"Design an AI governance program and
platform for a company with 2,000 AI systems, 30 billion tokens per month, and operations in the EU and US."*

**1. Clarify first:**
- What counts as an "AI system": every app calling a model, vendor SaaS features, internal ML models? The definition sets the inventory size and the workload.
- Which regulations apply (EU AI Act, sector rules like finance or health)? They set mandatory controls and evidence.
- What is the risk appetite set by the board? It decides where the high-risk threshold sits.
- How decentralized is engineering? With hundreds of teams, governance must be self-service with automated checks, or it becomes a bottleneck.

**2. Back-of-envelope: review workload**
- Tier mix (assumed): 70% low, 25% medium, 5% high, which is 1,400 low, 500 medium, and 100 high-risk systems.
- Annual review effort (assumed): 1 hour per low, 8 hours per medium, 40 hours per high system.
- Total: 1,400 × 1 + 500 × 8 + 100 × 40 = 1,400 + 4,000 + 4,000 = **9,400 person-hours per year**, about 5 full-time reviewers at roughly 1,800 working hours each.
- Insight: the 100 high-risk systems take as much effort as the 500 medium ones. Automating low and medium reviews (questionnaires plus telemetry checks) is where the program scales.
- Telemetry: 30B tokens per month at about 1,500 tokens per request is about 20M requests per month, roughly 8 per second on average. The governance data volume is modest; joining sources correctly is the hard part.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Inventory | self-registration | automatic discovery plus registration | discovery (gateway, billing, code search) reconciled against registrations |
| Reviews | every system gets a full review | tiered by risk | tiered; spend reviewer time where impact is highest |
| Organization | central team approves everything | central standards, federated execution | central standards and high-risk approvals; teams self-serve low risk |
| Frameworks | adopt one framework | map controls once to several | one internal control set mapped to NIST AI RMF, ISO 42001, and the EU AI Act |
| Evidence | collected before audits | collected continuously | continuous, generated by systems (CI, gateway), not by people |

**4. Follow-up questions with crisp answers:**
- *How is AI governance different from AI security?* Security protects systems from misuse and attack. Governance decides which systems should exist, who is accountable, which controls are required, and proves it.
- *Why not just use the EU AI Act risk tiers internally?* They cover legal obligations but not business risk. A payment agent may be legally "minimal risk" and still need strict internal controls.
- *What's the role of the three lines model?* Builders own and manage the risk (1st line), governance and risk teams set rules and monitor (2nd line), and internal audit independently checks both (3rd line).
- *Why is a named person the owner, not a team?* Teams don't answer questions or accept risk; people do. Ownership is reassigned when people leave.
- *How do you map one control to several frameworks?* Keep a control library (for example, "CTL-011 payment approval") and tag each control with the framework requirements it satisfies. Evidence is collected once.
- *How do you get engineering teams to comply willingly?* Make the compliant path the easy path: templates, a gateway that handles controls, automatic evidence, and fast low-risk approvals.
- *Which framework is certifiable?* ISO/IEC 42001 is a certifiable management-system standard. NIST AI RMF is voluntary guidance. The EU AI Act is law.
- *What is "material change"?* A change that alters the risk: new model or vendor, new tools with write access, new data categories, new user populations, or more autonomy. It triggers re-assessment.
- *How do you measure whether governance works?* KPIs like the share of systems with owners and valid approvals, and KRIs like shadow AI found and expired exceptions (module 15).
- *What's the first 90-day plan for a new governance program?* Inventory through discovery, name owners, set risk tiers, gate high-risk systems, and stand up the data store and dashboard.

**Debug this:** *"The governance dashboard shows 4 high-risk AI systems. A security review finds 9."*
1. List the 5 missing systems and how they were found: two from cloud billing, two from code search, one from a vendor contract.
2. Check why the inventory missed them. All 5 were never registered, because the inventory relied on self-registration through the intake form.
3. Check the gateway. Three of them call model providers directly with their own API keys, so the gateway never saw them.
4. Fix: register and assess the 5 systems, move provider keys behind the gateway, and add nightly reconciliation between billing, gateway, code search, and the inventory.
5. Prevention: a KRI for "unregistered AI usage detected", reported monthly, and a policy that provider keys can only be issued through the gateway.

Lesson: **an inventory built on self-reporting measures honesty, not reality.** Reconcile it with automatic sources.

**5. Senior vs. staff:**
- Senior: sets up an inventory, risk tiers, and an approval workflow.
- Staff: builds governance on automated data sources, sizes reviewer workload and automates the low tiers, maps one control library to several frameworks, and designs for engineering adoption.

**Red flags:** an inventory in a spreadsheet; team aliases as owners; one review depth for every system; evidence collected manually right before audits.
