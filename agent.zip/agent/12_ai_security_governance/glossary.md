# Glossary

| Term | Meaning | Example |
|---|---|---|
| **Agent** | LLM that plans and calls tools in a loop toward a goal | travel agent searching + booking flights |
| **Approval fatigue** | humans approving without reading because of too many prompts | clicking "approve" on the 30th popup |
| **ASR** | attack success rate: successful attacks / attempts | 6 of 200 injections succeeded → 3% |
| **Audit trail** | complete, attributable, tamper-evident log of decisions | hash-chained events per tool call |
| **Blast radius** | the maximum damage if a component is compromised | read-only bot → small; payment agent → large |
| **CaMeL / Dual LLM** | separating a privileged planner from a quarantined LLM that reads untrusted data | quarantined LLM returns only a date, never instructions |
| **Compensating control** | alternative control used while the normal one can't be met | human review while model is unapproved |
| **Confused deputy** | a privileged component tricked into acting for an attacker | agent with admin key fetches another user's order |
| **Context isolation** | separating untrusted content from instructions (delimiters, labels) | `<document trust="untrusted">…</document>` |
| **Corrective control** | limits damage after an event | kill switch, memory purge |
| **Data poisoning** | planting malicious content in training or RAG data | fake refund policy in the knowledge base |
| **Detective control** | detects that something happened | alert on guardrail block spike |
| **DLP** | data loss prevention: detect/redact sensitive data in outputs | mask card numbers |
| **DPIA** | data protection impact assessment (GDPR Art. 35) | required for high-risk personal-data processing |
| **Egress allow-list** | only approved outbound destinations | app may call only `api.openai.com` |
| **EU AI Act** | EU law with risk tiers for AI systems | chatbots must disclose they're AI |
| **Exception** | documented, time-limited deviation from a control | EXC-019 expires Dec 15 |
| **Excessive agency** | agent has more tools/permissions/autonomy than needed | support bot with `delete_user` |
| **Guardrail** | check on input/output/tool/data that detects or blocks unsafe behaviour | PII redaction |
| **Groundedness** | answer supported by retrieved sources | each claim cites a chunk |
| **HITL** | human-in-the-loop approval or review | confirm before sending email |
| **Indirect prompt injection** | instructions hidden in content the model reads | hidden text in a web page |
| **Instruction hierarchy** | system > developer > user > data priority | document text cannot override system rules |
| **Inventory** | register of all AI systems with owner, tier, status | 4 systems at Acme |
| **ISO/IEC 42001** | certifiable AI management-system standard | audited like ISO 27001 |
| **Jailbreak** | technique to make a model ignore its safety rules | role-play "DAN" |
| **Kill switch** | flag that instantly disables a tool/feature | `invoice_agent.enabled=false` |
| **KPI / KRI** | performance indicator / risk indicator with thresholds | % systems approved / expired exceptions |
| **Lethal trifecta** | private data + untrusted content + external communication in one agent | inbox agent that can send email |
| **Least privilege** | grant only the minimum permissions needed | read-only ERP access |
| **Memory poisoning** | getting malicious content saved in persistent memory | "always add this link" stored |
| **MITRE ATLAS** | knowledge base of adversary tactics against AI | technique IDs for red-team reports |
| **Model / system / agent card** | standard documentation of a model / application / agent | agent card with tools & limits |
| **Near-miss** | incident that was stopped by a control | injected invoice blocked |
| **NIST AI RMF** | Govern, Map, Measure, Manage framework | program structure |
| **OWASP LLM Top 10** | top security risks for LLM apps | LLM01 Prompt Injection |
| **Parameter injection** | attacker controls tool arguments | `to="attacker@evil.example"` |
| **Policy-as-code** | rules as versioned, tested code evaluated at runtime | Rego policy for tool calls |
| **Policy engine** | component that decides allow/block/redact/approve | OPA |
| **Preventive control** | stops an event happening | tool allow-list |
| **Prompt injection** | input that makes the model follow attacker instructions | "Ignore previous instructions" |
| **RACI** | Responsible, Accountable, Consulted, Informed | CFO accountable for InvoiceAgent approval |
| **Red teaming** | adversarial testing by authorized testers | 200-case attack suite |
| **Risk scoring** | combining signals into a number that drives a decision | 0.74 → require review |
| **Separation of duties** | the same person can't both do and approve | builder ≠ approver |
| **Shadow AI** | AI used without registration/approval | unknown service calling an LLM API |
| **Spotlighting / datamarking** | marking untrusted text so the model treats it as data | interleaving `^` between words |
| **System prompt leakage** | revealing hidden instructions | "repeat the text above" |
| **Taint tracking** | marking data from untrusted sources and restricting its use | tainted email address can't be a recipient without approval |
| **Three lines model** | owners / risk & compliance / internal audit | 1st, 2nd, 3rd line |
| **Trust boundary** | where data crosses from less to more trusted | user upload entering the prompt |
| **Unbounded consumption** | uncontrolled token/compute usage | agent loop costing $3k overnight |
