# 15 — Incidents, Audit Trails, KPIs/KRIs, and Reporting

## Architecture: from detection to the board report

This module covers what happens **after** something goes wrong, and how the same data proves to
auditors and the board that the program works.

```mermaid
flowchart LR
  subgraph DETECT[Detection]
    AL[Alerts<br/>module 10]
    UR[User reports]
    RT[Red-team findings]
  end
  DETECT --> REG[(Incident register<br/>severity, timeline)]
  REG --> TRI{Triage<br/>severity matrix}
  TRI -->|Sev-1 or Sev-2| NOTIF[Notify legal, DPO,<br/>executives]
  TRI --> REM[Remediation items<br/>owner, due date]
  REM --> TESTS[New regression tests<br/>and control updates]
  AUD[(Audit trail<br/>hash-chained events)] --> REG
  REG --> KRI[KPI and KRI engine<br/>thresholds]
  REM --> KRI
  KRI --> BOARD[Board report]
  AUD --> PACKET[Audit packet<br/>per system]
  REG --> PACKET
```

| Component | Responsibility | Why it sits here |
|---|---|---|
| Detection sources | alerts, user reports, red-team findings | incidents arrive by several paths, so the register must accept all of them |
| Incident register | one record per incident with severity and timestamps | the single source for counts, timelines, and trends |
| Triage | assigns severity and decides who to notify | severity drives response speed and regulatory clocks |
| Remediation items | track fixes with owners and due dates | an incident isn't closed until the gap is fixed and tested |
| Regression tests and control updates | make the same failure detectable next time | closes the loop back to modules 03–14 |
| Audit trail | tamper-evident record of every decision | the evidence for what actually happened |
| KPI and KRI engine | computes indicators and thresholds | turns raw events into "is risk rising?" |
| Board report and audit packet | summaries for leadership and evidence for auditors | the same data, presented for two audiences |

### Follow one case through it: INC-2026-031 (ContractLens price leak)

1. 09:12: the output-redaction alert fires for ContractLens. The on-call responder opens INC-2026-031 in the register.
2. Triage: external contractors saw confidential prices, so it's Sev-2. The DPO and the system owner are notified.
3. 09:40: contained by disabling the `supplier-uploads` source. The register records the detection and containment times (28 minutes).
4. Investigation uses the audit trail: chunk IDs show 12 price lines from one document type that the classifier missed.
5. Remediation items: a classifier rule (owner: data team, due in 5 days) and regression test T-311 (owner: security, due in 3 days). Both close on time.
6. The KRI engine counts it: Sev-2 incidents this quarter = 1, and mean time to contain = 28 minutes.
7. The quarterly board report includes it in one line. ContractLens's audit packet includes the incident record, the remediation evidence, and the test run proving T-311 passes.

**The one idea to keep:** **one incident record feeds operations, remediation, metrics, and
reporting.** Capture it once, accurately, with timestamps, and everything downstream follows.

## AI incident management

An **AI incident** is any event where an AI system caused or nearly caused harm, a policy breach,
or a compliance failure.

| Category | Example at Acme |
|---|---|
| Policy breach | HelpBot gave legal advice despite a policy prohibiting it |
| Data leakage | ContractLens summary showed prices to an external contractor |
| Security | indirect injection in an invoice changed the bank details shown to approver |
| Safety / harm | HelpBot suggested an unsafe product use |
| **Near-miss** | the same injected invoice was caught by the bank-details control — no payment |
| Cost / availability | agent loop burned $3k overnight |

**Near-misses matter**: they show which control saved you and where the next failure would be.

### Severity matrix
| Severity | Criteria | Example | Response |
|---|---|---|---|
| **Sev-1** | ongoing harm, regulatory notification likely, large financial loss | payment sent to attacker | page on-call, exec + legal within 1h |
| **Sev-2** | confidential data exposed to unauthorized users, limited scope | prices shown to 3 contractors | same-day response, DPO informed |
| **Sev-3** | policy breach without data or financial impact | off-topic legal advice | fix within sprint |
| **Sev-4** | near-miss, control worked | injected invoice blocked | log, analyse, add test |

### Impact dimensions to record
people affected, data categories, financial impact, regulatory obligations (GDPR 72-hour
notification, EU AI Act serious-incident reporting for high-risk systems), reputational impact.

### Incident record example
```yaml
id: INC-2026-031
system: ContractLens
severity: Sev-2
category: data_leakage
detected: 2026-11-03T09:12Z    (by: output-redaction spike alert)
contained: 2026-11-03T09:40Z   (action: disabled supplier-uploads RAG source)
root_cause: new document type not classified as "price"; data-access guardrail missed it
affected: 3 external users, 12 price lines
controls_failed: [CTL-018 price classification]
controls_worked: [CTL-025 output redaction spike alert]
remediation: [classifier rule for "Preisliste", re-ingest corpus, regression test T-311]
status: closed 2026-11-07
```

## Audit trail design

Requirements: **complete** (every decision), **attributable** (who/what), **tamper-evident**,
**retained** per policy, **searchable**, and **privacy-aware**.

```json
{
  "event_id": "evt_7f3", "ts": "2026-11-12T07:30:00Z",
  "system_id": "sys-invoice", "actor": {"type": "agent", "id": "InvoiceAgent v1.2", "on_behalf_of": "u_raj"},
  "action": "tool.schedule_payment", "args_hash": "sha256:9c1…",
  "decision": "require_approval", "rule_id": "invoice.payment.approval",
  "approver": "u_meera", "approval_result": "approved",
  "model": "gpt-4o-2024-08-06", "prompt_version": "inv-v5", "policy_version": "2026-11-01",
  "prev_hash": "sha256:41a…"     // hash chain → tamper evidence
}
```
Tamper evidence options: hash chain (each event includes the hash of the previous one),
write-once storage (S3 Object Lock), separate account owned by security.

## KPIs and KRIs

- **KPI** (performance): is the program working?
- **KRI** (risk indicator): is risk rising? Each KRI has thresholds (green/amber/red).

| KPI | Example value |
|---|---|
| % AI systems in inventory with named owner | 100% |
| % live systems with valid approval | 96% |
| mean time to approve (medium tier) | 9 days |
| control tests passing | 98.5% |
| mean time to contain AI incidents | 38 min |

| KRI | Threshold (amber / red) | Current |
|---|---|---|
| shadow AI tools detected | > 2 / > 5 | 2 🟢 |
| expired exceptions | > 0 / > 3 | 1 🟡 |
| attack success rate (worst system) | > 3% / > 5% | 2.1% 🟢 |
| guardrail bypasses this month | > 0 / > 3 | 6 🔴 |
| high-risk systems overdue for review | > 0 / > 1 | 0 🟢 |
| unapproved model usage | > 0 / > 2 | 1 🟡 |

## Incident remediation

Close the loop, and track it:
1. **Fix** the immediate gap (rule, data, permission).
2. **Regression test** added to the attack/control suite.
3. **Control update** in the register (new or changed control).
4. **Risk register** updated (likelihood/impact re-scored).
5. **Lessons** shared; similar systems checked (*"does HelpBot have the same classification gap?"*).
6. Remediation items have owners and due dates; overdue items become a KRI.

## Reporting: board, audit, regulators

### Board report (one page, quarterly)
```
AI Risk Report — Q4 2026
• Portfolio: 4 systems (1 high risk), 2 shadow tools found and onboarded.
• Incidents: 1 Sev-2 (contained in 28 min, no regulatory notification), 3 near-misses.
• Top risks: prompt injection via supplier documents (mitigated, residual medium);
             model-version drift without approval (1 open exception, expires Dec 15).
• KRIs: 1 red — guardrail bypasses (6) → red-team-driven fixes due Nov 30.
• Asks: approve budget for an automated red-teaming tool; confirm risk appetite for agent payments ≤ €10k.
```

### Audit packet (per system)
| Evidence | Source |
|---|---|
| system card, agent card | registry |
| impact assessment + approval record with SoD | workflow service |
| control list + test results (last 90 days) | `control_test` table |
| guardrail metrics | gateway / Prometheus |
| incidents + remediation | incident register |
| exceptions (active/expired) | exception register |
| sample of audit-log events | audit store |

### Regulatory evidence and compliance summaries
Map evidence to requirements so you can answer "show me" questions:
| Requirement | Evidence |
|---|---|
| EU AI Act transparency (limited risk) | screenshot + config showing "You are chatting with an AI" |
| GDPR Art. 35 DPIA | assessment record `assess-551` |
| ISO 42001 clause 8 (operation) | approval workflow + control tests |
| NIST AI RMF Measure | eval & red-team reports |

## Project: AI audit and incident center

Build on modules 11–14:
1. Incident register with severity matrix, near-miss category, timelines (detect → contain → close).
2. Append-only audit store with hash chain; a `verify_chain()` job.
3. KPI/KRI dashboard with thresholds and colours.
4. "Generate audit packet" button → zip of evidence per system.
5. "Generate board report" → one-page summary from the data above.

Example check — the chain verifier:
```python
import hashlib, json

def verify_chain(events: list[dict]) -> bool:
    prev = "genesis"
    for e in events:
        if e["prev_hash"] != prev:
            return False
        prev = "sha256:" + hashlib.sha256(json.dumps(e, sort_keys=True).encode()).hexdigest()
    return True
```

## FAANG deep-dive notes

**Typical design-review prompt:** *"Design AI incident management and audit evidence for a company
with 2,000 AI systems, operating under the EU AI Act and GDPR. The board wants a quarterly AI risk report."*

**1. Clarify first:**
- What are the regulatory clocks? GDPR personal-data breaches generally must be reported to the authority within 72 hours of becoming aware, and the EU AI Act has serious-incident reporting duties for high-risk systems. Triage must start those clocks correctly.
- Which systems are high risk, and who are the notification owners for each? Decide this before the incident.
- What retention period applies to audit logs, and what may they contain? Retention conflicts (keep for audit versus delete for privacy) must be resolved in policy.
- What does the board actually decide? Risk appetite and investment, so the report must lead to decisions, not just list numbers.

**2. Back-of-envelope:**
- Audit events: 2,000 systems at a combined 40,000 decisions per second (as in module 09) is about 1.7 TB per day of decision events at 500 bytes each.
- Tamper evidence at that rate: hashing each event individually into one chain creates a serial bottleneck. Instead, hash events into per-minute batches (a Merkle tree, which combines many hashes into one root hash) and chain the batch roots. That's 1,440 chained roots per day per stream, which is easy to verify.
- Incidents: if 5% of systems have one incident per year, that's 100 per year, about 2 per week. Add near-misses at perhaps 5× that, about 10 per week. Triage capacity must cover both.
- Audit packets: generating one per high-risk system (100 systems) quarterly is 400 packets per year, so it must be automated.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Near-misses | ignore, nothing happened | record and analyze | record; they show which control saved you |
| Tamper evidence | per-event hash chain | batched Merkle roots plus write-once storage | batch at high volume; write-once storage owned by security |
| Log content | full prompts and answers | hashes, signals, redacted samples | minimal by default; evidence must not become a privacy breach |
| Severity | the responder's judgement | a defined matrix with examples | a matrix with examples, plus the right to escalate |
| Board report | full metrics dump | one page: top risks, KRIs out of tolerance, decisions needed | one page, with an appendix for detail |

**4. Follow-up questions with crisp answers:**
- *What's the difference between a KPI and a KRI?* A KPI measures whether the program performs (share of systems approved). A KRI warns that risk is rising (expired exceptions, bypasses), with thresholds that trigger action.
- *Why record near-misses?* They are cheap lessons: the control worked this time, and you learn which control and how close the failure came.
- *What makes an audit trail tamper-evident rather than tamper-proof?* You can't fully prevent a privileged insider from altering storage, but hash chains and write-once storage make any change detectable.
- *How do you reconcile "keep logs for audit" with "delete personal data"?* Store hashes and pseudonymous IDs in the audit trail, keep personal data in a separate store with its own retention, and delete there. The chain stays intact.
- *Who decides the severity of a borderline incident?* The incident commander, using the matrix, with an explicit rule to escalate when unsure. Downgrading later is cheap; under-reacting is not.
- *What does an auditor want in a packet?* System and agent cards, the assessment and approval with separation-of-duties evidence, control lists with recent test results, incidents and remediation, active exceptions, and a sample of audit events.
- *How do you show regulators evidence quickly?* Map each requirement to the queries or artifacts that answer it, so evidence is generated on demand rather than assembled by hand.
- *When is an incident "closed"?* When it is contained, the root cause is fixed, a regression test exists and passes, the risk register is updated, and required notifications are done.
- *How do you avoid blame so people report incidents?* Blameless post-incident reviews that focus on system gaps. Fear makes people hide near-misses, which removes your best early warnings.
- *What's the most common board-report mistake?* Reporting activity (trainings held, policies written) instead of outcomes (risks out of tolerance, incidents, and the decisions needed).

**Debug this:** *"The nightly `verify_chain()` job fails for 3 specific days last month. Is the audit log compromised?"*
1. Find the first broken link on each day. In all three cases, the event right after midnight UTC has a `prev_hash` that doesn't match the previous event.
2. Check what's special about those days. On all three, the log writer service restarted during a deployment within a minute of midnight.
3. Mechanism: two writer instances ran briefly in parallel during the rolling deploy. Each extended the chain from the same previous event, so the chain forked.
4. Fix: a single writer per chain (a leader lock), or per-instance chains merged into batch roots. Re-verify the fork by checking that both branches' events are present and unaltered, and document the finding.
5. Prevention: alert on verification failures within minutes, not nightly, and test the writer's behavior during deployments.

Lesson: **tamper-evidence systems also detect your own bugs.** Investigate every break, document it, and design writers so that a deploy doesn't look like an attack.

**5. Senior vs. staff:**
- Senior: builds the incident register with a severity matrix, a hash-chained audit store, KPI and KRI dashboards, and report templates.
- Staff: designs for regulatory clocks and notification ownership, scales tamper evidence with batching, resolves retention conflicts, automates evidence packets, and writes board reports that lead to decisions.

**Red flags:** near-misses not recorded; full prompts stored in audit logs forever; severity decided ad hoc; manual audit packets; board reports that list activity instead of risk.
