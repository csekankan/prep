# 00 — Setup: Python, VS Code, Git, Ollama

## Why a local model for security work?

- **Free and unlimited** — attack testing sends thousands of prompts.
- **No provider filtering** — hosted APIs add their own safety layers, hiding what *your* defenses do.
- **Privacy** — test payloads and documents never leave your machine.
- **Same API shape** — Ollama exposes an OpenAI-compatible endpoint, so code moves to production providers unchanged.

Trade-off: small local models are *easier* to jailbreak than frontier models — great for learning
attacks; always re-test defenses against your production model.

## Tools

| Tool | Purpose | Check |
|---|---|---|
| Python 3.11+ | all labs | `python3 --version` |
| VS Code / Cursor | editor | Python extension installed |
| Git | version prompts, policies, tests | `git --version` |
| Ollama | run LLMs locally | `ollama --version` |

## Architecture

The lab environment is small, but it has the same shape as production. Your app talks to a model
server through one OpenAI-compatible client, so swapping the server later changes a URL, not your code.

```mermaid
flowchart LR
  subgraph DEV[Your laptop]
    ED[VS Code or Cursor] --> APP[Lab app<br/>Python venv]
    ENV[.env file<br/>not in git] -.->|config| APP
    GIT[(Git repo<br/>prompts, policies, tests)] -.->|versioned| APP
    APP --> CL[OpenAI-compatible client]
    CL -->|HTTP localhost:11434/v1| OL[Ollama server]
    OL --> M1[llama3.2<br/>chat model]
    OL --> M2[nomic-embed-text<br/>embeddings]
    OL --> M3[llama-guard3<br/>safety classifier]
  end
  CL -.->|same code, different base URL| PROD[Production endpoint<br/>OpenAI, Azure, Bedrock gateway, vLLM]
```

| Component | Responsibility | Why it sits here |
|---|---|---|
| Lab app (venv) | your code: prompts, guardrails, tests | an isolated virtual environment keeps package versions reproducible |
| `.env` | model names, URLs, keys | config stays out of code and out of git |
| Git repo | prompts, policies, attack tests | security rules are code: reviewed, versioned, diffable |
| OpenAI-compatible client | one API for every model server | provider-agnostic code makes switching vendors a config change |
| Ollama server | runs models locally on port 11434 | free, private, unlimited attack testing |
| Three models | chat, embeddings, safety classification | the same three roles exist in every production AI stack |

### Follow one request through it

1. You run a lab script in VS Code. Python loads settings (model name, base URL) from `.env`.
2. The script builds a message list (system prompt plus user message) and calls `client.chat.completions.create`.
3. The client sends an HTTP POST to `http://localhost:11434/v1/chat/completions`. Nothing leaves your machine.
4. Ollama loads `llama3.2` into memory (slow the first time, then cached), applies the model's chat template, and generates tokens.
5. The response comes back in the OpenAI format, so `r.choices[0].message.content` works unchanged.
6. In later labs the same flow calls `llama-guard3` to classify the input or output, and `nomic-embed-text` to embed documents for RAG.
7. In production, only `base_url`, `api_key`, and `model` change. The guardrail code you test here is the code you ship.

**The one idea to keep:** keep your security code **provider-agnostic**, so you can test it cheaply
on a local model and run the same code against the production model.

## Install Python, VS Code, and Git

Install the three base tools once. Each row ends with the command that proves it worked.

| Tool | macOS | Windows | Linux (Debian/Ubuntu) |
|---|---|---|---|
| Python 3.11+ | `brew install python@3.12` (Homebrew from [brew.sh](https://brew.sh)), or the installer from [python.org](https://www.python.org/downloads/) | `winget install Python.Python.3.12`, or the python.org installer with **"Add python.exe to PATH"** ticked | `sudo apt install python3 python3-venv python3-pip` |
| VS Code | `brew install --cask visual-studio-code`, or [code.visualstudio.com](https://code.visualstudio.com) | `winget install Microsoft.VisualStudioCode` | the `.deb` from code.visualstudio.com, or `sudo snap install code --classic` |
| Git | `xcode-select --install` (includes Git), or `brew install git` | `winget install Git.Git` | `sudo apt install git` |

Then verify, and set the identity Git puts on every commit (your policy and prompt changes become
audit evidence, so the name matters):

```bash
python3 --version          # Windows: py --version     → 3.11 or newer
git --version
code --version             # if "not found" on macOS: in VS Code, run "Shell Command: Install 'code' command in PATH"
git config --global user.name  "Your Name"
git config --global user.email "you@example.com"
```

In VS Code, install the **Python** extension (Microsoft). Open the project folder, run
**"Python: Select Interpreter"**, and choose the `.venv` you create below. The editor and the
terminal then use the same packages.

Common problems:
- **`python3` opens the Microsoft Store (Windows):** use `py` instead, or turn off the "App execution aliases" for Python in Settings.
- **`source .venv/bin/activate` fails on Windows:** the command there is `.venv\Scripts\activate` (PowerShell may first need `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`).
- **An old Python is found first:** check with `which python3` (macOS and Linux) or `where python` (Windows), and fix the PATH order.

## Ollama in 3 commands

```bash
# install: https://ollama.com/download  (macOS: brew install ollama)
ollama pull llama3.2          # small, fast general model (~2 GB)
ollama run llama3.2 "Say hi"  # sanity check; the server listens on http://localhost:11434
```

Useful extra models for this course:

```bash
ollama pull nomic-embed-text  # embeddings for RAG labs
ollama pull llama-guard3      # safety classifier model (input/output moderation)
```

## Project skeleton

```bash
mkdir secure-ai && cd secure-ai
python3 -m venv .venv && source .venv/bin/activate
pip install ollama openai "pydantic[email]" fastapi uvicorn pyyaml numpy
git init && printf ".venv/\n.env\n" > .gitignore
```

## Calling Ollama two ways

```python
# 1) Native client
import ollama
r = ollama.chat(model="llama3.2", messages=[{"role": "user", "content": "Hello"}])
print(r["message"]["content"])

# 2) OpenAI-compatible — the same code later works with OpenAI, Azure, vLLM, LiteLLM...
from openai import OpenAI
client = OpenAI(base_url="http://localhost:11434/v1", api_key="ollama")  # key is ignored locally
r = client.chat.completions.create(model="llama3.2", messages=[{"role": "user", "content": "Hello"}])
print(r.choices[0].message.content)
```

Prefer option 2 in labs: provider-agnostic code is itself a governance control (you can switch
providers after a vendor assessment without rewriting the app).

## FAANG deep-dive notes

**Typical design-review prompt:** *"Your team of 40 engineers builds LLM guardrails. Design the
development and test environment so that results on laptops predict results in production."*

**1. Clarify first:**
- Which production model(s)? Guardrail behavior depends heavily on the model, so local tests are only a proxy.
- Can test payloads (attacks, real documents) leave the company? This decides local models vs. a shared internal endpoint.
- How often do prompts, policies, and models change? That sets how often the full test suite must run.

**2. Back-of-envelope:**
- An attack suite of 500 prompts × 10 repetitions (outputs are probabilistic) = 5,000 calls per run.
- At about 2 seconds per call on a laptop model, that is about 10,000 seconds, nearly 3 hours. Too slow for every commit.
- Split it: a 50-prompt smoke suite on every commit (about 2 minutes with parallel calls), and the full suite nightly on a shared GPU endpoint.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Test model | local small model | production model | develop on local, **gate releases on production** |
| Test payloads | synthetic attacks | real incident samples | both; real samples must be redacted and access-controlled |
| Client | provider SDK | OpenAI-compatible client | compatible client unless you need a provider-only feature |
| Determinism | temperature 0 | production temperature | run with production settings, repeat N times, report rates |

**4. Follow-up questions with crisp answers:**
- *Why not test only against the production API?* It costs money per call, provider filters can hide your own guardrail's gaps, and test payloads leave your machine. Use it for release gates, not for every experiment.
- *A defense works on llama3.2 but fails in production. Why?* Different models follow and resist instructions differently, and production may use different temperature or system prompts. That's why the final gate runs on the production model.
- *Where do API keys live in development?* In `.env` files that are git-ignored, or better, pulled from a secret manager at runtime. Never in code, notebooks, or prompts.
- *How do you make results reproducible?* Pin model versions (an Ollama model tag or a provider's dated model ID), pin package versions, version prompts and policies in git, and log the exact versions with every test run.
- *Why put prompts and policies in git?* Every change is reviewed, can be diffed, and can be rolled back, and the history becomes audit evidence (module 14).
- *Should engineers use public chatbots for this work?* No. Pasting attack research or internal documents into unmanaged tools is shadow AI and a data-leak risk (module 12). Provide an approved internal endpoint instead.

**Debug this:** *"Nightly attack-suite success rate jumped from 2% to 15% with no code change."*
1. Check model versions first. An unpinned tag such as `llama3.2:latest` may have pulled a new build.
2. Check generation settings in the test config (temperature, max tokens).
3. Compare the per-family breakdown. A jump in one family points to one detector; a jump across all families points to the model or the environment.
4. Fix: pin the model digest, and record model plus prompt plus policy versions in every test report.

Lesson: **an unpinned dependency is an unreviewed change**, and that includes models.

**5. Senior vs. staff:** a senior engineer sets up a working local environment; a staff engineer designs
the environment so that local results are reproducible and predictive, with release gates on the real model.

**Red flags:** secrets in notebooks, unpinned models, attack tests only on a local model, and no record of which versions produced a result.
