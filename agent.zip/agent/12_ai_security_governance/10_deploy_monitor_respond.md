# 10 — Deploying, Monitoring, and Incident Response

## Deploying secure AI applications — checklist

| Area | Control | Example |
|---|---|---|
| Secrets | secret manager, never in images/prompts | `OPENAI_API_KEY` from AWS Secrets Manager |
| Identity | per-user auth to the app; workload identity to cloud | OIDC login; IRSA role for Bedrock |
| Network | egress allow-list | only `api.openai.com`, internal APIs |
| Container | non-root, read-only FS, minimal image | see Dockerfile below |
| Limits | rate limits, token budgets, timeouts | 60 req/min/user; 20k tokens/request |
| Kill switches | feature flags per tool / per model | disable `send_email` in seconds |
| Config | prompts & policies versioned in git | policy change = reviewed PR |

## Architecture: run, watch, respond

Deployment, monitoring, and incident response form one loop. The app runs in a locked-down
container, everything it does produces signals, signals become alerts, and responders act through
pre-built switches.

```mermaid
flowchart LR
  subgraph RUN[Run]
    C[App container<br/>non-root, read-only]
    SM[Secret manager] -->|injected at start| C
    C --> EG[Egress proxy<br/>allow-listed domains]
    EG --> P[Model provider<br/>and APIs]
  end
  subgraph WATCH[Watch]
    C -->|logs and metrics| PIPE[Log pipeline<br/>redaction]
    PIPE --> MET[(Metrics store)]
    PIPE --> SIEM[(Security log<br/>SIEM)]
    MET --> AL{Alert rules}
    SIEM --> AL
  end
  subgraph RESPOND[Respond]
    AL -->|page| OC[On-call responder]
    OC --> FF[Feature flags<br/>kill switches]
    OC --> RB[Runbook]
  end
  FF -->|disable tool or source| C
```

| Component | Responsibility | Why it sits here |
|---|---|---|
| Hardened container | runs the app with minimum privileges | limits what an exploited app can do on the host |
| Secret manager | supplies API keys at runtime | keys never live in images, git, or prompts |
| Egress proxy | allows only approved destinations | stops exfiltration to attacker domains even if the app is fooled |
| Log pipeline with redaction | collects events, strips PII | you need evidence without creating a privacy breach |
| Metrics and SIEM (security information and event management) | stores time series and security events | metrics for rates and spikes, SIEM for investigation |
| Alert rules | turn anomalies into pages | thresholds come from baselines, not guesses |
| Feature flags | disable a tool, source, or model in seconds | containment must not wait for a code deploy |

### Follow one incident through it

1. 06:10: the output-redaction rate for HelpBot rises to 4× its 7-day baseline. An alert rule fires and pages the on-call responder.
2. The responder opens the dashboard. The redactions are internal prices, all from answers citing the `supplier-uploads` source.
3. Containment: the responder flips the feature flag that disables the `supplier-uploads` retrieval source. The running pods pick it up within seconds, without a deploy.
4. The redaction rate drops back to baseline within minutes, which confirms the containment worked.
5. Investigation in the SIEM: the logged chunk IDs point to one uploaded PDF and the account that uploaded it.
6. Eradication: delete the PDF, fix the classification gap, and add the PDF to the attack test suite. Then re-enable the source behind a canary.

**The one idea to keep:** design the **response switches before you need them**. An incident is
contained by flags and runbooks prepared in advance, not by code written at 6 a.m.

## Package with Docker

```dockerfile
FROM python:3.12-slim
RUN useradd --uid 10001 --create-home app
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY gateway/ gateway/
COPY policies/ policies/
USER 10001
EXPOSE 8000
CMD ["uvicorn", "gateway.api:app", "--host", "0.0.0.0", "--port", "8000"]
```

```bash
docker build -t secure-ai-assistant:1.0 .
docker run --rm -p 8000:8000 --env-file .env --read-only --tmpfs /tmp \
  --cap-drop ALL --security-opt no-new-privileges secure-ai-assistant:1.0
```
Using Ollama on the host from the container: `OLLAMA_BASE_URL=http://host.docker.internal:11434/v1`.
Production on Kubernetes: `11_kubernetes/`.

## Monitoring and logging

### What to log (per request)
```json
{
  "ts": "2026-11-12T06:30:12Z", "request_id": "req_91a", "user_id": "u_123", "app": "helpbot",
  "model": "gpt-4o-mini-2024-07-18", "prompt_version": "v7", "policy_version": "2026-11-01",
  "input_risk": 0.72, "signals": ["roleplay", "refusal_suppression"],
  "decisions": {"input": "allow", "tool:send_email": "require_approval", "output": "redact"},
  "tools_called": ["search_kb"], "tokens_in": 1840, "tokens_out": 220, "latency_ms": 2310
}
```
**Don't** log raw prompts/answers by default if they contain PII; store hashes, or redacted text
with restricted access and short retention.

### What to alert on
| Signal | Example threshold | Likely meaning |
|---|---|---|
| guardrail block rate | 3× 7-day baseline | attack campaign or broken filter |
| high-risk prompts from one user | > 10 / hour | someone probing |
| tool approvals rejected | spike | agent being steered |
| output redactions | spike | data leaking into answers |
| tokens per user | > 5× normal | abuse / runaway agent |
| new external domains in tool args | any | exfiltration attempt |

## Incident response for AI systems

### Playbook: prompt-injection-driven data exposure
| Phase | Actions | Example |
|---|---|---|
| **Detect** | alert fires / user report | redactions spike on HelpBot at 06:10 |
| **Triage** | severity, scope, is it ongoing? | external users saw internal prices → Sev-2 |
| **Contain** | kill switch, block source, tighten policy | disable RAG source `supplier-uploads`; block user |
| **Eradicate** | remove poisoned content, fix the gap | delete poisoned PDF; add hidden-text stripping |
| **Recover** | re-enable gradually, monitor | canary 10% → 100% |
| **Learn** | post-incident review, new tests | add the PDF to the attack test suite; update risk register |

Things specific to AI incidents:
- **Reproducibility is hard** (non-determinism) → you need the logged context (retrieved chunks, model, prompt version).
- The fix is often **data** (remove a document, delete memories), not code.
- Notify data owners if model output exposed their data; check privacy-breach notification rules.
- Every incident becomes a **regression test**.

Governance view of incidents (severity matrix, KPIs, evidence): module 15.

## FAANG deep-dive notes

**Typical system-design prompt:** *"Design monitoring and incident response for 20 production AI
apps serving 3,000 requests per second in total. The security team has 2 on-call responders."*

**1. Clarify first:**
- Which apps can act (tools, payments) and which only answer? Response time targets differ by impact.
- What may be logged? Prompts can contain personal data, so the privacy rules shape the whole logging design.
- What does "contained" mean for each app: disable a tool, a data source, a model, or the whole app? Each needs a pre-built switch.
- Who has the authority to pull a kill switch at 3 a.m.? Decide in advance, not during the incident.

**2. Back-of-envelope:**
- Log volume: 3,000 requests per second × about 2 KB per structured event = 6 MB per second, about 518 GB per day.
- Retention: 90 days hot is about 47 TB. Keeping signals and decisions (about 500 bytes) instead of full events cuts that to about 12 TB, with raw redacted text kept only for flagged events.
- Alert load: 2 responders can handle maybe 5–10 actionable pages per day. With 20 apps × 6 alert types = 120 alert rules, each rule must fire rarely and mean something, or responders start ignoring pages.
- Containment target: a feature-flag flip propagating in under 1 minute, compared with a typical 20–40 minute build-and-deploy cycle.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Logging content | full prompts and answers | signals plus redacted samples | signals by default; raw text only for flagged events, with restricted access |
| Alert thresholds | static numbers | relative to a rolling baseline | baselines, since traffic and attack levels shift |
| Containment | roll back the deploy | feature flags per tool and source | flags first, rollback second |
| Egress | open internet | allow-listed proxy | allow-list; exfiltration needs an outbound path |
| Kill-switch scope | whole app only | per tool, source, model, and app | fine-grained, so containment doesn't take down the whole product |

**4. Follow-up questions with crisp answers:**
- *Why are AI incidents harder to reproduce?* Outputs are probabilistic and depend on retrieved content and model version. Without logged context (chunk IDs, model, prompt and policy versions) you can't replay them.
- *Why is the fix often data, not code?* Many incidents come from a poisoned document, a bad memory, or a stale permission. Removing or fixing data is the remediation.
- *What should a non-root, read-only container stop?* An attacker who gets code execution through a vulnerable dependency can't modify the app, install tools, or easily escalate to the host.
- *Why an egress proxy if the app already validates URLs?* Defense in depth. The proxy enforces the allow-list even if a validation bug or an unknown code path tries to call out.
- *How do you alert on prompt-injection campaigns?* Watch for spikes in high-risk input scores, blocked tool calls, and new external domains in tool arguments, grouped by user, IP address, and source document.
- *What belongs in an AI incident runbook?* Severity criteria, the available switches and who may use them, log queries for scoping, communication templates, data-owner notification steps, and the post-incident test requirement.
- *How do you test incident response?* Game days: inject a synthetic poisoned document in staging (or a safe canary in production) and measure time to detect and time to contain.
- *When do you notify users or regulators?* When personal data was exposed or a serious incident occurred under applicable rules. Privacy and legal own the decision, so the runbook must page them early.
- *How do you protect the logs themselves?* Restricted access, encryption, tamper-evident storage for audit events, and retention limits so logs don't become a data-breach source.
- *What's the first metric to dashboard for a new AI app?* Guardrail decisions by stage over time (allow, block, redact, approve). It shows both attacks and broken filters.

**Debug this:** *"During an incident, the responder flipped the kill switch for `send_email`, but the audit log shows emails still being sent for 20 more minutes."*
1. Check the flag service. The flip happened at 06:14 and propagated to the flag store immediately.
2. Check the pods. The app caches flag values for 30 minutes to reduce flag-service calls.
3. Check the agent loop. Long-running agent tasks read the flag once, at task start, not before each step.
4. Fix: re-check flags before every tool execution, use push-based flag updates (or a short cache of about 10 seconds), and make the tool gate itself check the flag.
5. Prevention: a monthly kill-switch drill that measures time from flip to the last blocked call, with a target under 60 seconds.

Lesson: **an untested kill switch is a hope, not a control.** Measure its propagation time.

**5. Senior vs. staff:**
- Senior: hardened containers, structured logging, alerts on key metrics, and a runbook.
- Staff: designs logging around privacy and cost, sizes alert load to the team, builds fine-grained switches with measured propagation, and runs game days that prove detection and containment times.

**Red flags:** full prompts logged forever; no egress control; containment that requires a deploy; alert rules nobody has tuned; kill switches never tested.
