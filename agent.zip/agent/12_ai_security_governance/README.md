# AI Security & Governance — Build, Attack, Secure, Govern

A concept-first course companion. Each module explains **why** a risk exists, **how** attackers
exploit it, and **which controls** stop it — with just enough code to make ideas concrete.

> Mindset for the whole course: **the LLM is not a security boundary.** It is a powerful,
> persuadable, non-deterministic component. Security comes from the system you build around it.

## What you'll build

**Part A** builds one assistant and then attacks and hardens it, layer by layer. Each module adds
the next capability, breaks it, and fixes it:

| Stage | You build | You attack it with | You end with |
|---|---|---|---|
| 02 | a chat assistant on a local model | secret extraction, long inputs | a list of eight weaknesses |
| 03–04 | input validation, a guard classifier, a prompt risk analyzer with tiers | 7 injection patterns, 11 jailbreak techniques, a harness that measures success rates | `guarded_chat()` and `filtered_chat()` with before and after numbers |
| 05 | a document-based RAG assistant | a poisoned PDF with hidden white text | permission-filtered retrieval, sanitizing, isolation |
| 06 | a tool-calling assistant (weather, calculator, email) | parameter injection and unauthorized calls | schemas, authorization, approvals |
| 07 | long-term memory | memory poisoning | validated, user-approved, expiring memory |
| 08 | a planner agent that books travel | excessive agency, forbidden tool chains | plan validation, budgets, human approval |
| 09–10 | **one AI security gateway** that every layer plugs into, packaged with Docker | the full attack library | a deployed, monitored pipeline with an incident runbook |

**Part B** builds the governance platform around it, using one fictional company (Acme Corp) from
start to finish:

| Stage | You build | It answers |
|---|---|---|
| 11 | operating model, RACI, governance data model | "who decides, and where is the evidence kept?" |
| 12 | AI inventory and usage telemetry | "which AI systems do we run, who owns them, and what do they cost?" |
| 13 | cards, impact assessments, an approval workflow | "was this system approved, by whom, and with which conditions?" |
| 14 | a control register, policy-as-code, control tests | "do our controls actually work?" |
| 15 | an incident register, a tamper-evident audit trail, KPI and KRI reports | "what went wrong, and can we prove what we did about it?" |

## Roadmap

```
 PART A — AI SECURITY (build → attack → defend, layer by layer)

  01 Foundations ─► 02 First chat app ─► 03 Prompt injection ─► 04 Jailbreaks
                                                                     │
  08 Agents ◄─ 07 Memory ◄─ 06 Tool calling ◄─ 05 RAG security ◄─────┘
     │
     └─► 09 Security gateway (all layers integrated) ─► 10 Deploy, monitor, respond

 PART B — AI GOVERNANCE (make security repeatable, measurable, auditable)

  11 Governance foundations ─► 12 Inventory & usage intelligence ─► 13 Assessments & approvals
                                                                            │
                          15 Incidents, audit & reporting ◄─ 14 Controls & policy-as-code
                                     │
                                     └─► 16 Wrap-up and next steps
```

| # | Module | You will understand |
|---|---|---|
| 00 | [Setup](00_setup.md) | Python, VS Code, Git, Ollama for local models |
| 01 | [AI security foundations](01_foundations.md) | why AI security differs, threat landscape, OWASP LLM Top 10, security layers |
| 02 | [Your first chat assistant](02_first_chat_assistant.md) | a minimal assistant and why it is insecure by default |
| 03 | [Prompt injection](03_prompt_injection.md) | direct injection, prompt hierarchy, validation, basic guardrails, testing |
| 04 | [Jailbreaks](04_jailbreaks.md) | role-play, encoding, multi-turn attacks, risk analyzer and scoring |
| 05 | [RAG security](05_rag_security.md) | indirect injection, document poisoning, trust boundaries, isolation, enforcement |
| 06 | [Tool-calling security](06_tool_security.md) | parameter injection, unauthorized actions, validation, permissions, approvals |
| 07 | [Memory security](07_memory_security.md) | memory poisoning, persistent context risk, validated and approved memory |
| 08 | [Agent security](08_agent_security.md) | planner agents, excessive agency, HITL, permission and decision controls |
| 09 | [AI security gateway](09_security_gateway.md) | layered architecture, policy engine, risk scoring, full pipeline |
| 10 | [Deploy, monitor, respond](10_deploy_monitor_respond.md) | Docker, logging, monitoring, incident response |
| 11 | [Governance foundations](11_governance_foundations.md) | operating model, frameworks, governance data architecture |
| 12 | [Inventory & usage intelligence](12_inventory_usage.md) | AI inventory, telemetry, cost allocation, ownership |
| 13 | [Assessments & approvals](13_assessments_approvals.md) | model/system/agent cards, impact assessments, approvals, exceptions |
| 14 | [Controls & policy-as-code](14_controls_policy_as_code.md) | preventive/detective/corrective controls, guardrail metrics, control testing |
| 15 | [Incidents, audit & reporting](15_incidents_audit_reporting.md) | incident management, audit trails, KPIs/KRIs, board and regulator evidence |
| 16 | [Wrap-up and next steps](16_wrap_up.md) | what to remember, a self-check, and where to go from here |
| — | [Attack test library](attack_test_library.md) | categorized test prompts for verifying your defenses |
| — | [Glossary](glossary.md) | every term in one place |
| — | [Coverage map](COVERAGE.md) | every lecture of the course outline, mapped to its file and section |
| — | [Coverage map](COVERAGE.md) | every lecture of the course outline, mapped to its file and section |

## How this connects to the rest of the repo

| Topic here | Deeper implementation elsewhere |
|---|---|
| Guardrails | `06_guardrails/`, `09_aws_bedrock/04_bedrock_guardrails.py` |
| RAG basics | `04_rag/` |
| Agents & tools | `01_foundations/03_tool_calling.py`, `02_single_agent/`, `03_multi_agent/` |
| Memory | `05_memory/` |
| Permission-aware retrieval | `apps/secure_doc_search/` |
| Evals & red-team tests | `07_evaluation/` |
| Monitoring, deployment | `08_production/`, `10_llmops_pipeline/`, `11_kubernetes/` |

## The five laws this course repeats

1. **Untrusted in, untrusted out.** Anything the model reads (user text, documents, web pages,
   tool results, memories) can carry instructions. Anything it writes can be wrong or malicious.
2. **Authorization lives in code, not prompts.** The model may *request* an action; deterministic
   code decides whether it is allowed for *this user*.
3. **Least privilege, least data, least autonomy.** Give only the tools, data, and freedom the task needs.
4. **Defense in depth.** No single filter is enough; layer cheap and expensive checks at every boundary.
5. **If it isn't logged, it didn't happen.** Governance runs on evidence.
