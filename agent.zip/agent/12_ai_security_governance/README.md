# AI Security & Governance — Build, Attack, Secure, Govern

A concept-first course companion. Each module explains **why** a risk exists, **how** attackers
exploit it, and **which controls** stop it — with just enough code to make ideas concrete.

> Mindset for the whole course: **the LLM is not a security boundary.** It is a powerful,
> persuadable, non-deterministic component. Security comes from the system you build around it.

## Roadmap

```
 PART A — AI SECURITY (build → attack → defend, layer by layer)

  01 Foundations ─► 02 First chat app ─► 03 Prompt injection ─► 04 Jailbreaks
                                                                     │
  08 Agents ◄─ 07 Memory ◄─ 06 Tool calling ◄─ 05 RAG security ◄─────┘
     │
     └─► 09 Security gateway (all layers integrated) ─► 10 Deploy, monitor, respond

 PART B — AI GOVERNANCE (make security repeatable, measurable, auditable)

  11 Governance foundations ─► 12 Inventory & usage intelligence ─► 13 Assessments & approvals
                                                                            │
                          15 Incidents, audit & reporting ◄─ 14 Controls & policy-as-code
```

| # | Module | You will understand |
|---|---|---|
| 00 | [Setup](00_setup.md) | Python, VS Code, Git, Ollama for local models |
| 01 | [AI security foundations](01_foundations.md) | why AI security differs, threat landscape, OWASP LLM Top 10, security layers |
| 02 | [Your first chat assistant](02_first_chat_assistant.md) | a minimal assistant and why it is insecure by default |
| 03 | [Prompt injection](03_prompt_injection.md) | direct injection, prompt hierarchy, validation, basic guardrails, testing |
| 04 | [Jailbreaks](04_jailbreaks.md) | role-play, encoding, multi-turn attacks, risk analyzer and scoring |
| 05 | [RAG security](05_rag_security.md) | indirect injection, document poisoning, trust boundaries, isolation, enforcement |
| 06 | [Tool-calling security](06_tool_security.md) | parameter injection, unauthorized actions, validation, permissions, approvals |
| 07 | [Memory security](07_memory_security.md) | memory poisoning, persistent context risk, validated and approved memory |
| 08 | [Agent security](08_agent_security.md) | planner agents, excessive agency, HITL, permission and decision controls |
| 09 | [AI security gateway](09_security_gateway.md) | layered architecture, policy engine, risk scoring, full pipeline |
| 10 | [Deploy, monitor, respond](10_deploy_monitor_respond.md) | Docker, logging, monitoring, incident response |
| 11 | [Governance foundations](11_governance_foundations.md) | operating model, frameworks, governance data architecture |
| 12 | [Inventory & usage intelligence](12_inventory_usage.md) | AI inventory, telemetry, cost allocation, ownership |
| 13 | [Assessments & approvals](13_assessments_approvals.md) | model/system/agent cards, impact assessments, approvals, exceptions |
| 14 | [Controls & policy-as-code](14_controls_policy_as_code.md) | preventive/detective/corrective controls, guardrail metrics, control testing |
| 15 | [Incidents, audit & reporting](15_incidents_audit_reporting.md) | incident management, audit trails, KPIs/KRIs, board and regulator evidence |
| — | [Attack test library](attack_test_library.md) | categorized test prompts for verifying your defenses |
| — | [Glossary](glossary.md) | every term in one place |

## How this connects to the rest of the repo

| Topic here | Deeper implementation elsewhere |
|---|---|
| Guardrails | `06_guardrails/`, `09_aws_bedrock/04_bedrock_guardrails.py` |
| RAG basics | `04_rag/` |
| Agents & tools | `01_foundations/03_tool_calling.py`, `02_single_agent/`, `03_multi_agent/` |
| Memory | `05_memory/` |
| Permission-aware retrieval | `apps/secure_doc_search/` |
| Evals & red-team tests | `07_evaluation/` |
| Monitoring, deployment | `08_production/`, `10_llmops_pipeline/`, `11_kubernetes/` |

## The five laws this course repeats

1. **Untrusted in, untrusted out.** Anything the model reads (user text, documents, web pages,
   tool results, memories) can carry instructions. Anything it writes can be wrong or malicious.
2. **Authorization lives in code, not prompts.** The model may *request* an action; deterministic
   code decides whether it is allowed for *this user*.
3. **Least privilege, least data, least autonomy.** Give only the tools, data, and freedom the task needs.
4. **Defense in depth.** No single filter is enough; layer cheap and expensive checks at every boundary.
5. **If it isn't logged, it didn't happen.** Governance runs on evidence.
