# 13 — Documentation, Assessments, Approvals, and Exceptions

## Architecture: the assessment and approval pipeline

Before a system goes live, governance needs three things: **documentation** (cards), a **risk
judgement** (assessment), and an **accountable decision** (approval). After go-live, it needs a way
to notice when those decisions no longer match reality.

```mermaid
flowchart LR
  IN[Intake form] --> CARD[Cards<br/>system, agent,<br/>dataset, vendor]
  CARD --> AS[Impact assessment<br/>questions, score, tier]
  AS --> REQ[Required evidence<br/>by tier]
  CI[(Evidence store<br/>evals, red team, DPIA)] --> REQ
  REQ --> AP{Approval workflow<br/>SoD enforced}
  AP -->|changes requested| CARD
  AP -->|approved with<br/>conditions, expiry| REG[(Registry status live)]
  AP -->|cannot meet a control| EXC[Exception register<br/>owner, expiry]
  EXC --> REG
  TEL[Gateway telemetry] --> DRIFT{Material change<br/>or expiry}
  REG --> DRIFT
  DRIFT -->|yes| AS
```

| Component | Responsibility | Why it sits here |
|---|---|---|
| Cards | describe what the system is, does, uses, and risks | reviewers can't assess what isn't written down |
| Impact assessment | turns answers into a score and a risk tier | consistent questions make tiers comparable across teams |
| Required evidence by tier | lists what must exist before approval | high tier needs red-team and privacy evidence; low tier doesn't |
| Evidence store | holds eval runs, red-team reports, DPIAs (data protection impact assessments) | approvals link to evidence instead of trusting claims |
| Approval workflow | records who approved, with which conditions, until when | accountability, with separation of duties enforced in code |
| Exception register | records approved deviations with expiry | honest, time-limited gaps instead of silent ones |
| Drift detection | spots material changes and expiry | approval is a snapshot; systems keep changing |

### Follow one case through it: InvoiceAgent v1.2

1. Raj (system owner) submits the intake form and the agent card shown below.
2. The impact assessment scores 14 out of 18, which is **high** tier.
3. The high tier requires: a security review, red-team evidence, a DPIA if personal data is involved (supplier contacts are personal data), and council approval.
4. The evidence store already holds the CI red-team run (`redteam-report-88`). The DPO (data protection officer) uploads DPIA `assess-551`.
5. Raj tries to approve his own system. The workflow refuses, because the submitter can't approve (separation of duties).
6. The CFO and CISO approve with conditions: a €10,000 payment limit and monthly audits of 50 payments, valid until 2027-05-01.
7. In March the gateway reports InvoiceAgent using a new model version. Drift detection marks it a material change and reopens the assessment.

**The one idea to keep:** **an approval is a dated decision with conditions, not a permanent
permission.** Build the machinery that notices when it no longer applies.

## Cards: standard documentation

| Card | Describes | Key fields |
|---|---|---|
| **Model card** | one model | intended use, training data summary, evaluation results, limitations, licence |
| **System card** | the whole AI application | purpose, users, architecture, models, data, controls, human oversight, known risks |
| **Agent card** | an agent | goals, tools + permission level, autonomy level, approval points, budgets, kill switch |
| **Dataset card** | data | source, owner, sensitivity, consent/legal basis, retention, known biases |
| **Vendor assessment** | external AI provider | data retention, training on your data?, region, certifications, sub-processors, SLA |

### Example agent card — InvoiceAgent
```yaml
agent: InvoiceAgent v1.2
goal: match supplier invoices to purchase orders and schedule approved payments
autonomy: semi-autonomous (human approves every payment)
tools:
  - {name: read_invoice,     impact: read,   scope: invoices inbox}
  - {name: lookup_po,        impact: read,   scope: ERP read-only}
  - {name: schedule_payment, impact: financial, limit: "€10,000", approval: finance_approver}
budgets: {max_steps: 12, max_tokens: 30000, timeout_s: 120}
untrusted_inputs: [invoice PDFs, supplier emails]
known_risks: [bank-detail substitution via injected invoice text, duplicate payment]
controls: [CTL-007 bank-details-must-match-vendor-master, CTL-011 payment-approval, CTL-014 step budget]
kill_switch: feature flag invoice_agent.enabled
```

### Example vendor assessment questions
- Is our data used to train the provider's models? (Required answer: **no**.)
- Retention of prompts/outputs? Where is data processed (region)?
- SOC 2 / ISO 27001 / ISO 42001? Abuse-monitoring access by humans?
- Model change notification and versioning policy?

## AI impact assessments

Structured questions → risk tier → required controls.

| Question | InvoiceAgent answer | Score |
|---|---|---|
| Can it take actions affecting money, access, or people? | yes — payments | 3 |
| Data sensitivity | confidential (bank details) | 2 |
| Affected people | suppliers (external) | 2 |
| Autonomy | human approves payments | 1 |
| Exposure to untrusted input | invoices from anyone | 3 |
| Reversibility of errors | payments hard to reverse | 3 |
| **Total** | **14 / 18** | **High** |

Tier → requirements:
| Tier | Requires |
|---|---|
| Low | registration, owner, basic guardrails |
| Medium | + security review, eval evidence, monitoring |
| High | + red-team, DPIA (if personal data), council approval, quarterly review |
| Prohibited | not built (e.g. EU AI Act prohibited practices like social scoring) |

## AI approval workflows

```
 proposed ─► intake review ─► assessments (security, privacy, legal) ─► council decision
                                    │                                       │
                                    └── changes requested ◄─────────────────┤
                                                                            ├─► approved (with conditions, expiry)
                                                                            └─► rejected
 approved ─► live ─► (material change OR annual review) ─► re-assessment
```
Material changes that trigger re-approval: new model/vendor, new tool with write impact, new data
category, new user population (e.g. internal → public), autonomy increase.

Example approval record:
```json
{"system_id":"sys-invoice","decision":"approved_with_conditions","approvers":["cfo@acme.com","ciso@acme.com"],
 "conditions":["payment limit €10k","monthly sample audit of 50 payments"],
 "valid_until":"2027-05-01","evidence":["assess-551","redteam-report-88","eval-run-2026-10-28"]}
```

## Exception management

When a system can't meet a control yet, you **record an exception** instead of silently ignoring it.

```yaml
id: EXC-019
system: ContractLens
control: CTL-003 "Only approved model versions"
reason: new Llama version needed for 128k context; assessment scheduled
compensating_controls: [output human review by legal, no external users]
risk_owner: head-of-legal@acme.com
approved_by: ai-gov-office@acme.com
expires: 2026-12-15          # exceptions MUST expire
status: active
```
Rules: every exception has an owner, compensating controls, and an expiry date; expired exceptions
show up red on the dashboard and on the KRI report.

## Accountability and separation of duties (SoD)

| Must NOT be the same person | Why |
|---|---|
| builder of the system ↔ its approver | self-approval |
| person who changes guardrail policy ↔ person who approves the change | silent weakening |
| requester of an exception ↔ approver of it | self-granted exceptions |
| agent payment initiator (the agent/requester) ↔ payment approver | fraud |

Enforce in tooling, not by trust:
```python
def approve(record, approver):
    if approver == record.submitted_by or approver in record.system.builders:
        raise PermissionError("separation of duties: builders cannot approve their own system")
```

## Project: AI assessment and approval workflow

Build a small service (FastAPI + SQLite) with:
1. `POST /systems/{id}/assessments` — questionnaire answers → computed tier.
2. `POST /systems/{id}/approvals` — enforces SoD and required evidence per tier.
3. `POST /exceptions` — requires expiry + compensating controls.
4. A nightly job: flag expired approvals/exceptions and systems live without approval.

Test examples:
| Case | Expected |
|---|---|
| builder approves own system | 403 |
| high-tier approval without red-team evidence | 422 |
| exception without expiry | 422 |
| approval expired yesterday | system flagged "review overdue" |

## FAANG deep-dive notes

**Typical design-review prompt:** *"Design the AI assessment and approval process for a company that
launches about 60 new AI systems per quarter. Today median approval takes 7 weeks, and teams are bypassing it."*

**1. Clarify first:**
- Where does the time go: waiting in queues, back-and-forth on missing information, or actual review? Each needs a different fix.
- What share of submissions are low risk? If most are, a self-service path cuts time most.
- Who must approve each tier, and are those people available? A CFO who approves monthly creates a monthly bottleneck.
- What do teams get for compliance? If the process only adds delay, people will route around it.

**2. Back-of-envelope:**
- Volume: 60 systems per quarter is about 20 per month.
- With the tier mix of 70% low, 25% medium, and 5% high: 14 low, 5 medium, and 1 high per month.
- If low-tier reviews are automated (questionnaire plus telemetry checks, about 1 hour of human time), human effort per month = 14 × 1 + 5 × 8 + 1 × 40 = 14 + 40 + 40 = **94 hours**, under one full-time reviewer.
- Queue time: if one council meets every 2 weeks and handles all medium and high systems, the average wait is about 1 week before review even starts. Delegate medium approvals to the governance office and keep the council for high only.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Assessment form | long questionnaire for all | short triage, then tier-specific depth | triage in 10 questions; ask more only when the tier needs it |
| Approvers | council for everything | delegated by tier | delegate low and medium; council for high and exceptions |
| Evidence | documents attached by teams | links to CI and gateway outputs | link to system-generated evidence; documents go stale |
| Approval validity | permanent | expiry plus change triggers | expiry plus material-change triggers |
| Exceptions | informal, by email | register with owner, compensating controls, and expiry | always the register; every exception must expire |

**4. Follow-up questions with crisp answers:**
- *What's the difference between a model card and a system card?* A model card describes one model (training, evals, limits). A system card describes the whole application around it (users, data, tools, controls, oversight), which is what governance approves.
- *Why does an agent card list tools with impact classes?* Agent risk comes mostly from what it can *do*. The tool list with limits is the core of the assessment.
- *What makes a vendor assessment useful rather than box-ticking?* Questions tied to your risks (training on your data, retention, region, model-change notice) with contract terms that enforce the answers.
- *How do you score impact consistently across teams?* Fixed questions with defined answer levels and examples, calibrated by reviewing a few sample systems together.
- *Why must exceptions expire?* Without expiry, "temporary" becomes permanent, and the control silently stops existing for that system.
- *What does separation of duties prevent here?* Self-approval, silent weakening of rules, and self-granted exceptions. Enforce it in the workflow tool, not by trust.
- *How do you detect material change automatically?* Compare live telemetry (models, tools, data sources, user populations) against the approved configuration in the registry.
- *What happens when a live system's approval expires?* It's flagged, the owner gets a deadline, and if it lapses, escalation to the risk owner and possibly suspension by feature flag.
- *How do you keep the process from becoming a bottleneck?* Measure queue time per stage, publish it, automate the low tier, and set service levels per tier (for example, low in 2 days, medium in 2 weeks).
- *How do you handle a system that is urgent for the business?* An expedited path with the same evidence but priority scheduling, or a time-limited exception with compensating controls. Never a skipped review.

**Debug this:** *"Approval queue time tripled from 2 to 6 weeks this quarter. Submissions rose only 20%."*
1. Measure time per stage. Most of the increase is in "waiting for evidence", not in review.
2. Inspect the stuck cases. 70% are waiting for a DPIA from the privacy team.
3. Mechanism: a new rule made DPIAs required for **all** medium-tier systems, including those processing no personal data, and the privacy team's capacity didn't change.
4. Fix: require the DPIA only when the assessment says personal data is processed, add a 3-question privacy triage, and pre-fill DPIAs from the system card.
5. Prevention: model the reviewer workload before changing tier requirements, and track queue time per stage as a governance KPI.

Lesson: **every new requirement has a capacity cost.** Measure the queue like a production system.

**5. Senior vs. staff:**
- Senior: builds the cards, assessment scoring, approval workflow with SoD, and exception register.
- Staff: does the workload math, tiers the process to cut queue time, links approvals to system-generated evidence, and adds automatic drift detection so approvals stay true after launch.

**Red flags:** one long questionnaire for everything; permanent approvals; exceptions without expiry; approvals that link to no evidence; a process that teams bypass.
