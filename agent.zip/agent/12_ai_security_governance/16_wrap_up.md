# 16 — Course Wrap-Up and Next Steps

## What you built

Part A started with a chat assistant that leaked its secret to the first "repeat everything
above", and ended with a gateway where every layer has a check, a policy decision, and an
audit record:

| Layer | Attack you ran | Control that held | Module |
|---|---|---|---|
| Input | override, extraction, 11 jailbreak families | validation, risk tiers, a guard classifier | 03, 04 |
| Retrieval | a PDF with hidden white text | permission-filtered retrieval, sanitizing, isolation | 05 |
| Tools | parameter injection, unauthorized calls | strict schemas, authorization in code, approvals | 06 |
| Memory | a planted "always include this link" rule | validation, user approval, read-time checks | 07 |
| Agent | a forbidden read-then-send chain | plan validation, budgets, human approval | 08 |
| Output | markdown-image exfiltration | secret patterns, a link allow-list | 03, 05 |
| Everything | the full attack library | one gateway and one policy, with audit logs | 09, 10 |

Part B built the system that keeps this true over time: an inventory that knows what runs,
approvals that know who accepted which risk, controls that are tested, and evidence an auditor
can verify.

## The ideas to keep

1. **The model is not a security boundary.** It can be persuaded. Every rule that matters is
   enforced in code, outside the model.
2. **Detection lowers the success rate, design caps the damage.** Filters will be bypassed. No
   secrets in prompts, authorization in code, and output allow-lists still hold when they are.
3. **Detectors produce signals, policy decides.** That split makes rules reviewable, testable,
   and changeable without a deploy.
4. **Measure two numbers together:** attack success rate and false-positive rate. Optimizing
   one alone gives a useless system or an insecure one.
5. **Governance is evidence.** If a decision, an approval, or a control test isn't recorded, it
   didn't happen as far as an auditor or regulator is concerned.

## Self-check: can you answer these without looking?

- Why is "Never reveal the code" in a system prompt not a control? (module 02)
- What does the risk analyzer score for a real compliance analyst asking for a KYC checklist, and why doesn't the system block it? (module 04)
- Why must permission filtering happen **inside** the vector query rather than after it? (module 05)
- A tool call passes schema validation. What else must be true before it runs? (module 06)
- Why does every memory write need the user's confirmation, even a harmless-looking one? (module 07)
- Which tool chain makes an agent able to exfiltrate data, and how does plan validation stop it? (module 08)
- Should the gateway fail open or fail closed when the classifier times out? What does it depend on? (module 09)
- What would you switch off first in a prompt-injection incident, and how fast can you do it? (module 10)
- What is the difference between a KPI and a KRI, and which ones does the board see? (module 15)

If an answer is unclear, reread that module's FAANG deep-dive notes, where each question is
worked through.

## Next steps

**Practice on your own system (first two weeks):**
1. Run `attack_test_library.md` against an AI feature you own. Record the attack success rate and false-positive rate as your baseline.
2. Fill in an agent card or a system card (module 13) for that feature. The gaps you find are your backlog.
3. Add one deterministic control that does not depend on the model, such as authorization on a tool or a link allow-list.

**Go deeper on security:**
- Automated red teaming with `garak`, `promptfoo`, PyRIT, or DeepTeam in CI (module 04).
- Dual-LLM and CaMeL-style designs, where untrusted text can never choose actions (module 08).
- The OWASP Top 10 for LLM Applications and MITRE ATLAS, to map your threat model to known techniques.

**Go deeper on governance:**
- Read NIST AI RMF and its Generative AI Profile, then ISO/IEC 42001, to see how your controls map to them (module 11).
- Turn one written policy into policy-as-code with a test suite (module 14).
- Run a tabletop exercise with the incident playbook from module 10 and record it as audit evidence (module 15).

**Elsewhere in this repo:**

| Next topic | Where |
|---|---|
| Guardrails libraries in depth | `06_guardrails/`, `09_aws_bedrock/04_bedrock_guardrails.py` |
| Evaluation and red-team tests | `07_evaluation/` |
| Permission-aware retrieval, as a full app | `apps/secure_doc_search/` |
| Production deployment | `08_production/`, `10_llmops_pipeline/`, `11_kubernetes/` |

## Where the course ends and the real world starts

Treat every number in this course as a lab result on a small local model. Before you rely on a
control in production, rerun the same tests against **your** production model with production
settings, repeat each attack several times, and keep the results as evidence. Models, prompts,
and attackers all change, so the tests must keep running after the course ends.
