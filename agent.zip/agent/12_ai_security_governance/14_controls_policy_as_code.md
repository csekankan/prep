# 14 — Controls, Guardrails, Policy-as-Code

## Preventive, detective, and corrective controls

| Type | Purpose | AI examples |
|---|---|---|
| **Preventive** | stop it happening | input injection filter, tool allow-list, payment approval, RAG permission filter |
| **Detective** | notice it happened | guardrail-event alerts, anomaly on tokens, audit-log review, sampling outputs |
| **Corrective** | fix / limit after | kill switch, memory purge, document removal, token revoke, model rollback |

Good programs have all three for each top risk. Example — *"InvoiceAgent pays an attacker"*:
- preventive: bank details must match vendor master; human approval
- detective: alert on payments to newly changed bank accounts
- corrective: payment recall procedure, suspend agent flag

## Guardrails across the stack

| Guardrail | Checks | Example rule |
|---|---|---|
| **Prompt** | inputs | block risk ≥ 0.9; flag role-play + refusal suppression |
| **Output** | answers | redact PII, block unsafe content, require citations |
| **Tool** | actions | schema validation, authz per user, approval for write/financial |
| **Data access** | retrieval | user's entitlements filter vector search (see `apps/secure_doc_search`) |
| **Agent action** | plans & steps | step budget, forbidden tool chains, taint rules |
| **Workflow** | business process | payments > €10k need two approvers |

### Guardrails for specific risks
| Risk | Example attack | Guardrail |
|---|---|---|
| Prompt injection | "Ignore instructions and…" | classifier + instruction hierarchy + least-privilege tools |
| Jailbreak | role-play / encoding | risk scoring + output moderation |
| Data leakage | "list all customer emails" | output DLP, data-access guardrail |
| Unsafe content | self-harm, weapons | moderation model (e.g. Llama Guard) |
| Policy evasion | splitting a forbidden request across turns; translating to another language | conversation-level scoring, normalization, multilingual classifiers |

## Measuring guardrail effectiveness

| Metric | Definition | Example (HelpBot, Oct) |
|---|---|---|
| **Triggers** | times a guardrail fired | 4,210 |
| **Blocks** | requests stopped | 380 |
| **Redactions** | content modified | 3,500 |
| **Escalations** | sent to human / approval | 330 |
| **Overrides** | human allowed what guardrail flagged | 41 |
| **Bypasses** | known-bad got through (from red-team / incidents) | 6 |
| **False positives** | benign flagged (from sampled review) | 7% of blocks |
| **Attack success rate (ASR)** | successful attacks / attempted in test suite | 2.1% (target < 3%) |
| **Latency overhead** | p95 added time | 120 ms |

Interpretation examples:
- Blocks rose 5× after a release, but ASR unchanged → probably **false positives** (bad filter), not attacks.
- Overrides high for one rule → rule too strict or reviewers rubber-stamping (check SoD and approval fatigue).
- Bypasses > 0 → each becomes a test case and a ticket.

## Architecture: from a written policy to enforced, tested, measured control

A control is only real if it is **enforced** at runtime, **tested** continuously, and **measured** in
production. This pipeline connects those three.

```mermaid
flowchart LR
  REGI[Control register<br/>CTL id, owner, type] --> REPO[(Policy repo<br/>Rego or YAML)]
  REPO -->|pull request| REV[Review<br/>author is not approver]
  REV --> TEST[CI control tests<br/>attack and benign suites]
  TEST -->|pass| BUN[Signed policy bundle<br/>versioned]
  TEST -->|fail| REPO
  BUN --> SHADOW[Shadow mode<br/>log would-be decisions]
  SHADOW --> PE[Policy engine<br/>in the gateway]
  PE --> DEC[Decisions<br/>allow, block, approve]
  DEC --> MET[(Metrics<br/>triggers, blocks,<br/>overrides, bypasses)]
  TEST --> EVID[(Evidence store<br/>test results)]
  MET --> EFF[Effectiveness dashboard]
  EVID --> EFF
```

| Component | Responsibility | Why it sits here |
|---|---|---|
| Control register | lists each control with ID, owner, type, and the risk it addresses | links code back to the risk it mitigates |
| Policy repo | rules as code | reviewable, diffable, revertible |
| Review | a second person approves every change | separation of duties for rule changes |
| CI control tests | prove the rule does what it claims, and doesn't block normal traffic | a rule without a test is an untested production change |
| Signed bundle | the exact rules in force, with a version | every runtime decision traces to a version |
| Shadow mode | measures a new rule's effect without enforcing it | finds false positives before users do |
| Policy engine | makes the runtime decisions | the enforcement point |
| Metrics and evidence | measure behavior in production and store test results | answers "does it work?" with data, for operations and auditors |

### Follow one change through it: lowering the payment limit

1. Finance asks to lower InvoiceAgent's maximum payment limit from €10,000 to €5,000. Payments up to the limit need human approval, and payments above it are denied. The control register entry is CTL-011.
2. An engineer edits `payment_limit` in the policy data and opens a pull request. A second reviewer approves it.
3. CI runs the control tests: €4,000 must require approval, €6,000 must be denied, and the 200 benign invoice cases must not change. One test fails, because a hard-coded €10,000 remained in a test fixture. It's fixed and re-run.
4. The signed bundle `2026-11-15` is published and runs in shadow mode for 3 days. Logs show it would deny 38 payments per week that today go to approval.
5. Finance confirms that's intended. The bundle is enforced.
6. Metrics show denials for CTL-011 rising as expected, and test results for the bundle are stored as evidence for the next audit.

**The one idea to keep:** treat every control like production code: **review, test, shadow, enforce, measure**.

## Policy-as-code

Write governance rules as **versioned, tested code** that the gateway evaluates at runtime.
Common engines: **OPA/Rego**, **AWS Cedar**, or plain Python/YAML for small setups.

### Example (Rego) — tool call policy
```rego
package ai.tools

default decision := "deny"

decision := "allow" if {
  input.tool.impact == "read"
  input.tool.name in data.systems[input.system_id].allowed_tools
}

decision := "require_approval" if {
  input.tool.impact in {"write", "financial"}
  input.tool.name in data.systems[input.system_id].allowed_tools
  not over_limit
}

over_limit if input.tool.args.amount > data.systems[input.system_id].payment_limit

decision := "deny" if over_limit
```
Example input → decision:
| Input | Decision |
|---|---|
| InvoiceAgent `lookup_po` | allow |
| InvoiceAgent `schedule_payment` €4,000 | require_approval |
| InvoiceAgent `schedule_payment` €25,000 | deny |
| HelpBot `schedule_payment` | deny (not in allowed tools) |

## Automated enforcement and control testing

Controls must be **tested continuously**, like code:

```python
# tests/test_controls.py — runs in CI and nightly against staging
def test_ctl011_payment_requires_approval(gateway):
    d = gateway.decide_tool("sys-invoice", "schedule_payment", {"amount": 4000})
    assert d == "require_approval"

def test_ctl003_unapproved_model_blocked(gateway):
    assert gateway.decide_model("sys-contractlens", "unknown-model-x") == "deny"

def test_ctl021_injection_suite_asr_under_target(run_attack_suite):
    assert run_attack_suite("sys-helpbot").asr < 0.03
```
Each test result is stored as **evidence** (`control_test` table: control_id, run_at, passed,
artifact link) — auditors love this (module 15).

## Project: guardrails and policy enforcement service

Build:
1. `policies/` folder (Rego or YAML) per system, reviewed via pull requests (SoD: author ≠ approver).
2. `POST /decide` — input `{system_id, stage, user, tool, args, signals}` → `{decision, rule_id}`.
3. Metrics: triggers/blocks/escalations per rule, exported to Prometheus.
4. Control tests in CI + nightly; results written to the evidence table.
5. Dashboard: guardrail effectiveness table above, per system.

## FAANG deep-dive notes

**Typical design-review prompt:** *"Design a policy-as-code control platform for 2,000 AI systems.
Auditors want proof that controls work, not just that they exist."*

**1. Clarify first:**
- Which controls must be enforced at runtime, and which are process controls (reviews, training)? Only the first kind belongs in a policy engine.
- Who writes policies: a central team, or app teams within guardrails? This decides the repo structure and review rules.
- What evidence do auditors accept: test results, decision logs, sampled reviews? Design evidence collection around it from day one.
- How quickly must an emergency policy change ship? Hours, not days, so the pipeline needs a fast lane that keeps review and tests.

**2. Back-of-envelope:**
- Controls: about 40 control types in the library, applied with different parameters across 2,000 systems, is up to 80,000 control instances.
- Tests: if each control type has about 10 test cases and each system runs its applicable 15 controls, that's about 150 tests per system, 300,000 test runs per nightly cycle. At about 5 ms each on the policy engine, that's 1,500 CPU-seconds, about 25 minutes on one core or under a minute on a small pool.
- Decision logs: from module 09, about 40,000 decisions per second is about 1.7 TB per day. For effectiveness metrics, aggregate counts per rule per minute instead of storing every event forever.
- Human review sampling: reviewing 0.1% of blocks to measure false positives. With about 50,000 blocks per day, that's 50 reviews per day, about 2 hours of one person's time.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Policy language | general code (Python) | a policy language (Rego, Cedar) | a policy language for authorization-style rules; it's easier to analyze and test |
| Ownership | central team writes all rules | layered: global baseline plus app-level rules | apps can tighten but not loosen the baseline |
| Rollout | enforce immediately | shadow, then canary, then enforce | always shadow first, except emergency blocks |
| Effectiveness metric | number of blocks | attack success rate plus false-positive rate | blocks alone mean nothing; measure both errors |
| Evidence | screenshots and documents | machine-generated test and decision records | machine-generated, linked to policy versions |

**4. Follow-up questions with crisp answers:**
- *What's the difference between preventive, detective, and corrective controls?* Preventive stops the event (an approval gate), detective notices it (an alert), and corrective limits or repairs damage (a kill switch, a refund recall). Top risks need all three.
- *Why are blocks a bad effectiveness metric?* Blocks rise with attacks and with broken rules. Pair them with attack success rate on a fixed suite and with false positives from sampled review.
- *What is a bypass, and how do you find one?* A known-bad action that got through. You find bypasses through red-team runs, incidents, and canary attacks, and each becomes a test.
- *Why does Rego default to deny in the example?* A fail-safe default: anything the rules don't explicitly allow is denied, so a missing rule can't open a gap.
- *How do you test a policy?* Unit tests with inputs and expected decisions, including boundary values (exactly at the limit), plus a regression set of real past decisions.
- *How do you prevent policy changes from weakening controls silently?* Mandatory review by someone other than the author, protected tests that can't be deleted without approval, and a diff report of decisions that would change.
- *What about controls that can't be automated, like human review?* Record them as workflow events (who reviewed what, when) and sample-audit them. They still produce evidence.
- *How do you show auditors that a control worked on a given date?* Point to the bundle version in force that day, the CI test run for that version, and decision logs from the gateway.
- *How do you handle emergency rules during an incident?* A fast lane: a minimal change, an expedited second-person review, the smoke test suite, and immediate enforcement. A full review follows afterward.
- *How do override rates help?* A rule that humans frequently override is either too strict or being rubber-stamped. Either way, investigate it.

**Debug this:** *"The control-test dashboard shows 100% passing for CTL-011 (payment approval), yet an incident shows a €12,000 payment executed without approval."*
1. Trace the payment in the audit log. There's no gateway decision for it at all, so the call never reached the policy engine.
2. Trace the call path. A new batch-payment job called the payments API directly with a service account, bypassing the agent's tool gateway.
3. Mechanism: the tests prove the **policy** is correct, but not that every path **goes through** it. Coverage of enforcement points was never tested.
4. Fix: restrict the payments API so it only accepts calls from the gateway's identity, revoke the batch job's direct credential, and route the job through the gateway.
5. Prevention: add a "path coverage" control test that tries to call protected APIs without the gateway and must fail, plus a detective control that compares payments-API logs with gateway decisions daily.

Lesson: **a correct policy that can be bypassed is not a control.** Test the enforcement path, not only the rule.

**5. Senior vs. staff:**
- Senior: writes policies as code with tests, ships through review and shadow mode, and builds effectiveness metrics.
- Staff: designs the layered policy model for thousands of systems, measures effectiveness with both error rates, makes evidence machine-generated and version-linked, and tests that enforcement points can't be bypassed.

**Red flags:** controls that exist only in documents; rules without tests; counting blocks as success; no shadow mode; no check that every path goes through the policy engine.
