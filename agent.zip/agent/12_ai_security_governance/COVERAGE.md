# Coverage map: course outline → where each lecture is covered

Every lecture in the course outline, mapped to the file and section that covers it. "Lab" means
the section contains code you run. "Concept" means explanation, examples, and tables only.

## AI Security Masterclass

### Getting started
| Lecture | Covered in | Type |
|---|---|---|
| Welcome to AI Security Masterclass | [README](README.md) | concept |
| Why AI Security Matters More Than Ever | [01](01_foundations.md) › Why AI security matters more than ever | concept |
| What You'll Build Throughout This Course | [README](README.md) › What you'll build | concept |
| Course Roadmap: Build, Attack and Secure AI Applications | [README](README.md) › Roadmap | concept |
| Installing Python, VS Code, and Git | [00](00_setup.md) › Install Python, VS Code, and Git | lab |
| Setting Up Ollama | [00](00_setup.md) › Ollama in 3 commands; Calling Ollama two ways | lab |

### AI security foundations
| Lecture | Covered in | Type |
|---|---|---|
| How AI Security Differs from Traditional Application Security | [01](01_foundations.md) › How AI security differs… | concept |
| Understanding the AI Threat Landscape | [01](01_foundations.md) › The AI threat landscape | concept |
| OWASP Top 10 for LLM Applications | [01](01_foundations.md) › OWASP Top 10 for LLM Applications (2025) | concept |
| Security Layers in Modern AI Systems | [01](01_foundations.md) › Security layers…; Architecture | concept |

### First chat assistant
| Lecture | Covered in | Type |
|---|---|---|
| Build Your First AI Chat Assistant | [02](02_first_chat_assistant.md) › The minimal assistant | lab |
| Explore Security Weaknesses in the Chat Assistant | [02](02_first_chat_assistant.md) › Explore the security weaknesses | lab |

### Prompt injection
| Lecture | Covered in | Type |
|---|---|---|
| Understanding Direct Prompt Injection | [03](03_prompt_injection.md) › What it is | concept |
| Prompt Hierarchy: System, Developer and User Messages | [03](03_prompt_injection.md) › Prompt hierarchy | concept |
| Attack the Chat Assistant with Prompt Injection | [03](03_prompt_injection.md) › Attack the chat assistant with prompt injection | lab |
| Implement Prompt Validation | [03](03_prompt_injection.md) › Defense 1 — Prompt validation | lab |
| Add Basic Guardrails | [03](03_prompt_injection.md) › Defense 2; Add basic guardrails to the chat assistant | lab |
| Test Prompt Injection Defenses | [03](03_prompt_injection.md) › Test your defenses | lab |

### Jailbreaks
| Lecture | Covered in | Type |
|---|---|---|
| Understanding AI Jailbreaks | [04](04_jailbreaks.md) › What a jailbreak is | concept |
| Role Playing, Encoding and Multi-Turn Attacks | [04](04_jailbreaks.md) › Technique families; Attack examples A1–A11 | concept |
| Run Jailbreak Attacks Against the Chat Assistant | [04](04_jailbreaks.md) › Run the jailbreak attacks against the chat assistant | lab |
| Build a Prompt Risk Analyzer | [04](04_jailbreaks.md) › Build a prompt risk analyzer (v1); Improve the analyzer (v2) | lab |
| Add Prompt Filtering and Risk Scoring | [04](04_jailbreaks.md) › Prompt filtering with risk tiers; Add prompt filtering to the chat assistant | lab |
| Test Jailbreak Resistance | [04](04_jailbreaks.md) › Test jailbreak resistance | lab |

### RAG fundamentals
| Lecture | Covered in | Type |
|---|---|---|
| What is Retrieval-Augmented Generation (RAG)? | [05](05_rag_security.md) › What RAG is, and why apps use it | concept |
| How RAG Applications Work | [05](05_rag_security.md) › How RAG applications work | concept |
| Understanding Embeddings and Vector Search | [05](05_rag_security.md) › Understanding embeddings and vector search | concept |
| Build a Document-Based RAG Assistant from Scratch | [05](05_rag_security.md) › Build a document-based RAG assistant from scratch | lab |
| Ask Questions Using Retrieved Documents | [05](05_rag_security.md) › Ask questions using retrieved documents | lab |

### RAG security
| Lecture | Covered in | Type |
|---|---|---|
| Prompt Injection in RAG Applications | [05](05_rag_security.md) › Threats › 1. Indirect prompt injection | concept |
| Document Poisoning and Trust Boundaries | [05](05_rag_security.md) › Threats › 2. Document poisoning; Trust boundaries | concept |
| Exploiting a RAG Assistant with a Malicious PDF | [05](05_rag_security.md) › Exploiting the RAG assistant with a malicious PDF | lab |
| Poisoning Retrieved Context | [05](05_rag_security.md) › Threats › 2–3 | concept |
| Implement Trusted Source Validation | [05](05_rag_security.md) › Defense 1 | lab |
| Add Context Isolation | [05](05_rag_security.md) › Defense 3 | lab |
| Sanitize Retrieved Content | [05](05_rag_security.md) › Defense 2 | lab |
| Add Enforcement Layer | [05](05_rag_security.md) › Defense 4 | lab |
| Verify the RAG Security Defenses | [05](05_rag_security.md) › Verify the RAG defenses | lab |

### Tool calling
| Lecture | Covered in | Type |
|---|---|---|
| What is Tool Calling? | [06](06_tool_security.md) › Tool calling recap | concept |
| Function Calling and Tool Selection | [06](06_tool_security.md) › Function calling and tool selection | concept |
| Designing Weather, Calculator and Email Tools | [06](06_tool_security.md) › Designing tools | concept |
| Build a Tool-Calling Chat Assistant | [06](06_tool_security.md) › Build a tool-calling chat assistant | lab |
| Test Multiple Tool Calls | [06](06_tool_security.md) › Test multiple tool calls | lab |

### Tool security
| Lecture | Covered in | Type |
|---|---|---|
| Tool Calling Security Risks | [06](06_tool_security.md) › Threats | concept |
| Parameter Injection and Unauthorized Actions | [06](06_tool_security.md) › Threats › Parameter injection; Unauthorized actions | concept |
| Triggering Unauthorized Tool Calls | [06](06_tool_security.md) › Triggering unauthorized tool calls (attack lab) | lab |
| Validate Tool Inputs | [06](06_tool_security.md) › Defense 1 | lab |
| Restrict Tool Permissions | [06](06_tool_security.md) › Defense 2 | lab |
| Add Human Approval for Sensitive Actions | [06](06_tool_security.md) › Defense 3 | lab |
| Verify Tool Security | [06](06_tool_security.md) › Verify tool security | lab |

### Memory
| Lecture | Covered in | Type |
|---|---|---|
| Short-Term vs Long-Term Memory | [07](07_memory_security.md) › Short-term vs long-term memory | concept |
| Designing Persistent AI Memory | [07](07_memory_security.md) › Designing persistent AI memory | concept |
| Add AI Memory to the Assistant | [07](07_memory_security.md) › Adding memory to the assistant | lab |
| Test Memory Retrieval | [07](07_memory_security.md) › Adding memory… › Test memory retrieval | lab |

### Memory security
| Lecture | Covered in | Type |
|---|---|---|
| Memory Poisoning Attacks | [07](07_memory_security.md) › Memory poisoning attacks | concept |
| Persistent Context Risks | [07](07_memory_security.md) › Persistent context risks | concept |
| Poisoning AI Memory | [07](07_memory_security.md) › Examples 1–3 | lab |
| Validate Memory Before Storage | [07](07_memory_security.md) › Defense 1 | lab |
| Require User Approval Before Saving Memory | [07](07_memory_security.md) › Defense 2 | lab |
| Protect Against Memory Poisoning | [07](07_memory_security.md) › Defense 3 | lab |
| Verify Memory Security | [07](07_memory_security.md) › Verify memory security | lab |

### Agents
| Lecture | Covered in | Type |
|---|---|---|
| From Chatbots to AI Agents | [08](08_agent_security.md) › From chatbots to AI agents | concept |
| Planning, Reasoning and Tool Use | [08](08_agent_security.md) › Planning, reasoning, and tool use | concept |
| Build an Autonomous Planner Agent | [08](08_agent_security.md) › Build an autonomous planner agent | lab |
| Test the Agent Workflow | [08](08_agent_security.md) › Test the agent workflow | lab |

### Agent security
| Lecture | Covered in | Type |
|---|---|---|
| Agent Security Threats | [08](08_agent_security.md) › Agent security threats | concept |
| Human-in-the-Loop Approvals | [08](08_agent_security.md) › Defense 1 | concept |
| Compromising an Autonomous Agent | [08](08_agent_security.md) › Compromising an autonomous agent | lab |
| Add Human Approval Workflows | [08](08_agent_security.md) › Defense 1 | lab |
| Restrict Agent Permissions | [08](08_agent_security.md) › Defense 2 | lab |
| Secure Agent Decision Making | [08](08_agent_security.md) › Defense 3 | lab |
| Validate Agent Security | [08](08_agent_security.md) › Validate agent security | lab |

### Secure AI architecture and the gateway
| Lecture | Covered in | Type |
|---|---|---|
| Layered AI Security Architecture | [09](09_security_gateway.md) › Layered AI security architecture | concept |
| Policy Engines, Guardrails and Risk Scoring | [09](09_security_gateway.md) › Policy engines, guardrails, and risk scoring | concept |
| Reviewing the Complete Secure AI Architecture | [09](09_security_gateway.md) › Architecture: the gateway as a service | concept |
| Build the AI Security Gateway | [09](09_security_gateway.md) › Build the gateway (skeleton); The policy | lab |
| Integrate Prompt Validation | [09](09_security_gateway.md) › Integrate prompt validation | lab |
| Integrate RAG Security | [09](09_security_gateway.md) › Integrate RAG security | lab |
| Integrate Tool Security | [09](09_security_gateway.md) › Integrate tool security | lab |
| Integrate Memory Security | [09](09_security_gateway.md) › Integrate memory security | lab |
| Integrate Agent Security | [09](09_security_gateway.md) › Integrate agent security | lab |
| Verify the Complete Security Pipeline | [09](09_security_gateway.md) › Integration walkthrough; Verify the complete pipeline | lab |

### Deployment
| Lecture | Covered in | Type |
|---|---|---|
| Deploying Secure AI Applications | [10](10_deploy_monitor_respond.md) › Deploying secure AI applications — checklist | concept |
| Monitoring, Logging and Incident Response | [10](10_deploy_monitor_respond.md) › Monitoring and logging; Incident response | concept |
| Package the Secure AI Assistant with Docker | [10](10_deploy_monitor_respond.md) › Package the secure AI assistant with Docker | lab |
| Build and Run the Dockerized Secure AI Assistant | [10](10_deploy_monitor_respond.md) › Build and run the Dockerized secure AI assistant | lab |
| Course Wrap-Up and Next Steps | [16](16_wrap_up.md) | concept |

## AI Governance

### Foundations
| Lecture | Covered in | Type |
|---|---|---|
| AI governance across the full lifecycle | [11](11_governance_foundations.md) › Governance across the AI lifecycle | concept |
| Governance versus risk, compliance, security, privacy, safety, & responsible AI | [11](11_governance_foundations.md) › Governance vs related disciplines | concept |
| AI governance operating model | [11](11_governance_foundations.md) › AI governance operating model | concept |
| Governance data architecture | [11](11_governance_foundations.md) › Governance data architecture; Architecture | concept |
| Governance frameworks | [11](11_governance_foundations.md) › Governance frameworks | concept |
| Hands-On Project: Build the AI Governance Data Foundation | [11](11_governance_foundations.md) › Project | lab |

### Inventory and usage intelligence
| Lecture | Covered in | Type |
|---|---|---|
| Building an enterprise AI inventory | [12](12_inventory_usage.md) › Enterprise AI inventory | concept |
| Usage telemetry | [12](12_inventory_usage.md) › AI usage telemetry | concept |
| Model usage analytics | [12](12_inventory_usage.md) › Model usage analytics | concept |
| Token consumption and cost allocation | [12](12_inventory_usage.md) › Token consumption and cost allocation | concept |
| Ownership and accountability | [12](12_inventory_usage.md) › AI ownership and accountability | concept |
| Hands-On Project: Build the AI Inventory and Usage Intelligence Dashboard | [12](12_inventory_usage.md) › Project | project outline |

### Assessments and approvals
| Lecture | Covered in | Type |
|---|---|---|
| Model cards, system cards, agent cards, dataset cards, and vendor assessments | [13](13_assessments_approvals.md) › Cards: standard documentation | concept |
| AI impact assessments | [13](13_assessments_approvals.md) › AI impact assessments | concept |
| Approval workflows | [13](13_assessments_approvals.md) › AI approval workflows | concept |
| Exception management | [13](13_assessments_approvals.md) › Exception management | concept |
| Governance accountability and separation of duties | [13](13_assessments_approvals.md) › Accountability and separation of duties | concept |
| Hands-On Project: Build an AI Assessment and Approval Workflow | [13](13_assessments_approvals.md) › Project | project outline |

### Controls, guardrails, and policy-as-code
| Lecture | Covered in | Type |
|---|---|---|
| Preventive, detective, and corrective controls for AI systems | [14](14_controls_policy_as_code.md) › Preventive, detective, and corrective controls | concept |
| Guardrails for prompts, outputs, tools, data access, agent actions, and workflows | [14](14_controls_policy_as_code.md) › Guardrails across the stack | concept |
| Prompt injection, jailbreaks, data leakage, unsafe content, and policy evasion | [14](14_controls_policy_as_code.md) › Guardrails for specific risks | concept |
| Measuring guardrail effectiveness: triggers, blocks, escalations, bypasses, … | [14](14_controls_policy_as_code.md) › Measuring guardrail effectiveness | concept |
| Policy-as-code, automated enforcement, and control testing | [14](14_controls_policy_as_code.md) › Policy-as-code; Automated enforcement and control testing | lab |
| Hands-On Project: Build a Guardrails and Policy Enforcement Service | [14](14_controls_policy_as_code.md) › Project | project outline |

### Incidents, audit, and reporting
| Lecture | Covered in | Type |
|---|---|---|
| AI incident management: policy breaches, near-misses, severity, impact, and response | [15](15_incidents_audit_reporting.md) › AI incident management | concept |
| Audit trail design | [15](15_incidents_audit_reporting.md) › Audit trail design | concept |
| Governance KPIs and KRIs for executives, risk teams, engineers, and auditors | [15](15_incidents_audit_reporting.md) › KPIs and KRIs; …for executives, risk teams, engineers, and auditors | concept |
| Incident remediation | [15](15_incidents_audit_reporting.md) › Incident remediation | concept |
| Board reports, audit packets, regulatory evidence, and compliance summaries | [15](15_incidents_audit_reporting.md) › Reporting: board, audit, regulators | concept |
| Hands-On Project: Build an AI Governance Audit and Incident Center | [15](15_incidents_audit_reporting.md) › Project | project outline |

## What "project outline" means

The four governance projects in modules 12–15 give the requirements, data model, sample records,
and acceptance checks, but not a complete runnable application. The module 11 project is
complete and runnable (SQLite schema, seed data for all four Acme systems, and the deliverable
query with a negative test).
