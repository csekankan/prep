# AI Engineering Field Guide — Agents, RAG, Memory, Guardrails, Evals

A **read-first** learning project. Every file is written so that the *comments are the
lesson* and the code is the illustration. You do not need to run anything to learn from it
(though the code is realistic and runnable once you install deps and set API keys).

## How to read this repo (suggested order)

| Step | Folder | What you learn |
|------|--------|----------------|
| 0 | `00_lifecycle/` | The AI engineering lifecycle — the "why" before the "how" |
| 1 | `01_foundations/` | LLM calls, prompting, structured output, tool calling |
| 2 | `02_single_agent/` | The agent loop: raw Python → LangChain → LangGraph |
| 3 | `03_multi_agent/` | Supervisor, handoff/swarm, plan-and-execute, reflection |
| 4 | `04_rag/` | RAG from scratch → advanced RAG → agentic/corrective RAG → pgvector & Qdrant servers |
| 5 | `05_memory/` | Short-term vs long-term memory, Mem0 |
| 6 | `06_guardrails/` | Layered input/output/tool guardrails |
| 7 | `07_evaluation/` | DeepEval for RAG and agents, LLM-as-judge, CI gates |
| 8 | `08_production/` | Observability, caching, cost, latency, MCP, deployment |
| 9 | `09_aws_bedrock/` | Bedrock Converse, tool use, Knowledge Bases, Guardrails, AgentCore, AWS pipeline |
| 10 | `10_llmops_pipeline/` | Monitor → alert → curate data → train → eval gate → publish versioned release |
| 11 | `11_kubernetes/` | Production deploy: Docker, Kustomize, canary with auto-rollback, GitOps, CronJobs, CI |
| 12 | `12_ai_security_governance/` | Course: AI security (injection, jailbreaks, RAG/tool/memory/agent security, gateway) + AI governance (inventory, approvals, policy-as-code, incidents, audit) |
| 13 | `13_sovereign_ai_infra_course/` | Course: sovereign AI infrastructure on Kubernetes — GPUs, distributed training, inference scaling, vector data, MCP agents, multi-cluster sovereignty (71 labs incl. Redis for AI, diagrams + FAANG notes) |
| 14 | `14_math_for_ml_dl_llm/` | Course: the math behind ML, deep learning and LLMs for senior engineers — linear algebra → attention, scaling laws, KV cache, LoRA/quantization, RLHF/DPO, and ML-systems math (memory, roofline, cost) |
| 15 | `15_ml_dl_llm_engineering/` | Course: ML → deep learning → LLMs → MLOps → deployment for software engineers — theory, math explained in plain words, architecture diagrams, worked examples, practical code, capstone + interview prep |
| 16 | `16_ai_infra_zero_to_hero/` | Course: AI infrastructure zero to hero — Linux, cloud, Docker, Kubernetes, GPUs, distributed training, MLOps, serving, observability, drift, security, edge, GenAI infra, capstone (54-section map; Part I written with diagrams, plain-words examples, and runnable exercises) |
| 17 | `17_big_data_engineering_aws/` | Course: big data engineering on AWS — HDFS/YARN/MapReduce internals, Spark deep dive (partitioning, caching, architecture, optimization), Hive/Athena, Kafka/MSK/Kinesis, Airflow/MWAA, Databricks on AWS + Delta, Glue/Lake Formation/Redshift, Olist capstone (all GCP/Azure parts replaced with AWS) |
| 18 | `apps/` | Three small production-grade apps tying everything together |

## The three apps

- `apps/support_copilot/` — **single agent + RAG + Mem0 + guardrails + evals**, served by FastAPI
  with Prometheus metrics and health probes. A customer-support assistant grounded in a knowledge base.
- `apps/research_team/` — **multi-agent LangGraph** (supervisor → researcher, analyst, writer, critic)
  with a bounded reflection loop, human-in-the-loop approval, and checkpointing.
- `apps/secure_doc_search/` — **permission-aware RAG**: Active Directory / Entra ID groups decide
  which document sections a user can retrieve (e.g. external workers see material data, not prices).

## Mental model in one picture

```
                  ┌────────────────────────── AI ENGINEERING LIFECYCLE ─────────────────────────┐
                  │ define → data → prototype → evaluate → harden → deploy → observe → improve  │
                  └──────────────────────────────────────────────────────────────────────────────┘
 user ─► [input guardrails] ─► AGENT LOOP ───────────────────────────► [output guardrails] ─► user
                                 │  think → act(tool) → observe → repeat
                                 ├── tools: search, RAG retriever, APIs, code
                                 ├── memory: short-term (state) + long-term (Mem0)
                                 └── other agents (multi-agent graph)
                        everything traced (LangSmith/Langfuse) + evaluated (DeepEval)
```

## Setup (optional — only if you want to run things)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # add your keys
```

## Golden rules this repo keeps repeating

1. **Start with the simplest thing** — a single prompt beats an agent; an agent beats a multi-agent system — until it doesn't.
2. **Evals before vibes** — build an eval set on day 1; every change is measured.
3. **Bound every loop** — max iterations, timeouts, budgets. Agents fail by looping.
4. **Ground or refuse** — RAG answers must cite context or say "I don't know".
5. **Defense in depth** — guardrails at input, tool, and output layers; never trust the model alone.
6. **Observe everything** — if it's not traced, you can't debug it.
