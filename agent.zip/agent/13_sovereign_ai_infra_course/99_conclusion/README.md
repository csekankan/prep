# Conclusion

## What you built, in plain words

You started with **one laptop running one small model**. You end with the blueprint for a **country-scale AI platform**.
Each section added one "organ" to the system:

```mermaid
flowchart LR
  A["🧪 Sandbox<br/>(laptop K3s + vLLM)"] --> B["⚡ Muscles<br/>(GPU fleet, scheduling)"]
  B --> C["🧠 Learning<br/>(distributed training)"]
  C --> D["🗣️ Voice<br/>(serving at scale)"]
  D --> E["📚 Memory<br/>(sovereign data + vectors)"]
  E --> F["🤝 Hands<br/>(agents + MCP tools)"]
  F --> G["🏛️ Citizenship<br/>(sovereignty, law, audit)"]
```

| Section | One-sentence takeaway |
|---|---|
| Foundations | Containers are fenced processes. Kubernetes is the operating system for the data center. |
| Accelerated compute | GPUs are expensive, so share, schedule, observe, and autoscale them. |
| Distributed training | The network is the computer. Plan parallelism around NVLink and InfiniBand, and checkpoint often. |
| Serving | VRAM (especially the KV cache) is the currency. Route smartly and deploy safely. |
| Sovereign data | Validate, mask, hash, back up, and enforce residency with policy, not wiki pages. |
| Agents & MCP | Standard protocols, validated outputs, sandboxes, and budgets turn agents into safe teammates. |
| Sovereign deployment | Route by law, federate across borders, run offline, audit with evidence. |

## The 10 laws of sovereign AI infrastructure

1. **Size from the model backwards:** weights + KV cache + headroom (Labs 1, 8, 42).
2. **Scale on what users feel** (queue depth, TTFT), not CPU (Lab 29).
3. **Keep tensor parallelism inside the fast domain** (NVLink/NVL72) (Lab 40).
4. **Assume failure:** checkpoints, replicas, restore drills (Labs 39, 68).
5. **Every byte has a home jurisdiction**, enforced at compute, storage, network, and routing (Labs 70, 97).
6. **LLM output is untrusted input:** validate, authorize, sandbox (Labs 75, 77).
7. **Govern in tokens and dollars**, not just requests (Lab 79).
8. **Provenance or it didn't happen:** hash data, sign models, keep lineage (Labs 44, 66).
9. **Policy as code, evidence as code** (Labs 70, 92, 99).
10. **Vendor diversity is resilience** (Labs 24, 74).

## Where to go next

| Path | Next steps |
|---|---|
| Platform/SRE | Kubernetes DRA, Gateway API Inference Extension, llm-d / NVIDIA Dynamo, Cilium |
| ML infrastructure | FP8/FP4 training, MoE expert parallelism, TorchTitan, fault-tolerant training (TorchFT) |
| Data | Iceberg lakehouses for AI, GPU vector search (CAGRA), streaming CDC at scale |
| Agents | MCP authorization deep dive, A2A protocol, durable agent workflows (Temporal) |
| Governance | ISO/IEC 42001 certification, EU AI Act harmonized standards, model signing (OMS/Sigstore) |

## Final exercise

Take the capstone (Lab 100) and **re-target it** for one of these:
- A mid-size bank (40 GPUs, two data centers, one country)
- A hospital network (federated with 5 partners, air-gapped imaging)
- A global SaaS (3 jurisdictions, multi-LoRA per customer)

Produce the diagram, sizing sheet, and top-5 risks. If you can explain every arrow in your diagram, you have completed the course.
