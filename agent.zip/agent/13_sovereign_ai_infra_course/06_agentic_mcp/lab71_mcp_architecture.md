# Lab 71: The Model Context Protocol (MCP) Architecture Review (3:29)

## Why it matters
Before MCP, every AI app wrote custom integrations for every tool, an **N × M** problem. MCP is an open
protocol that standardizes how AI applications connect to tools and data. Write a server once and any MCP-capable
host (IDEs, chat apps, your own orchestrator) can use it.

## In plain words
MCP is **USB-C for AI**. Before it, every app needed a custom cable for every tool. Now a tool builds one MCP "port" (server), and any
AI app with an MCP "socket" (client) can plug in.

## Core concepts

```mermaid
flowchart LR
  subgraph Host["MCP Host (app: IDE, chat, orchestrator)"]
    LLM[LLM]
    C1[MCP Client 1]
    C2[MCP Client 2]
  end
  C1 <-->|JSON-RPC 2.0| S1[MCP Server: Postgres]
  C2 <-->|JSON-RPC 2.0| S2[MCP Server: Jira]
```

**How to read it:** The host contains the LLM and one client per server. Each client speaks JSON-RPC to an MCP server that wraps one system.

| Role | Responsibility |
|---|---|
| **Host** | The AI application. Owns the LLM, user consent, and security policy |
| **Client** | One per server connection, inside the host |
| **Server** | Exposes capabilities from a system (DB, SaaS, filesystem) |

**Server primitives**

| Primitive | Controlled by | Example |
|---|---|---|
| **Tools** | Model (invoked by the LLM) | `run_sql_query`, `create_ticket` |
| **Resources** | Application (context data) | `schema://sales/orders`, file contents |
| **Prompts** | User (templates) | "Summarize incident {id}" |

**Client primitives:** *Sampling* (server asks the host's LLM to generate), *Elicitation* (server asks the user for input), *Roots* (filesystem scope).

**Transports:** `stdio` (local subprocess) and **Streamable HTTP** (remote, production). Remote servers use
**OAuth 2.1** authorization, so the host obtains scoped tokens on the user's behalf.

**Lifecycle:** `initialize` (capability negotiation), then `tools/list`, `tools/call`, `resources/read`, ..., then `notifications`, then shutdown.

## Architecture in depth

The concepts diagram shows host, clients, and servers. This view follows **one full MCP session** over Streamable HTTP, from
connection and OAuth to a tool call, which is the sequence you debug in production.

```mermaid
sequenceDiagram
  participant U as User
  participant H as Host (LLM + MCP client)
  participant AS as Authorization server (SSO)
  participant S as Remote MCP server (Jira)
  H->>S: POST /mcp initialize
  S-->>H: 401 + resource metadata (where to authorize)
  H->>U: consent screen
  U->>AS: login + approve scopes jira:read
  AS-->>H: access token (audience = Jira MCP server)
  H->>S: initialize (Bearer token) → capabilities
  H->>S: tools/list
  S-->>H: tools + JSON schemas
  H->>H: LLM chooses tool from list
  H->>S: tools/call search_issues(jql)
  S-->>H: result content
  S--)H: notifications/tools/list_changed (later)
```

### Follow one session from connect to result
1. **Connect.** The host sends `initialize` to the server's single MCP endpoint over HTTP.
2. **Discover auth.** The server answers 401 with metadata pointing to the authorization server, so the host learns where to get a token.
3. **Consent.** The user logs in through SSO and approves specific scopes. The token's audience is this server only, so it can't be replayed elsewhere.
4. **Negotiate.** With the token, `initialize` succeeds, and client and server agree on capabilities (tools, resources, prompts, notifications).
5. **Discover tools.** `tools/list` returns names, descriptions, and JSON schemas, which the host gives to the LLM.
6. **Call.** The LLM picks a tool, and the host validates arguments and sends `tools/call`. The server runs it *as the user*, with the user's permissions.
7. **Stay in sync.** If the server's tools change, it sends a notification, and the host refreshes the list.

**The one idea to keep:** MCP standardizes discovery, auth, and invocation. The host stays in control of consent and policy, and servers act with the user's identity.

## Minimal hands-on — what goes over the wire

```json
{"jsonrpc":"2.0","id":7,"method":"tools/call",
 "params":{"name":"run_sql_query","arguments":{"sql":"SELECT region, sum(revenue) FROM sales GROUP BY 1"}}}
```

```json
{"jsonrpc":"2.0","id":7,"result":{"content":[{"type":"text","text":"[{\"region\":\"EU\",\"sum\":1.2e6}]"}],
 "structuredContent":{"rows":[{"region":"EU","sum":1200000}]},"isError":false}}
```

## Worked example

**Scenario:** An enterprise with 6 AI apps (IDE assistant, support bot, analytics copilot, HR bot, SRE agent, sales copilot)
and 9 internal systems.

| Approach | Integrations to build/maintain | Security review surface |
|---|---|---|
| Custom per app | 6 × 9 = **54** | 54 code paths, inconsistent auth |
| **MCP** | **9 servers** (+ 6 hosts that speak MCP) | 9 servers with central OAuth + audit |

The platform team publishes an **internal MCP registry** listing approved servers, owners, data classes, and required scopes.
App teams compose servers instead of re-integrating them.

## Production deep dive
- **Remote over local:** For enterprises, deploy MCP servers as **centrally managed remote services** on K8s (Streamable HTTP + OAuth), not as random local binaries on laptops.
- **MCP gateway:** A proxy in front of all servers for authN/Z, rate limits, audit logging, tool allow-lists per app, and PII filters (Lab 65).
- **Threat model:** Tool poisoning (malicious tool descriptions), prompt injection via tool results, confused-deputy attacks with over-scoped tokens, and rug-pulls (server changes tool behavior after approval). Pin server versions and review tool descriptions.
- **Token passthrough is forbidden:** Servers must validate that tokens were issued *for them* (audience), and must not forward client tokens to downstream APIs.
- **Versioning:** The protocol evolves (dated spec versions). Negotiate versions and test hosts against servers in CI.

## FAANG deep-dive notes

- **How big tech does it:** Central tool registries with approved, owned, versioned integrations behind a gateway with auth, audit, and per-app allow-lists.
- **Staff review questions:** Who approves a new MCP server? How are tool descriptions reviewed for poisoning? Are tokens audience-bound?
- **Interview question:** *"How would you let 20 internal AI apps access 30 internal systems safely?"* Strong answers cover a standard protocol (MCP), central remote servers, OAuth scopes, a gateway, a registry, and a threat model.

**Typical system-design prompt:** *"Design how a 10,000-person company exposes 50 internal systems to AI assistants via MCP, securely."*

**1. Clarify first:**
- Which hosts: IDEs, chat assistants, autonomous agents, or all three?
- Identity: SSO provider, and must actions run as the user or as a service?
- Risk tiers: read-only systems vs. ones that can change money or production.

**2. Back-of-envelope sizing:**
- 10,000 users × 20 tool calls/day = 200k calls/day ≈ 2.3/s average, ~20/s peak, spread across 50 servers. Each server is light, and the gateway is the shared path.
- Tool metadata: 50 servers × ~10 tools × ~300 tokens of schema = 150k tokens, too much to put in every prompt. Hosts must select toolsets (Lab 73).
- Audit: 200k events/day × 1 KB = 200 MB/day, trivial to retain for years.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Transport | stdio (local) | Streamable HTTP (remote) | remote for shared enterprise servers |
| Identity | shared service account | OAuth per user (on-behalf-of) | per-user tokens with narrow scopes |
| Topology | hosts connect directly | MCP gateway / registry | gateway for policy, audit, discovery |
| Tool design | generic (raw SQL, raw HTTP) | curated task-level tools | curated tools; guarded generic ones only for experts |
| Server trust | any server | allow-listed, signed registry | registry of approved servers |

**4. Follow-up questions with crisp answers:**
- *Why not just give the LLM API keys?* Shared keys have no per-user permissions or audit, and they leak through prompts and logs.
- *What is token audience binding?* The token is valid only for one MCP server, which prevents confused-deputy replay.
- *Tools vs. resources vs. prompts?* Tools are model-invoked actions, resources are app-provided context, and prompts are user-selected templates.
- *What's tool poisoning?* A malicious server's tool descriptions instruct the model to do harmful things. Allow-list servers and review descriptions.
- *How do you version tools?* Additive schema changes, deprecation notices, and `list_changed` notifications.
- *Where is policy enforced?* In the host or gateway (allowed tools per user and task) *and* in the server (the user's permissions).

**Debug this (common onsite question):** *"An assistant created Jira tickets in a project the user has no access to."*
1. The Jira MCP server uses one service account with admin rights for all calls.
2. User identity is passed as a free-text field, which the server logs but doesn't enforce.
3. The LLM chose the project from a document in context.
4. Fix: OAuth on-behalf-of tokens so the server acts as the user, scope tokens to the required actions, require approval for write tools, and audit by real user identity.

The lesson: **an MCP server must act as the user. A shared admin account turns every prompt into privilege escalation.**

**5. What separates senior from staff answers:**
- Senior: builds MCP servers with OAuth, clear schemas, and audit.
- Staff: designs the enterprise MCP architecture (registry, gateway, identity model, risk tiers, tool-design standards) and defends against prompt injection and tool poisoning.

**Red flags:** shared admin service accounts, any-server-allowed hosts, hundreds of tools in every prompt, no audit by user identity.

## Failure modes
- 40 tools exposed with long descriptions overwhelm the context, so the model picks the wrong tool. Curate the tool sets.
- A local stdio server with the developer's full credentials becomes an exfiltration path.
- Tool results containing instructions ("ignore previous...") get executed by the model.

## Checklist
- [ ] You can explain host vs. client vs. server, and tools vs. resources vs. prompts
- [ ] You understand the transport choice (stdio vs. Streamable HTTP) and why
- [ ] An MCP threat model is drafted for your org
