# Section 7 — Agentic Orchestration & the Model Context Protocol (7:36)

**Goal:** Run agents as **governed production workloads**: standardized tool access via MCP, validated
outputs, durable state, sandboxed execution, enterprise integrations, and load control.

| Lab | Topic | Key idea |
|---|---|---|
| [71](lab71_mcp_architecture.md) | MCP architecture | USB-C for AI tools |
| [72](lab72_first_mcp_server_database.md) | First MCP server | Expose a DB safely |
| [73](lab73_mcp_client_orchestrator.md) | MCP client & routing | The host orchestrates |
| [74](lab74_langchain_to_native_protocols.md) | Beyond frameworks | Protocols over abstractions |
| [75](lab75_tool_calling_validation.md) | Tool calling at scale | Validate every artifact |
| [76](lab76_stateful_agents_redis.md) | Stateful agents (Redis) | Durable memory & checkpoints |
| [77](lab77_sandboxing_agent_tools.md) | Sandboxing | Assume the tool call is hostile |
| [78](lab78_enterprise_webhooks.md) | Webhooks (Jira/GitHub/Slack) | Event-driven agents |
| [79](lab79_rate_limiting_token_throttling.md) | Rate limits & token budgets | Govern the swarm |
| [80](lab80_multi_agent_swarm_high_load.md) | Swarm under load | Queues, back-pressure, chaos |

## The agent platform stack

```mermaid
flowchart TB
  EV[Triggers: chat, Slack, Jira, GitHub webhooks] --> GW[Gateway: auth, rate/token limits]
  GW --> Q[Task queue]
  Q --> ORCH[Orchestrator / MCP Host]
  ORCH --> LLM[Inference plane<br/>Section 5]
  ORCH -->|MCP| S1[MCP: DB server]
  ORCH -->|MCP| S2[MCP: Jira/GitHub]
  ORCH -->|MCP| S3[MCP: code-exec in sandbox]
  ORCH --> ST[(Redis: state, checkpoints)]
  ORCH --> OBS[Tracing + audit log]
```

## Agent production principles
1. **Least privilege per tool.** Agents get scoped, short-lived credentials, never a human's full access.
2. **Validate everything crossing a boundary:** tool inputs, tool outputs, final answers.
3. **Durable state:** Agents crash. Resume from checkpoints, don't restart.
4. **Human-in-the-loop** for irreversible actions (payments, deletes, production deploys).
5. **Budgets:** Every task has a max number of tokens, tool calls, wall-clock time, and dollars.
6. **Audit:** Every tool call is logged with who, what, why (the prompt), and the result.
