# Lab 72: Building the First MCP Server — Exposing Internal Databases (4:03)

## Why it matters
"Let the AI query our database" is the most requested and most dangerous agent capability. An MCP server
is the **controlled doorway**: it decides which data is visible, which operations are allowed, and how
results are shaped.

## In plain words
An MCP database server is a **bank teller window**. Customers (the AI) don't walk into the vault (the database). They ask the teller, who
checks their ID, only does allowed operations (read-only), and hands back a limited amount (row limits).

## Architecture at a glance

```mermaid
flowchart LR
  HOST["MCP host + user OAuth token"] --> SRV[MCP server: sales-db]
  SRV --> T1["Curated tool: get_order_status"]
  SRV --> T2["Guarded SQL: parse, SELECT-only, timeout, LIMIT"]
  SRV --> RES["Resource: schema://sales"]
  T1 & T2 -->|"read-only role + RLS by user"| DB[(Postgres read replica)]
  SRV --> AUD[(Audit log)]
```

**How to read it:** The host calls the MCP server with the user's token. The server offers curated tools, guarded SQL, and a schema resource. All DB access is read-only with row-level security, and everything is audited.

## Core concepts — design principles for a DB MCP server

| Principle | Implementation |
|---|---|
| **Read-only by default** | DB role with `SELECT` only on approved views |
| **Curated surface** | Prefer specific tools (`get_order_status(order_id)`) over raw SQL |
| **If raw SQL, sandbox it** | Parse/validate (single statement, SELECT only), statement timeout, row limit |
| **Row-level security** | Pass the end-user identity and let Postgres RLS filter by tenant/user |
| **Expose schema as Resources** | Model sees table/column descriptions and writes better queries |
| **Bounded output** | Truncate rows, return structured content, never dump entire tables |

## Architecture in depth

The overview shows curated and guarded tools. This view follows **one guarded SQL call** through every safety layer inside the
server, because each layer catches a different kind of mistake or attack.

```mermaid
flowchart TB
  CALL["tools/call run_query<br/>sql = SELECT * FROM orders WHERE region='EU'"] --> AUTH["(1) Verify token → user = anna, role = analyst"]
  AUTH --> PARSE["(2) Parse SQL (sqlglot)<br/>single statement? SELECT only?"]
  PARSE -->|"DROP, UPDATE, multi-statement"| DENY[Reject with reason]
  PARSE --> ALLOW["(3) Allow-list tables + columns<br/>no customers.ssn"]
  ALLOW --> REWRITE["(4) Rewrite: add LIMIT 200, statement_timeout 5s"]
  REWRITE --> DB[("(5) Read replica as anna<br/>read-only role + row-level security")]
  DB --> SHAPE["(6) Shape result: cap rows/bytes, mask PII columns"]
  SHAPE --> AUD[("(7) Audit: user, query hash, rows, latency")]
  SHAPE --> RESP[Result to host]
```

### Follow one query through the server
1. **Identity.** The server verifies the OAuth token and maps it to a database identity, so the query runs as Anna and not as a shared superuser.
2. **Parse, don't regex.** A real SQL parser confirms there's exactly one SELECT statement. Regex checks are easy to bypass.
3. **Allow-list.** Only approved tables and columns can be referenced. Sensitive columns like SSN are never reachable.
4. **Rewrite.** The server adds a row limit and a timeout, so a runaway query can't hurt the database.
5. **Database enforcement.** It runs on a read replica with a read-only role and row-level security, so even a bug above can't write or see other regions' rows.
6. **Shape the output.** Results are capped by rows and bytes (protecting the LLM context) and masked where needed.
7. **Audit.** Every call is logged with user, query hash, and row count.

**The one idea to keep:** defence in depth. The server validates, and the database enforces, so no single bug becomes a breach.

## Minimal hands-on (Python MCP SDK, FastMCP)

```python
from mcp.server.fastmcp import FastMCP
import asyncpg, sqlglot

mcp = FastMCP("sales-db")
POOL = None

async def pool():
    global POOL
    POOL = POOL or await asyncpg.create_pool(dsn="postgresql://mcp_readonly@pg/sales", max_size=10)
    return POOL

@mcp.resource("schema://sales")
async def schema() -> str:
    """Tables and columns the assistant may query."""
    return "orders(id, customer_id, region, total_eur, created_at)\ncustomers(id, segment, country)"

@mcp.tool()
async def get_order_status(order_id: int) -> dict:
    """Return status and total for one order."""
    row = await (await pool()).fetchrow("SELECT id, status, total_eur FROM orders WHERE id=$1", order_id)
    return dict(row) if row else {"error": "not found"}

@mcp.tool()
async def run_readonly_query(sql: str) -> list[dict]:
    """Run a single SELECT on approved views. Max 200 rows, 5s timeout."""
    stmts = sqlglot.parse(sql, read="postgres")
    if len(stmts) != 1 or stmts[0].key != "select":
        raise ValueError("Only a single SELECT statement is allowed")
    async with (await pool()).acquire() as conn:
        await conn.execute("SET statement_timeout = '5s'")
        rows = await conn.fetch(f"SELECT * FROM ({sql}) q LIMIT 200")
    return [dict(r) for r in rows]

if __name__ == "__main__":
    mcp.run(transport="streamable-http")      # remote; use "stdio" for local dev
```

Defense in depth: the **DB role itself** is read-only on views. The parser check is an extra layer, not the only control.

## Worked example

**Scenario:** A logistics company's ops staff ask "Which EU shipments are delayed > 48h for customer X?" ~2,000 times/day,
which used to mean an analyst writing SQL.

Design:
- MCP server exposes 6 curated tools (`find_delayed_shipments(region, hours, customer)`, ...) plus a guarded `run_readonly_query` limited to 4 analytics views.
- Postgres **RLS**: the MCP server sets `app.user_region` from the OAuth token, so EU staff can't see US customer rows even with crafted SQL.
- Statement timeout of 5 s plus a read replica keeps the production primary untouched.
- Audit: every tool call logs (user, tool, args hash, row count, latency).

Outcome: 82% of questions answered by curated tools and 18% by guarded SQL. Analyst backlog dropped 70%.
A red-team test found **zero cross-region leaks**, because RLS caught the crafted queries the parser allowed.

## Production deep dive
- **Deploy as a K8s Deployment** behind the MCP gateway (Lab 71), with HPA on request rate and a connection pool sized to DB limits.
- **Identity propagation:** Map the OAuth subject to DB session variables for RLS. Never use one god-mode service account for all users.
- **Query cost control:** `EXPLAIN` with a cost threshold before execution, a dedicated replica, and per-user query quotas.
- **Data classification:** Tag columns (PII, financial). Mask them in results through the proxy (Lab 65) unless the caller holds the scope.
- **Testing:** A contract test suite for tools plus an adversarial suite (SQL injection, prompt injection via data, oversized results).

## FAANG deep-dive notes

- **How big tech does it:** AI data access goes through governed semantic layers or curated APIs, with identity propagation and row-level controls. Raw database access is rare.
- **Staff review questions:** What stops a destructive query? How is user identity propagated? What is the max result size?
- **Interview question:** *"Let an AI assistant answer questions from a production database."* Strong answers cover a read replica, read-only role, RLS, curated tools, SQL validation, timeouts, row limits, and audit.

**Typical system-design prompt:** *"Let analysts ask questions of the sales data warehouse through an AI assistant, without risking data leaks or outages."*

**1. Clarify first:**
- Who are the users, and do row-level permissions already exist in the database?
- Data sensitivity: PII columns, financial data, regional restrictions?
- Load: interactive questions only, or also scheduled reports?

**2. Back-of-envelope sizing:**
- 500 analysts × 30 questions/day × ~2 queries each = 30k queries/day ≈ 1/s average, ~10/s peak. A read replica handles this if queries are bounded.
- One unbounded `SELECT *` on a 2-billion-row table can scan TBs, which is why LIMIT, timeouts, and a separate replica are mandatory.
- Result size: 200 rows × 10 columns ≈ 5–10k tokens. Larger results should become a file or aggregate, not context.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Tool style | free SQL | curated tools (get_revenue_by_region) | curated for common questions, guarded SQL for power users |
| Permissions | in MCP server code | database RLS + roles | database enforces; server adds checks |
| Target | primary DB | read replica / warehouse | never the primary |
| Results | raw rows | aggregates + file links | summarize large results |
| Schema context | dump everything | resource with curated schema + descriptions | curated semantic layer |

**4. Follow-up questions with crisp answers:**
- *Why parse instead of regex?* Comments, nested statements, and dialect tricks defeat regex.
- *Why RLS if the server already checks?* Defence in depth: server bugs or prompt injection can't bypass database rules.
- *How do you stop data exfiltration via the LLM?* Column allow-lists, masking, row caps, and audit with anomaly alerts.
- *Why expose the schema as a resource?* It gives the model accurate table and column descriptions, which reduces wrong queries.
- *What about expensive but valid queries?* Timeouts, cost estimation (EXPLAIN), and per-user query budgets.
- *How do you improve accuracy?* A semantic layer (metric definitions), plus examples of good queries in the prompt.

**Debug this (common onsite question):** *"The assistant answered a question with salary data, though salaries aren't in the allow-list."*
1. The audit log shows a query on a view `v_team_costs`, which is allow-listed.
2. The view joins the HR salary table, so the allow-list checked the view name, not the underlying columns.
3. The database role can read the view, because view permissions run with the owner's rights.
4. Fix: review views as part of the allow-list, use security-invoker views (or RLS on base tables), and add a test suite of forbidden questions run in CI.

The lesson: **allow-lists must cover what data a name exposes, not just the name. Test with forbidden questions.**

**5. What separates senior from staff answers:**
- Senior: builds a parsed, read-only, limited, audited SQL tool.
- Staff: designs the identity mapping into the database, a semantic layer for accuracy, data-classification-aware tools, and red-team test suites for leakage.

**Red flags:** regex SQL filters, shared superuser connections, queries against the primary, raw unbounded results into context.

## Failure modes
- Exposing `execute_sql` with a read-write role means one hallucinated `DELETE` causes data loss.
- Returning 50k rows floods the context window and costs a lot.
- Schema resource out of date, so the model invents columns and errors pile up.

## Checklist
- [ ] MCP server with ≥ 1 curated tool and 1 schema resource
- [ ] Read-only DB role + RLS + timeout + row limit
- [ ] Adversarial test cases pass
