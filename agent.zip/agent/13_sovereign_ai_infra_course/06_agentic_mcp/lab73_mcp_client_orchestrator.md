# Lab 73: The Master Orchestrator — MCP Client Configuration and Prompt Routing (3:51)

## Why it matters
The **host/orchestrator** is where intelligence meets control. It decides which MCP servers a task may use, which
model handles each step, how tool results flow back, and when to stop. Get this layer wrong and agents become slow,
expensive, or unsafe.

## In plain words
The orchestrator is a **project lead with a toolbox**. For each job it hands the worker (LLM) only the tools that job needs, watches the
time and budget, and insists on a real signature (human approval) before anything risky.

## Architecture at a glance

```mermaid
flowchart TB
  T[Task + user] --> RT[Router: intent → profile]
  RT --> TS["Toolset: only allowed MCP servers"]
  TS --> LOOP{LLM step}
  LOOP -->|tool_call| VAL[Validate args] --> MCP[MCP tools/call]
  MCP --> LOOP
  LOOP -->|destructive tool| HIL[Human approval UI]
  LOOP -->|final answer| OUT[Validated answer]
  LOOP -->|budget exceeded| STOP[Stop + report]
```

**How to read it:** A task is routed to a profile that selects the allowed tools. The LLM loop calls validated tools, pauses for human approval on destructive ones, and stops when it finishes or runs out of budget.

## Core concepts

**The agent loop (inside the host)**

```
1. Receive task + user identity
2. Select toolset (which MCP servers/tools are allowed for this user + task)
3. Select model (semantic routing, Lab 46)
4. LLM call with tool schemas ──► tool_calls?
       ├─ yes → validate args (Lab 75) → MCP tools/call → append results → loop (budget check)
       └─ no  → validate final answer → return
```

| Orchestrator concern | Approach |
|---|---|
| **Toolset scoping** | Load only relevant servers per task type. Fewer tools means better accuracy and less context |
| **Dynamic tool discovery** | `tools/list` at session start, and listen for `list_changed` notifications |
| **Model routing per step** | Cheap model for tool selection/extraction, strong model for planning and final synthesis |
| **Budgets** | Max iterations, tokens, tool calls, wall time (Lab 79) |
| **Parallel tool calls** | Independent calls fan out concurrently |
| **Human approval** | Tools tagged `destructive` require confirmation (elicitation) |

## Architecture in depth

The overview shows the router, toolset, and loop. This view shows **one agent loop iteration by iteration**, including the budget
checks that make it stop.

```mermaid
sequenceDiagram
  participant O as Orchestrator
  participant L as LLM
  participant V as Validator + policy
  participant M as MCP servers
  participant H as Human approver
  O->>O: profile "support" → tools: jira.search, kb.search, jira.comment
  O->>L: system + task + 3 tool schemas
  L-->>O: tool_call kb.search
  O->>V: schema ✅ policy ✅
  O->>M: tools/call kb.search
  M-->>O: 5 articles (trimmed to 2k tokens)
  O->>L: results
  L-->>O: tool_call jira.comment (write)
  O->>H: approve comment?
  H-->>O: approved
  O->>M: tools/call jira.comment
  O->>O: steps 3/10, tokens 9k/50k → continue
  L-->>O: final answer → validate → return
```

### Follow one support task through the loop
1. **Profile.** The router maps the task to the "support" profile, which allows only three tools. The model never sees irrelevant or dangerous tools.
2. **First call.** The LLM asks for `kb.search`. Arguments are validated against the schema, and policy confirms the user may use it.
3. **Trim results.** Tool output is cut to a token budget before it goes back to the model.
4. **Write action.** `jira.comment` is a write, so the loop pauses for human approval.
5. **Budgets.** After each step, the orchestrator checks steps, tokens, time, and cost. Any limit reached means stop and report.
6. **Loop detection.** The same tool with the same arguments three times means the agent is stuck, so stop.
7. **Finish.** The final answer is validated (format, citations) before it's returned.

**The one idea to keep:** the orchestrator, not the model, owns control flow: which tools exist, when to pause, and when to stop.

## Minimal hands-on — host config + loop

```json
{
  "mcpServers": {
    "sales-db": { "url": "https://mcp.corp/sales-db/mcp", "auth": "oauth" },
    "jira":     { "url": "https://mcp.corp/jira/mcp",     "auth": "oauth" },
    "docs":     { "command": "docs-mcp", "args": ["--index", "/kb"] }
  },
  "profiles": {
    "support-agent": { "servers": ["jira", "docs"], "model": "llama-70b" },
    "analyst":       { "servers": ["sales-db", "docs"], "model": "qwen-32b" }
  }
}
```

```python
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

async def run_task(task, profile, llm, max_steps=8):
    async with streamablehttp_client(profile.server_url, headers=profile.auth) as (r, w, _):
        async with ClientSession(r, w) as s:
            await s.initialize()
            tools = (await s.list_tools()).tools
            messages = [{"role": "user", "content": task}]
            for _ in range(max_steps):
                resp = llm.chat(messages, tools=[to_openai_schema(t) for t in tools])
                if not resp.tool_calls:
                    return resp.content
                messages.append(resp.message)                         # keep the assistant turn with its tool_calls
                for call in resp.tool_calls:
                    result = await s.call_tool(call.name, call.arguments)
                    messages.append({"role": "tool", "tool_call_id": call.id, "content": render(result)})
            return "Stopped: step budget exhausted"
```

## Worked example

**Scenario:** An IT helpdesk orchestrator with **5 MCP servers / 63 tools** (Jira, Confluence, Okta, ServiceNow CMDB, Slack).

| Version | Tools in context | Tool-selection accuracy | Avg tokens/task | Cost/task |
|---|---|---|---|---|
| v1: all servers always | 63 | 71% | 19k | $0.21 |
| v2: profile-scoped per intent (router first) | 8–14 | 92% | 7k | $0.08 |
| **v3: + small model for tool steps, 70B for final answer** | 8–14 | 93% | 7k | **$0.04** |

The intent router (Lab 46) maps "reset my MFA" to the `identity` profile (Okta + Slack tools only). Okta tools that **write**
(reset MFA) require user confirmation through elicitation, plus a policy check that the user is acting on themselves.

## Production deep dive
- **Stateless orchestrator workers** with state in Redis (Lab 76) scale horizontally behind a queue (Lab 80).
- **Connection management:** Pool MCP sessions per server, set timeouts per tool, and use circuit breakers when a server is down (degrade gracefully: "Jira is unavailable, I created a draft instead").
- **Observability:** OpenTelemetry spans per LLM call and per tool call (GenAI semantic conventions). A trace UI (Langfuse/Phoenix) shows the full reasoning path for debugging and audit.
- **Prompt routing ≠ prompt stuffing:** Keep system prompts stable for KV-cache reuse (Lab 47). Inject tools in a deterministic order.
- **Policy engine:** Externalize "who may call which tool with which args" to OPA/Cedar instead of if-statements in prompts.

## FAANG deep-dive notes

- **How big tech does it:** Agent runtimes enforce tool scoping, budgets, human-in-the-loop for irreversible actions, and full tracing of every step.
- **Staff review questions:** How many tools are in context per task? What enforces the budget? Where does approval come from: a UI event or model text?
- **Interview question:** *"Design an IT helpdesk agent that can reset MFA."* Strong answers cover intent routing, scoped tools, a self-only policy check, user confirmation, an audit trail, and failure handling.

**Typical system-design prompt:** *"Design the orchestrator for an internal agent platform connecting 40 MCP servers for 15 use cases."*

**1. Clarify first:**
- Use cases and risk levels (read-only research vs. actions in production systems).
- Latency expectations: interactive (seconds) or background (minutes)?
- Who defines profiles: platform team or use-case owners?

**2. Back-of-envelope sizing:**
- 40 servers × 10 tools × 300 tokens = 120k tokens of tool schema. Per-profile toolsets of 5–15 tools ≈ 2–5k tokens.
- Accuracy: tool-selection accuracy drops noticeably beyond ~20–30 tools in context, which is another reason for profiles.
- Cost per task: 6 steps × 8k tokens average context ≈ 50k tokens. At 10k tasks/day that's 500M tokens/day, so budget and cache.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Tool exposure | all tools | profile-scoped toolsets | profiles per use case |
| Control flow | free-form ReAct loop | explicit graph + LLM steps | graphs for known workflows; loops for open-ended tasks |
| Writes | auto-execute | human approval / policy | approval for irreversible or external actions |
| Limits | none | steps, tokens, time, cost | all four, per profile |
| Tool selection | model chooses from all | router → retrieval of tools | retrieve tools when the catalog is large |

**4. Follow-up questions with crisp answers:**
- *Why profiles?* Fewer tools mean better tool selection, lower cost, and a smaller attack surface.
- *What's a good stop condition?* A final answer, or any budget exceeded, or loop detection, and always report partial progress.
- *How do you handle tool errors?* Return structured errors to the model with a retry limit, then escalate.
- *Why trim tool outputs?* Large outputs push out instructions and inflate cost. Summarize or paginate.
- *Graph vs. agent loop?* Graphs are predictable and testable. Loops are flexible. Most production flows are mostly graph.
- *How do you test an orchestrator?* Scenario suites with mocked MCP servers, checking tool choices, approvals, and stops.

**Debug this (common onsite question):** *"Agent costs tripled in a week; a few tasks used 2 million tokens each."*
1. Traces show tasks looping: search, read, search with slightly different arguments, read again.
2. Loop detection only matches identical arguments, and the token budget wasn't configured for the new profile.
3. The tool returns full 30-page documents each time, which inflates context.
4. Fix: per-profile token and step budgets as required config, fuzzy loop detection (same tool and similar results), trim tool outputs, and alert on cost per task at p99.

The lesson: **agents fail expensively. Budgets must be mandatory defaults, not optional settings.**

**5. What separates senior from staff answers:**
- Senior: builds a validated tool loop with approvals and limits.
- Staff: designs the profile system, tool retrieval for large catalogs, graph-vs-loop standards, cost governance, and scenario-based testing for the platform.

**Red flags:** every tool in every prompt, no budgets, auto-executed writes, full tool outputs pasted into context.

## Failure modes
- Infinite tool loops (search → no result → search again) without a budget.
- Tool results appended without truncation, so the context overflows on step 4.
- The orchestrator trusts the model's claim "user approved this", when approval must come from a UI event, not text.

## Checklist
- [ ] Profiles scope servers/tools per task type
- [ ] Step/token budgets enforced in the loop
- [ ] Destructive tools gated by real human confirmation
