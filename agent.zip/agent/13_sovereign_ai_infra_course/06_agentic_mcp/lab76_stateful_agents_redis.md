# Lab 76: The Persistence Engine — Stateful Agents with Redis (4:01)

## Why it matters
Agents run multi-step tasks that take seconds to hours. Pods restart, users come back tomorrow, and approvals
arrive asynchronously. Without **externalized state**, every crash means starting over, and horizontal scaling is impossible.

## In plain words
Agents keep a **diary in Redis** after every step. If a worker falls asleep (crashes), any other worker can open the diary and continue
from the last page instead of starting the whole story again.

## Architecture at a glance

```mermaid
flowchart LR
  Q[(Task stream)] --> W1[Worker 1]
  Q --> W2[Worker 2]
  W1 -->|lease + step + checkpoint| R[(Redis: state, leases)]
  W1 -.crash.-x W1
  W2 -->|resume from last checkpoint| R
  WH[Approval webhook] -->|write approval + enqueue resume| R
```

**How to read it:** Workers take tasks from a stream, hold a lease, and checkpoint each step in Redis. If one crashes, another resumes from the checkpoint. Webhooks write approvals and enqueue a resume.

## Core concepts — kinds of agent state

| State | Lifetime | Redis structure | Example |
|---|---|---|---|
| **Session / short-term memory** | Minutes–hours | Hash / JSON with TTL | Conversation turns, scratchpad |
| **Checkpoint** (graph state per step) | Task duration | JSON keyed by `thread:step` | LangGraph `RedisSaver` |
| **Task queue** | Until processed | **Streams** + consumer groups | Pending agent jobs (Lab 80) |
| **Locks / leases** | Seconds | `SET NX PX` | One worker per task |
| **Rate-limit counters** | Seconds–minutes | INCR + TTL / Lua | Token budgets (Lab 79) |
| **Semantic cache** | Hours–days | Vector index (Redis Query Engine) | Reuse answers to similar questions |
| **Long-term memory** | Months | Vector DB / Postgres (not just Redis) | User preferences, facts |

**Key insight:** Make orchestrator workers **stateless**. Any worker can resume any task from the latest checkpoint.

## Architecture in depth

The overview shows workers, leases, and resume. This view follows **one long-running agent task across a crash and a human approval**,
showing exactly what Redis stores at each moment.

```mermaid
sequenceDiagram
  participant Q as Redis Stream tasks
  participant W1 as Worker 1
  participant R as Redis state
  participant W2 as Worker 2
  participant H as Approval webhook
  Q->>W1: task 881 (consumer group)
  W1->>R: SET lease:881 w1 NX PX 30000
  W1->>R: checkpoint step 1 (plan), step 2 (research)
  W1-xW1: crash during step 3
  Note over R: lease expires after 30 s
  Q->>W2: XAUTOCLAIM idle task 881
  W2->>R: acquire lease, load checkpoint (step 2 done)
  W2->>R: step 3 draft → status = awaiting_approval
  W2->>W2: release worker (no busy waiting)
  H->>R: approval for 881 (signed)
  H->>Q: enqueue resume 881
  Q->>W2: resume → step 4 send → done
```

### Follow task 881 from start to finish
1. **Claim.** Worker 1 reads the task from a Redis Stream consumer group, so the task is tracked as pending until acknowledged.
2. **Lease.** It sets a lease key with a 30-second expiry and renews it while working. Only the lease holder may write the task's state.
3. **Checkpoint per step.** After each step, the result and next step are saved. A crash loses at most the current step.
4. **Crash.** Worker 1 dies mid-step. Its lease expires after 30 seconds.
5. **Reclaim.** Worker 2 claims the idle pending message, takes the lease, loads the checkpoint, and continues from step 3, not from scratch.
6. **Wait without holding resources.** Step 3 needs approval, so the state becomes `awaiting_approval` and the worker moves on to other tasks.
7. **Resume.** The approval webhook records the decision and enqueues a resume. Any worker can finish the task.

**The one idea to keep:** agents must be resumable. Store state per step, protect it with leases, and never hold a worker while waiting for humans.

## Minimal hands-on

```python
import json, redis, uuid
r = redis.Redis(host="redis.agents", decode_responses=True)

def checkpoint(thread_id, step, state):
    key = f"agent:{thread_id}:ckpt"
    pipe = r.pipeline()
    pipe.hset(key, mapping={"step": step, "state": json.dumps(state)})
    pipe.expire(key, 7 * 24 * 3600)
    pipe.execute()

def resume(thread_id):
    data = r.hgetall(f"agent:{thread_id}:ckpt")
    return (int(data["step"]), json.loads(data["state"])) if data else (0, {})

def acquire_lease(thread_id, worker, ttl_ms=30_000):
    return r.set(f"agent:{thread_id}:lease", worker, nx=True, px=ttl_ms)    # single active worker

# Worker loop: lease → resume → do one step → checkpoint → renew lease → ...
```

With LangGraph: `from langgraph.checkpoint.redis import RedisSaver` and compile the graph with `checkpointer=RedisSaver(...)`.
Every node transition is persisted, and `graph.invoke(None, config={"thread_id": t})` resumes.

## Worked example

**Scenario:** A KYC (know-your-customer) onboarding agent does document extraction, then sanctions screening, then **waits for a
compliance officer's approval (hours)**, then account creation. It handles 8k onboardings/day.

| Without persistence | With Redis checkpoints |
|---|---|
| Worker holds the task in memory while waiting for approval, so thousands of idle coroutines pile up | Task checkpoints at `awaiting_approval` and the worker is freed |
| Pod restart during deploy loses ~300 in-flight onboardings | Any worker resumes from the last step |
| Approval webhook must find "the right pod" | Webhook writes the approval to Redis and enqueues `resume(thread_id)` on the stream |
| Scale limited by memory per pod | Workers scale on queue depth (KEDA, Lab 80) |

Deploys during business hours became safe. The "lost onboarding" support tickets went from ~40/week to 0.

## Production deep dive
- **HA:** Redis Sentinel or Redis Cluster (or Valkey). Use AOF persistence `everysec` for checkpoints and replicas across zones. Know your failover data-loss window, and keep critical state transitions also in Postgres if you need zero loss.
- **Memory hygiene:** TTLs on everything, size caps on stored state (no 2 MB tool outputs: store blobs in S3 and keep a reference), and monitor `used_memory` and evictions (`noeviction` for state DBs).
- **Security:** Use TLS, ACL users per service, and separate DBs/clusters for cache vs. durable state. State contains user data, so apply PII rules (Lab 65) and residency (Lab 70).
- **Semantic cache caution:** Scope cache keys by tenant + permissions. Otherwise one user's cached answer leaks to another. Lab 60 covers semantic caching in depth.
- **Durable workflows:** For very long or business-critical flows, a workflow engine (Temporal) persists state for you, and Redis remains the fast layer.

## FAANG deep-dive notes

- **How big tech does it:** Durable workflow engines and externalized state let long-running agents survive deploys, crashes, and human wait times.
- **Staff review questions:** What happens on worker crash mid-step? What prevents two workers on one task? Are checkpoints written before side effects?
- **Interview question:** *"Design an agent that waits hours for human approval."* Strong answers cover checkpointing, freeing workers, leases, webhook-driven resume, idempotency, and TTLs.

**Typical system-design prompt:** *"Design the state layer for 100,000 concurrent long-running agent tasks that may wait days for human input."*

**1. Clarify first:**
- Task duration and step count distribution.
- Durability needs: may any state be lost? (Redis persistence vs. a database.)
- Memory types needed: working state, conversation history, long-term user memory.

**2. Back-of-envelope sizing:**
- 100k tasks × ~50 KB state (checkpoints + trimmed history) = 5 GB, comfortable for Redis with replicas.
- Writes: 100k tasks × 1 step/minute ≈ 1,700 writes/s, easy. Lease renewals every 10 s for 10k active ones ≈ 1,000 ops/s.
- Long waits: tasks waiting days shouldn't hold memory forever. Move cold state to PostgreSQL or object storage after 1 hour idle.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Store | Redis only | Redis (hot) + Postgres (durable) | Redis for hot state, a database as the system of record |
| Persistence | none | AOF everysec + replicas | AOF + replicas at minimum |
| Concurrency | locks without expiry | leases with TTL + fencing token | leases with fencing |
| Waiting | worker sleeps | state machine + resume event | event-driven resume |
| Workflow engine | custom | Temporal / durable execution | consider Temporal for complex, long workflows |

**4. Follow-up questions with crisp answers:**
- *Why a lease with TTL?* A crashed worker's lock must expire automatically, or the task is stuck forever.
- *What is a fencing token?* A counter incremented on each lease. Writes with an old token are rejected, which stops a "zombie" worker from overwriting.
- *Why Redis Streams instead of lists?* Consumer groups track pending messages, so unacknowledged work can be reclaimed.
- *What's in a checkpoint?* Step number, step outputs, the next action, and the idempotency keys of side effects done.
- *How do you handle side effects on replay?* Idempotency keys (Lab 75), so redoing a step doesn't redo the action.
- *When use Temporal instead?* Complex multi-day workflows with timers, retries, and versioning needs.

**Debug this (common onsite question):** *"Some agent tasks post the same Slack message twice after worker restarts."*
1. Worker 1 paused for a long garbage-collection pause, and its lease expired.
2. Worker 2 took over and posted the message. Then worker 1 woke up and also posted, with no lease check before the side effect.
3. The checkpoint records "message posted" only *after* posting.
4. Fix: fencing tokens checked before every side effect, an idempotency key on the Slack post (task + step), and the checkpoint records intent before the action and the result after.

The lesson: **leases expire while processes are still alive. Fence your writes and make side effects idempotent.**

**5. What separates senior from staff answers:**
- Senior: streams + consumer groups, leases, per-step checkpoints.
- Staff: designs hot/cold state tiers, fencing, idempotent side effects, and event-driven waits, and knows when to adopt a durable-execution engine.

**Red flags:** locks without TTL, workers sleeping while waiting for humans, Redis without persistence as the only copy, replaying side effects.

## Failure modes
- No lease means two workers process the same task and produce duplicate side effects.
- Eviction policy `allkeys-lru` on the state DB silently drops checkpoints under memory pressure.
- Checkpointing after side effects instead of before (or without idempotency keys) duplicates actions on resume.

## Checklist
- [ ] A worker kill mid-task resumes on another worker
- [ ] Leases + idempotency keys prevent duplicate actions
- [ ] Redis is HA, uses TLS/ACLs, and has TTLs on all keys
