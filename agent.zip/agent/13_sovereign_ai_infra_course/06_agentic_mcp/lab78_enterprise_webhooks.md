# Lab 78: Enterprise Webhook Integrations (Jira, GitHub, Slack) (3:44)

## Why it matters
The most valuable agents aren't chatbots waiting for prompts. They **react to events**: a new Jira incident, a GitHub PR
opened, a Slack message in #support. Webhooks turn agents into teammates embedded in existing workflows.

## In plain words
Webhooks are **doorbells**. Jira, GitHub, or Slack rings, and you must answer quickly ("got it!"), then do the actual work afterwards.
Check that it's really them ringing (signature), and don't let the bot answer its own doorbell forever.

## Core concepts — event-driven agent pattern

```mermaid
sequenceDiagram
  participant SaaS as Jira/GitHub/Slack
  participant WH as Webhook receiver
  participant Q as Queue (Redis Streams/Kafka)
  participant AG as Agent workers
  participant MCP as MCP servers
  SaaS->>WH: POST event (signed)
  WH->>WH: verify signature, dedupe, validate schema
  WH-->>SaaS: 200 OK (< 3 s!)
  WH->>Q: enqueue task
  Q->>AG: consume
  AG->>MCP: read context, act (comment, label, reply)
```

**How to read it:** The provider sends a signed event. The receiver verifies it, dedupes it, acknowledges fast, and enqueues it. Agents consume from the queue and act through MCP.

| Rule | Why |
|---|---|
| **Acknowledge fast** (Slack requires < 3 s; GitHub ~10 s) | Do work asynchronously or the provider retries and duplicates |
| **Verify signatures** | GitHub `X-Hub-Signature-256` (HMAC), Slack signing secret + timestamp, Jira shared secret/JWT |
| **Replay protection** | Reject old timestamps (> 5 min), dedupe by delivery ID |
| **Idempotency** | Providers retry, so the same event may arrive twice |
| **Loop prevention** | Ignore events caused by the bot itself (e.g. its own comments) |
| **Least-privilege app identity** | GitHub App with per-repo installation tokens; Slack bot scopes; Jira service account per project |

## Architecture in depth

The concepts diagram shows the receive-ack-queue pattern. This view shows **the receiver's internal checks in order**, plus the loop
guard that stops the bot reacting to itself.

```mermaid
flowchart TB
  IN["POST /webhooks/github"] --> RAW["Read raw body bytes (before JSON parsing)"]
  RAW --> SIG{"HMAC-SHA256(secret, body) == X-Hub-Signature-256?<br/>constant-time compare"}
  SIG -->|no| R401[401, alert on spikes]
  SIG --> TS{"Timestamp within 5 min? (Slack)"}
  TS -->|no| R401
  TS --> DUP{"Delivery ID seen? (Redis SETNX, TTL 24h)"}
  DUP -->|yes| R200A[200 OK, ignore duplicate]
  DUP --> SCH{"Schema valid? Event type allowed?"}
  SCH -->|no| R200B[200 + log, don't retry]
  SCH --> LOOP{"Actor is our bot?"}
  LOOP -->|yes| R200C[200, ignore]
  LOOP --> ENQ[Enqueue task] --> ACK[200 OK within ms]
```

### Follow one GitHub webhook through the receiver
1. **Raw body first.** The signature is computed over the exact bytes received. Parsing and re-serializing JSON would change them.
2. **Verify signature.** Compute HMAC-SHA256 with the shared secret and compare in constant time. A mismatch means it's not from GitHub.
3. **Freshness.** For Slack, reject timestamps older than 5 minutes, which stops replays of captured requests.
4. **Deduplicate.** Providers retry, so the delivery ID is recorded with a TTL, and repeats get 200 without reprocessing.
5. **Validate.** Unknown event types or malformed payloads are logged and acknowledged, because retrying won't fix them.
6. **Loop guard.** Events caused by the bot itself (its own comment) are ignored, which prevents infinite reply loops.
7. **Enqueue and acknowledge.** The task goes to the queue, and the response returns in milliseconds, well within the provider's timeout.

**The one idea to keep:** a webhook receiver verifies, deduplicates, and acknowledges fast. All real work happens asynchronously behind a queue.

## Minimal hands-on

```python
import hmac, hashlib, time, json
from fastapi import FastAPI, Request, HTTPException

app = FastAPI()

def verify_github(body: bytes, sig: str, secret: bytes):
    expected = "sha256=" + hmac.new(secret, body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, sig or ""):
        raise HTTPException(401, "bad signature")

def verify_slack(body: bytes, ts: str, sig: str, secret: bytes):
    if abs(time.time() - int(ts)) > 300: raise HTTPException(401, "stale")
    base = f"v0:{ts}:{body.decode()}".encode()
    if not hmac.compare_digest("v0=" + hmac.new(secret, base, hashlib.sha256).hexdigest(), sig):
        raise HTTPException(401, "bad signature")

@app.post("/hooks/github")
async def github(req: Request):
    body = await req.body()
    verify_github(body, req.headers.get("X-Hub-Signature-256"), GH_SECRET)
    delivery = req.headers["X-GitHub-Delivery"]
    if not redis.set(f"wh:gh:{delivery}", 1, nx=True, ex=86400):
        return {"ok": "duplicate"}
    evt = json.loads(body)
    if evt.get("sender", {}).get("type") == "Bot": return {"ok": "ignored"}       # loop prevention
    redis.xadd("agent-tasks", {"type": f"github.{req.headers['X-GitHub-Event']}", "payload": body})
    return {"ok": True}
```

## Worked example

**Scenario:** An SRE "incident copilot" across Jira, GitHub, and Slack.

1. **PagerDuty → Jira** creates incident `OPS-4411`, and the Jira webhook enqueues a task.
2. The agent (MCP: Jira, GitHub, Prometheus, Loki) pulls the alert context, the **last 5 merged PRs** to the affected service, and error logs.
3. It posts to the Slack incident channel: suspected cause (PR #2231 changed connection-pool size), relevant graphs, and runbook link.
4. An engineer replies in Slack: "@copilot draft a revert PR". The Slack event triggers the agent, which opens a **draft** PR (it can't merge, by GitHub App permissions) and links it to Jira.

Measured over 3 months: median time-to-first-hypothesis went from 18 min to **4 min**. There were zero unintended actions, because the bot
could only comment, label, and open draft PRs.

## Production deep dive
- **Receiver as a thin, HA service** (3+ replicas, behind an Ingress with an IP allow-list where providers publish ranges). Keep no business logic in it.
- **Secrets:** Webhook secrets and app private keys in Vault/External Secrets, rotated regularly.
- **Back-pressure:** Event storms (mass-label 2,000 issues) shouldn't spawn 2,000 LLM calls. Coalesce or debounce per entity and rate-limit per source (Lab 79).
- **Human-visible actions:** The agent signs its outputs ("🤖 drafted by copilot, trace: ...") with a link to the trace for transparency and audit.
- **Data handling:** Slack and Jira content often contains PII and secrets. Mask it before the LLM (Lab 65) and respect residency (Lab 70).

## FAANG deep-dive notes

- **How big tech does it:** Event-driven bots run with least-privilege app identities, async processing, and visible attribution of every bot action.
- **Staff review questions:** Do you acknowledge within the provider timeout? How are duplicates and self-events handled? What can the bot's token do?
- **Interview question:** *"Build a bot that triages every new GitHub issue."* Strong answers cover webhook verification, fast acknowledgment, a queue, dedupe, loop prevention, least-privilege GitHub App scopes, and rate limits.

**Typical system-design prompt:** *"Build an AI assistant that reacts to GitHub PRs, Jira tickets, and Slack mentions across 2,000 repositories."*

**1. Clarify first:**
- Event volume and burstiness (e.g. monorepo pushes, Slack announcements).
- Which actions can the assistant take (comment, label, open PRs)?
- Identity: GitHub App per org, Slack bot scopes, Jira service accounts?

**2. Back-of-envelope sizing:**
- 2,000 repos × 50 events/day = 100k GitHub events/day, plus Slack/Jira maybe 200k/day total ≈ 3.5/s average, with bursts of 100+/s.
- The receiver is cheap (~1 ms per event). The agent work is expensive (~10–60 s and ~20k tokens), so the queue absorbs bursts.
- Filter early: perhaps only 10% of events need the agent (e.g. PR opened, mention). That cuts LLM cost 10×.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Processing | synchronous in handler | queue + workers | always async |
| Identity | personal access tokens | GitHub App installation tokens | apps with per-repo, short-lived tokens |
| Filtering | agent decides | rule filter before the queue | cheap filters first |
| Delivery | trust provider retries | dedupe + reconciliation polling | dedupe, plus periodic reconciliation for missed events |
| Bot output | post directly | rate-limited + loop guard | rate limits per channel and repo |

**4. Follow-up questions with crisp answers:**
- *Why must the acknowledgement be fast?* Slack expects 3 s, GitHub ~10 s. Slow acks cause retries and duplicates.
- *Why constant-time comparison?* Normal string comparison leaks timing information that can help forge signatures.
- *What if webhooks are lost?* Providers' delivery logs plus periodic reconciliation (poll recent changes) catch gaps.
- *How do you prevent bot loops?* Ignore events from the bot's own identity, and cap replies per thread.
- *Why GitHub Apps over tokens?* Fine-grained per-repo permissions, short-lived tokens, and no dependency on a person's account.
- *How do you handle secret rotation?* Support two active secrets during rotation, and verify against both.

**Debug this (common onsite question):** *"The bot posted 400 comments on one PR overnight."*
1. The bot comments on a PR. GitHub emits an `issue_comment` event for that comment.
2. The loop guard checks the user login `ai-bot`, but GitHub Apps comment as `ai-bot[bot]`, so the check never matched.
3. Each comment triggers the agent again, which comments again.
4. Fix: compare by app ID or sender type, add a per-PR comment cap and a circuit breaker, and test the loop guard with a recorded real event.

The lesson: **any bot that reacts to events must recognise its own events reliably, and have a hard cap as backup.**

**5. What separates senior from staff answers:**
- Senior: verified, deduplicated, async receivers with loop guards.
- Staff: designs the event platform across providers (identity model, filtering, reconciliation, rate limits, secret rotation), with observability per source.

**Red flags:** synchronous LLM calls in handlers, signature checks on parsed JSON, personal tokens, no loop guard or output caps.

## Failure modes
- Doing LLM work inside the webhook request means timeouts, provider retries, and duplicate replies.
- Missing self-event filtering means the bot replies to itself forever.
- An over-scoped GitHub token (org admin) turns a prompt injection in an issue body into repository takeover.

## Checklist
- [ ] Signature verification + replay protection + dedupe
- [ ] Async processing via a queue, with < 1 s acknowledgment
- [ ] Bot permissions reviewed (least privilege, no merge/delete)
