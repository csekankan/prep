# Lab 79: The Governor of the Swarm — Rate Limiting and Token Throttling (4:12)

## Why it matters
Requests per second is the wrong unit for LLMs. One request can cost 50 tokens or 200,000. A single runaway agent loop
can consume an entire GPU pool, or a month's API budget, in an hour. You need governance in **tokens, concurrency, and dollars**.

## In plain words
Every team gets a **water tank that refills at a steady rate** (token bucket). A big request takes a big bucketful. When the tank is empty
you wait. Measuring in tokens instead of requests is like charging per litre instead of per visit to the tap.

## Architecture at a glance

```mermaid
flowchart LR
  REQ["Request: prompt + max_tokens"] --> GW{Gateway: tenant bucket}
  GW -->|enough tokens: reserve| LLM[LLM pool]
  GW -->|empty| R429[429 + Retry-After]
  LLM --> REC[Reconcile actual usage → refund]
  REC --> GW
  ORCH["Orchestrator: per-task budget + loop detector"] --> GW
```

**How to read it:** A request reserves tokens from its tenant's bucket: allowed or 429. After the response, actual usage is reconciled and refunded. The orchestrator adds per-task budgets on top.

## Core concepts

| Limit type | Unit | Protects |
|---|---|---|
| Request rate | req/s per key | API abuse, DDoS |
| **Token rate** | input + output tokens/min per tenant | GPU capacity fairness |
| **Concurrency** | in-flight requests per tenant | KV cache / queue fairness |
| **Budget** | $ or tokens per day/month | Finance |
| **Per-task budget** | tokens, tool calls, steps, wall time per agent task | Runaway loops |
| **Priority tiers** | interactive > batch > background | User-facing latency |

**Algorithms:** *Token bucket* (allows bursts up to capacity, refills at a rate) is the standard. A *sliding window* is smoother, and
*GCRA* is the token bucket's precise cousin. For LLMs, use two-phase accounting:
1. **Reserve** estimated tokens at admission: `prompt_tokens + max_tokens`.
2. **Reconcile** with actual usage after the response and refund the difference.

## Architecture in depth

The overview shows reserve, then reconcile. This view shows the **hierarchy of limits** a single request passes through, because
real platforms throttle at several levels at once.

```mermaid
flowchart TB
  REQ["Request: tenant acme, user anna, task 77<br/>prompt 3k + max_tokens 2k = reserve 5k"] --> G
  subgraph G["Gateway checks (each an atomic Redis Lua call)"]
    L1["(1) Global: platform capacity 2M tokens/min"]
    L2["(2) Tenant acme: 200k tokens/min, 300 req/min"]
    L3["(3) User anna: 20k tokens/min"]
    L4["(4) Task 77 budget: 50k tokens total"]
    L5["(5) Concurrency: acme ≤ 40 in-flight"]
  end
  L1 --> L2 --> L3 --> L4 --> L5
  L5 -->|all pass| LLM[LLM pool]
  G -->|any fails| R429["429 + Retry-After + which limit"]
  LLM --> REC["Actual: 3k + 600 output = 3.6k → refund 1.4k"]
  REC --> G
  PRI["Priority: interactive > batch"] -.-> L1
```

### Follow one request through every limit
1. **Estimate.** The gateway reserves prompt tokens plus `max_tokens`, the worst case, because the real output length isn't known yet.
2. **Global capacity.** The platform-wide bucket reflects what the GPU fleet can actually serve.
3. **Tenant limits.** Each tenant gets tokens per minute and requests per minute according to its contract.
4. **User limits.** No single user or script can use the whole tenant quota.
5. **Task budget.** An agent task has a lifetime token budget, which stops runaway loops (Lab 73).
6. **Concurrency.** In-flight requests are capped, since long generations hold GPU memory even when token rates look fine.
7. **Reconcile.** After the response, actual usage replaces the reservation, and unused tokens are refunded.

**The one idea to keep:** limit tokens (cost and capacity), requests (overhead), and concurrency (GPU memory), at every level from platform to task.

## Minimal hands-on — Redis token bucket (atomic Lua)

```python
LUA = """
local key, rate, cap, now, cost = KEYS[1], tonumber(ARGV[1]), tonumber(ARGV[2]), tonumber(ARGV[3]), tonumber(ARGV[4])
local b = redis.call('HMGET', key, 'tokens', 'ts')
local tokens = tonumber(b[1]) or cap
local ts = tonumber(b[2]) or now
tokens = math.min(cap, tokens + (now - ts) * rate)
if tokens < cost then
  redis.call('HSET', key, 'tokens', tokens, 'ts', now)
  return {0, math.ceil((cost - tokens) / rate)}       -- denied, retry-after seconds
end
redis.call('HSET', key, 'tokens', tokens - cost, 'ts', now)
redis.call('EXPIRE', key, 3600)
return {1, 0}
"""
bucket = r.register_script(LUA)

def admit(tenant, prompt_tokens, max_tokens, tpm=200_000):
    ok, retry = bucket(keys=[f"tb:{tenant}"], args=[tpm / 60, tpm, time.time(), prompt_tokens + max_tokens])
    if not ok:
        raise HTTPException(429, headers={"Retry-After": str(retry)})

def reconcile(tenant, reserved, actual):
    r.hincrbyfloat(f"tb:{tenant}", "tokens", reserved - actual)    # refund unused
```

Gateway-level alternatives: Envoy global rate limit service with descriptors per tenant/model, Envoy AI Gateway token-based limits, Kong/Apigee AI plugins, LiteLLM budgets.

## Worked example

**Scenario:** A shared internal LLM platform: 40 teams on a 70B pool with a capacity of ~1.2M tokens/min.

**Incident:** A team's nightly agent hit a tool error, looped 14,000 times in 50 minutes, used 38M tokens, and pushed p95 TTFT for every other team to 22 s.

Controls added:
| Control | Setting |
|---|---|
| Per-tenant TPM | Default 150k (sum is oversubscribed ~3×, which is fine with a burst bucket) |
| Per-tenant concurrency | 32 in-flight |
| Per-task budget (orchestrator) | 50 steps, 300k tokens, 15 min. Then stop and alert the owner |
| Priority | `interactive` header gets a reserved 40% of capacity; batch is preemptible |
| Loop detector | Same tool + same args 3× in a row stops the task |
| Budget alerts | 80% / 100% of monthly allocation, with Slack to the team and FinOps |

Three months later, two similar loops were stopped at the per-task budget after ~$4 of spend. No cross-team latency incidents.

## Production deep dive
- **Where to enforce:** At the gateway (tenant/model limits), in the orchestrator (per-task budgets), and at the engine (max tokens, max context). Defense in depth.
- **Distributed correctness:** Use atomic Lua or Envoy RLS with Redis Cluster. Local in-memory limiters per pod multiply limits by the replica count.
- **Fairness under saturation:** Weighted fair queuing by tenant at the router (vLLM priority scheduling, Gateway Inference Extension criticality) instead of first-come-first-served.
- **Communicate:** Return `429` with `Retry-After` and rate-limit headers. Clients (and agents!) must honor back-off with jitter.
- **Chargeback:** Token accounting per tenant/model/route feeds showback dashboards (Lab 26). Incentives change behavior.

## FAANG deep-dive notes

- **How big tech does it:** Token-based quotas per customer and model, priority tiers, and fair queuing under saturation. Usage feeds billing directly.
- **Staff review questions:** Is the limit global or per pod? What is the per-task budget? Do clients back off correctly?
- **Interview question:** *"One team's runaway agent took down the shared LLM platform. Prevent it."* Strong answers cover token quotas, concurrency limits, per-task budgets, loop detection, priority tiers, and alerting.

**Typical system-design prompt:** *"Design rate limiting for a multi-tenant LLM platform with 300 tenants, interactive users, and batch agents sharing GPUs."*

**1. Clarify first:**
- Capacity of the fleet (tokens/s) and how contracts are expressed (tokens/month, TPM, RPM).
- Priority: should interactive traffic pre-empt batch?
- Accuracy needs: is a small overshoot acceptable?

**2. Back-of-envelope sizing:**
- Fleet: 40 GPUs × 2,500 output tokens/s ≈ 100k tokens/s ≈ 6M tokens/min of serving capacity.
- Sum of tenant TPM limits can oversubscribe (e.g. 2–3×) because tenants rarely peak together. The global bucket protects the fleet.
- Redis: 2,000 req/s × 5 Lua checks = 10k ops/s, a fraction of one Redis shard. Shard by tenant for headroom.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Unit | requests | tokens (+ requests + concurrency) | tokens primary |
| Algorithm | fixed window | token bucket / GCRA | token bucket for burst tolerance |
| Reservation | count after response | reserve max, refund actual | reserve and refund |
| Overload | queue everything | priority + shed batch first | shed lowest priority first |
| Implementation | per gateway instance | shared Redis (atomic Lua) | shared state for accuracy |

**4. Follow-up questions with crisp answers:**
- *Why tokens rather than requests?* One request may be 100 tokens or 100k. Tokens reflect cost and GPU load.
- *Why reserve `max_tokens`?* To avoid admitting more work than capacity. Refunds fix over-reservation.
- *Why Lua in Redis?* Check-and-decrement must be atomic across many gateway instances.
- *What should a 429 contain?* Retry-After, which limit was hit, and the remaining quota, so clients can back off intelligently.
- *How do you protect interactive users from batch?* Separate buckets and priority, and batch is shed first when the global bucket runs low.
- *What if Redis is down?* Fail to a conservative local limit per instance, never unlimited.

**Debug this (common onsite question):** *"Tenant acme stays under its tokens-per-minute limit, but other tenants see TTFT spike whenever acme's batch job runs."*
1. Acme's job sends 2,000 concurrent requests with `max_tokens` 8k, and the long generations hold GPU KV memory.
2. Token rate per minute is within limit because generation is slow, but concurrency saturates the fleet's KV cache.
3. Other tenants' requests queue behind them.
4. Fix: per-tenant concurrency limits, a lower `max_tokens` cap for batch, a separate batch priority class, and fleet-level KV pressure as a gateway admission signal.

The lesson: **token rate isn't the only scarce resource. Concurrency (KV memory) must be limited too.**

**5. What separates senior from staff answers:**
- Senior: implements an atomic token bucket with reservation and refunds.
- Staff: designs the hierarchy of limits mapped to contracts and fleet capacity, priority classes, oversubscription policy, and failure behaviour of the limiter itself.

**Red flags:** request-only limits, per-instance in-memory counters, no concurrency limits, fail-open limiter.

## Failure modes
- Request-based limits only, so one 200k-token request passes while 200 small ones are blocked.
- Reserving `max_tokens=32k` by default means huge over-reservation and false 429s. Set sane `max_tokens` per route.
- Agents retrying 429s immediately without back-off amplify the overload.

## Checklist
- [ ] Token-based limits per tenant with reserve/reconcile
- [ ] Per-task budgets + loop detection in the orchestrator
- [ ] Priority tiers protecting interactive traffic
