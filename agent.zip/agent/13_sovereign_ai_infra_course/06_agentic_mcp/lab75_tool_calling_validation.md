# Lab 75: Tool Calling at Scale — Validating Output Artifacts (4:03)

## Why it matters
At 1M tool calls per day, a 0.5% malformed-argument rate is **5,000 failures a day**: wrong tickets filed,
bad SQL, broken JSON to downstream systems. LLM outputs are **untrusted input**. Validate them like you would
a public API request.

## In plain words
Treat the AI's output like a **form filled in by a new intern**. First the form only allows valid boxes (constrained decoding). Then a
supervisor checks that the answers make sense (business rules). Then a manager checks that the intern is allowed to do this (authorization).
Only then is it submitted.

## Architecture at a glance

```mermaid
flowchart LR
  LLM[LLM tool call] --> L1{"(1) Schema: constrained decoding"}
  L1 --> L2{"(2) Semantics: Pydantic + business rules"}
  L2 -->|fail| FIX["Repair loop ≤ 2"] --> LLM
  L2 --> L3{"(3) Policy: may this user do this?"}
  L3 -->|deny| ESC[Escalate / refuse]
  L3 -->|allow| EXE["Execute with idempotency key"]
```

**How to read it:** Each tool call passes three gates in order: schema, semantics (with a repair loop), and policy. Only then does it execute, with an idempotency key.

## Core concepts — three layers of output control

| Layer | Mechanism | Guarantees |
|---|---|---|
| **1. Constrained decoding** | Engine forces tokens to match a JSON Schema/grammar (vLLM guided decoding via xgrammar/outlines; `response_format: json_schema`, `strict` tools) | **Syntactically valid** JSON matching the schema |
| **2. Semantic validation** | Pydantic validators, business rules, referential checks (does ticket ID exist? is amount ≤ limit?) | **Meaningful and allowed** |
| **3. Policy / authorization** | OPA/Cedar: may *this user* perform *this action* with *these args*? | **Permitted** |

Then **repair loops**: on validation failure, send the error back to the model once or twice, then fail safe.

**Artifacts to validate:** tool arguments, generated code (lint, typecheck, run tests in a sandbox, Lab 77), SQL (parse + EXPLAIN),
documents (schema, length, citations present), and final answers (grounding, PII scan).

## Architecture in depth

The overview shows the three validation layers. This view looks at **layer 1, constrained decoding**: how the engine makes invalid
JSON impossible, token by token.

```mermaid
flowchart LR
  SCHEMA["JSON schema: {amount: number, currency: EUR or USD}"] --> FSM["Compile to grammar / state machine"]
  FSM --> MASK
  subgraph STEP["Each decode step"]
    LOGITS["Model logits for all 128k tokens"] --> MASK["Mask: only tokens valid in current state"]
    MASK --> SAMPLE[Sample from allowed tokens]
    SAMPLE --> ADV[Advance state machine]
  end
  ADV -->|"not done"| LOGITS
  ADV -->|"closing brace"| OUT["Guaranteed-valid JSON"]
  OUT --> L2["Layer 2: Pydantic semantics (amount ≤ limit?)"]
  L2 --> L3["Layer 3: policy (may this user refund?)"]
```

### Follow one tool call being generated
1. **Compile.** The tool's JSON schema is turned into a grammar, a state machine that knows which characters can come next.
2. **Mask.** At each decoding step, the engine sets the probability of every token that would break the grammar to zero.
3. **Sample.** The model picks among valid tokens only. After `"currency": "`, only `EUR` or `USD` can follow.
4. **Advance.** The state machine moves forward. When the object closes, generation ends.
5. **Guarantee.** The output always parses and always matches the schema's structure. No retries for syntax.
6. **Semantics still matter.** Valid structure doesn't mean a correct value: a refund of 50,000 EUR is valid JSON. Layer 2 checks business rules.
7. **Policy last.** Layer 3 decides whether this user may perform this action at all.

**The one idea to keep:** constrained decoding guarantees *shape*. Only business validation and policy guarantee the *meaning*.

## Minimal hands-on

```python
from pydantic import BaseModel, Field, field_validator, ValidationError
from typing import Literal

class CreateTicket(BaseModel):
    project: Literal["OPS", "SEC", "HR"]
    summary: str = Field(min_length=10, max_length=120)
    priority: Literal["P1", "P2", "P3", "P4"]
    assignee_email: str = Field(pattern=r"^[\w.+-]+@corp\.example$")

    @field_validator("summary")
    @classmethod
    def no_secrets(cls, v):
        if any(k in v.lower() for k in ("password", "api_key", "secret=")):
            raise ValueError("summary must not contain credentials")
        return v

TOOLS = [{"type": "function", "function": {"name": "create_ticket", "strict": True,
          "parameters": CreateTicket.model_json_schema()}}]                    # layer 1

def execute(call, user, max_repairs=2, messages=None):
    for attempt in range(max_repairs + 1):
        try:
            args = CreateTicket.model_validate_json(call.arguments)             # layer 2
            if args.priority == "P1" and not user.can("raise_p1"):              # layer 3
                return {"error": "not authorized for P1"}
            return jira.create(**args.model_dump())
        except ValidationError as e:
            call = ask_model_to_fix(messages, call, e.errors())                  # repair loop
    return {"error": "validation failed after repairs", "escalate": True}
```

## Worked example

**Scenario:** A procurement agent creates purchase orders in SAP. It handles 40k calls/month.

| Stage | Failure rate | What caught it |
|---|---|---|
| Prompt-only ("return JSON") | 3.1% invalid JSON, 1.8% wrong fields | Downstream SAP errors, manual cleanup |
| + constrained decoding (json_schema) | 0% invalid JSON, 1.6% semantic issues | — |
| + Pydantic business rules (vendor exists, currency matches vendor, amount ≤ budget line) | 0.2% after 1 repair | Validator |
| + policy (approval required > €10k) | — | 340 POs/month routed to a human approver |

Result: SAP rejects went from ~1,900/month to **~80/month**, and no unauthorized high-value POs were created. The validator error
metrics also revealed that the vendor master data was stale, which had nothing to do with the LLM.

## Production deep dive
- **Schema design for LLMs:** Use enums over free text, flat over deeply nested, descriptions on every field, and avoid ambiguous optional fields.
- **Engine support:** Guided decoding in vLLM/SGLang/TRT-LLM has a small latency cost. Cache compiled grammars and test with your schemas.
- **Idempotency:** Tool calls with side effects carry an idempotency key (task_id + step), so retries don't create duplicate tickets or orders.
- **Metrics:** Validation failure rate per tool/field/model version, repair success rate, escalation rate. Regressions here often signal a model or prompt change.
- **Output scanning:** Final answers pass groundedness checks (citations map to retrieved docs) and PII/secret scans before reaching users.

## FAANG deep-dive notes

- **How big tech does it:** Structured outputs with constrained decoding, server-side validation, and policy engines in front of any side effect. Validation failure rates are tracked as a model-quality metric.
- **Staff review questions:** What fraction of calls fail validation? What is the repair budget? Are side effects idempotent?
- **Interview question:** *"An agent creates wrong tickets 2% of the time. Fix it."* Strong answers cover constrained decoding, semantic validation, authorization, repair loops, idempotency, and monitoring by field.

**Typical system-design prompt:** *"Agents execute 5 million tool calls a day across payment, CRM, and ticketing systems. Design output validation."*

**1. Clarify first:**
- Which calls have side effects, and which are irreversible (payments)?
- Current failure rate: invalid JSON, wrong values, unauthorized actions?
- Latency budget per call for validation and repair.

**2. Back-of-envelope sizing:**
- Without constrained decoding, 1–3% invalid structure → 50k–150k failures/day, each costing a retry (~1 s, ~2k tokens).
- With constrained decoding, structure failures drop to ~0, while semantic failures (~0.5%) still need the repair loop: ~25k repairs/day.
- Idempotency storage: 5M keys/day × 100 bytes, with a 7-day TTL ≈ 3.5 GB in Redis.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Structure | parse + retry | constrained decoding (xgrammar, Outlines) | constrained wherever the engine supports it |
| Semantics | trust the model | Pydantic + business rules | always validate server-side |
| Repair | unlimited retries | ≤ 2 repairs, then escalate | bounded repair |
| Side effects | execute directly | idempotency keys + approval tiers | idempotent, tiered by risk |
| Validation location | client only | tool server | the tool server is the real enforcement point |

**4. Follow-up questions with crisp answers:**
- *Does constrained decoding hurt quality?* Slightly, sometimes, when schemas force unnatural formats. Keep schemas simple and well-described.
- *Why validate in the tool server too?* Clients can be bypassed or buggy. The server owns its invariants.
- *What is an idempotency key?* A unique ID per intended action, so retries don't double-charge or double-create.
- *What goes in a repair prompt?* The exact validation error and field, not the whole conversation again.
- *How do you tier risk?* Read-only: auto. Reversible writes: auto with audit. Irreversible or high-value: human approval.
- *How do you measure it?* Failure rate per layer and per tool, repair success rate, and escalation rate.

**Debug this (common onsite question):** *"A customer was refunded twice for one complaint."*
1. Traces: the refund tool call timed out at the gateway after 30 s, though the payment system had processed it.
2. The orchestrator retried the call. No idempotency key was sent, so the payment API treated it as a new refund.
3. Validation passed both times, since both calls were valid.
4. Fix: generate an idempotency key per intended action (task ID + step), require it in the refund tool schema, make the payment adapter dedupe on it, and reconcile refunds daily.

The lesson: **validation stops bad calls, and idempotency stops good calls from happening twice. You need both.**

**5. What separates senior from staff answers:**
- Senior: constrained decoding, Pydantic validation, bounded repair, idempotency keys.
- Staff: designs risk-tiered execution policy across all tools, server-side invariants, reconciliation, and per-layer quality metrics for the platform.

**Red flags:** trusting model output for side effects, client-only validation, unlimited retries, no idempotency on payments.

## Failure modes
- Trusting `strict` JSON alone means valid syntax with wrong values (e.g. a real but wrong customer ID).
- Unbounded repair loops burn tokens. Cap them and escalate.
- Validation logic duplicated in prompts and code drifts apart. Generate the schema from one source (the Pydantic model).

## Checklist
- [ ] Tool schema generated from Pydantic and enforced with constrained decoding
- [ ] Semantic + policy validation before side effects
- [ ] Repair loop with a cap, plus an idempotency key
