# Lab 74: Shifting from LangChain to Native Execution Protocols (4:27)

## Why it matters
Frameworks like LangChain accelerated the first wave of LLM apps. At enterprise scale, teams often hit
**abstraction debt**: deep call stacks, hidden prompts, hard-to-debug retries, and version churn. The modern
pattern is **thin orchestration on open protocols** (OpenAI-compatible APIs, MCP, A2A, OpenTelemetry),
using frameworks selectively rather than as the foundation.

> This is not "frameworks are bad". It is: **own the parts that are your competitive and compliance surface**
> (control flow, prompts, state, security), and outsource the commodity parts.

## In plain words
Frameworks are **meal kits**: great for getting started, but you can't see every ingredient. At enterprise scale you want to **cook from
standard ingredients** (OpenAI-compatible API, MCP, OpenTelemetry), so you know exactly what's in the dish and can swap suppliers anytime.

## Architecture at a glance

```mermaid
flowchart LR
  subgraph Before["Framework-first"]
    APP1[App] --> FW["Framework: hidden prompts, wrappers, tools"] --> V1[Vendor SDK]
  end
  subgraph After["Protocol-native"]
    APP2["App: explicit graph + versioned prompts"] --> GW[AI gateway: OpenAI-compatible]
    APP2 --> MCP[MCP servers: shared tools]
    APP2 --> OT[OpenTelemetry traces]
    GW --> ANY["Any model: vLLM / TRT-LLM / API"]
  end
```

**How to read it:** Before: the app hides everything inside a framework. After: the app owns the explicit flow and prompts, and talks to standard interfaces (gateway, MCP, OTel) that work with any model.

## Core concepts

| Layer | Framework-first | Protocol-native |
|---|---|---|
| Model access | Framework LLM wrappers | **OpenAI-compatible HTTP** to your gateway (works with vLLM, TRT-LLM, APIs) |
| Tools | Framework `Tool` classes per app | **MCP servers** shared across apps |
| Agent↔agent | Framework-specific | **A2A protocol** / plain HTTP + queues |
| Control flow | Chains / hidden agent executors | **Explicit state machine/graph** you can read (LangGraph, Temporal, or plain code) |
| Structured output | Output parsers | **JSON Schema / constrained decoding** at the engine (Lab 75) |
| Observability | Framework callbacks | **OpenTelemetry GenAI** semantic conventions |
| Prompts | Embedded templates | **Versioned prompt files** in Git/registry |

## Architecture in depth

The overview contrasts framework-first and protocol-native designs. This view shows the **target layered architecture** and which
layer owns which concern after migration.

```mermaid
flowchart TB
  subgraph App["Application layer (your code)"]
    FLOW["Explicit flow: retrieve → rerank → generate → validate"]
    PR[(Versioned prompts in Git)]
    EVAL[Eval suite in CI]
  end
  subgraph Std["Standard interfaces"]
    API["OpenAI-compatible chat API"]
    MCPI["MCP for tools + context"]
    OTEL["OpenTelemetry GenAI spans"]
  end
  subgraph Plat["Platform layer"]
    GW["AI gateway: auth, quotas, routing, fallbacks"]
    TOOLS["MCP servers owned by system teams"]
    OBS["Tracing backend + dashboards"]
  end
  FLOW --> API --> GW --> MODELS["vLLM / TRT-LLM / external APIs"]
  FLOW --> MCPI --> TOOLS
  FLOW --> OTEL --> OBS
  PR --> FLOW
  EVAL --> FLOW
```

### Follow one RAG request through the new layers
1. **Explicit flow.** The application code shows every step: retrieve, rerank, build prompt, generate, validate. Nothing happens in a hidden chain.
2. **Versioned prompt.** The prompt template comes from Git with a version ID, so changes are reviewed and evaluated like code.
3. **Standard model API.** Generation calls go to the gateway through the OpenAI-compatible API, which routes to on-prem vLLM, TRT-LLM, or an external provider.
4. **Tools via MCP.** Retrieval and actions use MCP servers owned by the system teams, which are reusable by any app or agent.
5. **Traces.** Each step emits OpenTelemetry spans with GenAI attributes (model, tokens, latency), and any backend can show them.
6. **Evals gate changes.** A prompt or model change must pass the eval suite before it ships.

**The one idea to keep:** own your flow and prompts, and depend on standards (model API, MCP, OTel), not on a framework's internals.

## Minimal hands-on — the same RAG step, both ways

Framework-heavy (illustrative):

```python
chain = RetrievalQA.from_chain_type(llm=ChatOpenAI(), retriever=vs.as_retriever(), chain_type="stuff")
answer = chain.run(question)        # prompts, retries, formatting hidden inside
```

Protocol-native (explicit, ~15 lines):

```python
from openai import OpenAI
llm = OpenAI(base_url="https://ai-gw.corp/v1", api_key=TOKEN)
PROMPT = load_prompt("rag_answer@v7")                     # versioned, reviewed

def answer(question, tenant):
    docs = milvus.search("docs_current", embed(question), limit=8, filter=f'tenant=="{tenant}"')
    ctx = "\n\n".join(f"[{d['id']}] {d['text']}" for d in docs)
    with tracer.start_as_current_span("rag.answer") as span:
        r = llm.chat.completions.create(
            model="reason-70b",
            messages=[{"role": "system", "content": PROMPT}, {"role": "user", "content": f"{ctx}\n\nQ: {question}"}],
            response_format={"type": "json_schema", "json_schema": ANSWER_SCHEMA},
            temperature=0.1)
        span.set_attribute("gen_ai.usage.output_tokens", r.usage.completion_tokens)
    return r.choices[0].message.content
```

## Worked example — a migration plan

**Scenario:** An insurer has 14 LangChain apps built in 2023–24. Problems: 3 framework major-version upgrades broke production,
incident debugging took days, and the security team couldn't review hidden prompts.

| Phase | Action | Outcome |
|---|---|---|
| 1. Strangle the edges | All apps call models via the **AI gateway** (OpenAI-compatible) instead of vendor SDKs in the framework | Central auth, quotas, routing; models swappable |
| 2. Extract tools | Re-implement 22 framework tools as **9 MCP servers** | Shared across apps; one security review each |
| 3. Explicit control flow | Replace agent executors with explicit graphs (LangGraph) or Temporal workflows | Deterministic retries, resumability |
| 4. Prompts as artifacts | Move prompts to a registry with eval gates | Reviewable, A/B-testable |
| 5. OTel everywhere | GenAI spans | MTTR from 2 days to 2 hours |

The insurer kept LangChain **document loaders and text splitters**, which are commodity code that works well. Migration ran
app by app with no big-bang rewrite.

## Production deep dive
- **Decision rule:** Use a framework where it saves time without hiding behavior (loaders, eval utilities, graph runtime). Avoid it where it obscures control flow, prompts, or security decisions.
- **Durable execution:** For long-running agents (minutes to days), workflow engines (Temporal, Restate, DBOS) give retries, timers, and exactly-once activities. That is more robust than in-process loops.
- **Interoperability:** MCP (tools/context) + A2A (agent-to-agent) + OpenAI-compatible inference make up a vendor-neutral stack. That is sovereignty at the application layer.
- **Testing:** Plain functions are unit-testable. Record/replay LLM calls for deterministic tests.

## FAANG deep-dive notes

- **How big tech does it:** Thin, explicit orchestration on top of internal standard APIs. Frameworks are used for utilities, not as the core control plane.
- **Staff review questions:** Which behaviours are hidden in the framework? Are prompts versioned and evaluated? Can you swap the model in one config change?
- **Interview question:** *"Should we standardize on an agent framework?"* Strong answers cover owning control flow, prompts, and security, standard protocols, selective framework use, migration via strangler pattern, and testability.

**Typical system-design prompt:** *"Your company has 30 LLM apps built on different frameworks. Design a migration to a maintainable, vendor-neutral architecture."*

**1. Clarify first:**
- Pain points: debugging difficulty, upgrade breakage, vendor lock-in, performance?
- Which apps are business-critical, and which are experiments?
- Team skills and appetite for change.

**2. Back-of-envelope sizing:**
- Framework overhead is usually small in latency (ms), but large in debugging time. One incident caused by a hidden prompt change can cost days.
- Migration effort: a simple RAG app is ~1–2 weeks to make explicit, while complex agents take 4–8 weeks. Prioritize by criticality × pain.
- Gateway consolidation: 30 apps with their own API keys → one gateway gives central quota, audit, and failover.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Framework | full framework | thin libraries + explicit code | thin for production; frameworks for prototypes |
| Orchestration | framework chains | own code or a graph library (LangGraph, etc.) | graph libraries are fine when state is explicit |
| Model access | vendor SDKs | gateway + OpenAI-compatible API | gateway always |
| Tools | framework wrappers | MCP servers | MCP for shared tools |
| Migration | big bang | strangler pattern, app by app | strangler, with evals as a safety net |

**4. Follow-up questions with crisp answers:**
- *Are frameworks bad?* No. They're great for prototyping. The problem is hidden prompts and abstractions in production.
- *Why an OpenAI-compatible API?* Nearly every engine and provider supports it, so switching models becomes a config change.
- *What makes migration safe?* An eval suite capturing current behaviour, then comparing old and new paths on it.
- *Why OTel GenAI conventions?* Standard span attributes make traces portable across observability tools.
- *What stays in a library?* Retries, structured-output parsing, and token counting: small, replaceable utilities.
- *How do you handle framework-specific features (memory, agents)?* Replace them with explicit state (Lab 76) and orchestrators (Lab 73).

**Debug this (common onsite question):** *"After a minor framework upgrade, answer quality dropped and nobody knows why."*
1. Diff the actual prompts sent: the upgrade changed a default system prompt inside a chain class.
2. The app never defined that prompt, so it wasn't versioned or reviewed.
3. No eval suite ran on dependency upgrades.
4. Fix: pin and own all prompts explicitly, log the rendered prompt version with each request, and run the eval suite on every dependency change.

The lesson: **if you don't own the prompt, you don't own the product's behaviour.**

**5. What separates senior from staff answers:**
- Senior: rewrites an app with explicit flow, versioned prompts, and gateway calls.
- Staff: defines the organization's reference architecture, a migration plan by risk, shared MCP and gateway platforms, and eval-gated change management.

**Red flags:** hidden default prompts, vendor SDKs scattered across apps, migrations without eval baselines, a big-bang rewrite.

## Failure modes
- "Rewrite everything" projects that stall. Strangle incrementally instead.
- Replacing a framework with an in-house framework that's worse. Keep the native layer thin.
- Losing features silently in migration (streaming, retries, callbacks). Inventory them first.

## Checklist
- [ ] All model calls go through an OpenAI-compatible gateway
- [ ] At least one framework tool migrated to an MCP server
- [ ] Prompts versioned outside the code with an eval gate
