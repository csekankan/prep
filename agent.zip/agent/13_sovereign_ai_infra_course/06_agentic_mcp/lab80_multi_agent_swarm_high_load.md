# Lab 80: Multi-Agent Swarm Orchestration under High Load (4:06)

## Why it matters
One agent in a demo is easy. **10,000 concurrent agent tasks**, each spawning sub-agents, tool calls, and LLM requests, is a
distributed-systems problem: queues, back-pressure, fan-out control, partial failure, and observability.

## In plain words
A swarm is a **call centre on its busiest day**. You need a queue system (not everyone shouting at once), a cap on how many calls each
supervisor can hand out, and staffing tied to how many phone lines (LLM capacity) you actually have.

## Core concepts

**Multi-agent topologies**

| Pattern | Shape | Use | Load risk |
|---|---|---|---|
| Supervisor / worker | 1 planner → N specialists | Research, report generation | Fan-out explosion |
| Pipeline | A → B → C | Document processing | Slowest stage bottleneck |
| Handoff / swarm | Agents transfer control | Customer support routing | Ping-pong loops |
| Blackboard | Shared state, agents contribute | Complex analysis | Contention |
| Hierarchical | Supervisors of supervisors | Large tasks | Multiplicative cost |

**Load-engineering principles**
1. **Queue everything:** Tasks and sub-tasks go on durable queues (Redis Streams/Kafka/SQS). Agents never call each other synchronously in deep chains.
2. **Bound fan-out:** Max sub-agents per task, max depth, and a global concurrency semaphore per tier.
3. **Back-pressure:** When the LLM pool is saturated (queue depth, 429s), the dispatcher slows intake instead of piling up timeouts.
4. **Autoscale on queue lag** (KEDA), with ceilings tied to the downstream LLM capacity.
5. **Partial results:** If 1 of 8 sub-agents fails, the supervisor proceeds with 7 and notes the gap, rather than failing the whole task.
6. **Cost-aware model mix:** Workers use small models and supervisors/synthesis use large ones (Lab 46).

```mermaid
flowchart LR
  IN[Tasks] --> Q1[(tasks stream)]
  Q1 --> SUP[Supervisors<br/>KEDA: lag]
  SUP -->|≤ 6 subtasks| Q2[(subtasks stream)]
  Q2 --> WK[Worker agents<br/>KEDA: lag, max=f LLM capacity]
  WK --> GW[AI Gateway<br/>token limits, priority]
  GW --> LLM[LLM pools]
  WK --> RES[(results in Redis)]
  RES --> SUP
```

**How to read it:** Tasks enter a stream. Supervisors split them into a bounded number of subtasks on a second stream. Workers, capped by LLM capacity, process them through the gateway and write results back for supervisors.

## Architecture in depth

The concepts diagram shows streams, supervisors, and workers. This view shows **what happens when load exceeds LLM capacity**, the
back-pressure chain that keeps the swarm stable instead of collapsing.

```mermaid
flowchart RL
  LLM["LLM pool saturated<br/>queue depth ↑, TTFT ↑"] -->|"429s / latency"| GW[AI gateway]
  GW -->|"signal: shed batch, slow workers"| WK["Worker agents<br/>semaphore shrinks 40 → 20"]
  WK -->|"subtask lag grows"| Q2[(subtasks stream)]
  Q2 -->|"lag > threshold"| SUP["Supervisors: fewer subtasks per task<br/>6 → 3, prefer cheaper models"]
  SUP -->|"task lag grows"| Q1[(tasks stream)]
  Q1 -->|"lag > SLA"| ADM["Admission: reject or defer new low-priority tasks<br/>with clear ETA"]
  ADM --> USERS[Users / upstream systems]
```

### Follow back-pressure from the GPUs to the users
1. **Saturation.** The LLM pool's queue grows and TTFT rises. The gateway starts returning 429s to low-priority traffic.
2. **Workers slow down.** Worker agents use an adaptive concurrency limit (like TCP congestion control): on 429s and high latency, they halve their in-flight requests.
3. **Subtask backlog grows.** Work waits in the durable stream instead of in timeouts and retries. Nothing is lost.
4. **Supervisors adapt.** Seeing high lag, supervisors fan out less (3 subtasks instead of 6) and route more steps to small models.
5. **Admission control.** If the task backlog exceeds the SLA, new low-priority tasks are deferred or rejected with an ETA. That's honest, instead of silently slow.
6. **Recovery.** As capacity returns, limits grow gradually, which avoids a thundering herd.

**The one idea to keep:** under overload, every layer should slow down and queue durably. Retries and fan-out without back-pressure turn overload into collapse.

## Minimal hands-on — bounded fan-out with a semaphore

```python
import asyncio
GLOBAL_LLM_SLOTS = asyncio.Semaphore(64)          # per worker pod; size from capacity / replicas

async def run_subtask(spec):
    async with GLOBAL_LLM_SLOTS:
        return await worker_agent(spec)            # each worker has its own step/token budget (Lab 79)

async def supervisor(task, max_subtasks=6, deadline_s=120):
    plan = (await plan_subtasks(task))[:max_subtasks]
    results = await asyncio.wait_for(
        asyncio.gather(*(run_subtask(s) for s in plan), return_exceptions=True), timeout=deadline_s)
    ok = [r for r in results if not isinstance(r, Exception)]
    return await synthesize(task, ok, failed=len(results) - len(ok))
```

KEDA autoscaling for workers on Redis Streams lag:

```yaml
triggers:
- type: redis-streams
  metadata: { address: redis.agents:6379, stream: subtasks, consumerGroup: workers, pendingEntriesCount: "20" }
maxReplicaCount: 40        # = LLM pool capacity / per-pod concurrency, NOT unlimited
```

## Worked example

**Scenario:** At quarter-end, an equity-research firm runs a "company brief" swarm for **3,000 companies in 2 hours**. Each brief has
1 supervisor plus 5 workers (financials, news, filings, peers, risks) and averages ~25 LLM calls.

Capacity math:
- 3,000 × 25 = 75k LLM calls in 7,200 s, about **10.4 calls/s average**. With ~3k tokens per call, that is ~31k tokens/s (~1.9M tokens/min).
- Worker calls go to a 32B pool (~1.5M tok/min capacity on 8 replicas), and synthesis goes to the 70B pool.

| Run | Design | Outcome |
|---|---|---|
| 1 | Unbounded `asyncio.gather` across everything | 18k concurrent requests, gateway 429 storm, 31% of tasks failed, retries made it worse |
| 2 | Queues + semaphores + KEDA max tied to capacity + priority `batch` | 99.4% done in 1h52m, interactive users unaffected (priority tiers) |
| 3 | + prefix caching for shared system prompts (Lab 47) + small model for news/peers | Done in **1h21m**, 38% cheaper |

## Production deep dive
- **Chaos testing:** Kill workers, inject LLM 429s/timeouts, and slow down one MCP server. Verify that tasks complete or degrade gracefully and that nothing duplicates side effects (idempotency, Lab 75/76).
- **Observability:** Trace IDs propagate supervisor → subtasks → LLM/tool calls. Dashboards show queue lag per stage, task success rate, tokens per task, and cost per task.
- **Load testing:** Replay realistic task mixes (Locust/k6 with recorded prompts). Agent traffic is bursty and heavy-tailed.
- **Isolation:** Separate queues and quotas for interactive vs. batch swarms, so a quarter-end batch never degrades customer chat.
- **Termination guarantees:** Every task has a deadline. Orphaned subtasks are reaped, and supervisors handle "no response" as a result.

## FAANG deep-dive notes

- **How big tech does it:** Large agent workloads use queue-based orchestration, bounded fan-out, admission control tied to downstream capacity, and chaos testing.
- **Staff review questions:** What caps the fan-out? Is the worker ceiling tied to LLM capacity? What happens if one subtask fails?
- **Interview question:** *"Run 3,000 multi-agent research tasks in 2 hours."* Strong answers do capacity math, queueing, bounded concurrency, priority isolation, partial results, retries at one layer only, and cost estimates.

**Typical system-design prompt:** *"A research-agent product spawns sub-agents per query. Launch traffic is expected to be 20× normal. Design so it degrades gracefully."*

**1. Clarify first:**
- Fan-out per task (sub-agents, depth) and LLM calls per sub-agent.
- LLM capacity (tokens/s) and whether it can burst (spot, external fallback).
- What "graceful" means: slower answers, shallower research, or queued with ETA?

**2. Back-of-envelope sizing:**
- Normal: 5 tasks/s × 6 sub-agents × 8 LLM calls × 3k tokens ≈ 720k tokens/s. 20× = 14.4M tokens/s, far beyond a fleet of ~1M tokens/s.
- Degrade levers: fan-out 6 → 3 halves load, small models for workers cut cost and latency ~5×, and caching repeated sub-queries saves ~20–30%.
- Even with all levers (~10× reduction), 20× traffic needs admission control: queue with an ETA or reject the lowest tier.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Communication | synchronous agent calls | durable queues | queues between tiers |
| Fan-out | fixed | adaptive by load | adaptive, with a hard ceiling |
| Concurrency | static limits | adaptive (AIMD) | adaptive, driven by 429s and latency |
| Overload | retry aggressively | back-off + jitter + shed | exponential back-off with jitter, and shed low priority |
| Failure of sub-agents | fail the task | partial results | partial with gaps noted |

**4. Follow-up questions with crisp answers:**
- *Why queues instead of direct calls?* Queues absorb bursts and survive crashes, and lag becomes a clear scaling signal.
- *What is AIMD?* Additive increase, multiplicative decrease: grow concurrency slowly, and cut it in half on overload.
- *What's a retry storm?* Every layer retries on timeout, multiplying load exactly when capacity is lowest.
- *Why scale workers on lag with a ceiling?* More workers than the LLM capacity only creates more 429s.
- *How do you keep quality when degrading?* Prioritize which sub-agents matter most, and tell users when results are partial.
- *How do you test this?* Load tests at 20× with fault injection (429s, slow LLM), watching for stable lag rather than collapse.

**Debug this (common onsite question):** *"During launch, LLM throughput was saturated, but completed tasks per minute dropped to almost zero."*
1. Workers timed out after 30 s and retried 3 times, and supervisors also retried failed sub-agents, so the load multiplied about 9×.
2. KEDA scaled workers on lag up to 500 pods, far beyond LLM capacity, which created more contention.
3. Most GPU time went to requests that were later abandoned by timeouts.
4. Fix: retry budgets (e.g. ≤ 10% extra traffic), timeouts longer than queue wait, a worker ceiling tied to LLM capacity, adaptive concurrency, and admission control at the front door.

The lesson: **throughput collapses when work is abandoned and retried. Back-pressure and retry budgets keep goodput high.**

**5. What separates senior from staff answers:**
- Senior: queues, bounded fan-out, autoscaling on lag, back-off with jitter.
- Staff: designs end-to-end back-pressure, retry budgets, degradation tiers tied to product decisions, and load tests with fault injection that prove graceful degradation.

**Red flags:** synchronous deep agent chains, unbounded fan-out, scaling workers past LLM capacity, retries at every layer without budgets.

## Failure modes
- Retry storms: each layer retries 3× on top of every other layer, so a single failure becomes 27 calls. Retry at one layer only, with budgets.
- Supervisors waiting synchronously on workers hold resources, so the system deadlocks under load.
- Autoscaling workers beyond LLM capacity just moves the queue to the gateway and adds 429s.

## Checklist
- [ ] Queue-based fan-out with max subtasks/depth
- [ ] Worker autoscaling capped by downstream LLM capacity
- [ ] Chaos test (worker kill + LLM 429s) passes with no duplicates
