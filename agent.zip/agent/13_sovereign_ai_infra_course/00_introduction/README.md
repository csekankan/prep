# Introduction (6:15)

## What "Sovereign AI" means

**Sovereign AI** is the ability of an organization or nation to build, run, and govern AI systems
on infrastructure it controls, with data it controls, under laws it chooses. It has four pillars:

| Pillar | Question it answers | Course sections |
|---|---|---|
| **Compute sovereignty** | Who owns the GPUs, and can they be switched off by someone else? | 2, 3 |
| **Model sovereignty** | Can we train, fine-tune, and serve open-weight models ourselves? | 4, 5 |
| **Data sovereignty** | Where does data live, who can see it, and can we prove it? | 6 |
| **Operational sovereignty** | Can we run it air-gapped, audited, and compliant? | 7, 8 |

## Why Kubernetes is the substrate

Kubernetes has become the operating system of the data center. For AI it gives you:
- **Declarative infrastructure**: GPUs, models, and data pipelines described as versioned YAML.
- **Scheduling**: bin-packing expensive accelerators across many tenants.
- **Portability**: the same manifests run on a laptop (K3s), on-prem (bare metal), or a sovereign cloud.
- **An ecosystem**: operators exist for Ray, Triton, Milvus, Kafka, and almost everything else.

## The mindset shift for the AI era

```
Old skill:  "I can write the Deployment YAML."
New skill:  "I know why this Deployment will OOM at 3 a.m. under batch size 64,
             and which of 5 knobs to turn."
```

Treat AI assistants as junior engineers who type fast. You are the architect who:
1. Frames the constraints (latency SLO, budget, residency law, threat model).
2. Picks the pattern.
3. Reviews the generated config against failure modes.

## Example: why sovereignty is an engineering problem

**Scenario.** A European hospital group wants a clinical-notes assistant.

| Option | What happens | Verdict |
|---|---|---|
| Public LLM API (US region) | Patient notes leave the EU, so GDPR Art. 44 transfer risk and the AI Act "high-risk" tier both apply | Blocked by legal |
| Public API in an EU region | Better, but the vendor can still change the model, terms, or pricing overnight | Strategic risk |
| **Self-hosted open model on K8s in their own DC** | Data never leaves, the model version is pinned, every inference is audited | **Chosen** |

The sizing math turns that choice into a concrete design:
- 3,000 clinicians × 20 requests/day ≈ 60k requests/day ≈ **~3 req/s at peak** (assuming 4× peak/avg).
- A 70B model in FP8 on 2× H100 with vLLM handles ~20–40 req/s at moderate context.
- So **2 replicas (4 GPUs) plus 1 standby** meets the load with N+1 HA.

The rest of the course teaches how to build, operate, and prove the compliance of that system.

## Course outcome

By the capstone (Lab 100) you will be able to design an **enterprise-grade, multi-region,
compliance-aware AI platform** that can:
- Train billion-parameter models across GPU nodes
- Serve many models and LoRA adapters with autoscaling
- Run real-time RAG over sovereign data
- Host governed agent swarms through MCP
- Operate air-gapped when required

## How to study

1. Read the **Core concepts** block and draw the architecture yourself.
2. Run the **Minimal hands-on**, or ask an assistant to expand it.
3. Spend most of your time on the **Production deep dive** and **Failure modes** blocks. That is where seniority shows.
