# Lab 28: Spot Instance Fleets — Cost-Effective Node Provisioning (3:28)

## Why it matters
Spot/preemptible GPUs cost **60–90% less** but can vanish with 30 s to 2 min notice. Used well,
they can halve your compute bill. Used naively, they cause outages and lost training runs.

## In plain words
Spot instances are **standby airline tickets**: very cheap, but you can be bumped with two minutes' notice. Great for work that
can pause and resume (batch jobs). Bad for work that must never stop (live chat), so keep that on regular tickets.

## Architecture at a glance

```mermaid
flowchart LR
  BASE["On-demand / reserved<br/>baseline p50 load"] --> SVC[Inference service]
  SPOT["Spot pool<br/>many types × zones"] --> SVC
  SPOT --> BATCH[Batch / embeddings]
  N[Interruption notice] --> DR[Cordon + drain]
  DR --> CK["SIGTERM → checkpoint / finish"]
  CK --> RQ[Requeue work]
```

**How to read it:** The baseline (on-demand) and burst (spot) pools both feed the service. Follow an interruption: notice, drain, checkpoint, requeue. Work resumes elsewhere.

## Core concepts

| Workload | Spot-friendly? | Why |
|---|---|---|
| Batch inference / embeddings backfill | ✅ Excellent | Idempotent, retryable |
| Hyperparameter sweeps | ✅ | Independent trials |
| Distributed training | ⚠️ With frequent checkpoints | One lost node stalls the whole gang |
| Online inference (baseline) | ❌ | Keep on-demand/reserved |
| Online inference (burst) | ✅ | Overflow capacity above the baseline |

**Diversification:** Request *many* instance types and zones (H100, A100, L40S across 3 AZs).
Spot capacity is per pool, so a single-type request fails often.

**Interruption handling:** Node termination handler / Karpenter receives the notice, cordons and drains the node,
the pod gets SIGTERM, and the app checkpoints or finishes in-flight requests.

## Architecture in depth

The overview shows baseline and burst pools. This view follows **one spot interruption end to end**, showing which component reacts
at each second of the warning window.

```mermaid
sequenceDiagram
  participant CP as Cloud provider
  participant K as Karpenter / NTH
  participant N as Spot node
  participant P as Batch worker pod
  participant Q as Kafka / queue
  participant R as Replacement node
  CP->>K: Interruption notice (T-120s)
  K->>N: Cordon (no new pods)
  K->>R: Launch replacement (diversified type)
  K->>P: Drain → SIGTERM
  P->>P: Finish in-flight batch or checkpoint
  P->>Q: Commit offsets only for completed work
  P-->>K: Exit (before T-0)
  CP->>N: Terminate (T-0)
  R->>Q: New worker resumes uncommitted offsets
```

### Follow one interruption second by second
1. **T−120 s: notice.** The cloud sends an interruption warning. Karpenter (or the node termination handler) receives it.
2. **Cordon.** The node is marked unschedulable, so no new pods land there.
3. **Replace early.** A replacement node is requested immediately, from a *different* instance pool, because the same pool is likely being reclaimed.
4. **Drain.** Pods get SIGTERM with their grace period. Batch workers stop pulling new work.
5. **Save progress.** Workers finish the current batch or checkpoint, then commit only completed work to the queue.
6. **Exit cleanly** before T−0. Anything uncommitted stays in the queue.
7. **Resume.** Workers on the replacement node consume the uncommitted offsets. With idempotent writes, nothing is lost or duplicated.

**The one idea to keep:** spot is safe when work is small, committed after completion, and idempotent. The interruption becomes a normal event.

## Minimal hands-on

```yaml
# Pod spec for a spot-tolerant batch worker
tolerations:
- { key: karpenter.sh/capacity-type, value: spot, effect: NoSchedule }
nodeSelector: { karpenter.sh/capacity-type: spot }
terminationGracePeriodSeconds: 90
```

```python
import signal, sys
def on_sigterm(*_):
    save_checkpoint("s3://ckpt/run-42/latest")   # see Lab 39
    sys.exit(0)
signal.signal(signal.SIGTERM, on_sigterm)
```

## Worked example

**Scenario:** A legal-tech firm must embed **2 billion document chunks** one time.

| Plan | Hardware | Time | Cost |
|---|---|---|---|
| On-demand | 32× L40S | 3.5 days | ~$54k |
| **Spot, diversified (L40S/A10G/L4, 3 AZs)** | 32–48 mixed | 4 days (2–3 interruptions/hour absorbed) | **~$14k** |

Design: chunk IDs flow through a Kafka topic (Lab 63) and are committed **after** the vector write.
An interrupted worker's uncommitted offsets get re-consumed by others, so nothing is lost and nothing is duplicated
(writes use idempotent upserts by chunk hash).

## Production deep dive
- **Baseline + burst:** Run reserved/on-demand capacity at the p50 load and spot above it. Use a Karpenter `weight` to prefer spot for burst NodePools.
- **PodDisruptionBudgets** protect inference from drains. Spot drains still happen, so keep enough on-demand replicas to cover the SLO.
- **On-prem analogue:** "Scavenger" priority. Low-priority jobs use idle reserved GPUs and are preempted by production (Lab 25). It is the same design pattern with no cloud bill.
- **Capacity blocks / reservations:** For big training runs, reserve capacity (AWS Capacity Blocks, GCP DWS). Spot is rarely available for 512 H100s at once.
- **Price/availability monitoring:** Track interruption rates per instance type and drop the flaky pools.

## FAANG deep-dive notes

- **How big tech does it:** Internal "free tier" or preemptible capacity runs batch work on idle production hardware, with strict preemption semantics. Batch frameworks are designed to be interrupted.
- **Staff review questions:** What percentage of each workload can tolerate preemption? How much progress is lost per interruption? How diversified is the spot request?
- **Interview question:** *"Run a 2-billion-document embedding job as cheaply as possible."* Strong answers cover spot diversification, idempotent writes, queue-based work distribution, commit-after-write, and expected-interruption math.

**Typical system-design prompt:** *"Cut the GPU bill for batch inference by 60% without missing the nightly deadline."*

**1. Clarify first:**
- Job size and deadline (e.g. 50M documents by 6 a.m.).
- Can work be split into small idempotent units?
- Instance types acceptable (GPU memory floor) and regions/zones.

**2. Back-of-envelope sizing:**
- 50M docs at 2,000 docs/s per GPU = 25,000 GPU-seconds ≈ 7 GPU-hours. With a 6-hour window, that needs ~2 GPUs; plan 4 for safety.
- Interruptions: at 5% per hour per instance and 30 s lost per interruption (small batches), the overhead is under 1%.
- Spot at 70% discount: 7 GPU-hours × $3 on-demand = $21 vs. ~$6.3 on spot. At 1,000 such jobs per month, that's ~$15k saved.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Capacity | single instance type | diversified types × zones | ≥ 4 types and ≥ 2 zones |
| Online inference | all spot | on-demand baseline + spot burst | baseline on-demand at p50, spot above |
| Training | spot | reserved / capacity blocks | spot only with frequent checkpoints; large runs need reservations |
| Work unit | big batches | small batches + commit | small enough to lose without pain |

**4. Follow-up questions with crisp answers:**
- *Why diversify instance types?* Spot capacity is per pool. One type in one zone often has none.
- *What makes a workload spot-friendly?* Idempotent, retryable, checkpointable, and not latency-critical.
- *How do you avoid duplicates after interruption?* Commit after write, and use idempotent upserts keyed by content hash.
- *Why not spot for all inference?* Correlated reclaim can remove most capacity at once, causing an outage.
- *What's the on-prem equivalent?* A preemptible "scavenger" priority tier using idle reserved GPUs.
- *How do you protect the deadline?* Fall back to on-demand automatically when progress falls behind the schedule.

**Debug this (common onsite question):** *"The nightly embedding job on spot finished on time for months, then missed its deadline 3 nights in a row."*
1. Interruption rate for the main instance type tripled. A new large customer is using that pool.
2. Replacement requests kept landing in the same type because the NodePool list had only 2 types.
3. Each replacement took 8 minutes, so effective capacity fell 40%.
4. Fix: add 4 more instance types, enable an on-demand fallback when progress is behind schedule, and alert on interruption rate per pool.

The lesson: **spot capacity changes over time. Diversify and add a deadline-aware fallback.**

**5. What separates senior from staff answers:**
- Senior: SIGTERM handling, tolerations, diversified types.
- Staff: models interruption cost vs. savings, designs deadline-aware fallback, keeps on-demand baselines for SLO-bound services, and tracks pool reliability over time.

**Red flags:** single-type spot pools, no SIGTERM handling, online inference entirely on spot, commit-before-work.

## Failure modes
- A single instance type means "InsufficientCapacity" and nothing scales.
- No SIGTERM handler means an hour of progress lost per interruption.
- Spot for all inference means a regional spot reclaim causes a total outage.

## Checklist
- [ ] Workloads are classified for spot suitability
- [ ] The SIGTERM checkpoint path has been tested
- [ ] The diversified instance list has ≥ 4 types and ≥ 2 zones
