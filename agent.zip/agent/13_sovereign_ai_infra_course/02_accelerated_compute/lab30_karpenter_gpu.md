# Lab 30: Karpenter — Just-in-Time GPU Node Provisioning (3:37)

## Why it matters
The classic Cluster Autoscaler scales **pre-defined node groups**: you need one group per GPU type
per zone, and they're slow. **Karpenter** reads pending pods' requirements and launches the
**cheapest fitting instance** directly, typically in 60–90 s.

## In plain words
The old way was renting buses of fixed sizes in advance (node groups). Karpenter is a **ride-hailing app**: it sees exactly how many
passengers are waiting and what they need, then orders the cheapest vehicle that fits, right now. When rides end, the vehicle goes away.

## Core concepts

| Object | Role |
|---|---|
| `NodePool` | Constraints: allowed instance families, capacity types, taints, limits, disruption policy |
| `EC2NodeClass` (or provider equivalent) | AMI, subnets, security groups, disk |
| Consolidation | Repacks pods and removes under-used nodes |
| Disruption budgets | How many nodes can be removed at once |

```mermaid
flowchart LR
  HPA -->|+2 pods| P[Pending pods<br/>nvidia.com/gpu: 1]
  P --> K[Karpenter]
  K -->|bin-pack + price| C[Launch g6e.xlarge spot in AZ-b]
  C --> N[Node Ready → pods bind]
```

**How to read it:** Follow a pending pod: Karpenter reads its requirements, picks the cheapest instance that fits, and launches it. The pod binds once the node is ready. Consolidation removes nodes later.

## Architecture in depth

The overview shows a pending pod triggering a node. This view shows **Karpenter's decision loop**: how it picks an instance, and
how disruption (consolidation and drift) removes nodes safely later.

```mermaid
flowchart TB
  PP["Pending pods<br/>gpu: 1, mem: 64Gi, zone any"] --> BATCH[Batch window ~10s]
  BATCH --> REQ[Merge requirements: NodePool + pod constraints]
  REQ --> OPTS["Candidate instance types<br/>g6e, g5, p5 × spot/on-demand × zones"]
  OPTS --> PRICE[Cheapest that fits all pods]
  PRICE --> LAUNCH[Launch NodeClaim]
  LAUNCH --> JOIN[Node joins → GPU stack validates → pods bind]
  subgraph Disruption["Later: disruption controller"]
    EMPTY[Empty node > consolidateAfter] --> DEL[Delete]
    UNDER[Underutilized node] --> REPACK[Repack pods if budgets allow]
    DRIFT[AMI / config drift] --> ROLL[Replace node]
  end
  JOIN --> Disruption
  BUD[Disruption budgets + PDBs] -.limit.-> Disruption
```

### Follow one scale-up and one scale-down
1. **Batch.** Karpenter waits a few seconds to collect several pending pods, so it can pack them onto fewer nodes.
2. **Constraints.** It merges the NodePool's allowed types, capacity types, and taints with each pod's requirements (GPU count, memory, zone, tolerations).
3. **Choose.** From all instance types that satisfy everything, it picks the cheapest combination, preferring spot when allowed.
4. **Launch.** A NodeClaim creates the instance. The node joins, the GPU stack validates (Lab 21), and pods bind.
5. **Scale-down.** When a node has been empty longer than `consolidateAfter`, it's deleted.
6. **Repacking.** With `WhenEmptyOrUnderutilized`, Karpenter may evict pods to pack them onto fewer nodes, respecting PDBs and disruption budgets.
7. **Drift.** If the node image or config changes, Karpenter replaces nodes gradually, which is how new GPU AMIs roll out.

**The one idea to keep:** Karpenter is fast at adding nodes, and the disruption settings decide whether it is safe at removing them.

## Minimal hands-on

```yaml
apiVersion: karpenter.sh/v1
kind: NodePool
metadata: { name: gpu-inference }
spec:
  template:
    spec:
      requirements:
      - { key: karpenter.k8s.aws/instance-family, operator: In, values: [g6e, g5, p5] }
      - { key: karpenter.sh/capacity-type, operator: In, values: [on-demand, spot] }
      taints: [{ key: nvidia.com/gpu, effect: NoSchedule }]
      nodeClassRef: { group: karpenter.k8s.aws, kind: EC2NodeClass, name: gpu }
  limits: { nvidia.com/gpu: 64 }                 # hard spend cap
  disruption:
    consolidationPolicy: WhenEmpty               # don't evict live inference to save $
    consolidateAfter: 10m
```

## Worked example

**Scenario:** A marketing-AI startup generates images and copy with heavy bursts during campaigns.

| Metric | Cluster Autoscaler (3 fixed groups) | Karpenter |
|---|---|---|
| Node groups to maintain | 9 (3 GPU types × 3 AZs) | 1 NodePool |
| Time pending → running | 4–7 min | 70–100 s |
| Avg idle GPU nodes overnight | 3 | 0 (consolidation) |
| Monthly GPU bill | $41k | **$26k** |

The key settings were `WhenEmpty` consolidation for inference (never evict a live model to save a
few dollars) and `WhenEmptyOrUnderutilized` for the batch pool.

## Production deep dive
- **On-prem/sovereign equivalents:** Karpenter is cloud-native. On bare metal, use the Cluster API + Metal3 autoscaler, or simply treat the fixed fleet as a pool with Kueue queueing (Lab 26). Elasticity there comes from *workload* preemption, not node creation.
- **Large GPU nodes:** p5 (8×H100) nodes launch slowly and are capacity-constrained. Use capacity reservations / ODCRs referenced in the NodeClass.
- **AMIs:** Pin a GPU AMI version with drivers baked in (Lab 21). Roll it forward with Karpenter **drift** detection.
- **Spend guardrails:** `limits` per NodePool plus budget alerts. A runaway HPA should hit a ceiling, not your CFO.
- **Disruption windows:** Schedule node replacement (`budgets` with schedule) outside business hours.

## FAANG deep-dive notes

- **How big tech does it:** Node provisioning is demand-driven with spend caps per organization. Large GPU capacity is reserved in advance, and elasticity comes mostly from workload preemption, not new hardware.
- **Staff review questions:** What is the spend ceiling? Will consolidation ever evict live inference? How does provisioning behave when capacity is unavailable?
- **Interview question:** *"Compare Cluster Autoscaler and Karpenter for GPU workloads."* Strong answers cover node groups vs. direct provisioning, instance flexibility, speed, consolidation risks, and capacity reservations for large GPUs.

**Typical system-design prompt:** *"Design node provisioning for a GPU platform with bursty inference, nightly batch, and a hard monthly budget."*

**1. Clarify first:**
- Budget ceiling and who gets cut first when it's reached.
- Acceptable time from pending to running for each workload class.
- Large-GPU availability (are capacity reservations needed for 8-GPU nodes?).

**2. Back-of-envelope sizing:**
- Budget $200k/month at ~$4/GPU-hour ≈ 50,000 GPU-hours ≈ 69 GPUs on average. Set NodePool limits so the sum of max GPUs × hours stays under budget.
- Pending → running: node launch 60–90 s + GPU validation 30–60 s + model load. Inference needs warm spares if the SLO is under 3 minutes.
- Consolidation savings: if night traffic is 25% of peak, removing idle nodes saves ~40% of the inference bill.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Autoscaler | Cluster Autoscaler (node groups) | Karpenter (direct) | Karpenter for many GPU types; CA where Karpenter isn't supported |
| Inference consolidation | WhenEmptyOrUnderutilized | WhenEmpty | WhenEmpty for inference; underutilized for batch |
| Big GPUs | on-demand at launch | capacity reservations | reserve 8-GPU nodes for training |
| Spend control | alerts only | NodePool limits + alerts | hard limits plus alerts |
| On-prem | node autoscaling | fixed fleet + Kueue preemption | elasticity from workloads when hardware is fixed |

**4. Follow-up questions with crisp answers:**
- *Why is Karpenter faster than Cluster Autoscaler?* It calls the cloud API directly for the right instance, instead of resizing a pre-defined node group.
- *What's the risk of consolidation for inference?* Evicting a model server forces a multi-minute reload, causing latency spikes.
- *How do NodePool limits work?* They cap total resources (e.g. GPUs) the pool can provision.
- *What is drift?* The node no longer matches the desired NodeClass (new AMI), so Karpenter replaces it.
- *Why taint GPU NodePools?* Without a taint, any pod can trigger an expensive GPU node.
- *What happens when capacity is unavailable?* Karpenter tries other allowed types and zones. Diversification decides whether it succeeds.

**Debug this (common onsite question):** *"Inference latency spikes every 15 minutes, and the pattern started after enabling Karpenter."*
1. Correlate with Karpenter events: consolidation evicts inference pods to repack nodes.
2. Each eviction forces a model reload of ~90 s on another node.
3. The NodePool uses `WhenEmptyOrUnderutilized` with a short `consolidateAfter`.
4. Fix: a separate inference NodePool with `WhenEmpty`, PDBs on inference Deployments, and disruption budgets limited to off-peak windows.

The lesson: **consolidation saves money by moving pods. Some pods are very expensive to move.**

**5. What separates senior from staff answers:**
- Senior: writes NodePools with taints, limits, and instance diversity.
- Staff: maps workload classes to disruption policies, ties limits to budget, plans reservations for large GPUs, and measures end-to-end provisioning latency.

**Red flags:** one NodePool for all workloads, aggressive consolidation on inference, no limits, untainted GPU pools.

## Failure modes
- No GPU taint on the NodePool lets random pods trigger an 8-GPU node.
- Aggressive consolidation evicts inference pods every few minutes and causes model reload storms.
- No `limits`, so a misconfigured job scales to 200 GPUs over a weekend.

## Checklist
- [ ] A GPU NodePool exists with a taint, limits, and a conservative disruption policy
- [ ] Pending → Ready time is measured
- [ ] Consolidation behavior is tested against inference SLOs
