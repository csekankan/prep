# Lab 29: Horizontal Pod Autoscaling (HPA) via Custom Metrics (3:54)

## Why it matters
CPU% is meaningless for GPU inference: the CPU sits idle while the GPU is saturated. You need
to scale on **what users feel**, which means queue depth, KV-cache pressure, and latency.

## In plain words
Don't hire more cashiers based on how warm the store is (CPU%). Hire based on **how long the checkout line is** (requests waiting).
That's autoscaling on custom metrics.

## Core concepts

```mermaid
flowchart LR
  V[vLLM /metrics] --> P[Prometheus]
  P --> A[Prometheus Adapter<br/>or KEDA]
  A -->|custom.metrics.k8s.io| H[HPA]
  H -->|replicas| D[Deployment]
```

**How to read it:** vLLM exposes metrics, Prometheus scrapes them, and an adapter (or KEDA) turns them into a metric the HPA understands. The HPA then changes the Deployment's replica count.

| Signal | Good for | Caveat |
|---|---|---|
| `vllm:num_requests_waiting` | **Primary scale-out signal** | Lags slightly |
| `vllm:gpu_cache_usage_perc` | Memory saturation | High values are normal under good batching |
| TTFT p95 | SLO-aligned | Noisy at low traffic |
| Tokens/s per replica | Throughput planning | Depends on prompt mix |
| DCGM util | Avoid for scaling | Saturates early |

**KEDA vs. HPA + Adapter:** KEDA is simpler (a Prometheus scaler built in) and supports **scale-to-zero**. HPA + Adapter is the native route.

## Architecture in depth

The overview shows the metrics path to the HPA. This view shows the **full scaling loop with its delays**, because the delays,
not the formula, decide whether users see errors during a spike.

```mermaid
flowchart LR
  T[Traffic spike] --> Q["vLLM queue grows<br/>num_requests_waiting"]
  Q -->|"scrape 15s"| P[(Prometheus)]
  P -->|"poll 15-30s"| K[KEDA / HPA]
  K -->|"desired = ceil(metric / target)"| D[Deployment replicas +2]
  D --> PEND[Pods Pending]
  PEND -->|"free GPU node: ~0s"| START
  PEND -->|"no node: 60-300s"| KARP[Karpenter new node] --> START
  START["Pod starting<br/>model load 30s-6min"] --> READY[Ready → receives traffic]
  CRON["Cron trigger<br/>pre-scale at 08:45"] -.-> K
```

### Follow one spike from first queued request to relief
1. **Queue grows.** Requests wait in vLLM because KV memory or batch slots are full.
2. **Metric lag.** Prometheus scrapes every ~15 s, and KEDA polls every ~15–30 s, so up to 45 s pass before the scaler reacts.
3. **Decision.** Desired replicas = ceil(total waiting ÷ target per replica), within min/max bounds.
4. **Pods pending.** If a GPU node has room, scheduling is instant. If not, a new node takes 1–5 minutes.
5. **Model load.** Weights load in 30 s (node cache) to 6 minutes (cold download). This is usually the largest delay.
6. **Ready.** Only after the readiness probe passes do new replicas receive traffic, and load-aware routing (Lab 49) must actually send it to them.
7. **Pre-scaling.** For predictable peaks, a cron trigger scales before the spike, so the delays above happen before users arrive.

**The one idea to keep:** autoscaling latency = metric lag + node provisioning + model load. Shrink each one, or pre-scale.

## Minimal hands-on (KEDA)

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata: { name: vllm, namespace: ai }
spec:
  scaleTargetRef: { name: vllm }
  minReplicaCount: 2
  maxReplicaCount: 12
  cooldownPeriod: 600              # GPUs are slow to start; don't flap
  triggers:
  - type: prometheus
    metadata:
      serverAddress: http://prometheus.monitoring:9090
      query: sum(vllm:num_requests_waiting{namespace="ai"})
      threshold: "5"               # target ≤5 waiting per replica
```

## Worked example

**Scenario:** A customer-support copilot. Traffic is 40 req/s at 9 a.m. and 4 req/s at 3 a.m.
Each replica (70B FP8 on 2× H100) handles ~10 req/s within SLO.

- Static sizing for peak: 4 replicas × 24h = 192 GPU-hours/day.
- With HPA on queue depth (min 1, max 5): average ~2.1 replicas = **~100 GPU-hours/day**, a **48% saving**.
- **Cold-start problem:** A new replica needs 90 s (node already present) or 6 min (new node).
  Mitigations: keep 1 warm spare (`minReplicas = expected + 1`), schedule pre-scaling before 9 a.m. (a KEDA cron trigger), and speed up loading (Lab 7).

## Production deep dive
- **Scale-up fast, scale-down slow:** `behavior.scaleUp.stabilizationWindowSeconds: 0` and `scaleDown: 600+`.
- **Combine triggers:** queue depth OR TTFT p95 > SLO OR cron baseline. KEDA takes the max across them.
- **Scale-to-zero** suits long-tail models (dozens of fine-tunes used rarely). Pair it with a request-buffering activator (KServe/Knative) so the first request waits instead of failing.
- **Interaction with Karpenter:** HPA creates pods, pending pods trigger Karpenter (Lab 30), and the node comes up. Measure the *end-to-end* scale latency.
- **Load-aware routing (Lab 6/49)** must accompany autoscaling. Otherwise new replicas sit idle while old ones queue.

## FAANG deep-dive notes

- **How big tech does it:** Autoscaling for inference uses predictive (forecast-based) plus reactive signals, with warm pools to hide multi-minute model load times.
- **Staff review questions:** What is the end-to-end scale-up latency? What prevents flapping? What happens when the scale-up hits the GPU ceiling?
- **Interview question:** *"Design autoscaling for an LLM service with 5-minute cold starts and spiky traffic."* Strong answers cover queue-depth signals, predictive pre-scaling, warm spares, asymmetric stabilization windows, faster loading, and load shedding at the gateway.

**Typical system-design prompt:** *"Design autoscaling for an LLM API with 10× daily traffic swings and occasional 3× surprise spikes."*

**1. Clarify first:**
- SLO under spikes (e.g. TTFT p95 < 2 s during the first 5 minutes of a spike).
- Cold-start time per replica (node + model load).
- Cost tolerance for warm spare capacity.

**2. Back-of-envelope sizing:**
- Each replica handles 10 req/s at SLO. Daily range 4–40 req/s means 1–4 replicas (plus 1 spare).
- A surprise 3× spike from 30 to 90 req/s needs 9 replicas. If scale-up takes 5 minutes, ~60 req/s are excess for 5 minutes = 18,000 requests queued or shed.
- One warm spare replica costs ~$2–5/hour, while one 5-minute degradation event can cost far more in user trust.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Signal | GPU/CPU utilization | queue depth / KV usage / TTFT | queue depth primary, TTFT as a guard |
| Mode | reactive only | predictive + reactive | add cron/forecast for known peaks |
| Spare capacity | none | warm spares | 1+ spare when cold start > 1 minute |
| Scale to zero | yes | min ≥ 1 | zero only for long-tail models with a buffering activator |
| Overload | queue forever | shed with 429 at the gateway | shed early with Retry-After |

**4. Follow-up questions with crisp answers:**
- *Why not CPU-based HPA?* CPU is idle while the GPU is saturated, so it never triggers.
- *Why not GPU utilization?* It saturates early and stays high, so replicas get pinned at max.
- *What causes flapping?* Short scale-down windows combined with long model loads. Use a long scale-down stabilization window.
- *How do HPA and Karpenter interact?* HPA creates pods, pending pods trigger Karpenter, which adds nodes. Measure the end-to-end time.
- *What about scale-to-zero?* The first request must wait. Use an activator that buffers it (KServe/Knative) and accept the cold start.
- *What should happen when max replicas is reached?* Load shedding at the gateway with clear 429s, not unbounded queues.

**Debug this (common onsite question):** *"Every morning at 9:00, users get 30 seconds of timeouts, then everything recovers."*
1. Scaling is reactive. Replicas start scaling at 9:00:40, after metric lag.
2. Model load takes ~2.5 minutes, so new capacity arrives around 9:03.
3. The gateway timeout is 30 s, so queued requests fail during that window.
4. Fix: a cron trigger pre-scales at 8:45, warm spares cover surprises, faster loading from node cache, and the gateway sheds with 429s instead of timing out.

The lesson: **for predictable load, scale on the clock. Reactive scaling is for surprises.**

**5. What separates senior from staff answers:**
- Senior: queue-depth scaling with KEDA and sensible stabilization windows.
- Staff: models the end-to-end scale-up latency, combines predictive and reactive scaling, budgets warm capacity against SLO risk, and designs overload behaviour.

**Red flags:** CPU-based scaling for GPU services, no pre-scaling for known peaks, no load shedding, scale-down windows shorter than model load.

## Failure modes
- Scaling on GPU util pins replicas at max forever.
- A short cooldown causes flapping, and each flap costs minutes of model load.
- The metric query sums across namespaces by mistake and scales the wrong service.

## Checklist
- [ ] Autoscaling is driven by queue depth
- [ ] Scale-up latency is measured end-to-end
- [ ] Asymmetric scale-up/scale-down behavior is configured
