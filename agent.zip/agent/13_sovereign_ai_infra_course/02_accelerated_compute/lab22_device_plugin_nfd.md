# Lab 22: Deploying the NVIDIA Device Plugin and Node Feature Discovery (4:04)

## Why it matters
The scheduler knows about CPU and memory out of the box, but **not GPUs**. The device plugin
advertises them, and NFD/GFD labels **what kind** of GPU each node has.

## In plain words
Kubernetes can count CPUs and memory but is **blind to GPUs**. The device plugin is like hanging a sign on each node: "I have 8 GPUs".
NFD/GFD adds labels that say what kind: "H100, 80 GB, NVLink". Now the scheduler can match the right job to the right hardware.

## Core concepts

```mermaid
sequenceDiagram
  participant DP as Device Plugin (DaemonSet)
  participant KL as kubelet
  participant API as API server
  participant S as Scheduler
  DP->>KL: Register nvidia.com/gpu (gRPC)
  DP->>KL: ListAndWatch → 8 healthy devices
  KL->>API: node.status.allocatable nvidia.com/gpu=8
  S->>API: pod requests nvidia.com/gpu:2 → bind to node
  KL->>DP: Allocate(dev 3,4) → env NVIDIA_VISIBLE_DEVICES=3,4
```

**How to read it:** The device plugin registers with the kubelet and reports healthy devices. The kubelet publishes them as allocatable node resources. The scheduler binds a pod, and the plugin hands specific device IDs to the container.

**Labels from NFD + GPU Feature Discovery (GFD)**

```
nvidia.com/gpu.product=NVIDIA-H100-80GB-HBM3
nvidia.com/gpu.memory=81559
nvidia.com/gpu.count=8
nvidia.com/cuda.driver.major=550
nvidia.com/mig.capable=true
feature.node.kubernetes.io/pci-15b3.present=true   # Mellanox NIC → RDMA capable
```

**Sharing modes**

| Mode | Isolation | Use |
|---|---|---|
| Exclusive (default) | Full | Training, large inference |
| Time-slicing | None (shared memory, context switching) | Dev notebooks, CI |
| MPS | Partial (compute share, memory limits) | Many small inference pods |
| MIG | **Hardware** | Multi-tenant production (Lab 23) |
| DRA (Dynamic Resource Allocation) | Depends on driver | Next-gen K8s API for structured device claims |

## Architecture in depth

The overview shows the device plugin registration handshake. This view adds **discovery and health**: how labels and device health
flow into scheduling decisions, and where DRA is heading.

```mermaid
flowchart LR
  HW[(GPUs on node)] --> NVML[NVML / DCGM]
  NVML --> GFD["GPU Feature Discovery<br/>labels: product, memory, MIG"]
  NVML --> DP["Device Plugin<br/>ListAndWatch: healthy IDs"]
  GFD --> NODE[Node labels]
  DP --> KL[kubelet] --> ALLOC[node.status.allocatable]
  NODE & ALLOC --> SCH{Scheduler}
  POD["Pod: nodeSelector product=H100<br/>limits nvidia.com/gpu: 2"] --> SCH
  SCH --> BIND[Bind] --> KL
  KL -->|Allocate dev 3,4| DP
  DP -->|"CDI spec / env NVIDIA_VISIBLE_DEVICES"| CTR[Container sees 2 GPUs]
  XID[XID error] -.marks unhealthy.-> DP
```

### Follow one GPU pod from request to device injection
1. **Discovery.** GFD queries NVML and writes labels such as product, memory size, and MIG capability onto the node.
2. **Inventory.** The device plugin reports the IDs of healthy GPUs to the kubelet, which publishes the count as allocatable.
3. **Request.** The pod asks for 2 GPUs and selects a product label. The scheduler filters nodes by both.
4. **Bind.** The scheduler picks a node. The kubelet asks the device plugin to allocate 2 specific devices.
5. **Injection.** The plugin returns device specs (through CDI or env vars). The runtime exposes only those 2 GPUs inside the container.
6. **Health.** If a GPU hits a fatal XID, the plugin marks it unhealthy, allocatable drops, and no new pods get that GPU.

**The one idea to keep:** labels say *what kind* of GPU, the plugin says *how many healthy ones*, and both feed the scheduler.

## Minimal hands-on

```bash
kubectl get nodes -L nvidia.com/gpu.product,nvidia.com/gpu.count
kubectl describe node gpu-1 | grep -A5 Allocatable
```

Request a specific GPU type:

```yaml
nodeSelector: { nvidia.com/gpu.product: NVIDIA-H100-80GB-HBM3 }
resources: { limits: { nvidia.com/gpu: 1 } }
```

Time-slicing for a dev pool (4 virtual GPUs per physical):

```yaml
version: v1
sharing:
  timeSlicing:
    resources: [{ name: nvidia.com/gpu, replicas: 4 }]
```

## Worked example

**Scenario:** A research org has a mixed fleet of 16× A100-40GB, 32× H100, and 24× L4. Jobs landed
randomly, so a 70B fine-tune OOMed on an A100-40GB and a tiny embedding model hogged an H100.

Fix:
1. GFD labels every node automatically.
2. Platform templates map **workload class → node labels**:
   - `train-large` → `gpu.product=H100*`, `gpu.count=8`
   - `inference-small` → `gpu.product=NVIDIA-L4`
   - `notebook` → time-sliced A100 pool (4 users per GPU)
3. Kyverno mutates pods by namespace label to inject the right selector.

Result: zero OOM-by-wrong-GPU incidents, and H100 utilization for real training rose from 41% to 73%.

## Production deep dive
- **Health:** The device plugin marks GPUs unhealthy on XID errors (e.g. XID 79, "fallen off the bus"). Pair it with DCGM health checks and auto-cordon (Lab 98).
- **DRA:** Kubernetes Dynamic Resource Allocation (`ResourceClaim`) is replacing count-only device plugins and supports attributes ("≥ 40 GB memory, same NVLink domain"). Plan the migration.
- **CDI (Container Device Interface):** The modern, runtime-agnostic way devices are injected.
- **Topology:** Ask for GPUs that share NVLink/PCIe switches (`--topology` aware allocation) for TP workloads.

## FAANG deep-dive notes

- **How big tech does it:** Accelerators are modelled with rich attributes (type, memory, interconnect domain, health). Schedulers match on these attributes, not just counts, which is the direction Kubernetes DRA is heading.
- **Staff review questions:** How do unhealthy GPUs get removed from scheduling? Which sharing mode is used per pool, and why? Can a job request "same NVLink domain"?
- **Interview question:** *"How would you let 40 data scientists share 10 GPUs safely?"* Strong answers compare time-slicing (no isolation), MPS, and MIG (hardware isolation), plus queueing, idle culling, and quotas.

**Typical system-design prompt:** *"Design GPU scheduling for a cluster with 4 GPU types used by training, inference, and notebooks."*

**1. Clarify first:**
- GPU types and counts, interconnect (NVLink vs. PCIe), memory per type.
- Workload classes and their isolation needs.
- Is sharing acceptable for notebooks? For production?

**2. Back-of-envelope sizing:**
- 40 data scientists, each using a GPU ~15% of the time interactively: 40 × 0.15 = 6 GPUs of real demand. Time-slicing 4:1 on 10 GPUs covers peaks.
- A 7B inference model needing 18 GB on an 80 GB GPU uses 22%. MIG 2g.20gb packs 3 per GPU.
- Mis-scheduling cost: a 70B fine-tune OOM on a 40 GB A100 after 2 hours of setup wastes 2 h × 8 GPUs = 16 GPU-hours.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Sharing | exclusive | time-slicing / MPS / MIG | exclusive for training; MIG for multi-tenant production; time-slicing only for dev |
| Selection | nodeSelector on product | DRA with attributes | DRA when you need "≥ X GB" or "same NVLink domain" |
| Mapping | users pick GPUs | platform classes (small/large/notebook) | platform classes, mapped by policy |
| Health | manual | automatic unhealthy marking + cordon | automatic |

**4. Follow-up questions with crisp answers:**
- *What does the device plugin actually do?* It registers a resource, reports healthy device IDs, and allocates specific devices to containers.
- *Why can't you request 0.5 GPU natively?* Extended resources are integers. Fractions need MIG, MPS, or time-slicing replicas.
- *Time-slicing vs. MPS?* Time-slicing context-switches whole GPUs with no memory isolation. MPS runs kernels concurrently with configurable limits.
- *What is DRA?* Dynamic Resource Allocation: structured claims with device attributes, replacing count-only requests.
- *What is CDI?* A runtime-neutral standard for describing device injection into containers.
- *How do you prevent jobs landing on the wrong GPU type?* Platform workload classes plus a mutating policy that adds the right selectors.

**Debug this (common onsite question):** *"A node shows 8 GPUs in nvidia-smi but only 7 allocatable."*
1. Check device plugin logs: one GPU is reported unhealthy.
2. `nvidia-smi -q` shows pending row remapping, or a recent XID 48/63.
3. The plugin correctly withdrew it from scheduling.
4. Fix: drain, reset the GPU to apply remapping (or RMA it if that fails), and track the GPU's health history.

The lesson: **allocatable < physical is often the system working as designed.**

**5. What separates senior from staff answers:**
- Senior: knows the plugin, labels, and sharing modes.
- Staff: designs workload classes and per-pool sharing strategy, plans the DRA migration, automates health, and justifies with utilization numbers.

**Red flags:** time-slicing in multi-tenant production, users hand-picking node names, no health automation.

## Failure modes
- Time-slicing in production means one tenant OOMs the shared GPU and every tenant crashes.
- Labels drift after hardware swaps if NFD isn't running continuously.
- Pods request `nvidia.com/gpu` with no toleration and stay Pending forever (Lab 25).

## Checklist
- [ ] Nodes show `nvidia.com/gpu` allocatable and product labels
- [ ] There is a workload-class → GPU-type mapping
- [ ] The sharing strategy per pool is documented
