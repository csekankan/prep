# Section 3 — Accelerated Compute Fundamentals: GPUs & TPUs (7:19)

**Goal:** Turn expensive accelerators into a **shared, scheduled, observed, autoscaled fleet**.

| Lab | Topic | Key idea |
|---|---|---|
| [21](lab21_cuda_drivers_k8s.md) | CUDA drivers in K8s | Driver on host, toolkit in container, GPU Operator glues them |
| [22](lab22_device_plugin_nfd.md) | Device plugin + NFD | Make GPUs schedulable and discoverable |
| [23](lab23_mig_hopper.md) | MIG on Hopper | Hardware slices for small models |
| [24](lab24_amd_rocm_mi300x.md) | AMD ROCm / MI300X | Vendor diversity = sovereignty |
| [25](lab25_taints_tolerations_affinity.md) | Taints, tolerations, affinity | Keep non-GPU pods off GPU nodes |
| [26](lab26_resource_quotas_gpu.md) | Resource quotas | Fair share across teams |
| [27](lab27_dcgm_telemetry.md) | DCGM exporter | You can't optimize what you can't see |
| [28](lab28_spot_fleets.md) | Spot fleets | 60–90% cheaper, if you design for interruption |
| [29](lab29_hpa_custom_metrics.md) | HPA on custom metrics | Scale on queue depth, not CPU |
| [30](lab30_karpenter_gpu.md) | Karpenter | Nodes appear when pods need them |

## Accelerator landscape (2026 snapshot)

| Accelerator | Memory | Notes |
|---|---|---|
| NVIDIA H100 / H200 | 80 / 141 GB HBM3(e) | Hopper. MIG, FP8, NVLink 900 GB/s |
| NVIDIA B200 / GB200 NVL72 | 192 GB HBM3e | Blackwell. FP4, NVLink 5 (1.8 TB/s), 72-GPU NVLink domain |
| NVIDIA L40S / L4 | 48 / 24 GB | Inference/graphics, PCIe, cheaper |
| AMD MI300X / MI325X | 192 / 256 GB HBM3 | ROCm. Huge memory, good for big-model inference |
| Google TPU v5e/v5p/Trillium | 16–95 GB per chip | GKE-only. JAX/XLA. Pod slices via ICI |
| Intel Gaudi 3 | 128 GB | Ethernet-native scale-out |

## Enterprise lens
GPUs often account for **70–90% of an AI platform's infrastructure bill**. A 1,000-GPU fleet at 30%
utilization wastes about $20M/year. This section is about raising utilization without hurting latency.
