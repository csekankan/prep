# Lab 27: Telemetry Deep Dive — NVIDIA DCGM Exporter (3:35)

## Why it matters
`nvidia-smi` saying "100% utilization" can be **lying**. It only means a kernel was running, not
that the GPU was doing useful math. DCGM exposes the real signals.

## In plain words
`nvidia-smi` utilization is like checking whether a **car's engine is on**. DCGM tells you how fast you are actually driving.
A GPU can be "100% busy" while waiting on data or doing slow math. Tensor-core activity is the speedometer that matters.

## Architecture at a glance

```mermaid
flowchart LR
  GPU[(GPUs)] --> DC[DCGM Exporter]
  DC --> P[Prometheus]
  KS[kube-state: pod/team labels] --> P
  P --> G[Grafana: fleet / job / health]
  P --> AL["Alerts: XID, ECC, idle GPU"]
  AL --> OC[On-call / auto-cordon]
```

**How to read it:** GPU metrics and pod labels both flow into Prometheus. Dashboards show fleet, job, and health views. Alerts route faults to on-call or to automatic cordoning.

## Core concepts — metrics that matter

| Metric | Meaning | Healthy range |
|---|---|---|
| `DCGM_FI_DEV_GPU_UTIL` | Any kernel running (coarse) | Don't trust it alone |
| `DCGM_FI_PROF_SM_ACTIVE` | Fraction of SMs busy | Training > 0.8 |
| `DCGM_FI_PROF_PIPE_TENSOR_ACTIVE` | Tensor cores busy, the **real** "doing AI" signal | Training > 0.4–0.6 |
| `DCGM_FI_PROF_DRAM_ACTIVE` | Memory bandwidth used | Decode-heavy inference shows high values |
| `DCGM_FI_DEV_FB_USED` | VRAM used | — |
| `DCGM_FI_PROF_NVLINK_TX/RX_BYTES` | GPU↔GPU traffic | TP/FSDP jobs |
| `DCGM_FI_DEV_POWER_USAGE` / `GPU_TEMP` | Power/thermal | Throttle near limits |
| `DCGM_FI_DEV_XID_ERRORS` | Hardware/driver faults | Must be 0 |
| `DCGM_FI_DEV_ECC_DBE_VOL_TOTAL` | Uncorrectable memory errors | Must be 0, otherwise retire the GPU |

**MFU (Model FLOPs Utilization)**: achieved FLOPs ÷ peak FLOPs. This is the business metric for training efficiency.
Good large-scale training reaches 35–55% MFU.

## Architecture in depth

The overview shows the metrics pipeline. This view shows **which layer of the GPU each metric measures**, so you can tell
"busy" from "productive".

```mermaid
flowchart TB
  subgraph GPU["Inside one GPU"]
    K["Kernel scheduler<br/>GPU_UTIL: any kernel running?"]
    SM["Streaming multiprocessors<br/>SM_ACTIVE: fraction of SMs busy"]
    TC["Tensor cores<br/>TENSOR_ACTIVE: matrix math"]
    HBM["HBM memory<br/>DRAM_ACTIVE, FB_USED"]
    NVL["NVLink<br/>TX/RX bytes"]
    HLTH["Health<br/>XID, ECC, temp, power"]
  end
  K --> SM --> TC
  GPU --> DC[DCGM exporter] --> PROM[(Prometheus / Mimir)]
  APP["App metrics<br/>vLLM TTFT, train step time"] --> PROM
  PROM --> D1[Fleet: utilization by team]
  PROM --> D2[Job: MFU, comm vs compute]
  PROM --> D3[Health: XID, ECC → auto-cordon]
```

### Follow one diagnosis from "slow job" to root cause
1. **GPU_UTIL** says a kernel ran during the sample. A GPU running one tiny kernel shows 100%, so it can't tell you much.
2. **SM_ACTIVE** shows what fraction of SMs did work. 0.45 means half the chip is idle.
3. **TENSOR_ACTIVE** shows whether the matrix units were busy. Low values mean FP32 math, tiny batches, or waiting.
4. **DRAM_ACTIVE** high with low tensor activity means memory-bound work, which is normal for LLM decode.
5. **NVLink/PCIe bytes** high while SMs are idle means communication or host-copy bound.
6. **App metrics** close the loop: step time or TTFT tell you whether users or jobs actually suffer.
7. **Health metrics** run on a separate path: they trigger cordons, not dashboards.

**The one idea to keep:** read GPU metrics top-down: busy, then SMs, then tensor cores. The deeper the layer, the closer it is to useful work.

## Minimal hands-on

```bash
# Installed with GPU Operator; check the exporter
kubectl -n gpu-operator port-forward svc/nvidia-dcgm-exporter 9400
curl -s localhost:9400/metrics | grep -E "SM_ACTIVE|TENSOR_ACTIVE|XID"
```

PromQL starters:

```promql
# Fleet tensor-core utilization
avg(DCGM_FI_PROF_PIPE_TENSOR_ACTIVE)
# Idle-but-allocated GPUs (money burning)
count(DCGM_FI_DEV_GPU_UTIL == 0 and on(pod) kube_pod_info{pod!=""})
# Per-namespace GPU usage (needs pod labels from exporter)
sum by (namespace) (DCGM_FI_PROF_SM_ACTIVE)
```

## Worked example

**Scenario:** A training job reports "GPU util 98%", but throughput is half the vendor benchmark.

| Signal | Value | Diagnosis |
|---|---|---|
| GPU_UTIL | 98% | Misleading |
| SM_ACTIVE | 0.45 | Half the SMs are idle |
| TENSOR_ACTIVE | 0.12 | Barely using tensor cores |
| NVLINK bytes | Very high | Communication-bound |
| PCIe RX | Spiky | Host→device copies stalling |

**Root cause:** FP32 instead of BF16 (no tensor cores) plus non-pinned host memory.
**Fix:** `torch.autocast(bfloat16)`, `pin_memory=True`, larger micro-batch.
**Result:** TENSOR_ACTIVE 0.12 → 0.55, and the job finishes **2.3× faster**.

## Production deep dive
- **Standard dashboards:** A fleet view (utilization by pool/team), a job view (MFU, NVLink, power), and a health view (XID, ECC, thermals).
- **Alerting:** Page on XID 48/63/64/79/94/95, on ECC DBE, and when a GPU has been allocated but idle for more than 30 minutes (FinOps alert).
- **Correlate:** Join DCGM data with pod labels (the exporter's `--kubernetes` mode) so every metric has a team and job attached.
- **Profiling:** Use Nsight Systems / PyTorch Profiler for deep dives. DCGM handles always-on monitoring.
- **Inference SLOs:** Combine DCGM with vLLM metrics (TTFT, queue depth). Hardware busy does not mean users are happy.
- **Long-term storage:** Thanos/Mimir/VictoriaMetrics. GPU metrics at 10 s resolution across 1,000 GPUs add up to a lot of series.

## FAANG deep-dive notes

- **How big tech does it:** MFU and goodput (useful training time ÷ total time) are executive-level metrics. Every job reports them, and fleets automatically detect and remove degraded hardware.
- **Staff review questions:** What is your fleet MFU? What fraction of GPUs are allocated but idle? How quickly is a faulty GPU removed?
- **Interview question:** *"GPU util shows 98% but training is slow. Debug it."* Strong answers explain that utilization ≠ tensor-core activity, then check SM/tensor activity, NVLink/PCIe traffic, dtype, data loader stalls, and use profilers to confirm.

**Typical system-design prompt:** *"Design GPU observability for a 2,000-GPU fleet. Leadership wants one utilization number, and SREs want to catch failures."*

**1. Clarify first:**
- Who consumes the data: finance (cost), ML engineers (efficiency), SREs (health)?
- Retention needs (14 days high-res, 1 year downsampled?).
- Must metrics be attributed to teams and jobs?

**2. Back-of-envelope sizing:**
- 2,000 GPUs × ~40 metrics × labels (pod, namespace, job) ≈ 80k–200k active series at 10 s scrape. Plan Mimir/Thanos/VictoriaMetrics, not a single Prometheus.
- MFU for a 70B training job: achieved FLOPs = 6 × params × tokens/s. At 400 TFLOPS peak per GPU and 180 TFLOPS achieved, MFU = 45%.
- Idle-allocated detection: 2,000 GPUs × 5% idle-but-allocated = 100 GPUs ≈ $2M/year at $2.5/h.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Headline metric | GPU_UTIL | MFU / tensor activity / goodput | report MFU (training) and tokens/s per GPU (inference) |
| Resolution | 1 s | 10–30 s | 10 s for dashboards; profilers for deep dives |
| Profiling | always-on DCGM | Nsight on demand | always-on DCGM; Nsight for investigations |
| Health actions | alert humans | auto-cordon + ticket | automate common faults |

**4. Follow-up questions with crisp answers:**
- *Why is GPU_UTIL misleading?* It only says a kernel was running in the sample window, not how much of the chip did useful work.
- *What is MFU?* Achieved model FLOPs ÷ theoretical peak. It's the honest efficiency metric for training.
- *What is goodput?* Time spent making real training progress ÷ total time, after failures, restarts, and stalls.
- *Which XIDs page someone?* Fatal ones like 48 (DBE ECC), 79 (fallen off the bus), and 94/95 (ECC containment).
- *How do you attribute metrics to teams?* Exporter pod mapping joined with kube-state-metrics labels.
- *Why can't you see PROF metrics sometimes?* Another profiler (Nsight) holds the hardware counters.

**Debug this (common onsite question):** *"Fleet GPU utilization is 92%, but finance says the cost per trained token rose 30% this quarter."*
1. GPU_UTIL is high, but tensor-core activity fell from 0.5 to 0.3.
2. Per-job view: new jobs use smaller micro-batches and FP32 layers after a framework upgrade.
3. Goodput also fell: more restarts from a flaky NCCL timeout setting.
4. Fix: restore BF16 autocast, tune batch sizes, fix the timeout, and replace GPU_UTIL with MFU and goodput on the executive dashboard.

The lesson: **the metric you report shapes what teams optimize. Report the one that maps to cost.**

**5. What separates senior from staff answers:**
- Senior: knows which DCGM metrics matter and builds dashboards and alerts.
- Staff: defines org-level efficiency metrics (MFU, goodput, tokens per GPU-hour), designs telemetry at fleet scale, and connects health signals to automated remediation and cost.

**Red flags:** reporting GPU_UTIL as efficiency, no XID alerting, single Prometheus for a large fleet, no team attribution.

## Failure modes
- Profiling metrics (`PROF_*`) are unavailable when another profiler (Nsight) holds the counters.
- MIG instances need per-instance metrics. Aggregated metrics hide noisy slices.
- No retention policy, so Prometheus OOMs.

## Checklist
- [ ] A Grafana dashboard shows SM and tensor-core activity
- [ ] An idle-GPU alert exists
- [ ] XID/ECC alerts route to on-call
