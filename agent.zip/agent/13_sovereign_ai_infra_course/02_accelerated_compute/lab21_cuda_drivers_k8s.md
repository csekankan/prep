# Lab 21: Compiling and Injecting CUDA Drivers into K8s (3:51)

## Why it matters
Driver/CUDA mismatch is the #1 cause of "GPU not found" on day one. You need a repeatable way to
get the **kernel driver on every node** and the **CUDA user-space in every container**.

## In plain words
The GPU **driver** is the engine installed in the car (the host). **CUDA in the container** is the driver's manual the app reads. The
manual must not be newer than the engine supports. The **GPU Operator** is the mechanic who installs and checks all the parts on every car automatically.

## Architecture at a glance

```mermaid
flowchart TB
  OP[GPU Operator] --> DRV[Driver DaemonSet → kernel module]
  OP --> TK[Container Toolkit → runtime hook]
  OP --> DP[Device Plugin → nvidia.com/gpu]
  OP --> DC[DCGM Exporter → metrics]
  OP --> VAL[Validator → smoke test]
  DRV --> GPU[(GPU hardware)]
  TK --> POD["Pod gets /dev/nvidia* + libcuda"]
```

**How to read it:** The GPU Operator (top) deploys one component per box. The driver loads into the host kernel, the toolkit wires the runtime, and the device plugin advertises GPUs. Pods finally receive the device files and libraries.

## Core concepts

```
┌──────────────── Container ────────────────┐
│ PyTorch → CUDA runtime (libcudart 12.x)   │  ← shipped in the image
└──────────────────┬────────────────────────┘
       nvidia-container-toolkit injects libcuda.so + /dev/nvidia*
┌──────────────────▼────────────────────────┐
│ Host: NVIDIA kernel driver (e.g. 550.x)   │  ← must be ≥ the container's CUDA requirement
└───────────────────────────────────────────┘
```

- **Compatibility rule:** The driver is backward compatible. Driver 550 runs CUDA 12.4 containers and older.
  A CUDA 12.6 container on driver 535 **fails** (unless you use the forward-compat package).
- **GPU Operator** deploys a set of DaemonSets: driver container (compiles/loads the kernel module), container toolkit,
  device plugin, DCGM exporter, MIG manager, GFD/NFD, and a validator.
- **Precompiled vs. compiled drivers:** Precompiled driver images for your exact kernel avoid compiling on boot (faster, deterministic).

## Architecture in depth

The overview shows what the GPU Operator installs. This view shows the **order of operations on a new GPU node** and the
validation gates that keep a broken node out of the scheduling pool.

```mermaid
flowchart TB
  N[New node joins] --> NFD[NFD labels: PCI vendor 10de]
  NFD --> DRV["Driver DaemonSet<br/>load nvidia.ko / precompiled"]
  DRV --> FM["Fabric Manager<br/>NVSwitch systems only"]
  DRV --> TK["Container Toolkit<br/>configure containerd runtime"]
  TK --> DP[Device Plugin<br/>advertise nvidia.com/gpu]
  DP --> DCGM[DCGM + exporter]
  DCGM --> VAL{"Validator pods<br/>CUDA + plugin tests"}
  VAL -->|pass| READY["Label: gpu.deploy.validated<br/>node schedulable for GPU pods"]
  VAL -->|fail| CORD[Stays unschedulable + alert]
```

### Follow one node from boot to running GPU workloads
1. **Detection.** Node Feature Discovery sees an NVIDIA PCI device and labels the node, which triggers the operator's DaemonSets.
2. **Driver.** The driver container loads the kernel module, either precompiled for this exact kernel or compiled on the node. Precompiled is faster and deterministic.
3. **Fabric Manager.** On HGX systems with NVSwitch, it must run, or NVLink between GPUs stays disabled.
4. **Toolkit.** The container toolkit adds the NVIDIA runtime to containerd's config (K3s and RKE2 use different config paths).
5. **Device plugin.** Only now does the node advertise `nvidia.com/gpu`. Before this, GPU pods can't be scheduled here.
6. **Telemetry.** DCGM starts health monitoring and metrics export.
7. **Validation.** Validator pods run a CUDA sample and check the plugin. Only a passing node is labelled ready for GPU work.

**The one idea to keep:** GPU readiness is a pipeline with gates. A node advertising GPUs before validation passes will crash jobs.

## Minimal hands-on

```bash
helm repo add nvidia https://helm.ngc.nvidia.com/nvidia && helm repo update
helm install gpu-operator nvidia/gpu-operator -n gpu-operator --create-namespace \
  --set driver.version=550.127.08 \
  --set toolkit.env[0].name=CONTAINERD_CONFIG \
  --set toolkit.env[0].value=/var/lib/rancher/k3s/agent/etc/containerd/config.toml   # K3s path

kubectl -n gpu-operator get pods      # all Running / Completed
kubectl run cuda --rm -it --restart=Never --image=nvidia/cuda:12.4.1-base-ubuntu22.04 \
  --overrides='{"spec":{"containers":[{"name":"c","image":"nvidia/cuda:12.4.1-base-ubuntu22.04","command":["nvidia-smi"],"resources":{"limits":{"nvidia.com/gpu":1}}}]}}'
```

## Worked example

**Scenario:** A bank runs 60 GPU nodes. The security team mandates monthly kernel patches.

- *Before:* Drivers were installed by hand via `.run` files. Every kernel patch broke the module on ~10% of nodes and caused a 2-day outage hunt.
- *After:* Immutable node images ship with **driver pre-baked** for the pinned kernel (or GPU Operator with precompiled drivers).
  Rollouts are canaried: 2 nodes first, then the validator pod must pass, then the next 10%.
- Driver upgrade policy: `driver.upgradePolicy.autoUpgrade=true` with `maxUnavailable: 10%` drains pods gracefully.
- Outcome: patch cycles went from 2 days to 3 hours with zero GPU outages.

## Production deep dive
- **Decide where drivers live.** Driver in the node image (EKS GPU AMI, Bottlerocket NVIDIA, Talos extension) means fewer moving parts. Driver container (GPU Operator) means it is centrally managed. Pick one and document it.
- **Version matrix:** Maintain a tested matrix of kernel, driver, CUDA, framework, and NCCL. Pin all five.
- **Secure Boot:** Kernel modules must be signed. Use vendor-signed precompiled drivers or your own MOK.
- **Confidential computing:** H100 CC mode with attestation for sovereign/regulated workloads (pairs with Lab 94).
- **Fabric Manager:** Required for NVSwitch systems (HGX 8-GPU). Without it, NVLink is disabled.

## FAANG deep-dive notes

- **How big tech does it:** Immutable node images with a pinned kernel, driver, and firmware stack are rolled out through canary fleets with automated health validation. Drivers are never installed by hand.
- **Staff review questions:** Where is the version matrix documented? What is the rollback path for a bad driver? How long does a fleet-wide driver upgrade take?
- **Interview question:** *"Pods report 'driver/library version mismatch' after patching. Walk through it."* Strong answers cover user-space vs. kernel module versions, the reboot requirement, container CUDA compatibility rules, and canary rollout to prevent it next time.

**Typical system-design prompt:** *"Design driver and firmware management for a 4,000-GPU fleet with monthly kernel patches."*

**1. Clarify first:**
- Mixed GPU generations? Mixed OS images?
- Patch SLA for critical CVEs (e.g. 7 days).
- Acceptable capacity loss during rollouts (e.g. ≤ 10% at a time).

**2. Back-of-envelope sizing:**
- 500 nodes (8 GPUs each), 10% at a time = 50 nodes per wave. With ~30 minutes per wave (drain, reboot, validate), that's 10 waves ≈ 5 hours plus soak time.
- Draining training nodes costs progress. With checkpoints every 20 minutes, the expected loss is about 10 minutes per drained job.
- The version matrix: kernel × driver × CUDA × framework × NCCL. Even 2 options each gives 32 combinations, which is why you pin exactly one tested stack per pool.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Driver location | baked into node image | GPU Operator driver container | image for immutability; operator for central control on mutable nodes |
| Compile | on node (DKMS) | precompiled per kernel | precompiled for speed and determinism |
| Rollout | all at once | canary waves with validation | always waves, with automatic halt |
| Version policy | latest | pinned tested matrix | pin; upgrade deliberately with benchmarks |

**4. Follow-up questions with crisp answers:**
- *Driver/library version mismatch?* The user-space library in memory doesn't match the loaded kernel module, usually after an upgrade without a reboot.
- *Can a CUDA 12.6 container run on driver 535?* Not without the forward-compatibility package. Drivers are backward compatible only.
- *Why is nouveau a problem?* It claims the GPU first, so the NVIDIA module can't load. Blacklist it in the image.
- *What does Fabric Manager do?* It configures NVSwitch routing. Without it, NVLink traffic between GPUs on HGX systems doesn't work.
- *How do you upgrade without killing training?* Drain with PDBs, rely on checkpoint-resume, and schedule waves around large jobs.
- *Secure Boot impact?* Kernel modules must be signed, so use vendor-signed precompiled drivers or enroll your own key.

**Debug this (common onsite question):** *"After the monthly patch, 40 of 500 nodes show GPUs as 0 allocatable."*
1. All 40 share the same kernel minor version that was updated.
2. The driver pod logs show compile failures against the new kernel headers.
3. Precompiled drivers for this kernel weren't published yet.
4. Fix: pin the kernel to versions with available precompiled drivers, gate kernel upgrades on driver availability in CI, and make the validator block scheduling (it did, so jobs were protected).

The lesson: **kernel and driver are one versioned unit. Never upgrade one without the other.**

**5. What separates senior from staff answers:**
- Senior: installs the operator, knows the compatibility rules, debugs mismatch errors.
- Staff: owns a version matrix and wave-based rollout with automatic halt, estimates capacity loss, and integrates validation into scheduling.

**Red flags:** hand-installed drivers, unpinned kernels, fleet-wide simultaneous upgrades, no validation gate.

## Failure modes
- `Failed to initialize NVML: Driver/library version mismatch` because the host driver was upgraded without a reboot.
- `nouveau` open-source driver still loaded, which blocks the NVIDIA module.
- Containerd config path differs on K3s/RKE2, so the toolkit can't find the runtime.

## Checklist
- [ ] `nvidia-smi` works inside a pod
- [ ] There is a documented, pinned kernel/driver/CUDA matrix
- [ ] A canary procedure for driver upgrades is defined
