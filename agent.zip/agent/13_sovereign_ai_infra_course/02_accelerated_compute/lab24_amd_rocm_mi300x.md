# Lab 24: AMD ROCm Equivalencies — Configuring MI300X Nodes (3:49)

## Why it matters
Single-vendor dependence is a **sovereignty and supply-chain risk** (allocation shortages, pricing,
export controls). MI300X offers **192 GB HBM3** per GPU, enough to fit a 70B FP16 model on a
single card.

## In plain words
Relying on one GPU vendor is like a city with a single power plant. **AMD ROCm** is a second plant. Most apps (PyTorch, vLLM) can
plug into either, and MI300X's huge memory lets big models fit on fewer cards.

## Architecture at a glance

```mermaid
flowchart LR
  APP[Platform API: gpu-class=large-mem] --> T{Template}
  T -->|vendor=nvidia| N["image: vllm-cuda<br/>nvidia.com/gpu"]
  T -->|vendor=amd| A["image: vllm-rocm<br/>amd.com/gpu"]
  N --> NH[(H100/B200 nodes)]
  A --> AM[(MI300X nodes)]
```

**How to read it:** The platform API asks for a capability (large memory), not a vendor. Templates translate that into vendor-specific images and resource names, landing on NVIDIA or AMD nodes.

## Core concepts — NVIDIA ↔ AMD map

| NVIDIA | AMD |
|---|---|
| CUDA | ROCm / HIP |
| `nvidia-smi` | `rocm-smi` / `amd-smi` |
| NCCL | RCCL |
| cuDNN / cuBLAS | MIOpen / hipBLASLt |
| GPU Operator | AMD GPU Operator |
| `nvidia.com/gpu` | `amd.com/gpu` |
| DCGM exporter | AMD Device Metrics Exporter |
| NVLink | Infinity Fabric |
| MIG | Compute partitioning (SPX/CPX) + memory NPS modes |
| TensorRT-LLM | vLLM-ROCm, SGLang-ROCm |

**Portability layers:** PyTorch, JAX, vLLM, and Triton (the language) all support ROCm.
Most enterprise model code needs **zero changes** if you avoid custom CUDA kernels.

## Architecture in depth

The overview shows the vendor abstraction. This view shows the **full dual-vendor stack** side by side, so you can see which layers
are shared and which are vendor-specific.

```mermaid
flowchart TB
  APP["Same app: vLLM OpenAI API + Helm chart"] --> FW[PyTorch / vLLM / Triton-lang]
  FW --> CUDA["NVIDIA path<br/>CUDA, cuBLAS, NCCL"]
  FW --> ROCM["AMD path<br/>ROCm/HIP, hipBLASLt, RCCL"]
  CUDA --> NOP["GPU Operator<br/>nvidia.com/gpu, DCGM"]
  ROCM --> AOP["AMD GPU Operator<br/>amd.com/gpu, metrics exporter"]
  NOP --> NHW[(H100 / B200<br/>NVLink)]
  AOP --> AHW[(MI300X / MI325X<br/>Infinity Fabric)]
  EVAL["Eval + perf parity suite"] -.certifies model×vendor.-> APP
```

### Follow one model from "NVIDIA only" to dual-vendor
1. **Audit dependencies.** List any CUDA-only pieces: custom kernels, bitsandbytes builds, vendor-only quantization formats.
2. **Pick the shared layer.** PyTorch and vLLM support both vendors, so the serving API and chart stay the same.
3. **Build two images.** One CUDA-based, one ROCm-based, from the same source and version tag.
4. **Template the difference.** Helm values switch image, resource name (`nvidia.com/gpu` vs. `amd.com/gpu`), and node selector.
5. **Validate.** Run the same eval set (quality) and benchmark (throughput, TTFT) on both. Certify each model × vendor pair.
6. **Route.** The gateway treats both pools as one model endpoint. Weight traffic by capacity and cost.

**The one idea to keep:** portability lives in the framework layer. Vendor-specific code below it is a lock-in decision you should make knowingly.

## Minimal hands-on

```bash
helm install amd-gpu-operator rocm/gpu-operator-charts -n kube-amd-gpu --create-namespace
kubectl get nodes -L feature.node.kubernetes.io/amd-gpu
```

```yaml
containers:
- name: vllm
  image: rocm/vllm:latest
  args: ["--model","meta-llama/Llama-3.1-70B-Instruct","--tensor-parallel-size","1"]
  resources: { limits: { amd.com/gpu: 1 } }
```

## Worked example

**Scenario:** A government agency must serve Llama-3.1-70B in **FP16** (no quantization, for
accuracy-certification reasons).

| Option | GPUs needed | Notes |
|---|---|---|
| H100 80GB | 2 (TP=2), and KV gets tight | Needs NVLink and TP overhead |
| H200 141GB | 1–2 | Supply-constrained |
| **MI300X 192GB** | **1** (weights 140 GB + 40 GB KV) | No TP, simpler ops |

They run a **dual-vendor fleet**: MI300X for big-model inference, H100 for training.
One Helm chart is parameterized by `vendor: nvidia|amd`, which switches image, resource name, and node selector.
That gives them procurement leverage and resilience against allocation shocks.

## Production deep dive
- **Abstraction:** Express GPU type in your platform API ("gpu-class: large-mem") and map it to vendor resources in templates. Don't leak vendor names to app teams.
- **Validation:** Run the same evaluation suite (accuracy and performance) on both vendors before certifying a model/vendor pair.
- **Kernels:** Custom CUDA kernels (FlashAttention variants, custom MoE) need ROCm ports. Check before committing.
- **Networking:** MI300X clusters typically use RoCEv2 with RCCL. Tune much as in Lab 36.
- **TPUs and others:** On GKE, TPUs appear as `google.com/tpu` with topology selectors. Gaudi appears as `habana.ai/gaudi`. The pattern is the same.

## FAANG deep-dive notes

- **How big tech does it:** Large AI companies run multi-vendor accelerator fleets (custom chips, NVIDIA, AMD) behind compiler and runtime abstraction layers, so models move between hardware without app changes.
- **Staff review questions:** Which custom kernels block portability? Is there an eval-parity test per vendor? What is the procurement leverage worth?
- **Interview question:** *"How would you reduce dependence on a single GPU vendor?"* Strong answers cover framework-level portability, avoiding vendor-only kernels, abstraction in the platform API, dual validation pipelines, and an honest cost of portability.

**Typical system-design prompt:** *"Leadership wants to reduce GPU vendor lock-in for inference without hurting quality. Propose a plan."*

**1. Clarify first:**
- Which models and engines are in use? Any custom kernels?
- What does "without hurting quality" mean: accuracy parity, latency parity, or both?
- Procurement goals: price leverage, supply resilience, or regulatory diversity?

**2. Back-of-envelope sizing:**
- 70B FP16 = 140 GB weights. On MI300X (192 GB), 1 GPU per replica with ~40 GB for KV. On H100 80GB, TP=2 at minimum.
- If 10 replicas are needed: 10 MI300X vs. 20 H100. Compare total cost per replica, including power and networking.
- Engineering cost: two images, CI for both, a parity suite. Maybe 0.5–1 engineer ongoing.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Engine | TensorRT-LLM (NVIDIA-only) | vLLM / SGLang (both) | portable engine by default; TRT-LLM only where the gain justifies lock-in |
| Abstraction | vendor names in manifests | GPU classes in the platform API | classes; vendors hidden in templates |
| Mix | one vendor per region | both per region | both where traffic is large enough for two pools |
| Kernels | custom CUDA | Triton-lang / framework ops | framework ops unless profiling proves the need |

**4. Follow-up questions with crisp answers:**
- *What's the AMD equivalent of NCCL?* RCCL, with mostly the same API and environment variables.
- *Why is MI300X attractive for inference?* Memory capacity. Big models fit on fewer GPUs, so less tensor parallelism and simpler ops.
- *What usually breaks when porting?* Custom CUDA kernels, CUDA-only wheels, and vendor-specific quantization.
- *How do you prove parity?* The same eval set and benchmark harness, with tolerances agreed in advance.
- *How do you handle partition modes on MI300X?* Pin a partition mode per pool and benchmark in that mode.
- *What about TPUs?* A different stack (JAX/XLA) and GKE-only. Portability comes from model code in JAX or PyTorch/XLA.

**Debug this (common onsite question):** *"The same model on MI300X is 40% slower than the vendor benchmark."*
1. Compare configs: the benchmark used a different partition/NPS mode.
2. Check the image: an older ROCm build without the tuned attention kernels.
3. Check the engine flags: FP8 KV was disabled on this pool.
4. Fix: align mode, image, and flags with the benchmark, re-run the parity suite, and pin the configuration in the chart.

The lesson: **cross-vendor comparisons are only valid with identical, pinned configurations.**

**5. What separates senior from staff answers:**
- Senior: knows the ROCm equivalents and can deploy on AMD.
- Staff: frames lock-in as risk and cost, designs the abstraction layer, budgets engineering effort, and defines certification gates per model × vendor.

**Red flags:** "port everything" without a dependency audit, vendor names leaking into app manifests, no parity tests.

## Failure modes
- Using a CUDA-only wheel (e.g. bitsandbytes builds) inside a ROCm image.
- Ignoring partition/NPS mode, so performance differs from the benchmarks.
- Assuming NCCL env vars apply to RCCL (most do, some don't).

## Checklist
- [ ] A vendor-neutral GPU class abstraction is defined
- [ ] One model is validated on both vendors
- [ ] The RCCL/RoCE config is documented
