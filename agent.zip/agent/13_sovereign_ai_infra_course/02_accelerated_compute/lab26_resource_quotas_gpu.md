# Lab 26: Resource Quotas — Preventing GPU Starvation (3:42)

## Why it matters
Without quotas, one enthusiastic researcher launches a 64-GPU sweep on Friday and the
production fine-tune queue starves all weekend. Quotas are **organizational fairness encoded
as policy**.

## In plain words
Quotas are **slices of a shared pizza**: each team is guaranteed its slices. Kueue adds a polite rule: if your slices sit uneaten,
another team may borrow them, but must give them back the moment you're hungry.

## Architecture at a glance

```mermaid
flowchart TB
  CO[Cohort: research-org 64 GPUs] --> NLP["NLP queue: 24 nominal, +16 borrow"]
  CO --> VIS["Vision queue: 16 nominal, +16 borrow"]
  CO --> SP["Speech queue: 8 nominal"]
  J1[Jobs] --> NLP
  J2[Jobs] --> VIS
  NLP -->|idle capacity| BR[Borrow from Vision]
  VIS -->|needs it back| RC[Reclaim → preempt borrowed]
```

**How to read it:** Three team queues sit inside one shared cohort. Each has a guaranteed share, idle capacity can be borrowed, and the lender reclaims it by preempting borrowed work when it needs its GPUs back.

## Core concepts

| Object | Scope | Purpose |
|---|---|---|
| `ResourceQuota` | Namespace | Hard ceiling (e.g. max 16 GPUs) |
| `LimitRange` | Namespace | Defaults & per-pod min/max |
| **Kueue `ClusterQueue` / `LocalQueue`** | Cluster | Quota with **borrowing, lending, fair sharing, and queueing** |
| Volcano `Queue` | Cluster | Weighted queues + gang scheduling |

Native `ResourceQuota` **rejects** pods over the limit. Kueue **queues** jobs until capacity is free,
which is what ML teams actually want.

## Architecture in depth

The overview shows a cohort with borrowing. This view shows **how Kueue admits one job**: from submission to running pods,
including the quota check and reclaim path.

```mermaid
flowchart LR
  U[User submits PyTorchJob<br/>suspend: true] --> LQ[LocalQueue team-nlp]
  LQ --> CQ{"ClusterQueue nlp<br/>quota check per flavor"}
  CQ -->|"fits nominal"| ADM[Admit: unsuspend job]
  CQ -->|"fits with borrowing"| BOR[Admit as borrowed]
  CQ -->|"no capacity"| WAIT[Wait in queue, ordered by priority]
  ADM & BOR --> PODS[Pods created → scheduler]
  OTHER[Vision submits work] --> REC{Reclaim needed?}
  REC -->|yes| PRE[Preempt NLP borrowed workloads] --> REQ[Requeue + checkpoint resume]
  KQ[(Kueue metrics)] -.usage per queue.-> SHOW[Showback report]
```

### Follow one 16-GPU job through Kueue
1. **Submit.** The job is created *suspended*. No pods exist yet, so nothing competes with the scheduler.
2. **Queue.** It lands in the team's LocalQueue, which points to the team's ClusterQueue.
3. **Quota check.** Kueue checks the request against the ClusterQueue's nominal quota for the GPU flavor (e.g. h100).
4. **Borrow.** If nominal is exhausted but the cohort has idle quota, the job is admitted as *borrowed*.
5. **Admit.** Kueue unsuspends the job. Pods are created, and the normal scheduler places them. All pods fit, so there are no partial gangs.
6. **Reclaim.** When the lending team needs its GPUs back, Kueue preempts borrowed workloads. They checkpoint, requeue, and resume later.
7. **Report.** Usage per queue (nominal vs. borrowed) feeds the weekly showback report.

**The one idea to keep:** quota systems for ML should *queue*, not reject, and borrowing only works if reclaim is reliable.

## Minimal hands-on

```yaml
apiVersion: v1
kind: ResourceQuota
metadata: { name: gpu-quota, namespace: team-nlp }
spec:
  hard:
    requests.nvidia.com/gpu: "16"
    limits.memory: 2Ti
```

Kueue with borrowing:

```yaml
apiVersion: kueue.x-k8s.io/v1beta1
kind: ClusterQueue
metadata: { name: nlp }
spec:
  cohort: research-org          # queues in a cohort can borrow from each other
  namespaceSelector: {}
  resourceGroups:
  - coveredResources: [nvidia.com/gpu]
    flavors:
    - name: h100
      resources: [{ name: nvidia.com/gpu, nominalQuota: 16, borrowingLimit: 16 }]
```

## Worked example

**Scenario:** 64 H100s shared by 3 teams.

| Team | Nominal | Can borrow up to |
|---|---|---|
| NLP | 24 | +16 |
| Vision | 16 | +16 |
| Speech | 8 | +8 |
| Platform reserve | 16 | — |

- **Monday:** Vision is idle, so NLP borrows 16 and runs a 40-GPU job.
- **Tuesday:** Vision submits work. Kueue **reclaims** borrowed GPUs by preempting NLP's lowest-priority borrowed workloads, and the job checkpoints and requeues.
- **Monthly report:** Each team's GPU-hours (nominal vs. borrowed) feed chargeback.

Fleet utilization rose from 52% to 81%, and no team was ever starved below its nominal quota.

## Production deep dive
- **Flavors:** Model GPU types as Kueue `ResourceFlavor`s (h100, a100, l4, spot-h100) with different quotas.
- **Fair sharing:** Dominant Resource Fairness (DRF) across teams prevents one team monopolizing the cluster.
- **MultiKueue:** Dispatch jobs to whichever of several clusters has free capacity (feeds Lab 91).
- **Showback/chargeback:** OpenCost/Kubecost with GPU pricing. Publish a weekly per-team report.
- **Governance:** Quota changes go via a PR to a GitOps repo, so every change is reviewed and auditable.

## FAANG deep-dive notes

- **How big tech does it:** Quota is treated as a budget with lending and reclaiming between organizations. Capacity reviews happen quarterly, and showback makes idle allocations visible to leadership.
- **Staff review questions:** What is the policy when two teams both want borrowed GPUs? Are borrowed workloads preemptible and checkpointed? Is there a utilization report per team?
- **Interview question:** *"Design a fair GPU-sharing system for 10 research teams."* Strong answers cover nominal quotas, borrowing, preemption on reclaim, Dominant Resource Fairness (DRF), queueing instead of rejection, and reporting.

**Typical system-design prompt:** *"Design GPU quota and fair sharing for 10 teams on a 512-GPU cluster."*

**1. Clarify first:**
- Guaranteed shares per team (from budget or org priority).
- Can idle capacity be borrowed? Can borrowers be preempted?
- Job types: long training, short sweeps, interactive.

**2. Back-of-envelope sizing:**
- 512 GPUs, 10% platform reserve (51), 461 split by budget. Example: 3 large teams × 100, 7 small teams × ~23.
- Typical utilization without borrowing ≈ 50–60%, because teams' peaks don't align. With borrowing, 80%+ is common.
- At ~$2.5/GPU-hour, 25 points of utilization on 512 GPUs ≈ 128 GPUs ≈ $2.8M/year of recovered value.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Enforcement | ResourceQuota (reject) | Kueue (queue) | queueing for ML jobs; ResourceQuota as a hard ceiling |
| Sharing | strict quotas | cohorts + borrowing | borrowing with preemption on reclaim |
| Fairness | FIFO | DRF / weighted fair share | fair share across teams; priority within a team |
| Multi-cluster | per-cluster queues | MultiKueue | MultiKueue when jobs can run in any of several clusters |

**4. Follow-up questions with crisp answers:**
- *Why not just ResourceQuota?* It rejects pods over quota, so users write retry loops. Kueue holds jobs in a queue until capacity frees up.
- *What makes borrowing safe?* Preemption on reclaim, plus checkpointing in borrowed jobs.
- *What's a ResourceFlavor?* A type of capacity (h100, a100, spot-h100) with its own quota.
- *How do you stop one team monopolizing the cluster?* Borrowing limits, plus fair-share scheduling across cohorts.
- *How do you handle a big job that never fits?* Reservations or a priority boost after a wait threshold, so small jobs can't starve it.
- *Why showback?* Visible costs change behaviour. Teams release idle allocations when they see the bill.

**Debug this (common onsite question):** *"Team Vision complains its jobs wait hours even though it's under its nominal quota."*
1. Check the ClusterQueue: Vision's nominal is free on paper, but the GPUs are occupied by NLP's borrowed jobs.
2. Reclaim is configured, but NLP's jobs have higher priority, and the policy only reclaims lower-priority workloads.
3. Result: borrowed capacity effectively never returns.
4. Fix: set `reclaimWithinCohort: Any` (reclaim regardless of priority for borrowed workloads), and alert when a queue under nominal has pending jobs.

The lesson: **a lender's guarantee must beat the borrower's priority. Test reclaim explicitly.**

**5. What separates senior from staff answers:**
- Senior: sets quotas and installs Kueue.
- Staff: designs cohorts, flavors, borrowing limits, and reclaim semantics, quantifies the utilization gain, and builds governance around quota changes.

**Red flags:** reject-only quotas for ML, borrowing without preemption, no showback, quota edited by hand on the cluster.

## Failure modes
- Native quota on `requests.nvidia.com/gpu` but pods set only `limits`. GPUs are defaulted correctly, but double-check.
- Borrowing without preemption means a lender can never get its GPUs back.
- Quotas without queueing push users to write retry loops that hammer the API server.

## Checklist
- [ ] Each team namespace has a quota
- [ ] Kueue is installed with at least one cohort
- [ ] There is a GPU-hours report per team
