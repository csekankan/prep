# Lab 25: Taints, Tolerations, and Node Affinity for GPU Scheduling (3:28)

## Why it matters
If a logging DaemonSet or a web pod lands on a GPU node, it consumes CPU/RAM the GPU job needed.
Worse, it can **block node scale-down**, so you pay for an idle $98/hour 8×H100 node.

## In plain words
A **taint** is a "Staff only" sign on the expensive GPU room. A **toleration** is the staff badge that lets a pod past the sign.
**Affinity** is the pod saying "I *want* to work in that room". You need the sign, the badge, and the wish together, or the wrong
people wander in and the right ones go elsewhere.

## Architecture at a glance

```mermaid
flowchart LR
  WEB[Web pod: no toleration] -.blocked.-> GN["GPU node: taint nvidia.com/gpu"]
  ML["ML pod: toleration + affinity"] -->|allowed + attracted| GN
  WEB --> CN[CPU node]
  PR[PriorityClass] -->|evicts lower tiers when full| GN
```

**How to read it:** A web pod without a toleration is blocked from GPU nodes and lands on CPU nodes. An ML pod with both a toleration and affinity is allowed in and pulled toward GPU nodes. Priority decides who is evicted when space runs out.

## Core concepts

| Mechanism | Direction | Question |
|---|---|---|
| **Taint** (on node) | Repels | "Who is *not* allowed here?" |
| **Toleration** (on pod) | Permits | "I'm allowed onto tainted nodes" |
| **nodeSelector / nodeAffinity** (on pod) | Attracts | "I *want* to be on these nodes" |
| **podAffinity / antiAffinity** | Relative | "Near/away from these other pods" |
| **PriorityClass + preemption** | Ordering | "Who gets evicted when full?" |

A toleration alone doesn't attract the pod. You need **taint + toleration + affinity** together.

## Architecture in depth

The overview shows taints, tolerations, and affinity. This view shows the **scheduler's actual pipeline** for one GPU pod:
filter, score, then preempt if nothing fits.

```mermaid
flowchart LR
  POD["Pending pod<br/>tolerations, affinity, priority"] --> F{"Filter phase"}
  F -->|"taint not tolerated"| X1[Node excluded]
  F -->|"required affinity fails"| X2[Node excluded]
  F -->|"not enough GPU"| X3[Node excluded]
  F --> OK[Feasible nodes]
  OK --> S["Score phase<br/>preferred affinity, spread, bin-packing"]
  S --> BEST[Highest score → bind]
  F -->|no feasible node| PRE{"Preemption: lower-priority<br/>pods to evict?"}
  PRE -->|yes| EV[Evict victims → retry]
  PRE -->|no| PEND[Stay Pending → autoscaler]
```

### Follow one inference pod through scheduling during a traffic spike
1. **Filter.** Nodes whose taints the pod doesn't tolerate are excluded first. That's why CPU-only pods never even consider GPU nodes.
2. **Required affinity.** Only H100 nodes pass, because the pod requires that product label.
3. **Resources.** Nodes without a free GPU are excluded. Suppose none are left.
4. **Preemption.** The pod has priority 1,000,000. The scheduler looks for nodes where evicting lower-priority pods (research at 100) frees enough GPU.
5. **Eviction.** Victims get SIGTERM and their grace period. Well-behaved training jobs checkpoint now.
6. **Score and bind.** Once space exists, preferred affinities (same zone) and spreading rules rank the nodes, and the pod binds to the best one.
7. **No victims available?** The pod stays Pending, which is the signal for the node autoscaler (Lab 30).

**The one idea to keep:** taints and required affinity *filter*, preferences *score*, and priority decides who gets evicted when the cluster is full.

## Minimal hands-on

```bash
kubectl taint nodes gpu-1 nvidia.com/gpu=present:NoSchedule
```

```yaml
spec:
  tolerations:
  - { key: nvidia.com/gpu, operator: Exists, effect: NoSchedule }
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
        - matchExpressions:
          - { key: nvidia.com/gpu.product, operator: In, values: [NVIDIA-H100-80GB-HBM3] }
      preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 50
        preference: { matchExpressions: [{ key: topology.kubernetes.io/zone, operator: In, values: [eu-west-1a] }] }
  priorityClassName: inference-critical
```

## Worked example

**Scenario:** A shared cluster has 3 workload tiers competing for 64 H100s.

| Tier | PriorityClass | Preemptible? | Pool |
|---|---|---|---|
| Production inference | `inference-critical` (1,000,000) | No | Tainted `pool=inference` |
| Scheduled training | `training` (10,000) | Yes, by inference | Tainted `pool=training` |
| Research/notebooks | `research` (100) | Yes, by everything | Spillover onto either pool |

During a product launch, inference traffic triples. HPA scales inference pods, which **preempt
research pods first**, then training (which checkpoints, see Lab 39). After the spike, training
resumes automatically. GPU utilization stays above 85% around the clock with no human intervention.

## Production deep dive
- **Taint every GPU node** by default. The GPU Operator and cloud node groups can do this automatically.
- **DaemonSets** (log agents, CNI) need explicit tolerations. Keep them lean on GPU nodes.
- **Topology:** Use `podAntiAffinity` across nodes for inference replicas (HA) and `podAffinity` within one rack/NVLink domain for TP/training groups.
- **Kueue / Volcano** handle queue-based admission that goes beyond priority (Lab 38).
- **Descheduler:** Periodically rebalances pods that drifted off their preferred nodes.

## FAANG deep-dive notes

- **How big tech does it:** Cluster schedulers use strict priority bands (production > batch > best effort) with preemption, so expensive hardware stays busy while production SLOs stay protected.
- **Staff review questions:** Are all GPU nodes tainted? What priority does each workload class have? Does preemption trigger a checkpoint?
- **Interview question:** *"Design scheduling so inference never waits for training on a shared GPU cluster."* Strong answers cover priority classes, preemption, checkpoint-on-SIGTERM, reserved capacity, and fair-share for the remainder.

**Typical system-design prompt:** *"Design scheduling for a shared 256-GPU cluster: production inference must never wait, training should use everything else."*

**1. Clarify first:**
- Inference demand range (min/peak) and acceptable time-to-capacity during spikes.
- Can training be preempted? How often does it checkpoint?
- Any team-level guarantees (quotas) on top of priorities?

**2. Back-of-envelope sizing:**
- Inference peaks at 96 GPUs, baseline 32. Reserve 32 permanently; the other 64 are preemptible headroom.
- Training checkpoints every 20 minutes, so a preemption loses ~10 minutes on average. 64 preemptions/day × 10 min ≈ 11 GPU-hours/day lost, vs. 64 idle GPUs × 24 h = 1,536 GPU-hours if headroom were reserved. Preemption wins easily.
- Eviction grace period must cover checkpoint time (e.g. 90 s).

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Isolation | separate node pools | shared pool + priority | separate pools for strict SLOs; shared + preemption for utilization |
| Taint effect | NoSchedule | NoExecute | NoSchedule unless you really want running pods evicted |
| Affinity | required | preferred | required for hardware needs, preferred for locality |
| Preemption | allowed | `preemptionPolicy: Never` for some | disable for jobs that can't checkpoint |

**4. Follow-up questions with crisp answers:**
- *Does a toleration attract a pod to a node?* No. It only permits it. You need affinity to attract.
- *NoSchedule vs. NoExecute?* NoSchedule blocks new pods. NoExecute also evicts running pods that don't tolerate it.
- *What does a PriorityClass do?* Orders the queue and allows preemption of lower-priority pods.
- *Why might preemption fail to help?* PodDisruptionBudgets, victims on the wrong nodes, or the pod needing a GPU type no victim frees.
- *How do you keep DaemonSets off GPU nodes?* Don't give them the GPU toleration. Add it only to the agents that must run there.
- *What's topology spread for?* Spreading replicas across zones or nodes so one failure doesn't take out all of them.

**Debug this (common onsite question):** *"During a spike, new inference pods stay Pending for 10 minutes even though research jobs are running on GPU nodes."*
1. Check pod events: "preemption: not eligible due to PodDisruptionBudget".
2. The research namespace had a PDB with `minAvailable: 100%`, set by a researcher.
3. Preemption respects PDBs on a best-effort basis but avoids violating them, so it found no victims.
4. Fix: a policy (Kyverno) that forbids strict PDBs on preemptible tiers, plus an alert when high-priority pods are pending more than 2 minutes.

The lesson: **priority only works if lower tiers are actually preemptible. Enforce that with policy.**

**5. What separates senior from staff answers:**
- Senior: correct taints, tolerations, affinity, and priority classes.
- Staff: quantifies the cost of preemption vs. reserved headroom, ties grace periods to checkpoint time, enforces tier rules with policy, and alerts on scheduling latency.

**Red flags:** tolerations without affinity, NoExecute taints by default, preemptible jobs without checkpoints, no alert on pending high-priority pods.

## Failure modes
- Pods with a toleration but no affinity drift onto expensive GPU nodes.
- `NoExecute` taints evict running training jobs instantly. Use `NoSchedule` unless you mean it.
- Preemption without checkpointing loses hours of training.

## Checklist
- [ ] All GPU nodes are tainted
- [ ] PriorityClasses are defined per tier
- [ ] Non-GPU pods have been verified absent from GPU nodes
