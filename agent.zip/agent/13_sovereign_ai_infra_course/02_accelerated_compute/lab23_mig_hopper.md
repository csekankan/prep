# Lab 23: Multi-Instance GPU (MIG) — Slicing Hopper Architecture (3:31)

## Why it matters
A 7B embedding model uses 10 GB of an 80 GB H100. Without slicing, **87% of a $30k GPU sits idle**.
MIG partitions one GPU into up to **7 hardware-isolated instances**, each with its own
memory, cache, and compute engines.

## In plain words
MIG cuts one big GPU into **up to 7 separate apartments**, each with its own walls, kitchen, and front door. A small model gets a
small apartment, and the neighbours can't steal its memory or slow it down. Time-slicing, by contrast, is roommates sharing one room.

## Architecture at a glance

```mermaid
flowchart TB
  H[H100 80GB] --> A["3g.40gb → 13B model"]
  H --> B["2g.20gb → reranker"]
  H --> C["1g.10gb → embedder"]
  H --> D["1g.10gb → classifier"]
```

**How to read it:** One physical H100 at the top splits into independent slices below. Each slice has its own memory and compute, and each serves a different right-sized model.

## Core concepts

H100 80GB MIG profiles (examples):

| Profile | Compute slices | Memory | Max per GPU |
|---|---|---|---|
| `1g.10gb` | 1/7 | 10 GB | 7 |
| `2g.20gb` | 2/7 | 20 GB | 3 |
| `3g.40gb` | 3/7 | 40 GB | 2 |
| `4g.40gb` | 4/7 | 40 GB | 1 |
| `7g.80gb` | full | 80 GB | 1 |

- **Isolation:** Separate memory and SM partitions, so faults and OOMs are contained and QoS is predictable. Unlike time-slicing, it is safe for multi-tenant use.
- **Strategies in K8s:**
  - `single`: every slice on a node is the same profile and appears as `nvidia.com/gpu`.
  - `mixed`: slices are exposed as named resources like `nvidia.com/mig-1g.10gb`.
- **Limitations:** No P2P/NVLink between MIG instances. Reconfiguration requires the GPU to be idle.

## Architecture in depth

The overview shows one GPU split into slices. This view shows **how a MIG layout is applied and consumed in Kubernetes**,
from a node label to a pod running on a slice.

```mermaid
flowchart LR
  ADM["Platform: label node<br/>mig.config=inference-mix"] --> MM[MIG Manager]
  MM -->|drain GPU pods| DR[GPUs idle]
  DR --> CFG["Create GPU instances + compute instances<br/>3g.40gb + 2g.20gb + 2× 1g.10gb"]
  CFG --> DP["Device Plugin re-registers<br/>nvidia.com/mig-3g.40gb: 1 ..."]
  DP --> SCH{Scheduler}
  POD["Pod limits:<br/>nvidia.com/mig-1g.10gb: 1"] --> SCH
  SCH --> RUN[Pod on isolated slice]
  RUN --> DCGM[DCGM per-instance metrics]
```

### Follow one layout change from label to running pods
1. **Declare.** The platform team labels the node with a named layout from a config map, instead of running commands on the node.
2. **Drain.** The MIG Manager waits until GPU workloads on that node are gone, because reconfiguring needs idle GPUs.
3. **Partition.** It creates GPU instances (memory + SM slices) and compute instances inside them, per the layout.
4. **Advertise.** The device plugin restarts and advertises named slice resources (mixed strategy) or a uniform `nvidia.com/gpu` (single strategy).
5. **Request.** A pod asks for a specific slice type. The scheduler places it on a node that has a free one.
6. **Isolation.** The pod sees only its slice. Memory errors or OOMs stay inside that slice.
7. **Observe.** DCGM reports utilization per MIG instance, which feeds chargeback.

**The one idea to keep:** MIG layouts are infrastructure configuration. Define them per node pool, and change them rarely and deliberately.

## Minimal hands-on

```bash
# Label a node with the desired layout; MIG Manager (GPU Operator) applies it
kubectl label node gpu-3 nvidia.com/mig.config=all-1g.10gb --overwrite
kubectl get node gpu-3 -o jsonpath='{.status.allocatable}' | jq
```

```yaml
resources: { limits: { nvidia.com/mig-1g.10gb: 1 } }   # mixed strategy
```

Custom layout (one 3g + one 2g + two 1g on each GPU):

```yaml
mig-configs:
  inference-mix:
    - devices: all
      mig-enabled: true
      mig-devices: { "3g.40gb": 1, "2g.20gb": 1, "1g.10gb": 2 }
```

## Worked example

**Scenario:** A SaaS company serves **28 small models** (embeddings, rerankers, classifiers,
a 3B router) with 1 GPU each across 28 L40S cards.

Redesign on H100 + MIG:
- 4× H100 at `all-1g.10gb` gives **28 isolated slices**.
- Each model gets a guaranteed 10 GB and 1/7 of the compute. Latency stays stable because there are no noisy neighbours.
- GPU count goes from 28 to 4, power from ~9.8 kW to ~2.8 kW, and the bill drops by about 55%.
- Peak-hour latency for the reranker improved because it was previously time-sliced with a batch job.

**When not to use MIG:** large models that need TP across GPUs, or training jobs needing NVLink.

## Production deep dive
- **Pool design:** Dedicate node pools to MIG layouts (e.g. `mig-small`, `mig-mixed`) instead of reconfiguring nodes on the fly.
- **Dynamic MIG:** DRA-based drivers can carve slices on demand. Evaluate them carefully, because reconfiguration drains workloads.
- **Chargeback:** Bill per slice-hour. DCGM exports per-MIG-instance metrics (Lab 27).
- **Blackwell:** B200 also supports MIG (up to 7 instances), so the same patterns carry forward.
- **Alternatives:** For non-NVIDIA hardware, AMD MI300X supports compute/memory partition modes (CPX/NPS), covered in Lab 24.

## FAANG deep-dive notes

- **How big tech does it:** Small models are bin-packed onto GPU partitions or shared GPUs with strict isolation, and utilization per slice is tracked for chargeback. Partition layouts are fixed per pool, not changed on the fly.
- **Staff review questions:** Does each model's KV cache fit its slice under peak concurrency? What happens when a model outgrows its slice? How are layouts changed safely?
- **Interview question:** *"You have 30 small models and 4 H100s. Design the serving layout."* Strong answers cover sizing each model (weights + KV), choosing MIG profiles, leaving headroom, handling noisy neighbours, and when to merge models or use multi-LoRA instead.

**Typical system-design prompt:** *"You serve 30 small models (embeddings, rerankers, classifiers) with strict latency SLOs. Design the GPU layout."*

**1. Clarify first:**
- Per-model memory (weights + KV/activations at peak batch) and QPS.
- Latency SLOs and whether noisy-neighbour effects are acceptable.
- Traffic patterns (do models peak at the same time?).

**2. Back-of-envelope sizing:**
- Suppose 20 models fit in 10 GB and 10 need 20 GB. 1g.10gb: 7 per H100. 2g.20gb: 3 per H100.
- 20 small ÷ 7 ≈ 3 GPUs. 10 medium ÷ 3 ≈ 4 GPUs. Total 7 H100s (+1 spare) vs. 30 dedicated GPUs.
- Compute check: a 1g slice has ~1/7 of the SMs. If a model needs 300 QPS and one slice does 120 QPS, it needs 3 slices (replicas), not 1.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Sharing | MIG | MPS / time-slicing | MIG when isolation and predictable latency matter |
| Layout | uniform per pool | mixed per GPU | uniform pools are simpler to schedule; mixed packs tighter |
| Reconfigure | static | dynamic (DRA-based) | static unless demand shifts daily |
| Alternative | MIG slices | multi-LoRA on one model | multi-LoRA when the "models" are fine-tunes of one base |

**4. Follow-up questions with crisp answers:**
- *What does MIG isolate?* Memory, cache, and SM partitions, so one slice can't consume another's memory or bandwidth.
- *Limitations?* No NVLink/P2P between slices, reconfiguration needs idle GPUs, and fixed profile shapes.
- *Single vs. mixed strategy?* Single: all slices identical, exposed as `nvidia.com/gpu`. Mixed: slices exposed by profile name.
- *Can you train on MIG?* Small experiments yes; multi-GPU training no (no interconnect between slices).
- *How do you bill MIG?* Slice-hours weighted by slice size, from DCGM per-instance metrics.
- *What's the risk of 1g slices for an LLM?* The KV cache grows with concurrency. 10 GB fills fast, so you get OOMs or tiny batch sizes.

**Debug this (common onsite question):** *"After moving the reranker to a 1g.10gb slice, p99 latency doubled at peak, but memory is fine."*
1. Memory fits, so check compute: SM utilization on the slice is pinned at 100% at peak.
2. A 1g slice has 1/7 of the SMs, and the reranker was compute-bound at its batch size.
3. One slice can't absorb the peak QPS.
4. Fix: run 2–3 replicas on separate slices behind a load balancer, or use a 2g slice. Size slices for compute as well as memory.

The lesson: **MIG sizing has two axes: memory and compute.**

**5. What separates senior from staff answers:**
- Senior: knows the profiles, strategies, and isolation guarantees.
- Staff: does the packing math on both axes, designs pools by layout, compares against multi-LoRA and MPS, and plans chargeback.

**Red flags:** sizing slices by weights only, reconfiguring MIG on busy nodes, MIG for tensor-parallel models.

## Failure modes
- Requesting `nvidia.com/gpu` on a mixed-strategy node leaves the pod Pending (you must request the MIG resource name).
- Reconfiguring MIG while pods run makes the MIG Manager hang waiting for a drain.
- Choosing 1g slices for a model whose KV cache needs 15 GB means OOM under concurrency.

## Checklist
- [ ] A node exposes MIG resources
- [ ] A model→slice sizing table exists
- [ ] Per-slice metrics are visible
