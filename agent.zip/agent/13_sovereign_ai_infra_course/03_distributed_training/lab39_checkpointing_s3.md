# Lab 39: Fault Tolerance — Persistent Checkpointing to S3 (4:02)

## Why it matters
At scale, **failure is the steady state**. Meta reported ~419 interruptions over 54 days training
Llama 3 on 16k GPUs, about one every 3 hours. Without good checkpointing, large runs never finish.

## In plain words
Checkpoints are **save points in a video game**. On a long run something *will* crash. Save too rarely and you replay hours. Save
too often and you spend all your time saving. Async checkpointing is saving in the background while you keep playing.

## Architecture at a glance

```mermaid
flowchart LR
  T[Training step N] --> SN["Snapshot to CPU RAM: seconds"]
  SN --> T2[Training continues]
  SN -->|background| L[(Local NVMe tier)]
  L -->|background| S3[(S3/MinIO: durable)]
  F[Failure] --> R["Restart → find latest COMPLETE ckpt"]
  S3 --> R
  R --> T
```

**How to read it:** Training snapshots to RAM in seconds and keeps going while a background process writes to local NVMe, then to durable S3. After a failure, the job finds the latest complete checkpoint and resumes.

## Core concepts

**What goes in a checkpoint**
- Model weights (sharded)
- Optimizer state (typically 2× weights in fp32 for Adam)
- LR scheduler, step counter, RNG states
- **Data loader cursor** (epoch/shard/offset)
- Config + code version + data manifest hash

**Checkpoint size** ≈ 16 bytes × params for a full Adam state. A 70B model means **~1.1 TB per checkpoint**.

**Optimal interval (Young/Daly):** `interval ≈ √(2 × checkpoint_write_time × MTBF)`

| Technique | Benefit |
|---|---|
| **Sharded / distributed checkpoint (DCP)** | Every rank writes its piece in parallel |
| **Async checkpointing** | Snapshot to CPU RAM, upload in the background, training continues |
| **Tiered** | Fast local NVMe / peer memory first, then S3 |
| **Retention** | Keep the last N plus milestone checkpoints. Lifecycle-delete the rest |

## Architecture in depth

The overview shows the tiered checkpoint path. This view shows **how one checkpoint becomes "complete"** with many ranks writing in
parallel, and how restart picks a safe one.

```mermaid
sequenceDiagram
  participant R as All ranks (0..N)
  participant M as Host RAM
  participant L as Local NVMe
  participant S as S3 / MinIO
  participant C as Rank 0 (coordinator)
  R->>M: copy shard to CPU (seconds, training pauses)
  R->>R: resume training
  M->>L: write shard async
  L->>S: upload shard async (multipart)
  S-->>C: each rank reports shard done
  C->>S: write manifest + COMPLETE marker (last)
  Note over S: Restart lists COMPLETE markers only
  S->>R: load newest complete step
```

### Follow checkpoint step 12,000 from snapshot to restore
1. **Snapshot.** Every rank copies its own shard of model and optimizer state to CPU RAM. Training pauses only for this copy.
2. **Resume.** Training continues while the save happens in the background.
3. **Local tier.** Shards land on node NVMe first, which allows a fast restore when the same node restarts.
4. **Durable tier.** Shards upload to S3 or MinIO in parallel, using multipart uploads.
5. **Commit.** Rank 0 waits for every rank to report success, then writes the manifest and a COMPLETE marker *last*.
6. **Restore.** After a crash, the job lists COMPLETE markers and loads the newest one. Half-written step 12,500 is ignored.
7. **Retention.** Older checkpoints are deleted by policy (e.g. keep the last 3 + every 10k steps).

**The one idea to keep:** a checkpoint exists only when its COMPLETE marker exists. Write the marker last, and read only marked checkpoints.

## Minimal hands-on

```python
import torch.distributed.checkpoint as dcp
from torch.distributed.checkpoint.state_dict import get_state_dict, set_state_dict

def save(step, model, opt, loader_state):
    msd, osd = get_state_dict(model, opt)
    state = {"model": msd, "optim": osd, "step": step, "data": loader_state}
    dcp.async_save(state, checkpoint_id=f"s3://ckpt/run-42/step-{step}")   # via fsspec/S3 storage writer

def load(model, opt, path):
    msd, osd = get_state_dict(model, opt)
    state = {"model": msd, "optim": osd, "step": 0, "data": None}
    dcp.load(state, checkpoint_id=path)
    set_state_dict(model, opt, model_state_dict=state["model"], optim_state_dict=state["optim"])
    return state["step"], state["data"]
```

The job's entrypoint always does **"find latest valid checkpoint, resume"**, so restarts are automatic.

## Worked example

**Scenario:** A 70B fine-tune on 128 H100s. Measured MTBF for the job is ~6 h. A synchronous checkpoint takes 10 min.

| Strategy | Interval | Overhead | Expected lost work per failure |
|---|---|---|---|
| Sync, every 6 h | 6 h | 2.7% | ~3 h (avg half-interval) → **~50% waste** |
| Sync, Young/Daly optimum: √(2×10min×360min) ≈ 85 min | 85 min | 12% | ~42 min |
| **Async (30 s stall) + local NVMe tier, every 20 min** | 20 min | **~2.5%** | ~10 min |

Async plus tiered storage cut total waste from ~25% to **~5%**. On a $2M training run, that saves about $400k.

## Production deep dive
- **Atomicity:** Write to `step-N.tmp/` and rename or write a `COMPLETE` marker last. Resume logic ignores incomplete checkpoints.
- **Object store throughput:** 128 ranks writing 1 TB in parallel needs MinIO/S3 sized for tens of GB/s. Test it before the run.
- **Integrity & provenance:** Hash checkpoints and record them in MLflow (Lab 44). Sign the final model artifacts (Lab 66).
- **Auto-restart:** Kueue/Volcano `RestartJob` policies plus a health-check controller that cordons bad nodes before the restart.
- **In-memory redundancy:** Advanced systems (Gemini-style, TorchFT, NVIDIA NeMo resiliency) checkpoint into peer CPU memory for near-instant recovery.
- **Security:** Checkpoints are your crown-jewel IP. Encrypt them, restrict buckets, and audit access.

## FAANG deep-dive notes

- **How big tech does it:** Asynchronous, sharded, multi-tier checkpointing with in-memory peer redundancy, plus "goodput" as the headline metric for large runs.
- **Staff review questions:** What is the measured MTBF, and how was the interval derived? Are checkpoints atomic? Is the data loader cursor included?
- **Interview question:** *"Design checkpointing for a 10,000-GPU training run."* Strong answers cover the failure rate at scale, the Young/Daly interval, async + sharded writes, tiered storage, atomic completion markers, and fast restart.

**Typical system-design prompt:** *"Design checkpointing for a 3-month, 2,048-GPU pre-training run."*

**1. Clarify first:**
- Model and optimizer state size.
- Failure rate (MTBF per node and for the whole job).
- Storage bandwidth available and recovery time objective.

**2. Back-of-envelope sizing:**
- 70B model with Adam ≈ 1.1 TB per checkpoint (sharded across ranks).
- Job MTBF: if a node fails every ~1,000 days, 256 nodes give ~4 days per job failure. Including GPU/NCCL faults, plan for a failure about every 1–2 days.
- Young/Daly optimal interval ≈ √(2 × checkpoint_cost × MTBF) = √(2 × 60 s × 36 h) ≈ 2,500 s, roughly every 40 minutes.
- Storage: 1.1 TB in 60 s needs ~18 GB/s aggregate write. Spread across 256 nodes, that's ~73 MB/s per node, easy for async writes.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Write mode | synchronous | async (snapshot then background) | async; pause only for the snapshot |
| Tiers | S3 only | RAM/NVMe + S3 | tiered for fast restore |
| Format | full state on rank 0 | sharded / Distributed Checkpoint | sharded at scale |
| Frequency | fixed | Young/Daly from measured MTBF | recompute as failure rates change |
| Integrity | trust writes | manifest + checksums + COMPLETE | always verify |

**4. Follow-up questions with crisp answers:**
- *Why async checkpointing?* A sync save of 1 TB can pause 2,048 GPUs for minutes, which costs thousands of dollars each time.
- *Why a COMPLETE marker?* Crashes during save leave partial checkpoints. The marker makes "complete" atomic.
- *What must be saved besides weights?* Optimizer state, LR scheduler, RNG states, data-loader position, and the step number.
- *How fast must restore be?* With failures every day or two, restore time × failures = lost time. Aim for minutes.
- *Can you change GPU count on resume?* Yes with resharding-capable formats (Distributed Checkpoint), which helps after losing nodes.
- *Where's the real cost?* Lost work since the last checkpoint plus restart time, multiplied by the failure count.

**Debug this (common onsite question):** *"After a crash, the job resumed but loss jumped and never recovered to the previous curve."*
1. The checkpoint loaded model weights but not the optimizer state (a code path saved weights only).
2. Adam's moment estimates were reset, so the effective learning rate spiked.
3. The data loader also restarted at epoch 0, so it re-saw early data.
4. Fix: save and validate the full training state (optimizer, scheduler, RNG, loader), and add a resume test that compares loss over 100 steps after restore with an uninterrupted run.

The lesson: **a checkpoint you never restored in a test is a hope, not a backup.**

**5. What separates senior from staff answers:**
- Senior: async sharded checkpoints to object storage with atomic completion.
- Staff: sets the interval from measured MTBF, designs tiered restore for minutes-level recovery, tracks goodput, and runs regular restore drills.

**Red flags:** synchronous full saves, no COMPLETE marker, weights-only checkpoints, never testing restore, fixed intervals ignoring failure rate.

## Failure modes
- Saving model weights but not optimizer state means the resumed run diverges.
- No data cursor, so the model re-sees early data, which causes overfitting and broken reproducibility.
- Rank 0 gathers the full state dict, runs out of CPU memory, and the checkpoint crashes the job it was meant to protect.

## Checklist
- [ ] Kill a pod mid-training and confirm it auto-resumes from the latest checkpoint
- [ ] Checkpoint interval derived from measured MTBF
- [ ] Atomic write + retention lifecycle configured
