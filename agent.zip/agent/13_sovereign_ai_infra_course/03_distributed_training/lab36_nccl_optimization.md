# Lab 36: NCCL Backend Optimization on Kubernetes (3:50)

## Why it matters
NCCL is the library that actually moves gradients between GPUs. A fast fabric (Lab 35) is
wasted if NCCL picks the wrong interface, algorithm, or transport, which happens often inside containers.

## In plain words
NCCL is the **group-chat app** GPUs use to share results. If it can't find the fast private line (InfiniBand), it silently falls back
to the slow public internet (TCP). Training still works, just 5× slower, and nobody tells you. `NCCL_DEBUG=INFO` is how you check which line it used.

## Architecture at a glance

```mermaid
flowchart TB
  N[NCCL picks transport] --> Q1{Same node?}
  Q1 -->|yes| NV[NVLink / P2P: fastest]
  Q1 -->|no| Q2{RDMA device + IPC_LOCK + GDR?}
  Q2 -->|yes| IB[IB / RoCE verbs ✅]
  Q2 -->|no| TCP["TCP sockets ❌ silent 5× slowdown"]
```

**How to read it:** Follow NCCL's decision tree. On the same node it uses NVLink. Across nodes it uses RDMA only if the device, permissions, and GPUDirect are all present. Otherwise it silently falls back to TCP.

## Core concepts

**Collectives**

| Op | What | Used by |
|---|---|---|
| All-reduce | Sum across ranks, result everywhere | DDP gradients |
| All-gather | Concatenate shards everywhere | FSDP forward |
| Reduce-scatter | Sum then shard | FSDP backward |
| All-to-all | Each rank sends distinct data to each other rank | MoE expert routing |
| Broadcast | One to all | Weight init |

**Algorithms:** *Ring* (bandwidth-optimal, latency ∝ N) and *Tree* (lower latency at scale). NVLS/CollNet
offload reduction to NVSwitch or IB SHARP.

**Transports:** NVLink/P2P (intra-node), then SHM, then **IB/RoCE verbs (net)**, then TCP sockets (last resort).

**Key environment variables**

| Var | Purpose |
|---|---|
| `NCCL_DEBUG=INFO` | **Always on first run.** Prints the chosen transports |
| `NCCL_SOCKET_IFNAME=eth0` | Bootstrap interface (avoid `lo`, docker0) |
| `NCCL_IB_HCA=mlx5_0,mlx5_1,...` | Which RDMA NICs to use |
| `NCCL_IB_GID_INDEX=3` | RoCEv2 GID (commonly 3) |
| `NCCL_NET_GDR_LEVEL` | GPUDirect RDMA aggressiveness |
| `NCCL_ALGO` / `NCCL_PROTO` | Force algorithm (only for testing) |
| `NCCL_TIMEOUT` / `TORCH_NCCL_ASYNC_ERROR_HANDLING=1` | Fail fast instead of hanging forever |

## Architecture in depth

The overview shows NCCL's transport decision. This view shows **how NCCL runs one all-reduce**: topology detection, algorithm
choice, and the channels that carry the data.

```mermaid
flowchart TB
  INIT[ncclCommInit] --> TOPO["Detect topology<br/>NVLink, PCIe switches, NICs, NUMA"]
  TOPO --> GRAPH["Build graphs<br/>rings + trees"]
  GRAPH --> ALG{"Pick algorithm per message size"}
  ALG -->|"large messages"| RING["Ring: bandwidth-optimal"]
  ALG -->|"small messages / many nodes"| TREE["Tree: latency-optimal"]
  ALG -->|"NVSwitch / SHARP"| NVLS["NVLS / CollNet: in-network reduction"]
  RING & TREE & NVLS --> CH["Split into channels<br/>parallel streams over NICs"]
  CH --> PROTO["Protocol: LL, LL128, Simple"]
  PROTO --> NET["Transport: P2P/NVLink in node, IB/RoCE across"]
```

### Follow one 1 GB gradient all-reduce
1. **Topology detection.** At startup NCCL maps which GPUs share NVLink, which NIC is closest to each GPU (PCIe and NUMA), and how many NICs exist.
2. **Graph building.** It builds rings and trees that keep traffic on the fastest links, e.g. NVLink inside a node and one NIC per GPU across nodes.
3. **Algorithm choice.** For a 1 GB message, a ring is bandwidth-optimal. For tiny messages across many nodes, a tree cuts latency.
4. **Channels.** Data is split into channels (parallel streams) so all NICs and NVLinks are busy at once.
5. **Protocol.** LL/LL128 favour latency for small chunks, and Simple favours bandwidth for large ones.
6. **Transport.** Within a node P2P/NVLink is used, and across nodes IB/RoCE verbs with GPUDirect RDMA. If any requirement is missing, it silently falls back to TCP.

**The one idea to keep:** NCCL is fast only if it can *see* the right hardware. Most tuning is making the pod expose topology and devices correctly.

## Minimal hands-on

```bash
# nccl-tests as an MPIJob/PyTorchJob across 2 nodes
all_reduce_perf -b 8 -e 8G -f 2 -g 1
# Read the "busbw" column. Targets (approx):
#   intra-node H100 NVLink: ~450 GB/s     inter-node NDR IB x8: ~350-400 GB/s
```

```bash
NCCL_DEBUG=INFO torchrun ... 2>&1 | grep -E "NET/IB|NET/Socket|via P2P"
#   "NET/IB : Using [0]mlx5_0:1/RoCE"   ✅ RDMA
#   "NET/Socket : Using [0]eth0"        ❌ TCP fallback
```

## Worked example

**Scenario:** A team moves a working 4-node job from Slurm bare metal to K8s. It is **4.5× slower** with no errors.

Debug path:
1. `NCCL_DEBUG=INFO` shows `NET/Socket: Using eth0`, a TCP fallback.
2. The pod had no RDMA device resource and no `IPC_LOCK` capability.
3. After fixing that, it uses IB but busbw is only 120 GB/s. GPUDirect is disabled because `nvidia-peermem` is not loaded on the host.
4. With the module loaded via the GPU Operator (`driver.rdma.enabled=true`), busbw reaches **370 GB/s** and step time matches bare metal within 3%.

Write this procedure down as a **runbook**. Every new cluster goes through it.

## Production deep dive
- **Acceptance tests:** Run `nccl-tests` across all node pairs before a cluster or node enters the pool, and on a schedule afterwards. A degraded link or GPU gets cordoned automatically.
- **Topology files:** NCCL auto-detects topology but sometimes fails inside VMs/containers. Provide `NCCL_TOPO_FILE` for cloud SKUs (cloud vendors publish these).
- **Network plugins:** AWS EFA uses `aws-ofi-nccl`, GCP uses TCPXO/gIB plugins. Bake them into images.
- **Hang detection:** PyTorch flight recorder (`TORCH_NCCL_TRACE_BUFFER_SIZE`) dumps the last collectives on timeout, so you can find the straggler rank.
- **Version pinning:** NCCL is bundled with PyTorch. Upgrades can change algorithm selection, so re-benchmark on every bump.

## FAANG deep-dive notes

- **How big tech does it:** Every node passes collective-communication acceptance tests before joining a pool, and periodic sweeps catch degraded links. Hang detection dumps flight-recorder traces automatically.
- **Staff review questions:** What is the measured all-reduce bus bandwidth? How do you detect a TCP fallback? What is the collective timeout?
- **Interview question:** *"A job moved from bare metal to K8s is 4× slower with no errors."* Strong answers start with `NCCL_DEBUG`, then check RDMA device exposure, IPC_LOCK, `nvidia-peermem`, interface selection, and topology detection.

**Typical system-design prompt:** *"A training team says multi-node jobs on the new Kubernetes cluster are 4× slower than on bare metal. Design how you'd find and prevent this."*

**1. Clarify first:**
- Same NCCL and driver versions on both?
- Pod networking: is RDMA exposed (SR-IOV/Multus, IPC_LOCK, hugepages, `/dev/infiniband`)?
- Topology: are pods pinned to the right NUMA nodes?

**2. Back-of-envelope sizing:**
- Expected all-reduce bus bandwidth on 8×400 Gb/s per node ≈ 350–380 Gb/s per GPU (~45 GB/s). TCP fallback typically gives 5–10 GB/s.
- A 70B training step with 140 GB of gradient traffic: at 45 GB/s ≈ 3 s, at 8 GB/s ≈ 17 s. That's the 4–5× slowdown.
- nccl-tests takes ~2 minutes per run, cheap enough to run at every node admission.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Tuning | many NCCL env vars | defaults + correct topology | fix topology first; few env vars |
| Validation | at job start | at node admission + periodically | gate nodes on nccl-tests |
| Debug visibility | off | `NCCL_DEBUG=INFO` in first runs | log transport selection always |
| Pod network | host network | SR-IOV + Multus | SR-IOV for isolation with RDMA |

**4. Follow-up questions with crisp answers:**
- *How do you confirm the transport?* `NCCL_DEBUG=INFO` shows "NET/IB" vs. "NET/Socket" per channel.
- *Why IPC_LOCK?* RDMA needs pinned (locked) memory, so the container needs that capability.
- *What is bus bandwidth in nccl-tests?* A normalized number comparable to link speed, independent of the GPU count.
- *Why do NUMA and PCIe matter?* A GPU using a NIC on the other CPU socket crosses the inter-socket link, cutting bandwidth.
- *What's NCCL_IB_HCA for?* Choosing which NICs to use, for example excluding the management NIC.
- *Why do jobs hang instead of failing?* A collective waits for all ranks. Set timeouts and enable async error handling.

**Debug this (common onsite question):** *"After a base-image update, training throughput dropped 30% but nothing errors."*
1. Compare NCCL INFO logs: the new image uses 4 channels instead of 16.
2. The new image ships a different NCCL version with a topology-detection change for this PCIe layout.
3. NCCL only sees 2 of 8 NICs as near the GPUs.
4. Fix: pin the NCCL version in the base image, provide a topology XML file, and add an nccl-tests bus-bandwidth gate to the image release pipeline.

The lesson: **NCCL is part of your platform contract. Version it, test it, and gate releases on bandwidth.**

**5. What separates senior from staff answers:**
- Senior: reads NCCL logs, fixes RDMA exposure, runs nccl-tests.
- Staff: builds bandwidth gates into node admission and image release, owns the NCCL and driver version matrix, and makes performance regressions visible automatically.

**Red flags:** not knowing which transport is in use, copy-pasted NCCL env vars, no bandwidth gate, unpinned NCCL versions.

## Failure modes
- `NCCL_SOCKET_IFNAME` unset, so bootstrap picks the Multus interface without routing and the job hangs at init.
- One slow GPU (thermal throttling) gates every collective, and the whole job runs at its speed.
- Default timeout of 30+ minutes means hung jobs waste GPU-hours. Lower it and enable async error handling.

## Checklist
- [ ] `nccl-tests` busbw is recorded for intra-node and inter-node
- [ ] The NCCL debug log confirms IB/RoCE + GDR
- [ ] Hang detection and timeouts are configured
