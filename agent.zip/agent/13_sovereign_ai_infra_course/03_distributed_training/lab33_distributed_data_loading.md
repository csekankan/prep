# Lab 33: Distributed Data Loading and Memory Mapping (3:48)

## Why it matters
An H100 can consume training data faster than most storage systems can deliver it. If the GPUs
wait on data, you are paying for idle hardware. **Data loading is a distributed-systems problem.**

## In plain words
GPUs are **very fast eaters**. If the kitchen (data pipeline) is slow, they sit hungry and you pay for idle time. Prepare the food in
advance (pre-tokenize), keep it in big trays (shards), and use a conveyor belt (prefetch + pinned memory) so a plate is always ready.

## Architecture at a glance

```mermaid
flowchart LR
  S3[(Object store shards)] --> NV[(Node NVMe cache)]
  NV -->|mmap| W1[Loader worker 1]
  NV -->|mmap| W2[Loader worker N]
  W1 & W2 --> PB[Pinned host buffer]
  PB -->|async copy| GPU[GPU computes batch N<br/>while N+1 loads]
```

**How to read it:** Data flows left to right: object store, then NVMe cache, then memory-mapped reads by parallel workers into pinned memory, then an asynchronous copy to the GPU. The GPU always has the next batch ready.

## Core concepts

| Technique | Idea |
|---|---|
| **Sharding by rank** | Each worker reads a disjoint subset (`DistributedSampler`) |
| **Streaming formats** | WebDataset (tar shards), MosaicML Streaming (MDS), Parquet, Arrow |
| **Memory mapping (mmap)** | OS pages file data on demand. Zero-copy, shared across processes |
| **Prefetch & pipelining** | CPU prepares batch N+1 while the GPU computes batch N |
| **Pinned memory** | Page-locked host RAM gives faster, async H2D copies |
| **GPU decode** | NVIDIA DALI decodes images/video on the GPU |

```
Object store (S3/MinIO) ──► shard cache (NVMe) ──► mmap ──► DataLoader workers ──► pinned buffer ──► GPU
         sequential large reads        page cache         parallel decode/augment      non_blocking=True
```

**Why shards:** Millions of small files kill object stores and filesystems through metadata operations. A
100–500 MB shard of many samples turns random reads into sequential ones.

## Architecture in depth

The overview shows the data path. This view shows the **pipeline timeline**: how prefetch overlaps loading with compute, and what
happens when one stage is slower than the GPU.

```mermaid
gantt
  title Data loading overlapped with GPU compute
  dateFormat X
  axisFormat %s
  section Storage → NVMe
  shard 1 :a1, 0, 4
  shard 2 :a2, 4, 8
  section Loader workers
  decode batch 1 :b1, 1, 3
  decode batch 2 :b2, 3, 5
  decode batch 3 :b3, 5, 7
  section H2D copy
  copy 1 :c1, 3, 4
  copy 2 :c2, 5, 6
  copy 3 :c3, 7, 8
  section GPU
  step 1 :d1, 4, 6
  step 2 :d2, 6, 8
  step 3 :d3, 8, 10
```

### Follow one batch from storage to the GPU
1. **Shards, not files.** Data lives as large shards (e.g. 1 GB WebDataset or Parquet), not millions of tiny files, so object-store requests stay few and fast.
2. **Local cache.** Shards stream to node NVMe once. Later epochs read locally.
3. **Memory map.** Workers `mmap` shards. The OS page cache shares the bytes across processes, so there is no copy per worker.
4. **Decode in parallel.** `num_workers` processes tokenize and augment while the GPU computes on the previous batch.
5. **Pinned memory.** Batches land in page-locked RAM, so the copy to the GPU can run asynchronously.
6. **Prefetch.** `prefetch_factor` keeps 2–4 batches waiting, which absorbs jitter in storage and decode.
7. **Bottleneck check.** If the GPU row in the timeline has gaps, the loader is the bottleneck. Add workers, cache, or pre-tokenize.

**The one idea to keep:** the GPU should never wait. Every stage before it must be faster than it, with a buffer in between.

## Minimal hands-on

```python
import numpy as np, torch
from torch.utils.data import Dataset, DataLoader, DistributedSampler

class TokenDataset(Dataset):                     # pre-tokenized uint16 array on disk
    def __init__(self, path, seq=2048):
        self.data = np.memmap(path, dtype=np.uint16, mode="r")   # no RAM load
        self.seq = seq
    def __len__(self): return len(self.data) // self.seq - 1
    def __getitem__(self, i):
        x = self.data[i*self.seq:(i+1)*self.seq+1].astype(np.int64)
        return torch.from_numpy(x[:-1]), torch.from_numpy(x[1:])

ds = TokenDataset("/data/train.bin")
dl = DataLoader(ds, batch_size=8, sampler=DistributedSampler(ds),
                num_workers=8, pin_memory=True, prefetch_factor=4, persistent_workers=True)
```

Ray Data for preprocessing at scale:

```python
import ray
ds = ray.data.read_parquet("s3://lake/docs/").map_batches(tokenize, batch_size=1024)
```

## Worked example

**Scenario:** Pre-training a 1B model on **500B tokens** across 64 H100s.

- Throughput needed: each GPU processes ~25k tokens/s, so 64 × 25k = **1.6M tokens/s**, about 3.2 MB/s of uint16 tokens. That is *tiny*.
- The bottleneck was **not bandwidth**. The original pipeline tokenized raw JSON on the fly, and the CPU maxed out at 400k tokens/s.
- Fix: offline tokenization with Ray Data into 1 GB `.bin` shards on MinIO, then node-local NVMe caching and `np.memmap`.
- GPU idle time dropped from 38% to under 2%.

The lesson: **move expensive preprocessing offline. Training should read pre-baked tensors.**

## Production deep dive
- **Determinism and resumability:** Record the (epoch, shard, offset) cursor in checkpoints so a resumed job doesn't re-see or skip data (Lab 39).
- **Data mixing:** Weighted sampling across sources (code 20%, web 50%, papers 10%, ...) is a governance artifact. Version it alongside the model.
- **Provenance:** Hash every shard (Lab 66). The training manifest equals the list of shard hashes.
- **Caching layers:** Alluxio/JuiceFS/Fluid for hot datasets, and GPUDirect Storage for direct NVMe→GPU paths.
- **Multimodal:** Video/image pipelines are *heavily* CPU/decoder-bound. Use DALI or GPU decoding and budget 8–16 CPU cores per GPU.

## FAANG deep-dive notes

- **How big tech does it:** Offline preprocessing into large, sharded, deterministic datasets. Training only reads pre-baked tensors, with resumable cursors stored in checkpoints.
- **Staff review questions:** What percentage of step time is input stall? Can a resumed job continue exactly where it left off in the data? How are data mixtures versioned?
- **Interview question:** *"GPUs are idle 30% of the time waiting for data. Fix it."* Strong answers profile the bottleneck (CPU decode, I/O, small files), move preprocessing offline, shard, cache locally, prefetch, and use pinned memory.

**Typical system-design prompt:** *"Design the data pipeline for pre-training on 15 trillion tokens across 1,024 GPUs."*

**1. Clarify first:**
- Data format and location (tokenized shards on S3? raw text?).
- Throughput needed per GPU (tokens/s) and total.
- Determinism: must you resume mid-epoch at the exact sample?

**2. Back-of-envelope sizing:**
- 1,024 GPUs × 3,000 tokens/s ≈ 3M tokens/s. At 2 bytes per token (pre-tokenized uint16), that's ~6 MB/s per GPU, ~6 GB/s total. That's easy if pre-tokenized, hard if decoding raw text on the fly.
- 15T tokens × 2 bytes = 30 TB of tokenized data. Stream from object store with NVMe caching per node.
- Shard count: 30 TB ÷ 1 GB = 30k shards, enough for each of 1,024 ranks to get distinct shards.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Format | raw files | pre-tokenized shards | pre-tokenize for pre-training |
| Access | random file reads | sequential shard streaming + shuffle buffer | streaming at scale |
| Storage | parallel FS (Lustre/Weka) | object store + NVMe cache | object store + cache is cheaper; parallel FS for random access |
| Resume | restart epoch | checkpoint loader state | save sample offsets with each checkpoint |

**4. Follow-up questions with crisp answers:**
- *Why not millions of small files?* Per-request overhead dominates, and metadata servers melt.
- *Why pinned memory?* It allows asynchronous DMA to the GPU, overlapping copy with compute.
- *How do you shuffle in streaming?* Shuffle shard order per epoch, plus an in-memory shuffle buffer within shards.
- *What's the signal of a loader bottleneck?* GPU idle gaps, low SM activity, and step time varying with I/O.
- *Why save loader state in checkpoints?* Without it, a resumed run re-reads or skips data, which skews training.
- *How many workers?* Start at about the CPU cores per GPU, then tune until GPU idle gaps disappear.

**Debug this (common onsite question):** *"Step time is 1.2 s for the first epoch and 0.6 s afterwards."*
1. In epoch 1, data streams from S3 and fills the NVMe cache. After that, reads are local.
2. The S3 throughput per node is 400 MB/s, but the job needs ~800 MB/s at full speed.
3. The first epoch is I/O bound, and the GPUs are idle half the time.
4. Fix: pre-warm caches before the job starts (a DaemonSet or init job), use larger shards, raise S3 concurrency, or pre-tokenize to shrink bytes.

The lesson: **measure the GPU idle fraction per epoch. The first-epoch slowdown is storage, not the model.**

**5. What separates senior from staff answers:**
- Senior: tunes workers, pinning, and prefetch to remove GPU idle time.
- Staff: designs the data format and storage tier for the whole training program, ensures deterministic resume, and sizes storage throughput against cluster growth.

**Red flags:** raw-text decoding at pre-training scale, tiny files, no loader state in checkpoints, nobody measuring GPU idle time.

## Failure modes
- `num_workers` too high spawns 8 GPUs × 16 workers = 128 processes and causes memory explosion.
- No `persistent_workers`, so workers are re-forked every epoch, a multi-minute stall.
- Object-store `LIST` operations over millions of keys at job start take 20 minutes. Use a manifest file instead.

## Checklist
- [ ] Data is pre-tokenized into shards
- [ ] The DataLoader uses mmap + pinned memory + prefetch
- [ ] GPU idle-due-to-input is measured (< 5%)
