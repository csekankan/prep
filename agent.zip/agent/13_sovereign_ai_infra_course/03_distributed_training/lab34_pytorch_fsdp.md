# Lab 34: PyTorch FSDP (Fully Sharded Data Parallel) Concepts (3:52)

## Why it matters
DDP keeps a **full copy** of the model, gradients, and optimizer state on every GPU. FSDP **shards
all three** across GPUs and gathers parameters only when a layer needs them. That lets you
train models N× bigger than one GPU can hold.

## In plain words
Imagine 8 people assembling a huge IKEA wardrobe. With DDP, **everyone holds a complete copy of every part**, which doesn't fit in
the room. With FSDP, each person holds 1/8 of the parts and **briefly borrows the others' parts** only for the step they're building, then hands them back.

## Architecture at a glance

```mermaid
flowchart LR
  subgraph Layer_i["Layer i: forward"]
    S0[GPU0 shard] & S1[GPU1 shard] & S2[GPU2 shard] & S3[GPU3 shard] --> AG[All-gather → full layer]
    AG --> CMP[Compute]
    CMP --> FR[Free full params]
  end
  FR --> BW[Backward: grads]
  BW --> RS[Reduce-scatter → each GPU keeps 1/4 grads]
  RS --> OPT[Each GPU updates its own shard]
```

**How to read it:** For each layer, every GPU contributes its shard to an all-gather, computes, then frees the full parameters. In backward, a reduce-scatter leaves each GPU with only its slice of gradients to update.

## Core concepts

```
DDP (4 GPUs):   [P G O] [P G O] [P G O] [P G O]       memory per GPU = 16 B × params
FSDP (4 GPUs):  [¼P ¼G ¼O] × 4                        memory per GPU ≈ 16 B × params / 4
```

Per layer, during forward and backward:
1. **All-gather** the layer's parameter shards, giving the full layer temporarily.
2. Compute.
3. **Free** the full params (keep only the shard).
4. In backward: compute grads, then **reduce-scatter** so each rank keeps only its gradient shard.

| Sharding strategy | Shards | Comm | Use |
|---|---|---|---|
| `FULL_SHARD` (ZeRO-3) | P, G, O | Highest | Largest models |
| `SHARD_GRAD_OP` (ZeRO-2) | G, O | Medium | Mid-size |
| `HYBRID_SHARD` | Full shard **within** a node, replicate **across** nodes | Intra-node heavy | **Multi-node default** |
| `NO_SHARD` | — | = DDP | Small models |

**FSDP2** (`fully_shard`, per-parameter DTensor) is the modern API. It composes with TP and `torch.compile`.

## Architecture in depth

The overview shows one layer's all-gather and reduce-scatter. This view shows **memory per GPU over one training step**, which explains
why FSDP lets a model fit that DDP cannot.

```mermaid
flowchart TB
  subgraph DDP["DDP: every GPU holds everything"]
    D1["Params 16 GB + Grads 16 GB + Adam 64 GB<br/>= 96 GB per GPU (8B model, fp32 states)"]
  end
  subgraph FSDP["FSDP FULL_SHARD on 8 GPUs"]
    F1["Sharded params/grads/optimizer: 96 ÷ 8 = 12 GB"]
    F2["+ one unit gathered at a time: ~1-2 GB"]
    F3["+ activations: batch-dependent"]
  end
  DDP -->|"shard everything"| FSDP
  subgraph Step["One step, per FSDP unit"]
    S1[all-gather params] --> S2[forward] --> S3[free] --> S4[all-gather again] --> S5[backward] --> S6[reduce-scatter grads] --> S7[update local shard]
  end
```

### Follow one FSDP step for one transformer block
1. **Resting state.** Each GPU holds 1/8 of the block's parameters, gradients, and optimizer state.
2. **All-gather.** Before forward, the GPUs exchange shards, so each briefly holds the full block.
3. **Forward, then free.** Compute the block's output, then discard the gathered parameters.
4. **Prefetch.** While block *i* computes, FSDP already gathers block *i+1*, hiding communication.
5. **Backward.** Gather again, compute gradients, and free.
6. **Reduce-scatter.** Gradients are summed across GPUs, and each GPU keeps only its 1/8 slice.
7. **Update.** Each GPU updates its own shard with the optimizer. No GPU ever stores the full optimizer state.

**The one idea to keep:** FSDP trades extra communication (gathering every step) for an 8× smaller resident memory footprint.

## Minimal hands-on

```python
import os, torch, torch.distributed as dist
from torch.distributed.fsdp import fully_shard, MixedPrecisionPolicy
from transformers import AutoModelForCausalLM

dist.init_process_group("nccl")
torch.cuda.set_device(int(os.environ["LOCAL_RANK"]))
model = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-3.1-8B", torch_dtype=torch.bfloat16)

mp = MixedPrecisionPolicy(param_dtype=torch.bfloat16, reduce_dtype=torch.float32)
for layer in model.model.layers:          # shard each transformer block
    fully_shard(layer, mp_policy=mp)
fully_shard(model, mp_policy=mp)

opt = torch.optim.AdamW(model.parameters(), lr=2e-5)
```

```bash
torchrun --nnodes=2 --nproc-per-node=8 --rdzv-backend=c10d --rdzv-endpoint=$MASTER:29500 train.py
```

On K8s use the **Kubeflow Training Operator `PyTorchJob`** or **Ray Train `TorchTrainer`**, which set the env vars for you.

## Worked example

**Scenario:** Full fine-tune of **Llama-3.1-8B** on 8× A100-80GB (one node).

| Setup | Memory/GPU (excl. activations) | Fits? |
|---|---|---|
| DDP | 8B × 16 B = **128 GB** | ❌ |
| FSDP FULL_SHARD, 8 GPUs | 128 / 8 = **16 GB** | ✅ ~60 GB left for activations |
| + activation checkpointing | Activations ↓ ~70% | ✅ batch size 4 → 16 |

Scaling to 4 nodes: `HYBRID_SHARD` keeps the heavy all-gathers on NVLink (600 GB/s) and only
gradient all-reduce crosses the 400 Gb/s IB network. That achieved **91% scaling efficiency** versus 68% with
FULL_SHARD across all 32 GPUs.

## Production deep dive
- **Activation checkpointing** trades ~30% more compute for large memory savings. Use it almost always for LLMs.
- **CPU offload:** Fits huge models on few GPUs but is slow. Use it for experiments, not production pre-training.
- **Checkpointing:** Use **distributed checkpoint (DCP)** with sharded state dicts, where each rank writes its own shard in parallel (Lab 39).
- **FSDP vs. DeepSpeed ZeRO:** Equivalent ideas. FSDP is native PyTorch; DeepSpeed offers ZeRO++ and Infinity offload. Standardize on one.
- **Beyond ~70B:** Combine with TP (FSDP2 + DTensor) or move to Megatron-style 3D parallelism (Lab 40).

## FAANG deep-dive notes

- **How big tech does it:** Sharded data parallelism (FSDP/ZeRO-style) is the default for mid-size models, combined with tensor parallelism inside nodes for larger ones, and hybrid sharding to keep heavy traffic on NVLink.
- **Staff review questions:** What is memory per GPU with and without sharding? Why this sharding strategy? Is communication overlapped with compute?
- **Interview question:** *"Fine-tune a 13B model on 8× 40 GB GPUs. Will it fit?"* Strong answers compute 13B × 16 B ≈ 208 GB of state, show that FSDP across 8 brings it to ≈ 26 GB/GPU, then add activations and recommend checkpointing or offload.

**Typical system-design prompt:** *"Fine-tune a 70B model on 32 H100s. Choose the parallelism strategy and justify it."*

**1. Clarify first:**
- Full fine-tune or LoRA? (This changes memory by 10×.)
- Sequence length (activations grow with it).
- Interconnect: NVLink within nodes, IB between them?

**2. Back-of-envelope sizing:**
- Full fine-tune with mixed precision + Adam ≈ 16 bytes/param → 70B × 16 = 1.12 TB of state.
- FSDP across 32 GPUs: 1.12 TB ÷ 32 = 35 GB per GPU + activations, which fits in 80 GB with activation checkpointing.
- Communication per step ≈ 3 × param bytes (all-gather forward, all-gather backward, reduce-scatter) = 3 × 140 GB (bf16) = 420 GB per step across the group. With 400 Gb/s IB per GPU, it must overlap with compute.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Sharding | FULL_SHARD | HYBRID_SHARD (shard in node, replicate across) | hybrid when inter-node bandwidth is the limit |
| Memory | larger batch | activation checkpointing | checkpoint when activations dominate |
| Method | full fine-tune | LoRA/QLoRA | LoRA unless quality demands full |
| Framework | FSDP2 | DeepSpeed ZeRO-3 | equivalent concepts; follow your stack |
| Very large scale | FSDP only | TP + PP + DP (Lab 40) | add TP/PP beyond ~100B or very long sequences |

**4. Follow-up questions with crisp answers:**
- *FSDP vs. DDP?* DDP replicates everything. FSDP shards parameters, gradients, and optimizer state.
- *How does it map to ZeRO?* ZeRO-1 shards optimizer state, ZeRO-2 adds gradients, ZeRO-3 (FULL_SHARD) adds parameters.
- *Why HYBRID_SHARD?* It keeps the frequent all-gathers on fast NVLink within a node, and only replicates across nodes.
- *What is activation checkpointing?* Drop activations in forward and recompute them in backward, about 30% more compute for a big memory saving.
- *What wraps an FSDP unit?* Typically each transformer block, the granularity of gather and free.
- *How do you save checkpoints?* Sharded state dicts (each rank writes its shard) or Distributed Checkpoint, not a full gather to rank 0.

**Debug this (common onsite question):** *"FSDP training on 4 nodes is slower per GPU than on 1 node, by 2.5×."*
1. Profiling shows long all-gather waits, so communication isn't overlapping with compute.
2. NCCL logs show traffic going over TCP, not IB (see Lab 36).
3. Even after fixing transport, FULL_SHARD across nodes saturates the inter-node links.
4. Fix: enable RDMA, switch to HYBRID_SHARD, enable forward prefetch, and increase micro-batch to raise compute per communication.

The lesson: **FSDP's cost is communication. Place shards where bandwidth is highest.**

**5. What separates senior from staff answers:**
- Senior: configures FSDP with correct wrapping, mixed precision, and checkpointing.
- Staff: chooses sharding topology from bandwidth math, knows when to move to 3D parallelism, and designs checkpoint formats for resume and evaluation.

**Red flags:** full fine-tune when LoRA would do, FULL_SHARD over slow links, gathering full checkpoints on rank 0, no activation checkpointing for long sequences.

## Failure modes
- Wrapping only the root module gives no memory savings, because each layer must be sharded individually.
- Mixed precision with `reduce_dtype=bf16` causes gradient precision loss and divergence on long runs.
- Rank 0 alone loads a full checkpoint into CPU RAM and every other rank waits. Use meta-device init + sharded load.

## Checklist
- [ ] You can compute memory with DDP vs. FSDP for your model
- [ ] Per-layer wrapping + mixed precision configured
- [ ] HYBRID_SHARD tested for multi-node
