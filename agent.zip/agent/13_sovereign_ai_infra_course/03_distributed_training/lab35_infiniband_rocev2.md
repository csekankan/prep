# Lab 35: The Quantum Highway — Configuring InfiniBand and RoCEv2 (3:55)

## Why it matters
In multi-node training, GPUs spend a large share of each step **exchanging gradients**. On a normal
TCP network at 25 Gb/s, an 8-node job can be 80% communication. RDMA fabrics at 400–800 Gb/s
per GPU make the cluster behave closer to one giant computer.

## In plain words
Normal networking is **posting letters through a post office** (the CPU and OS handle every packet). RDMA is a **private pneumatic tube
straight from one GPU's desk to another's**, skipping the post office entirely. For training, where GPUs exchange gigabytes every second, that tube is everything.

## Architecture at a glance

```mermaid
flowchart LR
  subgraph NodeA
    GA[GPU0] --- NA[NIC0]
  end
  subgraph NodeB
    GB[GPU0] --- NB[NIC0]
  end
  NA -->|"RDMA: no CPU, no copies"| L0[Leaf switch: rail 0]
  L0 --> NB
  L0 --- SP[Spine]
  CPU[CPU / kernel] -.bypassed.- NA
```

**How to read it:** Compare two paths: normal traffic goes through the CPU and kernel, while RDMA goes straight from GPU to NIC to switch to the remote GPU. The same-rank GPUs on every node share one rail switch.

## Core concepts

**RDMA (Remote Direct Memory Access):** The NIC writes directly into remote memory. No CPU, no
kernel, no copies. **GPUDirect RDMA** extends this to GPU memory, so data moves GPU→NIC→wire→NIC→GPU.

| Fabric | Transport | Pros | Cons |
|---|---|---|---|
| **InfiniBand** (NDR 400G / XDR 800G) | Native, credit-based lossless | Lowest latency, SHARP in-network reduction, mature | Separate fabric, NVIDIA-centric, cost |
| **RoCEv2** | RDMA over UDP/IP Ethernet | Uses Ethernet skills/gear, multi-vendor | Needs lossless tuning (PFC/ECN), congestion is harder |
| Ultra Ethernet (UEC) | Next-gen Ethernet for AI | Open standard | Emerging |

**Rail-optimized topology:** On an 8-GPU node with 8 NICs, GPU *i* on every node connects to the same leaf
switch, "rail *i*". Same-rank traffic stays one hop away.

```
        Spine switches
       /   |    |    \
   Leaf0 Leaf1 ... Leaf7      ← one "rail" per GPU index
    |  \   |  \     |
  Node A GPU0..7 → NIC0..7   (GPU0→Leaf0, GPU1→Leaf1, ...)
  Node B GPU0..7 → NIC0..7
```

**Two networks per node:** a front-end (Ethernet, for K8s/storage/API) and a back-end (IB/RoCE, for GPU↔GPU only).

## Architecture in depth

The overview shows GPU-to-NIC-to-switch paths. This view shows the **rail-optimized fabric** used in GPU clusters, and how one
all-reduce message crosses it.

```mermaid
flowchart TB
  subgraph Node1
    G10[GPU0] --- N10[NIC0]
    G17[GPU7] --- N17[NIC7]
  end
  subgraph Node2
    G20[GPU0] --- N20[NIC0]
    G27[GPU7] --- N27[NIC7]
  end
  N10 --> R0[Leaf: rail 0]
  N20 --> R0
  N17 --> R7[Leaf: rail 7]
  N27 --> R7
  R0 --- S1[Spine 1]
  R0 --- S2[Spine 2]
  R7 --- S1
  R7 --- S2
  SM["IB: Subnet Manager<br/>RoCE: PFC + ECN config"] -.-> R0
  SM -.-> R7
```

### Follow one message from GPU0 on Node 1 to GPU0 on Node 2
1. **GPUDirect RDMA.** The NIC reads directly from GPU memory over PCIe. There is no copy through CPU RAM.
2. **Same rail.** GPU0 uses NIC0, which connects to leaf switch "rail 0". GPU0 on every node also uses rail 0.
3. **One hop.** Because both endpoints share rail 0, the message crosses a single leaf switch. Spine switches are only needed between rails.
4. **Lossless transport.** On InfiniBand, credit-based flow control prevents drops. On RoCE, PFC pauses and ECN marks keep Ethernet effectively lossless.
5. **Congestion control.** When many senders converge, switches mark packets and senders slow down, which prevents collapse.
6. **Remote write.** NIC0 on Node 2 writes directly into GPU0's memory, and the receiver's CPU never touches the data.

**The one idea to keep:** GPU fabrics are built so the common case (same-rank GPUs talking) is one hop, with no CPU and no packet loss.

## Minimal hands-on (K8s plumbing)

- **NVIDIA Network Operator:** installs the OFED/DOCA driver, RDMA shared device plugin / SR-IOV, and Multus.
- **Multus** attaches a second interface to pods for the RDMA network.

```yaml
metadata:
  annotations:
    k8s.v1.cni.cncf.io/networks: rdma-net-ipam      # secondary NIC
spec:
  containers:
  - resources:
      limits: { nvidia.com/gpu: 8, rdma/rdma_shared_device_a: 1 }
    securityContext: { capabilities: { add: [IPC_LOCK] } }   # pin memory for RDMA
```

```bash
ibstat; ibv_devinfo              # link state, rate
ib_write_bw -d mlx5_0 <peer>     # expect ~390 Gb/s on NDR
```

## Worked example

**Scenario:** A 13B model trained on 16 nodes × 8 H100. Step time breakdown:

| Fabric | Compute | Comm (exposed) | Step | Scaling eff. |
|---|---|---|---|---|
| 100 GbE TCP | 1.0 s | 2.6 s | 3.6 s | 28% |
| RoCEv2 400G untuned | 1.0 s | 0.9 s | 1.9 s | 53% |
| RoCEv2 400G + PFC/ECN + GPUDirect | 1.0 s | 0.25 s | 1.25 s | 80% |
| InfiniBand NDR + SHARP | 1.0 s | 0.12 s | 1.12 s | **89%** |

Moving from TCP to tuned RDMA turned a **4-week run into a 9-day run**. The network investment
paid for itself within the first training run.

## Production deep dive
- **Lossless Ethernet for RoCE:** PFC on a dedicated priority, ECN/DCQCN congestion control, consistent MTU (9000) end to end. One misconfigured switch port causes pause storms.
- **Fabric telemetry:** Port counters (symbol errors, link flaps), UFM (IB) or switch telemetry. A single flapping cable can slow a 1,000-GPU job.
- **Topology-aware scheduling:** Place job ranks on the same leaf/spine block (Kueue TAS, Volcano network topology, Lab 38).
- **Isolation:** IB partitions (PKeys) / VRFs per tenant for multi-tenant sovereign clusters.
- **Storage:** Often a separate RDMA path for the parallel filesystem (GPUDirect Storage).

## FAANG deep-dive notes

- **How big tech does it:** Dedicated back-end fabrics for GPU traffic (InfiniBand or tuned RoCE), rail-optimized topologies, and continuous fabric health monitoring. A single bad link is treated as an incident.
- **Staff review questions:** Is GPUDirect RDMA actually active? What is the measured bus bandwidth vs. line rate? How are flapping links detected?
- **Interview question:** *"InfiniBand or RoCE for a new 1,024-GPU cluster?"* Strong answers weigh latency, lossless requirements, team skills, vendor diversity, cost, congestion control, and tooling.

**Typical system-design prompt:** *"Design the network for a 1,024-GPU training cluster. Choose between InfiniBand and RoCE."*

**1. Clarify first:**
- Workload: large-scale pre-training (all-reduce heavy) or many small jobs?
- Team skills: InfiniBand fabric operations, or Ethernet/RoCE tuning?
- Budget and vendor constraints (sovereign procurement may prefer certain vendors).

**2. Back-of-envelope sizing:**
- 128 nodes × 8 GPUs × 400 Gb/s per GPU = 409.6 Tb/s of injection bandwidth.
- Non-blocking fat tree: leaf-to-spine uplinks must match downlinks, so a full bisection of ~200 Tb/s.
- Optics and switches typically cost 10–20% of the cluster capex. Oversubscribing 2:1 saves money but can slow all-reduce 20–40% when jobs span the whole cluster.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Fabric | InfiniBand | RoCEv2 (Spectrum-X, etc.) | IB for turnkey large training; RoCE if strong Ethernet ops |
| Topology | fat tree | rail-optimized | rail-optimized for 8-GPU nodes |
| Oversubscription | 1:1 | 2:1 | 1:1 for pre-training clusters |
| Kubernetes exposure | host networking | SR-IOV + Multus | SR-IOV with RDMA device plugin |
| Validation | trust the vendor | burn-in with nccl-tests | always burn in |

**4. Follow-up questions with crisp answers:**
- *What is RDMA?* Remote direct memory access: the NIC writes into remote memory without the CPU or kernel.
- *Why is RoCE harder?* Ethernet drops packets under congestion. PFC and ECN must be configured on every hop.
- *What's a PFC storm?* Pause frames spreading backwards through the network, freezing unrelated traffic.
- *Why rail-optimized?* NCCL's ring and tree patterns mostly connect same-rank GPUs, which stay within one rail switch.
- *How does Kubernetes give pods RDMA?* Multus adds a secondary interface, SR-IOV creates virtual functions, and the RDMA device plugin exposes them.
- *How do you validate the fabric?* nccl-tests all-reduce bus bandwidth vs. theoretical, run per rail and across the whole cluster.

**Debug this (common onsite question):** *"All-reduce bandwidth is 50% of expected, but only for jobs spanning more than 64 nodes."*
1. Up to 64 nodes, traffic stays within one pod of leaves. Beyond that, it crosses spines.
2. Switch counters show ECN marks and pause frames on two spine ports.
3. One spine link is down, so ECMP hashing concentrates traffic on the remaining links.
4. Fix: repair the link, add link-health alerting, consider adaptive routing, and re-run nccl-tests at full cluster scale after any fabric change.

The lesson: **fabric problems hide until jobs are big. Test at full scale and monitor every link.**

**5. What separates senior from staff answers:**
- Senior: wires SR-IOV and RDMA into pods and validates with nccl-tests.
- Staff: chooses topology and oversubscription from workload math, plans fabric operations (monitoring, burn-in, repair), and weighs vendor and sovereignty constraints.

**Red flags:** RoCE without PFC/ECN design, no burn-in, oversubscribed fabric for pre-training, no per-link monitoring.

## Failure modes
- Pods missing `IPC_LOCK` or the RDMA device fall back silently to TCP, making the job 5× slower with no error.
- MTU mismatch between host and switch causes drops on large messages.
- PFC deadlock or pause storms on RoCE can freeze the entire fabric.

## Checklist
- [ ] You can explain RDMA and GPUDirect in one sentence each
- [ ] A pod sees an RDMA device (`ibv_devices`)
- [ ] `ib_write_bw` reaches > 90% of line rate
