# Lab 32: Submitting Ray Core Jobs — Distributed Python (3:37)

## Why it matters
Ray Core's three primitives turn ordinary Python into a distributed program. Every higher-level
library (Train, Tune, Data, Serve) is built on them.

## In plain words
A **task** is hiring a freelancer for one job. An **actor** is a full-time employee who remembers things between jobs (like a loaded
model). An **object ref** is a receipt you can redeem later for the result. Loading a model is slow, so use employees (actors), not freelancers, for inference.

## Architecture at a glance

```mermaid
flowchart LR
  D[Driver script] -->|embed.remote x40| T[Tasks: stateless]
  D -->|Scorer.remote x16| A["Actors: model loaded once"]
  T --> OS[(Object store: results)]
  A --> OS
  OS -->|ray.get refs| D
```

**How to read it:** The driver sends stateless tasks and stateful actors to the cluster. Both put results into the object store, and the driver collects them with `ray.get`.

## Core concepts

| Primitive | Decorator | Think of it as | State |
|---|---|---|---|
| **Task** | `@ray.remote` def | A remote function call | Stateless |
| **Actor** | `@ray.remote` class | A remote object/service | Stateful |
| **Object** | `ray.put` / return values | A distributed future (`ObjectRef`) | Immutable |

Resource-aware scheduling: `@ray.remote(num_gpus=1)` means "run this where a GPU is free".
Fractional GPUs (`num_gpus=0.25`) pack small models onto one GPU.

## Architecture in depth

The overview shows tasks, actors, and the object store. This view follows **one `embed.remote()` call** through Ray's
scheduling and data path, showing where time and memory go.

```mermaid
flowchart LR
  D["Driver: ref = embed.remote(batch)"] --> OWN["Owner records task + returns ObjectRef immediately"]
  OWN --> LR[Local raylet]
  LR -->|"resources free here?"| LOC[Run locally]
  LR -->|"no: spillback"| RR[Remote raylet with free GPU]
  RR --> WK[Worker process executes]
  WK --> PUT["Result into node object store (shared memory)"]
  PUT --> GET["Driver ray.get(ref)"]
  GET -->|"same node: zero copy"| D
  GET -->|"other node: transfer"| D
  PUT -.store full.-> SPILL[(Spill to disk)]
```

### Follow one remote call to its result
1. **Call returns immediately.** `embed.remote(batch)` returns an ObjectRef, a receipt for a future result. Nothing waits yet.
2. **Ownership.** The driver owns the task. It tracks its status and retries it if a worker dies.
3. **Local scheduling first.** The local raylet runs the task if it has the resources (for example 1 GPU).
4. **Spillback.** If not, it forwards the task to a raylet that does. Data locality is considered when choosing.
5. **Execute.** A worker process runs the function. Large arguments come from the object store, not over the driver connection.
6. **Store result.** Output goes into that node's shared-memory object store. If memory fills, objects spill to disk, which is slow but safe.
7. **Collect.** `ray.get` fetches the result: zero-copy on the same node, a network transfer otherwise.

**The one idea to keep:** pass references, not data. Moving big objects through the driver is the most common Ray bottleneck.

## Minimal hands-on

```python
import ray
ray.init()  # inside a pod, or ray.init("ray://rc-head-svc:10001")

@ray.remote(num_gpus=0.5)
def embed(batch):                       # stateless task
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer("BAAI/bge-small-en").encode(batch).tolist()

@ray.remote
class Counter:                          # stateful actor
    def __init__(self): self.n = 0
    def add(self, k): self.n += k; return self.n

batches = [[f"doc {i}-{j}" for j in range(256)] for i in range(40)]
refs = [embed.remote(b) for b in batches]   # 40 tasks scheduled across GPUs
vectors = ray.get(refs)
```

Submit to a remote cluster:

```bash
ray job submit --address http://localhost:8265 --working-dir . -- python embed.py
```

## Worked example

**Scenario:** Score 10M customer reviews for sentiment with a 350M-param model.

- One GPU: ~2,000 reviews/s, so ~83 min.
- Ray with `num_gpus=0.25` (4 model copies per L4) across 4 L4s gives 16 actors and **~6.5 min**.
- Design choice: an **actor pool** (load the model once per actor) instead of tasks (which reload the model on every call).
  Using tasks here would take 10× longer because of repeated model loads.

```python
from ray.util import ActorPool
pool = ActorPool([Scorer.remote() for _ in range(16)])
results = list(pool.map_unordered(lambda a, b: a.score.remote(b), batches))
```

## Production deep dive
- **Avoid anti-patterns:** Calling `ray.get` inside loops (it serializes everything), passing big objects as arguments (use `ray.put` once and pass the ref), and creating millions of tiny tasks (batch them).
- **Runtime environments:** Prefer baked images over `runtime_env={"pip": [...]}` in production. That pip option is slow and can't be reproduced.
- **Retries:** `max_retries` for tasks and `max_restarts` for actors. Make tasks idempotent.
- **Observability:** The Ray dashboard plus Prometheus metrics integration. Export to Grafana and correlate with DCGM.
- **Job lifecycle:** Submit through `RayJob` CRDs from CI/Argo Workflows, not from laptops, so every run is traceable to a commit.

## FAANG deep-dive notes

- **How big tech does it:** Batch inference at scale uses long-lived workers with the model loaded once, streaming inputs, and automatic retries, never per-item model loading.
- **Staff review questions:** Where is the model loaded? What is the retry semantics? Are large objects passed by reference?
- **Interview question:** *"Score 1 billion items with a 1B-param model in 2 hours."* Strong answers do throughput math, choose actor pools, size the GPUs, batch inputs, stream I/O, handle failures idempotently, and estimate cost.

**Typical system-design prompt:** *"Embed 1 billion documents with Ray in under 12 hours on a GPU cluster."*

**1. Clarify first:**
- Model size and throughput per GPU.
- Input location and format (Parquet on S3?) and output sink (vector DB, object store).
- Failure tolerance: can partial output be resumed?

**2. Back-of-envelope sizing:**
- 1B docs ÷ 12 h = ~23k docs/s. At 1,500 docs/s per L40S, that's ~16 GPUs. Plan 20 for retries and stragglers.
- Task size: 1B docs in 10k-doc batches = 100k tasks. That's manageable for the GCS, whereas 1B single-doc tasks are not.
- Object store: 20 workers × 4 in-flight batches × 10k docs × 4 KB ≈ 3.2 GB, comfortable.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Model loading | task per batch (reload) | actor pool (load once) | actors for anything with a model |
| Granularity | tiny tasks | batches of seconds to minutes | each task ≥ ~100 ms of work |
| Back-pressure | submit everything | bounded in-flight with `ray.wait` | cap in-flight refs |
| API level | Ray Core | Ray Data | Ray Data for pipelines; Core for custom control |

**4. Follow-up questions with crisp answers:**
- *Task vs. actor?* A task is stateless and runs anywhere. An actor is a long-lived process holding state, such as a loaded model.
- *Why does `ray.get` in a loop hurt?* It serializes work. Submit many, then use `ray.wait` to process results as they finish.
- *What happens if a worker dies?* The owner retries tasks (`max_retries`). Actors restart if `max_restarts` is set, but their state is lost unless saved.
- *What causes object-store spilling?* Too many in-flight results or large objects held by references.
- *How do you pass a big model to tasks?* `ray.put` once and pass the ref, or better, load it inside an actor.
- *Why use Ray Data?* It gives streaming execution, back-pressure, and GPU/CPU stage pipelining for free.

**Debug this (common onsite question):** *"The Ray embedding job uses 20 GPUs, but throughput equals what 4 GPUs should do."*
1. The dashboard shows GPUs idle 80% of the time and the driver CPU at 100%.
2. The driver reads Parquet, tokenizes, and sends raw batches through `remote()` arguments, so the driver is the bottleneck.
3. Each task also reloads the model (2 s), because it uses tasks instead of actors.
4. Fix: move reading and tokenizing into Ray Data CPU stages, use an actor pool for the model, and bound the number of in-flight batches.

The lesson: **in distributed Python, the driver is often the bottleneck. Push work to workers.**

**5. What separates senior from staff answers:**
- Senior: uses actors for models and batches work sensibly.
- Staff: designs the pipeline end to end (I/O, CPU stages, GPU stages, sink), sizes task granularity and back-pressure, and plans resumable output.

**Red flags:** model loading per task, `ray.get` inside loops, unbounded submission, big data moving through the driver.

## Failure modes
- Object store full, so tasks spill or hang. Monitor `object_store_memory`.
- Fractional GPU packing with no memory control lets 4 actors × 6 GB exceed a 24 GB card.
- Driver dies, its owned objects die too, and a cascade of failures follows.

## Checklist
- [ ] Tasks and actors run across worker pods
- [ ] The actor pool pattern is implemented for model inference
- [ ] The job is submitted via `ray job submit` or a `RayJob` CRD
