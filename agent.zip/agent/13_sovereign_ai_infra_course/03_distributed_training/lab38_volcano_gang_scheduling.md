# Lab 38: Volcano Scheduler — Gang Scheduling for Distributed Training (4:22)

## Why it matters
The default K8s scheduler places pods **one at a time**. Two 8-pod jobs on a 12-GPU cluster
can each get 6 pods scheduled and wait forever for the rest. That is a **deadlock**, with 12 GPUs
allocated and doing nothing. Gang scheduling means **all or nothing**.

## In plain words
A distributed job is like **a group booking for a restaurant**: there's no point seating 3 of 8 friends and making them wait for hours.
Gang scheduling means the table is given only when **all 8 seats** are free, so half-seated groups never block the restaurant.

## Architecture at a glance

```mermaid
flowchart TB
  subgraph Default["Default scheduler: deadlock"]
    J1A[Job A: 6 of 8 pods] --- C1[(12 GPUs full)]
    J1B[Job B: 6 of 8 pods] --- C1
  end
  subgraph Gang["Gang scheduler"]
    J2A[Job A: 8 of 8 ✅ runs] --- C2[(12 GPUs)]
    J2B[Job B: waits in queue] -.-> C2
  end
```

**How to read it:** On the left, the default scheduler half-places two jobs and both stall, a deadlock. On the right, the gang scheduler runs one job completely while the other waits in the queue.

## Core concepts

| Feature | Volcano | Kueue (+ default scheduler) |
|---|---|---|
| Gang scheduling (`minMember`) | ✅ PodGroup | ✅ via all-or-nothing admission |
| Queues & fair share | ✅ Queue weights | ✅ ClusterQueue/cohorts |
| Preemption & reclaim | ✅ | ✅ |
| Topology-aware (network) | ✅ HyperNode | ✅ TAS |
| Job CRD | `vcjob` + plugins (svc, ssh, env) | Works with PyTorchJob, RayJob, JobSet |
| Replaces default scheduler for those pods | Yes (`schedulerName: volcano`) | No |

**Rule of thumb:** For a K8s-native platform with Kubeflow/Ray jobs, start with **Kueue**. For
HPC-style batch clusters needing rich scheduling plugins, use **Volcano**. The concepts transfer.

## Architecture in depth

The overview contrasts deadlock with gang scheduling. This view shows **Volcano's scheduling session**: the actions it runs in each
cycle to admit a whole gang or nothing.

```mermaid
flowchart LR
  subgraph Session["Each scheduling cycle (~1s)"]
    EN["enqueue<br/>queue has quota? → Inqueue"] --> AL["allocate<br/>try placing ALL minMember pods"]
    AL --> CHK{"minAvailable satisfied?"}
    CHK -->|yes| BIND[Bind all pods together]
    CHK -->|no| DISC[Discard tentative placements]
    DISC --> PRE["preempt / reclaim<br/>lower-priority or over-quota jobs"]
    PRE --> BF["backfill<br/>small jobs into idle gaps"]
  end
  PG["PodGroup<br/>minMember: 16"] --> EN
  Q["Queue weights + capability"] --> EN
  PLUG["Plugins: gang, drf, proportion, binpack, topology"] -.-> AL
```

### Follow one 16-pod training job through a cycle
1. **PodGroup.** The job declares `minMember: 16`, so it means nothing to run with fewer pods.
2. **Enqueue.** Volcano checks the queue's share and capability. If capacity is plausible, the job moves to Inqueue and its pods are created.
3. **Allocate.** The scheduler tentatively places pods one by one, scoring nodes with plugins (binpack, topology).
4. **All or nothing.** If all 16 fit, they bind together. If only 12 fit, every tentative placement is discarded, so no GPUs are held by a half-job.
5. **Preempt or reclaim.** If a higher-priority gang is waiting, lower-priority or over-quota jobs may be evicted to make room.
6. **Backfill.** Small jobs fill idle gaps while big gangs wait, which keeps utilization up.
7. **Retry.** Next cycle, the job tries again as resources free up.

**The one idea to keep:** gang scheduling makes placement atomic. A job either gets every pod it needs or holds nothing.

## Minimal hands-on (Volcano)

```yaml
apiVersion: batch.volcano.sh/v1alpha1
kind: Job
metadata: { name: llm-train }
spec:
  schedulerName: volcano
  minAvailable: 4                 # gang: start only if all 4 workers fit
  queue: research
  plugins: { pytorch: ["--master=master","--worker=worker","--port=23456"], svc: [] }
  policies:
  - { event: PodEvicted, action: RestartJob }
  tasks:
  - name: master
    replicas: 1
    template: { spec: { containers: [{ name: t, image: my/train:1.0, resources: { limits: { nvidia.com/gpu: 8 } } }] } }
  - name: worker
    replicas: 3
    template: { spec: { containers: [{ name: t, image: my/train:1.0, resources: { limits: { nvidia.com/gpu: 8 } } }] } }
```

## Worked example

**Scenario:** A university AI lab runs 96 GPUs (12 nodes × 8) shared by 40 researchers. Jobs are mostly 16–32 GPUs.

- **Before** (default scheduler): weekly partial-allocation deadlocks, an admin manually killing pods, and 22% of GPUs allocated but idle.
- **After** (Volcano with gang scheduling, 3 weighted queues `faculty:4, phd:3, students:1`, and backfill for small jobs):
  - Zero deadlocks.
  - Backfill places 1–2 GPU jobs into gaps while a big job waits.
  - **Network-topology awareness** keeps 32-GPU jobs within one leaf switch block, giving 14% faster steps.
- Utilization went from 61% to 84%.

## Production deep dive
- **JobSet** (K8s SIG) is becoming the standard multi-role job API (driver + workers + parameter servers). Kueue supports it.
- **Elastic training:** `torchrun --nnodes=2:4` combined with an elastic gang (`minAvailable` < replicas) lets jobs keep running as nodes come and go.
- **Fairness vs. throughput:** Strict fair share can leave GPUs idle. Enable borrowing (Lab 26) and backfill.
- **Starvation of big jobs:** Small jobs constantly backfill and the 64-GPU job never starts. Use reservations or a "big job" priority boost after a wait time.
- **Observability:** Queue length, wait time per queue, and admitted vs. pending GPU demand feed capacity planning.

## FAANG deep-dive notes

- **How big tech does it:** All-or-nothing admission for multi-node jobs, topology-aware placement within network blocks, and backfill so small jobs fill gaps without starving large ones.
- **Staff review questions:** Can partial allocations ever happen? How do big jobs avoid starvation? Is placement topology-aware?
- **Interview question:** *"Why do distributed jobs deadlock on default Kubernetes scheduling?"* Strong answers explain pod-by-pod scheduling, partial allocation, and gang scheduling via Volcano/Kueue, plus backfill and reservation strategies.

**Typical system-design prompt:** *"Design batch scheduling for a shared 1,024-GPU training cluster with jobs from 8 to 512 GPUs."*

**1. Clarify first:**
- Job size distribution (many small, few huge?).
- Priority classes: production pre-training vs. research.
- Topology needs: must large jobs sit within one network pod?

**2. Back-of-envelope sizing:**
- Without gang scheduling, two 512-GPU jobs each partially placed at 400 pods leaves 800 GPUs idle and deadlocked, about $2k/hour wasted.
- A big-job wait: a 512-GPU job needs half the cluster free at once. With small jobs constantly arriving, it can starve indefinitely without reservation or backfill limits.
- Backfill gain: filling gaps with small jobs typically raises utilization from ~70% to 85%+.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Scheduler | Volcano (replaces scheduling) | Kueue (admission) + default scheduler | Kueue for K8s-native quota; Volcano for rich batch policies |
| Large jobs | wait for space | reservation / draining | reserve for big jobs after a wait threshold |
| Placement | any node | topology-aware (same spine/pod) | topology for jobs over one rail group |
| Fairness | priority only | DRF / proportion + priority | fair share across teams |
| Small jobs | queue normally | backfill | backfill with time limits |

**4. Follow-up questions with crisp answers:**
- *What is gang scheduling?* All of a job's pods are scheduled together, or none are.
- *Why does the default scheduler deadlock?* It places pods independently, so two jobs can each hold part of the cluster forever.
- *How do you avoid starving big jobs?* Reservations: stop backfilling into the nodes a big job is waiting for.
- *What's the risk of backfill?* A backfilled job runs longer than expected and delays the big job. Require runtime limits.
- *Volcano or Kueue?* Kueue admits whole jobs into the default scheduler (plus TAS for topology). Volcano replaces the scheduler with batch plugins.
- *How does preemption interact with checkpointing?* Preempted gangs must checkpoint quickly. Set a grace period long enough to save.

**Debug this (common onsite question):** *"A 256-GPU job has been pending for 2 days while the cluster shows 300 free GPUs."*
1. The 300 free GPUs are fragmented: 1–3 per node across 120 nodes. The job needs 32 whole 8-GPU nodes.
2. Binpack is off, so small jobs spread across nodes.
3. Backfill keeps refilling freed nodes with small jobs.
4. Fix: enable binpack scoring, reserve nodes for the waiting gang after a threshold, and set runtime limits on backfill jobs.

The lesson: **free GPUs are not usable GPUs. Fragmentation and backfill can starve large gangs.**

**5. What separates senior from staff answers:**
- Senior: configures PodGroups and queues, and explains deadlock.
- Staff: designs policies for the mix of job sizes (binpack, reservation, backfill limits, topology), measures wait time per job size, and sets fairness rules across teams.

**Red flags:** distributed training without gang scheduling, unlimited backfill, no fragmentation metrics, ignoring topology for large jobs.

## Failure modes
- `minAvailable` lower than the real world size lets the job start and then hang at NCCL init waiting for missing ranks.
- Mixing default-scheduler and Volcano pods on the same nodes leads to double booking and race conditions. Dedicate nodes or use Kueue.
- No restart policy, so one evicted pod leaves the rest hanging until timeout.

## Checklist
- [ ] A gang-scheduled job starts only when all pods fit
- [ ] Queues with weights are defined
- [ ] A deadlock scenario was reproduced with the default scheduler and fixed with gang scheduling
