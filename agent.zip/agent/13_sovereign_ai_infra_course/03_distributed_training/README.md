# Section 4 — Distributed Training Networks (8:14)

**Goal:** Train models too big or too slow for one GPU by understanding **parallelism, collective
communication, network fabrics, gang scheduling, and fault tolerance**.

| Lab | Topic | Key idea |
|---|---|---|
| [31](lab31_ray_kuberay_architecture.md) | Ray & KubeRay | A distributed Python runtime on K8s |
| [32](lab32_ray_core_jobs.md) | Ray Core jobs | Tasks, actors, objects |
| [33](lab33_distributed_data_loading.md) | Distributed data loading | Keep GPUs fed |
| [34](lab34_pytorch_fsdp.md) | PyTorch FSDP | Shard everything, gather just in time |
| [35](lab35_infiniband_rocev2.md) | InfiniBand & RoCEv2 | RDMA: the network is the computer |
| [36](lab36_nccl_optimization.md) | NCCL on K8s | Collectives tuning |
| [37](lab37_multinode_gradient_descent.md) | Multi-node gradient descent | All-reduce, math & timing |
| [38](lab38_volcano_gang_scheduling.md) | Volcano gang scheduling | All-or-nothing scheduling |
| [39](lab39_checkpointing_s3.md) | Checkpointing to S3 | Failure is the default at scale |
| [40](lab40_megatron_lm.md) | Megatron-LM | 3D parallelism for billions of params |

## The one formula to remember

Training memory per GPU with Adam in mixed precision (no sharding):

```
≈ 16 bytes × params   (2 weights + 2 grads + 12 optimizer: fp32 master, m, v)
+ activations (∝ batch × seq_len × hidden × layers)
```

A 7B model needs about **112 GB before activations**. It does not fit on one 80 GB GPU without sharding, which is why this section exists.

## Parallelism cheat sheet

| Strategy | Splits | Comm pattern | Best within |
|---|---|---|---|
| Data (DDP) | Batch | All-reduce grads | Anywhere |
| FSDP / ZeRO-3 | Params + grads + optim | All-gather + reduce-scatter | Node or cluster |
| Tensor (TP) | Each matmul | All-reduce per layer (heavy) | **NVLink domain only** |
| Pipeline (PP) | Layers | Point-to-point activations | Across nodes |
| Sequence/Context (SP/CP) | Sequence length | All-gather / ring | Long context |
| Expert (EP) | MoE experts | All-to-all | NVLink / fast fabric |
