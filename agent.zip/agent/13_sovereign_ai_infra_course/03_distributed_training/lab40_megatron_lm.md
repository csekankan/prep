# Lab 40: Orchestrating Megatron-LM for Billion-Parameter Scale (4:07)

## Why it matters
Past ~70B parameters, FSDP alone runs into communication limits. Megatron-LM (and NeMo, built on it)
combines **Tensor, Pipeline, and Data parallelism (3D)**, plus sequence/context and expert parallelism.
It is the standard recipe for frontier-scale training.

## In plain words
Building a skyscraper with 128 workers: **tensor parallel** is several workers lifting one heavy beam together (they must stand very close:
same NVLink node). **Pipeline parallel** is different floors built by different crews in a relay. **Data parallel** is identical buildings
going up side by side. Megatron uses all three at once.

## Architecture at a glance

```mermaid
flowchart LR
  subgraph DP0["Data-parallel replica 0"]
    subgraph PP0["Stage 0: layers 1-20"]
      T0["TP=8 on Node 1 NVLink"]
    end
    subgraph PP1["Stage 1: layers 21-40"]
      T1["TP=8 on Node 2"]
    end
    subgraph PP2["Stage 2-3 ..."]
      T2["TP=8 on Nodes 3-4"]
    end
    T0 -->|activations| T1 --> T2
  end
  DP0 <-->|grad all-reduce once per step| DP1["Replicas 1-3: same layout"]
```

**How to read it:** Inside one data-parallel replica, layers are split into pipeline stages across nodes. Each stage uses tensor parallelism within its node. Replicas exchange gradients once per step.

## Core concepts

```
World = TP × PP × DP   (× CP × EP for long-context/MoE)

          ┌──────── Pipeline stage 0 ────────┐   ┌──── stage 1 ────┐ ...
DP rep 0: [GPU0 GPU1 GPU2 GPU3 ← TP=4 (NVLink)] → [GPU4..GPU7 TP=4]
DP rep 1: [ ... same layout on other nodes ...]
```

| Dim | Splits | Comm | Placement rule |
|---|---|---|---|
| **TP** | Matmuls inside each layer | All-reduce every layer (very heavy) | **Within a node (NVLink)** |
| **PP** | Groups of layers | Point-to-point activations | Across nodes |
| **DP** | Batch | Grad all-reduce once per step | Outermost |
| **CP/SP** | Sequence | Ring attention | Long contexts (128k+) |
| **EP** | MoE experts | All-to-all | Fast fabric |

**Pipeline bubble:** Idle time while the pipeline fills and drains ≈ `(PP−1) / (micro_batches + PP−1)`.
Fix it with many micro-batches and interleaved (virtual) pipeline stages.

## Architecture in depth

The overview shows the TP × PP × DP layout. This view shows the **pipeline schedule** inside one data-parallel replica: how
micro-batches flow through stages, and where the idle "bubble" comes from.

```mermaid
gantt
  title 1F1B pipeline, 4 stages, 4 micro-batches, forward = backward = 1 time unit
  dateFormat X
  axisFormat %s
  section Stage 0
  F1 :0, 1
  F2 :1, 2
  F3 :2, 3
  F4 :3, 4
  B1 :7, 8
  B2 :9, 10
  B3 :11, 12
  B4 :13, 14
  section Stage 1
  F1 :1, 2
  F2 :2, 3
  F3 :3, 4
  B1 :6, 7
  F4 :7, 8
  B2 :8, 9
  B3 :10, 11
  B4 :12, 13
  section Stage 2
  F1 :2, 3
  F2 :3, 4
  B1 :5, 6
  F3 :6, 7
  B2 :7, 8
  F4 :8, 9
  B3 :9, 10
  B4 :11, 12
  section Stage 3
  F1 :3, 4
  B1 :4, 5
  F2 :5, 6
  B2 :6, 7
  F3 :7, 8
  B3 :8, 9
  F4 :9, 10
  B4 :10, 11
```

Each stage does 8 units of work in a 14-unit step, so 6 units (43%) are bubble. That matches the formula (PP−1) ÷ (micro-batches + PP−1) = 3 ÷ 7. With 32 micro-batches, the bubble falls to about 9%.

### Follow micro-batches through the pipeline
1. **Split the batch.** The global batch per replica is cut into micro-batches (here 4).
2. **Fill.** Micro-batch 1 enters stage 0 (layers 1–20), then moves to stage 1, and so on. Later stages sit idle while the pipeline fills. This idle time is the *bubble*.
3. **Tensor parallelism inside each stage.** Each stage's layers are split across 8 GPUs on one node, which exchange partial results over NVLink at every layer.
4. **1F1B steady state.** Once full, each stage alternates one forward and one backward, keeping memory bounded and GPUs busy.
5. **Drain.** At the end, stages finish remaining backwards, causing another short bubble.
6. **Data-parallel sync.** After all micro-batches, replicas all-reduce gradients once per step, and every replica applies the same update.

**The one idea to keep:** TP stays inside a node (chatty, needs NVLink), PP crosses nodes (only activations), and more micro-batches shrink the bubble.

## Minimal hands-on (config, not code)

```bash
torchrun --nnodes 16 --nproc-per-node 8 pretrain_gpt.py \
  --tensor-model-parallel-size 8 \
  --pipeline-model-parallel-size 4 \
  --num-layers 80 --hidden-size 8192 --num-attention-heads 64 \
  --seq-length 8192 --micro-batch-size 1 --global-batch-size 1024 \
  --bf16 --use-distributed-optimizer --sequence-parallel \
  --recompute-activations \
  --save s3://ckpt/llm70b --save-interval 500
# DP = 128 / (8×4) = 4
```

On K8s: run as a `PyTorchJob`/`JobSet` with gang scheduling (Lab 38), RDMA (Lab 35), and checkpointing (Lab 39).
NeMo Framework and Megatron-Bridge wrap this with recipes.

## Worked example — choose the layout

**Scenario:** Pre-train a **70B dense model** on **128 H100s** (16 nodes × 8, NVLink in-node, 8×400G IB).

| Option | Layout | Verdict |
|---|---|---|
| A | FSDP only, DP=128 | Each layer all-gather crosses IB. ~32% MFU |
| B | TP=8, PP=1, DP=16 | Weights+optim per GPU: 70B×16B/8 = 140 GB ❌ without the distributed optimizer; with it ~9 GB ✅ but activations at 8k seq are huge |
| **C** | **TP=8, PP=4, DP=4**, interleaved, distributed optimizer, sequence parallel | TP on NVLink, PP across nodes, bubble ~5% with 64 micro-batches. **~47% MFU** |
| D | TP=16 | ❌ TP crosses nodes, all-reduce every layer over IB |

Option C brings training time down ~30% vs. A. On a ~$3M compute budget that saves about **$900k**.

## Production deep dive
- **Golden rule:** TP ≤ GPUs per NVLink domain. Blackwell **NVL72** makes that domain 72 GPUs, which changes the math (Lab 100).
- **MoE models:** EP plus all-to-all traffic dominate. Fabric quality and expert load balancing are critical.
- **FP8 training** (Transformer Engine) roughly doubles throughput on Hopper/Blackwell. Validate convergence against BF16 runs.
- **Run management:** A dedicated "training ops" rota: loss-curve watch, auto-rollback, node health sweeps, and checkpoint verification.
- **Conversion:** Megatron checkpoints must be converted to HF format for serving (Section 5). Automate it and verify logit parity.

## FAANG deep-dive notes

- **How big tech does it:** 3D/4D/5D parallelism (TP, PP, DP, plus context and expert parallelism) configured by automated search over layouts, validated by short benchmark runs before committing to multi-week jobs.
- **Staff review questions:** Does TP stay inside the NVLink domain? What is the pipeline bubble? Why this specific TP/PP/DP split?
- **Interview question:** *"Choose a parallelism layout for a 175B model on 512 GPUs."* Strong answers keep TP=8 in-node, size PP from memory, put DP on the remainder, compute the bubble, add the distributed optimizer, and justify each choice.

**Typical system-design prompt:** *"Choose the parallelism layout for training a 175B model on 1,024 H100s."*

**1. Clarify first:**
- Sequence length and global batch size (tokens per step).
- Node topology: 8 GPUs per node with NVLink, IB between nodes.
- Memory per GPU (80 GB) and whether activation recomputation is acceptable.

**2. Back-of-envelope sizing:**
- 175B × 16 bytes (mixed precision + Adam) ≈ 2.8 TB of training state.
- TP=8 (within node) × PP=8 → 64 GPUs per replica, each holding 1/64 ≈ 44 GB before activations. Adding ZeRO-1 across DP shards optimizer state further.
- DP = 1,024 ÷ 64 = 16 replicas.
- Bubble fraction ≈ (PP−1) ÷ (micro-batches + PP−1). With PP=8 and 64 micro-batches: 7 ÷ 71 ≈ 10%.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| TP degree | across nodes | ≤ GPUs per node | never stretch TP over IB |
| PP degree | small (fewer bubbles) | large (less memory) | the smallest PP that fits memory |
| Micro-batches | few | many (≥ 4× PP) | more micro-batches → smaller bubble |
| Schedule | 1F1B | interleaved / virtual stages | interleaved reduces the bubble at the cost of more communication |
| Long context | plain TP | sequence/context parallelism | add CP for sequences ≥ 32k |
| Framework | Megatron-LM | NeMo / TorchTitan | same concepts; choose by ecosystem |

**4. Follow-up questions with crisp answers:**
- *Why TP within a node?* It communicates at every layer, which only NVLink bandwidth sustains.
- *Why PP across nodes?* It only sends activations between neighbouring stages, which is far less traffic.
- *What is the pipeline bubble?* Idle time while the pipeline fills and drains.
- *How does DP fit in?* It replicates the TP×PP unit and all-reduces gradients once per step, usually with ZeRO-1.
- *What about MoE models?* Add expert parallelism: experts are spread across GPUs and tokens are routed with all-to-all.
- *How do you validate a layout?* Measure MFU and the step-time breakdown on a small number of steps before the full run.

**Debug this (common onsite question):** *"The 175B run reaches only 25% MFU; the target was 45%."*
1. Profile: stage 0 is 30% slower than the others, because it also holds the embedding layer.
2. The micro-batch count is 16 with PP=8, so the bubble is 7 ÷ 23 ≈ 30%.
3. TP communication is fine (on NVLink), and DP all-reduce is overlapped.
4. Fix: rebalance layers so stage 0 has fewer transformer blocks, raise micro-batches to 64 (or use interleaved scheduling), and re-measure. Typical result: MFU of 40–45%.

The lesson: **pipeline efficiency is decided by balance and bubble size. Profile per stage.**

**5. What separates senior from staff answers:**
- Senior: picks a valid TP/PP/DP layout and explains why TP stays within a node.
- Staff: derives the layout from memory and bandwidth math, quantifies the bubble, balances stages, plans for failures at 1,000+ GPUs, and validates MFU before committing months of compute.

**Red flags:** TP across nodes, few micro-batches with deep PP, unbalanced stages, launching a months-long run without an MFU benchmark.

## Failure modes
- TP spanning nodes cuts throughput by 3–5×.
- Too few micro-batches for the PP depth leaves a 30%+ pipeline bubble.
- An uneven layer split across stages (embedding/LM head heavy) means one stage is slower and gates the pipeline.

## Checklist
- [ ] You can choose TP/PP/DP for a given model and cluster with justification
- [ ] You can compute the pipeline bubble
- [ ] A checkpoint → HF conversion path is defined
