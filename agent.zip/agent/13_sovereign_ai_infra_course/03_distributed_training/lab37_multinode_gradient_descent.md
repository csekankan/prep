# Lab 37: Multi-Node Gradient Descent — The Symphony of Weights (4:21)

## Why it matters
This lab ties together data loading, FSDP, NCCL, and the fabric: **what actually happens in one
training step across many machines**, and how to reason about its cost.

## In plain words
Picture an orchestra where each musician (GPU) practises a different page of the music (data), then they all **compare notes**
(all-reduce) so everyone plays the same updated song (weights). The faster they compare notes while still playing (overlap), the shorter the rehearsal.

## Core concepts — anatomy of one data-parallel step

```mermaid
sequenceDiagram
  participant R0 as Rank 0
  participant R1 as Rank 1
  participant RN as Rank N
  Note over R0,RN: 1. Each rank gets a different micro-batch
  R0->>R0: forward + backward (local grads)
  R1->>R1: forward + backward
  RN->>RN: forward + backward
  Note over R0,RN: 2. All-reduce gradients (overlapped with backward via buckets)
  R0-->>RN: ring all-reduce
  Note over R0,RN: 3. Identical optimizer step → weights stay in sync
```

**How to read it:** Each rank computes on its own micro-batch. Gradients are averaged with an all-reduce, overlapped with backward. Every rank then applies the identical update, so the weights stay in sync.

**Key math**
- **Global batch** = micro_batch × grad_accum_steps × data_parallel_size.
- **Ring all-reduce traffic per GPU** ≈ `2 × (N-1)/N × gradient_bytes`, which is **almost independent of N**. That is why rings scale.
- **Linear scaling rule:** 4× the global batch needs roughly 4× the learning rate, plus warmup. Beyond the *critical batch size*, adding GPUs stops helping convergence.
- **Overlap:** Gradient buckets are all-reduced while backward is still computing earlier layers. A good overlap hides most of the communication.

**Scaling efficiency** = (throughput on N GPUs) ÷ (N × single-GPU throughput).

## Architecture in depth

The concepts diagram shows the ranks exchanging gradients. This view shows **how DDP overlaps communication with backward** using
gradient buckets, which is why good scaling is possible at all.

```mermaid
sequenceDiagram
  participant B as Backward (compute stream)
  participant C as All-reduce (comm stream)
  participant O as Optimizer
  B->>B: grads for layers 32..25 → bucket 1 full
  B->>C: launch all-reduce(bucket 1)
  B->>B: grads for layers 24..17 → bucket 2
  C-->>C: bucket 1 reducing (overlapped)
  B->>C: launch all-reduce(bucket 2)
  B->>B: layers 16..1 → buckets 3, 4
  B->>C: launch buckets 3, 4
  C-->>O: last bucket done (exposed comm only here)
  O->>O: identical update on every rank
```

### Follow one step's gradients from last layer to update
1. **Backward runs in reverse.** The last layers produce gradients first.
2. **Bucketing.** DDP groups gradients into buckets (~25 MB by default). When a bucket is full, it is ready to send.
3. **Launch early.** DDP immediately starts an all-reduce for that bucket on a separate communication stream.
4. **Overlap.** While bucket 1 is being reduced, backward keeps computing earlier layers' gradients.
5. **Tail.** Only the last bucket (first layers) has no compute left to hide behind. This is the *exposed* communication.
6. **Synchronize.** When all buckets finish, every rank has the same averaged gradients.
7. **Update.** The optimizer applies identical updates, so the weights stay identical without ever sending weights.

**The one idea to keep:** step time ≈ compute + *exposed* communication. Scaling efficiency is decided by how much communication hides under backward.

## Minimal hands-on (back-of-envelope calculator)

```python
def step_time(params_b, gpus, tflops_per_gpu=400, mfu=0.45, tokens_per_gpu=16384,
              link_GBps=50, overlap=0.7):
    flops = 6 * params_b * 1e9 * tokens_per_gpu          # 6·N·T rule
    compute = flops / (tflops_per_gpu * 1e12 * mfu)
    grad_bytes = params_b * 1e9 * 2                       # bf16 grads
    comm = 2 * (gpus - 1) / gpus * grad_bytes / (link_GBps * 1e9)
    exposed = comm * (1 - overlap)
    return compute, comm, compute + exposed

print(step_time(7, 64))   # compute ≈ 3.8 s, comm ≈ 0.55 s, step ≈ 4.0 s → ~96% eff
```

## Worked example

**Scenario:** A CFO asks: "If we double from 128 to 256 GPUs, does our 30-day training run take 15 days?"

| Factor | Effect |
|---|---|
| Comm per GPU ~constant (ring) | ✅ Scales |
| Global batch doubles (2,048 → 4,096 seqs) | ⚠️ Near the critical batch size; needs LR re-tune and may need ~10% more tokens |
| More nodes means more failures (Lab 39) | ⚠️ MTBF halves, so more restart overhead |
| Scaling efficiency at 256 measured at 88% vs. 93% | ⚠️ |

**Answer:** about **16.5–17 days**, not 15. The decision memo includes the cost delta: 256 GPUs × 17 days vs.
128 × 30, which is roughly 13% more GPU-hours for 13 days of time-to-market. That trade-off is a business call, and now it's quantified.

## Production deep dive
- **Stragglers:** The step time is set by the *slowest* rank. Monitor per-rank step time and auto-evict slow nodes.
- **Loss spikes:** Large-scale runs hit instabilities. Use gradient clipping, z-loss, LR warmup, BF16 master weights, and automatic rollback to the last good checkpoint.
- **Experiment tracking:** Log loss, grad norm, throughput, MFU, and per-rank timings (W&B/MLflow, Lab 44).
- **Reproducibility:** Seeds, data order cursor, library versions, and config hash all go in the checkpoint metadata.
- **Async/local-SGD** methods (DiLoCo) cut communication for WAN training (Lab 95).

## FAANG deep-dive notes

- **How big tech does it:** Scaling decisions are made with measured scaling-efficiency curves and critical-batch-size studies. Large runs have dedicated people watching loss curves and automated rollback.
- **Staff review questions:** What is the scaling efficiency at your target size? Is the global batch above the critical batch size? How are stragglers detected?
- **Interview question:** *"Will doubling GPUs halve training time?"* Strong answers cover constant ring comm per GPU, efficiency loss, the critical batch size, LR scaling, and failure rate growing with node count.

**Typical system-design prompt:** *"You doubled the GPUs from 64 to 128, and training only got 30% faster. Explain and fix."*

**1. Clarify first:**
- Did the global batch change (constant per-GPU batch, or constant global)?
- Interconnect and topology for the added nodes.
- Model size vs. compute per GPU (communication-to-compute ratio).

**2. Back-of-envelope sizing:**
- Per-GPU ring all-reduce traffic ≈ 2 × gradient bytes, nearly independent of N. A 7B model in bf16 = 14 GB of grads → ~28 GB per GPU per step.
- At 45 GB/s effective, communication ≈ 0.62 s. If compute is 1.2 s with 80% overlapped, exposed ≈ 0.12 s, giving ~91% efficiency.
- If the new nodes sit behind an oversubscribed spine at 20 GB/s, communication ≈ 1.4 s. That exceeds compute, so exposed ≈ 0.4 s+, and scaling collapses.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Global batch | keep constant (strong scaling) | grow with GPUs (weak scaling) | weak scaling, below the critical batch size |
| Learning rate | unchanged | linear/sqrt scaling + warmup | scale LR with batch, add warmup |
| Communication | fp32 grads | bf16 grads / compression | bf16 communication is standard |
| Sync frequency | every step | gradient accumulation | accumulate to cut communication per sample |
| Parallelism | pure DP | FSDP / TP (Labs 34 and 40) | move beyond DP when the model or communication doesn't fit |

**4. Follow-up questions with crisp answers:**
- *Why is ring all-reduce traffic independent of N?* Each GPU sends and receives 2(N−1)/N of the data, which approaches 2× as N grows.
- *What's the critical batch size?* The batch beyond which bigger batches no longer cut steps to a target loss, so extra GPUs stop helping.
- *Why bucket gradients?* To start communication before backward ends, overlapping it with compute.
- *What does a straggler do?* All ranks wait for the slowest at every all-reduce, so one slow GPU slows the whole job.
- *How do you find stragglers?* Per-rank step timing, plus DCGM metrics for clocks and thermals per GPU.
- *When does accumulation help?* When communication dominates: more compute per sync lowers communication per sample.

**Debug this (common onsite question):** *"Scaling from 64 to 128 GPUs gives only 1.3×."*
1. Per-rank timings: 120 ranks finish backward in 1.2 s, and 8 ranks take 1.9 s.
2. Those 8 ranks are on one node whose GPUs are throttling (DCGM shows thermal slowdown).
3. In addition, the new rack uses 2:1 oversubscribed uplinks, and communication grows to 0.9 s.
4. Fix: drain the hot node and repair its cooling, place jobs within non-oversubscribed pods via topology-aware scheduling, and use gradient accumulation to amortize communication.

The lesson: **synchronous training runs at the speed of the slowest rank and the slowest link.**

**5. What separates senior from staff answers:**
- Senior: computes scaling efficiency and fixes overlap and LR scaling.
- Staff: models communication vs. compute before buying hardware, enforces topology-aware placement, monitors stragglers fleet-wide, and knows when to change parallelism strategy.

**Red flags:** scaling without LR adjustment, ignoring stragglers, no per-rank timing, assuming more GPUs always means faster.

## Failure modes
- Different ranks see the same data (sampler seed bug), so the effective batch is smaller than you think.
- Grad accumulation applied with `no_sync` incorrectly, causing double all-reduce or no sync at all.
- LR not scaled with batch, so the model converges far slower than projected.

## Checklist
- [ ] You can compute global batch and per-step comm volume
- [ ] Scaling efficiency is measured at 1, 2, 4, and 8 nodes
- [ ] A loss-spike rollback procedure exists
