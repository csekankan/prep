# Lab 31: Architecting Ray — Head Nodes, Worker Nodes, and KubeRay (3:52)

## Why it matters
Ray is the "distributed Python" layer used by OpenAI, Uber, and Spotify for training, tuning,
batch inference, and RL. KubeRay makes Ray clusters first-class K8s objects.

## In plain words
Ray is a **project manager for Python**. The head node keeps the to-do list, and worker nodes do the tasks. KubeRay is the HR department
that hires (creates pods) and lets go of workers (deletes pods) as the project grows or shrinks.

## Core concepts

```mermaid
flowchart TB
  subgraph RayCluster
    H[Head pod<br/>GCS, dashboard, autoscaler, driver]
    W1[Worker group: cpu<br/>raylet + object store]
    W2[Worker group: gpu-h100<br/>raylet + object store]
  end
  H <--> W1
  H <--> W2
  OP[KubeRay Operator] -->|reconciles| RayCluster
```

**How to read it:** The KubeRay operator (bottom) reconciles the RayCluster. Inside it, the head pod coordinates and talks to separate CPU and GPU worker groups, each with its own object store.

| Component | Role |
|---|---|
| **GCS** (Global Control Store) | Cluster metadata, actor directory (on head) |
| **Raylet** | Per-node scheduler + object manager |
| **Object store (Plasma)** | Shared-memory store for zero-copy objects |
| **Autoscaler** | Adds/removes worker pods based on resource demand |

**KubeRay CRDs**

| CRD | Use |
|---|---|
| `RayCluster` | Long-lived interactive cluster |
| `RayJob` | Ephemeral cluster per job (creates, runs, deletes) — **preferred for training** |
| `RayService` | Ray Serve app with zero-downtime upgrades |

## Architecture in depth

The overview shows the head, the worker groups, and the operator. This view follows **one RayJob from YAML to finished
cluster**, showing which component acts at each step and where things fail.

```mermaid
sequenceDiagram
  participant U as User / CI
  participant OP as KubeRay operator
  participant H as Head pod (GCS + autoscaler)
  participant W as Worker pods (GPU group)
  participant K as Karpenter / Kueue
  U->>OP: kubectl apply RayJob
  OP->>H: Create head pod + service
  H->>H: GCS ready, dashboard up
  OP->>H: Submit entrypoint (driver)
  H->>H: Autoscaler sees demand: 8 GPUs
  H->>OP: Scale worker group to 2
  OP->>W: Create worker pods
  W->>K: Pending → node provisioned
  W->>H: Raylets register
  H->>W: Schedule tasks / actors
  W-->>H: Job finishes
  OP->>H: Delete cluster (shutdownAfterJobFinishes)
```

### Follow one RayJob through its lifecycle
1. **Apply.** CI submits a RayJob. The KubeRay operator sees the new object.
2. **Head first.** The operator creates the head pod. It runs the GCS (cluster metadata) and the autoscaler, with `num-cpus: 0` so no work runs on it.
3. **Submit driver.** Once the head is ready, the operator submits the entrypoint script.
4. **Demand-driven scaling.** The driver asks for GPU resources, and the Ray autoscaler asks KubeRay for more worker pods.
5. **Nodes appear.** Pending worker pods trigger Kueue admission and Karpenter provisioning (Labs 26 and 30).
6. **Register and run.** Each worker's raylet registers with the GCS, and tasks and actors are scheduled onto it.
7. **Tear down.** When the job ends, the operator deletes the whole cluster, so no idle GPUs remain.

**The one idea to keep:** one RayJob means one short-lived cluster. The head is the single coordinator, so keep it small, stable, and free of work.

## Minimal hands-on

```bash
helm install kuberay-operator kuberay/kuberay-operator -n ray-system --create-namespace
```

```yaml
apiVersion: ray.io/v1
kind: RayCluster
metadata: { name: rc }
spec:
  headGroupSpec:
    rayStartParams: { num-cpus: "0" }      # keep head free of work
    template: { spec: { containers: [{ name: head, image: rayproject/ray:2.40.0-py311 }] } }
  workerGroupSpecs:
  - groupName: gpu
    replicas: 2
    minReplicas: 0
    maxReplicas: 8
    template:
      spec:
        containers:
        - name: w
          image: rayproject/ray:2.40.0-py311-gpu
          resources: { limits: { nvidia.com/gpu: 1, memory: 64Gi } }
```

## Worked example

**Scenario:** A fintech runs nightly pipelines: feature prep (CPU) → fine-tune (8 GPUs) → batch scoring (4 GPUs).

- Before, there were 3 separate systems (Spark, a Slurm-like script, a custom scorer) with data copied between them through S3.
- With Ray, one `RayJob` holds two worker groups (CPU ×20, GPU ×8). Ray Data streams features straight into Ray Train, then into batch inference, and the objects stay in memory.
- The ephemeral cluster scales to zero after the job.
- End-to-end runtime went from 5h to 1h40m, and the GPU-idle time between stages disappeared.

## Production deep dive
- **Head HA:** GCS fault tolerance with external Redis, so a head-pod restart doesn't kill actors (critical for `RayService`).
- **Object store sizing:** Default is 30% of RAM. Spilling to local NVMe beats OOM. Set `object-store-memory` explicitly.
- **Multi-tenancy:** One RayCluster per team or job is safer than a giant shared cluster. Combine with Kueue (Lab 26) for queueing RayJobs.
- **Security:** The Ray dashboard and job API have **no auth by default** and allow remote code execution. Never expose them publicly. Put them behind an authenticated proxy and NetworkPolicies.
- **Images:** Pin Ray and Python versions identically on the head and workers. A mismatch is an instant failure.

## FAANG deep-dive notes

- **How big tech does it:** Ray-style distributed Python runs as ephemeral per-job clusters with queue-based admission, and dashboards and job APIs are kept strictly internal.
- **Staff review questions:** Is the head a single point of failure? Are job APIs authenticated? Is one cluster per team or shared, and why?
- **Interview question:** *"Design a platform for 50 data scientists running Ray jobs on shared GPUs."* Strong answers cover RayJob per run, Kueue admission, autoscaling worker groups, image standards, and security of the dashboard and job submission.

**Typical system-design prompt:** *"Design a Ray platform on Kubernetes for 30 ML teams running training, tuning, and batch inference."*

**1. Clarify first:**
- Mix of workloads: long training, many short tuning trials, batch inference.
- Multi-tenancy: shared clusters or a cluster per job?
- Fault tolerance needs: can a job survive a head-pod failure?

**2. Back-of-envelope sizing:**
- 30 teams × ~5 jobs/day = 150 RayJobs/day. If the head starts in 60 s and workers in 3 min, overhead is ~4 min per job, fine for jobs over 1 hour.
- Head memory: the GCS tracks objects and actors. 10k actors plus large task graphs need 8–16 GB RAM. An OOM on the head kills the whole job.
- Object store: default 30% of node RAM. For a 512 GB node, ~150 GB of shared memory per worker. Size `/dev/shm` accordingly.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Cluster model | shared long-lived RayCluster | RayJob per job | RayJob for batch and training; RayCluster for interactive work |
| Head HA | none | GCS fault tolerance with external Redis | enable for RayService and long jobs |
| Admission | Ray autoscaler only | Kueue + Ray autoscaler | Kueue for quota fairness across teams |
| Workers | one group | groups per hardware type | separate CPU and GPU groups |

**4. Follow-up questions with crisp answers:**
- *Why `num-cpus: 0` on the head?* Work on the head competes with the GCS. A busy head slows or crashes the whole cluster.
- *What happens if the head dies?* Without GCS fault tolerance, the cluster and job are lost. With external Redis, workers reconnect to a new head.
- *RayJob vs. RayCluster?* A RayJob creates a cluster, runs one job, and deletes it, giving clean isolation and no idle cost.
- *How does Ray autoscaling relate to Kubernetes?* Ray requests pods, then Kubernetes and Karpenter provide nodes. They are two loops in series.
- *Why separate worker groups?* So CPU preprocessing doesn't take GPU nodes, and each group scales on its own demand.
- *How do you isolate tenants?* Namespace per team, one cluster per job, and Kueue quotas.

**Debug this (common onsite question):** *"Long Ray jobs fail randomly after 6–10 hours with 'GCS connection lost'."*
1. Head pod events show OOMKilled. GCS memory grew steadily during the job.
2. The driver creates millions of small tasks and keeps their references, so metadata accumulates.
3. The head runs on a 4 GB limit with no GCS fault tolerance.
4. Fix: batch work into fewer, bigger tasks, release references, raise head memory to 16 GB, and enable GCS fault tolerance with external Redis.

The lesson: **the head is a single point of failure. Size it for the task graph and protect it.**

**5. What separates senior from staff answers:**
- Senior: deploys KubeRay, writes RayJobs, separates worker groups.
- Staff: designs tenancy (job-per-cluster plus Kueue), head-node HA, task-granularity guidelines, and cost controls across teams.

**Red flags:** work on the head node, long-lived shared clusters with idle GPUs, no GCS fault tolerance for services, millions of tiny tasks.

## Failure modes
- Head pod runs out of memory because the driver code collects large results with `ray.get` into the head.
- Workers can't reach the head because the NetworkPolicy blocks Ray's port ranges.
- Autoscaler requests a GPU type no node can provide, so pods stay Pending forever.

## Checklist
- [ ] KubeRay operator installed and a RayCluster running
- [ ] Dashboard reachable via port-forward only
- [ ] You understand when to choose RayJob vs. RayCluster vs. RayService
