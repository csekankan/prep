# Lab 91: Multi-Cluster Federation (KubeFed and Karmada) (4:14)

## Why it matters
Enterprises end up with **many clusters**: per region (residency), per environment, per GPU site, at the edge, and sovereign enclaves.
Managing them one by one doesn't scale. Federation propagates workloads and policies across clusters and **places
workloads intelligently** (where GPUs are free, where the data is allowed to be).

## In plain words
Federation is an **air-traffic control tower for many airports** (clusters). You file one flight plan (Deployment + policy), and the tower
decides which airports may receive it, never sending a flight to an airport in a country it isn't allowed to land in.

## Architecture at a glance

```mermaid
flowchart TB
  GIT[Git / Argo CD] --> KAR[Karmada control plane]
  KAR -->|PropagationPolicy: jurisdiction=eu| FRA[Frankfurt cluster]
  KAR --> PAR[Paris cluster]
  KAR --> MIL[Milan cluster]
  KAR -.never.-x US[US cluster]
  KAR -->|Duplicated| POL[Kyverno policies → all clusters]
  ENC["Air-gapped enclave"] -.signed bundles only.- KAR
```

**How to read it:** Git feeds Karmada, which places workloads only on clusters with the matching jurisdiction label. The US cluster is never a candidate. Policies are duplicated everywhere, and the enclave is outside federation.

## Core concepts

| Tool | Status | Model |
|---|---|---|
| **KubeFed** | **Archived** (retired 2023) | Federated* CRD wrappers. Learn it for history and concepts |
| **Karmada** (CNCF) | Active | K8s-native API: you apply normal Deployments plus a `PropagationPolicy` |
| Open Cluster Management (OCM) | Active | Hub/spoke, placement, add-ons (used by RHACM) |
| GitOps fleet (Argo CD ApplicationSets, Flux, Rancher Fleet) | Active | Git-driven per-cluster rendering; no runtime scheduling |
| MultiKueue | Active | Dispatch **batch jobs** to clusters with free quota (Lab 26) |

**Karmada concepts**
- `PropagationPolicy`: which resources go to which clusters (by name, labels, region), and how replicas are divided.
- `OverridePolicy`: per-cluster differences (image registry mirror, storage class, replica count).
- Scheduling: **Duplicated** (full copy everywhere) or **Divided** (split replicas by weight/available capacity).
- Failover: reschedules replicas when a member cluster becomes unhealthy (only **within allowed clusters**).

## Architecture in depth

The overview shows jurisdiction-aware placement. This view follows **one Deployment from Git to member clusters** inside Karmada,
including what happens when a cluster fails.

```mermaid
sequenceDiagram
  participant G as Git / Argo CD
  participant KA as Karmada API server
  participant SCH as Karmada scheduler
  participant FRA as Frankfurt cluster
  participant PAR as Paris cluster
  participant MIL as Milan cluster
  G->>KA: Deployment rag-api (replicas 12) + PropagationPolicy
  KA->>SCH: ResourceBinding: which clusters?
  SCH->>SCH: filter jurisdiction=eu, has GPU, healthy
  SCH->>SCH: divide by weight 50/30/20
  SCH->>FRA: Work: 6 replicas
  SCH->>PAR: Work: 4 replicas
  SCH->>MIL: Work: 2 replicas
  FRA-->>KA: status aggregated
  Note over FRA: Frankfurt becomes unreachable
  SCH->>PAR: failover: 7 replicas
  SCH->>MIL: failover: 5 replicas
```

### Follow one Deployment across clusters
1. **Submit once.** Argo CD applies the Deployment and a PropagationPolicy to the Karmada API, which looks like a normal Kubernetes API.
2. **Binding.** Karmada creates a ResourceBinding to decide where the object should live.
3. **Filter.** Only clusters labelled `jurisdiction=eu`, with GPUs, and currently healthy are candidates. The US cluster is never considered.
4. **Divide.** Replicas are split by weight (50/30/20), proportional to capacity.
5. **Propagate.** Karmada sends a Work object to each member cluster, which creates the real Deployment locally.
6. **Aggregate status.** Each cluster's status is collected back, giving one view of the global deployment.
7. **Failover.** When Frankfurt is unreachable beyond a tolerance window, its replicas are rescheduled to the remaining EU clusters, still within the jurisdiction.

**The one idea to keep:** federation turns "where to run" into a policy. Jurisdiction is a hard filter, and capacity is a weighting.

## Minimal hands-on

```yaml
apiVersion: policy.karmada.io/v1alpha1
kind: PropagationPolicy
metadata: { name: assistant-eu, namespace: ai }
spec:
  resourceSelectors: [{ apiVersion: apps/v1, kind: Deployment, name: assistant }]
  placement:
    clusterAffinity:
      labelSelector: { matchLabels: { jurisdiction: eu, gpu: h100 } }     # residency-safe set
    replicaScheduling:
      replicaSchedulingType: Divided
      replicaDivisionPreference: Weighted
      weightPreference:
        dynamicWeight: AvailableReplicas                                 # follow free GPU capacity
---
apiVersion: policy.karmada.io/v1alpha1
kind: OverridePolicy
metadata: { name: assistant-registry, namespace: ai }
spec:
  resourceSelectors: [{ apiVersion: apps/v1, kind: Deployment, name: assistant }]
  overrideRules:
  - targetCluster: { clusterNames: [fra-onprem-1] }
    overriders: { imageOverrider: [{ component: Registry, operator: replace, value: harbor.fra.corp }] }
```

## Worked example

**Scenario:** An EU telecom has **7 clusters**: 3 on-prem GPU sites (Frankfurt, Paris, Milan), 2 sovereign cloud regions, 1 air-gapped
lawful-intercept enclave, and 1 US cluster for its American subsidiary.

| Workload | Policy |
|---|---|
| Customer assistant (EU PII) | Divided across the 3 on-prem + 2 sovereign-cloud EU clusters by available GPU; **never** US |
| US subsidiary assistant | US cluster only |
| Training jobs | MultiKueue dispatches to whichever EU site has idle H100 quota |
| Kyverno residency + security policies | **Duplicated** to every cluster (Lab 70) |
| Enclave | **Not federated.** Manual, signed bundle import (Lab 94) |

Paris site power outage drill: Karmada moved the Paris replicas to Frankfurt and Milan in ~4 min, and GSLB (Lab 97) shifted the traffic.
The US cluster was never a candidate, by construction.

## Production deep dive
- **Control plane HA:** The Karmada control plane (its own etcd/apiserver) is critical infrastructure. Run it HA, back it up, and consider one per jurisdiction.
- **GitOps + federation:** Git is the source of truth. Argo CD applies to Karmada, and Karmada places onto members. Keep the layers clear.
- **Identity & secrets across clusters:** SPIFFE/SPIRE federation for workload identity and External Secrets per cluster from local vaults. Don't copy secrets across borders.
- **Networking across clusters:** Cilium ClusterMesh / Submariner / service mesh multi-cluster, only where data flows are permitted.
- **Blast radius:** A bad propagated policy hits every cluster. Use staged rollouts across clusters (canary cluster first).

## FAANG deep-dive notes

- **How big tech does it:** Fleet management treats clusters as cattle, with central placement policies, regional control planes, and staged rollouts across clusters.
- **Staff review questions:** Can failover ever cross a jurisdiction? What happens if the federation control plane is down? How are bad propagations contained?
- **Interview question:** *"Manage 50 clusters across 6 countries."* Strong answers cover GitOps, federation/placement, jurisdiction constraints, identity federation, staged rollout, and break-glass procedures.

**Typical system-design prompt:** *"Operate AI workloads across 12 clusters in 5 countries, with data-residency rules and a single control point for platform teams."*

**1. Clarify first:**
- Which workloads span clusters (stateless serving) vs. stay in one (training, stateful data)?
- Residency rules per workload class.
- Failure model: what if the federation control plane itself is down?

**2. Back-of-envelope sizing:**
- 12 clusters × ~300 workloads = 3,600 propagated objects. Karmada handles this comfortably. Plan HA control plane (3 etcd members).
- Failover capacity: losing the largest EU cluster (50% of EU serving) means the others need 2× headroom, or you accept degraded capacity. Typical: N+1 with 30% headroom per cluster.
- Control-plane outage: member clusters keep running their current workloads. Only changes stop.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Federation | Karmada / OCM | GitOps only (Argo CD ApplicationSets) | GitOps for config; Karmada when you need cross-cluster scheduling and failover |
| Scope | everything federated | stateless serving only | federate stateless; keep data and training local |
| Residency | labels by convention | hard cluster-affinity + policy checks | enforced affinity + admission policy |
| Control plane | one global | one per jurisdiction | per-jurisdiction for strict sovereignty |
| Failover | automatic | automatic within jurisdiction, manual across | never automatic across borders |

**4. Follow-up questions with crisp answers:**
- *Why not KubeFed?* It's archived. Karmada and OCM are the maintained options.
- *What happens when Karmada is down?* Member clusters keep running. Only new changes and failover pause.
- *How do you keep failover within a jurisdiction?* Cluster affinity on jurisdiction labels, plus admission policies in each member cluster as a second check.
- *What about stateful workloads?* Federating state is hard. Prefer per-cluster data with event replication (Lab 69).
- *How do you prevent label tampering?* Restrict who can label clusters, and audit changes.
- *GitOps vs. federation?* GitOps pushes desired state. Federation adds scheduling, failover, and status aggregation.

**Debug this (common onsite question):** *"During a Frankfurt outage, some EU workloads failed over to the London cluster."*
1. London was labelled `region=europe` and `jurisdiction=eu` when it was created years ago.
2. Post-Brexit, the residency assessment changed, but the cluster labels weren't updated.
3. The PropagationPolicy matched on labels, so London was a valid candidate.
4. Fix: maintain cluster jurisdiction labels from a governed inventory (not by hand), add admission policies in member clusters that reject workloads with mismatched data class, and review labels as part of compliance audits.

The lesson: **federation enforces whatever your labels say. Govern the labels like you govern the policies.**

**5. What separates senior from staff answers:**
- Senior: sets up Karmada with jurisdiction-aware propagation and failover.
- Staff: decides what to federate, designs per-jurisdiction control planes, failover capacity, and governed cluster inventory, and plans for control-plane failure.

**Red flags:** federating stateful data naively, cross-border automatic failover, hand-maintained cluster labels, no capacity headroom for failover.

## Failure modes
- Failover policy without residency constraints means an outage triggers an automatic legal violation.
- Federation control plane down means no new deployments (running workloads continue), so have a break-glass procedure.
- Divergent cluster versions/CRDs cause propagation failures. Standardize cluster baselines.

## Checklist
- [ ] Karmada (or OCM) with ≥ 2 member clusters
- [ ] PropagationPolicy constrained by jurisdiction labels
- [ ] Cluster failover drill respecting residency
