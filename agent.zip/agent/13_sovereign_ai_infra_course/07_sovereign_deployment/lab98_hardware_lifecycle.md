# Lab 98: The Ghost in the Machine — Physical Hardware Lifecycle (4:12)

## Why it matters
Software people forget that **GPUs are physical**. They arrive late, fail (often early in life), degrade, overheat, need firmware
updates, and when retired they may **still hold data**. In a sovereign platform you own the hardware's full lifecycle: procurement to destruction.

## In plain words
GPUs are like **aircraft**: inspected before first flight (burn-in), constantly monitored, grounded at the first warning light (auto-cordon),
repaired or replaced, and at retirement their black boxes (drives) are wiped or destroyed so no secrets leave with the scrap.

## Architecture at a glance

```mermaid
flowchart LR
  P[Procure] --> RA["Receive + attest"] --> BI["Burn-in 24-72h"]
  BI -->|fail| RMA[RMA]
  BI -->|pass| PR[Production]
  PR --> MON{"Health: XID, ECC, NVLink"}
  MON -->|fault| CO[Auto-cordon + ticket] --> RMA
  MON -->|healthy| PR
  PR --> RF["Refresh: training → inference"]
  RF --> SAN["Sanitize NIST 800-88"] --> DSP[Dispose + certificate]
```

**How to read it:** The top row is the normal path from procurement to production. The health loop either keeps nodes in production or cordons them for RMA. The bottom path covers refresh, sanitization, and disposal.

## Core concepts — lifecycle stages

```
Procure → Receive & attest → Burn-in → Production → Monitor & repair → Refresh/repurpose → Sanitize → Dispose
```

| Stage | Key activities |
|---|---|
| **Procure** | Vendor diversity (Lab 24), lead times (6–12 months for top GPUs), power/cooling readiness (Blackwell racks: ~120+ kW, liquid cooling), export-control compliance |
| **Receive & attest** | Verify serials, firmware versions, supply-chain integrity (tamper seals, firmware signatures, TPM/SPDM attestation) |
| **Burn-in** | 24–72 h stress: DCGM diagnostics (`dcgmi diag -r 3`), NCCL all-pairs tests (Lab 36), memory tests, thermal soak. Early-life failures show up here |
| **Production** | Cordon/drain automation, health checks, firmware/driver cadence (Lab 21) |
| **Monitor & repair** | XID errors, ECC, row remapping, NVLink errors, thermal throttling. Automate cordon, then ticket, then RMA |
| **Refresh** | Training-grade to inference-grade to dev/test (cascading reuse) |
| **Sanitize** | NIST SP 800-88: clear/purge/destroy media (NVMe, SSDs, BMC logs). GPU HBM is volatile, but **node drives, BMC, and NIC firmware configs** keep secrets |
| **Dispose** | Certified destruction or recycling, chain-of-custody records |

**Key GPU health signals**

| Signal | Meaning | Action |
|---|---|---|
| XID 79 (fallen off bus), 48 (DBE ECC), 94/95 (contained/uncontained ECC) | Hardware fault | Cordon; reset or RMA |
| Row remapping pending / failure | HBM degradation | Reset to apply; RMA if remapping fails |
| NVLink CRC/replay errors rising | Cable/connector/switch issue | Inspect, reseat, replace |
| Persistent thermal throttling | Cooling issue | Facility ticket |
| "Silent" slowness (straggler, Lab 37) | Degraded chip/link | Benchmark-based eviction |

## Architecture in depth

The overview shows the lifecycle from procurement to disposal. This view shows the **automated remediation loop** for a GPU fault in
production, which is where most operational effort goes.

```mermaid
flowchart TB
  DCGM["DCGM / kernel log: XID 79 on node gpu-17, GPU 3"] --> CLS{"Classify fault"}
  CLS -->|"XID 13/31/43: app error"| APP["Notify job owner, no node action"]
  CLS -->|"XID 48/63/64/94/95: ECC"| ECC["Cordon + drain gracefully"]
  CLS -->|"XID 79: fallen off bus"| HARD["Cordon + drain now"]
  ECC & HARD --> CK["Jobs checkpoint/requeue (Lab 39)"]
  CK --> DIAG["Run DCGM diag level 3 + GPU reset / node reboot"]
  DIAG -->|pass| BURN["Short burn-in + nccl-tests"] --> UNC[Uncordon]
  DIAG -->|fail| RMA["Open RMA ticket with logs + serial"]
  RMA --> REPL[Replace part] --> BURN
  CNT[(Fault history per serial)] -.repeat offender → RMA directly.-> CLS
```

### Follow one GPU failure from signal to repair
1. **Signal.** DCGM and the kernel log report XID 79 (GPU fell off the bus) on node `gpu-17`.
2. **Classify.** Not every XID is hardware. Some indicate application bugs (e.g. illegal memory access), so the job owner is told and the node keeps running.
3. **Cordon and drain.** Hardware faults cordon the node, so no new pods land there. Running jobs are drained, gracefully for ECC warnings and immediately for a dead GPU.
4. **Protect jobs.** Training jobs resume from their last checkpoint on other nodes.
5. **Diagnose.** DCGM level-3 diagnostics plus a GPU reset or reboot. Many faults are transient.
6. **Return or replace.** If diagnostics pass, a short burn-in and NCCL test run before uncordoning. If not, an RMA ticket opens automatically with logs and serial numbers.
7. **Learn.** Fault history per serial number catches repeat offenders, which go straight to RMA.

**The one idea to keep:** at fleet scale, hardware failure is routine. Automate classification, isolation, and validation, and keep humans for parts replacement.

## Minimal hands-on — automated health gate

```bash
# Node problem detector-style check (DaemonSet / CronJob on GPU nodes)
dcgmi diag -r 2 -j | jq -e '.DCGM_GPU_DIAGNOSTIC.test_categories[].tests[] | select(.results[].status=="Fail")' \
  && kubectl cordon "$NODE_NAME" \
  && kubectl label node "$NODE_NAME" gpu-health=failed --overwrite
nvidia-smi -q -d ROW_REMAPPER,ECC | grep -E "Pending|Failure|Uncorr"
```

Tools: NVIDIA **NVSentinel**-style health automation / DCGM health watches, node-problem-detector with custom GPU plugins, and a
"GPU health controller" that cordons, drains (respecting PDBs), opens a ticket, and tracks RMA state.

## Worked example

**Scenario:** A 2,048-GPU H100 sovereign cluster in its first year.

| Metric | Observed |
|---|---|
| GPUs failing burn-in (DOA / early life) | 1.1% (23 GPUs). RMA'd **before** production |
| Production GPU hardware incidents | ~3–5 per week (XID/ECC/NVLink) |
| Mean time to cordon (automated) | 40 s, vs. ~3 h when manual |
| Training jobs affected per incident | ~1, auto-resumed from checkpoint (Lab 39) |
| Spare pool | 2% hot spares (40 GPUs, 5 nodes) for fast swap |

Year-3 refresh: H100 training nodes were repurposed to inference (where memory bandwidth per $ is still good), and their NVMe drives were
**cryptographically erased** (keys destroyed), then physically shredded per the classified-data policy. Every step was logged with serial numbers for audit.

## Production deep dive
- **Inventory as code:** Serial → node → rack → firmware → health history → RMA cases → disposal certificate, in a CMDB (NetBox) linked to K8s node labels.
- **Firmware governance:** GPU VBIOS, NVSwitch, NIC, BMC, and BIOS versions pinned and rolled out like software (canary, Lab 21). Many "random" failures are firmware bugs.
- **Facilities:** Power (rack density), cooling (liquid loops on Blackwell), and power capping during grid stress. Thermal events show up as training stragglers.
- **Security:** BMC/IPMI hardening (separate network, no default creds), secure boot, measured boot, confidential computing attestation.
- **Sustainability:** Track PUE, energy per token/training run, and carbon intensity. These are increasingly reporting requirements (EU CSRD, AI Act GPAI energy reporting).

## FAANG deep-dive notes

- **How big tech does it:** Automated hardware health pipelines detect, drain, repair, and return nodes without humans in the loop for common faults. Fleet reliability metrics are reviewed weekly.
- **Staff review questions:** How long from GPU fault to cordon? What is the spare ratio? How are drives sanitized and certified?
- **Interview question:** *"Your 2,000-GPU cluster has 5 hardware faults per week. Design the response."* Strong answers cover health signals, auto-cordon and drain, checkpoint-resume, spares, RMA workflow, and trend analysis.

**Typical system-design prompt:** *"Design hardware operations for a 4,000-GPU on-prem fleet over 5 years, from delivery to disposal."*

**1. Clarify first:**
- Vendor support model (RMA times, on-site spares).
- Sovereignty and security requirements for disposal (data on drives, firmware).
- Refresh plan: will old training GPUs be reused for inference?

**2. Back-of-envelope sizing:**
- GPU annualized failure rates of ~1–5% for large fleets → 40–200 GPU failures per year, about one every 2–9 days. Plus NICs, optics, PSUs, and drives.
- Spares: hold ~2–3% spare nodes so capacity isn't reduced while RMAs (often 1–3 weeks) are pending.
- Burn-in: 500 new nodes × 48 h burn-in catches early-life failures that would otherwise hit production jobs in month one.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Acceptance | trust vendor | own burn-in (DCGM diag, nccl-tests, HPL) | always run your own burn-in |
| Remediation | manual tickets | automated cordon, diagnose, RMA | automate the common paths |
| Spares | none | on-site spare pool | 2–3% spares |
| Refresh | sell old GPUs | cascade training → inference | cascade, then sanitize and dispose |
| Disposal | vendor wipes | NIST 800-88 sanitize + certificate | your own verified process |

**4. Follow-up questions with crisp answers:**
- *Why burn in?* Failure rates are highest early in a component's life (the bathtub curve). Catch failures before production.
- *Which XIDs mean hardware?* For example 48 (double-bit ECC), 79 (fallen off bus), 94/95 (contained/uncontained ECC). Others like 13 or 31 often indicate software.
- *Why track faults per serial?* Some parts fail repeatedly. History turns guesswork into evidence for RMA.
- *What is NIST 800-88?* Media sanitization guidance: clear, purge, or destroy, with verification and certificates.
- *What about firmware?* Track and roll out BMC, GPU, and NIC firmware like software, with staged rollouts.
- *How do you handle thermal problems?* Monitor clocks and temperatures per GPU. Throttling GPUs slow whole synchronous jobs (Lab 37).

**Debug this (common onsite question):** *"One rack's nodes keep failing NCCL tests intermittently, but every GPU passes diagnostics."*
1. Failures correlate with time of day and high load across the rack.
2. Switch counters show errors on optical links in that rack, and optic temperatures are high.
3. A cooling issue at the top of the rack is overheating optics, not GPUs.
4. Fix: replace the affected optics, repair airflow, add link-error and optic-temperature monitoring to the health gate, and include the network in burn-in, not just GPUs.

The lesson: **"GPU problems" are often network, power, or cooling problems. Monitor the whole system.**

**5. What separates senior from staff answers:**
- Senior: automates the health gate, cordon, and RMA flow, and runs burn-in.
- Staff: designs fleet lifecycle economics (spares, refresh cascade, TCO), vendor SLAs, firmware management, whole-system telemetry, and sovereign disposal with evidence.

**Red flags:** no burn-in, manual fault handling, no fault history, trusting vendor wipes, ignoring network and cooling telemetry.

## Failure modes
- No burn-in, so early-life failures hit production training runs in week one.
- Manual cordoning means a bad GPU crashes job after job overnight.
- Retired servers sold with unwiped NVMe containing model weights, datasets, or credentials.

## Checklist
- [ ] Burn-in procedure with DCGM diag + NCCL tests
- [ ] Automated cordon/ticket on GPU health failures
- [ ] Sanitization procedure (NIST 800-88) with chain of custody
