# Lab 93: Sovereign Cloud Interoperability (Gaia-X Standards) (3:51)

## Why it matters
Sovereignty doesn't mean isolation. Organizations need to **share data, models, and compute with partners** (hospitals, suppliers,
research consortia) while keeping control. Gaia-X defines a framework for **verifiable trust** between participants, so
"who you are, what you offer, and under which rules" is machine-checkable.

## In plain words
Gaia-X is a **passport and visa system for data and cloud services**. Organisations carry verifiable passports (credentials), data comes
with visa rules (usage policies such as "training only, 90 days, EU only"), and connectors are the border control that checks them automatically.

## Core concepts

| Concept | Meaning |
|---|---|
| **Participant** | Organization with a verifiable identity (legal entity credentials) |
| **Service offering** | Machine-readable description of a cloud/data/AI service, its location, certifications, and terms |
| **Verifiable Credentials (W3C VC)** | Signed claims ("this service runs in the EU", "ISO 27001 certified") |
| **Decentralized Identifiers (DIDs)** | Self-controlled identifiers (e.g. `did:web:ai.hospital.example`) |
| **Gaia-X Compliance / Trust Framework** | Rules + compliance service that checks credentials. Labels (levels 1–3) express sovereignty strength |
| **Data spaces** | Sector ecosystems (health, mobility such as Catena-X for automotive, manufacturing) |
| **Dataspace connector** (Eclipse EDC, IDSA) | Software that negotiates **usage policies** (ODRL) and transfers data under contract |

**Usage control is the core idea:** Data is shared with *enforceable policies* such as "use only for model training of purpose X, delete after 90 days, no onward transfer".
Data is not just handed over.

```mermaid
sequenceDiagram
  participant A as Hospital A (provider, EDC)
  participant CAT as Federated catalogue
  participant B as AI Lab B (consumer, EDC)
  A->>CAT: publish dataset offer + ODRL policy + VCs (EU-hosted, GDPR-basis)
  B->>CAT: discover offer
  B->>A: contract negotiation (B presents its VCs)
  A-->>B: agreement (policy: training only, 90 days, EU compute)
  B->>A: transfer request → data plane (or compute-to-data)
```

**How to read it:** The provider publishes an offer with a policy and credentials to a catalogue. The consumer discovers it, negotiates by presenting its own credentials, and receives data, or sends compute to the data, under the agreed policy.

## Architecture in depth

The concepts diagram shows the offer, negotiation, and transfer sequence. This view shows the **control plane vs. data plane split**
in a dataspace connector, and where policies are enforced during use.

```mermaid
flowchart TB
  subgraph Provider["Hospital A (provider)"]
    PCP["Connector control plane<br/>catalogue, contracts, policy engine"]
    PDP["Data plane<br/>S3 / API / compute-to-data"]
    DATA[(Imaging dataset)]
    PDP --- DATA
  end
  subgraph Consumer["AI Lab B (consumer)"]
    CCP["Connector control plane"]
    CDP["Data plane: EU GPU cluster"]
  end
  TRUST["Trust anchors: Gaia-X Compliance,<br/>verifiable credentials (DIDs)"]
  CCP <-->|"(1) catalogue + (2) negotiate (DSP protocol)"| PCP
  PCP -.verify consumer VCs.-> TRUST
  CCP -.verify provider VCs.-> TRUST
  PCP -->|"(3) agreement → start transfer"| PDP
  PDP -->|"(4) data or results only"| CDP
  CDP -->|"(5) usage logs"| CCP
  PCP -.->|"(6) audit + revoke on expiry"| PDP
```

### Follow one dataset agreement from offer to revocation
1. **Catalogue.** The consumer's connector queries the provider's catalogue and finds a dataset offer with an ODRL policy (training only, EU compute, 90 days).
2. **Verify identities.** Each side checks the other's verifiable credentials, e.g. "EU-registered research org" and "Gaia-X compliant service".
3. **Negotiate.** The connectors agree on a contract using the Dataspace Protocol. The agreement is signed and stored on both sides.
4. **Transfer.** Only after agreement does the provider's data plane deliver data, or, with compute-to-data, run the consumer's job next to the data and return only results.
5. **Use under policy.** The consumer's cluster enforces the constraints (EU location, purpose), backed by its own residency policies (Lab 70).
6. **Log and expire.** Usage is logged. At 90 days, access is revoked and deletion is attested.

**The one idea to keep:** a dataspace separates *agreeing* (control plane, with verifiable identities) from *moving data* (data plane). The policy travels with the agreement.

## Minimal hands-on — a usage policy (ODRL, simplified)

```json
{
  "@context": "http://www.w3.org/ns/odrl.jsonld",
  "@type": "Offer",
  "permission": [{
    "action": "use",
    "constraint": [
      { "leftOperand": "purpose", "operator": "eq", "rightOperand": "oncology-model-training" },
      { "leftOperand": "spatial", "operator": "isPartOf", "rightOperand": "EU" },
      { "leftOperand": "elapsedTime", "operator": "lteq", "rightOperand": "P90D" }
    ],
    "duty": [{ "action": "delete", "constraint": [{ "leftOperand": "elapsedTime", "operator": "eq", "rightOperand": "P90D" }] }]
  }],
  "prohibition": [{ "action": "distribute" }]
}
```

On the consumer's platform, these constraints map to concrete controls: Kyverno residency (Lab 70), MinIO lifecycle deletion (Lab 67),
provenance manifests recording the contract ID (Lab 66), and audit (Lab 99).

## Worked example

**Scenario:** **5 European hospitals** and an AI startup want to build a radiology triage model. Hospitals can't send images to the startup's cloud.

| Option | Verdict |
|---|---|
| Central data pool | Legal/ethical blockers, months of DPAs |
| **Data space + compute-to-data** | Hospitals publish offers via EDC. The startup's training container (signed) runs **inside each hospital's sovereign cluster**. Only model updates leave (combine with federated learning, Lab 96) |

Trust is established via VCs: the startup proves its legal identity and certification, and each hospital cluster proves EU location and certification.
Contracts are machine-negotiated and logged. Onboarding a new hospital took **3 weeks instead of ~6 months** of bilateral legal work, because the policy
templates and credentials were reusable.

## Production deep dive
- **Identity infrastructure:** Issue and manage VCs/DIDs (wallets, key management in HSMs). Rotate keys and handle revocation.
- **Connectors on K8s:** Deploy EDC control and data planes as services with HA, mTLS, and policy engines. Treat them as critical edge components.
- **Policy enforcement gap:** ODRL describes policies, and *your platform* enforces them. Map every policy term to a technical control and test it.
- **Interoperability beyond Gaia-X:** IDSA, Eclipse Dataspace Components, SIMPL (the EU's data-space middleware), and sector rulebooks. Align with what your ecosystem actually uses.
- **AI-specific:** Publish **model offerings** too (model card + VCs about training data provenance and AI Act tier) so partners can verify before use.

## FAANG deep-dive notes

- **How big tech does it:** Data clean rooms and partner data-sharing platforms enforce usage policies technically, with audit, rather than relying on contracts alone.
- **Staff review questions:** Which technical control enforces each policy term? How are credentials revoked? Can data be copied outside the controlled plane?
- **Interview question:** *"Train a model on data from 5 hospitals that can't share data."* Strong answers cover compute-to-data or federated learning, usage policies, verifiable identities, provenance, and audit.

**Typical system-design prompt:** *"Enable 10 hospitals in 4 countries to share data for training a diagnostic model, without a central data lake."*

**1. Clarify first:**
- Can data move at all, or must computation go to the data?
- Legal basis per hospital and country (GDPR, national health laws).
- Trust model: who issues credentials, who audits?

**2. Back-of-envelope sizing:**
- 10 hospitals × 50 TB imaging = 500 TB. Moving it all is slow and legally hard. Compute-to-data moves the model (~1 GB) instead.
- Contract negotiation is cheap (seconds). The real timeline is legal: weeks per partner, which pre-agreed policy templates reduce.
- If compute-to-data is chosen, each hospital needs local GPU capacity (e.g. 4–8 GPUs), or a trusted regional processor.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Data movement | transfer copies | compute-to-data / federated learning (Lab 96) | compute-to-data for sensitive data |
| Connector | custom APIs | Eclipse Dataspace Components (EDC) | standard connectors for interoperability |
| Policies | contracts in PDFs | machine-readable ODRL | ODRL, linked to the legal contract |
| Trust | bilateral checks | credentials from trusted issuers | verifiable credentials |
| Enforcement | trust the consumer | technical controls + audit logs | both technical and contractual |

**4. Follow-up questions with crisp answers:**
- *What is Gaia-X?* A European framework of standards for trustworthy, interoperable data and cloud services, not a cloud provider.
- *What is a connector?* Software that each participant runs to publish offers, negotiate contracts, and control data transfer.
- *What is ODRL?* A W3C language for permissions, prohibitions, and obligations on data use.
- *Can policies be enforced after transfer?* Only partly, through technical controls on the consumer's side and audits. Compute-to-data avoids the problem.
- *What are verifiable credentials?* Cryptographically signed claims about an organization or service, checkable without calling the issuer.
- *How does this relate to the EU Data Act and data spaces?* It's the technical basis for sector data spaces (health, mobility, manufacturing).

**Debug this (common onsite question):** *"A partner's dataset was used to train a commercial model, although the agreement said research only."*
1. The ODRL policy said "purpose: research", but the consumer's training pipeline never read the policy.
2. Data was copied into a general data lake after transfer, where the purpose metadata was lost.
3. Nobody audited usage logs against agreements.
4. Fix: carry agreement IDs and purpose with data into the lake (as tags enforced by policy), require an agreement check before training jobs (provenance, Lab 66), prefer compute-to-data for restricted purposes, and audit usage regularly.

The lesson: **policies on paper don't follow data. Bind usage rules to the data and check them where it's used.**

**5. What separates senior from staff answers:**
- Senior: deploys connectors, writes ODRL policies, sets up credentials.
- Staff: chooses between transfer, compute-to-data, and federated learning per use case, links legal agreements to technical enforcement, and designs audit across organizations.

**Red flags:** copying shared data into general lakes, policies nobody's pipeline reads, custom one-off sharing APIs, no audit of usage vs. agreement.

## Failure modes
- Credentials checked at onboarding but never re-validated (expired certification still trusted).
- Policies agreed in the connector but not enforced in storage/compute, which is compliance theater.
- Data copied outside the controlled data plane ("just for debugging").

## Checklist
- [ ] You can explain VC/DID, service offering, and connector roles
- [ ] One ODRL policy mapped to concrete K8s/storage controls
- [ ] Compute-to-data pattern sketched for a partner use case
