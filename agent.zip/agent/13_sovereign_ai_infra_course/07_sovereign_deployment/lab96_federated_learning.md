# Lab 96: Federated Learning Pipelines across Multiple Organizations (4:20)

## Why it matters
Lab 95 distributes *compute*. Federated learning (FL) distributes *data ownership*: multiple organizations train a shared model **without any
raw data leaving its owner**. It is the technical answer to "we can't share data, but we all want a better model" in healthcare,
banking (fraud), telecom, and manufacturing.

## In plain words
Six chefs want one great recipe, but none will share their secret ingredients. Each **cooks at home**, then sends only notes on how the
recipe should change. A trusted referee (aggregator) combines the notes without seeing any individual chef's notes (secure aggregation).
The recipe improves, and the secrets stay home.

## Architecture at a glance

```mermaid
flowchart TB
  AGG["Aggregator in TEE: secure aggregation"] -->|global model| B1[Bank 1 cluster]
  AGG --> B2[Bank 2 cluster]
  AGG --> B3[Bank N cluster]
  B1 -->|"DP-noised update only"| AGG
  B2 --> AGG
  B3 --> AGG
  D1[(Raw data stays)] --- B1
  D2[(Raw data stays)] --- B2
  AGG --> SIG["Signed model per round + provenance"]
```

**How to read it:** The aggregator sends the global model to each bank. Each bank trains locally and sends back only noised updates. The aggregator combines them securely and signs the new model each round.

## Core concepts

| Concept | Meaning |
|---|---|
| **FedAvg** | Server sends the model, clients train locally for E epochs, send updates, server averages (weighted by sample count) |
| **Cross-silo FL** | Few large, reliable participants (hospitals, banks). Our focus |
| **Cross-device FL** | Millions of phones. Different engineering |
| **Non-IID data** | Each silo's data differs (case mix, demographics). Use FedProx, SCAFFOLD, or personalization layers |
| **Secure aggregation** | Server sees only the *sum* of updates, never an individual silo's update |
| **Differential privacy (DP)** | Clip + add noise to updates. A formal bound (ε) on what any single record can leak |
| **Confidential computing (TEE)** | Aggregator runs in an attested enclave (H100 CC, SEV-SNP, TDX) |
| **Frameworks** | Flower, NVIDIA FLARE, OpenFL, FATE |

**Threats:** Gradient inversion (reconstruct inputs from updates), membership inference, and model poisoning by a malicious silo.
Defenses are layered: secure aggregation + DP + robust aggregation (median/trimmed mean) + client attestation.

## Architecture in depth

The overview shows banks sending noised updates to a secure aggregator. This view follows **one federated round** and shows where
each privacy protection is applied.

```mermaid
sequenceDiagram
  participant AG as Aggregator (in TEE)
  participant B1 as Bank 1
  participant B2 as Bank 2
  participant B3 as Bank 3
  AG->>B1: global model round 12 (signed)
  AG->>B2: global model round 12
  AG->>B3: global model round 12
  B1->>B1: train 1 epoch locally on own data
  B1->>B1: clip update norm ≤ C, add DP noise
  B1->>B1: mask update (secure aggregation share)
  B1->>AG: masked update
  B2->>AG: masked update
  B3--xAG: offline this round (dropout tolerated)
  AG->>AG: masks cancel in the sum → only the total is visible
  AG->>AG: FedAvg weighted by samples → round 13
  AG->>AG: sign model + log round provenance
```

### Follow one round from broadcast to new model
1. **Broadcast.** The aggregator sends the signed global model to each participant. Each bank checks the signature before training.
2. **Local training.** Each bank trains on its own data inside its own cluster. Raw data never leaves.
3. **Clip.** Each update's size is capped, so no single bank, or single customer record, can dominate.
4. **Add noise.** Differential-privacy noise is added, which bounds what can be learned about any individual from the update.
5. **Mask.** Secure aggregation adds pairwise masks that cancel out in the sum, so the aggregator sees only the total, never one bank's update.
6. **Tolerate dropouts.** If Bank 3 is offline, the protocol still completes with the others.
7. **Aggregate and sign.** The weighted average becomes the next model, and the round's participants and parameters are logged for provenance.

**The one idea to keep:** federated learning moves the model to the data. Clipping, noise, and secure aggregation protect what the updates themselves could reveal.

## Minimal hands-on (Flower)

```python
# client.py — runs inside each organization's cluster
import flwr as fl

class Client(fl.client.NumPyClient):
    def get_parameters(self, config): return get_weights(model)
    def fit(self, parameters, config):
        set_weights(model, parameters)
        train(model, local_loader, epochs=config["local_epochs"], dp_clip=1.0, dp_noise=0.8)   # DP-SGD (Opacus)
        return get_weights(model), len(local_loader.dataset), {}
    def evaluate(self, parameters, config):
        set_weights(model, parameters); loss, acc = test(model, local_val)
        return loss, len(local_val.dataset), {"acc": acc}

fl.client.start_client(server_address="fl.consortium.example:443", client=Client().to_client(),
                       root_certificates=open("ca.pem", "rb").read())
```

```python
# server.py — aggregator (ideally inside a TEE)
strategy = fl.server.strategy.FedProx(proximal_mu=0.1, min_fit_clients=4, min_available_clients=5,
                                      fraction_fit=1.0, on_fit_config_fn=lambda r: {"local_epochs": 2})
fl.server.start_server(server_address="0.0.0.0:8443", strategy=strategy,
                       config=fl.server.ServerConfig(num_rounds=50))
```

## Worked example

**Scenario:** **6 banks** want a better fraud model. Fraud patterns cross banks (mule accounts), but sharing transaction data is illegal or
unacceptable.

| Model | AUC-PR on each bank's holdout (avg) |
|---|---|
| Each bank alone | 0.41 |
| Federated (FedProx, 50 rounds) | **0.58** |
| Federated + DP (ε = 8) | 0.55 |
| Hypothetical centralized (not allowed) | 0.60 |

Architecture: each bank runs a Flower client in its own K8s cluster (updates only, mTLS). The aggregator runs in a **confidential VM with remote
attestation**, operated by a neutral consortium entity. Secure aggregation means even the operator sees only sums. Each round's global model is
**signed and recorded** with provenance (Lab 66). Each bank keeps a personalization head trained only on its own data.

Federation recovered **~90% of the centralized gain** while staying compliant with banking secrecy and GDPR.

## Production deep dive
- **Governance first:** A consortium agreement covering who owns the model, IP, liability, exit rights, and the data use policy (Gaia-X-style contracts, Lab 93).
- **Operations:** Each silo has heterogeneous infrastructure. Ship the client as a signed container with pinned versions, plus a health check and dry-run mode.
- **Data harmonization:** Common feature schemas (Pydantic contracts, Lab 64) are often harder than the ML. Budget time for it.
- **Evaluation:** Per-silo eval and fairness across silos. Make sure the global model doesn't regress for minority silos.
- **Poisoning defense:** Robust aggregation, anomaly detection on update norms, and attestation of client code.

## FAANG deep-dive notes

- **How big tech does it:** Federated learning in production combines secure aggregation, differential privacy, and attestation, with careful measurement of utility vs. privacy budget.
- **Staff review questions:** What ε is used, and why? Is aggregation secure? How do you detect a poisoning client?
- **Interview question:** *"Design federated fraud detection across banks."* Strong answers cover cross-silo FL, non-IID handling, secure aggregation, DP, TEE aggregation, governance, and per-silo evaluation.

**Typical system-design prompt:** *"Train a fraud-detection model across 8 banks that legally cannot share customer data."*

**1. Clarify first:**
- Data shape: same features across banks (horizontal) or different features for the same customers (vertical)?
- Privacy requirements: is secure aggregation enough, or is formal DP required?
- Trust: who runs the aggregator? Can it be a neutral party or a TEE?

**2. Back-of-envelope sizing:**
- Model: a 50M-parameter tabular or transformer model is 200 MB per update. 8 banks × 200 MB per round is trivial over normal links.
- Rounds: typically 50–500 rounds. At ~20 minutes of local training + 2 minutes of communication, 200 rounds ≈ 3 days.
- DP cost: a privacy budget ε of ~2–8 typically costs a few points of accuracy. Measure it against the non-DP baseline on a simulation.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Framework | custom | Flower / NVIDIA FLARE | established frameworks |
| Privacy | secure aggregation only | + differential privacy | add DP for regulated personal data |
| Aggregator trust | one bank runs it | neutral party or TEE | neutral or attested TEE |
| Data heterogeneity | plain FedAvg | FedProx / personalization layers | handle non-IID data explicitly |
| Participation | all required | dropout-tolerant | tolerate dropouts |

**4. Follow-up questions with crisp answers:**
- *Why isn't "data stays local" enough?* Model updates can leak training data through inversion or membership inference.
- *What does secure aggregation protect?* Individual updates from the aggregator. It doesn't protect against what the final model reveals.
- *What does DP protect?* It bounds how much any single record influences the result, measured by ε.
- *What is non-IID data?* Each bank's data distribution differs, so updates disagree and convergence slows.
- *How do you evaluate without sharing data?* Federated evaluation: each bank evaluates locally and reports metrics only.
- *How do you stop a malicious participant poisoning the model?* Norm clipping, robust aggregation (median or trimmed mean), and anomaly detection on updates.

**Debug this (common onsite question):** *"The federated fraud model performs well for 7 banks, but badly for the smallest one."*
1. Per-bank federated evaluation shows the small bank has very different fraud patterns (a regional market).
2. FedAvg weights by sample count, so the small bank's signal is drowned out.
3. DP noise, scaled for the whole federation, hits the small bank's few updates hardest.
4. Fix: personalization (shared base + local head layers), FedProx to handle heterogeneity, per-bank metrics as acceptance criteria, and agreed fairness weighting in the consortium contract.

The lesson: **a federation averages its members. Measure per member and personalize where they differ.**

**5. What separates senior from staff answers:**
- Senior: runs Flower with secure aggregation, DP, and federated evaluation.
- Staff: designs the consortium's trust model, privacy budget, poisoning defences, per-member acceptance criteria, and the governance and legal agreements around rounds and model ownership.

**Red flags:** treating "data stays local" as full privacy, a member bank running the aggregator unchecked, only global metrics, no poisoning defence.

## Failure modes
- Assuming FL means privacy. Without DP/secure aggregation, updates can leak training records.
- Non-IID data plus naive FedAvg gives a global model worse than local models for some silos.
- One silo's slow infrastructure stalls rounds. Set timeouts and allow partial participation.

## Checklist
- [ ] Flower/FLARE federation with ≥ 3 clients running
- [ ] DP or secure aggregation enabled, with ε documented
- [ ] Per-silo evaluation and a signed global model per round
