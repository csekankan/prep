# Section 8 — Sovereign Deployment & Decentralized Research (7:23)

**Goal:** Operate AI across **clusters, regions, organizations, and legal regimes**, including fully offline. Then audit
everything and design the capstone: a sovereign Blackwell-class platform.

| Lab | Topic | Key idea |
|---|---|---|
| [91](lab91_multi_cluster_federation.md) | Multi-cluster federation | One control plane, many clusters |
| [92](lab92_eu_ai_act_compliance_as_code.md) | EU AI Act compliance-as-code | Risk tier → required controls, automated |
| [93](lab93_gaia_x_interoperability.md) | Gaia-X interoperability | Verifiable, federated trust |
| [94](lab94_air_gapped_architecture.md) | Air-gapped serving | No internet, still production-grade |
| [95](lab95_decentralized_training_wan.md) | Training over WAN | Low-communication optimizers |
| [96](lab96_federated_learning.md) | Federated learning | Train together, share no raw data |
| [97](lab97_global_traffic_border_routing.md) | Border-aware routing | Route by law, not just latency |
| [98](lab98_hardware_lifecycle.md) | Hardware lifecycle | GPUs fail, age, and leak data |
| [99](lab99_architects_review_audit.md) | The architect's review | Audit the whole stack |
| [100](lab100_sovereign_blackwell_capstone.md) | Capstone | Design the sovereign Blackwell platform |

## Sovereignty maturity model

| Level | Description |
|---|---|
| 0 — Dependent | Public APIs only; no control over model, data location, or availability |
| 1 — Hosted open models | Open-weight models on a cloud you rent; data residency by region |
| 2 — Controlled platform | Own K8s platform, own registry, policies, audit (Sections 2–7) |
| 3 — Sovereign operations | Multi-cluster, residency-enforced, air-gap-capable, vendor-diverse hardware |
| 4 — Sovereign ecosystem | Federated with partners (Gaia-X), joint training without data sharing, verifiable compliance |
