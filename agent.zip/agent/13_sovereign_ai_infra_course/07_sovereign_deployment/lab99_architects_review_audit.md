# Lab 99: The Architect's Review — Auditing the Entire Stack (4:21)

## Why it matters
Individual components can each be "correct" while the system as a whole is fragile, insecure, or non-compliant. An architect's review
checks the **whole stack end-to-end**: does a request, a dataset, and a model each flow through the controls we designed?

## In plain words
Think of a building inspection before people move in. The electrician says the wiring is fine and the plumber says the pipes are fine.
The inspector still walks through the whole building: do the fire exits actually lead outside, and does the alarm actually reach the
fire station? This lab is that walk-through for your AI platform.

## Architecture — the audit trace paths

```mermaid
flowchart LR
  subgraph Request["(1) Follow a REQUEST"]
    R1[User] --> R2[Gateway: auth, limits] --> R3[Router] --> R4[PII mask] --> R5[LLM pool] --> R6[Tools via MCP] --> R7[Audit log]
  end
  subgraph Data["(2) Follow a DATASET"]
    D1[Source] --> D2[Validate] --> D3[Mask] --> D4[Hash + manifest] --> D5[MinIO / Milvus] --> D6[Backup + residency]
  end
  subgraph Model["(3) Follow a MODEL"]
    M1[Training job] --> M2[Checkpoint] --> M3[Registry + eval] --> M4[Signed artifact] --> M5[Canary] --> M6[Production + monitoring]
  end
```

**How to read it:** Three swimlanes: follow one request, one dataset, and one model through every control. Each arrow needs a piece of evidence.

Pick one real request, one real dataset, and one real model, then trace each end to end. Every arrow must have **evidence**: a log, a hash, a policy report, or a dashboard.

## Core concepts — the review framework

| Pillar | Key questions | Evidence (labs) |
|---|---|---|
| **Reliability** | What is the SPOF? What happens if a GPU node, zone, region, or Kafka broker dies? Are RPO/RTO measured? | Failover drills (6, 49, 68, 69, 91) |
| **Performance** | Are TTFT/TPOT SLOs met at p95 under realistic load? Is the bottleneck known? | Load tests (10, 29, 42, 47, 80) |
| **Cost** | GPU utilization, cost per 1M tokens, idle GPUs, spot share | DCGM + OpenCost (26, 27, 28, 30) |
| **Security** | Zero trust, sandboxing, supply chain, secrets, BMC/hardware | Policies, signatures, red-team (2, 70, 77, 94, 98) |
| **Data governance** | PII masking recall, provenance, deletion propagation | Manifests, DLQ, erasure tests (63–66) |
| **Sovereignty** | Residency enforced at compute, storage, network, backup, failover? | Policy reports, probes (69, 70, 91, 97) |
| **Compliance** | AI Act tier per system, evidence bundles, human oversight | Registry + gates (44, 92) |
| **Operability** | Runbooks, on-call, upgrade paths, who owns what | RACI, runbooks (36, 98) |

**Scoring:** For each pillar, rate 0 = not addressed, 1 = designed, 2 = implemented, 3 = **tested and evidenced**. Only 3 counts in production.

## Architecture in depth

The architecture section shows the three audit trace paths. This view follows **one complete review** of the stack, from scoping
to remediation, which is how you run an audit as a process rather than a one-off read-through.

```mermaid
flowchart LR
  SCOPE["(1) Scope: systems, risks, regulations"] --> AUTO["(2) Automated checks<br/>policies, configs, SBOMs, residency, costs"]
  AUTO --> TRACE["(3) Trace paths<br/>request, dataset, model"]
  TRACE --> INT["(4) Interviews + runbook drills<br/>restore, failover, incident"]
  INT --> FIND["(5) Findings: severity × likelihood"]
  FIND --> PLAN["(6) Remediation plan<br/>owner, date, verification"]
  PLAN --> VERIFY["(7) Re-test fixes"]
  VERIFY --> CONT["(8) Turn checks into continuous controls"]
  CONT -.next review starts smaller.-> AUTO
```

### Follow one review from scope to lasting fix
1. **Scope.** Decide which systems, which risks (security, residency, reliability, cost), and which regulations are in scope.
2. **Automated checks.** Run the cheap, broad checks first: policy reports, unsigned images, missing limits, residency labels, idle GPUs.
3. **Trace paths.** Follow one request, one dataset, and one model end to end, looking for gaps between components.
4. **Drills.** Ask teams to *do* things: restore a backup, fail over a region, revoke a credential. Documents describe intentions, and drills show reality.
5. **Rate findings.** Rate each finding by severity and likelihood, with evidence.
6. **Plan.** Every finding gets an owner, a date, and a way to verify the fix.
7. **Verify.** Re-test the fix rather than accepting "done".
8. **Automate.** Each finding becomes a continuous check, so the next review starts from a higher baseline.

**The one idea to keep:** a good review ends with new automated controls, not just a report. Prefer drills and traces over reading documents.

## Minimal hands-on — automated audit checks

```bash
# Unsigned images running anywhere?
kubectl get pods -A -o jsonpath='{range .items[*]}{.spec.containers[*].image}{"\n"}{end}' | sort -u > images.txt
while read img; do cosign verify --key cosign.pub "$img" >/dev/null 2>&1 || echo "UNSIGNED $img"; done < images.txt

# Policy violations (Kyverno reports)
kubectl get policyreport -A -o json | jq '[.items[].results[] | select(.result=="fail")] | length'

# GPU pods without limits/priority, idle GPUs
kubectl get pods -A -o json | jq -r '.items[] | select(.spec.containers[].resources.limits["nvidia.com/gpu"] != null)
  | select(.spec.priorityClassName == null) | "\(.metadata.namespace)/\(.metadata.name) no priorityClass"'

# Residency: any eu-pii namespace pods on non-EU nodes?
kubectl get pods -A -l data-class=eu-pii -o wide | awk '{print $8}' | xargs -I{} kubectl get node {} -L topology.kubernetes.io/region
```

## Worked example — findings from a real-style review

**Scenario:** A review of an insurer's AI platform (4 clusters, 300 GPUs, 40 AI systems) **before** AI Act high-risk obligations apply.

| # | Finding | Severity | Fix |
|---|---|---|---|
| 1 | Velero backups succeed but **no restore tested in 9 months** | High | Monthly automated restore drill (Lab 68) |
| 2 | Envoy retries on timeouts for LLM routes, which **doubled load** during the last incident | High | Retry only on connect failure; retry budgets (Lab 49) |
| 3 | Kyverno `failurePolicy: Ignore`, so residency isn't enforced during webhook downtime | Critical | Fail closed + 3 replicas (Lab 70) |
| 4 | Ray dashboard exposed via LoadBalancer **without auth** | Critical | Remove; port-forward only (Lab 31) |
| 5 | 2 high-risk systems missing a human-oversight design doc | High | Evidence gate blocks deploys (Lab 92) |
| 6 | GPU utilization 34%, with 18 GPUs allocated to idle notebooks | Medium | Idle-GPU alert + culling + time-slicing pool (Labs 22, 27) |
| 7 | PII detector never evaluated on German text | High | Labeled DE test set; recall gate (Lab 65) |

The scorecard went from an average of 1.6 to 2.7 in 10 weeks. The review report itself became evidence for the regulator.

## Production deep dive
- **Make the review continuous:** Turn each check into a scheduled job or policy, so the "audit" becomes a dashboard.
- **Game days:** Quarterly chaos exercises (region loss, Kafka loss, compromised MCP server, poisoned dataset) with written outcomes.
- **Threat modeling:** STRIDE plus AI-specific threats (OWASP Top 10 for LLMs, MITRE ATLAS) on the architecture diagram, updated per major change.
- **Architecture Decision Records (ADRs):** Every big choice (vLLM vs. TRT-LLM, Milvus vs. Qdrant, federation model) is written down with its context, so future reviewers understand *why*.
- **Independent eyes:** Rotate reviewers across teams, and bring in external auditors for high-risk systems.

## FAANG deep-dive notes

- **How big tech does it:** Production readiness reviews (PRRs) and launch reviews use standard checklists across reliability, security, privacy, and cost, with continuous automated conformance afterwards.
- **Staff review questions:** Which pillar scores lowest, and what is the plan? Which checks are automated? When was the last game day?
- **Interview question:** *"You've joined as staff engineer on an AI platform. What do you review in your first 30 days?"* Strong answers trace critical paths end to end, check SLOs, DR drills, security boundaries, cost, and compliance, and prioritize findings by risk.

**Typical system-design prompt:** *"You're the new principal architect. Review the AI platform in 4 weeks and tell leadership the top risks."*

**1. Clarify first:**
- What leadership worries about: an incident, an audit, cost, or a launch?
- Access: can you run drills and read production configs?
- Who owns remediation after the review?

**2. Back-of-envelope sizing:**
- 4 weeks ≈ 1 week of scoping and automated checks, 1.5 weeks of traces and drills, 1 week of findings and plan, 0.5 week of presentation.
- Typical output: 30–60 findings, of which 5–10 are critical/high. Leadership needs the top 5 with cost and risk.
- Automated checks cover most of the breadth cheaply, which leaves human time for depth.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Method | document review | traces + drills | drills reveal reality |
| Coverage | everything shallow | breadth automated, depth on top risks | automate breadth |
| Findings | long list | prioritized by risk × cost to fix | top 5 for leadership |
| Outcome | report | owners + dates + continuous controls | controls outlive reports |
| Tone | blame | systemic causes | systemic, blameless |

**4. Follow-up questions with crisp answers:**
- *Why drills?* Untested backups, failovers, and runbooks fail far more often than documents suggest.
- *How do you prioritize?* Likelihood × impact, adjusted for cost to fix. Cheap, high-impact fixes go first.
- *What's a trace path?* Following one concrete object (a request, a dataset, a model) through every component to find gaps between teams.
- *What do reviews usually find?* Untested restores, overly broad permissions, missing residency on telemetry, idle GPUs, and unclear ownership.
- *How do you present to leadership?* Top risks in business terms (outage, fine, cost), each with a fix, owner, and date.
- *How do you avoid the report being ignored?* Agree on owners before presenting, and track remediation publicly.

**Debug this (common onsite question):** *"The last review found 40 issues; a year later, 30 are still open and two caused incidents."*
1. Findings had no owners or dates, only recommendations.
2. Many were phrased as general advice ("improve DR"), with no clear definition of done.
3. Nothing checked continuously whether problems came back.
4. Fix: specific findings with acceptance criteria, named owners and dates agreed with leadership, monthly tracking, and automated controls for each fixed finding (policy, test, alert).

The lesson: **a finding without an owner, a date, and a verification is just an opinion.**

**5. What separates senior from staff answers:**
- Senior: finds real issues through traces and checks.
- Staff: scopes the review to business risk, uses drills, prioritizes for leadership, drives remediation through owners, and converts findings into lasting automated controls.

**Red flags:** document-only reviews, unprioritized long lists, no owners, no re-testing, no continuous controls afterwards.

## Failure modes
- Checklist theater: boxes ticked from design docs, not from evidence.
- Reviews only at launch, with drift accumulating afterwards.
- Findings without owners and dates, so nothing changes.

## Checklist
- [ ] Request, dataset, and model each traced end-to-end with evidence
- [ ] Scorecard (0–3) across all 8 pillars
- [ ] Findings tracked with owner + due date, and checks automated
