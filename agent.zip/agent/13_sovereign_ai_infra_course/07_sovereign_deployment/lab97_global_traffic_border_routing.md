# Lab 97: Global Traffic Management and Border-Aware Routing (4:11)

## Why it matters
Classic global load balancing optimizes **latency and health**: send users to the nearest healthy region. Sovereign AI adds a
third, *hard* constraint: **jurisdiction**. A German user's prompt with health data must never be served by a US region,
even if Frankfurt is down and Virginia is 20 ms closer.

## In plain words
Normal routing is a GPS choosing the **fastest road**. Border-aware routing is a GPS that also knows **which roads your cargo is legally
allowed on**. It will take a longer road, or wait, before crossing a border it mustn't cross.

## Core concepts

| Layer | Mechanism | Decision basis |
|---|---|---|
| DNS (GSLB) | GeoDNS, latency-based DNS, health-checked records (Route53, NS1, PowerDNS + GeoIP) | Client IP location, health |
| Anycast | Same IP announced from many PoPs (BGP) | Network proximity |
| L7 global gateway | Envoy/edge proxy routes per request | **Identity, tenant, data class, headers**, health, load |
| Application | Home-region lookup per tenant | Contract / residency registry |

**Why DNS/Geo-IP alone isn't enough:** A user's *location* is not the data's *jurisdiction*. A French employee travelling in Singapore still
has EU-homed data. VPNs distort geolocation, and DNS caching ignores failover nuances.

**Border-aware routing = route by the data's home jurisdiction (from identity/tenant), constrained by an allow-list of regions, optimized for latency within it.**

```mermaid
flowchart LR
  U[User request + JWT] --> EDGE[Nearest edge PoP]
  EDGE --> POL{Lookup tenant home + data class}
  POL -->|EU, eu-pii| EUR[EU regions only: FRA → PAR → MIL failover]
  POL -->|US| USR[US regions]
  POL -->|global-public| ANY[Any healthy region, lowest latency]
  POL -->|EU region all down| DEG[Degraded mode: queue / read-only / clear error — NOT cross-border]
```

**How to read it:** Requests reach the nearest edge, the jurisdiction is looked up from identity, and the request is routed only within allowed regions. If all allowed regions are down, it enters degraded mode instead of crossing a border.

## Architecture in depth

The concepts diagram shows the routing decision by jurisdiction. This view follows **one request from DNS lookup to the serving
region**, and shows the layers where a border could be crossed by mistake.

```mermaid
flowchart LR
  U[User in Lyon] --> DNS["(1) GeoDNS / Anycast<br/>nearest PoP: Paris"]
  DNS --> EDGE["(2) Edge Envoy: TLS, verify JWT"]
  EDGE --> CLAIM{"(3) Verified claim: tenant home = EU,<br/>data class = eu-pii"}
  CLAIM --> SET["(4) Allowed set: FRA, PAR, MIL"]
  SET --> HEALTH{"(5) Healthy + capacity?"}
  HEALTH -->|"PAR ok"| PAR[Paris serving]
  HEALTH -->|"PAR down"| FRA[Frankfurt serving]
  HEALTH -->|"all EU down"| DEG["Degraded: queue / read-only / 503<br/>never a US region"]
  PAR --> LOG["(6) Log: region served + rule matched"]
  IP["IP geolocation"] -.used only for latency, never for residency.-> DNS
```

### Follow one request from Lyon
1. **DNS.** GeoDNS or Anycast sends the user to the nearest edge point of presence, Paris. That's a latency decision only.
2. **Authenticate.** The edge verifies the user's token. Residency must come from a verified identity claim, not from the IP address.
3. **Read the claim.** The token says the tenant's home is the EU and the data class is `eu-pii`.
4. **Allowed set.** Policy maps that claim to a set of permitted regions: Frankfurt, Paris, Milan.
5. **Health and capacity.** Among the allowed regions, the router picks the healthiest and closest. If Paris is down, Frankfurt serves.
6. **Degrade, don't cross.** If every allowed region is down, the request is queued, served read-only, or refused with a clear error. It never goes to the US.
7. **Log.** Each request records the region and the rule that chose it, as evidence for audits.

**The one idea to keep:** latency decides *which* allowed region, and identity decides *which regions are allowed*. Failover must never widen the allowed set.

## Minimal hands-on — Envoy routing by a verified claim

```yaml
# The JWT filter verifies the token and copies claims into headers (claim_to_headers)
http_filters:
- name: envoy.filters.http.jwt_authn
  typed_config:
    providers:
      corp:
        issuer: https://id.corp.example
        remote_jwks: { http_uri: { uri: https://id.corp.example/jwks, cluster: idp, timeout: 2s } }
        claim_to_headers: [{ header_name: x-data-home, claim_name: data_home }]
    rules: [{ match: { prefix: / }, requires: { provider_name: corp } }]
route_config:
  virtual_hosts:
  - name: ai
    domains: ["ai.corp.example"]
    routes:
    - match: { prefix: /, headers: [{ name: x-data-home, string_match: { exact: eu } }] }
      route: { cluster: llm_eu }          # cluster has only EU endpoints, with locality priority FRA>PAR>MIL
    - match: { prefix: /, headers: [{ name: x-data-home, string_match: { exact: us } }] }
      route: { cluster: llm_us }
    - match: { prefix: / }
      direct_response: { status: 403, body: { inline_string: "unknown data jurisdiction" } }   # fail closed
```

Strip any client-supplied `x-data-home` header before the JWT filter runs, so users can't spoof their jurisdiction.

## Worked example

**Scenario:** A global HR-tech SaaS. Tenants are contractually homed in the EU, US, or India (DPDP Act). There are 9 regions, and each jurisdiction has 2–3.

| Incident | Naive GeoDNS | Border-aware |
|---|---|---|
| Frankfurt outage | EU users routed to the nearest healthy region, sometimes US-East (residency breach) | EU traffic to Paris/Milan only. p95 latency +18 ms |
| All EU regions degraded (simulated) | Routed to US | **Degraded mode**: chat queued with an ETA, read-only HR data from EU cache, status message. No cross-border processing |
| EU employee travelling in India | Served from Mumbai (breach) | Served from EU (identity-based). +140 ms acceptable |

Contract compliance was verified by synthetic probes from 30 countries every 5 minutes, with assertions on which region served each jurisdiction
(response header `x-served-region`).

## Production deep dive
- **Residency registry:** Tenant → home jurisdiction → allowed regions, as a single source of truth used by the gateway, Karmada (Lab 91), Kafka mirroring (Lab 69), and backups (Lab 68).
- **Capacity per jurisdiction:** Failover stays inside the border, so each jurisdiction needs N+1 capacity *on its own*. That is the real cost of sovereignty. Plan it explicitly.
- **Edge processing:** TLS termination at a foreign PoP may itself count as processing. Some regulated tenants need termination inside the jurisdiction (regional anycast or direct regional endpoints).
- **Observability:** Every request logs `data_home`, `served_region`, and `route_reason`. Alert on any mismatch, which should be zero.
- **Hybrid with external LLM APIs:** The gateway only allows external providers whose processing region matches (e.g. an EU-region endpoint) and only after masking (Lab 65).

## FAANG deep-dive notes

- **How big tech does it:** Global traffic layers combine latency, health, and policy constraints, and residency-bound customers get region-pinned endpoints with in-region failover.
- **Staff review questions:** Is routing derived from verified identity? What is the in-jurisdiction N+1 capacity? How is residency verified continuously?
- **Interview question:** *"Design global routing for a SaaS with EU, US, and India data residency."* Strong answers cover home-region lookup, constrained failover, degraded mode, capacity per jurisdiction, and synthetic probes.

**Typical system-design prompt:** *"Design global routing for an AI assistant used in 40 countries, with residency rules and 99.95% availability."*

**1. Clarify first:**
- Which data classes have residency rules, and which countries/blocs?
- What should users experience when their only allowed region is down?
- Do anonymous or public requests exist (no residency constraint)?

**2. Back-of-envelope sizing:**
- 99.95% availability allows ~22 minutes of downtime per month. A single-region jurisdiction can't reach this alone, so plan ≥ 2 regions per jurisdiction where possible.
- Latency: in-jurisdiction failover (Paris → Frankfurt) adds ~10 ms RTT, acceptable. Cross-continent (EU → US) would add ~80 ms, and it's forbidden anyway.
- Edge capacity: N PoPs with health checks every 5 s, and failover decisions in < 30 s.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Residency signal | IP geolocation | verified identity claim | identity; IP only for latency |
| Failover scope | any healthy region | within allowed set only | within allowed set only |
| Outage behaviour | silent cross-border | explicit degraded mode | degrade explicitly |
| Policy location | app code | edge + gateway policy | central, versioned policy |
| Single-region countries | accept lower SLA | in-country second site | second site, or an explicit SLA exception |

**4. Follow-up questions with crisp answers:**
- *Why not IP geolocation?* VPNs, travel, and roaming make it unreliable. A French user in New York still has EU data.
- *What if a token has no residency claim?* Fail closed: route to the most restrictive set, or reject.
- *How is residency logged?* Region served, rule matched, and claim values, for every request.
- *How do you test it?* Synthetic requests per jurisdiction, plus chaos tests that take regions down and verify no cross-border routing.
- *What about caches and CDNs?* They must respect the same rules. Don't cache personal responses at foreign PoPs.
- *How fast should failover be?* Seconds to tens of seconds, using health checks and connection draining.

**Debug this (common onsite question):** *"During an EU regional outage, monitoring shows some EU tenants' requests served from Virginia."*
1. The edge routing policy correctly restricted EU claims to EU regions.
2. But the AI gateway behind it had its own "fallback model provider" config, which sends to a US-hosted API when all local models fail.
3. That fallback was added for availability and never reviewed for residency.
4. Fix: residency policy enforced at *every* routing layer (edge, gateway, model fallback), allowed-region checks in gateway fallback logic, and chaos tests covering whole-jurisdiction outages.

The lesson: **every fallback is a routing decision. Each one must respect the same border rules.**

**5. What separates senior from staff answers:**
- Senior: implements claim-based routing with in-jurisdiction failover and degraded mode.
- Staff: designs residency enforcement across all routing layers and fallbacks, availability architecture per jurisdiction, explicit outage UX, and continuous compliance testing.

**Red flags:** IP-based residency, any-region failover, unreviewed fallback providers, no per-request region logging.

## Failure modes
- Failover config written for availability only (any healthy region) causes a silent legal breach during an outage.
- Trusting client-sent region headers lets attackers or misconfigured clients pick regions.
- No degraded-mode UX, so the strict policy is perceived as an outage and someone "temporarily" disables it.

## Checklist
- [ ] Routing derived from verified identity claims, failing closed
- [ ] In-jurisdiction failover order + capacity plan
- [ ] Synthetic residency probes with assertions
