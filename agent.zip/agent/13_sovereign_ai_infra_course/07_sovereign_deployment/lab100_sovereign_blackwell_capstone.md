# Lab 100: The Sovereign Blackwell Architecture Capstone (16:04)

## Why it matters
This capstone combines everything into one design: a **national-scale, sovereign AI platform** on NVIDIA Blackwell (GB200 NVL72) plus a
vendor-diverse inference tier. It trains its own models, serves millions of citizens and enterprises, keeps data in its jurisdiction,
and proves compliance.

## In plain words
Imagine a country building its own "AI power plant". It needs **generators** (GPUs), a **grid** (networks), **fuel storage** (data),
**substations** (inference clusters near users), **safety rules** (policies and law), and **inspectors** (audit). Every lab you did built one of these parts.
Here you connect them into one working plant.

## The brief

> **Client:** A European national AI agency.
> **Mission:** Train and serve sovereign foundation models (national languages, public-sector knowledge) for government and regulated industry.
>
> | Requirement | Target |
> |---|---|
> | Training | Pre-train a ~70B dense or ~400B MoE model in < 90 days; continuous fine-tuning |
> | Inference | 20M requests/day peak national load; TTFT p95 < 600 ms; 99.9% availability |
> | Data | Citizens' data never leaves national jurisdiction; GDPR + AI Act |
> | Security | Some ministries require an air-gapped enclave |
> | Independence | No single foreign provider can switch the service off |
> | Budget | Capex-heavy; target > 60% average GPU utilization |

## Architecture

```mermaid
flowchart TB
  subgraph Users["Users"]
    CIT[Citizens apps] & GOV[Ministries] & ENT[Regulated enterprises]
  end

  subgraph Edge["National edge (Lab 97)"]
    DNS[GeoDNS/Anycast<br/>national PoPs] --> GW[Envoy AI Gateway<br/>OIDC eID, token limits, PII mask]
  end

  subgraph SiteA["Site A — Training campus (liquid-cooled)"]
    NVL[8× GB200 NVL72 racks<br/>576 Blackwell GPUs]
    IB[Quantum-X800 IB / Spectrum-X<br/>rail-optimized]
    LUS[(Parallel FS + MinIO hot tier)]
    TR[Kueue + JobSet + Megatron/NeMo<br/>async ckpt]
    NVL --- IB --- LUS
    TR --> NVL
  end

  subgraph SiteB["Site B — Inference region 1"]
    INF1[vLLM / TRT-LLM pools<br/>B200 + MI325X]
    MIL1[(Milvus + Kafka)]
  end
  subgraph SiteC["Site C — Inference region 2"]
    INF2[vLLM / TRT-LLM pools<br/>B200 + H200]
    MIL2[(Milvus + Kafka)]
  end
  subgraph Enclave["Air-gapped enclave (Lab 94)"]
    AG[RKE2 + H100<br/>signed bundles only]
  end

  subgraph Gov["Governance plane"]
    KAR[Karmada federation]
    KYV[Kyverno residency + signatures]
    MLF[MLflow registry + provenance]
    ACT[AI Act registry + evidence gates]
    OBS[Prometheus/Grafana/Loki/OTel]
  end

  Users --> DNS
  GW --> INF1 & INF2
  INF1 <-->|MM2 global topics only| INF2
  TR -->|signed models| MLF --> INF1 & INF2
  MLF -.->|offline bundle| AG
  KAR -.-> SiteA & SiteB & SiteC
  KYV -.-> SiteA & SiteB & SiteC
```

**How to read it:** Users enter through the national edge, which routes to two inference regions. The training campus produces signed models via the registry. Governance spans every site, and the enclave receives only offline bundles.

## Architecture in depth

The architecture shows all the sites and planes. This view zooms into the **GB200 NVL72 rack**, the building block of the training
campus, and shows why the rack, not the server, is the unit of design.

```mermaid
flowchart TB
  subgraph Rack["One GB200 NVL72 rack (~120-130 kW, liquid-cooled)"]
    subgraph Trays["18 compute trays"]
      CT["Each tray: 2 Grace CPUs + 4 Blackwell GPUs"]
    end
    subgraph Switch["9 NVLink switch trays"]
      NVS["NVLink 5 switches: 72 GPUs in one NVLink domain<br/>~1.8 TB/s per GPU"]
    end
    CT <--> NVS
  end
  Rack -->|"ConnectX-8 / BlueField, 800 Gb/s per GPU"| FAB["Scale-out fabric: Quantum-X800 IB / Spectrum-X<br/>rail-optimized across racks"]
  FAB --> OTHER["Other NVL72 racks (8 total = 576 GPUs)"]
  FAB --> STOR[(Storage: parallel FS + MinIO hot tier)]
  CDU["Coolant distribution unit"] -.liquid loop.-> Rack
  PWR["Power: redundant feeds, ~1 MW for 8 racks"] -.-> Rack
```

### Follow one training step through the hardware
1. **Inside a GPU.** Each Blackwell GPU computes its part of the model in FP8 or FP4.
2. **Inside the rack.** Tensor and expert parallelism traffic (Lab 40), the chattiest kind, stays inside the 72-GPU NVLink domain at ~1.8 TB/s per GPU, about 18× faster than the scale-out network.
3. **Bigger parallel groups.** With 72 GPUs on NVLink, TP and expert parallelism can span far more GPUs than on 8-GPU servers, which is why the rack is the design unit.
4. **Across racks.** Pipeline and data-parallel traffic crosses the rail-optimized fabric at 800 Gb/s per GPU (Lab 35).
5. **Checkpoints.** Asynchronous checkpoints stream to the storage tier (Lab 39).
6. **Facilities.** Each rack draws roughly 120–130 kW and needs liquid cooling. Power and cooling, not GPUs, often set the delivery date.
7. **Failure domain.** A rack or coolant fault affects 72 GPUs at once, so the scheduler, checkpoints, and spares must plan at rack granularity.

**The one idea to keep:** on Blackwell-class systems, design parallelism, failure handling, and facilities around the 72-GPU NVLink rack, not the individual server.

## Design decisions (with reasoning)

### 1. Why GB200 NVL72 for training
- **In plain words:** NVL72 connects 72 GPUs so tightly (NVLink 5, ~1.8 TB/s per GPU) that they behave almost like *one giant GPU*.
- **Impact:** Tensor/expert parallelism can span 72 GPUs instead of 8 (Lab 40 rule: TP ≤ the NVLink domain). MoE all-to-all stays inside the rack, so less traffic hits InfiniBand.
- **Precision:** FP8 training and FP4 (NVFP4) inference roughly double throughput vs. Hopper at the same precision class.
- **Facility:** ~120+ kW per rack, **liquid cooling mandatory**. Site selection is driven by power and cooling, not by floor space.

### 2. Training sizing (back-of-envelope)
```
Model: 70B dense, 15T tokens
FLOPs ≈ 6 × 70e9 × 15e12 ≈ 6.3e24
576 GPUs × ~2.2 PFLOPS (dense BF16-class, approx) × 40% MFU ≈ 5.1e17 FLOP/s
Time ≈ 6.3e24 / 5.1e17 ≈ 1.2e7 s ≈ 143 days  ✗ (> 90 days)

Options:  FP8 training (~1.6–2× effective) → ~75–90 days ✓
          or MoE ~400B total / ~40B active → similar quality at fewer active FLOPs ✓
```
Decision: **FP8 dense 70B** first (lower risk), and a MoE in year 2 when the team has ops experience. Plan for ~1 interruption every few
hours at this scale, so async checkpoints run every 15–20 min (Lab 39).

### 3. Inference sizing
```
20M req/day, 5× peak/avg factor → ~1,160 req/s peak
Avg 1.5k input + 400 output tokens; prefix cache hit ~50% (shared system prompts, Lab 47)
Router split (Lab 46): 65% → 8B, 25% → 70B, 10% → specialized (code, legal)
Per-GPU capacity (FP8/FP4, measured in pilot): 8B ≈ 60 req/s; 70B ≈ 12 req/s on B200
GPUs: 8B: 754/60 ≈ 13 → 70B: 290/12 ≈ 25 → spec: ~10   ≈ 48 GPUs per region at peak
N+1 per jurisdiction region pair + 30% headroom → ~64 GPUs per region × 2 regions
```
Vendor diversity: one region mixes **AMD MI325X** for the 70B tier (256 GB memory fits the model on fewer GPUs, Lab 24). Both vendors run vLLM, so the serving templates stay the same.

### 4. Data & sovereignty layers
| Concern | Design | Labs |
|---|---|---|
| Ingestion | Kafka per region, Pydantic contracts, PII tokenization before embedding | 63, 64, 65 |
| Vectors | Milvus per region, tenant partition keys, 2 replicas | 61, 62 |
| Storage | MinIO HA with Object Lock; site replication **within the country only** | 67 |
| Provenance | Merkle manifests for every training shard; signed training attestations | 66 |
| DR | Native vector backups + Kafka replay; monthly restore drills | 68 |
| Residency | Kyverno + egress policies + border-aware routing; jurisdiction labels on every cluster | 70, 91, 97 |

### 5. Agents & public-sector apps
- MCP servers for government registries (read-only, RLS by citizen consent, Lab 72), sandboxed code-exec (Lab 77), token budgets per ministry (Lab 79).
- Human oversight for decisions affecting citizens (**high-risk** under the AI Act). Approvals are UI events, not model text (Lab 73).

### 6. Governance & operations
- AI Act registry: every system classified, with evidence bundles gating deploys (Lab 92).
- Gaia-X credentials for partner data spaces (universities, hospitals, Lab 93); federated fine-tuning with hospitals (Lab 96).
- Hardware lifecycle: burn-in of every NVL72 rack, 2% spares, automated cordon, NIST 800-88 sanitization (Lab 98).
- Continuous architect's review scorecard (Lab 99).

## Risk register (top 5)

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| GPU delivery delays (6–12 months) | High | High | Phased plan; start on H200/MI300X; contract penalties |
| Liquid-cooling/facility readiness | Medium | High | Facility work starts before procurement; vendor-certified integrator |
| Training instability at scale | Medium | High | BF16 baseline run, FP8 convergence checks, auto-rollback |
| Talent shortage (IB/NCCL/ops) | High | Medium | Vendor residency engineers + training programme (this course!) |
| Regulatory change | Medium | Medium | Compliance-as-code allows fast control updates |

## Capstone deliverables (what you submit)

1. **One-page architecture diagram** (adapt the above to your scenario).
2. **Sizing sheet:** training FLOPs/time, inference GPUs per tier, storage PB, network.
3. **10 ADRs:** e.g. "TRT-LLM for the 8B tier, vLLM for the rest", "Karmada over OCM", "MinIO over Ceph RGW".
4. **Policy pack:** Kyverno residency + image signature + GPU quota policies.
5. **Runbooks:** region failover, GPU failure, restore drill, model rollback, air-gap import.
6. **Compliance map:** AI Act tier per system → controls → evidence source.
7. **Cost model:** capex/opex, $/1M tokens, utilization targets, 3-year TCO vs. API-only.

## Worked example — TCO snapshot (illustrative)

| Item | 3-year cost (approx.) |
|---|---|
| 576 Blackwell GPUs (8 NVL72 racks) + networking + storage | €250–320M |
| 128 inference GPUs across 2 regions | €45–60M |
| Facility (power, liquid cooling), 3 yrs energy | €40–70M |
| Staff (~60 FTE platform/ML/SRE/GRC) | €30–40M |
| **Total** | **~€365–490M** |
| API-only alternative at national volume | Comparable or higher, **with no sovereignty, no model ownership, and foreign kill-switch risk** |

The sovereignty value (independence, compliance, local industry capability) is the strategic justification. The TCO shows it isn't
financially irrational at national scale.

## FAANG deep-dive notes

- **How big tech does it:** Frontier AI infrastructure is co-designed across power, cooling, network fabric, scheduler, and model architecture. Capacity is planned years ahead, and every layer has a dedicated owning team.
- **Staff review questions:** Which assumption, if wrong, breaks the plan (delivery dates, MFU, traffic forecast)? Where are the single points of failure? What is the 3-year TCO vs. alternatives?
- **Interview question:** *"Design a sovereign AI platform for a country."* Strong answers cover requirements, sizing math for training and inference, the network and NVLink domain, data residency at every layer, governance, risks, phased delivery, and TCO.

**Typical system-design prompt:** *"Design a sovereign national AI platform: pre-train a 400B MoE model in 90 days and serve 20 million requests a day."*

**1. Clarify first:**
- Model choice and token budget (e.g. 400B MoE with ~40B active, 15T tokens).
- Inference SLOs, peak-to-average ratio, and which users need the air-gapped enclave.
- Budget split between capex and opex, facility power available, and delivery dates for hardware.

**2. Back-of-envelope sizing:**
- Training FLOPs ≈ 6 × active params × tokens = 6 × 40B × 15T = 3.6 × 10²⁴ FLOPs.
- 576 Blackwell GPUs at ~2.5 PFLOPS dense FP8 each × 40% MFU ≈ 576 PFLOPS effective → 3.6 × 10²⁴ ÷ 5.76 × 10¹⁷ ≈ 6.25M seconds ≈ 72 days. That fits 90 days with ~20% margin for failures and restarts.
- Inference: 20M requests/day × 1,500 tokens ≈ 30B tokens/day. At a 3× peak-to-average ratio, that's ~1M tokens/s at peak. At ~5–10k tokens/s per GPU (MoE, FP8, batched), that's 100–200 GPUs across two regions, plus N+1 headroom.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Model | dense 70B | MoE 400B (40B active) | MoE for quality per FLOP; dense for simpler serving |
| Training hardware | HGX 8-GPU servers | NVL72 racks | NVL72 for MoE and large TP/EP |
| Fabric | InfiniBand | Spectrum-X Ethernet | by team skills and sovereignty and vendor constraints |
| Inference fleet | single vendor | multi-vendor (NVIDIA + AMD) | multi-vendor for independence, if the team can support it |
| Delivery | big bang | phased (pilot rack → full campus) | phased, with go/no-go gates |

**4. Follow-up questions with crisp answers:**
- *Why does NVL72 matter for MoE?* Expert parallelism uses all-to-all traffic, which needs the NVLink domain's bandwidth.
- *What's the biggest schedule risk?* Facilities (power, liquid cooling) and hardware delivery, not software.
- *How do you reach 40% MFU?* Balanced parallel layout, FP8, overlapping communication, healthy fabric, and fast checkpoints, all validated on a pilot rack.
- *How is sovereignty ensured end to end?* National sites, own keys, residency enforced at four layers (compute, storage, network, routing), signed supply chain, and multi-vendor options.
- *What if MFU is only 30%?* The run takes ~96 days. Decide upfront: more tokens later, a smaller token budget, or more GPUs.
- *How do you justify cost?* TCO over 3–5 years against API costs at national volume, plus the strategic value of independence.

**Debug this (common onsite question):** *"Two weeks into the run, effective throughput is 30% below plan, though MFU during steps looks fine."*
1. Goodput analysis: steps run at the planned MFU, but 30% of wall time is lost to restarts.
2. A coolant issue in one rack triggers thermal shutdowns several times a day, and each takes down the whole job.
3. Checkpoints are every 2 hours and restart takes 25 minutes, so each failure costs ~1.5 hours on average.
4. Fix: repair the cooling loop, move the checkpoint interval to the Young/Daly optimum (Lab 39), add hot-spare racks so jobs restart without waiting for repairs, and track goodput as the primary run metric.

The lesson: **at this scale, goodput (time doing useful work) matters more than peak MFU. Facilities are part of the training stack.**

**5. What separates senior from staff answers:**
- Senior: produces correct sizing math and a coherent architecture across training, serving, data, and governance.
- Staff: plans phased delivery with go/no-go gates, identifies the assumptions that break the plan (MFU, delivery dates, traffic), designs for rack-level failure and goodput, and makes the sovereignty and TCO case to decision makers.

**Red flags:** sizing by GPU count without FLOP math, ignoring power and cooling, no goodput plan, single points of failure, sovereignty claimed but not enforced at every layer.

## Checklist
- [ ] Architecture diagram covering compute, network, data, serving, agents, and governance
- [ ] Training + inference sizing with formulas shown
- [ ] Residency enforced at 4 layers (compute, storage, network, routing)
- [ ] ADRs, runbooks, policy pack, compliance map, cost model
