# Lab 94: The Air-Gapped Architecture — Offline Model Serving (4:08)

## Why it matters
Defense, intelligence, critical infrastructure, some healthcare, and finance environments run **with no internet connection at all**.
Everything you normally `pull` (container images, Helm charts, model weights, Python packages, OS updates, CVE databases, license checks)
must be brought in deliberately, verified, and served locally.

## In plain words
An air-gapped cluster is a **submarine**. Once it dives, nothing comes in from outside. Everything it needs (images, models, packages, certificates)
must be **packed, inspected, and sealed** before boarding, and resupply happens only through a controlled hatch.

## Core concepts

```mermaid
flowchart LR
  subgraph Low["Connected side (low)"]
    SRC[Upstream: registries, HF, PyPI] --> BUILD[Bundle builder<br/>mirror + scan + sign]
  end
  BUILD -->|one-way transfer<br/>data diode / approved media| IMPORT
  subgraph High["Air-gapped side (high)"]
    IMPORT[Import station<br/>verify signatures + hashes + rescan] --> HARBOR[(Harbor registry)]
    IMPORT --> MODELS[(MinIO model store)]
    IMPORT --> PKG[(Package mirror: PyPI/apt)]
    HARBOR --> K8S[RKE2/K3s cluster]
    MODELS --> K8S
  end
```

**How to read it:** Everything is gathered, scanned, and signed on the connected side. It crosses one way to the high side, where it is verified again and loaded into local registries and stores that the cluster pulls from.

| Must work offline | Solution |
|---|---|
| Container images | Harbor/Zot registry. Mirror via `skopeo`/`oras`/Hauler. Rewrite registries via `registries.yaml` / OverridePolicy |
| Helm charts & manifests | OCI charts in Harbor; GitOps from an internal Git server (Gitea) |
| Model weights | OCI artifacts or MinIO with manifests + signatures (Lab 66) |
| Python/OS packages | devpi/Nexus/Artifactory mirror, local apt/yum repos |
| K8s itself | RKE2/K3s air-gap tarballs; Talos/immutable OS images |
| GPU drivers/operators | Precompiled driver images (Lab 21), operator images mirrored |
| Time (TLS, tokens, logs) | Internal NTP (GPS/PTP-backed) |
| PKI | Internal CA (cert-manager + Vault/HSM) |
| CVE scanning | Offline Trivy DB bundles imported regularly |
| Licenses | Offline license files; avoid software that phones home |

**The bundle is the unit of change.** Each release becomes a versioned, signed bundle (images + charts + models + SBOM + attestations).

## Architecture in depth

The concepts diagram shows the low side, the one-way transfer, and the high side. This view follows **one model update bundle**
through every verification step, because in an air gap, each step is the only chance to catch a problem.

```mermaid
sequenceDiagram
  participant B as Bundle builder (low side)
  participant S as Scanner + signer
  participant D as Data diode / approved media
  participant I as Import station (high side)
  participant H as Harbor + MinIO
  participant K as Cluster (Kyverno)
  B->>B: pull images, model weights, charts (Hauler)
  B->>S: SBOM + CVE scan + malware scan
  S->>S: sign bundle (cosign), write manifest with hashes
  S->>D: one-way transfer
  D->>I: bundle arrives
  I->>I: verify signature + every hash + rescan
  I->>H: push images to Harbor, weights to MinIO
  K->>H: pod pulls image
  K->>K: admission verifies signature against enclave trust root
  K-->>K: run only if signed + listed in manifest
```

### Follow one model update into the enclave
1. **Collect.** On the connected side, a tool such as Hauler gathers the exact images, Helm charts, and model weights needed, pinned by digest.
2. **Scan.** Everything is scanned for CVEs and malware, and an SBOM is generated.
3. **Sign.** The bundle and its manifest of hashes are signed with a key the enclave trusts.
4. **One-way transfer.** A data diode or an approved media process moves the bundle in. Nothing can flow back out.
5. **Verify again.** The import station checks the signature, recomputes every hash, and rescans with its own offline databases. It trusts nothing from the low side.
6. **Load.** Images go into Harbor and weights into MinIO, inside the enclave.
7. **Enforce at run time.** Kyverno admits only images signed by the enclave's trust root and listed in an approved manifest.

**The one idea to keep:** an air gap is only as strong as its import process. Verify on both sides, sign everything, and run only what was signed.

## Minimal hands-on

```bash
# Connected side: collect + sign
hauler store sync -f bundle-2026.11.yaml          # images, charts, files (model weights)
hauler store save --filename ai-bundle-2026.11.tar.zst
cosign sign-blob --key hsm://bundle-key ai-bundle-2026.11.tar.zst > bundle.sig
sha256sum ai-bundle-2026.11.tar.zst > bundle.sha256

# Air-gapped side: verify + load
cosign verify-blob --key bundle.pub --signature bundle.sig ai-bundle-2026.11.tar.zst
hauler store load ai-bundle-2026.11.tar.zst && hauler store copy registry://harbor.high.local
```

```yaml
# /etc/rancher/rke2/registries.yaml — all pulls go to the local mirror
mirrors:
  "*": { endpoint: ["https://harbor.high.local"] }
```

vLLM offline: `HF_HUB_OFFLINE=1`, `TRANSFORMERS_OFFLINE=1`, and `--model /models/<name>` from local storage.

## Worked example

**Scenario:** A defense ministry wants an intelligence-analysis assistant (RAG over classified reports) on a **classified network**.
Hardware: 4 nodes × 8 H100, isolated.

| Layer | Choice |
|---|---|
| OS / K8s | Hardened RHEL + RKE2 (FIPS, CIS profile) |
| Registry | Harbor with cosign verification + Kyverno `verifyImages` (Lab 70) |
| Models | Llama-3.1-70B FP8 + embedding + reranker, imported as a signed OCI artifact; eval report attached |
| RAG | Milvus + MinIO on-cluster (Labs 62, 67) |
| Updates | Monthly bundle: patches, CVE DB, model updates. Two-person approval for import |
| Monitoring | Prometheus/Grafana/Loki in-cluster; no SaaS |
| Users | Smart-card authentication → Keycloak → AI gateway |

The first import took 2 weeks (dependency discovery). After automation, monthly bundles take ~1 day end-to-end. The ~600 GB monthly bundle is mostly model weights.

## Production deep dive
- **Dependency discovery:** Run the full stack in a **simulated air-gap** (egress deny-all) on the connected side first. Anything that fails is a missing dependency.
- **Supply-chain integrity:** SBOMs and signatures verified at import *and* at admission. Keep the import station separate from the cluster.
- **Cross-domain solutions:** Moving data *out* (e.g. aggregated metrics) needs approved guards/diodes. Usually only up-flow is allowed.
- **Operational readiness:** On-site runbooks, offline documentation (a docs mirror), spare parts (Lab 98), and staff trained to operate without internet search.
- **Model updates:** New model versions go through the same eval gates as connected environments (Lab 50), run offline with stored eval sets.

## FAANG deep-dive notes

- **How big tech does it:** Disconnected or sovereign regions run fully mirrored dependency chains with signed release bundles, separate operations teams, and simulated air-gap testing before shipping.
- **Staff review questions:** Was the stack tested with egress fully denied? How are bundles signed and verified? How old is the CVE database?
- **Interview question:** *"Deploy an LLM platform in a classified network."* Strong answers cover dependency discovery, mirrors, signed bundles, internal PKI and NTP, offline models, update cadence, and operations without the internet.

**Typical system-design prompt:** *"Deliver an LLM assistant into a classified, air-gapped ministry network and keep it updated monthly."*

**1. Clarify first:**
- Transfer mechanism and approval process (diode, media, frequency, size limits).
- Hardware inside: GPU types and count, storage.
- Accreditation requirements for software entering the enclave.

**2. Back-of-envelope sizing:**
- Monthly bundle: 70B model in FP8 (~70 GB) + images (~30 GB) + charts and packages (~5 GB) ≈ 105 GB.
- A data diode at 1 Gb/s moves this in ~15 minutes. Media transfer with approvals typically takes days, which is the real constraint.
- Inside: 8 × H100 serves ~100–300 concurrent users for a 70B model, typical for a ministry.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Kubernetes | upstream with many deps | RKE2 / K3s with air-gap bundles | distributions designed for air gaps |
| Transfer | ad hoc media | automated bundles + diode | reproducible, signed bundles |
| Update cadence | as needed | fixed release train (monthly) | release train plus emergency path |
| Trust | low-side verification only | verify on both sides | double verification |
| Dependencies | pull at run time | everything pre-mirrored | zero runtime internet assumptions |

**4. Follow-up questions with crisp answers:**
- *What breaks first in air gaps?* Hidden internet dependencies: a model download at start-up, a Helm chart pulling images by tag, a pip install.
- *Why pin by digest?* Tags can change. Digests guarantee the exact bytes that were scanned and signed.
- *How do you handle CVEs between releases?* An emergency bundle path with the same verification, and a smaller scope.
- *How do you get telemetry out?* Usually you can't. Plan local observability and manual export of approved reports.
- *How do you test before transfer?* A staging enclave replica on the low side with the network physically disabled.
- *What about model provenance?* Bundle manifests include model hashes and attestations (Lab 66), verified on import.

**Debug this (common onsite question):** *"After the monthly import, the vLLM pods crash-loop inside the enclave, though staging was fine."*
1. Logs: the tokenizer tries to download a file from Hugging Face at start-up.
2. Staging had a cached copy in the image layer from an earlier build, while the new image was rebuilt cleanly.
3. The bundle contained the weights but not the tokenizer config files.
4. Fix: set `HF_HUB_OFFLINE=1` everywhere, include complete model directories in the manifest with a completeness check, and test bundles in a network-disabled staging environment built from scratch.

The lesson: **test air-gap bundles from a clean, offline environment. Caches hide missing dependencies.**

**5. What separates senior from staff answers:**
- Senior: builds signed bundles, mirrors registries, enforces signatures on the high side.
- Staff: designs the release train and emergency path, double verification, accreditation-friendly processes, offline observability, and clean-room testing.

**Red flags:** runtime internet assumptions, tags instead of digests, verification on one side only, no clean offline staging.

## Failure modes
- Hidden network calls (telemetry, license checks, `pip install` at container start, HF tokenizer downloads) crash pods in the air-gap.
- Expired certificates with no internal CA automation produce cluster-wide outages months later.
- Stale CVE databases give false confidence. Track bundle age as a metric.

## Checklist
- [ ] Full stack runs under an egress deny-all simulation
- [ ] Signed bundle build/verify/load pipeline
- [ ] Internal registry mirror + offline model loading
