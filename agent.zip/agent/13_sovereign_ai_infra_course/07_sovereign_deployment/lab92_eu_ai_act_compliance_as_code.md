# Lab 92: Compliance-as-Code — Automating EU AI Act Risk Tiering (4:07)

## Why it matters
The EU AI Act applies obligations by **risk tier**, with penalties of up to 7% of global turnover for prohibited practices. Enterprises
run hundreds of AI use cases. Manual spreadsheets go stale the day they're written. **Compliance-as-code** classifies each AI system,
attaches the required controls, and blocks deployment when evidence is missing.

> This lab is engineering guidance, not legal advice. Your legal/GRC team owns interpretation.

## In plain words
The AI Act is like **building codes**: a garden shed (spam filter) needs nothing special, but a hospital (credit scoring, hiring) needs
fire exits, inspections, and paperwork. Compliance-as-code is the building inspector built into your pipeline, so no "hospital" gets built without its fire exits.

## Core concepts — risk tiers (simplified)

| Tier | Examples | Key obligations |
|---|---|---|
| **Prohibited** (Art. 5) | Social scoring, manipulative techniques, untargeted facial scraping, emotion recognition at work/school (with exceptions) | Must not be deployed |
| **High-risk** (Art. 6, Annex III) | Credit scoring, hiring/HR decisions, critical infrastructure, education access, essential services, some biometrics | Risk management, data governance, technical docs, logging, human oversight, accuracy/robustness/cybersecurity, conformity assessment, registration, post-market monitoring |
| **Limited / transparency** (Art. 50) | Chatbots, AI-generated content, deepfakes | Disclose AI interaction, label synthetic content |
| **Minimal** | Spam filters, internal code assistants (typically) | Voluntary codes |
| **GPAI models** (Art. 51–55) | Foundation models | Technical docs, copyright policy, training-data summary; systemic-risk models: evals, incident reporting, cybersecurity |

Obligations phase in over 2025–2027. Track the dates for your categories.

## Architecture

```mermaid
flowchart LR
  REG[AI system registry entry<br/>ai-system.yaml in Git] --> CLS[Classifier rules<br/>OPA/Rego or Python]
  CLS --> TIER[Risk tier + required controls]
  TIER --> EVID[Evidence collector<br/>model card, evals, logs, DPIA, oversight design]
  EVID --> GATE{CI/CD + admission gate}
  GATE -->|complete| DEPLOY[Deploy]
  GATE -->|missing| BLOCK[Block + ticket to owner]
  DEPLOY --> MON[Post-market monitoring<br/>drift, incidents]
```

**How to read it:** A system manifest in Git is classified by rules into a risk tier with required controls. The evidence collector checks those controls, and the CI and admission gate deploys or blocks. Monitoring continues after deploy.

## Architecture in depth

The architecture diagram shows registry, classification, evidence, and gate. This view follows **one AI system from registration to
deployment** and shows which evidence each risk tier requires.

```mermaid
flowchart TB
  MAN["ai-system.yaml<br/>purpose: CV screening, users: HR, data: applicants"] --> RULE{"Classifier rules"}
  RULE -->|"social scoring, manipulation"| PROH["Prohibited → block"]
  RULE -->|"Annex III area: employment"| HIGH["High-risk"]
  RULE -->|"chatbot, generated content"| LIM["Limited: transparency duties"]
  RULE -->|"other"| MIN["Minimal: voluntary codes"]
  HIGH --> REQ["Required evidence:<br/>risk mgmt, data governance, tech docs,<br/>logging, human oversight, accuracy + robustness"]
  LIM --> REQT["Required: AI disclosure, content labels"]
  REQ & REQT --> CHK{"Evidence complete + fresh?"}
  CHK -->|no| BLK["Block deploy + ticket to owner"]
  CHK -->|yes| DEP["Deploy with signed attestation"]
  DEP --> PMM["Post-market monitoring: incidents, drift → re-evaluate"]
```

### Follow one HR screening system through the gate
1. **Register.** The team describes the system in `ai-system.yaml`: purpose, users, affected people, data, and model.
2. **Classify.** Rules map the purpose to a tier. CV screening falls under employment in Annex III, so it's high-risk.
3. **Derive controls.** High-risk systems need risk management, data governance, technical documentation, logging, human oversight, and accuracy and robustness evidence.
4. **Collect evidence.** CI checks that each item exists and is current: the model card, eval reports including bias tests, the DPIA, and the oversight design.
5. **Gate.** Missing or stale evidence blocks deployment and opens a ticket. Complete evidence produces a signed attestation.
6. **Deploy.** Admission policy (Lab 70) checks for the attestation before pods can run.
7. **Monitor.** Incidents and drift trigger re-evaluation, and the classification is reviewed when the purpose changes.

**The one idea to keep:** compliance-as-code turns legal obligations into required evidence, checked automatically at every release. Legal review still decides the rules.

## Minimal hands-on

```yaml
# ai-system.yaml (lives next to the service's code)
id: credit-limit-advisor
owner: retail-risk@bank.example
purpose: "Recommend credit limit increases for existing customers"
domain: essential_private_services          # Annex III category
decision_impact: significant_effect_on_individuals
users: internal_underwriters
human_in_loop: true
models: ["models:/credit-advisor@champion"]
data: ["datasets/credit_features_v9 (sha256:ab12...)"]
```

```python
ANNEX_III = {"biometrics", "critical_infrastructure", "education", "employment",
             "essential_private_services", "law_enforcement", "migration", "justice"}
PROHIBITED = {"social_scoring", "subliminal_manipulation", "workplace_emotion_recognition"}

REQUIRED = {
    "high": ["risk_assessment", "data_governance_report", "technical_documentation",
             "event_logging", "human_oversight_design", "accuracy_robustness_evals",
             "cybersecurity_review", "conformity_assessment", "eu_database_registration"],
    "limited": ["ai_disclosure_ui", "synthetic_content_labeling"],
    "minimal": [],
}

def classify(s: dict) -> str:
    if s.get("practice") in PROHIBITED: return "prohibited"
    if s["domain"] in ANNEX_III and s.get("decision_impact") == "significant_effect_on_individuals":
        return "high"
    if s.get("interacts_with_public") or s.get("generates_content"): return "limited"
    return "minimal"

def gate(s: dict, evidence: set[str]):
    tier = classify(s)
    if tier == "prohibited": raise SystemExit(f"{s['id']}: prohibited practice")
    missing = [c for c in REQUIRED[tier] if c not in evidence]
    if missing: raise SystemExit(f"{s['id']} ({tier}) missing evidence: {missing}")
```

The deployment carries the label `ai-act/tier=high` and `ai-act/system-id=...`. A Kyverno policy (Lab 70) denies high-tier workloads
without an `evidence-bundle` annotation referencing a signed bundle.

## Worked example

**Scenario:** A bank inventories **312 AI use cases** across business units.

| Result of automated classification | Count | Action |
|---|---|---|
| Prohibited | 1 (an "employee sentiment from webcam" pilot) | Shut down |
| High-risk | 23 (credit, fraud-related customer decisions, HR screening) | Full control set; conformity work prioritized |
| Limited (transparency) | 87 (chatbots, content generation) | Disclosure UI component + content labels |
| Minimal | 201 | Register only |

Engineering made the high-risk controls cheap by **reusing the platform**: event logging (gateway logs + model version, Lab 44), data governance
(provenance manifests, Lab 66), human oversight (approval steps, Lab 73/75), robustness evals (Lab 50 gates), and cybersecurity
(sandboxing + policies, Labs 70/77). Evidence assembly per high-risk system went from ~6 weeks to **~4 days**.

## Production deep dive
- **Registry as source of truth:** Every AI system has a manifest in Git. CI fails if a service calls the AI gateway without a registered system ID (the gateway enforces a header).
- **Evidence is generated, not written:** Eval reports, lineage graphs, log retention configs, and policy reports are exported automatically and signed (Lab 66).
- **Logging obligations:** High-risk systems need traceable logs for an appropriate retention period. Make that a platform default with tamper-evident storage (Object Lock, Lab 67).
- **Human oversight UX:** Reviewers must understand the output and be able to override it. Measure override rates, since a rate near 0% may indicate rubber-stamping.
- **Map to standards:** ISO/IEC 42001 (AI management system), the NIST AI RMF, and CEN-CENELEC harmonized standards as they mature.

## FAANG deep-dive notes

- **How big tech does it:** Responsible-AI reviews are embedded in launch processes, with risk classification, required artifacts, and sign-offs automated through internal tooling.
- **Staff review questions:** Who owns classification, and when is it re-run? Is evidence generated automatically? Which role (provider or deployer) are we per system?
- **Interview question:** *"Make 300 AI use cases EU AI Act ready."* Strong answers cover an inventory, automated tiering, controls per tier, platform reuse for evidence, deployment gates, and ongoing monitoring.

**Typical system-design prompt:** *"Your company runs 150 AI systems in the EU. Design how you'll comply with the AI Act without stopping delivery."*

**1. Clarify first:**
- Inventory: do you even know all 150 systems, including vendor-provided ones?
- Your role per system: provider, deployer, or both?
- Which systems might be high-risk (employment, credit, essential services, etc.)?

**2. Back-of-envelope sizing:**
- Typically ~5–15% of enterprise AI systems are high-risk → 8–20 systems needing full evidence packs.
- Manual compliance: ~2–4 weeks of effort per high-risk system per major release. Automated evidence collection cuts that to days.
- Most systems (limited or minimal) need light-touch controls: disclosure, inventory, basic monitoring.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Classification | manual questionnaire | rules as code + legal review | code for consistency; legal owns the rules |
| Evidence | documents in SharePoint | generated from pipelines (evals, lineage, logs) | generate wherever possible |
| Enforcement | periodic audits | CI + admission gates | gates, plus periodic audits |
| Scope | high-risk only | inventory everything | inventory everything; deep controls by tier |
| Ownership | compliance team | system owners with platform tooling | owners accountable, platform makes it easy |

**4. Follow-up questions with crisp answers:**
- *Can code decide the risk tier?* It can apply agreed rules consistently. Edge cases go to legal review, recorded in the manifest.
- *What evidence comes for free from the platform?* Lineage (Lab 66), registry history (Lab 44), logs, eval reports, and policy reports (Lab 70).
- *What about general-purpose AI models?* Providers have separate obligations (documentation, copyright policy, and more for systemic-risk models).
- *How do you keep evidence fresh?* Expiry dates per evidence item, and re-running evals on each model change.
- *What's human oversight in practice?* Designed review points, the ability to override, and training for the reviewers, documented and tested.
- *What's post-market monitoring?* Ongoing performance, incident tracking, and serious-incident reporting.

**Debug this (common onsite question):** *"An internal audit finds a high-risk use running on a system registered as 'minimal risk'."*
1. The system was registered as an "internal document search" assistant, which is minimal risk.
2. HR later started using it to summarise and rank candidates, which is employment and therefore high-risk.
3. Nothing detected the change of purpose, because classification ran only at registration.
4. Fix: purpose-bound access (HR use requires a separately classified system), usage monitoring for out-of-scope prompts, periodic re-attestation of purpose by owners, and a clear process for reclassification.

The lesson: **risk depends on use, not technology. Monitor how systems are actually used, not only how they were registered.**

**5. What separates senior from staff answers:**
- Senior: builds the manifest, classifier, and evidence gate in CI and admission.
- Staff: designs the organization-wide inventory, the platform evidence that's generated automatically, ownership and review processes with legal, and detection of purpose drift.

**Red flags:** no inventory, compliance as one-time paperwork, code replacing legal judgement, ignoring vendor-provided AI.

## Failure modes
- Classification done once at launch, then the use case drifts (a chatbot starts making eligibility decisions) and nobody re-classifies.
- Evidence stored in slides, which can't be verified or reproduced at audit time.
- Treating GPAI provider obligations as the deployer's (or vice versa). Map your **role** (provider, deployer, importer) per system.

## Checklist
- [ ] `ai-system.yaml` schema + classifier in CI
- [ ] Required-controls matrix per tier
- [ ] Deployment gate checks for a signed evidence bundle
