# Lab 95: Decentralized Model Training over WAN (4:14)

## Why it matters
Not every organization has a single 10,000-GPU data center. Sovereign consortia, national labs, and multi-site enterprises
have GPUs **spread across sites connected by WAN links** (1–100 Gb/s, 10–100 ms latency), which is 100–1000× worse than InfiniBand.
Standard data-parallel training collapses on such links. Low-communication algorithms make it workable.

## In plain words
Three teams in different cities write chapters of one book. Phoning each other after every sentence (DDP over WAN) is hopeless. Instead
each team **writes 500 sentences alone**, then they **merge their changes** in one call (DiLoCo). That is far less talking, nearly the same book.

## Architecture at a glance

```mermaid
flowchart LR
  subgraph A["Site A: fast IB"]
    IA["500 local steps FSDP"]
  end
  subgraph B["Site B"]
    IB2["500 local steps"]
  end
  subgraph C["Site C"]
    IC["500 local steps"]
  end
  IA & IB2 & IC -->|"Δ weights, compressed, over WAN"| OUT[Outer optimizer: average + momentum]
  OUT -->|new global weights| IA & IB2 & IC
```

**How to read it:** Each site runs many fast local steps on its own fabric. Only weight deltas cross the WAN to an outer optimizer, which sends new global weights back to all sites.

## Core concepts

| Approach | Idea | Comm reduction |
|---|---|---|
| Standard DDP over WAN | All-reduce every step | 1× (unusable) |
| **Local SGD / DiLoCo** | Each site trains H steps (e.g. 500) locally, then sites sync **parameter deltas** with an outer optimizer (Nesterov momentum) | ~H× (100–500×) |
| **Streaming DiLoCo** | Sync different parameter fragments at staggered times; overlap with compute | Lower peak bandwidth |
| Gradient compression (top-k, quantized, PowerSGD) | Send fewer bits | 10–100× |
| Hierarchical | Fast all-reduce **within** each site, slow sync **between** sites | Combine with the above |
| Asynchronous / SWARM-style | Tolerate stragglers and dropouts | Robust, but harder convergence |

```
Site A (IB, 64 GPUs) ── inner FSDP steps ×500 ──┐
Site B (IB, 64 GPUs) ── inner FSDP steps ×500 ──┼─► outer sync: average Δθ (WAN, compressed) ─► repeat
Site C (RoCE, 32 GPUs) ─ inner steps ×500 ──────┘
```

## Architecture in depth

The overview shows sites running local steps and exchanging deltas. This view shows **one DiLoCo round on a timeline**, which
makes clear why WAN bandwidth stops being the bottleneck.

```mermaid
sequenceDiagram
  participant A as Site A (256 GPUs)
  participant B as Site B (256 GPUs)
  participant C as Site C (128 GPUs)
  participant O as Outer optimizer
  O->>A: global weights θ(t)
  O->>B: θ(t)
  O->>C: θ(t)
  Note over A,C: 500 inner steps each (AdamW, local FSDP over IB) ≈ 40 min
  A->>O: Δ_A = θ(t) − θ_A (compressed, e.g. int8)
  B->>O: Δ_B
  C->>O: Δ_C (weighted by tokens processed)
  O->>O: average deltas, Nesterov momentum → θ(t+1)
  O->>A: θ(t+1)
  O->>B: θ(t+1)
  O->>C: θ(t+1)
  Note over A,O: comms ≈ minutes per 40 min, overlappable
```

### Follow one outer round
1. **Broadcast.** All sites start from the same global weights θ(t).
2. **Inner loop.** Each site trains independently for H steps (e.g. 500), using normal fast training on its own InfiniBand fabric.
3. **Compute the delta.** Each site sends how far its weights moved, compressed, e.g. to int8.
4. **Weight by work.** A smaller or slower site contributes proportionally to the tokens it processed.
5. **Outer update.** The outer optimizer averages the deltas and applies momentum, producing θ(t+1).
6. **Repeat.** New weights go back to all sites. Communication happens once every ~40 minutes instead of every second.

**The one idea to keep:** synchronize rarely and send only compressed deltas. WAN bandwidth then matters 500× less than in normal data-parallel training.

## Minimal hands-on — DiLoCo outer loop (concept)

```python
import torch, torch.distributed as dist

# inner_model: trained with normal FSDP inside the site (fast fabric)
# outer group: one rank per site, connected over WAN (gloo/nccl over TCP)
global_params = [p.detach().clone() for p in inner_model.parameters()]
outer_opt = torch.optim.SGD(global_params, lr=0.7, momentum=0.9, nesterov=True)

for outer_step in range(T):
    for _ in range(H):                                   # e.g. H = 500 local steps
        loss = inner_model(next(batch)).loss; loss.backward(); inner_opt.step(); inner_opt.zero_grad()
    for g, p in zip(global_params, inner_model.parameters()):
        delta = (g - p.detach()).to(torch.bfloat16)      # "pseudo-gradient", compressed
        dist.all_reduce(delta, group=wan_group); delta /= n_sites
        g.grad = delta.to(g.dtype)
    outer_opt.step(); outer_opt.zero_grad()
    for g, p in zip(global_params, inner_model.parameters()):
        p.data.copy_(g)                                  # all sites restart from the new global
```

## Worked example

**Scenario:** A national AI consortium: **3 university sites** with 128, 96, and 64 H100s, connected by a **10 Gb/s research network** (25 ms RTT).
Goal: pre-train a 3B sovereign-language model.

| Method | Data exchanged per outer sync | Wall-clock per 1B tokens | Final loss vs. a single-site baseline |
|---|---|---|---|
| DDP across WAN | 6 GB **every step** (~5 s WAN per step) | ~20× slower | same |
| **DiLoCo, H=500, bf16 deltas** | 6 GB every 500 steps (~5 s, overlapped) | ~1.08× | within ~1–2% |
| + int8/int4 delta quantization | 1.5–3 GB | ~1.04× | within ~2% |

The consortium trained on 288 GPUs that **no single site had**, without building a new data center. Each site keeps its own training data
locally (useful for licensing), and only parameter deltas cross the network.

## Production deep dive
- **Heterogeneity:** Sites have different GPU counts and speeds. Weight contributions by tokens processed, and tolerate slower sites (async variants).
- **Fault tolerance:** A site going offline shouldn't stop the others. Continue with N−1 sites and rejoin from the latest global state (Lab 39 patterns per site).
- **Security:** Encrypt WAN sync (WireGuard/mTLS), authenticate sites (SPIFFE), and sign checkpoints. Malicious or buggy sites can poison the model, so use robust aggregation or anomaly checks on deltas.
- **Orchestration:** Each site runs its own K8s + Kueue. A thin cross-site coordinator (or Karmada/MultiKueue, Lab 91) handles outer sync membership.
- **Research frontier:** OpenDiLoCo, Prime Intellect INTELLECT-style runs, and Nous DisTrO-style optimizers. Validate convergence on your scale before committing.

## FAANG deep-dive notes

- **How big tech does it:** Multi-datacenter training is an active area, using hierarchical communication and low-communication optimizers to span sites.
- **Staff review questions:** What is the bandwidth per outer sync, and is it overlapped? How is a site failure handled? Was convergence verified at small scale?
- **Interview question:** *"Train a model across 3 data centers with 10 Gb/s links."* Strong answers show why DDP fails (bandwidth math), propose local SGD/DiLoCo with compression and hierarchical sync, and cover failure handling.

**Typical system-design prompt:** *"A country has GPUs spread across 3 data centres 300 km apart. Train one 7B model using all of them."*

**1. Clarify first:**
- GPU count per site and WAN bandwidth between sites (e.g. 100 Gb/s).
- Is a modest quality gap acceptable vs. a single-site run?
- Are sites reliable, or do they come and go (e.g. shared capacity)?

**2. Back-of-envelope sizing:**
- 7B model in bf16 = 14 GB of gradients. Standard DP all-reduce every step (~1 s) over 100 Gb/s needs ~2.2 s just for communication, so GPUs would idle most of the time.
- DiLoCo with H = 500: one exchange of 14 GB (or 7 GB at int8) per ~500 s ≈ 0.6–1.1 s of transfer per 500 s, under 0.3% overhead.
- Quality: published results show DiLoCo close to synchronous training at moderate H. Validate on your setup with a small-scale ablation.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Method | synchronous DP over WAN | DiLoCo / local SGD | local SGD-style across sites |
| Sync interval H | small (better quality) | large (less comms) | tune H; start around 100–500 |
| Compression | none | int8 / top-k | compress outer deltas |
| Heterogeneity | equal weighting | weight by tokens processed | weight by work |
| Alternative | one-site training | federated (Lab 96) if data can't move | DiLoCo when data can move; FL when it can't |

**4. Follow-up questions with crisp answers:**
- *Why doesn't synchronous DP work over WAN?* Every step needs a full gradient exchange, and WAN latency and bandwidth make GPUs wait.
- *What is the outer optimizer?* An optimizer (often Nesterov momentum SGD) applied to averaged deltas, treating them like a gradient.
- *What if a site drops out?* Proceed with the remaining deltas for that round, and the site rejoins with the latest global weights.
- *Does it hurt quality?* Slightly at large H. Ablations decide the acceptable H.
- *Can the inner loops differ?* Yes, each site may use different parallelism internally. Only the deltas must match in shape.
- *How do you checkpoint?* The outer state (global weights + momentum) at each round, plus local checkpoints per site.

**Debug this (common onsite question):** *"The multi-site run's loss is worse than single-site, and worsens when Site C participates."*
1. Site C processes half the tokens per round (fewer, older GPUs) but its delta is weighted equally.
2. Site C's data shard also has a different language mix, so its deltas pull in a different direction.
3. H was raised to 2,000 to save bandwidth, which amplifies drift between sites.
4. Fix: weight deltas by tokens processed, shuffle data globally so each site sees the same distribution, lower H to 500, and track per-site delta norms and divergence.

The lesson: **decentralized training needs balanced data and fair weighting. Otherwise sites pull the model apart.**

**5. What separates senior from staff answers:**
- Senior: implements a DiLoCo outer loop with compression and weighting.
- Staff: decides when multi-site training beats consolidating hardware, runs ablations on H and compression, designs data distribution and failure handling across sites, and sets quality acceptance criteria.

**Red flags:** synchronous all-reduce over WAN, equal weighting of unequal sites, no ablation for H, unbalanced data across sites.

## Failure modes
- Too large H means sites drift apart and the outer average degrades. Tune H against loss.
- Data distribution very different per site (non-IID) slows convergence. Mix data or use per-site weighting.
- WAN sync blocks compute because it isn't overlapped (no streaming), so GPUs idle during sync.

## Checklist
- [ ] You can explain why DDP fails over WAN with numbers
- [ ] Inner/outer loop structure understood
- [ ] Site failure + rejoin procedure designed
