# Glossary

| Term | Meaning |
|---|---|
| **cgroups** | Linux kernel feature that limits and accounts for CPU, memory, and I/O of process groups. Kubernetes resource limits are built on it. |
| **containerd** | The container runtime that K8s talks to through CRI. Docker uses it underneath. |
| **CRI / CNI / CSI** | Container Runtime, Network, and Storage Interfaces: the plug-in points of Kubernetes. |
| **K3s** | Lightweight, CNCF-certified Kubernetes distribution packaged as a single binary. |
| **CoreDNS** | Cluster DNS. Resolves `svc.namespace.svc.cluster.local`. |
| **Ingress / Gateway API** | L7 entry points into the cluster. Gateway API is the modern successor to Ingress. |
| **PV / PVC / StorageClass** | Persistent Volume, the claim on it, and the provisioner policy. |
| **vLLM** | High-throughput LLM inference engine using PagedAttention. |
| **PagedAttention** | Manages the KV cache in fixed-size blocks, like OS virtual memory pages. |
| **KV cache** | Cached attention keys/values for previous tokens. The dominant memory cost in inference. |
| **TTFT / TPOT** | Time To First Token / Time Per Output Token: the two key latency metrics. |
| **Device Plugin** | K8s extension that advertises hardware such as `nvidia.com/gpu` to the scheduler. |
| **NFD** | Node Feature Discovery. Labels nodes with hardware capabilities. |
| **GPU Operator** | NVIDIA operator that installs drivers, the toolkit, the device plugin, and DCGM as one unit. |
| **MIG** | Multi-Instance GPU. Hardware partitioning of A100/H100 into isolated slices. |
| **ROCm** | AMD's GPU compute stack, the counterpart to CUDA. |
| **DCGM** | NVIDIA Data Center GPU Manager, used for telemetry and health. |
| **HPA / KEDA** | Horizontal Pod Autoscaler / event-driven autoscaler. |
| **Karpenter** | Just-in-time node provisioner. Picks instance types based on pending pods. |
| **Ray / KubeRay** | Distributed Python framework / its K8s operator. |
| **DDP / FSDP / ZeRO** | Data parallelism variants: full replicas vs. sharded params, grads, and optimizer states. |
| **TP / PP / SP / EP** | Tensor, Pipeline, Sequence, and Expert parallelism. |
| **NCCL** | NVIDIA Collective Communications Library (all-reduce, all-gather). |
| **InfiniBand / RoCEv2** | RDMA networks. IB is native; RoCE carries RDMA over Ethernet. |
| **GPUDirect RDMA** | NIC reads and writes GPU memory directly, bypassing the CPU. |
| **Gang scheduling** | Schedule all pods of a job together or none at all (Volcano, Kueue). |
| **Megatron-LM** | NVIDIA framework for 3D-parallel (TP+PP+DP) LLM training. |
| **Triton** | NVIDIA multi-framework inference server. |
| **TensorRT-LLM** | NVIDIA compiler and runtime for optimized LLM engines. |
| **LoRA** | Low-Rank Adaptation. Small adapter weights on top of a frozen base model. |
| **Speculative decoding** | A draft model proposes tokens and the target model verifies them in parallel. |
| **Semantic cache** | Reuse a stored LLM answer when a new prompt is close enough in embedding space, within the same tenant, permission, and version scope (Lab 60). |
| **Semantic routing** | Route prompts to models or tools by embedding-based intent classification. |
| **HNSW / IVF / PQ** | Vector index families: graph-based, inverted-file, and product quantization. |
| **Milvus** | Distributed vector database with separated storage and compute. |
| **Kafka** | Distributed commit log for streaming. |
| **CDC** | Change Data Capture. Streams database row changes. |
| **PII** | Personally Identifiable Information. |
| **Provenance** | Verifiable lineage of data and models (hashes, signatures, SBOMs). |
| **MinIO** | S3-compatible object storage you can self-host. |
| **Valkey** | BSD-licensed, Linux Foundation fork of Redis 7.2. Protocol-compatible, with vector search via `valkey-search` (Lab 60). |
| **Velero** | K8s backup and restore for resources and volumes. |
| **Kyverno / OPA Gatekeeper** | Policy-as-code admission controllers. |
| **MCP** | Model Context Protocol. Open protocol that connects LLM hosts to tools and data servers. |
| **gVisor / Kata / Firecracker** | Sandboxing runtimes, from user-space kernels to micro-VMs. |
| **Karmada / KubeFed** | Multi-cluster federation control planes. |
| **EU AI Act** | EU regulation that classifies AI systems by risk tier. |
| **Gaia-X** | European framework for federated, sovereign data and cloud services. |
| **Air-gap** | Network with no connection to the public internet. |
| **Federated learning** | Train across parties without centralizing raw data. |
| **Blackwell (B200/GB200)** | NVIDIA GPU generation after Hopper. NVL72 racks with 5th-gen NVLink. |
