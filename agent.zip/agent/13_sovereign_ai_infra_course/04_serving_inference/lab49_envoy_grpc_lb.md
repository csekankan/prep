# Lab 49: Envoy Proxy — Advanced Load Balancing for gRPC (4:21)

## Why it matters
gRPC uses long-lived HTTP/2 connections that **multiplex** many requests. K8s Services (L4) balance
connections, not requests (Lab 6), so one gRPC client can hammer one pod. LLM requests also vary
enormously in cost. You need **L7, request-aware balancing**, and Envoy is the standard data plane for it.

## In plain words
gRPC keeps **one long phone call open** and sends many messages over it. A normal load balancer only chooses who answers the call, so
one operator gets everything. Envoy listens to each message and **hands it to the least busy operator**, and hangs up on operators who keep failing.

## Architecture at a glance

```mermaid
flowchart LR
  C1[Client 1] & C2[Client 2] -->|HTTP/2 long-lived| E[Envoy]
  E -->|per-request LEAST_REQUEST| P1[Pod 1]
  E --> P2[Pod 2]
  E --> P3[Pod 3]
  E -.outlier ejected.-x P4[Pod 4: errors]
  E --> CB["Circuit breaker → fast 503 when full"]
```

**How to read it:** Clients keep long-lived HTTP/2 connections to Envoy. Envoy spreads each request to the least busy pod, ejects failing pods, and returns fast 503s when the circuit breaker trips.

## Core concepts

| Envoy feature | Why AI cares |
|---|---|
| **Per-request LB** over HTTP/2/gRPC | Even spread across replicas |
| `LEAST_REQUEST` (power of two choices) | Avoids slow/busy pods better than round-robin |
| **Outlier detection** | Ejects pods returning errors/timeouts |
| **Circuit breakers** (max pending/requests) | Shed load before GPUs collapse |
| **Retries with budgets** | Retry *safely* (idempotent only) |
| **Timeouts / stream idle timeouts** | Long-running streams without leaks |
| **External processing (ext_proc)** | Plug in token counting, routing, PII filters |
| **Rate limiting (global/local)** | Per-tenant quotas (Lab 79) |
| **mTLS** | Zero-trust between services |

Envoy is the data plane for Istio, Envoy Gateway, Envoy AI Gateway, and Contour. The **Gateway API
Inference Extension** adds an endpoint picker that chooses pods by KV-cache usage and queue depth.

## Architecture in depth

The overview shows Envoy spreading requests. This view shows **Envoy's internal filter and cluster pipeline** for one gRPC
request, including where each protection acts.

```mermaid
flowchart LR
  C[Client HTTP/2 stream] --> L[Listener :443 + TLS]
  L --> HCM[HTTP connection manager]
  subgraph Filters["HTTP filter chain"]
    AUTH[ext_authz / JWT] --> RL[Rate limit] --> ROUTE[Router: match /llm.Generate]
  end
  HCM --> Filters
  ROUTE --> CL["Cluster llm-backends"]
  subgraph ClusterLogic["Cluster logic"]
    CB{"Circuit breaker:<br/>pending < 100?"} --> LB["LB: LEAST_REQUEST, pick 2 of N"]
    LB --> OD["Outlier detection: skip ejected hosts"]
    OD --> HC["Active health checks"]
  end
  CL --> ClusterLogic
  ClusterLogic --> P1[Pod A] & P2[Pod B]
  CB -->|"full"| FAST[503 + retry-after]
  EDS[(EDS from K8s endpoints)] -.membership.-> ClusterLogic
```

### Follow one gRPC call from client to pod
1. **Listener.** The client keeps one long-lived HTTP/2 connection with many streams. Envoy terminates TLS.
2. **Filters.** Authentication, rate limiting, and routing run in order. The route matches the gRPC method.
3. **Circuit breaker.** If too many requests are already pending for the cluster, Envoy fails fast with a 503 instead of queueing forever.
4. **Load balancing per request.** Unlike a Kubernetes Service, which balances per *connection*, Envoy picks a backend per *request*, using least-request ("power of two choices").
5. **Outlier detection.** Pods returning consecutive errors are ejected for a period and skipped.
6. **Membership.** Endpoint discovery (EDS) keeps the host list in sync with Kubernetes endpoints as pods scale.
7. **Response streams back.** Retries happen only for safe failures (e.g. connection refused before any bytes were sent).

**The one idea to keep:** HTTP/2 pins traffic to one connection, so a layer-7 proxy that balances per request is what keeps every GPU equally busy.

## Minimal hands-on (key snippets)

```yaml
clusters:
- name: embeddings_grpc
  type: STRICT_DNS                      # headless service → pod IPs
  lb_policy: LEAST_REQUEST
  typed_extension_protocol_options:
    envoy.extensions.upstreams.http.v3.HttpProtocolOptions:
      explicit_http_config: { http2_protocol_options: {} }
  load_assignment:
    cluster_name: embeddings_grpc
    endpoints: [{ lb_endpoints: [{ endpoint: { address: { socket_address: { address: embed-headless.ai.svc, port_value: 8001 } } } }] }]
  outlier_detection: { consecutive_5xx: 5, interval: 10s, base_ejection_time: 30s, max_ejection_percent: 50 }
  circuit_breakers:
    thresholds: [{ max_pending_requests: 200, max_requests: 1000 }]
```

Route-level for LLM streams:

```yaml
route: { cluster: llm, timeout: 0s, idle_timeout: 300s,
         retry_policy: { retry_on: "connect-failure,refused-stream", num_retries: 1 } }   # NOT on 5xx/timeouts
```

## Worked example

**Scenario:** A gRPC embedding service (Triton) used by a RAG ingestion pipeline. 6 replicas. p99 is
**2.4 s** and one pod is always at 100% while others sit at 30%.

1. Diagnosis: 3 ingestion clients with HTTP/2 connections pinned by kube-proxy to 3 pods (2 got double load).
2. Envoy sidecar/gateway with `LEAST_REQUEST` over the headless service splits requests across all 6.
3. Outlier detection ejects a pod with a degraded GPU (XID errors causing timeouts) automatically.
4. Circuit breaker returns fast `503` with retry-after instead of a queue explosion during bursts. Upstream Kafka consumers back off (Lab 63).

Result: p99 2.4 s → **180 ms**, and throughput +40% on the same GPUs.

## Production deep dive
- **Retry discipline:** Never auto-retry non-idempotent LLM generations on timeout. That doubles GPU load during incidents. Use retry budgets (`retry_budget: 20%`).
- **Envoy AI Gateway / ext_proc:** Count tokens from responses for chargeback, inject auth to upstream providers, and route on the `model` field.
- **Locality-aware LB:** Prefer same-zone endpoints, fail over cross-zone (`locality_weighted_lb`).
- **Observability:** Envoy access logs plus OpenTelemetry tracing across gateway, router, LLM, and vector DB give end-to-end latency attribution.
- **Config management:** Use Envoy Gateway/Istio CRDs. Hand-written xDS configs don't scale.

## FAANG deep-dive notes

- **How big tech does it:** Service meshes or proxies handle L7 balancing, outlier detection, retries with budgets, and mTLS, configured via CRDs with per-service SLOs.
- **Staff review questions:** Which errors are retried, and are they idempotent? What is the circuit-breaker threshold based on? Is balancing per request?
- **Interview question:** *"Design load balancing for a gRPC model service."* Strong answers cover L7 per-request LB, least-request with P2C, health and outlier detection, retry budgets, deadlines, and locality.

**Typical system-design prompt:** *"Design the load-balancing layer for an LLM gRPC API with 40 GPU replicas and very uneven request durations."*

**1. Clarify first:**
- Request duration variance (100 ms to 60 s streams?).
- Client types: few large internal clients with long-lived connections, or many external ones?
- Requirements for retries, timeouts, and tenant fairness.

**2. Back-of-envelope sizing:**
- 5 internal clients × 2 connections each = 10 HTTP/2 connections. With connection-level balancing, at most 10 of 40 pods get traffic, so 75% of GPUs sit idle.
- Per-request least-request balancing spreads load across all 40, which is the 4× capacity you already paid for.
- Envoy overhead ≈ 1 ms per request and ~1 vCPU per few thousand RPS, negligible versus inference time.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| LB layer | L4 (Service / kube-proxy) | L7 (Envoy, gateway) | L7 for gRPC/HTTP2 |
| Algorithm | round robin | least request / queue-aware | least request; LLM-aware (KV/queue) for inference |
| Overload | queue | circuit breaker + 503 | fail fast with Retry-After |
| Retries | always | idempotent and safe only | never retry mid-stream generation |
| Deployment | central proxy | sidecar / mesh | central gateway for north-south; mesh for many services |

**4. Follow-up questions with crisp answers:**
- *Why doesn't a K8s Service balance gRPC well?* kube-proxy balances TCP connections, and HTTP/2 multiplexes all requests over a few of them.
- *What is "power of two choices"?* Pick two random hosts and send to the less loaded one. It's nearly optimal and cheap.
- *What does outlier detection add over health checks?* It reacts to real traffic errors in seconds, without waiting for probes.
- *What's an LLM-aware balancer?* One that uses engine metrics (queue depth, KV usage, prefix cache) to choose, e.g. the Gateway API Inference Extension.
- *Why not retry generation?* It doubles GPU cost and can duplicate side effects. Retry only before the backend starts work.
- *How do you set timeouts for streams?* Idle timeouts per stream, plus max duration by product tier.

**Debug this (common onsite question):** *"Half the GPUs show 95% utilization and half show 10%, yet the HPA says the average is fine."*
1. The client connects directly to the Kubernetes Service with gRPC. It has 3 long-lived connections.
2. Each connection was pinned to one pod at creation, and later replicas never receive traffic.
3. The HPA averages utilization, so it doesn't scale, and the hot pods breach TTFT.
4. Fix: put Envoy (or a gateway) in front with per-request least-request balancing, plus max connection age on the server to rebalance old connections.

The lesson: **with HTTP/2, adding replicas doesn't add capacity unless something balances per request.**

**5. What separates senior from staff answers:**
- Senior: configures Envoy with least-request, outlier detection, circuit breakers.
- Staff: designs LLM-aware load balancing with engine signals, retry/timeout policy per API, overload semantics, and the gateway-vs-mesh boundary.

**Red flags:** gRPC through a plain Service, retries on streaming generation, no circuit breakers, round robin with highly variable request lengths.

## Failure modes
- `STATIC`/ClusterIP upstream gives Envoy one IP, so per-request balancing does nothing. Use headless/EDS.
- Global timeout of 15 s kills long streaming responses.
- Outlier detection with `max_ejection_percent: 100` can eject every pod during a correlated blip.

## Checklist
- [ ] Even per-request distribution shown in metrics
- [ ] Outlier detection + circuit breakers configured
- [ ] Retry policy reviewed for idempotency
