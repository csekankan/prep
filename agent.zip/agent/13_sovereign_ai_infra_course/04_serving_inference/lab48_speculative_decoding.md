# Lab 48: Speculative Decoding — Accelerating Time-To-First-Token (3:33)

## Why it matters
Decode is **memory-bandwidth bound**. Each token requires reading all the weights, and the GPU's compute
sits mostly idle. Speculative decoding uses that idle compute: **guess several tokens cheaply, then
verify them all in one forward pass** of the big model. The output is mathematically the same, and it arrives 1.5–3× faster.

> **Precision note:** Speculative decoding mainly improves **TPOT/inter-token latency** and total
> response time. Strict TTFT (prefill) improves only indirectly: replicas finish requests faster, so queues
> are shorter and waiting requests start sooner. For direct TTFT wins, see prefix caching (Lab 47) and
> disaggregated prefill (Lab 42).

## In plain words
A senior writer (big model) is slow but accurate. A junior (draft model) quickly drafts the next few words, and the senior **checks
the whole draft in one glance**, keeping the correct words and fixing the first wrong one. The text is exactly what the senior would have written, only faster.

## Architecture at a glance

```mermaid
flowchart LR
  CTX[Context] --> DR["Draft: propose k tokens fast"]
  DR --> TG["Target: verify all k in 1 pass"]
  TG --> ACC{Accepted?}
  ACC -->|first m correct| OUT["Emit m + 1 tokens"]
  ACC -->|rejected rest| DR
  OUT --> CTX
```

**How to read it:** The draft proposes several tokens, the target verifies them all in one pass, and the accepted tokens are emitted. The loop repeats from the new context.

## Core concepts

```
Draft proposes:      "The capital of France is Paris ."   (k=5 tokens, cheap)
Target verifies:     ✓   ✓      ✓  ✓      ✓   ✗→"," (1 forward pass)
Accepted: 5 tokens + 1 corrected token from one big-model step
```

| Method | Draft source | Notes |
|---|---|---|
| **Draft model** | Small model of same family (1B for 70B) | Needs the same tokenizer |
| **EAGLE / EAGLE-3** | Lightweight head trained on target's hidden states | Top acceptance rates |
| **Medusa** | Extra decoding heads | Requires fine-tune |
| **N-gram / prompt lookup** | Copy from the prompt | Free. Great for RAG/code edits/summaries |
| **MTP** (multi-token prediction) | Native in some models (DeepSeek-V3) | Built-in heads |

**Acceptance rate (α)** drives the speedup. α depends on the task: highly predictable text (code, structured
JSON, summarization) gets high α; creative writing gets low α.

**When it hurts:** At very high batch sizes the GPU is already compute-busy, so verification overhead
can *reduce* throughput. Speculative decoding is a **latency** optimization, best at low to moderate concurrency.

## Architecture in depth

The overview shows the draft-verify loop. This view shows **one verification step in detail**: how the target checks k draft tokens
in a single pass, and why acceptance rate decides the speed-up.

```mermaid
sequenceDiagram
  participant D as Draft (EAGLE head / small model)
  participant T as Target model (70B)
  participant S as Sampler
  Note over D: context = "The invoice total is"
  D->>D: propose 4 tokens: " $" "1" "," "250"
  D->>T: context + 4 drafts
  T->>T: ONE forward pass scores all 5 positions in parallel
  T->>S: target probabilities per position
  S->>S: accept " $" ✅ "1" ✅ "," ✅ "250" ❌ (target prefers "200")
  S-->>D: emit " $1,200" = 3 accepted + 1 corrected token
  Note over D,T: 4 tokens for ~1 target pass + 4 cheap draft steps
```

### Follow one speculative step
1. **Draft.** A cheap drafter (an EAGLE head on the target, or a small model) guesses the next 4 tokens. This costs a fraction of a target step.
2. **Verify in parallel.** The target processes the context plus all 4 guesses in *one* forward pass. Decode is memory-bound, so checking 5 positions costs about the same as generating 1.
3. **Accept the prefix.** Guesses are accepted left to right while they match what the target would produce (rejection sampling keeps the output distribution identical).
4. **Correct.** At the first mismatch, the target's own token is used instead, so even a full miss yields 1 token.
5. **Emit.** Here, 3 accepted + 1 correction = 4 tokens for roughly the cost of one target step.
6. **Repeat.** The draft continues from the new context.

**The one idea to keep:** speculation turns spare compute into fewer target passes. It helps when acceptance is high and the GPU isn't already compute-saturated.

## Minimal hands-on

```bash
# Prompt-lookup (n-gram) — zero extra model
vllm serve meta-llama/Llama-3.1-70B-Instruct -tp 4 \
  --speculative-config '{"method":"ngram","num_speculative_tokens":5,"prompt_lookup_max":4}'

# EAGLE draft head
vllm serve meta-llama/Llama-3.1-70B-Instruct -tp 4 \
  --speculative-config '{"method":"eagle","model":"yuhuili/EAGLE-LLaMA3.1-Instruct-70B","num_speculative_tokens":4}'
```

## Worked example

**Scenario:** A code assistant (70B) must hit **≥ 40 tok/s per user** for a "feels instant" UX. Baseline is 24 tok/s at 16 concurrent users.

| Method | Acceptance α | tok/s per user | GPU throughput |
|---|---|---|---|
| Baseline | — | 24 | 100% |
| N-gram lookup (code edits copy a lot from context) | 0.62 | 39 | 104% |
| **EAGLE-3** | 0.78 | **52** | 112% |
| EAGLE-3 at 128 concurrent users | 0.78 | 21 (vs. 19 baseline) | 96% |

Decision: enable EAGLE on the **interactive** pool (≤ 32 concurrent per replica) and disable it on the **batch** pool.
Routing by workload class (Lab 46) makes both possible.

## Production deep dive
- **Correctness:** With rejection sampling, the output distribution equals the target model's. Still run eval parity tests after enabling it, because implementation bugs happen.
- **Memory:** A draft model or heads consume VRAM and KV. Budget for them (Lab 42).
- **Per-workload tuning:** `num_speculative_tokens` around 3–5. Too many means wasted verification on rejections.
- **Monitoring:** Export acceptance rate and mean accepted length, and alert on drops (e.g. after a prompt change or model update).
- **TRT-LLM / SGLang** support EAGLE and Medusa natively. Compare engines (Lab 43).

## FAANG deep-dive notes

- **How big tech does it:** Speculative decoding (draft heads, MTP) is enabled for latency-critical, interactive tiers and disabled or tuned for throughput-bound batch tiers.
- **Staff review questions:** What is the acceptance rate per workload? Does it help or hurt at your concurrency level? Was output parity tested?
- **Interview question:** *"Explain speculative decoding and when it doesn't help."* Strong answers explain that decode is bandwidth-bound and verification is parallel, then cover acceptance-rate dependence and why high batch sizes erase the gain.

**Typical system-design prompt:** *"Reduce latency per output token for a 70B chat model by 2× without changing outputs."*

**1. Clarify first:**
- Batch sizes in production (speculation gains shrink at high batch).
- Output types: code and structured data (predictable) vs. creative text.
- Can you train a draft head (EAGLE) on your own traffic?

**2. Back-of-envelope sizing:**
- With k = 4 drafts and per-token acceptance α = 0.7, expected tokens per target pass = (1 − α^(k+1)) ÷ (1 − α) ≈ 2.8.
- Draft overhead ~10–15% of a target step, giving a net speed-up of ~2.3–2.5× at low batch.
- At batch 64+, the GPU becomes compute-bound, so verification is no longer "free" and gains fall toward 1.2× or below.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Drafter | separate small model | EAGLE / Medusa heads | EAGLE-style heads for best acceptance |
| Draft length k | long (8) | short (3–5) | tune k on measured acceptance |
| When to enable | always | low/medium batch only | disable or shorten k at high load |
| No drafter | n-gram / prompt lookup | — | great for RAG and code that copies from context |

**4. Follow-up questions with crisp answers:**
- *Does speculation change outputs?* No. With proper rejection sampling, the output distribution is identical to the target's.
- *Why is verification cheap?* Decode is memory-bandwidth bound, so scoring several positions reuses the same weight reads.
- *Why does it help TPOT more than TTFT?* It speeds up generation steps, while TTFT is dominated by prefill.
- *What lowers acceptance?* High temperature, a domain mismatch between drafter and traffic, creative writing.
- *When does it hurt?* At high batch, where wasted draft compute competes with real work.
- *How do you train an EAGLE head?* On the target's own hidden states from representative traffic. It's small and quick to train.

**Debug this (common onsite question):** *"Speculative decoding gave 2.2× in staging, but in production tokens/s per GPU fell 15%."*
1. Staging tested with single requests. Production runs batch sizes of 80–120.
2. At that batch, the GPU is compute-bound, and rejected draft tokens waste compute.
3. Measured acceptance in production is also lower (0.45), because traffic is more creative than the staging set.
4. Fix: enable speculation only below a batch threshold (dynamic speculation), retrain the draft head on production samples, and benchmark at real concurrency.

The lesson: **latency optimizations must be benchmarked at production batch sizes. Speculation trades throughput for latency.**

**5. What separates senior from staff answers:**
- Senior: enables EAGLE or n-gram speculation and tunes k.
- Staff: models acceptance vs. batch to decide when speculation is on, trains drafters on real traffic, and frames the latency-vs-throughput trade-off for the business.

**Red flags:** benchmarking only at batch 1, claiming TTFT gains, ignoring acceptance metrics, always-on speculation at high load.

## Failure modes
- Draft model with a different tokenizer means near-zero acceptance and a slowdown.
- Enabled on a saturated batch pool, so throughput drops 10–20%.
- Base model upgraded without retraining EAGLE heads, so acceptance collapses.

## Checklist
- [ ] Speculative decoding enabled and acceptance rate measured
- [ ] Speedup compared at low vs. high concurrency
- [ ] Enable/disable policy defined per workload pool
