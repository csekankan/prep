# Lab 50: Blue/Green Deployments for Zero-Downtime Model Updates (4:39)

## Why it matters
Model updates are riskier than code updates. A new model can be **fluent and wrong**, and it fails
in ways no health check catches. You need deployment strategies that keep the old model ready,
shift traffic gradually, and roll back in seconds.

## In plain words
Blue/green is having a **second stage fully set up** behind the curtain. You let a few audience members peek at the new show (canary).
If they frown, you close the curtain instantly. The old show never stopped.

## Architecture at a glance

```mermaid
flowchart LR
  U[Users] --> GW[Gateway HTTPRoute weights]
  GW -->|90%| B["Blue: model v11 (warm)"]
  GW -->|10%| G["Green: model v12"]
  G --> AN{"Analysis: errors, TTFT, thumbs-down, cost"}
  AN -->|pass| UP[Increase weight → 100%]
  AN -->|fail| RB[Weight 0% → instant rollback]
```

**How to read it:** The gateway splits traffic by weight between blue (old) and green (new). Analysis on quality, latency, and cost decides whether to increase green's weight or drop it to zero instantly.

## Core concepts

| Strategy | How | Pros | Cons |
|---|---|---|---|
| **Rolling** | Replace pods gradually | Cheap | Mixed versions; slow rollback; capacity dip during model loads |
| **Blue/Green** | Full new stack (green) beside old (blue); flip traffic | Instant rollback | 2× GPUs during switch |
| **Canary** | Shift 1% → 10% → 50% → 100% with metric gates | Limits blast radius | Needs good metrics |
| **Shadow / mirror** | Copy live traffic to new model, discard responses | Zero user risk; real data eval | 2× compute; privacy review |
| **A/B** | Split by user cohort for business metrics | Measures impact | Longer duration |

**LLM-specific gates** (beyond 5xx and latency):
- Offline eval suite pass (accuracy, safety, regression set)
- Online: thumbs-down rate, escalation-to-human rate, refusal rate, avg output length drift, guardrail trigger rate
- Cost per request (a new model being more verbose means a higher bill)

## Architecture in depth

The overview shows the weighted split between blue and green. This view follows **one automated canary rollout** with Argo
Rollouts, including the analysis that decides each step.

```mermaid
sequenceDiagram
  participant G as Git (model v12 alias)
  participant AR as Argo Rollouts
  participant GW as Gateway HTTPRoute
  participant GR as Green pods (v12)
  participant AN as AnalysisRun (Prometheus + eval)
  G->>AR: new revision
  AR->>GR: scale green to full size, wait warm-up
  AR->>GW: shadow 5% (mirror, responses discarded)
  AR->>AN: compare quality offline
  AR->>GW: weight 5% live
  AN-->>AR: errors ✅ TTFT ✅ thumbs-down ✅ cost ✅
  AR->>GW: 25% → 50% → 100% (analysis at each step)
  AN-->>AR: ❌ at any step
  AR->>GW: weight 0% green → instant rollback
```

### Follow model v12 from merge to 100%
1. **Trigger.** Merging the new model alias into Git creates a new rollout revision.
2. **Warm up first.** Green pods start and load weights, and they only become eligible after warm-up requests (CUDA graphs, caches), so no user sees a cold start.
3. **Shadow.** A copy of 5% of traffic is mirrored to green. Users see blue's answers, and green's answers are compared offline for quality.
4. **Canary.** Green gets 5% of live traffic.
5. **Analysis.** At each step, automated checks compare green with blue: error rate, TTFT and TPOT, thumbs-down rate, refusal rate, and cost per request.
6. **Promote stepwise.** 25%, then 50%, then 100%, with analysis passing at every step.
7. **Rollback.** Any failing check sets green's weight to 0% instantly, and blue is still warm.

**The one idea to keep:** for models, "healthy" means *quality* and cost, not just HTTP 200. Automate those checks and keep blue warm until the end.

## Minimal hands-on — Gateway API traffic split

```yaml
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata: { name: assistant, namespace: ai }
spec:
  parentRefs: [{ name: ai-gateway }]
  rules:
  - backendRefs:
    - { name: assistant-blue,  port: 8000, weight: 90 }    # model v11
    - { name: assistant-green, port: 8000, weight: 10 }    # model v12
```

Automate the progression with **Argo Rollouts** or **Flagger** and an `AnalysisTemplate` that queries Prometheus:

```yaml
metrics:
- name: thumbs-down-rate
  successCondition: result[0] < 0.05
  provider: { prometheus: { query: 'sum(rate(feedback_negative{version="green"}[10m])) / sum(rate(feedback_total{version="green"}[10m]))' } }
```

## Worked example

**Scenario:** A bank upgrades its customer-assistant from v11 to v12 (a new fine-tune that improves mortgage answers).

| Phase | Traffic | Duration | Gate | Result |
|---|---|---|---|---|
| Offline eval | 0% | — | 2,400-case suite ≥ v11 on all categories | ✅ +4% mortgage, −0.5% cards |
| Shadow | 100% mirrored (PII-masked logs) | 24 h | LLM-judge parity ≥ 95%, no safety flags | ✅ |
| Canary | 5% | 4 h | Thumbs-down < 5%, TTFT p95 < 600 ms, cost/req < +10% | ✅ |
| Canary | 25% → 50% | 12 h | Same + escalation rate ≤ blue | ⚠️ Escalations +8% on "card disputes" |
| Rollback | 0% green | **20 s** (weight flip) | Auto, by analysis failure | Blue still warm |

Fix: add card-dispute examples to the training data, then v12.1 passes. Without blue staying warm, the rollback
would have meant reloading 140 GB of weights, about 6+ minutes of degraded service.

## Production deep dive
- **Warm standby cost:** Blue/green doubles GPUs for hours. Mitigate with canary at small scale and scale blue down only after green holds 100% for N hours.
- **Sticky sessions:** Keep a conversation on one model version (hash on session id). Switching mid-chat confuses users and breaks KV reuse.
- **Version everywhere:** Response headers and logs include the model version, which is required for incident analysis and audits (Lab 44).
- **Multi-LoRA:** Adapter updates can canary *within* the same replicas by routing a percentage to `adapter@v4` vs. `adapter@v3` (Lab 45).
- **Change management:** Promotions require registry approval tags. In regulated contexts, record who approved each traffic step.

## FAANG deep-dive notes

- **How big tech does it:** Model launches go through offline evals, shadow traffic, staged canaries with quality metrics, and A/B tests for business impact. Rollback is a config change.
- **Staff review questions:** Which quality metric gates the canary? Is the old version still warm? Are sessions sticky to one version?
- **Interview question:** *"How would you safely roll out a new LLM version?"* Strong answers cover offline eval, shadow, canary with quality + latency + cost gates, sticky sessions, instant rollback, and changing one variable at a time.

**Typical system-design prompt:** *"Design zero-downtime model updates for an LLM assistant used by 2 million employees, with weekly model releases."*

**1. Clarify first:**
- Which quality signals are available online (thumbs, retries, escalations) and offline (evals)?
- Capacity headroom: can you run blue and green at full size simultaneously?
- Sticky behaviour: should one conversation stay on one model version?

**2. Back-of-envelope sizing:**
- Full blue/green doubles GPUs during rollout. 40 GPUs × 2 × 6 hours ≈ 240 extra GPU-hours ≈ $720 per release, cheap insurance.
- Detecting a 1-point thumbs-down increase (5% → 6%) with confidence needs ~10k rated responses per arm. At 2% rating rate, that's ~500k requests, so plan hours per canary step.
- Rollback time: weight change < 5 seconds, with blue warm.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Strategy | blue/green (full switch) | canary (gradual) | canary with blue kept warm |
| Capacity | 2× during rollout | surge in steps | full 2× for large changes |
| Stickiness | per request | per conversation | per conversation (header or cookie) |
| Gates | errors/latency | + quality + cost + safety | include quality and safety |
| Pre-live | none | shadow traffic | shadow for major model changes |

**4. Follow-up questions with crisp answers:**
- *Why shadow traffic?* It tests the new model on real prompts with zero user impact.
- *Why sticky conversations?* Switching models mid-conversation changes tone and context handling, which confuses users.
- *How do you detect quality regressions fast?* Online LLM-judge sampling on canary traffic, plus refusal and length shifts as early proxies.
- *What about KV and prefix caches?* Green starts cold, so warm it with representative prompts before taking traffic.
- *How do you roll back?* Weight to 0% at the gateway, with blue still running. Then revert the alias in Git.
- *When can blue be deleted?* After a bake period at 100% (e.g. 24 hours) with no regression.

**Debug this (common onsite question):** *"A new model passed all canary gates, but two days after 100% rollout, legal escalations doubled."*
1. Canary gates checked errors, latency, and thumbs-down, which were all fine.
2. Legal escalations come from a small user segment (contract questions) with low traffic during the canary window.
3. The new model hedges less on legal advice, a safety regression not covered by any gate.
4. Fix: add segment-level and safety evals (policy classifier on sampled outputs) to the analysis, extend the bake period, and keep blue available for a fast revert.

The lesson: **gates only catch what they measure. Include safety and segment-level checks for high-risk domains.**

**5. What separates senior from staff answers:**
- Senior: implements weighted canaries with automated rollback on errors and latency.
- Staff: designs quality, safety, and cost gates with statistical power, segment-aware analysis, stickiness, capacity planning for 2×, and a bake-and-retire policy.

**Red flags:** HTTP-only health gates for models, cold green pods taking traffic, no stickiness, deleting blue right after the switch.

## Failure modes
- Only HTTP health gates in place: the new model returns 200 OK with confidently wrong answers.
- Readiness probe passes before the model is warmed up, so the first users get 30 s TTFT. Warm up with synthetic requests first.
- Prompt template changed alongside the model, so you can't tell which caused the regression. Change one thing at a time.

## Checklist
- [ ] Weighted traffic split between two model versions
- [ ] An automated analysis gate uses at least one quality metric
- [ ] Rollback measured (seconds, not minutes)
