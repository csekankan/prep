# Lab 45: Multi-LoRA Architecture — Serving Adapters Dynamically (3:50)

## Why it matters
Enterprises want a model fine-tuned for *each* department, customer, or language. 100 full
fine-tunes of an 8B model is 100 × 16 GB of weights on 100 GPUs. With **LoRA**, it is one base
model plus 100 adapters of ~20–200 MB each, served from the **same GPU**.

## In plain words
The base model is a **shared car**, and LoRA adapters are **personal seat-and-mirror settings**. Instead of buying 350 cars for 350
customers, you keep one car and apply each customer's tiny settings file on the fly, even for several customers in the same trip (batch).

## Architecture at a glance

```mermaid
flowchart LR
  R1[tenant A] & R2[tenant B] & R3[tenant C] --> GW["Gateway: JWT tenant → adapter"]
  GW --> V[vLLM replica]
  subgraph V_inner["One GPU"]
    BASE[(Base model weights)]
    HOT["Hot adapters A, B"]
  end
  V --> V_inner
  CPU[(CPU adapter cache)] -->|load on demand| HOT
  S3[(Adapter registry)] --> CPU
```

**How to read it:** Requests from different tenants pass through a gateway that maps each tenant to its adapter. One GPU holds the base model plus hot adapters, and colder adapters load from CPU or the registry on demand.

## Core concepts

**LoRA:** Freeze the base weights `W` and learn a low-rank update `ΔW = B·A` (rank r = 8–64).
The adapter is roughly 0.1–1% of model size.

**Multi-LoRA serving (S-LoRA / Punica-style):**
- The base model is loaded once.
- Adapters live in GPU memory (hot), CPU (warm), or disk/S3 (cold).
- **Requests for different adapters are batched together.** Custom kernels (SGMV/BGMV) apply each request's adapter within one batch.

```
Batch: [req1→adapter "legal"] [req2→"hr"] [req3→base] [req4→"legal"]
        ─────────── single forward pass on shared base weights ───────────
        + per-row LoRA delta (SGMV kernel)
```

| Setting (vLLM) | Meaning |
|---|---|
| `--enable-lora` | Turn on |
| `--max-loras 16` | Adapters resident on the GPU at once |
| `--max-cpu-loras 128` | Adapter LRU cache in CPU |
| `--max-lora-rank 64` | Upper bound on rank |
| Dynamic load API | `POST /v1/load_lora_adapter` (when runtime updating is enabled) |

## Architecture in depth

The overview shows tenants mapped to adapters. This view follows **one batch with mixed adapters** through a decode step, which shows
how one GPU serves many tenants at once.

```mermaid
flowchart TB
  subgraph Batch["One decode step: 4 requests, 3 adapters"]
    R1["req 1 → adapter A"]
    R2["req 2 → adapter B"]
    R3["req 3 → adapter A"]
    R4["req 4 → base only"]
  end
  Batch --> BASE["Base weights W: one big GEMM for all 4"]
  Batch --> LORA["Segmented LoRA kernel (Punica / SGMV):<br/>x·A·B per request's adapter"]
  BASE --> ADD[Add: W·x + B·A·x]
  LORA --> ADD
  ADD --> OUT[Next tokens for all 4]
  subgraph Slots["GPU adapter slots (max_loras = 8)"]
    SA[A] & SB[B] & SE[empty]
  end
  CPU[(CPU cache: 200 adapters)] -->|"load miss ~50 ms"| Slots
  Slots -.LRU evict.-> CPU
```

### Follow one decode step for four tenants
1. **Mixed batch.** The scheduler batches requests regardless of adapter. Requests 1 and 3 use adapter A, request 2 uses B, and request 4 uses the base model.
2. **Shared base compute.** The big base-model matrix multiply runs once for the whole batch. This is most of the work.
3. **Per-request deltas.** A special kernel applies each request's small LoRA matrices (A and B, rank 16) in one launch.
4. **Combine.** Base output plus adapter delta gives each request's result.
5. **Slots.** Only `max_loras` adapters can be active in GPU memory at once. Others wait in the CPU cache.
6. **Load on miss.** A request for a cold adapter triggers a load (~tens of ms), and the least recently used adapter is evicted.
7. **Registry.** New adapters are published to the registry and loaded on demand, with no restart.

**The one idea to keep:** the base model is shared work and adapters are cheap deltas, so hundreds of fine-tunes cost about one deployment.

## Minimal hands-on

```bash
vllm serve meta-llama/Llama-3.1-8B-Instruct --enable-lora --max-loras 16 --max-lora-rank 32 \
  --lora-modules legal=s3://adapters/legal/v3 hr=s3://adapters/hr/v1
```

```python
client.chat.completions.create(model="legal", messages=[...])   # adapter selected by model name
client.chat.completions.create(model="meta-llama/Llama-3.1-8B-Instruct", messages=[...])  # base
```

## Worked example

**Scenario:** A B2B SaaS has **350 enterprise customers**, each wanting a model tuned on their tone, product
catalog, and policies.

| Design | GPUs | Monthly cost | Onboarding a new customer |
|---|---|---|---|
| Full fine-tune per customer | ~350 (most idle) | $$$$ | Days, new deployment |
| Dedicated replica per top-10, shared for the rest | ~40 | $$$ | Hours |
| **Multi-LoRA on shared base (8 replicas)** | **16** | $ | **Minutes** (upload adapter, register) |

Routing: the gateway maps `tenant_id` to its adapter name (Lab 46). Adapter popularity follows a power law.
The top 16 stay hot on the GPU and the long tail loads from CPU in ~50 ms on the first request.

## Production deep dive
- **Tenant isolation:** One tenant's adapter must never be selectable by another. Enforce the adapter↔tenant mapping at the gateway from JWT claims, never from the client-supplied `model` field alone.
- **Adapter registry:** Version adapters in MLflow (Lab 44) with base-model compatibility metadata. A LoRA trained on base v3.1 is invalid on v3.2.
- **Affinity routing:** Route each adapter's traffic preferentially to replicas where it's already hot (consistent hashing on adapter id) to minimize swaps.
- **Eval per adapter:** Automated eval before activation, because a bad adapter is a bad model.
- **Limits:** Very high-rank adapters or heavy per-tenant traffic may justify a merged dedicated model. Track per-adapter tokens/s.

## FAANG deep-dive notes

- **How big tech does it:** Per-customer customization uses adapters on shared base models, with strict tenant-to-adapter enforcement and adapter-affinity routing.
- **Staff review questions:** How do you prevent a tenant selecting another tenant's adapter? What happens on a base-model upgrade? What is the swap latency?
- **Interview question:** *"Offer a fine-tuned model to each of 1,000 customers."* Strong answers cover multi-LoRA serving, adapter caching tiers, affinity routing, isolation, per-adapter evals, and cost math.

**Typical system-design prompt:** *"Serve custom fine-tunes for 500 enterprise customers on a single base model, each with tenant isolation."*

**1. Clarify first:**
- Adapter rank and target modules (size per adapter).
- Traffic distribution across tenants (long tail?).
- Isolation requirements: may tenants share a GPU batch?

**2. Back-of-envelope sizing:**
- Rank-16 LoRA on a 70B model's attention projections ≈ 100–200 MB per adapter. 500 adapters ≈ 75 GB, so not all fit on a GPU, but they fit easily in CPU RAM.
- Traffic: if 20 tenants make 80% of requests, keep those hot (`max_loras` ~ 16–32) and load the rest on demand.
- Alternative: 500 full fine-tunes × 140 GB = 70 TB and 500 deployments. Adapters cost about 1,000× less.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Customization | full fine-tune per tenant | LoRA adapters | LoRA unless quality demands full |
| Placement | every adapter on every replica | adapter-affinity routing | affinity for many adapters |
| Hot set | large `max_loras` | small + fast loading | sized to hot tenants; bigger slots cost KV memory |
| Isolation | shared batches | dedicated replicas for top-tier tenants | dedicated only when contracts require it |
| Rank | high (64) | low (8–16) | lowest rank that meets quality |

**4. Follow-up questions with crisp answers:**
- *Why can different adapters share a batch?* The base computation is identical, and only the small delta differs per request.
- *What's the cost of more adapter slots?* GPU memory taken from the KV cache, and slightly slower kernels.
- *How do you route?* Gateway maps tenant to adapter, and the router prefers replicas where that adapter is already hot.
- *Is a shared batch a data-leak risk?* Requests are computed independently, but contracts may still require dedicated pools.
- *How do you version adapters?* In the registry (Lab 44), tied to the base model version, which must match exactly.
- *What happens when the base model upgrades?* All adapters must be retrained or re-validated, so plan migration waves.

**Debug this (common onsite question):** *"Tenant X reports 2-second latency spikes several times a minute; others are fine."*
1. Logs show adapter X being loaded repeatedly, then evicted.
2. `max_loras` is 8, but 12 active tenants are hitting the replica, so adapters thrash in and out.
3. The router spreads tenant X across all replicas, so each replica has to load the adapter.
4. Fix: adapter-affinity routing (each tenant goes to a subset of replicas), size `max_loras` to the hot set, and alert on adapter load rate.

The lesson: **adapters thrash like any cache. Route for affinity and size the hot set.**

**5. What separates senior from staff answers:**
- Senior: enables multi-LoRA, sets slots and ranks, maps tenants at the gateway.
- Staff: designs affinity routing, hot-set sizing from traffic data, isolation tiers by contract, and base-model upgrade migrations.

**Red flags:** full fine-tunes per tenant, random routing with many adapters, base/adapter version mismatch, no adapter load metrics.

## Failure modes
- Too many hot adapters (`max-loras`) eat KV cache memory and reduce concurrency.
- Adapter thrashing when traffic spreads uniformly over hundreds of adapters across all replicas.
- Base model upgraded while old adapters still deployed produces garbage outputs.

## Checklist
- [ ] Two adapters plus the base served from one vLLM instance
- [ ] Tenant→adapter enforcement happens at the gateway
- [ ] Adapter compatibility metadata is stored in the registry
