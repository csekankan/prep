# Lab 42: Memory Orchestration for Hyper-Scale Inference (4:17)

## Why it matters
In LLM serving, **GPU memory is the hard constraint**. It decides how many users fit, how long
contexts can be, and how many GPUs you buy. The weights are a fixed cost. The **KV cache scales
with every user and every token**.

## In plain words
GPU memory is a **hotel**. The model's weights are permanent residents who never leave. Every user conversation is a guest needing a
room (the KV cache), and long conversations need suites. Quantization makes rooms smaller, offloading moves sleeping guests to the
annex (CPU/NVMe), and splitting prefill and decode puts check-in and long stays in different buildings.

## Architecture at a glance

```mermaid
flowchart LR
  subgraph VRAM["GPU VRAM budget"]
    W["Weights: fixed"] --- KV["KV cache: grows per user × tokens"] --- WS["Workspace / CUDA graphs"]
  end
  KV -->|cold sessions| CPU[(CPU DRAM tier)]
  CPU -->|colder| NV[(NVMe tier)]
  PF[Prefill pool: compute-heavy] -->|ship KV| DEC[Decode pool: bandwidth-heavy]
```

**How to read it:** The top box is the fixed VRAM budget. KV cache spills to CPU and then NVMe tiers. The bottom shows prefill and decode split into separate pools that hand off KV.

## Core concepts — the VRAM budget

```
VRAM = weights + activations(peak) + KV cache + CUDA graphs/workspace + fragmentation
```

| Lever | Saves | Trade-off |
|---|---|---|
| **Weight quantization** (FP8, INT4 AWQ/GPTQ) | 2–4× weights | Small accuracy loss; validate |
| **KV cache quantization** (FP8 KV) | 2× KV | Minor quality impact |
| **GQA/MQA models** (fewer KV heads) | 4–8× KV vs. MHA | Model choice |
| **PagedAttention** | No fragmentation | Default in vLLM |
| **Max context cap** | Avoids reserving huge sequences | Product limit |
| **Tensor parallel** | Splits weights + KV across GPUs | Comm overhead, NVLink needed |
| **KV offload to CPU/NVMe** (LMCache) | Huge cache capacity | Bandwidth/latency |
| **Disaggregated prefill/decode** | Separate pools optimized per phase | Complexity, KV transfer |

**Disaggregated serving:** Prefill is compute-bound and decode is memory-bandwidth-bound. Running them
on separate GPU pools (with the KV transferred over NVLink/RDMA) improves both TTFT and TPOT under load.
NVIDIA Dynamo, llm-d, and vLLM disaggregated prefill implement this.

## Architecture in depth

The overview shows the VRAM budget and memory tiers. This view follows **one long-context request** through disaggregated serving,
where prefill and decode run on different GPU pools.

```mermaid
sequenceDiagram
  participant R as Router
  participant P as Prefill pool (compute-heavy)
  participant X as KV transfer (NIXL / RDMA)
  participant D as Decode pool (memory-heavy)
  participant T as KV tiers (CPU / NVMe)
  R->>P: 32k-token prompt
  P->>P: compute all prompt tokens in parallel (~1.5 s)
  P->>X: KV blocks (~10 GB for 70B)
  X->>D: write into decode GPU memory
  D->>D: generate tokens one by one (memory-bound)
  D-->>R: stream tokens
  D->>T: idle session → offload KV
  T->>D: user returns → fetch KV, no re-prefill
```

### Follow one 32k-token request
1. **Route.** The router knows prefill and decode are separate pools and sends the prompt to a prefill GPU.
2. **Prefill.** The whole prompt is processed in parallel. This is compute-bound, needing high FLOPs.
3. **Transfer.** The resulting KV cache, about 10 GB for a 70B model at 32k tokens, moves over RDMA to a decode GPU.
4. **Decode.** Tokens are generated one at a time. This is memory-bandwidth bound: each step reads all weights plus the KV cache.
5. **Isolation.** Long prefills no longer stall other users' decode steps, which keeps TPOT smooth.
6. **Offload.** When the session goes idle, its KV moves to CPU RAM or NVMe instead of being discarded.
7. **Return.** On the next turn, the KV is fetched back, skipping a multi-second re-prefill.

**The one idea to keep:** prefill and decode need different hardware traits. Splitting them, and tiering KV memory, is how large-scale inference is run.

## Minimal hands-on

```bash
vllm serve meta-llama/Llama-3.1-70B-Instruct \
  --tensor-parallel-size 2 \
  --quantization fp8 --kv-cache-dtype fp8 \
  --max-model-len 16384 --gpu-memory-utilization 0.92 \
  --enable-chunked-prefill --max-num-batched-tokens 8192
```

Watch: `vllm:gpu_cache_usage_perc`, `vllm:num_preemptions_total` (preemptions mean the KV cache is too small).

## Worked example

**Scenario:** A legal research tool. Llama-70B, 32k-token contexts (long contracts), 200 concurrent users.

KV/token for 70B (80 layers, 8 KV heads, 128 dim): 2 × 80 × 8 × 128 × 2 B = **320 KB** (BF16).
One 32k sequence needs ~10 GB, so 200 users need **~2 TB of KV**. That is impossible on a few GPUs.

Design:
1. FP8 KV halves it to ~1 TB.
2. **Prefix caching:** 70% of each prompt is the same 20k-token contract set per matter, so the effective unique KV is ~35%, around **350 GB**.
3. **LMCache CPU/NVMe offload** holds cold sessions and frees HBM for active decode.
4. Deployment: 6 replicas × TP=2 on H200 (141 GB) gives ~1.2 TB of HBM in total, with offload covering bursts.

That is 12 H200s instead of the ~40 H100s a naive design needs.

## Production deep dive
- **Admission control:** When the KV cache is full, queue at the gateway instead of letting the engine preempt and recompute (preemption wastes compute and inflates latency).
- **Context-length tiers:** Separate pools for ≤ 8k (the high-concurrency majority) and long context (32k–128k). Route by prompt length (Lab 46).
- **Chunked prefill:** Prevents one giant prompt from stalling all decodes. It is essential for mixed workloads.
- **Memory headroom:** Leave 5–8% of VRAM for CUDA graphs and fragmentation. 0.98 utilization OOMs under spikes.
- **Hardware choice:** For KV-heavy (long context) workloads, H200/MI300X/B200 memory capacity often beats raw FLOPs.

## FAANG deep-dive notes

- **How big tech does it:** Disaggregated prefill/decode, multi-tier KV caches, and admission control are standard at scale. Context-length tiers keep long prompts from hurting everyone else.
- **Staff review questions:** What is the KV per token, and the max concurrency on paper vs. measured? What happens when the cache is full: queue or preempt? Are preemptions alerted?
- **Interview question:** *"Long-context requests are destroying latency for everyone. Fix it."* Strong answers cover chunked prefill, context-length routing, separate pools, KV quantization, offload, and admission control.

**Typical system-design prompt:** *"Serve a 70B model to 5,000 concurrent users with 16k-token average contexts. Size the GPUs."*

**1. Clarify first:**
- TTFT and TPOT SLOs.
- Context length distribution (average vs. p99).
- Session behaviour: multi-turn with idle gaps?

**2. Back-of-envelope sizing:**
- KV per token (70B with GQA, 80 layers × 8 KV heads × 128 dim × 2 (K, V) × 2 bytes) ≈ 320 KB/token.
- 16k tokens × 320 KB ≈ 5 GB per user. 5,000 users would need 25 TB of KV if all were active at once.
- If only 20% are generating at once: 1,000 × 5 GB = 5 TB of hot KV. On H200s (141 GB, ~70 GB for weights at FP8 with TP=2), there's ~70 GB per GPU pair left for KV, so ~70 pairs ≈ 140 GPUs. Idle sessions sit in CPU/NVMe tiers.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Architecture | colocated prefill + decode | disaggregated | disaggregate at scale with long prompts |
| KV precision | FP16 | FP8 KV | FP8 KV halves memory with small quality impact |
| Idle sessions | evict, re-prefill | offload to CPU/NVMe | offload when re-prefill > fetch time |
| Weights | FP16 | FP8 / INT4 | FP8 on Hopper+ after evaluation |
| Long-context limit | serve all | route long contexts to a special pool | separate pools by context class |

**4. Follow-up questions with crisp answers:**
- *Why is decode memory-bound?* Each token needs reading all weights and the KV cache, while compute per byte is tiny.
- *What does GQA buy?* Fewer KV heads, so 4–8× less KV memory than full multi-head attention.
- *When is disaggregation worth it?* When long prefills hurt decode latency and the volume justifies separate pools.
- *What's the cost of KV transfer?* ~10 GB over 400 Gb/s RDMA ≈ 0.2 s, worth it versus a 1.5 s prefill interference.
- *Why offload instead of recomputing?* Fetching 5 GB from CPU takes ~0.2 s, while re-prefilling 16k tokens takes ~1 s+.
- *What's the first thing that runs out?* KV memory, almost always, not compute.

**Debug this (common onsite question):** *"TPOT p99 jumps from 40 ms to 400 ms whenever a few users paste huge documents."*
1. The deployment is colocated: a 100k-token prefill occupies the GPU for seconds.
2. Decode steps for all other users wait behind the prefill chunks.
3. Chunked prefill is disabled, so the whole prefill runs at once.
4. Fix: enable chunked prefill (interleaving prefill chunks with decode), route very long prompts to a dedicated pool, and at scale disaggregate prefill and decode.

The lesson: **long prompts are noisy neighbours. Bound their impact with chunking, separate pools, or disaggregation.**

**5. What separates senior from staff answers:**
- Senior: computes KV per token and sets memory utilization and max sequence length.
- Staff: sizes the fleet from concurrency and context distributions, designs tiered KV memory and disaggregation, and separates pools by context class to protect SLOs.

**Red flags:** sizing by weights only, no long-context policy, colocated serving with unbounded prefills, discarding KV for multi-turn chat.

## Failure modes
- Rising preemption counts cause TPOT to spike. Users see stalls mid-response.
- Quantizing without evaluation silently costs ~3% accuracy on domain tasks.
- A single pool for 1k and 100k contexts lets long prompts starve everyone.

## Checklist
- [ ] You can calculate KV memory per token for your model
- [ ] Preemptions are monitored and alerted
- [ ] A context-length tiering decision is made
