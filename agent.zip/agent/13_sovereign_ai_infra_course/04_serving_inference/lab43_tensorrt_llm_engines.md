# Lab 43: Compiling Engines with TensorRT-LLM (4:01)

## Why it matters
Generic PyTorch execution leaves performance on the table. **TensorRT-LLM** compiles a model into an
engine fused for a *specific GPU, precision, and shape range*. That typically gives 1.3–2× more throughput
than general engines on NVIDIA hardware, and it enables FP8/FP4 on Hopper/Blackwell.

## In plain words
A regular engine is **ready-to-wear clothing**: fits everyone reasonably. TensorRT-LLM is a **tailored suit** made for one exact GPU
and size: faster and more efficient, but it must be re-tailored if you change GPU or measurements (sequence length, batch).

## Architecture at a glance

```mermaid
flowchart LR
  HF[HF checkpoint] --> QZ["Quantize FP8 + calibrate"]
  QZ --> BLD["trtllm-build for H100"]
  BLD --> EV{Eval + perf gates}
  EV -->|pass| REG[(Registry: engine + GPU + version)]
  EV -->|fail| X[Reject]
  REG --> SRV[trtllm-serve / Triton]
```

**How to read it:** Follow the pipeline: quantize, build an engine for a specific GPU, pass eval and performance gates, store it with metadata, then serve.

## Core concepts

| Optimization | Effect |
|---|---|
| Kernel fusion (attention, GEMM+activation) | Fewer memory round-trips |
| FP8 / FP4 (NVFP4 on Blackwell) / INT4-AWQ | Smaller and faster with Tensor Core paths |
| In-flight batching | Equivalent to continuous batching |
| Paged KV cache, KV reuse | Like vLLM |
| CUDA graphs | Removes launch overhead for decode |
| Plugins | Custom attention kernels (XQA, FMHA) |

**The trade-off:** Engines are **hardware- and config-specific**. An engine built on H100 won't run on L40S.
Changing max batch or sequence length may need a rebuild. The PyTorch-backend workflow in recent TRT-LLM versions reduces this friction.

## Architecture in depth

The overview shows the build pipeline. This view looks **inside the engine build**: what TensorRT-LLM changes in the model, and why
the engine is tied to one GPU type and configuration.

```mermaid
flowchart TB
  HF["HF checkpoint (bf16)"] --> CONV["Convert to TRT-LLM checkpoint<br/>apply TP/PP split"]
  CONV --> QUANT["Quantize: FP8 weights + FP8 KV<br/>calibrate on 512 real samples"]
  QUANT --> BUILD["trtllm-build"]
  subgraph BUILD_IN["What the builder does"]
    FUSE["Fuse kernels: attention, GEMM + activation"]
    PLUG["Select plugins: paged KV, GEMM, all-reduce"]
    TUNE["Autotune kernels for this GPU"]
    LIM["Fix limits: max batch, max input, max tokens"]
  end
  BUILD --> BUILD_IN --> ENG["Engine files<br/>valid only for: H100 × TP2 × these limits"]
  ENG --> GATE{"Eval: quality Δ ≤ 0.5%<br/>Perf: tokens/s ≥ target"}
```

### Follow one model from checkpoint to engine
1. **Convert.** The Hugging Face weights are reshaped into TRT-LLM's format and split for tensor parallelism (e.g. TP=2).
2. **Quantize.** Weights and KV are converted to FP8, with calibration on real prompts to set the scaling factors.
3. **Fuse.** The builder merges small operations into large kernels, so fewer GPU launches and fewer memory round trips.
4. **Plugins.** Optimized implementations are chosen for attention with paged KV, GEMMs, and multi-GPU all-reduce.
5. **Autotune.** For each layer, the builder times kernel options on *this* GPU and picks the fastest.
6. **Fix limits.** Max batch size, input length, and token counts are baked in, which sets memory plans ahead of time.
7. **Gate.** The engine ships only if quality and throughput gates pass.

**The one idea to keep:** an engine is compiled for one GPU type, parallel layout, and limit set. Treat it like a binary with a target platform.

## Minimal hands-on

```bash
# 1) Quantize checkpoint to FP8 (calibration on sample data)
python quantize.py --model_dir Llama-3.1-8B --qformat fp8 --output_dir ckpt_fp8

# 2) Build engine
trtllm-build --checkpoint_dir ckpt_fp8 --output_dir engine_h100_fp8 \
  --max_batch_size 128 --max_input_len 8192 --max_seq_len 12288 \
  --gemm_plugin auto --use_paged_context_fmha enable

# 3) Serve (OpenAI-compatible)
trtllm-serve engine_h100_fp8 --tokenizer Llama-3.1-8B --port 8000
```

Or deploy through Triton's `tensorrtllm` backend, or use **NVIDIA NIM**, which ships prebuilt optimized engines.

## Worked example

**Scenario:** A telco's customer-care bot runs Llama-3.1-8B. Peak load is 1,500 req/s. On vLLM BF16 it needs
**48 H100s**. Leadership asks for a cost-down.

| Step | Throughput/GPU | GPUs |
|---|---|---|
| vLLM BF16 (baseline) | 31 req/s | 48 |
| vLLM FP8 | 46 req/s | 33 |
| **TRT-LLM FP8, tuned batch, CUDA graphs** | 58 req/s | **26** |

Accuracy check: FP8 vs. BF16 on the internal eval set (2k real transcripts) showed a −0.3% intent accuracy difference, which was accepted.
Annual saving: 22 H100s × ~$25k/yr ≈ **$550k**.

The cost: a **CI pipeline** that rebuilds engines per GPU SKU on each model update (Lab 44).

## Production deep dive
- **Build pipeline:** Registry event (new model version) triggers a build job per target GPU (H100, L40S), then an eval gate, a perf gate, and an engine artifact pushed with metadata (GPU, precision, TRT-LLM version).
- **Engine/runtime version lock:** The engine must match the TRT-LLM runtime version exactly. Pin them together in the image tag.
- **When not to compile:** For rapidly iterating research models, or many low-traffic models, the build overhead outweighs the gains. Use vLLM.
- **Vendor lock-in:** TRT-LLM is NVIDIA-only. Keep a vLLM fallback path for AMD/other hardware (Lab 24) and for sovereignty.

## FAANG deep-dive notes

- **How big tech does it:** Compiled or optimized engines are CI artifacts built per hardware SKU, with mandatory accuracy and performance gates before release.
- **Staff review questions:** What accuracy delta did quantization cause, measured on what data? How long does the rebuild pipeline take? What is the fallback runtime?
- **Interview question:** *"Cut inference cost 40% without changing the model."* Strong answers cover quantization (FP8/INT4) with evals, compiled engines, batching tuning, prefix caching, speculative decoding, and right-sized GPUs.

**Typical system-design prompt:** *"Your LLM costs are too high. Should you move from vLLM to TensorRT-LLM? Design the evaluation and the build pipeline."*

**1. Clarify first:**
- Current throughput per GPU and cost per million tokens.
- How often do models change? (Engine rebuild cadence.)
- GPU fleet homogeneity: one type or several?

**2. Back-of-envelope sizing:**
- Typical gain: FP8 + fused kernels give 1.3–2× tokens/s per GPU vs. an un-tuned bf16 baseline. Against tuned vLLM with FP8, the gain is often 10–30%.
- Fleet of 100 GPUs at $3/h = $2.6M/year. A 25% throughput gain ≈ $650k/year, enough to fund a build pipeline.
- Build time: 10–60 minutes per engine × (GPU types × TP configs × models) — the matrix grows fast.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Engine | vLLM / SGLang (flexible) | TRT-LLM (compiled) | TRT-LLM for stable, high-volume models |
| Precision | bf16 | FP8 (Hopper+) / FP4 (Blackwell) | FP8 after evaluation on your tasks |
| Build | on startup | CI pipeline + registry | always prebuilt in CI |
| Fleet | many GPU types | standardized types | fewer types means fewer engines |

**4. Follow-up questions with crisp answers:**
- *Why is the engine GPU-specific?* Kernels are autotuned and compiled for one architecture and its memory layout.
- *What does calibration do?* It measures activation ranges on real data to set quantization scales.
- *What breaks if max input length is too low?* Requests exceeding it are rejected. Set limits from real traffic percentiles.
- *How do you validate quality?* Task-specific evals (not just perplexity) with a regression threshold.
- *What's in-flight batching?* TRT-LLM's continuous batching, which adds and removes requests every step.
- *Where do you store engines?* A registry keyed by model, version, GPU type, TP size, and TRT-LLM version.

**Debug this (common onsite question):** *"The FP8 engine passed benchmarks, but customers report the assistant now gets numbers wrong in invoices."*
1. The quality gate used a generic chat benchmark. Invoice extraction wasn't covered.
2. Calibration used generic web text, so the activation ranges for numeric-heavy prompts were off.
3. The quality loss is concentrated in exactly the bank's main use case.
4. Fix: calibrate on domain samples, add an invoice-extraction eval to the gate, and keep FP8 on layers that tolerate it while some layers stay in bf16.

The lesson: **quantization quality is task-specific. Calibrate and evaluate on your own traffic.**

**5. What separates senior from staff answers:**
- Senior: builds engines, sets limits, runs benchmarks.
- Staff: decides when compilation is worth the operational cost, standardizes GPU types to keep the build matrix small, and owns domain-specific quality gates.

**Red flags:** building engines at pod start, generic-only eval for quantization, an engine matrix nobody tracks, mismatched TRT-LLM versions between build and serve.

## Failure modes
- `max_seq_len` set below real traffic, so long requests are rejected in production.
- Calibration data unrepresentative (e.g. English-only for multilingual traffic) degrades FP8/INT4 quality.
- An engine built on one driver/TRT version deployed to nodes with another crashes on load.

## Checklist
- [ ] An engine built for one GPU SKU and benchmarked against vLLM
- [ ] A quantization eval gate is defined
- [ ] Engine metadata (GPU, precision, versions) is stored in the registry
