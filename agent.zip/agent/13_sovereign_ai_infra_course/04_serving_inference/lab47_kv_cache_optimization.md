# Lab 47: The Memory Architect — KV Cache Optimization and Cross-Node Sharing (4:27)

## Why it matters
Re-computing the same 10k-token system prompt, RAG context, or chat history for every request burns
GPU compute and inflates TTFT. **Reusing KV cache** across requests, and even across nodes, is one of
the biggest wins in modern serving.

## In plain words
If every customer asks a librarian to re-read the same 6,000-page rulebook before answering, the line never moves. **Prefix caching**
means the librarian remembers the rulebook, and **prefix-aware routing** sends you to the librarian who already read it.

## Architecture at a glance

```mermaid
flowchart LR
  REQ["Request: system prompt + docs + question"] --> RT{Router: prefix hash lookup}
  RT -->|has prefix cached| RB["Replica B: compute only new tokens"]
  RT -.cache miss.-> RA["Replica A: full prefill"]
  RB --> HBM[(GPU KV blocks)]
  HBM <-->|offload / fetch| CPU[(CPU / LMCache tier)]
```

**How to read it:** A request's prefix is hashed. The router sends it to the replica that already holds that prefix, which only computes the new tokens. KV blocks can move between GPU memory and CPU tiers.

## Core concepts

| Technique | Scope | Idea |
|---|---|---|
| **Automatic prefix caching** (vLLM APC, SGLang RadixAttention) | One replica | Hash KV blocks by token prefix and reuse on match |
| **Prefix-aware routing** | Cluster | Send requests to the replica that already holds their prefix |
| **KV offload tiers** (LMCache, Mooncake) | Node → cluster | GPU HBM → CPU DRAM → local NVMe → remote store |
| **Cross-node KV sharing** | Cluster | Replicas fetch cached KV from peers over RDMA instead of recomputing |
| **Disaggregated prefill/decode** | Cluster | Prefill pool computes KV and ships it to the decode pool (Lab 42) |

```
Request ─► Router (prefix hash lookup) ─► Replica B has 9k of 10k tokens cached
                                         └─ compute only 1k new tokens → TTFT 2.1s → 0.25s
```

**Cache hit rate** is the metric that matters. Design prompts so that stable content comes **first**
(system prompt, tools, docs) and variable content **last** (user question).

## Architecture in depth

The overview shows prefix-aware routing. This view shows **how prefix caching works inside one engine**, block by block, and how
a shared tier extends it across nodes.

```mermaid
flowchart TB
  REQ["Prompt tokens: [system 2k][docs 6k][question 200]"] --> SPLIT["Split into 16-token blocks"]
  SPLIT --> HASH["Hash chain: h1 = H(block1), h2 = H(h1, block2) ..."]
  HASH --> LOOK{"Look up each hash in GPU block table"}
  LOOK -->|"hits: blocks 1..500"| REUSE["Reuse KV blocks (refcount++)"]
  LOOK -->|"misses: blocks 501..513"| COMP["Compute only these tokens"]
  REUSE & COMP --> ATTN[Attention over all blocks]
  subgraph Tiers["KV storage tiers"]
    GPU["GPU HBM: hot blocks"]
    CPU["CPU DRAM / LMCache: warm"]
    REM["Remote shared cache: cross-node"]
  end
  GPU <-->|"evict / fetch"| CPU <-->|"share"| REM
  LOOK -.miss in GPU.-> CPU
```

### Follow one RAG request through prefix caching
1. **Blocks.** The prompt is divided into fixed blocks of tokens (16 in vLLM).
2. **Hash chain.** Each block's hash includes the previous block's hash, so a block matches only if *everything before it* is identical too.
3. **Look up.** The engine checks which block hashes already exist in GPU memory.
4. **Reuse.** The 8k-token system prompt and documents are hits. Their KV is reused with no compute.
5. **Compute the rest.** Only the 200-token question is prefilled, so TTFT drops from ~1 s to ~60 ms.
6. **Tiers.** Blocks evicted from GPU memory move to CPU or a shared cache (LMCache), so another replica or a later request can fetch them instead of recomputing.
7. **Order matters.** Put stable content first (system prompt, then documents, then question). One changed early token invalidates every later block.

**The one idea to keep:** the cache matches exact prefixes only. Design prompts with stable content first, and route requests to where their prefix lives.

## Minimal hands-on

```bash
vllm serve Qwen/Qwen2.5-32B-Instruct --enable-prefix-caching
# metrics:  vllm:gpu_prefix_cache_hit_rate (or prefix_cache_queries/hits)
```

Prompt structure for cacheability:

```
[SYSTEM PROMPT  — identical for all users]       ← cached
[TOOL DEFINITIONS — identical]                   ← cached
[RAG DOCS for tenant X — identical per tenant]   ← cached per tenant
[CHAT HISTORY — grows, prefix stable]            ← cached up to last turn
[NEW USER MESSAGE]                               ← computed
```

## Worked example

**Scenario:** An agent platform. Every call carries a **6k-token** system prompt plus tool schemas.
Average user input is 300 tokens. 50 req/s on 8 replicas.

| Setup | Prefill tokens/s computed | TTFT p95 | Replicas needed |
|---|---|---|---|
| No caching | 315k | 1.8 s | 8 |
| APC, random routing (hit only when lucky, ~1/8 chance) | ~280k | 1.6 s | 8 |
| **APC + prefix-aware routing** | ~25k | **0.22 s** | **4** |
| + LMCache CPU offload for long chat histories | ~18k | 0.19 s | 4 |

Halving the replica count paid for the routing work in the first week. A prompt engineer once put a
**timestamp at the top of the system prompt**, and the hit rate fell to 0% overnight. Add a CI check for prompt prefix stability.

## Production deep dive
- **Router integration:** The Gateway API Inference Extension, llm-d, NVIDIA Dynamo, and the vLLM production-stack router expose KV-aware routing using block-hash events from engines.
- **Security:** Shared prefix caches across tenants can leak information through timing side channels. Salt cache keys per tenant for sensitive deployments (vLLM supports a `cache_salt`).
- **Capacity:** CPU DRAM is ~10× cheaper per GB than HBM. Size the offload tier for the working set of active sessions.
- **Eviction policy:** LRU by default. Pin truly global prefixes (the system prompt).
- **Observability:** Track hit rate per route and tenant, and alert on sudden drops (usually a prompt change).

## FAANG deep-dive notes

- **How big tech does it:** Prompt or context caching is exposed as a product feature (cheaper cached tokens), backed by KV-aware routing and cache tiers.
- **Staff review questions:** What is your prefix hit rate? Is the prompt template ordered for cacheability? Is the cache isolated per tenant?
- **Interview question:** *"Every agent call includes a 6k-token system prompt. Optimize it."* Strong answers cover prefix caching, stable prompt ordering, prefix-aware routing, cache salting for security, and measuring the hit rate.

**Typical system-design prompt:** *"A RAG product sends 8k tokens of context per request. TTFT is 1.2 s and GPU cost is high. Design KV cache optimization."*

**1. Clarify first:**
- How much of the context is shared across requests (system prompt, popular documents)?
- Multi-turn sessions? How long between turns?
- Number of replicas and how requests are routed today.

**2. Back-of-envelope sizing:**
- 8k-token prefill on a 70B model ≈ 1 s on an H100 pair. With 90% prefix hits, only 800 tokens are computed, ≈ 0.1 s.
- Throughput: prefill work drops ~10×, so the same GPUs serve 2–4× more requests (decode still costs the same).
- Cache capacity: a 2k-token system prompt for 20 products at 320 KB/token ≈ 13 GB, which fits comfortably and saves the most.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Routing | round robin | prefix/session-aware | prefix-aware with load balance |
| Prompt layout | dynamic first | stable first | system → docs → history → question |
| Tiers | GPU only | GPU + CPU + shared | add CPU tier for multi-turn |
| Sharing | per replica | cross-node (LMCache, Mooncake) | share at large scale with RDMA |
| Isolation | global cache | per-tenant salt | salt prefix hashes per tenant |

**4. Follow-up questions with crisp answers:**
- *Why chain hashes?* KV values depend on all previous tokens, so a block is reusable only if the whole prefix matches.
- *Why does round-robin hurt?* Each replica sees a random slice and caches it, so hit rates fall with replica count.
- *Can prefix caching leak data?* Timing side channels can reveal cache hits. Salt per tenant for sensitive deployments.
- *What breaks hit rates?* Timestamps or user names at the start of system prompts.
- *How do you balance affinity with load?* Consistent hashing with bounded load: prefer the cached replica unless it's overloaded.
- *What metrics matter?* Prefix hit rate, TTFT split by hit vs. miss, and eviction rate.

**Debug this (common onsite question):** *"Prefix caching is enabled, but the hit rate is 3%."*
1. Inspect prompts: the system prompt begins with `Current time: 2026-11-12 10:41:07`.
2. Every request has a different first block, so every later block also misses.
3. Even without that, requests are round-robined across 12 replicas.
4. Fix: move dynamic fields to the end of the prompt, add prefix-aware routing, and track hit rate per route. Result: a hit rate of ~85% and TTFT down 6×.

The lesson: **one dynamic token at the start of a prompt disables the whole cache.**

**5. What separates senior from staff answers:**
- Senior: enables prefix caching, fixes prompt layout, adds affinity routing.
- Staff: designs tiered and shared KV across the fleet, tenant isolation for caches, and prompt-template governance, and quantifies GPU savings.

**Red flags:** timestamps at the start of prompts, round-robin routing with prefix caching, a shared cache across tenants without salting, no hit-rate metric.

## Failure modes
- Dynamic content (dates, request IDs, randomized few-shot order) at the start of prompts kills the cache.
- Prefix routing overloads one hot replica. Combine prefix affinity with load-aware limits.
- Offloading KV over a slow network costs more than recomputing. Measure the break-even point.

## Checklist
- [ ] Prefix cache hit rate is measured
- [ ] Prompt template is ordered stable → variable, with a CI check
- [ ] Prefix-aware routing evaluated against round-robin
