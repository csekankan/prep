# Lab 46: Semantic Routing — Directing Prompts by Intent (4:14)

## Why it matters
Sending every prompt to your biggest model is like sending every email by courier. **60–80% of
enterprise traffic is simple** (FAQ, classification, short rewrites) and a small model handles it at
1/10th the cost. A semantic router picks the right model per request.

## In plain words
A hospital doesn't send every patient to the top surgeon. A **triage nurse** looks at each case: a cold goes to the GP, surgery goes to
the specialist. The semantic router is that nurse for prompts, so easy questions go to cheap fast models and hard ones to big models.

## Core concepts

```mermaid
flowchart LR
  Q[Prompt] --> E[Embed prompt<br/>small encoder ~5ms]
  E --> C{Classify intent<br/>nearest route centroid}
  C -->|simple FAQ| S[8B model]
  C -->|code| K[Coder model]
  C -->|complex reasoning| L[70B / frontier]
  C -->|PII / restricted| SOV[Sovereign on-prem only]
  C -->|off-topic / jailbreak| B[Block / canned reply]
```

**How to read it:** The prompt is embedded, compared with route examples, then sent down one branch: small model, coder, large model, sovereign model, or blocked.

| Routing signal | Example |
|---|---|
| **Intent** (embedding similarity to labeled examples) | "reset password" → FAQ route |
| **Complexity** (classifier / LLM-as-judge on a sample) | Multi-step math → large model |
| **Data sensitivity** (PII detector) | Contains patient ID → on-prem model (Lab 65) |
| **Context length** | > 32k tokens → long-context pool (Lab 42) |
| **Tenant / tier** | Premium tier → best model |
| **Cost/latency budget** | Real-time voice → fastest model |

Implementations: vLLM Semantic Router, semantic-router (Aurelio), RouteLLM, Envoy AI Gateway, or a custom router.

## Architecture in depth

The concepts section explains intent classes and embeddings. This view shows the **router as a production service**: the
decision cascade, from cheapest to most expensive check, and the feedback loop that keeps it accurate.

```mermaid
flowchart LR
  P[Prompt] --> RULES{"(1) Rules: regex, tenant policy, PII flag<br/>~0.1 ms"}
  RULES -->|"match"| DEST
  RULES -->|"no match"| EMB["(2) Embed prompt (small model)<br/>~3 ms"]
  EMB --> KNN{"(3) Nearest intent centroids<br/>similarity ≥ 0.82?"}
  KNN -->|"confident"| DEST
  KNN -->|"unsure"| CLS["(4) Small LLM classifier<br/>~80 ms"]
  CLS --> DEST{Destination}
  DEST --> M1["Small model: FAQ, chit-chat"]
  DEST --> M2["Large model: reasoning, code"]
  DEST --> M3["Sovereign on-prem model: sensitive data"]
  M1 & M2 & M3 --> FB[(Feedback: thumbs, escalations, eval samples)]
  FB -.retrain centroids + thresholds weekly.-> KNN
```

### Follow one prompt through the router
1. **Rules first.** Cheap deterministic checks handle the clear cases. Sensitive data detected always goes to the sovereign on-prem model, whatever the intent.
2. **Embed.** A small embedding model turns the prompt into a vector in a few milliseconds.
3. **Nearest intent.** The vector is compared with stored centroids for each intent (FAQ, code, legal...). If similarity clears the threshold, route.
4. **Fallback classifier.** Ambiguous prompts go to a small LLM classifier. That's slower, but only a minority of traffic needs it.
5. **Dispatch.** The chosen backend serves the request: small model, large model, or sovereign model.
6. **Feedback.** Thumbs-down, escalations, and sampled evals reveal misroutes.
7. **Retrain.** Centroids and thresholds are refreshed weekly from labelled misroutes.

**The one idea to keep:** route with a cascade (cheap checks first, expensive only when unsure), and measure misroutes or the savings turn into quality loss.

## Minimal hands-on

```python
import numpy as np
from sentence_transformers import SentenceTransformer

enc = SentenceTransformer("BAAI/bge-small-en-v1.5")
routes = {
    "faq-8b":    ["how do I reset my password", "what are your opening hours"],
    "coder":     ["write a python function", "fix this stack trace"],
    "reason-70b":["compare these two contracts and list risks", "plan a migration strategy"],
}
centroids = {r: enc.encode(ex, normalize_embeddings=True).mean(0) for r, ex in routes.items()}

def route(prompt, threshold=0.55, default="reason-70b"):
    v = enc.encode(prompt, normalize_embeddings=True)
    best, score = max(((r, float(v @ c)) for r, c in centroids.items()), key=lambda x: x[1])
    return best if score >= threshold else default      # uncertain → safest/strongest
```

## Worked example

**Scenario:** An internal enterprise assistant handles 2M requests/month, all sent to a 70B model.

| Route | Share | Model | Cost per 1k req |
|---|---|---|---|
| FAQ / HR policy | 55% | 8B | $0.20 |
| Code help | 15% | 32B coder | $0.90 |
| Complex analysis | 25% | 70B | $2.50 |
| Blocked / off-topic | 5% | none | $0 |

Blended cost went from $2.50 to **~$0.87 per 1k requests (−65%)**. Quality held: on a 1,000-prompt
human-rated set, the router's pick matched or beat 70B-only answers 96% of the time. The 4% of misroutes
were mostly borderline complexity, so the threshold was tuned to send uncertain cases to 70B.

## Production deep dive
- **Fail-safe defaults:** On low confidence, route to the *safer* option (bigger model, or the sovereign model for sensitive data). Misrouting PII to an external API is a compliance incident, not a quality bug.
- **Feedback loop:** Log route decisions with outcomes (thumbs, escalations). Retrain route examples monthly.
- **Latency budget:** The router must add < 10–20 ms. Run the encoder on CPU or a MIG slice (Lab 23), and cache embeddings for repeated prompts.
- **Cascade pattern:** Try the small model first and escalate if self-confidence or a verifier fails. That trades latency for cost.
- **Governance:** Routes are policy. Version them in Git, review them, and log which route handled each request for audit.

## FAANG deep-dive notes

- **How big tech does it:** Model cascades and routers are standard cost levers, with continuous offline evaluation of routing decisions against human or LLM-judge labels.
- **Staff review questions:** What happens on low confidence? How is routing quality measured? Can an attacker force a weaker route?
- **Interview question:** *"Reduce LLM spend 60% without hurting quality."* Strong answers cover routing or cascades, eval sets per route, fail-safe defaults, caching, and monitoring for drift.

**Typical system-design prompt:** *"Cut LLM serving cost by 50% by routing between a small and a large model without hurting quality."*

**1. Clarify first:**
- Traffic mix: what share is simple (FAQ, extraction) vs. hard (reasoning)?
- Quality metric and acceptable drop (e.g. ≤ 1% on the eval set).
- Latency budget for the routing decision itself.

**2. Back-of-envelope sizing:**
- Large model at $10 per million tokens, small at $1. If 60% of traffic can go small: cost = 0.4 × 10 + 0.6 × 1 = $4.6, a 54% saving.
- Router overhead: embedding (3 ms) + kNN (< 1 ms) for 90% of traffic, plus an 80 ms classifier for 10% → ~11 ms average. That's negligible versus TTFT.
- Misroute cost: if 5% of hard prompts go small and fail, users retry or escalate. Measure the retry rate.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Method | rules only | embeddings + classifier cascade | cascade; rules for policy |
| Uncertain cases | route small | route large | route large when unsure (protect quality) |
| Sensitivity | intent-based | policy override | data sensitivity always overrides intent |
| Learning | static | feedback-driven retraining | weekly retraining from misroutes |
| Alternative | routing | cascading (try small, escalate on low confidence) | cascading for verifiable tasks |

**4. Follow-up questions with crisp answers:**
- *How do you pick the threshold?* Sweep it on a labelled set, and choose the point that meets the quality floor with the most small-model traffic.
- *What's the risk of embedding routing?* Short or novel prompts land near the wrong centroid, so use the fallback classifier.
- *Routing vs. cascading?* Routing decides upfront. Cascading tries small first, then escalates if a verifier or confidence check fails.
- *How do you handle new intents?* Monitor low-similarity traffic clusters and add intents from them.
- *Where should routing run?* At the gateway, before any model call, with policy checks first.
- *How do you prove quality didn't drop?* A/B test with sampled evaluations, comparing routed answers against large-model answers.

**Debug this (common onsite question):** *"After launching the router, cost dropped 50%, but customer satisfaction on billing questions fell 12%."*
1. Misroute analysis: billing questions with amounts and dates are classified as "FAQ" and sent to the small model.
2. The FAQ centroid was built from short generic examples, and billing prompts look similar in embedding space.
3. The small model makes arithmetic mistakes on multi-step billing questions.
4. Fix: add a "billing calculation" intent routed to the large model, raise the threshold for FAQ, and monitor satisfaction per intent, not just overall.

The lesson: **measure quality per route. Average metrics hide the intent you broke.**

**5. What separates senior from staff answers:**
- Senior: builds an embedding router with thresholds and a fallback.
- Staff: designs the cost-vs-quality frontier, per-intent quality monitoring, policy overrides for sovereignty, and continuous learning from misroutes.

**Red flags:** routing without a labelled eval set, defaulting uncertain prompts to the small model, no per-intent metrics, sensitive data routed by intent alone.

## Failure modes
- Router drift: new product features create intents the router doesn't know, which default to the wrong place.
- Adversarial prompts engineered to land on a weaker, less-guarded model.
- Router as a single point of failure. Run it HA with a static fallback route.

## Checklist
- [ ] A router with ≥ 3 routes and a confidence threshold
- [ ] PII-sensitive routing to a sovereign model
- [ ] Route-level cost and quality dashboard
