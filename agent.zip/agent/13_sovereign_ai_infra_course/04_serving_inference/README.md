# Section 5 — Serving Infrastructure & Inference Scaling (7:33)

**Goal:** Serve many models to many users with **low latency, high throughput, and zero downtime**,
at a cost per token the business can sustain.

| Lab | Topic | Key idea |
|---|---|---|
| [41](lab41_triton_multi_framework.md) | Triton Inference Server | One server, many frameworks |
| [42](lab42_memory_orchestration_inference.md) | Memory orchestration | VRAM is the currency |
| [43](lab43_tensorrt_llm_engines.md) | TensorRT-LLM engines | Compile for the hardware |
| [44](lab44_mlflow_model_registry.md) | MLflow registry | Single source of model truth |
| [45](lab45_multi_lora_serving.md) | Multi-LoRA | 100 fine-tunes, 1 base model |
| [46](lab46_semantic_routing.md) | Semantic routing | Right model per prompt |
| [47](lab47_kv_cache_optimization.md) | KV cache optimization | Prefix reuse, offload, sharing |
| [48](lab48_speculative_decoding.md) | Speculative decoding | Guess fast, verify in parallel |
| [49](lab49_envoy_grpc_lb.md) | Envoy for gRPC | L7, load-aware balancing |
| [50](lab50_blue_green_models.md) | Blue/green deployments | Swap models with no downtime |

## The inference economics triangle

```
          Latency (TTFT/TPOT)
               /\
              /  \
             /    \
   Throughput ──── Cost
```

Batching raises throughput but hurts latency. Bigger GPUs cut latency but raise cost. Every lab here moves
the triangle in some direction. Know which one, and by how much.

## SLO template

| Metric | Interactive chat | Agent tool-step | Batch |
|---|---|---|---|
| TTFT p95 | < 500 ms | < 1 s | n/a |
| TPOT p95 | < 50 ms (≥ 20 tok/s) | < 30 ms | n/a |
| Availability | 99.9% | 99.9% | best effort |
| Cost target | $/1M tokens | $/task | $/1M tokens |
