# Lab 44: MLflow — Centralizing the Model Registry (3:51)

## Why it matters
"Which model is in production, who approved it, what data trained it, and how do we roll back?"
If answering takes more than 30 seconds, you have no registry. That fails audits (EU AI Act, Lab 92)
and causes incidents.

## In plain words
The registry is a **library catalog for models**. Every model has a card saying who made it, from what ingredients (data), how it
scored, and who approved it. Labels like `@champion` are bookmarks: move the bookmark and production switches models, and moving it back is an instant rollback.

## Architecture at a glance

```mermaid
flowchart LR
  TR[Training run] -->|log params, metrics, data hash| TRK[MLflow tracking]
  TRK -->|register| V7[claims-assistant v7]
  V7 --> EV{Eval gate}
  EV -->|pass| CH["@challenger → canary"]
  CH -->|healthy| CP["@champion → production"]
  CP -->|regression| RB["Move alias back to v6"]
  SRV[Serving] -->|resolves models:/...@champion| CP
```

**How to read it:** A training run logs everything, registers a version, and passes an eval gate. It becomes the challenger, then the champion. Serving always resolves the champion alias, and rollback just moves the alias back.

## Core concepts

| MLflow piece | Role |
|---|---|
| **Tracking** | Runs, params, metrics, artifacts per experiment |
| **Model Registry** | Named models, versions, **aliases** (`@champion`, `@challenger`), tags |
| **Artifacts store** | S3/MinIO holding weights, engines, tokenizers |
| **Backend store** | Postgres for metadata |
| **Model signatures** | Input/output schemas |

**Lifecycle with aliases (stages are deprecated):**

```
train run ──► register v7 ──► eval gate ──► alias @challenger ──► canary 10% ──► alias @champion
                                   │                                  │
                                   ▼ fail                             ▼ regress
                               rejected                         alias back to v6 (rollback)
```

## Architecture in depth

The overview shows the alias lifecycle. This view shows the **MLflow deployment architecture** and what happens in each component
when a new version is promoted.

```mermaid
flowchart LR
  subgraph MLflow["MLflow platform"]
    API[Tracking + Registry server<br/>stateless, 2+ replicas]
    DB[(PostgreSQL<br/>runs, versions, aliases)]
    ART[(S3 / MinIO<br/>artifacts: weights, evals)]
  end
  CI[Training pipeline] -->|log run + register| API
  API --> DB
  CI -->|upload artifacts| ART
  GATE[Eval gate job] -->|set alias @challenger| API
  OP[Promotion approver] -->|set alias @champion| API
  API -->|webhook / poll| DEP[Deployer: Argo CD / Rollouts]
  DEP --> SRV[Serving pods]
  SRV -->|"download models:/name@champion"| ART
  AUD[(Audit log)] <-.alias changes.- API
```

### Follow version 8 from training run to production
1. **Log.** The training pipeline logs parameters, metrics, data hashes, and code commit to the tracking server, which stores them in PostgreSQL.
2. **Upload.** Weights and eval reports go to object storage. The database only keeps pointers.
3. **Register.** The run is registered as `claims-assistant` version 8.
4. **Gate.** An eval job compares v8 against the champion and sets the `@challenger` alias if it passes.
5. **Approve.** A human (or policy) moves `@champion` to v8. The change is audit-logged with who, when, and why.
6. **Deploy.** The deployer notices the alias change and rolls out a canary (Lab 50).
7. **Serve.** Pods resolve `@champion` to v8 and download its artifacts. Rollback means moving the alias back to v7.

**The one idea to keep:** the registry is the single source of truth for *which* model runs. Serving resolves aliases and never hard-codes versions.

## Minimal hands-on

```python
import mlflow
mlflow.set_tracking_uri("http://mlflow.mlops:5000")

with mlflow.start_run(run_name="llama8b-sft-claims") as run:
    mlflow.log_params({"base": "Llama-3.1-8B", "lr": 2e-5, "data_manifest": "sha256:9f2c..."})
    mlflow.log_metrics({"eval_accuracy": 0.912, "toxicity": 0.002})
    mlflow.log_artifacts("out/merged_model", artifact_path="model")

mv = mlflow.register_model(f"runs:/{run.info.run_id}/model", "claims-assistant")
client = mlflow.MlflowClient()
client.set_registered_model_alias("claims-assistant", "challenger", mv.version)
client.set_model_version_tag("claims-assistant", mv.version, "risk_tier", "limited")
```

Serving resolves `models:/claims-assistant@champion`. Promotion is a metadata change with no redeploy of code.

## Worked example

**Scenario:** A bank regulator asks: "Show the lineage of the model that gave credit advice on 3 March."

With the registry:
1. The inference log entry carries `model_version=claims-assistant/12` (the gateway logs the alias resolution).
2. Registry v12 links to its training run, which holds params, eval metrics, the **data manifest hash** (Lab 66), the code commit, and the approver (tag `approved_by=risk-team/jdoe`, plus a link to the approval ticket).
3. The artifact hash matches the deployed engine's hash (Lab 43).

Answer delivered in **minutes**, not weeks. The same chain supports **rollback**: re-point `@champion` to v11 and the serving layer reloads.

## Production deep dive
- **HA deployment:** MLflow server stateless behind a Service, Postgres HA (CloudNativePG), MinIO HA (Lab 67). Use SSO/OIDC auth with RBAC per model.
- **Promotion via GitOps:** Alias changes go through PR plus CI so promotions are auditable. Use registry webhooks to trigger engine builds and deployments.
- **Large artifacts:** Store weights once and reference by URI and hash. Don't duplicate 140 GB per version. Consider OCI artifacts (ORAS) for weights.
- **Model cards:** Attach intended use, limitations, eval results, and risk tier. These are required documentation for regulated use.
- **Alternatives:** W&B Registry, Kubeflow Model Registry, Hugging Face Hub (self-hosted). The pattern matters more than the tool.

## FAANG deep-dive notes

- **How big tech does it:** Every production model has traceable lineage (data, code, config, approver), and promotions happen via automated gates plus human sign-off for high-impact models.
- **Staff review questions:** Can you name the exact model behind any logged response? How long does rollback take? Who approved the current champion?
- **Interview question:** *"Design an ML release process for a regulated company."* Strong answers cover registry, lineage, eval gates, aliases, canary, audit trail, and rollback.

**Typical system-design prompt:** *"Design model lifecycle management for 200 models across 15 teams, with regulatory audit requirements."*

**1. Clarify first:**
- What auditors need: lineage (data, code, approver) for every production model?
- Who may promote to production, and how?
- Multi-environment: dev, staging, and prod registries, or one registry with permissions?

**2. Back-of-envelope sizing:**
- 200 models × ~50 versions/year = 10k versions. Metadata is tiny, and the database holds it easily.
- Artifacts: LLM fine-tunes are 10–150 GB each. 1,000 retained versions × 30 GB average = 30 TB, so plan lifecycle rules for non-champion versions.
- Promotion latency target: alias change to canary start in under 5 minutes.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Version pointer | stages (deprecated) | aliases | aliases (`@champion`, `@challenger`) |
| Promotion | manual UI clicks | gated pipeline + approval | pipeline with recorded approval |
| Environments | one registry | registry per environment | one registry with RBAC, or copy-on-promote for strict isolation |
| Large artifacts | in MLflow store | external path + hash | external for huge LLM weights, hash in metadata |
| Retention | keep all | lifecycle rules | keep champions, challengers, and audit-required versions |

**4. Follow-up questions with crisp answers:**
- *Why aliases instead of version numbers in serving config?* Promotion and rollback become a metadata change, not a redeploy of config.
- *What makes it auditable?* Every version links to the run, data hash, code commit, eval report, and approver.
- *How do you make MLflow highly available?* Stateless servers behind a load balancer, managed PostgreSQL, and durable object storage.
- *How does serving get notified?* Webhooks or polling by a controller, which triggers a GitOps rollout.
- *How do you stop a bad model reaching prod?* An automated eval gate, plus required approval to move `@champion`.
- *What about data lineage?* Log dataset versions or hashes (Lab 66) with each run.

**Debug this (common onsite question):** *"An auditor asks which data trained the model that produced a disputed decision 8 months ago. Nobody can answer."*
1. Serving logs record the model name but not the resolved version.
2. The alias moved four times since then, with no history of what it pointed to.
3. Training runs logged metrics but not dataset hashes.
4. Fix: log the resolved version with every prediction, keep an append-only alias-change audit log, log dataset hashes in every run, and make these required fields in CI.

The lesson: **lineage must be captured at write time. You cannot reconstruct it later.**

**5. What separates senior from staff answers:**
- Senior: uses aliases, gates promotion, configures HA MLflow.
- Staff: designs end-to-end lineage (data → run → version → prediction), governance for promotion rights, retention policy, and the audit story regulators need.

**Red flags:** hard-coded versions in serving, manual promotions without records, predictions without a version, no artifact retention policy.

## Failure modes
- Serving pins `/models/latest/` from S3, bypassing the registry, so nobody knows what's live.
- Artifacts deleted by S3 lifecycle rules while the version is still `@champion`.
- No approval tag, and the audit trail breaks at the most important step.

## Checklist
- [ ] Model registered with a data manifest hash and eval metrics
- [ ] Serving resolves models by alias
- [ ] Rollback via alias tested in < 5 minutes
