# Lab 41: Triton Inference Server — Multi-Framework Serving (3:37)

## Why it matters
Real AI products use **many model types**: an LLM, an embedder, a reranker, an OCR model, a classifier, and
XGBoost fraud scoring. Running a different server for each means duplicated ops. Triton serves
them all with one API, one set of metrics, and one deployment pattern.

## In plain words
Triton is a **universal power strip**: whatever plug your model has (PyTorch, ONNX, TensorRT, XGBoost), it fits into one server with one
switchboard (API) and one meter (metrics). Dynamic batching is the waiter who collects several orders before walking to the kitchen.

## Architecture at a glance

```mermaid
flowchart LR
  C[Clients HTTP/gRPC] --> TS[Triton server]
  TS --> DB[Dynamic batcher]
  DB --> B1[TensorRT backend]
  DB --> B2[ONNX backend]
  DB --> B3[FIL / XGBoost backend]
  DB --> B4[TRT-LLM / vLLM backend]
  REPO[(Model repository S3)] --> TS
```

**How to read it:** Clients hit one Triton server. The dynamic batcher groups requests, then each model runs on its own backend. All models come from a single repository.

## Core concepts

| Feature | What |
|---|---|
| **Backends** | TensorRT, TensorRT-LLM, PyTorch (LibTorch), ONNX Runtime, OpenVINO, Python, vLLM, FIL (trees) |
| **Model repository** | Folder/S3 layout: `model/1/model.onnx` + `config.pbtxt` |
| **Dynamic batching** | Combines individual requests into GPU batches within `max_queue_delay` |
| **Concurrent model execution** | Multiple instances of models per GPU (`instance_group`) |
| **Ensembles / BLS** | Server-side pipelines (tokenize → model → postprocess) with no network hops |
| **Protocols** | HTTP/gRPC (KServe v2), plus an OpenAI-compatible frontend |

```
model_repository/
├── bge_embed/       config.pbtxt  1/model.plan      (TensorRT)
├── reranker/        config.pbtxt  1/model.onnx      (ONNX)
├── fraud_xgb/       config.pbtxt  1/xgboost.json    (FIL)
└── llama_8b/        config.pbtxt  1/ (TRT-LLM engine) or vLLM backend
```

## Architecture in depth

The overview shows the backends behind one server. This view follows **one request through Triton's internals**, including
the dynamic batcher's wait window and an ensemble pipeline.

```mermaid
flowchart LR
  REQ[gRPC request: fraud score] --> FE[Frontend: parse + validate]
  FE --> SCH{"Scheduler for model 'fraud_ens'"}
  SCH --> ENS["Ensemble: preprocess → model → postprocess"]
  ENS --> PRE["Python backend: feature prep (CPU)"]
  PRE --> Q["Dynamic batcher queue<br/>max_queue_delay 2 ms"]
  Q -->|"batch of 32 or timeout"| INST["Model instance on GPU 0<br/>TensorRT backend"]
  INST --> POST["Postprocess: threshold + explain"]
  POST --> RESP[Response]
  MET[(Prometheus: queue time, compute time per model)] -.-> Q
  MET -.-> INST
```

### Follow one fraud-score request
1. **Frontend.** Triton parses the request and checks inputs against the model's declared shapes and types.
2. **Ensemble.** The client calls one model name, and Triton runs a pipeline of steps server-side. The client makes no extra round trips.
3. **Preprocess on CPU.** A Python or C++ backend builds features, keeping CPU work off the GPU.
4. **Dynamic batching.** The request waits up to 2 ms for others. A batch of 32 goes to the GPU as one call, often 10× the throughput of single requests.
5. **Instance groups.** Each model can run several instances (e.g. 2 per GPU) so batches overlap.
6. **Postprocess and respond.** Thresholding and explanation run, then the response returns.
7. **Metrics per stage.** Queue time vs. compute time tells you whether to add instances (queue-bound) or optimize the model (compute-bound).

**The one idea to keep:** Triton trades a few milliseconds of waiting for much larger batches. Tune `max_queue_delay` against your latency budget.

## Minimal hands-on

```protobuf
# reranker/config.pbtxt
name: "reranker"
backend: "onnxruntime"
max_batch_size: 64
dynamic_batching { max_queue_delay_microseconds: 2000 preferred_batch_size: [16, 32] }
instance_group [{ count: 2, kind: KIND_GPU }]
```

```bash
tritonserver --model-repository=s3://models/repo --model-control-mode=explicit
curl localhost:8000/v2/models/reranker/ready
```

Use `perf_analyzer` / `model-analyzer` to sweep batch sizes and instance counts automatically.

## Worked example

**Scenario:** An insurance claims pipeline: OCR (PyTorch) → field extractor (ONNX BERT) → fraud
score (XGBoost) → summary (8B LLM). Before, there were 4 microservices, 4 Docker images, and 6 network hops.

- After: one Triton deployment with an **ensemble** for OCR → extractor → fraud, and a separate LLM model in the same repository.
- Dynamic batching on the extractor: throughput **5.2×** at +3 ms p50 latency.
- The fraud XGBoost runs on the GPU FIL backend: 40× faster than the CPU scorer, which removed 12 CPU nodes.
- Ops: one Helm chart, one Grafana dashboard (`nv_inference_*` metrics), one upgrade cadence.

## Production deep dive
- **Model control:** `explicit` mode with load/unload through the API, driven by the registry (Lab 44). Don't poll S3 in production.
- **Where Triton fits:** It is excellent for non-LLM models and TRT-LLM. Many teams run vLLM/SGLang for LLMs and Triton for "everything else". Both expose Prometheus metrics, so dashboards can be unified.
- **KServe integration:** `InferenceService` with the Triton runtime gives you canary, autoscaling, and a standard v2 protocol.
- **Security:** Disable the model-repository management endpoints for external callers. Restrict them to the platform control plane.
- **Capacity:** `model-analyzer` outputs the best config per latency budget. Commit those configs as code.

## FAANG deep-dive notes

- **How big tech does it:** A small number of standardized serving runtimes, each with a model-analyzer step that picks the batch size and instance count per latency SLO.
- **Staff review questions:** Why this batching delay? How are models loaded and unloaded, and by whom? What is the per-model GPU memory budget?
- **Interview question:** *"Serve 15 different non-LLM models efficiently."* Strong answers cover one multi-framework server, dynamic batching, ensembles to remove network hops, instance groups, and per-model metrics.

**Typical system-design prompt:** *"Serve 40 different models (vision, tabular, embeddings, one LLM) for a bank with a 50 ms p99 for real-time models."*

**1. Clarify first:**
- Which models are real-time vs. batch, and their QPS.
- Model sizes: can several share one GPU?
- Update cadence and who owns each model.

**2. Back-of-envelope sizing:**
- 30 small models at ~1 GB each fit on 2 × L40S (48 GB). Packing them on shared GPUs avoids 30 mostly idle GPUs.
- Fraud model: 5,000 QPS, 1 ms compute per batch of 32 → ~160 batches/s per instance. One GPU instance handles it with headroom.
- Latency budget: 50 ms p99 = network 10 + preprocessing 5 + queue delay 2 + compute 3 + margin.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Server | Triton (multi-framework) | framework-specific (vLLM, TorchServe) | Triton for many classic models; vLLM/SGLang for LLMs |
| Packing | one model per GPU | many models per GPU | pack small models; isolate LLMs |
| Batching | none | dynamic with queue delay | dynamic batching for anything above ~50 QPS |
| Pipelines | client-side chaining | ensembles / BLS | ensembles to cut round trips |
| Model loading | all at start | explicit load/unload API | explicit control for large repositories |

**4. Follow-up questions with crisp answers:**
- *What does the dynamic batcher do?* It groups requests arriving within a small window into one GPU call.
- *Instance group vs. replicas?* Instance groups are copies inside one Triton process. Replicas are separate pods for scaling and fault isolation.
- *How do you avoid one model starving others on a shared GPU?* Rate limiter settings, priority, and separate pools for critical models.
- *What's the model repository?* Versioned folders with `config.pbtxt`, polled or explicitly loaded from S3.
- *Why Triton for LLMs at all?* Uniform metrics and APIs, but most teams serve LLMs with TRT-LLM or vLLM backends.
- *How do you test a config change?* `perf_analyzer` and Model Analyzer sweep batch size and instances for latency vs. throughput.

**Debug this (common onsite question):** *"After adding 10 new models to the shared Triton server, fraud-model p99 rose from 20 ms to 140 ms."*
1. Triton metrics: fraud model compute time unchanged, but queue time rose 6×.
2. The new models share the same GPU, and one image model runs large batches that occupy the GPU for 80 ms.
3. The fraud model waits behind them.
4. Fix: move the fraud model to a dedicated GPU pool (or MIG slice, Lab 23), set priorities and rate limits, and alert on queue time per model.

The lesson: **sharing GPUs saves money until a noisy neighbour breaks a latency SLO. Isolate the critical models.**

**5. What separates senior from staff answers:**
- Senior: configures dynamic batching and instance groups, and reads queue vs. compute metrics.
- Staff: designs model placement across shared and dedicated pools by SLO tier, sets repository governance, and uses Model Analyzer to set configs instead of guessing.

**Red flags:** one GPU per tiny model, latency-critical models sharing GPUs with batch-heavy ones, no per-model queue metrics, manual config tuning.

## Failure modes
- Dynamic batching delay too high (e.g. 50 ms) quietly destroys p99 latency for interactive calls.
- Python backend used for heavy pre-processing becomes a GIL bottleneck. Move it to C++ or the GPU (DALI).
- One huge model loaded on every Triton replica wastes memory. Split repositories per deployment.

## Checklist
- [ ] Two models from different frameworks are served by one Triton
- [ ] A dynamic batching config is tuned with `perf_analyzer`
- [ ] Explicit model control is wired to the registry
