# Enterprise Reference Architecture — The Target Stack

This is the system you build incrementally across the course. Keep it open while you work through the labs.

```mermaid
flowchart TB
  subgraph Edge["Edge / Global Traffic (Lab 97)"]
    GSLB[GeoDNS / Anycast] --> GW[Envoy / Gateway API]
  end

  subgraph Control["Governance Plane"]
    KYV[Kyverno policies<br/>residency, images]
    AUD[Audit + EU AI Act tiering]
    FED[Karmada federation]
    REG[MLflow registry + signed artifacts]
  end

  subgraph Agents["Agent Plane (Section 7)"]
    ORCH[MCP Host / Orchestrator]
    RL[Token rate limiter]
    SBX[gVisor/Kata tool sandboxes]
    MCPS[MCP servers: DB, Jira, GitHub]
    RED[(Redis state)]
  end

  subgraph Serve["Inference Plane (Section 5)"]
    SR[Semantic router]
    VLLM[vLLM / TRT-LLM pools<br/>multi-LoRA, spec decoding]
    TRI[Triton: embeddings, rerankers]
  end

  subgraph Data["Sovereign Data Plane (Section 6)"]
    KAF[Kafka ingest]
    PII[PII masking proxy]
    MIL[(Milvus cluster)]
    MINIO[(MinIO HA)]
    VEL[Velero DR]
  end

  subgraph Train["Training Plane (Section 4)"]
    VOL[Volcano / Kueue]
    RAY[KubeRay]
    MEG[Megatron / FSDP jobs]
    IB[InfiniBand / RoCE fabric]
  end

  subgraph Compute["Compute Plane (Section 3)"]
    GPUOP[GPU Operator, MIG, DCGM]
    KARP[Karpenter / cluster autoscaler]
  end

  GW --> RL --> ORCH --> SR --> VLLM
  ORCH --> MCPS
  ORCH --> SBX
  ORCH --> RED
  SR --> TRI
  ORCH --> MIL
  KAF --> PII --> MIL
  MIL --> MINIO
  VEL --> MINIO
  RAY --> MEG --> IB
  MEG --> MINIO
  REG --> VLLM
  KYV -.-> Serve & Data & Train & Agents
  FED -.-> Compute
```

## Non-functional requirements (NFRs) to design against

| Concern | Enterprise target (typical) | Where addressed |
|---|---|---|
| Availability | 99.9% for chat APIs, 99.99% for the control plane | Labs 6, 49, 50, 69 |
| Latency | TTFT p95 < 500 ms, TPOT < 50 ms | Labs 42, 43, 47, 48 |
| GPU utilization | > 60% averaged across the fleet | Labs 23, 26, 29, 30 |
| RPO / RTO | RPO < 15 min, RTO < 1 h | Labs 39, 68, 69 |
| Data residency | 100% of EU PII stays in the EU | Labs 65, 70, 97 |
| Auditability | Every model and dataset hash-traceable | Labs 44, 66, 92, 99 |
| Security | Zero trust, mTLS, sandboxed tool exec | Labs 49, 77, 94 |

## Platform team ownership (RACI sketch)

| Layer | Owns | Consumes |
|---|---|---|
| Platform/SRE | Clusters, GPU fleet, networking, DR | — |
| ML Platform | Ray, registry, serving templates | Platform |
| Data Platform | Kafka, Milvus, MinIO, masking | Platform |
| App/Agent teams | Agents, prompts, MCP servers | ML + Data platform |
| Security/GRC | Policies, audits, AI Act tiering | Everything |
