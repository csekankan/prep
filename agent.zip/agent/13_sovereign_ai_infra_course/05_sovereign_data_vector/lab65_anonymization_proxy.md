# Lab 65: Anonymization Proxies — GDPR-Compliant Data Masking (3:50)

## Why it matters
Once PII is in a prompt, it can end up in logs, vector stores, KV caches, fine-tuning sets, and third-party
APIs. An **anonymization proxy** strips or tokenizes PII *before* it reaches the model, and
optionally restores it in the response for authorized users.

## In plain words
The proxy is a **translator who swaps real names for code names** before talking to the AI ("John Smith" becomes `PERSON_1`), and swaps them
back in the reply, but only for people allowed to know. The AI does its job without ever learning who anyone is.

## Core concepts

| Technique | Reversible? | Example | Use |
|---|---|---|---|
| **Redaction** | No | `John` → `[NAME]` | Logs, analytics |
| **Pseudonymization (tokenization)** | Yes, with a vault | `John Smith` → `PERSON_7f3a` | Prompts where the answer refers back to the entity |
| **Format-preserving encryption** | Yes, with a key | IBAN → valid-looking IBAN | Legacy systems needing format |
| **Generalization** | No | Age 37 → "30–40" | Analytics / training |
| **Synthetic replacement** | No | `John` → `Michael` | Fine-tuning data |

**GDPR nuance:** Pseudonymized data is **still personal data** (Recital 26) if re-identification is possible. Only truly
anonymized data falls outside GDPR. A proxy lowers risk; it doesn't remove obligations.

**Detection stack:** Regex/checksums (IBAN, credit cards, national IDs), NER models (Presidio, spaCy, GLiNER),
and custom dictionaries (employee IDs, project codenames). The combination matters, because any single method misses things.

```mermaid
sequenceDiagram
  participant U as User/App
  participant P as Anonymization Proxy
  participant V as Token Vault (per-tenant key)
  participant L as LLM
  U->>P: "Email John Smith at js@acme.com about invoice 4411"
  P->>V: store {PERSON_1: John Smith, EMAIL_1: js@acme.com}
  P->>L: "Email PERSON_1 at EMAIL_1 about invoice 4411"
  L-->>P: "Draft: Dear PERSON_1, ..."
  P->>V: resolve (caller authorized?)
  P-->>U: "Draft: Dear John Smith, ..."
```

**How to read it:** The proxy swaps real identifiers for tokens, stores the mapping in a vault, sends only tokens to the LLM, then swaps them back in the reply for authorized users.

## Architecture in depth

The concepts diagram shows the tokenize-and-restore sequence. This view shows the **proxy's internal detection pipeline** and the
security boundary around the vault.

```mermaid
flowchart TB
  IN[Prompt from app] --> DET
  subgraph DET["Detection (combine, don't rely on one)"]
    RX["Regex + checksums: IBAN, cards, national IDs"]
    NER["NER model: names, orgs, addresses"]
    DICT["Dictionaries: employee IDs, codenames"]
  end
  DET --> MERGE["Merge spans, resolve overlaps, confidence threshold"]
  MERGE --> POL{"Policy per tenant + data class"}
  POL -->|"redact"| RED["[NAME]"]
  POL -->|"tokenize"| TOK["PERSON_1"]
  TOK --> VAULT[("Token vault<br/>per-tenant key, TTL, audit")]
  RED & TOK --> LLM[LLM: sees only tokens]
  LLM --> REST["Restore tokens for authorized caller"]
  VAULT --> REST
  REST --> OUT[Response]
  LOGS[(Logs: masked text only)] -.-> MERGE
```

### Follow one prompt through the proxy
1. **Detect with several methods.** Regex with checksums catches structured IDs reliably, an NER model catches names and addresses, and dictionaries catch company-specific identifiers.
2. **Merge.** Overlapping detections are combined, and low-confidence spans are handled by policy (mask when unsure, for high-risk tenants).
3. **Apply policy.** Each data class gets a treatment: redact (irreversible) or tokenize (reversible through the vault).
4. **Vault.** Token-to-value mappings are stored encrypted with a per-tenant key, with a TTL and an audit log of every lookup.
5. **LLM sees tokens only.** Neither the model provider nor model logs see raw personal data.
6. **Restore.** For authorized callers, tokens in the answer are swapped back. Unauthorized callers get the masked version.
7. **Logs stay masked.** Only masked text is ever logged, which is where most leaks actually happen.

**The one idea to keep:** the proxy is a security boundary. Detection quality decides what leaks, and vault access control decides who can reverse it.

## Minimal hands-on

```python
from presidio_analyzer import AnalyzerEngine
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig
import hashlib

analyzer, anonymizer = AnalyzerEngine(), AnonymizerEngine()
vault: dict[str, str] = {}                      # production: per-tenant encrypted store (Vault/Redis+KMS)

def pseudo(entity_type):
    def op(value):
        token = f"{entity_type}_{hashlib.sha256(value.encode()).hexdigest()[:6]}"
        vault[token] = value
        return token
    return op

def mask(text):
    results = analyzer.analyze(text=text, language="en",
                               entities=["PERSON", "EMAIL_ADDRESS", "PHONE_NUMBER", "IBAN_CODE"])
    ops = {r.entity_type: OperatorConfig("custom", {"lambda": pseudo(r.entity_type)}) for r in results}
    return anonymizer.anonymize(text=text, analyzer_results=results, operators=ops).text

def unmask(text):
    for t, v in vault.items(): text = text.replace(t, v)
    return text
```

## Worked example

**Scenario:** A German health insurer wants to use a **hosted frontier model** for complex claim summaries,
but patient data may not leave its sovereign zone in identifiable form.

Architecture:
1. Claims flow into the anonymization proxy (on-prem K8s). Names, insurance numbers, addresses, and dates of birth are tokenized. Diagnoses are generalized to ICD chapter level.
2. A **semantic router** (Lab 46) sends anything with residual risk (detector confidence < 0.9 or rare-disease codes, which are re-identifiable) to the **on-prem 70B model** instead.
3. Responses are de-tokenized only for authenticated caseworkers. Audit logs store the masked version.

Results: 71% of volume uses the frontier API with masked data and 29% stays fully on-prem. The DPO approved it based on
the DPIA, which documents detector recall measured on 5,000 annotated claims: **99.2% recall for direct identifiers**.

## Production deep dive
- **Measure recall:** Build a labeled PII test set per language and domain, and gate detector changes on it. Missed PII is the failure that matters.
- **Vault security:** Per-tenant keys, short TTLs for session tokens, access logged, and crypto-shredding for erasure requests.
- **Everywhere, not just prompts:** Apply the same masking to logs, traces, eval datasets, and the embeddings pipeline (Lab 63).
- **Placement:** Use an Envoy ext_proc filter or a sidecar in front of every LLM endpoint, so teams can't bypass it.
- **Latency budget:** NER adds 5–30 ms. Use small, GPU/CPU-optimized models and cache per-document results.

## FAANG deep-dive notes

- **How big tech does it:** PII detection and redaction runs as shared infrastructure on logs, prompts, and training data, with measured recall and strict access controls on the re-identification maps.
- **Staff review questions:** What is the detector recall per language? Where else does PII leak (logs, traces, vectors)? Who can de-tokenize?
- **Interview question:** *"Use an external LLM on data containing customer PII."* Strong answers cover masking/tokenization, recall measurement, routing high-risk data to on-prem, vault security, and legal basis (DPIA).

**Typical system-design prompt:** *"Let 20,000 employees use an external LLM API without sending personal data out of the EU."*

**1. Clarify first:**
- What counts as sensitive: GDPR personal data, financial IDs, trade secrets?
- Must answers refer back to real entities (needs reversible tokens)?
- Latency budget for the proxy.

**2. Back-of-envelope sizing:**
- 20,000 users × 30 prompts/day ≈ 600k prompts/day ≈ 7/s average, ~50/s at peak.
- Detection latency: regex < 1 ms, NER on CPU ~20–50 ms for 1k tokens, on GPU ~5 ms. Total proxy overhead ~30–60 ms, small versus LLM latency.
- Recall target: if NER finds 95% of names, 5% leak. For high-risk classes, add dictionaries and stricter thresholds, or route to an on-prem model instead.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Technique | redaction | tokenization | tokenize when answers need entities; redact for logs and analytics |
| Detection | regex only | regex + NER + dictionaries | layered detection |
| Uncertain spans | pass | mask | mask for high-risk tenants |
| Very sensitive data | proxy to external LLM | route to sovereign on-prem model | on-prem for special categories (health, etc.) |
| Vault | shared key | per-tenant keys in HSM/KMS | per-tenant keys |

**4. Follow-up questions with crisp answers:**
- *Is pseudonymized data out of GDPR scope?* No. It's still personal data if re-identification is possible.
- *Why consistent tokens within a conversation?* So the LLM can reason ("PERSON_1 emailed PERSON_2") coherently.
- *How do you measure detection quality?* A labelled test set per language and data type, with recall tracked over time.
- *What about context leakage?* "The CEO of Acme in Berlin" can identify someone without a name. Policy may require on-prem routing for such content.
- *Where do leaks really happen?* Logs, traces, error messages, and caches. Mask before any of them.
- *How do you handle documents in RAG?* Mask at ingestion for external models, or keep the whole pipeline sovereign.

**Debug this (common onsite question):** *"An audit finds customer names in the external LLM provider's logs, even though the proxy is deployed."*
1. Sample leaked prompts: the names are in German-language prompts with lowercase names.
2. The NER model is English-only and case-sensitive. Regex covered IDs, not names.
3. A retry path in the SDK also sends the original prompt when the proxy times out (fail-open).
4. Fix: multilingual NER plus a test set per language, make the proxy fail-closed, block direct egress to the provider at the network layer, and run regular leak tests with canary data.

The lesson: **a masking proxy must be fail-closed and the only path out. Test detection in every language you serve.**

**5. What separates senior from staff answers:**
- Senior: deploys Presidio-style detection with tokenization and a vault.
- Staff: designs the policy model per data class, fail-closed architecture with egress controls, detection quality measurement, and the routing decision between masking and sovereign models.

**Red flags:** regex-only detection, fail-open proxies, raw prompts in logs, a shared vault key, claiming GDPR no longer applies.

## Failure modes
- The LLM "helpfully" guesses the real name from context (quasi-identifiers). Generalize those as well.
- Tokens not consistent across a conversation (`PERSON_1` vs. `PERSON_2` for the same person), so the model gets confused.
- The vault becomes a high-value breach target if it lacks proper isolation.

## Checklist
- [ ] Mask/unmask round-trip working
- [ ] PII recall measured on a labeled test set
- [ ] Masking applied to logs + vectors, not just prompts
