# Lab 66: Data Provenance — Cryptographic Hashing of Training Sets (4:12)

## Why it matters
"Was copyrighted or personal data used to train this model?" Regulators (EU AI Act Art. 10 and 53),
courts, and customers now ask this. Without **cryptographic lineage**, you can't answer, can't
remove data, and can't prove a model wasn't tampered with.

## In plain words
A hash is a **fingerprint for a file**: change one byte and the fingerprint changes. A Merkle root is **one fingerprint for a whole library**.
Signing it is like a notary's stamp. Together they let you prove, years later, exactly which data trained a model.

## Architecture at a glance

```mermaid
flowchart LR
  F1[shard 1] --> H1[hash]
  F2[shard 2] --> H2[hash]
  F3[shard N] --> H3[hash]
  H1 & H2 & H3 --> MR[Merkle root]
  MR --> MAN["Manifest + signature"]
  MAN --> ATT["Training attestation: data root + code commit + config"]
  ATT --> MOD["Model hash in registry"]
```

**How to read it:** Each shard is hashed, the hashes combine into one Merkle root, and the root goes into a signed manifest. That feeds a training attestation linked to the model's hash in the registry.

## Core concepts

| Primitive | Gives you |
|---|---|
| **Content hash** (SHA-256 / BLAKE3) per file/shard | Identity: same bytes, same hash |
| **Merkle tree** over shard hashes | One root hash for an entire dataset. Prove inclusion of any item cheaply |
| **Manifest** | List of `(uri, hash, size, license, source, pii_status)` plus the root |
| **Signature** (Sigstore cosign / in-toto) | Who produced or approved the manifest and when |
| **Attestation** (SLSA / in-toto) | "Model X was trained by pipeline Y on dataset root R with code commit C" |
| **Transparency log** (Rekor) | Tamper-evident public or private record |

```
shard hashes ─► Merkle root R_data ─┐
code commit C ──────────────────────┼─► training attestation (signed) ─► model hash M
config hash  ───────────────────────┘                                    └─► registry (Lab 44)
```

Data versioning tools: **DVC**, **lakeFS** (Git-like branches over S3), **Delta/Iceberg** snapshots. Hashes should be stored alongside them.

## Architecture in depth

The overview shows shards hashed into a Merkle root. This view shows **how a Merkle tree proves one file belongs to a dataset**
without re-hashing everything, which is how audits stay cheap at petabyte scale.

```mermaid
flowchart TB
  ROOT["Root R = H(H12, H34)<br/>signed in manifest"] --> H12["H12 = H(H1, H2)"]
  ROOT --> H34["H34 = H(H3, H4)"]
  H12 --> H1["H1 = H(shard-1)"]
  H12 --> H2["H2 = H(shard-2)"]
  H34 --> H3["H3 = H(shard-3) ← auditor asks about this"]
  H34 --> H4["H4 = H(shard-4)"]
  PROOF["Proof for shard-3: H4 + H12"] -.-> VER
  VER["Verifier: H(H(H3, H4), H12) == R ?"] --> OK[✅ shard-3 was in training set]
  ROOT --> ATT["Attestation (in-toto / SLSA style)<br/>data root + code commit + config + model hash"]
  ATT --> SIG["Signed with cosign / KMS key"] --> LOG[(Transparency / audit log)]
```

### Follow one audit question: "Was this file used to train model v7?"
1. **Hash the file.** The auditor hashes the file in question with SHA-256, getting H3.
2. **Get the proof.** The data platform provides the sibling hashes on the path to the root: H4 and H12. That's only log₂(N) hashes, about 30 for a billion shards.
3. **Recompute the root.** H(H(H3, H4), H12) must equal the root R.
4. **Check the signature.** R is in a manifest signed by the data platform's key, so nobody altered it after training.
5. **Link to the model.** The training attestation binds R to the code commit, config, and the hash of model v7's weights.
6. **Answer.** If everything matches, the file was in the training set. If any byte of the file differed, the hash would differ and the proof would fail.

**The one idea to keep:** hash everything once, sign the root, and you can later prove membership or tampering cheaply and without trusting anyone's word.

## Minimal hands-on

```python
import hashlib, json, pathlib

def sha256(p, buf=1 << 20):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        while chunk := f.read(buf): h.update(chunk)
    return h.hexdigest()

def merkle_root(hashes):
    level = sorted(hashes)
    while len(level) > 1:
        if len(level) % 2: level.append(level[-1])
        level = [hashlib.sha256((a + b).encode()).hexdigest() for a, b in zip(level[::2], level[1::2])]
    return level[0]

shards = sorted(pathlib.Path("/data/sft_v4").glob("*.parquet"))
entries = [{"uri": str(s), "sha256": sha256(s), "license": "internal", "pii": "masked"} for s in shards]
manifest = {"dataset": "sft_v4", "root": merkle_root([e["sha256"] for e in entries]), "items": entries}
pathlib.Path("manifest.json").write_text(json.dumps(manifest, indent=2))
# then: cosign sign-blob manifest.json --bundle manifest.sigstore.json
```

## Worked example

**Scenario:** A media company receives a takedown claim: *"Your model was trained on our paywalled archive."*

With provenance in place:
1. The model card links to training attestation `att-2026-07-14`, signed by the ML pipeline identity.
2. The attestation references dataset root `R=9c1e…`, and the manifest lists 18,420 shards, each with a source and license.
3. The claimant's article URLs are checked against the **source index**: none are found. Inclusion proofs for the 3 overlapping domains show they came from a licensed news feed (contract ID attached).
4. Legal responds in **4 days**, with cryptographic evidence.

Without provenance, the alternative was retraining from a "clean" dataset at roughly $1.8M with no proof either way.

## Production deep dive
- **Hash at ingestion**, not just at training time. Every object in the data lake (Lab 67) carries a hash in its metadata, and it is verified on read.
- **Training pipeline verifies** the manifest signature and recomputes shard hashes before the first step, so a tampered dataset blocks the job.
- **Unlearning / erasure:** Map PII subjects to shard hashes. On erasure requests, you know exactly which datasets, and therefore which models, are affected.
- **Model supply chain:** Sign model weights and engines. Kyverno verifies signatures at deploy time (Lab 70). Track model SBOMs (base model, adapters, datasets).
- **Standards:** C2PA for content provenance, SLSA levels for pipelines, OpenSSF model signing (OMS), and the EU AI Act GPAI training-data summary template.

## FAANG deep-dive notes

- **How big tech does it:** Data lineage systems track every dataset version used in training, and model artifacts are signed and traceable for legal, safety, and security reviews.
- **Staff review questions:** Can you prove which data trained model X? Is the manifest signed and verified before training? How does an erasure request map to models?
- **Interview question:** *"A copyright holder claims their data trained your model. Respond."* Strong answers cover content hashes, signed manifests, source and license records, inclusion proofs, and the lineage from model back to data.

**Typical system-design prompt:** *"Design data provenance for training sets so you can answer regulators (EU AI Act) and copyright claims about any model."*

**1. Clarify first:**
- Granularity: per shard, per file, or per record?
- Which questions must be answerable: "was X used?", "which data trained model Y?", "was data altered?"
- Retention and opt-out handling: what happens when data must be removed?

**2. Back-of-envelope sizing:**
- 5 PB dataset hashed at ~1 GB/s per core (SHA-256 with hardware acceleration): 5M core-seconds ≈ 58 core-days, or about 3 hours on 500 cores, done once at ingestion.
- Per-file manifest: 2B files × ~100 bytes (path + hash + size) ≈ 200 GB, fine in object storage or columnar tables.
- Proof size per file: ~31 hashes × 32 bytes ≈ 1 KB.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Granularity | per shard | per file / document | per document for copyright and opt-out questions |
| Structure | flat manifest | Merkle tree | Merkle for proofs and large sets |
| Signing | none | KMS/HSM keys, Sigstore | always sign roots and attestations |
| Format | custom | in-toto / SLSA / ML-BOM (CycloneDX) | standards for auditors |
| Opt-outs | ignore | record exclusions + retrain policy | log exclusions; define a retrain policy |

**4. Follow-up questions with crisp answers:**
- *Why a Merkle tree and not one hash of everything?* A single hash can prove that nothing changed, but not that one file was included without re-hashing all of it.
- *What does signing add?* Proof of *who* vouched for the root and that it hasn't changed since.
- *What is a training attestation?* A signed statement linking dataset roots, code, config, and the resulting model hash.
- *How does this help with the EU AI Act?* It supports technical documentation and data governance requirements for training data.
- *What about data deletion?* The manifest records what was used. For removal, you document exclusions and follow a retraining or unlearning policy.
- *Content hashes vs. paths?* Paths change and content hashes don't. Always store the content hash.

**Debug this (common onsite question):** *"A publisher claims their articles were used in training. The team says they were filtered out, but can't prove it."*
1. Filtering happened in a preprocessing job, but only the final shard hashes were recorded, not which documents went in.
2. Per-document lineage was never captured, so the team can't show absence.
3. The filter job's own output (excluded IDs) was deleted with temporary files.
4. Fix: record document-level manifests (included and excluded, with reasons), sign them, keep them with the model's attestation, and make the manifest step mandatory in the training pipeline.

The lesson: **you can only prove what you recorded at training time, including what you left out.**

**5. What separates senior from staff answers:**
- Senior: builds hashing, Merkle manifests, and signing into the data pipeline.
- Staff: designs end-to-end lineage (source → filter → shard → model) in standard formats, aligns it with legal and regulatory questions, and makes provenance a release gate for models.

**Red flags:** path-based lineage, unsigned manifests, no exclusion records, provenance added after training.

## Failure modes
- Hashing file *paths* instead of content means renames break lineage and a modified file with the same name passes.
- Manifest not signed, so anyone can edit it and the hashes prove nothing.
- Preprocessing outputs not hashed, so lineage is broken between raw and tokenized data.

## Checklist
- [ ] Manifest with a Merkle root generated for a dataset
- [ ] Manifest signed and verified in the training job entrypoint
- [ ] Model registry entry links model hash → dataset root → code commit
