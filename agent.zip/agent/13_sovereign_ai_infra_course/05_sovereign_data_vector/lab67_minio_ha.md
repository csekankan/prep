# Lab 67: Sovereign Storage Tiers — MinIO High Availability (3:57)

## Why it matters
Object storage holds your **crown jewels**: datasets, checkpoints, model weights, vector segments, and backups.
For sovereignty it must run on hardware you control, speak the S3 API (so all tools work), and survive
disk, node, and site failures.

## In plain words
MinIO is **your own S3 in your own building**. Erasure coding is like tearing a document into 16 pieces with clever spares, so you can lose
any 4 pieces and still rebuild it. Object Lock is a **time-locked safe**: nobody, not even an admin or ransomware, can delete what's inside until the timer ends.

## Architecture at a glance

```mermaid
flowchart TB
  CL[Training / serving / backups] -->|S3 API| LB[MinIO endpoint]
  LB --> HOT["Hot pool: NVMe, EC 12+4"]
  HOT -->|ILM after 30d| WARM["Warm pool: HDD"]
  HOT <-->|site replication| SITE2[(Site 2 MinIO)]
  KMS[KES + HSM] -.keys.-> HOT
  LOCK["Object Lock buckets: WORM"] --- HOT
```

**How to read it:** Clients use the S3 API. Data lands in an erasure-coded hot pool, tiers to warm storage over time, and replicates to a second site. Keys come from an HSM, and locked buckets are immutable.

## Core concepts

| Concept | Meaning |
|---|---|
| **Erasure coding (EC)** | Objects split into data + parity shards across drives. `EC:4` on 16 drives means 12 data + 4 parity, surviving 4 drive losses with ~75% usable capacity |
| **Server pool / erasure set** | Group of nodes/drives. Expand by adding pools |
| **Bitrot protection** | Per-shard hashing (HighwayHash), healed automatically |
| **Versioning + Object Lock (WORM)** | Immutable objects, ransomware protection, compliance retention |
| **Site replication** | Active-active across sites (buckets, IAM, policies) |
| **ILM tiering** | Hot NVMe pool → warm HDD pool / remote tier by age |
| **SSE-KMS** | Encryption with external KMS (KES + Vault/HSM) |

**Tier strategy for AI**

| Tier | Media | Data |
|---|---|---|
| Hot | NVMe | Active training shards, checkpoints, model weights for serving |
| Warm | HDD (high-density) | Older datasets, checkpoint history |
| Cold / archive | Remote/tape, Object Lock | Compliance retention, provenance evidence |

## Architecture in depth

The overview shows pools, tiers, and replication. This view shows **how one object is written with erasure coding** and why the
cluster survives losing drives or whole nodes.

```mermaid
flowchart LR
  PUT["PUT checkpoint-shard (64 MB)"] --> NODE[Any MinIO node]
  NODE --> SET{"Hash object name → erasure set of 16 drives"}
  SET --> SPLIT["Split into 12 data + 4 parity blocks"]
  SPLIT --> D1[Drive 1 node A] & D2[Drive 2 node B] & D3[...] & D16[Drive 16 node D]
  D1 & D2 & D3 & D16 --> QUO{"Write quorum: ≥ 13 acks?"}
  QUO -->|yes| ACK[200 OK to client]
  QUO -->|no| FAIL[Error: retry]
  GET["GET later: any 12 of 16 blocks"] --> REC[Reconstruct object]
  HEAL["Background healing: rebuild lost blocks"] -.-> D2
```

### Follow one 64 MB checkpoint shard
1. **Any node accepts.** The client writes through any MinIO node. There is no central metadata server to bottleneck.
2. **Pick an erasure set.** The object name is hashed to choose one set of 16 drives, spread across nodes.
3. **Split and encode.** The object is cut into 12 data blocks, and 4 parity blocks are computed (EC 12+4).
4. **Spread out.** Blocks go to 16 drives on different nodes, so one node failure loses only a few blocks.
5. **Quorum.** The write succeeds once enough drives confirm. Otherwise the client gets an error and retries, never a silent partial write.
6. **Read with any 12.** Reads reconstruct from any 12 blocks, so up to 4 drives can be lost.
7. **Healing.** When a drive is replaced, background healing rebuilds its blocks from the others.

**The one idea to keep:** erasure coding gives replication-like safety (survive 4 failures) for 33% overhead instead of 200%.

## Minimal hands-on

```bash
# MinIO Operator + a 4-node tenant (16 drives)
kubectl apply -k "github.com/minio/operator?ref=v6.0.4"
# Tenant CR (excerpt): pools: [{ servers: 4, volumesPerServer: 4, size: 4Ti, storageClassName: local-nvme }]

mc alias set lake https://minio.storage.svc admin <secret>
mc mb --with-lock lake/training-data
mc version enable lake/training-data
mc retention set --default COMPLIANCE 365d lake/provenance-evidence
mc ilm rule add lake/checkpoints --transition-days 30 --transition-tier WARM-HDD
```

## Worked example

**Scenario:** A defense contractor (air-gap-capable, Lab 94) needs **2 PB** usable for training data and checkpoints, with
no data loss on a site failure, and must survive ransomware.

| Requirement | Design |
|---|---|
| Throughput for 256-GPU checkpoints (~1 TB every 20 min, Lab 39) | Hot pool: 16 nodes × 12 NVMe, 2×100 GbE each, ~150 GB/s aggregate |
| Capacity 2 PB usable | Warm pool: 6 nodes × 60 HDD × 10 TB = 3.6 PB raw. At EC 12+4 (75%) that is ~2.7 PB usable, leaving ~35% headroom |
| Site failure | Site replication to a second data center 40 km away (synchronous-ish latency) |
| Ransomware | Object Lock COMPLIANCE on datasets + provenance; versioning on checkpoints |
| Encryption | SSE-KMS with keys in an on-prem HSM via KES |

A drill that pulled 2 nodes from the hot pool mid-checkpoint caused no write failures, and healing completed in 3 h.

## Production deep dive
- **Hardware:** Homogeneous nodes and drives per pool, JBOD (no RAID), XFS, and dedicated networks. Mixing drive sizes wastes capacity.
- **Network sizing:** Aggregate client throughput ≤ server NIC bandwidth minus EC overhead. AI checkpoint bursts are the peak load to size for.
- **IAM:** OIDC (Keycloak) and per-team policies. Training jobs get read-only access to datasets and write access to their own checkpoint prefix.
- **Monitoring:** Prometheus metrics (drive health, healing, request latency). Alert on offline drives and on capacity > 70%.
- **Licensing:** MinIO is AGPLv3 or commercial. Review it with legal. Alternatives: Ceph RGW, SeaweedFS, vendor appliances.

## FAANG deep-dive notes

- **How big tech does it:** Erasure-coded object storage with geo-replication and immutable retention for critical data. Storage capacity planning is driven by checkpoint bandwidth, not just total size.
- **Staff review questions:** What failure does the EC config survive? Is ransomware protection in place? Can the network handle checkpoint bursts?
- **Interview question:** *"Design storage for model checkpoints of a 70B training run."* Strong answers cover size per checkpoint, write bandwidth, tiering, retention, immutability, and restore speed.

**Typical system-design prompt:** *"Design sovereign object storage for 3 PB of training data and checkpoints, with on-prem only and ransomware protection."*

**1. Clarify first:**
- Workload mix: large sequential reads (training), bursty writes (checkpoints), small objects (logs)?
- Throughput needs (GB/s) during checkpoints.
- Compliance: retention and immutability requirements, key management.

**2. Back-of-envelope sizing:**
- 3 PB usable at EC 12+4 (75% efficiency) needs 4 PB raw, e.g. 8 nodes × 24 drives × 22 TB ≈ 4.2 PB raw.
- Throughput: 8 nodes × 2 × 100 GbE ≈ 200 GB/s network ceiling. NVMe hot tier for checkpoints (Lab 39 needs ~20 GB/s bursts), HDD for warm data.
- Rebuild: losing one 22 TB drive rebuilds in hours. Keep spare capacity of at least 1 node's worth.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Protection | 3× replication | erasure coding | EC for capacity; replication only for tiny clusters |
| EC ratio | 8+4 (more parity) | 12+4 (more efficient) | balance by drive size and rebuild time |
| Ransomware | backups only | Object Lock (WORM) + versioning | Object Lock on critical buckets |
| Encryption | disk-level | SSE with KMS/HSM (KES) | SSE-KMS with keys you hold |
| DR | single site | site replication | site replication for critical data |

**4. Follow-up questions with crisp answers:**
- *Why erasure coding instead of replication?* Similar fault tolerance at far lower overhead (33% vs. 200%).
- *What's a write quorum?* The minimum number of drives that must confirm for the write to count.
- *What is Object Lock?* WORM retention: objects can't be deleted or overwritten until the date, even by admins in compliance mode.
- *How do you expand?* Add a new server pool. Existing pools aren't rebalanced, and new objects spread by free space.
- *Why are small objects a problem?* Per-object overhead dominates. Batch logs and pack small files.
- *How does sovereignty show up?* On-prem hardware, keys in your own HSM, and no dependency on foreign cloud control planes.

**Debug this (common onsite question):** *"Checkpoint writes slowed 5× during a drive replacement, and training stalled."*
1. Healing for the replaced drive started at full speed, competing with checkpoint writes.
2. The affected erasure set was also the target for many checkpoint objects (hot prefix).
3. The network links of the node being healed were saturated.
4. Fix: throttle healing during peak hours, spread checkpoint object names (avoid sequential hot prefixes), keep checkpoints on a separate NVMe pool, and monitor healing impact.

The lesson: **storage maintenance competes with workloads. Throttle background work and isolate critical paths.**

**5. What separates senior from staff answers:**
- Senior: deploys MinIO with EC, TLS, KMS, Object Lock, and lifecycle rules.
- Staff: sizes capacity and throughput by workload tier, plans failure domains and rebuild impact, designs ransomware and DR posture, and owns the sovereign key-management story.

**Red flags:** no Object Lock on backups, keys stored with the data, a single pool for checkpoints and archives, no healing throttling.

## Failure modes
- Using a K8s distributed StorageClass under MinIO (double replication and slow performance). Use local drives.
- No Object Lock, so ransomware or a bad script deletes all checkpoints.
- Expanding a pool with differently sized nodes creates an imbalance.

## Checklist
- [ ] HA tenant with erasure coding running
- [ ] Versioning + Object Lock on critical buckets
- [ ] Drive/node failure drill executed
