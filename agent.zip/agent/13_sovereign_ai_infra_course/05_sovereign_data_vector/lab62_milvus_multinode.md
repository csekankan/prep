# Lab 62: Deploying Milvus Multi-Node on Kubernetes — The Scalable Neural Memory (3:48)

## Why it matters
Milvus is a cloud-native vector DB that **separates storage from compute**, so ingest, indexing, and query
can scale independently. It is designed to run on K8s with object storage you control (MinIO), which
makes it a natural fit for sovereign deployments.

## In plain words
Milvus splits the job like a **warehouse company**: front-desk staff (proxies), stock-takers who receive goods (data nodes), packers who
organise shelves (index nodes), pickers who fetch orders fast (query nodes), and a big cheap storage yard (MinIO). Each team can be
hired or reduced independently.

## Core concepts

```mermaid
flowchart TB
  C[Client SDK] --> P[Proxy<br/>stateless, routes]
  P --> COORD[Coordinators<br/>root/data/query/index → mixcoord]
  P --> QN[Query nodes<br/>serve search, hold segments in RAM]
  P --> SN[Streaming / Data nodes<br/>ingest, WAL]
  IN[Index nodes<br/>build HNSW/IVF, CPU or GPU] --> OBJ
  SN --> WAL[(WAL: Woodpecker / Kafka / Pulsar)]
  SN --> OBJ[(Object storage: MinIO/S3<br/>segments + indexes)]
  QN --> OBJ
  COORD --> ETCD[(etcd metadata)]
```

**How to read it:** Clients talk to stateless proxies. Coordinators manage metadata in etcd. Streaming nodes write the WAL, index nodes build indexes, and query nodes serve searches, all backed by object storage.

| Component | Scales with |
|---|---|
| Proxy | Client connections / QPS |
| Query nodes | Vector count in memory + search QPS |
| Data/streaming nodes | Ingest rate |
| Index nodes | Indexing backlog (bursty, so a good fit for spot, Lab 28) |
| etcd | Metadata (3 nodes, fast SSD) |
| Object storage | Total data (cheap, durable) |

**Segments:** Data arrives in *growing* segments (in memory, brute-force searchable), which are sealed, indexed, and
loaded on query nodes. **Consistency levels:** Strong, Bounded (default), Session, Eventually. This is a latency vs. freshness trade-off.

## Architecture in depth

The concepts diagram shows Milvus's components. This view follows **one inserted vector through its lifecycle**, from write to
indexed and searchable, because most production problems happen at the transitions.

```mermaid
sequenceDiagram
  participant C as Client
  participant P as Proxy
  participant S as Streaming node
  participant W as WAL
  participant O as Object storage
  participant I as Index node
  participant Q as Query node
  C->>P: insert(vector, tenant_id)
  P->>S: route to shard channel
  S->>W: append (durable, acked)
  S-->>Q: growing segment (searchable, brute force)
  S->>O: seal segment at ~1 GB → flush binlog
  O->>I: build HNSW index
  I->>O: store index files
  O->>Q: load sealed segment + index
  Q->>Q: release growing copy, search uses index
```

### Follow one vector from insert to indexed search
1. **Insert.** The client sends a vector. The proxy routes it to a shard's channel based on the primary key or partition key.
2. **Durable first.** The streaming node appends it to the WAL. Once acknowledged, the write survives crashes.
3. **Searchable quickly.** It sits in a *growing* segment, which is searched by brute force. Consistency level decides whether a query waits for it.
4. **Seal and flush.** When the segment reaches its size limit, it's sealed and written to object storage as binlogs.
5. **Index build.** An index node builds HNSW (or IVF) for the sealed segment and stores the index files.
6. **Load.** Query nodes load the sealed segment plus its index into memory.
7. **Compaction.** Later, small segments merge and deleted rows are purged, which keeps search fast.

**The one idea to keep:** in Milvus, durability (WAL), searchability (growing segment), and speed (indexed segment) happen at different moments. Monitor each step.

## Minimal hands-on

```bash
helm repo add zilliztech https://zilliztech.github.io/milvus-helm/
helm install vdb zilliztech/milvus -n vector --create-namespace \
  --set cluster.enabled=true \
  --set queryNode.replicas=3 --set indexNode.replicas=2 \
  --set minio.mode=distributed --set etcd.replicaCount=3
```

```python
from pymilvus import MilvusClient, DataType
c = MilvusClient("http://vdb-milvus.vector:19530")
schema = c.create_schema(auto_id=False)
schema.add_field("id", DataType.VARCHAR, is_primary=True, max_length=64)
schema.add_field("tenant", DataType.VARCHAR, max_length=32, is_partition_key=True)
schema.add_field("vec", DataType.FLOAT_VECTOR, dim=1024)
idx = c.prepare_index_params(); idx.add_index("vec", index_type="HNSW", metric_type="COSINE", params={"M": 16})
c.create_collection("docs_v1", schema=schema, index_params=idx, num_partitions=64)
c.search("docs_v1", data=[qvec], limit=10, filter='tenant == "acme"')
```

## Worked example

**Scenario:** A national library's sovereign research assistant: **1.2B paragraph vectors** from digitized books, ingest of 5M/day,
search at 500 QPS, everything on-prem.

| Layer | Sizing |
|---|---|
| Object store | MinIO 4-node erasure set, ~8 TB (vectors + indexes + binlogs) |
| Query nodes | 12 × (64 vCPU, 512 GB RAM) with IVF_PQ + a hot HNSW partition for recent works |
| Index nodes | 4 GPU (L4) nodes with CAGRA/GPU IVF build. Re-index 1.2B in ~9 h vs. ~3 days on CPU |
| Streaming | 3 nodes; WAL on Woodpecker/Kafka |
| Replicas | `replica_number=2` for collection load → survives a query-node loss |

Rolling upgrade test: killing one query node during load keeps p99 < 120 ms because the second replica serves.

## Production deep dive
- **Memory planning:** Query nodes must hold loaded segments plus indexes. Use mmap/DiskANN for cold data and monitor `memory_usage` per node.
- **Resource groups:** Pin heavy tenants' collections to dedicated query-node groups (noisy-neighbor isolation).
- **Security:** Enable authentication + RBAC, TLS on gRPC, NetworkPolicies, and encryption at rest via MinIO/KMS (Lab 67).
- **Backups:** `milvus-backup` to MinIO/S3, and/or Velero for the K8s state (Lab 68). Test restores.
- **Upgrade discipline:** Pin versions. Coordinate etcd, Milvus, and SDK compatibility. Stage in a pre-prod cluster with a production-shaped data sample.

## FAANG deep-dive notes

- **How big tech does it:** Retrieval systems separate ingest, indexing, and serving tiers so each scales independently, with object storage as the durable layer.
- **Staff review questions:** What happens when a query node dies? Is etcd on fast dedicated disks? How are heavy tenants isolated?
- **Interview question:** *"Why separate storage and compute in a vector DB?"* Strong answers cover independent scaling, cheap durability, elastic indexing, faster recovery, and the trade-off of added latency and complexity.

**Typical system-design prompt:** *"Run Milvus for 500M vectors with continuous ingestion of 5,000 vectors/s and 2,000 QPS searches."*

**1. Clarify first:**
- Freshness SLO: how soon must an insert be searchable?
- Delete/update rate (affects compaction load).
- Index type and memory budget per query node.

**2. Back-of-envelope sizing:**
- 500M × 768 dim × 4 bytes ≈ 1.5 TB raw. HNSW in RAM with replicas = 2 × ~1.8 TB ≈ 3.6 TB of query-node memory, e.g. 14 nodes × 256 GB usable. Consider int8 or DiskANN to halve this.
- Ingest: 5,000/s × 3 KB ≈ 15 MB/s into the WAL, which is modest. Index builds: 432M new vectors/day need continuous index-node capacity.
- etcd: small but latency-critical. 3 nodes on fast SSD, kept separate from noisy workloads.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Consistency | Strong | Bounded / Session | Bounded by default; Session for read-your-writes |
| Index nodes | always on | autoscaled / spot | autoscale on index backlog |
| Partitioning | partitions per tenant | partition key | partition key for many tenants |
| Memory | full RAM HNSW | mmap / DiskANN | mmap or disk indexes for cost at scale |
| WAL | Kafka/Pulsar | Woodpecker (built-in) | built-in for simplicity; Kafka if you already run it |

**4. Follow-up questions with crisp answers:**
- *Why is a newly inserted vector slower to search?* It's in a growing segment, searched by brute force until sealed and indexed.
- *What does compaction do?* It merges small segments and removes deleted rows. Without it, search slows and memory grows.
- *What fails if etcd is slow?* Coordinator operations, causing slow loads, stuck index tasks, and timeouts.
- *How do you scale queries?* Add query nodes and replicas, and the coordinator rebalances segments.
- *How do you handle a re-embedding with a new model?* A new collection, a dual-write or backfill, then an alias swap.
- *Strong consistency cost?* Queries wait for all prior writes to be visible, which adds latency.

**Debug this (common onsite question):** *"Search p99 rose from 40 ms to 300 ms over two weeks with no traffic change."*
1. Segment metrics: thousands of small segments, because the frequent small flushes were never compacted.
2. Index nodes run on spot and were frequently interrupted, so many segments were never indexed and are searched by brute force.
3. Deletes from GDPR erasure also accumulated without compaction.
4. Fix: tune flush and compaction settings, keep a small on-demand index-node baseline, and alert on unindexed segment count and segment count per collection.

The lesson: **vector DB latency degrades silently through background debt. Monitor segments and the index backlog.**

**5. What separates senior from staff answers:**
- Senior: deploys Milvus with HA etcd, sizes query nodes, picks consistency levels.
- Staff: owns the segment lifecycle (flush, index, compact), capacity planning for memory, re-embedding migrations, and SLOs on freshness and recall.

**Red flags:** etcd on shared slow disks, no compaction monitoring, all index nodes on spot, Strong consistency everywhere.

## Failure modes
- etcd on slow disks causes leader elections and makes the cluster unstable. Use NVMe and dedicated nodes.
- Growing segments never flushing (misconfigured) causes memory to climb until OOM.
- Collection not loaded with replicas, so one query-node failure means a search outage.

## Checklist
- [ ] Multi-node Milvus running with external/distributed MinIO and 3-node etcd
- [ ] Collection uses a partition key and has 2 replicas loaded
- [ ] Query-node kill test passes
