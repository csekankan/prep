# Lab 69: The Global Neural Bridge — Cross-Region Active-Active Replication (3:59)

## Why it matters
Global users want low latency. Regulators want data kept in place. Business continuity wants no single region
to be fatal. **Active-active** serves reads *and* writes in multiple regions at once, but it forces you to
handle conflicts, lag, and residency explicitly.

## In plain words
Each region keeps **its own diary** (Kafka log) and builds its own index from it. Only pages marked "public" are photocopied to other
regions. Private pages never leave home, so every region is fast and local, and the law is respected.

## Core concepts

| Pattern | Writes | Reads | RPO | Complexity |
|---|---|---|---|---|
| Backup/restore | One region | One region | Hours | Low |
| Active-passive (warm standby) | Primary | Primary (+ stale reads at standby) | Minutes | Medium |
| **Active-active** | All regions | All regions | ~Seconds | High |
| **Partitioned (geo-sharded) active-active** | Each region owns its data | Local + selective global | ~Seconds | High, and **the sovereign default** |

**Replicate events, not databases.** For RAG, the cleanest approach is to replicate the **ingestion stream** (Kafka
MirrorMaker 2 / Cluster Linking) and let each region embed and index locally. Each region's vector DB is a
*deterministic projection* of the event log. This avoids vendor-specific DB replication and makes conflicts tractable.

**Conflict handling**
- Use a single writer per key (home region owns `tenant_id`), which avoids conflicts entirely.
- Use last-writer-wins with a version/HLC timestamp for genuinely multi-writer data.
- CRDTs for counters/sets (e.g. usage metering).

## Architecture

```mermaid
flowchart LR
  subgraph EU["EU-Frankfurt"]
    KEU[Kafka EU] --> EEU[Embed] --> MEU[(Milvus EU)]
  end
  subgraph US["US-Virginia"]
    KUS[Kafka US] --> EUS[Embed] --> MUS[(Milvus US)]
  end
  subgraph IN["IN-Mumbai"]
    KIN[Kafka IN] --> EIN[Embed] --> MIN[(Milvus IN)]
  end
  KEU <-->|MM2: only topics tagged class=global| KUS
  KUS <-->|MM2: class=global| KIN
  KEU <-->|MM2: class=global| KIN
```

**How to read it:** Each region has its own Kafka, embedder, and Milvus. Only topics tagged global are mirrored between regions, and regional data never crosses.

Per-tenant data (`class=regional`) **never leaves its home region**. Shared public knowledge (`class=global`, e.g. product docs) is replicated everywhere.

## Architecture in depth

The architecture diagram shows regions mirroring global topics. This view follows **one global and one regional event** through
the system, and shows how the home-region rule prevents conflicts.

```mermaid
sequenceDiagram
  participant EU as EU writer (home of tenant 42)
  participant KEU as Kafka EU
  participant MM as MirrorMaker 2
  participant KUS as Kafka US
  participant MUS as Milvus US
  participant MEU as Milvus EU
  EU->>KEU: product-docs update (class=global)
  KEU->>MEU: embed + upsert locally
  KEU->>MM: topic tagged global → mirror
  MM->>KUS: eu.product-docs (prefixed, no loop)
  KUS->>MUS: embed + upsert in US
  EU->>KEU: tenant 42 contract (class=regional)
  KEU->>MEU: embed + upsert in EU only
  Note over MM: regional topics are never mirrored
  Note over EU,MUS: US write for tenant 42 → rejected, home region is EU
```

### Follow two events across regions
1. **Global event.** A product-docs update is written in the EU, tagged `class=global`.
2. **Local first.** EU's embedder indexes it into Milvus EU right away.
3. **Mirror.** MirrorMaker 2 copies only global topics to the US, under a prefixed topic name (`eu.product-docs`), which prevents replication loops.
4. **Embed in each region.** The US embeds the same event locally. Each region's index is a projection of the same log.
5. **Regional event.** Tenant 42's contract is tagged `class=regional`. It's indexed in the EU and never mirrored.
6. **Home-region rule.** A write for tenant 42 arriving in the US is rejected or forwarded, because only the home region writes a tenant's data, so there are no conflicts.
7. **Lag monitoring.** Replication lag per mirrored topic is the RPO for global data during a region failure.

**The one idea to keep:** replicate events, not databases, and give every key one home region. Most conflict problems then disappear.

## Minimal hands-on (MirrorMaker 2 via Strimzi, excerpt)

```yaml
kind: KafkaMirrorMaker2
spec:
  clusters: [{ alias: eu, bootstrapServers: kafka-eu:9093 }, { alias: us, bootstrapServers: kafka-us:9093 }]
  mirrors:
  - sourceCluster: eu
    targetCluster: us
    topicsPattern: "global\\..*"            # only global-class topics cross the border
    sourceConnector: { config: { replication.factor: 3, sync.topic.acls.enabled: "false" } }
```

## Worked example

**Scenario:** A global consulting firm runs a knowledge assistant in 3 regions, used by 60k staff.

| Data class | Example | Replication |
|---|---|---|
| Global | Methodology docs, public research | All regions (MM2) |
| Regional | Client engagement files | Home region only |
| Restricted | Government client work | Home region + air-gapped enclave (Lab 94) |

- **Read path:** The user hits the nearest region (GeoDNS, Lab 97) and searches local global data plus their home region's regional data. A cross-region query is federated *only if* the user is authorized and policy allows it, and the results (not raw data) return.
- **Failover drill:** The US region goes offline and its users route to the EU. They can access global data but **not** US-regional client files, which is legally intended. The status page says so clearly.
- Measured global replication lag is p95 **4.2 s**.

## Production deep dive
- **Embedding determinism:** Every region must use the same embedding model version and chunker, or vectors differ and search is inconsistent. Pin them through the registry (Lab 44).
- **Lag SLO and monitoring:** Alert on MM2 lag. Expose freshness per region.
- **Idempotent projection:** Regions can rebuild their vector DB from the replicated log (Lab 68), which doubles as DR.
- **Cost:** Cross-region egress for large documents adds up. Replicate text once and embed locally, rather than shipping vectors and text.
- **Legal review:** The data-class taxonomy and replication rules are legal artifacts. Encode them as policy (Lab 70) and audit them (Lab 99).

## FAANG deep-dive notes

- **How big tech does it:** Geo-partitioned data with home-region ownership, plus selective global replication. Conflict avoidance (single writer per key) is preferred over conflict resolution.
- **Staff review questions:** How is the data class enforced in replication config? What do users experience in failover? Are embedding versions identical across regions?
- **Interview question:** *"Design multi-region RAG with data residency."* Strong answers cover data classes, event-log replication, local projection, home-region ownership, failover within borders, and consistency trade-offs.

**Typical system-design prompt:** *"Serve RAG in EU, US, and India with local latency, sovereign data residency, and survival of a full region outage."*

**1. Clarify first:**
- Which data is global (shareable) vs. regional (must stay)?
- During a region outage, may another region serve that region's tenants (would data leave the region)?
- Latency target per region and write volume.

**2. Back-of-envelope sizing:**
- Cross-region RTT: EU–US ~80 ms, EU–IN ~120 ms. Synchronous cross-region writes would add that to every write, so use async replication.
- Mirroring volume: global topics at 500 events/s × 5 KB = 2.5 MB/s per link, negligible bandwidth.
- Region outage: regional tenants of the failed region are unavailable (residency), or served from an in-region standby site. That's a business decision, not a technical one.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Replication | DB-native | event log (MM2 / Cluster Linking) | event log for portability and control |
| Write model | multi-writer + conflict resolution | home region per key | home region per tenant |
| Consistency | synchronous global | async + lag SLO | async; publish the lag SLO |
| Regional DR | fail over to another region | second site within the same jurisdiction | in-jurisdiction DR for sovereign data |
| Classification | by topic name | by explicit data-class tag + policy | explicit tags enforced by policy (Lab 70) |

**4. Follow-up questions with crisp answers:**
- *Why replicate events instead of the vector DB?* Each region rebuilds deterministically, independent of DB vendor replication features.
- *How does MirrorMaker 2 avoid loops?* Prefixed remote topics plus source cluster aliases.
- *What if two regions must write the same key?* Last-writer-wins with hybrid logical clocks, or CRDTs for counters and sets.
- *What is the RPO for global data?* The replication lag at the moment of failure.
- *Can regional data ever be mirrored?* Only to sites in the same jurisdiction, enforced by policy, not convention.
- *How do consumers fail over?* MM2 checkpoints translate offsets, so consumers resume at the right point.

**Debug this (common onsite question):** *"An audit finds EU customer documents in the US vector index."*
1. Trace the documents: they arrived via the mirrored topic `eu.product-docs`.
2. A team reused the global product-docs topic for customer-specific annexes to save setup time.
3. Mirroring rules were based on topic names, so classification wasn't checked per event.
4. Fix: validate the data-class tag per event at the producer (Lab 64), filter in MM2 by header, purge US copies, add residency policy checks (Lab 70), and run a periodic audit query per region.

The lesson: **residency must be enforced on the data itself, not inferred from where it was published.**

**5. What separates senior from staff answers:**
- Senior: configures MM2 with global/regional topics and monitors lag.
- Staff: designs the data classification model, home-region ownership, in-jurisdiction DR, and continuous residency audits, and makes the outage trade-offs explicit to the business.

**Red flags:** synchronous cross-region writes, multi-writer without a conflict strategy, residency by topic naming convention, no lag SLO.

## Failure modes
- Topic-pattern misconfiguration replicates a regional topic globally, which is a **residency breach**. Guard it with policy plus a CI test.
- Split-brain writes to the same key in two regions without versioning produce silent overwrites.
- Different embedding model versions per region make results differ by user location.

## Checklist
- [ ] Data-class taxonomy (global/regional/restricted) defined
- [ ] MirrorMaker topic filter enforces it
- [ ] Region failover drill with documented user impact
