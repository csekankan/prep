# Lab 63: Kafka Streaming — Real-Time RAG Ingestion (4:41)

## Why it matters
Batch re-indexing once a night means the assistant answers with **yesterday's prices, policies, and
tickets**. Streaming ingestion makes new knowledge searchable within seconds, and it decouples producers from the
GPU-bound embedding workers.

## In plain words
Kafka is a **conveyor belt with a memory**. Every document change is placed on the belt, and embedding workers pick items off, process
them, and only then tick them as done. If a worker drops out, another picks up the unticked items. Nothing falls off the belt.

## Architecture at a glance

```mermaid
flowchart LR
  SRC["CDC / webhooks / files"] --> RAW[(docs.raw)]
  RAW --> VAL[Validator] -->|ok| VT[(docs.validated)]
  VAL -->|bad| DLQ[(docs.dlq)]
  VT --> EMB["Embed workers: consumer group, scale on lag"]
  EMB -->|upsert / delete on tombstone| MIL[(Milvus)]
  EMB -->|commit offset AFTER write| VT
```

**How to read it:** Sources write to a raw topic. A validator splits good from bad (DLQ). Embedding workers consume, write to Milvus, and only then commit their offset.

## Core concepts

| Kafka concept | RAG meaning |
|---|---|
| Topic | `docs.raw`, `docs.validated`, `docs.embedded`, `docs.dlq` |
| Partition | Unit of parallelism. Key by `doc_id` to keep per-document order |
| Consumer group | Embedding worker pool. Scale workers up to the partition count |
| Offset commit | "Processed up to here". Commit **after** writing to the vector DB |
| Compacted topic | Latest state per key (current doc version) |
| Schema Registry | Enforced Avro/Protobuf/JSON schemas between teams |

**Sources:** CDC from Postgres/Oracle (Debezium), SaaS webhooks (Lab 78), file drops (S3 events), app events.

**Delivery semantics:** Aim for **at-least-once delivery + idempotent upserts** keyed by `hash(doc_id, chunk_idx, version)`.
That gives effectively-once results without distributed transactions.

**Deletes matter:** A GDPR erasure or revoked document must emit a tombstone, and the worker must delete the vectors.
Otherwise the RAG system keeps serving deleted data.

## Architecture in depth

The overview shows the topic pipeline. This view shows **how partitions, keys, and consumer groups** make the pipeline ordered,
parallel, and safe to replay.

```mermaid
flowchart TB
  subgraph Topic["docs.validated (12 partitions)"]
    P0["P0: doc-17 v1, doc-17 v2, doc-93 v1"]
    P1["P1: doc-4 v1, doc-4 DELETE"]
    PN["P11: ..."]
  end
  PROD["Producer: key = doc_id"] -->|"hash(doc_id) % 12"| Topic
  subgraph CG["Consumer group embedders (6 pods)"]
    E1["pod 1: P0, P1"]
    E2["pod 2: P2, P3"]
    E6["pod 6: P10, P11"]
  end
  Topic --> CG
  CG -->|"upsert by doc_id + version"| MIL[(Milvus)]
  CG -->|"commit offset after write"| OFF[(__consumer_offsets)]
  LAG[Lag metric] --> KEDA[KEDA: scale pods ≤ 12]
```

### Follow one document update through the stream
1. **Key by document.** The producer uses `doc_id` as the message key, so all versions of one document go to the same partition.
2. **Ordering.** Within a partition, order is preserved: v1, then v2, then a delete (tombstone). Across partitions, there is no order, and none is needed.
3. **Parallelism.** Each partition is consumed by exactly one pod in the consumer group, and 12 partitions allow up to 12 pods.
4. **Process.** The pod chunks, embeds, and upserts into Milvus using `doc_id` + version, so a replay doesn't create duplicates.
5. **Commit after write.** Offsets are committed only after Milvus confirms. A crash before that means the message is reprocessed, which is safe because writes are idempotent.
6. **Deletes.** A tombstone removes the document's vectors, which matters for GDPR erasure.
7. **Scale on lag.** KEDA adds pods when the backlog grows, up to the partition count.

**The one idea to keep:** key by entity for ordering, commit after write for safety, and make writes idempotent so replays are harmless.

## Minimal hands-on

```bash
# Strimzi operator for Kafka on K8s
kubectl create ns kafka && kubectl apply -f 'https://strimzi.io/install/latest?namespace=kafka' -n kafka
```

```python
from confluent_kafka import Consumer
c = Consumer({"bootstrap.servers": "kafka:9092", "group.id": "embedders",
              "enable.auto.commit": False, "auto.offset.reset": "earliest"})
c.subscribe(["docs.validated"])

while True:
    msgs = c.consume(num_messages=256, timeout=1.0)
    if not msgs: continue
    events = [json.loads(m.value()) for m in msgs if m.value() is not None]
    deletes = [m.key().decode() for m in msgs if m.value() is None]     # tombstones
    vecs = embed([e["text"] for e in events])                            # batched → GPU (Triton)
    milvus.upsert("docs_v1", [{"id": e["chunk_id"], "tenant": e["tenant"], "vec": v}
                              for e, v in zip(events, vecs)])
    if deletes: milvus.delete("docs_v1", filter=f"doc_id in {deletes}")
    c.commit(asynchronous=False)                                         # only after durable write
```

## Worked example

**Scenario:** An airline's ops assistant must reflect **gate changes, delays, and policy updates within 60 s**.

| Stage | Throughput | Notes |
|---|---|---|
| Debezium CDC (flight DB) + CMS webhooks | Peaks of 4k events/s during disruptions | Keyed by `flight_id` / `doc_id` |
| Validation (Lab 64) | 4k/s | 0.3% to DLQ (malformed) |
| PII masking (Lab 65) | 4k/s | Passenger names tokenized |
| Embedding (24 partitions, 8 workers on L4 MIG slices) | 6k chunks/s capacity | Batched 256 |
| Milvus upsert (Bounded consistency) | — | Searchable in ~1–3 s |

End-to-end freshness p95 is **14 s**. During a snowstorm the backlog rose to 90 s. KEDA scaled the embedding
workers on **consumer lag** (not CPU) from 8 to 24, and the lag recovered in 6 minutes.

## Production deep dive
- **Autoscale on lag:** KEDA's Kafka scaler with `lagThreshold`. Max workers = partitions, so plan partitions for peak (they're hard to increase without rehashing keys).
- **Backpressure:** If the embedding cluster saturates, lag grows safely in Kafka. Never drop events. Set retention ≥ the worst-case recovery time (e.g. 7 days).
- **Ordering:** Same-key ordering lets version N+1 overwrite N. Include `version` in the payload and ignore stale updates.
- **Security:** mTLS + SASL, ACLs per topic, and encryption at rest. Kafka holds sensitive raw text, so treat it like a database.
- **Replay:** Re-embedding with a new model means resetting the consumer group offset on the compacted topic. Reprocess into `docs_v2`, then cut over.
- **Sovereignty:** Kafka clusters are per region. Cross-region mirroring (MirrorMaker 2) only for data classes allowed to move (Lab 69/70).

## FAANG deep-dive notes

- **How big tech does it:** Real-time indexing pipelines are event-driven with at-least-once delivery and idempotent writes, plus freshness SLOs and lag-based autoscaling.
- **Staff review questions:** What is the freshness SLO and current p95? How are deletes propagated? What is the replay plan when re-embedding?
- **Interview question:** *"Keep a RAG index fresh within 60 seconds of source changes."* Strong answers cover CDC, Kafka partitioning by key, idempotent upserts, tombstones, DLQ, lag-based scaling, and backpressure.

**Typical system-design prompt:** *"Design real-time RAG ingestion so that edits in Confluence, Jira, and the CRM are searchable within 60 seconds."*

**1. Clarify first:**
- Change volume (peak events/s) and document sizes.
- Deletion and permission-change propagation requirements.
- Backfill needs: re-embedding the whole corpus after a model change?

**2. Back-of-envelope sizing:**
- Peak 2,000 changes/s × 5 chunks each = 10,000 embeddings/s. At 2,500/s per GPU, that's 4 GPUs, so plan 6 for spikes.
- Partitions: target ≥ the max consumer count (e.g. 24), leaving room to scale without repartitioning.
- Retention: keep 7 days in Kafka, enough to replay after a vector DB restore (Lab 68).

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Delivery | at-most-once | at-least-once + idempotent writes | at-least-once + idempotency |
| Sources | polling | CDC (Debezium) / webhooks | CDC where possible |
| Bad data | drop | DLQ with reason | DLQ + replay tooling |
| Backfill | same topic | separate topic and consumers | separate, so it can't starve real-time |
| Permissions | at ingestion only | ACL metadata + query-time check | store ACLs; enforce at query time too |

**4. Follow-up questions with crisp answers:**
- *Why key by doc_id?* To keep per-document ordering. Otherwise a delete may be processed before the create.
- *Why can't you exceed the partition count in consumers?* Each partition goes to one consumer in a group, so extra pods sit idle.
- *Exactly-once?* Kafka transactions help within Kafka, but writes to Milvus must be idempotent anyway.
- *How do you handle a poison message?* Retry with a limit, then send it to the DLQ with the error, and don't block the partition.
- *How are permission changes handled?* They're events too: update ACL metadata on the vectors immediately.
- *How do you re-embed everything?* Replay from a compacted source topic into a new collection, then swap the alias.

**Debug this (common onsite question):** *"Deleted Jira tickets still show up in RAG answers days later."*
1. CDC emits delete events, but the validator rejects them, since the schema requires a body field that tombstones lack.
2. Rejected deletes go to the DLQ, which nobody monitors.
3. The vectors for deleted tickets remain searchable.
4. Fix: model deletes explicitly in the schema, alert on DLQ growth, run a nightly reconciliation (source IDs vs. vector DB IDs), and add an end-to-end delete test.

The lesson: **deletes are the easiest events to lose and the most expensive to miss. Test them end to end.**

**5. What separates senior from staff answers:**
- Senior: builds a keyed, at-least-once pipeline with DLQ and lag-based scaling.
- Staff: designs the end-to-end freshness SLO, delete and permission propagation, reconciliation, and backfill isolation, and owns the data contract with source teams.

**Red flags:** committing offsets before writes, non-idempotent upserts, an unmonitored DLQ, backfill sharing the real-time consumer group.

## Failure modes
- Auto-commit enabled, so the worker crashes after commit but before upsert and data is silently lost.
- Poison message causes an infinite retry and the partition stalls. Route to DLQ after N attempts.
- Tombstones not handled, so "deleted" documents keep surfacing in answers (a GDPR violation).

## Checklist
- [ ] Commit-after-write consumer implemented
- [ ] DLQ + tombstone handling tested
- [ ] Lag-based autoscaling and a freshness SLO dashboard
