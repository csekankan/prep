# Lab 70: Enforcing Data Residency Policies with Kyverno (3:51)

## Why it matters
"EU data must stay in the EU" written in a wiki is a hope. Written as an **admission policy**, it is a
guarantee: the cluster refuses to create anything that would violate it, and every decision is logged for auditors.

## In plain words
Kyverno is a **border guard at the cluster's front door**. Every new workload shows its papers: "Where will you run? Where will you store
data? Is your image signed?" No valid papers, no entry, and every decision is logged for the auditor.

## Architecture at a glance

```mermaid
flowchart LR
  DEV["kubectl / GitOps apply"] --> API[K8s API server]
  API --> KY{Kyverno admission}
  KY -->|"mutate: add EU affinity"| KY
  KY -->|"validate: region, storage, signed image"| OK[Admitted]
  KY -->|violation| DENY[Denied + reason]
  KY --> PR[(Policy reports → GRC audit)]
```

**How to read it:** Every apply goes through the API server to Kyverno. It can mutate (add EU affinity) and validate (region, storage, signature), then admits or denies, and records the result in policy reports.

## Core concepts

**Kyverno** is a K8s-native policy engine (policies are YAML, with no Rego to learn). Policy types:

| Type | Does | Residency example |
|---|---|---|
| **validate** | Allow/deny resources | Deny pods labeled `data-class=eu-pii` on nodes outside EU zones |
| **mutate** | Modify on admission | Inject EU node affinity automatically |
| **generate** | Create companion resources | Default-deny NetworkPolicy per new namespace |
| **verifyImages** | Check signatures/attestations | Only signed model-serving images (Lab 66) |
| **cleanup** | Delete on schedule | Expire temporary data workloads |

**Policy Reports** record pass/fail results for audits. **Background scans** catch existing violations, not just new ones.

Residency touches many layers at once: **compute placement, storage location, network egress, and image/model source**.

## Architecture in depth

The overview shows admission mutate-and-validate. This view shows **where residency is enforced across the whole lifecycle**,
because admission control is only one of several layers.

```mermaid
flowchart LR
  subgraph Shift_left["Before the cluster"]
    PR[Pull request] --> CI["CI: kyverno test / CLI<br/>same policies as cluster"]
  end
  subgraph Admission["At admission"]
    API[API server] --> MUT["Mutate: add EU node affinity<br/>+ region labels"]
    MUT --> VAL["Validate: storage class EU,<br/>signed image, data-class label"]
  end
  subgraph Runtime["After admission"]
    BG["Background scans:<br/>existing resources"]
    NET["Egress policy: block non-EU endpoints"]
    REP["PolicyReports → GRC dashboard"]
  end
  CI --> API
  VAL -->|admitted| BG
  VAL -->|denied| MSG["Clear error: which rule, how to fix"]
  BG --> REP
  NET --> REP
```

### Follow one deployment through every residency layer
1. **Pull request.** CI runs the same Kyverno policies with the CLI, so violations fail in review instead of at deploy time.
2. **Mutate.** At admission, Kyverno adds the EU node affinity and region labels automatically, so teams don't need to remember them.
3. **Validate.** It checks the storage class is EU-only, the image is signed (Lab 94), and the workload declares its data class.
4. **Deny with guidance.** A violation returns a message naming the rule and the fix. Good messages decide whether teams accept the policy.
5. **Background scans.** Resources created before a policy existed are scanned and reported, not just new ones.
6. **Runtime egress.** Network policies block calls to non-EU endpoints, since admission can't see where a running app sends data.
7. **Report.** PolicyReports feed the compliance dashboard as audit evidence.

**The one idea to keep:** residency is enforced in layers (CI, admission, runtime network, and audit reports). Admission alone can't stop data from leaving.

## Minimal hands-on

```yaml
apiVersion: kyverno.io/v1
kind: ClusterPolicy
metadata: { name: eu-data-residency }
spec:
  validationFailureAction: Enforce
  background: true
  rules:
  - name: eu-pii-pods-only-in-eu
    match: { any: [{ resources: { kinds: [Pod], namespaceSelector: { matchLabels: { data-class: eu-pii } } } }] }
    validate:
      message: "eu-pii workloads must pin to EU zones"
      pattern:
        spec:
          affinity:
            nodeAffinity:
              requiredDuringSchedulingIgnoredDuringExecution:
                nodeSelectorTerms:
                - matchExpressions:
                  - { key: topology.kubernetes.io/region, operator: In, values: ["eu-*"] }
  - name: eu-pii-storage-classes
    match: { any: [{ resources: { kinds: [PersistentVolumeClaim], namespaceSelector: { matchLabels: { data-class: eu-pii } } } }] }
    validate:
      message: "Use an EU-resident StorageClass"
      pattern: { spec: { storageClassName: "eu-*" } }
  - name: signed-model-images
    match: { any: [{ resources: { kinds: [Pod], namespaceSelector: { matchLabels: { data-class: eu-pii } } } }] }
    verifyImages:
    - imageReferences: ["registry.eu.corp/*"]
      attestors: [{ entries: [{ keyless: { issuer: "https://token.actions.githubusercontent.com", subject: "https://github.com/corp/ml-platform/*" } }] }]
```

Pair it with a **Cilium/Calico egress policy**: pods in `data-class=eu-pii` can reach only EU endpoints (FQDN allow-list).

## Worked example

**Scenario:** A fintech operates in the EU and the US on one multi-region K8s fleet (Karmada, Lab 91). An audit finds that an
analytics team once scheduled a batch embedding job on **US GPU nodes** with EU customer data, because those GPUs were free.

Controls introduced:
1. Namespaces labeled by data class, through a namespace provisioning pipeline (the label can't be changed by tenants, also enforced by Kyverno).
2. `validate` policies on compute placement + StorageClass + image registry (above).
3. `mutate` policy auto-injects EU affinity so developers don't have to remember it.
4. Egress policy blocks calls to non-EU LLM APIs from EU-PII namespaces (forcing the anonymization proxy route, Lab 65).
5. Policy Reports exported to the GRC system. The auditor gets a dashboard instead of screenshots.

Six months later: **217 blocked violations** (mostly misconfigured Helm values), zero residency incidents, and audit prep time reduced from 3 weeks to 2 days.

## Production deep dive
- **Rollout:** Start in `Audit` mode, review reports, fix workloads, then switch to `Enforce`. Never go straight to Enforce in a busy cluster.
- **Policy as code:** Policies live in Git with unit tests (`kyverno test`) and are deployed via GitOps. Changes require GRC approval.
- **Exceptions:** Use `PolicyException` resources with expiry and a ticket reference. No silent bypasses.
- **HA:** Kyverno's admission webhook runs with 3+ replicas. Decide the `failurePolicy` deliberately (fail-closed for residency).
- **Beyond K8s:** Residency also applies to backups (Lab 68), logs, Kafka mirroring (Lab 69), and SaaS tools. Policy at admission is necessary but not sufficient.

## FAANG deep-dive notes

- **How big tech does it:** Policy-as-code at admission plus continuous scanning, with exceptions as expiring, ticketed resources and policies tested in CI.
- **Staff review questions:** What is the failurePolicy? Can tenants change their own labels? Is the rollout audit-then-enforce?
- **Interview question:** *"Guarantee EU data never runs on US nodes in a shared fleet."* Strong answers cover namespace data-class labels, admission policies on placement, storage, and images, egress policy, federation constraints, and audit evidence.

**Typical system-design prompt:** *"Guarantee that EU personal data in a multi-region Kubernetes estate never lands outside the EU, and prove it to auditors."*

**1. Clarify first:**
- Data flows: storage, compute, logs, backups, and third-party APIs, all in scope?
- Exceptions process: who can approve non-EU processing, and how is it recorded?
- Cluster topology: EU-only clusters, or mixed clusters with EU node pools?

**2. Back-of-envelope sizing:**
- 40 clusters × ~30 policies = 1,200 policy instances. Manage them through GitOps, never by hand.
- Admission latency: Kyverno adds ~5–20 ms per request, fine. Keep webhook HA (3 replicas) and set failure policy deliberately.
- Background scans of 50k resources per cluster run in minutes, so schedule them hourly.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Engine | Kyverno (YAML) | OPA Gatekeeper (Rego) / ValidatingAdmissionPolicy (CEL) | Kyverno for mutate + generate; CEL for simple built-in checks |
| Failure policy | fail-open | fail-closed | fail-closed for residency, with HA webhooks |
| Rollout | enforce immediately | audit mode, then enforce | audit first, then enforce |
| Topology | mixed-region clusters | EU-only clusters | EU-only clusters are simpler to prove |
| Exceptions | ad hoc edits | PolicyException with expiry + approval | time-bound, recorded exceptions |

**4. Follow-up questions with crisp answers:**
- *Why mutate and validate?* Mutation makes compliance the default, and validation catches what mutation can't fix.
- *What does fail-closed risk?* If Kyverno is down, deployments are blocked, so run it HA and monitor it.
- *Why background scanning?* New policies don't re-check existing resources at admission.
- *What can't admission control see?* Runtime behaviour: API calls to external services, data written by apps. That needs egress controls.
- *How do you prove compliance?* PolicyReports, Git history of policies, exception records, and network logs.
- *Where else does data go?* Logs, traces, backups, and container registries, which all need residency too.

**Debug this (common onsite question):** *"All residency policies pass, yet traces with EU user prompts appear in a US observability SaaS."*
1. Pods are in the EU and storage is EU-only, so every admission policy passes.
2. The OpenTelemetry collector exports to a US endpoint, and traces include prompt text as span attributes.
3. No policy covers egress destinations or telemetry content.
4. Fix: egress network policies (EU endpoints only), an EU telemetry backend, attribute scrubbing in the collector, and a policy that validates collector exporter config.

The lesson: **data leaves through side channels: telemetry, logs, backups. Enforce residency on egress, not only on placement.**

**5. What separates senior from staff answers:**
- Senior: writes Kyverno mutate and validate policies with good messages and CI tests.
- Staff: designs layered residency controls (placement, egress, telemetry, backups), the exception process, and audit evidence, and chooses cluster topology to make compliance provable.

**Red flags:** admission-only residency, fail-open webhooks for sovereignty policies, untracked exceptions, ignoring telemetry and backups.

## Failure modes
- `failurePolicy: Ignore` means webhook downtime lets everything through.
- Policies only on Pods let a Deployment pass and its pods fail later. Kyverno auto-generates rules for controllers; verify it does.
- Tenants able to edit their own namespace labels bypass all policies.

## Checklist
- [ ] Residency policy for placement + storage + images
- [ ] Audit → Enforce rollout with Policy Reports reviewed
- [ ] Egress restrictions for sensitive namespaces
