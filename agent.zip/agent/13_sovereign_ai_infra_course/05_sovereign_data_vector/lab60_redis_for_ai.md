# Lab 60: Redis for AI — Semantic Caching, Vector Search, and Agent Memory (bonus lab)

## Why it matters
Almost every production AI platform runs Redis somewhere. It caches LLM answers, stores chat history and agent state, enforces rate
limits, and queues work. It can also serve as a vector database. Because it's in-memory, it's the fastest layer in the stack. It's
also the easiest to misuse: one instance doing six jobs with the wrong eviction policy can leak answers between tenants or silently
lose agent state.

## In plain words
Redis is the platform's **whiteboard next to the desk**. It's instant to read and write, and everyone can see it, but it's small and you
must decide what gets erased when it's full. A **semantic cache** is a whiteboard of past questions and answers. If someone asks
something that *means* the same thing as a question already on the board, you read the answer off the board instead of asking the expensive expert (the LLM) again.

## Architecture at a glance

```mermaid
flowchart LR
  APP[AI gateway / agents] --> C["Redis A: cache<br/>semantic + exact LLM cache<br/>allkeys-lru, TTLs"]
  APP --> S["Redis B: state<br/>chat history, agent checkpoints,<br/>leases, rate limits<br/>noeviction, AOF + replicas"]
  APP --> Q["Redis B: streams<br/>task queues (Labs 76, 80)"]
  APP --> V["Redis C: vector search<br/>small/hot indexes, < ~50M vectors"]
  V -.large corpora.-> MIL[(Milvus, Lab 62)]
  S -.durable record.-> PG[(Postgres)]
```

**How to read it:** The same technology plays different roles, and the roles need different settings. Caches may evict data. State must never be evicted. Vector search needs memory sized for indexes. That's why production platforms run **separate Redis instances per role**, and hand very large corpora to a dedicated vector database.

## Core concepts

**The six jobs Redis does in AI systems**

| Job | Data structure / feature | Eviction | Covered in |
|---|---|---|---|
| **Exact LLM cache** | String key = hash(model + prompt + params) | allowed (LRU + TTL) | this lab |
| **Semantic LLM cache** | Hash/JSON + vector index (Redis Query Engine) | allowed (LRU + TTL) | this lab |
| **Vector store for RAG** | Vector index: FLAT or HNSW, with TAG/NUMERIC/TEXT filters | never | this lab |
| **Conversation memory** | Lists/Streams (short-term), vectors (long-term recall) | never (TTL by policy) | this lab |
| **Agent state + leases** | Hashes, `SET NX PX`, Streams consumer groups | never | Lab 76 |
| **Rate limits, dedupe, idempotency** | Lua token buckets, `SETNX` + TTL | never | Labs 75, 78, 79 |

**Semantic caching in one paragraph:** Embed the incoming prompt, search the cache index for the nearest previous prompt *within the
same scope*, and return the stored answer if the distance is below a threshold. Redis reports cosine **distance** (1 − similarity),
so a threshold of 0.08 means "at least 92% similar".

**The cache key is more than the question.** An answer is only reusable if everything that shaped it is the same:

| Must match | Why |
|---|---|
| Tenant and access scope (ACL group) | Otherwise one user's answer, built from documents they can see, leaks to someone who can't |
| Model version + prompt template version | A new model or system prompt changes answers |
| Source data version (for RAG) | Answers go stale when the documents change |
| Language / locale | "Same meaning" in another language may need a different answer |

**What not to cache:** personalized answers ("my balance"), time-sensitive questions ("today's status"), tool-calling agent steps
with side effects, and anything containing personal data unless it's scoped to that user.

**Redis as a vector database:** The Redis Query Engine (built into Redis 8, formerly Redis Stack) indexes vectors with **FLAT** (exact)
or **HNSW** (approximate, Lab 61), with FLOAT32/FLOAT16 types and COSINE/L2/IP distance, and combines KNN with tag and numeric filters
in one query. Everything lives in RAM, so it's fast (single-digit ms) but costly per GB, which is why it fits hot or small indexes best.

**Licensing matters for sovereignty:** Redis moved away from the BSD licence in 2024 (RSALv2/SSPL) and added AGPLv3 as an option
with Redis 8. **Valkey** is the Linux Foundation fork of Redis 7.2 under BSD, protocol-compatible, with vector search via the
`valkey-search` module. For a sovereign platform, check the licence of the exact version and modules you deploy. Legal review decides, not engineering preference.

## Architecture in depth

The overview shows Redis's roles. This view follows **one question through the semantic cache**, including the scope check and
how cached answers are invalidated.

```mermaid
sequenceDiagram
  participant U as User (tenant acme, group finance)
  participant G as AI gateway
  participant E as Embedder (small model)
  participant R as Redis cache index
  participant L as LLM + RAG
  U->>G: "How do I reset my VPN token?"
  G->>G: skip cache? (personal / time-sensitive / tools) → no
  G->>G: scope = hash(acme, finance, model v12, prompt v7, kb v311)
  G->>E: embed prompt (~3 ms)
  G->>R: KNN 1 where tenant=acme AND scope=…
  R-->>G: nearest: "reset VPN token how?" distance 0.04
  G-->>U: cached answer (~10 ms total)
  Note over G,R: miss path (distance > 0.08)
  G->>L: full RAG + generation (~2 s)
  L-->>G: answer
  G->>R: store prompt vector + answer + scope, TTL 24h
  Note over R: KB update v312 → new scope, old entries expire unused
```

### Follow one question through the cache
1. **Decide if it's cacheable.** Rules skip personal, time-sensitive, and tool-using requests before any lookup.
2. **Build the scope.** Tenant, access group, model version, prompt version, and knowledge-base version are hashed into one scope tag.
3. **Embed.** A small embedding model turns the prompt into a vector in a few milliseconds.
4. **Filtered nearest-neighbour search.** Redis searches *only* entries with the same tenant and scope, so the filter is part of the KNN query and not applied afterwards.
5. **Hit.** A distance of 0.04 is below the 0.08 threshold, so the stored answer returns in about 10 ms instead of 2 seconds. No GPU was used.
6. **Miss.** Above the threshold, the request goes through normal RAG and generation, and the result is stored with its scope and a TTL.
7. **Invalidate by versioning.** When the knowledge base updates, the scope hash changes, so old entries are never matched again and simply expire. There's no risky bulk delete.

**The one idea to keep:** a semantic cache is only safe when the scope (who, which model, which data) is part of the lookup. The similarity threshold controls the trade-off between savings and wrong answers.

## Minimal hands-on — a scoped semantic cache with raw Redis commands

```python
import hashlib, numpy as np, redis

r = redis.Redis()
DIM = 768

r.execute_command(
    "FT.CREATE", "cache_idx", "ON", "HASH", "PREFIX", "1", "cache:",
    "SCHEMA", "tenant", "TAG", "scope", "TAG",
    "vec", "VECTOR", "HNSW", "6", "TYPE", "FLOAT32", "DIM", DIM, "DISTANCE_METRIC", "COSINE",
)

def scope_of(acl_group, model_v, prompt_v, kb_v):
    return hashlib.sha256(f"{acl_group}|{model_v}|{prompt_v}|{kb_v}".encode()).hexdigest()[:16]

def lookup(tenant, scope, qvec, max_dist=0.08):
    q = f"(@tenant:{{{tenant}}} @scope:{{{scope}}})=>[KNN 1 @vec $v AS dist]"
    res = r.execute_command("FT.SEARCH", "cache_idx", q, "PARAMS", "2", "v",
                            qvec.astype(np.float32).tobytes(), "RETURN", "2", "answer", "dist", "DIALECT", "2")
    if res[0] == 0:
        return None
    f = dict(zip(res[2][::2], res[2][1::2]))
    return f[b"answer"].decode() if float(f[b"dist"]) <= max_dist else None

def store(tenant, scope, qvec, answer, ttl=86400):
    key = f"cache:{tenant}:{hashlib.sha256(qvec.tobytes()).hexdigest()[:16]}"
    r.hset(key, mapping={"tenant": tenant, "scope": scope, "answer": answer,
                         "vec": qvec.astype(np.float32).tobytes()})
    r.expire(key, ttl)
```

Libraries such as **RedisVL** (`SemanticCache`, `SemanticRouter`, message history) wrap the same pattern. The raw version shows what
they do underneath: a filtered KNN query plus a distance threshold.

## Worked example

**Scenario:** An internal IT and HR assistant for a 40,000-employee company handles **2M questions per month**. Many are repeats
("reset VPN", "holiday policy"). LLM cost averages **$0.004 per question**, and p95 latency is 2.1 s.

| Decision | Choice | Why |
|---|---|---|
| Cache scope | tenant + ACL group + model v + prompt v + KB v | No cross-group leakage, auto-invalidation on updates |
| Threshold | distance 0.08, tuned on 2,000 labelled pairs | 1.2% false hits at 0.12 vs. 0.3% at 0.08 |
| Excluded | personal questions (detected by rules + classifier), tool calls | Never reuse "my payslip" answers |
| Vector type | FLOAT16, 768 dims | Halves memory with no measurable hit-rate change |
| TTL | 24 h (FAQ-style), 1 h (IT status pages) | Bounds staleness |
| Deployment | dedicated cache Redis, `allkeys-lru`, 1 primary + 1 replica | Eviction is fine for a cache, but not for agent state |

**Result:**
- **Hit rate:** 31% of questions are served from the cache, and 620k LLM calls a month are avoided, saving about **$2,500 a month**. GPU peak load drops by about 30%, which delayed one GPU purchase.
- **Latency:** cache hits take 12 ms at p95, against 2.1 s for misses.
- **Memory:** 1.5M live entries × (1.5 KB vector + ~1.5 KB answer + ~0.5 KB index and overhead) ≈ **5 GB**.

## Production deep dive
- **Separate instances by role.** Cache: `allkeys-lru` with TTLs, so losing it only costs money. State, memory, and queues: `noeviction`, AOF `everysec`, replicas across zones, and a database as the system of record where loss is unacceptable (Lab 76). Mixing them means a cache spike can evict agent state.
- **Memory sizing for vectors.** 768-dim FLOAT32 = 3 KB per vector, plus the HNSW graph (roughly 10–30% more, depending on `M`). 10M vectors ≈ 35–40 GB of RAM before replicas. FLOAT16 halves the vector part. Beyond tens of millions of vectors, a disk- or compression-based vector database (Labs 61–62) is usually cheaper.
- **Threshold tuning is an evaluation task.** Label pairs of "same intent" and "different intent" prompts from real traffic, sweep the threshold, and pick it from the false-hit rate you can tolerate. Re-tune when you change the embedding model.
- **Kubernetes.** Run Redis or Valkey as a StatefulSet through an operator, with persistent volumes for AOF, pod anti-affinity across zones, PodDisruptionBudgets, and `maxmemory` set below the container limit (leave ~25% for fragmentation, replication buffers, and forks during AOF rewrite).
- **Scaling.** Redis Cluster spreads keys across shards. Check whether your edition supports search queries across cluster shards. If not, shard indexes by tenant at the application level.
- **Security.** Use TLS, ACL users per service (the cache service can't read agent state), no `KEYS *` or `FLUSHALL` for app users, and keep personal data out of cache keys and logs (Lab 65).
- **Observability.** Track hit rate, false-hit rate from sampled evaluation, p99 lookup latency, memory and evictions, and keyspace size per tenant.
- **Managed alternatives.** Redis's LangCache and cloud-managed Redis/Valkey exist. For sovereign deployments, check where the data and embeddings are processed.

## FAANG deep-dive notes

- **How big tech does it:** Large LLM products cache aggressively at several levels: exact-match response caches, semantic caches for FAQ-like traffic, and the engine's own prefix KV cache (Lab 47). Every level is scoped by user permissions and model version. In-memory stores are split by role and durability needs.
- **Staff review questions:** What's the false-hit rate, and how was it measured? What exactly is in the cache scope? What happens to agent state if the cache instance fills up?
- **Interview question:** *"Add caching to cut LLM cost for a support assistant."* Strong answers separate exact, semantic, and prefix caching, define scope and invalidation, tune the threshold with labelled data, and exclude personal and tool-calling requests.

**Typical system-design prompt:** *"Cut LLM spend by 30% for a multi-tenant assistant with 50M requests a month, without serving wrong or leaked answers."*

**1. Clarify first:**
- How repetitive is traffic? (Sample and cluster a week of prompts.)
- Tenancy and permission model: can two users in one tenant see different documents?
- How fresh must answers be after source documents change?

**2. Back-of-envelope sizing:**
- If 35% of prompts have a near-duplicate within 24 h and the cache catches 80% of them safely, the hit rate is ~28%. At $0.005 per request that saves 14M × $0.005 ≈ **$70k per month**.
- Memory: 50M requests a month ≈ 1.7M a day. With a 24 h TTL, at most ~1.7M live entries × ~3.5 KB ≈ 6 GB per tenant set. Plan ~10–20 GB with headroom and growth, on 1–2 primaries with replicas.
- Lookup cost: embedding (~3 ms) + KNN (~1–3 ms), which is negligible next to a 2 s generation.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Cache type | exact match | semantic | exact first (zero risk), semantic for FAQ-like traffic |
| Threshold | loose (more hits) | strict (fewer wrong answers) | strict; tune on labelled pairs |
| Scope | tenant only | tenant + ACL + versions | full scope always |
| Invalidation | delete on change | version in scope + TTL | versioned scope, with TTL as backstop |
| Store | Redis / Valkey | vector database | Redis for hot caches; vector database for large corpora |
| Topology | one shared Redis | instances per role | separate cache from state |

**4. Follow-up questions with crisp answers:**
- *Semantic cache vs. prefix (KV) cache?* A semantic cache skips the LLM entirely for similar questions. A prefix cache (Lab 47) still runs the LLM but skips recomputing shared prompt tokens. They complement each other.
- *How do you measure false hits?* Sample cached responses, have an LLM judge or humans compare them to fresh answers, and track the mismatch rate per tenant.
- *Why does scope need the ACL group?* RAG answers depend on which documents the user may see, so a cached answer can carry information from restricted documents.
- *Why FLOAT16 vectors?* Half the memory, with negligible effect on nearest-neighbour ranking for caching.
- *Why separate Redis instances?* Different eviction and durability rules. A cache must evict, and state must not.
- *Redis or Valkey?* Functionally similar for these patterns. The choice is mostly about licence, support, and module availability for your version.

**Debug this (common onsite question):** *"After launching the semantic cache, an HR user saw salary-band details in an answer to a generic question."*
1. The cached answer was originally generated for an HR manager whose RAG context included restricted salary documents.
2. The cache scope contained tenant and model version, but not the user's ACL group.
3. A generic employee asked a similar question, got distance 0.05, and received the manager's answer.
4. Fix: add the ACL group (or a hash of the user's document permissions) to the scope, never cache answers built from restricted documents unless scoped to that permission set, purge the existing cache, and add a red-team test that asks similar questions across permission levels.

The lesson: **a semantic cache returns answers to people who didn't ask the original question. Anything that affected the answer must be in the cache scope.**

**5. What separates senior from staff answers:**
- Senior: builds a scoped semantic cache with a tuned threshold and TTLs, and separates cache from state instances.
- Staff: designs the multi-level caching strategy (exact, semantic, prefix), the permission-aware scope model, false-hit measurement, cost and memory economics, and the Redis-vs-Valkey-vs-vector-database decision, including licensing for sovereign deployment.

**Red flags:** cache scope without permissions, a threshold picked by gut feeling, caching personal or tool-calling responses, one Redis instance for cache and agent state, no false-hit metric.

## Failure modes
- Cache and agent state share one instance with `allkeys-lru`, so a traffic spike evicts checkpoints and agents restart from scratch.
- The threshold is loosened to raise the hit rate, and similar but different questions ("reset VPN" vs. "set up VPN") get wrong answers.
- The embedding model changes but old cache entries remain, so distances become meaningless and hits turn random.
- `maxmemory` is set equal to the container limit, so the pod is OOM-killed during an AOF rewrite.

## Checklist
- [ ] Separate Redis/Valkey instances for cache and for state, each with the right eviction policy
- [ ] Cache scope includes tenant, ACL group, model, prompt, and data versions
- [ ] Threshold tuned on labelled prompt pairs, with false-hit rate monitored
- [ ] Exclusion rules for personal, time-sensitive, and tool-calling requests
- [ ] Memory sized for vectors + index + overhead, with `maxmemory` below the container limit
- [ ] Licence of the exact Redis/Valkey version and modules reviewed for your deployment
