# Lab 61: Vector Database Topologies — Scale and Sharding (3:58)

## Why it matters
A demo RAG has 10k vectors in memory. An enterprise has **1–10 billion** vectors across tenants,
languages, and document versions. Index choice, sharding, and replication decide recall, latency, and cost.

## In plain words
A vector database is a **library organised by meaning**, not alphabet. With billions of books you need several buildings (**shards**),
photocopies of each building so many readers can visit at once (**replicas**), and separate floors per customer (**partitions**) so
nobody searches the whole city for one book.

## Architecture at a glance

```mermaid
flowchart LR
  Q[Query vector + tenant filter] --> PX[Proxy]
  PX --> S1["Shard 1: replica a / b"]
  PX --> S2["Shard 2: replica a / b"]
  PX --> S3["Shard 3: replica a / b"]
  S1 & S2 & S3 --> MG[Merge top-k]
  MG --> RR[Reranker] --> LLM[LLM context]
```

**How to read it:** A query with a tenant filter goes to a proxy, fans out to every shard (each with replicas), and the results are merged, reranked, and passed to the LLM.

## Core concepts

**Index families**

| Index | How | Recall/latency | Memory | Use |
|---|---|---|---|---|
| FLAT | Brute force | Perfect / slow | 1× | < 1M vectors, ground truth |
| **HNSW** | Navigable graph | Excellent / fast | 1.5–2× (graph) | Default for < 100M per node |
| IVF_FLAT | k-means clusters, probe `nprobe` | Good / fast | ~1× | Large, tunable |
| IVF_PQ / ScaNN | Clusters + product quantization | Good / very fast | **10–30× smaller** | Billions |
| DiskANN | Graph on SSD | Good / fast | Mostly SSD | Billions on cheap hardware |
| GPU (CAGRA) | GPU graph | Excellent / ultra-fast | GPU HBM | High QPS |

**Memory math:** 1B vectors × 768 dims × 4 bytes (fp32) = **3 TB raw**. HNSW adds about 50% more.
With PQ (96 bytes/vector) it becomes **~96 GB**.

**Scaling dimensions**
- **Sharding** (scale data): split vectors across nodes. Each query fans out to all shards and results are merged (scatter-gather).
- **Replication** (scale QPS + HA): copies of each shard.
- **Partitioning** (prune search): by tenant/date/language, so queries touch only the relevant partitions.

```
Query ─► Proxy ─┬─► Shard 1 (replica a|b) ─┐
                ├─► Shard 2 (replica a|b) ─┼─► merge top-k ─► rerank ─► LLM
                └─► Shard 3 (replica a|b) ─┘
```

## Architecture in depth

The overview shows a query fanning out to shards. This view looks **inside one shard's HNSW index** and shows how a search walks the
graph, which is what the recall and latency knobs actually control.

```mermaid
flowchart TB
  Q[Query vector] --> L2["Layer 2 (few nodes): long jumps"]
  L2 -->|"greedy: move to closer neighbour"| L1["Layer 1: medium jumps"]
  L1 --> L0["Layer 0 (all vectors): fine search"]
  L0 --> BEAM["Beam of ef candidates<br/>ef = 64 → explore 64 best so far"]
  BEAM --> FILT{"Filter tenant_id = 42?"}
  FILT -->|"pre-filter / filtered traversal"| TOPK[Top-k = 10 for this shard]
  TOPK --> MERGE[Proxy merges shard results]
  subgraph Knobs["Build/search knobs"]
    M["M: links per node → memory + recall"]
    EFC["efConstruction: build quality"]
    EFS["ef (search): recall vs latency"]
  end
```

### Follow one search inside a shard
1. **Enter at the top.** HNSW has layers. The top layer has a few nodes with long-range links, like motorways.
2. **Greedy descent.** At each layer, the search moves to whichever neighbour is closest to the query, then drops down a layer.
3. **Beam search at the bottom.** On layer 0, which holds every vector, it keeps the `ef` best candidates and explores their neighbours.
4. **Filter.** The tenant filter is applied during traversal. Filtering *after* the search can leave fewer than k results.
5. **Return top-k.** Each shard returns its best 10, and the proxy merges them across shards.
6. **Knobs.** Bigger `ef` explores more and raises recall but costs latency. Bigger `M` gives more links, better recall, and more memory.

**The one idea to keep:** approximate search is a dial between recall and latency. Measure recall on your data, then pick `ef` and `M` to hit the target cheaply.

## Minimal hands-on — measure recall vs. latency

```python
import numpy as np, faiss, time
d, n = 768, 200_000
xb = np.random.rand(n, d).astype("float32"); xq = xb[:1000] + 0.01
flat = faiss.IndexFlatIP(d); flat.add(xb); _, gt = flat.search(xq, 10)

hnsw = faiss.IndexHNSWFlat(d, 32); hnsw.hnsw.efConstruction = 200; hnsw.add(xb)
for ef in (16, 64, 256):
    hnsw.hnsw.efSearch = ef
    t = time.time(); _, I = hnsw.search(xq, 10); dt = (time.time() - t) / len(xq) * 1e3
    recall = np.mean([len(set(I[i]) & set(gt[i])) / 10 for i in range(len(xq))])
    print(f"ef={ef:>3} recall@10={recall:.3f} latency={dt:.2f}ms")
```

## Worked example

**Scenario:** A pan-EU retailer runs product search plus support RAG. **800M chunks**, 1024-dim, 24 languages,
3,000 QPS peak, p99 < 80 ms, 2,000 B2B tenants.

| Decision | Choice | Why |
|---|---|---|
| Vector dtype | fp16 + IVF_PQ for cold, HNSW for hot tenants | 3.2 TB raw becomes ~300 GB working set |
| Partition key | `tenant_id` (+ `lang`) | Queries scan 1 partition, not 800M vectors |
| Shards | 16 | ~50M vectors/shard fits node RAM with HNSW |
| Replicas | 2 per shard (3 for top tenants) | QPS and zone failure |
| Hybrid search | BM25 + dense, reciprocal rank fusion | SKUs/part numbers need lexical match |
| Rerank | Cross-encoder on top-50 (Triton) | +12% answer accuracy |

Result: p99 62 ms, recall@10 0.95. Cost is ~40% of an all-HNSW-in-RAM design.

## Production deep dive
- **Multi-tenancy models:** a collection per tenant (strong isolation, but overhead at thousands of tenants), a partition per tenant (balanced), or a shared collection with a metadata filter (cheapest, with filter performance and isolation risks). Choose per tenant size and compliance tier.
- **Filtered search:** Metadata filters (ACLs!) combined with ANN can wreck recall. Test with real ACL selectivity.
- **Re-embedding:** Changing the embedding model means re-indexing everything. Version collections (`docs_v3_bge-m3`) and dual-write during migration.
- **Benchmark honestly:** Use your data, your filters, and your concurrency (VectorDBBench). Vendor benchmarks are marketing.
- **Choices:** Milvus (Lab 62), Qdrant, Weaviate, pgvector (≤ ~50M with care), Elasticsearch/OpenSearch, Vespa.

## FAANG deep-dive notes

- **How big tech does it:** Billion-scale retrieval uses quantized indexes, partitioning by tenant or locale, hybrid lexical + dense retrieval, and reranking. Recall is measured against exact search on samples.
- **Staff review questions:** What is recall@k at your latency target? How are ACL filters applied? What is the memory plan for 10× growth?
- **Interview question:** *"Design vector search for 1 billion documents."* Strong answers cover memory math, index choice (HNSW vs. IVF-PQ vs. DiskANN), sharding and replication, partitioning, hybrid search, reranking, and re-embedding strategy.

**Typical system-design prompt:** *"Design vector search for 2 billion chunks with 5,000 QPS at p99 under 50 ms and recall@10 ≥ 0.95."*

**1. Clarify first:**
- Embedding dimension and type (768 float32? Can you quantize?).
- Filters: per-tenant, per-ACL, by date?
- Freshness: how fast must new documents be searchable?

**2. Back-of-envelope sizing:**
- Raw vectors: 2B × 768 × 4 bytes = 6.1 TB. HNSW graph adds ~10–20% more. That's too big for RAM cheaply.
- Options: IVF-PQ (compress ~16–32× → ~200–400 GB in RAM, rerank with full vectors from SSD), DiskANN (graph on SSD, small RAM cache), or FP16/int8 HNSW.
- Shards: at ~200M vectors per shard → 10 shards × 2 replicas. 5,000 QPS ÷ 2 replicas = 2,500 QPS per shard replica, so plan 3 replicas for headroom.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Index | HNSW in RAM | IVF-PQ / DiskANN | HNSW below ~100M vectors; compressed or disk beyond |
| Sharding | by hash | by tenant | tenant sharding when queries are single-tenant |
| Filtering | post-filter | pre-filter / filtered graph | filtered search for selective filters |
| Precision | float32 | int8 / binary + rerank | quantize, then rerank the top 100 |
| Freshness | batch rebuild | growing segments + background index | streaming inserts with periodic compaction |

**4. Follow-up questions with crisp answers:**
- *Why not exact search?* 2B distance computations per query is far too slow. ANN visits a tiny fraction.
- *What's recall@10?* The fraction of the true top-10 neighbours the index returns.
- *Why does post-filtering fail?* If the filter matches 1% of data, the top-100 ANN results may contain none of it.
- *How does reranking help?* Fast compressed search gets 100 candidates, and exact or cross-encoder scoring picks the best 10.
- *When shard by tenant?* When almost all queries are within one tenant, so only one shard is searched.
- *How do you measure recall in production?* Periodically run exact search on a sample and compare.

**Debug this (common onsite question):** *"Search quality complaints rose after onboarding a large customer, though recall benchmarks look fine."*
1. The benchmark uses unfiltered queries. Production queries filter by tenant.
2. Small tenants match < 0.1% of vectors, so filtered HNSW traversal hits dead ends and returns few relevant results.
3. The large customer's vectors dominate the graph neighbourhoods.
4. Fix: partition by tenant (or a partition key for small tenants), measure *filtered* recall per tenant size, and raise `ef` for highly selective filters.

The lesson: **benchmark the queries you actually run, filters included.**

**5. What separates senior from staff answers:**
- Senior: picks an index type, tunes `ef`/`M`, measures recall vs. latency.
- Staff: sizes memory vs. compression vs. disk for cost, designs sharding around query patterns and tenancy, and builds continuous recall monitoring with filters.

**Red flags:** recall never measured, unfiltered benchmarks only, all vectors in float32 RAM at billion scale, post-filtering selective ACLs.

## Failure modes
- No partitioning, so every tenant query scans everything and latency grows with each new customer.
- ACL filtering done *after* top-k retrieval returns 0 results or leaks unauthorized docs into context.
- HNSW graph memory not budgeted, so nodes OOM when the index grows.

## Checklist
- [ ] Recall vs. latency curve measured for 2 index types
- [ ] Memory sized for the target vector count
- [ ] Tenancy model chosen and justified
