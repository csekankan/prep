# Lab 68: Disaster Recovery — Velero Backups for Vector Stores (4:09)

## Why it matters
Rebuilding a billion-vector index from source means **re-embedding everything**: days of GPU time,
plus the source systems must still have every document. A vector store is a derived asset that is
**expensive to regenerate**, so back it up like a primary database.

## In plain words
A backup you've never restored is a **parachute you've never opened**. Velero packs up your cluster's setup and disks, and native vector
backups save the index itself. A restore drill is jumping with a spare chute on, so you find problems before the real emergency.

## Architecture at a glance

```mermaid
flowchart LR
  MIL[(Milvus)] -->|milvus-backup every 4h| BK[(Immutable MinIO bucket)]
  K8S[K8s objects + PVCs] -->|Velero nightly| BK
  KAF[(Kafka retention)] --> RP[Replay events since backup]
  BK --> RS[Restore to new collection]
  RP --> RS
  RS --> VAL["Validate counts + recall"] --> SW[Swap alias → live]
```

**How to read it:** Two backup streams (native vector backups and Velero) land in an immutable bucket. To recover, restore into a new collection, replay Kafka events since the backup, validate, and swap the alias.

## Core concepts

| Term | Meaning |
|---|---|
| **RPO** | Max acceptable data loss (time since last good backup) |
| **RTO** | Max acceptable time to restore service |
| **Velero** | Backs up K8s resources (CRDs, PVCs, Secrets) + volume data (CSI snapshots or file-level via Kopia) to S3/MinIO |
| **App-consistent backup** | Flush/quiesce the app before snapshot (Velero pre/post hooks) |
| **Native backup tools** | `milvus-backup`, Qdrant snapshots, `pg_dump`/pgBackRest for pgvector |

**Layered DR strategy for a vector platform**

| Layer | Tool | Protects against |
|---|---|---|
| K8s objects (Deployments, CRs, configs) | Velero / GitOps repo | Cluster loss, accidental deletion |
| Vector data (segments, indexes) | Native backup → MinIO (immutable) | Corruption, bad upserts, ransomware |
| Volume snapshots (etcd, local state) | Velero CSI snapshots | Node/disk loss |
| Source of truth (Kafka compacted topics, data lake) | Retention + replication | "Rebuild from scratch" last resort |

## Architecture in depth

The overview shows backup streams and restore. This view follows **one recovery timeline** after a disaster, showing where RPO
and RTO come from minute by minute.

```mermaid
gantt
  title Recovery after vector store loss at 14:00 (last backup 12:00)
  dateFormat HH:mm
  axisFormat %H:%M
  section Incident
  Writes since last backup at risk :crit, 12:00, 14:00
  Detect and declare disaster :14:00, 14:10
  section Restore
  Velero restores namespace, PVCs, configs :14:10, 14:25
  milvus-backup restores to new collection :14:25, 15:05
  section Catch up
  Replay Kafka from backup offsets :15:05, 15:30
  section Verify
  Counts and sample recall check :15:30, 15:45
  Swap alias to live :milestone, 15:45, 0m
```

### Follow one recovery from detection to traffic
1. **Loss.** At 14:00 the vector store is corrupted. The last backup is from 12:00.
2. **Detect and declare.** Alerts fire, and the on-call follows the runbook. Fast detection matters as much as fast restore.
3. **Restore the platform.** Velero restores Kubernetes objects and volumes: namespaces, configs, secrets, PVCs.
4. **Restore the data.** `milvus-backup` restores the 12:00 snapshot into a *new* collection, never over the old one.
5. **Catch up.** Ingestion replays Kafka from the offsets recorded at backup time, so writes from 12:00 to 14:00 are re-applied. The effective RPO is near zero, because Kafka kept the events.
6. **Verify.** Compare entity counts with the source of truth, and run a recall check on sample queries.
7. **Swap.** The alias points to the restored collection, and traffic resumes. RTO ≈ 1 h 45 min.

**The one idea to keep:** backups give a starting point, and the event log closes the gap. RTO is the sum of every step, so rehearse it.

## Minimal hands-on

```bash
velero install --provider aws --plugins velero/velero-plugin-for-aws:v1.10.0 \
  --bucket velero-backups --backup-location-config region=minio,s3ForcePathStyle=true,s3Url=https://minio.storage.svc \
  --use-node-agent --default-volumes-to-fs-backup

# Nightly backup of the vector namespace, kept 14 days
velero schedule create vector-nightly --schedule "0 2 * * *" \
  --include-namespaces vector --ttl 336h

# Quiesce hook on Milvus pods (flush growing segments before snapshot)
kubectl annotate pod -n vector -l app=milvus \
  pre.hook.backup.velero.io/command='["/bin/sh","-c","curl -s -X POST localhost:9091/api/v1/flush_all || true"]'

# Restore into a fresh cluster / namespace
velero restore create --from-backup vector-nightly-20261112020000 --namespace-mappings vector:vector-restore
```

## Worked example

**Scenario:** A SaaS platform with **420M vectors** (Milvus). An engineer runs a migration script that `delete`s by the wrong
filter at 14:05, and **38% of tenants lose their knowledge bases**.

| Option | Data loss (RPO) | Time (RTO) | Cost |
|---|---|---|---|
| Re-embed from source | 0 (if source intact) | ~3.5 days on 32 GPUs | ~$25k GPU + 3 days of broken product |
| Velero FS backup of PVCs only (02:00) | 12 h | 6 h | Inconsistent segments, failed restore ❌ |
| **`milvus-backup` every 4 h to Object-Locked MinIO + Kafka replay** | ~0 (replay 12:00–14:05 events from Kafka) | **55 min** | — |

Recovery: restore the 12:00 backup into a new collection, replay Kafka offsets from the 12:00 timestamp up to the
event before the bad script (Lab 63), validate counts per tenant, then swap the collection alias. Total customer impact was under 1 hour.

## Production deep dive
- **Restore drills are the real backup.** Run a monthly automated restore into an isolated namespace with checksum/count validation and a sample query recall check. Report the actual RTO.
- **Immutability:** Backup bucket with Object Lock (Lab 67) and separate credentials. The production cluster can write but never delete.
- **Off-site / cross-region** copies respect residency. EU backups stay in the EU (Lab 70).
- **Consistency across systems:** Vector DB, metadata DB (Postgres), and object store must be restored to a coherent point. Use timestamp-aligned backups plus event replay.
- **Aliases:** Serving reads `docs_current` (alias). Restores go to new collections and the alias switches atomically.

## FAANG deep-dive notes

- **How big tech does it:** Regular, automated restore testing with published RTO/RPO per service. Backups are logically air-gapped from production credentials.
- **Staff review questions:** When was the last successful restore? Measured RTO? Can a compromised prod credential delete backups?
- **Interview question:** *"Someone deleted 40% of your vector data. Recover with no data loss."* Strong answers cover point-in-time backup, event-log replay, restore to a side collection, validation, and an atomic alias swap.

**Typical system-design prompt:** *"Define and implement DR for a RAG platform: RPO 15 minutes, RTO 2 hours, 300M vectors."*

**1. Clarify first:**
- Can vectors be rebuilt from source (re-embedding) instead of restored?
- Which failures are in scope: corruption, deletion, ransomware, region loss?
- Dependencies: Kafka, etcd, object storage, and embedding models must also be recoverable.

**2. Back-of-envelope sizing:**
- Re-embedding 300M chunks at 20k/s on 8 GPUs ≈ 4.2 hours, which exceeds the 2-hour RTO. Restore from backup instead, and use re-embedding as a last resort.
- Backup size: 300M × 768 × 4 bytes ≈ 0.9 TB of vectors + indexes ≈ 1.5 TB. Restoring at 1 GB/s takes ~25 minutes.
- RPO 15 minutes: backups every 4 hours plus Kafka replay with ≥ 7 days of retention meets it, as long as offsets are stored with each backup.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Recovery | restore backup | re-embed from source | restore for speed; re-embed as a fallback |
| Backup tool | Velero volume snapshots | native milvus-backup | native for data; Velero for K8s state |
| Restore target | overwrite | new collection + alias swap | always restore side-by-side |
| Gap closure | accept loss | Kafka replay | replay from saved offsets |
| Ransomware | same-account backups | immutable, separate credentials | Object Lock + separate account |

**4. Follow-up questions with crisp answers:**
- *Why not only Velero?* Volume snapshots of a running distributed DB may be inconsistent. Native backups are.
- *Why restore to a new collection?* So a bad restore doesn't destroy what's left, and the switch is an atomic alias change.
- *What must be stored with a backup?* Kafka offsets, the embedding model version, and index parameters.
- *What if the embedding model changed since the backup?* Replayed events must use the same model version, or re-embed everything.
- *How do you test DR?* Scheduled restore drills into an isolated namespace, with measured RTO and validation.
- *What do people forget?* etcd metadata, secrets, and the model weights for the embedder.

**Debug this (common onsite question):** *"A DR drill restored the collection successfully, but search quality was terrible afterwards."*
1. Counts match, but recall on sample queries is 0.4.
2. The restored vectors were produced by embedding model v3, while the replayed events and live queries use v4.
3. Vectors from two models in one space aren't comparable.
4. Fix: record the embedding model version in backup metadata, replay with the matching model (or re-embed), and include a recall check, not only counts, in the drill's pass criteria.

The lesson: **a vector backup is only valid together with the model that produced it.**

**5. What separates senior from staff answers:**
- Senior: native backups, Velero for cluster state, immutable storage, restore drills.
- Staff: designs RPO/RTO from business needs, decides between restore and rebuild, captures all dependencies (offsets, model versions, metadata), and makes drills routine with measured results.

**Red flags:** never-tested restores, overwriting in place, no model version in backup metadata, backups deletable with production credentials.

## Failure modes
- Backups "succeed" for months but restores fail (missing CRDs, wrong storage class, version mismatch). Drill monthly.
- File-level backup of a live DB without quiescing gives corrupted segments.
- Backup credentials with delete rights let an attacker wipe production and backups together.

## Checklist
- [ ] Scheduled Velero + native vector backups configured
- [ ] Restore drill executed with measured RTO/RPO
- [ ] Backup bucket is immutable with separate credentials
