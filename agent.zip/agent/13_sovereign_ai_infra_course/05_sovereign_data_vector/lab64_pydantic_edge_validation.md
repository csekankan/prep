# Lab 64: Pydantic Data Validation at the Network Edge (4:15)

## Why it matters
Garbage in the vector store becomes **confident garbage in answers**. Malformed events, oversized
payloads, wrong tenant IDs, and injected instructions are cheapest to stop **at the edge**, before they
consume GPU time or poison the index.

## In plain words
Validation is **airport security for data**. It is far cheaper to stop a bad bag at the entrance than after it's on the plane (the vector
index), where it causes confident wrong answers. Pydantic is the scanner, and the schema is the list of allowed items.

## Architecture at a glance

```mermaid
flowchart LR
  P[Producer / webhook] --> E{"Edge: Pydantic schema + auth + size"}
  E -->|422 reject| P
  E -->|ok| K[(Kafka)]
  K --> C{"Consumer: schema + semantic checks"}
  C -->|fail| DLQ[(DLQ + error reason)]
  C -->|ok| IDX[(Vector DB / lake)]
```

**How to read it:** Producers hit the edge validator first, and bad requests bounce back. Inside, consumers validate again, so bad events go to the DLQ and good ones reach the index.

## Core concepts

**Validate at every trust boundary:**

```
External/webhook ─► [API edge: schema + auth + size] ─► Kafka ─► [Consumer: schema + semantics] ─► Vector DB
LLM output       ─► [Output validator: structured schema]  ─► Tools / users   (Lab 75)
```

| Check type | Examples |
|---|---|
| **Structural** | Required fields, types, enums, lengths |
| **Semantic** | `tenant_id` exists and matches the caller's token; dates not in the future |
| **Security** | Max sizes, allowed MIME types, URL allow-list, strip control chars, prompt-injection heuristics |
| **Quality** | Min text length, language detection, dedup by content hash |

**Pydantic v2** (Rust core) validates tens of thousands of objects per second per core, fast enough for inline edge use.
Its models also generate **JSON Schema**, which serves as a contract for producers and for LLM structured output.

## Architecture in depth

The overview shows validation at the edge and again inside. This view shows the **layers of checks inside one validator**, ordered
from cheapest to most expensive, and how schema versions evolve without breaking producers.

```mermaid
flowchart LR
  IN[Incoming JSON] --> L1{"(1) Transport: size ≤ 1 MB, content-type, auth"}
  L1 -->|fail| R413[413 / 401]
  L1 --> L2{"(2) Structure: Pydantic model v2<br/>types, required fields, enums"}
  L2 -->|fail| R422["422 + field-level errors"]
  L2 --> L3{"(3) Semantics: dates sane, tenant exists,<br/>language supported, no PII in title"}
  L3 -->|fail| DLQ[(DLQ + reason code)]
  L3 --> L4["(4) Normalize: trim, unicode NFC, canonical IDs"]
  L4 --> OUT[(Kafka docs.validated, schema_version = 2)]
  REG[(Schema registry: v1, v2 compatible)] -.-> L2
```

### Follow one webhook payload through the validator
1. **Transport checks.** Oversized bodies and unauthenticated calls are rejected before any parsing. These are the cheapest checks, and they protect the CPU.
2. **Structure.** Pydantic parses the payload into a typed model: wrong types, missing fields, and unknown enum values return a 422 listing every bad field.
3. **Semantics.** Business rules that types can't express: the tenant exists, the date isn't in the future, the language is supported.
4. **Route failures.** Structural errors go back to the producer, who can fix them. Semantic errors in async pipelines go to the DLQ with a reason code.
5. **Normalize.** Clean the data into one canonical form (Unicode, whitespace, ID formats), so downstream code doesn't repeat this.
6. **Emit versioned.** The event is written with its schema version. A registry enforces backward-compatible changes.

**The one idea to keep:** validate once, strictly, at the boundary. Everything behind the edge can then trust the data shape.

## Minimal hands-on

```python
from datetime import datetime, timezone
from typing import Literal
from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict

class DocEvent(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, frozen=True)

    doc_id: str = Field(pattern=r"^[a-z0-9\-]{8,64}$")
    tenant_id: str = Field(min_length=3, max_length=32)
    source: Literal["confluence", "sharepoint", "crm", "jira"]
    classification: Literal["public", "internal", "confidential", "restricted"]
    region: Literal["eu", "us", "in"]
    text: str = Field(min_length=20, max_length=200_000)
    updated_at: datetime

    @field_validator("text")
    @classmethod
    def no_control_chars(cls, v: str) -> str:
        return "".join(ch for ch in v if ch.isprintable() or ch in "\n\t")

    @model_validator(mode="after")
    def not_future(self):
        if self.updated_at > datetime.now(timezone.utc):
            raise ValueError("updated_at in the future")
        return self
```

In a FastAPI edge endpoint, invalid requests are rejected with `422` automatically. In a Kafka consumer, catch
`ValidationError`, send to the DLQ with the error details, and increment a metric.

## Worked example

**Scenario:** A pharma company ingests documents from 14 internal systems into a regulatory-affairs RAG.
After launch, answers start citing **draft, unapproved SOPs** and some results mix up sites.

Root causes found in the data:
| Issue | % of events | Edge rule added |
|---|---|---|
| Missing `classification` (defaulted to internal) | 6% | Required field, `extra=forbid` |
| `status=draft` docs ingested | 11% | `status: Literal["approved"]` for this pipeline |
| `site_id` free text ("Basel", "BSL", "basel-2") | 9% | Enum + normalization map |
| 40 MB PDFs extracted as one chunk | 0.4% | `max_length` + chunker upstream |

After the edge contract went in, DLQ volume was 3% (fixed upstream within weeks) and the answer-citation error rate
fell from **7.8% to 0.6%**. The JSON Schema export became the official contract shared with all 14 source teams.

## Production deep dive
- **Contract-first:** Publish schemas in a Schema Registry and version them (`DocEvent v3`). Allow only backward-compatible evolution.
- **Fail closed for security fields** (tenant, classification, region). Fail soft (DLQ + alert) for quality fields.
- **Observability:** Validation error rate per source and per field. A sudden spike usually means an upstream deploy broke something.
- **Performance:** Validate in batches, and use `model_validate_json` (avoids a double parse).
- **Defense in depth:** Validation doesn't replace authZ. The edge checks that the JWT's tenant equals `tenant_id`.

## FAANG deep-dive notes

- **How big tech does it:** Schema contracts between teams are enforced in CI and at runtime, with a schema registry and backward-compatibility checks.
- **Staff review questions:** Where is validation duplicated, and why? Who owns the DLQ? Are security fields fail-closed?
- **Interview question:** *"Bad data is degrading RAG answers. How do you stop it?"* Strong answers cover contract-first schemas, edge + consumer validation, quality rules, DLQ ownership, metrics per source, and upstream fixes.

**Typical system-design prompt:** *"Design the ingestion contract for 50 internal teams sending documents into the shared RAG platform."*

**1. Clarify first:**
- Sync (webhook) or async (Kafka) producers, or both?
- How often do schemas change, and who approves changes?
- What should happen to bad data: reject, quarantine, or repair?

**2. Back-of-envelope sizing:**
- Pydantic v2 (Rust core) validates simple models at ~100k–1M objects/s per core, so validation is rarely the bottleneck.
- Without validation: if 0.5% of 10M daily documents are malformed, that's 50k bad records per day reaching the index, each one a potential bad answer or crash.
- DLQ volume target: < 0.1% steady state, with alerts on spikes per producer.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Strictness | lenient (coerce) | strict (reject) | strict at boundaries; explicit coercions only |
| Unknown fields | ignore | forbid | forbid on external APIs; allow with logging internally |
| Schema evolution | free-form | registry + compatibility rules | backward-compatible changes only |
| Failure routing | drop | 422 sync / DLQ async | never drop silently |
| Ownership | platform owns all schemas | producers own via contract | producer-owned, platform-reviewed contracts |

**4. Follow-up questions with crisp answers:**
- *Why validate at the edge and in the consumer?* The edge protects the system; the consumer protects against producers who bypass the edge or old events being replayed.
- *What is backward compatibility?* New consumers can read old events, e.g. adding optional fields is fine, while renaming required ones is not.
- *Why forbid extra fields?* Typos (`tenat_id`) silently become missing data otherwise.
- *What's a reason code?* A machine-readable failure category for dashboards and per-producer alerts.
- *How does this help LLM safety?* Structured, validated metadata (tenant, ACL, classification) is what access control and residency rely on.
- *Where do semantic checks belong?* After structural parsing, using reference data that's cached.

**Debug this (common onsite question):** *"RAG answers started citing documents from the wrong tenant for one customer."*
1. Trace a bad document: its `tenant_id` was `"0042"`, while the canonical ID is `"42"`.
2. A producer changed formats. The lenient model coerced the string, and the ACL filter compares exact strings.
3. These documents were indexed under a tenant that doesn't exist, and a fallback rule treated them as "shared".
4. Fix: canonicalize IDs in the normalizer, reject unknown tenants semantically, remove the "shared" fallback, and add a contract test per producer in CI.

The lesson: **lenient parsing plus permissive fallbacks turns a formatting change into a data leak.**

**5. What separates senior from staff answers:**
- Senior: strict Pydantic models at the edge with good errors and a DLQ.
- Staff: designs data contracts across teams (registry, compatibility rules, CI contract tests), ties validation to security metadata, and runs per-producer quality metrics.

**Red flags:** silent coercion of IDs, dropping invalid data, no schema versioning, ACL metadata that isn't validated.

## Failure modes
- `extra="allow"` lets unexpected fields (e.g. `is_admin`) flow downstream.
- Validation only at the API means internal producers on Kafka bypass it. Validate at the consumer too.
- The DLQ is never reviewed, so silent data loss grows. Assign an owner and an SLO.

## Checklist
- [ ] Strict Pydantic model at the API edge and in the consumer
- [ ] DLQ with structured error reasons
- [ ] JSON Schema published as a producer contract
