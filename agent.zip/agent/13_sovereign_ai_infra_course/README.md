# Sovereign AI Infrastructure on Kubernetes — From Laptop to Blackwell

> 12 sections • 112 lectures • ~8h 31m • Concept-first, minimal code, production deep dives.

In the AI era, writing YAML and boilerplate is cheap: an assistant can generate it in seconds.
The scarce skill is **architectural judgment**. You need to know *why* a GPU node is starving, *which*
parallelism strategy fits your model, and *where* data is allowed to live. This course teaches that
judgment. Each lab has only as much code as you need to make the idea concrete.

## How every lab is structured

Concept first, code second. Every lab follows this order:

| # | Block | Purpose |
|---|---|---|
| 1 | **Why it matters** | The business/engineering problem |
| 2 | **In plain words** | An everyday analogy, so the idea clicks before any jargon |
| 3 | **Architecture at a glance** + **How to read it** | A Mermaid diagram of the moving parts, with a walkthrough of the flow |
| 4 | **Core concepts** | Mental model, vocabulary, trade-off tables |
| 5 | **Architecture in depth** | A second diagram that follows one request, job, or object step by step, ending with "the one idea to keep" |
| 6 | **Minimal hands-on** | The smallest code/config that proves the concept |
| 7 | **Worked example** | A concrete scenario with real numbers ("a bank with 40 H100s needs…") |
| 8 | **Production deep dive** | What changes at enterprise scale: HA, security, cost, compliance |
| 9 | **FAANG deep-dive notes** | How big tech does it, plus a full system-design walkthrough: clarifying questions, back-of-envelope sizing, trade-off table, follow-up Q&A, a "debug this" scenario, senior vs. staff answers, and red flags |
| 10 | **Failure modes** | How it breaks in real life |
| 11 | **Checklist** | What "done" looks like |

## Course map

| # | Section | Labs | Folder |
|---|---|---|---|
| 1 | Introduction | — | [00_introduction](00_introduction/README.md) |
| 2 | Foundations & the Local AI Sandbox | 1–10 | [01_foundations_local_sandbox](01_foundations_local_sandbox/README.md) |
| 3 | Accelerated Compute Fundamentals (GPUs & TPUs) | 21–30 | [02_accelerated_compute](02_accelerated_compute/README.md) |
| 4 | Distributed Training Networks | 31–40 | [03_distributed_training](03_distributed_training/README.md) |
| 5 | Serving Infrastructure & Inference Scaling | 41–50 | [04_serving_inference](04_serving_inference/README.md) |
| 6 | Sovereign Data Pipelines & Vector Architectures | 60 (bonus: Redis for AI), 61–70 | [05_sovereign_data_vector](05_sovereign_data_vector/README.md) |
| 7 | Agentic Orchestration & MCP | 71–80 | [06_agentic_mcp](06_agentic_mcp/README.md) |
| 8 | Sovereign Deployment & Decentralized Research | 91–100 | [07_sovereign_deployment](07_sovereign_deployment/README.md) |
| 9 | Conclusion | — | [99_conclusion](99_conclusion/README.md) |

Cross-cutting references:
- [GLOSSARY.md](GLOSSARY.md): every term used in the course
- [ENTERPRISE_REFERENCE_ARCHITECTURE.md](ENTERPRISE_REFERENCE_ARCHITECTURE.md): the full target stack on one page

> Lab numbering follows the original curriculum. Gaps (11–20, 51–59, 81–90) are reserved for
> optional extension modules. Lab 60 is the first one: a bonus lab on Redis for AI. You can do the course in order without them.

## The narrative arc

```mermaid
flowchart LR
  A[Laptop sandbox<br/>K3s + vLLM] --> B[GPU fleet<br/>scheduling + autoscaling]
  B --> C[Distributed training<br/>Ray, FSDP, NCCL]
  C --> D[Serving at scale<br/>Triton, LoRA, KV cache]
  D --> E[Sovereign data<br/>Milvus, Kafka, residency]
  E --> F[Agents<br/>MCP, sandboxes, rate limits]
  F --> G[Sovereign multi-cluster<br/>air-gap, federation, compliance]
```

## Prerequisites

- Comfortable with the Linux shell, Git, and basic Python
- Basic Docker usage
- A machine with 16 GB+ RAM. A GPU is optional until Section 3; cloud GPUs are fine.

## Tooling used across the course

`docker`, `k3d`/`k3s`, `kubectl`, `helm`, `k9s`, `nvidia-smi`, `ray`, `vllm`, `tritonserver`,
`mlflow`, `milvus`, `kafka`, `minio`, `velero`, `kyverno`, `karmada`, `envoy`, `redis`.
