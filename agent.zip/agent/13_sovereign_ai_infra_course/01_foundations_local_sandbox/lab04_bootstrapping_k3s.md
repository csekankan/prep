# Lab 4: Bootstrapping K3s — Your First Lightweight Cluster (5:09)

## Why it matters
K3s is real, CNCF-conformant Kubernetes in a ~70 MB binary. It is ideal for laptops, **edge
inference sites**, and air-gapped deployments (Lab 94).

## In plain words
Full Kubernetes is a commercial kitchen. **K3s** is the same kitchen packed into a food truck: the same recipes (YAML) work, but it
starts in seconds and fits anywhere: laptops, shops, factories, or offline sites. The **server** is the head chef taking orders, and
**agents** are the cooks doing the work.

## Core concepts

```mermaid
flowchart LR
  subgraph Server["k3s server (control plane)"]
    API[kube-apiserver] --- DS[(SQLite / etcd)]
    SCH[scheduler] --- CM[controller-manager]
  end
  subgraph Agent["k3s agent (worker)"]
    KL[kubelet] --- CTR[containerd]
    FL[flannel CNI]
  end
  Agent -->|join token| Server
```

**How to read it:** Read left to right: the agent joins the server using a token. The server holds the control plane and the datastore. Everything a full cluster needs is bundled into the two processes.

Bundled by default: **containerd, Flannel (CNI), CoreDNS, Traefik (Ingress), ServiceLB, local-path-provisioner, metrics-server**.

| Datastore | Use |
|---|---|
| SQLite | Single-server dev |
| Embedded etcd (`--cluster-init`) | 3-server HA |
| External Postgres/MySQL | Managed HA option |

## Architecture in depth

The overview shows one server and one agent. This view shows a **production-shaped K3s deployment**: HA control plane, a fixed
registration address, and GitOps delivery. The same shape is used for edge fleets.

```mermaid
flowchart TB
  VIP["kube-vip / LB<br/>fixed registration address :6443"] --> S1[Server 1<br/>apiserver + etcd]
  VIP --> S2[Server 2<br/>apiserver + etcd]
  VIP --> S3[Server 3<br/>apiserver + etcd]
  S1 <-->|etcd raft quorum| S2 <--> S3
  A1[Agent: GPU node] -->|join token| VIP
  A2[Agent: CPU node] -->|join token| VIP
  GIT[(Git repo)] --> ARGO[Argo CD / Fleet<br/>pull-based] --> VIP
  S1 -.snapshots.-> BK[(etcd snapshots → S3/MinIO)]
  SUC[system-upgrade-controller] -.plans.-> A1 & A2 & S1
```

### Follow one cluster from install to steady state
1. **First server** starts with `--cluster-init`, creating an embedded etcd cluster of one.
2. **Two more servers** join through the fixed address, so etcd reaches a 3-member quorum. Any one server can fail without losing the cluster.
3. **Agents join** with the node token through the same address, so replacing a server never requires re-joining workers.
4. **Bundled components** (CoreDNS, Traefik, local-path, metrics-server) deploy automatically. In production, disable the ones you replace (e.g. Cilium for Flannel).
5. **GitOps pull.** Argo CD or Fleet inside the cluster pulls manifests from Git. Nothing pushes into the cluster, which suits firewalled edge sites.
6. **Backups.** Scheduled etcd snapshots go to object storage. A restore rebuilds the control-plane state on new servers.
7. **Upgrades.** The system-upgrade-controller applies version *plans* node by node (servers first, then agents), with cordon and drain.

**The one idea to keep:** the cluster is cattle. Install, join, upgrade, and restore are all automated and repeatable.

## Minimal hands-on

```bash
# Option A: Docker-based (Mac/Linux)
k3d cluster create ai --agents 2 -p "80:80@loadbalancer"

# Option B: Native Linux
curl -sfL https://get.k3s.io | sh -
sudo cat /var/lib/rancher/k3s/server/node-token   # join token
# on a worker:
curl -sfL https://get.k3s.io | K3S_URL=https://<server>:6443 K3S_TOKEN=<t> sh -

kubectl get nodes -o wide
```

## Worked example

**Scenario:** A retail chain wants **on-store inference** (shelf-camera vision + a small LLM for staff Q&A)
in 400 stores, each with one GPU box and unreliable WAN.

- K3s single-node per store (SQLite datastore, ~512 MB RAM overhead).
- GitOps pull model: Fleet or ArgoCD in each store pulls from a central Git repo, so there are no inbound connections.
- When the WAN drops, the store keeps serving because the model is cached locally on NVMe.
- Rollouts go in waves: 5 stores, then 50, then all 400, gated by health metrics.

Compare that with full kubeadm per store: ~3× the ops burden and more RAM. **K3s wins at the edge.**

## Production deep dive
- **HA:** 3 servers with embedded etcd behind a fixed registration address (VIP via kube-vip).
- **Hardening:** CIS profile (`--profile=cis`), secrets encryption at rest (`--secrets-encryption`), and audit logging.
- **Swap components:** Disable Traefik and Flannel (`--disable traefik --flannel-backend=none`) to bring your own Cilium + Envoy Gateway.
- **Enterprise sibling:** RKE2, the same UX with FIPS 140-2 and a government-hardened default. It is preferred for regulated data centers.
- **Upgrades:** The system-upgrade-controller performs rolling, plan-driven node upgrades.

## FAANG deep-dive notes

- **How big tech does it:** Large fleets of small edge clusters are managed by GitOps pull agents with staged waves (1% → 10% → 100%), never by SSH-ing into sites.
- **Staff review questions:** What happens when the WAN is down for 3 days? How do you roll back a bad edge release on 400 sites? Where is the datastore backup?
- **Interview question:** *"Design software delivery to 5,000 retail stores, each with one GPU box."* Strong answers cover a pull-based GitOps model, offline tolerance, staged rollouts with health gates, a local model cache, and fleet observability with intermittent connectivity.

**Typical system-design prompt:** *"Design AI inference at 2,000 edge locations (stores or factories), each with one or two GPU boxes and unreliable WAN."*

**1. Clarify first:**
- What must work when the WAN is down (inference? logging? updates?) and for how long?
- How often do models and apps update, and what's the acceptable rollout time across all sites?
- Who has physical access to the boxes (tamper risk, disk encryption)?

**2. Back-of-envelope sizing:**
- 2,000 sites × 8 GB model update = 16 TB per model release. At 50 Mb/s per site, one site downloads in ~22 minutes. Waves of 200 sites ≈ 10 waves.
- Control-plane overhead per K3s node ≈ 0.5–1 GB RAM. On a 64 GB box that's acceptable; full kubeadm is ~2–3×.
- Fleet management: one central GitOps manager handling 2,000 clusters needs sharding (e.g. 10 manager shards of 200).

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Per-site topology | single-node K3s | 3-node HA | single node unless the site has a strict uptime SLA |
| Delivery | push (CI → cluster) | pull (GitOps agent) | pull at the edge; no inbound connectivity |
| Datastore | SQLite | embedded etcd | SQLite for single node, etcd for HA |
| Distro | K3s | RKE2 (FIPS/CIS) | RKE2 for regulated or government sites |
| Model delivery | download per site | regional cache / P2P | regional cache when > 100 sites share a region |

**4. Follow-up questions with crisp answers:**
- *Why 3 servers, not 2?* etcd needs a majority. With 2, losing 1 loses quorum. With 3, you tolerate 1 failure.
- *How do you roll back a bad release on 2,000 sites?* Git revert, and agents pull the previous version. Waves stop automatically when health gates fail.
- *What if a site is offline during a release?* It converges when it reconnects. GitOps is eventually consistent by design.
- *How do you protect a stolen edge box?* Full-disk encryption with TPM-bound keys, secrets fetched at runtime and short-lived, and remote revocation of credentials.
- *How do you monitor sites with intermittent links?* Local buffering (Prometheus agent mode / OTel with a queue), shipped when the link returns.
- *Why disable bundled Traefik/Flannel?* To standardize on the org's chosen ingress and CNI (with network policies, eBPF) across all clusters.

**Debug this (common onsite question):** *"After a K3s upgrade, 15% of edge sites report pods stuck in ContainerCreating."*
1. Group failures by attribute: they share a hardware model or kernel version.
2. Events show a CNI error: the new Flannel version needs a kernel module that is missing on that image.
3. Waves should have caught it: the first wave lacked a site with that hardware.
4. Fix: roll those sites back, pin the CNI version, and make the canary wave include one site of each hardware profile.

The lesson: **canary waves must cover the diversity of the fleet, not just a count of sites.**

**5. What separates senior from staff answers:**
- Senior: can install HA K3s, explain etcd quorum, and set up GitOps.
- Staff: designs fleet-level rollout waves by hardware profile, offline tolerance, security for physical tampering, and fleet observability, with cost and bandwidth numbers.

**Red flags:** 2-server HA, push-based deploys to edge sites, no etcd backups, no plan for offline sites.

## Failure modes
- Losing the single SQLite server loses the cluster state. Back up `/var/lib/rancher/k3s/server/db`.
- Clock skew between nodes breaks the TLS join.
- Flannel VXLAN MTU mismatches on cloud VPCs cause silent packet drops on large payloads.

## Checklist
- [ ] A 1-server + 2-agent cluster is running
- [ ] You know which bundled components to disable in production
- [ ] There is a backup plan for the datastore
