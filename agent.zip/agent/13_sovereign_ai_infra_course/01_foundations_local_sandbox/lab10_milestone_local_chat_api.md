# Lab 10: Initial Success Milestone — Bypassing the Cloud with a Local Chat API (4:24)

## Why it matters
You now own a **sovereign, OpenAI-compatible endpoint**. Any app written against OpenAI SDKs
(LangChain, LlamaIndex, Cursor-style tools, your agents from earlier modules) can switch
to it by changing one URL. No data leaves your machine.

## In plain words
You built your own **private ChatGPT-style endpoint**. Any app that speaks "OpenAI language" can switch to yours by changing one
address, and none of your data leaves your machine.

## What you assembled

```mermaid
flowchart LR
  SDK[OpenAI SDK app] -->|https://chat.local/v1| ING[Ingress]
  ING --> SVC[Service] --> V[vLLM pod]
  V --> PVC[(PVC weights)]
```

**How to read it:** Your app talks to one URL. Ingress forwards to a Service, which reaches the vLLM pod reading weights from the PVC. This is the same shape production uses, just smaller.

| Layer | Lab |
|---|---|
| Sized hardware & tools | 1 |
| Lean container image | 2 |
| Guaranteed QoS pod | 3 |
| K3s cluster | 4 |
| Init-container weight fetch + `/dev/shm` | 5 |
| Service + DNS | 6 |
| PVC for weights | 7 |
| vLLM engine | 8 |
| Ingress + local DNS + TLS | 9 |

## Architecture in depth

The overview shows the request path. This view maps **every Kubernetes object you created** in Labs 1–9 and how they reference
each other. Use it as a review checklist for the sandbox.

```mermaid
flowchart TB
  NS[Namespace: ai] --> ING["Ingress / HTTPRoute<br/>host chat.local, TLS secret"]
  ING --> SVC["Service vllm :8000<br/>selector app=vllm"]
  SVC --> DEP["Deployment vllm<br/>replicas, probes, Guaranteed QoS"]
  DEP --> RS[ReplicaSet] --> POD[Pod]
  POD --> INIT[Init: fetch + verify weights]
  POD --> CTR["Container: vllm-openai<br/>limits: gpu, memory"]
  POD --> PVC["PVC model-store"] --> PV[(PV: local-path)]
  POD --> SHM[("emptyDir /dev/shm")]
  CTR -->|/metrics| MON[Prometheus scrape]
  DNS[CoreDNS] -.resolves.-> SVC
```

### Follow one change through the sandbox: swapping the model
1. **Download** the new weights into the existing PVC (a one-off Job), so pods don't download on start.
2. **Edit the Deployment** `--model` argument. Kubernetes creates a new ReplicaSet.
3. **Rolling update.** A new pod starts, its init container verifies the files, and the readiness probe waits for the model to load.
4. **Service switch.** Only when the new pod is ready does the Service EndpointSlice include it, and the old pod is removed.
5. **Clients are unchanged.** The SDK still calls `https://chat.local/v1`. Only the `model` name in requests (or a served alias) changes.
6. **Verify** with `/v1/models`, a smoke prompt, and the baseline load test from this lab.

**The one idea to keep:** a production rollout is the same object graph with more replicas, stricter probes, and traffic splitting (Lab 50).

## Minimal hands-on

```python
from openai import OpenAI
client = OpenAI(base_url="http://chat.local/v1", api_key="local-not-needed")

stream = client.chat.completions.create(
    model="/models/qwen",
    messages=[{"role": "user", "content": "Explain cgroups in one sentence."}],
    stream=True,
)
for chunk in stream:
    print(chunk.choices[0].delta.content or "", end="")
```

Smoke-test the load:

```bash
# 20 concurrent users for 60s
hey -z 60s -c 20 -m POST -T application/json \
  -d '{"model":"/models/qwen","messages":[{"role":"user","content":"hi"}],"max_tokens":64}' \
  http://chat.local/v1/chat/completions
```

## Worked example — cost comparison

**Scenario:** An internal assistant processes **50M tokens/day** (input + output).

| Option | Approx monthly cost | Data leaves org? |
|---|---|---|
| Frontier API (~$5 / 1M blended) | ~$7,500 | Yes |
| Smaller hosted API (~$0.50 / 1M) | ~$750 | Yes |
| **Self-hosted 8B on 1× L40S (owned, 3-yr amortized + power)** | **~$450–600** | **No** |
| Self-hosted 70B FP8 on 2× H100 (owned) | ~$2,000–2,500 | No |

Self-hosting wins when utilization is high, data is sensitive, or the model must be pinned.
APIs win for spiky, low-volume, or frontier-quality-only use cases. **Most enterprises run hybrid**
behind a single gateway (Lab 46 semantic routing).

## Production deep dive: the readiness gap

What your sandbox still lacks, and where the course adds it:

| Gap | Fixed in |
|---|---|
| Real GPUs, scheduling, sharing | Section 3 |
| Autoscaling | Labs 29, 30 |
| HA & zero-downtime updates | Labs 49, 50 |
| Auth, quotas, rate limits | Labs 9, 79 |
| Observability | Lab 27 |
| Data governance | Section 6 |
| Compliance evidence | Labs 92, 99 |

## FAANG deep-dive notes

- **How big tech does it:** Internal platforms expose one OpenAI-compatible endpoint backed by many models, with a mix of self-hosted and vendor models behind a single gateway and policy layer.
- **Staff review questions:** What is your baseline (TTFT, throughput, cost/1M tokens)? What breaks first at 10× load? What is the build-vs-buy break-even point?
- **Interview question:** *"When should a company self-host LLMs instead of using an API?"* Strong answers weigh volume, utilization, data sensitivity, latency, model control, team skills, and hybrid routing, with a cost-per-token calculation.

**Typical system-design prompt:** *"Your CTO asks: should we self-host LLMs or keep using a public API? Make the case with numbers."*

**1. Clarify first:**
- Token volume per day and its growth.
- Data sensitivity and residency obligations.
- Quality requirement: is an open model good enough on our eval set?

**2. Back-of-envelope sizing:**
- 50M tokens/day ≈ 580 tokens/s average, ~2,300 tokens/s at 4× peak.
- One 8B replica on an L40S sustains ~2,000–3,000 output tokens/s under batching, so 2 replicas (N+1) cover it.
- API cost at $0.50/1M ≈ $25/day. Self-hosted 2 GPUs ≈ $1.5/h each at cloud rates ≈ $72/day. **At this volume the API is cheaper.** At 500M tokens/day, the API costs $250/day while self-hosting needs perhaps 4–6 GPUs (~$150–220/day), and the balance flips.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Hosting | public API | self-host | API for low/spiky volume; self-host for high steady volume or sensitive data |
| Model | frontier closed | open-weight | open when it passes evals; frontier for the hardest tasks |
| Integration | vendor SDK | OpenAI-compatible gateway | gateway, so you can switch either way |
| Ownership | app team runs vLLM | platform team | platform team once more than ~2 teams use it |

**4. Follow-up questions with crisp answers:**
- *What's the hidden cost of self-hosting?* People: on-call, upgrades, evals, security. Often 1–3 engineers for a small platform.
- *What makes the switch reversible?* An OpenAI-compatible gateway in front of both options, plus model-agnostic prompts and evals.
- *How do you compare quality fairly?* The same eval set, the same prompts, scored by humans or a calibrated LLM judge.
- *Where does self-hosting clearly win regardless of cost?* Data that cannot leave, pinned model versions for regulated decisions, and air-gapped sites.
- *What's the baseline you should record now?* TTFT p50/p95, TPOT, max throughput at your SLO, and cost per 1M tokens.

**Debug this (common onsite question):** *"The local endpoint works with curl, but the LangChain app gets malformed responses."*
1. Compare requests: the app sends `model="gpt-4o"`, which the server doesn't know, or uses tool-calling features the model's template doesn't support.
2. Check the chat template: the server uses a default template, not the model's, so roles are formatted wrong.
3. Check streaming: the app expects a `usage` field in the final chunk.
4. Fix: serve with the model's chat template, add a model alias, enable tool parsing for that model, and run a compatibility test suite against the endpoint.

The lesson: **"OpenAI-compatible" is a contract. Test it like one.**

**5. What separates senior from staff answers:**
- Senior: builds the stack and measures a baseline.
- Staff: frames build vs. buy with volume, utilization, risk, and people cost, and designs a hybrid gateway so the decision stays reversible.

**Red flags:** self-hosting "because it's free", no baseline numbers, vendor-specific SDKs baked into every app.

## Checklist
- [ ] An OpenAI SDK app works against your endpoint
- [ ] The load test was run, with TTFT and throughput recorded as your **baseline**
- [ ] A cost comparison exists for your own token volume
