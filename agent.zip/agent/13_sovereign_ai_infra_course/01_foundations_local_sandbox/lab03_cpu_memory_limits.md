# Lab 3: Virtualizing CPU and Memory Limits for AI Workloads (4:40)

## Why it matters
AI pods are memory-hungry and bursty. Wrong limits cause either **OOMKills** (limit too low)
or **noisy neighbours and wasted nodes** (no limits, or requests set too high).

## In plain words
**Requests** are a restaurant reservation: the scheduler holds that table for you. **Limits** are the bouncer: exceed the memory limit
and you are thrown out (OOMKill). Exceed the CPU limit and you are just made to wait (throttling). For AI, always reserve enough memory,
and be careful with CPU limits, because waiting in line slows every answer.

## Architecture at a glance

```mermaid
flowchart LR
  P[Pod spec] -->|requests| S[Scheduler: picks node with room]
  S --> N[Node]
  N -->|limits.memory| C1["cgroup memory.max → exceed = OOMKill"]
  N -->|limits.cpu| C2["cgroup cpu.max → exceed = throttled"]
  N -->|nvidia.com/gpu| G["Whole GPU assigned, no sharing"]
```

**How to read it:** A pod's requests go to the scheduler, which only places it. Limits are enforced later by the kernel on the node: memory kills, CPU throttles, GPUs are exclusive.

## Core concepts

| Field | Used by | Effect |
|---|---|---|
| `requests.cpu/memory` | **Scheduler** | Reserves capacity and decides which node |
| `limits.memory` | **Kernel (cgroup)** | Hard cap. Exceeding it means OOMKill |
| `limits.cpu` | **Kernel (CFS quota)** | Throttling, not killing |
| `nvidia.com/gpu` | Scheduler + device plugin | Integer, non-overcommittable; request = limit |

**QoS classes**
- `Guaranteed`: requests == limits for every container. Evicted last. **Use this for inference.**
- `Burstable`: requests < limits. Fine for batch preprocessing.
- `BestEffort`: no requests. Never use it for AI.

**The CPU limit debate:** CPU limits cause CFS throttling even when the node is idle. Many
enterprises set CPU **requests only** for latency-sensitive services. They always set memory limits.

## Architecture in depth

The overview shows requests vs. limits. This view shows **who enforces what, and when**: the scheduler at placement time, the
kubelet at runtime, and the kernel on every CPU tick and memory allocation.

```mermaid
flowchart TB
  POD["Pod spec<br/>requests + limits"] --> SCH{Scheduler}
  SCH -->|"node allocatable minus sum of requests ≥ pod requests"| BIND[Bind to node]
  BIND --> KL[kubelet]
  KL --> QOS["QoS class: Guaranteed / Burstable / BestEffort"]
  KL --> CGW[Write cgroup files]
  CGW --> MEM["memory.max → kernel OOM killer"]
  CGW --> CPU["cpu.max quota per 100 ms → throttling"]
  CGW --> PIDS[pids.max]
  KL --> EVICT["Node pressure → evict by QoS order<br/>BestEffort → Burstable → Guaranteed"]
  RES["kube-reserved + system-reserved"] -.protects.-> KL
```

### Follow one pod from spec to enforcement
1. **Scheduling uses requests only.** The scheduler subtracts the requests of pods already placed from node *allocatable* (capacity minus reserved). It never looks at actual usage.
2. **QoS class is derived.** If requests equal limits for every container and every resource, the pod is Guaranteed. That decides eviction order under node pressure.
3. **The kubelet writes cgroups.** `memory.max` is set from the memory limit, and `cpu.max` (quota/period) from the CPU limit. CPU requests become `cpu.weight` (a fair share under contention).
4. **Memory over the limit.** The kernel OOM-kills a process in that cgroup *immediately*. There's no throttling for memory.
5. **CPU over the limit.** The cgroup is throttled until the next 100 ms period. Bursty AI work (tokenization, batching) hits this even on an idle node.
6. **Node pressure.** If the node itself runs low on memory, the kubelet evicts pods: BestEffort first, then Burstable over their requests, then Guaranteed.
7. **Reserved resources** keep the kubelet and system daemons alive. Without them, an AI pod can starve the kubelet and the node goes NotReady.

**The one idea to keep:** requests are for the scheduler, limits are for the kernel, and memory and CPU are punished differently.

## Minimal hands-on

```yaml
resources:
  requests: { cpu: "4", memory: "24Gi", nvidia.com/gpu: 1 }
  limits:   {           memory: "24Gi", nvidia.com/gpu: 1 }
```

```bash
kubectl top pod; kubectl describe pod <p> | grep -A3 "Last State"
# CPU throttling evidence
cat /sys/fs/cgroup/cpu.stat | grep throttled
```

## Worked example

**Scenario:** An embedding service on CPU nodes has p99 latency of **900 ms**, but average CPU use is only 30%.

1. `cpu.stat` shows `nr_throttled` climbing. The pod has `limits.cpu: 2`.
2. Tokenization plus batched matmul bursts to 6 cores for 50 ms windows, so CFS throttles it.
3. Fix: remove the CPU limit, keep `requests.cpu: 2`, and add a `LimitRange` so the namespace can't explode.
4. Result: p99 drops to **140 ms** with the same node count.

**Counter-example:** A tokenizer worker with no memory limit leaked 1 GB/hour and took down the
node's kubelet. **Always set memory limits.**

## Production deep dive
- **Right-sizing:** Run VPA in `recommend` mode for 2 weeks, then set requests at p95 usage.
- **Node allocatable:** Reserve `system-reserved` and `kube-reserved` (e.g. 4 CPU and 16 GiB on GPU nodes). Otherwise the kubelet itself starves.
- **CPU pinning:** Use `cpuManagerPolicy: static` plus `topologyManagerPolicy: single-numa-node` so GPU, CPU, and NIC share a NUMA node. This matters a lot for data loaders.
- **HugePages:** Some inference runtimes and DPDK NICs benefit from 2Mi/1Gi hugepages.
- **Namespace guardrails:** `LimitRange` (defaults) + `ResourceQuota` (ceilings), covered in Lab 26.

## FAANG deep-dive notes

- **How big tech does it:** Borg-style systems overcommit CPU with priority tiers but treat memory and accelerators as non-overcommittable. Requests are auto-tuned from historical usage (VPA-like autopilot).
- **Staff review questions:** What is the QoS class of every serving pod? Do you have throttling metrics? How did you choose the memory limit? Was it measured during model load, which is the peak?
- **Interview question:** *"A latency-sensitive pod has low average CPU but bad p99. Why?"* Strong answers identify CFS quota throttling at 100 ms periods, show how to confirm it via `cpu.stat`, and fix it by removing CPU limits or using static CPU pinning.

**Typical system-design prompt:** *"Define resource policy for a shared cluster that runs latency-sensitive inference, batch embedding, and notebooks."*

**1. Clarify first:**
- Which workloads have latency SLOs, and which are throughput-only?
- Is CPU overcommit acceptable for batch? Is memory overcommit ever acceptable?
- Are there GPU nodes where CPU/RAM per GPU must be reserved for data loading?

**2. Back-of-envelope sizing:**
- A GPU node with 8 GPUs, 192 vCPU, 2 TB RAM: reserve 8 vCPU and 32 GiB for system/kube, which leaves ~23 vCPU and ~250 GiB per GPU pod.
- An inference pod that peaks at 22 GiB during model load: set memory request = limit = 24 GiB (Guaranteed). Don't size from steady state (14 GiB).
- A CPU limit of 2 cores = 200 ms of CPU per 100 ms period. A 50 ms burst that needs 6 cores uses its quota in ~33 ms, then waits ~67 ms. That's p99 inflation.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| CPU limits on latency services | set limits | requests only | requests only + LimitRange guardrails; keep limits for noisy batch |
| Memory | request < limit (Burstable) | request = limit (Guaranteed) | Guaranteed for serving; never unlimited |
| Pinning | shared CPUs | static CPU manager + NUMA alignment | pin for data-loader-heavy training and DPDK/RDMA |
| Sizing | manual | VPA recommendations | VPA in recommend mode, humans apply |

**4. Follow-up questions with crisp answers:**
- *Why is a pod throttled at 30% average CPU?* CFS quota is enforced per 100 ms window, so short bursts above the limit are throttled even when the average is low.
- *What happens when memory exceeds the limit?* Immediate OOMKill of a process in the cgroup (exit code 137), no grace.
- *How is QoS determined?* Guaranteed: requests equal limits for CPU and memory in every container. Burstable: some requests set. BestEffort: none.
- *Why does PyTorch crash with "bus error" in DataLoader?* `/dev/shm` defaults to 64 MB. Mount a memory-backed emptyDir.
- *Can GPUs be overcommitted?* Not with the standard device plugin. They're integer resources. Sharing needs time-slicing, MPS, or MIG.
- *Why reserve resources for the kubelet?* Without kube-reserved/system-reserved, workloads can starve node agents, and the node goes NotReady.

**Debug this (common onsite question):** *"The embedding service p99 jumped from 120 ms to 900 ms after a 'hardening' change. CPU usage looks low."*
1. Diff the change: CPU limits were added to every Deployment.
2. Check `cpu.stat`: `nr_throttled` and `throttled_usec` are climbing.
3. Correlate: the throttling windows align with the latency spikes.
4. Fix: remove the CPU limit for this service, keep requests, enforce namespace ceilings with LimitRange/ResourceQuota, and dashboard throttling.

The lesson: **CPU limits trade tail latency for isolation, so choose deliberately.**

**5. What separates senior from staff answers:**
- Senior: knows QoS classes, OOM vs. throttle, and `/dev/shm`.
- Staff: defines org-wide policy per workload class, uses reserved resources and NUMA alignment, tunes with VPA data, and adds guardrails (LimitRange/Quota) so teams can't hurt each other.

**Red flags:** BestEffort AI pods, memory limits set from averages, CPU limits on latency services by default, no `/dev/shm`.

## Failure modes
- Pinned host memory (`pin_memory=True` in PyTorch) counts against the cgroup and causes surprise OOMs.
- `/dev/shm` defaults to 64 MB, so PyTorch DataLoader workers crash. Mount an `emptyDir: {medium: Memory}` at `/dev/shm`.
- Java/Go runtimes that ignore cgroup limits on older versions.

## Checklist
- [ ] Inference pods are `Guaranteed` QoS
- [ ] There is a `/dev/shm` mount for PyTorch workloads
- [ ] Throttling metrics are dashboarded
