# Lab 6: Local Networking — CoreDNS and Internal Load Balancing (5:20)

## Why it matters
Pods die and get new IPs constantly. AI systems are chains of services (gateway → router → LLM →
vector DB → reranker), and those chains need **stable names** and **balanced traffic**.

## In plain words
Pods are like employees who keep changing desks. A **Service** is the department phone number: you call "sales", not a specific desk.
**CoreDNS** is the phone directory. The catch: once a call connects, it stays on that line, so one busy caller can overload one employee.
That's why LLMs need smarter, per-request balancing.

## Core concepts

```mermaid
flowchart LR
  C[client pod] -->|vllm.ai.svc.cluster.local| DNS[CoreDNS]
  DNS -->|ClusterIP 10.43.0.50| C
  C --> KP[kube-proxy / eBPF<br/>iptables/IPVS rules]
  KP --> P1[pod A] & P2[pod B] & P3[pod C]
```

**How to read it:** The client resolves a name through CoreDNS and gets one stable virtual IP. kube-proxy or eBPF rules then spread connections across pods. Note that it spreads connections, not individual requests.

| Service type | Use |
|---|---|
| `ClusterIP` | Internal east-west (default) |
| `Headless` (`clusterIP: None`) | DNS returns pod IPs directly. Ray, Milvus, and NCCL peers need this |
| `NodePort` / `LoadBalancer` | North-south exposure |

**Critical for LLMs:** kube-proxy balances **per connection**, not per request. With HTTP/2 or gRPC
keep-alive, one client can pin all its traffic to one pod. LLM requests also vary 100× in cost
(10 tokens vs. 10k tokens), so round-robin is a poor fit.

## Architecture in depth

The overview shows DNS and kube-proxy. This view follows **one request's network path** inside the cluster, including where
DNS caching, policy, and load balancing happen.

```mermaid
flowchart LR
  APP[Client pod] -->|"(1) lookup vllm.ai"| NLD[NodeLocal DNSCache]
  NLD -->|cache miss| CDNS[CoreDNS pods]
  CDNS --> API[(EndpointSlices via API)]
  NLD -->|"ClusterIP 10.43.0.50"| APP
  APP -->|"(2) TCP to ClusterIP"| EBPF[kube-proxy iptables/IPVS<br/>or Cilium eBPF]
  EBPF -->|"(3) NetworkPolicy check"| POL{allowed?}
  POL -->|yes, pick backend| P1[vLLM pod A]
  POL --> P2[vLLM pod B]
  POL -.deny.-x X[dropped]
  P1 -.readiness fails.-> ES[removed from EndpointSlice]
```

### Follow one request from client pod to model pod
1. **Name lookup.** The client resolves `vllm.ai.svc.cluster.local`. The node-local DNS cache answers most lookups without leaving the node.
2. **Cache miss.** CoreDNS answers from EndpointSlices it watches through the API server. For a normal Service it returns one virtual ClusterIP.
3. **Connect.** The client opens TCP to the ClusterIP. No process listens on that IP; kernel rules (iptables/IPVS) or eBPF programs rewrite the destination to a real pod IP.
4. **Policy.** NetworkPolicy, enforced by the CNI, checks that this source may talk to this destination port. Default-deny means "only what's explicitly allowed".
5. **Backend choice.** A backend is picked *per connection*. With HTTP/2 keep-alive, every later request on that connection goes to the same pod.
6. **Health.** When a pod fails readiness, it's removed from the EndpointSlice and stops receiving *new* connections. Existing connections may linger.
7. **Headless services** skip the virtual IP. DNS returns pod IPs directly, which peers like Ray, Milvus, and NCCL need to address each other.

**The one idea to keep:** Kubernetes networking gives you stable names and connection-level balancing. Request-level intelligence needs an L7 proxy.

## Minimal hands-on

```bash
kubectl run tmp --rm -it --image=busybox -- nslookup vllm.ai.svc.cluster.local
kubectl get endpointslices -l kubernetes.io/service-name=vllm
kubectl -n kube-system get cm coredns -o yaml
```

## Worked example

**Scenario:** 3 vLLM replicas. Grafana shows **pod A at 95% KV-cache usage while B and C sit at 20%**.

- Root cause: the API gateway keeps 4 long-lived HTTP/2 connections, and all of them were hashed to pod A.
- Fix, step 1: an L7 load balancer (Envoy, Lab 49) balances per request with `LEAST_REQUEST`.
- Fix, step 2: a load-aware router such as the Gateway API Inference Extension or the vLLM production-stack router uses KV-cache utilization and queue depth as signals.
- Result: p95 TTFT goes from 4.1 s to **0.6 s** with no new GPUs.

## Production deep dive
- **DNS at scale:** Run NodeLocal DNSCache to cut CoreDNS QPS and fix the conntrack-race 5-second timeouts. Set `ndots: 2` to avoid the search-path storm (`ndots:5` turns one lookup into 5).
- **CNI choice:** Cilium (eBPF) replaces kube-proxy and adds L7 visibility (Hubble), network policies, and transparent encryption (WireGuard).
- **Zero trust:** Default-deny `NetworkPolicy` per namespace. Allow only gateway→LLM and LLM→vector-db.
- **Service mesh:** Istio ambient / Linkerd for mTLS and retries. Budget the latency cost (~1 ms/hop) and **disable retries for non-idempotent generation**.
- **Topology-aware routing:** `trafficDistribution: PreferClose` keeps traffic in-zone and avoids cross-AZ egress fees.

## FAANG deep-dive notes

- **How big tech does it:** Client-side or proxy-based L7 load balancing with load reports (outstanding requests, queue depth) is the norm for RPC. Pure L4 round-robin is rare for expensive, variable-cost requests.
- **Staff review questions:** Is balancing per request or per connection? What is the retry policy, and can it cause a retry storm? What is the DNS QPS at peak?
- **Interview question:** *"Why does one LLM replica overload while others idle?"* Strong answers cover HTTP/2 connection pinning, variable request cost, and the fixes: L7 least-request balancing, load-aware routing on KV usage, and connection rebalancing.

**Typical system-design prompt:** *"Design east-west networking for an AI platform: gateway → router → 6 model pools → vector DB → reranker, all inside one cluster."*

**1. Clarify first:**
- Protocols (HTTP/1.1, HTTP/2, gRPC, streaming SSE).
- Isolation requirements between tenants or teams.
- Latency budget per hop (e.g. < 2 ms added per hop).

**2. Back-of-envelope sizing:**
- 5,000 pods × 2 DNS lookups/s with `ndots:5` (5 queries per lookup due to search paths) = 50k QPS on CoreDNS. With `ndots:2` + NodeLocal cache, most never reach CoreDNS.
- iptables mode: rules grow with services × endpoints, and updates get slow at ~10k+ services. eBPF/IPVS scale better.
- A mesh sidecar adds ~0.5–1 ms per hop and ~50–100 MB RAM per pod. Over 6 hops that's ~5 ms, fine for LLMs (seconds) but not free.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Data plane | kube-proxy iptables | Cilium eBPF | eBPF at scale or when you need L7 visibility |
| Balancing | L4 per connection | L7 per request (Envoy/mesh) | L7 for gRPC/HTTP2 and variable-cost requests |
| mTLS | app-level TLS | mesh (Istio ambient, Linkerd) | mesh when many services need zero trust |
| Service type | ClusterIP | headless | headless for peer-to-peer systems |
| Traffic locality | any zone | topology-aware (PreferClose) | prefer same zone to cut latency and cross-AZ cost |

**4. Follow-up questions with crisp answers:**
- *Why the 5-second DNS timeouts?* A conntrack race on parallel UDP A/AAAA queries drops packets. NodeLocal DNSCache (TCP upstream) fixes it.
- *Why does round-robin fail for LLMs?* Requests vary 100× in cost, and HTTP/2 pins connections. Use least-request or load-aware routing.
- *ClusterIP vs. headless?* ClusterIP: one virtual IP, kernel balancing. Headless: DNS returns pod IPs, and the client chooses.
- *What does readiness actually do?* It controls EndpointSlice membership, so it decides whether a pod receives new traffic.
- *Why default-deny NetworkPolicy?* It turns network access into an explicit allow-list, which limits lateral movement after a compromise.
- *Should LLM generation requests be retried by the mesh?* Not on timeouts. Retries duplicate expensive work. Retry only connection failures.

**Debug this (common onsite question):** *"One of 4 vLLM replicas is at 100% KV cache while the others are at 20%. Traffic is steady."*
1. Check client connections: the gateway holds 3 long-lived HTTP/2 connections.
2. Map connections to pods: kube-proxy assigned 2 of the 3 connections to the same pod.
3. Every request on those connections lands on that pod, regardless of load.
4. Fix: per-request L7 balancing (Envoy least-request) or load-aware routing on KV usage, plus connection max-age to rebalance.

The lesson: **L4 balances connections, not work.**

**5. What separates senior from staff answers:**
- Senior: knows DNS, Services, headless, and NetworkPolicy, and spots HTTP/2 pinning.
- Staff: picks the data plane and mesh with cost numbers, plans DNS at scale, uses topology-aware routing, sets a zero-trust policy model, and defines retry policy for non-idempotent AI calls.

**Red flags:** ClusterIP for gRPC LLM traffic, no network policies, mesh retries on generation timeouts, `ndots:5` at 5k pods.

## Failure modes
- CoreDNS has only 2 replicas, so a 5,000-pod burst produces SERVFAIL. Autoscale CoreDNS.
- Headless service plus client-side DNS caching means traffic keeps going to dead pods.
- Retries on timeouts double GPU load during an incident (a retry storm).

## Checklist
- [ ] You can resolve a service from inside a pod
- [ ] You can explain why L4 balancing fails for LLMs
- [ ] A default-deny NetworkPolicy is drafted
