# Lab 1: Architecting the Baseline — System Requirements and CLI Tooling (3:45)

## Why it matters
Most failed AI projects die at the sizing stage. Someone picks a model that doesn't fit in
memory, or a box with no headroom for the KV cache. Size **from the model backwards**.

## In plain words
Before buying a moving truck, you measure your furniture. A model's **weights** are the furniture, and the **KV cache** is the extra
space every passenger (user) needs. If you only measure the furniture, the truck is full the moment people get in.
The CLI tools are your toolbox: `kubectl` is the steering wheel, `helm` is the app store, and `k9s` is the dashboard.

## Architecture at a glance

```mermaid
flowchart LR
  M[Pick model] --> W["Weights = params × bytes"]
  W --> K["+ KV cache per user × users"]
  K --> O["+ 20% overhead"]
  O --> H{Fits in GPU/RAM?}
  H -->|yes| T[Install CLI toolbelt → cluster]
  H -->|no| Q[Quantize / smaller model / more GPUs]
  Q --> W
```

**How to read it:** Start at the model, add the three memory costs left to right, then ask the single question in the diamond. If the answer is no, loop back through the cheaper options before buying hardware.

## Core concepts

**Memory rule of thumb for inference:**

```
weights_GB  ≈ params_B × bytes_per_param
              FP16/BF16 = 2, FP8/INT8 = 1, INT4 = 0.5
total_GB    ≈ weights_GB × 1.2  (runtime overhead)  + KV cache budget
```

**KV cache per token** ≈ `2 × layers × kv_heads × head_dim × bytes`

| Model | Precision | Weights | Fits on |
|---|---|---|---|
| Llama-3.2-1B | BF16 | ~2.5 GB | Laptop CPU / any GPU |
| Llama-3.1-8B | BF16 | ~16 GB | 1× 24 GB GPU (tight), 1× L40S / A100 |
| Llama-3.1-8B | INT4 | ~5 GB | 8 GB consumer GPU, Apple M-series |
| Llama-3.1-70B | FP8 | ~70 GB | 1× H100 80GB (small KV) or 2× H100 |
| Llama-3.1-405B | FP8 | ~405 GB | 8× H100 (1 node) |

**The CLI toolbelt**

| Tool | Role |
|---|---|
| `docker` / `nerdctl` | Build & run images |
| `k3d` or `k3s` | Local cluster |
| `kubectl` + `kubectx`/`kubens` | Cluster control |
| `helm` | Package manager |
| `k9s` | TUI for cluster ops |
| `stern` | Multi-pod log tailing |
| `nvidia-smi` / `nvtop` | GPU visibility |

## Architecture in depth

The overview diagram shows the sizing loop. This one shows the **whole decision pipeline** a platform team runs before buying or
allocating hardware: from a product request to a validated hardware plan.

```mermaid
flowchart LR
  REQ["Product request<br/>users, latency, context"] --> TR[Traffic model<br/>peak req/s, tokens in/out]
  MC[Model card<br/>params, layers, KV heads] --> MEM[Memory model<br/>weights + KV + overhead]
  TR --> CONC["Concurrency<br/>Little's law"]
  CONC --> MEM
  MEM --> HW[Hardware candidates<br/>L40S / H100 / MI300X]
  HW --> BM[Benchmark run<br/>real prompts]
  BM -->|meets SLO| PLAN[Capacity plan + budget]
  BM -->|misses| OPT[Quantize / cap context / route]
  OPT --> MEM
  PLAN --> TOOLS[Provision cluster + pinned toolchain]
```

### Follow one sizing request through the pipeline
1. **Product request.** "Support copilot, 3,000 agents, answers in under 1 s." Turn this into numbers before talking about GPUs.
2. **Traffic model.** Peak requests per second, plus *distributions* of input and output tokens (mean and p95). Output length matters most, because it sets how long each request occupies the GPU.
3. **Concurrency (Little's law).** In-flight sequences = arrival rate × time in system. 5 req/s × 12 s per answer = 60 concurrent sequences.
4. **Memory model.** Weights (params × bytes), plus KV per token × context × concurrency, plus ~20% overhead. This gives a minimum HBM figure.
5. **Hardware candidates.** Divide by usable HBM per GPU (~90% of the total). Check whether the model needs tensor parallelism, which requires NVLink.
6. **Benchmark run.** Paper math says the sequences *fit*. Only a benchmark with real prompts proves they're *fast enough*.
7. **Optimize loop.** If the plan misses the SLO or the budget, quantize, cap context, or route easy traffic to a smaller model, then recompute.
8. **Provision.** Only now create the cluster, with a pinned toolchain so every engineer and CI job uses the same versions.

**The one idea to keep:** hardware is the *output* of the sizing process, never the input.

## Minimal hands-on

```bash
# macOS
brew install kubectl helm k3d k9s stern
# Linux
curl -sfL https://get.k3s.io | sh -

# Preflight
nproc; free -g; df -h /; nvidia-smi --query-gpu=name,memory.total --format=csv
```

## Worked example

**Scenario:** A team wants to prototype an internal coding assistant on developer laptops
(MacBook M3 Pro, 36 GB unified memory) before buying GPUs.

1. Candidate: Qwen2.5-Coder-7B.
2. BF16 = 7 × 2 = 14 GB, ×1.2 = ~17 GB. That leaves ~19 GB for the OS, the IDE, and the KV cache. It **fits**.
3. KV cache: 28 layers × 4 KV heads × 128 dim × 2 (K,V) × 2 bytes ≈ **57 KB/token**.
   An 8k context comes to ~470 MB per concurrent session, so 4 sessions need about 2 GB. Fine.
4. Production projection: 200 developers at 2 concurrent requests each is 400 sessions × 470 MB ≈ **188 GB of KV**.
   That is 3× H100 just for cache, which justifies the GPU purchase in a one-page memo.

## Production deep dive
- **Golden images:** Bake OS + drivers + container runtime into immutable images (Packer, or Talos for an immutable OS). Never hand-configure GPU nodes.
- **Hardware BOM thinking:** GPU memory, GPU-to-GPU bandwidth (NVLink), NIC bandwidth (400G IB per GPU on training nodes), local NVMe for model caching, and CPU RAM ≥ 2× GPU memory for loading checkpoints.
- **Tool version pinning:** Use `mise`/`asdf` or a devcontainer so every engineer runs the same `kubectl`/`helm` versions. Version skew causes subtle failures.
- **Access:** Use an SSO-backed kubeconfig (OIDC via Dex/Keycloak), not static admin certs.

## FAANG deep-dive notes

- **How big tech does it:** Capacity planning is a formal process. Teams submit a model card plus traffic forecast, and a capacity team converts it into GPU-quarters using exactly this weights + KV + overhead math, validated by a benchmark run.
- **Staff review questions:** What is the p99 context length, not the average? What concurrency did you assume, and where does it come from? What is the plan when the forecast is 3× wrong?
- **Interview question:** *"Estimate the GPUs needed to serve a 70B model to 10k concurrent users at 4k context."* Strong answers compute weights (FP8 ≈ 70 GB), KV/token (≈ 320 KB BF16), total KV (≈ 13 TB), divide by usable HBM, then discuss quantized KV, prefix caching, and context caps to cut it down.

**Typical system-design prompt:** *"A company wants an internal assistant for 20,000 employees. Estimate the hardware and justify it."*

**1. Clarify first:**
- Daily active users, requests per user per day, peak-to-average ratio (often 3–5× for business hours).
- Token distributions: input (with RAG context) and output, mean and p95.
- Quality bar: does it need a 70B model, or does an 8B model with RAG pass the eval set?

**2. Back-of-envelope sizing:**
- 20k users × 30% daily active × 15 requests ≈ 90k requests/day. With a 4× peak over 8 business hours: 90k ÷ 28,800 s × 4 ≈ **12.5 req/s peak**.
- Output 300 tokens at 30 tok/s ≈ 10 s, plus prefill ≈ 11 s in system, so concurrency ≈ 12.5 × 11 ≈ **140 sequences**.
- 70B FP8 with 4k average context: KV ≈ 320 KB × 4k ≈ 1.3 GB per sequence (BF16 KV), so 140 × 1.3 ≈ **180 GB KV** + 70 GB weights per replica set.
- That is about 4× H100 80GB (TP=2 × 2 replicas) with FP8 KV, plus 1 replica for N+1. The answer is **6 GPUs, not 60**.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Model size | 70B: higher quality | 8B + RAG: 10× cheaper | pick the smallest model that passes the eval set |
| Precision | BF16 | FP8 / INT4 | quantize after an eval shows no regression |
| GPU type | H100: fast, NVLink | L40S: cheap, PCIe | L40S for ≤ 13B single-GPU; H100 when TP or long context is needed |
| Buy vs. rent | owned: cheapest at high utilization | cloud: elastic | own the baseline, rent the burst |

**4. Follow-up questions with crisp answers:**
- *Why include output length in sizing?* Each output token is a decode step, so output length sets how long a sequence holds KV memory and a batch slot.
- *What overhead do you add, and why?* About 20% for activations, CUDA graphs, and fragmentation, plus 30% headroom for traffic growth and failover.
- *How do you validate the paper estimate?* Run a load test with recorded real prompts at the target concurrency, and measure TTFT/TPOT at p95.
- *What changes for 128k-context use cases?* KV dominates. Route long-context requests to a separate pool, and use FP8 KV and prefix caching.
- *Why pin CLI tool versions?* Client/server skew (kubectl, helm) causes subtle apply differences. Pinning makes CI and laptops behave identically.
- *What is the most common sizing mistake?* Counting weights only. At 100+ concurrent users, the KV cache is often 2–5× the weights.

**Debug this (common onsite question):** *"The pilot worked for 20 users. At 300 users, requests time out, but GPU memory usage hasn't changed. What happened?"*
1. Memory is flat because vLLM pre-allocates the KV pool, so memory usage isn't the signal. Check `num_requests_waiting`.
2. The queue is huge: concurrency demand (300 users × long answers) exceeds the KV pool's sequence capacity.
3. Recompute: KV per sequence × required concurrency is greater than the pool. The pilot never exercised this.
4. Fix: add replicas, use FP8 KV, cap `max-model-len` at p99, and add a load test to the launch checklist.

The lesson: **sizing is a concurrency problem, not a model-size problem.**

**5. What separates senior from staff answers:**
- Senior: correct weights + KV math and a sensible GPU choice.
- Staff: starts from SLOs and traffic distributions, uses Little's law, plans N+1 and growth, gives cost per request, and proposes a benchmark to validate.

**Red flags:** sizing from parameter count alone, ignoring output length, no headroom, no validation benchmark.

## Failure modes
- Sizing only weights and forgetting the KV cache, which OOMs under concurrency.
- Choosing a model whose license forbids your use case (always check the license).
- The CPU-RAM bottleneck: loading a 140 GB checkpoint on a 128 GB RAM host swaps forever.

## Checklist
- [ ] A sizing sheet (weights + KV + overhead) exists for the target model
- [ ] CLI tools installed and versions pinned
- [ ] `kubectl version` and `helm version` work
