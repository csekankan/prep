# Section 2 — Foundations & The Local AI Sandbox (8:38)

**Goal:** Build a full AI platform on your laptop: K3s, storage, networking, vLLM, and an
OpenAI-compatible chat API, with no cloud account required.

| Lab | Topic | Key idea |
|---|---|---|
| [01](lab01_system_requirements_cli.md) | System requirements & CLI tooling | Size the box from the model you plan to run |
| [02](lab02_containerization_deep_dive.md) | Docker, containerd, cgroups | Containers are just processes with fences |
| [03](lab03_cpu_memory_limits.md) | CPU & memory limits for AI | Requests schedule, limits kill |
| [04](lab04_bootstrapping_k3s.md) | Bootstrapping K3s | A real cluster in 30 seconds |
| [05](lab05_pod_topologies_ephemeral_storage.md) | Pod topologies & ephemeral storage | Init containers, sidecars, emptyDir for ML data |
| [06](lab06_coredns_internal_lb.md) | CoreDNS & internal load balancing | Services are stable names over moving pods |
| [07](lab07_persistent_volumes_data_lakes.md) | Persistent volumes | Model weights must outlive pods |
| [08](lab08_local_vllm_sandbox.md) | Local vLLM | PagedAttention and the KV cache budget |
| [09](lab09_ingress_local_dns.md) | Ingress & local DNS | One front door, many backends |
| [10](lab10_milestone_local_chat_api.md) | Milestone: local chat API | Drop-in replacement for the OpenAI API |

## Section architecture

```mermaid
flowchart LR
  U[curl / SDK] --> ING[Traefik Ingress<br/>chat.local]
  ING --> SVC[Service vllm]
  SVC --> P1[vLLM pod]
  P1 --> PVC[(PVC: model weights)]
  P1 -.DNS.-> DNS[CoreDNS]
```

## Enterprise lens

Your laptop sandbox is a **miniature of production**. The same objects (Deployment, Service,
PVC, Ingress) appear at 1,000-GPU scale. Only the implementations change:

| Laptop | Enterprise |
|---|---|
| K3s single node | RKE2 / OpenShift / EKS / bare-metal kubeadm, 3+ control-plane nodes |
| local-path storage | Ceph, NetApp, Weka, Lustre, or VAST via CSI |
| Traefik | Envoy Gateway / NGINX / F5 + WAF |
| Small model (1–8B) | 70B–400B+ on multi-GPU nodes |
