# Lab 7: Persistent Volumes — Mounting Local Data Lakes (5:09)

## Why it matters
Model weights (GBs to TBs), datasets, checkpoints, and vector indexes must **outlive pods**.
Storage is the most common hidden bottleneck in AI platforms.

## In plain words
Pods are rental cars, and you return them often. **Persistent Volumes** are your storage unit: your stuff (model weights, datasets)
stays there no matter which car you drive. A **PVC** is the rental form saying "I need 50 GB", and the **StorageClass** is the type of
unit (fast and close by, or cheap and far away).

## Architecture at a glance

```mermaid
flowchart LR
  POD[Pod] -->|claims| PVC[PVC 50Gi]
  PVC -->|bound to| PV[PersistentVolume]
  SC[StorageClass fast-nvme] -->|provisions| PV
  PV --> D1[(Hot: local NVMe)]
  PV -.tier.-> D2[(Warm: parallel FS)]
  PV -.tier.-> D3[(Cool: S3/MinIO)]
```

**How to read it:** A pod asks for storage via a PVC. The StorageClass decides how to create the actual PersistentVolume and on which tier. Dotted arrows show data moving between tiers by policy.

## Core concepts

```
StorageClass (policy: "fast-nvme", "shared-rwx")
     │ dynamic provisioning
     ▼
PersistentVolume (actual disk)  ◀── bound ──  PersistentVolumeClaim (pod's request)
```

| Access mode | Meaning | AI use |
|---|---|---|
| `RWO` | One node read-write | Vector DB shard, training scratch |
| `ROX` | Many nodes read-only | Shared model weights |
| `RWX` | Many nodes read-write | Shared checkpoints, datasets |
| `RWOP` | One pod | Strict single-writer DBs |

**Storage tiers for AI**

| Tier | Tech | Throughput | Use |
|---|---|---|---|
| Hot | Local NVMe | 5–14 GB/s per drive | Weights cache, shuffle buffers |
| Warm | Parallel FS (Lustre, Weka, GPFS, VAST) | 100s of GB/s aggregate | Training data, checkpoints |
| Cool | Object store (S3/MinIO) | Scales out | Data lake, model registry |
| Cold | Tape / glacier | — | Compliance retention |

## Architecture in depth

The overview shows PVC → PV → tiers. This view shows **dynamic provisioning end to end**: what happens between `kubectl apply`
of a PVC and the pod reading weights from disk.

```mermaid
flowchart TB
  PVC["PVC: 500Gi, RWX, class=shared-fast"] --> WAIT{"volumeBindingMode:<br/>WaitForFirstConsumer"}
  POD[Pod scheduled to node in zone b] --> WAIT
  WAIT --> CTRL[CSI external-provisioner]
  CTRL -->|CreateVolume in zone b| BACK[(Storage backend<br/>Ceph / Weka / NetApp / EBS)]
  BACK --> PV[PV created + bound]
  PV --> ATT[CSI attacher → NodeStage]
  ATT --> MNT[CSI node plugin → NodePublish<br/>mount into pod path]
  MNT --> APP[Pod reads /models]
  SNAP[VolumeSnapshot] -.point-in-time copy.-> BACK
  ENC[KMS keys] -.encryption at rest.-> BACK
```

### Follow one PVC from request to mounted volume
1. **Claim.** The PVC asks for size, access mode, and a StorageClass. It's a request, not a disk yet.
2. **Wait for the consumer.** With `WaitForFirstConsumer`, provisioning waits until a pod is scheduled, so the disk is created in the pod's zone instead of a random one.
3. **Provision.** The CSI provisioner calls the storage backend's `CreateVolume` with the class parameters (performance tier, replication, encryption).
4. **Bind.** A PV object representing the new disk is created and bound one-to-one to the PVC.
5. **Attach and stage.** For block storage, the volume is attached to the node and formatted or mounted once at a staging path.
6. **Publish.** The node plugin bind-mounts it into the pod's container path (e.g. `/models`).
7. **Lifecycle.** Snapshots give point-in-time copies. When the PVC is deleted, the reclaim policy decides whether the disk is deleted or retained.

**The one idea to keep:** the StorageClass is a policy. Choosing it is choosing performance, locality, durability, and cost.

## Minimal hands-on

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata: { name: model-store }
spec:
  accessModes: [ReadWriteOnce]
  storageClassName: local-path      # K3s default
  resources: { requests: { storage: 50Gi } }
```

```bash
# Pre-load weights once, reuse forever
kubectl run loader --image=python:3.12 --overrides='{...mount model-store...}' -- \
  sh -c "pip install -q huggingface_hub && huggingface-cli download Qwen/Qwen2.5-1.5B-Instruct --local-dir /models/qwen"
```

## Worked example

**Scenario:** Autoscaling a 70B model (140 GB BF16). Each new pod takes **11 minutes** to become ready.

| Approach | Load time |
|---|---|
| Download from Hugging Face on every start | 11 min (network-bound, and HF rate limits apply) |
| Download from in-DC MinIO (10 GbE) | ~2.5 min |
| Shared RWX parallel FS (Weka) | ~60 s |
| Node-local NVMe cache, pre-warmed by a DaemonSet | ~35 s |
| + `safetensors` mmap + Run:ai Model Streamer / fastsafetensors | **~15 s** |

The enterprise pattern combines them: the **object store is the source of truth, the node-local
NVMe cache is the fast path, and loading uses mmap streaming.**

## Production deep dive
- **CSI drivers:** Ceph-CSI (Rook) for on-prem block/RWX, the vendor CSIs (NetApp Trident, Pure Portworx), and Mountpoint-S3/JuiceFS to expose object storage as files.
- **Topology:** `volumeBindingMode: WaitForFirstConsumer` so the volume is created in the zone where the pod lands.
- **Snapshots:** `VolumeSnapshot` CRDs give instant vector-DB/checkpoint copies (feeding Lab 68).
- **Data lakes:** Mount Iceberg/Delta tables via S3, not through POSIX hacks. Training readers (Ray Data, WebDataset) speak S3 natively.
- **Encryption:** At rest (LUKS / storage-native, KMS-managed keys) and in transit. Per-tenant keys enable crypto-shredding for GDPR deletion.

## FAANG deep-dive notes

- **How big tech does it:** Object storage is the durable source of truth. Hot data sits on local NVMe caches, and distributed caching layers sit in between. POSIX shared filesystems are reserved for training workloads that truly need them.
- **Staff review questions:** What is the load time at 100 concurrent pod starts? What is the reclaim policy? How is the data encrypted, and who holds the keys?
- **Interview question:** *"Design storage for a 1,000-GPU training cluster."* Strong answers separate the dataset read path (high throughput) from the checkpoint write path (bursty, very high bandwidth), and cover metadata scaling, tiering, and cost.

**Typical system-design prompt:** *"Design the storage layer for an AI platform: 2 PB of training data, 50 models for serving, and checkpoints from 512-GPU jobs."*

**1. Clarify first:**
- Read pattern for training (sequential large shards or random small files?).
- Checkpoint size and frequency (this sets the write-bandwidth peak).
- Durability and residency requirements per data class.

**2. Back-of-envelope sizing:**
- Training read: 512 GPUs × ~50 MB/s each (for tokenized text) ≈ 25 GB/s aggregate. Images/video are 10× higher.
- Checkpoint write: a 70B model with full Adam ≈ 1.1 TB. Written in 2 minutes, that needs ~9 GB/s. Every 20 minutes, that's a 10% duty cycle.
- Serving: 50 models × average 30 GB = 1.5 TB hot set, small enough to cache on node NVMe.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Training data | parallel FS (Lustre/Weka) | object store + streaming loaders | object + streaming for text; parallel FS for random-access multimodal |
| Checkpoints | parallel FS | object store with async upload | object store as durable tier, NVMe as fast tier |
| Serving weights | RWX shared FS | node-local cache from object store | local cache for hot models |
| Access mode | RWO block | RWX file | RWO for databases; RWX only when multiple writers truly need it |
| Encryption | storage-level | per-tenant keys | per-tenant keys enable crypto-shredding |

**4. Follow-up questions with crisp answers:**
- *Why `WaitForFirstConsumer`?* So the volume is created in the zone where the pod runs. Otherwise the pod can't attach a disk in another zone.
- *RWO vs. RWOP?* RWO is one node (several pods on it could share). RWOP is exactly one pod, for strict single-writer safety.
- *Why do small files hurt?* Each file costs metadata operations. Millions of small files overload the metadata servers. Pack them into shards.
- *Retain vs. Delete reclaim policy?* Delete removes the disk with the PVC. Retain keeps it for manual recovery. Use Retain for irreplaceable data.
- *How do you back up a PVC consistently?* Quiesce the app, take a CSI VolumeSnapshot, then copy off-cluster (Lab 68).
- *Why is NFS a bad checkpoint target at scale?* Hundreds of ranks writing at once cause metadata storms and lock contention, and throughput collapses.

**Debug this (common onsite question):** *"Training step time doubles every 20 minutes for about 3 minutes."*
1. Correlate with the checkpoint schedule: the spikes match.
2. Checkpoints are synchronous and written to the same parallel filesystem the data loaders read from.
3. Write bandwidth saturates the filesystem, so reads stall and the GPUs wait for data.
4. Fix: async checkpointing to local NVMe first, then background upload to object storage, and a separate QoS/path for checkpoint traffic.

The lesson: **storage paths for reads and bursty writes must be designed separately.**

**5. What separates senior from staff answers:**
- Senior: correct use of PVCs, StorageClasses, access modes, and snapshots.
- Staff: quantifies read and write bandwidth per workload, designs tiers, separates the checkpoint and read paths, and covers encryption, residency, and reclaim policy.

**Red flags:** one storage class for everything, NFS for 512-rank checkpoints, Delete reclaim on irreplaceable data, no bandwidth math.

## Failure modes
- `local-path` RWO volumes pin the pod to one node. If that node dies, the pod is stuck Pending.
- RWX NFS used for checkpoints from 64 ranks causes metadata storms that stall training.
- PVC `Retain` vs. `Delete` reclaim policy confusion leads to accidental data loss on namespace deletion.

## Checklist
- [ ] Weights are on a PVC and the pod restarts without re-downloading
- [ ] A tier map (hot/warm/cool) for your org exists
- [ ] The reclaim policy is reviewed for critical data
