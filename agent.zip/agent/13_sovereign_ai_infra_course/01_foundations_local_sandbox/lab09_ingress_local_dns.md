# Lab 9: Exposing the API — Ingress Controllers and Local DNS (5:28)

## Why it matters
Clients need one stable, TLS-protected URL. Behind it you may have many models, versions, and
tenants. The ingress layer is where **auth, rate limits, routing, and TLS** live.

## In plain words
**Ingress** is the building's front door with a receptionist. Visitors use one address (`chat.local`), and the receptionist checks
their badge (TLS/auth) and sends them to the right room (model service). Local DNS is the sign outside that makes the address work.

## Architecture at a glance

```mermaid
flowchart LR
  C[Client] -->|https://chat.local| DNS[Local DNS / hosts]
  DNS --> GW["Ingress / Gateway: TLS, auth, limits"]
  GW -->|/v1 model=llama| S1[Service vllm-llama]
  GW -->|model=embed| S2[Service embed]
  S1 --> P1[Pods]
  S2 --> P2[Pods]
```

**How to read it:** Follow one request: DNS points to the gateway, which terminates TLS, checks auth and limits, then picks a backend service by path or model. Each service fans out to its pods.

## Core concepts

| API | Status | Notes |
|---|---|---|
| `Ingress` | Stable, frozen | Simple host/path routing; vendor annotations for everything else |
| **Gateway API** | Successor (GA) | Role-split: `GatewayClass` (infra) → `Gateway` (platform) → `HTTPRoute`/`GRPCRoute` (app team) |
| Gateway API Inference Extension | Emerging | `InferencePool` / model-aware routing for LLMs |

**LLM-specific ingress concerns**
- **Streaming (SSE):** Disable response buffering and raise idle timeouts (generations can last minutes).
- **Body size:** Long prompts and base64 images need `client_max_body_size` ≥ 10–50 MB.
- **Timeouts:** Default 60 s proxies cut off long completions.

## Architecture in depth

The overview shows one gateway routing to services. This view shows the **Gateway API role split** and the full path of a
streaming request, including where TLS, auth, and limits apply.

```mermaid
flowchart LR
  subgraph Infra["Infra team owns"]
    GC[GatewayClass: envoy-gateway]
  end
  subgraph Platform["Platform team owns"]
    GW["Gateway: ai.corp.example :443<br/>TLS cert from cert-manager"]
    SEC[SecurityPolicy: OIDC JWT]
    RL[RateLimit policy per team claim]
  end
  subgraph Apps["Model teams own"]
    R1["HTTPRoute: model=llama-70b"]
    R2["HTTPRoute: model=embed"]
  end
  GC --> GW
  GW --> SEC --> RL
  RL --> R1 --> S1[Service llama] --> P1[Pods]
  RL --> R2 --> S2[Service embed] --> P2[Pods]
  DNS[ExternalDNS] -.publishes hostname.-> GW
```

### Follow one streaming chat request through the gateway
1. **DNS.** ExternalDNS published `ai.corp.example` pointing to the Gateway's load-balancer IP.
2. **TLS.** The Gateway terminates TLS with a certificate that cert-manager issued and renews automatically.
3. **Authentication.** The security policy validates the OIDC JWT. The `team` claim identifies the caller.
4. **Rate limit.** The team's quota is checked (requests now, tokens later in Lab 79). Over quota returns 429 with Retry-After.
5. **Route match.** The model team's HTTPRoute matches on path, header, or model name, and forwards to its Service.
6. **Streaming.** The response comes back as Server-Sent Events. Buffering must be off and the idle timeout long enough for a full generation.
7. **Access log.** The gateway logs team, route, status, latency, and (from the response) token counts for chargeback.

**The one idea to keep:** the Gateway API splits ownership. Infra owns the class, platform owns the entry point and policy, and app teams own only their routes.

## Minimal hands-on

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: chat
  namespace: ai
spec:
  rules:
  - host: chat.local
    http:
      paths:
      - path: /v1
        pathType: Prefix
        backend: { service: { name: vllm, port: { number: 8000 } } }
```

```bash
echo "127.0.0.1 chat.local" | sudo tee -a /etc/hosts
# Or wildcard local DNS without editing hosts:  *.127.0.0.1.nip.io
curl http://chat.local/v1/models
```

TLS locally: `mkcert chat.local` → `kubectl create secret tls chat-tls ...`. In real clusters use cert-manager.

## Worked example

**Scenario:** A company exposes 3 models to 12 internal teams.

```
https://ai.corp.example/v1/chat/completions
   │  body: {"model": "llama-70b" | "qwen-coder" | "embed-bge"}
   ▼
Gateway (Envoy Gateway)
   ├─ OIDC JWT validation (Keycloak)          → who is calling
   ├─ Rate limit by JWT claim `team`          → 50 req/s per team
   ├─ Route by header/body `model`            → HTTPRoute per model
   └─ Canary: 10% of llama-70b → v2 pool      → Lab 50
```

The result is one hostname, one certificate, and per-team quotas. Model teams own only their `HTTPRoute`.

## Production deep dive
- **cert-manager** with an internal ACME/Vault PKI issuer. Rotate certificates automatically.
- **WAF + DDoS** in front (F5, Cloudflare, ModSecurity/Coraza). Add prompt-injection filtering as an L7 concern (Section 7).
- **Private vs. public:** Separate `Gateway` objects for internal-only and partner-facing traffic, on different LoadBalancer IPs.
- **External DNS:** ExternalDNS syncs `Gateway` hostnames into Route53, Infoblox, or PowerDNS.
- **Observability:** Access logs with token counts (parsed from the response) give you chargeback per team.

## FAANG deep-dive notes

- **How big tech does it:** A global front door handles TLS, DDoS, and WAF, an API gateway handles auth, quotas, and routing, and internal L7 routing handles the model pools. Each layer is owned by a different team with clear contracts.
- **Staff review questions:** Does streaming work end to end without buffering? What are the timeout values at each hop? How do you attribute token costs per team?
- **Interview question:** *"Design the API layer for an internal LLM platform used by 50 teams."* Strong answers cover OIDC auth, per-team token quotas, model routing, streaming support, observability per tenant, and chargeback.

**Typical system-design prompt:** *"Design the API front door for an internal LLM platform: 50 teams, 10 models, streaming responses, per-team quotas."*

**1. Clarify first:**
- Auth model (SSO users, service accounts, or both).
- Quota unit (requests, tokens, dollars) and enforcement granularity (team, user, app).
- Internal only, or also partner-facing (WAF, DDoS, separate IPs)?

**2. Back-of-envelope sizing:**
- Peak 500 req/s with average 15 s streams = 7,500 concurrent open connections. Envoy handles this easily, but idle timeouts and connection limits must allow it.
- Access logs: 500 req/s × 1 KB = 43 GB/day, so plan retention and sampling.
- TLS handshakes: with keep-alive and HTTP/2, handshake CPU is small. Without keep-alive, it dominates gateway CPU.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| API | Ingress + annotations | Gateway API | Gateway API for multi-team ownership and portability |
| Routing key | path per model | `model` field in body | body routing needs an L7 filter; paths are simpler |
| Auth | at gateway | in every service | gateway authN, service-level authZ for sensitive actions |
| Internal vs. external | one gateway | separate Gateways | separate for blast radius and different WAF rules |
| Certificates | wildcard | per-host | per-host for tenant isolation |

**4. Follow-up questions with crisp answers:**
- *Why do streamed tokens arrive all at once?* Proxy buffering is on. Disable it for SSE routes.
- *Why do long answers end with a 504?* An idle or route timeout shorter than the generation time. Raise it for LLM routes only.
- *How do you attribute cost per team?* The gateway reads token usage from responses and logs it with the team claim.
- *Why the Gateway API over Ingress?* Role separation, standard features without vendor annotations, and gRPC/HTTPRoute types.
- *How do you canary a model at the gateway?* Weighted backendRefs in the HTTPRoute (Lab 50).
- *Where should prompt-injection filtering live?* As an L7 filter at the gateway (or ext_proc), plus defenses in the app. Never only one layer.

**Debug this (common onsite question):** *"Users on the partner portal see responses cut off after exactly 60 seconds, but internal users don't."*
1. Compare paths: partners go through the external Gateway and the WAF. Internal users don't.
2. The WAF has a default 60 s response timeout.
3. Long reasoning responses exceed 60 s.
4. Fix: raise the timeout for the streaming route on the WAF and gateway, add a heartbeat comment in SSE to keep the connection alive, and set a per-route max generation time.

The lesson: **every hop has a timeout. List them all for streaming paths.**

**5. What separates senior from staff answers:**
- Senior: TLS, routing, streaming settings, auth at the gateway.
- Staff: an ownership model (Gateway API roles), quota design in tokens, chargeback, separate blast radii, and timeout budgets across every hop.

**Red flags:** one shared wildcard cert for all tenants, buffering on SSE, default 60 s timeouts, no per-team quotas.

## Failure modes
- Buffering enabled on the proxy, so streaming tokens arrive all at once at the end.
- A 60 s idle timeout produces `504` on long reasoning-model responses.
- Wildcard certificates shared across tenants widen the blast radius on key leak.

## Checklist
- [ ] `curl https://chat.local/v1/models` works with TLS
- [ ] Streaming works token-by-token through the ingress
- [ ] A Gateway API version of the route is written
