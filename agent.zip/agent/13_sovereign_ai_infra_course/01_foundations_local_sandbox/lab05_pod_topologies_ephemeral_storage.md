# Lab 5: Pod Topologies and Ephemeral Storage for ML Data (5:33)

## Why it matters
An inference pod is rarely one container. It usually downloads weights, runs the model, ships logs,
and maybe proxies auth. Arranging these correctly gives you fast, clean, debuggable pods.

## In plain words
A pod is a **small team sharing one desk**. The **init container** is the intern who sets up the desk before work starts (downloads
the model). The **main container** does the real work (serves the model). **Sidecars** are assistants who stay all day (logs, auth).
`emptyDir` is a whiteboard on the desk: handy, but wiped when the team leaves.

## Architecture at a glance

```mermaid
flowchart LR
  subgraph Pod
    I["Init: fetch + verify weights"] --> V[(emptyDir /models)]
    V --> S[Main: vLLM server]
    SH[("/dev/shm RAM")] --> S
    SC[Sidecar: log shipper] -.-> S
  end
  S3[(Object store)] --> I
```

**How to read it:** The init container runs first and fills the shared volume. Only then does the main server start and read from it. The RAM-backed `/dev/shm` and the sidecar run alongside the main container.

## Core concepts

| Pattern | Use in AI |
|---|---|
| **Init container** | Download or verify model weights before the server starts |
| **Sidecar** (native since K8s 1.29, `restartPolicy: Always` in initContainers) | Log shipping, auth proxy, metrics adapter |
| **Ambassador** | Local proxy to a remote vector DB |
| **Adapter** | Convert app metrics to Prometheus format |

**Ephemeral storage options**

| Volume | Backed by | Lifetime | ML use |
|---|---|---|---|
| `emptyDir` | Node disk | Pod | Scratch, decompressed datasets |
| `emptyDir: {medium: Memory}` | RAM (tmpfs) | Pod | `/dev/shm`, hot tensors |
| Generic ephemeral volume | Any StorageClass | Pod | Large scratch on fast NVMe CSI |
| `hostPath` | Node path | Node | Avoid it (security risk) |

## Architecture in depth

The overview shows one pod's containers. This view shows **how model weights reach many pods at scale** without overloading the
origin store, and the pod lifecycle around them.

```mermaid
flowchart LR
  ORIG[(Origin: S3 / MinIO / registry)] --> RC[Regional cache / P2P]
  RC --> DS["Pre-pull DaemonSet<br/>warms node NVMe"]
  DS --> NC[(Node cache: /var/cache/models)]
  subgraph Pod
    direction TB
    INIT["Init: verify checksum + signature<br/>copy or link from node cache"] --> MAIN[Main: inference server]
    SIDE["Native sidecar: log/metrics<br/>starts first, stops last"] -.-> MAIN
  end
  NC --> INIT
  MAIN --> SHM[("/dev/shm: RAM emptyDir")]
  MAIN --> SCR[(Scratch: emptyDir sizeLimit)]
```

### Follow one pod start on a fresh node
1. **Before any pod lands**, a DaemonSet on each new GPU node pulls the popular models into a node-local cache. This happens while the node joins, not on the critical path.
2. **The pod is scheduled.** Native sidecars (declared in `initContainers` with `restartPolicy: Always`) start first, so logging is ready before the app speaks.
3. **The init container** checks that the model exists in the node cache, verifies its checksum and signature, and fetches from the regional cache only on a miss.
4. **The main container starts** only after init succeeds. It reads weights via mmap (fast, shared across processes) instead of copying them into RAM.
5. **`/dev/shm`** (a memory-backed emptyDir) gives data-loader and tensor-parallel workers shared memory. Its size counts against the pod's memory limit.
6. **Scratch emptyDir** has a `sizeLimit`. Exceeding it evicts the pod, which is better than filling the node disk and evicting everyone.
7. **On shutdown**, the main container drains, and the sidecars stop last, so final logs are flushed.

**The one idea to keep:** weight distribution is a caching problem. Origin, regional cache, and node cache form a hierarchy, and pods should almost always hit the node cache.

## Minimal hands-on

```yaml
spec:
  initContainers:
  - name: fetch-model
    image: amazon/aws-cli
    command: ["sh","-c","aws s3 sync s3://models/llama-8b /models && sha256sum -c /models/SHA256SUMS"]
    volumeMounts: [{ name: models, mountPath: /models }]
  containers:
  - name: server
    image: vllm/vllm-openai:v0.6.3
    args: ["--model", "/models"]
    volumeMounts:
    - { name: models, mountPath: /models }
    - { name: shm, mountPath: /dev/shm }
  volumes:
  - { name: models, emptyDir: { sizeLimit: 40Gi } }
  - { name: shm, emptyDir: { medium: Memory, sizeLimit: 8Gi } }
```

## Worked example

**Scenario:** A fine-tuning job reads 200k images from S3 every epoch. GPU utilization sits at **35%**
because the job is I/O-bound.

1. Add an init container that syncs and decompresses the dataset (60 GB) to an `emptyDir` on local NVMe.
2. The DataLoader now reads at ~3 GB/s locally instead of ~300 MB/s over the network.
3. Mount `/dev/shm` at 16 GB for 8 DataLoader workers.
4. GPU utilization rises to **88%** and epoch time falls from 42 min to 17 min.

Trade-off: the 60 GB copy costs ~4 minutes on every pod start. That is worth it for 10-epoch jobs,
but not for 1-epoch jobs, which should stream (Lab 33).

## Production deep dive
- **Model weight distribution at scale:** Don't have 100 pods each pull 140 GB from S3. Use a node-level cache (a DaemonSet pre-puller, Fluid/Alluxio, or a shared RWX volume from Lab 7). OCI model artifacts (ModelCar / KServe ModelCar, ORAS) let you treat weights as image layers.
- **Integrity:** Always verify checksums or signatures in the init container. A poisoned weight file is a supply-chain attack.
- **Eviction:** If ephemeral usage exceeds `ephemeral-storage` limits, the pod is evicted. Set `sizeLimit` explicitly.
- **Topology spread:** Use `topologySpreadConstraints` across zones/racks so one rack failure doesn't kill all replicas.

## FAANG deep-dive notes

- **How big tech does it:** Weights are distributed through a node-level cache or P2P layer, so thousands of pods never pull from the origin at once. The integrity of every artifact is verified before use.
- **Staff review questions:** What happens when 200 pods start simultaneously? Is checksum verification mandatory? What evicts the pod if scratch space fills?
- **Interview question:** *"How would you cut model server cold start from 10 minutes to 30 seconds?"* Strong answers cover a node-local cache, pre-warming DaemonSets, mmap'd safetensors, streaming loaders, keeping weights out of images, and right-sized startup probes.

**Typical system-design prompt:** *"Design model weight distribution for 500 GPU nodes serving 40 models (2–140 GB each), with new pods ready in under 60 seconds."*

**1. Clarify first:**
- Model popularity distribution (usually a few hot models and a long tail).
- Update frequency of weights (daily fine-tunes vs. quarterly base models).
- Node local disk size and network bandwidth per node.

**2. Back-of-envelope sizing:**
- 140 GB in 60 s needs ~2.3 GB/s per node, which is only realistic from local NVMe, not from S3 over a 25 GbE NIC (~3 GB/s at best, shared).
- 500 nodes cold-pulling 140 GB from the origin at once = 70 TB, which would saturate any object store. A regional cache plus P2P is mandatory.
- Node cache: the top 5 models ≈ 300 GB, so 1–2 TB NVMe per node holds the hot set comfortably.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Weight packaging | files in object store | OCI artifacts (ModelCar/ORAS) | OCI when you want registry tooling, signing, and P2P for free |
| Fetch timing | at pod start (init) | pre-pulled per node (DaemonSet) | pre-pull hot models; init-fetch the long tail |
| Shared vs. local | RWX shared filesystem | node-local NVMe cache | local for the speed-critical hot set; RWX for the long tail |
| Integrity | trust the store | verify hash + signature on load | always verify; poisoned weights are a supply-chain attack |

**4. Follow-up questions with crisp answers:**
- *Why init containers instead of the app downloading on start?* Separation of concerns, a clear failure state, and the app image stays small and generic.
- *Native sidecar vs. regular sidecar?* Native sidecars start before the main container and stop after it, which fixes log loss and startup ordering.
- *Why does a pod get evicted with "ephemeral storage exceeded"?* emptyDir/container writable layer usage passed the limit. Set `sizeLimit` and requests explicitly.
- *How do you avoid a thundering herd on the origin?* A regional cache, P2P distribution, and staggered (jittered) pre-pulls.
- *mmap vs. read into RAM?* mmap lets the OS page weights in on demand and share pages between processes, so loads are faster and use less memory.
- *How do you update a hot model without a download spike?* Pre-pull the new version in the background, then switch pods (blue/green, Lab 50).

**Debug this (common onsite question):** *"During a traffic spike, new inference pods take 12 minutes to become ready, but the image is small."*
1. Look at the pod timeline: the init container takes 11 minutes.
2. Its logs show S3 download throughput of 200 MB/s, shared by 30 pods starting at once.
3. The node cache is empty: the new nodes came from Karpenter and the pre-pull DaemonSet was still running.
4. Fix: bake the top models into the node image (or warm pools of pre-cached nodes), add a regional cache, and use a startup probe that tolerates the load time.

The lesson: **cold-start time is dominated by data movement. Design the cache hierarchy, not the container.**

**5. What separates senior from staff answers:**
- Senior: correct init/sidecar usage, checksums, `/dev/shm`, sizeLimit.
- Staff: a cache hierarchy with numbers, popularity-based pre-pulling, origin protection, signed artifacts, and cold-start SLOs tied to autoscaling.

**Red flags:** every pod downloading from Hugging Face, no integrity check, unbounded emptyDir, hostPath for weights.

## Failure modes
- The init container downloads succeed, but the main container starts before a file system sync and sees partial files.
- `emptyDir` on the root disk fills `/var/lib/kubelet` and evicts every pod on the node.
- Sidecar ordering: the log sidecar exits before the app flushes, so final logs are lost. Native sidecars fix this.

## Checklist
- [ ] Weights load via an init container with checksum verification
- [ ] `/dev/shm` is sized
- [ ] `ephemeral-storage` requests/limits are set
