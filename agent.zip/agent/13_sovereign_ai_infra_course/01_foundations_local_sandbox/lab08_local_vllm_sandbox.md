# Lab 8: Deploying the Inferencing Engine — Local vLLM Sandbox (4:34)

## Why it matters
Naive HuggingFace `generate()` serves ~1 request at a time. vLLM serves **dozens to hundreds
concurrently** on the same GPU, typically with 10–24× the throughput. It became the de facto open inference engine.

## In plain words
Old-style serving is a **taxi**: one passenger at a time. vLLM is a **bus with smart seating**. Passengers get on and off at every stop
(continuous batching), and seats are assigned in small blocks so no space is wasted (PagedAttention). The same GPU carries many more people.

## Architecture at a glance

```mermaid
flowchart LR
  R1[Request A] & R2[Request B] & R3[Request C] --> Q[Scheduler queue]
  Q --> B["Continuous batch: every step, join/leave"]
  B --> GPU[GPU forward pass]
  GPU --> KV[("Paged KV cache blocks")]
  KV --> B
  GPU --> OUT[Stream tokens back]
```

**How to read it:** Requests enter a queue. Every step, the scheduler admits or removes sequences from the running batch. The GPU writes KV into paged blocks, which feed the next step.

## Core concepts

**1. PagedAttention.** The KV cache is split into fixed blocks (like OS pages). There is no
pre-allocation for max length, so memory waste drops from ~60–80% to < 4%.

**2. Continuous batching.** New requests join the running batch at every decode step, and
finished ones leave. The GPU never waits for the slowest request.

**3. Prefill vs. decode**

| Phase | Work | Bound by | Metric |
|---|---|---|---|
| Prefill | Process the whole prompt at once | Compute | TTFT |
| Decode | One token at a time | Memory bandwidth | TPOT |

**Key flags**

| Flag | Meaning |
|---|---|
| `--gpu-memory-utilization 0.9` | Fraction of VRAM for weights + KV |
| `--max-model-len 8192` | Caps context. Smaller means more concurrent sequences |
| `--tensor-parallel-size N` | Split the model across N GPUs |
| `--enable-prefix-caching` | Reuse KV for shared system prompts |
| `--quantization fp8/awq` | Smaller weights, more room for KV |

## Architecture in depth

The overview diagram above shows the batching loop. This one adds the two layers around it: the **Kubernetes wrapper** (how traffic and model weights reach the pod) and the
**engine internals** (what vLLM does with a request inside the pod).

```mermaid
flowchart LR
  C[Client<br/>OpenAI SDK] -->|POST /v1/chat/completions| I[Ingress]
  I --> S[Service :8000]
  S --> P
  subgraph P[vLLM Pod]
    direction TB
    API[API server<br/>chat template + tokenize] --> SCH[Scheduler<br/>waiting / running queues]
    SCH <--> KV[KV cache manager<br/>block tables, prefix hashes]
    SCH --> EX[Model executor<br/>GPU forward pass]
    EX --> KV
    EX --> DT[Detokenizer<br/>SSE stream]
  end
  PVC[(PVC model-store<br/>weights)] -.loaded at startup.-> EX
  PR[Prometheus] -.scrapes /metrics.-> API
```

### Follow one request through the engine

1. **Ingress → Service → Pod.** The request arrives as plain HTTP. Kubernetes only routes it.
   Every component inside the pod belongs to vLLM.
2. **API server.** It applies the model's chat template to turn the messages into one string, then
   tokenizes it (say 1,800 tokens). A wrong template here is the classic "garbage output" bug.
3. **Scheduler: waiting queue.** The sequence waits until the **KV cache manager** can reserve
   blocks for it. Admission depends on free KV memory, not on free CPU or request count. This is why
   `vllm:num_requests_waiting` is the real saturation signal.
4. **Prefix cache lookup.** Blocks are hashed by their token content. If the first 1,500 tokens (the
   system prompt) match blocks already in memory, those blocks are **shared**, and only the remaining
   300 tokens are computed.
5. **Prefill step.** One forward pass computes KV for the new prompt tokens and writes it into
   16-token blocks. A **block table** maps the sequence's logical blocks to physical GPU blocks, so
   they don't need to be contiguous. That is PagedAttention, the same idea as OS virtual memory.
   This step dominates **TTFT**.
6. **Decode loop (continuous batching).** On every iteration the scheduler builds a batch from *all*
   running sequences: yours, the 40 others mid-generation, and any just admitted. Each sequence
   gets one token per iteration, and a new block is allocated each time a sequence fills 16 tokens.
   This step dominates **TPOT**.
7. **Memory pressure.** If blocks run out mid-generation, the scheduler **preempts** the newest
   sequences. It frees their blocks and recomputes them later. Users see this as latency spikes,
   and `vllm:gpu_cache_usage_perc` near 100% predicts it.
8. **Stream and free.** Tokens are detokenized and streamed back as Server-Sent Events. When the
   sequence finishes, its blocks return to the pool. Shared prefix blocks stay cached until they're
   evicted (LRU, least recently used first).

**The one idea to keep:** an inference server is a **memory scheduler**. GPU compute is rarely the
first limit. KV-cache blocks are, and every flag in the table above is a way to trade KV memory
against something else.

## Minimal hands-on

```yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: vllm, namespace: ai }
spec:
  replicas: 1
  selector: { matchLabels: { app: vllm } }
  template:
    metadata: { labels: { app: vllm } }
    spec:
      containers:
      - name: vllm
        image: vllm/vllm-openai:v0.6.3          # CPU: use vllm-cpu image or Ollama for laptops
        args: ["--model","/models/qwen","--max-model-len","4096","--enable-prefix-caching"]
        ports: [{ containerPort: 8000 }]
        readinessProbe: { httpGet: { path: /health, port: 8000 }, initialDelaySeconds: 30 }
        resources: { limits: { nvidia.com/gpu: 1, memory: 24Gi } }
        volumeMounts: [{ name: models, mountPath: /models }]
      volumes: [{ name: models, persistentVolumeClaim: { claimName: model-store } }]
```

> On a Mac without NVIDIA hardware, run Ollama or `llama.cpp` server in the same Deployment
> shape. The platform concepts are identical.

## Worked example

**Scenario:** Llama-3.1-8B BF16 on 1× L40S (48 GB). How many concurrent 4k-token chats fit?

1. Weights ≈ 16 GB. With `gpu-memory-utilization 0.9` the budget is 43 GB, which leaves ~27 GB for KV.
2. KV/token = 2 × 32 layers × 8 KV heads × 128 × 2 bytes = **128 KB**.
3. A 4k-token sequence needs 512 MB, and 27 GB ÷ 512 MB ≈ **~52 concurrent sequences**.
4. Switching to FP8 weights (8 GB) plus an FP8 KV cache (64 KB/token) gives ~35 GB for KV and **~140 sequences**.

This calculation is the single most important capacity-planning skill in LLM serving.

## Production deep dive
- **Probes:** Model load takes a while, so use a `startupProbe` with a long threshold. Otherwise the liveness probe kills the pod mid-load in a crash loop.
- **Metrics:** vLLM exposes `/metrics` with `vllm:num_requests_waiting`, `vllm:gpu_cache_usage_perc`, `vllm:time_to_first_token_seconds`. These drive autoscaling (Lab 29).
- **Graceful shutdown:** `preStop` sleep plus `terminationGracePeriodSeconds: 120` so in-flight generations finish.
- **Engine choice:** vLLM (breadth, community), SGLang (structured output, RadixAttention), TensorRT-LLM (peak NVIDIA performance, Lab 43), TGI. Standardize on one or two of them.
- **Platform wrappers:** KServe, the vLLM production-stack, and NVIDIA NIM add routing, scale-to-zero, and model CRDs.

## Failure modes
- `max-model-len` set to the model's 128k default leaves only ~2 concurrent sequences and causes queueing.
- `CUDA out of memory` at startup because another process holds VRAM, or utilization is set too high.
- Tokenizer/chat-template mismatch produces garbage output. Always pin `--chat-template`.

## FAANG deep-dive notes

**How big tech does it:** In-house engines use continuous batching, paged or radix KV caches, chunked
prefill, and disaggregated prefill/decode, all tuned per model family with automated benchmarks on
every release.

**Staff review questions:** What is the max concurrent sequence count on paper vs. measured? What
triggers preemption? Are TTFT and TPOT SLOs tracked separately?

**Typical system-design prompt:** *"Design an LLM inference service for a chat product: 200
requests/s at peak, p95 time-to-first-token under 1 s, using an 8B open model."*

**1. Clarify first. Strong candidates ask before drawing boxes:**
- Input and output token distributions (mean *and* p95). Output length drives cost and concurrency more than input length.
- Which SLO matters: TTFT (feels responsive) or TPOT (reading speed, about 30 tokens/s is enough for humans)?
- Context length cap, multi-tenancy, and data-residency constraints (they decide self-host vs. API).

**2. Back-of-envelope sizing (Little's law: concurrency = arrival rate × time in system):**
- Output 400 tokens at 30 tokens/s ≈ 13 s per request, so 200 req/s × 13 s ≈ **2,600 concurrent sequences**.
- Average context of 2k tokens × 128 KB/token = 256 MB of KV per sequence, so 2,600 × 256 MB ≈ **666 GB of KV cache**.
- About 27 GB of KV per L40S (from the worked example) gives ≈ 25 GPUs, or ≈ 33 with 30% headroom. FP8 weights + FP8 KV roughly halves that.
- Then check the other limit: run a load test (for example `vllm bench serve`) at the target batch size to confirm decode throughput meets 30 tokens/s per stream. Memory sizing tells you whether the sequences *fit*. Benchmarks tell you whether they're *fast enough*.
- Cost per 1M output tokens = GPU $/hour ÷ (tokens/s × 3600) × 10⁶. For example, $2/h at 3,000 tokens/s ≈ $0.19 (illustrative prices).

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Scale out | more replicas (data parallel) | tensor parallel inside a replica | replicas for throughput; TP only when the model doesn't fit or latency needs it (TP adds an all-reduce per layer) |
| Batch size | large: cheaper per token | small: lower TPOT | set by the TPOT SLO, then maximize batch under it |
| `max-model-len` | long: supports long chats | short: more concurrency | cap at p99 of real traffic, and route long-context requests to a separate pool |
| Long prompts | chunked prefill on the same GPUs | disaggregated prefill/decode pools (Lab 42) | chunked first; disaggregate at large scale |
| Weights | BF16: best quality | FP8/AWQ: about 2× capacity | quantize only after an eval shows no quality regression |

**4. Follow-up questions with crisp answers:**
- *Why does continuous batching beat static batching?* Sequences finish at different times. A static batch keeps the GPU waiting for its longest sequence, while iteration-level scheduling refills freed slots on every step.
- *Why is decode memory-bound?* Each step reads all the weights plus every sequence's KV to produce one token per sequence. That is very little arithmetic per byte read. Batching amortizes the weight reads, which is why continuous batching matters so much.
- *What happens when KV memory is full?* New requests queue and running ones get preempted. Detect it with `num_requests_waiting` and `gpu_cache_usage_perc`, and autoscale on those signals.
- *Why not autoscale on CPU or GPU utilization?* GPU utilization can show 100% at both healthy and saturated load. Queue depth and KV usage measure what users actually feel.
- *Cold starts?* Loading a 16 GB model takes minutes. Keep a warm buffer replica, pre-stage weights on local NVMe, use image or weight streaming, and scale ahead of the curve.
- *One user sends a 100k-token prompt and everyone's latency spikes. Why?* A huge prefill stalls the decode batch. Fixes: chunked prefill, a per-tenant token cap, or a separate long-context pool.
- *What fragmentation does PagedAttention remove?* Two kinds. Internal fragmentation comes from reserving memory for the maximum length up front. External fragmentation comes from needing contiguous chunks. With 16-token blocks, the only waste is the last, partly filled block of each sequence.
- *TTFT is fine, but TPOT gets worse at peak. Why?* The batch grows, and each decode step must read the KV of every sequence in it, so the per-step time rises with the total context in flight. Fixes: cap `--max-num-seqs` at the value that meets the TPOT SLO, and add replicas instead of letting the batch grow.
- *Does a shared prefix cache create multi-tenant risk?* Yes. A cache hit is measurably faster, so a tenant could probe whether another tenant's prompt prefix exists (a timing side channel). Salt cache keys per tenant (Lab 47).
- *Streaming through an Ingress: what breaks?* Proxy buffering holds back the Server-Sent Events, so users see the whole answer at once. Idle timeouts shorter than a long generation cut streams off. Turn buffering off and raise read timeouts for this route.
- *vLLM or Ollama?* Ollama and llama.cpp target one user on a laptop with GGUF quantization. vLLM targets many concurrent users, with continuous batching, prefix caching, and production metrics. Same API shape, different job.
- *How do you ship a new model version safely?* Run it as a separate Deployment with weights pre-staged, mirror traffic to it (shadow), compare evals and latency, then shift traffic in canary steps with automatic rollback (Lab 50).

**Debug this (common onsite question):** *"After Tuesday's release, p95 TTFT jumped from 0.4 s to 3 s. Error rate is 0, traffic is flat, and GPU utilization looks normal. What do you check?"*
1. `vllm:num_requests_waiting`: is it queueing (capacity) or slow per request (work per request)? Here the queue is flat, so the work per request rose.
2. Prefix-cache hit rate: it dropped from 85% to 0%. Every request now runs a full 6k-token prefill.
3. Diff the release: the new prompt template puts `Current time: {now}` on the first line, so every prompt has a unique prefix.
4. Fix: move dynamic content to the end of the prompt, add a CI check that the first N tokens of the template are stable, and alert on drops in hit rate.

The lesson interviewers want: **reason from metrics to mechanism**, rather than adding GPUs.

**5. What separates senior from staff answers:**
- Senior: correct engine choice, KV math, sensible autoscaling signals.
- Staff: sizes from SLOs and traffic distributions, states cost per million tokens, names failure domains (zone, node, GPU), and plans a capacity-test methodology plus a model-rollout path (Lab 50).

**Red flags:** sizing by model weights alone, ignoring output length, autoscaling on CPU, a single replica "because it has a GPU", and no load test.

## Checklist
- [ ] `/v1/models` returns your model
- [ ] You can compute concurrent capacity on paper
- [ ] Startup, readiness, and liveness probes are configured separately
