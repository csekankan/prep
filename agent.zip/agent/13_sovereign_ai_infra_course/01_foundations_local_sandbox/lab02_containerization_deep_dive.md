# Lab 2: Containerization Deep Dive — Docker, containerd, and cgroups (4:45)

## Why it matters
Every GPU OOM, CPU throttle, and "works on my machine" bug in AI infrastructure traces back to how
containers actually work. A container is **not a VM**. It is a Linux process with:
- **Namespaces**: what the process can *see* (PID, NET, MNT, UTS, IPC, USER)
- **cgroups**: what the process can *use* (CPU, memory, I/O, PIDs)
- **A layered filesystem** (overlayfs): what it boots from

## In plain words
A container is like a **hotel room**, not a separate house (a VM). Everyone shares the same building (the Linux kernel), but each room
has its own walls (**namespaces**: what you can see) and its own electricity meter with a breaker (**cgroups**: how much you can use).
Docker is the receptionist who books rooms, and containerd is the building manager who actually runs them.

## Core concepts

```mermaid
flowchart TB
  K[kubelet] -->|CRI gRPC| C[containerd]
  D[docker CLI] --> DD[dockerd] --> C
  C --> S[containerd-shim] --> R[runc / nvidia-container-runtime]
  R --> P[Process in namespaces + cgroups]
```

**How to read it:** Read top-down: both kubelet and the Docker CLI end up talking to containerd. The shim and runc (or the NVIDIA runtime) create the actual process, which is fenced by namespaces and cgroups.

- **Docker** is a developer UX. **containerd** is the runtime K8s uses (Docker was removed from the kubelet in 1.24).
- **OCI image**: a manifest plus a stack of tarball layers. Layer order matters for caching.
- **cgroups v2**: a unified hierarchy. `memory.max` and `cpu.max` are the files that enforce K8s limits.
- **GPU containers**: `nvidia-container-runtime` is a runc wrapper that injects `/dev/nvidia*` and driver libs at start.

## Architecture in depth

The overview shows the runtime chain. This view follows a **GPU inference image** from build to running process, including the parts
that make it secure and fast to start.

```mermaid
flowchart LR
  SRC[Dockerfile<br/>multi-stage] --> CI[CI build]
  CI --> SBOM[SBOM + vuln scan]
  SBOM --> SIGN[cosign sign]
  SIGN --> REG[(Harbor registry)]
  REG -->|pull layers| CTD[containerd on node]
  CTD --> SNAP[overlayfs snapshot<br/>read-only layers + writable top]
  CTD --> SHIM[containerd-shim]
  SHIM --> RT[nvidia-container-runtime → runc]
  RT --> NS[namespaces: pid, net, mnt, user]
  RT --> CG["cgroups v2: memory.max, cpu.max, pids.max"]
  RT --> DEV["/dev/nvidia* + libcuda injected"]
  NS & CG & DEV --> PROC[PID 1: vLLM server]
```

### Follow one image from build to running process
1. **Build.** A multi-stage Dockerfile compiles wheels in a builder stage and copies only the runtime artifacts into a slim CUDA *runtime* base. Compilers never ship.
2. **Scan and sign.** CI generates an SBOM (what's inside), scans it for CVEs, and signs the digest with cosign. The registry stores the image *and* its signature.
3. **Pull.** containerd fetches only the layers the node doesn't already have. Layer order matters: rarely changing layers (CUDA, Python deps) go first so they're cached.
4. **Snapshot.** overlayfs stacks the read-only layers and adds a thin writable layer. With `readOnlyRootFilesystem`, even that layer is blocked.
5. **Runtime hook.** The NVIDIA runtime wraps runc and injects the GPU device files and driver libraries from the host, so the image never contains the driver.
6. **Fences.** runc creates namespaces (what the process sees) and writes cgroup limits (what it can use). Kubernetes limits are literally these cgroup files.
7. **PID 1.** The server runs as PID 1, so it must handle SIGTERM for graceful shutdown. Otherwise Kubernetes kills it after the grace period and in-flight requests are lost.

**The one idea to keep:** a container is a process plus fences plus a filesystem. Every container problem is in one of those three.

## Minimal hands-on

```bash
docker run -d --name hog --memory=256m --cpus=0.5 python:3.12-slim \
  python -c "x=bytearray(512*1024*1024)"
docker inspect hog --format '{{.State.OOMKilled}}'   # true

# See the cgroup files the kernel enforces
docker run --rm --memory=256m alpine cat /sys/fs/cgroup/memory.max   # 268435456
```

AI image best practice (multi-stage, slim, non-root):

```dockerfile
FROM python:3.12-slim AS build
RUN pip wheel --wheel-dir /w vllm==0.6.3
FROM nvidia/cuda:12.4.1-runtime-ubuntu22.04
COPY --from=build /w /w
RUN pip install --no-index /w/* && useradd -u 10001 app
USER 10001
```

## Worked example

**Scenario:** An ML team's inference image is **18 GB**. Each new node pulls it in 6 minutes,
so autoscaling is useless during traffic spikes.

| Fix | Size after |
|---|---|
| Removed model weights from the image (mounted from a PVC instead, see Lab 7) | 18 → 9 GB |
| CUDA `runtime` base instead of `devel` | 9 → 5.5 GB |
| Multi-stage build, no compilers, `pip --no-cache-dir` | 5.5 → 4.2 GB |
| Pre-pulled on the node AMI + lazy pulling (stargz/SOCI) | Cold start 6 min → **40 s** |

The lesson: **keep code in the image and weights in storage.**

## Production deep dive
- **Supply chain:** Sign images with cosign, generate SBOMs (syft), scan them (trivy/grype), and enforce signatures at admission (Kyverno, Lab 70).
- **Private registry:** Harbor with replication. For air-gapped sites, mirror everything (Lab 94).
- **Rootless & read-only:** `runAsNonRoot`, `readOnlyRootFilesystem`, drop all capabilities. AI containers rarely need root.
- **Runtime classes:** `runc` for trusted workloads, `gVisor`/`Kata` for untrusted agent tools (Lab 77), `nvidia` for GPU.
- **Image pull at scale:** Spegel or Dragonfly P2P distribution stops 500 nodes from hammering the registry at once.

## FAANG deep-dive notes

- **How big tech does it:** Hermetic, reproducible builds (Bazel-style), base images owned by a central team, mandatory signing and SBOMs, and lazy image loading (e.g. SOCI/stargz-like systems) so 10 GB images start in seconds.
- **Staff review questions:** Why are the model weights in the image? What is the cold-start time on a fresh node? Who patches the base image, and how fast after a CVE?
- **Interview question:** *"What actually happens when you run `docker run`?"* Strong answers cover image pull and layers, overlayfs, namespace creation, cgroup limits, the runtime chain (containerd → shim → runc), and PID 1 signal handling.

**Typical system-design prompt:** *"Design the container build-and-deploy pipeline for 200 ML services that use GPUs."*

**1. Clarify first:**
- How many distinct base stacks (CUDA versions, frameworks)? Fewer is better.
- Security requirements: signed images only, SBOMs, CVE patch SLA.
- Cold-start target for autoscaling (e.g. new pod ready in < 2 minutes).

**2. Back-of-envelope sizing:**
- 200 services × 5 GB images × 10 builds/week ≈ 10 TB/week of registry writes without layer sharing. Shared base layers cut this by about 80%.
- Pull time: a 5 GB image at 1 GB/s effective ≈ 5 s from a local mirror, vs. ≈ 50 s from a remote registry at 100 MB/s. With 500 nodes pulling at once, the registry needs 500 GB/s, which is why P2P distribution exists.
- Rebuild on base CVE: 200 services × 8 min ≈ 27 build-hours, so you need parallel CI capacity.

**3. Trade-offs interviewers probe:**

| Decision | Option A | Option B | Rule of thumb |
|---|---|---|---|
| Base image | full CUDA devel | CUDA runtime / distroless | runtime for production, devel only in the builder stage |
| Weights | baked in image | mounted from storage | mount; images hold code, storage holds weights |
| Distribution | central registry | registry + P2P (Spegel/Dragonfly) | add P2P beyond ~100 nodes pulling the same image |
| Tags | mutable `latest` | immutable digest | deploy by digest, always |
| Runtime | runc | gVisor / Kata | runc for trusted code, sandboxes for untrusted (Lab 77) |

**4. Follow-up questions with crisp answers:**
- *Namespace vs. cgroup?* Namespaces limit what a process can see. cgroups limit how much it can use.
- *Why did Kubernetes drop Docker?* The kubelet talks CRI directly to containerd. Docker was an extra layer (dockershim) with no benefit to the kubelet.
- *Exit code 137?* SIGKILL, usually an OOMKill from the memory cgroup. Check `OOMKilled: true` and compare peak usage (often during model load) with the limit.
- *Why does a container ignore SIGTERM?* A shell-form entrypoint makes `sh` PID 1, and it doesn't forward signals. Use exec form or an init like `tini`.
- *How do GPUs get into a container without a driver in the image?* The NVIDIA runtime hook mounts device nodes and host driver libraries at start.
- *How do you make 500 nodes start fast?* Pre-pull base layers into the node image, use lazy pulling (stargz/SOCI), and P2P distribution.

**Debug this (common onsite question):** *"A new image version takes 7 minutes to start on fresh nodes, but 20 seconds on old nodes."*
1. Compare image layers between versions (`docker history`). A change early in the Dockerfile invalidated all later layers.
2. Fresh nodes have no cached layers, so they pull the full 12 GB.
3. Root cause: `COPY . .` was moved above `pip install`, and model files were accidentally included.
4. Fix: reorder layers, add a `.dockerignore`, mount weights from storage, and add an image-size check to CI.

The lesson: **layer order and image contents are performance decisions.**

**5. What separates senior from staff answers:**
- Senior: lean multi-stage images, digests, and signal handling.
- Staff: a fleet-level supply-chain design (signing, SBOM, admission verification), distribution at scale, base-image ownership, and CVE response SLAs.

**Red flags:** `latest` tags in production, weights inside images, root containers, no signing, no idea what PID 1 is.

## Failure modes
- `latest` tags let a silent CUDA upgrade break the driver match.
- Exit code 137 with OOMKilled. The limit was lower than the peak during model load (load spikes can reach ~2× steady-state).
- Huge layers invalidated on every build because `COPY . .` comes before `pip install`.

## Checklist
- [ ] You can explain namespace vs. cgroup in one sentence each
- [ ] Your image is < 6 GB with weights excluded
- [ ] The image is signed and scanned in CI
