"""
03 — AGENTIC / CORRECTIVE RAG with LangGraph
=============================================

CONCEPT DEEP DIVE
-----------------
Classic RAG is a fixed pipeline: always retrieve once, always answer. AGENTIC RAG puts
decisions in the loop:

  - Should I retrieve at all? (greetings, math → no)
  - Are the retrieved docs actually relevant? (GRADE them)
  - If not, REWRITE the query and try again (or fall back to web search)
  - Is my answer grounded in the docs? (HALLUCINATION CHECK) If not, regenerate.

This combines ideas from two papers:
  - CRAG (Corrective RAG): grade retrieved docs; if poor, correct via rewrite/web search.
  - Self-RAG: model reflects on whether its generation is supported by the evidence.

Graph:

  START → route_question ──(no retrieval needed)──────────────────────────► direct_answer → END
                │
                ▼
            retrieve → grade_docs ──(relevant)──► generate → check_grounded ──(grounded)──► END
                ▲           │                        ▲             │
                │      (irrelevant)                  └──(not grounded, retries left)
                └── rewrite_query ◄──┘
                   (bounded by MAX_RETRIES; then answer "I don't know")

Trade-off: 2–4x more LLM calls than naive RAG. Worth it when wrong answers are costly.
Use cheap/small models for the graders — they're simple yes/no classification tasks.
"""

from typing import Literal, TypedDict

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_core.documents import Document
from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel, Field

load_dotenv()
MAX_RETRIES = 2

gen_llm = init_chat_model("openai:gpt-4o-mini", temperature=0)
grader_llm = init_chat_model("openai:gpt-4o-mini", temperature=0)


def fake_retriever(query: str) -> list[Document]:
    """Stand-in for a vector store retriever (see 01_rag_from_scratch.py)."""
    return [Document(page_content="Refunds are allowed within 30 days of delivery.", metadata={"source": "policy.md"})]


class RAGState(TypedDict):
    question: str
    query: str               # may differ from question after rewriting
    docs: list[Document]
    answer: str
    retries: int


# ---------------------------------------------------------------- graders (structured yes/no)
class Route(BaseModel):
    needs_retrieval: bool = Field(description="True if answering requires company documents.")


class DocGrade(BaseModel):
    relevant: bool = Field(description="Does the document contain information useful for the question?")


class Grounded(BaseModel):
    grounded: bool = Field(description="Is every claim in the answer supported by the documents?")


# ---------------------------------------------------------------- nodes
def route_question(state: RAGState) -> Literal["retrieve", "direct_answer"]:
    r = grader_llm.with_structured_output(Route).invoke(
        f"Question: {state['question']}\nDoes this need our company knowledge base?"
    )
    return "retrieve" if r.needs_retrieval else "direct_answer"


def direct_answer(state: RAGState) -> dict:
    return {"answer": gen_llm.invoke(state["question"]).content}


def retrieve(state: RAGState) -> dict:
    return {"docs": fake_retriever(state.get("query") or state["question"])}


def grade_docs(state: RAGState) -> dict:
    # Filter step: drop irrelevant docs BEFORE generation. Less noise = fewer hallucinations.
    grader = grader_llm.with_structured_output(DocGrade)
    kept = [
        d for d in state["docs"]
        if grader.invoke(f"Question: {state['question']}\nDocument: {d.page_content}").relevant
    ]
    return {"docs": kept}


def after_grading(state: RAGState) -> str:
    if state["docs"]:
        return "generate"
    if state["retries"] >= MAX_RETRIES:
        return "give_up"
    return "rewrite_query"


def rewrite_query(state: RAGState) -> dict:
    new_q = gen_llm.invoke(
        f"The search query '{state.get('query') or state['question']}' found nothing relevant. "
        "Write a better search query (synonyms, more specific terms). Output only the query."
    ).content
    return {"query": new_q, "retries": state["retries"] + 1}


def generate(state: RAGState) -> dict:
    context = "\n".join(f"[{d.metadata['source']}] {d.page_content}" for d in state["docs"])
    prompt = f"Answer using only this context, cite sources.\n<context>{context}</context>\nQ: {state['question']}"
    return {"answer": gen_llm.invoke(prompt).content}


def check_grounded(state: RAGState) -> str:
    context = "\n".join(d.page_content for d in state["docs"])
    g = grader_llm.with_structured_output(Grounded).invoke(f"Documents:\n{context}\n\nAnswer:\n{state['answer']}")
    if g.grounded:
        return END
    return "give_up" if state["retries"] >= MAX_RETRIES else "generate_retry"


def generate_retry(state: RAGState) -> dict:
    return {"retries": state["retries"] + 1}


def give_up(state: RAGState) -> dict:
    # A confident refusal is a FEATURE. Track the refusal rate as a metric:
    # too high → retrieval is broken; too low → maybe hallucinating.
    return {"answer": "I don't know based on the available documents."}


builder = StateGraph(RAGState)
for name, fn in [
    ("direct_answer", direct_answer), ("retrieve", retrieve), ("grade_docs", grade_docs),
    ("rewrite_query", rewrite_query), ("generate", generate),
    ("generate_retry", generate_retry), ("give_up", give_up),
]:
    builder.add_node(name, fn)

builder.add_conditional_edges(START, route_question, ["retrieve", "direct_answer"])
builder.add_edge("retrieve", "grade_docs")
builder.add_conditional_edges("grade_docs", after_grading, ["generate", "rewrite_query", "give_up"])
builder.add_edge("rewrite_query", "retrieve")
builder.add_conditional_edges("generate", check_grounded, [END, "generate_retry", "give_up"])
builder.add_edge("generate_retry", "generate")
builder.add_edge("direct_answer", END)
builder.add_edge("give_up", END)
graph = builder.compile()

if __name__ == "__main__":
    print(graph.invoke({"question": "How long do I have to return an item?", "retries": 0, "query": ""})["answer"])
