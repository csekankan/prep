# Vector Databases: from local demo to real server

**Quick recap of what a vector database is.** RAG finds relevant text by *meaning*, not by exact
keywords. To do that, each chunk of text is turned into an **embedding**: a list of numbers (for example
1,536 of them) produced by an embedding model, where texts with similar meanings get similar lists. A
**vector database** stores these lists and answers one question very fast: "which stored vectors are
closest to this query vector?" That's how "How do I get my money back?" finds a chunk titled "Refund
policy" even though no words match.

`01_rag_from_scratch.py` used numpy and a local Chroma database. Everything ran in one Python process,
with the data in RAM or in a folder on your laptop. That's perfect for learning, but production needs a
**server**: a separate database that many copies of your app share, that keeps data safely on disk,
is backed up, is secured with passwords and encryption, and can grow.

*Example of why local breaks:* you deploy your RAG API as 4 copies (**replicas**) behind a load balancer
so it can handle more traffic. With a local Chroma folder, each replica has its own separate copy of the
data. Re-index the documents on one replica and the other three keep serving stale answers. With a vector
database server, all four query the same data.

## Local vs server: what changes

| Concern | Local (Chroma folder / in-memory) | Server (pgvector / Qdrant) |
|---|---|---|
| Who can read it | one process | every app replica, ingestion workers, eval jobs |
| Persistence | a folder on one disk | managed storage, backups, point-in-time restore |
| Connection | a function call | a network connection: **URL, credentials, TLS, timeouts, pooling** |
| Ingestion | at app startup | a **separate pipeline** (a batch job, or triggered by events) |
| Multi-tenancy | ignored | a **tenant filter on every query**, plus an index on that field |
| Scale | the RAM of one machine | replicas, sharding, quantization |
| Schema changes | delete the folder | migrations, re-embedding into versioned collections |

Terms in this table:
- **Point-in-time restore**: the ability to roll the database back to its exact state at any moment, for
  example "10:42 yesterday, before the bad import".
- **TLS**: the encryption used by HTTPS. It stops anyone on the network from reading your queries and data.
- **Connection pooling**: opening a network connection to a database is slow (tens of milliseconds). A
  **pool** keeps a few connections open and lends them out to requests, instead of opening a new one each
  time.
- **Ingestion pipeline**: the process that reads documents, splits them into chunks, embeds them, and
  writes them to the database. In production it runs separately from the app (for example nightly, or
  whenever a document changes), so loading 100,000 documents doesn't slow down users.
- **Multi-tenancy**: one system serving many customers (**tenants**). Every chunk is tagged with its
  `tenant_id`, and every search must filter on it, or customer A could retrieve customer B's documents.
- **Sharding**: splitting the data across several machines when it no longer fits on one.
- **Quantization**: storing each number in a vector with fewer bits (for example 1 byte instead of 4). This
  cuts memory by about 4× for a small loss in search accuracy.
- **Versioned collections**: if you switch embedding models, old and new vectors aren't comparable, so you
  embed everything again into a *new* collection and switch over once it's ready (see checklist item 7).

## The two servers in this folder

| | **pgvector** (`04_pgvector_server.py`) | **Qdrant** (`05_qdrant_server.py`) |
|---|---|---|
| What | a Postgres extension adding a `vector` column type and ANN indexes | a purpose-built vector database (written in Rust) |
| Pick when | you already run Postgres; you want vectors, relational data, and transactions in one database; you need SQL joins with business tables | vector search is core to the product; large scale (10M+ vectors); you want rich filtering, quantization, and native hybrid search (dense + sparse) |
| Query language | SQL (`ORDER BY embedding <=> $1`) | client SDK, REST, or gRPC |
| Hybrid search | vector search plus Postgres full-text search (`tsvector`), combined in SQL | dense and sparse (BM25) vectors combined on the server (RRF) |
| Filtering | normal `WHERE` clauses | payload filters, backed by payload indexes |
| Managed options | AWS RDS / Aurora PostgreSQL, Supabase, Neon, Azure, GCP Cloud SQL | Qdrant Cloud, self-hosted on Kubernetes (Helm), AWS Marketplace |

Terms in this table:
- **ANN index**: **approximate nearest neighbor**. Comparing a query with every stored vector is exact but
  slow at millions of vectors. An ANN index finds *almost* the closest vectors (typically 95–99% the same
  results) in milliseconds.
- **`ORDER BY embedding <=> $1`**: in pgvector, `<=>` is the **cosine distance** operator. Cosine distance
  measures the angle between two vectors: 0 means the same direction (same meaning), and larger means less
  similar. "Order by distance to the query vector" returns the closest chunks first. `$1` is the query
  vector passed as a parameter.
- **Transactions**: a group of database changes that either all succeed or all fail. With pgvector you can
  update a product row and its embedding together, so they can never get out of sync.
- **SDK, REST, gRPC**: three ways to talk to Qdrant. An **SDK** is a client library for your language,
  **REST** is plain HTTP with JSON, and **gRPC** is a faster binary protocol.
- **Dense vs sparse vectors**: a **dense** vector is the usual embedding (every one of its 1,536 numbers
  matters) and captures meaning. A **sparse** vector has one slot per vocabulary word and is mostly zeros.
  It captures exact keywords. **BM25** is the classic keyword-scoring formula used by search engines; it
  rewards query words that appear often in a chunk and are rare across the whole corpus.
- **Hybrid search**: running both kinds of search and combining the results. Meaning-based search finds
  "money back" for "refund". Keyword search finds exact terms such as an error code `E-4021` or a product
  name that embeddings handle poorly.
- **RRF (Reciprocal Rank Fusion)**: a simple way to merge two ranked lists. Each document gets
  \(\sum 1/(k + \text{rank})\) across the lists, with \(k\) usually 60. A document ranked 1st in one list
  and 3rd in the other scores \(1/61 + 1/63 \approx 0.0323\), which beats one ranked 2nd in only one list
  (\(1/62 \approx 0.0161\)). Documents that do well in *both* searches rise to the top.
- **Payload**: Qdrant's name for the metadata stored with each vector (for example `tenant_id`, `source`,
  `created_at`). **Payload filters** are like a SQL `WHERE` clause, and a **payload index** makes them fast.
- **Helm**: a package manager for Kubernetes that installs complex software from a single chart.

Others you'll meet:
- **Pinecone**: fully managed and serverless (you never manage machines).
- **Weaviate** and **Milvus / Zilliz**: open-source vector databases (Zilliz is the managed Milvus).
- **OpenSearch** (k-NN plugin): the default store behind AWS Bedrock Knowledge Bases.
- **Elasticsearch** and **MongoDB Atlas Vector Search**: vector search added to existing popular databases.
- **S3 Vectors**: vector storage built into Amazon S3, cheap for large collections that are queried rarely.

## Run both servers locally (same behavior as production, minus scale)

```bash
docker compose -f 04_rag/docker-compose.vectordb.yml up -d
export PG_URL="postgresql://rag:rag_password@localhost:5432/rag"
export QDRANT_URL="http://localhost:6333"
export QDRANT_API_KEY="local-dev-key"
```

`docker compose up -d` starts both databases as containers in the background, and the `export` lines tell
the example scripts where to connect.

Production differs only in configuration: the URL points to a managed database (RDS/Aurora or Qdrant
Cloud), TLS is required, and the credentials come from a **secret manager** (AWS Secrets Manager or
HashiCorp Vault, services that store passwords securely and hand them to your app at runtime), never from
the code.

## Production checklist (both)

1. **Connection management.** Use a connection pool (`psycopg_pool` for Postgres), or create one Qdrant
   client per process and reuse it. Set timeouts so a slow database fails fast instead of hanging every
   request. *Example:* without a pool, 200 concurrent requests open 200 Postgres connections, and Postgres
   starts refusing connections at its limit (100 by default).
2. **Secrets.** The URL, password, and API key arrive as environment variables that the platform injects
   from a secret manager. They are never committed to git.
3. **TLS.** Use `sslmode=require` in the Postgres connection string, and `https://` for Qdrant Cloud, so
   traffic is encrypted.
4. **Indexes.** Create an **HNSW** index on the vector column. HNSW (Hierarchical Navigable Small World) is
   the most common ANN index: a layered graph where search hops quickly toward the closest vectors. Also
   index every field you filter on, such as `tenant_id` (a **B-tree** index in Postgres, a payload index in
   Qdrant). Without that, a tenant filter scans every row.
5. **Idempotent upserts.** An **upsert** means "insert, or update if it already exists". **Idempotent** means
   running it twice gives the same result as running it once. Give each chunk a **deterministic ID**, for
   example a hash of its source file and content. Then re-running ingestion after a crash overwrites the
   same chunks instead of creating duplicates that would show up twice in search results.
6. **Tenant isolation.** Filter by tenant on *every* query, and enforce it in the code layer that talks to
   the database (the **repository layer**), so no developer can forget it. Never rely on telling the LLM
   "only use tenant A's documents": a prompt is not a security boundary.
7. **Versioned collections or tables.** Name them after the embedding model and a version, for example
   `chunks_te3small_v2`. Changing the embedding model means re-embedding everything into a *new* collection,
   testing it, and then switching the app over. Vectors from different models live in different "spaces"
   and can't be compared.
8. **Delete stale chunks.** When a document changes, delete all of its old chunks (by `source`) before
   inserting the new ones. Otherwise the old version of the policy keeps showing up in answers.
9. **Monitor.** Track query latency at **p95** (the time 95% of queries beat), **recall** on your eval set
   (does search still find the right chunks?), index size, and memory use.
10. **Backups.** Take regular RDS snapshots or Qdrant snapshots and copy them to S3, and test restoring
    them. A backup you've never restored is only a hope.
