# Vector Databases: from local demo to real server

`01_rag_from_scratch.py` used numpy and local Chroma — everything in one process, data in RAM or
a local folder. Production needs a **server**: shared by many app replicas, persistent, backed up,
secured, and scalable.

## Local vs server — what changes

| Concern | Local (Chroma folder / in-memory) | Server (pgvector / Qdrant) |
|---|---|---|
| Who can read it | one process | every app replica, ingestion workers, eval jobs |
| Persistence | a folder on one disk | managed storage, backups, point-in-time restore |
| Connection | function call | network: **URL + credentials + TLS + timeouts + pooling** |
| Ingestion | at app startup | **separate pipeline** (batch job / event-driven) |
| Multi-tenancy | ignored | **tenant filter on every query** + payload/column index |
| Scale | RAM of one machine | replicas, sharding, quantization |
| Schema changes | delete folder | migrations, re-embedding with versioned collections |

## The two servers in this folder

| | **pgvector** (`04_pgvector_server.py`) | **Qdrant** (`05_qdrant_server.py`) |
|---|---|---|
| What | Postgres extension adding a `vector` type + ANN indexes | purpose-built vector database (Rust) |
| Pick when | you already run Postgres; want vectors + relational data + transactions in one DB; SQL joins with business tables | vector search is core; large scale (10M+ vectors); want rich filtering, quantization, native hybrid (dense + sparse) |
| Query language | SQL (`ORDER BY embedding <=> $1`) | client SDK / REST / gRPC |
| Hybrid search | vector + Postgres full-text (`tsvector`) fused in SQL | dense + sparse (BM25) vectors fused server-side (RRF) |
| Filtering | normal `WHERE` clauses | payload filters with payload indexes |
| Managed options | AWS RDS / Aurora PostgreSQL, Supabase, Neon, Azure, GCP Cloud SQL | Qdrant Cloud, self-host on Kubernetes (Helm), AWS Marketplace |

Others you'll meet: Pinecone (fully managed, serverless), Weaviate, Milvus/Zilliz, OpenSearch
(k-NN; used by Bedrock Knowledge Bases), Elasticsearch, MongoDB Atlas Vector Search, S3 Vectors.

## Run both servers locally (same behavior as production, minus scale)

```bash
docker compose -f 04_rag/docker-compose.vectordb.yml up -d
export PG_URL="postgresql://rag:rag_password@localhost:5432/rag"
export QDRANT_URL="http://localhost:6333"
export QDRANT_API_KEY="local-dev-key"
```

Production differs only in configuration: the URL points to RDS/Aurora or Qdrant Cloud, TLS is
required, and credentials come from a secret manager (AWS Secrets Manager, Vault), never from code.

## Production checklist (both)

1. **Connection management** — pool connections (psycopg_pool) / reuse one client per process; set timeouts.
2. **Secrets** — URL/password/API key from env injected by the platform from a secret manager.
3. **TLS** — `sslmode=require` (Postgres), `https://` (Qdrant Cloud).
4. **Index** — HNSW on vectors; B-tree / payload index on `tenant_id` and other filter fields.
5. **Idempotent upserts** — deterministic chunk IDs (hash of source + content).
6. **Tenant isolation** — filter by tenant on *every* query; enforce in the repository layer, not in prompts.
7. **Versioned collections/tables** — `chunks_te3small_v2`; changing embedding model = re-embed into a new one, then switch.
8. **Delete stale chunks** — when a doc changes, delete its old chunks by `source` before inserting new ones.
9. **Monitor** — query latency p95, recall on eval set, index size, memory.
10. **Backups** — RDS snapshots / Qdrant snapshots to S3.
