"""
01 — RAG FROM SCRATCH: Retrieval-Augmented Generation
======================================================

CONCEPT DEEP DIVE: WHY RAG?
---------------------------
LLMs don't know your private data, their knowledge has a cutoff date, and they hallucinate
when asked about things they don't know. RAG fixes this by RETRIEVING relevant text at
query time and putting it in the prompt, so the model answers FROM EVIDENCE.

RAG vs fine-tuning:
  - RAG          → teaches the model FACTS (knowledge). Updatable instantly, citable, cheap.
  - Fine-tuning  → teaches the model BEHAVIOR (style, format, domain jargon). Not for facts.

THE TWO PIPELINES
-----------------
  INDEXING (offline, batch):
     load docs → clean → CHUNK → EMBED each chunk → store vectors + text + metadata

  QUERY (online, per request):
     user question → EMBED → similarity search top-k → (rerank) → build prompt → LLM → answer + citations

KEY CONCEPTS
------------
EMBEDDING: a model maps text → a vector (e.g. 1536 floats) such that semantically similar
  texts are close. "refund policy" ≈ "how do I get my money back" even with no shared words.

SIMILARITY: usually cosine similarity = dot(a,b) / (|a||b|). 1 = same direction, 0 = unrelated.

CHUNKING (the most underrated knob):
  - Too large → retrieved chunk is mostly irrelevant noise; fewer chunks fit in context.
  - Too small → chunk lacks context ("it costs $5" — what does?).
  - Typical start: 500–1000 tokens with 10–20% OVERLAP so sentences at boundaries survive.
  - Better: split on structure (headings, paragraphs) — RecursiveCharacterTextSplitter
    tries "\n\n", then "\n", then " " — or semantic chunking.
  - Attach METADATA (source, page, section, date, access level) → enables filtering & citations.

VECTOR DATABASE: stores vectors and does fast Approximate Nearest Neighbor (ANN) search
  (HNSW index). Options: Chroma (local/dev), pgvector (if you already run Postgres),
  Pinecone/Weaviate/Qdrant (managed/scale).

TOP-K: how many chunks to retrieve. Higher k → better recall, more noise and cost.

This file implements the core math by hand (numpy) so nothing is hidden, then shows the
same thing with LangChain + Chroma.
"""

import numpy as np
from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

load_dotenv()

RAW_DOCS = [
    Document(
        page_content=(
            "# Refund Policy\nCustomers can request a full refund within 30 days of delivery. "
            "Items must be unused and in original packaging. Digital goods are non-refundable.\n\n"
            "# Shipping\nStandard shipping takes 3-5 business days. Express shipping takes 1-2 days "
            "and costs $15. Free standard shipping on orders above $50."
        ),
        metadata={"source": "policies.md", "updated": "2026-09-01"},
    ),
    Document(
        page_content="# Warranty\nElectronics carry a 1-year limited warranty covering manufacturing defects.",
        metadata={"source": "warranty.md", "updated": "2026-05-10"},
    ),
]

embedder = OpenAIEmbeddings(model="text-embedding-3-small")


# ============================ INDEXING ============================
def chunk(docs: list[Document]) -> list[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=200,     # tiny for the demo; ~800-1000 chars is a common real default
        chunk_overlap=30,   # overlap preserves sentences cut at boundaries
        separators=["\n# ", "\n\n", "\n", ". ", " "],  # prefer splitting at headings
    )
    # split_documents copies each parent's metadata onto its chunks → citations still work.
    return splitter.split_documents(docs)


def build_index(chunks: list[Document]) -> np.ndarray:
    # Batch embedding: one API call for many texts (cheaper and faster than one-by-one).
    vectors = embedder.embed_documents([c.page_content for c in chunks])
    matrix = np.array(vectors)
    # Normalize once so cosine similarity becomes a plain dot product at query time.
    return matrix / np.linalg.norm(matrix, axis=1, keepdims=True)


# ============================ RETRIEVAL ============================
def retrieve(question: str, chunks: list[Document], index: np.ndarray, k: int = 2) -> list[tuple[Document, float]]:
    q = np.array(embedder.embed_query(question))
    q = q / np.linalg.norm(q)
    scores = index @ q                    # cosine similarity against every chunk (brute force)
    top = np.argsort(scores)[::-1][:k]    # a vector DB does this with an ANN index instead
    return [(chunks[i], float(scores[i])) for i in top]


# ============================ GENERATION ============================
RAG_PROMPT = """Answer the question using ONLY the context below.
If the context does not contain the answer, reply exactly: "I don't know based on the available documents."
Cite sources in square brackets like [policies.md].

<context>
{context}
</context>

Question: {question}"""
# Why each line matters:
# - "ONLY the context"        → grounding; reduces hallucination
# - exact refusal string      → measurable (evals can check it) and safe
# - citations                 → user trust + lets evals verify faithfulness
# - <context> delimiters      → separates retrieved (untrusted!) text from instructions


def answer(question: str, chunks: list[Document], index: np.ndarray) -> str:
    hits = retrieve(question, chunks, index)
    # Relevance threshold: if nothing is similar enough, don't even call the LLM.
    # Saves cost and prevents answers built on irrelevant context. Tune on your eval set.
    if not hits or hits[0][1] < 0.25:
        return "I don't know based on the available documents."
    context = "\n\n".join(f"[{d.metadata['source']}]\n{d.page_content}" for d, _ in hits)
    llm = init_chat_model("openai:gpt-4o-mini", temperature=0)
    return llm.invoke(RAG_PROMPT.format(context=context, question=question)).content


# ============================ SAME THING, WITH LANGCHAIN + CHROMA ============================
def langchain_version(question: str) -> str:
    from langchain_chroma import Chroma  # pip install langchain-chroma

    store = Chroma.from_documents(chunk(RAW_DOCS), embedder, collection_name="demo")
    # as_retriever turns the store into a Runnable; search_kwargs can add metadata filters,
    # e.g. {"k": 4, "filter": {"source": "policies.md"}} — use filters for multi-tenant ACLs!
    retriever = store.as_retriever(search_kwargs={"k": 2})
    docs = retriever.invoke(question)
    context = "\n\n".join(f"[{d.metadata['source']}]\n{d.page_content}" for d in docs)
    llm = init_chat_model("openai:gpt-4o-mini", temperature=0)
    return llm.invoke(RAG_PROMPT.format(context=context, question=question)).content


if __name__ == "__main__":
    chunks = chunk(RAW_DOCS)
    index = build_index(chunks)
    print(answer("Can I return headphones after 3 weeks?", chunks, index))
    print(answer("What is the CEO's name?", chunks, index))  # should refuse
