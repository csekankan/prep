"""
02 — ADVANCED RAG: fixing the ways naive RAG fails
===================================================

CONCEPT DEEP DIVE: WHERE NAIVE RAG BREAKS
-----------------------------------------
Failure                                  → Technique (implemented below)
---------------------------------------------------------------------------------------
Exact terms (SKUs, error codes, names)   → HYBRID SEARCH: BM25 keyword + vector, fused with RRF
 missed by embeddings
Top-k has right doc but ranked low,      → RERANKING with a cross-encoder / LLM
 or lots of noise
User query is vague/conversational       → QUERY REWRITING (standalone question)
 ("what about the other one?")
One phrasing misses relevant docs        → MULTI-QUERY: generate N paraphrases, union results
Question and answer look different       → HyDE: embed a hypothetical ANSWER, search with it
Small chunks lack context                → PARENT-DOCUMENT / small-to-big: search small chunks,
                                           return their larger parent section
Stale or wrong-tenant docs               → METADATA FILTERING (date, tenant_id, ACL)

BI-ENCODER vs CROSS-ENCODER (why reranking works)
  Bi-encoder (embeddings): query and doc embedded SEPARATELY → fast, can precompute docs,
    but compresses meaning into one vector.
  Cross-encoder (reranker): reads query AND doc TOGETHER → much more accurate relevance,
    but too slow to run over millions of docs.
  → Standard production recipe: retrieve top-50 cheaply (hybrid) → rerank → keep top-5.

RECIPROCAL RANK FUSION (RRF)
  Combine multiple ranked lists without comparing incompatible scores:
     score(doc) = Σ over lists  1 / (k + rank_in_list),   k ≈ 60
  Docs ranked well by BOTH retrievers float to the top.

Measure every technique on your eval set (contextual precision/recall, see 07_evaluation).
Each adds latency and cost; keep only what moves the metric.
"""

from collections import defaultdict

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model
from langchain_core.documents import Document
from pydantic import BaseModel, Field
from rank_bm25 import BM25Okapi

load_dotenv()
llm = init_chat_model("openai:gpt-4o-mini", temperature=0)


# ---------------------------------------------------------------- hybrid search
class HybridRetriever:
    """BM25 (lexical) + vector (semantic), fused with RRF."""

    def __init__(self, docs: list[Document], vector_store):
        self.docs = docs
        self.vector_store = vector_store
        # Naive whitespace tokenization; use a proper tokenizer/stemmer in production.
        self.bm25 = BM25Okapi([d.page_content.lower().split() for d in docs])

    def _bm25(self, query: str, k: int) -> list[Document]:
        scores = self.bm25.get_scores(query.lower().split())
        ranked = sorted(range(len(self.docs)), key=lambda i: scores[i], reverse=True)
        return [self.docs[i] for i in ranked[:k]]

    def invoke(self, query: str, k: int = 20) -> list[Document]:
        lists = [self._bm25(query, k), self.vector_store.similarity_search(query, k=k)]
        fused: dict[str, float] = defaultdict(float)
        by_key: dict[str, Document] = {}
        for ranked in lists:
            for rank, doc in enumerate(ranked):
                key = doc.page_content  # use a stable chunk id in production
                fused[key] += 1 / (60 + rank + 1)
                by_key[key] = doc
        return [by_key[key] for key, _ in sorted(fused.items(), key=lambda x: x[1], reverse=True)]


# ---------------------------------------------------------------- reranking
class RelevanceScores(BaseModel):
    scores: list[int] = Field(description="Relevance 0-10 for each passage, in order.")


def llm_rerank(query: str, docs: list[Document], top_n: int = 4) -> list[Document]:
    """LLM-as-reranker. In production prefer a dedicated reranker (Cohere Rerank,
    bge-reranker, Voyage) — faster and cheaper, same idea: score (query, doc) jointly."""
    passages = "\n\n".join(f"[{i}] {d.page_content[:500]}" for i, d in enumerate(docs))
    result = llm.with_structured_output(RelevanceScores).invoke(
        f"Query: {query}\n\nScore each passage's relevance to the query.\n\n{passages}"
    )
    ranked = sorted(zip(docs, result.scores), key=lambda x: x[1], reverse=True)
    return [d for d, _ in ranked[:top_n]]


# ---------------------------------------------------------------- query transformations
def rewrite_standalone(question: str, chat_history: list[str]) -> str:
    """Conversational RAG must condense history into a self-contained query, otherwise
    'what about express?' retrieves garbage."""
    if not chat_history:
        return question
    return llm.invoke(
        "Rewrite the last user question as a standalone search query. Output only the query.\n"
        f"History: {chat_history}\nQuestion: {question}"
    ).content


class Queries(BaseModel):
    queries: list[str] = Field(description="3 diverse rephrasings of the question.")


def multi_query(question: str) -> list[str]:
    return [question, *llm.with_structured_output(Queries).invoke(question).queries]


def hyde(question: str) -> str:
    """HyDE: documents look like answers, not questions. Generate a fake answer and search
    with ITS embedding. The fake answer may be wrong — that's fine, we only use it to search."""
    return llm.invoke(f"Write a short passage that would answer: {question}").content


# ---------------------------------------------------------------- full advanced pipeline
def advanced_retrieve(question: str, history: list[str], retriever: HybridRetriever) -> list[Document]:
    """Where BM25 and the LLM meet. They never run in the same step — they take turns:

      "what about E-4012?"  + history
              │
      ① LLM   rewrite_standalone → "How do I fix error E-4012 on the X200 router?"
              │
      ② LLM   multi_query        → [original, paraphrase 1, paraphrase 2, paraphrase 3]
              │
              │  for EACH query:
      ③ BM25 + VECTOR (HybridRetriever.invoke)        ← no LLM here, just math
              │     BM25:   exact words  ("E-4012", "X200")      → ranked list A
              │     vector: meaning      ("fix", "troubleshoot") → ranked list B
              │     RRF:    merge A + B into one ranked list
              │
      ④ dedupe all candidates from all queries (~20–40 chunks)
              │
      ⑤ LLM   llm_rerank → reads query + each chunk together, keeps the best 4
              │
           top-4 chunks → ⑥ LLM writes the answer from them (advanced_answer below)

    Roles: the LLM improves the QUERY (before) and judges RELEVANCE (after); BM25 + vectors do the
    cheap, fast SEARCH in the middle. LLM calls per request: 1 rewrite + 1 multi-query + 1 rerank = 3.
    `hyde()` is an alternative to step ②: search with a fake answer instead of paraphrases.
    """
    standalone = rewrite_standalone(question, history)        # ① LLM
    candidates: dict[str, Document] = {}
    for q in multi_query(standalone):                          # ② LLM
        for d in retriever.invoke(q, k=10):                    # ③ BM25 + vector + RRF
            candidates[d.page_content] = d                     # ④ dedupe across queries
    return llm_rerank(standalone, list(candidates.values()), top_n=4)   # ⑤ LLM


# ---------------------------------------------------------------- generation (step ⑥)
ANSWER_PROMPT = """Answer the question using ONLY the context below.
If the context does not contain the answer, reply exactly: "I don't know based on the available documents."
Cite sources like [1], [2] using the numbers in the context.

<context>
{context}
</context>

Conversation so far:
{history}

Question: {question}"""


def advanced_answer(question: str, history: list[str], retriever: HybridRetriever) -> dict:
    """Steps ①–⑤ find the best chunks; step ⑥ writes the answer from them.

    Two details worth noticing:
    - The prompt gets the ORIGINAL question + history (what the user actually said, so the reply
      sounds natural), while retrieval used the REWRITTEN query (better for search).
    - The answer is generated by a separate LLM call AFTER retrieval is finished — generation never
      sees chunks that the reranker dropped, which keeps the context short and focused.
    """
    top_docs = advanced_retrieve(question, history, retriever)                        # ①–⑤
    if not top_docs:
        return {"answer": "I don't know based on the available documents.", "sources": []}

    context = "\n\n".join(f"[{i}] {d.page_content}" for i, d in enumerate(top_docs, start=1))
    answer = llm.invoke(                                                               # ⑥ LLM
        ANSWER_PROMPT.format(context=context, history="\n".join(history) or "(none)", question=question)
    ).content
    # Return sources alongside the answer so the UI can show citations and evals can check faithfulness.
    return {"answer": answer, "sources": [d.page_content[:80] for d in top_docs]}


# ---------------------------------------------------------------- worked example
if __name__ == "__main__":
    from langchain_chroma import Chroma
    from langchain_openai import OpenAIEmbeddings

    docs = [
        Document(page_content="Error E-4012 on the X200 router means the firmware update failed. Hold reset for 10 seconds."),
        Document(page_content="If your router keeps disconnecting, move it away from microwaves and update the firmware."),
        Document(page_content="The X200 supports WPA3 and has four gigabit Ethernet ports."),
        Document(page_content="Refunds for routers are accepted within 30 days of delivery."),
    ]
    store = Chroma.from_documents(docs, OpenAIEmbeddings(model="text-embedding-3-small"))
    hybrid = HybridRetriever(docs, store)

    query = "how to fix E-4012"
    # See each retriever separately to understand why we combine them:
    print("BM25 only  :", [d.page_content[:40] for d in hybrid._bm25(query, k=2)])
    #   → finds the E-4012 doc (exact token match); embeddings often miss rare codes like this
    print("Vector only:", [d.page_content[:40] for d in store.similarity_search(query, k=2)])
    #   → finds "keeps disconnecting… update firmware" (similar meaning, no shared keywords)
    print("Hybrid RRF :", [d.page_content[:40] for d in hybrid.invoke(query, k=2)])
    #   → both kinds of match, ranked together

    # Full pipeline: LLM rewrite → LLM multi-query → BM25+vector per query → LLM rerank → LLM answer
    history = ["User: My X200 router shows a code.", "Assistant: Which code do you see?"]
    result = advanced_answer("it says E-4012, what now?", history, hybrid)
    print("ANSWER :", result["answer"])
    print("SOURCES:", result["sources"])
