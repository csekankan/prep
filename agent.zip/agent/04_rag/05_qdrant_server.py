"""
05 — QDRANT SERVER (native client + hybrid search + LangChain)
===============================================================

CONCEPT DEEP DIVE
-----------------
Qdrant vocabulary:
  COLLECTION  ≈ table. Has a vector config (size, distance) — possibly SEVERAL NAMED vectors.
  POINT       ≈ row: id (uint or UUID) + vector(s) + PAYLOAD (arbitrary JSON metadata).
  PAYLOAD INDEX  index on a payload field so filters are fast (always index tenant_id!).
  FILTER      must / should / must_not conditions on payload, applied DURING the HNSW search
              (unlike pgvector's post-filtering) → correct top-k even with selective filters.

Production features worth knowing:
  - QUANTIZATION: store int8 (scalar) or binary copies of vectors in RAM → 4–32x less memory,
    with full vectors on disk for rescoring. Main lever for cost at scale.
  - SPARSE VECTORS: native BM25-style keyword vectors → HYBRID search fused server-side with RRF.
  - MULTITENANCY: one collection + `tenant_id` keyword index with is_tenant=True (Qdrant
    optimizes storage per tenant) — preferred over one collection per tenant.
  - Replication/sharding, snapshots (backups to S3), REST (6333) and gRPC (6334) APIs.

Connecting to a SERVER is just a URL + API key:
  local docker:  QdrantClient(url="http://localhost:6333", api_key="local-dev-key")
  Qdrant Cloud:  QdrantClient(url="https://<cluster-id>.<region>.cloud.qdrant.io:6333", api_key=<secret>)
  self-hosted:   Kubernetes via the official Helm chart, behind TLS + API key / JWT RBAC
NEVER use QdrantClient(":memory:") or path=... beyond notebooks — that's the local embedded mode.

Prereq: docker compose -f 04_rag/docker-compose.vectordb.yml up -d
"""

import os
import uuid

from fastembed import SparseTextEmbedding
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from qdrant_client import QdrantClient, models

QDRANT_URL = os.environ.get("QDRANT_URL", "http://localhost:6333")
QDRANT_API_KEY = os.environ.get("QDRANT_API_KEY", "local-dev-key")
COLLECTION = "support_chunks_v1"
EMBED_DIM = 1536

# One client per process; it's thread-safe and keeps connections alive.
# prefer_grpc=True → faster bulk upserts; timeout prevents a hung request from blocking a worker.
client = QdrantClient(url=QDRANT_URL, api_key=QDRANT_API_KEY, prefer_grpc=True, timeout=10)

dense_embedder = OpenAIEmbeddings(model="text-embedding-3-small")
# BM25 sparse embeddings computed locally (fastembed); Qdrant applies IDF server-side (modifier=IDF).
sparse_embedder = SparseTextEmbedding("Qdrant/bm25")


# ================================================================ collection setup (migration step)
def create_collection() -> None:
    if client.collection_exists(COLLECTION):
        return
    client.create_collection(
        collection_name=COLLECTION,
        # Named vectors: one point carries BOTH a dense and a sparse vector → hybrid search.
        vectors_config={
            "dense": models.VectorParams(
                size=EMBED_DIM,
                distance=models.Distance.COSINE,
                on_disk=True,  # full-precision vectors on disk...
            )
        },
        sparse_vectors_config={"sparse": models.SparseVectorParams(modifier=models.Modifier.IDF)},
        # ...and int8-quantized copies in RAM for fast search (~4x memory saving).
        quantization_config=models.ScalarQuantization(
            scalar=models.ScalarQuantizationConfig(type=models.ScalarType.INT8, always_ram=True)
        ),
        hnsw_config=models.HnswConfigDiff(m=16, ef_construct=100),
    )
    # Payload indexes: required for fast filtering. is_tenant=True optimizes multi-tenant layout.
    client.create_payload_index(
        COLLECTION, "tenant_id", field_schema=models.KeywordIndexParams(type="keyword", is_tenant=True)
    )
    client.create_payload_index(COLLECTION, "source", field_schema=models.PayloadSchemaType.KEYWORD)


# ================================================================ ingestion
def point_id(tenant_id: str, source: str, text: str) -> str:
    # Deterministic UUID → re-running ingestion overwrites instead of duplicating.
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"{tenant_id}|{source}|{text}"))


def upsert_documents(tenant_id: str, source: str, docs: list[Document]) -> None:
    # Remove stale chunks of this source first (the doc may now have fewer chunks).
    client.delete(
        COLLECTION,
        points_selector=models.FilterSelector(
            filter=models.Filter(must=[
                models.FieldCondition(key="tenant_id", match=models.MatchValue(value=tenant_id)),
                models.FieldCondition(key="source", match=models.MatchValue(value=source)),
            ])
        ),
    )
    texts = [d.page_content for d in docs]
    dense = dense_embedder.embed_documents(texts)
    sparse = list(sparse_embedder.embed(texts))
    points = [
        models.PointStruct(
            id=point_id(tenant_id, source, t),
            vector={
                "dense": dv,
                "sparse": models.SparseVector(indices=sv.indices.tolist(), values=sv.values.tolist()),
            },
            payload={"tenant_id": tenant_id, "source": source, "content": t, **d.metadata},
        )
        for d, t, dv, sv in zip(docs, texts, dense, sparse)
    ]
    # Batch large uploads (e.g. 256 points per call); wait=True makes writes visible before returning.
    for i in range(0, len(points), 256):
        client.upsert(COLLECTION, points=points[i : i + 256], wait=True)


# ================================================================ search
def tenant_filter(tenant_id: str) -> models.Filter:
    return models.Filter(must=[models.FieldCondition(key="tenant_id", match=models.MatchValue(value=tenant_id))])


def dense_search(tenant_id: str, query: str, k: int = 5) -> list[dict]:
    result = client.query_points(
        COLLECTION,
        query=dense_embedder.embed_query(query),
        using="dense",
        query_filter=tenant_filter(tenant_id),  # applied during HNSW traversal
        limit=k,
        with_payload=True,
        search_params=models.SearchParams(
            hnsw_ef=128,
            # Search the quantized vectors, then rescore the top candidates with full vectors.
            quantization=models.QuantizationSearchParams(rescore=True, oversampling=2.0),
        ),
        score_threshold=0.3,  # drop weak matches (tune on evals)
    )
    return [{"source": p.payload["source"], "content": p.payload["content"], "score": p.score} for p in result.points]


def hybrid_search(tenant_id: str, query: str, k: int = 5) -> list[dict]:
    """Server-side hybrid: two PREFETCH queries (dense + sparse) fused with RRF in one request."""
    sq = next(sparse_embedder.query_embed(query))
    result = client.query_points(
        COLLECTION,
        prefetch=[
            models.Prefetch(query=dense_embedder.embed_query(query), using="dense", limit=20, filter=tenant_filter(tenant_id)),
            models.Prefetch(
                query=models.SparseVector(indices=sq.indices.tolist(), values=sq.values.tolist()),
                using="sparse", limit=20, filter=tenant_filter(tenant_id),
            ),
        ],
        query=models.FusionQuery(fusion=models.Fusion.RRF),
        limit=k,
        with_payload=True,
    )
    return [{"source": p.payload["source"], "content": p.payload["content"], "score": p.score} for p in result.points]


# ================================================================ LangChain wrapper
def langchain_qdrant():
    """QdrantVectorStore on top of the SAME server collection. RetrievalMode.HYBRID uses the
    named dense + sparse vectors created above."""
    from langchain_qdrant import FastEmbedSparse, QdrantVectorStore, RetrievalMode

    store = QdrantVectorStore(
        client=client,
        collection_name=COLLECTION,
        embedding=dense_embedder,
        sparse_embedding=FastEmbedSparse(model_name="Qdrant/bm25"),
        retrieval_mode=RetrievalMode.HYBRID,
        vector_name="dense",
        sparse_vector_name="sparse",
        content_payload_key="content",   # match the payload layout used in upsert_documents
    )
    return store.as_retriever(search_kwargs={"k": 4, "filter": tenant_filter("acme")})


if __name__ == "__main__":
    create_collection()
    upsert_documents(
        "acme", "refunds.md",
        [Document(page_content="Refunds are allowed within 30 days of delivery.", metadata={"section": "Refund Policy"})],
    )
    print(dense_search("acme", "how long can I return something?"))
    print(hybrid_search("acme", "refund 30 days"))
