"""
04 — PGVECTOR ON A POSTGRES SERVER (raw SQL + LangChain)
=========================================================

CONCEPT DEEP DIVE
-----------------
pgvector adds to Postgres:
  - a column type:     embedding vector(1536)
  - distance operators: <=> cosine distance, <-> L2 distance, <#> negative inner product
  - ANN indexes:       HNSW (best recall/latency, more memory) or IVFFlat (faster build, needs training data)

So "vector search" becomes plain SQL:
    SELECT content FROM chunks WHERE tenant_id = 'acme' ORDER BY embedding <=> $query LIMIT 5;

Big advantage: vectors live NEXT TO your business data. You can JOIN chunks to a `documents` or
`permissions` table, filter by any column, and get transactions + backups you already operate.

HNSW knobs:
  m               links per node (16 default). Higher → better recall, more memory.
  ef_construction build-time search width (64 default). Higher → better index, slower build.
  hnsw.ef_search  query-time search width (40 default). Raise (e.g. 100) for recall; costs latency.

FILTERING GOTCHA: with HNSW, Postgres finds the top ef_search neighbors THEN applies WHERE.
A very selective filter (tiny tenant) can return fewer than k rows. Fixes: raise ef_search,
enable iterative scans (pgvector >= 0.8: SET hnsw.iterative_scan = relaxed_order), or partition by tenant.

This file shows two layers:
  A) Raw SQL with psycopg — understand exactly what runs on the server (schema, index, hybrid query).
  B) LangChain's PGVector — the convenient wrapper you'd plug into the agents in this repo.

Prereq: docker compose -f 04_rag/docker-compose.vectordb.yml up -d   (or an RDS/Aurora endpoint)
"""

import hashlib
import os

from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from pgvector.psycopg import register_vector
from psycopg_pool import ConnectionPool

# Server connection from the environment. Production example:
#   postgresql://app_user:<from-secrets-manager>@mydb.cluster-xyz.us-east-1.rds.amazonaws.com:5432/rag?sslmode=require
PG_URL = os.environ.get("PG_URL", "postgresql://rag:rag_password@localhost:5432/rag")
EMBED_DIM = 1536
TABLE = "chunks_te3small_v1"   # versioned: a new embedding model gets a new table

embedder = OpenAIEmbeddings(model="text-embedding-3-small")


# ================================================================ A) RAW SQL
def _configure(conn):
    register_vector(conn)  # teaches psycopg to send/receive numpy arrays as `vector`


# A pool, not a connection per request: opening a Postgres connection costs ~10-50 ms and the
# server has a hard max_connections. One pool per process, sized to your worker concurrency.
# open=False → the pool connects when first used, not at import time.
pool = ConnectionPool(PG_URL, min_size=1, max_size=10, timeout=10, configure=_configure, open=False)

SCHEMA_SQL = f"""
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS {TABLE} (
    id          TEXT PRIMARY KEY,                 -- deterministic hash → idempotent upserts
    tenant_id   TEXT NOT NULL,                    -- multi-tenant isolation
    source      TEXT NOT NULL,                    -- for citations + deleting stale chunks
    content     TEXT NOT NULL,
    metadata    JSONB NOT NULL DEFAULT '{{}}',
    embedding   vector({EMBED_DIM}) NOT NULL,
    -- generated full-text column for the keyword half of hybrid search
    content_tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', content)) STORED,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ANN index. vector_cosine_ops must match the operator used in queries (<=> = cosine).
CREATE INDEX IF NOT EXISTS {TABLE}_hnsw ON {TABLE} USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);
CREATE INDEX IF NOT EXISTS {TABLE}_tenant ON {TABLE} (tenant_id);
CREATE INDEX IF NOT EXISTS {TABLE}_tsv ON {TABLE} USING gin (content_tsv);
"""


def create_schema() -> None:
    """Run once via your migration tool (Alembic, Flyway) — not at app startup in production."""
    with pool.connection() as conn:
        conn.execute(SCHEMA_SQL)


def chunk_id(tenant_id: str, doc: Document) -> str:
    return hashlib.sha256(f"{tenant_id}|{doc.metadata['source']}|{doc.page_content}".encode()).hexdigest()


def upsert_documents(tenant_id: str, docs: list[Document], source: str) -> int:
    """Re-ingest one source document: delete its old chunks, insert new ones — in ONE transaction
    so readers never see a half-updated document."""
    vectors = embedder.embed_documents([d.page_content for d in docs])  # one batched API call
    with pool.connection() as conn, conn.transaction():
        conn.execute(f"DELETE FROM {TABLE} WHERE tenant_id = %s AND source = %s", (tenant_id, source))
        with conn.cursor() as cur:
            cur.executemany(
                f"""INSERT INTO {TABLE} (id, tenant_id, source, content, metadata, embedding)
                    VALUES (%s, %s, %s, %s, %s::jsonb, %s)
                    ON CONFLICT (id) DO UPDATE SET content = EXCLUDED.content,
                        embedding = EXCLUDED.embedding, updated_at = now()""",
                [
                    (chunk_id(tenant_id, d), tenant_id, source, d.page_content,
                     _json(d.metadata), _vec(v))
                    for d, v in zip(docs, vectors)
                ],
            )
    return len(docs)


def vector_search(tenant_id: str, query: str, k: int = 5) -> list[dict]:
    q = _vec(embedder.embed_query(query))
    with pool.connection() as conn:
        # SET LOCAL lasts only for this transaction → safe with pooled connections.
        with conn.transaction():
            conn.execute("SET LOCAL hnsw.ef_search = 100")
            rows = conn.execute(
                f"""SELECT id, source, content, 1 - (embedding <=> %s) AS score
                    FROM {TABLE}
                    WHERE tenant_id = %s
                    ORDER BY embedding <=> %s
                    LIMIT %s""",
                (q, tenant_id, q, k),
            ).fetchall()
    return [{"id": r[0], "source": r[1], "content": r[2], "score": float(r[3])} for r in rows]


HYBRID_SQL = f"""
WITH semantic AS (
    SELECT id, ROW_NUMBER() OVER (ORDER BY embedding <=> %(q)s) AS rank
    FROM {TABLE} WHERE tenant_id = %(tenant)s
    ORDER BY embedding <=> %(q)s LIMIT 20
),
keyword AS (
    SELECT id, ROW_NUMBER() OVER (ORDER BY ts_rank_cd(content_tsv, query) DESC) AS rank
    FROM {TABLE}, websearch_to_tsquery('english', %(text)s) AS query
    WHERE tenant_id = %(tenant)s AND content_tsv @@ query
    ORDER BY ts_rank_cd(content_tsv, query) DESC LIMIT 20
)
SELECT c.id, c.source, c.content,
       COALESCE(1.0 / (60 + s.rank), 0) + COALESCE(1.0 / (60 + k.rank), 0) AS rrf_score
FROM semantic s
FULL OUTER JOIN keyword k ON s.id = k.id
JOIN {TABLE} c ON c.id = COALESCE(s.id, k.id)
ORDER BY rrf_score DESC
LIMIT %(k)s
"""
# Reciprocal Rank Fusion (see 04_rag/02_advanced_rag.py) done INSIDE the database:
# one round trip, no extra service. Keyword search catches exact terms (SKUs, error codes).


def hybrid_search(tenant_id: str, query: str, k: int = 5) -> list[dict]:
    q = _vec(embedder.embed_query(query))
    with pool.connection() as conn:
        rows = conn.execute(HYBRID_SQL, {"q": q, "tenant": tenant_id, "text": query, "k": k}).fetchall()
    return [{"id": r[0], "source": r[1], "content": r[2], "score": float(r[3])} for r in rows]


def _vec(values):
    import numpy as np

    return np.array(values, dtype=np.float32)


def _json(d: dict) -> str:
    import json

    return json.dumps(d)


# ================================================================ B) LANGCHAIN PGVector
def langchain_pgvector():
    """langchain-postgres manages its own tables (langchain_pg_collection / langchain_pg_embedding).
    Good for getting started; use raw SQL (above) when you need custom schema, joins, or hybrid SQL.
    Newer versions also offer `PGVectorStore` + `PGEngine` with custom table schemas."""
    from langchain_postgres import PGVector

    store = PGVector(
        embeddings=embedder,
        collection_name="support_policies_v1",
        # SQLAlchemy URL with the psycopg3 driver.
        connection=PG_URL.replace("postgresql://", "postgresql+psycopg://"),
        use_jsonb=True,          # metadata stored as JSONB → filterable
        pre_delete_collection=False,
    )
    docs = [
        Document(page_content="Refunds within 30 days of delivery.", metadata={"source": "refunds.md", "tenant_id": "acme"}),
        Document(page_content="Express shipping costs $15.", metadata={"source": "shipping.md", "tenant_id": "acme"}),
    ]
    store.add_documents(docs, ids=[chunk_id("acme", d) for d in docs])

    # Metadata filter operators: $eq, $ne, $in, $nin, $gt, $lt, $like, $and, $or ...
    results = store.similarity_search_with_score(
        "how long do I have to return?", k=3, filter={"tenant_id": {"$eq": "acme"}}
    )
    # As a retriever for LangGraph tools / chains:
    retriever = store.as_retriever(search_kwargs={"k": 4, "filter": {"tenant_id": {"$eq": "acme"}}})
    return results, retriever


if __name__ == "__main__":
    pool.open()
    create_schema()
    upsert_documents(
        "acme",
        [Document(page_content="Refunds are allowed within 30 days of delivery.", metadata={"source": "refunds.md"})],
        source="refunds.md",
    )
    print(vector_search("acme", "return window?"))
    print(hybrid_search("acme", "refund 30 days"))
    pool.close()
