"""
01 — MEMORY FOR AGENTS: types, trade-offs, and LangGraph's two memory layers
=============================================================================

CONCEPT DEEP DIVE: "MEMORY" MEANS SEVERAL DIFFERENT THINGS
----------------------------------------------------------
Borrowing from cognitive science (CoALA paper), agent memory splits into:

| Type        | Holds                                  | Lifetime        | Implementation                         |
|-------------|----------------------------------------|-----------------|----------------------------------------|
| Working /   | current conversation, tool results,    | one thread      | messages in state + checkpointer       |
| short-term  | scratchpad                             |                 |                                        |
| Semantic    | FACTS about user/world                 | across threads  | Mem0, LangGraph Store, vector DB       |
|             | ("Priya is vegetarian", "uses Python") |                 |                                        |
| Episodic    | past EXPERIENCES / examples            | across threads  | stored successful trajectories used    |
|             | ("last time this worked: ...")         |                 | as few-shot examples                   |
| Procedural  | HOW to behave (rules, prompts)         | long-lived      | system prompt, possibly self-updated   |

SHORT-TERM MEMORY PROBLEM: context grows every turn.
Strategies when history gets long:
  1. TRIM    — keep last N messages/tokens (`trim_messages`). Cheap; forgets early facts.
  2. SUMMARIZE — replace old messages with a running summary. Keeps gist; loses detail; costs a call.
  3. RETRIEVE — store everything, retrieve relevant bits per turn. Most scalable; most complex.
Careful when trimming: never split an AIMessage with tool_calls from its ToolMessages —
the API rejects orphaned tool results.

LONG-TERM MEMORY DESIGN QUESTIONS
  - WHAT to remember? (extract salient facts, not raw transcripts)
  - WHEN to write? "hot path" (during the turn, adds latency) vs "background" (after the turn, async)
  - How to UPDATE/CONFLICT-RESOLVE? ("moved to Berlin" should replace "lives in Pune")
  - SCOPE: per user, per org, per agent? → namespaces
  - PRIVACY: users must be able to view/delete memories (GDPR "right to be forgotten").

LangGraph has two built-in layers:
  - Checkpointer  → short-term, per `thread_id`
  - Store         → long-term, per namespace (e.g. ("memories", user_id)), shared across threads
"""

import uuid

from langchain_core.messages import trim_messages
from langchain_core.messages.utils import count_tokens_approximately
from langgraph.store.memory import InMemoryStore


# ---------------------------------------------------------------- 1. trimming short-term memory
def trim_history(messages):
    return trim_messages(
        messages,
        strategy="last",            # keep the most recent
        token_counter=count_tokens_approximately,
        max_tokens=2000,
        start_on="human",           # valid chat must start on a human turn after the system msg
        include_system=True,        # always keep the system prompt
        allow_partial=False,
    )


# ---------------------------------------------------------------- 2. LangGraph Store (long-term)
def store_demo():
    # In prod: PostgresStore. `index` enables SEMANTIC search over stored memories.
    store = InMemoryStore(index={"embed": "openai:text-embedding-3-small", "dims": 1536})
    user_ns = ("memories", "user-42")  # namespace = scoping; think folder path

    store.put(user_ns, str(uuid.uuid4()), {"fact": "Prefers answers with code examples in Python"})
    store.put(user_ns, str(uuid.uuid4()), {"fact": "Works at a fintech startup, uses AWS"})

    # Inside a LangGraph node you receive the store via `store: BaseStore` injection:
    #   def agent(state, config, *, store): ...
    # and pass it at compile time: builder.compile(checkpointer=..., store=store)
    hits = store.search(user_ns, query="which cloud does the user use?", limit=1)
    for h in hits:
        print(h.value, h.score)
