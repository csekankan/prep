"""
03 — MANAGED RAG WITH BEDROCK KNOWLEDGE BASES
==============================================

CONCEPT DEEP DIVE
-----------------
Compare with 04_rag/01_rag_from_scratch.py — Knowledge Bases (KB) manage the whole indexing
pipeline for you:

   S3 bucket (docs) ──► Data source ──► INGESTION JOB: parse → chunk → embed ──► vector store
                                         (re-run whenever docs change!)          (OpenSearch Serverless,
                                                                                  Aurora pgvector, S3 Vectors...)

Two query APIs (client: bedrock-agent-runtime):
  - Retrieve              → returns chunks + scores + source locations. YOU build the prompt and
                            call the model. Maximum control (use your own LangGraph agent, guardrails, evals).
  - RetrieveAndGenerate   → retrieve + generate + citations in one call, with optional
                            sessionId for multi-turn. Fastest path to a working RAG app.

Choices you still own (they're KB configuration, set in IaC):
  - chunking strategy: FIXED_SIZE, HIERARCHICAL (small-to-big!), SEMANTIC, or custom Lambda
  - embedding model: amazon.titan-embed-text-v2:0, cohere.embed-*
  - search type: SEMANTIC or HYBRID (keyword + vector)
  - metadata filters: put `<file>.metadata.json` next to each doc in S3 → filter by tenant/date/etc.
  - reranking model: rerank top results with a Bedrock reranker model
"""

import time

import boto3

REGION = "us-east-1"
KB_ID = "ABCDEFGHIJ"          # from IaC outputs / SSM Parameter Store — never hardcode in real code
DATA_SOURCE_ID = "KLMNOPQRST"
GEN_MODEL_ARN = f"arn:aws:bedrock:{REGION}::foundation-model/amazon.nova-pro-v1:0"

agent_runtime = boto3.client("bedrock-agent-runtime", region_name=REGION)
agent_admin = boto3.client("bedrock-agent", region_name=REGION)


# ---------------------------------------------------------------- Retrieve (you control generation)
def retrieve(question: str, tenant_id: str, k: int = 5) -> list[dict]:
    resp = agent_runtime.retrieve(
        knowledgeBaseId=KB_ID,
        retrievalQuery={"text": question},
        retrievalConfiguration={
            "vectorSearchConfiguration": {
                "numberOfResults": k,
                "overrideSearchType": "HYBRID",  # catches exact terms like SKUs and error codes
                # Multi-tenant isolation: ALWAYS filter by the authenticated tenant.
                "filter": {"equals": {"key": "tenant_id", "value": tenant_id}},
            }
        },
    )
    return [
        {"text": r["content"]["text"], "score": r.get("score"), "source": r["location"].get("s3Location", {}).get("uri")}
        for r in resp["retrievalResults"]
    ]


# ---------------------------------------------------------------- RetrieveAndGenerate (managed)
PROMPT_TEMPLATE = """You are ShopCo support. Answer ONLY from the search results.
If they don't contain the answer, say "I don't know based on our policies."

$search_results$

$output_format_instructions$"""
# $search_results$ and $output_format_instructions$ are placeholders Bedrock fills in
# (the latter makes the model emit citation markers).


def retrieve_and_generate(question: str, session_id: str | None = None) -> dict:
    kwargs = {}
    if session_id:
        kwargs["sessionId"] = session_id  # Bedrock keeps the conversation context server-side
    resp = agent_runtime.retrieve_and_generate(
        input={"text": question},
        retrieveAndGenerateConfiguration={
            "type": "KNOWLEDGE_BASE",
            "knowledgeBaseConfiguration": {
                "knowledgeBaseId": KB_ID,
                "modelArn": GEN_MODEL_ARN,
                "retrievalConfiguration": {"vectorSearchConfiguration": {"numberOfResults": 5}},
                "generationConfiguration": {
                    "promptTemplate": {"textPromptTemplate": PROMPT_TEMPLATE},
                    "inferenceConfig": {"textInferenceConfig": {"temperature": 0, "maxTokens": 400}},
                    # Attach a Bedrock Guardrail (see 04_bedrock_guardrails.py):
                    # "guardrailConfiguration": {"guardrailId": "...", "guardrailVersion": "1"},
                },
            },
        },
        **kwargs,
    )
    citations = [
        ref["location"].get("s3Location", {}).get("uri")
        for c in resp.get("citations", [])
        for ref in c.get("retrievedReferences", [])
    ]
    return {"answer": resp["output"]["text"], "citations": citations, "session_id": resp["sessionId"]}


# ---------------------------------------------------------------- LangChain integration
def langchain_retriever():
    """Drop-in retriever for the LangGraph agents in this repo (e.g. replace retrieval.search
    in apps/support_copilot with this)."""
    from langchain_aws.retrievers import AmazonKnowledgeBasesRetriever

    return AmazonKnowledgeBasesRetriever(
        knowledge_base_id=KB_ID,
        region_name=REGION,
        retrieval_config={"vectorSearchConfiguration": {"numberOfResults": 4}},
    )


# ---------------------------------------------------------------- ingestion (pipeline/admin side)
def sync_knowledge_base(timeout_s: int = 900) -> dict:
    """Re-index after documents change. In production this is triggered automatically by S3
    events (see pipeline/kb_sync_lambda.py) — not run by hand."""
    job = agent_admin.start_ingestion_job(knowledgeBaseId=KB_ID, dataSourceId=DATA_SOURCE_ID)["ingestionJob"]
    deadline = time.time() + timeout_s
    while job["status"] in ("STARTING", "IN_PROGRESS") and time.time() < deadline:
        time.sleep(10)
        job = agent_admin.get_ingestion_job(
            knowledgeBaseId=KB_ID, dataSourceId=DATA_SOURCE_ID, ingestionJobId=job["ingestionJobId"]
        )["ingestionJob"]
    # statistics: numberOfDocumentsScanned / Indexed / Failed — alert if Failed > 0.
    return {"status": job["status"], "stats": job.get("statistics", {})}


if __name__ == "__main__":
    print(retrieve_and_generate("Can I return headphones after 3 weeks?"))
