"""
04 — BEDROCK GUARDRAILS: managed input/output safety
=====================================================

CONCEPT DEEP DIVE
-----------------
A Bedrock Guardrail is a VERSIONED policy you create once (ideally in IaC) and attach anywhere.
It implements most of the layers from 06_guardrails/ as a managed service:

| Policy                 | What it does                                                    |
|------------------------|-----------------------------------------------------------------|
| Content filters        | HATE, INSULTS, SEXUAL, VIOLENCE, MISCONDUCT with strengths       |
| PROMPT_ATTACK filter   | detects jailbreaks / prompt injection (input side)              |
| Denied topics          | natural-language topic definitions, e.g. "investment advice"    |
| Word filters           | exact words/phrases, managed profanity list                     |
| Sensitive info (PII)   | BLOCK or ANONYMIZE entities (EMAIL, PHONE, CREDIT_DEBIT_CARD...) + custom regex |
| Contextual grounding   | scores answer GROUNDING (vs source) and RELEVANCE (vs query) → blocks hallucinations |
| Automated reasoning    | checks answers against formal policy rules (advanced)           |

Three ways to use it:
  1. Attach to Converse via `guardrailConfig`           → checks input AND output of that call
  2. Attach to Knowledge Base / Agents generation config
  3. Call ApplyGuardrail directly on ANY text            → works with non-Bedrock models too,
     and lets you guard tool outputs / retrieved docs, not just user input

Versioning: edits go to DRAFT; `create_guardrail_version` freezes an immutable version ("1", "2").
Production references a NUMBERED version, promoted through the pipeline like any release.
Still keep app-level checks (authz in tools, business rules) — guardrails don't know your domain.
"""

import boto3

REGION = "us-east-1"
control = boto3.client("bedrock", region_name=REGION)            # create/manage
runtime = boto3.client("bedrock-runtime", region_name=REGION)    # apply at request time


def create_support_guardrail() -> tuple[str, str]:
    """Normally defined in IaC (see infra/app.py, CfnGuardrail). Shown in boto3 for clarity."""
    g = control.create_guardrail(
        name="shopco-support",
        description="Safety policy for the ShopCo support copilot",
        blockedInputMessaging="Sorry, I can't help with that request.",
        blockedOutputsMessaging="Sorry, I can't share that. Let me connect you with a human agent.",
        contentPolicyConfig={
            "filtersConfig": [
                {"type": t, "inputStrength": "HIGH", "outputStrength": "HIGH"}
                for t in ("HATE", "INSULTS", "SEXUAL", "VIOLENCE", "MISCONDUCT")
            ]
            # Prompt attacks are an INPUT concern; output strength must be NONE.
            + [{"type": "PROMPT_ATTACK", "inputStrength": "HIGH", "outputStrength": "NONE"}]
        },
        topicPolicyConfig={
            "topicsConfig": [
                {
                    "name": "FinancialAdvice",
                    "definition": "Recommendations about investments, stocks, crypto, or personal finance decisions.",
                    "examples": ["Should I buy Tesla stock?", "Is bitcoin a good investment?"],
                    "type": "DENY",
                }
            ]
        },
        sensitiveInformationPolicyConfig={
            "piiEntitiesConfig": [
                {"type": "EMAIL", "action": "ANONYMIZE"},
                {"type": "PHONE", "action": "ANONYMIZE"},
                {"type": "CREDIT_DEBIT_CARD_NUMBER", "action": "BLOCK"},
            ],
            "regexesConfig": [
                {"name": "InternalTicketId", "pattern": r"INT-\d{6}", "action": "ANONYMIZE"}
            ],
        },
        contextualGroundingPolicyConfig={
            "filtersConfig": [
                {"type": "GROUNDING", "threshold": 0.75},   # answer must be supported by the source
                {"type": "RELEVANCE", "threshold": 0.75},   # answer must address the question
            ]
        },
    )
    version = control.create_guardrail_version(
        guardrailIdentifier=g["guardrailId"], description="initial release"
    )["version"]
    return g["guardrailId"], version


def converse_with_guardrail(guardrail_id: str, version: str, question: str) -> str:
    resp = runtime.converse(
        modelId="us.amazon.nova-lite-v1:0",
        messages=[{"role": "user", "content": [{"text": question}]}],
        guardrailConfig={"guardrailIdentifier": guardrail_id, "guardrailVersion": version, "trace": "enabled"},
    )
    if resp["stopReason"] == "guardrail_intervened":
        # The trace says WHICH policy fired — emit it as a metric (block rate per policy).
        print("blocked by:", list(resp.get("trace", {}).get("guardrail", {}).keys()))
    return resp["output"]["message"]["content"][0]["text"]


def check_grounding(guardrail_id: str, version: str, source: str, query: str, answer: str) -> bool:
    """ApplyGuardrail as a standalone hallucination check for ANY model's RAG answer.
    Qualifiers tell the grounding policy which text is the source, the query, and the answer."""
    resp = runtime.apply_guardrail(
        guardrailIdentifier=guardrail_id,
        guardrailVersion=version,
        source="OUTPUT",
        content=[
            {"text": {"text": source, "qualifiers": ["grounding_source"]}},
            {"text": {"text": query, "qualifiers": ["query"]}},
            {"text": {"text": answer, "qualifiers": ["guard_content"]}},
        ],
    )
    return resp["action"] == "NONE"  # "GUARDRAIL_INTERVENED" means it failed a policy


def guard_untrusted_document(guardrail_id: str, version: str, document_text: str) -> bool:
    """Indirect-injection defense: scan web pages / emails / uploaded files BEFORE an agent reads them."""
    resp = runtime.apply_guardrail(
        guardrailIdentifier=guardrail_id, guardrailVersion=version, source="INPUT",
        content=[{"text": {"text": document_text}}],
    )
    return resp["action"] == "NONE"
