"""
05 — LANGGRAPH AGENT ON BEDROCK + HOSTING ON AGENTCORE RUNTIME
===============================================================

CONCEPT DEEP DIVE
-----------------
Two separate decisions:
  1. WHICH MODEL PROVIDER  → Bedrock via langchain-aws (ChatBedrockConverse). Your LangGraph code
                             doesn't change; the model object does.
  2. WHERE THE AGENT RUNS  → options on AWS:
       - ECS Fargate / EKS with FastAPI (like apps/support_copilot/api.py) — full control
       - Lambda — fine for short, stateless agents (15-min limit, cold starts)
       - Bedrock AgentCore Runtime — serverless hosting purpose-built for agents:
           * session isolation (each user session in its own microVM)
           * long-running sessions (much longer than Lambda), streaming
           * framework-agnostic: LangGraph, CrewAI, Strands, custom
           * companions: AgentCore Memory (short/long-term), Identity (OAuth to tools),
             Gateway (turn APIs/Lambdas into MCP tools), Observability (OTel traces → CloudWatch),
             Code Interpreter and Browser tools
       - Bedrock Agents (classic) — fully managed, configured not coded; less flexible than LangGraph.

Rule: keep the agent a plain Python function `handle(payload) -> response`. Then the same code
can run locally, in FastAPI, in Lambda, or in AgentCore — hosting becomes a deployment choice.
"""

import os

from langchain_aws import ChatBedrockConverse
from langchain_aws.retrievers import AmazonKnowledgeBasesRetriever
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import START, MessagesState, StateGraph
from langgraph.prebuilt import ToolNode, tools_condition

REGION = os.environ.get("AWS_REGION", "us-east-1")
# Config comes from the environment (injected by IaC from SSM/Secrets Manager) → same image
# runs in dev/staging/prod with different models, KBs, and guardrail versions.
MODEL_ID = os.environ.get("CHAT_MODEL_ID", "us.amazon.nova-pro-v1:0")
KB_ID = os.environ.get("KB_ID", "ABCDEFGHIJ")
GUARDRAIL_ID = os.environ.get("GUARDRAIL_ID", "")
GUARDRAIL_VERSION = os.environ.get("GUARDRAIL_VERSION", "1")

retriever = AmazonKnowledgeBasesRetriever(
    knowledge_base_id=KB_ID, region_name=REGION,
    retrieval_config={"vectorSearchConfiguration": {"numberOfResults": 4, "overrideSearchType": "HYBRID"}},
)


@tool
def search_policies(query: str) -> str:
    """Search ShopCo policies (refunds, shipping, warranty). Use for any policy question."""
    docs = retriever.invoke(query)
    return "\n\n".join(d.page_content for d in docs) or "NO_RELEVANT_POLICY_FOUND"


llm = ChatBedrockConverse(
    model=MODEL_ID,
    region_name=REGION,
    temperature=0,
    max_tokens=600,
    # Managed guardrail on every model call (input + output). Empty → disabled for local dev.
    guardrail_config=(
        {"guardrailIdentifier": GUARDRAIL_ID, "guardrailVersion": GUARDRAIL_VERSION, "trace": "enabled"}
        if GUARDRAIL_ID else None
    ),
).bind_tools([search_policies])


def agent(state: MessagesState) -> dict:
    system = ("system", "You are ShopCo support. Use search_policies for policy questions. Cite sources. Be brief.")
    return {"messages": [llm.invoke([system, *state["messages"]])]}


builder = StateGraph(MessagesState)
builder.add_node("agent", agent)
builder.add_node("tools", ToolNode([search_policies]))
builder.add_edge(START, "agent")
builder.add_conditional_edges("agent", tools_condition)  # prebuilt router: tools or END
builder.add_edge("tools", "agent")
# Local/dev checkpointer. On AWS use a durable one (Postgres on Aurora, or DynamoDB-based
# savers from langgraph-checkpoint-aws) or AgentCore Memory for conversation state.
graph = builder.compile(checkpointer=InMemorySaver())


def handle(payload: dict) -> dict:
    """Hosting-agnostic entrypoint."""
    config = {"configurable": {"thread_id": payload.get("session_id", "default")}, "recursion_limit": 12}
    out = graph.invoke({"messages": [("user", payload["prompt"])]}, config)
    return {"answer": out["messages"][-1].content}


# ---------------------------------------------------------------- AgentCore Runtime wrapper
# pip install bedrock-agentcore bedrock-agentcore-starter-toolkit
# Deploy:   agentcore configure --entrypoint 05_langgraph_on_bedrock.py
#           agentcore launch            (builds container → ECR → AgentCore Runtime)
# Invoke:   agentcore invoke '{"prompt": "Can I return shoes?", "session_id": "u1"}'
if os.environ.get("RUN_ON_AGENTCORE"):
    from bedrock_agentcore.runtime import BedrockAgentCoreApp

    app = BedrockAgentCoreApp()

    @app.entrypoint
    def invoke(payload: dict) -> dict:
        return handle(payload)

    if __name__ == "__main__":
        app.run()

elif __name__ == "__main__":
    print(handle({"prompt": "How long do refunds take?", "session_id": "local"}))
