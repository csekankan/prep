# Running the LLMOps lifecycle on AWS with Bedrock

**LLMOps** is the practice of running LLM applications in production and improving them safely over time:
watching quality, collecting failures, producing a better version, testing it, and rolling it out without
breaking anything. The generic, vendor-neutral pipeline lives in `10_llmops_pipeline/`. It has six stages:
**monitor** quality, **alert** on problems, **curate** a dataset from failures, **train** a candidate, pass
an **evaluation gate**, and **publish** a release. Deployment is in `11_kubernetes/` (EKS, canary releases,
GitOps).

This page shows which AWS service handles each stage when Bedrock is your model provider.

```
           ┌────────────── docs change ──────────────┐
  S3 docs ─┤ EventBridge rule ─► Lambda: StartIngestionJob ─► Bedrock Knowledge Base (new index)
           └─────────────────────────────────────────┘
                                                                     ┌─────────── Bedrock ───────────┐
  users ─► ALB ─► EKS pods (LangGraph, IRSA role) ── Converse ──────►│ models + Guardrail vN + KB    │
                     │                                               │ model invocation logging ──┐  │
                     │ /metrics → Prometheus  (or CloudWatch EMF)    └────────────────────────────┼──┘
                     ▼                                                                            ▼
              CloudWatch alarms / Alertmanager ◄── online monitor CronJob ◄── invocation logs in S3/CloudWatch
                     │ quality breach
                     ▼
              EventBridge ─► Step Functions / Argo Workflow: curate → train → eval gate → publish
                                                              │          │
                                               Bedrock fine-tuning   Bedrock evaluation jobs
                                               (custom model)        or DeepEval with Bedrock judge
                                                              ▼
                                         release manifest (model ARN, guardrail version, KB id, prompt ARN)
                                                              ▼
                                         GitOps commit ─► Argo CD ─► canary on EKS ─► auto-rollback
```

**How to read it:** there are three flows.

1. **Top: keeping knowledge fresh.** When someone adds or changes a document in S3, an event automatically
   triggers a small function that tells the Knowledge Base to re-index. Answers then reflect the new
   document within minutes.
2. **Middle: serving users.** Requests come through a load balancer to the app running on Kubernetes, which
   calls Bedrock. Every call is logged, and the app publishes metrics.
3. **Bottom: improving the system.** A scheduled job scores recent logged conversations. If quality drops,
   an alarm starts a workflow that builds an improved version, tests it, records it as a release, and
   rolls it out gradually, with automatic rollback if the new version misbehaves.

**Terms in this diagram:**
- **EventBridge**: AWS's event router. A **rule** says "when event X happens (a file is created in this S3
  bucket), call target Y".
- **Lambda**: AWS's serverless functions. You upload a small piece of code and AWS runs it whenever it's
  triggered, with no servers to manage.
- **StartIngestionJob**: the Bedrock API call that re-indexes a Knowledge Base data source.
- **ALB** (Application Load Balancer): spreads incoming HTTP requests across your app's copies.
- **EKS pods**: **EKS** is AWS's managed Kubernetes. A **pod** is one running copy of your app container.
- **IRSA role** (IAM Roles for Service Accounts): lets a Kubernetes pod use an AWS IAM role, meaning AWS
  permissions, without any stored access keys. See `11_kubernetes/`.
- **Guardrail vN**: a specific, frozen version (N) of a Bedrock guardrail.
- **Model invocation logging**: a Bedrock setting that records every model call (input, output, token
  counts) to S3 and/or CloudWatch.
- **/metrics and Prometheus**: the app exposes numbers (request count, latency, errors) at a `/metrics` URL.
  **Prometheus** is an open-source system that collects them every few seconds. **CloudWatch EMF**
  (Embedded Metric Format) is the AWS-native alternative: you write metrics as specially formatted log
  lines and CloudWatch extracts them.
- **CloudWatch alarms / Alertmanager**: send a notification when a metric crosses a threshold. Alertmanager
  is the Prometheus companion that does this.
- **Online monitor CronJob**: a Kubernetes job that runs on a schedule (for example hourly), scores a sample
  of recent conversations, and publishes quality metrics.
- **Step Functions / Argo Workflow**: tools that run a multi-step pipeline in order, with retries and
  branching. Step Functions is AWS-native, and Argo Workflows runs on Kubernetes.
- **Bedrock fine-tuning (custom model)**: training a copy of a base model on your examples inside Bedrock.
- **Bedrock evaluation jobs / DeepEval with a Bedrock judge**: two ways to score the candidate. Both use an
  LLM to grade answers (**LLM-as-judge**).
- **Release manifest**: one small file recording the exact versions that make up a release (which model,
  which guardrail version, which Knowledge Base, which prompt version). Deploy, roll back, and compare by
  this file.
- **GitOps commit, Argo CD**: in **GitOps**, the desired state of production lives in a git repository.
  **Argo CD** watches that repository and makes the cluster match it. Deploying means committing a change.
- **Canary and auto-rollback**: a **canary** release sends a small share of traffic (say 10%) to the new
  version first. If its metrics get worse, the system automatically switches everything back to the old
  version.

## Stage-by-stage mapping to AWS services

| Stage | AWS | Notes |
|---|---|---|
| Identity for pods | IRSA / EKS Pod Identity, mapped to an IAM role | least privilege: specific model ARNs, one KB, one guardrail |
| Model calls | Bedrock Converse via `ChatBedrockConverse` | pin model IDs / application inference profiles per release |
| Knowledge index | Bedrock Knowledge Bases | event-driven sync (below); nightly full sync as a backstop |
| Safety | Bedrock Guardrails | the guardrail **version** is part of the release manifest |
| Prompts | Bedrock Prompt Management or git | prompt version ARN pinned per release |
| Logging | Bedrock model invocation logging to S3 and CloudWatch | input for the online monitor; mind PII retention |
| Metrics and alarms | CloudWatch (`AWS/Bedrock`: Invocations, InvocationLatency, InputTokenCount, OutputTokenCount, InvocationThrottles) plus app metrics | alarms go to SNS, then Slack/PagerDuty |
| Online eval | CronJob (EKS) or a scheduled Lambda/Fargate task | DeepEval with Bedrock as judge (a `DeepEvalBaseLLM` wrapper around Converse) |
| Fine-tuning | Bedrock model customization (`10_llmops_pipeline/03_train_candidate.py::fine_tune_bedrock`) | custom models usually need provisioned throughput to serve |
| Managed eval | Bedrock evaluation jobs (model and RAG, LLM-as-judge) | complements DeepEval; results go to S3 |
| Orchestration | Step Functions or Argo Workflows on EKS | EventBridge triggers from alarms and S3 events |
| Registry | SageMaker Model Registry or MLflow on EKS | aliases champion / challenger |
| Cost control | AWS Budgets, cost allocation tags, application inference profiles | per-app, per-environment spend visibility |
| Network | VPC endpoints (PrivateLink) for bedrock-runtime, bedrock-agent-runtime, S3 | traffic never leaves the AWS network |

What the less obvious rows mean:

- **Least privilege for pods.** The pod's IAM role should allow calling only the specific models, the one
  Knowledge Base, and the one guardrail it needs, not `bedrock:*`. If the app is ever compromised (for
  example through prompt injection), the damage is limited to those resources.
- **Pin versions per release.** "Pin" means referencing an exact, unchanging version (`support@v7`, guardrail
  version `3`) instead of "latest". Then a release behaves the same next month as it did on the day you
  tested it.
- **Nightly full sync as a backstop.** Event-driven sync can miss an event (for example while an ingestion
  job is already running). A full re-sync every night guarantees the index is never more than a day stale.
- **Mind PII retention.** Invocation logs contain everything users typed, possibly names and account
  numbers. Set an expiry on the log bucket (for example 30 days) and restrict who can read it.
- **`AWS/Bedrock` metrics.** Bedrock publishes these automatically to CloudWatch: number of calls
  (`Invocations`), how long they took (`InvocationLatency`), tokens in and out (which drive cost), and how
  often you were rate-limited (`InvocationThrottles`).
- **SNS** (Simple Notification Service): AWS's notification fan-out. One alarm message can go to email,
  Slack, and **PagerDuty** (an on-call paging service that wakes up the engineer on duty).
- **Fargate**: runs containers without you managing servers. It suits a scheduled task that runs for 10
  minutes an hour.
- **Custom models need provisioned throughput.** A fine-tuned model in Bedrock usually can't be called
  on-demand; you buy reserved capacity by the hour. Include that fixed cost when deciding whether
  fine-tuning is worth it.
- **Model registry with champion/challenger aliases.** A **model registry** is a catalog of model and release
  versions. **Champion** is the alias for the version currently serving production, and **challenger** is the
  new candidate being tested against it. Promoting a release means moving the champion alias.
- **AWS Budgets and cost allocation tags.** Tags label resources (`app=support-bot`). Budgets send alerts when
  tagged spend passes a limit (for example 80% of the monthly budget).

## Event-driven Knowledge Base sync (Lambda)

**Goal:** when a document changes in S3, re-index the Knowledge Base automatically, so the bot never answers
from a stale policy.

```python
# Triggered by an EventBridge rule on S3 "Object Created/Deleted" in the docs bucket.
import os
import boto3

agent = boto3.client("bedrock-agent")

def handler(event, context):
    try:
        job = agent.start_ingestion_job(
            knowledgeBaseId=os.environ["KB_ID"], dataSourceId=os.environ["DATA_SOURCE_ID"],
            description=f"s3 change: {event['detail']['object']['key']}",
        )["ingestionJob"]
        return {"ingestionJobId": job["ingestionJobId"]}
    except agent.exceptions.ConflictException:
        # An ingestion job is already running; it (or the next event) will pick up this change.
        # Debounce bursts of uploads with an SQS queue + batching window in front of this Lambda.
        return {"skipped": "job already running"}
```

**How it works:** S3 emits an event for every created or deleted object. The EventBridge rule passes it to
this Lambda, which starts an ingestion job for the Knowledge Base's data source. `KB_ID` and
`DATA_SOURCE_ID` come from environment variables, so the same code works in staging and production.

**Why the `ConflictException` handling matters:** only one ingestion job can run per data source at a time.
If someone uploads 200 files at once, the first event starts a job and the other 199 hit this exception.
Skipping them is safe, because an ingestion job scans the whole data source and so picks up every change.

**Debouncing:** "debounce" means collapsing a burst of events into one action. Put an **SQS** queue (AWS's
message queue) in front of the Lambda with a **batching window** (for example 60 seconds). The Lambda then
receives all the uploads from that minute as one batch and starts one job, instead of being invoked 200
times.

## Using Bedrock as the DeepEval judge

**DeepEval** (see `07_evaluation/`) scores answers using an LLM as the judge, and by default it calls OpenAI.
This wrapper makes it call a Bedrock model instead:

```python
import boto3
from deepeval.models import DeepEvalBaseLLM

class BedrockJudge(DeepEvalBaseLLM):
    def __init__(self, model_id="us.amazon.nova-pro-v1:0"):
        self.model_id = model_id
        self.client = boto3.client("bedrock-runtime")

    def load_model(self):
        return self.client

    def generate(self, prompt: str) -> str:
        r = self.client.converse(modelId=self.model_id,
                                 messages=[{"role": "user", "content": [{"text": prompt}]}],
                                 inferenceConfig={"temperature": 0, "maxTokens": 1024})
        return r["output"]["message"]["content"][0]["text"]

    async def a_generate(self, prompt: str) -> str:
        return self.generate(prompt)

    def get_model_name(self) -> str:
        return self.model_id

# FaithfulnessMetric(model=BedrockJudge(), threshold=0.8)
```

**How it works:** DeepEval requires any custom judge to implement a few methods. The key one is `generate`,
which takes the grading prompt DeepEval builds and returns the model's text reply, here via the Converse
API. `temperature=0` makes the judge as deterministic as possible, so the same answer gets the same score
on every run. `a_generate` is the async version DeepEval calls when it runs evaluations in parallel; this
simple version just calls the synchronous one. The last line shows usage: a faithfulness metric that fails
any answer scoring below 0.8.

**Why bother:** the conversations you're grading may contain customer data. With a Bedrock judge, that data
stays inside your AWS account and region instead of going to a third-party API. That's often a compliance
requirement in regulated industries.
