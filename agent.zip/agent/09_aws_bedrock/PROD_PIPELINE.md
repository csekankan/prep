# Running the LLMOps lifecycle on AWS with Bedrock

The generic pipeline lives in `10_llmops_pipeline/` (monitor → alert → curate → train → gate →
publish) and the deployment in `11_kubernetes/` (EKS, canary, GitOps). This page maps each stage
onto AWS services when Bedrock is the model provider.

```
           ┌────────────── docs change ──────────────┐
  S3 docs ─┤ EventBridge rule ─► Lambda: StartIngestionJob ─► Bedrock Knowledge Base (new index)
           └─────────────────────────────────────────┘
                                                                     ┌─────────── Bedrock ───────────┐
  users ─► ALB ─► EKS pods (LangGraph, IRSA role) ── Converse ──────►│ models + Guardrail vN + KB    │
                     │                                               │ model invocation logging ──┐  │
                     │ /metrics → Prometheus  (or CloudWatch EMF)    └────────────────────────────┼──┘
                     ▼                                                                            ▼
              CloudWatch alarms / Alertmanager ◄── online monitor CronJob ◄── invocation logs in S3/CloudWatch
                     │ quality breach
                     ▼
              EventBridge ─► Step Functions / Argo Workflow: curate → train → eval gate → publish
                                                              │          │
                                               Bedrock fine-tuning   Bedrock evaluation jobs
                                               (custom model)        or DeepEval with Bedrock judge
                                                              ▼
                                         release manifest (model ARN, guardrail version, KB id, prompt ARN)
                                                              ▼
                                         GitOps commit ─► Argo CD ─► canary on EKS ─► auto-rollback
```

## Stage → AWS service

| Stage | AWS | Notes |
|---|---|---|
| Identity for pods | IRSA / EKS Pod Identity → IAM role | least privilege: specific model ARNs, one KB, one guardrail |
| Model calls | Bedrock Converse via `ChatBedrockConverse` | pin model IDs / application inference profiles per release |
| Knowledge index | Bedrock Knowledge Bases | event-driven sync (below); nightly full sync as backstop |
| Safety | Bedrock Guardrails | guardrail **version** is part of the release manifest |
| Prompts | Bedrock Prompt Management or git | prompt version ARN pinned per release |
| Logging | Bedrock model invocation logging → S3 + CloudWatch | input for online monitor; mind PII retention |
| Metrics & alarms | CloudWatch (`AWS/Bedrock`: Invocations, InvocationLatency, InputTokenCount, OutputTokenCount, InvocationThrottles) + app metrics | alarms → SNS → Slack/PagerDuty |
| Online eval | CronJob (EKS) or scheduled Lambda/Fargate task | DeepEval with Bedrock as judge (`DeepEvalBaseLLM` wrapper around Converse) |
| Fine-tuning | Bedrock model customization (`10_llmops_pipeline/03_train_candidate.py::fine_tune_bedrock`) | custom models usually need provisioned throughput to serve |
| Managed eval | Bedrock evaluation jobs (model + RAG, LLM-as-judge) | complements DeepEval; results to S3 |
| Orchestration | Step Functions or Argo Workflows on EKS | EventBridge triggers from alarms and S3 events |
| Registry | SageMaker Model Registry or MLflow on EKS | aliases champion / challenger |
| Cost control | AWS Budgets + cost allocation tags + application inference profiles | per-app, per-env spend visibility |
| Network | VPC endpoints (PrivateLink) for bedrock-runtime, bedrock-agent-runtime, S3 | traffic never leaves AWS network |

## Event-driven Knowledge Base sync (Lambda)

```python
# Triggered by an EventBridge rule on S3 "Object Created/Deleted" in the docs bucket.
import os
import boto3

agent = boto3.client("bedrock-agent")

def handler(event, context):
    try:
        job = agent.start_ingestion_job(
            knowledgeBaseId=os.environ["KB_ID"], dataSourceId=os.environ["DATA_SOURCE_ID"],
            description=f"s3 change: {event['detail']['object']['key']}",
        )["ingestionJob"]
        return {"ingestionJobId": job["ingestionJobId"]}
    except agent.exceptions.ConflictException:
        # An ingestion job is already running; it (or the next event) will pick up this change.
        # Debounce bursts of uploads with an SQS queue + batching window in front of this Lambda.
        return {"skipped": "job already running"}
```

## Using Bedrock as the DeepEval judge

```python
import boto3
from deepeval.models import DeepEvalBaseLLM

class BedrockJudge(DeepEvalBaseLLM):
    def __init__(self, model_id="us.amazon.nova-pro-v1:0"):
        self.model_id = model_id
        self.client = boto3.client("bedrock-runtime")

    def load_model(self):
        return self.client

    def generate(self, prompt: str) -> str:
        r = self.client.converse(modelId=self.model_id,
                                 messages=[{"role": "user", "content": [{"text": prompt}]}],
                                 inferenceConfig={"temperature": 0, "maxTokens": 1024})
        return r["output"]["message"]["content"][0]["text"]

    async def a_generate(self, prompt: str) -> str:
        return self.generate(prompt)

    def get_model_name(self) -> str:
        return self.model_id

# FaithfulnessMetric(model=BedrockJudge(), threshold=0.8)
```

Keeps evaluation data inside your AWS account — often a compliance requirement.
