"""
01 — BEDROCK CONVERSE API BASICS (boto3 and LangChain)
=======================================================

CONCEPT DEEP DIVE
-----------------
Auth: there is no API key. boto3 uses the standard AWS credential chain:
  env vars → ~/.aws/credentials / SSO profile → IAM role (EC2/ECS/Lambda/EKS).
In production the service runs with an IAM ROLE that allows only what it needs, e.g.
  bedrock:InvokeModel, bedrock:InvokeModelWithResponseStream on specific model ARNs.

Converse request shape (identical for Claude, Nova, Llama, Mistral):
  messages        [{"role": "user"|"assistant", "content": [{"text": ...} | {"image": ...} | {"toolUse": ...} | {"toolResult": ...}]}]
  system          [{"text": "..."}]                       ← system prompt is separate from messages
  inferenceConfig {"maxTokens", "temperature", "topP", "stopSequences"}
  toolConfig      tools the model may call (see 02_...)
  guardrailConfig guardrail to apply (see 04_...)

Response: output.message (assistant message), stopReason, usage {inputTokens, outputTokens}, metrics {latencyMs}.
"""

import boto3
from botocore.config import Config

REGION = "us-east-1"
# Cross-region inference profile ("us." prefix). Verify current IDs in the Bedrock console;
# you must enable model access per account/region before calling.
MODEL_ID = "us.amazon.nova-lite-v1:0"

# botocore's "adaptive" retry mode = exponential backoff + client-side rate limiting.
# Essential: on-demand Bedrock throttles (ThrottlingException) when you exceed per-minute quotas.
runtime = boto3.client(
    "bedrock-runtime",
    region_name=REGION,
    config=Config(retries={"max_attempts": 6, "mode": "adaptive"}, read_timeout=60, connect_timeout=5),
)


def converse_once() -> None:
    response = runtime.converse(
        modelId=MODEL_ID,
        system=[{"text": "You are a concise AWS tutor. Max 3 sentences."}],
        messages=[{"role": "user", "content": [{"text": "What is a cross-region inference profile?"}]}],
        inferenceConfig={"maxTokens": 300, "temperature": 0},
    )
    print(response["output"]["message"]["content"][0]["text"])
    # Log these on every call — they feed cost dashboards and latency SLOs.
    print(response["stopReason"], response["usage"], response["metrics"]["latencyMs"])


def converse_streaming() -> None:
    """ConverseStream yields events; text arrives in contentBlockDelta events.
    Forward deltas to the browser over SSE for a fast-feeling UI."""
    response = runtime.converse_stream(
        modelId=MODEL_ID,
        messages=[{"role": "user", "content": [{"text": "Explain Bedrock Knowledge Bases in one paragraph."}]}],
        inferenceConfig={"maxTokens": 400, "temperature": 0.3},
    )
    for event in response["stream"]:
        if "contentBlockDelta" in event:
            print(event["contentBlockDelta"]["delta"].get("text", ""), end="", flush=True)
        elif "metadata" in event:
            print("\nusage:", event["metadata"]["usage"])


def multi_turn() -> None:
    """Same statelessness as any LLM API: you resend history. Bedrock requires strictly
    alternating user/assistant turns starting with user."""
    history = []
    for text in ["My team uses ECS Fargate.", "Which Bedrock auth method fits us?"]:
        history.append({"role": "user", "content": [{"text": text}]})
        out = runtime.converse(modelId=MODEL_ID, messages=history, inferenceConfig={"maxTokens": 200})
        history.append(out["output"]["message"])
        print(out["output"]["message"]["content"][0]["text"], "\n")


def langchain_version() -> None:
    """With langchain-aws, Bedrock is just another provider. Everything in folders 01–08
    (structured output, tools, LangGraph) works by swapping the model line."""
    from langchain.chat_models import init_chat_model
    from langchain_aws import ChatBedrockConverse

    llm = ChatBedrockConverse(model=MODEL_ID, region_name=REGION, temperature=0, max_tokens=300)
    # equivalent: init_chat_model(f"bedrock_converse:{MODEL_ID}", region_name=REGION, temperature=0)
    print(llm.invoke("Name three Bedrock features.").content)
    _ = init_chat_model


if __name__ == "__main__":
    converse_once()
