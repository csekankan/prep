"""
02 — THE AGENT LOOP ON RAW BEDROCK CONVERSE (tool use)
=======================================================

Same loop as 02_single_agent/01_agent_loop_from_scratch.py, but in Bedrock's native format.
Seeing both shows the loop is universal; only the message shapes change.

Bedrock tool-use protocol:
  1. Send `toolConfig={"tools": [{"toolSpec": {name, description, inputSchema: {"json": <JSON Schema>}}}]}`.
  2. If the model wants a tool → stopReason == "tool_use" and the assistant message contains
     content blocks like {"toolUse": {"toolUseId", "name", "input"}} (possibly several = parallel calls).
  3. Append the assistant message, then a USER message with one {"toolResult": {...}} block per call,
     matching toolUseId. Mark failures with "status": "error" so the model knows to recover.
  4. Repeat until stopReason == "end_turn".
"""

import json

import boto3
from botocore.config import Config

MODEL_ID = "us.amazon.nova-pro-v1:0"
MAX_ITERATIONS = 6
runtime = boto3.client("bedrock-runtime", region_name="us-east-1", config=Config(retries={"mode": "adaptive"}))

ORDERS = {"ORD-1001": {"status": "shipped", "eta": "2026-11-14"}}


def get_order_status(order_id: str) -> dict:
    if order_id not in ORDERS:
        raise KeyError(f"order {order_id} not found; IDs look like ORD-1234")
    return ORDERS[order_id]


TOOL_IMPLS = {"get_order_status": get_order_status}

TOOL_CONFIG = {
    "tools": [
        {
            "toolSpec": {
                "name": "get_order_status",
                "description": "Get shipping status and ETA for an order. Use when the user asks where an order is.",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {"order_id": {"type": "string", "description": "Format ORD-1234"}},
                        "required": ["order_id"],
                    }
                },
            }
        }
    ]
}


def run_agent(question: str) -> str:
    messages = [{"role": "user", "content": [{"text": question}]}]
    system = [{"text": "You are ShopCo support. Use tools for order data. Be brief."}]

    for _ in range(MAX_ITERATIONS):
        resp = runtime.converse(
            modelId=MODEL_ID, system=system, messages=messages, toolConfig=TOOL_CONFIG,
            inferenceConfig={"maxTokens": 500, "temperature": 0},
        )
        assistant_msg = resp["output"]["message"]
        messages.append(assistant_msg)

        if resp["stopReason"] != "tool_use":
            # end_turn, max_tokens, or guardrail_intervened — return whatever text exists.
            return "".join(block.get("text", "") for block in assistant_msg["content"])

        tool_results = []
        for block in assistant_msg["content"]:
            if "toolUse" not in block:
                continue
            call = block["toolUse"]
            try:
                output = TOOL_IMPLS[call["name"]](**call["input"])
                tool_results.append({"toolResult": {"toolUseId": call["toolUseId"], "content": [{"json": output}]}})
            except Exception as exc:  # noqa: BLE001 — errors go back to the model as observations
                tool_results.append(
                    {"toolResult": {"toolUseId": call["toolUseId"], "content": [{"text": str(exc)}], "status": "error"}}
                )
        # Tool results travel in a USER-role message (Bedrock's convention).
        messages.append({"role": "user", "content": tool_results})

    return "Stopped: too many steps."


if __name__ == "__main__":
    print(run_agent("Where is ORD-1001?"))
    print(json.dumps(TOOL_CONFIG, indent=2)[:200])
