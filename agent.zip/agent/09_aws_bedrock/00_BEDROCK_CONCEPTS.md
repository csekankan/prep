# AWS Bedrock — Concepts

Amazon Bedrock is AWS's managed service for foundation models. You call models from many providers
(Anthropic Claude, Amazon Nova, Meta Llama, Mistral, Cohere, ...) through **one AWS API**, with
AWS IAM, VPC, KMS, CloudWatch and billing — no API keys from each vendor, data stays in your AWS account/region.

## Why teams pick Bedrock

| Need | Bedrock answer |
|---|---|
| Enterprise security | IAM auth (no API keys), VPC endpoints (PrivateLink), KMS encryption, data not used for training |
| One API, many models | **Converse API** — same request shape for Claude, Nova, Llama, Mistral |
| Managed RAG | **Knowledge Bases** — S3 → chunk → embed → vector store → retrieve, all managed |
| Managed safety | **Guardrails** — content filters, denied topics, PII, prompt-attack, grounding checks |
| Agent hosting | **AgentCore** — runtime, memory, identity, gateway (tools/MCP), observability for any framework (LangGraph, CrewAI, Strands) |
| Prompt versioning | **Prompt Management** — versioned prompts invoked by ARN |
| Evaluation | **Model / RAG evaluation jobs** — LLM-as-judge or human evaluation |
| Cost & scale | on-demand, **batch inference** (~50% cheaper), **provisioned throughput**, **cross-region inference profiles** |

## The service map

```
                      ┌──────────────────────── Amazon Bedrock ─────────────────────────┐
  your app ──IAM──►   │  bedrock-runtime        Converse / ConverseStream / InvokeModel │ ← model calls
                      │                         ApplyGuardrail                          │
                      │  bedrock-agent-runtime  Retrieve / RetrieveAndGenerate          │ ← Knowledge Base queries
                      │  bedrock-agent          KBs, data sources, ingestion, prompts   │ ← build-time / admin
                      │  bedrock                guardrails, eval jobs, logging config   │ ← control plane
                      │  bedrock-agentcore      hosted agent runtime + memory           │ ← agent hosting
                      └──────────────────────────────────────────────────────────────────┘
```

Rule of thumb: **runtime** clients are what your app calls per request; the others are used by
infrastructure code and pipelines.

## Key concepts

- **Model ID vs inference profile ID.** `anthropic.claude-3-5-haiku-20241022-v1:0` is a model in one region.
  `us.anthropic.claude-3-7-sonnet-20250219-v1:0` is a **cross-region inference profile**: Bedrock routes
  requests across several US regions for higher throughput. Newer models often *require* a profile.
  **Application inference profiles** wrap a model with your own ARN + tags → per-app cost tracking.
  Always check the Bedrock console for current IDs and request model access first.
- **Converse API.** Model-agnostic messages format: `messages=[{"role":"user","content":[{"text": "..."}]}]`,
  `system=[{"text": "..."}]`, `toolConfig` for tool use, `guardrailConfig` to attach a guardrail.
  Prefer it over `InvokeModel` (which uses each provider's native JSON body).
- **stopReason.** `end_turn` (done), `tool_use` (model wants a tool — the agent loop), `max_tokens`
  (truncated), `guardrail_intervened` (blocked).
- **Knowledge Base.** Data source (S3, web crawler, Confluence, SharePoint...) → chunking strategy
  (fixed, hierarchical, semantic) → embedding model (Titan / Cohere) → vector store (OpenSearch
  Serverless, Aurora pgvector, S3 Vectors, Pinecone...). Supports hybrid search, metadata filters, reranking.
  **Ingestion jobs** must run when documents change.
- **Guardrail.** A versioned policy object (`DRAFT` → `1`, `2`...). Attach to Converse, Knowledge
  Base generation, or Agents; or call **ApplyGuardrail** on any text — even for non-Bedrock models.
- **Throughput.** On-demand has per-account quotas (requests/tokens per minute). Handle
  `ThrottlingException` with retries + backoff; use inference profiles, batch, or provisioned throughput at scale.

## Bedrock vs calling OpenAI/Anthropic directly

| | Direct vendor API | Bedrock |
|---|---|---|
| Auth | API key | IAM roles (no secrets in code) |
| Network | public internet | can stay in VPC (PrivateLink) |
| Model choice | one vendor | many vendors, one API |
| Newest features | first | sometimes days/weeks later |
| Managed RAG/guardrails/agents | no | yes |

LangChain makes this a config choice: `init_chat_model("bedrock_converse:<model-id>")` instead of
`init_chat_model("openai:gpt-4o-mini")` — the rest of the repo's code works unchanged.

## Files in this folder

| File | What |
|---|---|
| `01_bedrock_converse_basics.py` | Converse, streaming, token usage, retries |
| `02_bedrock_tool_use_loop.py` | the agent loop with raw Converse tool use |
| `03_knowledge_base_rag.py` | Retrieve, RetrieveAndGenerate, LangChain retriever, ingestion |
| `04_bedrock_guardrails.py` | create/version guardrails, attach to Converse, ApplyGuardrail |
| `05_langgraph_on_bedrock.py` | LangGraph agent on Bedrock + AgentCore Runtime entrypoint |
| `PROD_PIPELINE.md` | **the production lifecycle on AWS**: KB sync Lambda, Bedrock as DeepEval judge, service mapping |
| `../10_llmops_pipeline/` | the monitor → alert → curate → train → gate → publish loop |
| `../11_kubernetes/` | deploying on EKS with IRSA, canary rollouts, GitOps, CI |
