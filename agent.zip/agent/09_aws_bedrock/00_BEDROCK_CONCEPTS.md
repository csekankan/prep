# AWS Bedrock: Concepts

**What Bedrock is.** Amazon Bedrock is AWS's managed service for **foundation models** (large pre-trained
models such as Claude or Llama). Instead of signing up with each model vendor separately, you call models
from many providers (Anthropic Claude, Amazon Nova, Meta Llama, Mistral, Cohere, and others) through
**one AWS API**. You also get the AWS features your company already uses:

- **IAM** (Identity and Access Management): AWS's permission system. It decides *who* may call *which* model.
  You don't need a separate API key from each vendor.
- **VPC** (Virtual Private Cloud): your private network inside AWS. Calls to Bedrock can stay inside it
  instead of crossing the public internet.
- **KMS** (Key Management Service): manages the encryption keys protecting your data.
- **CloudWatch**: AWS's logging, metrics, and alarm service.
- **One AWS bill**, with cost tags you can break down per team or app.

Your prompts and outputs stay in your AWS account and region, and AWS states that they are not used to
train the models. For banks, hospitals, and governments, that's often the deciding factor.

*Example:* a bank's legal team won't approve sending customer data to a startup's public API. The bank
already has an approved AWS setup, so using Claude through Bedrock, inside its own AWS account and
network, goes through the same approval process as any other AWS service.

## Why teams pick Bedrock

| Need | Bedrock answer |
|---|---|
| Enterprise security | IAM auth (no API keys), VPC endpoints (PrivateLink), KMS encryption, data not used for training |
| One API, many models | **Converse API**: the same request shape for Claude, Nova, Llama, Mistral |
| Managed RAG | **Knowledge Bases**: S3 documents are chunked, embedded, stored in a vector store, and retrieved, all managed |
| Managed safety | **Guardrails**: content filters, denied topics, PII, prompt-attack detection, grounding checks |
| Agent hosting | **AgentCore**: runtime, memory, identity, gateway (tools/MCP), and observability for any framework (LangGraph, CrewAI, Strands) |
| Prompt versioning | **Prompt Management**: versioned prompts invoked by ARN |
| Evaluation | **Model / RAG evaluation jobs**: LLM-as-judge or human evaluation |
| Cost and scale | on-demand, **batch inference** (~50% cheaper), **provisioned throughput**, **cross-region inference profiles** |

What the terms in this table mean:

- **VPC endpoints (PrivateLink)**: a private entrance to an AWS service from inside your VPC. Traffic to
  Bedrock never touches the public internet, and your servers don't even need internet access.
- **Knowledge Bases**: Bedrock's managed RAG. You point it at documents in S3; it splits them into
  **chunks**, turns each chunk into an **embedding** (a list of numbers representing its meaning), stores
  those in a **vector store** (a database that finds text by meaning), and at question time retrieves the
  most relevant chunks. Building this yourself is what `04_rag/` teaches.
- **Guardrails**: a configurable safety filter. It can block hateful or violent content, refuse
  **denied topics** you list (for example "investment advice"), mask **PII** (personally identifiable
  information such as emails and card numbers), detect **prompt attacks** (attempts to override your
  instructions), and run **grounding checks** (flag answers not supported by the retrieved documents, a
  defense against hallucination).
- **AgentCore**: managed hosting for agents built with any framework (**LangGraph**, **CrewAI**, AWS's own
  **Strands**). It provides the server that runs your agent (**runtime**), memory storage, user
  **identity**, a **gateway** that exposes tools (including **MCP** servers, the open standard for
  connecting AI apps to tools), and **observability** (traces and metrics).
- **ARN** (Amazon Resource Name): the unique ID of anything in AWS, for example
  `arn:aws:bedrock:us-east-1:123456789012:prompt/ABC123:3`. Calling a prompt "by ARN" means your code refers
  to a specific stored, versioned prompt instead of embedding the prompt text.
- **Batch inference**: send a file of thousands of requests and get the results within hours, at about half
  the normal price. Good for offline jobs such as classifying a year of tickets.
- **Provisioned throughput**: pay a fixed hourly price to reserve dedicated model capacity. It's needed for
  guaranteed high volume, and to serve your own fine-tuned (custom) models.
- **Cross-region inference profiles**: explained under "Key concepts" below.

## The service map

```
                      ┌──────────────────────── Amazon Bedrock ─────────────────────────┐
  your app ──IAM──►   │  bedrock-runtime        Converse / ConverseStream / InvokeModel │ ← model calls
                      │                         ApplyGuardrail                          │
                      │  bedrock-agent-runtime  Retrieve / RetrieveAndGenerate          │ ← Knowledge Base queries
                      │  bedrock-agent          KBs, data sources, ingestion, prompts   │ ← build-time / admin
                      │  bedrock                guardrails, eval jobs, logging config   │ ← control plane
                      │  bedrock-agentcore      hosted agent runtime + memory           │ ← agent hosting
                      └──────────────────────────────────────────────────────────────────┘
```

**How to read it:** Bedrock isn't one API but several, each with its own `boto3` client name (left
column). `boto3` is the AWS SDK for Python, and you create a client with `boto3.client("bedrock-runtime")`.
The middle column lists the main operations of each client, and the right column says what you use it for.

- `bedrock-runtime`: call models. **Converse** sends a conversation and gets the full reply,
  **ConverseStream** gets the reply token by token, **InvokeModel** is the older call that uses each
  vendor's own request format, and **ApplyGuardrail** runs a guardrail on any text.
- `bedrock-agent-runtime`: query a Knowledge Base. **Retrieve** returns matching chunks only.
  **RetrieveAndGenerate** retrieves *and* has a model write the answer, in one call.
- `bedrock-agent`: build and manage Knowledge Bases, their data sources, ingestion jobs, and stored prompts.
- `bedrock`: the **control plane**, meaning the administrative APIs that create and configure resources
  (guardrails, evaluation jobs, logging settings), as opposed to the per-request APIs.
- `bedrock-agentcore`: run agents hosted on AgentCore.

**Rule of thumb:** the two **runtime** clients are what your app calls on every user request. The others
are used by infrastructure code, setup scripts, and pipelines.

## Key concepts

### Model ID vs inference profile ID

A **model ID** names one model in one region, for example `anthropic.claude-3-5-haiku-20241022-v1:0`.

A **cross-region inference profile** ID has a geography prefix, for example
`us.anthropic.claude-3-7-sonnet-20250219-v1:0`. Requests to it are spread by Bedrock across several US
regions, so you get more capacity and fewer "too busy" errors than one region alone could give. Many newer
models can *only* be called through a profile.

An **application inference profile** is a profile you create yourself that wraps a model with your own ARN
and **tags** (labels such as `app=support-bot`, `env=prod`). Calls made through it show up under those tags
on the bill, so you can see exactly what each app costs.

*Example:* the support bot and the HR bot both use Claude. Each gets its own application inference profile,
and the monthly bill shows support-bot at $4,200 and hr-bot at $600, instead of one undivided "Claude" line.

Model IDs change as new versions are released, so always check the current IDs in the Bedrock console, and
**request access** to a model there before your first call (calls fail until access is granted).

### Converse API

The Converse API uses one **model-agnostic** format, meaning the same request shape works for every model:

- `messages=[{"role": "user", "content": [{"text": "..."}]}]`: the conversation so far.
- `system=[{"text": "..."}]`: the system prompt (standing instructions).
- `toolConfig`: the tools the model may call (see `02_bedrock_tool_use_loop.py`).
- `guardrailConfig`: attaches a guardrail to this call.

Prefer it over `InvokeModel`, which needs each vendor's native JSON body. With Converse, switching from
Claude to Llama is a one-line change of `modelId`. With `InvokeModel`, you'd rewrite the request and
response handling.

### stopReason

Every Converse response tells you *why* the model stopped generating:

| `stopReason` | Meaning | What your code should do |
|---|---|---|
| `end_turn` | the model finished its answer | show it to the user |
| `tool_use` | the model wants to call a tool | run the tool, send back the result, call the model again. This repetition *is* the agent loop |
| `max_tokens` | the answer was cut off at your length limit | raise `maxTokens`, or ask the model to continue |
| `guardrail_intervened` | a guardrail blocked the input or output | show the guardrail's safe message, and log it |

### Knowledge Base

The pipeline has four configurable parts:
1. **Data source**: where documents come from (S3, a web crawler, Confluence, SharePoint, and others).
2. **Chunking strategy**: how documents are split.
   - *Fixed*: every N tokens.
   - *Hierarchical*: small chunks for precise matching, linked to bigger parent chunks that are given to the
     model for context.
   - *Semantic*: split where the topic changes.
3. **Embedding model**: turns chunks into vectors, for example **Titan** (Amazon's) or **Cohere**.
4. **Vector store**: where vectors live. Options include **OpenSearch Serverless** (the default), **Aurora
   pgvector** (Postgres with vector search), **S3 Vectors**, and **Pinecone**.

It also supports **hybrid search** (meaning-based plus keyword search combined), **metadata filters** (for
example only documents where `department = "HR"`), and **reranking** (a second model re-sorts the results by
relevance).

**Ingestion jobs must run whenever documents change.** Adding a file to S3 does *not* update the Knowledge
Base by itself. An ingestion job re-reads the source and updates the index. `PROD_PIPELINE.md` shows how to
trigger it automatically.

### Guardrail

A guardrail is a **versioned** policy object. You edit the `DRAFT`, then publish numbered versions (`1`,
`2`, ...) that never change afterwards, so production can pin "version 3" and you always know exactly which
rules were active. You can attach it to Converse calls, to Knowledge Base answer generation, or to Bedrock
Agents. You can also call **ApplyGuardrail** on any text directly, even text produced by a model *outside*
Bedrock, such as one from OpenAI.

### Throughput and throttling

On-demand use has **per-account quotas**: limits on requests per minute and tokens per minute, per model and
region. Go over them and calls fail with `ThrottlingException`. Handle it with **retries and exponential
backoff** (wait 1 s, then 2 s, then 4 s, before retrying). At larger scale, use cross-region inference
profiles for more capacity, batch inference for offline work, or provisioned throughput for guaranteed
capacity.

*Example:* a launch-day traffic spike pushes the bot to 3× its usual load. Without backoff, users see
errors. With backoff plus a cross-region profile, most requests succeed after a short delay.

## Bedrock vs calling OpenAI/Anthropic directly

| | Direct vendor API | Bedrock |
|---|---|---|
| Auth | API key | IAM roles (no secrets in code) |
| Network | public internet | can stay inside your VPC (PrivateLink) |
| Model choice | one vendor | many vendors, one API |
| Newest features | first | sometimes days or weeks later |
| Managed RAG / guardrails / agents | no | yes |

An **IAM role** is a set of permissions that a server, container, or function *assumes* automatically. AWS
gives it short-lived credentials behind the scenes, so there is no long-lived API key to leak in a git
repository or a log file.

The trade-off: vendors release new models and features on their own APIs first, so Bedrock sometimes lags
a little behind.

LangChain makes the choice a configuration setting: `init_chat_model("bedrock_converse:<model-id>")`
instead of `init_chat_model("openai:gpt-4o-mini")`. The rest of the repo's code works unchanged.

## Files in this folder

| File | What |
|---|---|
| `01_bedrock_converse_basics.py` | Converse, streaming, token usage, retries |
| `02_bedrock_tool_use_loop.py` | the agent loop with raw Converse tool use |
| `03_knowledge_base_rag.py` | Retrieve, RetrieveAndGenerate, LangChain retriever, ingestion |
| `04_bedrock_guardrails.py` | create and version guardrails, attach to Converse, ApplyGuardrail |
| `05_langgraph_on_bedrock.py` | LangGraph agent on Bedrock, plus an AgentCore Runtime entrypoint |
| `PROD_PIPELINE.md` | **the production lifecycle on AWS**: Knowledge Base sync Lambda, Bedrock as DeepEval judge, service mapping |
| `../10_llmops_pipeline/` | the improvement loop: monitor, alert, curate data, train, evaluation gate, publish |
| `../11_kubernetes/` | deploying on EKS with IRSA, canary rollouts, GitOps, CI |
